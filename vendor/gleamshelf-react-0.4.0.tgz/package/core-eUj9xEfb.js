import { n as e } from "./rolldown-runtime-DArdT4gl.js";
import { a as t, r as n } from "./src-CJixF5Xc.js";
import { n as r, r as i, t as a } from "./ModelMode-D6OIyX2x.js";
function o(e) {
	let t = e.flat();
	if (!t.length) return {
		contours: [],
		aspect: 1
	};
	let n = t.map((e) => e[0]), r = t.map((e) => e[1]), [i, a, o, c] = [
		Math.min(...n),
		Math.max(...n),
		Math.min(...r),
		Math.max(...r)
	], l = Math.max(a - i, 1e-6), u = Math.max(c - o, 1e-6);
	return {
		contours: e.map((e) => e.map(([e, t]) => [s((e - i) / l - .5), s((t - o) / u - .5)])),
		aspect: l / u
	};
}
var s = (e) => Math.round(e * 1e4) / 1e4;
function c(e, t, n, r) {
	let i = new Uint8Array(t * n), a = [];
	for (let t of e) for (let e = 0; e < t.length; e++) {
		let n = r(t[e]), i = r(t[(e + 1) % t.length]);
		n[1] !== i[1] && a.push([
			n[0],
			n[1],
			i[0],
			i[1]
		]);
	}
	let o = [];
	for (let e = 0; e < n; e++) {
		let n = e + .5;
		o.length = 0;
		for (let [e, t, r, i] of a) (t <= n && i > n || i <= n && t > n) && o.push(e + (n - t) / (i - t) * (r - e));
		o.sort((e, t) => e - t);
		for (let n = 0; n + 1 < o.length; n += 2) {
			let r = Math.max(0, Math.ceil(o[n] - .5)), a = Math.min(t - 1, Math.floor(o[n + 1] - .5));
			for (let n = r; n <= a; n++) i[e * t + n] = 1;
		}
	}
	return i;
}
var l = /* @__PURE__ */ new Map(), u = /* @__PURE__ */ new WeakMap();
function d(e, t, n) {
	let r = u.get(e);
	if (r && r.sx === t && r.sy === n) return r.field;
	let i = `${t.toFixed(4)}x${n.toFixed(4)}:${JSON.stringify(e)}`, a = l.get(i);
	if (a) return u.set(e, {
		sx: t,
		sy: n,
		field: a
	}), a;
	let o = Math.max(t, n) / 2 * 1.3, s = 2 * o / 256, d = ([e, r]) => [(e * t + o) / s, (o - r * n) / s], p = c(e, 256, 256, d), m = f(e.map((e) => e.map(d)), 256, 256, 25), h = /* @__PURE__ */ new Float32Array(65536);
	for (let e = 0; e < h.length; e++) {
		let t = p[e] ? -m[e] : m[e];
		h[e] = Math.min(24, Math.max(-24, t));
	}
	let g = {
		grid: h,
		half: o,
		texel: s
	};
	return l.size > 64 && l.delete(l.keys().next().value), l.set(i, g), u.set(e, {
		sx: t,
		sy: n,
		field: g
	}), g;
}
function f(e, t, n, r) {
	let i = new Float32Array(t * n).fill(r);
	for (let a of e) for (let e = 0; e < a.length; e++) {
		let [o, s] = a[e], [c, l] = a[(e + 1) % a.length], u = c - o, d = l - s, f = u * u + d * d || 1e-12, p = Math.max(0, Math.floor(Math.min(o, c) - r)), m = Math.min(t - 1, Math.ceil(Math.max(o, c) + r)), h = Math.max(0, Math.floor(Math.min(s, l) - r)), g = Math.min(n - 1, Math.ceil(Math.max(s, l) + r));
		for (let e = h; e <= g; e++) {
			let n = e + .5;
			for (let r = p; r <= m; r++) {
				let a = r + .5, c = Math.min(1, Math.max(0, ((a - o) * u + (n - s) * d) / f)), l = a - o - u * c, p = n - s - d * c, m = Math.sqrt(l * l + p * p), h = e * t + r;
				m < i[h] && (i[h] = m);
			}
		}
	}
	return i;
}
function p(e, t, n) {
	let r = Math.min(255, Math.max(0, (t + e.half) / e.texel - .5)), i = Math.min(255, Math.max(0, (e.half - n) / e.texel - .5)), a = Math.floor(r), o = Math.floor(i), s = Math.min(255, a + 1), c = Math.min(255, o + 1), l = r - a, u = i - o, d = e.grid, f = ((d[o * 256 + a] * (1 - l) + d[o * 256 + s] * l) * (1 - u) + (d[c * 256 + a] * (1 - l) + d[c * 256 + s] * l) * u) * e.texel, p = Math.max(Math.abs(t) - e.half * .98, 0), m = Math.max(Math.abs(n) - e.half * .98, 0);
	return f + Math.hypot(p, m);
}
function m(e, t, n, r) {
	let i = (e, i) => e >= 0 && i >= 0 && e < n && i < r ? t[i * n + e] : 0;
	return e.map(([t, n], r) => {
		let [a, o] = e[(r + 1) % e.length], [s, c] = [a - t, o - n], [l, u] = [(t + a) / 2, (n + o) / 2], [d, f] = [l + c * .5, u - s * .5], [p, m] = [l - c * .5, u + s * .5], h = i(Math.floor(d), Math.floor(f)), g = i(Math.floor(p), Math.floor(m)), _ = h - g > 1e-6 ? Math.min(1, Math.max(0, (h - .5) / (h - g))) : .5;
		return [d + (p - d) * _, f + (m - f) * _];
	});
}
function h(e) {
	let t = e;
	for (let e = 0; e < 2; e++) t = t.map(([e, n], r) => {
		let [i, a] = t[(r + t.length - 1) % t.length], [o, s] = t[(r + 1) % t.length];
		return [(i + 2 * e + o) / 4, (a + 2 * n + s) / 4];
	});
	return t;
}
function g(e, t, n, r = .75, i) {
	let a = (r, i) => r >= 0 && i >= 0 && r < t && i < n ? e[i * t + r] : 0, o = /* @__PURE__ */ new Map(), s = (e, n) => n * (t + 1) + e, c = (e, t, n, r) => {
		let i = s(e, t), a = o.get(i);
		a ? a.push(s(n, r)) : o.set(i, [s(n, r)]);
	};
	for (let e = 0; e <= n; e++) for (let r = 0; r <= t; r++) {
		if (r < t) {
			let t = a(r, e - 1), n = a(r, e);
			t && !n ? c(r, e, r + 1, e) : n && !t && c(r + 1, e, r, e);
		}
		if (e < n) {
			let t = a(r - 1, e), n = a(r, e);
			n && !t ? c(r, e, r, e + 1) : t && !n && c(r, e + 1, r, e);
		}
	}
	let l = [];
	for (let [e] of o) for (; o.get(e)?.length;) {
		let a = [], s = e;
		for (let r = 0; r < 4 * (t + 1) * (n + 1); r++) {
			a.push([s % (t + 1), Math.floor(s / (t + 1))]);
			let n = o.get(s), r = n.pop();
			if (n.length || o.delete(s), s = r, s === e) break;
		}
		a.length >= 4 && l.push(_(i ? h(m(a, i, t, n)) : a, r));
	}
	return l.filter((e) => e.length >= 3);
}
function _(e, t) {
	if (e.length < 8 || t <= 0) return e;
	let n = 0, r = -1;
	for (let t = 1; t < e.length; t++) {
		let i = Math.hypot(e[t][0] - e[0][0], e[t][1] - e[0][1]);
		i > r && (r = i, n = t);
	}
	let i = (e) => {
		if (e.length < 3) return e;
		let [n, r] = [e[0], e[e.length - 1]], a = Math.hypot(r[0] - n[0], r[1] - n[1]) || 1e-9, o = 0, s = 0;
		for (let t = 1; t < e.length - 1; t++) {
			let i = e[t], c = Math.abs((r[0] - n[0]) * (n[1] - i[1]) - (n[0] - i[0]) * (r[1] - n[1])) / a;
			c > o && (o = c, s = t);
		}
		return o <= t ? [n, r] : [...i(e.slice(0, s + 1)).slice(0, -1), ...i(e.slice(s))];
	}, a = i(e.slice(0, n + 1)), o = i([...e.slice(n), e[0]]);
	return [...a.slice(0, -1), ...o.slice(0, -1)];
}
var v = (e) => e.reduce((t, n, r) => t + (n[0] * e[(r + 1) % e.length][1] - e[(r + 1) % e.length][0] * n[1]), 0) / 2, y = (e, t, n = Math.PI / 2) => Array.from({ length: e }, (r, i) => {
	let a = n + i / e * Math.PI * 2;
	return [Math.cos(a) * t(i), Math.sin(a) * t(i)];
}), b = {
	star: {
		label: "Star",
		contours: [y(10, (e) => e % 2 ? .2 : .5)]
	},
	heart: {
		label: "Heart",
		contours: [Array.from({ length: 72 }, (e, t) => {
			let n = t / 72 * Math.PI * 2;
			return [16 * Math.sin(n) ** 3, 13 * Math.cos(n) - 5 * Math.cos(2 * n) - 2 * Math.cos(3 * n) - Math.cos(4 * n)];
		})]
	},
	hexagon: {
		label: "Hexagon",
		contours: [y(6, () => .5, 0)]
	},
	arrow: {
		label: "Arrow",
		contours: [[
			[-.5, -.12],
			[.1, -.12],
			[.1, -.3],
			[.5, 0],
			[.1, .3],
			[.1, .12],
			[-.5, .12]
		]]
	},
	cross: {
		label: "Plus",
		contours: [[
			[-.15, -.5],
			[.15, -.5],
			[.15, -.15],
			[.5, -.15],
			[.5, .15],
			[.15, .15],
			[.15, .5],
			[-.15, .5],
			[-.15, .15],
			[-.5, .15],
			[-.5, -.15],
			[-.15, -.15]
		]]
	},
	donut: {
		label: "Washer",
		contours: [y(48, () => .5), y(48, () => .22)]
	},
	bolt: {
		label: "Bolt",
		contours: [[
			[.1, .5],
			[-.3, -.05],
			[-.02, -.05],
			[-.15, -.5],
			[.3, .08],
			[.02, .08]
		]]
	}
}, x = [
	"box",
	"sphere",
	"cylinder",
	"cone",
	"torus",
	"capsule",
	"pyramid"
], S = [
	...x,
	"extrude",
	"text",
	"mesh",
	"group"
], C = [
	"add",
	"subtract",
	"intersect"
], w = [
	"matte",
	"satin",
	"glossy",
	"metal"
], T = [
	"soft",
	"toon",
	"flat",
	"clay"
], E = 64e6, D = 128e6, O = {
	box: "Box",
	sphere: "Sphere",
	cylinder: "Cylinder",
	cone: "Cone",
	torus: "Ring",
	capsule: "Capsule",
	pyramid: "Pyramid",
	extrude: "Outline",
	text: "Text",
	mesh: "Model",
	group: "Group"
}, k = {
	box: [
		1,
		1,
		1
	],
	sphere: [
		1,
		1,
		1
	],
	cylinder: [
		.8,
		1.2,
		.8
	],
	cone: [
		1,
		1.2,
		1
	],
	torus: [
		1.2,
		.36,
		1.2
	],
	capsule: [
		.6,
		1.4,
		.6
	],
	pyramid: [
		1,
		1,
		1
	],
	extrude: [
		1,
		1,
		.35
	],
	text: [
		2,
		.6,
		.3
	],
	mesh: [
		1,
		1,
		1
	],
	group: [
		1,
		1,
		1
	]
}, A = [
	"#ff7ab6",
	"#a78bfa",
	"#67e8f9",
	"#fbbf24",
	"#34d399",
	"#f87171",
	"#60a5fa"
], j = 0, M = () => `s${Date.now().toString(36)}${(j++).toString(36)}`;
function N(e, t = 0, n = {}) {
	let r = k[e];
	return {
		id: M(),
		name: O[e],
		kind: e,
		position: [
			0,
			r[1] / 2,
			0
		],
		rotation: [
			0,
			0,
			0
		],
		size: [...r],
		round: e === "box" || e === "pyramid" ? .08 : e === "extrude" || e === "text" ? .05 : 0,
		thickness: .3,
		combine: "add",
		blend: 0,
		color: A[t % A.length],
		finish: "satin",
		hidden: !1,
		...n
	};
}
function P() {
	return {
		version: 1,
		shapes: [N("box", 0, { position: [
			0,
			.5,
			0
		] })],
		light: {
			azimuth: -40,
			elevation: 50,
			intensity: 1.4,
			ambient: .35,
			color: "#ffffff",
			shadows: !0
		},
		style: {
			look: "soft",
			outline: 0,
			outlineColor: "#1b1530",
			bands: 3
		},
		background: {
			transparent: !0,
			color: "#f4f1fb"
		},
		ground: {
			on: !0,
			shadow: .35
		},
		camera: {
			yaw: 30,
			pitch: 22,
			distance: 5.5,
			target: [
				0,
				.5,
				0
			],
			fov: 35,
			projection: "perspective"
		}
	};
}
var F = (e, t, n, r) => Math.min(n, Math.max(t, typeof e == "number" && Number.isFinite(e) ? e : r)), I = (e, t) => typeof e == "string" && /^#[0-9a-f]{6}$/i.test(e) ? e.toLowerCase() : t, L = (e, t, n, r) => Array.isArray(e) && e.length === 3 ? [
	F(e[0], t, n, r[0]),
	F(e[1], t, n, r[1]),
	F(e[2], t, n, r[2])
] : r, R = (e, t, n) => t.includes(e) ? e : n;
function ee(e) {
	if (!Array.isArray(e)) return;
	let t = e.slice(0, 64).filter(Array.isArray).map((e) => e.slice(0, 2e3).filter((e) => Array.isArray(e) && Number.isFinite(e[0]) && Number.isFinite(e[1])).map(([e, t]) => [Math.min(.5, Math.max(-.5, e)), Math.min(.5, Math.max(-.5, t))])).filter((e) => e.length >= 3);
	return t.length ? t : void 0;
}
function z(e) {
	let t = o(e);
	return {
		outline: t.contours,
		aspect: t.aspect
	};
}
function te(e) {
	let t = 0, n = 0, r = 0, i = (e) => {
		e.kind === "mesh" ? r += 1 : (t += 1, n += +!!e.outline);
	};
	for (let n of e) n.kind === "group" ? (t += 2, (n.children ?? []).forEach(i)) : i(n);
	return {
		slots: t,
		fields: n,
		meshes: r
	};
}
var B = (e) => {
	let t = te(e);
	return t.slots <= 48 && t.fields <= 16 && t.meshes <= 16;
};
function V(e, t = 0, n = !1) {
	let r = e && typeof e == "object" ? e : {}, i = n ? S.filter((e) => e !== "group") : S, a = R(r.kind, i, "box"), o = ee(r.outline);
	(a === "extrude" || a === "text") && !o && (a = "box");
	let s = typeof r.asset == "string" && /^[\w-]{1,40}$/.test(r.asset) ? r.asset : void 0;
	a === "mesh" && !s && (a = "box");
	let c = N(a, t), l = r.text ?? {}, u = {};
	return (a === "extrude" || a === "text") && (u.outline = o), a === "text" && (u.text = {
		value: typeof l.value == "string" ? l.value.slice(0, 200) : "Text",
		font: typeof l.font == "string" && l.font.trim() ? l.font.slice(0, 80) : "Arial",
		weight: Math.round(F(l.weight, 100, 900, 700) / 100) * 100
	}), a === "group" && (u.children = Array.isArray(r.children) ? r.children.slice(0, 48).map((e, n) => V(e, t + n, !0)) : []), a === "mesh" && (u.asset = s, u.ownColors = r.ownColors !== !1), {
		id: typeof r.id == "string" && r.id ? r.id.slice(0, 40) : c.id,
		name: typeof r.name == "string" && r.name.trim() ? r.name.slice(0, 60) : c.name,
		kind: a,
		position: L(r.position, -100, 100, c.position),
		rotation: L(r.rotation, -360, 360, c.rotation),
		size: L(r.size, .01, 100, c.size),
		round: F(r.round, 0, .5, c.round),
		thickness: F(r.thickness, .05, .5, c.thickness),
		combine: R(r.combine, C, "add"),
		blend: F(r.blend, 0, 1, 0),
		color: I(r.color, c.color),
		finish: R(r.finish, w, "satin"),
		hidden: r.hidden === !0,
		...u
	};
}
function ne(e) {
	let t = [...e];
	for (; t.length && !B(t);) t.pop();
	return t;
}
function H(e) {
	let t = {};
	if (!e || typeof e != "object") return t;
	let n = 0;
	for (let [r, i] of Object.entries(e)) {
		let e = i ?? {};
		!/^[\w-]{1,40}$/.test(r) || typeof e.data != "string" || !e.data || e.data.length > 64e6 || n + e.data.length > 128e6 || !/^[A-Za-z0-9+/]+={0,2}$/.test(e.data) || (n += e.data.length, t[r] = {
			name: typeof e.name == "string" && e.name.trim() ? e.name.slice(0, 80) : "Model",
			data: e.data,
			triangles: Math.max(0, Math.round(F(e.triangles, 0, 1e8, 0))),
			size: L(e.size, 0, 1e6, [
				1,
				1,
				1
			]),
			centre: L(e.centre, -1e6, 1e6, [
				0,
				0,
				0
			])
		});
	}
	return t;
}
function U(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e) for (let e of n.kind === "group" ? n.children ?? [] : [n]) e.kind === "mesh" && e.asset && t.add(e.asset);
	return t;
}
function W(e) {
	if (!e.assets) return e;
	let t = U(e.shapes), n = Object.fromEntries(Object.entries(e.assets).filter(([e]) => t.has(e))), { assets: r, ...i } = e;
	return Object.keys(n).length ? {
		...i,
		assets: n
	} : i;
}
function re(e) {
	let t = [];
	return e.shapes.forEach((n, r) => {
		if (n.hidden) return;
		let i = n.kind === "group" ? (n.children ?? []).map((e, t) => [e, [r, t]]) : [[n, [r]]];
		for (let [n, r] of i) {
			let i = n.kind === "mesh" && !n.hidden && n.asset ? e.assets?.[n.asset] : void 0;
			i && t.push({
				shape: n,
				path: r,
				asset: i
			});
		}
	}), t;
}
function ie(e, t) {
	if (!t) return;
	let n = e.shapes[t[0]];
	return t.length === 1 ? n : n?.children?.[t[1]];
}
function ae(e) {
	let t = [];
	return e.shapes.forEach((e, n) => {
		if (e.hidden || e.kind === "mesh") return;
		if (e.kind !== "group") return void t.push({
			op: "shape",
			shape: e,
			path: [n]
		});
		let r = (e.children ?? []).map((e, t) => ({
			c: e,
			j: t
		})).filter(({ c: e }) => !e.hidden && e.kind !== "mesh");
		if (r.length) {
			t.push({
				op: "begin",
				group: e,
				path: [n]
			});
			for (let { c: e, j: i } of r) t.push({
				op: "shape",
				shape: e,
				path: [n, i]
			});
			t.push({
				op: "end",
				group: e,
				path: [n]
			});
		}
	}), t;
}
function G(e) {
	let t = P(), n = e && typeof e == "object" ? e : {}, r = n.light ?? {}, i = n.style ?? {}, a = n.background ?? {}, o = n.ground ?? {}, s = n.camera ?? {}, c = H(n.assets), l = (e) => e.kind !== "mesh" || e.asset !== void 0 && e.asset in c, u = Array.isArray(n.shapes) ? ne(n.shapes.slice(0, 48).map((e, t) => V(e, t)).filter(l).map((e) => e.kind === "group" ? {
		...e,
		children: (e.children ?? []).filter(l)
	} : e)) : t.shapes, d = U(u), f = Object.fromEntries(Object.entries(c).filter(([e]) => d.has(e)));
	return {
		version: 1,
		shapes: u,
		...Object.keys(f).length ? { assets: f } : {},
		light: {
			azimuth: F(r.azimuth, -180, 180, t.light.azimuth),
			elevation: F(r.elevation, 0, 90, t.light.elevation),
			intensity: F(r.intensity, 0, 3, t.light.intensity),
			ambient: F(r.ambient, 0, 1, t.light.ambient),
			color: I(r.color, t.light.color),
			shadows: r.shadows !== !1
		},
		style: {
			look: R(i.look, T, t.style.look),
			outline: F(i.outline, 0, 12, t.style.outline),
			outlineColor: I(i.outlineColor, t.style.outlineColor),
			bands: Math.round(F(i.bands, 2, 6, t.style.bands))
		},
		background: {
			transparent: a.transparent !== !1,
			color: I(a.color, t.background.color)
		},
		ground: {
			on: o.on !== !1,
			shadow: F(o.shadow, 0, 1, t.ground.shadow)
		},
		camera: {
			yaw: F(s.yaw, -360, 360, t.camera.yaw),
			pitch: F(s.pitch, -89, 89, t.camera.pitch),
			distance: F(s.distance, .5, 200, t.camera.distance),
			target: L(s.target, -100, 100, t.camera.target),
			fov: F(s.fov, 10, 90, t.camera.fov),
			projection: R(s.projection, ["perspective", "orthographic"], "perspective")
		}
	};
}
var oe = {
	front: {
		yaw: 0,
		pitch: 0,
		projection: "orthographic"
	},
	side: {
		yaw: 90,
		pitch: 0,
		projection: "orthographic"
	},
	top: {
		yaw: 0,
		pitch: 89,
		projection: "orthographic"
	},
	isometric: {
		yaw: 45,
		pitch: 35.264,
		projection: "orthographic"
	},
	perspective: {
		yaw: 30,
		pitch: 22,
		projection: "perspective"
	}
}, se = [
	"light",
	"style",
	"background",
	"ground",
	"camera"
], ce = Object.keys(N("box")).concat([
	"outline",
	"text",
	"children",
	"asset",
	"ownColors"
]);
function le(e, t, n) {
	return e === "outline" ? V({
		kind: "extrude",
		outline: t
	}, 0, n).outline : e === "text" ? V({
		kind: "text",
		outline: [[
			[0, 0],
			[1, 0],
			[0, 1]
		]],
		text: t
	}, 0, n).text : e === "children" ? V({
		kind: "group",
		children: t
	}, 0).children : e === "asset" ? V({
		kind: "mesh",
		asset: t
	}, 0, n).asset : e === "ownColors" ? V({
		kind: "mesh",
		asset: "a",
		ownColors: t
	}, 0, n).ownColors : V({
		...N("box"),
		kind: e === "kind" ? t : void 0,
		[e]: t
	}, 0, n)[e];
}
var ue = (e, n) => {
	let r = t(e), [i, a] = r;
	if (i === "shapes") {
		if (r.length === 1) {
			if (!Array.isArray(n)) return "invalid-value";
			let e = n.map((e, t) => V(e, t));
			return B(e) ? {
				value: e,
				label: "Shapes"
			} : "invalid-value";
		}
		let e = Number(a);
		if (!Number.isInteger(e) || e < 0 || e >= 48) return "invalid-path";
		if (r.length === 2) return {
			value: V(n, e),
			label: "Shape"
		};
		if (r[2] === "children" && r.length >= 4) {
			let e = Number(r[3]);
			if (!Number.isInteger(e) || e < 0 || e >= 48) return "invalid-path";
			if (r.length === 4) return {
				value: V(n, e, !0),
				label: "Shape"
			};
			let t = r[4];
			return r.length !== 5 || !ce.includes(t) || t === "id" || t === "children" ? "invalid-path" : {
				value: le(t, n, !0),
				label: t
			};
		}
		let t = r[2];
		return r.length !== 3 || !ce.includes(t) || t === "id" ? "invalid-path" : {
			value: le(t, n, !1),
			label: t
		};
	}
	if (i === "assets" && r.length === 1) return {
		value: H(n),
		label: "Models"
	};
	if (se.includes(i ?? "") && r.length === 2 && a) {
		let e = i, t = G({});
		return a in t[e] ? {
			value: G({ [e]: {
				...t[e],
				[a]: n
			} })[e][a],
			label: `${e} ${a}`
		} : "invalid-path";
	}
	return "invalid-path";
}, de = (e) => e.length === 1 ? `shapes/${e[0]}` : `shapes/${e[0]}/children/${e[1]}`, fe = class extends n {
	constructor(e) {
		super(G(e), ue);
	}
	get shapes() {
		return this.doc.shapes;
	}
	fits(e) {
		return B([...this.doc.shapes, e]);
	}
	addShape(e, t = {}) {
		let n = V(N(e, this.doc.shapes.length, t), this.doc.shapes.length);
		if (n.kind !== e || !this.fits(n)) return -1;
		if (!t.position) {
			let [e, , t] = this.doc.camera.target, r = this.doc.shapes.length;
			n.position = [
				e + (r ? (r % 2 ? 1 : -1) * .7 * Math.ceil(r / 2) : 0),
				n.size[1] / 2,
				t
			];
		}
		return this.apply(`Add ${n.name.toLowerCase()}`, [["shapes", [...this.doc.shapes, n]]]), this.doc.shapes.length - 1;
	}
	addModel(e, t = {}, n = 1.5) {
		let r = M(), i = Math.max(...e.size, 1e-9), a = e.size.map((e) => Math.max(.01, e / i * n)), o = V(N("mesh", this.doc.shapes.length, {
			name: e.name.slice(0, 60),
			size: a,
			asset: r,
			ownColors: !0,
			...t
		}), this.doc.shapes.length);
		if (o.kind !== "mesh" || !this.fits(o)) return -1;
		if (!t.position) {
			let [e, , t] = this.doc.camera.target, n = this.doc.shapes.length;
			o.position = [
				e + (n ? (n % 2 ? 1 : -1) * .9 * Math.ceil(n / 2) : 0),
				o.size[1] / 2,
				t
			];
		}
		return this.apply(`Import ${o.name}`, [["assets", {
			...this.doc.assets ?? {},
			[r]: e
		}], ["shapes", [...this.doc.shapes, o]]]), this.doc.shapes.length - 1;
	}
	updateShapeAt(e, t, n = "Change shape") {
		ie(this.doc, e) && this.apply(n, Object.entries(t).filter(([e]) => e !== "id").map(([t, n]) => [`${de(e)}/${t}`, n]));
	}
	updateShape(e, t, n = "Change shape") {
		this.updateShapeAt([e], t, n);
	}
	setChildren(e, t) {
		this.doc.shapes[e]?.kind === "group" && this.apply("Move group", [[`shapes/${e}/children`, t]]);
	}
	listOf(e) {
		if (e.length === 1) return this.doc.shapes[e[0]] ? {
			list: [...this.doc.shapes],
			at: e[0],
			write: (e, t) => this.apply(t, [["shapes", e]])
		} : null;
		let t = this.doc.shapes[e[0]];
		return t?.children?.[e[1]] ? {
			list: [...t.children],
			at: e[1],
			write: (t, n) => this.apply(n, [[`shapes/${e[0]}/children`, t]])
		} : null;
	}
	removeShapeAt(e) {
		let t = this.listOf(e);
		if (!t) return;
		let n = t.list[t.at].name;
		t.write(t.list.filter((e, n) => n !== t.at), `Delete ${n}`);
	}
	removeShape(e) {
		this.removeShapeAt([e]);
	}
	duplicateShapeAt(e) {
		let t = this.listOf(e);
		if (!t) return null;
		let n = t.list[t.at], r = (e) => ({
			...e,
			id: M(),
			position: [
				e.position[0] + (n.kind === "group" ? 1 : n.size[0] * .6),
				e.position[1],
				e.position[2]
			],
			children: e.children?.map(r)
		}), i = {
			...r(n),
			name: `${n.name} copy`
		};
		return this.fits(i) ? (t.list.splice(t.at + 1, 0, i), t.write(t.list, `Duplicate ${n.name}`), e.length === 1 ? [t.at + 1] : [e[0], t.at + 1]) : null;
	}
	duplicateShape(e) {
		return this.duplicateShapeAt([e])?.[0] ?? -1;
	}
	moveShapeAt(e, t) {
		let n = this.listOf(e);
		if (!n) return e;
		let r = n.at + t;
		return r < 0 || r >= n.list.length ? e : ([n.list[n.at], n.list[r]] = [n.list[r], n.list[n.at]], n.write(n.list, "Reorder shapes"), e.length === 1 ? [r] : [e[0], r]);
	}
	moveShape(e, t) {
		return this.moveShapeAt([e], t)[0];
	}
	group(e) {
		let t = [...new Set(e)].filter((e) => this.doc.shapes[e] && this.doc.shapes[e].kind !== "group").sort((e, t) => e - t);
		if (!t.length) return -1;
		let n = N("group", 0, {
			name: "Group",
			children: t.map((e) => this.doc.shapes[e]),
			combine: "add",
			blend: 0
		}), r = this.doc.shapes.filter((e, n) => !t.includes(n)), i = t[0] - t.filter((e) => e < t[0]).length;
		return r.splice(i, 0, n), B(r) ? (this.apply("Group", [["shapes", r]]), i) : -1;
	}
	ungroup(e) {
		let t = this.doc.shapes[e];
		if (t?.kind !== "group") return -1;
		let n = [...this.doc.shapes];
		return n.splice(e, 1, ...t.children ?? []), this.apply("Ungroup", [["shapes", n]]), e;
	}
	setSetting(e, t, n, r) {
		this.apply(r ?? `${e} ${t}`, [[`${e}/${t}`, n]]);
	}
	setView(e) {
		let t = oe[e];
		this.apply(`${e[0].toUpperCase()}${e.slice(1)} view`, [
			["camera/yaw", t.yaw],
			["camera/pitch", t.pitch],
			["camera/projection", t.projection]
		]);
	}
	frameAll(e = 1) {
		let t = this.doc.shapes.flatMap((e) => e.hidden ? [] : e.kind === "group" ? (e.children ?? []).filter((e) => !e.hidden) : [e]).filter((e) => e.combine === "add");
		if (!t.length) return;
		let n = [
			Infinity,
			Infinity,
			Infinity
		], r = [
			-Infinity,
			-Infinity,
			-Infinity
		];
		for (let e of t) {
			let t = Math.hypot(...e.size) / 2;
			for (let i = 0; i < 3; i++) n[i] = Math.min(n[i], e.position[i] - t), r[i] = Math.max(r[i], e.position[i] + t);
		}
		let i = n.map((e, t) => (e + r[t]) / 2), a = Math.max(...r.map((e, t) => e - n[t])) / 2 * 1.25 / Math.min(1, e), o = Math.min(200, Math.max(1.5, a / Math.tan(this.doc.camera.fov / 2 * Math.PI / 180)));
		this.apply("Frame all", [["camera/target", i], ["camera/distance", o]]);
	}
	setCamera(e) {
		this.apply("Turn the view", Object.entries(e).map(([e, t]) => [`camera/${e}`, t]));
	}
};
function pe(e, t, n = {}) {
	let { color: r, name: i, depth: a = .35, long: o = 2, viewAspect: s = 1 } = n, [c, l] = t >= 1 ? [o, o / t] : [o * t, o], u = new fe({
		...P(),
		shapes: []
	});
	return u.addShape("extrude", {
		outline: e,
		size: [
			c,
			l,
			a
		],
		position: [
			0,
			l / 2,
			0
		],
		...r ? { color: r } : {},
		...i ? { name: i } : {}
	}), u.frameAll(s), u.document;
}
//#endregion
//#region ../scene3d/src/model/sdf.ts
var me = Math.PI / 180;
function he([e, t, n]) {
	let [r, i, a, o, s, c] = [
		Math.cos(e * me),
		Math.sin(e * me),
		Math.cos(t * me),
		Math.sin(t * me),
		Math.cos(n * me),
		Math.sin(n * me)
	];
	return [
		a * s,
		-a * c,
		o,
		r * c + i * o * s,
		r * s - i * o * c,
		-i * a,
		i * c - r * o * s,
		i * s + r * o * c,
		r * a
	];
}
function ge(e, t) {
	let n = he(e.rotation), r = [
		t[0] - e.position[0],
		t[1] - e.position[1],
		t[2] - e.position[2]
	];
	return [
		n[0] * r[0] + n[3] * r[1] + n[6] * r[2],
		n[1] * r[0] + n[4] * r[1] + n[7] * r[2],
		n[2] * r[0] + n[5] * r[1] + n[8] * r[2]
	];
}
var _e = (e, t) => Math.hypot(e, t), ve = (e, t, n) => Math.hypot(e, t, n), ye = (e, t, n) => Math.min(n, Math.max(t, e));
function be(e, t) {
	let [n, r, i] = [
		e.size[0] / 2,
		e.size[1] / 2,
		e.size[2] / 2
	], a = e.round * Math.min(e.size[0], e.size[1], e.size[2]), [o, s, c] = t;
	switch (e.kind) {
		case "box": {
			let e = Math.abs(o) - n + a, t = Math.abs(s) - r + a, l = Math.abs(c) - i + a;
			return ve(Math.max(e, 0), Math.max(t, 0), Math.max(l, 0)) + Math.min(Math.max(e, t, l), 0) - a;
		}
		case "sphere": {
			let e = ve(o / n, s / r, c / i), t = ve(o / (n * n), s / (r * r), c / (i * i));
			return t > 0 ? e * (e - 1) / t : -Math.min(n, r, i);
		}
		case "cylinder": {
			let e = Math.min(n, i), t = Math.min(a, e, r), l = _e(o * e / n, c * e / i) - e + t, u = Math.abs(s) - r + t;
			return Math.min(Math.max(l, u), 0) + _e(Math.max(l, 0), Math.max(u, 0)) - t;
		}
		case "cone": {
			let e = Math.min(n, i), t = _e(o * e / n, c * e / i), l = s, u = r, d = -e, f = 2 * u, p = t - Math.min(t, l < 0 ? e : 0), m = Math.abs(l) - u, h = ye((-t * d + (u - l) * f) / (d * d + f * f), 0, 1), g = t + d * h, _ = l - u + f * h;
			return (g < 0 && m < 0 ? -1 : 1) * Math.sqrt(Math.min(p * p + m * m, g * g + _ * _)) - a * .5;
		}
		case "torus": {
			let t = Math.min(e.thickness * n, r), a = Math.max(n - t, .001);
			return _e(_e(o, c * n / i) - a, s) - t;
		}
		case "capsule": {
			let e = Math.min(n, i), t = Math.max(r - e, 0), a = s - ye(s, -t, t);
			return ve(o * e / n, a, c * e / i) - e;
		}
		case "pyramid": {
			let e = Math.min(n, i), t = 2 * r / (2 * e), l = Math.abs(o * e / n) / (2 * e), u = Math.abs(c * e / i) / (2 * e), d = (s + r) / (2 * e);
			u > l && ([l, u] = [u, l]), l -= .5, u -= .5;
			let f = t * t + .25, p = u, m = t * d - .5 * l, h = t * l + .5 * d, g = Math.max(-p, 0), _ = ye((m - .5 * u) / (f + .25), 0, 1), v = f * (p + g) * (p + g) + m * m, y = f * (p + .5 * _) * (p + .5 * _) + (m - f * _) * (m - f * _), b = Math.min(m, -p * f - m * .5) > 0 ? 0 : Math.min(v, y);
			return 2 * e * Math.sqrt((b + h * h) / f) * Math.sign(Math.max(h, -d)) - a * .5;
		}
		case "extrude":
		case "text": {
			if (!e.outline) return 1e9;
			let t = p(d(e.outline, e.size[0], e.size[1]), o, s), n = Math.min(a, i * .95), r = t + n, l = Math.abs(c) - i + n;
			return Math.min(Math.max(r, l), 0) + _e(Math.max(r, 0), Math.max(l, 0)) - n;
		}
		case "group":
		case "mesh": return 1e9;
	}
}
var xe = (e) => e.blend * .6;
function Se(e, t, n, r) {
	if (n === "add") {
		if (r > 1e-4) {
			let n = ye(.5 + .5 * (e - t) / r, 0, 1);
			return {
				d: e * (1 - n) + t * n - r * n * (1 - n),
				h: n
			};
		}
		return t < e ? {
			d: t,
			h: 1
		} : {
			d: e,
			h: 0
		};
	}
	if (n === "subtract") {
		let n = -t;
		if (r > 1e-4) {
			let t = ye(.5 - .5 * (n - e) / r, 0, 1);
			return {
				d: e * (1 - t) + n * t + r * t * (1 - t),
				h: t
			};
		}
		return n > e ? {
			d: n,
			h: 1
		} : {
			d: e,
			h: 0
		};
	}
	if (r > 1e-4) {
		let n = ye(.5 - .5 * (t - e) / r, 0, 1);
		return {
			d: e * (1 - n) + t * n + r * n * (1 - n),
			h: n
		};
	}
	return t > e ? {
		d: t,
		h: 1
	} : {
		d: e,
		h: 0
	};
}
var Ce = {
	matte: [8, 0],
	satin: [32, 0],
	glossy: [140, 0],
	metal: [64, 1]
}, we = (e) => {
	let t = parseInt(e.slice(1), 16);
	return [
		(t >> 16 & 255) / 255,
		(t >> 8 & 255) / 255,
		(t & 255) / 255
	];
}, Te = (e, t, n) => [
	e[0] + (t[0] - e[0]) * n,
	e[1] + (t[1] - e[1]) * n,
	e[2] + (t[2] - e[2]) * n
];
function Ee(e, t, n = ae(e)) {
	let r = {
		d: 1e9,
		color: [
			.8,
			.8,
			.8
		],
		shine: 32,
		metal: 0,
		owner: null
	}, i = r;
	for (let e of n) {
		if (e.op === "begin") {
			i = r, r = {
				d: 1e9,
				color: [
					.8,
					.8,
					.8
				],
				shine: 32,
				metal: 0,
				owner: null
			};
			continue;
		}
		let n = e.op === "end" ? e.group : e.shape, a = e.op === "end" ? r.d : be(n, ge(n, t)), o = e.op === "end" ? r.color : we(n.color), [s, c] = e.op === "end" ? [r.shine, r.metal] : Ce[n.finish], l = e.op === "end" ? r.owner : e.path, u = e.op === "end" ? i : r, { d, h: f } = Se(u.d, a, n.combine, xe(n));
		r = {
			d,
			color: Te(u.color, o, f),
			shine: u.shine + (s - u.shine) * f,
			metal: u.metal + (c - u.metal) * f,
			owner: f > .5 ? l : u.owner
		};
	}
	return r;
}
function De(e, t, n, r = 200) {
	let i = ae(e), a = 0;
	for (let o = 0; o < 256 && a < r; o++) {
		let r = Ee(e, [
			t[0] + n[0] * a,
			t[1] + n[1] * a,
			t[2] + n[2] * a
		], i);
		if (r.d < .001 * Math.max(1, a)) return {
			t: a,
			shape: r.owner
		};
		a += Math.max(r.d * .9, 1e-4);
	}
	return null;
}
//#endregion
//#region ../scene3d/src/model/text.ts
function Oe(e, t, n, r = 128) {
	let i = new Uint8Array(t * n), a = new Float32Array(t * n);
	for (let o = 0; o < t * n; o++) {
		let t = e[o * 4 + 3];
		i[o] = +(t >= r), a[o] = Math.min(1, Math.max(0, .5 + (t - r) / 255));
	}
	let o = g(i, t, n, Math.max(.25, Math.max(t, n) / 2e3), a).filter((e) => Math.abs(v(e)) > t * n / 4e4).map((e) => e.map(([e, t]) => [e, -t]));
	return o.length ? z(o) : null;
}
function ke(e, t, n) {
	let r = /* @__PURE__ */ new Map();
	for (let i = 0; i < t * n; i++) {
		if (e[i * 4 + 3] < 200) continue;
		let [t, n, a] = [
			e[i * 4],
			e[i * 4 + 1],
			e[i * 4 + 2]
		], o = t >> 4 << 8 | n >> 4 << 4 | a >> 4, s = r.get(o) ?? {
			n: 0,
			r: 0,
			g: 0,
			b: 0
		};
		r.set(o, {
			n: s.n + 1,
			r: s.r + t,
			g: s.g + n,
			b: s.b + a
		});
	}
	let i;
	for (let e of r.values()) (!i || e.n > i.n) && (i = e);
	return i ? `#${[
		i.r,
		i.g,
		i.b
	].map((e) => Math.round(e / i.n).toString(16).padStart(2, "0")).join("")}` : null;
}
function Ae(e, t, n, r = {}) {
	let i = Oe(e, t, n);
	return i ? pe(i.outline, i.aspect, {
		...r,
		color: ke(e, t, n) ?? void 0
	}) : null;
}
function je(e, t, n, r) {
	let i = e.split("\n")[0].trim() || " ", a = `${n} 240px ${/[\s,]/.test(t) ? t : `"${t}"`}, sans-serif`, o = r(8, 8).getContext("2d");
	if (!o) return null;
	o.font = a;
	let s = Math.ceil(o.measureText(i).width + 72), c = r(s, 360).getContext("2d");
	return c ? (c.font = a, c.fillStyle = "#000", c.textBaseline = "middle", c.fillText(i, 36, 180), Oe(c.getImageData(0, 0, s, 360).data, s, 360)) : null;
}
var Me = (e, t) => {
	if (typeof OffscreenCanvas < "u") return new OffscreenCanvas(e, t);
	let n = document.createElement("canvas");
	return n.width = e, n.height = t, n;
}, Ne = () => ({
	color: [
		.8,
		.8,
		.8
	],
	opacity: 1,
	metalness: 0,
	roughness: .6,
	texture: -1,
	normalTexture: -1,
	normalScale: 1,
	roughnessTexture: -1,
	occlusionTexture: -1,
	occlusionStrength: 1,
	emissive: [
		0,
		0,
		0
	],
	emissiveTexture: -1,
	clearcoat: 0,
	clearcoatTexture: -1,
	clearcoatRoughness: 0,
	clearcoatRoughnessTexture: -1,
	clearcoatNormalTexture: -1,
	clearcoatNormalScale: 1,
	sheenColor: [
		0,
		0,
		0
	],
	sheenColorTexture: -1,
	sheenRoughness: 0,
	sheenRoughnessTexture: -1,
	transmission: 0,
	transmissionTexture: -1,
	ior: 1.5,
	cutout: !1,
	doubleSided: !1
});
function Pe(e) {
	let t = globalThis.Buffer;
	if (t) return t.from(e).toString("base64");
	let n = "";
	for (let t = 0; t < e.length; t += 32768) n += String.fromCharCode(...e.subarray(t, t + 32768));
	return btoa(n);
}
function Fe(e) {
	let t = globalThis.Buffer;
	if (t) return new Uint8Array(t.from(e, "base64"));
	let n = atob(e), r = new Uint8Array(n.length);
	for (let e = 0; e < n.length; e++) r[e] = n.charCodeAt(e);
	return r;
}
function Ie(e) {
	let t = [
		Infinity,
		Infinity,
		Infinity
	], n = [
		-Infinity,
		-Infinity,
		-Infinity
	];
	for (let r of e) for (let e = 0; e < r.positions.length; e += 3) for (let i = 0; i < 3; i++) {
		let a = r.positions[e + i];
		a < t[i] && (t[i] = a), a > n[i] && (n[i] = a);
	}
	return t[0] === Infinity ? {
		min: [
			0,
			0,
			0
		],
		max: [
			0,
			0,
			0
		]
	} : {
		min: t,
		max: n
	};
}
function Le(e, t) {
	let n = new Float32Array(e.length);
	for (let r = 0; r < t.length; r += 3) {
		let [i, a, o] = [
			t[r] * 3,
			t[r + 1] * 3,
			t[r + 2] * 3
		], s = [
			e[a] - e[i],
			e[a + 1] - e[i + 1],
			e[a + 2] - e[i + 2]
		], c = [
			e[o] - e[i],
			e[o + 1] - e[i + 1],
			e[o + 2] - e[i + 2]
		], l = [
			s[1] * c[2] - s[2] * c[1],
			s[2] * c[0] - s[0] * c[2],
			s[0] * c[1] - s[1] * c[0]
		];
		for (let e of [
			i,
			a,
			o
		]) for (let t = 0; t < 3; t++) n[e + t] += l[t];
	}
	for (let e = 0; e < n.length; e += 3) {
		let t = Math.hypot(n[e], n[e + 1], n[e + 2]) || 1;
		n[e] /= t, n[e + 1] /= t, n[e + 2] /= t;
	}
	return n;
}
var Re = 1179937895, ze = 1313821514, Be = 5130562, Ve = (e) => e + 3 & -4, He = (e, t = {}) => e >= 0 ? {
	index: e,
	...t
} : void 0, Ue = (e) => Object.fromEntries(Object.entries(e).filter(([, e]) => e !== void 0));
function We(e) {
	let t = {}, n = {}, r = Math.max(...e.emissive);
	if (r > 0 || e.emissiveTexture >= 0) {
		let i = Math.max(1, r);
		t.emissiveFactor = e.emissive.map((e) => e / i), e.emissiveTexture >= 0 && (t.emissiveTexture = { index: e.emissiveTexture }), i > 1 && (n.KHR_materials_emissive_strength = { emissiveStrength: i });
	}
	return e.clearcoat > 0 && (n.KHR_materials_clearcoat = Ue({
		clearcoatFactor: e.clearcoat,
		clearcoatTexture: He(e.clearcoatTexture),
		clearcoatRoughnessFactor: e.clearcoatRoughness,
		clearcoatRoughnessTexture: He(e.clearcoatRoughnessTexture),
		clearcoatNormalTexture: He(e.clearcoatNormalTexture, { scale: e.clearcoatNormalScale })
	})), Math.max(...e.sheenColor) > 0 && (n.KHR_materials_sheen = Ue({
		sheenColorFactor: e.sheenColor,
		sheenColorTexture: He(e.sheenColorTexture),
		sheenRoughnessFactor: e.sheenRoughness,
		sheenRoughnessTexture: He(e.sheenRoughnessTexture)
	})), e.transmission > 0 && (n.KHR_materials_transmission = Ue({
		transmissionFactor: e.transmission,
		transmissionTexture: He(e.transmissionTexture)
	})), e.ior !== 1.5 && (n.KHR_materials_ior = { ior: e.ior }), Object.keys(n).length && (t.extensions = n), t;
}
function Ge(e) {
	let t = [], n = [], r = [], i = 0, a = (e, n) => {
		t.push({
			buffer: 0,
			byteOffset: i,
			byteLength: e.byteLength,
			...n ? { target: n } : {}
		}), r.push(e);
		let a = Ve(e.byteLength);
		return a > e.byteLength && r.push(new Uint8Array(a - e.byteLength)), i += a, t.length - 1;
	}, o = (e, t, r, i = !1) => {
		let o = a(new Uint8Array(e.buffer, e.byteOffset, e.byteLength), r), s = t === "VEC3" ? 3 : t === "VEC2" ? 2 : 1, c = {
			bufferView: o,
			componentType: e instanceof Float32Array ? 5126 : 5125,
			count: e.length / s,
			type: t
		};
		if (i) {
			let t = [
				Infinity,
				Infinity,
				Infinity
			].slice(0, s), n = [
				-Infinity,
				-Infinity,
				-Infinity
			].slice(0, s);
			for (let r = 0; r < e.length; r++) {
				let i = r % s;
				t[i] = Math.min(t[i], e[r]), n[i] = Math.max(n[i], e[r]);
			}
			Object.assign(c, {
				min: t,
				max: n
			});
		}
		return n.push(c), n.length - 1;
	}, s = e.parts.map((e) => {
		let t = {
			POSITION: o(e.positions, "VEC3", 34962, !0),
			NORMAL: o(e.normals, "VEC3", 34962)
		};
		return e.uvs && (t.TEXCOORD_0 = o(e.uvs, "VEC2", 34962)), e.colors && (t.COLOR_0 = o(e.colors, "VEC3", 34962)), {
			attributes: t,
			indices: o(e.indices, "SCALAR", 34963),
			material: e.material,
			mode: 4
		};
	}), c = e.textures.map((e) => ({
		bufferView: a(e.bytes),
		mimeType: e.mime
	})), l = [...new Set(e.materials.flatMap((e) => Object.keys(We(e).extensions ?? {})))], u = {
		asset: {
			version: "2.0",
			generator: "Gleamshelf"
		},
		...l.length ? { extensionsUsed: l } : {},
		scene: 0,
		scenes: [{ nodes: [0] }],
		nodes: [{ mesh: 0 }],
		meshes: [{ primitives: s }],
		materials: e.materials.map((e) => ({
			pbrMetallicRoughness: {
				baseColorFactor: [...e.color, e.opacity],
				metallicFactor: e.metalness,
				roughnessFactor: e.roughness,
				...e.texture >= 0 ? { baseColorTexture: { index: e.texture } } : {},
				...e.roughnessTexture >= 0 ? { metallicRoughnessTexture: { index: e.roughnessTexture } } : {}
			},
			...e.normalTexture >= 0 ? { normalTexture: {
				index: e.normalTexture,
				scale: e.normalScale
			} } : {},
			...e.occlusionTexture >= 0 ? { occlusionTexture: {
				index: e.occlusionTexture,
				strength: e.occlusionStrength
			} } : {},
			...We(e),
			...e.cutout ? {
				alphaMode: "MASK",
				alphaCutoff: .5
			} : {},
			...e.doubleSided ? { doubleSided: !0 } : {}
		})),
		...c.length ? {
			images: c,
			textures: c.map((e, t) => ({
				source: t,
				sampler: 0
			})),
			samplers: [{
				magFilter: 9729,
				minFilter: 9987,
				wrapS: 10497,
				wrapT: 10497
			}]
		} : {},
		accessors: n,
		bufferViews: t,
		buffers: [{ byteLength: i }]
	}, d = new TextEncoder().encode(JSON.stringify(u)), f = Ve(d.byteLength), p = 20 + f + 8 + i, m = new Uint8Array(p), h = new DataView(m.buffer);
	h.setUint32(0, Re, !0), h.setUint32(4, 2, !0), h.setUint32(8, p, !0), h.setUint32(12, f, !0), h.setUint32(16, ze, !0), m.set(d, 20), m.fill(32, 20 + d.byteLength, 20 + f);
	let g = 20 + f;
	h.setUint32(g, i, !0), h.setUint32(g + 4, Be, !0), g += 8;
	for (let e of r) m.set(e, g), g += e.byteLength;
	return m;
}
var Ke = {
	KHR_draco_mesh_compression: "Draco compression",
	EXT_meshopt_compression: "meshopt compression",
	KHR_meshopt_compression: "meshopt compression",
	KHR_texture_basisu: "KTX2 textures"
}, qe = [
	1,
	0,
	0,
	0,
	0,
	1,
	0,
	0,
	0,
	0,
	1,
	0,
	0,
	0,
	0,
	1
];
function Je(e, t) {
	let n = Array(16).fill(0);
	for (let r = 0; r < 4; r++) for (let i = 0; i < 4; i++) for (let a = 0; a < 4; a++) n[r * 4 + i] += e[a * 4 + i] * t[r * 4 + a];
	return n;
}
function Ye(e = [
	0,
	0,
	0
], t = [
	0,
	0,
	0,
	1
], n = [
	1,
	1,
	1
]) {
	let [r, i, a, o] = t, [s, c, l] = n;
	return [
		(1 - 2 * (i * i + a * a)) * s,
		2 * (r * i + a * o) * s,
		2 * (r * a - i * o) * s,
		0,
		2 * (r * i - a * o) * c,
		(1 - 2 * (r * r + a * a)) * c,
		2 * (i * a + r * o) * c,
		0,
		2 * (r * a + i * o) * l,
		2 * (i * a - r * o) * l,
		(1 - 2 * (r * r + i * i)) * l,
		0,
		e[0],
		e[1],
		e[2],
		1
	];
}
function Xe(e) {
	let [t, n, r, i, a, o, s, c, l] = [
		e[0],
		e[4],
		e[8],
		e[1],
		e[5],
		e[9],
		e[2],
		e[6],
		e[10]
	], u = t * (a * l - o * c) - n * (i * l - o * s) + r * (i * c - a * s), d = 1 / (u || 1);
	return {
		n: [
			(a * l - o * c) * d,
			-(i * l - o * s) * d,
			(i * c - a * s) * d,
			-(n * l - r * c) * d,
			(t * l - r * s) * d,
			-(t * c - n * s) * d,
			(n * o - r * a) * d,
			-(t * o - r * i) * d,
			(t * a - n * i) * d
		],
		mirrored: u < 0
	};
}
var Ze = {
	SCALAR: 1,
	VEC2: 2,
	VEC3: 3,
	VEC4: 4,
	MAT4: 16
};
function Qe(e, t, n) {
	let r = e.accessors?.[n];
	if (!r) throw Error(`The model points at accessor ${n}, which is missing.`);
	if (r.sparse) throw Error("The model uses sparse accessors, which are not read here; open it in 3D mode instead.");
	let i = Ze[r.type] ?? 1, a = new Float32Array(r.count * i);
	if (r.bufferView === void 0) return {
		data: a,
		size: i
	};
	let o = e.bufferViews[r.bufferView], s = t[o.buffer ?? 0], c = {
		5120: 1,
		5121: 1,
		5122: 2,
		5123: 2,
		5125: 4,
		5126: 4
	}[r.componentType] ?? 4, l = o.byteStride || c * i, u = s.byteOffset + (o.byteOffset ?? 0) + (r.byteOffset ?? 0), d = new DataView(s.buffer), f = r.normalized === !0;
	for (let e = 0; e < r.count; e++) for (let t = 0; t < i; t++) {
		let n = u + e * l + t * c, o;
		switch (r.componentType) {
			case 5126:
				o = d.getFloat32(n, !0);
				break;
			case 5125:
				o = d.getUint32(n, !0);
				break;
			case 5123:
				o = d.getUint16(n, !0), f && (o /= 65535);
				break;
			case 5122:
				o = d.getInt16(n, !0), f && (o = Math.max(o / 32767, -1));
				break;
			case 5121:
				o = d.getUint8(n), f && (o /= 255);
				break;
			default: o = d.getInt8(n), f && (o = Math.max(o / 127, -1));
		}
		a[e * i + t] = o;
	}
	return {
		data: a,
		size: i
	};
}
var $e = (e) => {
	let t = /^data:([^;,]*)(;base64)?,(.*)$/s.exec(e);
	return t ? {
		mime: t[1] || "application/octet-stream",
		bytes: t[2] ? Fe(t[3]) : new TextEncoder().encode(decodeURIComponent(t[3]))
	} : null;
};
function et(e, t, n = () => null) {
	let r = (e.extensionsRequired ?? []).filter((e) => Ke[e]);
	if (r.length) throw Error(`This model uses ${r.map((e) => Ke[e]).join(" and ")}; import it in 3D mode, which decodes it.`);
	let i = (e.buffers ?? []).map((e, r) => {
		if (e.uri === void 0) {
			if (r === 0 && t) return t;
			throw Error("The model’s data is missing.");
		}
		let i = $e(e.uri)?.bytes ?? n(decodeURIComponent(e.uri));
		if (!i) throw Error(`The model needs "${e.uri}" beside it.`);
		return i;
	}), a = /* @__PURE__ */ new Map(), o = [], s = (t) => {
		if (!t || typeof t.index != "number" || (t.texCoord ?? 0) !== 0) return -1;
		if (a.has(t.index)) return a.get(t.index);
		let r = e.textures?.[t.index], s = r?.source ?? r?.extensions?.EXT_texture_webp?.source, c = e.images?.[s], l = null;
		if (c?.bufferView !== void 0) {
			let t = e.bufferViews[c.bufferView], n = i[t.buffer ?? 0];
			l = {
				mime: c.mimeType ?? "image/png",
				bytes: n.slice(t.byteOffset ?? 0, (t.byteOffset ?? 0) + t.byteLength)
			};
		} else if (typeof c?.uri == "string" && (l = $e(c.uri), !l)) {
			let e = n(decodeURIComponent(c.uri));
			e && (l = {
				mime: /\.jpe?g$/i.test(c.uri) ? "image/jpeg" : /\.webp$/i.test(c.uri) ? "image/webp" : "image/png",
				bytes: e
			});
		}
		let u = l && /^image\/(png|jpeg|webp)$/.test(l.mime) ? o.push(l) - 1 : -1;
		return a.set(t.index, u), u;
	}, c = (e.materials ?? []).map((e) => {
		let t = e.pbrMetallicRoughness ?? {}, n = t.baseColorFactor ?? [
			1,
			1,
			1,
			1
		];
		return {
			color: [
				n[0] ?? 1,
				n[1] ?? 1,
				n[2] ?? 1
			],
			opacity: n[3] ?? 1,
			metalness: t.metallicFactor ?? 1,
			roughness: t.roughnessFactor ?? 1,
			texture: s(t.baseColorTexture),
			normalTexture: s(e.normalTexture),
			normalScale: typeof e.normalTexture?.scale == "number" ? e.normalTexture.scale : 1,
			roughnessTexture: s(t.metallicRoughnessTexture),
			occlusionTexture: s(e.occlusionTexture),
			occlusionStrength: typeof e.occlusionTexture?.strength == "number" ? e.occlusionTexture.strength : 1,
			emissive: (e.emissiveFactor ?? [
				0,
				0,
				0
			]).slice(0, 3).map((t) => t * (e.extensions?.KHR_materials_emissive_strength?.emissiveStrength ?? 1)),
			emissiveTexture: s(e.emissiveTexture),
			...tt(e.extensions ?? {}, s),
			cutout: e.alphaMode === "MASK" || e.alphaMode === "BLEND",
			doubleSided: e.doubleSided === !0
		};
	}), l = -1, u = [], d = (t, n, r) => {
		let a = e.nodes?.[t];
		if (!a || r > 64) return;
		let o = Je(n, a.matrix ?? Ye(a.translation, a.rotation, a.scale)), s = e.meshes?.[a.mesh];
		if (s) {
			let { n: t, mirrored: n } = Xe(o);
			for (let r of s.primitives ?? []) {
				if ((r.mode ?? 4) !== 4 || r.attributes?.POSITION === void 0) continue;
				let a = Qe(e, i, r.attributes.POSITION).data, s = a.length / 3, d = new Float32Array(a.length);
				for (let e = 0; e < s; e++) {
					let [t, n, r] = [
						a[e * 3],
						a[e * 3 + 1],
						a[e * 3 + 2]
					];
					for (let i = 0; i < 3; i++) d[e * 3 + i] = o[i] * t + o[4 + i] * n + o[8 + i] * r + o[12 + i];
				}
				let f = r.indices === void 0 ? Uint32Array.from({ length: s }, (e, t) => t) : Uint32Array.from(Qe(e, i, r.indices).data);
				if (n) for (let e = 0; e < f.length; e += 3) [f[e + 1], f[e + 2]] = [f[e + 2], f[e + 1]];
				let p;
				if (r.attributes.NORMAL !== void 0) {
					let n = Qe(e, i, r.attributes.NORMAL).data;
					p = new Float32Array(n.length);
					for (let e = 0; e < s; e++) {
						let [r, i, a] = [
							n[e * 3],
							n[e * 3 + 1],
							n[e * 3 + 2]
						], o = [
							t[0] * r + t[1] * i + t[2] * a,
							t[3] * r + t[4] * i + t[5] * a,
							t[6] * r + t[7] * i + t[8] * a
						], s = Math.hypot(o[0], o[1], o[2]) || 1;
						p.set([
							o[0] / s,
							o[1] / s,
							o[2] / s
						], e * 3);
					}
				} else p = Le(d, f);
				let m = r.attributes.TEXCOORD_0 === void 0 ? null : Qe(e, i, r.attributes.TEXCOORD_0).data, h = null;
				if (r.attributes.COLOR_0 !== void 0) {
					let t = Qe(e, i, r.attributes.COLOR_0);
					h = new Float32Array(s * 3);
					for (let e = 0; e < s; e++) h.set([
						t.data[e * t.size],
						t.data[e * t.size + 1],
						t.data[e * t.size + 2]
					], e * 3);
				}
				let g = typeof r.material == "number" && c[r.material] ? r.material : -1;
				g < 0 && (l < 0 && (l = c.push(Ne()) - 1), g = l), u.push({
					positions: d,
					normals: p,
					uvs: m,
					colors: h,
					indices: f,
					material: g
				});
			}
		}
		for (let e of a.children ?? []) d(e, o, r + 1);
	}, f = e.scenes?.[e.scene ?? 0]?.nodes ?? (e.nodes ?? []).map((e, t) => t);
	for (let e of f) d(e, qe, 0);
	if (!u.length) throw Error("The model has no triangles to draw.");
	return nt(u, c, o);
}
function tt(e, t) {
	let n = e.KHR_materials_clearcoat ?? {}, r = e.KHR_materials_sheen ?? {}, i = e.KHR_materials_transmission ?? {}, a = (e, t) => typeof e == "number" && Number.isFinite(e) ? e : t;
	return {
		clearcoat: a(n.clearcoatFactor, 0),
		clearcoatTexture: t(n.clearcoatTexture),
		clearcoatRoughness: a(n.clearcoatRoughnessFactor, 0),
		clearcoatRoughnessTexture: t(n.clearcoatRoughnessTexture),
		clearcoatNormalTexture: t(n.clearcoatNormalTexture),
		clearcoatNormalScale: a(n.clearcoatNormalTexture?.scale, 1),
		sheenColor: e.KHR_materials_sheen ? (r.sheenColorFactor ?? [
			0,
			0,
			0
		]).slice(0, 3).map((e) => a(e, 0)) : [
			0,
			0,
			0
		],
		sheenColorTexture: t(r.sheenColorTexture),
		sheenRoughness: a(r.sheenRoughnessFactor, 0),
		sheenRoughnessTexture: t(r.sheenRoughnessTexture),
		transmission: a(i.transmissionFactor, 0),
		transmissionTexture: t(i.transmissionTexture),
		ior: Math.min(3, Math.max(1, a(e.KHR_materials_ior?.ior, 1.5)))
	};
}
function nt(e, t, n) {
	let { min: r, max: i } = Ie(e);
	return {
		parts: e,
		materials: t,
		textures: n,
		min: r,
		max: i,
		triangles: e.reduce((e, t) => e + t.indices.length / 3, 0)
	};
}
function rt(e, t) {
	let n = new DataView(e.buffer, e.byteOffset, e.byteLength);
	if (e.byteLength >= 12 && n.getUint32(0, !0) === Re) {
		let r = 12, i = null, a = null;
		for (; r + 8 <= e.byteLength;) {
			let t = n.getUint32(r, !0), o = n.getUint32(r + 4, !0), s = e.subarray(r + 8, r + 8 + t);
			o === ze ? i = JSON.parse(new TextDecoder().decode(s)) : o === Be && (a = s), r += 8 + Ve(t);
		}
		if (!i) throw Error("That GLB has no model description in it.");
		return et(i, a, t);
	}
	try {
		return et(JSON.parse(new TextDecoder().decode(e)), null, t);
	} catch (e) {
		throw e instanceof SyntaxError ? Error("That is not a glTF or GLB model.") : e;
	}
}
var it = /* @__PURE__ */ new Map();
function at(e, t) {
	let n = it.get(e);
	if (n && n.data === t) return n.asset;
	let r = rt(Fe(t));
	return it.set(e, {
		data: t,
		asset: r
	}), it.size > 24 && it.delete(it.keys().next().value), r;
}
var ot = /* @__PURE__ */ new WeakMap();
function st(e) {
	let t = ot.get(e);
	if (t) return t;
	let n = e.triangles, r = new Float32Array(n * 9), i = new Uint32Array(n * 4), a = 0;
	e.parts.forEach((e, t) => {
		for (let n = 0; n < e.indices.length; n += 3, a++) {
			for (let t = 0; t < 3; t++) {
				let o = e.indices[n + t];
				r.set([
					e.positions[o * 3],
					e.positions[o * 3 + 1],
					e.positions[o * 3 + 2]
				], a * 9 + t * 3), i[a * 4 + 1 + t] = o;
			}
			i[a * 4] = t;
		}
	});
	let o = Uint32Array.from({ length: n }, (e, t) => t), s = new Float32Array(n * 3);
	for (let e = 0; e < n; e++) for (let t = 0; t < 3; t++) s[e * 3 + t] = (r[e * 9 + t] + r[e * 9 + 3 + t] + r[e * 9 + 6 + t]) / 3;
	let c = [], l = [], u = (e, t) => {
		let n = l.length / 3;
		l.push(0, 0, 0);
		let [i, a, d, f, p, m] = [
			Infinity,
			Infinity,
			Infinity,
			-Infinity,
			-Infinity,
			-Infinity
		];
		for (let n = e; n < t; n++) {
			let e = o[n] * 9;
			for (let t = 0; t < 9; t += 3) i = Math.min(i, r[e + t]), a = Math.min(a, r[e + t + 1]), d = Math.min(d, r[e + t + 2]), f = Math.max(f, r[e + t]), p = Math.max(p, r[e + t + 1]), m = Math.max(m, r[e + t + 2]);
		}
		if (c.push(i, a, d, f, p, m), t - e <= 4) return l[n * 3] = 1, l[n * 3 + 1] = e, l[n * 3 + 2] = t - e, n;
		let h = f - i >= p - a && f - i >= m - d ? 0 : p - a >= m - d ? 1 : 2, g = Array.from(o.subarray(e, t)).sort((e, t) => s[e * 3 + h] - s[t * 3 + h]);
		o.set(g, e);
		let _ = e + t >> 1;
		u(e, _);
		let v = u(_, t);
		return l[n * 3] = 0, l[n * 3 + 1] = v, n;
	};
	n && u(0, n);
	let d = Float32Array.from(c), f = Uint32Array.from(l), p = (e, t, a, s, c) => {
		if (!n) return null;
		let l = [
			1 / t[0],
			1 / t[1],
			1 / t[2]
		], u = null, p = s, m = [0];
		for (; m.length;) {
			let n = m.pop(), s = a, h = p;
			for (let t = 0; t < 3; t++) {
				let r = (d[n * 6 + t] - e[t]) * l[t], i = (d[n * 6 + 3 + t] - e[t]) * l[t];
				if (r > i && ([r, i] = [i, r]), s = Math.max(s, r), h = Math.min(h, i), s > h) break;
			}
			if (!(s > h)) {
				if (f[n * 3] === 1) {
					let s = f[n * 3 + 1], l = f[n * 3 + 2];
					for (let n = s; n < s + l; n++) {
						let s = o[n], l = s * 9, d = [
							r[l + 3] - r[l],
							r[l + 4] - r[l + 1],
							r[l + 5] - r[l + 2]
						], f = [
							r[l + 6] - r[l],
							r[l + 7] - r[l + 1],
							r[l + 8] - r[l + 2]
						], m = [
							t[1] * f[2] - t[2] * f[1],
							t[2] * f[0] - t[0] * f[2],
							t[0] * f[1] - t[1] * f[0]
						], h = d[0] * m[0] + d[1] * m[1] + d[2] * m[2];
						if (Math.abs(h) < 1e-12) continue;
						let g = 1 / h, _ = [
							e[0] - r[l],
							e[1] - r[l + 1],
							e[2] - r[l + 2]
						], v = (_[0] * m[0] + _[1] * m[1] + _[2] * m[2]) * g;
						if (v < 0 || v > 1) continue;
						let y = [
							_[1] * d[2] - _[2] * d[1],
							_[2] * d[0] - _[0] * d[2],
							_[0] * d[1] - _[1] * d[0]
						], b = (t[0] * y[0] + t[1] * y[1] + t[2] * y[2]) * g;
						if (b < 0 || v + b > 1) continue;
						let x = (f[0] * y[0] + f[1] * y[1] + f[2] * y[2]) * g;
						if (!(x <= a || x >= p) && (p = x, u = {
							t: x,
							part: i[s * 4],
							a: i[s * 4 + 1],
							b: i[s * 4 + 2],
							c: i[s * 4 + 3],
							u: v,
							v: b
						}, c)) return u;
					}
				} else m.push(f[n * 3 + 1], n + 1);
			}
		}
		return u;
	}, m = {
		intersect: (e, t, n = 0, r = Infinity) => p(e, t, n, r, !1),
		occluded: (e, t, n = 0, r = Infinity) => p(e, t, n, r, !0) !== null
	};
	return ot.set(e, m), m;
}
//#endregion
//#region ../scene3d/src/model/meshcpu.ts
var ct = typeof createImageBitmap == "function" && typeof OffscreenCanvas < "u" ? async (e, t) => {
	try {
		let n = await createImageBitmap(new Blob([e], { type: t }), {
			premultiplyAlpha: "none",
			colorSpaceConversion: "none"
		}), r = new OffscreenCanvas(n.width, n.height), i = r.getContext("2d");
		return i.drawImage(n, 0, 0), n.close(), i.getImageData(0, 0, r.width, r.height);
	} catch {
		return null;
	}
} : void 0, lt = /* @__PURE__ */ new WeakMap();
async function ut(e, t = ct) {
	let n = [];
	for (let { shape: r, asset: i } of re(e)) {
		let e = at(r.asset, i.data), a = lt.get(e);
		a || lt.set(e, a = /* @__PURE__ */ new Map());
		let o = t ? a.get(t) : void 0;
		o || (o = t ? Promise.all(e.textures.map((e) => t(e.bytes, e.mime))) : Promise.resolve(e.textures.map(() => null)), t && a.set(t, o));
		let s = e.max.map((t, n) => Math.max(t - e.min[n], 1e-9));
		n.push({
			shape: r,
			asset: e,
			bvh: st(e),
			textures: await o,
			rot: he(r.rotation),
			scale: r.size.map((e, t) => e / s[t]),
			centre: e.min.map((t, n) => (t + e.max[n]) / 2),
			position: r.position
		});
	}
	return n;
}
function dt(e, t, n) {
	let r = e.rot, i = [
		t[0] - e.position[0],
		t[1] - e.position[1],
		t[2] - e.position[2]
	];
	return [[
		0,
		1,
		2
	].map((t) => (r[t] * i[0] + r[3 + t] * i[1] + r[6 + t] * i[2]) / e.scale[t] + e.centre[t]), [
		0,
		1,
		2
	].map((t) => (r[t] * n[0] + r[3 + t] * n[1] + r[6 + t] * n[2]) / e.scale[t])];
}
var K = (e) => (e / 255) ** 2.2, q = (e, t, n) => {
	let r = Math.min(e.width - 1, Math.floor((t - Math.floor(t)) * e.width));
	return (Math.min(e.height - 1, Math.floor((n - Math.floor(n)) * e.height)) * e.width + r) * 4;
}, ft = (e, t) => {
	let n = [
		t[0] * e.scale[0],
		t[1] * e.scale[1],
		t[2] * e.scale[2]
	], r = e.rot;
	return [
		0,
		1,
		2
	].map((e) => r[e * 3] * n[0] + r[e * 3 + 1] * n[1] + r[e * 3 + 2] * n[2]);
};
function pt(e, t, n, r, i, a, o, s) {
	let c = (e) => [
		t.positions[e * 3],
		t.positions[e * 3 + 1],
		t.positions[e * 3 + 2]
	], l = (e) => [t.uvs[e * 2], t.uvs[e * 2 + 1]], [u, d, f] = n.map(c), [p, m, h] = n.map(l), g = [
		0,
		1,
		2
	].map((e) => d[e] - u[e]), _ = [
		0,
		1,
		2
	].map((e) => f[e] - u[e]), [v, y, b, x] = [
		m[0] - p[0],
		m[1] - p[1],
		h[0] - p[0],
		h[1] - p[1]
	], S = v * x - b * y;
	if (Math.abs(S) <= 1e-12) return r;
	let C = [
		0,
		1,
		2
	].map((e) => (g[e] * x - _[e] * y) / S), w = [
		0,
		1,
		2
	].map((e) => (_[e] * v - g[e] * b) / S), T = (e) => mt([
		0,
		1,
		2
	].map((t) => e[t] - r[t] * (e[0] * r[0] + e[1] * r[1] + e[2] * r[2]))), E = T(ft(e, C)), D = T(ft(e, w)), O = q(i, a, o), k = (i.data[O] / 255 * 2 - 1) * s, A = (i.data[O + 1] / 255 * 2 - 1) * s, j = i.data[O + 2] / 255 * 2 - 1;
	return mt([
		0,
		1,
		2
	].map((e) => E[e] * k - D[e] * A + r[e] * j));
}
var mt = (e) => {
	let t = Math.hypot(e[0], e[1], e[2]) || 1;
	return [
		e[0] / t,
		e[1] / t,
		e[2] / t
	];
};
function ht(e, t, n, r = Infinity) {
	let i = null, a = r;
	for (let r of e) {
		let [e, o] = dt(r, t, n), s = 1e-5;
		for (let t = 0; t < 6; t++) {
			let t = r.bvh.intersect(e, o, s, a);
			if (!t) break;
			let c = r.asset.parts[t.part], l = r.asset.materials[c.material], u = [
				1 - t.u - t.v,
				t.u,
				t.v
			], d = [
				t.a,
				t.b,
				t.c
			], f = (e, t, n) => d.reduce((r, i, a) => r + e[i * t + n] * u[a], 0), p = [...l.color], m = l.opacity, [h, g] = c.uvs ? [f(c.uvs, 2, 0), f(c.uvs, 2, 1)] : [0, 0], _ = l.texture >= 0 && c.uvs ? r.textures[l.texture] : null;
			if (_) {
				let e = q(_, h, g);
				p = [
					p[0] * K(_.data[e]),
					p[1] * K(_.data[e + 1]),
					p[2] * K(_.data[e + 2])
				], m *= _.data[e + 3] / 255;
			}
			if (l.cutout && m < .5) {
				s = t.t + 1e-5;
				continue;
			}
			c.colors && (p = [
				p[0] * f(c.colors, 3, 0),
				p[1] * f(c.colors, 3, 1),
				p[2] * f(c.colors, 3, 2)
			]);
			let v = [
				0,
				1,
				2
			].map((e) => f(c.normals, 3, e) / r.scale[e]), y = r.rot, b = mt([
				0,
				1,
				2
			].map((e) => y[e * 3] * v[0] + y[e * 3 + 1] * v[1] + y[e * 3 + 2] * v[2])), x = b, S = l.normalTexture >= 0 && c.uvs ? r.textures[l.normalTexture] : null;
			S && (b = pt(r, c, d, b, S, h, g, l.normalScale)), b[0] * n[0] + b[1] * n[1] + b[2] * n[2] > 0 && (b = b.map((e) => -e));
			let C = r.shape.ownColors !== !1, [w, T] = [l.roughness, l.metalness], E = C && l.roughnessTexture >= 0 && c.uvs ? r.textures[l.roughnessTexture] : null;
			if (E) {
				let e = q(E, h, g);
				w *= E.data[e + 1] / 255, T *= E.data[e + 2] / 255;
			}
			let [D, O] = C ? [6 + (1 - w) ** 2 * 134, T] : Ce[r.shape.finish], k = l.occlusionTexture >= 0 && c.uvs ? r.textures[l.occlusionTexture] : null, A = k ? 1 + l.occlusionStrength * (k.data[q(k, h, g)] / 255 - 1) : 1, j = C ? [...l.emissive] : [
				0,
				0,
				0
			], M = C && l.emissiveTexture >= 0 && c.uvs ? r.textures[l.emissiveTexture] : null;
			if (M && Math.max(...j) > 0) {
				let e = q(M, h, g);
				j = [
					j[0] * K(M.data[e]),
					j[1] * K(M.data[e + 1]),
					j[2] * K(M.data[e + 2])
				];
			}
			if (!C) {
				let e = parseInt(r.shape.color.slice(1), 16);
				p = [
					(e >> 16 & 255) / 255,
					(e >> 8 & 255) / 255,
					(e & 255) / 255
				].map((e) => e ** 2.2);
			}
			a = t.t;
			let N = (e) => C && e >= 0 && c.uvs ? r.textures[e] : null, P = (e, t, n = 1) => {
				let r = N(e);
				return r ? r.data[q(r, h, g) + t] / 255 : n;
			}, F = x, I = x, L = N(l.clearcoatNormalTexture);
			L && (I = pt(r, c, d, x, L, h, g, l.clearcoatNormalScale));
			let R = (e) => e[0] * n[0] + e[1] * n[1] + e[2] * n[2] > 0 ? e.map((e) => -e) : e;
			F = R(F), I = R(I);
			let ee = N(l.sheenColorTexture), z = C ? [...l.sheenColor] : [
				0,
				0,
				0
			];
			if (ee) {
				let e = q(ee, h, g);
				for (let t = 0; t < 3; t++) z[t] = z[t] * K(ee.data[e + t]);
			}
			i = {
				t: t.t,
				normal: b,
				color: p,
				shine: D,
				metal: O,
				occ: A,
				emissive: j,
				shapeNormal: F,
				clearcoat: C ? l.clearcoat * P(l.clearcoatTexture, 0) : 0,
				clearcoatRoughness: l.clearcoatRoughness * P(l.clearcoatRoughnessTexture, 1),
				coatNormal: I,
				sheen: z,
				sheenRoughness: l.sheenRoughness * P(l.sheenRoughnessTexture, 3),
				transmission: C ? l.transmission * P(l.transmissionTexture, 0) : 0,
				ior: l.ior
			};
			break;
		}
	}
	return i;
}
function gt(e, t, n, r = Infinity) {
	for (let i of e) {
		let [e, a] = dt(i, t, n), o = i.shape.ownColors !== !1, s = 1e-4;
		for (let t = 0; t < 6; t++) {
			let t = i.bvh.intersect(e, a, s, r);
			if (!t) break;
			if (o && i.asset.materials[i.asset.parts[t.part].material].transmission > .5) s = t.t + 1e-5;
			else return !0;
		}
	}
	return !1;
}
//#endregion
//#region ../scene3d/src/model/cpu.ts
var _t = (e, t) => [
	e[0] - t[0],
	e[1] - t[1],
	e[2] - t[2]
], J = (e, t) => [
	e[0] + t[0],
	e[1] + t[1],
	e[2] + t[2]
], Y = (e, t) => [
	e[0] * t,
	e[1] * t,
	e[2] * t
], X = (e, t) => e[0] * t[0] + e[1] * t[1] + e[2] * t[2], vt = (e, t) => [
	e[1] * t[2] - e[2] * t[1],
	e[2] * t[0] - e[0] * t[2],
	e[0] * t[1] - e[1] * t[0]
], Z = (e) => Y(e, 1 / (Math.hypot(...e) || 1)), Q = (e, t, n) => e + (t - e) * n, yt = (e) => Math.min(1, Math.max(0, e)), bt = (e, t, n) => {
	let r = yt((n - e) / (t - e));
	return r * r * (3 - 2 * r);
}, xt = (e) => {
	let t = parseInt(e.slice(1), 16);
	return [
		((t >> 16 & 255) / 255) ** 2.2,
		((t >> 8 & 255) / 255) ** 2.2,
		((t & 255) / 255) ** 2.2
	];
}, $ = Math.PI / 180;
async function St(e, t) {
	let { width: n, height: r, samples: i = 1, frame: a = 1, tones: o, region: s, onProgress: c } = t, l = t.meshes ?? await ut(e, t.decodeImage ?? ct), u = ae(e), d = (t) => Ee(e, t, u), f = (e) => d(e).d, p = e.camera, m = p.target, h = J(m, Y([
		Math.sin(p.yaw * $) * Math.cos(p.pitch * $),
		Math.sin(p.pitch * $),
		Math.cos(p.yaw * $) * Math.cos(p.pitch * $)
	], p.distance)), g = Z(_t(m, h)), _ = Z(vt(g, [
		0,
		1,
		0
	])), v = vt(_, g), y = Math.tan(p.fov / 2 * $) * a, b = p.projection === "orthographic", x = p.distance * y, S = n / r, C = Z([
		Math.sin(e.light.azimuth * $) * Math.cos(e.light.elevation * $),
		Math.sin(e.light.elevation * $),
		Math.cos(e.light.azimuth * $) * Math.cos(e.light.elevation * $)
	]), w = xt(e.light.color), { intensity: T, ambient: E } = e.light, D = e.style.look, O = o ? 0 : e.style.outline * r / 1e3, k = xt(e.style.outlineColor), A = xt(e.background.color), j = b ? 2 * x / r : 2 * y / r, M = (e, t) => {
		let n = 5e-4 * Math.max(1, t), r = [
			1,
			-1,
			-1
		], i = [
			-1,
			-1,
			1
		], a = [
			-1,
			1,
			-1
		], o = [
			1,
			1,
			1
		];
		return Z(J(J(Y(r, f(J(e, Y(r, n)))), Y(i, f(J(e, Y(i, n))))), J(Y(a, f(J(e, Y(a, n)))), Y(o, f(J(e, Y(o, n)))))));
	}, N = (t, n, r = !1) => {
		if (!e.light.shadows) return 1;
		if (l.length && gt(l, t, n, 60)) return 0;
		let i = 1, a = .02;
		for (let e = 0; e < 48; e++) {
			let e = f(J(t, Y(n, a)));
			if (r && e < .002) return 0;
			if (i = Math.min(i, 10 * e / a), a += Math.min(Math.max(e, .02), .4), i < .002 || a > 30) break;
		}
		return r ? 1 : yt(i);
	}, P = (e, t) => {
		let n = 0, r = 1;
		for (let i = 0; i < 5; i++) {
			let a = .02 + .12 * i;
			n += (a - f(J(e, Y(t, a)))) * r, r *= .75;
		}
		return yt(1 - 1.6 * n);
	}, F = (t, n, r, i, a, s, c = 1) => {
		D === "clay" && (i = [
			.86,
			.84,
			.82
		]);
		let l = Math.max(X(n, C), 0);
		if (o) {
			let e = l > 0 ? l * N(J(t, Y(n, .003)), C, !0) : 0, r = Math.floor(e * o + .5) / o;
			return Y(i, E * .9 + T * .75 * r);
		}
		let u = l > 0 ? N(J(t, Y(n, .003)), C) : 0, d = P(t, n) * c, f = Z(_t(C, r)), p = Math.max(X(n, f), 0) ** a * l * u, m = .5 + .5 * n[1];
		if (D === "flat") return Y(i, .82 + .18 * l);
		if (D === "toon") {
			let t = Math.floor(l * u * e.style.bands + .5) / e.style.bands, a = (1 - Math.max(X(n, Y(r, -1)), 0)) ** 3 * .25, o = (p >= .92) * .35;
			return J(Y(i, E * .9 * c + T * .75 * t), Y(w, o + a * t));
		}
		let h = [
			Q(1, i[0], s),
			Q(1, i[1], s),
			Q(1, i[2], s)
		], g = Y(i, 1 - .6 * s), _ = Z([
			-C[0],
			.3,
			-C[2]
		]), v = Math.max(X(n, _), 0), y = (1 - Math.max(X(n, Y(r, -1)), 0)) ** 4, b = [
			0,
			0,
			0
		];
		for (let e = 0; e < 3; e++) b[e] = g[e] * w[e] * l * u * T + g[e] * [
			.72,
			.82,
			1
		][e] * E * (.25 + .75 * v) * d + g[e] * E * .45 * m * d + w[e] * y * .22 * T * d * m + h[e] * w[e] * p * T * Q(.35, 1.6, s) * (a > 60 ? 1 : .6) + g[e] * [
			1,
			.9,
			.8
		][e] * .05 * Math.max(-n[1], 0);
		return b;
	}, I = (e, t) => {
		let i = e / n * 2 - 1, a = 1 - t / r * 2, o, s;
		return b ? (o = J(h, J(Y(_, i * x * S), Y(v, a * x))), s = g) : (o = h, s = Z(J(g, J(Y(_, i * y * S), Y(v, a * y))))), z(o, s, 0);
	}, L = (e) => {
		let t = bt(-.25, .6, e[1]), n = bt(.22, .32, e[1]) * (1 - bt(.5, .62, e[1]));
		return [
			0,
			1,
			2
		].map((e) => (Q([
			.3,
			.28,
			.27
		][e], [
			.85,
			.9,
			1
		][e], t) + 1.6 * n) * (.5 + E) * w[e]);
	}, R = (e, t) => t + (1 - t) * (1 - e) ** 5, ee = (e, t) => _t(e, Y(t, 2 * X(e, t))), z = (t, n, r) => {
		let i = e.ground.on && n[1] < -1e-4 ? -t[1] / n[1] : 1e9, a = r === 0 ? O : 0, s = r ? 5e-4 : b ? 0 : .01, c = 1e9, u = !1, f = d(t);
		for (let e = 0; e < 200; e++) {
			let e = J(t, Y(n, s));
			f = d(e);
			let r = b ? j : j * Math.max(s, .01);
			if (c = Math.min(c, f.d / r), f.d < 4e-4 * Math.max(1, s)) {
				u = !0;
				break;
			}
			if (s += f.d * .92, s > 120 || s > i + .5) break;
		}
		let p = l.length ? ht(l, t, n, Math.min(u && s < i + .001 ? s : Infinity, i)) : null;
		if (p) {
			let e = J(t, Y(n, p.t)), i = p.normal, s = F(e, i, n, p.color, p.shine, p.metal, p.occ), c = 1, l = Y(n, -1), u = D === "soft" && !o, d = u && (p.clearcoat > 0 || Math.max(...p.sheen) > 0 || p.transmission > 0) ? N(J(e, Y(p.shapeNormal, .003)), C) : 1;
			if (p.transmission > 0 && D !== "clay" && !o && r < 4) {
				let t = ((p.ior - 1) / (p.ior + 1)) ** 2, a = R(Math.max(X(i, l), 0), t), o = z(J(e, Y(n, .001)), n, r + 1), u = [
					o[0] * p.color[0],
					o[1] * p.color[1],
					o[2] * p.color[2]
				], f = p.transmission * (1 - a), m = Z(J(C, l)), h = Math.max(X(i, m), 0) ** Math.max(p.shine, 60) * Math.max(X(i, C), 0) * d * T, g = L(ee(n, i));
				s = [
					0,
					1,
					2
				].map((e) => Q(s[e], u[e], f) + g[e] * a * p.transmission + w[e] * h), c = yt(Q(1, o[3], f) + h + a * p.transmission);
			}
			if (u && Math.max(...p.sheen) > 0) {
				let e = (1 - Math.max(X(i, l), 0)) ** Q(5, 1.5, p.sheenRoughness), t = T * Math.max(X(i, C), 0) * d * .8;
				s = [
					0,
					1,
					2
				].map((n) => s[n] + p.sheen[n] * e * (w[n] * t + E * .6 * p.occ));
			}
			if (u && p.clearcoat > 0) {
				let e = p.coatNormal, t = R(Math.max(X(e, l), 0), .04), r = Z(J(C, l)), i = 8 + (1 - p.clearcoatRoughness) ** 2 * 600, a = Math.max(X(e, r), 0) ** i * Math.max(X(e, C), 0) * d * T * (1 + i / 120), o = Y(L(ee(n, e)), Q(1, .35, p.clearcoatRoughness));
				s = [
					0,
					1,
					2
				].map((e) => s[e] * (1 - p.clearcoat * t) + p.clearcoat * (w[e] * a + o[e] * t));
			}
			if (D !== "clay" && (s = J(s, p.emissive)), a > 0) {
				let e = bt(.12 + .02 * a, .02, Math.abs(X(i, n)));
				s = [
					Q(s[0], k[0], e),
					Q(s[1], k[1], e),
					Q(s[2], k[2], e)
				], c = Q(c, 1, e);
			}
			return [...s, c];
		}
		if (u && s < i + .001) {
			let e = J(t, Y(n, s)), r = M(e, s), i = F(e, r, n, f.color.map((e) => e ** 2.2), f.shine, f.metal);
			if (a > 0) {
				let e = bt(.12 + .02 * a, .02, Math.abs(X(r, n)));
				i = [
					Q(i[0], k[0], e),
					Q(i[1], k[1], e),
					Q(i[2], k[2], e)
				];
			}
			return [...i, 1];
		}
		if (a > 0 && c < a) return [...k, bt(a, a * .6, c)];
		if (i < 1e8) {
			let r = J(t, Y(n, i)), a = 1 - N(J(r, [
				0,
				.002,
				0
			]), C, !!o), s = o ? 1 : Math.exp(-.08 * Math.hypot(r[0], r[2])), c = a * e.ground.shadow * s;
			return e.background.transparent ? [
				0,
				0,
				0,
				o ? c > .05 ? e.ground.shadow : 0 : c
			] : [
				A[0] * (1 - c),
				A[1] * (1 - c),
				A[2] * (1 - c),
				1
			];
		}
		return e.background.transparent ? [
			0,
			0,
			0,
			0
		] : [...A, 1];
	}, [te, B, V, ne] = s ? [
		Math.max(0, s[0]),
		Math.max(0, s[1]),
		Math.min(n, s[2]),
		Math.min(r, s[3])
	] : [
		0,
		0,
		n,
		r
	], [H, U] = [Math.max(0, V - te), Math.max(0, ne - B)], W = new Float32Array(H * U * 4), re = i > 1 && !o, ie = U || 1;
	for (let e = 0; e < U; e++) {
		for (let t = 0; t < H; t++) {
			let n = I(te + t + .5, B + e + .5), r = (e * H + t) * 4;
			W[r] = n[0] * n[3], W[r + 1] = n[1] * n[3], W[r + 2] = n[2] * n[3], W[r + 3] = n[3];
		}
		c && e % 16 == 15 && await c((e + 1) / ie * (re ? .75 : 1));
	}
	if (re) {
		let e = (e, t) => Math.abs(W[e] - W[t]) + Math.abs(W[e + 1] - W[t + 1]) + Math.abs(W[e + 2] - W[t + 2]) > .06 || Math.abs(W[e + 3] - W[t + 3]) > .1, t = new Uint8Array(H * U);
		for (let n = 0; n < U; n++) for (let r = 0; r < H; r++) {
			let i = (n * H + r) * 4;
			(r + 1 < H && e(i, i + 4) || n + 1 < U && e(i, i + H * 4)) && (t[n * H + r] = 1, r + 1 < H && (t[n * H + r + 1] = 1), n + 1 < U && (t[(n + 1) * H + r] = 1));
		}
		let n = [
			[-.375, -.125],
			[.125, -.375],
			[.375, .125],
			[-.125, .375]
		], r = new Float32Array(W);
		for (let e = 0; e < U; e++) {
			for (let i = 0; i < H; i++) {
				if (!t[e * H + i]) continue;
				let a = (e * H + i) * 4;
				for (let [t, o] of n) {
					let n = I(te + i + .5 + t, B + e + .5 + o);
					r[a] += n[0] * n[3], r[a + 1] += n[1] * n[3], r[a + 2] += n[2] * n[3], r[a + 3] += n[3];
				}
				for (let e = 0; e < 4; e++) r[a + e] /= 5;
			}
			c && e % 16 == 15 && await c(.75 + (e + 1) / ie * .25);
		}
		W.set(r);
	}
	let G = new Uint8ClampedArray(H * U * 4);
	for (let e = 0; e < H * U; e++) {
		let t = W[e * 4 + 3];
		t > 0 && (G[e * 4] = 255 * Math.max(0, W[e * 4] / t) ** (1 / 2.2), G[e * 4 + 1] = 255 * Math.max(0, W[e * 4 + 1] / t) ** (1 / 2.2), G[e * 4 + 2] = 255 * Math.max(0, W[e * 4 + 2] / t) ** (1 / 2.2)), G[e * 4 + 3] = 255 * t;
	}
	return {
		width: H,
		height: U,
		data: G
	};
}
//#endregion
//#region ../scene3d/src/model/vector.ts
var Ct = (e, t, n) => `#${[
	e,
	t,
	n
].map((e) => e.toString(16).padStart(2, "0")).join("")}`, wt = (e) => String(Math.round(e * 10) / 10), Tt = (e) => e.map((e) => `M${e.map(([e, t]) => `${wt(e)} ${wt(t)}`).join("L")}Z`).join("");
function Et(e) {
	let { width: t, height: n, data: r } = e, i = /* @__PURE__ */ new Map();
	for (let e = 0; e < t * n; e++) {
		let t = r[e * 4 + 3];
		if (t < 8) continue;
		let n = (r[e * 4] << 16 | r[e * 4 + 1] << 8 | r[e * 4 + 2]) * 256 + Math.round(t / 32);
		i.set(n, (i.get(n) ?? 0) + 1);
	}
	let a = [];
	for (let [e, o] of i) {
		if (o < 6) continue;
		let i = new Uint8Array(t * n);
		for (let a = 0; a < t * n; a++) {
			let t = r[a * 4 + 3];
			t < 8 || (r[a * 4] << 16 | r[a * 4 + 1] << 8 | r[a * 4 + 2]) * 256 + Math.round(t / 32) === e && (i[a] = 1);
		}
		let s = Math.floor(e / 256);
		a.push({
			fill: Ct(s >> 16 & 255, s >> 8 & 255, s & 255),
			opacity: Math.min(1, e % 256 * 32 / 255),
			contours: g(i, t, n, .6),
			size: o
		});
	}
	return a.sort((e, t) => Number(t.opacity < 1) - Number(e.opacity < 1) || t.size - e.size).map(({ fill: e, opacity: t, contours: n }) => ({
		fill: e,
		opacity: t,
		contours: n
	}));
}
async function Dt(e, t) {
	let { width: n, height: r, tones: i = 3, frame: a = 1, trim: o = 12, decodeImage: s, onProgress: c } = t, l = Et(await St(e, {
		width: n,
		height: r,
		tones: Math.min(6, Math.max(2, i)),
		frame: a,
		decodeImage: s,
		onProgress: c
	})).filter((e) => e.contours.length), [u, d, f, p] = [
		0,
		0,
		n,
		r
	];
	if (e.background.transparent && o >= 0 && l.length) {
		let e = l.flatMap((e) => e.contours.flat()), t = e.map((e) => e[0]), i = e.map((e) => e[1]);
		u = Math.max(0, Math.floor(Math.min(...t)) - o), d = Math.max(0, Math.floor(Math.min(...i)) - o), f = Math.min(n, Math.ceil(Math.max(...t)) + o) - u, p = Math.min(r, Math.ceil(Math.max(...i)) + o) - d;
	}
	let m = l.map((e) => `<path d="${Tt(e.contours)}" fill="${e.fill}"${e.opacity < 1 ? ` fill-opacity="${wt(e.opacity)}"` : ""} fill-rule="evenodd"/>`).join("\n"), h = e.background.transparent ? "" : `<rect width="${n}" height="${r}" fill="${e.background.color}"/>\n`;
	return `<svg xmlns="http://www.w3.org/2000/svg" width="${f}" height="${p}" viewBox="${u} ${d} ${f} ${p}">\n${h}${m}\n</svg>\n`;
}
//#endregion
//#region ../scene3d/src/model/core.ts
var Ot = /* @__PURE__ */ e({
	ALL_KINDS: () => S,
	COMBINE: () => C,
	FIELD_RANGE: () => 24,
	FIELD_SIZE: () => 256,
	FINISH: () => Ce,
	FINISHES: () => w,
	LOOKS: () => T,
	MAX_ASSETS_CHARS: () => D,
	MAX_ASSET_CHARS: () => E,
	MAX_FIELDS: () => 16,
	MAX_MESHES: () => 16,
	MAX_SHAPES: () => 48,
	MAX_TRIANGLES: () => a,
	ModelEditor: () => fe,
	OUTLINES: () => b,
	SHAPE_KINDS: () => x,
	SHAPE_LABELS: () => O,
	VIEWS: () => oe,
	area: () => v,
	assetFromObject3D: () => r,
	blendRadius: () => xe,
	boundsOf: () => Ie,
	browserCanvas: () => Me,
	browserDecode: () => ct,
	budget: () => te,
	checkAssets: () => H,
	checkModel: () => G,
	checkOutline: () => ee,
	checkShape: () => V,
	computeNormals: () => Le,
	createModel: () => P,
	createShape: () => N,
	defaultMaterial: () => Ne,
	fieldOf: () => d,
	finish: () => nt,
	fitsBudget: () => B,
	fromBase64: () => Fe,
	join: () => Se,
	mainColour: () => ke,
	march: () => De,
	meshAsset: () => at,
	meshBlocks: () => gt,
	meshBvh: () => st,
	meshShapes: () => re,
	modelFromOutline: () => pe,
	modelFromPicture: () => Ae,
	modelToSvg: () => Dt,
	newId: () => M,
	normalizeContours: () => o,
	outlineFrom: () => z,
	outlineFromAlpha: () => Oe,
	pathData: () => Tt,
	prepareMeshes: () => ut,
	pruneAssets: () => W,
	rasterize: () => c,
	readGltf: () => et,
	readModelFile: () => rt,
	regionsOf: () => Et,
	renderModelCpu: () => St,
	rotationMatrix: () => he,
	sampleField: () => p,
	sampleScene: () => Ee,
	segmentDistances: () => f,
	shapeAt: () => ie,
	shapeDistance: () => be,
	simplify: () => _,
	steps: () => ae,
	textOutline: () => je,
	toBase64: () => Pe,
	toLocal: () => ge,
	toModelAsset: () => i,
	traceContours: () => g,
	traceMeshes: () => ht,
	usedAssets: () => U,
	writeGlb: () => Ge
});
//#endregion
export { W as C, d as D, b as E, z as S, ae as T, T as _, Ne as a, P as b, Pe as c, je as d, De as f, w as g, C as h, Le as i, Ge as l, fe as m, Dt as n, nt as o, he as p, Tt as r, at as s, Ot as t, Me as u, x as v, ie as w, re as x, O as y };

//# sourceMappingURL=core-eUj9xEfb.js.map