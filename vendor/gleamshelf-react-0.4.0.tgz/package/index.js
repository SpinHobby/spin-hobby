import { A as e, D as t, M as n, N as r, O as i, S as a, _ as o, b as s, c, f as l, g as u, h as d, j as f, k as p, l as m, m as h, n as g, p as _, s as v, t as y, u as b, v as x, x as S, y as C } from "./src-CJixF5Xc.js";
import { _ as w, c as ee, d as te, f as ne, g as re, h as T, i as ie, l as ae, m as E, r as oe, t as se, u as ce } from "./Help-D3ggN5RX.js";
import { a as D, c as O, i as le, n as ue, o as de, r as fe, s as pe, t as me } from "./images-CA4oj0g0.js";
import { t as he } from "./PhotoLab-CJ_1bOoR.js";
import { Suspense as ge, lazy as _e, useCallback as k, useEffect as A, useLayoutEffect as ve, useMemo as ye, useRef as j, useState as M, useSyncExternalStore as be } from "react";
import { Fragment as N, jsx as P, jsxs as F } from "react/jsx-runtime";
import { createPortal as xe } from "react-dom";
//#region ../core/src/recolour.ts
var I = (e) => [
	parseInt(e.slice(1, 3), 16) / 255,
	parseInt(e.slice(3, 5), 16) / 255,
	parseInt(e.slice(5, 7), 16) / 255
], Se = (e) => ({
	width: e.width,
	height: e.height,
	data: new Uint8ClampedArray(e.data)
});
//#endregion
//#region ../pipeline/src/inpaint.ts
function Ce(e, t, n, r = 0, i = r) {
	let a = new Uint8Array(e * t);
	for (let o of n) {
		let n = Math.max(0, Math.floor((o.x - r) * e)), s = Math.max(0, Math.floor((o.y - i) * t)), c = Math.min(e, Math.ceil((o.x + o.width + r) * e)), l = Math.min(t, Math.ceil((o.y + o.height + i) * t));
		for (let t = s; t < l; t++) for (let r = n; r < c; r++) a[t * e + r] = 1;
	}
	return a;
}
function we(e, t, n, r) {
	let i = new Uint8Array(e.length);
	for (let a = 0; a < n; a++) for (let o = 0; o < t; o++) if (e[a * t + o]) for (let e = -r; e <= r; e++) for (let s = -r; s <= r; s++) {
		let r = o + s, c = a + e;
		r >= 0 && c >= 0 && r < t && c < n && (i[c * t + r] = 1);
	}
	return i;
}
var Te = (...e) => {
	let t = new Uint8Array(e[0].length);
	for (let n of e) for (let e = 0; e < t.length; e++) n[e] && (t[e] = 1);
	return t;
};
function Ee(e, t) {
	let { width: n, height: r, data: i } = e, a = null, o = 0, s = 0;
	for (let e of [
		8,
		4,
		2,
		1
	]) {
		let c = Math.max(2, Math.floor(n / e)), l = Math.max(2, Math.floor(r / e)), u = new Float32Array(c * l * 3), d = new Uint8Array(c * l);
		for (let e = 0; e < l; e++) for (let f = 0; f < c; f++) {
			let p = Math.floor(f * n / c), m = Math.floor(e * r / l), h = Math.max(p + 1, Math.floor((f + 1) * n / c)), g = Math.max(m + 1, Math.floor((e + 1) * r / l)), _ = 0, v = 0, y = 0, b = 0, x = 0;
			for (let e = m; e < g; e++) for (let r = p; r < h; r++) if (v++, !t[e * n + r]) {
				_++;
				let t = (e * n + r) * 4;
				y += i[t], b += i[t + 1], x += i[t + 2];
			}
			let S = e * c + f;
			if (_ === v) u[S * 3] = y / _, u[S * 3 + 1] = b / _, u[S * 3 + 2] = x / _;
			else if (d[S] = 1, a) {
				let t = (Math.min(s - 1, Math.floor(e * s / l)) * o + Math.min(o - 1, Math.floor(f * o / c))) * 3;
				u[S * 3] = a[t], u[S * 3 + 1] = a[t + 1], u[S * 3 + 2] = a[t + 2];
			} else _ ? (u[S * 3] = y / _, u[S * 3 + 1] = b / _, u[S * 3 + 2] = x / _) : u[S * 3] = u[S * 3 + 1] = u[S * 3 + 2] = 128;
		}
		let f = e === 1 ? 60 : 250;
		for (let e = 0; e < f; e++) for (let e = 0; e < l; e++) for (let t = 0; t < c; t++) {
			let n = e * c + t;
			if (!d[n]) continue;
			let r = t > 0 ? n - 1 : n, i = t < c - 1 ? n + 1 : n, a = e > 0 ? n - c : n, o = e < l - 1 ? n + c : n;
			for (let e = 0; e < 3; e++) u[n * 3 + e] = (u[r * 3 + e] + u[i * 3 + e] + u[a * 3 + e] + u[o * 3 + e]) / 4;
		}
		a = u, o = c, s = l;
	}
	let c = Se(e);
	if (a) {
		for (let e = 0; e < n * r; e++) if (t[e]) for (let t = 0; t < 3; t++) c.data[e * 4 + t] = a[e * 3 + t] + e * (7 + 4 * t) % 5 - 2;
	}
	return c;
}
//#endregion
//#region ../pipeline/src/stickers.ts
var De = (e) => Math.min(1, Math.max(0, e));
function Oe(e, t) {
	let { width: n, height: r, data: i } = e, a = t.width * 1, o = t.height * 1, s = Math.max(0, Math.floor((t.x - a) * n)), c = Math.max(0, Math.floor((t.y - o) * r)), l = Math.min(n, Math.ceil((t.x + t.width + a) * n)), u = Math.min(r, Math.ceil((t.y + t.height + o) * r)), d = l - s, f = u - c;
	if (d < 4 || f < 4) return t;
	let p = (e, t) => {
		let r = (t * n + e) * 4, a = Math.min(i[r], i[r + 1], i[r + 2]);
		return a >= 150 && Math.max(i[r], i[r + 1], i[r + 2]) - a <= 26;
	}, m = (e, i) => e >= t.x * n && e < (t.x + t.width) * n && i >= t.y * r && i < (t.y + t.height) * r, h = new Uint8Array(d * f), g = null, _ = [];
	for (let e = 0; e < f; e++) for (let t = 0; t < d; t++) {
		if (h[e * d + t] || !p(s + t, c + e)) continue;
		let n = 0, r = t, i = t, a = e, o = e;
		for (h[e * d + t] = 1, _.push(e * d + t); _.length;) {
			let e = _.pop(), t = e % d, l = (e - t) / d;
			m(s + t, c + l) && n++, t < r && (r = t), t > i && (i = t), l < a && (a = l), l > o && (o = l);
			for (let [e, n] of [
				[1, 0],
				[-1, 0],
				[0, 1],
				[0, -1]
			]) {
				let r = t + e, i = l + n;
				r < 0 || i < 0 || r >= d || i >= f || h[i * d + r] || !p(s + r, c + i) || (h[i * d + r] = 1, _.push(i * d + r));
			}
		}
		(!g || n > g.overlap) && (g = {
			overlap: n,
			minX: r,
			maxX: i,
			minY: a,
			maxY: o
		});
	}
	let v = t.width * n * t.height * r;
	if (!g || g.overlap < v * .2 || g.minX === 0 || g.minY === 0 || g.maxX === d - 1 || g.maxY === f - 1 || g.maxX - g.minX + 1 > t.width * n * 2 || g.maxY - g.minY + 1 > t.height * r * 2.5) return t;
	let y = Math.max(3, (g.maxX - g.minX) * .02), b = Math.max(3, (g.maxY - g.minY) * .04), x = De((s + g.minX - y) / n), S = De((c + g.minY - b) / r);
	return {
		x,
		y: S,
		width: De((s + g.maxX + 1 + y) / n) - x,
		height: De((c + g.maxY + 1 + b) / r) - S
	};
}
//#endregion
//#region ../pipeline/src/words.ts
var ke = {
	lightness: 225,
	maxWidth: 30,
	minLength: 35
};
function Ae(e, t) {
	let { width: n, height: r, data: i } = e, a = new Uint8Array(n * r);
	for (let e = 0; e < n * r; e++) {
		if (i[e * 4 + 3] < 128) continue;
		let n = i[e * 4], r = i[e * 4 + 1], o = i[e * 4 + 2], s = Math.min(n, r, o);
		s >= t && Math.max(n, r, o) - s <= 34 && (a[e] = 1);
	}
	return a;
}
function je(e, t, n, r, i) {
	let a = (e, a) => {
		let o = new Uint8Array(e.length), s = a ? t : n, c = a ? n : t;
		for (let n = 0; n < c; n++) for (let c = 0; c < s; c++) {
			let l = +!i;
			for (let o = -r; o <= r; o++) {
				let r = c + o, u = r < 0 || r >= s ? 0 : e[a ? n * t + r : r * t + n];
				if (i ? u : !u) {
					l = +!!i;
					break;
				}
			}
			o[a ? n * t + c : c * t + n] = l;
		}
		return o;
	};
	return a(a(e, !0), !1);
}
function Me(e, t = ke, n) {
	let { width: r, height: i } = e, a = Math.max(r, i), o = Ae(e, t.lightness), s = Math.max(1, Math.round(t.maxWidth / 1e3 * a * .5)), c = je(je(o, r, i, s, !1), r, i, s, !0), l = t.minLength / 1e3 * a, u = new Uint8Array(r * i), d = new Uint8Array(r * i), f = [], p = [];
	for (let e = 0; e < o.length; e++) {
		if (!o[e] || u[e] || n && !n[e]) continue;
		let t = [], a = r, s = 0, m = i, h = 0, g = 0;
		for (u[e] = 1, f.push(e); f.length;) {
			let e = f.pop();
			t.push(e), c[e] && g++;
			let i = e % r, l = (e - i) / r;
			i < a && (a = i), i > s && (s = i), l < m && (m = l), l > h && (h = l);
			for (let t of [
				e - 1,
				e + 1,
				e - r,
				e + r,
				e - r - 1,
				e - r + 1,
				e + r - 1,
				e + r + 1
			]) {
				if (t < 0 || t >= o.length || !o[t] || u[t] || n && !n[t]) continue;
				let e = t % r;
				Math.abs(e - i) > 1 || (u[t] = 1, f.push(t));
			}
		}
		let _ = Math.hypot(s - a, h - m);
		if (_ >= l && g / t.length < .5) for (let e of t) d[e] = 1;
		else _ >= l * .4 && p.push({
			members: t,
			thickShare: g / t.length
		});
	}
	let m = je(d, r, i, Math.max(2, Math.round(a * .03)), !0);
	for (let e of p) if (e.thickShare < .85 && e.members.some((e) => m[e])) for (let t of e.members) d[t] = 1;
	let h = Ae(e, Math.max(150, t.lightness - 40)), g = d;
	for (let e = 0; e < 4; e++) {
		let e = new Uint8Array(g);
		for (let t = 0; t < e.length; t++) {
			if (e[t] || !h[t] || n && !n[t]) continue;
			let i = t % r;
			(i > 0 && g[t - 1] || i < r - 1 && g[t + 1] || t >= r && g[t - r] || t + r < e.length && g[t + r]) && (e[t] = 1);
		}
		g = e;
	}
	return we(g, r, i, Math.max(2, Math.round(a * .0045)));
}
function Ne(e, t = ke, n, r, i = !0) {
	let a = i ? Me(e, t, n) : new Uint8Array(e.width * e.height);
	r && (a = a.map((e, t) => e || r[t] ? 1 : 0));
	let o = 0;
	for (let e of a) o += e;
	return {
		image: o ? Ee(e, a) : Se(e),
		filled: o
	};
}
//#endregion
//#region ../pipeline/src/printed.ts
var Pe = (e) => {
	let t = [...e].sort((e, t) => e - t);
	return t[Math.floor(t.length / 2)] ?? 0;
};
function Fe(e, t, n = 40) {
	let { width: r, height: i, data: a } = e, o = new Uint8Array(r * i), s = Math.max(0, Math.floor(t.x * r)), c = Math.max(0, Math.floor(t.y * i)), l = Math.min(r, Math.ceil((t.x + t.width) * r)), u = Math.min(i, Math.ceil((t.y + t.height) * i));
	if (l - s < 2 || u - c < 2) return o;
	let d = Math.max(2, Math.round(Math.min(l - s, u - c) * .25)), f = [], p = [], m = [], h = (e, t) => {
		let n = (t * r + e) * 4;
		f.push(a[n]), p.push(a[n + 1]), m.push(a[n + 2]);
	};
	for (let e = Math.max(0, c - d); e < Math.min(i, u + d); e++) for (let t = Math.max(0, s - d); t < Math.min(r, l + d); t++) (t < s || t >= l || e < c || e >= u) && h(t, e);
	if (f.length < 8) {
		for (let e = s; e < l; e++) h(e, c), h(e, u - 1);
		for (let e = c; e < u; e++) h(s, e), h(l - 1, e);
	}
	let g = [
		Pe(f),
		Pe(p),
		Pe(m)
	];
	if ([
		f,
		p,
		m
	].reduce((e, t, n) => e + Pe(t.map((e) => Math.abs(e - g[n]))), 0) / 3 > 18) return Ie(e, s, c, l, u);
	for (let e of [n, n * 1.8]) {
		let t = 0;
		o.fill(0);
		for (let n = c; n < u; n++) for (let i = s; i < l; i++) {
			let s = (n * r + i) * 4;
			(Math.abs(a[s] - g[0]) + Math.abs(a[s + 1] - g[1]) + Math.abs(a[s + 2] - g[2])) / 3 > e && (o[n * r + i] = 1, t++);
		}
		if (t <= (l - s) * (u - c) * .6) return o;
	}
	return Ie(e, s, c, l, u);
}
function Ie(e, t, n, r, i, a = 70) {
	let { width: o, height: s, data: c } = e, l = r - t, u = i - n, d = new Uint8Array(o * s), f = new Float32Array(l * u);
	for (let e = 0; e < u; e++) for (let r = 0; r < l; r++) {
		let i = ((n + e) * o + t + r) * 4;
		f[e * l + r] = .299 * c[i] + .587 * c[i + 1] + .114 * c[i + 2];
	}
	let p = Math.max(2, Math.round(u * .09)), m = (e, t) => {
		let n = (e, n) => {
			let r = new Float32Array(e.length), i = n ? l : u, a = n ? u : l;
			for (let o = 0; o < a; o++) for (let a = 0; a < i; a++) {
				let s = t ? -Infinity : Infinity;
				for (let r = Math.max(0, a - p); r <= Math.min(i - 1, a + p); r++) {
					let i = e[n ? o * l + r : r * l + o];
					(t ? i > s : i < s) && (s = i);
				}
				r[n ? o * l + a : a * l + o] = s;
			}
			return r;
		};
		return n(n(e, !0), !1);
	}, h = m(m(f, !0), !1), g = m(m(f, !1), !0), _ = 0, v = new Uint8Array(l * u);
	for (let e = 0; e < f.length; e++) (h[e] - f[e] > a || f[e] - g[e] > a) && (v[e] = 1, _++);
	if (_ > l * u * .4) return d;
	for (let e = 0; e < u; e++) for (let r = 0; r < l; r++) v[e * l + r] && (d[(n + e) * o + t + r] = 1);
	return d;
}
function Le(e, t, n, r = 48) {
	let { width: i, height: a, data: o } = e, s = (e, t) => {
		let n = (Math.min(a - 1, Math.max(0, t)) * i + Math.min(i - 1, Math.max(0, e))) * 4;
		return [
			o[n],
			o[n + 1],
			o[n + 2]
		];
	}, c = (e, t) => (Math.abs(e[0] - t[0]) + Math.abs(e[1] - t[1]) + Math.abs(e[2] - t[2])) / 3, l = Math.round(n.x), u = Math.round(n.y), d = Math.min(44, Math.max(14, Math.round((t.y1 - t.y0) * .2))), f = [], p = [], m = [];
	for (let e = -d - 2; e <= d + 2; e++) for (let t = -d - 2; t <= d + 2; t++) {
		if (Math.max(Math.abs(t), Math.abs(e)) < d) continue;
		let [n, r, i] = s(l + t, u + e);
		f.push(n), p.push(r), m.push(i);
	}
	let h = (e) => [...e].sort((e, t) => e - t)[Math.floor(e.length / 2)], g = [
		h(f),
		h(p),
		h(m)
	], _ = Math.min(22, Math.max(8, Math.round(d * .5))), v = null, y = 0;
	for (let e = 0; e <= _ && !v; e++) {
		for (let t = -e; t <= e; t++) for (let n = -e; n <= e; n++) {
			if (Math.max(Math.abs(n), Math.abs(t)) !== e) continue;
			let r = s(l + n, u + t), i = c(r, g);
			i >= 60 && i > y && (y = i, v = r);
		}
		if (v) for (let t = -(e + 2); t <= e + 2; t++) for (let n = -(e + 2); n <= e + 2; n++) {
			let e = s(l + n, u + t), r = c(e, g);
			r > y && (y = r, v = e);
		}
	}
	if (!v) return { problem: "no-print" };
	let b = new Uint8Array(i * a), x = 0, S = Math.max(0, Math.round(t.x0)), C = Math.max(0, Math.round(t.y0)), w = Math.min(i, Math.round(t.x1)), ee = Math.min(a, Math.round(t.y1));
	for (let e = C; e < ee; e++) for (let t = S; t < w; t++) {
		let n = (e * i + t) * 4;
		(Math.abs(o[n] - v[0]) + Math.abs(o[n + 1] - v[1]) + Math.abs(o[n + 2] - v[2])) / 3 < r && (b[e * i + t] = 1, x++);
	}
	return x < 12 ? { problem: "no-print" } : x > (w - S) * (ee - C) * .45 ? { problem: "too-much" } : {
		mask: b,
		color: v
	};
}
//#endregion
//#region ../pipeline/src/reconstruct.ts
function Re(e, t, n) {
	let r = (e) => {
		let t = e / 255;
		return t <= .04045 ? t / 12.92 : ((t + .055) / 1.055) ** 2.4;
	}, i = r(e), a = r(t), o = r(n), s = (e) => e > .008856 ? Math.cbrt(e) : 7.787 * e + 16 / 116, c = s((.4124 * i + .3576 * a + .1805 * o) / .95047), l = s(.2126 * i + .7152 * a + .0722 * o), u = s((.0193 * i + .1192 * a + .9505 * o) / 1.08883);
	return [
		116 * l - 16,
		500 * (c - l),
		200 * (l - u)
	];
}
function ze(e, t) {
	let n = /* @__PURE__ */ new Float64Array(128);
	for (let r of e) n[Math.min(127, Math.floor(r / t * 128))]++;
	let r = e.length, i = 0;
	for (let e = 0; e < 128; e++) i += e * n[e];
	let a = 0, o = 0, s = 0, c = 0;
	for (let e = 0; e < 128; e++) {
		if (a += n[e], !a) continue;
		let t = r - a;
		if (!t) break;
		o += e * n[e];
		let l = a * t * (o / a - (i - o) / t) ** 2;
		l > s && (s = l, c = e);
	}
	return (c + 1) / 128 * t;
}
function Be(e, t, n, r) {
	let i = new Uint8Array(t * n), a = new Uint8Array(t * n), o = [];
	for (let s = 0; s < t * n; s++) {
		if (!e[s] || a[s]) continue;
		let c = [];
		for (a[s] = 1, o.push(s); o.length;) {
			let r = o.pop();
			c.push(r);
			let i = r % t;
			for (let s of [
				i > 0 ? r - 1 : -1,
				i < t - 1 ? r + 1 : -1,
				r - t,
				r + t
			]) s < 0 || s >= t * n || !e[s] || a[s] || (a[s] = 1, o.push(s));
		}
		if (c.length >= r) for (let e of c) i[e] = 1;
	}
	return i;
}
function Ve(e, t, n, r = {}) {
	let { width: i, height: a } = e, { grow: o = 2, minPiece: s = 14, floor: c = 8 } = r, l = new Float32Array(i * a), u = [];
	for (let r = 0; r < i * a; r++) {
		if (!n[r]) continue;
		let i = Re(e.data[r * 4], e.data[r * 4 + 1], e.data[r * 4 + 2]), a = Re(t.data[r * 4], t.data[r * 4 + 1], t.data[r * 4 + 2]);
		l[r] = Math.hypot(i[0] - a[0], i[1] - a[1], i[2] - a[2]), u.push(l[r]);
	}
	if (!u.length) return new Uint8Array(i * a);
	let d = new Float32Array(i * a);
	for (let e = 0; e < a; e++) for (let t = 0; t < i; t++) {
		let n = 0, r = 0;
		for (let o = -1; o <= 1; o++) for (let s = -1; s <= 1; s++) {
			let c = t + s, u = e + o;
			if (c < 0 || u < 0 || c >= i || u >= a) continue;
			let d = (2 - Math.abs(s)) * (2 - Math.abs(o));
			n += l[u * i + c] * d, r += d;
		}
		d[e * i + t] = n / r;
	}
	l.set(d);
	let f = [];
	for (let e = 0; e < i * a; e++) n[e] && f.push(l[e]);
	let p = f.reduce((e, t) => Math.max(e, t), 0), m = Math.max(c, ze(f, Math.max(p, 1)) * .6), h = new Uint8Array(i * a);
	for (let e = 0; e < i * a; e++) n[e] && l[e] > m && (h[e] = 1);
	h = Be(h, i, a, s);
	let g = we(h, i, a, o);
	for (let e = 0; e < g.length; e++) n[e] || (g[e] = 0);
	return g;
}
//#endregion
//#region ../shaders/src/compose.ts
var He = "#version 300 es\nprecision highp float;\nuniform sampler2D uInput;\nuniform vec2 uResolution;\nuniform float uTime;\nuniform bool uFlipY;\nuniform bool uInputFlipped;\nout vec4 outColor;\nvec4 sampleInput(vec2 uv) { return texture(uInput, uInputFlipped ? vec2(uv.x, 1.0 - uv.y) : uv); }\nvec2 perMille(float v) { return v * 0.001 * max(uResolution.x, uResolution.y) / uResolution; }\n", Ue = "\nvoid main() {\n  vec2 uv = gl_FragCoord.xy / uResolution;\n  if (uFlipY) uv.y = 1.0 - uv.y;\n  outColor = effect(uv, sampleInput(uv));\n}\n";
function L(e) {
	return He + e.source + Ue;
}
//#endregion
//#region ../render2d/src/shaders.ts
var We = "#version 300 es\nvoid main() {\n  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));\n  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);\n}", R = "#version 300 es\nprecision highp float;\n\nuniform sampler2D uSource;\nuniform sampler2D uMask;   // cut-out alpha, same coordinates as the source\nuniform bool uHasMask;\nuniform vec2 uMaskTexel;   // size of one mask pixel in source coordinates\nuniform bool uDespill;     // pull green spill off the product's cut edge\nuniform sampler2D uBackground;\nuniform int uBgMode;       // 0 transparent, 1 colour, 2 photo\nuniform vec3 uBgColor;\nuniform vec4 uBgTransform; // output uv -> photo uv: scale.xy, offset.xy (\"cover\")\nuniform mat3 uOutputToSource;\nuniform vec2 uOutputSize;\nuniform bool uFlipY;\n\nuniform float uExposure;   // stops\nuniform float uContrast;   // -1..1\nuniform float uHighlights; // -1..1\nuniform float uShadows;    // -1..1\nuniform vec3 uWhiteBalance; // per-channel gains, luminance-neutral\nuniform float uVibrance;   // -1..1\nuniform float uSaturation; // -1..1\nuniform float uVignette;   // -1..1\nuniform bool uRecolour;    // off by default: it changes the product's own colour (core/recolour.ts is the reference)\nuniform vec3 uRecolourFrom;\nuniform vec3 uRecolourTo;\nuniform float uRecolourRange; // degrees of hue\n\nout vec4 outColor;\n\nvec3 toLinear(vec3 c) {\n  return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), step(0.04045, c));\n}\n\nvec3 toDisplay(vec3 c) {\n  c = max(c, 0.0);\n  return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c));\n}\n\nfloat luma(vec3 c) {\n  return dot(c, vec3(0.2126, 0.7152, 0.0722));\n}\n\n// hue in degrees, saturation, value\nvec3 rgbToHsv(vec3 c) {\n  float mx = max(c.r, max(c.g, c.b));\n  float mn = min(c.r, min(c.g, c.b));\n  float d = mx - mn;\n  float h = 0.0;\n  if (d > 0.0) {\n    if (mx == c.r) h = mod((c.g - c.b) / d, 6.0);\n    else if (mx == c.g) h = (c.b - c.r) / d + 2.0;\n    else h = (c.r - c.g) / d + 4.0;\n    h *= 60.0;\n  }\n  return vec3(h, mx > 0.0 ? d / mx : 0.0, mx);\n}\n\nvec3 hsvToRgb(vec3 hsv) {\n  vec3 k = mod(vec3(5.0, 3.0, 1.0) + mod(hsv.x, 360.0) / 60.0, 6.0);\n  return hsv.z - hsv.z * hsv.y * clamp(min(k, 4.0 - k), 0.0, 1.0);\n}\n\nvec3 recolour(vec3 c) {\n  vec3 p = rgbToHsv(c);\n  vec3 f = rgbToHsv(uRecolourFrom);\n  vec3 t = rgbToHsv(uRecolourTo);\n  float d = abs(mod(p.x - f.x + 540.0, 360.0) - 180.0);\n  float w = smoothstep(0.06, 0.18, p.y) * (1.0 - smoothstep(uRecolourRange * 0.6, uRecolourRange, d));\n  vec3 changed = hsvToRgb(vec3(p.x + (t.x - f.x), min(1.0, p.y * t.y / max(f.y, 0.05)), min(1.0, p.z * t.z / max(f.z, 0.05))));\n  return mix(c, changed, w);\n}\n\nvoid main() {\n  vec2 uv = gl_FragCoord.xy / uOutputSize;\n  if (uFlipY) uv.y = 1.0 - uv.y;\n\n  // The product, if this output pixel falls inside the photo (a square canvas can reach past its edges).\n  vec4 product = vec4(0.0);\n  vec2 src = (uOutputToSource * vec3(uv, 1.0)).xy;\n  if (!(any(lessThan(src, vec2(0.0))) || any(greaterThan(src, vec2(1.0))))) {\n    vec4 texel = texture(uSource, src);\n    float maskAlpha = uHasMask ? texture(uMask, src).r : 1.0;\n\n    if (uDespill && uHasMask) {\n      // Only where the cut edge is close: elsewhere a green pixel is the product's own colour.\n      vec2 d = uMaskTexel * 3.0;\n      float nearest = min(min(texture(uMask, src + vec2(d.x, 0.0)).r, texture(uMask, src - vec2(d.x, 0.0)).r),\n                          min(texture(uMask, src + vec2(0.0, d.y)).r, texture(uMask, src - vec2(0.0, d.y)).r));\n      float dom = texel.g - max(texel.r, texel.b);\n      if (nearest < 0.99 && dom > 0.0) texel.g = max(texel.r, texel.b) + dom * 0.15;\n    }\n\n    if (uRecolour) texel.rgb = recolour(texel.rgb);\n\n    vec3 linear = toLinear(texel.rgb) * exp2(uExposure) * uWhiteBalance;\n    vec3 c = toDisplay(linear);\n\n    float y = luma(c);\n    c *= 1.0 + uShadows * 0.6 * (1.0 - smoothstep(0.0, 0.55, y));\n    c *= 1.0 + uHighlights * 0.5 * smoothstep(0.45, 1.0, y);\n    c = (c - 0.5) * (1.0 + uContrast * 0.8) + 0.5;\n\n    y = luma(c);\n    float chroma = max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b));\n    c = mix(vec3(y), c, 1.0 + uVibrance * (1.0 - clamp(chroma, 0.0, 1.0)));\n    c = mix(vec3(y), c, 1.0 + uSaturation);\n\n    float edge = smoothstep(0.35, 1.0, length(uv - 0.5) * 1.41421);\n    c *= 1.0 + uVignette * edge;\n\n    product = vec4(clamp(c, 0.0, 1.0), texel.a * maskAlpha);\n  }\n\n  // Put the product over whatever is behind it.\n  vec3 behind = vec3(0.0);\n  float behindAlpha = 0.0;\n  if (uBgMode == 1) {\n    behind = uBgColor;\n    behindAlpha = 1.0;\n  } else if (uBgMode == 2) {\n    behind = texture(uBackground, uv * uBgTransform.xy + uBgTransform.zw).rgb;\n    behindAlpha = 1.0;\n  }\n  float a = product.a + behindAlpha * (1.0 - product.a);\n  vec3 rgb = a > 0.0 ? (product.rgb * product.a + behind * behindAlpha * (1.0 - product.a)) / a : vec3(0.0);\n  outColor = vec4(rgb, a);\n}", z = [
	"uSource",
	"uMask",
	"uHasMask",
	"uMaskTexel",
	"uDespill",
	"uBackground",
	"uBgMode",
	"uBgColor",
	"uBgTransform",
	"uOutputToSource",
	"uOutputSize",
	"uFlipY",
	"uExposure",
	"uContrast",
	"uHighlights",
	"uShadows",
	"uWhiteBalance",
	"uVibrance",
	"uSaturation",
	"uVignette",
	"uRecolour",
	"uRecolourFrom",
	"uRecolourTo",
	"uRecolourRange"
], B = "#version 300 es\nprecision highp float;\nuniform sampler2D uProduct;\nuniform sampler2D uBackground;\nuniform vec2 uResolution;\nuniform bool uFlipY;\nuniform int uBgMode;\nuniform vec3 uBgColor;\nuniform vec4 uBgTransform;\nout vec4 outColor;\nvoid main() {\n  vec2 uv = gl_FragCoord.xy / uResolution;\n  if (uFlipY) uv.y = 1.0 - uv.y;\n  vec4 product = texture(uProduct, uv);\n  vec3 behind = vec3(0.0);\n  float behindAlpha = 0.0;\n  if (uBgMode == 1) { behind = uBgColor; behindAlpha = 1.0; }\n  else if (uBgMode == 2) { behind = texture(uBackground, uv * uBgTransform.xy + uBgTransform.zw).rgb; behindAlpha = 1.0; }\n  float a = product.a + behindAlpha * (1.0 - product.a);\n  vec3 rgb = a > 0.0 ? (product.rgb * product.a + behind * behindAlpha * (1.0 - product.a)) / a : vec3(0.0);\n  outColor = vec4(rgb, a);\n}";
function Ge(e, t, n) {
	let r = e.createShader(t);
	if (e.shaderSource(r, n), e.compileShader(r), !e.getShaderParameter(r, e.COMPILE_STATUS)) {
		let t = e.getShaderInfoLog(r);
		throw e.deleteShader(r), Error(`Shader failed to compile: ${t}`);
	}
	return r;
}
function V(e, t) {
	let n = e / 100, r = t / 100, i = [
		1 + .25 * n,
		1 - .2 * r,
		1 - .25 * n
	], a = .2126 * i[0] + .7152 * i[1] + .0722 * i[2];
	return i.map((e) => e / a);
}
function Ke(e, t, n) {
	return new Promise((r, i) => e.toBlob((e) => e ? r(e) : i(/* @__PURE__ */ Error("This browser could not encode the image.")), t, n));
}
var qe = class {
	canvas;
	maxTextureSize;
	gl;
	program;
	vao;
	uniforms;
	source = null;
	mask = null;
	maskTexel = [0, 0];
	despill = !1;
	background = null;
	backgroundSize = [1, 1];
	effectPrograms = /* @__PURE__ */ new Map();
	composite = null;
	scratch = null;
	noMask;
	constructor(e) {
		this.canvas = e;
		let t = e.getContext("webgl2", {
			alpha: !0,
			premultipliedAlpha: !1,
			antialias: !1
		});
		if (!t) throw Error("This browser does not support WebGL2, which the editor needs.");
		this.gl = t, this.maxTextureSize = t.getParameter(t.MAX_TEXTURE_SIZE);
		let n = t.createProgram();
		if (t.attachShader(n, Ge(t, t.VERTEX_SHADER, We)), t.attachShader(n, Ge(t, t.FRAGMENT_SHADER, R)), t.linkProgram(n), !t.getProgramParameter(n, t.LINK_STATUS)) throw Error(`Shader failed to link: ${t.getProgramInfoLog(n)}`);
		this.program = n, this.vao = t.createVertexArray(), this.noMask = t.createTexture(), t.bindTexture(t.TEXTURE_2D, this.noMask), t.texImage2D(t.TEXTURE_2D, 0, t.R8, 1, 1, 0, t.RED, t.UNSIGNED_BYTE, new Uint8Array([255])), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MIN_FILTER, t.NEAREST), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MAG_FILTER, t.NEAREST), this.uniforms = Object.fromEntries(z.map((e) => [e, t.getUniformLocation(n, e)]));
	}
	setSource(e) {
		let t = this.gl;
		this.source && t.deleteTexture(this.source), this.source = t.createTexture(), t.bindTexture(t.TEXTURE_2D, this.source), t.pixelStorei(t.UNPACK_FLIP_Y_WEBGL, !1), t.pixelStorei(t.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !1), t.texImage2D(t.TEXTURE_2D, 0, t.RGBA8, t.RGBA, t.UNSIGNED_BYTE, e), t.generateMipmap(t.TEXTURE_2D), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MIN_FILTER, t.LINEAR_MIPMAP_LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MAG_FILTER, t.LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_S, t.CLAMP_TO_EDGE), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_T, t.CLAMP_TO_EDGE);
	}
	setMask(e, t = 0, n = 0, r = {}) {
		let i = this.gl;
		this.mask && i.deleteTexture(this.mask), this.mask = null, this.despill = !1, e && (this.despill = r.despill === !0, this.maskTexel = [1 / t, 1 / n], this.mask = i.createTexture(), i.bindTexture(i.TEXTURE_2D, this.mask), i.pixelStorei(i.UNPACK_ALIGNMENT, 1), i.texImage2D(i.TEXTURE_2D, 0, i.R8, t, n, 0, i.RED, i.UNSIGNED_BYTE, e), i.pixelStorei(i.UNPACK_ALIGNMENT, 4), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_MIN_FILTER, i.LINEAR), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_MAG_FILTER, i.LINEAR), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_WRAP_S, i.CLAMP_TO_EDGE), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_WRAP_T, i.CLAMP_TO_EDGE));
	}
	setBackground(e) {
		let t = this.gl;
		this.background && t.deleteTexture(this.background), this.background = null, e && (this.backgroundSize = [e.width, e.height], this.background = t.createTexture(), t.bindTexture(t.TEXTURE_2D, this.background), t.pixelStorei(t.UNPACK_FLIP_Y_WEBGL, !1), t.pixelStorei(t.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !1), t.texImage2D(t.TEXTURE_2D, 0, t.RGBA8, t.RGBA, t.UNSIGNED_BYTE, e), t.generateMipmap(t.TEXTURE_2D), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MIN_FILTER, t.LINEAR_MIPMAP_LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MAG_FILTER, t.LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_S, t.CLAMP_TO_EDGE), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_T, t.CLAMP_TO_EDGE));
	}
	draw(e, t, n) {
		this.canvas.width !== t && (this.canvas.width = t), this.canvas.height !== n && (this.canvas.height = n), this.render(e, t, n, !0, null);
	}
	async export(e, t = {}) {
		let n = this.gl, r = Math.min(this.maxTextureSize, n.getParameter(n.MAX_RENDERBUFFER_SIZE)), { width: i, height: a } = _(e, Math.min(t.maxSize ?? Infinity, r)), o = n.createTexture();
		n.bindTexture(n.TEXTURE_2D, o), n.texStorage2D(n.TEXTURE_2D, 1, n.RGBA8, i, a);
		let s = n.createFramebuffer();
		n.bindFramebuffer(n.FRAMEBUFFER, s), n.framebufferTexture2D(n.FRAMEBUFFER, n.COLOR_ATTACHMENT0, n.TEXTURE_2D, o, 0);
		let c = new Uint8ClampedArray(i * a * 4);
		try {
			this.render(e, i, a, !1, s), n.readPixels(0, 0, i, a, n.RGBA, n.UNSIGNED_BYTE, c);
		} finally {
			n.bindFramebuffer(n.FRAMEBUFFER, null), n.deleteFramebuffer(s), n.deleteTexture(o);
		}
		let l = t.type ?? "image/webp", u = document.createElement("canvas");
		u.width = i, u.height = a, u.getContext("2d").putImageData(new ImageData(c, i, a), 0, 0);
		let d = async (e, n) => {
			if (e !== "image/jpeg") return Ke(u, e, n);
			let r = document.createElement("canvas");
			r.width = i, r.height = a;
			let o = r.getContext("2d");
			return o.fillStyle = t.background ?? "#ffffff", o.fillRect(0, 0, i, a), o.drawImage(u, 0, 0), Ke(r, e, n);
		}, f = t.quality ?? .88, p = await d(l, f), m = p.type === l ? l : l === "image/webp" ? "image/jpeg" : p.type;
		if (m !== p.type && (p = await d(m, f)), t.maxBytes && m !== "image/png") for (; p.size > t.maxBytes && f > .4;) f -= .08, p = await d(m, f);
		return {
			blob: p,
			width: i,
			height: a,
			type: p.type
		};
	}
	dispose() {
		let e = this.gl;
		this.source && e.deleteTexture(this.source), this.mask && e.deleteTexture(this.mask), this.background && e.deleteTexture(this.background), e.deleteTexture(this.noMask), this.freeScratch();
		for (let t of this.effectPrograms.values()) typeof t != "string" && e.deleteProgram(t.program);
		this.effectPrograms.clear(), this.composite && e.deleteProgram(this.composite.program), e.deleteProgram(this.program), e.deleteVertexArray(this.vao), this.source = null;
	}
	compileEffect(e) {
		let t = this.effectProgram(e);
		return typeof t == "string" ? t : null;
	}
	effectProgram(e) {
		let t = `${e.id}:${e.source.length}:${e.source.slice(-40)}`, n = this.effectPrograms.get(t);
		if (n) return n;
		let r = this.gl, i;
		try {
			let t = r.createProgram();
			if (r.attachShader(t, Ge(r, r.VERTEX_SHADER, E)), r.attachShader(t, Ge(r, r.FRAGMENT_SHADER, L(e))), r.linkProgram(t), !r.getProgramParameter(t, r.LINK_STATUS)) throw Error(`Shader failed to link: ${r.getProgramInfoLog(t)}`);
			i = {
				program: t,
				inputs: {
					uInput: r.getUniformLocation(t, "uInput"),
					uResolution: r.getUniformLocation(t, "uResolution"),
					uTime: r.getUniformLocation(t, "uTime"),
					uFlipY: r.getUniformLocation(t, "uFlipY"),
					uInputFlipped: r.getUniformLocation(t, "uInputFlipped")
				},
				params: new Map(e.params.map((e) => [e.uniform, r.getUniformLocation(t, e.uniform)]))
			};
		} catch (t) {
			i = `${e.id}: ${t instanceof Error ? t.message : String(t)}`, console.warn(`The "${e.name}" effect was skipped. ${i}`);
		}
		return this.effectPrograms.set(t, i), i;
	}
	freeScratch() {
		if (this.scratch) {
			for (let e of this.scratch.targets) this.gl.deleteFramebuffer(e.framebuffer), this.gl.deleteTexture(e.texture);
			this.scratch = null;
		}
	}
	scratchTargets(e, t) {
		let n = this.gl;
		if (this.scratch && this.scratch.width === e && this.scratch.height === t) return this.scratch.targets;
		this.freeScratch();
		let r = () => {
			let r = n.createTexture();
			n.bindTexture(n.TEXTURE_2D, r), n.texStorage2D(n.TEXTURE_2D, 1, n.RGBA8, e, t), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MIN_FILTER, n.LINEAR), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MAG_FILTER, n.LINEAR), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_S, n.CLAMP_TO_EDGE), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_T, n.CLAMP_TO_EDGE);
			let i = n.createFramebuffer();
			return n.bindFramebuffer(n.FRAMEBUFFER, i), n.framebufferTexture2D(n.FRAMEBUFFER, n.COLOR_ATTACHMENT0, n.TEXTURE_2D, r, 0), {
				texture: r,
				framebuffer: i
			};
		}, i = [r(), r()];
		return this.scratch = {
			width: e,
			height: t,
			targets: i
		}, i;
	}
	runEffect(e, t, n, r, i, a, o, s) {
		let c = this.gl;
		c.bindFramebuffer(c.FRAMEBUFFER, i), c.viewport(0, 0, a, o), c.useProgram(e.program), c.bindVertexArray(this.vao), c.activeTexture(c.TEXTURE0), c.bindTexture(c.TEXTURE_2D, r), c.uniform1i(e.inputs.uInput, 0), c.uniform2f(e.inputs.uResolution, a, o), c.uniform1f(e.inputs.uTime, 0), c.uniform1i(e.inputs.uFlipY, +!!s), c.uniform1i(e.inputs.uInputFlipped, 0);
		for (let r of t.params) {
			let t = e.params.get(r.uniform);
			if (!t) continue;
			let i = w(r, n[r.key]);
			Array.isArray(i) ? c.uniform3f(t, i[0], i[1], i[2]) : r.glslType === "float" ? c.uniform1f(t, i) : c.uniform1i(t, i);
		}
		c.drawArrays(c.TRIANGLES, 0, 3);
	}
	runComposite(e, t, n, r, i, a) {
		let o = this.gl;
		if (!this.composite) {
			let e = o.createProgram();
			if (o.attachShader(e, Ge(o, o.VERTEX_SHADER, We)), o.attachShader(e, Ge(o, o.FRAGMENT_SHADER, B)), o.linkProgram(e), !o.getProgramParameter(e, o.LINK_STATUS)) throw Error(`Shader failed to link: ${o.getProgramInfoLog(e)}`);
			let t = [
				"uProduct",
				"uBackground",
				"uResolution",
				"uFlipY",
				"uBgMode",
				"uBgColor",
				"uBgTransform"
			];
			this.composite = {
				program: e,
				uniforms: Object.fromEntries(t.map((t) => [t, o.getUniformLocation(e, t)]))
			};
		}
		let s = this.composite.uniforms;
		o.bindFramebuffer(o.FRAMEBUFFER, n), o.viewport(0, 0, r, i), o.useProgram(this.composite.program), o.bindVertexArray(this.vao), o.activeTexture(o.TEXTURE0), o.bindTexture(o.TEXTURE_2D, t), o.uniform1i(s.uProduct, 0);
		let c = S(e.recipe, "backdrop", "mode") === "image" && this.background;
		o.activeTexture(o.TEXTURE1), o.bindTexture(o.TEXTURE_2D, c ? this.background : this.noMask), o.uniform1i(s.uBackground, 1), o.uniform2f(s.uResolution, r, i), o.uniform1i(s.uFlipY, +!!a), this.setBackdropUniforms(e, r, i, s.uBgMode, s.uBgColor, s.uBgTransform), o.activeTexture(o.TEXTURE0), o.drawArrays(o.TRIANGLES, 0, 3);
	}
	setBackdropUniforms(e, t, n, r, i, a) {
		let o = this.gl, s = e.recipe, c = S(s, "backdrop", "mode"), l = c === "image" && this.background;
		o.uniform1i(r, l ? 2 : +(c === "color"));
		let u = S(s, "backdrop", "color") || "#ffffff";
		o.uniform3f(i, parseInt(u.slice(1, 3), 16) / 255, parseInt(u.slice(3, 5), 16) / 255, parseInt(u.slice(5, 7), 16) / 255);
		let d = t / n, f = this.backgroundSize[0] / this.backgroundSize[1], p = f > d ? d / f : 1, m = f > d ? 1 : f / d;
		o.uniform4f(a, p, m, (1 - p) / 2, (1 - m) / 2);
	}
	render(e, t, n, r, i) {
		let a = e.recipe.effects.map((e) => ({
			step: e,
			def: T(e.id)
		})).filter((e) => !!e.def).map((e) => ({
			...e,
			program: this.effectProgram(e.def)
		})).filter((e) => typeof e.program != "string");
		if (!a.length) {
			this.gl.bindFramebuffer(this.gl.FRAMEBUFFER, i), this.drawPhoto(e, t, n, r, !0);
			return;
		}
		let [o, s] = this.scratchTargets(t, n);
		this.gl.bindFramebuffer(this.gl.FRAMEBUFFER, o.framebuffer), this.drawPhoto(e, t, n, !1, !1);
		let c = o, l = s, u = () => {
			[c, l] = [l, c];
		}, d = a.filter((e) => e.def.scope === "product"), f = a.filter((e) => e.def.scope !== "product");
		for (let e of d) this.runEffect(e.program, e.def, re(e.def, e.step.params), c.texture, l.framebuffer, t, n, !1), u();
		this.runComposite(e, c.texture, f.length ? l.framebuffer : i, t, n, !f.length && r), f.length && (u(), f.forEach((e, a) => {
			let o = a === f.length - 1;
			this.runEffect(e.program, e.def, re(e.def, e.step.params), c.texture, o ? i : l.framebuffer, t, n, o ? r : !1), u();
		}));
	}
	drawPhoto(e, t, n, r, i) {
		let o = this.gl, c = this.uniforms, l = e.recipe, u = h(e);
		if (o.viewport(0, 0, t, n), o.clearColor(0, 0, 0, 0), o.clear(o.COLOR_BUFFER_BIT), !this.source) return;
		o.useProgram(this.program), o.bindVertexArray(this.vao), o.activeTexture(o.TEXTURE0), o.bindTexture(o.TEXTURE_2D, this.source), o.uniform1i(c.uSource, 0), o.activeTexture(o.TEXTURE1), o.bindTexture(o.TEXTURE_2D, this.mask ?? this.noMask), o.uniform1i(c.uMask, 1), o.uniform1i(c.uHasMask, +!!this.mask), o.uniform2f(c.uMaskTexel, this.maskTexel[0], this.maskTexel[1]), o.uniform1i(c.uDespill, +!!this.despill);
		let d = i && S(l, "backdrop", "mode") === "image" && this.background;
		o.activeTexture(o.TEXTURE2), o.bindTexture(o.TEXTURE_2D, d ? this.background : this.noMask), o.uniform1i(c.uBackground, 2), i ? this.setBackdropUniforms(e, t, n, c.uBgMode, c.uBgColor, c.uBgTransform) : o.uniform1i(c.uBgMode, 0), o.activeTexture(o.TEXTURE0), o.uniformMatrix3fv(c.uOutputToSource, !1, [
			u.a,
			u.b,
			0,
			u.c,
			u.d,
			0,
			u.e,
			u.f,
			1
		]), o.uniform2f(c.uOutputSize, t, n), o.uniform1i(c.uFlipY, +!!r), o.uniform1f(c.uExposure, a(l, "light", "exposure")), o.uniform1f(c.uContrast, a(l, "light", "contrast") / 100), o.uniform1f(c.uHighlights, a(l, "light", "highlights") / 100), o.uniform1f(c.uShadows, a(l, "light", "shadows") / 100), o.uniform3fv(c.uWhiteBalance, V(a(l, "color", "temperature"), a(l, "color", "tint"))), o.uniform1f(c.uVibrance, a(l, "color", "vibrance") / 100), o.uniform1f(c.uSaturation, a(l, "color", "saturation") / 100), o.uniform1f(c.uVignette, a(l, "effects", "vignette") / 100), o.uniform1i(c.uRecolour, +!!s(l, "recolour", "on")), o.uniform3fv(c.uRecolourFrom, I(S(l, "recolour", "from") || "#d23c3c")), o.uniform3fv(c.uRecolourTo, I(S(l, "recolour", "to") || "#3c64d2")), o.uniform1f(c.uRecolourRange, a(l, "recolour", "range") || 30), o.drawArrays(o.TRIANGLES, 0, 3);
	}
}, Je = [
	"nw",
	"n",
	"ne",
	"e",
	"se",
	"s",
	"sw",
	"w"
], Ye = (e) => `${e * 100}%`;
function Xe({ editor: e, doc: t, width: n, height: r }) {
	let i = j(null), a = c(t), o = (t) => (n) => {
		n.preventDefault(), n.stopPropagation(), n.currentTarget.setPointerCapture(n.pointerId), i.current = {
			handle: t,
			start: c(e.document),
			x: n.clientX,
			y: n.clientY
		}, e.begin(t === "move" ? "Move crop" : "Resize crop");
	}, s = (t) => {
		let a = i.current;
		if (!a) return;
		let o = e.document;
		e.setCrop(m(a.start, a.handle, (t.clientX - a.x) / n, (t.clientY - a.y) / r, b(o), l(o)));
	}, u = () => {
		i.current && (i.current = null, e.commit());
	};
	return /* @__PURE__ */ P("div", {
		className: "gs-crop",
		style: {
			width: n,
			height: r
		},
		onPointerMove: s,
		onPointerUp: u,
		onPointerCancel: u,
		children: /* @__PURE__ */ F("div", {
			className: "gs-crop__box",
			style: {
				left: Ye(a.x),
				top: Ye(a.y),
				width: Ye(a.width),
				height: Ye(a.height)
			},
			onPointerDown: o("move"),
			children: [/* @__PURE__ */ P("div", { className: "gs-crop__thirds" }), Je.map((e) => /* @__PURE__ */ P("div", {
				className: `gs-crop__handle gs-crop__handle--${e}`,
				onPointerDown: o(e)
			}, e))]
		})
	});
}
//#endregion
//#region src/CutoutOverlay.tsx
var Ze = .002;
function Qe({ editor: e, doc: t, settings: n, width: r, height: i }) {
	let a = j(null), [o, s] = M(null), c = (t) => {
		let n = t.currentTarget.getBoundingClientRect(), [r, i] = v(h(e.document), (t.clientX - n.left) / n.width, (t.clientY - n.top) / n.height);
		return [Math.min(1, Math.max(0, r)), Math.min(1, Math.max(0, i))];
	}, l = (e) => ({
		kind: "brush",
		mode: n.tool === "erase" ? "remove" : "keep",
		radius: n.brush,
		points: e
	}), u = (t) => {
		t.preventDefault();
		let [r, i] = c(t);
		n.tool === "tap" ? e.addMaskOp({
			kind: "fill",
			mode: "remove",
			x: r,
			y: i,
			tolerance: n.tolerance
		}) : (t.currentTarget.setPointerCapture(t.pointerId), a.current = [r, i], e.begin(n.tool === "erase" ? "Erase" : "Restore"), e.addMaskOp(l(a.current)));
	}, d = (t) => {
		let n = t.currentTarget.getBoundingClientRect();
		s({
			x: t.clientX - n.left,
			y: t.clientY - n.top
		});
		let r = a.current;
		if (!r) return;
		let [i, o] = c(t);
		Math.hypot(i - r[r.length - 2], o - r[r.length - 1]) < Ze || (r.push(i, o), e.updateLastMaskOp(l([...r])));
	}, f = () => {
		a.current && (a.current = null, e.commit());
	}, p = _(t), m = n.brush * Math.max(t.source.width, t.source.height) * (r / p.width);
	return /* @__PURE__ */ P("div", {
		className: `gs-cutout gs-cutout--${n.tool}`,
		style: {
			width: r,
			height: i
		},
		onPointerDown: u,
		onPointerMove: d,
		onPointerUp: f,
		onPointerCancel: f,
		onPointerLeave: () => s(null),
		children: o && n.tool !== "tap" && /* @__PURE__ */ P("div", {
			className: "gs-cutout__brush",
			style: {
				left: o.x - m,
				top: o.y - m,
				width: m * 2,
				height: m * 2
			}
		})
	});
}
var $e = {
	id: "birefnet-general-fp16",
	name: "BiRefNet (whole box, larger)",
	task: "cutout",
	summary: "Cuts a whole box or product out of any background. Four times the size of the compact model, and it was never fooled by artwork on a cover (the compact one took a girl on the cover for the object on one box in ten).",
	recommended: !1,
	license: {
		name: "MIT",
		commercialUse: "allowed",
		url: "https://huggingface.co/ZhengPeng7/BiRefNet"
	},
	sizeMb: 489.7,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/ZhengPeng7/BiRefNet",
		download: "https://huggingface.co/onnx-community/BiRefNet-ONNX/resolve/main/onnx/model_fp16.onnx"
	},
	file: {
		name: "birefnet-general-fp16.onnx",
		bytes: 489666272
	},
	input: {
		size: 1024,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "logits-mask"
}, H = {
	id: "birefnet-lite-fp16",
	name: "BiRefNet lite (compact)",
	task: "cutout",
	summary: "Separates the product from any background, with clean edges. The compact version: half the download, nearly the same quality.",
	recommended: !0,
	license: {
		name: "MIT",
		commercialUse: "allowed",
		url: "https://huggingface.co/ZhengPeng7/BiRefNet_lite"
	},
	sizeMb: 114.5,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/ZhengPeng7/BiRefNet_lite",
		download: "https://huggingface.co/onnx-community/BiRefNet_lite-ONNX/resolve/main/onnx/model_fp16.onnx"
	},
	file: {
		name: "birefnet-lite-fp16.onnx",
		bytes: 114538221
	},
	input: {
		size: 1024,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "logits-mask"
}, et = {
	id: "birefnet-lite",
	name: "BiRefNet lite (full precision)",
	task: "cutout",
	summary: "The same cut-out model at full precision. A bigger download for slightly finer edges.",
	recommended: !1,
	license: {
		name: "MIT",
		commercialUse: "allowed",
		url: "https://huggingface.co/ZhengPeng7/BiRefNet_lite"
	},
	sizeMb: 224,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/ZhengPeng7/BiRefNet_lite",
		download: "https://huggingface.co/onnx-community/BiRefNet_lite-ONNX/resolve/main/onnx/model.onnx"
	},
	file: {
		name: "birefnet-lite.onnx",
		bytes: 224005088
	},
	input: {
		size: 1024,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "logits-mask"
}, tt = {
	id: "lama-fp32",
	name: "LaMa fill (removes marks and lettering)",
	task: "inpaint",
	summary: "Paints over what you mask (printed words, stickers, marks) with realistic detail from around it. Much cleaner than the free fill on hair and fabric. Takes a few seconds per patch on a laptop.",
	recommended: !0,
	license: {
		name: "Apache-2.0",
		commercialUse: "allowed",
		url: "https://huggingface.co/Carve/LaMa-ONNX"
	},
	sizeMb: 208,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/Carve/LaMa-ONNX",
		download: "https://huggingface.co/Carve/LaMa-ONNX/resolve/main/lama_fp32.onnx"
	},
	file: {
		name: "lama-fp32.onnx",
		bytes: 208044816
	},
	input: {
		size: 512,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image"
}, nt = {
	id: "ppocr-det-v4",
	name: "Text finder (PaddleOCR v4, compact)",
	task: "text-detect",
	summary: "Finds where printed text is on a picture (any colour, many languages including Japanese), so it can be filled in. Tiny and quick.",
	recommended: !0,
	license: {
		name: "Apache-2.0",
		commercialUse: "allowed",
		url: "https://huggingface.co/SWHL/RapidOCR"
	},
	sizeMb: 4.7,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/SWHL/RapidOCR",
		download: "https://huggingface.co/SWHL/RapidOCR/resolve/main/PP-OCRv4/ch_PP-OCRv4_det_infer.onnx"
	},
	file: {
		name: "ppocr-det-v4.onnx",
		bytes: 4745517
	},
	input: {
		size: 960,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "probability-map"
}, rt = {
	id: "ppocr-rec-v4",
	name: "Text reader (PaddleOCR v4, compact)",
	task: "text-read",
	summary: "Reads what printed text says (numbers, prices, English, Chinese, Japanese kana), so a shop's price sticker can be told apart from the box's own printing. Used together with the text finder.",
	recommended: !0,
	license: {
		name: "Apache-2.0",
		commercialUse: "allowed",
		url: "https://huggingface.co/SWHL/RapidOCR"
	},
	sizeMb: 10.9,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/SWHL/RapidOCR",
		download: "https://huggingface.co/SWHL/RapidOCR/resolve/main/PP-OCRv4/ch_PP-OCRv4_rec_infer.onnx"
	},
	file: {
		name: "ppocr-rec-v4.onnx",
		bytes: 10857958
	},
	input: {
		size: 48,
		mean: [
			.5,
			.5,
			.5
		],
		std: [
			.5,
			.5,
			.5
		]
	},
	output: "probability-map"
}, it = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realesr-general-x4",
	name: "Sharpen & enlarge (fast, small)",
	recommended: !1,
	summary: "Makes a picture 4 times larger and clearly sharper, adding believable fine detail. The small, quick one (about a quarter of a second for a face-sized area). Best first choice for photos of figures and boxes. In the benchmark it over-sharpened (1.13 times the original's edge detail) and lost some structure, so the x4plus model is the default.",
	sizeMb: 4.95,
	license: {
		name: "BSD-3-Clause (Real-ESRGAN)",
		commercialUse: "check",
		url: "https://github.com/xinntao/Real-ESRGAN/blob/master/LICENSE"
	},
	links: {
		modelCard: "https://huggingface.co/baker76/upscale-models",
		download: "https://huggingface.co/baker76/upscale-models/resolve/main/RealESR_General_x4.onnx"
	},
	file: {
		name: "realesr-general-x4.onnx",
		bytes: 4954907
	}
}, at = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realesrgan-anime-x4",
	name: "Sharpen & enlarge (illustrations)",
	recommended: !1,
	summary: "Tuned for drawn art: very clean lines and flat colour, but it smooths skin and plastic texture, so it suits flat box illustrations more than photos of figures.",
	sizeMb: 18.7,
	license: {
		name: "BSD-3-Clause (Real-ESRGAN)",
		commercialUse: "check",
		url: "https://github.com/xinntao/Real-ESRGAN/blob/master/LICENSE"
	},
	links: {
		modelCard: "https://huggingface.co/baker76/upscale-models",
		download: "https://huggingface.co/baker76/upscale-models/resolve/main/RealESRGAN_anime_x4.onnx"
	},
	file: {
		name: "realesrgan-anime-x4.onnx",
		bytes: 18688425
	}
}, ot = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realesrgan-x4plus",
	name: "Sharpen & enlarge (best photo quality)",
	recommended: !1,
	summary: "Sharpens and enlarges 4x with the larger photo model. On a benchmark (half-size, compressed crops restored and compared with the originals) it was the most faithful and best balanced of the Real-ESRGAN models: highest SSIM and sharpness closest to the original. Slower (a few seconds for a face-sized area).",
	sizeMb: 69.9,
	license: {
		name: "BSD-3-Clause (Real-ESRGAN)",
		commercialUse: "check",
		url: "https://github.com/xinntao/Real-ESRGAN/blob/master/LICENSE"
	},
	links: {
		modelCard: "https://huggingface.co/baker76/upscale-models",
		download: "https://huggingface.co/baker76/upscale-models/resolve/main/RealESRGAN_x4plus.onnx"
	},
	file: {
		name: "realesrgan-x4plus.onnx",
		bytes: 69879921
	}
}, st = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realplksr-x4",
	name: "Photo restore 4x (RealPLKSR, small and fast)",
	recommended: !0,
	summary: "A small 4x restoration model from darktable (MIT), trained for photographs. Best of every enlarging method on ten real product photos (bench/enlarge): sharper and truer than Real-ESRGAN, and it keeps printed text readable.",
	sizeMb: 29.7,
	license: {
		name: "MIT (darktable RealPLKSR)",
		commercialUse: "yes",
		url: "https://huggingface.co/darktable-org/upscale-realplksr-onnx"
	},
	links: {
		modelCard: "https://huggingface.co/darktable-org/upscale-realplksr-onnx",
		download: "https://huggingface.co/darktable-org/upscale-realplksr-onnx/resolve/main/onnx/model_x4.onnx"
	},
	file: {
		name: "realplksr-x4.onnx",
		bytes: 29711010
	}
}, ct = {
	id: "sdxl-inpaint",
	name: "Redraw (Stable Diffusion XL inpainting)",
	task: "redraw",
	summary: "Redraws part of a picture with a believable continuation: a missing antenna, an edge that was cut off. Runs on this computer's GPU (about 30 seconds). It invents what it draws, so use it where the picture really is missing a part.",
	recommended: !0,
	license: {
		name: "OpenRAIL++-M (commercial use of the pictures is allowed; see the licence for its use restrictions)",
		commercialUse: "check",
		url: "https://huggingface.co/diffusers/stable-diffusion-xl-1.0-inpainting-0.1"
	},
	sizeMb: 6940,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/diffusers/stable-diffusion-xl-1.0-inpainting-0.1",
		download: "https://huggingface.co/diffusers/stable-diffusion-xl-1.0-inpainting-0.1"
	},
	file: {
		name: "sdxl-inpaint/unet/diffusion_pytorch_model.fp16.safetensors",
		bytes: 5135178560
	},
	input: {
		size: 1024,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image"
}, lt = {
	id: "sdxl-tile",
	name: "Sharpen with detail (SDXL tile ControlNet)",
	task: "enhance",
	summary: "Makes a picture crisper and cleaner while every shape stays where it was: hair strands, fabric folds, edges. The original colours are kept. Runs on this computer's GPU (about half a minute to a minute for a 1024 pixel picture once the models are loaded). Works together with the redraw model.",
	recommended: !0,
	license: {
		name: "Apache-2.0 (used with SDXL, OpenRAIL++-M)",
		commercialUse: "allowed",
		url: "https://huggingface.co/xinsir/controlnet-tile-sdxl-1.0"
	},
	sizeMb: 2502,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/xinsir/controlnet-tile-sdxl-1.0",
		download: "https://huggingface.co/xinsir/controlnet-tile-sdxl-1.0"
	},
	file: {
		name: "sdxl-tile/diffusion_pytorch_model.safetensors",
		bytes: 2502139104
	},
	input: {
		size: 1024,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image"
}, ut = (e) => {
	let t = e;
	return !!t && typeof t.id == "string" && /^[a-z0-9][a-z0-9-]*$/.test(t.id) && typeof t.name == "string" && (t.task === "cutout" || t.task === "inpaint" || t.task === "text-detect" || t.task === "text-read" || t.task === "upscale" || t.task === "redraw" || t.task === "enhance") && typeof t.file?.name == "string" && typeof t.links?.download == "string" && typeof t.input?.size == "number";
};
function dt(e) {
	return [...e].filter(ut).sort((e, t) => Number(t.recommended) - Number(e.recommended) || e.name.localeCompare(t.name));
}
function ft(e) {
	return {
		MODELS: e,
		findModel: (t) => e.find((e) => e.id === t),
		modelsFor: (t) => e.filter((e) => e.task === t)
	};
}
var { MODELS: pt, findModel: mt, modelsFor: ht } = ft(dt(Object.values(/* @__PURE__ */ Object.assign({
	"../registry/birefnet-general-fp16.json": $e,
	"../registry/birefnet-lite-fp16.json": H,
	"../registry/birefnet-lite.json": et,
	"../registry/lama-fp32.json": tt,
	"../registry/ppocr-det-v4.json": nt,
	"../registry/ppocr-rec-v4.json": rt,
	"../registry/realesr-general-x4.json": it,
	"../registry/realesrgan-anime-x4.json": at,
	"../registry/realesrgan-x4plus.json": ot,
	"../registry/realplksr-x4.json": st,
	"../registry/sdxl-inpaint.json": ct,
	"../registry/sdxl-tile.json": lt
})))), gt = {
	strength: .5,
	control: .6,
	guidance: 6,
	keepColour: !1,
	seed: 7,
	prompt: "professional studio product photograph of a collectible, clean even soft lighting, glossy finish, crisp detail, true to the original colours, e-commerce pack shot",
	negativePrompt: "blurry, low quality, noise, artifacts, deformed, extra parts, changed design, text, watermark, logo"
}, U = class extends Error {
	status;
	constructor(e, t) {
		super(t), this.status = e;
	}
}, _t = "http://127.0.0.1:47321", W = {
	start: "npm run local:start",
	token: "npm run local:token",
	models: "npm run models",
	redrawSetup: "npm run redraw:setup",
	install: (e) => e && e !== "birefnet-lite-fp16" ? `npm run models:install -- ${e}` : "npm run models:install"
}, vt = class {
	options;
	base;
	doFetch;
	constructor(e = {}) {
		this.options = e, this.base = (e.url ?? "http://127.0.0.1:47321").replace(/\/$/, "");
		let t = e.fetch;
		this.doFetch = (e, n) => (t ?? fetch)(e, n);
	}
	headers(e = {}) {
		return this.options.token ? {
			Authorization: `Bearer ${this.options.token}`,
			...e
		} : e;
	}
	async probe() {
		if (await this.health()) return "ok";
		try {
			return await this.doFetch(`${this.base}/health`, {
				mode: "no-cors",
				signal: AbortSignal.timeout(2500)
			}), "blocked";
		} catch {
			return "offline";
		}
	}
	async health() {
		try {
			let e = await this.doFetch(`${this.base}/health`, { signal: AbortSignal.timeout(2500) });
			if (!e.ok) return null;
			let t = await e.json();
			return t.app === "gleamshelf-local" ? t : null;
		} catch {
			return null;
		}
	}
	async inpaint(e, t, n) {
		let r = await this.doFetch(`${this.base}/inpaint?model=${encodeURIComponent(t)}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "image/png" }),
			body: e,
			signal: n
		});
		if (!r.ok) throw new U(r.status, await yt(r));
		return new Blob([await r.arrayBuffer()], { type: "image/png" });
	}
	async upscale(e, t, n) {
		let r = await this.doFetch(`${this.base}/upscale?model=${encodeURIComponent(t)}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!r.ok) throw new U(r.status, await yt(r));
		return new Blob([await r.arrayBuffer()], { type: "image/png" });
	}
	async redraw(e, t, n) {
		let r = new URLSearchParams({ prompt: t.prompt });
		t.stacked && r.set("stacked", "true"), t.box && r.set("box", t.box.join(",")), t.negative && r.set("negative", t.negative);
		for (let e of [
			"strength",
			"steps",
			"guidance",
			"candidates",
			"seed"
		]) t[e] !== void 0 && r.set(e, String(t[e]));
		let i = await this.doFetch(`${this.base}/redraw?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "image/png" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new U(i.status, await yt(i));
		return new Blob([await i.arrayBuffer()], { type: "image/png" });
	}
	async enhance(e, t = {}, n) {
		let r = new URLSearchParams();
		t.prompt && r.set("prompt", t.prompt), t.negativePrompt && r.set("negativePrompt", t.negativePrompt);
		for (let e of [
			"strength",
			"seed",
			"control",
			"guidance"
		]) t[e] !== void 0 && r.set(e, String(t[e]));
		t.keepColour === !1 && r.set("keepColour", "false");
		let i = await this.doFetch(`${this.base}/enhance?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "image/png" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new U(i.status, await yt(i));
		return new Blob([await i.arrayBuffer()], { type: "image/png" });
	}
	gloss(e, t) {
		return this.enhance(e, gt, t);
	}
	async readText(e, t) {
		let n = await this.doFetch(`${this.base}/read-text`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: t
		});
		if (!n.ok) throw new U(n.status, await yt(n));
		return (await n.json()).boxes;
	}
	async detectText(e, t, n) {
		let r = await this.doFetch(`${this.base}/detect-text?model=${encodeURIComponent(t)}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!r.ok) throw new U(r.status, await yt(r));
		return (await r.json()).boxes;
	}
	async startProcess(e, t = {}, n) {
		let r = new URLSearchParams();
		t.mode && r.set("mode", t.mode), t.vivid !== void 0 && r.set("vivid", String(t.vivid));
		for (let e of [
			"find",
			"listing",
			"enlarge",
			"stickers",
			"lettering",
			"thinParts",
			"colour",
			"look",
			"gloss",
			"review"
		]) t[e] !== void 0 && r.set(e, t[e] ? "1" : "0");
		let i = await this.doFetch(`${this.base}/process?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new U(i.status, await yt(i));
		return (await i.json()).id;
	}
	async processStatus(e, t) {
		let n = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}`, {
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new U(n.status, await yt(n));
		return await n.json();
	}
	async foundPicture(e, t, n) {
		let r = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/found/${t}.jpg`, {
			headers: this.headers(),
			signal: n
		});
		if (!r.ok) throw new U(r.status, await yt(r));
		return new Blob([await r.arrayBuffer()], { type: "image/jpeg" });
	}
	async chooseReferences(e, t, n) {
		let r = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/choose`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify({ use: t }),
			signal: n
		});
		if (!r.ok) throw new U(r.status, await yt(r));
	}
	async cancelProcess(e, t) {
		let n = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/cancel`, {
			method: "POST",
			headers: this.headers(),
			signal: t
		});
		if (!n.ok && n.status !== 404) throw new U(n.status, await yt(n));
	}
	async processPicture(e, t = "cutout", n) {
		let r = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/${t === "cutout" ? "cutout.png" : "studio.jpg"}`, {
			headers: this.headers(),
			signal: n
		});
		if (!r.ok) throw new U(r.status, await yt(r));
		return new Blob([await r.arrayBuffer()], { type: t === "cutout" ? "image/png" : "image/jpeg" });
	}
	async models() {
		let e = await this.doFetch(`${this.base}/models`, { headers: this.headers() });
		if (!e.ok) throw new U(e.status, await yt(e));
		return (await e.json()).models;
	}
	async cutout(e, t, n, r = {}) {
		let i = await this.doFetch(`${this.base}/cutout?model=${encodeURIComponent(t)}${r.thinParts ? "&refine=thin" : ""}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new U(i.status, await yt(i));
		let a = Number(i.headers.get("X-Mask-Width")), o = Number(i.headers.get("X-Mask-Height")), s = new Uint8Array(await i.arrayBuffer());
		if (!(a > 0 && o > 0) || s.length !== a * o) throw new U(502, "The companion app sent a mask in a format this editor does not understand.");
		return {
			alpha: s,
			width: a,
			height: o,
			...i.headers.get("X-Mask-Parts") === "kept" ? { partsKept: !0 } : {}
		};
	}
};
async function yt(e) {
	let t = await e.json().catch(() => null);
	return e.status === 401 ? "The companion app did not accept the pairing token. Copy it again from the app and paste it in." : t?.error ?? `The companion app answered ${e.status}.`;
}
//#endregion
//#region src/useLocalApp.ts
var bt = "gleamshelf:local-app";
function xt() {
	try {
		let e = JSON.parse(localStorage.getItem(bt) ?? "{}");
		return {
			url: typeof e.url == "string" ? e.url : _t,
			token: typeof e.token == "string" ? e.token : ""
		};
	} catch {
		return {
			url: _t,
			token: ""
		};
	}
}
function G(e) {
	try {
		localStorage.setItem(bt, JSON.stringify(e));
	} catch {}
}
function St(e) {
	let [t, n] = M(() => ({
		...xt(),
		...e?.url ? { url: e.url } : {},
		...e?.token ? { token: e.token } : {}
	})), [r, i] = M("checking"), [a, o] = M(null), [s, c] = M(null), [l, u] = M([]), d = ye(() => new vt({
		url: t.url,
		token: t.token
	}), [t]), f = k(async () => {
		c(null);
		let e = await d.probe();
		if (e === "ok" && u((await d.health())?.features ?? []), e !== "ok") i(e === "blocked" ? "blocked" : "offline"), o(null);
		else if (!t.token) i("needs-token"), o(null);
		else try {
			o(await d.models()), i("ready");
		} catch (e) {
			o(null), c(e instanceof Error ? e.message : "The companion app did not answer."), e instanceof U && e.status === 401 ? (n((e) => ({
				...e,
				token: ""
			})), i("needs-token")) : i("offline");
		}
	}, [d, t.token]);
	return A(() => {
		f();
	}, [f]), A(() => {
		if (r !== "offline" && r !== "blocked") return;
		let e = setInterval(() => void f(), 3e3);
		return () => clearInterval(e);
	}, [r, f]), {
		state: r,
		saved: t,
		client: d,
		models: a,
		installed: (e) => a?.filter((t) => t.task === e && t.installed) ?? [],
		problem: s,
		setProblem: c,
		check: f,
		connect: (e) => {
			let r = {
				...t,
				token: e.trim()
			};
			G(r), n(r);
		},
		canProcess: l.includes("process")
	};
}
//#endregion
//#region src/AiCutout.tsx
function Ct({ app: e, what: t }) {
	let [n, r] = M("");
	return e.state === "checking" ? /* @__PURE__ */ P("p", {
		className: "gs-hint",
		children: "Looking for the Gleamshelf app on this computer…"
	}) : e.state === "blocked" ? /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ F("p", {
		className: "gs-error",
		children: [
			"The Gleamshelf app is running at ",
			e.saved.url,
			", but this browser will not let the page talk to it. Safari does this. Open the editor in Chrome or Edge, or serve it from ",
			/* @__PURE__ */ P("code", { children: "http://localhost" }),
			"."
		]
	}), /* @__PURE__ */ P("button", {
		type: "button",
		className: "gs-button",
		onClick: () => void e.check(),
		children: "Check again"
	})] }) : e.state === "offline" ? /* @__PURE__ */ F(N, { children: [
		/* @__PURE__ */ F("p", {
			className: "gs-hint",
			children: [
				t.intro,
				" It needs the small Gleamshelf app running on this computer (your photos never leave it). Nothing answered at",
				" ",
				/* @__PURE__ */ P("code", { children: e.saved.url }),
				". This page keeps looking, so it will notice as soon as the app starts."
			]
		}),
		/* @__PURE__ */ F("ol", {
			className: "gs-steps",
			children: [/* @__PURE__ */ F("li", { children: [
				"Open a terminal in the Gleamshelf folder and run ",
				/* @__PURE__ */ P("code", { children: W.start }),
				". ",
				/* @__PURE__ */ P("strong", { children: "Leave it running" }),
				" while you edit."
			] }), /* @__PURE__ */ F("li", { children: [
				"Once, if you have not yet: ",
				/* @__PURE__ */ P("code", { children: t.install }),
				" (it says \"Already installed\" when the model is there; that is fine, the app still has to be started)."
			] })]
		}),
		/* @__PURE__ */ P("button", {
			type: "button",
			className: "gs-button",
			onClick: () => void e.check(),
			children: "Check now"
		})
	] }) : e.state === "needs-token" ? /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ F("p", {
		className: "gs-hint",
		children: [
			"The app is running. Paste its pairing token to connect. The token is a 32-character code. It is printed when you start the app, and again by ",
			/* @__PURE__ */ P("code", { children: W.token }),
			" (it is the last line of the output)."
		]
	}), /* @__PURE__ */ F("div", {
		className: "gs-crop-tools",
		children: [/* @__PURE__ */ P("input", {
			type: "password",
			className: "gs-input",
			"aria-label": "Pairing token",
			placeholder: "Pairing token",
			value: n,
			onChange: (e) => r(e.target.value)
		}), /* @__PURE__ */ P("button", {
			type: "button",
			className: "gs-button",
			disabled: !n.trim(),
			onClick: () => {
				e.connect(n), r("");
			},
			children: "Connect"
		})]
	})] }) : null;
}
function wt({ getPhoto: e, onMask: t, greenBackdrop: n, app: r }) {
	let [i, a] = M(""), [o, s] = M(!1), [c, l] = M("product"), u = ht("cutout"), d = r.installed("cutout"), f = i && d.some((e) => e.id === i) ? i : d[0]?.id ?? "", p = mt(f), m = async () => {
		s(!0), r.setProblem(null);
		try {
			t(f, await r.client.cutout(await e(c), f, void 0, { thinParts: c === "character" }), c);
		} catch (e) {
			r.setProblem(e instanceof Error ? e.message : "The cut-out did not work.");
		} finally {
			s(!1);
		}
	};
	return /* @__PURE__ */ F("div", {
		className: "gs-ai",
		children: [
			/* @__PURE__ */ F("div", {
				className: "gs-ai__title",
				children: [/* @__PURE__ */ P("strong", { children: "AI cut-out" }), /* @__PURE__ */ P("span", {
					className: "gs-badge gs-badge--free",
					title: "The model runs on your computer. Nothing is sent anywhere and nothing is charged.",
					children: "free · on your computer"
				})]
			}),
			/* @__PURE__ */ P(ie, { id: "aiCutout" }),
			/* @__PURE__ */ P(Ct, {
				app: r,
				what: {
					intro: "Works for any background, not just green.",
					install: W.install(u.find((e) => e.recommended)?.id)
				}
			}),
			r.state === "ready" && /* @__PURE__ */ F(N, { children: [d.length === 0 ? /* @__PURE__ */ F("p", {
				className: "gs-hint",
				children: [
					"No cut-out model is installed yet. Run ",
					/* @__PURE__ */ P("code", { children: W.install(u.find((e) => e.recommended)?.id) }),
					", then",
					" ",
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-link",
						onClick: () => void r.check(),
						children: "check again"
					}),
					"."
				]
			}) : /* @__PURE__ */ F(N, { children: [
				/* @__PURE__ */ F("label", {
					className: "gs-control",
					children: [/* @__PURE__ */ P("span", {
						className: "gs-control__row",
						children: /* @__PURE__ */ P("span", { children: "Model" })
					}), /* @__PURE__ */ P("select", {
						value: f,
						onChange: (e) => a(e.target.value),
						children: d.map((e) => /* @__PURE__ */ P("option", {
							value: e.id,
							children: e.name
						}, e.id))
					})]
				}),
				/* @__PURE__ */ F("div", {
					className: "gs-segmented",
					role: "group",
					"aria-label": "What to cut out",
					children: [/* @__PURE__ */ P("button", {
						type: "button",
						className: `gs-button ${c === "product" ? "is-active" : ""}`,
						"aria-pressed": c === "product",
						onClick: () => l("product"),
						title: "The whole box or product, without its background",
						children: "Whole product"
					}), /* @__PURE__ */ P("button", {
						type: "button",
						className: `gs-button ${c === "character" ? "is-active" : ""}`,
						"aria-pressed": c === "character",
						onClick: () => l("character"),
						title: "Only the character in the artwork on a box cover",
						children: "Character on cover"
					})]
				}),
				c === "product" && n && /* @__PURE__ */ F("p", {
					className: "gs-hint",
					children: [
						/* @__PURE__ */ P("strong", { children: "This photo has a green backdrop." }),
						" The free ",
						/* @__PURE__ */ P("em", { children: "Remove green backdrop" }),
						" button above does the same job instantly, so AI is not needed here. AI is for photos on any other background, or for picking out the character on a box cover."
					]
				}),
				c === "character" && /* @__PURE__ */ F("p", {
					className: "gs-hint",
					children: [
						"Use ",
						/* @__PURE__ */ P("strong", { children: "Crop" }),
						" first to frame just the artwork (leave out the logos, price tags and title text), then cut out. The character is found inside the crop. Printed words that cross the character stay with it; remove them with",
						" ",
						/* @__PURE__ */ P("strong", { children: "Printed lettering" }),
						" in the Clean up tab."
					]
				}),
				p && /* @__PURE__ */ F("p", {
					className: "gs-hint",
					children: [
						p.summary,
						" ",
						/* @__PURE__ */ P("a", {
							href: p.links.modelCard,
							target: "_blank",
							rel: "noreferrer",
							children: "About this model"
						}),
						" ",
						"· ",
						p.license.name,
						" licence, commercial use ",
						p.license.commercialUse
					]
				}),
				/* @__PURE__ */ P("button", {
					type: "button",
					className: "gs-button gs-button--primary",
					disabled: o || !f,
					onClick: () => void m(),
					children: o ? c === "character" ? "Working… also looking for thin parts, about 30 seconds" : "Working… the first run loads the model" : c === "character" ? "Cut out the character" : "Cut out with AI"
				})
			] }), u.some((e) => !r.models?.find((t) => t.id === e.id)?.installed) && /* @__PURE__ */ F("details", {
				className: "gs-hint",
				children: [/* @__PURE__ */ P("summary", { children: "More models" }), /* @__PURE__ */ P("ul", {
					className: "gs-models",
					children: u.filter((e) => !r.models?.find((t) => t.id === e.id)?.installed).map((e) => /* @__PURE__ */ F("li", { children: [
						/* @__PURE__ */ P("strong", { children: e.name }),
						" · ",
						e.sizeMb,
						" MB · ",
						e.license.name,
						/* @__PURE__ */ P("br", {}),
						e.summary,
						" ",
						/* @__PURE__ */ P("a", {
							href: e.links.modelCard,
							target: "_blank",
							rel: "noreferrer",
							children: "Read about it"
						}),
						/* @__PURE__ */ P("br", {}),
						/* @__PURE__ */ P("code", { children: W.install(e.id) })
					] }, e.id))
				})]
			})] }),
			r.problem && /* @__PURE__ */ P("p", {
				className: "gs-error",
				children: r.problem
			})
		]
	});
}
//#endregion
//#region src/AiEnlarge.tsx
function Tt({ getPicture: e, onEnlarged: t, onRemove: n, applied: r, app: i, sharpen: a }) {
	let [o, s] = M(!1), [c, l] = M(!1), [u, d] = M(""), f = ht("upscale"), p = i.installed("upscale"), m = u && p.some((e) => e.id === u) ? u : p[0]?.id ?? "", h = mt(m), g = f.find((e) => e.recommended), _ = async () => {
		s(!0), i.setProblem(null);
		try {
			let n = await e();
			c && a && (n = await a(n)), t(m, await i.client.upscale(n, m));
		} catch (e) {
			i.setProblem(e instanceof Error ? e.message : "The enlarging did not work.");
		} finally {
			s(!1);
		}
	};
	return /* @__PURE__ */ F("div", {
		className: "gs-ai",
		children: [
			/* @__PURE__ */ F("div", {
				className: "gs-ai__title",
				children: [/* @__PURE__ */ P("strong", { children: "Sharpen & enlarge" }), /* @__PURE__ */ P("span", {
					className: "gs-badge gs-badge--free",
					title: "The model runs on your computer. Nothing is sent anywhere and nothing is charged.",
					children: "free · on your computer"
				})]
			}),
			/* @__PURE__ */ P(ie, { id: "enlarge" }),
			/* @__PURE__ */ P(Ct, {
				app: i,
				what: {
					intro: "Rebuilds fine detail so the picture is clearly sharper and can be saved larger.",
					install: W.install(g?.id)
				}
			}),
			i.state === "ready" && (p.length === 0 ? /* @__PURE__ */ F("p", {
				className: "gs-hint",
				children: [
					"No enlarging model is installed yet. Run ",
					/* @__PURE__ */ P("code", { children: W.install(g?.id) }),
					" (",
					g?.sizeMb,
					" MB), then",
					" ",
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-link",
						onClick: () => void i.check(),
						children: "check again"
					}),
					"."
				]
			}) : /* @__PURE__ */ F(N, { children: [
				/* @__PURE__ */ F("label", {
					className: "gs-control",
					children: [/* @__PURE__ */ P("span", {
						className: "gs-control__row",
						children: /* @__PURE__ */ P("span", { children: "Model" })
					}), /* @__PURE__ */ P("select", {
						value: m,
						onChange: (e) => d(e.target.value),
						children: p.map((e) => /* @__PURE__ */ P("option", {
							value: e.id,
							children: e.name
						}, e.id))
					})]
				}),
				h && /* @__PURE__ */ F("p", {
					className: "gs-hint",
					children: [
						h.summary,
						" ",
						/* @__PURE__ */ P("a", {
							href: h.links.modelCard,
							target: "_blank",
							rel: "noreferrer",
							children: "About this model"
						}),
						" ",
						"· ",
						h.license.name,
						"; check it allows your use. It adds believable detail that was not in the photo."
					]
				}),
				a && /* @__PURE__ */ F("label", {
					className: "gs-control gs-control--inline",
					title: "Re-draws the picture slightly with Stable Diffusion, pinned to the original shapes, so hair, fabric and edges come back crisper. Colours are kept. Free, on your computer.",
					children: [/* @__PURE__ */ P("input", {
						type: "checkbox",
						checked: c,
						onChange: (e) => l(e.target.checked)
					}), "Add detail first (slower, about a minute). Not for a box with small print: it redraws small text as gibberish."]
				}),
				/* @__PURE__ */ F("div", {
					className: "gs-crop-tools",
					children: [/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-button gs-button--primary",
						disabled: o || !m,
						onClick: () => void _(),
						children: o ? c && a ? "Sharpening… about a minute" : "Enlarging… a few seconds" : r ? "Enlarge again" : "Sharpen & enlarge"
					}), r && /* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-button",
						onClick: n,
						children: "Remove"
					})]
				}),
				r && /* @__PURE__ */ F("p", {
					className: "gs-hint",
					children: [
						"Applied: the saved picture is ",
						r.factor,
						" times larger than the original photo. Do the lettering first: changing it later removes this."
					]
				})
			] })),
			i.problem && /* @__PURE__ */ P("p", {
				className: "gs-error",
				children: i.problem
			})
		]
	});
}
//#endregion
//#region src/PickOverlay.tsx
function Et({ editor: e, width: t, height: n, onPick: r }) {
	return /* @__PURE__ */ P("div", {
		className: "gs-pick",
		style: {
			width: t,
			height: n
		},
		onPointerDown: (t) => {
			t.preventDefault();
			let n = t.currentTarget.getBoundingClientRect(), [i, a] = v(h(e.document), (t.clientX - n.left) / n.width, (t.clientY - n.top) / n.height);
			r(Math.min(1, Math.max(0, i)), Math.min(1, Math.max(0, a)));
		}
	});
}
//#endregion
//#region src/AiFill.tsx
function Dt({ buildInput: e, onFilled: t, applied: n, app: r, busyOutside: i }) {
	let [a, o] = M(!1), s = a || !!i, [c, l] = M(!0), u = ht("inpaint"), d = ht("text-detect"), f = r.installed("inpaint")[0], p = r.installed("text-detect")[0], m = mt(f?.id ?? u[0]?.id ?? ""), h = u.find((e) => e.recommended), g = async () => {
		if (f) {
			o(!0), r.setProblem(null);
			try {
				let n = await e({
					otherText: c && !!p,
					textModel: p?.id,
					client: r.client
				});
				n ? t(f.id, await r.client.inpaint(n.picture, f.id), n.cutAway) : r.setProblem("Nothing to fill: no lettering or printed text was found. Try a lower \"How white\" above.");
			} catch (e) {
				r.setProblem(e instanceof Error ? e.message : "The fill did not work.");
			} finally {
				o(!1);
			}
		}
	};
	return /* @__PURE__ */ F("div", {
		className: "gs-ai",
		children: [
			/* @__PURE__ */ F("div", {
				className: "gs-ai__title",
				children: [/* @__PURE__ */ P("strong", { children: "AI fill" }), /* @__PURE__ */ P("span", {
					className: "gs-badge gs-badge--free",
					title: "The model runs on your computer. Nothing is sent anywhere and nothing is charged.",
					children: "free · on your computer"
				})]
			}),
			/* @__PURE__ */ P(ie, { id: "aiFill" }),
			/* @__PURE__ */ P(Ct, {
				app: r,
				what: {
					intro: "A cleaner fill than the free one: it repaints hair, fabric and skin where the words were.",
					install: W.install(h?.id)
				}
			}),
			r.state === "ready" && /* @__PURE__ */ P(N, { children: f ? /* @__PURE__ */ F(N, { children: [
				/* @__PURE__ */ F("p", {
					className: "gs-hint",
					children: [
						m?.summary,
						" ",
						/* @__PURE__ */ P("a", {
							href: m?.links.modelCard,
							target: "_blank",
							rel: "noreferrer",
							children: "About this model"
						}),
						" ",
						"· ",
						m?.license.name,
						" licence. It invents the part hidden under the words, so look closely at the result."
					]
				}),
				/* @__PURE__ */ F("label", {
					className: "gs-control gs-control--inline",
					title: p ? "Finds other printed text (any colour) and fills it in too" : `Needs the text finder: ${W.install(d[0]?.id)}`,
					children: [
						/* @__PURE__ */ P("input", {
							type: "checkbox",
							checked: c && !!p,
							disabled: !p,
							onChange: (e) => l(e.target.checked)
						}),
						"Also fill other printed text",
						p ? "" : " (needs the text finder)"
					]
				}),
				!p && d[0] && /* @__PURE__ */ F("p", {
					className: "gs-hint",
					children: [
						"Text finder: ",
						d[0].name,
						", ",
						d[0].sizeMb,
						" MB, ",
						d[0].license.name,
						".",
						" ",
						/* @__PURE__ */ P("code", { children: W.install(d[0].id) })
					]
				}),
				/* @__PURE__ */ P("button", {
					type: "button",
					className: "gs-button gs-button--primary",
					disabled: s,
					onClick: () => void g(),
					children: s ? "Filling… a few seconds" : n ? "Fill again with AI" : "Fill with AI"
				})
			] }) : /* @__PURE__ */ F("p", {
				className: "gs-hint",
				children: [
					"No fill model is installed yet (",
					m ? `${m.name}, ${m.sizeMb} MB, ${m.license.name}` : "LaMa",
					"). Run",
					" ",
					/* @__PURE__ */ P("code", { children: W.install(h?.id) }),
					", then",
					" ",
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-link",
						onClick: () => void r.check(),
						children: "check again"
					}),
					"."
				]
			}) }),
			r.problem && /* @__PURE__ */ P("p", {
				className: "gs-error",
				children: r.problem
			})
		]
	});
}
//#endregion
//#region src/AiFinish.tsx
function Ot({ app: e, applied: t, onRedrawArea: n, onCancelArea: r, picking: i, onRemove: a, note: o, busyOutside: s }) {
	let [c, l] = M(!1), u = c || s, [d, f] = M(""), [p, m] = M(!0), h = e.state === "ready" && e.installed("redraw").length > 0;
	return /* @__PURE__ */ F("div", {
		className: "gs-ai",
		children: [
			/* @__PURE__ */ F("div", {
				className: "gs-ai__title",
				children: [/* @__PURE__ */ P("strong", { children: "Finishing touches (AI redraw)" }), /* @__PURE__ */ P("span", {
					className: "gs-badge gs-badge--free",
					title: "The model runs on your computer. Nothing is sent anywhere and nothing is charged.",
					children: "free · on your computer · about 30 s"
				})]
			}),
			/* @__PURE__ */ P(ie, { id: "finish" }),
			/* @__PURE__ */ P(Ct, {
				app: e,
				what: {
					intro: "Redraws an area you choose, for a part the photo cuts off or something the fill missed. Nothing is invented elsewhere.",
					install: W.redrawSetup
				}
			}),
			e.state === "ready" && !h && /* @__PURE__ */ F("p", {
				className: "gs-hint",
				children: [
					"The redraw model is not set up yet. Run ",
					/* @__PURE__ */ P("code", { children: W.redrawSetup }),
					" once (about 7 GB; it asks first), then",
					" ",
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-link",
						onClick: () => void e.check(),
						children: "check again"
					}),
					"."
				]
			}),
			h && /* @__PURE__ */ F(N, { children: [
				/* @__PURE__ */ F("label", {
					className: "gs-control",
					children: [/* @__PURE__ */ P("span", {
						className: "gs-control__row",
						children: /* @__PURE__ */ P("span", { children: "Redraw an area as…" })
					}), /* @__PURE__ */ P("input", {
						className: "gs-input",
						value: d,
						maxLength: 400,
						placeholder: "e.g. smooth blue plastic hair",
						onChange: (e) => f(e.target.value)
					})]
				}),
				/* @__PURE__ */ F("label", {
					className: "gs-control gs-control--inline",
					children: [/* @__PURE__ */ P("input", {
						type: "checkbox",
						checked: p,
						onChange: (e) => m(e.target.checked)
					}), "Keep what is there as a guide (less change)"]
				}),
				/* @__PURE__ */ F("div", {
					className: "gs-crop-tools",
					children: [/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-button",
						disabled: u || t || !d.trim(),
						onClick: () => i ? r() : n(d.trim(), p),
						children: i ? "Cancel" : "Choose the area…"
					}), t && /* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-button",
						disabled: u,
						onClick: a,
						children: "Remove"
					})]
				}),
				t && /* @__PURE__ */ P("p", {
					className: "gs-hint",
					children: "Applied. This is the last step: changing anything else in the editor takes it off (Undo brings it back)."
				}),
				/* @__PURE__ */ P("p", {
					className: "gs-hint",
					children: "The model draws new pixels, so it can differ from the real item. Check the result before listing, and do not use it where a buyer needs to see the actual condition."
				})
			] }),
			o && /* @__PURE__ */ P("p", {
				className: "gs-hint",
				children: o
			}),
			e.problem && /* @__PURE__ */ P("p", {
				className: "gs-error",
				children: e.problem
			})
		]
	});
}
//#endregion
//#region src/AreaOverlay.tsx
function kt({ width: e, height: t, onArea: n }) {
	let r = j(null), [i, a] = M(null), o = (e) => {
		let t = e.currentTarget.getBoundingClientRect();
		return {
			x: Math.min(1, Math.max(0, (e.clientX - t.left) / t.width)),
			y: Math.min(1, Math.max(0, (e.clientY - t.top) / t.height))
		};
	}, s = (e, t) => ({
		x: Math.min(e.x, t.x),
		y: Math.min(e.y, t.y),
		width: Math.abs(e.x - t.x),
		height: Math.abs(e.y - t.y)
	});
	return /* @__PURE__ */ P("div", {
		className: "gs-pick",
		style: {
			width: e,
			height: t
		},
		onPointerDown: (e) => {
			e.preventDefault(), e.currentTarget.setPointerCapture(e.pointerId), r.current = o(e), a(null);
		},
		onPointerMove: (e) => r.current && a(s(r.current, o(e))),
		onPointerUp: (e) => {
			if (!r.current) return;
			let t = s(r.current, o(e));
			r.current = null, a(null), t.width > .02 && t.height > .02 && n([
				t.x,
				t.y,
				t.width,
				t.height
			]);
		},
		children: i && /* @__PURE__ */ P("div", {
			className: "gs-area",
			style: {
				left: `${i.x * 100}%`,
				top: `${i.y * 100}%`,
				width: `${i.width * 100}%`,
				height: `${i.height * 100}%`
			}
		})
	});
}
//#endregion
//#region ../canvas/src/document.ts
var At = [
	{
		id: "normal",
		label: "Normal"
	},
	{
		id: "multiply",
		label: "Multiply (darker)"
	},
	{
		id: "darken",
		label: "Keep darker"
	},
	{
		id: "color-burn",
		label: "Burn"
	},
	{
		id: "screen",
		label: "Screen (lighter)"
	},
	{
		id: "lighten",
		label: "Keep lighter"
	},
	{
		id: "color-dodge",
		label: "Dodge"
	},
	{
		id: "overlay",
		label: "Overlay"
	},
	{
		id: "soft-light",
		label: "Soft light"
	},
	{
		id: "hard-light",
		label: "Hard light"
	},
	{
		id: "difference",
		label: "Difference"
	},
	{
		id: "exclusion",
		label: "Exclusion"
	},
	{
		id: "hue",
		label: "Hue only"
	},
	{
		id: "saturation",
		label: "Saturation only"
	},
	{
		id: "color",
		label: "Colour only"
	},
	{
		id: "luminosity",
		label: "Brightness only"
	}
], jt = {
	x: 0,
	y: 0,
	scaleX: 1,
	scaleY: 1,
	rotation: 0
}, Mt = 0, Nt = (e) => `${e}-${Date.now().toString(36)}-${(Mt++).toString(36)}`, Pt = (e, t) => ({
	width: e,
	height: t,
	data: new Uint8ClampedArray(e * t * 4)
}), Ft = (e) => ({
	width: e.width,
	height: e.height,
	data: new Uint8ClampedArray(e.data)
}), It = class {
	map = /* @__PURE__ */ new Map();
	get(e) {
		return this.map.get(e);
	}
	add(e, t = "px") {
		let n = Nt(t);
		return this.map.set(n, e), n;
	}
	set(e, t) {
		this.map.set(e, t);
	}
	get size() {
		return this.map.size;
	}
	keepOnly(e) {
		let t = /* @__PURE__ */ new Set();
		for (let n of e) for (let e of Lt(n)) t.add(e);
		for (let e of [...this.map.keys()]) t.has(e) || this.map.delete(e);
	}
};
function Lt(e) {
	let t = [];
	for (let n of e.layers) n.kind === "raster" && t.push(n.pixels), n.mask && t.push(n.mask);
	return t;
}
function Rt(e, t, n = "#ffffff") {
	if (!(e >= 1 && t >= 1 && e <= 16384 && t <= 16384)) throw Error("A canvas must be 1 to 16384 pixels on each side.");
	return {
		width: Math.round(e),
		height: Math.round(t),
		background: n,
		layers: []
	};
}
var zt = (e, t) => ({
	id: Nt(t),
	name: e,
	visible: !0,
	locked: !1,
	opacity: 1,
	blend: "normal",
	transform: { ...jt }
}), Bt = (e, t, n = {}) => ({
	...zt(e, "raster"),
	kind: "raster",
	pixels: t,
	transform: {
		...jt,
		...n
	}
}), Vt = (e, t, n = {}, r = {}) => ({
	...zt(e, "shape"),
	kind: "shape",
	shape: t,
	fill: "#e46a9b",
	stroke: null,
	strokeWidth: 4,
	...n,
	transform: {
		...jt,
		...r
	}
}), Ht = (e, t = {}, n = {}) => ({
	...zt(e.split("\n")[0].slice(0, 24) || "Text", "text"),
	kind: "text",
	text: e,
	font: "system-ui, sans-serif",
	size: 64,
	weight: 700,
	italic: !1,
	color: "#1a1a1a",
	align: "left",
	lineHeight: 1.2,
	box: {
		width: 0,
		height: 0
	},
	...t,
	transform: {
		...jt,
		...n
	}
}), Ut = (e, t) => e.layers.find((e) => e.id === t);
function K(e, t, n) {
	let r = [...e.layers], i = n ? r.findIndex((e) => e.id === n) : -1;
	return r.splice(i >= 0 ? i + 1 : r.length, 0, t), {
		...e,
		layers: r
	};
}
function q(e, t, n) {
	return {
		...e,
		layers: e.layers.map((e) => e.id === t ? {
			...e,
			...n
		} : e)
	};
}
var Wt = (e, t) => ({
	...e,
	layers: e.layers.filter((e) => e.id !== t)
});
function Gt(e, t, n) {
	let r = [...e.layers], i = r.findIndex((e) => e.id === t);
	if (i < 0) return e;
	let a = Math.max(0, Math.min(r.length - 1, n === Infinity ? r.length - 1 : n === -Infinity ? 0 : i + n));
	if (a === i) return e;
	let [o] = r.splice(i, 1);
	return r.splice(a, 0, o), {
		...e,
		layers: r
	};
}
function Kt(e, t, n) {
	let r = Ut(e, n);
	if (!r) return {
		doc: e,
		id: n
	};
	let i = {
		...r,
		id: Nt(r.kind),
		name: `${r.name} copy`
	};
	return i.kind === "raster" && (i.pixels = t.add(Ft(t.get(i.pixels)))), i.mask &&= t.add(Ft(t.get(i.mask)), "mask"), {
		doc: K(e, i, n),
		id: i.id
	};
}
//#endregion
//#region ../canvas/src/geometry.ts
function qt(e) {
	let t = Math.cos(e.rotation), n = Math.sin(e.rotation);
	return {
		a: t * e.scaleX,
		b: n * e.scaleX,
		c: -n * e.scaleY,
		d: t * e.scaleY,
		e: e.x,
		f: e.y
	};
}
function Jt(e) {
	let t = e.a * e.d - e.b * e.c;
	return t ? {
		a: e.d / t,
		b: -e.b / t,
		c: -e.c / t,
		d: e.a / t,
		e: (e.c * e.f - e.d * e.e) / t,
		f: (e.b * e.e - e.a * e.f) / t
	} : {
		a: 1,
		b: 0,
		c: 0,
		d: 1,
		e: -e.e,
		f: -e.f
	};
}
var Yt = (e, t) => ({
	x: e.a * t.x + e.c * t.y + e.e,
	y: e.b * t.x + e.d * t.y + e.f
}), Xt = (e, t) => Yt(Jt(qt(e.transform)), t);
function Zt(e, t) {
	switch (e.kind) {
		case "raster": {
			let n = t?.get(e.pixels);
			return {
				x: 0,
				y: 0,
				width: n?.width ?? 0,
				height: n?.height ?? 0
			};
		}
		case "text": return {
			x: e.align === "center" ? -e.box.width / 2 : e.align === "right" ? -e.box.width : 0,
			y: 0,
			...e.box
		};
		case "shape": {
			let t = e.shape, n = e.stroke ? e.strokeWidth / 2 : 0, r;
			return r = t.type === "rect" || t.type === "ellipse" ? {
				x: 0,
				y: 0,
				width: t.width,
				height: t.height
			} : t.type === "line" ? {
				x: Math.min(0, t.x2),
				y: Math.min(0, t.y2),
				width: Math.abs(t.x2),
				height: Math.abs(t.y2)
			} : en(t.path), {
				x: r.x - n,
				y: r.y - n,
				width: r.width + n * 2,
				height: r.height + n * 2
			};
		}
	}
}
function Qt(e, t) {
	let n = Zt(e, t), r = qt(e.transform);
	return [
		{
			x: n.x,
			y: n.y
		},
		{
			x: n.x + n.width,
			y: n.y
		},
		{
			x: n.x + n.width,
			y: n.y + n.height
		},
		{
			x: n.x,
			y: n.y + n.height
		}
	].map((e) => Yt(r, e));
}
function $t(e, t, n) {
	for (let r = e.layers.length - 1; r >= 0; r--) {
		let i = e.layers[r];
		if (!i.visible || i.locked) continue;
		let a = Xt(i, n), o = Zt(i, t);
		if (!(a.x < o.x || a.y < o.y || a.x >= o.x + o.width || a.y >= o.y + o.height)) {
			if (i.kind === "raster") {
				let e = t.get(i.pixels);
				if (e.data[(Math.floor(a.y) * e.width + Math.floor(a.x)) * 4 + 3] < 10) continue;
			}
			return i;
		}
	}
}
function en(e) {
	if (!e.points.length) return {
		x: 0,
		y: 0,
		width: 0,
		height: 0
	};
	let t = [], n = [];
	for (let r of e.points) t.push(r.x, r.x + (r.in?.x ?? 0), r.x + (r.out?.x ?? 0)), n.push(r.y, r.y + (r.in?.y ?? 0), r.y + (r.out?.y ?? 0));
	let r = Math.min(...t), i = Math.min(...n);
	return {
		x: r,
		y: i,
		width: Math.max(...t) - r,
		height: Math.max(...n) - i
	};
}
var J = (e) => Math.round(e * 100) / 100;
function tn(e) {
	let t = e.points;
	if (!t.length) return "";
	let n = [`M${J(t[0].x)} ${J(t[0].y)}`], r = (e, t) => {
		if (!e.out && !t.in) return `L${J(t.x)} ${J(t.y)}`;
		let n = {
			x: e.x + (e.out?.x ?? 0),
			y: e.y + (e.out?.y ?? 0)
		}, r = {
			x: t.x + (t.in?.x ?? 0),
			y: t.y + (t.in?.y ?? 0)
		};
		return `C${J(n.x)} ${J(n.y)} ${J(r.x)} ${J(r.y)} ${J(t.x)} ${J(t.y)}`;
	};
	for (let e = 1; e < t.length; e++) n.push(r(t[e - 1], t[e]));
	if (e.closed && t.length > 2) {
		let e = t[t.length - 1], i = t[0];
		(e.out || i.in) && n.push(r(e, i)), n.push("Z");
	}
	return n.join(" ");
}
function nn(e) {
	switch (e.type) {
		case "rect": {
			let { width: t, height: n } = e, r = Math.max(0, Math.min(e.radius, t / 2, n / 2));
			return r ? `M${J(r)} 0 H${J(t - r)} A${J(r)} ${J(r)} 0 0 1 ${J(t)} ${J(r)} V${J(n - r)} A${J(r)} ${J(r)} 0 0 1 ${J(t - r)} ${J(n)} H${J(r)} A${J(r)} ${J(r)} 0 0 1 0 ${J(n - r)} V${J(r)} A${J(r)} ${J(r)} 0 0 1 ${J(r)} 0 Z` : `M0 0 H${J(t)} V${J(n)} H0 Z`;
		}
		case "ellipse": {
			let t = e.width / 2, n = e.height / 2;
			return `M0 ${J(n)} A${J(t)} ${J(n)} 0 1 0 ${J(e.width)} ${J(n)} A${J(t)} ${J(n)} 0 1 0 0 ${J(n)} Z`;
		}
		case "line": return `M0 0 L${J(e.x2)} ${J(e.y2)}`;
		case "path": return tn(e.path);
	}
}
var rn = (e, t = Math.PI / 12) => Math.round(e / t) * t, an = class {
	store;
	limit;
	past = [];
	future = [];
	current;
	constructor(e, t, n = 60) {
		this.store = t, this.limit = n, this.current = {
			doc: e,
			label: "Opened"
		};
	}
	get doc() {
		return this.current.doc;
	}
	get canUndo() {
		return this.past.length > 0;
	}
	get canRedo() {
		return this.future.length > 0;
	}
	list() {
		return {
			steps: [
				...this.past,
				this.current,
				...[...this.future].reverse()
			],
			at: this.past.length
		};
	}
	push(e, t) {
		e !== this.current.doc && (this.past.push(this.current), this.current = {
			doc: e,
			label: t
		}, this.future = [], this.past.length > this.limit && this.past.shift(), this.store.keepOnly([this.current.doc, ...this.past.map((e) => e.doc)]));
	}
	replace(e) {
		this.current = {
			...this.current,
			doc: e
		};
	}
	undo() {
		let e = this.past.pop();
		return e && (this.future.push(this.current), this.current = e), this.current.doc;
	}
	redo() {
		let e = this.future.pop();
		return e && (this.past.push(this.current), this.current = e), this.current.doc;
	}
	goTo(e) {
		for (; this.past.length > e && this.canUndo;) this.undo();
		for (; this.past.length < e && this.canRedo;) this.redo();
		return this.current.doc;
	}
}, on = (e, t) => ({
	width: e,
	height: t,
	mask: new Uint8Array(e * t)
});
function sn(e, t) {
	let n = on(e, t);
	return n.mask.fill(255), n;
}
function cn(e, t, n) {
	let r = on(e, t), i = Math.max(0, Math.round(Math.min(n.x, n.x + n.width))), a = Math.min(e, Math.round(Math.max(n.x, n.x + n.width))), o = Math.max(0, Math.round(Math.min(n.y, n.y + n.height))), s = Math.min(t, Math.round(Math.max(n.y, n.y + n.height)));
	for (let t = o; t < s; t++) r.mask.fill(255, t * e + i, t * e + a);
	return r;
}
function ln(e, t, n) {
	let r = on(e, t), i = n.x + n.width / 2, a = n.y + n.height / 2, o = Math.abs(n.width / 2), s = Math.abs(n.height / 2);
	if (o < .5 || s < .5) return r;
	let c = Math.max(0, Math.floor(a - s)), l = Math.min(t, Math.ceil(a + s)), u = Math.max(0, Math.floor(i - o)), d = Math.min(e, Math.ceil(i + o));
	for (let t = c; t < l; t++) for (let n = u; n < d; n++) {
		let c = (n + .5 - i) / o, l = (t + .5 - a) / s, u = (1 - Math.sqrt(c * c + l * l)) * Math.min(o, s);
		u > 0 && (r.mask[t * e + n] = Math.round(255 * Math.min(1, u + .5)));
	}
	return r;
}
function un(e, t, n) {
	let r = on(e, t);
	if (n.length < 3) return r;
	let i = n.map((e) => e.y), a = Math.max(0, Math.floor(Math.min(...i))), o = Math.min(t, Math.ceil(Math.max(...i))), s = [];
	for (let t = a; t < o; t++) {
		let i = t + .5;
		s.length = 0;
		for (let e = 0; e < n.length; e++) {
			let t = n[e], r = n[(e + 1) % n.length];
			t.y <= i != r.y <= i && s.push(t.x + (i - t.y) / (r.y - t.y) * (r.x - t.x));
		}
		s.sort((e, t) => e - t);
		for (let n = 0; n + 1 < s.length; n += 2) {
			let i = Math.max(0, Math.round(s[n])), a = Math.min(e, Math.round(s[n + 1]));
			a > i && r.mask.fill(255, t * e + i, t * e + a);
		}
	}
	return r;
}
function dn(e, t, n) {
	if (!e || n === "replace") return t;
	let r = on(t.width, t.height);
	for (let i = 0; i < r.mask.length; i++) {
		let a = e.mask[i], o = t.mask[i];
		r.mask[i] = n === "add" ? Math.max(a, o) : n === "subtract" ? Math.max(0, a - o) : Math.min(a, o);
	}
	return r;
}
function fn(e) {
	let t = on(e.width, e.height);
	for (let n = 0; n < t.mask.length; n++) t.mask[n] = 255 - e.mask[n];
	return t;
}
function pn(e) {
	let t = e.width, n = e.height, r = -1, i = -1;
	for (let a = 0; a < e.height; a++) for (let o = 0; o < e.width; o++) e.mask[a * e.width + o] > 0 && (o < t && (t = o), o > r && (r = o), a < n && (n = a), a > i && (i = a));
	return r < 0 ? null : {
		x: t,
		y: n,
		width: r - t + 1,
		height: i - n + 1
	};
}
function mn(e, t) {
	let n = Math.round(t);
	if (n < 1) return e;
	let r = Float32Array.from(e.mask), i = new Float32Array(r.length), { width: a, height: o } = e;
	for (let e = 0; e < 3; e++) {
		for (let e = 0; e < o; e++) {
			let t = 0;
			for (let i = -n; i <= n; i++) t += r[e * a + Math.min(a - 1, Math.max(0, i))];
			for (let o = 0; o < a; o++) i[e * a + o] = t / (2 * n + 1), t += r[e * a + Math.min(a - 1, o + n + 1)] - r[e * a + Math.max(0, o - n)];
		}
		[r, i] = [i, r];
		for (let e = 0; e < a; e++) {
			let t = 0;
			for (let i = -n; i <= n; i++) t += r[Math.min(o - 1, Math.max(0, i)) * a + e];
			for (let s = 0; s < o; s++) i[s * a + e] = t / (2 * n + 1), t += r[Math.min(o - 1, s + n + 1) * a + e] - r[Math.max(0, s - n) * a + e];
		}
		[r, i] = [i, r];
	}
	let s = on(a, o);
	for (let e = 0; e < s.mask.length; e++) s.mask[e] = Math.round(r[e]);
	return s;
}
function hn(e, t, n, r = !0) {
	let { width: i, height: a, data: o } = e, s = on(i, a), c = Math.floor(t.x), l = Math.floor(t.y);
	if (c < 0 || l < 0 || c >= i || l >= a) return s;
	let u = (l * i + c) * 4, d = [
		o[u],
		o[u + 1],
		o[u + 2],
		o[u + 3]
	], f = (e) => {
		let t = e * 4;
		return Math.max(Math.abs(o[t] - d[0]), Math.abs(o[t + 1] - d[1]), Math.abs(o[t + 2] - d[2]), Math.abs(o[t + 3] - d[3])) <= n;
	};
	if (!r) {
		for (let e = 0; e < i * a; e++) f(e) && (s.mask[e] = 255);
		return s;
	}
	let p = [l * i + c];
	for (s.mask[l * i + c] = 255; p.length;) {
		let e = p.pop(), t = e % i, n = (e - t) / i;
		for (let r of [
			t > 0 ? e - 1 : -1,
			t < i - 1 ? e + 1 : -1,
			n > 0 ? e - i : -1,
			n < a - 1 ? e + i : -1
		]) r >= 0 && !s.mask[r] && f(r) && (s.mask[r] = 255, p.push(r));
	}
	return s;
}
function gn(e) {
	let { width: t, height: n, mask: r } = e, i = new Uint8Array(t * n);
	for (let e = 0; e < n; e++) for (let a = 0; a < t; a++) {
		let o = e * t + a;
		r[o] < 128 || (a === 0 || e === 0 || a === t - 1 || e === n - 1 || r[o - 1] < 128 || r[o + 1] < 128 || r[o - t] < 128 || r[o + t] < 128) && (i[o] = 1);
	}
	return i;
}
//#endregion
//#region ../canvas/src/paint.ts
var _n = (e) => [
	parseInt(e.slice(1, 3), 16),
	parseInt(e.slice(3, 5), 16),
	parseInt(e.slice(5, 7), 16)
], vn = ([e, t, n]) => `#${[
	e,
	t,
	n
].map((e) => Math.round(Math.min(255, Math.max(0, e))).toString(16).padStart(2, "0")).join("")}`;
function yn(e, t, n, r) {
	let i = Math.max(.5, n.size / 2), a = Math.max(0, Math.floor(t.x - i)), o = Math.min(e.width, Math.ceil(t.x + i)), s = Math.max(0, Math.floor(t.y - i)), c = Math.min(e.height, Math.ceil(t.y + i));
	if (o <= a || c <= s) return null;
	let l = i * Math.min(.999, Math.max(0, n.hardness)), u = e.data;
	for (let d = s; d < c; d++) for (let s = a; s < o; s++) {
		let a = Math.hypot(s + .5 - t.x, d + .5 - t.y);
		if (a >= i) continue;
		let o = a <= l ? 1 : 1 - (a - l) / (i - l);
		if (o = o * o * (3 - 2 * o) * n.flow, r && (o *= r(s, d)), o <= 0) continue;
		let c = (d * e.width + s) * 4, f = u[c + 3] / 255;
		if (n.mode === "erase" || n.mode === "hide") u[c + 3] = f * (1 - o) * 255;
		else if (n.mode === "reveal") u[c + 3] = (f + (1 - f) * o) * 255;
		else {
			let e = o + f * (1 - o);
			for (let t = 0; t < 3; t++) u[c + t] = (n.color[t] * o + u[c + t] * f * (1 - o)) / e;
			u[c + 3] = e * 255;
		}
	}
	return {
		x: a,
		y: s,
		width: o - a,
		height: c - s
	};
}
var bn = () => ({
	last: null,
	carry: 0
}), xn = (e, t) => {
	if (!e) return t;
	if (!t) return e;
	let n = Math.min(e.x, t.x), r = Math.min(e.y, t.y);
	return {
		x: n,
		y: r,
		width: Math.max(e.x + e.width, t.x + t.width) - n,
		height: Math.max(e.y + e.height, t.y + t.height) - r
	};
};
function Sn(e, t, n, r) {
	if (!e.last) return e.last = t, e.carry = 0, r(t);
	let i = e.last, a = Math.hypot(t.x - i.x, t.y - i.y), o = null, s = n - e.carry;
	for (; s <= a;) o = xn(o, r({
		x: i.x + (t.x - i.x) * s / a,
		y: i.y + (t.y - i.y) * s / a
	})), s += n;
	return e.carry = a - (s - n), e.last = t, o;
}
var Cn = (e) => Math.max(1, e * .12);
function wn(e, t, n, r, i) {
	return Sn(t, n, Cn(r.size), (t) => yn(e, t, r, i));
}
function Tn(e, t, n, r, i = !0, a) {
	let { width: o, height: s, data: c } = e, l = Math.floor(t.x), u = Math.floor(t.y);
	if (l < 0 || u < 0 || l >= o || u >= s) return null;
	let d = (u * o + l) * 4, f = [
		c[d],
		c[d + 1],
		c[d + 2],
		c[d + 3]
	], p = (e) => {
		let t = e * 4;
		return Math.max(Math.abs(c[t] - f[0]), Math.abs(c[t + 1] - f[1]), Math.abs(c[t + 2] - f[2]), Math.abs(c[t + 3] - f[3])) <= r;
	}, m = new Uint8Array(o * s);
	if (i) {
		let e = [u * o + l];
		for (m[u * o + l] = 1; e.length;) {
			let t = e.pop(), n = t % o, r = (t - n) / o;
			for (let i of [
				n > 0 ? t - 1 : -1,
				n < o - 1 ? t + 1 : -1,
				r > 0 ? t - o : -1,
				r < s - 1 ? t + o : -1
			]) i >= 0 && !m[i] && p(i) && (m[i] = 1, e.push(i));
		}
	} else for (let e = 0; e < o * s; e++) p(e) && (m[e] = 1);
	let h = o, g = s, _ = -1, v = -1;
	for (let e = 0; e < o * s; e++) {
		if (!m[e]) continue;
		let t = e % o, r = (e - t) / o, i = a ? a(t, r) : 1;
		i <= 0 || (En(c, e * 4, n, i), t < h && (h = t), t > _ && (_ = t), r < g && (g = r), r > v && (v = r));
	}
	return _ < 0 ? null : {
		x: h,
		y: g,
		width: _ - h + 1,
		height: v - g + 1
	};
}
function En(e, t, n, r) {
	let i = e[t + 3] / 255, a = r + i * (1 - r);
	for (let o = 0; o < 3; o++) e[t + o] = (n[o] * r + e[t + o] * i * (1 - r)) / a;
	e[t + 3] = a * 255;
}
function Dn(e, t, n) {
	for (let r = 0; r < e.height; r++) for (let i = 0; i < e.width; i++) {
		let a = n ? n(i, r) : 1;
		a > 0 && En(e.data, (r * e.width + i) * 4, t, a);
	}
}
function On(e, t) {
	for (let n = 0; n < e.height; n++) for (let r = 0; r < e.width; r++) {
		let i = t ? t(r, n) : 1, a = (n * e.width + r) * 4 + 3;
		i > 0 && (e.data[a] = e.data[a] * (1 - i));
	}
}
function kn(e, t) {
	let n = {
		width: e.width,
		height: e.height,
		data: new Uint8ClampedArray(e.data)
	};
	if (t) for (let r = 0; r < e.height; r++) for (let i = 0; i < e.width; i++) {
		let a = (r * e.width + i) * 4 + 3;
		n.data[a] = n.data[a] * t(i, r);
	}
	return n;
}
function An(e, t, n, r, i, a) {
	let o = n.x - t.x, s = n.y - t.y, c = o * o + s * s || 1;
	for (let n = 0; n < e.height; n++) for (let l = 0; l < e.width; l++) {
		let u = a ? a(l, n) : 1;
		if (u <= 0) continue;
		let d = Math.min(1, Math.max(0, ((l + .5 - t.x) * o + (n + .5 - t.y) * s) / c));
		En(e.data, (n * e.width + l) * 4, [
			r[0] + (i[0] - r[0]) * d,
			r[1] + (i[1] - r[1]) * d,
			r[2] + (i[2] - r[2]) * d
		], u);
	}
}
function jn(e, t) {
	let n = Math.floor(t.x), r = Math.floor(t.y);
	if (n < 0 || r < 0 || n >= e.width || r >= e.height) return null;
	let i = (r * e.width + n) * 4;
	return [
		e.data[i],
		e.data[i + 1],
		e.data[i + 2]
	];
}
function Mn(e, t, n, r, i, a) {
	let o = Math.max(.5, i.size / 2), s = Math.max(0, Math.floor(n.x - o)), c = Math.min(e.width, Math.ceil(n.x + o)), l = Math.max(0, Math.floor(n.y - o)), u = Math.min(e.height, Math.ceil(n.y + o));
	if (c <= s || u <= l) return null;
	let d = o * Math.min(.999, Math.max(0, i.hardness));
	for (let f = l; f < u; f++) for (let l = s; l < c; l++) {
		let s = Math.floor(l + r.x), c = Math.floor(f + r.y);
		if (s < 0 || c < 0 || s >= t.width || c >= t.height) continue;
		let u = Math.hypot(l + .5 - n.x, f + .5 - n.y);
		if (u >= o) continue;
		let p = u <= d ? 1 : 1 - (u - d) / (o - d);
		p = p * p * (3 - 2 * p) * i.flow * (a ? a(l, f) : 1);
		let m = (c * t.width + s) * 4, h = t.data[m + 3] / 255 * p;
		h <= 0 || En(e.data, (f * e.width + l) * 4, [
			t.data[m],
			t.data[m + 1],
			t.data[m + 2]
		], h);
	}
	return {
		x: s,
		y: l,
		width: c - s,
		height: u - l
	};
}
//#endregion
//#region ../canvas/src/adjust.ts
function Nn(e, t, n) {
	let r = {
		width: e.width,
		height: e.height,
		data: new Uint8ClampedArray(e.data)
	}, i = r.data;
	for (let r = 0; r < e.height; r++) for (let a = 0; a < e.width; a++) {
		let o = (r * e.width + a) * 4;
		if (!i[o + 3]) continue;
		let s = t ? t(a, r) : 1;
		if (s <= 0) continue;
		let [c, l, u] = n(i[o], i[o + 1], i[o + 2]);
		i[o] = i[o] + (c - i[o]) * s, i[o + 1] = i[o + 1] + (l - i[o + 1]) * s, i[o + 2] = i[o + 2] + (u - i[o + 2]) * s;
	}
	return r;
}
var Pn = (e, t) => Nn(e, t, (e, t, n) => [
	255 - e,
	255 - t,
	255 - n
]), Fn = (e, t) => Nn(e, t, (e, t, n) => {
	let r = .2126 * e + .7152 * t + .0722 * n;
	return [
		r,
		r,
		r
	];
});
function In(e, t, n, r) {
	let i = Math.tan((Math.max(-99, Math.min(99, n)) / 100 + 1) * Math.PI / 4), a = t * 1.28;
	return Nn(e, r, (e, t, n) => [
		e,
		t,
		n
	].map((e) => (e + a - 128) * i + 128));
}
function Ln(e, t, n, r, i) {
	return Nn(e, i, (e, i, a) => {
		let [o, s, c] = qn(e, i, a);
		return o = (o + t + 360) % 360, s = Math.min(1, Math.max(0, s * (1 + n / 100))), c = r >= 0 ? c + (1 - c) * (r / 100) : c * (1 + r / 100), Jn(o, s, c);
	});
}
var Rn = (e, t, n) => Nn(e, n, (e, n, r) => [
	t[e],
	t[n],
	t[r]
]);
function zn(e, t, n, r, i, a, o) {
	let s = Math.min(t, n - 1), c = Math.max(n, s + 1), l = /* @__PURE__ */ new Uint8ClampedArray(256);
	for (let e = 0; e < 256; e++) {
		let t = Math.min(1, Math.max(0, (e - s) / (c - s)));
		l[e] = i + (a - i) * t ** (1 / Math.max(.01, r));
	}
	return Rn(e, l, o);
}
function Bn(e, t, n, r, i) {
	let a = [
		0,
		64,
		128,
		192,
		255
	], o = [
		0,
		64 + t * .64,
		128 + n * .64,
		192 + r * .64,
		255
	].map((e) => Math.min(255, Math.max(0, e)));
	for (let e = 1; e < o.length; e++) o[e] = Math.max(o[e], o[e - 1]);
	let s = a.length, c = a.slice(1).map((e, t) => e - a[t]), l = o.slice(1).map((e, t) => (e - o[t]) / c[t]), u = a.map((e, t) => t === 0 ? l[0] : t === s - 1 ? l[s - 2] : l[t - 1] * l[t] <= 0 ? 0 : (l[t - 1] + l[t]) / 2);
	for (let e = 0; e < s - 1; e++) {
		if (l[e] === 0) {
			u[e] = u[e + 1] = 0;
			continue;
		}
		let t = u[e] / l[e], n = u[e + 1] / l[e], r = Math.hypot(t, n);
		r > 3 && (u[e] = 3 * t * l[e] / r, u[e + 1] = 3 * n * l[e] / r);
	}
	let d = /* @__PURE__ */ new Uint8ClampedArray(256);
	for (let e = 0; e < 256; e++) {
		let t = 0;
		for (; t < s - 2 && e > a[t + 1];) t++;
		let n = (e - a[t]) / c[t], r = 2 * n ** 3 - 3 * n ** 2 + 1, i = n ** 3 - 2 * n ** 2 + n, l = -2 * n ** 3 + 3 * n ** 2, f = n ** 3 - n ** 2;
		d[e] = r * o[t] + i * c[t] * u[t] + l * o[t + 1] + f * c[t] * u[t + 1];
	}
	return Rn(e, d, i);
}
function Vn(e, t, n) {
	let r = t / 100;
	return Nn(e, n, (e, t, n) => {
		let i = Math.max(e, t, n), a = (e + t + n) / 3, o = i ? (i - Math.min(e, t, n)) / i : 0, s = 1 + r * (1 - o) * 1.5;
		return [
			a + (e - a) * s,
			a + (t - a) * s,
			a + (n - a) * s
		];
	});
}
function Hn(e, t, n, r) {
	let i = t * .3, a = n * .3;
	return Nn(e, r, (e, t, n) => [
		e + i + a * .5,
		t - a,
		n - i + a * .5
	]);
}
function Un(e, t, n) {
	let r = Math.max(2, Math.round(t)), i = /* @__PURE__ */ new Uint8ClampedArray(256);
	for (let e = 0; e < 256; e++) i[e] = Math.round(e / 255 * (r - 1)) / (r - 1) * 255;
	return Rn(e, i, n);
}
function Wn(e, t, n) {
	return Nn(e, n, (e, n, r) => {
		let i = .2126 * e + .7152 * n + .0722 * r >= t ? 255 : 0;
		return [
			i,
			i,
			i
		];
	});
}
function Gn(e, t, n) {
	let r = Math.round(t);
	if (r < 1) return {
		...e,
		data: new Uint8ClampedArray(e.data)
	};
	let { width: i, height: a } = e, o = new Float32Array(i * a * 4);
	for (let t = 0; t < i * a; t++) {
		let n = e.data[t * 4 + 3] / 255;
		o[t * 4] = e.data[t * 4] * n, o[t * 4 + 1] = e.data[t * 4 + 1] * n, o[t * 4 + 2] = e.data[t * 4 + 2] * n, o[t * 4 + 3] = e.data[t * 4 + 3];
	}
	let s = new Float32Array(o.length), c = 2 * r + 1;
	for (let e = 0; e < 3; e++) {
		for (let e = 0; e < a; e++) for (let t = 0; t < 4; t++) {
			let n = 0;
			for (let a = -r; a <= r; a++) n += o[(e * i + Math.min(i - 1, Math.max(0, a))) * 4 + t];
			for (let a = 0; a < i; a++) s[(e * i + a) * 4 + t] = n / c, n += o[(e * i + Math.min(i - 1, a + r + 1)) * 4 + t] - o[(e * i + Math.max(0, a - r)) * 4 + t];
		}
		[o, s] = [s, o];
		for (let e = 0; e < i; e++) for (let t = 0; t < 4; t++) {
			let n = 0;
			for (let s = -r; s <= r; s++) n += o[(Math.min(a - 1, Math.max(0, s)) * i + e) * 4 + t];
			for (let l = 0; l < a; l++) s[(l * i + e) * 4 + t] = n / c, n += o[(Math.min(a - 1, l + r + 1) * i + e) * 4 + t] - o[(Math.max(0, l - r) * i + e) * 4 + t];
		}
		[o, s] = [s, o];
	}
	let l = {
		width: i,
		height: a,
		data: new Uint8ClampedArray(e.data)
	};
	for (let t = 0; t < a; t++) for (let r = 0; r < i; r++) {
		let a = n ? n(r, t) : 1;
		if (a <= 0) continue;
		let s = (t * i + r) * 4, c = o[s + 3], u = c > 0 ? 255 / c : 0;
		for (let t = 0; t < 3; t++) l.data[s + t] = e.data[s + t] + (o[s + t] * u - e.data[s + t]) * a;
		l.data[s + 3] = e.data[s + 3] + (c - e.data[s + 3]) * a;
	}
	return l;
}
function Kn(e, t, n = 1, r) {
	let i = Gn(e, n), a = {
		width: e.width,
		height: e.height,
		data: new Uint8ClampedArray(e.data)
	};
	for (let n = 0; n < e.height; n++) for (let o = 0; o < e.width; o++) {
		let s = r ? r(o, n) : 1;
		if (s <= 0) continue;
		let c = (n * e.width + o) * 4;
		for (let n = 0; n < 3; n++) a.data[c + n] = e.data[c + n] + (e.data[c + n] - i.data[c + n]) * t * s;
	}
	return a;
}
function qn(e, t, n) {
	e /= 255, t /= 255, n /= 255;
	let r = Math.max(e, t, n), i = Math.min(e, t, n), a = (r + i) / 2;
	if (r === i) return [
		0,
		0,
		a
	];
	let o = r - i, s = a > .5 ? o / (2 - r - i) : o / (r + i);
	return [
		r === e ? ((t - n) / o + (t < n ? 6 : 0)) * 60 : r === t ? ((n - e) / o + 2) * 60 : ((e - t) / o + 4) * 60,
		s,
		a
	];
}
function Jn(e, t, n) {
	let r = (1 - Math.abs(2 * n - 1)) * t, i = e / 60, a = r * (1 - Math.abs(i % 2 - 1)), [o, s, c] = i < 1 ? [
		r,
		a,
		0
	] : i < 2 ? [
		a,
		r,
		0
	] : i < 3 ? [
		0,
		r,
		a
	] : i < 4 ? [
		0,
		a,
		r
	] : i < 5 ? [
		a,
		0,
		r
	] : [
		r,
		0,
		a
	], l = n - r / 2;
	return [
		(o + l) * 255,
		(s + l) * 255,
		(c + l) * 255
	];
}
//#endregion
//#region ../canvas/src/render.ts
var Yn = (e) => `${e.italic ? "italic " : ""}${e.weight} ${e.size}px ${e.font}`;
function Xn(e, t) {
	e.font = Yn(t);
	let n = t.text.split("\n");
	return {
		width: Math.ceil(Math.max(1, ...n.map((t) => e.measureText(t).width))),
		height: Math.ceil(n.length * t.size * t.lineHeight)
	};
}
function Zn(e, t, n) {
	if (t.kind === "raster") {
		let r = n.image(t.pixels);
		r && e.drawImage(r, 0, 0);
		return;
	}
	if (t.kind === "text") {
		e.font = Yn(t), e.fillStyle = t.color, e.textAlign = t.align, e.textBaseline = "top";
		let n = t.size * t.lineHeight, r = (n - t.size) / 2;
		t.text.split("\n").forEach((t, i) => e.fillText(t, 0, i * n + r));
		return;
	}
	let r = n.path(nn(t.shape));
	t.fill && t.shape.type !== "line" && (e.fillStyle = t.fill, e.fill(r, "evenodd")), t.stroke && t.strokeWidth > 0 && (e.strokeStyle = t.stroke, e.lineWidth = t.strokeWidth, e.lineJoin = "round", e.lineCap = "round", e.stroke(r));
}
var Qn = (e, t) => {
	let n = qt(t.transform);
	e.transform(n.a, n.b, n.c, n.d, n.e, n.f);
}, $n = (e) => !!(e && (e.shadow || e.glow || e.stroke)), er = (e, t) => {
	let n = parseInt(e.slice(1), 16);
	return `rgba(${n >> 16 & 255}, ${n >> 8 & 255}, ${n & 255}, ${Math.max(0, Math.min(1, t))})`;
};
function tr(e, t, n, r, i) {
	let a = (e, n) => {
		let a = i.surface(r.width, r.height, 2);
		return a.ctx.drawImage(t, 0, 0), a.ctx.globalCompositeOperation = "source-in", a.ctx.fillStyle = er(e, n), a.ctx.fillRect(0, 0, r.width, r.height), a.ctx.globalCompositeOperation = "source-over", a.canvas;
	}, o = (t, n, r, i) => {
		e.save(), n > 0 && (e.filter = `blur(${n / 2}px)`), e.drawImage(t, r, i), e.restore();
	};
	if (n.shadow && n.shadow.opacity > 0) {
		let e = n.shadow.angle * Math.PI / 180;
		o(a(n.shadow.color, n.shadow.opacity), n.shadow.blur, -Math.cos(e) * n.shadow.distance, Math.sin(e) * n.shadow.distance);
	}
	if (n.glow && n.glow.opacity > 0 && n.glow.size > 0) {
		let e = a(n.glow.color, n.glow.opacity);
		for (let t = 0; t < 2; t++) o(e, n.glow.size, 0, 0);
	}
	if (n.stroke && n.stroke.width > 0) {
		let t = a(n.stroke.color, 1), r = n.stroke.width;
		for (let n = Math.min(1, r); n <= r; n += Math.max(1, r / 4)) {
			let r = Math.max(8, Math.ceil(n * 3));
			for (let i = 0; i < r; i++) e.drawImage(t, Math.cos(i / r * 2 * Math.PI) * n, Math.sin(i / r * 2 * Math.PI) * n);
		}
	}
}
function nr(e, t, n, r) {
	let i = n.mask && !n.maskOff ? r.image(n.mask) : void 0, a = $n(n.style) ? n.style : void 0;
	if (e.save(), e.globalAlpha = n.opacity, e.globalCompositeOperation = n.blend === "normal" ? "source-over" : n.blend, !i && !a) Qn(e, n), Zn(e, n, r);
	else {
		let o = r.surface(t.width, t.height, 0);
		if (o.ctx.save(), Qn(o.ctx, n), Zn(o.ctx, n, r), o.ctx.restore(), i && (o.ctx.globalCompositeOperation = "destination-in", o.ctx.drawImage(i, 0, 0), o.ctx.globalCompositeOperation = "source-over"), !a) e.drawImage(o.canvas, 0, 0);
		else {
			let n = r.surface(t.width, t.height, 1);
			tr(n.ctx, o.canvas, a, t, r), n.ctx.drawImage(o.canvas, 0, 0), e.drawImage(n.canvas, 0, 0);
		}
	}
	e.restore();
}
function rr(e, t, n, r = {}) {
	r.background !== !1 && t.background && (e.save(), e.fillStyle = t.background, e.fillRect(0, 0, t.width, t.height), e.restore());
	for (let i of t.layers) i.visible && !r.hide?.has(i.id) && nr(e, t, i, n);
}
//#endregion
//#region ../canvas/src/files.ts
var ir = (e) => e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"), ar = (e) => String(Math.round(e * 1e3) / 1e3);
function or(e, t) {
	let n = [], r = [];
	e.background && r.push(`<rect width="${e.width}" height="${e.height}" fill="${e.background}"/>`);
	for (let i of e.layers) {
		if (!i.visible) continue;
		let a = qt(i.transform), o = [
			`transform="matrix(${[
				a.a,
				a.b,
				a.c,
				a.d,
				a.e,
				a.f
			].map(ar).join(" ")})"`,
			i.opacity < 1 ? `opacity="${ar(i.opacity)}"` : "",
			i.blend === "normal" ? "" : `style="mix-blend-mode:${i.blend}"`
		], s = "";
		if (i.mask && !i.maskOff) {
			let r = `m-${n.length}`;
			n.push(`<mask id="${r}" maskUnits="userSpaceOnUse" x="0" y="0" width="${e.width}" height="${e.height}" style="mask-type:alpha"><image href="${t(i.mask)}" width="${e.width}" height="${e.height}"/></mask>`), s = ` mask="url(#${r})"`;
		}
		let c = "";
		if (i.style && (i.style.shadow || i.style.glow || i.style.stroke)) {
			let e = `f-${n.length}`;
			n.push(sr(e, i.style)), c = ` filter="url(#${e})"`;
		}
		r.push(`<g${s}${c}><g ${o.filter(Boolean).join(" ")}>${cr(i, t)}</g></g>`);
	}
	return `<svg xmlns="http://www.w3.org/2000/svg" width="${e.width}" height="${e.height}" viewBox="0 0 ${e.width} ${e.height}">${n.length ? `<defs>${n.join("")}</defs>` : ""}${r.join("")}</svg>`;
}
function sr(e, t) {
	let n = [], r = [];
	if (t.shadow && t.shadow.opacity > 0) {
		let e = t.shadow.angle * Math.PI / 180;
		n.push(`<feGaussianBlur in="SourceAlpha" stdDeviation="${ar(t.shadow.blur / 2)}" result="sb"/><feOffset in="sb" dx="${ar(-Math.cos(e) * t.shadow.distance)}" dy="${ar(Math.sin(e) * t.shadow.distance)}" result="so"/><feFlood flood-color="${t.shadow.color}" flood-opacity="${ar(t.shadow.opacity)}"/><feComposite in2="so" operator="in" result="shadow"/>`), r.push("shadow");
	}
	return t.glow && t.glow.opacity > 0 && (n.push(`<feGaussianBlur in="SourceAlpha" stdDeviation="${ar(t.glow.size / 2)}" result="gb"/><feFlood flood-color="${t.glow.color}" flood-opacity="${ar(Math.min(1, t.glow.opacity * 1.6))}"/><feComposite in2="gb" operator="in" result="glow"/>`), r.push("glow")), t.stroke && t.stroke.width > 0 && (n.push(`<feMorphology in="SourceAlpha" operator="dilate" radius="${ar(t.stroke.width)}" result="sd"/><feFlood flood-color="${t.stroke.color}"/><feComposite in2="sd" operator="in" result="stroke"/>`), r.push("stroke")), `<filter id="${e}" x="-50%" y="-50%" width="200%" height="200%" color-interpolation-filters="sRGB">${n.join("")}<feMerge>${r.map((e) => `<feMergeNode in="${e}"/>`).join("")}<feMergeNode in="SourceGraphic"/></feMerge></filter>`;
}
function cr(e, t) {
	if (e.kind === "raster") return `<image href="${t(e.pixels)}"/>`;
	if (e.kind === "text") {
		let t = e.align === "center" ? "middle" : e.align === "right" ? "end" : "start", n = e.size * e.lineHeight, r = ir(Yn(e));
		return e.text.split("\n").map((i, a) => `<text x="0" y="${ar(a * n + (n - e.size) / 2 + e.size * .8)}" style="font:${r}" fill="${e.color}" text-anchor="${t}" xml:space="preserve">${ir(i)}</text>`).join("");
	}
	let n = e.fill && e.shape.type !== "line" ? e.fill : "none", r = e.stroke && e.strokeWidth > 0 ? ` stroke="${e.stroke}" stroke-width="${ar(e.strokeWidth)}" stroke-linejoin="round" stroke-linecap="round"` : "";
	return `<path d="${nn(e.shape)}" fill="${n}" fill-rule="evenodd"${r}/>`;
}
function lr(e, t) {
	let n = {};
	for (let r of Lt(e)) n[r] = t(r);
	return {
		format: "gleamshelf-canvas",
		version: 1,
		doc: e,
		pixels: n
	};
}
async function ur(e, t) {
	let n = e;
	if (!n || n.format !== "gleamshelf-canvas" || n.version !== 1 || !n.doc || !Array.isArray(n.doc.layers)) throw Error("That is not a Gleamshelf design file.");
	let r = new It();
	for (let e of Lt(n.doc)) {
		let i = n.pixels?.[e];
		if (typeof i != "string") throw Error("The design file is missing one of its pictures.");
		r.set(e, await t(i));
	}
	return {
		doc: n.doc,
		store: r
	};
}
//#endregion
//#region ../canvas/src/commands.ts
var dr = class {
	backend;
	history;
	store;
	selection = null;
	selectedId = null;
	colours = {
		main: "#1a1a1a",
		second: "#ffffff"
	};
	clipboard = null;
	dry = !1;
	preview = null;
	constructor(e, t, n = new It()) {
		this.backend = e, this.store = n, this.history = new an(t, n), this.selectedId = t.layers[t.layers.length - 1]?.id ?? null;
	}
	get doc() {
		return this.preview ?? this.history.doc;
	}
	get selected() {
		return this.selectedId ? Ut(this.doc, this.selectedId) : void 0;
	}
	commit(e, t) {
		this.dry ? this.preview = e : this.history.push(e, t);
	}
	replace(e, t = new It()) {
		this.store = t, this.history = new an(e, t), this.selection = null, this.selectedId = e.layers[e.layers.length - 1]?.id ?? null, this.clipboard = null, this.preview = null;
	}
	host() {
		return {
			image: (e) => {
				let t = this.store.get(e);
				return t ? this.backend.image(e, t) : void 0;
			},
			surface: (e, t) => {
				let n = this.backend.surface(e, t);
				return {
					ctx: n.ctx,
					canvas: n.canvas
				};
			},
			path: (e) => this.backend.path(e)
		};
	}
	flatten(e = this.doc, t = !0) {
		let n = this.backend.surface(e.width, e.height);
		return rr(n.ctx, e, this.host(), { background: t }), n.read();
	}
}, Y = class extends Error {};
function fr(e) {
	if (typeof e != "string") {
		if (e && typeof e == "object") return e;
		throw new Y("The 3D design is missing.");
	}
	try {
		let t = JSON.parse(e);
		if (!t || typeof t != "object" || !Array.isArray(t.shapes)) throw new Y("That is not a 3D design (it has no shapes).");
		return t;
	} catch (e) {
		throw e instanceof Y ? e : new Y("The 3D design is not valid JSON.");
	}
}
var X = {
	name: "layer",
	type: "string",
	label: "Layer",
	description: "The layer, by id or name (the picked layer when left out).",
	optional: !0
}, pr = {
	name: "mode",
	type: "enum",
	label: "Combine",
	options: [
		"replace",
		"add",
		"subtract",
		"intersect"
	],
	default: "replace",
	description: "How the new selection combines with the current one."
};
function Z(e, t) {
	let n = e.doc;
	if (t) {
		let e = Ut(n, t) ?? [...n.layers].reverse().find((e) => e.name === t);
		if (!e) throw new Y(`There is no layer called "${t}".`);
		return e;
	}
	let r = e.selected;
	if (!r) throw new Y("Pick a layer first.");
	return r;
}
var mr = (e) => {
	if (e.locked) throw new Y(`"${e.name}" is locked.`);
	return e;
}, hr = (e) => {
	if (e.kind !== "raster") throw new Y(`"${e.name}" is a ${e.kind} layer. Rasterize it first to change its pixels.`);
	return mr(e);
};
function gr(e, t) {
	let n = e.selection;
	if (!n) return;
	let { width: r, height: i, mask: a } = n;
	if (!t) return (e, t) => e >= 0 && t >= 0 && e < r && t < i ? a[t * r + e] / 255 : 0;
	let o = qt(t.transform);
	return (e, t) => {
		let n = Yt(o, {
			x: e + .5,
			y: t + .5
		}), s = Math.floor(n.x), c = Math.floor(n.y);
		return s >= 0 && c >= 0 && s < r && c < i ? a[c * r + s] / 255 : 0;
	};
}
function _r(e, t) {
	let n = t ? Z(e, t) : e.selected;
	if (n?.kind === "raster") return {
		doc: e.doc,
		layer: hr(n)
	};
	let r = Bt("Paint", e.store.add(Pt(e.doc.width, e.doc.height)));
	return e.selectedId = r.id, {
		doc: K(e.doc, r, n?.id),
		layer: r
	};
}
function vr(e, t, n) {
	let r = Ft(e.store.get(n.pixels)), i = e.store.add(r);
	return {
		doc: q(t, n.id, { pixels: i }),
		working: r,
		layer: {
			...n,
			pixels: i
		}
	};
}
var yr = (e, t) => (e.selection = pn(t) ? t : null, { message: e.selection ? void 0 : "Nothing is selected." });
function br(e, t) {
	let n = e.backend.surface(e.doc.width, e.doc.height);
	return nr(n.ctx, e.doc, {
		...t,
		opacity: 1,
		blend: "normal",
		mask: void 0
	}, e.host()), n.read();
}
var xr = (e, t) => Xn(e.backend.surface(1, 1).ctx, {
	...t,
	text: t.text || " "
}), Sr = (e, t, n) => {
	let r = Yt(qt(e), n), i = Yt(qt({
		...t,
		x: 0,
		y: 0
	}), n);
	return {
		...t,
		x: r.x - i.x,
		y: r.y - i.y
	};
}, Cr = (e) => e.map((e) => Array.isArray(e) ? {
	x: Number(e[0]),
	y: Number(e[1])
} : {
	x: Number(e.x),
	y: Number(e.y)
});
function wr(e) {
	let t = e.doc, n = e.selection ? pn(e.selection) : null;
	return {
		width: t.width,
		height: t.height,
		background: t.background,
		picked: e.selectedId,
		selection: n,
		colours: e.colours,
		canUndo: e.history.canUndo,
		canRedo: e.history.canRedo,
		layers: [...t.layers].reverse().map((t) => {
			let n = Zt(t, e.store), r = {
				id: t.id,
				name: t.name,
				kind: t.kind,
				visible: t.visible,
				locked: t.locked,
				opacity: t.opacity,
				blend: t.blend,
				x: Math.round(t.transform.x * 10) / 10,
				y: Math.round(t.transform.y * 10) / 10,
				width: Math.round(n.width * Math.abs(t.transform.scaleX)),
				height: Math.round(n.height * Math.abs(t.transform.scaleY)),
				rotation: Math.round(t.transform.rotation * 180 / Math.PI * 10) / 10,
				mask: t.mask ? t.maskOff ? "off" : "on" : null
			};
			return t.kind === "text" ? {
				...r,
				text: t.text,
				font: t.font,
				size: t.size,
				color: t.color
			} : t.kind === "shape" ? {
				...r,
				shape: t.shape.type,
				fill: t.fill,
				stroke: t.stroke,
				strokeWidth: t.strokeWidth
			} : r;
		})
	};
}
var Q = (e, t, n, r, i, a = {}) => ({
	name: t,
	label: e,
	type: "number",
	min: n,
	max: r,
	default: i,
	...a
}), $ = (e, t, n, r = {}) => ({
	name: t,
	label: e,
	type: "color",
	default: n,
	...r
}), Tr = (e) => e.colours.main, Er = [
	{
		id: "undo",
		label: "Undo",
		menu: "Edit",
		keys: "Ctrl Z",
		description: "Undo the last change.",
		blocked: (e) => e.history.canUndo ? null : "Nothing to undo.",
		run: (e) => void e.history.undo()
	},
	{
		id: "redo",
		label: "Redo",
		menu: "Edit",
		keys: "Ctrl Shift Z",
		description: "Redo what was undone.",
		blocked: (e) => e.history.canRedo ? null : "Nothing to redo.",
		run: (e) => void e.history.redo()
	},
	{
		id: "new_canvas",
		label: "New canvas…",
		menu: "File",
		description: "Start a new, empty design (replaces the open one).",
		params: [
			Q("Width", "width", 1, 16384, 2e3, {
				type: "integer",
				unit: "px"
			}),
			Q("Height", "height", 1, 16384, 2e3, {
				type: "integer",
				unit: "px"
			}),
			$("Canvas colour", "background", "#ffffff", {
				nullable: !0,
				description: "null for transparent."
			})
		],
		run: (e, t) => e.replace(Rt(t.width, t.height, t.background))
	},
	{
		id: "save_design",
		label: "Save design (.gleam)",
		menu: "File",
		keys: "Ctrl S",
		description: "The design as a .gleam file (one JSON file with its pictures), to open and keep editing later.",
		run: async (e) => {
			let t = lr(e.doc, () => "");
			for (let n of Object.keys(t.pixels)) t.pixels[n] = await kr(e, n);
			return { file: {
				name: "design.gleam",
				type: "application/json",
				data: new TextEncoder().encode(JSON.stringify(t))
			} };
		}
	},
	{
		id: "export",
		label: "Export…",
		menu: "File",
		description: "The finished picture as PNG or JPEG, or as SVG with shapes and text kept as vectors.",
		params: [{
			name: "format",
			type: "enum",
			label: "Format",
			options: [
				"png",
				"jpeg",
				"svg"
			],
			default: "png"
		}, Q("Quality (JPEG)", "quality", .1, 1, .92, { step: .01 })],
		run: async (e, t) => {
			if (t.format === "svg") {
				let t = /* @__PURE__ */ new Map();
				for (let n of e.doc.layers) n.kind === "raster" && t.set(n.pixels, await kr(e, n.pixels)), n.mask && t.set(n.mask, await kr(e, n.mask));
				return { file: {
					name: "design.svg",
					type: "image/svg+xml",
					data: new TextEncoder().encode(or(e.doc, (e) => t.get(e)))
				} };
			}
			let n = t.format === "jpeg" && !e.doc.background ? {
				...e.doc,
				background: "#ffffff"
			} : e.doc, r = await e.backend.encode(e.flatten(n), t.format, t.quality);
			return { file: {
				name: `design.${t.format === "jpeg" ? "jpg" : "png"}`,
				type: `image/${t.format}`,
				data: r
			} };
		}
	},
	{
		id: "place_image",
		label: "Place a picture…",
		menu: "File",
		description: "Put a picture on a new layer, fitted inside the canvas and centred unless x and y are given.",
		params: [
			{
				name: "image",
				type: "image",
				label: "Picture",
				description: "The picture (a file path from the command line or MCP)."
			},
			{
				name: "name",
				type: "string",
				label: "Layer name",
				default: "Picture"
			},
			Q("X", "x", -1e5, 1e5, void 0, { optional: !0 }),
			Q("Y", "y", -1e5, 1e5, void 0, { optional: !0 }),
			Q("Scale", "scale", .001, 100, void 0, {
				optional: !0,
				description: "Size as a fraction (1 = the picture’s own pixels); fits the canvas when left out."
			})
		],
		run: (e, t) => {
			let n = t.image, r = e.doc, i = t.scale ?? Math.min(1, r.width / n.width, r.height / n.height), a = Bt(t.name, e.store.add(n), {
				x: t.x ?? (r.width - n.width * i) / 2,
				y: t.y ?? (r.height - n.height * i) / 2,
				scaleX: i,
				scaleY: i
			});
			return e.commit(K(r, a, e.selectedId ?? void 0), "Place picture"), e.selectedId = a.id, { data: { id: a.id } };
		}
	},
	{
		id: "place_model",
		label: "Place a 3D picture",
		description: "Put a picture drawn in 3D mode on a new layer, with the 3D design it came from (JSON), so the layer can be opened in 3D mode and drawn again.",
		params: [
			{
				name: "image",
				type: "image",
				label: "Picture",
				description: "The picture 3D mode drew (a file path from the command line or MCP)."
			},
			{
				name: "model",
				type: "string",
				label: "3D design",
				description: "The 3D design as JSON."
			},
			{
				name: "name",
				type: "string",
				label: "Layer name",
				default: "3D object"
			}
		],
		run: (e, t) => {
			let n = fr(t.model), r = t.image, i = e.doc, a = Math.min(1, i.width / r.width, i.height / r.height), o = {
				...Bt(t.name, e.store.add(r), {
					x: (i.width - r.width * a) / 2,
					y: (i.height - r.height * a) / 2,
					scaleX: a,
					scaleY: a
				}),
				model3d: n
			};
			return e.commit(K(i, o, e.selectedId ?? void 0), "Place 3D object"), e.selectedId = o.id, { data: { id: o.id } };
		}
	},
	{
		id: "redraw_model",
		label: "Redraw a 3D layer",
		description: "Give a 3D layer its new picture and design after a change in 3D mode. The layer keeps its place, size on the canvas, mask and settings.",
		params: [
			X,
			{
				name: "image",
				type: "image",
				label: "Picture",
				description: "The new picture from 3D mode."
			},
			{
				name: "model",
				type: "string",
				label: "3D design",
				description: "The changed 3D design as JSON."
			}
		],
		run: (e, t) => {
			let n = Z(e, t.layer);
			if (n.kind !== "raster" || n.model3d === void 0) throw new Y(`"${n.name}" is not a 3D layer.`);
			let r = fr(t.model), i = t.image, a = e.store.get(n.pixels), o = a ? a.width * n.transform.scaleX / i.width : 1;
			e.commit(q(e.doc, n.id, {
				pixels: e.store.add(i),
				model3d: r,
				transform: {
					...n.transform,
					scaleX: o,
					scaleY: o * (n.transform.scaleY / n.transform.scaleX)
				}
			}), "Redraw 3D object");
		}
	},
	{
		id: "describe",
		label: "Describe the design",
		description: "The canvas size, selection, colours and every layer (top first) with its id, kind, position and settings.",
		run: (e) => ({ data: wr(e) })
	},
	{
		id: "add_layer",
		label: "New picture layer",
		menu: "Layer",
		keys: "Ctrl Shift N",
		description: "An empty picture layer the size of the canvas, above the picked layer.",
		params: [{
			name: "name",
			type: "string",
			label: "Name",
			default: "Layer"
		}],
		run: (e, t) => {
			let n = Bt(t.name, e.store.add(Pt(e.doc.width, e.doc.height)));
			return e.commit(K(e.doc, n, e.selectedId ?? void 0), "New layer"), e.selectedId = n.id, { data: { id: n.id } };
		}
	},
	{
		id: "add_text",
		label: "Add text",
		description: "A text layer. x and y are its top-left corner (or its centre or right edge, by alignment).",
		params: [
			{
				name: "text",
				type: "string",
				label: "Text"
			},
			Q("X", "x", -1e5, 1e5, 0),
			Q("Y", "y", -1e5, 1e5, 0),
			Q("Size", "size", 1, 2e3, 72, { unit: "px" }),
			{
				name: "font",
				type: "string",
				label: "Font",
				default: "system-ui, sans-serif",
				description: "A CSS font family list."
			},
			Q("Weight", "weight", 100, 900, 700, { type: "integer" }),
			$("Colour", "color", Tr),
			{
				name: "align",
				type: "enum",
				label: "Align",
				options: [
					"left",
					"center",
					"right"
				],
				default: "left"
			},
			{
				name: "italic",
				type: "boolean",
				label: "Italic",
				default: !1
			}
		],
		run: (e, t) => {
			let n = Ht(t.text, {
				size: t.size,
				font: t.font,
				weight: t.weight,
				color: t.color,
				align: t.align,
				italic: t.italic
			}, {
				x: t.x,
				y: t.y
			}), r = {
				...n,
				box: xr(e, n)
			};
			return e.commit(K(e.doc, r, e.selectedId ?? void 0), "Add text"), e.selectedId = r.id, { data: { id: r.id } };
		}
	},
	{
		id: "add_shape",
		label: "Add shape",
		description: "A rectangle, ellipse or line layer that stays an editable shape. For a line, width and height are how far it runs.",
		params: [
			{
				name: "shape",
				type: "enum",
				label: "Shape",
				options: [
					"rect",
					"ellipse",
					"line"
				],
				default: "rect"
			},
			Q("X", "x", -1e5, 1e5, 0),
			Q("Y", "y", -1e5, 1e5, 0),
			Q("Width", "width", -1e5, 1e5, 400),
			Q("Height", "height", -1e5, 1e5, 300),
			Q("Corner radius", "radius", 0, 1e5, 0),
			$("Fill", "fill", Tr, { nullable: !0 }),
			$("Outline", "stroke", null, { nullable: !0 }),
			Q("Outline width", "strokeWidth", 0, 1e3, 4)
		],
		run: (e, t) => {
			let n = t.shape === "line" ? {
				type: "line",
				x2: t.width,
				y2: t.height
			} : t.shape === "ellipse" ? {
				type: "ellipse",
				width: Math.abs(t.width),
				height: Math.abs(t.height)
			} : {
				type: "rect",
				width: Math.abs(t.width),
				height: Math.abs(t.height),
				radius: t.radius
			}, r = t.shape === "line" ? {
				fill: null,
				stroke: t.stroke ?? t.fill ?? e.colours.main,
				strokeWidth: t.strokeWidth || 4
			} : {
				fill: t.fill,
				stroke: t.stroke,
				strokeWidth: t.strokeWidth
			}, i = t.shape === "rect" ? "Rectangle" : t.shape === "ellipse" ? "Ellipse" : "Line", a = Vt(i, n, r, {
				x: t.x,
				y: t.y
			});
			return e.commit(K(e.doc, a, e.selectedId ?? void 0), `Draw ${i.toLowerCase()}`), e.selectedId = a.id, { data: { id: a.id } };
		}
	},
	{
		id: "add_path",
		label: "Add path",
		description: "A path through points ([[x, y], ...] in canvas pixels), straight between them, open or closed.",
		params: [
			{
				name: "points",
				type: "points",
				label: "Points"
			},
			{
				name: "closed",
				type: "boolean",
				label: "Closed",
				default: !0
			},
			$("Fill", "fill", Tr, { nullable: !0 }),
			$("Outline", "stroke", null, { nullable: !0 }),
			Q("Outline width", "strokeWidth", 0, 1e3, 4)
		],
		run: (e, t) => {
			let n = Cr(t.points);
			if (n.length < 2) throw new Y("A path needs at least two points.");
			let r = Vt("Path", {
				type: "path",
				path: {
					points: n,
					closed: t.closed
				}
			}, t.closed ? {
				fill: t.fill,
				stroke: t.stroke,
				strokeWidth: t.strokeWidth
			} : {
				fill: null,
				stroke: t.stroke ?? t.fill ?? e.colours.main,
				strokeWidth: t.strokeWidth || 4
			});
			return e.commit(K(e.doc, r, e.selectedId ?? void 0), "Draw path"), e.selectedId = r.id, { data: { id: r.id } };
		}
	},
	{
		id: "pick_layer",
		label: "Pick a layer",
		description: "Make a layer the one later commands act on.",
		params: [{
			...X,
			optional: !1
		}],
		run: (e, t) => {
			e.selectedId = Z(e, t.layer).id;
		}
	},
	{
		id: "drop_shadow",
		label: "Drop shadow…",
		menu: "Layer",
		description: "A soft shadow under the layer, cast away from a light at the given angle; it follows the layer as it changes. Opacity 0 removes it.",
		preview: !0,
		params: [
			Q("Opacity", "opacity", 0, 100, (e) => Math.round((e.selected?.style?.shadow?.opacity ?? .5) * 100), {
				type: "integer",
				unit: "%"
			}),
			Q("Angle", "angle", -180, 180, (e) => e.selected?.style?.shadow?.angle ?? 120, {
				type: "integer",
				unit: "°"
			}),
			Q("Distance", "distance", 0, 500, (e) => e.selected?.style?.shadow?.distance ?? 12, {
				type: "integer",
				unit: "px"
			}),
			Q("Softness", "blur", 0, 250, (e) => e.selected?.style?.shadow?.blur ?? 18, {
				type: "integer",
				unit: "px"
			}),
			$("Colour", "color", (e) => e.selected?.style?.shadow?.color ?? "#000000"),
			X
		],
		blocked: (e) => e.selected ? null : "Pick a layer.",
		run: (e, t) => {
			let n = Z(e, t.layer), r = t.opacity > 0 ? {
				color: t.color,
				opacity: t.opacity / 100,
				angle: t.angle,
				distance: t.distance,
				blur: t.blur
			} : void 0;
			e.commit(q(e.doc, n.id, { style: {
				...n.style,
				shadow: r
			} }), r ? "Drop shadow" : "Remove drop shadow");
		}
	},
	{
		id: "outer_glow",
		label: "Outer glow…",
		menu: "Layer",
		description: "A soft halo all round the layer, in the main colour unless one is given. Opacity 0 removes it.",
		preview: !0,
		params: [
			Q("Opacity", "opacity", 0, 100, (e) => Math.round((e.selected?.style?.glow?.opacity ?? .75) * 100), {
				type: "integer",
				unit: "%"
			}),
			Q("Size", "size", 1, 250, (e) => e.selected?.style?.glow?.size ?? 24, {
				type: "integer",
				unit: "px"
			}),
			$("Colour", "color", (e) => e.selected?.style?.glow?.color ?? e.colours.main),
			X
		],
		blocked: (e) => e.selected ? null : "Pick a layer.",
		run: (e, t) => {
			let n = Z(e, t.layer), r = t.opacity > 0 ? {
				color: t.color,
				opacity: t.opacity / 100,
				size: t.size
			} : void 0;
			e.commit(q(e.doc, n.id, { style: {
				...n.style,
				glow: r
			} }), r ? "Outer glow" : "Remove outer glow");
		}
	},
	{
		id: "stroke_outline",
		label: "Stroke…",
		menu: "Layer",
		description: "A line round the outside of the layer’s shape (its see-through edge), in the main colour unless one is given. Width 0 removes it.",
		preview: !0,
		params: [
			Q("Width", "width", 0, 100, (e) => e.selected?.style?.stroke?.width ?? 6, {
				type: "integer",
				unit: "px"
			}),
			$("Colour", "color", (e) => e.selected?.style?.stroke?.color ?? e.colours.main),
			X
		],
		blocked: (e) => e.selected ? null : "Pick a layer.",
		run: (e, t) => {
			let n = Z(e, t.layer), r = t.width > 0 ? {
				color: t.color,
				width: t.width
			} : void 0;
			e.commit(q(e.doc, n.id, { style: {
				...n.style,
				stroke: r
			} }), r ? "Stroke" : "Remove stroke");
		}
	},
	{
		id: "clear_style",
		label: "Clear layer style",
		menu: "Layer",
		description: "Take the drop shadow, glow and stroke off the layer.",
		blocked: (e) => e.selected?.style ? null : "The picked layer has no style.",
		params: [X],
		run: (e, t) => {
			let n = Z(e, t.layer);
			e.commit(q(e.doc, n.id, { style: void 0 }), "Clear layer style");
		}
	},
	{
		id: "set_layer",
		label: "Change a layer",
		description: "Change any of a layer’s settings: name, visible, locked, opacity (0-1), blend, x, y, scaleX, scaleY, rotation (degrees); fill, stroke, strokeWidth, radius (shapes); text, size, font, weight, color, align, italic (text).",
		params: [
			X,
			{
				name: "name",
				type: "string",
				label: "Name",
				optional: !0
			},
			{
				name: "visible",
				type: "boolean",
				label: "Visible",
				optional: !0
			},
			{
				name: "locked",
				type: "boolean",
				label: "Locked",
				optional: !0
			},
			Q("Opacity", "opacity", 0, 1, void 0, {
				optional: !0,
				step: .01
			}),
			{
				name: "blend",
				type: "enum",
				label: "Blend",
				options: At.map((e) => e.id),
				optional: !0
			},
			Q("X", "x", -1e5, 1e5, void 0, { optional: !0 }),
			Q("Y", "y", -1e5, 1e5, void 0, { optional: !0 }),
			Q("Scale across", "scaleX", -100, 100, void 0, { optional: !0 }),
			Q("Scale down", "scaleY", -100, 100, void 0, { optional: !0 }),
			Q("Turn", "rotation", -3600, 3600, void 0, {
				optional: !0,
				unit: "°"
			}),
			$("Fill", "fill", void 0, {
				optional: !0,
				nullable: !0
			}),
			$("Outline", "stroke", void 0, {
				optional: !0,
				nullable: !0
			}),
			Q("Outline width", "strokeWidth", 0, 1e3, void 0, { optional: !0 }),
			Q("Corner radius", "radius", 0, 1e5, void 0, { optional: !0 }),
			{
				name: "text",
				type: "string",
				label: "Text",
				optional: !0
			},
			Q("Size", "size", 1, 2e3, void 0, { optional: !0 }),
			{
				name: "font",
				type: "string",
				label: "Font",
				optional: !0
			},
			Q("Weight", "weight", 100, 900, void 0, {
				optional: !0,
				type: "integer"
			}),
			$("Text colour", "color", void 0, { optional: !0 }),
			{
				name: "align",
				type: "enum",
				label: "Align",
				options: [
					"left",
					"center",
					"right"
				],
				optional: !0
			},
			{
				name: "italic",
				type: "boolean",
				label: "Italic",
				optional: !0
			}
		],
		run: (e, t) => {
			let n = Z(e, t.layer);
			if (n.locked && t.locked !== !1) throw new Y(`"${n.name}" is locked.`);
			let r = {};
			for (let e of [
				"name",
				"visible",
				"locked",
				"opacity",
				"blend"
			]) t[e] !== void 0 && (r[e] = t[e]);
			let i = { ...n.transform };
			if (t.x !== void 0 && (i.x = t.x), t.y !== void 0 && (i.y = t.y), t.scaleX !== void 0 && (i.scaleX = t.scaleX || .001), t.scaleY !== void 0 && (i.scaleY = t.scaleY || .001), t.rotation !== void 0 && (i.rotation = t.rotation * Math.PI / 180), r.transform = i, n.kind === "shape") {
				for (let e of [
					"fill",
					"stroke",
					"strokeWidth"
				]) t[e] !== void 0 && (r[e] = t[e]);
				t.radius !== void 0 && n.shape.type === "rect" && (r.shape = {
					...n.shape,
					radius: t.radius
				});
			}
			if (n.kind === "text") {
				for (let e of [
					"text",
					"size",
					"font",
					"weight",
					"color",
					"align",
					"italic"
				]) t[e] !== void 0 && (r[e] = t[e]);
				r.box = xr(e, {
					...n,
					...r
				});
			}
			e.commit(q(e.doc, n.id, r), "Change layer");
		}
	},
	{
		id: "duplicate_layer",
		label: "Duplicate layer",
		menu: "Layer",
		keys: "Ctrl J",
		description: "A copy of the layer just above it.",
		params: [X],
		blocked: (e) => e.selected ? null : "Pick a layer first.",
		run: (e, t) => {
			let n = Kt(e.doc, e.store, Z(e, t.layer).id);
			return e.commit(n.doc, "Duplicate"), e.selectedId = n.id, { data: { id: n.id } };
		}
	},
	{
		id: "delete_layer",
		label: "Delete layer",
		menu: "Layer",
		description: "Remove the layer.",
		params: [X],
		blocked: (e) => e.selected ? null : "Pick a layer first.",
		run: (e, t) => {
			let n = Z(e, t.layer), r = e.doc.layers.indexOf(n), i = Wt(e.doc, n.id);
			e.commit(i, "Delete layer"), e.selectedId === n.id && (e.selectedId = i.layers[Math.max(0, r - 1)]?.id ?? null);
		}
	},
	{
		id: "arrange_layer",
		label: "Arrange layer",
		description: "Move the layer in the stack: front, forward, backward or back.",
		params: [X, {
			name: "to",
			type: "enum",
			label: "To",
			options: [
				"front",
				"forward",
				"backward",
				"back"
			],
			default: "forward"
		}],
		run: (e, t) => {
			let n = {
				front: Infinity,
				forward: 1,
				backward: -1,
				back: -Infinity
			}[t.to];
			e.commit(Gt(e.doc, Z(e, t.layer).id, n), "Arrange");
		}
	},
	...[
		[
			"front",
			"Bring to front",
			"Ctrl Shift ]"
		],
		[
			"forward",
			"Bring forward",
			"Ctrl ]"
		],
		[
			"backward",
			"Send backward",
			"Ctrl ["
		],
		[
			"back",
			"Send to back",
			"Ctrl Shift ["
		]
	].map(([e, t, n]) => ({
		id: `arrange_${e}`,
		label: t,
		menu: "Layer",
		keys: n,
		description: `${t} (the picked layer).`,
		blocked: (e) => e.selected ? null : "Pick a layer first.",
		run: (n) => void n.commit(Gt(n.doc, n.selectedId, {
			front: Infinity,
			forward: 1,
			backward: -1,
			back: -Infinity
		}[e]), t)
	})),
	{
		id: "merge_down",
		label: "Merge down",
		menu: "Layer",
		keys: "Ctrl E",
		description: "Combine the layer with the one under it into one picture layer.",
		params: [X],
		blocked: (e) => e.selected && e.doc.layers.indexOf(e.selected) > 0 ? null : "Pick a layer that has one under it.",
		run: (e, t) => {
			let n = Z(e, t.layer), r = e.doc.layers.indexOf(n);
			if (r < 1) throw new Y("There is no layer under it to merge with.");
			let i = e.doc.layers[r - 1], a = e.backend.surface(e.doc.width, e.doc.height);
			nr(a.ctx, e.doc, i, e.host()), nr(a.ctx, e.doc, n, e.host());
			let o = Bt(i.name, e.store.add(a.read())), s = Wt(e.doc, n.id);
			e.commit({
				...s,
				layers: s.layers.map((e) => e.id === i.id ? o : e)
			}, "Merge down"), e.selectedId = o.id;
		}
	},
	{
		id: "flatten",
		label: "Flatten into one layer",
		menu: "Layer",
		description: "Every layer drawn into one picture layer (the canvas colour stays separate).",
		blocked: (e) => e.doc.layers.length > 1 ? null : "There is only one layer.",
		run: (e) => {
			let t = Bt("Flattened", e.store.add(e.flatten(e.doc, !1)));
			e.commit({
				...e.doc,
				layers: [t]
			}, "Flatten"), e.selectedId = t.id;
		}
	},
	{
		id: "rasterize",
		label: "Rasterize (turn into pixels)",
		menu: "Layer",
		description: "Turn a shape or text layer into a picture layer, to paint on it.",
		params: [X],
		blocked: (e) => e.selected && e.selected.kind !== "raster" ? null : "Pick a shape or text layer.",
		run: (e, t) => {
			let n = Z(e, t.layer);
			if (n.kind === "raster") return { message: "It is already a picture layer." };
			let r = {
				...Bt(n.name, e.store.add(br(e, n))),
				opacity: n.opacity,
				blend: n.blend,
				mask: n.mask,
				visible: n.visible
			};
			e.commit({
				...e.doc,
				layers: e.doc.layers.map((e) => e.id === n.id ? r : e)
			}, "Rasterize"), e.selectedId = r.id;
		}
	},
	{
		id: "flip_layer",
		label: "Flip layer",
		description: "Mirror the layer left to right (across) or upside down (down), about its centre.",
		params: [X, {
			name: "axis",
			type: "enum",
			label: "Axis",
			options: ["across", "down"],
			default: "across"
		}],
		run: (e, t) => {
			let n = mr(Z(e, t.layer)), r = Zt(n, e.store), i = n.transform, a = t.axis === "across" ? {
				...i,
				scaleX: -i.scaleX
			} : {
				...i,
				scaleY: -i.scaleY
			};
			e.commit(q(e.doc, n.id, { transform: Sr(i, a, {
				x: r.x + r.width / 2,
				y: r.y + r.height / 2
			}) }), "Flip");
		}
	},
	...[["across", "Flip layer left to right"], ["down", "Flip layer upside down"]].map(([e, t]) => ({
		id: `flip_${e}`,
		label: t,
		menu: "Layer",
		description: `${t} (the picked layer).`,
		blocked: (e) => e.selected ? null : "Pick a layer first.",
		run: (t) => jr(t, "flip_layer", { axis: e })
	})),
	{
		id: "add_mask",
		label: "Add mask",
		menu: "Layer",
		description: "A mask on the layer: it shows what is selected (or everything when nothing is). Paint on it to hide and show parts.",
		params: [X],
		blocked: (e) => e.selected && !e.selected.mask ? null : e.selected ? "It already has a mask." : "Pick a layer first.",
		run: (e, t) => {
			let n = Z(e, t.layer);
			if (n.mask) throw new Y(`"${n.name}" already has a mask.`);
			let r = Pt(e.doc.width, e.doc.height);
			for (let t = 0; t < e.doc.width * e.doc.height; t++) r.data[t * 4 + 3] = e.selection ? e.selection.mask[t] : 255;
			e.commit(q(e.doc, n.id, {
				mask: e.store.add(r, "mask"),
				maskOff: !1
			}), "Add mask");
		}
	},
	{
		id: "toggle_mask",
		label: "Switch mask off/on",
		menu: "Layer",
		description: "See the layer without its mask, or with it again.",
		params: [X],
		blocked: (e) => e.selected?.mask ? null : "The layer has no mask.",
		run: (e, t) => {
			let n = Z(e, t.layer);
			if (!n.mask) throw new Y(`"${n.name}" has no mask.`);
			e.commit(q(e.doc, n.id, { maskOff: !n.maskOff }), "Switch mask");
		}
	},
	{
		id: "apply_mask",
		label: "Apply mask to pixels",
		menu: "Layer",
		description: "Make what the mask hides transparent for good, and remove the mask.",
		params: [X],
		blocked: (e) => e.selected?.kind === "raster" && e.selected.mask ? null : "Pick a picture layer with a mask.",
		run: (e, t) => {
			let n = hr(Z(e, t.layer));
			if (!n.mask) throw new Y(`"${n.name}" has no mask.`);
			let r = e.backend.surface(e.doc.width, e.doc.height);
			nr(r.ctx, e.doc, {
				...n,
				opacity: 1,
				blend: "normal"
			}, e.host());
			let i = {
				...n,
				pixels: e.store.add(r.read()),
				mask: void 0,
				transform: {
					x: 0,
					y: 0,
					scaleX: 1,
					scaleY: 1,
					rotation: 0
				}
			};
			e.commit({
				...e.doc,
				layers: e.doc.layers.map((e) => e.id === n.id ? i : e)
			}, "Apply mask");
		}
	},
	{
		id: "delete_mask",
		label: "Delete mask",
		menu: "Layer",
		description: "Remove the layer’s mask (the layer shows fully again).",
		params: [X],
		blocked: (e) => e.selected?.mask ? null : "The layer has no mask.",
		run: (e, t) => void e.commit(q(e.doc, Z(e, t.layer).id, { mask: void 0 }), "Delete mask")
	},
	{
		id: "select_all",
		label: "Select all",
		menu: "Select",
		keys: "Ctrl A",
		description: "Select the whole canvas.",
		run: (e) => void (e.selection = sn(e.doc.width, e.doc.height))
	},
	{
		id: "deselect",
		label: "Deselect",
		menu: "Select",
		keys: "Ctrl D",
		description: "Select nothing.",
		run: (e) => void (e.selection = null)
	},
	{
		id: "invert_selection",
		label: "Invert selection",
		menu: "Select",
		keys: "Ctrl Shift I",
		description: "Select what is not selected.",
		run: (e) => yr(e, fn(e.selection ?? {
			width: e.doc.width,
			height: e.doc.height,
			mask: new Uint8Array(e.doc.width * e.doc.height)
		}))
	},
	{
		id: "select_rect",
		label: "Select a box",
		description: "Select a rectangle of the canvas.",
		params: [
			Q("X", "x", -1e5, 1e5, 0),
			Q("Y", "y", -1e5, 1e5, 0),
			Q("Width", "width", 0, 1e5, 100),
			Q("Height", "height", 0, 1e5, 100),
			pr
		],
		run: (e, t) => yr(e, dn(e.selection, cn(e.doc.width, e.doc.height, t), t.mode))
	},
	{
		id: "select_ellipse",
		label: "Select an oval",
		description: "Select the oval inside a box.",
		params: [
			Q("X", "x", -1e5, 1e5, 0),
			Q("Y", "y", -1e5, 1e5, 0),
			Q("Width", "width", 0, 1e5, 100),
			Q("Height", "height", 0, 1e5, 100),
			pr
		],
		run: (e, t) => yr(e, dn(e.selection, ln(e.doc.width, e.doc.height, t), t.mode))
	},
	{
		id: "select_polygon",
		label: "Select an outline",
		description: "Select inside an outline through points ([[x, y], ...]).",
		params: [{
			name: "points",
			type: "points",
			label: "Points"
		}, pr],
		run: (e, t) => yr(e, dn(e.selection, un(e.doc.width, e.doc.height, Cr(t.points)), t.mode))
	},
	{
		id: "magic_wand",
		label: "Select by colour",
		description: "Select the colour at a point, as the canvas looks: the touching patch, or every pixel of that colour.",
		params: [
			Q("X", "x", 0, 1e5, 0),
			Q("Y", "y", 0, 1e5, 0),
			Q("Tolerance", "tolerance", 0, 255, 32, { type: "integer" }),
			{
				name: "contiguous",
				type: "boolean",
				label: "Only touching pixels",
				default: !0
			},
			pr
		],
		run: (e, t) => yr(e, dn(e.selection, hn(e.flatten(), t, t.tolerance, t.contiguous), t.mode))
	},
	{
		id: "feather_selection",
		label: "Soften selection edge…",
		menu: "Select",
		description: "Blur the selection’s edge so edits fade out.",
		params: [Q("Softness", "radius", 1, 200, 8, {
			unit: "px",
			type: "integer"
		})],
		blocked: (e) => e.selection ? null : "Nothing is selected.",
		run: (e, t) => void (e.selection = mn(e.selection, t.radius))
	},
	{
		id: "select_layer_pixels",
		label: "Select the layer’s pixels",
		menu: "Select",
		description: "Select what the layer covers (its non-transparent pixels).",
		params: [X],
		blocked: (e) => e.selected ? null : "Pick a layer first.",
		run: (e, t) => {
			let n = br(e, Z(e, t.layer)), r = new Uint8Array(e.doc.width * e.doc.height);
			for (let e = 0; e < r.length; e++) r[e] = n.data[e * 4 + 3];
			return yr(e, {
				width: e.doc.width,
				height: e.doc.height,
				mask: r
			});
		}
	},
	{
		id: "fill",
		label: "Fill with main colour",
		menu: "Edit",
		keys: "Alt Delete",
		description: "Fill the selection (or the whole layer) of a picture layer with a colour.",
		params: [$("Colour", "color", Tr), X],
		run: (e, t) => {
			let n = _r(e, t.layer), r = vr(e, n.doc, n.layer);
			Dn(r.working, _n(t.color), gr(e, r.layer)), e.commit(r.doc, "Fill");
		}
	},
	{
		id: "clear",
		label: "Clear selected pixels",
		menu: "Edit",
		keys: "Delete",
		description: "Make the selected pixels of a picture layer transparent.",
		params: [X],
		blocked: (e) => e.selection ? e.selected?.kind === "raster" ? null : "Pick a picture layer." : "Select something first.",
		run: (e, t) => {
			if (!e.selection) throw new Y("Select something first.");
			let n = hr(Z(e, t.layer)), r = vr(e, e.doc, n);
			On(r.working, gr(e, r.layer)), e.commit(r.doc, "Clear");
		}
	},
	{
		id: "copy",
		label: "Copy",
		menu: "Edit",
		keys: "Ctrl C",
		description: "Copy the selected pixels of a picture layer (Paste puts them on a new layer).",
		params: [X],
		blocked: (e) => e.selected?.kind === "raster" ? null : "Pick a picture layer.",
		run: (e, t) => {
			let n = hr(Z(e, t.layer));
			return e.clipboard = {
				pixels: kn(e.store.get(n.pixels), gr(e, n)),
				transform: n.transform
			}, { message: "Copied. Paste puts it on a new layer." };
		}
	},
	{
		id: "cut",
		label: "Cut",
		menu: "Edit",
		keys: "Ctrl X",
		description: "Copy the selected pixels and clear them.",
		params: [X],
		blocked: (e) => e.selected?.kind === "raster" ? null : "Pick a picture layer.",
		run: (e, t) => {
			let n = hr(Z(e, t.layer)), r = gr(e, n);
			e.clipboard = {
				pixels: kn(e.store.get(n.pixels), r),
				transform: n.transform
			};
			let i = vr(e, e.doc, n);
			return On(i.working, r), e.commit(i.doc, "Cut"), { message: "Cut. Paste puts it on a new layer." };
		}
	},
	{
		id: "paste",
		label: "Paste as new layer",
		menu: "Edit",
		keys: "Ctrl V",
		description: "What was copied, on a new layer where it came from.",
		blocked: (e) => e.clipboard ? null : "Nothing has been copied.",
		run: (e) => {
			if (!e.clipboard) throw new Y("Nothing has been copied.");
			let t = Bt("Pasted", e.store.add(Ft(e.clipboard.pixels)), e.clipboard.transform);
			e.commit(K(e.doc, t, e.selectedId ?? void 0), "Paste"), e.selectedId = t.id;
		}
	},
	{
		id: "brush_stroke",
		label: "Paint a stroke",
		description: "Paint (or erase) along points ([[x, y], ...] in canvas pixels) on a picture layer, inside the selection.",
		params: [
			{
				name: "points",
				type: "points",
				label: "Points"
			},
			Q("Size", "size", 1, 2e3, 24, { unit: "px" }),
			Q("Hardness", "hardness", 0, 1, .6, { step: .01 }),
			Q("Flow", "flow", .01, 1, 1, { step: .01 }),
			$("Colour", "color", Tr),
			{
				name: "erase",
				type: "boolean",
				label: "Erase",
				default: !1
			},
			X
		],
		run: (e, t) => {
			let n = _r(e, t.layer), r = vr(e, n.doc, n.layer), i = gr(e, r.layer), a = bn(), o = (e) => {
				let t = qt(r.layer.transform), n = t.a * t.d - t.b * t.c || 1, i = e.x - t.e, a = e.y - t.f;
				return {
					x: (t.d * i - t.c * a) / n,
					y: (-t.b * i + t.a * a) / n
				};
			};
			for (let e of Cr(t.points)) wn(r.working, a, o(e), {
				size: t.size,
				hardness: t.hardness,
				flow: t.flow,
				color: _n(t.color),
				mode: t.erase ? "erase" : "paint"
			}, i);
			e.commit(r.doc, t.erase ? "Erase" : "Brush");
		}
	},
	{
		id: "flood_fill",
		label: "Fill a patch",
		description: "Fill the patch of similar colour around a point of a picture layer (paint bucket).",
		params: [
			Q("X", "x", -1e5, 1e5, 0),
			Q("Y", "y", -1e5, 1e5, 0),
			$("Colour", "color", Tr),
			Q("Tolerance", "tolerance", 0, 255, 32, { type: "integer" }),
			{
				name: "contiguous",
				type: "boolean",
				label: "Only touching pixels",
				default: !0
			},
			X
		],
		run: (e, t) => {
			let n = _r(e, t.layer), r = vr(e, n.doc, n.layer), i = qt(r.layer.transform), a = i.a * i.d - i.b * i.c || 1, o = t.x - i.e, s = t.y - i.f;
			Tn(r.working, {
				x: (i.d * o - i.c * s) / a,
				y: (-i.b * o + i.a * s) / a
			}, _n(t.color), t.tolerance, t.contiguous, gr(e, r.layer)), e.commit(r.doc, "Fill");
		}
	},
	{
		id: "gradient",
		label: "Gradient",
		description: "A straight gradient on a picture layer from one point and colour to another, inside the selection.",
		params: [
			Q("From X", "x1", -1e5, 1e5, 0),
			Q("From Y", "y1", -1e5, 1e5, 0),
			Q("To X", "x2", -1e5, 1e5, (e) => e.doc.width),
			Q("To Y", "y2", -1e5, 1e5, 0),
			$("From colour", "from", Tr),
			$("To colour", "to", (e) => e.colours.second),
			X
		],
		run: (e, t) => {
			let n = _r(e, t.layer), r = vr(e, n.doc, n.layer), i = qt(r.layer.transform), a = i.a * i.d - i.b * i.c || 1, o = (e, t) => ({
				x: (i.d * (e - i.e) - i.c * (t - i.f)) / a,
				y: (-i.b * (e - i.e) + i.a * (t - i.f)) / a
			});
			An(r.working, o(t.x1, t.y1), o(t.x2, t.y2), _n(t.from), _n(t.to), gr(e, r.layer)), e.commit(r.doc, "Gradient");
		}
	},
	...[
		[
			"brightness_contrast",
			"Brightness and contrast…",
			[Q("Brightness", "brightness", -100, 100, 0, { type: "integer" }), Q("Contrast", "contrast", -100, 100, 0, { type: "integer" })],
			(e, t, n) => In(e, t.brightness, t.contrast, n)
		],
		[
			"hue_saturation",
			"Hue and saturation…",
			[
				Q("Hue", "hue", -180, 180, 0, {
					type: "integer",
					unit: "°"
				}),
				Q("Saturation", "saturation", -100, 100, 0, { type: "integer" }),
				Q("Lightness", "lightness", -100, 100, 0, { type: "integer" })
			],
			(e, t, n) => Ln(e, t.hue, t.saturation, t.lightness, n)
		],
		[
			"blur",
			"Blur…",
			[Q("Radius", "radius", 1, 100, 4, {
				type: "integer",
				unit: "px"
			})],
			(e, t, n) => Gn(e, t.radius, n)
		],
		[
			"sharpen",
			"Sharpen…",
			[Q("Amount", "amount", 0, 3, .8, { step: .05 }), Q("Radius", "radius", 1, 8, 1, {
				type: "integer",
				unit: "px"
			})],
			(e, t, n) => Kn(e, t.amount, t.radius, n)
		],
		[
			"levels",
			"Levels…",
			[
				Q("Input black", "inBlack", 0, 254, 0, { type: "integer" }),
				Q("Input white", "inWhite", 1, 255, 255, { type: "integer" }),
				Q("Midtones", "gamma", .1, 4, 1, { step: .01 }),
				Q("Output black", "outBlack", 0, 255, 0, { type: "integer" }),
				Q("Output white", "outWhite", 0, 255, 255, { type: "integer" })
			],
			(e, t, n) => zn(e, t.inBlack, t.inWhite, t.gamma, t.outBlack, t.outWhite, n)
		],
		[
			"curves",
			"Curves…",
			[
				Q("Shadows", "shadows", -100, 100, 0, { type: "integer" }),
				Q("Midtones", "midtones", -100, 100, 0, { type: "integer" }),
				Q("Highlights", "highlights", -100, 100, 0, { type: "integer" })
			],
			(e, t, n) => Bn(e, t.shadows, t.midtones, t.highlights, n)
		],
		[
			"vibrance",
			"Vibrance…",
			[Q("Vibrance", "vibrance", -100, 100, 0, { type: "integer" })],
			(e, t, n) => Vn(e, t.vibrance, n)
		],
		[
			"colour_balance",
			"Colour balance…",
			[Q("Warmth", "warmth", -100, 100, 0, { type: "integer" }), Q("Tint", "tint", -100, 100, 0, { type: "integer" })],
			(e, t, n) => Hn(e, t.warmth, t.tint, n)
		],
		[
			"posterize",
			"Posterize…",
			[Q("Levels", "steps", 2, 32, 6, { type: "integer" })],
			(e, t, n) => Un(e, t.steps, n)
		],
		[
			"threshold",
			"Threshold…",
			[Q("Level", "level", 0, 255, 128, { type: "integer" })],
			(e, t, n) => Wn(e, t.level, n)
		],
		[
			"black_and_white",
			"Black and white",
			[],
			(e, t, n) => Fn(e, n)
		],
		[
			"invert_colours",
			"Invert colours",
			[],
			(e, t, n) => Pn(e, n)
		]
	].map(([e, t, n, r]) => ({
		id: e,
		label: t,
		menu: "Adjust",
		keys: e === "invert_colours" ? "Ctrl I" : void 0,
		description: `${t.replace("…", "")} on a picture layer, inside the selection.`,
		params: [...n, X],
		preview: n.length > 0,
		blocked: (e) => e.selected?.kind === "raster" ? null : "Pick a picture layer.",
		run: (e, n) => {
			let i = hr(Z(e, n.layer));
			e.commit(q(e.doc, i.id, { pixels: e.store.add(r(e.store.get(i.pixels), n, gr(e, i))) }), t.replace("…", ""));
		}
	})),
	{
		id: "canvas_size",
		label: "Canvas size…",
		menu: "Canvas",
		description: "Make the canvas a new size; layers stay centred.",
		params: [Q("Width", "width", 1, 16384, (e) => e.doc.width, {
			type: "integer",
			unit: "px"
		}), Q("Height", "height", 1, 16384, (e) => e.doc.height, {
			type: "integer",
			unit: "px"
		})],
		run: (e, t) => {
			let n = (t.width - e.doc.width) / 2, r = (t.height - e.doc.height) / 2;
			e.commit({
				...e.doc,
				width: t.width,
				height: t.height,
				layers: e.doc.layers.map((e) => ({
					...e,
					mask: void 0,
					transform: {
						...e.transform,
						x: e.transform.x + n,
						y: e.transform.y + r
					}
				}))
			}, "Canvas size"), e.selection = null;
		}
	},
	{
		id: "crop",
		label: "Crop canvas",
		description: "Keep only a box of the canvas.",
		params: [
			Q("X", "x", -1e5, 1e5, 0, { type: "integer" }),
			Q("Y", "y", -1e5, 1e5, 0, { type: "integer" }),
			Q("Width", "width", 1, 16384, 100, { type: "integer" }),
			Q("Height", "height", 1, 16384, 100, { type: "integer" })
		],
		run: (e, t) => {
			let n = {
				x: t.x,
				y: t.y,
				width: t.width,
				height: t.height
			}, r = e.doc.layers.map((t) => {
				let r = t.mask;
				if (r) {
					let t = e.store.get(r), i = Pt(n.width, n.height);
					for (let e = 0; e < n.height; e++) for (let r = 0; r < n.width; r++) {
						let a = r + n.x, o = e + n.y;
						i.data[(e * n.width + r) * 4 + 3] = a >= 0 && o >= 0 && a < t.width && o < t.height ? t.data[(o * t.width + a) * 4 + 3] : 0;
					}
					r = e.store.add(i, "mask");
				}
				return {
					...t,
					mask: r,
					transform: {
						...t.transform,
						x: t.transform.x - n.x,
						y: t.transform.y - n.y
					}
				};
			});
			e.commit({
				...e.doc,
				width: n.width,
				height: n.height,
				layers: r
			}, "Crop"), e.selection = null;
		}
	},
	{
		id: "canvas_colour",
		label: "Canvas colour",
		description: "The colour under every layer, or null for transparent.",
		params: [$("Colour", "color", "#ffffff", { nullable: !0 })],
		run: (e, t) => void e.commit({
			...e.doc,
			background: t.color
		}, "Canvas colour")
	},
	{
		id: "set_colours",
		label: "Set colours",
		description: "The main and second colours used by painting, shapes and text when no colour is given.",
		params: [$("Main colour", "main", void 0, { optional: !0 }), $("Second colour", "second", void 0, { optional: !0 })],
		run: (e, t) => {
			t.main && (e.colours = {
				...e.colours,
				main: t.main
			}), t.second && (e.colours = {
				...e.colours,
				second: t.second
			});
		}
	}
], Dr = new Map(Er.map((e) => [e.id, e])), Or = (e) => Dr.get(e);
async function kr(e, t) {
	let n = await e.backend.encode(e.store.get(t), "png"), r = "";
	for (let e = 0; e < n.length; e += 32768) r += String.fromCharCode(...n.subarray(e, e + 32768));
	return `data:image/png;base64,${btoa(r)}`;
}
async function Ar(e, t, n = {}) {
	let r = {}, i = new Set((t.params ?? []).map((e) => e.name));
	for (let e of Object.keys(n)) if (!i.has(e)) throw new Y(`"${t.id}" has no setting called "${e}".`);
	for (let i of t.params ?? []) {
		let a = n[i.name];
		if (a === void 0 && (a = typeof i.default == "function" ? i.default(e) : i.default), a === void 0) {
			if (i.optional) continue;
			throw new Y(`"${t.id}" needs ${i.label.toLowerCase()} (${i.name}).`);
		}
		switch (i.type) {
			case "number":
			case "integer": {
				let e = typeof a == "string" ? Number(a) : a;
				if (typeof e != "number" || !Number.isFinite(e)) throw new Y(`${i.name} must be a number.`);
				let t = Math.min(i.max ?? Infinity, Math.max(i.min ?? -Infinity, e));
				i.type === "integer" && (t = Math.round(t)), a = t;
				break;
			}
			case "boolean":
				if ((a === "true" || a === "false") && (a = a === "true"), typeof a != "boolean") throw new Y(`${i.name} must be true or false.`);
				break;
			case "string":
				a = String(a);
				break;
			case "enum":
				if (!i.options.includes(String(a))) throw new Y(`${i.name} must be one of: ${i.options.join(", ")}.`);
				break;
			case "color":
				if (a === null || a === "null" || a === "none") {
					if (!i.nullable) throw new Y(`${i.name} needs a colour.`);
					a = null;
				} else if (typeof a != "string" || !/^#[0-9a-f]{6}$/i.test(a)) throw new Y(`${i.name} must be a colour like #ff8800.`);
				else a = a.toLowerCase();
				break;
			case "points": {
				let e = typeof a == "string" ? JSON.parse(a) : a;
				if (!Array.isArray(e) || !e.length) throw new Y(`${i.name} must be a list of points like [[10, 20], [30, 40]].`);
				a = e;
				break;
			}
			case "image": if (a instanceof Uint8Array && (a = await e.backend.decode(a)), !a || typeof a != "object" || !("data" in a)) throw new Y(`${i.name} must be a picture.`);
		}
		r[i.name] = a;
	}
	return r;
}
async function jr(e, t, n = {}) {
	let r = Or(t);
	if (!r) throw new Y(`There is no command "${t}". The command "describe" lists the design; the list of commands says what each does.`);
	let i = r.params?.some((e) => e.name === "layer") && n.layer ? null : r.blocked?.(e) ?? null;
	if (i) throw new Y(i);
	return r.run(e, await Ar(e, r, n));
}
//#endregion
//#region src/edit/icons.tsx
var Mr = {
	move: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("path", { d: "M12 3v18M3 12h18" }), /* @__PURE__ */ P("path", { d: "M12 3l-3 3M12 3l3 3M12 21l-3-3M12 21l3-3M3 12l3-3M3 12l3 3M21 12l-3-3M21 12l-3 3" })] }),
	box: /* @__PURE__ */ P("rect", {
		x: "4",
		y: "5",
		width: "16",
		height: "14",
		rx: "1",
		strokeDasharray: "3 2.5"
	}),
	oval: /* @__PURE__ */ P("ellipse", {
		cx: "12",
		cy: "12",
		rx: "8.5",
		ry: "7",
		strokeDasharray: "3 2.5"
	}),
	lasso: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("path", {
		d: "M7 16c-3-2-3.5-6 0-8.5S17 5 19 8s0 7-5 7.5c-2.5.3-5 0-7 .5",
		strokeDasharray: "3 2.5"
	}), /* @__PURE__ */ P("path", { d: "M7 16c-1 1.5 0 3.5 2 3" })] }),
	wand: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("path", { d: "M5 19L15 9" }), /* @__PURE__ */ P("path", { d: "M16 3v3M19.5 4.5l-2 2M21 8h-3M17 11.5l-1.5-1.5" })] }),
	brush: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("path", { d: "M14 4l6 6-8 8-6-6z" }), /* @__PURE__ */ P("path", { d: "M6 12c-2 1-2.5 4-3 8 4-.5 7-1 8-3" })] }),
	eraser: /* @__PURE__ */ F(N, { children: [
		/* @__PURE__ */ P("path", { d: "M8 20h12" }),
		/* @__PURE__ */ P("path", { d: "M4 15l9-9 6 6-8 8H8z" }),
		/* @__PURE__ */ P("path", { d: "M9 10l6 6" })
	] }),
	clone: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("rect", {
		x: "4",
		y: "4",
		width: "10",
		height: "10",
		rx: "1"
	}), /* @__PURE__ */ P("rect", {
		x: "10",
		y: "10",
		width: "10",
		height: "10",
		rx: "1",
		strokeDasharray: "3 2"
	})] }),
	bucket: /* @__PURE__ */ F(N, { children: [
		/* @__PURE__ */ P("path", { d: "M5 11l6-6 8 8-6 6z" }),
		/* @__PURE__ */ P("path", { d: "M5 11h14" }),
		/* @__PURE__ */ P("path", { d: "M20 16c0 1.5.8 2.5 0 3.5s-2-.5-1.5-1.5z" })
	] }),
	gradient: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("rect", {
		x: "3",
		y: "5",
		width: "18",
		height: "14",
		rx: "2"
	}), /* @__PURE__ */ P("path", {
		d: "M7 5v14M11 5v14M15 5v14",
		opacity: ".5"
	})] }),
	dropper: /* @__PURE__ */ F(N, { children: [
		/* @__PURE__ */ P("path", { d: "M14 6l4 4" }),
		/* @__PURE__ */ P("path", { d: "M16 4a2.1 2.1 0 013 3l-2 2-3-3z" }),
		/* @__PURE__ */ P("path", { d: "M15 9l-8 8-3 1 1-3 8-8" })
	] }),
	rect: /* @__PURE__ */ P("rect", {
		x: "4",
		y: "5",
		width: "16",
		height: "14",
		rx: "2"
	}),
	ellipse: /* @__PURE__ */ P("ellipse", {
		cx: "12",
		cy: "12",
		rx: "8.5",
		ry: "7"
	}),
	line: /* @__PURE__ */ P("path", { d: "M5 19L19 5" }),
	pen: /* @__PURE__ */ F(N, { children: [
		/* @__PURE__ */ P("path", { d: "M12 3l5 9-5 9-5-9z" }),
		/* @__PURE__ */ P("circle", {
			cx: "12",
			cy: "12",
			r: "1.5"
		}),
		/* @__PURE__ */ P("path", { d: "M12 21v-7.5" })
	] }),
	text: /* @__PURE__ */ P(N, { children: /* @__PURE__ */ P("path", { d: "M5 6V4h14v2M12 4v16M9 20h6" }) }),
	crop: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("path", { d: "M7 3v14h14" }), /* @__PURE__ */ P("path", { d: "M3 7h14v14" })] }),
	hand: /* @__PURE__ */ P("path", { d: "M8 13V6.5a1.5 1.5 0 013 0V12m0-6.5a1.5 1.5 0 013 0V12m0-5a1.5 1.5 0 013 0v7c0 4-2.5 7-6 7s-5-2-7-5l-1.5-2.5a1.5 1.5 0 012.5-1.5L8 14" }),
	zoom: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("circle", {
		cx: "10.5",
		cy: "10.5",
		r: "6.5"
	}), /* @__PURE__ */ P("path", { d: "M15.5 15.5L20 20M8 10.5h5M10.5 8v5" })] }),
	eye: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("path", { d: "M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z" }), /* @__PURE__ */ P("circle", {
		cx: "12",
		cy: "12",
		r: "3"
	})] }),
	eyeOff: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("path", {
		d: "M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z",
		opacity: ".35"
	}), /* @__PURE__ */ P("path", { d: "M4 20L20 4" })] }),
	lock: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("rect", {
		x: "5",
		y: "11",
		width: "14",
		height: "9",
		rx: "2"
	}), /* @__PURE__ */ P("path", { d: "M8 11V8a4 4 0 018 0v3" })] }),
	unlock: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("rect", {
		x: "5",
		y: "11",
		width: "14",
		height: "9",
		rx: "2"
	}), /* @__PURE__ */ P("path", { d: "M8 11V8a4 4 0 017.5-2" })] }),
	plus: /* @__PURE__ */ P("path", { d: "M12 5v14M5 12h14" }),
	copy: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("rect", {
		x: "8",
		y: "8",
		width: "12",
		height: "12",
		rx: "2"
	}), /* @__PURE__ */ P("path", { d: "M16 8V5a1 1 0 00-1-1H5a1 1 0 00-1 1v10a1 1 0 001 1h3" })] }),
	trash: /* @__PURE__ */ P(N, { children: /* @__PURE__ */ P("path", { d: "M4 7h16M10 7V4h4v3M6 7l1 13h10l1-13" }) }),
	up: /* @__PURE__ */ P("path", { d: "M12 19V5M6 11l6-6 6 6" }),
	down: /* @__PURE__ */ P("path", { d: "M12 5v14M6 13l6 6 6-6" }),
	merge: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("path", { d: "M7 4v5a5 5 0 005 5 5 5 0 005-5V4" }), /* @__PURE__ */ P("path", { d: "M12 14v6M9 17l3 3 3-3" })] }),
	mask: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("rect", {
		x: "3",
		y: "5",
		width: "18",
		height: "14",
		rx: "2"
	}), /* @__PURE__ */ P("circle", {
		cx: "12",
		cy: "12",
		r: "4",
		fill: "currentColor",
		stroke: "none"
	})] }),
	undo: /* @__PURE__ */ P("path", {
		d: "M9 7L4 12l5 5M4 12h10a6 6 0 010 12",
		transform: "translate(0 -3)"
	}),
	redo: /* @__PURE__ */ P("path", {
		d: "M15 7l5 5-5 5M20 12H10a6 6 0 000 12",
		transform: "translate(0 -3)"
	}),
	swap: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("path", { d: "M7 4L4 7l3 3M4 7h11a4 4 0 014 4" }), /* @__PURE__ */ P("path", { d: "M17 20l3-3-3-3M20 17H9a4 4 0 01-4-4" })] }),
	search: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("circle", {
		cx: "11",
		cy: "11",
		r: "6"
	}), /* @__PURE__ */ P("path", { d: "M16 16l4 4" })] })
};
function Nr({ name: e, size: t = 18, title: n }) {
	return /* @__PURE__ */ F("svg", {
		width: t,
		height: t,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: 1.7,
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": !n || void 0,
		role: n ? "img" : void 0,
		children: [n && /* @__PURE__ */ P("title", { children: n }), Mr[e]]
	});
}
//#endregion
//#region src/edit/EditMode.tsx
var Pr = _e(() => import("./ModelMode-D6OIyX2x.js").then((e) => ({ default: e.ModelMode })));
function Fr(e) {
	let t = document.createElement("canvas");
	t.width = e.width, t.height = e.height;
	let n = t.getContext("2d", { willReadFrequently: !0 });
	n.drawImage(e, 0, 0);
	let r = n.getImageData(0, 0, t.width, t.height);
	return {
		width: r.width,
		height: r.height,
		data: r.data
	};
}
function Ir(e, t, n, r = 640) {
	let i = document.createElement("canvas");
	i.width = e.width, i.height = e.height;
	let a = i.getContext("2d", { willReadFrequently: !0 });
	nr(a, e, {
		...t,
		opacity: 1,
		blend: "normal",
		visible: !0,
		style: void 0
	}, n);
	let o = a.getImageData(0, 0, e.width, e.height).data, [s, c, l, u] = [
		e.width,
		e.height,
		-1,
		-1
	];
	for (let t = 0; t < e.height; t++) for (let n = 0; n < e.width; n++) o[(t * e.width + n) * 4 + 3] >= 128 && ([s, c, l, u] = [
		Math.min(s, n),
		Math.min(c, t),
		Math.max(l, n),
		Math.max(u, t)
	]);
	if (l < 0) return null;
	let d = Math.min(1, r / Math.max(l - s + 1, u - c + 1)), [f, p] = [Math.round((l - s + 1) * d) + 8, Math.round((u - c + 1) * d) + 8], m = document.createElement("canvas");
	m.width = f, m.height = p;
	let h = m.getContext("2d", { willReadFrequently: !0 });
	return h.drawImage(i, s, c, l - s + 1, u - c + 1, 4, 4, f - 8, p - 8), {
		rgba: h.getImageData(0, 0, f, p).data,
		width: f,
		height: p
	};
}
function Lr(e) {
	let t = document.createElement("canvas");
	return t.width = e.width, t.height = e.height, t.getContext("2d").putImageData(new ImageData(e.data, e.width, e.height), 0, 0), t;
}
var Rr = (e, t = "image/png", n) => new Promise((r, i) => e.toBlob((e) => e ? r(e) : i(/* @__PURE__ */ Error("The picture could not be made.")), t, n));
function zr(e, t) {
	let n = URL.createObjectURL(e), r = document.createElement("a");
	r.href = n, r.download = t, r.click(), setTimeout(() => URL.revokeObjectURL(n), 1e3);
}
function Br(e) {
	return new Promise((t) => {
		let n = document.createElement("input");
		n.type = "file", n.accept = e, n.onchange = () => t(n.files?.[0] ?? null), n.click();
	});
}
async function Vr(e) {
	let t = new Image();
	return t.src = e, await t.decode(), Fr(t);
}
var Hr = null, Ur = (e) => Xn(Hr ??= document.createElement("canvas").getContext("2d"), e), Wr = [
	"system-ui, sans-serif",
	"Georgia, serif",
	"\"Trebuchet MS\", sans-serif",
	"Impact, sans-serif",
	"\"Courier New\", monospace",
	"\"Brush Script MT\", cursive"
], Gr = [
	"File",
	"Edit",
	"Select",
	"Layer",
	"Adjust",
	"Canvas",
	"View"
], Kr = (e) => `Command ${e} in packages/canvas/src/commands.ts; headless: npm run design, or the MCP tool design_run with command "${e}" (docs/MCP.md).`, qr = new It();
function Jr(e) {
	return {
		surface: (e, t) => {
			let n = document.createElement("canvas");
			n.width = e, n.height = t;
			let r = n.getContext("2d", { willReadFrequently: !0 });
			return {
				ctx: r,
				canvas: n,
				read: () => ({
					width: e,
					height: t,
					data: r.getImageData(0, 0, e, t).data
				})
			};
		},
		image(t, n) {
			let r = e.get(t);
			return r || (r = Lr(n), e.set(t, r)), r;
		},
		path: (e) => new Path2D(e),
		async encode(e, t, n) {
			let r = await Rr(Lr(e), `image/${t}`, n);
			return new Uint8Array(await r.arrayBuffer());
		},
		async decode(e) {
			let t = await createImageBitmap(new Blob([e])), n = Fr(t);
			return t.close(), n;
		}
	};
}
var Yr = (e, t, n = !1) => {
	let r = t.x - e.x, i = t.y - e.y;
	if (n) {
		let e = Math.max(Math.abs(r), Math.abs(i));
		r = Math.sign(r || 1) * e, i = Math.sign(i || 1) * e;
	}
	return {
		x: Math.min(e.x, e.x + r),
		y: Math.min(e.y, e.y + i),
		width: Math.abs(r),
		height: Math.abs(i)
	};
}, Xr = (e) => e.shiftKey && e.altKey ? "intersect" : e.shiftKey ? "add" : e.altKey ? "subtract" : "replace";
function Zr({ open: e, title: t = "Design", onDone: n, doneLabel: r = "Done", onClose: i }) {
	let a = j(null), [o, s] = M(null), [c, l] = M(null), [u, d] = M(null), [f, p] = M("move"), [m, h] = M({
		main: "#1a1a1a",
		second: "#ffffff"
	}), [g, _] = M({
		size: 24,
		hardness: .6,
		flow: 1
	}), [v, y] = M({
		tolerance: 32,
		contiguous: !0
	}), [b, x] = M({
		fill: "#e46a9b",
		stroke: null,
		strokeWidth: 4,
		radius: 0
	}), [S, C] = M({
		font: Wr[0],
		size: 72,
		weight: 700
	}), [w, te] = M(null), [ne, re] = M(!1), [T, ie] = M({
		zoom: 1,
		x: 0,
		y: 0
	}), [E, oe] = M(null), [D, O] = M(null), [le, ue] = M(null), [de, fe] = M(null), [pe, me] = M(null), [he, _e] = M(null), [k, be] = M(null), [xe, I] = M(null), [Se, Ce] = M(null), [we, Te] = M("layers"), [Ee, De] = M(null), [Oe, ke] = M(null), [Ae, je] = M(null), [Me, Ne] = M(!1), Pe = j(null), Fe = j(null), Ie = j(null), Le = j(null), Re = j(!1), ze = j(null), Be = j(null), Ve = j(/* @__PURE__ */ new Map()), He = j([]), [Ue, L] = M({
		width: 0,
		height: 0
	}), We = ye(() => Jr(Ve.current), []), R = () => a.current, z = a.current?.store ?? qr, B = o && u ? Ut(o, u) : void 0;
	A(() => {
		let t = !1;
		return (async () => {
			try {
				let n, r = new It();
				if (e.kind === "project") {
					let t = await ur(e.file, Vr);
					r = t.store, n = t.doc;
				} else if (n = Rt(e.width, e.height, e.background === void 0 ? "#ffffff" : e.background), e.kind === "pictures") for (let t of e.layers) n = K(n, Bt(t.name, r.add(Fr(t.picture)), {
					x: t.x ?? 0,
					y: t.y ?? 0
				}));
				if (t) return;
				a.current = new dr(We, n, r), s(n), d(n.layers[n.layers.length - 1]?.id ?? null);
			} catch (e) {
				t || l(e instanceof Error ? e.message : "This could not be opened.");
			}
		})(), () => {
			t = !0;
		};
	}, []);
	let Ge = () => {
		for (let e of [...Ve.current.keys()]) R().store.get(e) || Ve.current.delete(e);
	}, V = (e, t) => {
		R().commit(e, t), s(e), Ge();
	}, Ke = () => {
		R().history.canUndo && s(R().history.undo());
	}, qe = () => {
		R().history.canRedo && s(R().history.redo());
	}, Je = () => s(R().history.doc), Ye = (e) => {
		let t = Ve.current.get(e);
		if (!t) {
			let n = R().store.get(e);
			if (!n) return;
			t = Lr(n), Ve.current.set(e, t);
		}
		return t;
	}, Xe = {
		image: Ye,
		surface(e, t, n = 0) {
			let r = He.current[n] ??= document.createElement("canvas");
			(r.width !== e || r.height !== t) && (r.width = e, r.height = t);
			let i = r.getContext("2d");
			return i.setTransform(1, 0, 0, 1, 0, 0), i.globalCompositeOperation = "source-over", i.clearRect(0, 0, e, t), {
				ctx: i,
				canvas: r
			};
		},
		path: (e) => new Path2D(e)
	}, Ze = (e, t = !0) => {
		let n = document.createElement("canvas");
		return n.width = e.width, n.height = e.height, rr(n.getContext("2d"), e, Xe, { background: t }), n;
	}, Qe = (e) => {
		let t = Ze(e), n = t.getContext("2d", { willReadFrequently: !0 }).getImageData(0, 0, t.width, t.height);
		return {
			width: n.width,
			height: n.height,
			data: n.data
		};
	}, $e = (e) => {
		if (!w) return;
		let { width: t, height: n, mask: r } = w;
		if (!e) return (e, i) => e >= 0 && i >= 0 && e < t && i < n ? r[i * t + e] / 255 : 0;
		let i = qt(e.transform);
		return (e, a) => {
			let o = Yt(i, {
				x: e + .5,
				y: a + .5
			}), s = Math.floor(o.x), c = Math.floor(o.y);
			return s >= 0 && c >= 0 && s < t && c < n ? r[c * t + s] / 255 : 0;
		};
	}, H = (e = o) => {
		if (!e || !Ue.width) return;
		let t = Math.min(1, (Ue.width - 64) / e.width, (Ue.height - 150) / e.height);
		ie({
			zoom: t,
			x: (Ue.width - e.width * t) / 2,
			y: (Ue.height - 90 - e.height * t) / 2 + 10
		});
	}, et = (e, t = {
		x: Ue.width / 2,
		y: Ue.height / 2
	}) => ie((n) => {
		let r = Math.min(32, Math.max(.05, n.zoom * e));
		return {
			zoom: r,
			x: t.x - (t.x - n.x) * r / n.zoom,
			y: t.y - (t.y - n.y) * r / n.zoom
		};
	});
	ve(() => {
		let e = Pe.current;
		if (!e) return;
		let t = new ResizeObserver(() => L({
			width: e.clientWidth,
			height: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, [o === null]);
	let tt = j(!1);
	A(() => {
		o && Ue.width && !tt.current && (tt.current = !0, H(o));
	}, [o, Ue.width]);
	let nt = (e) => {
		let t = Fe.current.getBoundingClientRect();
		return {
			x: (e.clientX - t.left - T.x) / T.zoom,
			y: (e.clientY - t.top - T.y) / T.zoom
		};
	}, rt = ye(() => {
		if (!w) return null;
		let e = gn(w), t = document.createElement("canvas");
		t.width = w.width, t.height = w.height;
		let n = t.getContext("2d"), r = n.createImageData(t.width, t.height);
		for (let n = 0; n < e.length; n++) {
			if (!e[n]) continue;
			let i = n % t.width, a = i + (n - i) / t.width >> 2 & 1 ? 255 : 0;
			r.data.set([
				a,
				a,
				a,
				255
			], n * 4);
		}
		return n.putImageData(r, 0, 0), t;
	}, [w]), it = ye(() => {
		let e = document.createElement("canvas");
		e.width = e.height = 16;
		let t = e.getContext("2d");
		return t.fillStyle = "#ffffff", t.fillRect(0, 0, 16, 16), t.fillStyle = "#e4e4ea", t.fillRect(0, 0, 8, 8), t.fillRect(8, 8, 8, 8), e;
	}, []), at = () => E?.kind === "line" && f === "line" ? Vt("", {
		type: "line",
		x2: E.to.x - E.from.x,
		y2: E.to.y - E.from.y
	}, {
		fill: null,
		stroke: b.stroke ?? m.main,
		strokeWidth: b.strokeWidth
	}, {
		x: E.from.x,
		y: E.from.y
	}) : E?.kind === "rect" && (f === "rect" || f === "ellipse") ? Vt("", f === "rect" ? {
		type: "rect",
		width: E.rect.width,
		height: E.rect.height,
		radius: b.radius
	} : {
		type: "ellipse",
		width: E.rect.width,
		height: E.rect.height
	}, b, {
		x: E.rect.x,
		y: E.rect.y
	}) : D && D.length ? Vt("", {
		type: "path",
		path: {
			points: D,
			closed: !1
		}
	}, {
		fill: null,
		stroke: b.stroke ?? m.main,
		strokeWidth: Math.max(1, b.strokeWidth)
	}) : null, ot = () => {
		let e = Fe.current;
		if (!e || !o) return;
		let t = window.devicePixelRatio || 1, n = Math.round(Ue.width * t), r = Math.round(Ue.height * t);
		(e.width !== n || e.height !== r) && (e.width = n, e.height = r);
		let i = e.getContext("2d");
		i.setTransform(1, 0, 0, 1, 0, 0), i.clearRect(0, 0, n, r);
		let a = T.zoom;
		i.setTransform(t * a, 0, 0, t * a, t * T.x, t * T.y), i.save(), i.shadowColor = "rgba(0,0,0,0.5)", i.shadowBlur = 30 * t;
		let s = i.createPattern(it, "repeat");
		s.setTransform(new DOMMatrix().scale(1 / a)), i.fillStyle = s, i.fillRect(0, 0, o.width, o.height), i.restore(), i.save(), i.beginPath(), i.rect(0, 0, o.width, o.height), i.clip(), i.imageSmoothingEnabled = a < 2;
		let c = at();
		rr(i, c ? {
			...o,
			layers: [...o.layers, c]
		} : o, Xe, { hide: de ? /* @__PURE__ */ new Set([de.id]) : void 0 }), i.restore();
		let l = 1 / a;
		if (rt && (i.imageSmoothingEnabled = !1, i.drawImage(rt, 0, 0)), i.lineWidth = l * 1.5, f === "move" && B && B.visible && !de) {
			let e = Qt(B, z);
			if (i.strokeStyle = "#7cc4ff", i.beginPath(), e.forEach((e, t) => t ? i.lineTo(e.x, e.y) : i.moveTo(e.x, e.y)), i.closePath(), i.stroke(), !B.locked) {
				i.fillStyle = "#ffffff";
				for (let t of e) i.fillRect(t.x - 4 * l, t.y - 4 * l, 8 * l, 8 * l), i.strokeRect(t.x - 4 * l, t.y - 4 * l, 8 * l, 8 * l);
				let t = ut(B);
				i.beginPath(), i.moveTo((e[0].x + e[1].x) / 2, (e[0].y + e[1].y) / 2), i.lineTo(t.x, t.y), i.stroke(), i.beginPath(), i.arc(t.x, t.y, 5 * l, 0, Math.PI * 2), i.fill(), i.stroke();
			}
		}
		if (i.setLineDash([5 * l, 4 * l]), i.strokeStyle = "#ffffff", E?.kind === "rect" && (f === "box" || f === "oval")) {
			let e = E.rect;
			i.beginPath(), E.oval ? i.ellipse(e.x + e.width / 2, e.y + e.height / 2, e.width / 2, e.height / 2, 0, 0, Math.PI * 2) : i.rect(e.x, e.y, e.width, e.height), i.stroke();
		}
		if (E?.kind === "lasso" && (i.beginPath(), E.points.forEach((e, t) => t ? i.lineTo(e.x, e.y) : i.moveTo(e.x, e.y)), i.stroke()), E?.kind === "line" && f === "gradient") {
			i.setLineDash([]), i.strokeStyle = "#ffffff", i.beginPath(), i.moveTo(E.from.x, E.from.y), i.lineTo(E.to.x, E.to.y), i.stroke();
			for (let [e, t] of [[E.from, m.main], [E.to, m.second]]) i.fillStyle = t, i.beginPath(), i.arc(e.x, e.y, 6 * l, 0, Math.PI * 2), i.fill(), i.stroke();
		}
		let u = E?.kind === "crop" ? E.rect : le;
		if (u && f === "crop") {
			i.setLineDash([]), i.fillStyle = "rgba(10,10,14,0.6)", i.beginPath(), i.rect(-1e5, -1e5, 2e5, 2e5), i.rect(u.x, u.y, u.width, u.height), i.fill("evenodd"), i.strokeStyle = "#ffffff", i.strokeRect(u.x, u.y, u.width, u.height), i.strokeStyle = "rgba(255,255,255,0.35)";
			for (let e of [1 / 3, 2 / 3]) i.beginPath(), i.moveTo(u.x + u.width * e, u.y), i.lineTo(u.x + u.width * e, u.y + u.height), i.moveTo(u.x, u.y + u.height * e), i.lineTo(u.x + u.width, u.y + u.height * e), i.stroke();
		}
		if (i.setLineDash([]), D?.length && (i.strokeStyle = "#7cc4ff", i.fillStyle = "#ffffff", D.forEach((e, t) => {
			for (let t of [e.in, e.out]) t && (i.beginPath(), i.moveTo(e.x, e.y), i.lineTo(e.x + t.x, e.y + t.y), i.stroke(), i.beginPath(), i.arc(e.x + t.x, e.y + t.y, 3 * l, 0, Math.PI * 2), i.fill());
			i.fillStyle = t === 0 ? "#7cc4ff" : "#ffffff", i.fillRect(e.x - 3.5 * l, e.y - 3.5 * l, 7 * l, 7 * l), i.strokeRect(e.x - 3.5 * l, e.y - 3.5 * l, 7 * l, 7 * l), i.fillStyle = "#ffffff";
		})), Ee && (f === "brush" || f === "eraser" || f === "clone") && (i.strokeStyle = "rgba(255,255,255,0.9)", i.beginPath(), i.arc(Ee.x, Ee.y, g.size / 2, 0, Math.PI * 2), i.stroke(), i.strokeStyle = "rgba(0,0,0,0.6)", i.beginPath(), i.arc(Ee.x, Ee.y, g.size / 2 + l, 0, Math.PI * 2), i.stroke()), f === "clone" && ze.current) {
			let e = ze.current;
			i.strokeStyle = "#7cc4ff", i.beginPath(), i.moveTo(e.x - 8 * l, e.y), i.lineTo(e.x + 8 * l, e.y), i.moveTo(e.x, e.y - 8 * l), i.lineTo(e.x, e.y + 8 * l), i.stroke();
		}
	}, st = j(ot);
	st.current = ot;
	let ct = j(0), lt = () => {
		ct.current ||= requestAnimationFrame(() => {
			ct.current = 0, st.current();
		});
	};
	A(lt);
	function ut(e) {
		let t = Qt(e, z), n = {
			x: (t[0].x + t[1].x) / 2,
			y: (t[0].y + t[1].y) / 2
		}, r = {
			x: (t[0].x + t[2].x) / 2,
			y: (t[0].y + t[2].y) / 2
		}, i = n.x - r.x, a = n.y - r.y, o = Math.hypot(i, a) || 1;
		return {
			x: n.x + i / o * (26 / T.zoom),
			y: n.y + a / o * (26 / T.zoom)
		};
	}
	let dt = (e, t) => {
		let n = 9 / T.zoom, r = ut(e);
		if (Math.hypot(t.x - r.x, t.y - r.y) < n) return "rotate";
		let i = Qt(e, z);
		for (let e = 0; e < 4; e++) if (Math.hypot(t.x - i[e].x, t.y - i[e].y) < n) return e;
		return null;
	}, ft = (e, t, n) => {
		let r = Yt(qt(e), n), i = Yt(qt({
			...t,
			x: 0,
			y: 0
		}), n);
		return {
			...t,
			x: r.x - i.x,
			y: r.y - i.y
		};
	}, pt = (e) => {
		let t = u ? Ut(e, u) : void 0;
		if (t?.locked) return ke("That layer is locked. Unlock it in the layers list to paint on it."), null;
		if (t && ne && t.mask) return {
			doc: e,
			layer: t,
			field: "mask"
		};
		if (t?.kind === "raster") return {
			doc: e,
			layer: t,
			field: "pixels"
		};
		let n = Bt("Paint", z.add(Pt(e.width, e.height)));
		return d(n.id), {
			doc: K(e, n, t?.id),
			layer: n,
			field: "pixels"
		};
	}, mt = (e, t, n) => {
		let r = n === "mask" ? t.mask : t.pixels, i = Ft(z.get(r)), a = z.add(i, n === "mask" ? "mask" : "px");
		return {
			next: q(e, t.id, { [n]: a }),
			working: i,
			id: a
		};
	}, ht = (e, t, n) => {
		if (!n) return;
		let r = Ye(e);
		r && (r.getContext("2d").putImageData(new ImageData(t.data, t.width, t.height), 0, 0, n.x, n.y, n.width, n.height), lt());
	}, gt = (e) => {
		if (!o || de) return;
		e.preventDefault(), (!Ie.current?.contains(document.activeElement) || document.activeElement === document.body) && Ie.current?.focus({ preventScroll: !0 }), e.target.setPointerCapture(e.pointerId), _e(null), ke(null);
		let t = nt(e);
		if (Re.current || f === "hand" || e.button === 1) Le.current = {
			kind: "pan",
			start: {
				x: e.clientX,
				y: e.clientY
			},
			view0: T
		};
		else switch (f) {
			case "move": {
				if (B && !B.locked && B.visible) {
					let e = dt(B, t);
					if (e === "rotate") return void (Le.current = {
						kind: "rotate",
						start: t,
						doc0: o,
						layer0: B
					});
					if (e !== null) return void (Le.current = {
						kind: "scale",
						corner: e,
						doc0: o,
						layer0: B
					});
				}
				let e = $t(o, z, t) ?? (B && !B.locked && U(B, t) ? B : void 0);
				e && (d(e.id), Le.current = {
					kind: "move",
					start: t,
					doc0: o,
					layer0: e
				});
				return;
			}
			case "box":
			case "oval":
				Le.current = {
					kind: "marquee",
					start: t,
					how: Xr(e),
					oval: f === "oval"
				};
				return;
			case "lasso":
				Le.current = {
					kind: "lasso",
					points: [t],
					how: Xr(e)
				};
				return;
			case "wand": {
				let n = hn(Qe(o), t, v.tolerance, v.contiguous), r = dn(w, n, Xr(e));
				te(pn(r) ? r : null);
				return;
			}
			case "dropper": {
				let n = jn(Qe(o), t);
				n && h((t) => e.altKey ? {
					...t,
					second: vn(n)
				} : {
					...t,
					main: vn(n)
				});
				return;
			}
			case "brush":
			case "eraser":
			case "clone": {
				if (f === "clone" && e.altKey) {
					ze.current = t, lt();
					return;
				}
				if (f === "clone" && !ze.current) {
					ke("Alt-click where to copy from first.");
					return;
				}
				let n = pt(o);
				if (!n) return;
				let { next: r, working: i, id: a } = mt(n.doc, n.layer, n.field), c = Ut(r, n.layer.id), l = n.field === "mask" ? t : Xt(c, t), u = {
					kind: "paint",
					layerId: c.id,
					field: n.field,
					working: i,
					id: a,
					stroke: bn(),
					clip: $e(n.field === "mask" ? null : c)
				};
				if (f === "clone") {
					let e = n.field === "mask" ? ze.current : Xt(c, ze.current);
					u.clone = {
						snapshot: Ft(i),
						offset: {
							x: e.x - l.x,
							y: e.y - l.y
						}
					};
				}
				Le.current = u, s(r), _t(u, l);
				return;
			}
			case "bucket":
			case "gradient": {
				if (f === "gradient") return void (Le.current = {
					kind: "gradient",
					start: t
				});
				let e = pt(o);
				if (!e) return;
				let { next: n, working: r, id: i } = mt(e.doc, e.layer, e.field), a = Ut(n, e.layer.id);
				Tn(r, e.field === "mask" ? t : Xt(a, t), _n(m.main), v.tolerance, v.contiguous, $e(e.field === "mask" ? null : a)) && (Ye(i), ht(i, r, {
					x: 0,
					y: 0,
					width: r.width,
					height: r.height
				}), V(n, "Fill"));
				return;
			}
			case "rect":
			case "ellipse":
			case "line":
				Le.current = {
					kind: "shape",
					start: t,
					type: f
				};
				return;
			case "pen": {
				let e = D ?? [];
				if (e.length > 2 && Math.hypot(t.x - e[0].x, t.y - e[0].y) < 8 / T.zoom) {
					bt(!0);
					return;
				}
				let n = [...e, {
					x: t.x,
					y: t.y
				}];
				O(n), Le.current = {
					kind: "pen",
					index: n.length - 1
				};
				return;
			}
			case "text": {
				let e = [...o.layers].reverse().find((e) => e.kind === "text" && e.visible && !e.locked && U(e, t));
				if (e) {
					d(e.id), fe({
						id: e.id,
						fresh: !1
					});
					return;
				}
				let n = Ht("", {
					font: S.font,
					size: S.size,
					weight: S.weight,
					color: m.main
				}, {
					x: t.x,
					y: t.y - S.size * .6
				}), r = {
					...n,
					box: Ur({
						...n,
						text: " "
					})
				};
				s(K(o, r, u ?? void 0)), d(n.id), fe({
					id: n.id,
					fresh: !0
				});
				return;
			}
			case "crop":
				ue(null), Le.current = {
					kind: "crop",
					start: t
				};
				return;
			case "zoom":
				et(e.altKey ? 1 / 1.6 : 1.6, {
					x: t.x * T.zoom + T.x,
					y: t.y * T.zoom + T.y
				});
				return;
		}
	}, U = (e, t) => {
		let n = Xt(e, t), r = Zt(e, z);
		return n.x >= r.x && n.y >= r.y && n.x <= r.x + r.width && n.y <= r.y + r.height;
	}, _t = (e, t) => {
		let n;
		if (e.clone) {
			let { snapshot: r, offset: i } = e.clone;
			n = Sn(e.stroke, t, Cn(g.size), (t) => Mn(e.working, r, t, i, g, e.clip));
		} else {
			let r = e.field === "mask" ? f === "eraser" ? "hide" : "reveal" : f === "eraser" ? "erase" : "paint";
			n = wn(e.working, e.stroke, t, {
				...g,
				color: _n(m.main),
				mode: r
			}, e.clip);
		}
		ht(e.id, e.working, n);
	}, W = (e) => {
		if (!o) return;
		let t = nt(e);
		(f === "brush" || f === "eraser" || f === "clone") && De(t);
		let n = Le.current;
		if (!n) D?.length && f === "pen" && lt();
		else switch (n.kind) {
			case "pan":
				ie({
					...n.view0,
					x: n.view0.x + e.clientX - n.start.x,
					y: n.view0.y + e.clientY - n.start.y
				});
				return;
			case "move": {
				let r = t.x - n.start.x, i = t.y - n.start.y;
				e.shiftKey && (Math.abs(r) > Math.abs(i) ? i = 0 : r = 0);
				let a = n.layer0.transform;
				s(q(n.doc0, n.layer0.id, { transform: {
					...a,
					x: a.x + r,
					y: a.y + i
				} }));
				return;
			}
			case "scale": {
				let r = Zt(n.layer0, z), i = [
					{
						x: r.x,
						y: r.y
					},
					{
						x: r.x + r.width,
						y: r.y
					},
					{
						x: r.x + r.width,
						y: r.y + r.height
					},
					{
						x: r.x,
						y: r.y + r.height
					}
				], a = i[n.corner], o = i[(n.corner + 2) % 4], c = n.layer0.transform, l = Yt(Jt(qt(c)), t), u = (l.x - o.x) / (a.x - o.x || 1), d = (l.y - o.y) / (a.y - o.y || 1);
				if (e.shiftKey || n.layer0.kind === "text") {
					let e = Math.max(Math.abs(u), Math.abs(d));
					u = Math.sign(u || 1) * e, d = Math.sign(d || 1) * e;
				}
				let f = ft(c, {
					...c,
					scaleX: c.scaleX * (Math.abs(u) < .01 ? .01 : u),
					scaleY: c.scaleY * (Math.abs(d) < .01 ? .01 : d)
				}, o);
				s(q(n.doc0, n.layer0.id, { transform: f }));
				return;
			}
			case "rotate": {
				let r = Zt(n.layer0, z), i = {
					x: r.x + r.width / 2,
					y: r.y + r.height / 2
				}, a = n.layer0.transform, o = Yt(qt(a), i), c = a.rotation + Math.atan2(t.y - o.y, t.x - o.x) - Math.atan2(n.start.y - o.y, n.start.x - o.x);
				e.shiftKey && (c = rn(c)), s(q(n.doc0, n.layer0.id, { transform: ft(a, {
					...a,
					rotation: c
				}, i) }));
				return;
			}
			case "marquee":
				oe({
					kind: "rect",
					rect: Yr(n.start, t, e.shiftKey && n.how === "replace"),
					oval: n.oval
				});
				return;
			case "lasso":
				n.points.push(t), oe({
					kind: "lasso",
					points: [...n.points]
				});
				return;
			case "paint": {
				let e = Ut(o, n.layerId);
				_t(n, n.field === "mask" ? t : Xt(e, t));
				return;
			}
			case "gradient":
				oe({
					kind: "line",
					from: n.start,
					to: t
				});
				return;
			case "shape":
				if (n.type === "line") {
					let r = t;
					if (e.shiftKey) {
						let e = rn(Math.atan2(t.y - n.start.y, t.x - n.start.x), Math.PI / 4), i = Math.hypot(t.x - n.start.x, t.y - n.start.y);
						r = {
							x: n.start.x + Math.cos(e) * i,
							y: n.start.y + Math.sin(e) * i
						};
					}
					oe({
						kind: "line",
						from: n.start,
						to: r
					});
				} else oe({
					kind: "rect",
					rect: Yr(n.start, t, e.shiftKey),
					oval: n.type === "ellipse"
				});
				return;
			case "pen": {
				if (!D) return;
				let e = D[n.index], r = {
					x: t.x - e.x,
					y: t.y - e.y
				};
				if (Math.hypot(r.x, r.y) < 3 / T.zoom) return;
				let i = [...D];
				i[n.index] = {
					...e,
					out: r,
					in: {
						x: -r.x,
						y: -r.y
					}
				}, O(i);
				return;
			}
			case "crop":
				oe({
					kind: "crop",
					rect: Yr(n.start, t, e.shiftKey)
				});
				return;
		}
	}, vt = (e) => {
		let t = Le.current;
		if (Le.current = null, !t || !o) return;
		let n = nt(e);
		switch (t.kind) {
			case "move":
			case "scale":
			case "rotate":
				o !== t.doc0 && V(o, t.kind === "move" ? "Move" : t.kind === "scale" ? "Resize" : "Turn");
				return;
			case "marquee": {
				let r = Yr(t.start, n, e.shiftKey && t.how === "replace");
				if (oe(null), r.width < 2 && r.height < 2) {
					t.how === "replace" && te(null);
					return;
				}
				let i = dn(w, (t.oval ? ln : cn)(o.width, o.height, r), t.how);
				te(pn(i) ? i : null);
				return;
			}
			case "lasso": {
				if (oe(null), t.points.length < 3) return;
				let e = dn(w, un(o.width, o.height, t.points), t.how);
				te(pn(e) ? e : null);
				return;
			}
			case "paint":
				V(o, f === "eraser" ? "Erase" : f === "clone" ? "Clone" : t.field === "mask" ? "Paint mask" : "Brush");
				return;
			case "gradient": {
				if (oe(null), Math.hypot(n.x - t.start.x, n.y - t.start.y) < 2) return;
				let e = pt(o);
				if (!e) return;
				let { next: r, working: i, id: a } = mt(e.doc, e.layer, e.field), s = Ut(r, e.layer.id), c = (t) => e.field === "mask" ? t : Xt(s, t);
				An(i, c(t.start), c(n), _n(m.main), _n(m.second), $e(e.field === "mask" ? null : s)), Ye(a), ht(a, i, {
					x: 0,
					y: 0,
					width: i.width,
					height: i.height
				}), V(r, "Gradient");
				return;
			}
			case "shape": {
				let e = E;
				oe(null);
				let n = at();
				if (!n || !e || !(e.kind === "line" ? Math.hypot(e.to.x - e.from.x, e.to.y - e.from.y) > 2 : e.kind === "rect" && e.rect.width > 2 && e.rect.height > 2)) return;
				let r = {
					...n,
					name: t.type === "rect" ? "Rectangle" : t.type === "ellipse" ? "Ellipse" : "Line"
				};
				V(K(o, r, u ?? void 0), `Draw ${r.name.toLowerCase()}`), d(r.id);
				return;
			}
			case "crop": {
				let r = Yr(t.start, n, e.shiftKey);
				oe(null), ue(r.width > 4 && r.height > 4 ? r : null);
				return;
			}
			default: return;
		}
	}, yt = (e) => {
		if (!o) return;
		let t = Fe.current.getBoundingClientRect();
		e.ctrlKey || e.metaKey ? et(Math.exp(-e.deltaY * .01), {
			x: e.clientX - t.left,
			y: e.clientY - t.top
		}) : ie((t) => ({
			...t,
			x: t.x - e.deltaX,
			y: t.y - e.deltaY
		}));
	};
	A(() => {
		let e = Fe.current;
		if (!e) return;
		let t = (e) => e.preventDefault();
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, [o === null]);
	let bt = (e) => {
		if (!o || !D || D.length < 2) {
			O(null);
			return;
		}
		let t = Vt("Path", {
			type: "path",
			path: {
				points: D,
				closed: e
			}
		}, e ? {
			fill: b.fill,
			stroke: b.stroke,
			strokeWidth: b.strokeWidth
		} : {
			fill: null,
			stroke: b.stroke ?? m.main,
			strokeWidth: Math.max(1, b.strokeWidth)
		});
		V(K(o, t, u ?? void 0), "Draw path"), d(t.id), O(null);
	}, xt = async () => {
		if (!o || !le) return;
		let e = le;
		ue(null), await Dt("crop", {
			x: e.x,
			y: e.y,
			width: e.width,
			height: e.height
		});
	}, G = de && o ? Ut(o, de.id) : void 0, St = (e) => {
		if (!o || !G) return;
		let t = {
			...G,
			...e
		};
		s(q(o, G.id, {
			...e,
			box: Ur({
				...t,
				text: t.text || " "
			}),
			name: t.text.split("\n")[0].slice(0, 24) || "Text"
		}));
	}, Ct = () => {
		if (!o || !de) return;
		let e = Ut(o, de.id);
		if (fe(null), Ie.current?.focus({ preventScroll: !0 }), e) {
			if (e.text.trim()) V(o, de.fresh ? "Add text" : "Edit text");
			else {
				let t = Wt(o, e.id);
				de.fresh ? s(R().history.doc) : V(t, "Delete text");
			}
		}
	}, wt = async () => {
		if (!o || !B) return;
		let e = Ir(o, B, Xe), { modelFromPicture: t } = await import("./core-eUj9xEfb.js").then((e) => e.t), n = e && t(e.rgba, e.width, e.height, {
			name: B.name,
			viewAspect: .75
		});
		n ? be({ design: n }) : ke("This layer has nothing solid to push out.");
	}, Tt = () => {
		let e = R();
		return e.selection = w, e.selectedId = u, e.colours = m, e.clipboard = Be.current, e;
	}, Et = (e) => {
		s(e.doc), te(e.selection), d(e.selectedId), h(e.colours), Be.current = e.clipboard, Ge();
	}, Dt = async (e, n = {}) => {
		let r = Tt();
		Ne(!0);
		try {
			let i = await jr(r, e, n);
			Et(r), je(null), i?.file && zr(new Blob([i.file.data], { type: i.file.type }), i.file.name.replace(/^design/, t)), ke(i?.message ?? null), (e === "new_canvas" || e === "crop" || e === "canvas_size") && setTimeout(() => H(r.doc));
		} catch (e) {
			Et(r), je(e instanceof Error ? e.message : String(e));
		} finally {
			Ne(!1);
		}
	}, Ot = (e) => {
		let t = Tt(), n = e.blocked?.(t);
		if (n) return ke(n);
		let r = (e.params ?? []).filter((e) => e.type === "number" || e.type === "integer");
		if (!r.length) return void Dt(e.id);
		let i = r.map((e) => ({
			key: e.name,
			label: e.label,
			min: e.min ?? 0,
			max: e.max ?? 100,
			step: e.step ?? (e.type === "integer" ? 1 : .01),
			unit: e.unit,
			value: Number(typeof e.default == "function" ? e.default(t) : e.default ?? e.min ?? 0)
		})), a = 0;
		me({
			title: e.label.replace("…", ""),
			fields: i,
			preview: e.preview ? (t) => {
				clearTimeout(a), a = window.setTimeout(async () => {
					let n = Tt();
					n.dry = !0;
					try {
						await jr(n, e.id, t), s(n.doc);
					} catch {} finally {
						n.dry = !1, n.preview = null;
					}
				}, 120);
			} : void 0,
			apply: (t) => {
				clearTimeout(a), Dt(e.id, t);
			}
		});
	}, kt = async (e, t) => {
		try {
			let n = await createImageBitmap(e), r = Fr(n);
			n.close(), await Dt("place_image", {
				image: r,
				name: t
			}), p("move");
		} catch {
			je("That file is not a picture this browser can open.");
		}
	};
	async function At() {
		let e = await Br(".gleam,application/json");
		if (e) try {
			let t = await ur(JSON.parse(await e.text()), Vr);
			Ve.current.clear(), R().replace(t.doc, t.store), Et(R()), setTimeout(() => H(t.doc));
		} catch (e) {
			je(e instanceof Error ? e.message : "That file could not be opened.");
		}
	}
	let jt = o ? [
		{
			id: "open",
			menu: "File",
			label: "Open design…",
			keys: "Ctrl O",
			help: "Opens a saved .gleam design, with all its layers.",
			dev: "fromProject in packages/canvas (the .gleam JSON), then session().replace. MCP: design_open.",
			run: () => void At()
		},
		{
			id: "place",
			menu: "File",
			label: "Place a picture…",
			help: "Adds a picture from your computer as a new layer.",
			dev: Kr("place_image"),
			run: () => void Br("image/*").then((e) => e && kt(e, e.name.replace(/\.[^.]+$/, "")))
		},
		{
			id: "new-3d",
			menu: "File",
			label: "New 3D object…",
			help: "Builds a 3D object from shapes in 3D mode and places it on a new layer.",
			dev: "ModelMode (packages/react/src/model3d/ModelMode.tsx), then the place_model command with the picture and its design.",
			run: () => be({})
		},
		...[
			"png",
			"jpeg",
			"svg"
		].map((e) => ({
			id: `export-${e}`,
			menu: "File",
			label: e === "svg" ? "Export SVG (shapes and text stay vectors)" : `Export ${e.toUpperCase()}`,
			help: e === "svg" ? "Saves an SVG file; shapes and text stay sharp at any size." : `Saves the picture as a ${e.toUpperCase()} file.`,
			dev: `${Kr("export")} With format "${e}".`,
			run: () => void Dt("export", { format: e })
		})),
		...Er.filter((e) => e.menu && e.id !== "export" && e.id !== "place_image").map((e) => ({
			id: e.id,
			menu: e.menu,
			label: e.label,
			keys: e.keys,
			help: e.description,
			dev: Kr(e.id),
			run: () => Ot(e),
			enabled: () => !e.blocked?.(Tt())
		})),
		{
			id: "edit-3d",
			menu: "Layer",
			label: "Edit 3D layer…",
			help: "Opens the picked 3D layer in 3D mode; when you finish, the layer is drawn again in place.",
			dev: "RasterLayer.model3d reopened in ModelMode; redraw_model gives the layer its new picture and keeps its size on the canvas.",
			enabled: () => B?.kind === "raster" && B.model3d !== void 0,
			run: () => B?.kind === "raster" && be({
				layerId: B.id,
				design: B.model3d
			})
		},
		{
			id: "make-3d",
			menu: "Layer",
			label: "Make 3D (push out)…",
			help: "Pushes the picked layer’s shape (a logo, text, a cut-out) out into a solid in 3D mode; when you finish, it is placed as a new 3D layer.",
			dev: "layerPicture (the layer drawn alone) → modelFromPicture (scene3d: one extrude shape in its main colour) → ModelMode → place_model.",
			enabled: () => !!B && (B.kind !== "raster" || B.model3d === void 0),
			run: () => void wt()
		},
		{
			id: "mask-edit",
			menu: "Layer",
			label: "Paint on mask (on/off)",
			help: "While on, the brush and eraser paint the layer’s mask: brush shows the layer, eraser hides it.",
			dev: "maskEdit state in EditMode.tsx: strokes go to layer.mask instead of the layer pixels (packages/canvas/src/paint.ts).",
			enabled: () => !!B?.mask,
			run: () => re((e) => !e)
		},
		...[
			[
				"zoom-in",
				"Zoom in",
				"Ctrl +",
				"Shows the picture bigger.",
				() => et(1.25)
			],
			[
				"zoom-out",
				"Zoom out",
				"Ctrl −",
				"Shows the picture smaller.",
				() => et(.8)
			],
			[
				"fit",
				"Fit on screen",
				"Ctrl 0",
				"Shows the whole picture.",
				() => H()
			],
			[
				"actual",
				"Actual pixels",
				"Ctrl 1",
				"Shows one picture pixel per screen pixel.",
				() => et(1 / T.zoom)
			]
		].map(([e, t, n, r, i]) => ({
			id: e,
			menu: "View",
			label: t,
			keys: n,
			help: r,
			dev: "View only (view.zoom in EditMode.tsx); the document is not changed.",
			run: i
		}))
	] : [], Mt = () => void Dt("delete_layer"), Nt = (e) => {
		let t = jt.find((t) => t.id === e);
		t && (!t.enabled || t.enabled()) && t.run(), _e(null), Ce(null);
	}, Lt = (e) => {
		e.stopPropagation();
		let t = e.target, n = t.tagName === "TEXTAREA" || t.tagName === "INPUT" && ![
			"range",
			"checkbox",
			"color"
		].includes(t.type) || t.tagName === "SELECT";
		if (e.type === "keyup") {
			e.key === " " && (Re.current = !1);
			return;
		}
		if (n) {
			e.key === "Escape" && t.blur();
			return;
		}
		let r = e.ctrlKey || e.metaKey, i = e.key.toLowerCase(), a = r ? e.shiftKey ? {
			z: "redo",
			i: "invert_selection",
			n: "add_layer",
			"]": "arrange_front",
			"[": "arrange_back",
			"}": "arrange_front",
			"{": "arrange_back"
		} : {
			z: "undo",
			y: "redo",
			x: "cut",
			c: "copy",
			v: "paste",
			a: "select_all",
			d: "deselect",
			j: "duplicate_layer",
			e: "merge_down",
			i: "invert_colours",
			s: "save_design",
			o: "open",
			"]": "arrange_forward",
			"[": "arrange_backward",
			0: "fit",
			1: "actual",
			"=": "zoom-in",
			"+": "zoom-in",
			"-": "zoom-out"
		} : {};
		if (r && i === "k") {
			e.preventDefault(), Ce("");
			return;
		}
		if (r && a[i]) {
			e.preventDefault(), Nt(a[i]);
			return;
		}
		if (e.key === " ") {
			Re.current = !0, e.preventDefault();
			return;
		}
		if (e.key === "Escape") {
			Se === null ? pe ? (Je(), me(null)) : D ? O(null) : le ? ue(null) : w && te(null) : Ce(null);
			return;
		}
		if (e.key === "Enter") {
			D ? bt(!1) : le && xt();
			return;
		}
		if (e.key === "Delete" || e.key === "Backspace") {
			e.preventDefault(), e.altKey ? Nt("fill") : w && B?.kind === "raster" ? Nt("clear") : Mt();
			return;
		}
		if (e.key.startsWith("Arrow") && B && !B.locked && o) {
			e.preventDefault();
			let t = e.shiftKey ? 10 : 1, n = e.key === "ArrowLeft" ? -t : e.key === "ArrowRight" ? t : 0, r = e.key === "ArrowUp" ? -t : e.key === "ArrowDown" ? t : 0;
			V(q(o, B.id, { transform: {
				...B.transform,
				x: B.transform.x + n,
				y: B.transform.y + r
			} }), "Nudge");
			return;
		}
		if (e.key === "[" || e.key === "]") {
			_((t) => ({
				...t,
				size: Math.max(1, Math.min(1e3, Math.round(t.size * (e.key === "]" ? 1.2 : 1 / 1.2))))
			}));
			return;
		}
		if (i === "x") return void h((e) => ({
			main: e.second,
			second: e.main
		}));
		if (i === "d") return void h({
			main: "#1a1a1a",
			second: "#ffffff"
		});
		let s = ee.find((t) => t.key === i && !!t.shift === e.shiftKey) ?? ee.find((e) => e.key === i);
		s && zt(s.id);
	}, zt = (e) => {
		D && e !== "pen" && bt(!1), e !== "crop" && ue(null), p(e), ke(null);
	};
	A(() => {
		let e = (e) => {
			let t = [...e.clipboardData?.files ?? []].find((e) => e.type.startsWith("image/"));
			t && (e.preventDefault(), kt(t, "Pasted picture"));
		};
		return window.addEventListener("paste", e), () => window.removeEventListener("paste", e);
	}), A(() => {
		o && !pe && Se === null && !he && !de && (!Ie.current?.contains(document.activeElement) || document.activeElement === document.body) && Ie.current?.focus({ preventScroll: !0 });
	}, [
		o === null,
		pe,
		Se,
		he,
		de
	]);
	let Kt = async () => {
		if (o && n) {
			Ne(!0);
			try {
				n(await Rr(Ze(o)));
			} finally {
				Ne(!1);
			}
		}
	};
	if (c) return /* @__PURE__ */ F("div", {
		className: "gs-edit gs-edit--message",
		children: [/* @__PURE__ */ P("p", { children: c }), /* @__PURE__ */ P("button", {
			type: "button",
			className: "gs-edit__btn",
			onClick: i,
			children: "Close"
		})]
	});
	if (!o) return /* @__PURE__ */ P("div", {
		className: "gs-edit gs-edit--message",
		children: "Opening…"
	});
	let en = ce(f), J = R().history.list(), tn = ne && !!B?.mask, nn = Se === null ? [] : jt.filter((e) => e.label.toLowerCase().includes(Se.toLowerCase())).slice(0, 12), an = G && (() => {
		let e = G.transform, t = Zt(G);
		return {
			left: T.x + (e.x + t.x * e.scaleX) * T.zoom,
			top: T.y + e.y * T.zoom,
			fontSize: G.size * T.zoom * e.scaleY,
			width: Math.max(80, (G.box.width + G.size) * T.zoom * e.scaleX),
			rotation: e.rotation
		};
	})();
	return /* @__PURE__ */ F("div", {
		className: "gs-edit",
		ref: Ie,
		tabIndex: -1,
		onKeyDown: Lt,
		onKeyUp: Lt,
		children: [
			/* @__PURE__ */ F("header", {
				className: "gs-edit__top",
				children: [
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-edit__btn gs-edit__btn--ghost",
						onClick: i,
						title: "Leave Edit mode without keeping changes",
						children: "← Back"
					}),
					/* @__PURE__ */ P("strong", {
						className: "gs-edit__title",
						children: t
					}),
					/* @__PURE__ */ P("nav", {
						className: "gs-edit__menus",
						"aria-label": "Menus",
						children: Gr.map((e) => /* @__PURE__ */ F("div", {
							className: "gs-edit__menu",
							children: [/* @__PURE__ */ P("button", {
								type: "button",
								className: `gs-edit__menubtn ${he === e ? "is-open" : ""}`,
								onClick: () => _e(he === e ? null : e),
								onMouseEnter: () => he && _e(e),
								children: e
							}), he === e && /* @__PURE__ */ F("ul", {
								className: "gs-edit__dropdown",
								role: "menu",
								children: [jt.filter((t) => t.menu === e).map((e) => /* @__PURE__ */ P("li", {
									onMouseEnter: () => I(e.id),
									children: /* @__PURE__ */ F("button", {
										type: "button",
										role: "menuitem",
										disabled: e.enabled ? !e.enabled() : !1,
										onClick: () => Nt(e.id),
										onFocus: () => I(e.id),
										children: [/* @__PURE__ */ P("span", { children: e.label }), e.keys && /* @__PURE__ */ P("kbd", { children: e.keys })]
									})
								}, e.id)), /* @__PURE__ */ P("li", {
									className: "gs-edit__menuhelp",
									role: "none",
									children: (() => {
										let t = jt.find((t) => t.id === xe && t.menu === e);
										return t ? /* @__PURE__ */ F(N, { children: [t.help, /* @__PURE__ */ P(se, { text: t.dev })] }) : "Point at an item to see what it does.";
									})()
								})]
							})]
						}, e))
					}),
					/* @__PURE__ */ F("button", {
						type: "button",
						className: "gs-edit__search",
						onClick: () => Ce(""),
						title: "Find any command (Ctrl K)",
						children: [
							/* @__PURE__ */ P(Nr, {
								name: "search",
								size: 15
							}),
							" Find a command ",
							/* @__PURE__ */ P("kbd", { children: "Ctrl K" })
						]
					}),
					/* @__PURE__ */ P("span", { className: "gs-edit__spacer" }),
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-edit__icon",
						onClick: Ke,
						disabled: !R().history.canUndo,
						title: "Undo (Ctrl Z)",
						children: /* @__PURE__ */ P(Nr, { name: "undo" })
					}),
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-edit__icon",
						onClick: qe,
						disabled: !R().history.canRedo,
						title: "Redo (Ctrl Shift Z)",
						children: /* @__PURE__ */ P(Nr, { name: "redo" })
					}),
					/* @__PURE__ */ F("button", {
						type: "button",
						className: "gs-edit__zoom",
						onClick: () => H(),
						title: "Fit on screen (Ctrl 0)",
						children: [Math.round(T.zoom * 100), "%"]
					}),
					n && /* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-edit__btn gs-edit__btn--primary",
						onClick: () => void Kt(),
						disabled: Me,
						children: r
					})
				]
			}),
			/* @__PURE__ */ F("div", {
				className: "gs-edit__body",
				children: [/* @__PURE__ */ F("div", {
					className: "gs-edit__stage",
					ref: Pe,
					children: [
						/* @__PURE__ */ P("canvas", {
							ref: Fe,
							className: `gs-edit__canvas gs-edit__canvas--${Re.current || f === "hand" ? "hand" : f}`,
							onPointerDown: gt,
							onPointerMove: W,
							onPointerUp: vt,
							onPointerLeave: () => De(null),
							onWheel: yt,
							onDoubleClick: () => f === "pen" && D && bt(!1)
						}),
						G && an && /* @__PURE__ */ P("textarea", {
							className: "gs-edit__textedit",
							autoFocus: !0,
							value: G.text,
							placeholder: "Type here",
							onChange: (e) => St({ text: e.target.value }),
							onBlur: Ct,
							onKeyDown: (e) => {
								(e.key === "Escape" || e.key === "Enter" && (e.metaKey || e.ctrlKey)) && (e.preventDefault(), e.target.blur());
							},
							style: {
								left: an.left,
								top: an.top,
								width: an.width,
								font: Yn({
									...G,
									size: an.fontSize
								}),
								lineHeight: G.lineHeight,
								color: G.color,
								textAlign: G.align,
								transform: `rotate(${an.rotation}rad)`,
								height: (G.text.split("\n").length * G.lineHeight + .4) * an.fontSize
							}
						}),
						Ae && /* @__PURE__ */ F("div", {
							className: "gs-edit__problem",
							role: "alert",
							children: [
								/* @__PURE__ */ P("strong", { children: "Could not do that." }),
								" ",
								/* @__PURE__ */ P("span", { children: Ae }),
								/* @__PURE__ */ P("button", {
									type: "button",
									"aria-label": "Dismiss",
									onClick: () => je(null),
									children: "×"
								})
							]
						}),
						/* @__PURE__ */ F("div", {
							className: "gs-edit__options",
							role: "toolbar",
							"aria-label": `${en.label} options`,
							children: [
								/* @__PURE__ */ P("span", {
									className: "gs-edit__optname",
									children: tn && (f === "brush" || f === "eraser") ? `${en.label} on mask` : en.label
								}),
								/* @__PURE__ */ P(ei, {
									tool: f,
									brush: g,
									setBrush: _,
									wand: v,
									setWand: y,
									shapeStyle: b,
									setShapeStyle: x,
									textStyle: S,
									setTextStyle: C,
									pen: D,
									finishPen: bt,
									cropRect: le,
									applyCrop: xt,
									cancelCrop: () => ue(null)
								}),
								/* @__PURE__ */ F("span", {
									className: "gs-edit__hint",
									children: [Oe ?? en.hint, !Oe && /* @__PURE__ */ P(se, { text: en.dev })]
								})
							]
						}),
						/* @__PURE__ */ F("div", {
							className: "gs-edit__dock",
							role: "toolbar",
							"aria-label": "Tools",
							children: [/* @__PURE__ */ F("div", {
								className: "gs-edit__colors",
								title: "Main and second colour (X swaps, D resets)",
								children: [
									/* @__PURE__ */ P("label", {
										className: "gs-edit__swatch gs-edit__swatch--main",
										style: { background: m.main },
										children: /* @__PURE__ */ P("input", {
											type: "color",
											"aria-label": "Main colour",
											value: m.main,
											onChange: (e) => h((t) => ({
												...t,
												main: e.target.value
											}))
										})
									}),
									/* @__PURE__ */ P("label", {
										className: "gs-edit__swatch gs-edit__swatch--second",
										style: { background: m.second },
										children: /* @__PURE__ */ P("input", {
											type: "color",
											"aria-label": "Second colour",
											value: m.second,
											onChange: (e) => h((t) => ({
												...t,
												second: e.target.value
											}))
										})
									}),
									/* @__PURE__ */ P("button", {
										type: "button",
										className: "gs-edit__swap",
										onClick: () => h((e) => ({
											main: e.second,
											second: e.main
										})),
										title: "Swap colours (X)",
										children: /* @__PURE__ */ P(Nr, {
											name: "swap",
											size: 13
										})
									})
								]
							}), ae.map((e) => /* @__PURE__ */ P("div", {
								className: "gs-edit__group",
								"aria-label": e.name,
								children: e.tools.map((e) => /* @__PURE__ */ P("button", {
									type: "button",
									className: `gs-edit__tool ${f === e.id ? "is-active" : ""}`,
									"aria-pressed": f === e.id,
									title: `${e.label} (${e.shift ? "Shift " : ""}${e.key.toUpperCase()})`,
									onClick: () => zt(e.id),
									children: /* @__PURE__ */ P(Nr, { name: e.id })
								}, e.id))
							}, e.name))]
						})
					]
				}), /* @__PURE__ */ F("aside", {
					className: "gs-edit__side",
					children: [/* @__PURE__ */ F("div", {
						className: "gs-edit__tabs",
						role: "tablist",
						children: [/* @__PURE__ */ P("button", {
							type: "button",
							role: "tab",
							"aria-selected": we === "layers",
							className: we === "layers" ? "is-active" : "",
							onClick: () => Te("layers"),
							children: "Layers"
						}), /* @__PURE__ */ P("button", {
							type: "button",
							role: "tab",
							"aria-selected": we === "history",
							className: we === "history" ? "is-active" : "",
							onClick: () => Te("history"),
							children: "History"
						})]
					}), we === "layers" ? /* @__PURE__ */ F(N, { children: [
						/* @__PURE__ */ P(ni, {
							doc: o,
							host: Xe,
							selectedId: u,
							maskEdit: ne,
							onSelect: (e) => {
								d(e), re(!1);
							},
							onMaskSelect: (e) => {
								d(e), re(!0);
							},
							onChange: (e, t, n) => V(q(o, e, t), n),
							onReorder: (e, t) => {
								let n = o.layers.findIndex((t) => t.id === e);
								V(Gt(o, e, t - n), "Reorder");
							}
						}),
						/* @__PURE__ */ F("div", {
							className: "gs-edit__layerbar",
							children: [
								/* @__PURE__ */ P("button", {
									type: "button",
									className: "gs-edit__icon",
									title: "New picture layer",
									onClick: () => Nt("new-layer"),
									children: /* @__PURE__ */ P(Nr, { name: "plus" })
								}),
								/* @__PURE__ */ P("button", {
									type: "button",
									className: "gs-edit__icon",
									title: "Duplicate (Ctrl J)",
									disabled: !B,
									onClick: () => Nt("duplicate"),
									children: /* @__PURE__ */ P(Nr, { name: "copy" })
								}),
								/* @__PURE__ */ P("button", {
									type: "button",
									className: "gs-edit__icon",
									title: "Add mask",
									disabled: !B || !!B.mask,
									onClick: () => Nt("mask-add"),
									children: /* @__PURE__ */ P(Nr, { name: "mask" })
								}),
								/* @__PURE__ */ P("button", {
									type: "button",
									className: "gs-edit__icon",
									title: "Merge down (Ctrl E)",
									disabled: !B || o.layers.indexOf(B) === 0,
									onClick: () => Nt("merge"),
									children: /* @__PURE__ */ P(Nr, { name: "merge" })
								}),
								/* @__PURE__ */ P("button", {
									type: "button",
									className: "gs-edit__icon",
									title: "Delete layer",
									disabled: !B,
									onClick: Mt,
									children: /* @__PURE__ */ P(Nr, { name: "trash" })
								})
							]
						}),
						B && /* @__PURE__ */ P(ii, {
							layer: B,
							live: (e) => s(q(o, B.id, e)),
							commit: (e, t) => V(q(o, B.id, e), t),
							commitLive: (e) => V(o, e),
							measure: Ur
						}, B.id),
						/* @__PURE__ */ F("div", {
							className: "gs-edit__canvasprops",
							children: [
								/* @__PURE__ */ P("span", { children: "Canvas" }),
								/* @__PURE__ */ F("span", {
									className: "gs-edit__muted",
									children: [
										o.width,
										" × ",
										o.height
									]
								}),
								/* @__PURE__ */ F("label", {
									className: "gs-edit__inline",
									children: [/* @__PURE__ */ P("input", {
										type: "checkbox",
										checked: !o.background,
										onChange: (e) => V({
											...o,
											background: e.target.checked ? null : "#ffffff"
										}, "Canvas colour")
									}), "Transparent"]
								}),
								o.background && /* @__PURE__ */ P("input", {
									type: "color",
									"aria-label": "Canvas colour",
									value: o.background,
									onChange: (e) => V({
										...o,
										background: e.target.value
									}, "Canvas colour")
								})
							]
						})
					] }) : /* @__PURE__ */ P("ol", {
						className: "gs-edit__history",
						children: J.steps.map((e, t) => /* @__PURE__ */ P("li", { children: /* @__PURE__ */ P("button", {
							type: "button",
							className: t === J.at ? "is-active" : t > J.at ? "is-future" : "",
							onClick: () => s(R().history.goTo(t)),
							children: e.label
						}) }, t))
					})]
				})]
			}),
			k && /* @__PURE__ */ P("div", {
				className: "gs-edit__model3d",
				children: /* @__PURE__ */ P(ge, {
					fallback: /* @__PURE__ */ P("div", {
						className: "gs-edit--message",
						children: "Loading 3D mode…"
					}),
					children: /* @__PURE__ */ P(Pr, {
						open: k.design,
						title: k.layerId ? B?.name ?? "3D object" : "New 3D object",
						doneLabel: k.layerId ? "Update the layer" : "Place in design",
						onClose: () => be(null),
						onDone: (e, t) => {
							let n = k.layerId;
							be(null), (async () => {
								let r = await createImageBitmap(e), i = Fr(r);
								r.close(), n ? await Dt("redraw_model", {
									layer: n,
									image: i,
									model: JSON.stringify(t)
								}) : (await Dt("place_model", {
									image: i,
									model: JSON.stringify(t),
									name: "3D object"
								}), p("move"));
							})();
						}
					})
				})
			}),
			pe && /* @__PURE__ */ P(oi, {
				spec: pe,
				onCancel: () => {
					Je(), me(null);
				},
				onApply: (e) => {
					pe.apply(e), me(null);
				}
			}),
			Se !== null && /* @__PURE__ */ P("div", {
				className: "gs-edit__scrim",
				onPointerDown: () => Ce(null),
				children: /* @__PURE__ */ F("div", {
					className: "gs-edit__palette",
					onPointerDown: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ P("input", {
						autoFocus: !0,
						placeholder: "What do you want to do?",
						value: Se,
						onChange: (e) => Ce(e.target.value),
						onKeyDown: (e) => {
							e.key === "Enter" && nn[0] && (e.preventDefault(), Nt(nn[0].id)), e.key === "Escape" && Ce(null);
						}
					}), /* @__PURE__ */ F("ul", { children: [nn.map((e) => /* @__PURE__ */ P("li", { children: /* @__PURE__ */ F("button", {
						type: "button",
						disabled: e.enabled ? !e.enabled() : !1,
						onClick: () => Nt(e.id),
						children: [/* @__PURE__ */ F("span", {
							className: "gs-edit__palitem",
							children: [
								/* @__PURE__ */ F("span", { children: [
									/* @__PURE__ */ P("span", {
										className: "gs-edit__muted",
										children: e.menu
									}),
									" ",
									e.label
								] }),
								/* @__PURE__ */ P("span", {
									className: "gs-edit__palhelp",
									children: e.help
								}),
								/* @__PURE__ */ P(se, { text: e.dev })
							]
						}), e.keys && /* @__PURE__ */ P("kbd", { children: e.keys })]
					}) }, e.id)), !nn.length && /* @__PURE__ */ P("li", {
						className: "gs-edit__muted",
						children: "Nothing matches."
					})] })]
				})
			})
		]
	});
}
function Qr({ label: e, value: t, min: n, max: r, step: i, unit: a, onChange: o }) {
	return /* @__PURE__ */ F("label", {
		className: "gs-edit__slider",
		children: [
			/* @__PURE__ */ P("span", { children: e }),
			/* @__PURE__ */ P("input", {
				type: "range",
				min: n,
				max: r,
				step: i,
				value: t,
				onChange: (e) => o(Number(e.target.value))
			}),
			/* @__PURE__ */ F("output", { children: [Math.round(t * 100) / 100, a] })
		]
	});
}
function $r({ label: e, value: t, onChange: n }) {
	return /* @__PURE__ */ F("span", {
		className: "gs-edit__colorpick",
		children: [
			/* @__PURE__ */ P("span", { children: e }),
			/* @__PURE__ */ P("input", {
				type: "checkbox",
				"aria-label": `${e} on`,
				checked: t !== null,
				onChange: (e) => n(e.target.checked ? "#1a1a1a" : null)
			}),
			t !== null && /* @__PURE__ */ P("input", {
				type: "color",
				"aria-label": e,
				value: t,
				onChange: (e) => n(e.target.value)
			})
		]
	});
}
function ei(e) {
	switch (e.tool) {
		case "brush":
		case "eraser":
		case "clone": return /* @__PURE__ */ F(N, { children: [
			/* @__PURE__ */ P(Qr, {
				label: "Size",
				min: 1,
				max: 500,
				step: 1,
				unit: "px",
				value: e.brush.size,
				onChange: (t) => e.setBrush((e) => ({
					...e,
					size: t
				}))
			}),
			/* @__PURE__ */ P(Qr, {
				label: "Hardness",
				min: 0,
				max: 1,
				step: .01,
				value: e.brush.hardness,
				onChange: (t) => e.setBrush((e) => ({
					...e,
					hardness: t
				}))
			}),
			/* @__PURE__ */ P(Qr, {
				label: "Flow",
				min: .02,
				max: 1,
				step: .01,
				value: e.brush.flow,
				onChange: (t) => e.setBrush((e) => ({
					...e,
					flow: t
				}))
			})
		] });
		case "wand":
		case "bucket": return /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P(Qr, {
			label: "Tolerance",
			min: 0,
			max: 255,
			step: 1,
			value: e.wand.tolerance,
			onChange: (t) => e.setWand((e) => ({
				...e,
				tolerance: t
			}))
		}), /* @__PURE__ */ F("label", {
			className: "gs-edit__inline",
			children: [/* @__PURE__ */ P("input", {
				type: "checkbox",
				checked: e.wand.contiguous,
				onChange: (t) => e.setWand((e) => ({
					...e,
					contiguous: t.target.checked
				}))
			}), "Only touching pixels"]
		})] });
		case "rect":
		case "ellipse":
		case "line":
		case "pen": return /* @__PURE__ */ F(N, { children: [
			e.tool !== "line" && /* @__PURE__ */ P($r, {
				label: "Fill",
				value: e.shapeStyle.fill,
				onChange: (t) => e.setShapeStyle((e) => ({
					...e,
					fill: t
				}))
			}),
			/* @__PURE__ */ P($r, {
				label: "Outline",
				value: e.shapeStyle.stroke,
				onChange: (t) => e.setShapeStyle((e) => ({
					...e,
					stroke: t
				}))
			}),
			/* @__PURE__ */ P(Qr, {
				label: "Width",
				min: 0,
				max: 100,
				step: 1,
				unit: "px",
				value: e.shapeStyle.strokeWidth,
				onChange: (t) => e.setShapeStyle((e) => ({
					...e,
					strokeWidth: t
				}))
			}),
			e.tool === "rect" && /* @__PURE__ */ P(Qr, {
				label: "Corners",
				min: 0,
				max: 300,
				step: 1,
				unit: "px",
				value: e.shapeStyle.radius,
				onChange: (t) => e.setShapeStyle((e) => ({
					...e,
					radius: t
				}))
			}),
			e.tool === "pen" && e.pen && e.pen.length > 1 && /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("button", {
				type: "button",
				className: "gs-edit__btn",
				onClick: () => e.finishPen(!1),
				children: "Finish open"
			}), /* @__PURE__ */ P("button", {
				type: "button",
				className: "gs-edit__btn",
				onClick: () => e.finishPen(!0),
				children: "Close shape"
			})] })
		] });
		case "text": return /* @__PURE__ */ F(N, { children: [
			/* @__PURE__ */ P("select", {
				"aria-label": "Font",
				value: e.textStyle.font,
				onChange: (t) => e.setTextStyle((e) => ({
					...e,
					font: t.target.value
				})),
				children: Wr.map((e) => /* @__PURE__ */ P("option", {
					value: e,
					children: e.split(",")[0].replace(/"/g, "")
				}, e))
			}),
			/* @__PURE__ */ P(Qr, {
				label: "Size",
				min: 8,
				max: 400,
				step: 1,
				unit: "px",
				value: e.textStyle.size,
				onChange: (t) => e.setTextStyle((e) => ({
					...e,
					size: t
				}))
			}),
			/* @__PURE__ */ F("select", {
				"aria-label": "Weight",
				value: e.textStyle.weight,
				onChange: (t) => e.setTextStyle((e) => ({
					...e,
					weight: Number(t.target.value)
				})),
				children: [
					/* @__PURE__ */ P("option", {
						value: 400,
						children: "Regular"
					}),
					/* @__PURE__ */ P("option", {
						value: 700,
						children: "Bold"
					}),
					/* @__PURE__ */ P("option", {
						value: 900,
						children: "Heavy"
					})
				]
			})
		] });
		case "crop": return e.cropRect ? /* @__PURE__ */ F(N, { children: [
			/* @__PURE__ */ F("span", {
				className: "gs-edit__muted",
				children: [
					Math.round(e.cropRect.width),
					" × ",
					Math.round(e.cropRect.height)
				]
			}),
			/* @__PURE__ */ P("button", {
				type: "button",
				className: "gs-edit__btn gs-edit__btn--primary",
				onClick: e.applyCrop,
				children: "Crop"
			}),
			/* @__PURE__ */ P("button", {
				type: "button",
				className: "gs-edit__btn",
				onClick: e.cancelCrop,
				children: "Cancel"
			})
		] }) : null;
		default: return null;
	}
}
function ti({ doc: e, layer: t, host: n, mask: r }) {
	let i = j(null);
	return A(() => {
		let a = i.current;
		if (!a) return;
		let o = Math.min(44 / e.width, 44 / e.height);
		a.width = Math.max(1, Math.round(e.width * o)), a.height = Math.max(1, Math.round(e.height * o));
		let s = a.getContext("2d");
		if (s.clearRect(0, 0, a.width, a.height), s.save(), s.scale(o, o), r && t.mask) {
			s.fillStyle = "#000", s.fillRect(0, 0, e.width, e.height);
			let r = n.image(t.mask);
			if (r) {
				let t = n.surface(e.width, e.height);
				t.ctx.fillStyle = "#fff", t.ctx.fillRect(0, 0, e.width, e.height), t.ctx.globalCompositeOperation = "destination-in", t.ctx.drawImage(r, 0, 0), s.drawImage(t.canvas, 0, 0);
			}
		} else nr(s, e, {
			...t,
			opacity: 1,
			blend: "normal",
			mask: void 0,
			maskOff: !0
		}, n);
		s.restore();
	}), /* @__PURE__ */ P("canvas", {
		ref: i,
		className: "gs-edit__thumb"
	});
}
function ni({ doc: e, host: t, selectedId: n, maskEdit: r, onSelect: i, onMaskSelect: a, onChange: o, onReorder: s }) {
	let [c, l] = M(null), [u, d] = M(null);
	return e.layers.length ? /* @__PURE__ */ P("ul", {
		className: "gs-edit__layers",
		children: [...e.layers].reverse().map((f) => {
			let p = e.layers.indexOf(f);
			return /* @__PURE__ */ F("li", {
				className: `gs-edit__layer ${f.id === n ? "is-active" : ""} ${f.visible ? "" : "is-hidden"} ${u === f.id ? "is-dragging" : ""}`,
				draggable: c !== f.id,
				onDragStart: (e) => {
					d(f.id), e.dataTransfer.effectAllowed = "move";
				},
				onDragEnd: () => d(null),
				onDragOver: (e) => e.preventDefault(),
				onDrop: (e) => {
					e.preventDefault(), u && u !== f.id && s(u, p), d(null);
				},
				onClick: () => i(f.id),
				children: [
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-edit__icon gs-edit__icon--sm",
						title: f.visible ? "Hide" : "Show",
						onClick: (e) => (e.stopPropagation(), o(f.id, { visible: !f.visible }, f.visible ? "Hide layer" : "Show layer")),
						children: /* @__PURE__ */ P(Nr, {
							name: f.visible ? "eye" : "eyeOff",
							size: 16
						})
					}),
					/* @__PURE__ */ P("span", {
						className: `gs-edit__thumbwrap ${f.id === n && !r ? "is-target" : ""}`,
						children: /* @__PURE__ */ P(ti, {
							doc: e,
							layer: f,
							host: t
						})
					}),
					f.mask && /* @__PURE__ */ P("span", {
						className: `gs-edit__thumbwrap ${f.id === n && r ? "is-target" : ""} ${f.maskOff ? "is-off" : ""}`,
						title: "Mask: click to paint on it",
						onClick: (e) => (e.stopPropagation(), a(f.id)),
						children: /* @__PURE__ */ P(ti, {
							doc: e,
							layer: f,
							host: t,
							mask: !0
						})
					}),
					c === f.id ? /* @__PURE__ */ P("input", {
						className: "gs-edit__rename",
						autoFocus: !0,
						defaultValue: f.name,
						onClick: (e) => e.stopPropagation(),
						onBlur: (e) => {
							l(null), e.target.value.trim() && e.target.value !== f.name && o(f.id, { name: e.target.value.trim() }, "Rename");
						},
						onKeyDown: (e) => {
							e.key === "Enter" && e.target.blur(), e.key === "Escape" && l(null);
						}
					}) : /* @__PURE__ */ F("span", {
						className: "gs-edit__layername",
						onDoubleClick: () => l(f.id),
						title: "Double-click to rename",
						children: [f.name, /* @__PURE__ */ P("small", { children: f.kind === "raster" ? "picture" : f.kind === "text" ? "text" : f.shape.type === "path" ? "path" : "shape" })]
					}),
					/* @__PURE__ */ P("button", {
						type: "button",
						className: `gs-edit__icon gs-edit__icon--sm ${f.locked ? "is-on" : ""}`,
						title: f.locked ? "Unlock" : "Lock",
						onClick: (e) => (e.stopPropagation(), o(f.id, { locked: !f.locked }, f.locked ? "Unlock" : "Lock")),
						children: /* @__PURE__ */ P(Nr, {
							name: f.locked ? "lock" : "unlock",
							size: 15
						})
					})
				]
			}, f.id);
		})
	}) : /* @__PURE__ */ P("p", {
		className: "gs-edit__empty",
		children: "No layers yet. Draw, type, paint, or place a picture."
	});
}
var ri = (e) => Math.round(e * 180 / Math.PI * 10) / 10;
function ii({ layer: e, live: t, commit: n, commitLive: r, measure: i }) {
	let a = e.transform, o = (e, t, r, i = "") => /* @__PURE__ */ F("label", {
		className: "gs-edit__num",
		children: [
			/* @__PURE__ */ P("span", { children: e }),
			/* @__PURE__ */ P("input", {
				type: "number",
				value: Math.round(t * 10) / 10,
				onChange: (t) => {
					let i = Number(t.target.value);
					Number.isFinite(i) && n(r(i), `Set ${e.toLowerCase()}`);
				}
			}),
			i && /* @__PURE__ */ P("em", { children: i })
		]
	}), s = (t, r) => {
		let a = {
			...e,
			...t
		};
		n({
			...t,
			box: i({
				...a,
				text: a.text || " "
			})
		}, r);
	};
	return /* @__PURE__ */ F("section", {
		className: "gs-edit__props",
		children: [
			/* @__PURE__ */ F("label", {
				className: "gs-edit__slider",
				children: [
					/* @__PURE__ */ P("span", { children: "Opacity" }),
					/* @__PURE__ */ P("input", {
						type: "range",
						min: 0,
						max: 1,
						step: .01,
						value: e.opacity,
						onChange: (e) => t({ opacity: Number(e.target.value) }),
						onPointerUp: () => r("Opacity"),
						onKeyUp: () => r("Opacity")
					}),
					/* @__PURE__ */ F("output", { children: [Math.round(e.opacity * 100), "%"] })
				]
			}),
			/* @__PURE__ */ F("label", {
				className: "gs-edit__field",
				children: [/* @__PURE__ */ P("span", { children: "Mix" }), /* @__PURE__ */ P("select", {
					value: e.blend,
					onChange: (e) => n({ blend: e.target.value }, "Blend mode"),
					children: At.map((e) => /* @__PURE__ */ P("option", {
						value: e.id,
						children: e.label
					}, e.id))
				})]
			}),
			/* @__PURE__ */ F("div", {
				className: "gs-edit__grid",
				children: [
					o("X", a.x, (e) => ({ transform: {
						...a,
						x: e
					} })),
					o("Y", a.y, (e) => ({ transform: {
						...a,
						y: e
					} })),
					o("Width", a.scaleX * 100, (e) => ({ transform: {
						...a,
						scaleX: e / 100 || .01
					} }), "%"),
					o("Height", a.scaleY * 100, (e) => ({ transform: {
						...a,
						scaleY: e / 100 || .01
					} }), "%"),
					o("Turn", ri(a.rotation), (e) => ({ transform: {
						...a,
						rotation: e * Math.PI / 180
					} }), "°")
				]
			}),
			e.kind === "shape" && /* @__PURE__ */ P(ai, {
				layer: e,
				commit: n
			}),
			e.kind === "text" && /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("textarea", {
				className: "gs-edit__textprop",
				value: e.text,
				onChange: (e) => s({
					text: e.target.value,
					name: e.target.value.split("\n")[0].slice(0, 24) || "Text"
				}, "Edit text"),
				rows: 2
			}), /* @__PURE__ */ F("div", {
				className: "gs-edit__grid",
				children: [
					/* @__PURE__ */ F("label", {
						className: "gs-edit__field gs-edit__field--wide",
						children: [/* @__PURE__ */ P("span", { children: "Font" }), /* @__PURE__ */ P("select", {
							value: e.font,
							onChange: (e) => s({ font: e.target.value }, "Font"),
							children: Wr.map((e) => /* @__PURE__ */ P("option", {
								value: e,
								children: e.split(",")[0].replace(/"/g, "")
							}, e))
						})]
					}),
					o("Size", e.size, (t) => ({
						size: Math.max(1, t),
						box: i({
							...e,
							size: Math.max(1, t)
						})
					}), "px"),
					/* @__PURE__ */ F("label", {
						className: "gs-edit__field",
						children: [/* @__PURE__ */ P("span", { children: "Weight" }), /* @__PURE__ */ F("select", {
							value: e.weight,
							onChange: (e) => s({ weight: Number(e.target.value) }, "Weight"),
							children: [
								/* @__PURE__ */ P("option", {
									value: 400,
									children: "Regular"
								}),
								/* @__PURE__ */ P("option", {
									value: 700,
									children: "Bold"
								}),
								/* @__PURE__ */ P("option", {
									value: 900,
									children: "Heavy"
								})
							]
						})]
					}),
					/* @__PURE__ */ F("label", {
						className: "gs-edit__field",
						children: [/* @__PURE__ */ P("span", { children: "Colour" }), /* @__PURE__ */ P("input", {
							type: "color",
							value: e.color,
							onChange: (e) => n({ color: e.target.value }, "Text colour")
						})]
					}),
					/* @__PURE__ */ F("label", {
						className: "gs-edit__field",
						children: [/* @__PURE__ */ P("span", { children: "Align" }), /* @__PURE__ */ F("select", {
							value: e.align,
							onChange: (e) => s({ align: e.target.value }, "Align"),
							children: [
								/* @__PURE__ */ P("option", {
									value: "left",
									children: "Left"
								}),
								/* @__PURE__ */ P("option", {
									value: "center",
									children: "Centre"
								}),
								/* @__PURE__ */ P("option", {
									value: "right",
									children: "Right"
								})
							]
						})]
					}),
					/* @__PURE__ */ F("label", {
						className: "gs-edit__inline",
						children: [/* @__PURE__ */ P("input", {
							type: "checkbox",
							checked: e.italic,
							onChange: (e) => s({ italic: e.target.checked }, "Italic")
						}), "Italic"]
					})
				]
			})] })
		]
	});
}
function ai({ layer: e, commit: t }) {
	return /* @__PURE__ */ F("div", {
		className: "gs-edit__grid",
		children: [
			e.shape.type !== "line" && /* @__PURE__ */ P($r, {
				label: "Fill",
				value: e.fill,
				onChange: (e) => t({ fill: e }, "Fill colour")
			}),
			/* @__PURE__ */ P($r, {
				label: "Outline",
				value: e.stroke,
				onChange: (e) => t({ stroke: e }, "Outline colour")
			}),
			/* @__PURE__ */ F("label", {
				className: "gs-edit__num",
				children: [
					/* @__PURE__ */ P("span", { children: "Outline" }),
					/* @__PURE__ */ P("input", {
						type: "number",
						min: 0,
						value: e.strokeWidth,
						onChange: (e) => t({ strokeWidth: Math.max(0, Number(e.target.value) || 0) }, "Outline width")
					}),
					/* @__PURE__ */ P("em", { children: "px" })
				]
			}),
			e.shape.type === "rect" && /* @__PURE__ */ F("label", {
				className: "gs-edit__num",
				children: [
					/* @__PURE__ */ P("span", { children: "Corners" }),
					/* @__PURE__ */ P("input", {
						type: "number",
						min: 0,
						value: e.shape.radius,
						onChange: (n) => t({ shape: {
							...e.shape,
							radius: Math.max(0, Number(n.target.value) || 0)
						} }, "Corners")
					}),
					/* @__PURE__ */ P("em", { children: "px" })
				]
			})
		]
	});
}
function oi({ spec: e, onCancel: t, onApply: n }) {
	let [r, i] = M(() => Object.fromEntries(e.fields.map((e) => [e.key, e.value]))), a = (t, n) => {
		let a = {
			...r,
			[t]: n
		};
		i(a), e.preview?.(a);
	};
	return /* @__PURE__ */ P("div", {
		className: "gs-edit__scrim",
		children: /* @__PURE__ */ F("form", {
			className: "gs-edit__dialog",
			onSubmit: (e) => {
				e.preventDefault(), n(r);
			},
			children: [
				/* @__PURE__ */ P("h3", { children: e.title }),
				e.fields.map((e) => e.max - e.min > 1e3 ? /* @__PURE__ */ F("label", {
					className: "gs-edit__num gs-edit__num--wide",
					children: [
						/* @__PURE__ */ P("span", { children: e.label }),
						/* @__PURE__ */ P("input", {
							type: "number",
							min: e.min,
							max: e.max,
							step: e.step,
							value: r[e.key],
							onChange: (t) => a(e.key, Math.min(e.max, Math.max(e.min, Number(t.target.value) || e.min)))
						}),
						e.unit && /* @__PURE__ */ P("em", { children: e.unit })
					]
				}, e.key) : /* @__PURE__ */ P(Qr, {
					label: e.label,
					min: e.min,
					max: e.max,
					step: e.step,
					unit: e.unit,
					value: r[e.key],
					onChange: (t) => a(e.key, t)
				}, e.key)),
				/* @__PURE__ */ F("div", {
					className: "gs-edit__dialogbar",
					children: [/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-edit__btn",
						onClick: t,
						children: "Cancel"
					}), /* @__PURE__ */ P("button", {
						type: "submit",
						className: "gs-edit__btn gs-edit__btn--primary",
						autoFocus: !0,
						children: "Apply"
					})]
				})
			]
		})
	});
}
//#endregion
//#region src/GleamEditor.tsx
var si = _e(() => import("./PhotoLab-CJ_1bOoR.js").then((e) => e.n).then((e) => ({ default: e.PhotoLab }))), ci = (e) => e.ops.backdrop?.mode, li = {
	maxSize: 2048,
	type: "image/webp",
	quality: .88
}, ui = 32, di = "the same photograph, the surface continued smoothly with the same material, colour and lighting as right around it, nothing new added, sharp focus", fi = "text, letters, words, logo, writing, new objects, pom pom, ball, flower, jewelry, pattern, stain, blotch, blurry, smudge", pi = (e) => Array.from({ length: Math.floor((e?.length ?? 0) / 4) }, (t, n) => ({
	x: e[n * 4],
	y: e[n * 4 + 1],
	width: e[n * 4 + 2],
	height: e[n * 4 + 3]
})), mi = [
	{
		key: "stickers",
		label: "Remove price stickers",
		title: "Reads the prices on the photo and paints the shop's price stickers out, so the photo stays right when the price changes."
	},
	{
		key: "lettering",
		label: "Repaint lettering and printed text",
		title: "For a character on a cover: paints the title and printed text out from the rest of the picture before the character is cut out. Does nothing for a whole box."
	},
	{
		key: "find",
		label: "Look the product up on the web (free; sends search words, not the photo)",
		title: "Reads the cover with a local model, searches the web (DuckDuckGo) with those words and uses the official pictures it finds. Free. The search words leave this computer; your photo never does."
	},
	{
		key: "thinParts",
		label: "Complete what the box hides, from official pictures",
		title: "Looks again along the character's outline for thin or detached parts (an antenna), and, when an official photo of this figure is found and lines up with the cover, finishes the parts the box's printing hides (a title band over the tail) from it, in this photo's colours. Those parts are flagged for you to check."
	},
	{
		key: "colour",
		label: "Match colours to the official picture",
		title: "Brings the box's colours to the product's own published picture. Needs the web lookup to find it.",
		needs: "find"
	},
	{
		key: "vivid",
		label: "Punchier colours",
		title: "After colours are matched to an official picture, make them 40% stronger: the punchy look of a ChatGPT redraw. Off keeps the published, softer colours.",
		needs: "colour"
	},
	{
		key: "look",
		label: "Brighten and sharpen",
		title: "The colour and sharpness look applied at the end."
	},
	{
		key: "gloss",
		label: "Studio gloss (changes the product; off unless ticked)",
		title: "Redraws the product as a glossy studio pack shot with Stable Diffusion, free, on this computer, about a minute. It changes the product itself: finish, small details and printed text may no longer match the real item, so the result is flagged for review. Needs npm run redraw:setup.",
		optIn: !0
	},
	{
		key: "enlarge",
		label: "Enlarge",
		title: "Makes the picture bigger with a local model. Printed text is enlarged the plain way, so the model cannot rewrite it; everything else gets its extra detail."
	},
	{
		key: "listing",
		label: "Write a title and description",
		title: "Writes a title and description with a local model, only from what was found. Needs the web lookup and the vision model (npm run vlm:setup).",
		needs: "find"
	}
];
function hi({ source: e, name: t, recipe: n, background: r, masks: i, repairs: a, enlargements: o, finishes: s, localApp: c, exportOptions: l, onDone: u, onCancel: d, doneLabel: f = "Done" }) {
	let [p, m] = M(null), [h, _] = M(null), [v, y] = M(e), [b, S] = M(null), [C, w] = M(null);
	A(() => {
		y(e), S(null), w(null);
	}, [e]);
	let ee = j(n);
	return A(() => {
		let n = new AbortController(), r = null;
		return m(null), _(null), (async () => {
			try {
				let i = typeof v == "string" ? await fe(v, n.signal) : v;
				if (r = await ue(i), n.signal.aborted) return;
				let a = t ?? (e instanceof File ? e.name : typeof e == "string" ? e.split("/").pop()?.split("?")[0] : void 0), o = x({
					width: r.width,
					height: r.height,
					name: a
				}, ee.current);
				m({
					image: r,
					editor: new g(o),
					blob: i
				});
			} catch (e) {
				n.signal.aborted || _(e instanceof Error ? e.message : "This photo couldn't be opened.");
			}
		})(), () => {
			n.abort(), r?.close();
		};
	}, [v, t]), h ? /* @__PURE__ */ F("div", {
		className: "gs-editor gs-editor--message",
		children: [/* @__PURE__ */ P("p", {
			className: "gs-error",
			children: h
		}), d && /* @__PURE__ */ P("button", {
			type: "button",
			className: "gs-button",
			onClick: d,
			children: "Close"
		})]
	}) : p ? /* @__PURE__ */ P(gi, {
		editor: p.editor,
		image: p.image,
		initialBackground: r,
		initialMasks: i,
		initialRepairs: a,
		initialEnlargements: o,
		initialFinishes: s,
		localApp: c,
		sourceBlob: b ? null : p.blob,
		startFrom: b,
		fullReport: C,
		onOpenProcessed: async (e, t, n) => {
			let r = await createImageBitmap(e, { premultiplyAlpha: "none" }), i = document.createElement("canvas");
			i.width = r.width, i.height = r.height;
			let a = i.getContext("2d", { willReadFrequently: !0 });
			a.drawImage(r, 0, 0);
			let o = a.getImageData(0, 0, i.width, i.height).data, s = new Uint8Array(i.width * i.height);
			for (let e = 0; e < s.length; e++) s[e] = o[e * 4 + 3];
			a.globalCompositeOperation = "destination-over", a.fillStyle = "#ffffff", a.fillRect(0, 0, i.width, i.height);
			let c = await new Promise((e, t) => i.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png")), l = {
				alpha: s,
				width: i.width,
				height: i.height
			};
			r.close(), S({
				mask: l,
				shadow: t
			}), w(n), y(c);
		},
		onBackToOriginal: b ? () => (S(null), w(null), y(e)) : void 0,
		onEdited: (e) => {
			ee.current = void 0, S(null), w(null), y(e);
		},
		exportOptions: {
			...li,
			...l
		},
		onDone: u,
		onCancel: d,
		doneLabel: f
	}) : /* @__PURE__ */ P("div", {
		className: "gs-editor gs-editor--message",
		children: "Opening photo…"
	});
}
function gi({ editor: a, image: s, initialBackground: c, initialMasks: l, initialRepairs: m, initialEnlargements: h, initialFinishes: g, localApp: v, sourceBlob: b, startFrom: x, fullReport: w, onOpenProcessed: ee, onBackToOriginal: re, onEdited: T, exportOptions: ie, onDone: ae, onCancel: E, doneLabel: se }) {
	let ce = be(a.subscribe, a.getSnapshot), { doc: O } = ce, le = j(null), he = j(null), _e = j(null), [k, ve] = M(null), [N, xe] = M({
		width: 0,
		height: 0
	}), [I, Se] = M(!1), [De, ke] = M(!1), [Ae, je] = M(!1), [Pe, Ie] = M(!1), [Re, ze] = M({
		tool: "tap",
		brush: .02,
		tolerance: 25
	}), [Be, He] = M(!1), [Ue, L] = M(null), [We, R] = M(null), [z, B] = M(null), [Ge, V] = M(() => /* @__PURE__ */ new Map()), Ke = O.recipe.finish, Je = Ke ? Ge.get(Ke.ref)?.bitmap : void 0, Ye = ye(() => Je ? o({
		width: Je.width,
		height: Je.height
	}) : null, [Je]), Ze = () => {
		Ae || a.clearFinish(), Ie(!1), je((e) => !e);
	}, $e = () => {
		Pe || a.clearFinish(), je(!1), Ie((e) => !e);
	}, H = ye(() => {
		let { width: e, height: t } = n(s.width, s.height), r = document.createElement("canvas");
		r.width = e, r.height = t;
		let i = r.getContext("2d", { willReadFrequently: !0 });
		return i.drawImage(s, 0, 0, e, t), {
			pixels: i.getImageData(0, 0, e, t).data,
			width: e,
			height: t
		};
	}, [s]);
	A(() => {
		try {
			let e = new qe(_e.current);
			return e.setSource(s), ve(e), () => e.dispose();
		} catch (e) {
			L(e instanceof Error ? e.message : "The preview could not start.");
		}
	}, [s]), A(() => {
		let e = new ResizeObserver(([e]) => {
			let { width: t, height: n } = e.contentRect;
			xe({
				width: t,
				height: n
			});
		});
		return e.observe(he.current), le.current?.focus({ preventScroll: !0 }), () => e.disconnect();
	}, []);
	let et = ye(() => I ? o(O.source) : Ye ?? (Ae ? u(O) : O), [
		I,
		Ae,
		O,
		Ye
	]), tt = _(et), nt = _(Ye ?? O, ie.maxSize), rt = Math.min((N.width - ui) / tt.width, (N.height - ui) / tt.height, 1), it = Math.max(1, Math.floor(tt.width * rt)), at = Math.max(1, Math.floor(tt.height * rt)), ot = O.recipe.mask, st = ye(() => i(H.pixels, H.width, H.height) > .5, [H]), [ct, lt] = M(() => /* @__PURE__ */ new Map()), ut = j(/* @__PURE__ */ new Map()), dt = (e, t) => {
		ut.current.set(e, t), lt((n) => new Map(n).set(e, t));
	}, ft = () => {
		let e = a.document.recipe.mask;
		return e.length ? t(H.pixels, H.width, H.height, e, ut.current) : null;
	}, pt = ye(() => ot.length ? t(H.pixels, H.width, H.height, ot, ct) : null, [
		ot,
		H,
		ct
	]), mt = r(ot, ct).length;
	A(() => {
		if (!l) return;
		let e = !1;
		return (async () => {
			for (let [t, n] of Object.entries(l)) try {
				let r = typeof n == "string" ? await fe(n) : n, i = await me(r);
				e || dt(t, i);
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [l]);
	let ht = (t, n, r, i = !0) => {
		let o = r === "character" ? y(a.document, n.partsKept ? n : e(n)) : n, s = Array.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(6)), (e) => e.toString(16).padStart(2, "0")).join("");
		dt(s, o), a.addModelCutout(t, s, { replace: r === "character" }), i && xt();
	};
	A(() => {
		k && (I || !pt || Je ? k.setMask(null) : k.setMask(pt, H.width, H.height, { despill: p(ot) }));
	}, [
		k,
		pt,
		ot,
		I,
		H,
		Je
	]);
	let gt = async (e, t) => {
		let n = await ue(e, Math.min(4096, k?.maxTextureSize ?? 4096));
		B((r) => (r?.bitmap.close(), {
			bitmap: n,
			blob: e,
			name: t
		}));
	}, U = (e) => {
		L(null), gt(e, e.name).then(() => a.set("recipe/ops/backdrop/mode", "image", "Backdrop: Photo"), (e) => L(e instanceof Error ? e.message : "That background photo couldn't be opened."));
	};
	A(() => {
		if (!c) return;
		let e = !1;
		return (async () => {
			try {
				let t = typeof c == "string" ? await fe(c) : c;
				e || await gt(t, t instanceof File ? t.name : void 0);
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [c, k]), A(() => {
		k?.setBackground(z?.bitmap ?? null);
	}, [k, z]), A(() => () => z?.bitmap.close(), [z]);
	let _t = O.recipe.words, W = St(v), [vt, yt] = M(() => {
		try {
			return localStorage.getItem("gleamshelf:auto-enhance") !== "off";
		} catch {
			return !0;
		}
	}), bt = (e) => {
		yt(e);
		try {
			localStorage.setItem("gleamshelf:auto-enhance", e ? "on" : "off");
		} catch {}
	}, xt = () => {
		let e = a.document.recipe, t = e.ops.light?.exposure === 0 && e.ops.color?.vibrance === 0 && !e.effects.some((e) => e.id === "sharpen");
		vt && t && a.applyLook("bright-sharp");
	}, [G, Ct] = M(!1), [At, jt] = M(() => /* @__PURE__ */ new Map()), Mt = j(/* @__PURE__ */ new Map()), Nt = (e, t) => {
		Mt.current.set(e, t), jt((n) => new Map(n).set(e, t));
	}, [Pt, Ft] = M(null), [It, Lt] = M(!1);
	A(() => {
		if (!m) return;
		let e = !1;
		return (async () => {
			for (let [t, n] of Object.entries(m)) try {
				let r = typeof n == "string" ? await fe(n) : n, i = await createImageBitmap(r);
				e || Nt(t, {
					bitmap: i,
					blob: r
				});
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [m]);
	let Rt = (e = s) => {
		let t = Math.min(1, 2048 / Math.max(e.width, e.height)), n = Math.max(1, Math.round(e.width * t)), r = Math.max(1, Math.round(e.height * t)), i = document.createElement("canvas");
		i.width = n, i.height = r;
		let a = i.getContext("2d", { willReadFrequently: !0 });
		a.drawImage(e, 0, 0, n, r);
		let o = a.getImageData(0, 0, n, r), c = ft(), l = new Uint8Array(n * r).fill(+!c);
		if (c) for (let e = 0; e < r; e++) {
			let t = Math.min(H.height - 1, Math.floor(e / r * H.height));
			for (let r = 0; r < n; r++) l[e * n + r] = +(c[t * H.width + Math.min(H.width - 1, Math.floor(r / n * H.width))] > 140);
		}
		return {
			w: n,
			h: r,
			pixels: o,
			inside: l
		};
	}, zt = () => W.state === "ready" ? W.installed("inpaint")[0] ?? W.installed("redraw")[0] : void 0, Bt = (e, t) => e.task === "redraw" ? W.client.redraw(t.picture, {
		prompt: di,
		negative: fi,
		strength: .99,
		steps: 24,
		guidance: 5,
		candidates: 3,
		seed: 5,
		stacked: !!t.region
	}) : W.client.inpaint(t.picture, e.id), Vt = async (e, t, n = s) => {
		let r = document.createElement("canvas");
		r.width = t.fullWidth, r.height = t.fullHeight;
		let i = r.getContext("2d");
		i.drawImage(n, 0, 0, t.fullWidth, t.fullHeight);
		let a = await createImageBitmap(e);
		return i.drawImage(a, t.x, t.y), a.close(), new Promise((e, t) => r.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be saved.")), "image/png"));
	}, Ht = () => {
		let e = a.document.recipe.words?.ai;
		return e && Mt.current.get(e.ref)?.bitmap || s;
	}, Ut = _t?.ai ? At.get(_t.ai.ref)?.bitmap : void 0;
	A(() => {
		if (!_t) {
			Ft((e) => e && (e.owned && e.bitmap.close(), null));
			return;
		}
		if (Ut) {
			Ft((e) => (e?.owned && e.bitmap.close(), {
				bitmap: Ut,
				filled: -1,
				owned: !1
			})), Lt(!1);
			return;
		}
		let e = !1;
		Lt(!0);
		let t = setTimeout(async () => {
			let { w: t, h: n, pixels: r, inside: i } = Rt(), a = pi(_t.stickers), o = a.length ? Ce(t, n, a, .003) : void 0, { image: s, filled: c } = Ne({
				width: t,
				height: n,
				data: r.data
			}, _t, i, o, _t.lettering !== !1), l = await createImageBitmap(new ImageData(new Uint8ClampedArray(s.data), t, n));
			if (e) return l.close();
			Ft((e) => (e?.owned && e.bitmap.close(), {
				bitmap: l,
				filled: c,
				owned: !0
			})), Lt(!1);
		}, 60);
		return () => {
			e = !0, clearTimeout(t);
		};
	}, [
		_t,
		pt,
		s,
		H,
		Ut
	]), A(() => () => void (Pt?.owned && Pt.bitmap.close()), [Pt]);
	let [K, q] = M(() => /* @__PURE__ */ new Map());
	A(() => {
		if (!h) return;
		let e = !1;
		return (async () => {
			for (let [t, n] of Object.entries(h)) try {
				let r = typeof n == "string" ? await fe(n) : n, i = await createImageBitmap(r);
				e || q((e) => new Map(e).set(t, {
					bitmap: i,
					blob: r
				}));
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [h]);
	let Wt = O.recipe.upscale, Gt = Wt ? K.get(Wt.ref)?.bitmap : void 0;
	A(() => {
		if (!k) return;
		let e = Je ?? Gt ?? Pt?.bitmap ?? s;
		k.setSource(I ? s : e);
	}, [
		k,
		Pt,
		Gt,
		I,
		s,
		Je
	]), A(() => {
		if (!g) return;
		let e = !1;
		return (async () => {
			for (let [t, n] of Object.entries(g)) try {
				let r = typeof n == "string" ? await fe(n) : n, i = await createImageBitmap(r);
				e || V((e) => new Map(e).set(t, {
					bitmap: i,
					blob: r
				}));
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [g]);
	let [Kt, qt] = M(!1), [Jt, Yt] = M(null), [Xt, Zt] = M(null), Qt = async () => {
		if (!k) throw Error("The preview is not ready yet.");
		return (await k.export(a.document, {
			type: "image/png",
			maxSize: 1024
		})).blob;
	}, $t = async (e, t) => {
		let n = W.state === "ready" ? W.installed("upscale")[0] : void 0, r = t;
		if (n) try {
			r = await W.client.upscale(t, n.id);
		} catch {}
		let i = await createImageBitmap(r), o = Math.min(2048, k?.maxTextureSize ?? 2048);
		if (Math.max(i.width, i.height) > o) {
			let e = o / Math.max(i.width, i.height), t = await createImageBitmap(i, {
				resizeWidth: Math.floor(i.width * e),
				resizeHeight: Math.floor(i.height * e),
				resizeQuality: "high"
			});
			i.close(), i = t;
			let n = document.createElement("canvas");
			n.width = i.width, n.height = i.height, n.getContext("2d").drawImage(i, 0, 0), r = await new Promise((e, t) => n.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be saved.")), "image/png"));
		}
		let s = Array.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(6)), (e) => e.toString(16).padStart(2, "0")).join("");
		V((e) => new Map(e).set(s, {
			bitmap: i,
			blob: r
		})), a.setFinish(e, s);
	}, en = () => {
		let e = W.state === "ready" ? W.installed("redraw")[0] : void 0;
		if (!e) throw Error("The redraw model is not ready: start the Gleamshelf app and set it up first.");
		return e;
	}, J = async (e) => {
		let t = Xt;
		if (Zt(null), t) {
			qt(!0), Yt(null), L(null);
			try {
				let n = en();
				a.commit();
				let r = await W.client.redraw(await Qt(), {
					prompt: t.prompt,
					strength: t.keepShape ? .6 : .99,
					steps: 25,
					box: e
				});
				await $t(n.id, r), Yt("The area was redrawn. Compare it with the real item before listing.");
			} catch (e) {
				L(e instanceof Error ? `The redraw did not work: ${e.message}` : "The redraw did not work.");
			} finally {
				qt(!1);
			}
		}
	}, tn = async () => {
		let e = a.document.recipe.words?.ai, t = e && Mt.current.get(e.ref)?.bitmap || Pt?.bitmap || s, n = Math.min(1, 1024 / Math.max(t.width, t.height)), r = document.createElement("canvas");
		return r.width = Math.max(1, Math.round(t.width * n)), r.height = Math.max(1, Math.round(t.height * n)), r.getContext("2d").drawImage(t, 0, 0, r.width, r.height), new Promise((e, t) => r.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png"));
	}, nn = async (e, t) => {
		let n = await createImageBitmap(t), r = k?.maxTextureSize ?? 4096;
		if (Math.max(n.width, n.height) > r) {
			let e = r / Math.max(n.width, n.height), t = await createImageBitmap(n, {
				resizeWidth: Math.floor(n.width * e),
				resizeHeight: Math.floor(n.height * e),
				resizeQuality: "high"
			});
			n.close(), n = t;
		}
		let i = Array.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(6)), (e) => e.toString(16).padStart(2, "0")).join("");
		q((e) => new Map(e).set(i, {
			bitmap: n,
			blob: t
		})), a.setUpscale(e, i);
	}, rn = async (e, { otherText: t, textModel: n, client: r, rebuild: i = !1, from: a = s, smoothOnly: o = !1, body: c, extra: l }) => {
		let u = Rt(a), { w: d, h: p, pixels: m } = u, h = Math.max(d, p), g = i ? we(u.inside, d, p, Math.max(4, Math.round(h * .06))) : u.inside, _ = e.lettering === !1 ? new Uint8Array(d * p) : Me({
			width: d,
			height: p,
			data: m.data
		}, e, g), v = pi(e.stickers);
		v.length && (_ = Te(_, Ce(d, p, v, .003)));
		let y = [], b = new Uint8Array(d * p), x = new Uint8Array(d * p), S = 0;
		if (t && n) {
			let e = await r.detectText(await pe(a), n), t = new Uint8Array(d * p);
			for (let n of e) {
				if (n.width * n.height > (i ? .2 : .05)) continue;
				let e = Math.max(0, Math.floor(n.x * d)), r = Math.min(d, Math.ceil((n.x + n.width) * d)), a = Math.max(0, Math.floor(n.y * p)), o = Math.min(p, Math.ceil((n.y + n.height) * p)), s = 0, l = 0;
				for (let t = a; t < o; t++) for (let n = e; n < r; n++) s++, g[t * d + n] || l++;
				if (s) {
					if (i && c) {
						let t = 0, n = 0;
						for (let i = a; i < o; i += 2) for (let a = e; a < r; a += 2) {
							let e = Math.min(c.width - 1, Math.floor(a / d * c.width)), r = Math.min(c.height - 1, Math.floor(i / p * c.height));
							n++, c.alpha[r * c.width + e] > 140 && t++;
						}
						if (n && t / n < .35) {
							let t = Math.max(2, Math.round(h * .004));
							y.push({
								x: Math.max(0, (e - t) / d),
								y: Math.max(0, (a - t) / p),
								width: Math.min(1, (r - e + 2 * t) / d),
								height: Math.min(1, (o - a + 2 * t) / p)
							});
							continue;
						}
					}
					if (l / s >= .2 && !i) {
						let t = Math.max(2, Math.round(h * .004));
						y.push({
							x: Math.max(0, (e - t) / d),
							y: Math.max(0, (a - t) / p),
							width: Math.min(1, (r - e + 2 * t) / d),
							height: Math.min(1, (o - a + 2 * t) / p)
						});
					} else if (i) {
						let e = Fe({
							width: d,
							height: p,
							data: m.data
						}, n), r = 0;
						for (let t = 0; t < e.length; t++) r += +!!e[t];
						if (r === 0 && n.width * n.height > .004 && S++, r > n.width * d * n.height * p * .4) {
							S++;
							continue;
						}
						let i = n.height < .02 ? x : t;
						for (let t = 0; t < e.length; t++) e[t] && (i[t] = 1);
					} else for (let n = a; n < o; n++) for (let i = e; i < r; i++) g[n * d + i] && (t[n * d + i] = 1);
				}
			}
			i ? b = t : _ = Te(_, t);
		}
		if (o) {
			for (let e = 0; e < _.length; e++) (_[e] || b[e]) && (x[e] = 1);
			_ = new Uint8Array(d * p), b = new Uint8Array(d * p);
		}
		if (l) {
			if (i) for (let e = 0; e < l.length; e++) b[e] ||= l[e];
			else _ = Te(_, l);
		}
		let C = x.some(Boolean), w = S;
		if (!_.some(Boolean) && !b.some(Boolean) && !C && y.length === 0) return null;
		_ = we(_, d, p, Math.max(2, Math.round(h * (i ? .0015 : .005)))), b.some(Boolean) && (_ = Te(_, we(b, d, p, Math.max(3, Math.round(h * .006)))));
		let ee = C ? Te(_, we(x, d, p, Math.max(3, Math.round(h * .009)))) : _;
		if (i) {
			let e = (() => {
				let e = ft();
				return e ? f(e, H.width, H.height) : null;
			})(), t = .05, n = e ? Math.max(0, Math.floor((e.x - t) * d)) : 0, r = e ? Math.max(0, Math.floor((e.y - t) * p)) : 0, i = e ? Math.min(d, Math.ceil((e.x + e.width + t) * d)) : d, a = e ? Math.min(p, Math.ceil((e.y + e.height + t) * p)) : p, o = i - n, s = a - r, c = Ee({
				width: d,
				height: p,
				data: m.data
			}, ee).data, l = new Uint8ClampedArray(o * s * 2 * 4);
			for (let e = 0; e < s; e++) for (let t = 0; t < o; t++) {
				let i = ((r + e) * d + n + t) * 4, a = (e * o + t) * 4;
				l[a] = c[i], l[a + 1] = c[i + 1], l[a + 2] = c[i + 2], l[a + 3] = 255;
				let u = ((s + e) * o + t) * 4, f = _[(r + e) * d + n + t] ? 255 : 0;
				l[u] = l[u + 1] = l[u + 2] = f, l[u + 3] = 255;
			}
			let u = 0;
			for (let e = 0; e < ee.length; e++) u += +!!ee[e];
			if (!_.some(Boolean)) {
				let e = document.createElement("canvas");
				return e.width = o, e.height = s, e.getContext("2d").putImageData(new ImageData(l.slice(0, o * s * 4), o, s), 0, 0), {
					picture: await new Promise((t, n) => e.toBlob((e) => e ? t(e) : n(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png")),
					cutAway: y,
					region: {
						x: n,
						y: r,
						width: o,
						height: s,
						fullWidth: d,
						fullHeight: p
					},
					share: u / ee.length,
					skipped: w,
					done: !0
				};
			}
			let h = document.createElement("canvas");
			return h.width = o, h.height = s * 2, h.getContext("2d").putImageData(new ImageData(l, o, s * 2), 0, 0), {
				picture: await new Promise((e, t) => h.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png")),
				cutAway: y,
				region: {
					x: n,
					y: r,
					width: o,
					height: s,
					fullWidth: d,
					fullHeight: p
				},
				share: u / ee.length,
				skipped: w
			};
		}
		let te = new Uint8ClampedArray(m.data);
		for (let e = 0; e < d * p; e++) te[e * 4 + 3] = _[e] ? 0 : 255;
		let ne = document.createElement("canvas");
		return ne.width = d, ne.height = p, ne.getContext("2d").putImageData(new ImageData(te, d, p), 0, 0), {
			picture: await new Promise((e, t) => ne.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png")),
			cutAway: y,
			share: 0
		};
	}, an = async () => {
		let e = W.installed("text-detect")[0], t = W.installed("text-read")[0];
		if (!e || !t) throw Error("Reading prices needs the text finder and the text reader: install both with the commands in the AI panel.");
		let n = await W.client.readText(await pe(s)), r = /[$＄¥￥]\s*\d|\d\s*[$＄]|\d+\s*円/, { w: i, h: a, pixels: o } = Rt(), c = {
			width: i,
			height: a,
			data: o.data
		}, l = [];
		for (let e of n) {
			if (!r.test(e.text) || e.score < .5) continue;
			let t = {
				x: Math.max(0, e.x - e.width * .6),
				y: Math.max(0, e.y - e.height * 1),
				width: Math.min(1, e.width * 2.6),
				height: Math.min(1, e.height * 3.2)
			}, n = Oe(c, t);
			(n.width * n.height > .06 || n.x === t.x && n.y === t.y && n.width === t.width) && (n = {
				x: Math.max(0, e.x - e.width * .25),
				y: Math.max(0, e.y - e.height * .5),
				width: Math.min(1, e.width * 1.5),
				height: Math.min(1, e.height * 2)
			}), l.length < 28 && l.push(n.x, n.y, Math.min(n.width, 1 - n.x), Math.min(n.height, 1 - n.y));
		}
		return l;
	}, on = async (e, { lettering: t, stickerBoxes: n, body: r }) => {
		let i = Ht(), { w: a, h: o, pixels: s, inside: c } = Rt(i), l = Math.max(a, o), u = s.data, d = (e) => {
			let t = document.createElement("canvas");
			return t.width = a, t.height = o, t.getContext("2d").putImageData(new ImageData(new Uint8ClampedArray(e), a, o), 0, 0), new Promise((e, n) => t.toBlob((t) => t ? e(t) : n(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png"));
		}, f = async (t) => {
			let n = new Uint8ClampedArray(u);
			for (let e = 0; e < a * o; e++) t[e] && (n[e * 4 + 3] = 0);
			let r = await createImageBitmap(await W.client.inpaint(await d(n), e.id)), i = document.createElement("canvas");
			i.width = a, i.height = o;
			let s = i.getContext("2d", { willReadFrequently: !0 });
			s.drawImage(r, 0, 0, a, o), r.close();
			let c = s.getImageData(0, 0, a, o).data, l = new Uint8ClampedArray(u);
			for (let e = 0; e < a * o; e++) if (t[e]) for (let t = 0; t < 3; t++) l[e * 4 + t] = c[e * 4 + t];
			return l;
		}, p = () => new Uint8Array(a * o), m = p();
		if (t) {
			let e = we(c, a, o, Math.max(4, Math.round(l * .06)));
			m = we(Me({
				width: a,
				height: o,
				data: u
			}, { ...C }, e), a, o, Math.max(1, Math.round(l * .001)));
		}
		let h = n.length ? Ce(a, o, pi(n), .003) : p(), g = [], _ = 0, v = p(), y = W.installed("text-detect")[0];
		if (t && y) {
			let e = p();
			for (let t of await W.client.detectText(await pe(i), y.id)) {
				if (t.width * t.height > .05) {
					_++;
					continue;
				}
				let n = Math.max(0, Math.floor(t.x * a)), i = Math.min(a, Math.ceil((t.x + t.width) * a)), s = Math.max(0, Math.floor(t.y * o)), c = Math.min(o, Math.ceil((t.y + t.height) * o));
				if (r) {
					let e = 0, t = 0;
					for (let l = s; l < c; l += 2) for (let s = n; s < i; s += 2) {
						let n = Math.min(r.width - 1, Math.floor(s / a * r.width)), i = Math.min(r.height - 1, Math.floor(l / o * r.height));
						t++, r.alpha[i * r.width + n] > 140 && e++;
					}
					if (t && e / t < .35) {
						let e = Math.max(2, Math.round(l * .004));
						g.push({
							x: Math.max(0, (n - e) / a),
							y: Math.max(0, (s - e) / o),
							width: Math.min(1, (i - n + 2 * e) / a),
							height: Math.min(1, (c - s + 2 * e) / o)
						});
						continue;
					}
				}
				let u = Math.max(4, Math.round(l * .005));
				for (let t = Math.max(0, s - u); t < Math.min(o, c + u); t++) for (let r = Math.max(0, n - u); r < Math.min(a, i + u); r++) e[t * a + r] = 1;
			}
			e.some(Boolean) && (v = Ve({
				width: a,
				height: o,
				data: u
			}, {
				width: a,
				height: o,
				data: await f(e)
			}, e));
		}
		let b = Te(Te(m, h), v);
		return b.some(Boolean) ? {
			picture: await d(await f(b)),
			cutAway: g,
			skipped: _
		} : {
			picture: null,
			cutAway: g,
			skipped: _
		};
	}, sn = async ({ lettering: e, stickers: t, add: n = [], body: r }) => {
		let i = zt();
		if (!i) return {
			result: "no-ai",
			stickersFound: 0
		};
		let o = W.installed("text-detect")[0], s = [...a.document.recipe.words?.stickers ?? []], c;
		if (t) {
			s = [];
			try {
				s = await an();
			} catch (e) {
				c = e instanceof Error ? e.message : "Price stickers could not be searched for.";
			}
		}
		if (s = [...s, ...n].slice(0, 28), i.task === "inpaint") {
			let t = await on(i, {
				lettering: e,
				stickerBoxes: s,
				body: r
			});
			return t.picture ? (a.setWords(!0, {
				lettering: e,
				stickers: s
			}), await yn(i.id, t.picture, t.cutAway, !1), {
				result: "filled",
				stickersFound: s.length / 4,
				stickerNote: c,
				skipped: t.skipped
			}) : {
				result: "nothing",
				stickersFound: 0,
				stickerNote: c,
				skipped: t.skipped
			};
		}
		let l = {
			...C,
			...e ? {} : { lettering: !1 },
			...s.length ? { stickers: s } : {}
		}, u = await rn(l, {
			otherText: e && !!o,
			textModel: o?.id,
			client: W.client,
			rebuild: i.task === "redraw",
			body: r
		});
		if (!u) return {
			result: "nothing",
			stickersFound: 0,
			stickerNote: c
		};
		let d = u.skipped ?? 0;
		a.setWords(!0, {
			lettering: e,
			stickers: s
		});
		let f = u.done ? u.picture : await Bt(i, u);
		if (await yn(i.id, u.region ? await Vt(f, u.region) : f, u.cutAway, i.task !== "redraw"), i.task === "redraw" && e) try {
			let e = await rn({ ...C }, {
				otherText: !!o,
				textModel: o?.id,
				client: W.client,
				rebuild: !0,
				from: Ht(),
				smoothOnly: !0
			});
			if (e?.region && e.share > 0 && e.share < u.share * .5) {
				let t = Ht(), n = e.done ? e.picture : await Bt(i, e);
				await yn(i.id, await Vt(n, e.region, t), []);
			}
		} catch {}
		return {
			result: "filled",
			stickersFound: s.length / 4,
			stickerNote: c,
			skipped: d
		};
	}, cn = async () => {
		if (!zt()) return void a.setWords(!0);
		Ct(!0);
		try {
			(await sn({
				lettering: !0,
				stickers: !!W.installed("text-read")[0]
			})).result === "nothing" && a.setWords(!0);
		} catch (e) {
			L(e instanceof Error ? `The AI fill did not work: ${e.message}` : "The AI fill did not work.");
		} finally {
			Ct(!1);
		}
	}, [ln, un] = M(!1), [dn, fn] = M("sticker"), pn = async (e, t) => {
		un(!1), gn(null), Ct(!0);
		try {
			let { w: n, h: r, pixels: i } = Rt(), o = {
				x: Math.max(0, e - .06),
				y: Math.max(0, t - .035),
				width: .12,
				height: .07
			}, s = Oe({
				width: n,
				height: r,
				data: i.data
			}, o);
			s.width * s.height > .05 && (s = {
				x: Math.max(0, e - .03),
				y: Math.max(0, t - .02),
				width: .06,
				height: .04
			});
			let c = a.document.recipe.words ? a.document.recipe.words.lettering !== !1 : !1, { result: l } = await sn({
				lettering: c,
				stickers: !1,
				add: [
					s.x,
					s.y,
					Math.min(s.width, 1 - s.x),
					Math.min(s.height, 1 - s.y)
				]
			});
			gn(l === "no-ai" ? "Needs an AI fill: start the Gleamshelf app and set up the redraw model (or install LaMa)." : "Removed the sticker you pointed at.");
		} catch (e) {
			gn(e instanceof Error ? e.message : "The sticker could not be removed.");
		} finally {
			Ct(!1);
		}
	}, mn = async (e, t) => {
		un(!1), gn(null), Ct(!0);
		try {
			let n = zt();
			if (!n) return void gn("Needs an AI fill: start the Gleamshelf app and set up the redraw model (or install LaMa).");
			let r = Ht(), { w: i, h: o, pixels: s } = Rt(r), c = {
				x: e * i,
				y: t * o
			}, l = {
				x0: c.x - i * .3,
				y0: c.y - o * .08,
				x1: c.x + i * .3,
				y1: c.y + o * .08
			}, u = W.installed("text-detect")[0];
			if (u) {
				let n = await W.client.detectText(await pe(r), u.id), a = (n, r) => e >= n.x - r && e <= n.x + n.width + r && t >= n.y - r && t <= n.y + n.height + r, s = (n) => Math.hypot(e - (n.x + n.width / 2), t - (n.y + n.height / 2)), c = n.filter((e) => a(e, 0)).sort((e, t) => e.width * e.height - t.width * t.height)[0] ?? n.filter((e) => a(e, .015)).sort((e, t) => s(e) - s(t))[0], d = .012;
				c && (l = {
					x0: (c.x - d) * i,
					y0: (c.y - d) * o,
					x1: (c.x + c.width + d) * i,
					y1: (c.y + c.height + d) * o
				});
			}
			let d = Le({
				width: i,
				height: o,
				data: s.data
			}, l, c);
			if (!("mask" in d)) return void gn(d.problem === "too-much" ? "That colour covers too much of the area to be sure it is print, so nothing was taken off. Click a letter of the text itself, not the picture behind it." : "No printed text was found at that point. Click right on a letter (a second click takes off a second colour).");
			let f = a.document.recipe.words, p = {
				...f ?? C,
				lettering: !1,
				stickers: void 0,
				ai: void 0
			}, m = await rn(p, {
				otherText: !1,
				client: W.client,
				rebuild: n.task === "redraw",
				from: r,
				extra: d.mask
			});
			if (!m) return void gn("Nothing to take off there.");
			let h = !!a.document.recipe.upscale;
			f || a.setWords(!0, { lettering: !1 });
			let g = m.done ? m.picture : await Bt(n, m);
			await yn(n.id, m.region ? await Vt(g, m.region, r) : g, [], n.task !== "redraw"), gn(`Took off the printed text you pointed at${h ? " (the enlarging was reset: run Sharpen & enlarge again)" : ""}.`);
		} catch (e) {
			gn(e instanceof Error ? e.message : "The printed text could not be removed.");
		} finally {
			Ct(!1);
		}
	}, [hn, gn] = M(null), _n = async () => {
		gn(null), Ct(!0);
		try {
			let e = a.document.recipe.words ? a.document.recipe.words.lettering !== !1 : !1, { result: t, stickersFound: n, stickerNote: r } = await sn({
				lettering: e,
				stickers: !0
			});
			gn(t === "no-ai" ? "Needs an AI fill: start the Gleamshelf app and set up the redraw model (or install LaMa)." : r ?? (n ? `Removed ${n} price sticker${n === 1 ? "" : "s"}.` : "No price sticker found. A sticker with no clear price on it can be painted out with the cut-out brush."));
		} catch (e) {
			gn(e instanceof Error ? e.message : "The price stickers could not be removed.");
		} finally {
			Ct(!1);
		}
	}, vn = (e) => {
		let t = ft(), n = t && f(t, H.width, H.height);
		if (!n) return e;
		let r = e.filter((e) => e.y >= n.y + n.height * .65);
		if (!r.length) return e;
		let i = Math.max(n.y, Math.min(...r.map((e) => e.y)) - .004);
		return [...e.filter((e) => !r.includes(e)), {
			x: 0,
			y: i,
			width: 1,
			height: 1 - i
		}];
	}, yn = async (e, t, n = [], r = !0) => {
		let i = await createImageBitmap(t), o = Array.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(6)), (e) => e.toString(16).padStart(2, "0")).join("");
		Nt(o, {
			bitmap: i,
			blob: t
		}), n.length && a.eraseBoxes(r ? vn(n) : n), a.setWordsAi(e, o), xt();
	}, bn = (e) => {
		let t = ft(), n = t && f(t, H.width, H.height);
		return n ? (a.begin("Studio photo"), a.set("recipe/ops/backdrop/mode", "color"), a.set("recipe/ops/backdrop/color", "#ffffff"), a.fitSquareToProduct(n, .07), e?.shadow !== !1 && !a.effects.some((e) => e.id === "drop-shadow") && a.addEffect("drop-shadow", {
			opacity: .22,
			blur: 16,
			offsetX: 0,
			offsetY: 20,
			color: "#000000"
		}), a.commit(), !0) : !1;
	}, [xn, Sn] = M(() => {
		try {
			let e = localStorage.getItem("gleamshelf:auto-mode");
			return e === "character" || e === "auto" ? e : "product";
		} catch {
			return "product";
		}
	}), Cn = (e) => {
		Sn(e);
		try {
			localStorage.setItem("gleamshelf:auto-mode", e);
		} catch {}
	}, [wn, Tn] = M(null), [En, Dn] = M(null), [On, kn] = M(!1), [An, jn] = M(null), Mn = () => jn((e) => {
		if (e) for (let t of Object.values(e.thumbs)) URL.revokeObjectURL(t);
		return null;
	});
	A(() => () => Mn(), []);
	let Nn = async (e) => {
		if (An && !An.sent) {
			jn({
				...An,
				sent: !0
			});
			try {
				await W.client.chooseReferences(An.job, e), jn((t) => t && {
					...t,
					ticked: e ?? t.online.photos.filter((e) => e.linesUp).map((e) => e.index)
				});
			} catch (e) {
				jn((e) => e && {
					...e,
					sent: !1
				}), L(e instanceof Error ? e.message : "The app did not take the choice.");
			}
		}
	}, Pn = (e, t) => {
		try {
			let n = localStorage.getItem(e);
			return n === null ? t : n === "on";
		} catch {
			return t;
		}
	}, [Fn, In] = M(() => Object.fromEntries(mi.map((e) => [e.key, !e.optIn && Pn(`gleamshelf:full-${e.key}`, !0)]))), Ln = (e, t) => {
		if (In((n) => ({
			...n,
			[e]: t
		})), !mi.find((t) => t.key === e)?.optIn) try {
			localStorage.setItem(`gleamshelf:full-${e}`, t ? "on" : "off");
		} catch {}
	}, Rn = j(!0);
	A(() => (Rn.current = !0, () => {
		Rn.current = !1;
	}), []);
	let zn = j(!1);
	A(() => {
		x && !zn.current && (zn.current = !0, ht("pipeline", x.mask, "product", !1), bn({ shadow: x.shadow }));
	}, []);
	let Bn = async () => {
		if (On || !b) return;
		a.commit(), L(null), kn(!0), Mn();
		let e = (e) => Tn(e.map((e) => ({
			label: e.name,
			state: e.state,
			startedAt: e.startedAt,
			seconds: e.seconds
		}))), t = null, n = !1, r = () => {
			n = !0, t && W.client.cancelProcess(t).catch(() => {});
		};
		try {
			e([{
				name: "Sending the photo to the Gleamshelf app (it stays on this computer)",
				state: "running"
			}]);
			let i = Fn.find, a = i && Fn.colour, o = await W.client.startProcess(b, {
				mode: xn,
				find: i,
				listing: i && Fn.listing,
				colour: a,
				vivid: a && Fn.vivid ? 1.4 : 1,
				stickers: Fn.stickers,
				lettering: Fn.lettering,
				thinParts: Fn.thinParts,
				look: Fn.look,
				enlarge: Fn.enlarge,
				gloss: Fn.gloss,
				review: i
			});
			t = o;
			let s, c = 0, l = !1;
			for (Dn({
				health: null,
				receivedAt: Date.now(),
				queued: !0,
				unanswered: 0,
				stop: r
			});;) {
				if (await new Promise((e) => setTimeout(e, 1e3)), !Rn.current) return;
				if (n) throw Error("Stopped.");
				try {
					s = await W.client.processStatus(o), c = 0;
				} catch (e) {
					if (c++, Dn((e) => e && {
						...e,
						unanswered: c
					}), c >= 15) throw Error(`the Gleamshelf app stopped answering (${e instanceof Error ? e.message : "no answer"}). Is it still running? Start it again with: npm run local:start`);
					continue;
				}
				if (Dn({
					health: s.health ?? null,
					receivedAt: Date.now(),
					queued: s.status === "queued",
					unanswered: 0,
					stop: r
				}), e(s.steps.length ? s.steps : [{
					name: s.status === "queued" ? "Waiting for the app to finish another job" : "Starting",
					state: "running"
				}]), s.found && s.status === "waiting") {
					let e = s.found;
					if (jn((t) => t && t.job === o ? t : {
						job: o,
						online: e,
						thumbs: {},
						ticked: e.photos.filter((e) => e.linesUp).map((e) => e.index),
						sent: !1
					}), !l) {
						l = !0;
						for (let t of e.photos.slice(0, 24)) W.client.foundPicture(o, t.index).then((e) => {
							let n = URL.createObjectURL(e);
							if (!Rn.current) return URL.revokeObjectURL(n);
							jn((e) => e && e.job === o ? {
								...e,
								thumbs: {
									...e.thumbs,
									[t.index]: n
								}
							} : (URL.revokeObjectURL(n), e));
						}).catch(() => {});
					}
				}
				if (s.status === "done" || s.status === "failed") break;
			}
			if (s.status === "failed") throw Error(s.error === "Stopped." ? "Stopped." : s.error ?? "The app could not finish.");
			await ee(await W.client.processPicture(o, "cutout"), s.report?.modeUsed !== "character", s.report ?? null);
		} catch (e) {
			let t = e instanceof Error && e.message === "Stopped.";
			Tn((e) => e?.map((e) => e.state === "running" ? {
				...e,
				state: "skipped",
				note: t ? "stopped" : "did not finish"
			} : e) ?? null), R(t ? {
				kind: "stopped",
				message: "Stopped. Nothing was changed."
			} : {
				kind: "failed",
				message: e instanceof Error ? e.message : "The app could not finish."
			});
		} finally {
			Rn.current && (kn(!1), Dn(null));
		}
	}, [Vn, Hn] = M(() => {
		try {
			return localStorage.getItem("gleamshelf:auto-detail") === "on";
		} catch {
			return !1;
		}
	}), Un = (e) => {
		Hn(e);
		try {
			localStorage.setItem("gleamshelf:auto-detail", e ? "on" : "off");
		} catch {}
	}, [Wn, Gn] = M(!1), Kn = W.state === "ready" && !!W.installed("enhance")[0] && !!W.installed("redraw")[0], qn = async () => {
		if (On) return;
		if (W.canProcess && W.state === "ready" && b) return Bn();
		a.commit(), L(null), kn(!0);
		let t = xn === "character", n = Vn && Kn && t, r = Wn && Kn, i = [
			t ? "Cut out the box and crop to it" : "Cut out the product",
			t ? "Repaint lettering, printed text and price stickers" : "Remove price stickers",
			...t ? ["Cut out the character"] : [],
			"Brighter and sharper",
			r ? "Studio gloss (changes the product), then enlarge (about 2 minutes)" : n ? "Sharpen with detail, then enlarge (about 2 minutes)" : "Sharpen and enlarge",
			t ? "Studio photo (white, square, no shadow)" : "Studio photo (white, square)"
		], o = i.map((e) => ({
			label: e,
			state: "todo"
		})), [c, l, ...u] = [
			0,
			1,
			...i.slice(2).map((e, t) => t + 2)
		], p = t ? u.shift() : -1, [m, h, g] = u, _ = (e, t, n) => {
			o[e] = {
				...o[e],
				state: t,
				note: n
			}, Tn([...o]);
		}, v = async (e, t) => {
			_(e, "running");
			try {
				let n = await t();
				o[e].state === "running" && _(e, "done", n || void 0);
			} catch (t) {
				_(e, "skipped", t instanceof Error ? t.message : "This step did not work.");
			}
		}, x = (e, t) => _(e, "skipped", t), S = W.state === "ready", C = S ? W.installed("cutout")[0] : void 0, w = (e, t) => {
			throw _(e, "skipped", t), Error(t);
		};
		Tn([...o]);
		try {
			if (await v(c, async () => {
				let e = "";
				if (a.document.recipe.mask.length === 0) {
					if (st) a.removeGreenBackdrop(), e = "green backdrop removed (free)";
					else if (C) ht(C.id, await W.client.cutout(await pe(s), C.id), "product"), e = "AI cut-out";
					else return w(c, "No green backdrop, and the AI cut-out is not available: start the Gleamshelf app and install a cut-out model.");
				} else e = "already cut out";
				if (t) {
					if (!C) return w(c, "Finding the character needs the AI cut-out: start the Gleamshelf app.");
					let t = ft(), n = t && f(t, H.width, H.height);
					if (n) {
						let e = .06, t = Math.max(0, n.x - n.width * e), r = Math.max(0, n.y - n.height * e);
						a.setCrop(d(a.document, {
							x: t,
							y: r,
							width: Math.min(1, n.x + n.width * 1.06) - t,
							height: Math.min(1, n.y + n.height * 1.06) - r
						}));
					}
					e += ", cropped to the box";
				}
				return e;
			}), !ft()) {
				for (let e = 1; e < o.length; e++) x(e, "Needs a cut-out first.");
				return;
			}
			await v(l, async () => {
				let n;
				if (t && C) try {
					n = y(a.document, e(await W.client.cutout(await de(s, a.document), C.id)));
				} catch {}
				let { result: r, stickersFound: i, stickerNote: o, skipped: c = 0 } = await sn({
					lettering: t,
					stickers: !0,
					body: n
				});
				return r === "no-ai" ? w(l, "Needs an AI fill: start the Gleamshelf app and set up the redraw model (or install LaMa).") : r === "nothing" ? o ?? (t ? "nothing to remove" : "no price sticker found") : `${t ? "lettering and printed text" : ""}${t && i ? " and " : ""}${i ? `${i} price sticker${i === 1 ? "" : "s"}` : ""} repainted${o ? ` (${o})` : ""}${c ? `; ${c} printed line${c === 1 ? "" : "s"} left, too tangled with the picture to take off safely (take them off with "Click printed text", or crop them out)` : ""}`;
			}), t && await v(p, async () => C ? (ht(C.id, await W.client.cutout(await de(Ht(), a.document), C.id, void 0, { thinParts: !0 }), "character"), "cut out of the repainted cover") : w(p, "Finding the character needs the AI cut-out: start the Gleamshelf app.")), await v(m, async () => {
				let e = a.document.recipe;
				return xt(), e === a.document.recipe ? "already set" : void 0;
			}), await v(h, async () => {
				let e = S ? W.installed("upscale")[0] : void 0;
				if (!e) return w(h, "Needs an enlarging model: start the Gleamshelf app and install one.");
				let t = await tn(), i = !1;
				if (r) try {
					t = await W.client.gloss(t), i = !0;
				} catch (e) {
					L(e instanceof Error ? `Studio gloss did not work, so the product was left as photographed: ${e.message}` : "Studio gloss did not work, so the product was left as photographed.");
				}
				else if (n) try {
					t = await W.client.enhance(t, { strength: .25 });
				} catch (e) {
					L(e instanceof Error ? `The detail sharpening did not work, so the plain enlarge was used: ${e.message}` : "The detail sharpening did not work, so the plain enlarge was used.");
				}
				return await nn(e.id, await W.client.upscale(t, e.id)), i ? `glossed by AI, so compare it with the real item before listing; ${e.name}, saved 2 times larger` : `${e.name}, saved 2 times larger`;
			}), await v(g, async () => {
				if (t && a.fadeBottom(.15), !bn({ shadow: !t })) return w(g, "Nothing is cut out.");
			});
		} finally {
			kn(!1);
		}
	}, Jn = () => {
		let e = ft(), t = e && f(e, H.width, H.height);
		t && a.fitSquareToProduct(t);
	};
	A(() => {
		if (!k || N.width <= 0) return;
		let e = window.devicePixelRatio || 1, t = requestAnimationFrame(() => k.draw(et, Math.round(it * e), Math.round(at * e)));
		return () => cancelAnimationFrame(t);
	}, [
		k,
		et,
		it,
		at,
		N.width,
		z,
		Pt,
		I
	]);
	let Yn = (e) => {
		let t = e.target;
		if (t.tagName === "SELECT" || t.tagName === "INPUT" && t.type !== "range") return;
		let n = e.type === "keydown", r = e.ctrlKey || e.metaKey, i = e.key.toLowerCase();
		n && r && i === "z" ? (e.preventDefault(), e.shiftKey ? a.redo() : a.undo()) : n && r && i === "y" ? (e.preventDefault(), a.redo()) : e.key === "\\" ? Se(n) : n && !r && i === "c" ? Ze() : n && !r && i === "e" && !Xn ? Qn() : n && !r && i === "l" && !$n ? tr() : n && !r && e.key === "?" ? ke(!0) : n && e.key === "Escape" && (ln || Xt) ? (un(!1), Zt(null)) : n && (e.key === "Enter" || e.key === "Escape") && (Ae || Pe) && (e.preventDefault(), je(!1), Ie(!1));
	}, [Xn, Zn] = M(null), Qn = async () => {
		if (k && !Be) {
			He(!0), L(null);
			try {
				a.commit();
				let e = Ye ?? a.document, t = ci(e.recipe), n = e.recipe.ops, r = t === "image" ? e : {
					...e,
					recipe: {
						...e.recipe,
						ops: {
							...n,
							backdrop: {
								...n.backdrop,
								mode: "transparent"
							}
						}
					}
				}, { blob: i } = await k.export(r, { type: "image/png" }), o = await createImageBitmap(i, { premultiplyAlpha: "none" });
				Zn({
					kind: "pictures",
					width: o.width,
					height: o.height,
					background: t === "color" ? S(e.recipe, "backdrop", "color") || "#ffffff" : t === "image" ? "#ffffff" : null,
					layers: [{
						name: e.recipe.mask.length ? "Product" : "Photo",
						picture: o
					}]
				});
			} catch (e) {
				L(e instanceof Error ? e.message : "Edit mode could not open this picture.");
			} finally {
				He(!1);
			}
		}
	}, [$n, er] = M(null), tr = async () => {
		if (k && !Be) {
			He(!0), L(null);
			try {
				a.commit();
				let { blob: e } = await k.export(Ye ?? a.document, { type: "image/png" });
				er(e);
			} catch (e) {
				L(e instanceof Error ? e.message : "Photo lab could not open this picture.");
			} finally {
				He(!1);
			}
		}
	}, nr = () => {
		er(null), le.current?.focus();
	}, rr = () => {
		if (Xn?.kind === "pictures") for (let e of Xn.layers) e.picture.close?.();
		Zn(null), le.current?.focus();
	}, ir = async () => {
		if (k && !Be) {
			He(!0), L(null);
			try {
				a.commit();
				let e = await k.export(Ye ?? a.document, ie), t = a.document.recipe.upscale?.ref, n = t && K.get(t) ? { [t]: K.get(t).blob } : void 0, r = a.document.recipe.words?.ai?.ref, i = r && At.get(r) ? { [r]: At.get(r).blob } : void 0, o = ci(a.document.recipe) === "image" && z, s = {};
				for (let e of a.document.recipe.mask) {
					let t = e.kind === "model" ? ct.get(e.ref) : void 0;
					e.kind === "model" && t && (s[e.ref] = await D(t));
				}
				let c = a.document.recipe.finish?.ref, l = c && Ge.get(c) ? { [c]: Ge.get(c).blob } : void 0;
				ae({
					...e,
					finishes: l,
					recipe: a.document.recipe,
					source: a.document.source,
					backgroundPhoto: o ? z.blob : void 0,
					cutoutMasks: Object.keys(s).length ? s : void 0,
					repairs: i,
					enlargements: n
				});
			} catch (e) {
				L(e instanceof Error ? e.message : "The image could not be saved.");
			} finally {
				He(!1);
			}
		}
	};
	return /* @__PURE__ */ F("div", {
		className: "gs-editor",
		ref: le,
		tabIndex: -1,
		onKeyDown: Yn,
		onKeyUp: Yn,
		children: [
			/* @__PURE__ */ F("header", {
				className: "gs-toolbar",
				children: [
					/* @__PURE__ */ F("div", {
						className: "gs-toolbar__group",
						children: [E && /* @__PURE__ */ F("button", {
							type: "button",
							className: "gs-button gs-button--ghost",
							onClick: E,
							title: "Close without saving",
							children: [/* @__PURE__ */ P(te, { name: "close" }), " Cancel"]
						}), /* @__PURE__ */ F("span", {
							className: "gs-brand",
							"aria-hidden": "true",
							children: [/* @__PURE__ */ P("span", { className: "gs-brand__mark" }), "Gleamshelf"]
						})]
					}),
					/* @__PURE__ */ F("div", {
						className: "gs-toolbar__group gs-toolbar__group--center",
						children: [
							/* @__PURE__ */ P("button", {
								type: "button",
								className: "gs-icon-button",
								disabled: !ce.canUndo,
								onClick: () => a.undo(),
								title: ce.undoLabel ? `Undo ${ce.undoLabel} (Ctrl+Z)` : "Undo",
								"aria-label": "Undo",
								children: /* @__PURE__ */ P(te, { name: "undo" })
							}),
							/* @__PURE__ */ P("button", {
								type: "button",
								className: "gs-icon-button",
								disabled: !ce.canRedo,
								onClick: () => a.redo(),
								title: ce.redoLabel ? `Redo ${ce.redoLabel} (Ctrl+Shift+Z)` : "Redo",
								"aria-label": "Redo",
								children: /* @__PURE__ */ P(te, { name: "redo" })
							}),
							/* @__PURE__ */ P("span", { className: "gs-toolbar__divider" }),
							/* @__PURE__ */ F("button", {
								type: "button",
								className: `gs-button gs-button--ghost ${I ? "is-active" : ""}`,
								onPointerDown: () => Se(!0),
								onPointerUp: () => Se(!1),
								onPointerLeave: () => Se(!1),
								title: "Hold to see the original (or hold \\)",
								children: [/* @__PURE__ */ P(te, { name: "compare" }), " Compare"]
							}),
							/* @__PURE__ */ F("button", {
								type: "button",
								className: "gs-button gs-button--ghost",
								onClick: () => a.reset(),
								title: "Back to the photo as it was",
								children: [/* @__PURE__ */ P(te, { name: "reset" }), " Reset"]
							})
						]
					}),
					/* @__PURE__ */ F("div", {
						className: "gs-toolbar__group gs-toolbar__group--end",
						children: [
							/* @__PURE__ */ F("span", {
								className: "gs-toolbar__meta",
								children: [
									nt.width,
									" × ",
									nt.height
								]
							}),
							/* @__PURE__ */ F("button", {
								type: "button",
								className: "gs-button gs-button--ghost",
								onClick: () => ke(!0),
								title: "How to use every feature (?)",
								children: [/* @__PURE__ */ P(te, { name: "help" }), " Guide"]
							}),
							/* @__PURE__ */ F("button", {
								type: "button",
								className: "gs-button gs-button--edit",
								disabled: !k || Be,
								onClick: () => void Qn(),
								title: "Layers, brushes, selections, shapes and text on this picture (E)",
								children: [/* @__PURE__ */ P(te, { name: "layers" }), " Edit mode"]
							}),
							/* @__PURE__ */ F("button", {
								type: "button",
								className: "gs-button gs-button--edit",
								disabled: !k || Be,
								onClick: () => void tr(),
								title: "Develop, looks, retouching and every filter, by hand (L)",
								children: [/* @__PURE__ */ P(te, { name: "sliders" }), " Photo lab"]
							}),
							/* @__PURE__ */ P("button", {
								type: "button",
								className: "gs-button gs-button--primary",
								disabled: !k || Be,
								onClick: () => void ir(),
								children: Be ? "Saving…" : se
							})
						]
					})
				]
			}),
			/* @__PURE__ */ F("main", {
				className: "gs-stage",
				ref: he,
				children: [
					/* @__PURE__ */ F("div", {
						className: "gs-stage__frame",
						children: [
							/* @__PURE__ */ P("canvas", {
								ref: _e,
								className: "gs-stage__canvas",
								style: {
									width: it,
									height: at
								}
							}),
							Ae && !I && /* @__PURE__ */ P(Xe, {
								editor: a,
								doc: O,
								width: it,
								height: at
							}),
							Xt && !I && !Je && /* @__PURE__ */ P(kt, {
								width: it,
								height: at,
								onArea: (e) => void J(e)
							}),
							ln && !I && /* @__PURE__ */ P(Et, {
								editor: a,
								width: it,
								height: at,
								onPick: (e, t) => void (dn === "text" ? mn(e, t) : pn(e, t))
							}),
							Pe && !I && /* @__PURE__ */ P(Qe, {
								editor: a,
								doc: O,
								settings: Re,
								width: it,
								height: at
							})
						]
					}),
					I && /* @__PURE__ */ P("span", {
						className: "gs-stage__badge",
						children: "Original"
					}),
					Pe && !I && /* @__PURE__ */ F("span", {
						className: "gs-stage__badge",
						children: [
							Re.tool === "tap" ? "Tap the background to remove it" : Re.tool === "erase" ? "Paint to erase" : "Paint to bring back",
							" ",
							"· Enter when done"
						]
					}),
					Ae && !I && /* @__PURE__ */ P("span", {
						className: "gs-stage__badge",
						children: "Cropping · Enter when done"
					}),
					Xt && !I && /* @__PURE__ */ P("span", {
						className: "gs-stage__badge",
						children: "Drag a rectangle around the area to redraw · Esc to cancel"
					}),
					ln && !I && /* @__PURE__ */ P("span", {
						className: "gs-stage__badge",
						children: dn === "text" ? "Click a letter of the printed text to remove · Esc to cancel" : "Click the sticker to remove · Esc to cancel"
					}),
					Ue && /* @__PURE__ */ F("div", {
						className: "gs-alert",
						role: "alert",
						children: [
							/* @__PURE__ */ P("span", {
								className: "gs-alert__icon",
								"aria-hidden": "true",
								children: "!"
							}),
							/* @__PURE__ */ P("p", { children: Ue }),
							/* @__PURE__ */ P("button", {
								type: "button",
								className: "gs-alert__close",
								"aria-label": "Dismiss",
								onClick: () => L(null),
								children: "×"
							})
						]
					}),
					!Ue && mt > 0 && /* @__PURE__ */ P("p", {
						className: "gs-error gs-stage__error",
						children: "This edit used an AI cut-out whose mask was not supplied, so it is not applied. Run the AI cut-out again."
					})
				]
			}),
			/* @__PURE__ */ P("aside", {
				className: "gs-sidebar",
				children: /* @__PURE__ */ P(ne, {
					editor: a,
					doc: O,
					onOpenGuide: () => ke(!0),
					cropping: Ae,
					onToggleCrop: Ze,
					cutout: Pe,
					onToggleCutout: $e,
					cutSettings: Re,
					onCutSettings: (e) => ze((t) => ({
						...t,
						...e
					})),
					onFitProduct: Jn,
					onStudio: bn,
					onBackgroundPhoto: U,
					hasBackgroundPhoto: !!z,
					backgroundName: z?.name,
					hasCutout: ot.length > 0,
					lettering: {
						busy: It || G,
						filled: Pt?.filled ?? 0,
						aiReady: !!zt()
					},
					onRemoveLettering: () => void cn(),
					stickers: {
						run: () => void _n(),
						busy: G,
						note: hn,
						picking: ln,
						setPicking: (e) => (fn("sticker"), un(e)),
						pickingText: ln && dn === "text",
						setPickingText: (e) => (fn("text"), un(e))
					},
					auto: {
						run: () => {
							R(null), qn();
						},
						end: We,
						dismissEnd: () => R(null),
						busy: On,
						mode: xn,
						setMode: Cn,
						steps: wn,
						watch: En,
						appReady: W.state === "ready",
						greenBackdrop: st,
						full: W.canProcess && W.state === "ready" ? {
							available: !!b,
							steps: mi.map((e) => ({
								...e,
								on: Fn[e.key],
								disabled: e.needs === "find" && !Fn.find || e.needs === "colour" && !(Fn.find && Fn.colour)
							})),
							setStep: Ln,
							report: w,
							found: An && {
								identity: An.online.identity,
								photos: An.online.photos.map((e) => ({
									...e,
									thumb: An.thumbs[e.index]
								})),
								ticked: An.ticked,
								waiting: !An.sent,
								toggle: (e) => jn((t) => t && !t.sent ? {
									...t,
									ticked: t.ticked.includes(e) ? t.ticked.filter((t) => t !== e) : [...t.ticked, e]
								} : t),
								use: () => void Nn(An.ticked),
								skip: () => void Nn([])
							},
							goBack: re
						} : void 0,
						detail: {
							available: Kn && xn === "character",
							on: Vn,
							set: Un
						},
						gloss: {
							available: Kn,
							on: Wn,
							set: Gn
						}
					},
					aiEnlarge: /* @__PURE__ */ P(Tt, {
						app: W,
						sharpen: Kn ? (e) => W.client.enhance(e, { strength: .25 }) : null,
						getPicture: tn,
						onEnlarged: (e, t) => void nn(e, t),
						onRemove: () => a.clearUpscale(),
						applied: Wt && Gt ? { factor: Wt.factor } : null
					}),
					aiFinish: /* @__PURE__ */ P(Ot, {
						app: W,
						applied: !!Je,
						onRedrawArea: (e, t) => (Yt(null), Zt({
							prompt: e,
							keepShape: t
						})),
						onCancelArea: () => Zt(null),
						picking: !!Xt,
						onRemove: () => a.clearFinish(),
						note: Jt,
						busyOutside: Kt
					}),
					autoEnhance: vt,
					onAutoEnhance: bt,
					aiFill: /* @__PURE__ */ P(Dt, {
						app: W,
						buildInput: (e) => rn(a.document.recipe.words ?? _t ?? C, e),
						onFilled: (e, t, n) => void yn(e, t, n),
						applied: !!Ut,
						busyOutside: G
					}),
					aiCutout: /* @__PURE__ */ P(wt, {
						app: W,
						getPhoto: (e) => e === "character" ? de(Ht(), a.document) : pe(Ht()),
						onMask: ht,
						greenBackdrop: st
					})
				})
			}),
			Xn && /* @__PURE__ */ P("div", {
				className: "gs-edit-overlay",
				children: /* @__PURE__ */ P(Zr, {
					open: Xn,
					title: a.document.source.name?.replace(/\.[^.]+$/, "") || "Design",
					doneLabel: "Use this picture",
					onClose: rr,
					onDone: (e) => {
						rr(), T(e);
					}
				})
			}),
			$n && /* @__PURE__ */ P("div", {
				className: "gs-edit-overlay",
				children: /* @__PURE__ */ P(ge, {
					fallback: null,
					children: /* @__PURE__ */ P(si, {
						picture: $n,
						title: a.document.source.name?.replace(/\.[^.]+$/, "") || "Photo",
						doneLabel: "Use this picture",
						onClose: nr,
						onDone: (e) => {
							nr(), T(e);
						}
					})
				})
			}),
			De && /* @__PURE__ */ P(oe, { onClose: () => ke(!1) })
		]
	});
}
//#endregion
//#region src/GleamEditorModal.tsx
function _i({ open: e, ...t }) {
	return A(() => {
		if (!e) return;
		let t = document.body.style.overflow;
		return document.body.style.overflow = "hidden", () => {
			document.body.style.overflow = t;
		};
	}, [e]), e ? xe(/* @__PURE__ */ P("div", {
		className: "gs-modal",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Edit photo",
		children: /* @__PURE__ */ P(hi, { ...t })
	}), document.body) : null;
}
//#endregion
export { Zr as EditMode, hi as GleamEditor, _i as GleamEditorModal, he as PhotoLab, ue as decodePhoto, fe as fetchPhoto, le as gpuMaxTextureSize, O as trimTransparent };

//# sourceMappingURL=index.js.map