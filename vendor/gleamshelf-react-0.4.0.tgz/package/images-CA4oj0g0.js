import { i as e } from "./rolldown-runtime-DArdT4gl.js";
import { d as t, m as n, p as r } from "./src-CJixF5Xc.js";
//#region ../heic/src/index.ts
var i = (e, t, n) => String.fromCharCode(...e.subarray(t, n)), a = /* @__PURE__ */ new Set([
	"heic",
	"heix",
	"hevc",
	"hevx",
	"heim",
	"heis"
]);
function o(e) {
	if (e.length < 16 || i(e, 4, 8) !== "ftyp") return !1;
	let t = Math.min(e.length, new DataView(e.buffer, e.byteOffset, e.byteLength).getUint32(0), 256), n = [i(e, 8, 12)];
	for (let r = 16; r + 4 <= t; r += 4) n.push(i(e, r, r + 4));
	return n.includes("avif") || n.includes("avis") ? !1 : n.some((e) => a.has(e));
}
async function s(t) {
	let { default: n } = await import("./heic-decode-BYdIj7Hj.js").then((t) => /* @__PURE__ */ e(t.default, 1)), { width: r, height: i, data: a } = await n({ buffer: t });
	return {
		width: r,
		height: i,
		data: a instanceof Uint8ClampedArray ? a : new Uint8ClampedArray(a.buffer, a.byteOffset, a.byteLength)
	};
}
//#endregion
//#region src/images.ts
var c;
function l() {
	if (c === void 0) {
		let e = document.createElement("canvas").getContext("webgl2");
		c = e ? e.getParameter(e.MAX_TEXTURE_SIZE) : 4096, e?.getExtension("WEBGL_lose_context")?.loseContext();
	}
	return c;
}
var u = 2048;
async function d(e) {
	let t = URL.createObjectURL(e);
	try {
		let n = new Image();
		n.src = t, await n.decode();
		let r = n.naturalWidth || u, i = n.naturalHeight || u;
		if (e.type === "image/svg+xml") {
			let e = u / Math.max(r, i);
			r = Math.round(r * e), i = Math.round(i * e);
		}
		let a = document.createElement("canvas");
		return a.width = r, a.height = i, a.getContext("2d").drawImage(n, 0, 0, r, i), await createImageBitmap(a);
	} catch {
		throw Error("This file couldn't be opened as an image. Try a JPEG, PNG, WebP or HEIC.");
	} finally {
		URL.revokeObjectURL(t);
	}
}
async function f(e) {
	if (!o(new Uint8Array(await e.slice(0, 512).arrayBuffer()))) return null;
	let { width: t, height: n, data: r } = await s(new Uint8Array(await e.arrayBuffer()));
	return createImageBitmap(new ImageData(new Uint8ClampedArray(r), t, n));
}
async function p(e, t = l()) {
	let n;
	try {
		n = await createImageBitmap(e, { imageOrientation: "from-image" });
	} catch {
		n = await f(e).catch(() => null) ?? await d(e);
	}
	let r = Math.max(n.width, n.height);
	if (r <= t) return n;
	let i = t / r, a = await createImageBitmap(n, {
		resizeWidth: Math.floor(n.width * i),
		resizeHeight: Math.floor(n.height * i),
		resizeQuality: "high"
	});
	return n.close(), a;
}
async function m(e) {
	let t = Math.min(1, 512 / Math.max(e.width, e.height)), n = Math.max(1, Math.round(e.width * t)), r = Math.max(1, Math.round(e.height * t)), i = document.createElement("canvas");
	i.width = n, i.height = r;
	let a = i.getContext("2d", { willReadFrequently: !0 });
	a.drawImage(e, 0, 0, n, r);
	let o = a.getImageData(0, 0, n, r).data, s = n, c = -1, l = r, u = -1;
	for (let e = 0; e < r; e++) for (let t = 0; t < n; t++) o[(e * n + t) * 4 + 3] > 16 && (t < s && (s = t), t > c && (c = t), e < l && (l = e), e > u && (u = e));
	if (c < 0 || s === 0 && l === 0 && c === n - 1 && u === r - 1) return e;
	let d = Math.max(0, Math.floor((s - 1) / t)), f = Math.max(0, Math.floor((l - 1) / t)), p = Math.min(e.width, Math.ceil((c + 2) / t)), m = Math.min(e.height, Math.ceil((u + 2) / t));
	return createImageBitmap(e, d, f, p - d, m - f);
}
async function h(e, t) {
	let n;
	try {
		n = await fetch(e, {
			mode: "cors",
			signal: t
		});
	} catch (e) {
		throw t?.aborted ? e : Error("The photo couldn't be downloaded. Its server may not allow other sites to read it (CORS).");
	}
	if (!n.ok) throw Error(`The photo couldn't be downloaded (${n.status}).`);
	return n.blob();
}
async function g(e) {
	let t = document.createElement("canvas");
	t.width = e.width, t.height = e.height;
	let n = new Uint8ClampedArray(e.width * e.height * 4);
	for (let t = 0; t < e.alpha.length; t++) n.set([
		e.alpha[t],
		e.alpha[t],
		e.alpha[t],
		255
	], t * 4);
	return t.getContext("2d").putImageData(new ImageData(n, e.width, e.height), 0, 0), new Promise((e, n) => t.toBlob((t) => t ? e(t) : n(/* @__PURE__ */ Error("The mask could not be saved.")), "image/png"));
}
async function _(e) {
	let t = await createImageBitmap(e, { colorSpaceConversion: "none" }), n = document.createElement("canvas");
	n.width = t.width, n.height = t.height;
	let r = n.getContext("2d", { willReadFrequently: !0 });
	r.drawImage(t, 0, 0);
	let { data: i } = r.getImageData(0, 0, t.width, t.height), a = new Uint8Array(t.width * t.height);
	for (let e = 0; e < a.length; e++) a[e] = i[e * 4];
	let o = {
		alpha: a,
		width: t.width,
		height: t.height
	};
	return t.close(), o;
}
async function v(e, t = 1536) {
	let n = Math.min(1, t / Math.max(e.width, e.height)), r = document.createElement("canvas");
	return r.width = Math.max(1, Math.round(e.width * n)), r.height = Math.max(1, Math.round(e.height * n)), r.getContext("2d").drawImage(e, 0, 0, r.width, r.height), new Promise((e, t) => r.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The photo could not be prepared.")), "image/jpeg", .92));
}
async function y(e, i, a = 1536) {
	let o = {
		...i,
		recipe: {
			...i.recipe,
			ops: {
				...i.recipe.ops,
				canvas: {
					...i.recipe.ops.canvas,
					square: !1,
					margin: 0
				}
			}
		}
	}, { width: s, height: c } = r(o, a), l = t(n(o));
	if (!l) throw Error("This crop cannot be used.");
	let u = document.createElement("canvas");
	u.width = s, u.height = c;
	let d = u.getContext("2d");
	return d.fillStyle = "#ffffff", d.fillRect(0, 0, s, c), d.setTransform(s * l.a / e.width, c * l.b / e.width, s * l.c / e.height, c * l.d / e.height, s * l.e, c * l.f), d.drawImage(e, 0, 0), new Promise((e, t) => u.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The crop could not be prepared.")), "image/jpeg", .92));
}
//#endregion
export { g as a, m as c, l as i, p as n, y as o, h as r, v as s, _ as t };

//# sourceMappingURL=images-CA4oj0g0.js.map