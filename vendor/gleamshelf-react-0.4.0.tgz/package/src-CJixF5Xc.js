//#region ../core/src/mask.ts
var e = /^[a-z0-9][a-z0-9-]{0,59}$/, t = /^[a-z0-9]{6,32}$/, n = (e) => typeof e == "number" && Number.isFinite(e) && e >= 0 && e <= 1;
function r(r) {
	if (!r || typeof r != "object") return;
	let i = r, a = i.mode === "remove" || i.mode === "keep" ? i.mode : void 0;
	if (a) {
		if (i.kind === "green") return a === "remove" ? {
			kind: "green",
			mode: a
		} : void 0;
		if (i.kind === "fade") return a === "remove" && i.edge === "bottom" && typeof i.size == "number" && Number.isFinite(i.size) ? {
			kind: "fade",
			mode: a,
			edge: "bottom",
			size: Math.min(.4, Math.max(.02, i.size))
		} : void 0;
		if (i.kind === "erase") {
			let e = i.boxes;
			return a !== "remove" || !Array.isArray(e) || e.length === 0 || e.length % 4 || e.length > 400 || !e.every(n) ? void 0 : {
				kind: "erase",
				mode: a,
				boxes: e
			};
		}
		if (i.kind === "model") return a === "remove" && typeof i.model == "string" && e.test(i.model) && typeof i.ref == "string" && t.test(i.ref) ? {
			kind: "model",
			mode: a,
			model: i.model,
			ref: i.ref
		} : void 0;
		if (i.kind === "fill") return !n(i.x) || !n(i.y) || typeof i.tolerance != "number" || !Number.isFinite(i.tolerance) ? void 0 : {
			kind: "fill",
			mode: a,
			x: i.x,
			y: i.y,
			tolerance: Math.min(100, Math.max(0, i.tolerance))
		};
		if (i.kind === "brush") {
			let e = i.points;
			return !Array.isArray(e) || e.length < 2 || e.length % 2 || e.length > 2e4 || !e.every(n) || typeof i.radius != "number" || !(i.radius > 0) || i.radius > .5 ? void 0 : {
				kind: "brush",
				mode: a,
				radius: i.radius,
				points: e
			};
		}
	}
}
function i(e) {
	if (!Array.isArray(e) || e.length > 500) return;
	let t = e.map(r);
	return t.every((e) => e !== void 0) ? t : void 0;
}
function a(e) {
	return Array.isArray(e) ? e.slice(0, 500).map(r).filter((e) => e !== void 0) : [];
}
function o(e, t) {
	let n = Math.min(1, 1024 / Math.max(e, t));
	return {
		width: Math.max(1, Math.round(e * n)),
		height: Math.max(1, Math.round(t * n))
	};
}
function s(e, t, n, r, i) {
	let a = new Uint8Array(t * n).fill(255);
	for (let o of r) o.kind === "fill" ? ee(e, a, t, n, o) : o.kind === "green" ? v(e, a, t, n) : o.kind === "fade" ? m(a, t, n, o.size) : o.kind === "erase" ? h(a, t, n, o.boxes) : o.kind === "model" ? _(a, t, n, i?.get(o.ref)) : b(a, t, n, o);
	return r.length ? x(a, t, n) : a;
}
function c(e, t, n) {
	let r = Math.max(2, Math.round(Math.min(t, n) * .02)), i = 0, a = 0, o = (n, r) => {
		let o = (r * t + n) * 4, s = e[o + 1] - Math.max(e[o], e[o + 2]);
		a++, s > 12 && s / Math.max(e[o + 1], 1) > .2 && i++;
	};
	for (let e = 0; e < n; e += 2) for (let n = 0; n < r; n++) o(n, e), o(t - 1 - n, e);
	for (let e = 0; e < t; e += 2) for (let t = 0; t < r; t++) o(e, t), o(e, n - 1 - t);
	return a ? i / a : 0;
}
var l = (e) => e.some((e) => e.kind === "green");
function u(e, t, n) {
	let r = Math.max(4, Math.round(Math.min(t, n) * .03)), i = [], a = [], o = (n, r) => {
		let o = (r * t + n) * 4, s = e[o], c = e[o + 1], l = e[o + 2];
		if (c - Math.max(s, l) < 20 || (c - Math.max(s, l)) / Math.max(c, 1) < .15) return;
		let u = s + c + l;
		i.push(s / u), a.push(c / u);
	};
	for (let e = 0; e < n; e += 2) for (let n = 0; n < r; n += 2) o(n, e), o(t - 1 - n, e);
	for (let e = 0; e < t; e += 2) for (let t = 0; t < r; t += 2) o(e, t), o(e, n - 1 - t);
	if (i.length < 200) return null;
	let s = (e) => [...e].sort((e, t) => e - t)[Math.floor(e.length / 2)];
	return {
		r: s(i),
		g: s(a)
	};
}
function d(e, t, n) {
	let r = new Uint8Array(t * n), i = [], a = (t) => {
		!r[t] && e[t] < 255 && (r[t] = 1, i.push(t));
	};
	for (let e = 0; e < t; e++) a(e), a((n - 1) * t + e);
	for (let e = 0; e < n; e++) a(e * t), a(e * t + t - 1);
	for (; i.length;) {
		let e = i.pop(), r = e % t, o = (e - r) / t;
		r > 0 && a(e - 1), r < t - 1 && a(e + 1), o > 0 && a(e - t), o < n - 1 && a(e + t);
	}
	for (let t = 0; t < e.length; t++) r[t] || (e[t] = 255);
}
function f(e, t, n, r = Math.max(4, Math.round(Math.min(t, n) * .012))) {
	let i = new Int32Array(t * n).fill(-1), a = [], o = [];
	for (let n = 0; n < e.length; n++) {
		if (e[n] < 230 || i[n] !== -1) continue;
		let r = 0;
		for (i[n] = a.length, o.push(n); o.length;) {
			let n = o.pop();
			r++;
			let s = n % t;
			for (let r of [
				s > 0 ? n - 1 : -1,
				s < t - 1 ? n + 1 : -1,
				n - t,
				n + t
			]) r < 0 || r >= e.length || e[r] < 230 || i[r] !== -1 || (i[r] = a.length, o.push(r));
		}
		a.push(r);
	}
	if (!a.length) return 0;
	let s = Math.max(...a), c = new Float32Array(t * n);
	for (let e = 0; e < c.length; e++) c[e] = i[e] >= 0 && a[i[e]] >= .05 * s ? 0 : 1e9;
	for (let e = 0; e < n; e++) for (let n = 0; n < t; n++) {
		let r = e * t + n, i = c[r];
		n > 0 && (i = Math.min(i, c[r - 1] + 1)), e > 0 && (i = Math.min(i, c[r - t] + 1), n > 0 && (i = Math.min(i, c[r - t - 1] + 1.4)), n < t - 1 && (i = Math.min(i, c[r - t + 1] + 1.4))), c[r] = i;
	}
	let l = 0;
	for (let i = n - 1; i >= 0; i--) for (let a = t - 1; a >= 0; a--) {
		let o = i * t + a, s = c[o];
		a < t - 1 && (s = Math.min(s, c[o + 1] + 1)), i < n - 1 && (s = Math.min(s, c[o + t] + 1), a < t - 1 && (s = Math.min(s, c[o + t + 1] + 1.4)), a > 0 && (s = Math.min(s, c[o + t - 1] + 1.4))), c[o] = s, e[o] > 0 && e[o] < 230 && s > r && (e[o] = 0, l++);
	}
	return l;
}
function p(e, t, n) {
	let r = t, i = n, a = new Uint8Array(r * i), o = u(e, r, i);
	for (let t = 0; t < r * i; t++) {
		let n = e[t * 4], r = e[t * 4 + 1], i = e[t * 4 + 2], s = r - Math.max(n, i), c = s / Math.max(r, 1), l = s <= 6 ? 1 : c >= .42 ? 0 : c <= .16 ? 1 : 1 - (c - .16) / .26;
		if (o && s > 6) {
			let e = n + r + i || 1, t = Math.hypot(n / e - o.r, r / e - o.g);
			l = Math.min(l, t <= .07 ? 0 : t >= .14 ? 1 : (t - .07) / .07);
		}
		let u = Math.min(1, Math.max(0, (s - 14) / 10));
		a[t] = Math.round((1 - u * (1 - l)) * 255);
	}
	d(a, r, i);
	let s = new Uint8Array(a.length);
	for (let e = 0; e < i; e++) for (let t = 0; t < r; t++) {
		let n = 255;
		for (let o = -1; o <= 1; o++) for (let s = -1; s <= 1; s++) n = Math.min(n, a[Math.min(i - 1, Math.max(0, e + o)) * r + Math.min(r - 1, Math.max(0, t + s))]);
		s[e * r + t] = n;
	}
	return f(s, r, i), s;
}
function m(e, t, n, r) {
	let i = y(e, t, n);
	if (!i) return;
	let a = i.y * n, o = (i.y + i.height) * n, s = Math.max(1, (o - a) * r);
	for (let r = Math.max(0, Math.floor(o - s)); r < Math.min(n, Math.ceil(o)); r++) {
		let n = Math.max(0, Math.min(1, (o - r) / s)), i = n * n * (3 - 2 * n);
		for (let n = 0; n < t; n++) e[r * t + n] = Math.round(e[r * t + n] * i);
	}
}
function h(e, t, n, r) {
	for (let i = 0; i < r.length; i += 4) {
		let a = Math.max(0, Math.floor(r[i] * t)), o = Math.max(0, Math.floor(r[i + 1] * n)), s = Math.min(t, Math.ceil((r[i] + r[i + 2]) * t)), c = Math.min(n, Math.ceil((r[i + 1] + r[i + 3]) * n));
		for (let n = o; n < c; n++) for (let r = a; r < s; r++) e[n * t + r] = 0;
	}
}
function g(e, t) {
	return e.filter((e) => e.kind === "model" && !t?.has(e.ref));
}
function _(e, t, n, r) {
	if (r) for (let i = 0; i < n; i++) {
		let a = Math.min(r.height - 1, Math.max(0, (i + .5) / n * r.height - .5)), o = Math.floor(a), s = Math.min(r.height - 1, o + 1), c = a - o;
		for (let n = 0; n < t; n++) {
			let a = Math.min(r.width - 1, Math.max(0, (n + .5) / t * r.width - .5)), l = Math.floor(a), u = Math.min(r.width - 1, l + 1), d = a - l, f = r.alpha[o * r.width + l] * (1 - d) + r.alpha[o * r.width + u] * d, p = r.alpha[s * r.width + l] * (1 - d) + r.alpha[s * r.width + u] * d, m = f * (1 - c) + p * c, h = i * t + n;
			e[h] = Math.min(e[h], Math.round(m));
		}
	}
}
function v(e, t, n, r) {
	let i = p(e, n, r);
	for (let e = 0; e < t.length; e++) t[e] = Math.min(t[e], i[e]);
}
function y(e, t, n, r = 24) {
	let i = t, a = n, o = -1, s = -1;
	for (let c = 0; c < n; c++) for (let n = 0; n < t; n++) e[c * t + n] > r && (n < i && (i = n), n > o && (o = n), c < a && (a = c), c > s && (s = c));
	return o < 0 ? null : {
		x: i / t,
		y: a / n,
		width: (o + 1 - i) / t,
		height: (s + 1 - a) / n
	};
}
function ee(e, t, n, r, i) {
	let a = Math.min(n - 1, Math.floor(i.x * n)), o = Math.min(r - 1, Math.floor(i.y * r)), s = (o * n + a) * 4, c = e[s], l = e[s + 1], u = e[s + 2], d = (i.tolerance / 100 * 160) ** 2, f = i.mode === "remove" ? 0 : 255, p = new Uint8Array(n * r), m = [o * n + a];
	for (p[m[0]] = 1; m.length;) {
		let i = m.pop(), a = i * 4, o = e[a] - c, s = e[a + 1] - l, h = e[a + 2] - u;
		if (o * o + s * s + h * h > d) continue;
		t[i] = f;
		let g = i % n;
		g > 0 && !p[i - 1] && (p[i - 1] = 1, m.push(i - 1)), g < n - 1 && !p[i + 1] && (p[i + 1] = 1, m.push(i + 1)), i >= n && !p[i - n] && (p[i - n] = 1, m.push(i - n)), i < n * (r - 1) && !p[i + n] && (p[i + n] = 1, m.push(i + n));
	}
}
function b(e, t, n, r) {
	let i = Math.max(1, r.radius * Math.max(t, n)), a = r.mode === "remove" ? 0 : 255, o = (r, o) => {
		let s = Math.max(0, Math.floor(r - i)), c = Math.min(t - 1, Math.ceil(r + i)), l = Math.max(0, Math.floor(o - i)), u = Math.min(n - 1, Math.ceil(o + i)), d = i * i;
		for (let n = l; n <= u; n++) for (let i = s; i <= c; i++) (i - r) ** 2 + (n - o) ** 2 <= d && (e[n * t + i] = a);
	}, s = r.points, c = s[0] * t, l = s[1] * n;
	o(c, l);
	for (let e = 2; e < s.length; e += 2) {
		let r = s[e] * t, a = s[e + 1] * n, u = Math.max(1, Math.ceil(Math.hypot(r - c, a - l) / (i / 3)));
		for (let e = 1; e <= u; e++) o(c + (r - c) * e / u, l + (a - l) * e / u);
		c = r, l = a;
	}
}
function x(e, t, n) {
	let r = new Uint8Array(e.length);
	for (let i = 0; i < n; i++) for (let a = 0; a < t; a++) {
		let o = 0, s = 0;
		for (let r = -1; r <= 1; r++) {
			let c = i + r;
			if (!(c < 0 || c >= n)) for (let n = -1; n <= 1; n++) {
				let r = a + n;
				r < 0 || r >= t || (o += e[c * t + r], s++);
			}
		}
		r[i * t + a] = Math.round(o / s);
	}
	return r;
}
function S(e, t = .12, n = 127) {
	let { alpha: r, width: i, height: a } = e, o = new Int32Array(i * a).fill(-1), s = [], c = [];
	for (let e = 0; e < r.length; e++) {
		if (r[e] <= n || o[e] !== -1) continue;
		let t = s.length, a = 0;
		for (o[e] = t, c.push(e); c.length;) {
			let e = c.pop();
			a++;
			let s = e % i;
			for (let a of [
				s > 0 ? e - 1 : -1,
				s < i - 1 ? e + 1 : -1,
				e - i,
				e + i
			]) a < 0 || a >= r.length || r[a] <= n || o[a] !== -1 || (o[a] = t, c.push(a));
		}
		s.push(a);
	}
	let l = Math.max(0, ...s);
	for (let e = 0; e < r.length; e++) {
		let i = o[e];
		(i === -1 ? r[e] > 0 && r[e] <= n : s[i] < l * t) && (r[e] = 0);
	}
	return e;
}
var te = 24, C = /^[a-z0-9][a-z0-9-]{0,59}$/, ne = /^[a-z][A-Za-z0-9]{0,39}$/;
function w(e) {
	if (!e || typeof e != "object") return;
	let { id: t, params: n } = e;
	if (typeof t != "string" || !C.test(t)) return;
	let r = {};
	if (n !== void 0) {
		if (!n || typeof n != "object" || Array.isArray(n)) return;
		let e = Object.entries(n);
		if (e.length > te) return;
		for (let [t, n] of e) {
			if (!ne.test(t) || (typeof n == "number" ? !Number.isFinite(n) : typeof n == "string" ? n.length > 40 : typeof n != "boolean")) return;
			r[t] = n;
		}
	}
	return {
		id: t,
		params: r
	};
}
function re(e) {
	if (!Array.isArray(e) || e.length > 12) return;
	let t = e.map(w);
	return t.every((e) => e !== void 0) ? t : void 0;
}
function ie(e) {
	return Array.isArray(e) ? e.slice(0, 12).map(w).filter((e) => e !== void 0) : [];
}
function ae(e, t, n, r) {
	return e.map((e, i) => i === t ? {
		...e,
		params: {
			...e.params,
			[n]: r
		}
	} : e);
}
function oe(e, t, n) {
	let r = t + n;
	if (r < 0 || r >= e.length) return [...e];
	let i = [...e];
	return [i[t], i[r]] = [i[r], i[t]], i;
}
//#endregion
//#region ../core/src/ops.ts
var T = [
	"free",
	"original",
	"1:1",
	"4:5",
	"3:4",
	"2:3",
	"16:9"
], E = (e) => ({
	kind: "number",
	label: e,
	min: -100,
	max: 100,
	step: 1,
	default: 0
}), D = (e, t) => ({
	kind: "number",
	label: e,
	min: 0,
	max: 1,
	step: .001,
	default: t,
	hidden: !0
}), O = [
	{
		type: "orient",
		label: "Orientation",
		group: "geometry",
		params: {
			quarterTurns: {
				kind: "number",
				label: "Quarter turns clockwise",
				min: 0,
				max: 3,
				step: 1,
				default: 0,
				hidden: !0
			},
			flipH: {
				kind: "boolean",
				label: "Flip horizontally",
				default: !1,
				hidden: !0
			},
			flipV: {
				kind: "boolean",
				label: "Flip vertically",
				default: !1,
				hidden: !0
			}
		}
	},
	{
		type: "straighten",
		label: "Straighten",
		group: "geometry",
		params: { angle: {
			kind: "number",
			label: "Straighten",
			min: -45,
			max: 45,
			step: .1,
			default: 0,
			unit: "°"
		} }
	},
	{
		type: "crop",
		label: "Crop",
		group: "geometry",
		params: {
			aspect: {
				kind: "choice",
				label: "Aspect ratio",
				options: T,
				default: "free",
				hidden: !0
			},
			x: D("Left", 0),
			y: D("Top", 0),
			width: D("Width", 1),
			height: D("Height", 1)
		}
	},
	{
		type: "canvas",
		label: "Canvas",
		group: "geometry",
		params: {
			square: {
				kind: "boolean",
				label: "Square canvas",
				default: !1,
				hidden: !0
			},
			margin: {
				kind: "number",
				label: "Space around",
				min: 0,
				max: 40,
				step: .5,
				default: 0,
				unit: "%",
				hidden: !0
			}
		}
	},
	{
		type: "light",
		label: "Light",
		group: "light",
		params: {
			exposure: {
				kind: "number",
				label: "Exposure",
				min: -3,
				max: 3,
				step: .01,
				default: 0,
				unit: " EV"
			},
			contrast: E("Contrast"),
			highlights: E("Highlights"),
			shadows: E("Shadows")
		}
	},
	{
		type: "color",
		label: "Color",
		group: "color",
		params: {
			temperature: E("Temperature"),
			tint: E("Tint"),
			vibrance: E("Vibrance"),
			saturation: E("Saturation")
		}
	},
	{
		type: "recolour",
		label: "Colour swap",
		group: "color",
		hint: "Changes the product's colour, so the photo no longer shows the item as it is. Use it only for a colour version you really sell, and say so in the listing. Pick a colour that has some colour in it (not white, grey or black).",
		params: {
			on: {
				kind: "boolean",
				label: "Swap a colour (changes the product)",
				default: !1
			},
			from: {
				kind: "color",
				label: "Colour to change",
				default: "#d23c3c"
			},
			to: {
				kind: "color",
				label: "New colour",
				default: "#3c64d2"
			},
			range: {
				kind: "number",
				label: "How close a colour counts",
				min: 5,
				max: 90,
				step: 1,
				default: 30,
				unit: "°"
			}
		}
	},
	{
		type: "backdrop",
		label: "Backdrop",
		group: "background",
		params: {
			mode: {
				kind: "choice",
				label: "Behind the product",
				options: [
					"transparent",
					"color",
					"image"
				],
				default: "transparent",
				hidden: !0
			},
			color: {
				kind: "color",
				label: "Colour",
				default: "#ffffff",
				hidden: !0
			}
		}
	},
	{
		type: "effects",
		label: "Effects",
		group: "effects",
		params: { vignette: E("Vignette") }
	}
], se = new Map(O.map((e) => [e.type, e]));
function ce(e, t) {
	let n = se.get(e)?.params;
	return n && Object.hasOwn(n, t) ? n[t] : void 0;
}
function k(e, t) {
	switch (e.kind) {
		case "number": {
			if (typeof t != "number" || !Number.isFinite(t)) return;
			let n = Math.min(e.max, Math.max(e.min, t));
			return Number.isInteger(e.step) && e.step >= 1 ? Math.round(n) : n;
		}
		case "boolean": return typeof t == "boolean" ? t : void 0;
		case "choice": return typeof t == "string" && e.options.includes(t) ? t : void 0;
		case "color": return typeof t == "string" && /^#[0-9a-f]{6}$/i.test(t) ? t.toLowerCase() : void 0;
	}
}
function le(e) {
	if (!e || typeof e != "object") return null;
	let t = e;
	return typeof t.model != "string" || !/^[a-z0-9][a-z0-9-]{0,59}$/.test(t.model) || typeof t.ref != "string" || !/^[a-z0-9]{6,32}$/.test(t.ref) ? null : {
		model: t.model,
		ref: t.ref
	};
}
function A(e) {
	if (!e || typeof e != "object") return null;
	let t = e;
	if (typeof t.model != "string" || !/^[a-z0-9][a-z0-9-]{0,59}$/.test(t.model) || typeof t.ref != "string" || !/^[a-z0-9]{6,32}$/.test(t.ref)) return null;
	let n = typeof t.factor == "number" && Number.isFinite(t.factor) ? Math.min(4, Math.max(1, Math.round(t.factor))) : 2;
	return {
		model: t.model,
		ref: t.ref,
		factor: n
	};
}
var ue = {
	lightness: [150, 255],
	maxWidth: [4, 80],
	minLength: [5, 200]
}, j = {
	lightness: 225,
	maxWidth: 30,
	minLength: 35
};
function de(e) {
	if (!e || typeof e != "object") return null;
	let t = e, n = {};
	for (let [e, [r, i]] of Object.entries(ue)) {
		let a = t[e];
		if (typeof a != "number" || !Number.isFinite(a)) return null;
		n[e] = Math.min(i, Math.max(r, Math.round(a)));
	}
	let r = n;
	t.lettering === !1 && (r.lettering = !1);
	let i = t.stickers;
	Array.isArray(i) && i.length > 0 && i.length % 4 == 0 && i.length <= 32 && i.every((e) => typeof e == "number" && Number.isFinite(e) && e >= 0 && e <= 1) && (r.stickers = i);
	let a = t.ai;
	return a && typeof a.model == "string" && /^[a-z0-9][a-z0-9-]{0,59}$/.test(a.model) && typeof a.ref == "string" && /^[a-z0-9]{6,32}$/.test(a.ref) && (r.ai = {
		model: a.model,
		ref: a.ref
	}), r;
}
function fe(e) {
	return Object.fromEntries(Object.entries(e.params).map(([e, t]) => [e, t.default]));
}
function M() {
	return {
		version: 1,
		ops: Object.fromEntries(O.map((e) => [e.type, fe(e)])),
		mask: [],
		effects: [],
		words: null,
		upscale: null,
		finish: null
	};
}
function pe(e) {
	let t = M();
	t.mask = a(e?.mask), t.effects = ie(e?.effects), t.words = de(e?.words), t.upscale = A(e?.upscale), t.finish = le(e?.finish);
	let n = e?.ops;
	if (!n || typeof n != "object") return t;
	for (let e of O) {
		let r = n[e.type];
		if (r && typeof r == "object") for (let [n, i] of Object.entries(e.params)) {
			let a = k(i, r[n]);
			a !== void 0 && (t.ops[e.type][n] = a);
		}
	}
	return t;
}
function N(e, t, n) {
	let r = e.ops[t]?.[n];
	return typeof r == "number" ? r : 0;
}
function P(e, t, n) {
	return e.ops[t]?.[n] === !0;
}
function F(e, t, n) {
	let r = e.ops[t]?.[n];
	return typeof r == "string" ? r : "";
}
//#endregion
//#region ../core/src/document.ts
function me(e, t = M()) {
	if (!(e.width > 0 && e.height > 0)) throw Error("A photo needs a positive width and height.");
	return {
		schema: "gleamshelf/photo",
		version: 1,
		source: { ...e },
		recipe: t
	};
}
function he(e, t) {
	return me(e, pe(t));
}
//#endregion
//#region ../core/src/geometry.ts
var I = {
	a: 1,
	b: 0,
	c: 0,
	d: 1,
	e: 0,
	f: 0
}, L = (e) => ({
	...I,
	...e
});
function ge(e, t) {
	return {
		a: e.a * t.a + e.c * t.b,
		b: e.b * t.a + e.d * t.b,
		c: e.a * t.c + e.c * t.d,
		d: e.b * t.c + e.d * t.d,
		e: e.a * t.e + e.c * t.f + e.e,
		f: e.b * t.e + e.d * t.f + e.f
	};
}
function R(e, t, n) {
	return [e.a * t + e.c * n + e.e, e.b * t + e.d * n + e.f];
}
function z(e) {
	let { width: t, height: n } = e.source;
	return N(e.recipe, "orient", "quarterTurns") % 2 == 1 ? {
		width: n,
		height: t
	} : {
		width: t,
		height: n
	};
}
function _e(e, t, n) {
	let r = Math.abs(n) * Math.PI / 180, i = Math.cos(r), a = Math.sin(r);
	return Math.max((e * i + t * a) / e, (e * a + t * i) / t);
}
function B(e) {
	let t = e.recipe;
	return {
		x: N(t, "crop", "x"),
		y: N(t, "crop", "y"),
		width: N(t, "crop", "width"),
		height: N(t, "crop", "height")
	};
}
function ve(e) {
	let t = z(e), n = B(e), r = e.recipe.upscale?.factor ?? 1, i = Math.max(1, n.width * t.width * r), a = Math.max(1, n.height * t.height * r), o = 1 + 2 * (N(e.recipe, "canvas", "margin") / 100);
	if (P(e.recipe, "canvas", "square")) {
		let e = Math.max(i, a) * o;
		return {
			crop: {
				width: i,
				height: a
			},
			canvas: {
				width: e,
				height: e
			}
		};
	}
	return {
		crop: {
			width: i,
			height: a
		},
		canvas: {
			width: i * o,
			height: a * o
		}
	};
}
function ye(e, t) {
	let { width: n, height: r } = ve(e).canvas;
	if (t && Math.max(n, r) > t) {
		let e = t / Math.max(n, r);
		n *= e, r *= e;
	}
	return {
		width: Math.max(1, Math.round(n)),
		height: Math.max(1, Math.round(r))
	};
}
function V(e) {
	let t = e.recipe, { width: n, height: r } = z(e), i = B(e), a = N(t, "straighten", "angle"), o = _e(n, r, a), s = a * Math.PI / 180, c = Math.cos(s) / o, l = Math.sin(s) / o, { crop: u, canvas: d } = ve(e), f = d.width / u.width, p = d.height / u.height, m = [
		L({
			a: f,
			d: p,
			e: .5 - .5 * f,
			f: .5 - .5 * p
		}),
		L({
			a: i.width,
			d: i.height,
			e: i.x,
			f: i.y
		}),
		L({
			a: n,
			d: r,
			e: -n / 2,
			f: -r / 2
		}),
		L({
			a: c,
			b: -l,
			c: l,
			d: c
		}),
		L({
			a: 1 / n,
			d: 1 / r,
			e: .5,
			f: .5
		})
	];
	P(t, "orient", "flipH") && m.push(L({
		a: -1,
		e: 1
	})), P(t, "orient", "flipV") && m.push(L({
		d: -1,
		f: 1
	}));
	for (let e = 0; e < N(t, "orient", "quarterTurns"); e++) m.push(L({
		a: 0,
		b: -1,
		c: 1,
		d: 0,
		f: 1
	}));
	return m.reduce((e, t) => ge(t, e), I);
}
function be(e, t) {
	if (e === "original") return t.width / t.height;
	let n = /^(\d+):(\d+)$/.exec(e);
	return n ? Number(n[1]) / Number(n[2]) : null;
}
function xe(e) {
	return be(F(e.recipe, "crop", "aspect"), z(e));
}
function Se(e) {
	let t = {
		...e.recipe.ops.crop,
		x: 0,
		y: 0,
		width: 1,
		height: 1
	}, n = {
		...e.recipe.ops.canvas,
		square: !1,
		margin: 0
	};
	return {
		...e,
		recipe: {
			...e.recipe,
			ops: {
				...e.recipe.ops,
				crop: t,
				canvas: n
			}
		}
	};
}
function H(e) {
	let t = e.a * e.d - e.b * e.c;
	return Math.abs(t) < 1e-12 ? null : {
		a: e.d / t,
		b: -e.b / t,
		c: -e.c / t,
		d: e.a / t,
		e: (e.c * e.f - e.d * e.e) / t,
		f: (e.b * e.e - e.a * e.f) / t
	};
}
function Ce(e, t) {
	let n = H(V(Se(e)));
	if (!n) return {
		x: 0,
		y: 0,
		width: 1,
		height: 1
	};
	let r = [
		[t.x, t.y],
		[t.x + t.width, t.y],
		[t.x, t.y + t.height],
		[t.x + t.width, t.y + t.height]
	].map(([e, t]) => R(n, e, t)), i = r.map((e) => e[0]), a = r.map((e) => e[1]), o = Math.max(0, Math.min(...i)), s = Math.max(0, Math.min(...a)), c = Math.min(1, Math.max(...i)), l = Math.min(1, Math.max(...a));
	return {
		x: o,
		y: s,
		width: Math.max(.001, c - o),
		height: Math.max(.001, l - s)
	};
}
function we(e, t) {
	let n = e.width / e.height, r = t < n ? t / n : 1, i = t < n ? 1 : n / t;
	return {
		x: (1 - r) / 2,
		y: (1 - i) / 2,
		width: r,
		height: i
	};
}
var U = .02, W = (e, t, n) => Math.min(n, Math.max(t, e));
function Te(e, t, n, r, i, a) {
	if (t === "move") return {
		...e,
		x: W(e.x + n, 0, 1 - e.width),
		y: W(e.y + r, 0, 1 - e.height)
	};
	let o = t.includes("w"), s = t.includes("e"), c = t.includes("n"), l = t.includes("s"), u = e.x, d = e.y, f = e.x + e.width, p = e.y + e.height;
	if (a === null) return o && (u = W(u + n, 0, f - U)), s && (f = W(f + n, u + U, 1)), c && (d = W(d + r, 0, p - U)), l && (p = W(p + r, d + U, 1)), {
		x: u,
		y: d,
		width: f - u,
		height: p - d
	};
	let m = a * i.height / i.width, h = o || s, g = c || l, _ = o ? f : s ? u : (u + f) / 2, v = c ? p : l ? d : (d + p) / 2, y = o ? _ : s ? 1 - _ : 2 * Math.min(_, 1 - _), ee = c ? v : l ? 1 - v : 2 * Math.min(v, 1 - v), b = e.width + (o ? -n : s ? n : 0), x = e.height + (c ? -r : l ? r : 0), S = h && g ? Math.max(b, x * m) : h ? b : x * m, te = Math.max(U, U * m);
	S = W(S, te, Math.min(y, ee * m));
	let C = S / m;
	return {
		x: o ? _ - S : s ? _ : _ - S / 2,
		y: c ? v - C : l ? v : v - C / 2,
		width: S,
		height: C
	};
}
function Ee(e, t) {
	return t === 1 ? {
		x: 1 - e.y - e.height,
		y: e.x,
		width: e.height,
		height: e.width
	} : {
		x: e.y,
		y: 1 - e.x - e.width,
		width: e.height,
		height: e.width
	};
}
//#endregion
//#region ../core/src/looks.ts
var G = [
	{
		id: "bright-sharp",
		label: "Bright & sharp",
		description: "A little brighter, richer colour and clearly sharper detail. What AI results get automatically.",
		ops: {
			light: {
				exposure: .3,
				contrast: 12,
				highlights: -4,
				shadows: 20
			},
			color: {
				vibrance: 35,
				saturation: 8
			}
		},
		effects: [{
			id: "sharpen",
			params: {
				amount: .9,
				radius: 1.2
			}
		}]
	},
	{
		id: "vivid",
		label: "Vivid",
		description: "Richer colour and a little more punch, with crisper detail. Good for printed box art.",
		ops: {
			light: {
				exposure: .1,
				contrast: 14,
				shadows: 12
			},
			color: {
				vibrance: 45,
				saturation: 10
			}
		},
		effects: [{
			id: "sharpen",
			params: {
				amount: .5,
				radius: 1.2
			}
		}]
	},
	{
		id: "extra-vivid",
		label: "Extra vivid",
		description: "A stronger version of Vivid for dull or faded photos.",
		ops: {
			light: {
				exposure: .15,
				contrast: 24,
				highlights: -8,
				shadows: 20
			},
			color: {
				vibrance: 70,
				saturation: 18
			}
		},
		effects: [{
			id: "sharpen",
			params: {
				amount: .8,
				radius: 1.2
			}
		}]
	}
], De = (e) => G.find((t) => t.id === e);
//#endregion
//#region ../core/src/path.ts
function K(e) {
	return e.split("/").filter(Boolean);
}
function Oe(e, t) {
	let n = e;
	for (let e of K(t)) {
		if (typeof n != "object" || !n) return;
		n = n[e];
	}
	return n;
}
function q(e, t, n) {
	let r = K(t), i = (e, t) => {
		if (t === r.length) return n;
		let a = r[t], o = typeof e == "object" && e ? e : {}, s = Array.isArray(o) ? [...o] : { ...o };
		return s[a] = i(o[a], t + 1), s;
	};
	return i(e, 0);
}
//#endregion
//#region ../core/src/history.ts
var ke = class {
	limit;
	past = [];
	future = [];
	constructor(e = 200) {
		this.limit = e;
	}
	push(e) {
		this.past.push(e), this.past.length > this.limit && this.past.shift(), this.future = [];
	}
	undo() {
		let e = this.past.pop();
		return e && this.future.push(e), e;
	}
	redo() {
		let e = this.future.pop();
		return e && this.past.push(e), e;
	}
	clear() {
		this.past = [], this.future = [];
	}
	get canUndo() {
		return this.past.length > 0;
	}
	get canRedo() {
		return this.future.length > 0;
	}
	get undoLabel() {
		return this.past.at(-1)?.label;
	}
	get redoLabel() {
		return this.future.at(-1)?.label;
	}
}, Ae = class {
	validate;
	doc;
	history = new ke();
	gesture = null;
	snapshot;
	listeners = /* @__PURE__ */ new Set();
	constructor(e, t) {
		this.validate = t, this.doc = e, this.snapshot = this.makeSnapshot();
	}
	getSnapshot = () => this.snapshot;
	subscribe = (e) => (this.listeners.add(e), () => this.listeners.delete(e));
	get document() {
		return this.doc;
	}
	set(e, t, n) {
		let r = this.validate(e, t);
		return typeof r == "string" ? r : Oe(this.doc, e) === r.value ? "unchanged" : (this.apply(n ?? r.label, [[e, r.value]]), "ok");
	}
	begin(e) {
		this.commit(), this.gesture = {
			label: e,
			start: this.doc,
			changes: /* @__PURE__ */ new Map()
		};
	}
	commit() {
		let e = this.gesture;
		if (!e) return;
		this.gesture = null;
		let t = [...e.changes.values()].filter((e) => e.before !== e.after);
		t.length && this.history.push({
			label: e.label,
			changes: t
		}), this.emit();
	}
	cancel() {
		this.gesture && (this.doc = this.gesture.start, this.gesture = null, this.emit());
	}
	undo() {
		this.commit();
		let e = this.history.undo();
		return e ? (this.doc = [...e.changes].reverse().reduce((e, t) => q(e, t.path, t.before), this.doc), this.emit(), !0) : !1;
	}
	redo() {
		this.commit();
		let e = this.history.redo();
		return e ? (this.doc = e.changes.reduce((e, t) => q(e, t.path, t.after), this.doc), this.emit(), !0) : !1;
	}
	load(e) {
		this.gesture = null, this.history.clear(), this.doc = e, this.emit();
	}
	apply(e, t) {
		let n = [], r = this.doc;
		for (let [e, i] of t) {
			let t = this.validate(e, i);
			if (typeof t == "string") throw Error(`Invalid edit (${t}): ${e} = ${String(i)}`);
			let a = Oe(r, e);
			a !== t.value && (r = q(r, e, t.value), n.push({
				path: e,
				before: a,
				after: t.value
			}));
		}
		if (n.length) {
			if (this.doc = r, this.gesture) for (let e of n) {
				let t = this.gesture.changes.get(e.path);
				this.gesture.changes.set(e.path, {
					...e,
					before: t ? t.before : e.before
				});
			}
			else this.history.push({
				label: e,
				changes: n
			});
			this.emit();
		}
	}
	makeSnapshot() {
		return {
			doc: this.doc,
			canUndo: this.history.canUndo || !!this.gesture?.changes.size,
			canRedo: this.history.canRedo,
			undoLabel: this.history.undoLabel,
			redoLabel: this.history.redoLabel
		};
	}
	emit() {
		this.snapshot = this.makeSnapshot();
		for (let e of this.listeners) e();
	}
};
function je(e) {
	return (t, n) => {
		let r = e(t);
		if (!r) return "invalid-path";
		let i = k(r, n);
		return i === void 0 ? "invalid-value" : {
			value: i,
			label: r.label
		};
	};
}
//#endregion
//#region ../core/src/editor.ts
var J = (e, t) => `recipe/ops/${e}/${t}`;
function Me(e) {
	let [t, n, r, i, ...a] = K(e);
	if (t === "recipe" && n === "ops" && r && i && !a.length) return ce(r, i);
}
var Y = "recipe/mask", X = "recipe/effects", Z = "recipe/words", Q = "recipe/upscale", $ = "recipe/finish", Ne = je(Me), Pe = (e, t) => {
	let n = K(e).join("/");
	if (n === $) {
		if (t === null) return {
			value: null,
			label: "Finishing touches"
		};
		let e = le(t);
		return e ? {
			value: e,
			label: "Finishing touches"
		} : "invalid-value";
	}
	if (n === Q) {
		if (t === null) return {
			value: null,
			label: "Enlarge"
		};
		let e = A(t);
		return e ? {
			value: e,
			label: "Enlarge"
		} : "invalid-value";
	}
	if (n === Z) {
		if (t === null) return {
			value: null,
			label: "Lettering"
		};
		let e = de(t);
		return e ? {
			value: e,
			label: "Lettering"
		} : "invalid-value";
	}
	if (n === X) {
		let e = re(t);
		return e ? {
			value: e,
			label: "Effects"
		} : "invalid-value";
	}
	if (n !== Y) return Ne(e, t);
	let r = i(t);
	return r ? {
		value: r,
		label: "Cut-out"
	} : "invalid-value";
}, Fe = class extends Ae {
	constructor(e) {
		super(e, Pe);
	}
	apply(e, t) {
		let n = this.doc.recipe.finish && !t.some(([e]) => e === $);
		super.apply(e, n ? [...t, [$, null]] : t);
	}
	get finish() {
		return this.doc.recipe.finish;
	}
	setFinish(e, t) {
		this.apply("Finishing touches (AI)", [[$, {
			model: e,
			ref: t
		}]]);
	}
	clearFinish() {
		this.finish && this.apply("Remove finishing touches", [[$, null]]);
	}
	get mask() {
		return this.doc.recipe.mask;
	}
	get words() {
		return this.doc.recipe.words;
	}
	setWords(e, t = {}) {
		let n = { ...j };
		t.lettering === !1 && (n.lettering = !1), t.stickers?.length && (n.stickers = t.stickers), this.apply(e ? t.lettering === !1 ? "Remove price stickers" : "Remove lettering" : "Put lettering back", [[Z, e ? n : null], ...this.dropUpscale()]);
	}
	setWordsAi(e, t) {
		this.words && this.apply("Fill lettering with AI", [[Z, {
			...this.words,
			ai: {
				model: e,
				ref: t
			}
		}], ...this.dropUpscale()]);
	}
	setWordsParam(e, t, n = "Lettering") {
		this.words && this.apply(n, [[Z, {
			...this.words,
			ai: void 0,
			[e]: t
		}], ...this.dropUpscale()]);
	}
	dropUpscale() {
		return this.doc.recipe.upscale ? [[Q, null]] : [];
	}
	get upscale() {
		return this.doc.recipe.upscale;
	}
	setUpscale(e, t, n = 2) {
		this.apply("Enlarge with AI", [[Q, {
			model: e,
			ref: t,
			factor: n
		}]]);
	}
	clearUpscale() {
		this.upscale && this.apply("Remove AI enlarging", [[Q, null]]);
	}
	get effects() {
		return this.doc.recipe.effects;
	}
	addEffect(e, t, n = "Add effect") {
		this.apply(n, [[X, [...this.effects, {
			id: e,
			params: t
		}]]]);
	}
	removeEffect(e, t = "Remove effect") {
		this.apply(t, [[X, this.effects.filter((t, n) => n !== e)]]);
	}
	moveEffect(e, t) {
		this.apply("Reorder effects", [[X, oe(this.effects, e, t)]]);
	}
	setEffectParam(e, t, n, r = "Adjust effect") {
		this.effects[e] && this.apply(r, [[X, ae(this.effects, e, t, n)]]);
	}
	applyLook(e) {
		let t = De(e);
		if (!t) return;
		let n = [];
		for (let [e, r] of Object.entries(t.ops)) for (let [t, i] of Object.entries(r)) n.push([J(e, t), i]);
		let r = new Set(t.effects.map((e) => e.id));
		n.push([X, [...this.effects.filter((e) => !r.has(e.id)), ...t.effects]]), this.apply(t.label, n);
	}
	clearLook() {
		let e = [];
		for (let t of ["light", "color"]) for (let [n, r] of Object.entries(M().ops[t] ?? {})) e.push([J(t, n), r]);
		let t = new Set(G.flatMap((e) => e.effects.map((e) => e.id)));
		e.push([X, this.effects.filter((e) => !t.has(e.id))]), this.apply("Natural", e);
	}
	fadeBottom(e = .1) {
		this.apply("Fade the bottom edge", [[Y, [...this.mask.filter((e) => e.kind !== "fade"), {
			kind: "fade",
			mode: "remove",
			edge: "bottom",
			size: e
		}]]]);
	}
	eraseBoxes(e) {
		let t = (e) => Math.min(1, Math.max(0, e)), n = e.slice(0, 100).flatMap((e) => [
			t(e.x),
			t(e.y),
			t(e.width),
			t(e.height)
		]);
		n.length && this.apply("Cut away text", [[Y, [...this.mask, {
			kind: "erase",
			mode: "remove",
			boxes: n
		}]]]);
	}
	addModelCutout(e, t, n = {}) {
		let r = n.replace ? this.mask.filter((e) => e.kind !== "model") : this.mask;
		this.apply("AI cut-out", [[Y, [...r, {
			kind: "model",
			mode: "remove",
			model: e,
			ref: t
		}]]]);
	}
	removeGreenBackdrop() {
		this.mask.some((e) => e.kind === "green") || this.apply("Remove green backdrop", [[Y, [...this.mask, {
			kind: "green",
			mode: "remove"
		}]]]);
	}
	fitSquareToProduct(e, t = .06) {
		let n = Ce(this.doc, e);
		this.apply("Fit square to product", [
			[J("crop", "aspect"), "free"],
			...this.cropValues(n),
			[J("canvas", "square"), !0],
			[J("canvas", "margin"), Math.round(Math.min(40, Math.max(0, t * 100)) * 2) / 2]
		]);
	}
	addMaskOp(e) {
		this.apply(e.kind === "fill" ? e.mode === "remove" ? "Remove background" : "Restore area" : e.mode === "remove" ? "Erase" : "Restore", [[Y, [...this.mask, e]]]);
	}
	updateLastMaskOp(e) {
		if (!this.mask.length) return this.addMaskOp(e);
		this.apply("Brush", [[Y, [...this.mask.slice(0, -1), e]]]);
	}
	clearMask() {
		this.mask.length && this.apply("Clear cut-out", [[Y, []]]);
	}
	rotate(e) {
		let t = this.doc.recipe, n = (N(t, "orient", "quarterTurns") + e + 4) % 4, r = F(t, "crop", "aspect");
		this.apply(e === 1 ? "Rotate right" : "Rotate left", [
			[J("orient", "quarterTurns"), n],
			[J("orient", "flipH"), P(t, "orient", "flipV")],
			[J("orient", "flipV"), P(t, "orient", "flipH")],
			...this.cropValues(Ee(B(this.doc), e)),
			[J("crop", "aspect"), r === "original" || r === "1:1" ? r : "free"]
		]);
	}
	flip(e) {
		let t = B(this.doc), n = e === "horizontal", r = n ? "flipH" : "flipV";
		this.apply(n ? "Flip horizontally" : "Flip vertically", [[J("orient", r), !P(this.doc.recipe, "orient", r)], ...this.cropValues(n ? {
			...t,
			x: 1 - t.x - t.width
		} : {
			...t,
			y: 1 - t.y - t.height
		})]);
	}
	setCropAspect(e) {
		let t = be(e, z(this.doc));
		this.apply("Crop aspect", [[J("crop", "aspect"), e], ...t === null ? [] : this.cropValues(we(z(this.doc), t))]);
	}
	setCrop(e) {
		this.apply("Crop", this.cropValues(e));
	}
	reset() {
		let e = Object.entries(M().ops).flatMap(([e, t]) => Object.entries(t).map(([t, n]) => [J(e, t), n]));
		this.apply("Reset", [
			...e,
			[Y, []],
			[X, []],
			[Z, null],
			[Q, null],
			[$, null]
		]);
	}
	cropValues(e) {
		let t = Math.min(1, Math.max(.001, e.width)), n = Math.min(1, Math.max(.001, e.height));
		return [
			[J("crop", "x"), Math.min(1 - t, Math.max(0, e.x))],
			[J("crop", "y"), Math.min(1 - n, Math.max(0, e.y))],
			[J("crop", "width"), t],
			[J("crop", "height"), n]
		];
	}
};
//#endregion
//#region ../core/src/cropmask.ts
function Ie(e, t) {
	let n = H(V({
		...e,
		recipe: {
			...e.recipe,
			ops: {
				...e.recipe.ops,
				canvas: {
					...e.recipe.ops.canvas,
					square: !1,
					margin: 0
				}
			}
		}
	})), { width: r, height: i } = o(e.source.width, e.source.height), a = new Uint8Array(r * i);
	if (!n) return {
		alpha: a,
		width: r,
		height: i
	};
	for (let e = 0; e < i; e++) for (let o = 0; o < r; o++) {
		let [s, c] = R(n, (o + .5) / r, (e + .5) / i);
		if (s < 0 || s > 1 || c < 0 || c > 1) continue;
		let l = Math.min(t.width - 1, Math.max(0, s * t.width - .5)), u = Math.min(t.height - 1, Math.max(0, c * t.height - .5)), d = Math.floor(l), f = Math.floor(u), p = Math.min(t.width - 1, d + 1), m = Math.min(t.height - 1, f + 1), h = l - d, g = u - f, _ = t.alpha[f * t.width + d] * (1 - h) + t.alpha[f * t.width + p] * h, v = t.alpha[m * t.width + d] * (1 - h) + t.alpha[m * t.width + p] * h;
		a[e * r + o] = Math.round(_ * (1 - g) + v * g);
	}
	return {
		alpha: a,
		width: r,
		height: i
	};
}
//#endregion
export { S as A, T as C, s as D, ce as E, o as M, g as N, c as O, N as S, k as T, me as _, K as a, P as b, B as c, H as d, xe as f, Se as g, Ce as h, je as i, y as j, l as k, Te as l, V as m, Fe as n, G as o, ye as p, Ae as r, R as s, Ie as t, z as u, he as v, O as w, F as x, j as y };

//# sourceMappingURL=src-CJixF5Xc.js.map