import type { Img } from './image';
/**
 * Two checks a person would otherwise make by eye on every picture: how sure we are the cut-out is right, and how much of the finished product
 * is still the photo's own pixels. Both are scores with plain reasons, so a batch of hundreds can be sorted by what needs looking at.
 */
export interface CutoutConfidence {
    /** 0-1: 1 is a clean, solid, box-shaped cut-out well inside the photo. */
    score: number;
    /** Why it is lower than 1, worst first, in the shop's words. */
    reasons: string[];
}
export interface CutoutFacts {
    /** The cut-out: one alpha byte per pixel. */
    alpha: Uint8Array;
    width: number;
    height: number;
    /** How much of its convex hull the cut-out fills (a box is above 0.96). */
    fill?: number;
    /** Whether the product is expected to be solid (a box) rather than a figure with gaps between arms and legs. */
    solid?: boolean;
}
/** How much to trust a cut-out, from the matte alone: soft (unsure) edges, holes inside, pieces at the photo's edge, odd shape, tiny size. */
export declare function cutoutConfidence(f: CutoutFacts): CutoutConfidence;
export interface Fidelity {
    /** 0-1: the share of the product that is still the photo's own detail (colour and light changes do not count as changes). */
    original: number;
    /** Where the changed parts are, as a coarse map (`cols` × `rows`, 1 = changed) for drawing over the picture. */
    map: {
        cols: number;
        rows: number;
        changed: Uint8Array;
    };
}
/**
 * Compares the product as photographed with the finished product (both transparent cut-outs, any size): block by block, does the finished one still have
 * the photo's detail? Structure is compared, not colour, so colour matching, brighter light and sharpening count as the photo's own; a repainted sticker,
 * a redrawn area or a borrowed part counts as changed.
 */
export declare function fidelityCheck(before: Img, after: Img, blocks?: number): Fidelity;
