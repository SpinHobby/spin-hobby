//#region ../../node_modules/three/examples/jsm/libs/fflate.module.js
var e = Uint8Array, t = Uint16Array, n = Int32Array, r = new e([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0,
	0,
	0,
	0
]), i = new e([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13,
	0,
	0
]), a = new e([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]), o = function(e, r) {
	for (var i = new t(31), a = 0; a < 31; ++a) i[a] = r += 1 << e[a - 1];
	for (var o = new n(i[30]), a = 1; a < 30; ++a) for (var s = i[a]; s < i[a + 1]; ++s) o[s] = s - i[a] << 5 | a;
	return {
		b: i,
		r: o
	};
}, s = o(r, 2), c = s.b, l = s.r;
c[28] = 258, l[258] = 28;
var u = o(i, 0), d = u.b;
u.r;
for (var f = new t(32768), p = 0; p < 32768; ++p) {
	var m = (p & 43690) >> 1 | (p & 21845) << 1;
	m = (m & 52428) >> 2 | (m & 13107) << 2, m = (m & 61680) >> 4 | (m & 3855) << 4, f[p] = ((m & 65280) >> 8 | (m & 255) << 8) >> 1;
}
for (var h = (function(e, n, r) {
	for (var i = e.length, a = 0, o = new t(n); a < i; ++a) e[a] && ++o[e[a] - 1];
	var s = new t(n);
	for (a = 1; a < n; ++a) s[a] = s[a - 1] + o[a - 1] << 1;
	var c;
	if (r) {
		c = new t(1 << n);
		var l = 15 - n;
		for (a = 0; a < i; ++a) if (e[a]) for (var u = a << 4 | e[a], d = n - e[a], p = s[e[a] - 1]++ << d, m = p | (1 << d) - 1; p <= m; ++p) c[f[p] >> l] = u;
	} else for (c = new t(i), a = 0; a < i; ++a) e[a] && (c[a] = f[s[e[a] - 1]++] >> 15 - e[a]);
	return c;
}), g = new e(288), p = 0; p < 144; ++p) g[p] = 8;
for (var p = 144; p < 256; ++p) g[p] = 9;
for (var p = 256; p < 280; ++p) g[p] = 7;
for (var p = 280; p < 288; ++p) g[p] = 8;
for (var _ = new e(32), p = 0; p < 32; ++p) _[p] = 5;
var v = /*#__PURE__*/ h(g, 9, 1), ee = /*#__PURE__*/ h(_, 5, 1), y = function(e) {
	for (var t = e[0], n = 1; n < e.length; ++n) e[n] > t && (t = e[n]);
	return t;
}, b = function(e, t, n) {
	var r = t / 8 | 0;
	return (e[r] | e[r + 1] << 8) >> (t & 7) & n;
}, x = function(e, t) {
	var n = t / 8 | 0;
	return (e[n] | e[n + 1] << 8 | e[n + 2] << 16) >> (t & 7);
}, te = function(e) {
	return (e + 7) / 8 | 0;
}, S = function(t, n, r) {
	return (n == null || n < 0) && (n = 0), (r == null || r > t.length) && (r = t.length), new e(t.subarray(n, r));
}, C = [
	"unexpected EOF",
	"invalid block type",
	"invalid length/literal",
	"invalid distance",
	"stream finished",
	"no stream handler",
	,
	"no callback",
	"invalid UTF-8 data",
	"extra field too long",
	"date not in range 1980-2099",
	"filename too long",
	"stream finishing",
	"invalid zip data"
], w = function(e, t, n) {
	var r = Error(t || C[e]);
	if (r.code = e, Error.captureStackTrace && Error.captureStackTrace(r, w), !n) throw r;
	return r;
}, T = function(t, n, o, s) {
	var l = t.length, u = s ? s.length : 0;
	if (!l || n.f && !n.l) return o || new e(0);
	var f = !o, p = f || n.i != 2, m = n.i;
	f && (o = new e(l * 3));
	var g = function(t) {
		var n = o.length;
		if (t > n) {
			var r = new e(Math.max(n * 2, t));
			r.set(o), o = r;
		}
	}, _ = n.f || 0, C = n.p || 0, T = n.b || 0, E = n.l, D = n.d, O = n.m, k = n.n, A = l * 8;
	do {
		if (!E) {
			_ = b(t, C, 1);
			var j = b(t, C + 1, 3);
			if (C += 3, !j) {
				var M = te(C) + 4, N = t[M - 4] | t[M - 3] << 8, P = M + N;
				if (P > l) {
					m && w(0);
					break;
				}
				p && g(T + N), o.set(t.subarray(M, P), T), n.b = T += N, n.p = C = P * 8, n.f = _;
				continue;
			}
			if (j == 1) E = v, D = ee, O = 9, k = 5;
			else if (j == 2) {
				var F = b(t, C, 31) + 257, I = b(t, C + 10, 15) + 4, L = F + b(t, C + 5, 31) + 1;
				C += 14;
				for (var R = new e(L), z = new e(19), B = 0; B < I; ++B) z[a[B]] = b(t, C + B * 3, 7);
				C += I * 3;
				for (var V = y(z), ne = (1 << V) - 1, re = h(z, V, 1), B = 0; B < L;) {
					var H = re[b(t, C, ne)];
					C += H & 15;
					var M = H >> 4;
					if (M < 16) R[B++] = M;
					else {
						var U = 0, W = 0;
						for (M == 16 ? (W = 3 + b(t, C, 3), C += 2, U = R[B - 1]) : M == 17 ? (W = 3 + b(t, C, 7), C += 3) : M == 18 && (W = 11 + b(t, C, 127), C += 7); W--;) R[B++] = U;
					}
				}
				var G = R.subarray(0, F), K = R.subarray(F);
				O = y(G), k = y(K), E = h(G, O, 1), D = h(K, k, 1);
			} else w(1);
			if (C > A) {
				m && w(0);
				break;
			}
		}
		p && g(T + 131072);
		for (var ie = (1 << O) - 1, ae = (1 << k) - 1, q = C;; q = C) {
			var U = E[x(t, C) & ie], J = U >> 4;
			if (C += U & 15, C > A) {
				m && w(0);
				break;
			}
			if (U || w(2), J < 256) o[T++] = J;
			else if (J == 256) {
				q = C, E = null;
				break;
			} else {
				var Y = J - 254;
				if (J > 264) {
					var B = J - 257, X = r[B];
					Y = b(t, C, (1 << X) - 1) + c[B], C += X;
				}
				var Z = D[x(t, C) & ae], Q = Z >> 4;
				Z || w(3), C += Z & 15;
				var K = d[Q];
				if (Q > 3) {
					var X = i[Q];
					K += x(t, C) & (1 << X) - 1, C += X;
				}
				if (C > A) {
					m && w(0);
					break;
				}
				p && g(T + 131072);
				var $ = T + Y;
				if (T < K) {
					var oe = u - K, se = Math.min(K, $);
					for (oe + T < 0 && w(3); T < se; ++T) o[T] = s[oe + T];
				}
				for (; T < $; ++T) o[T] = o[T - K];
			}
		}
		n.l = E, n.p = q, n.b = T, n.f = _, E && (_ = 1, n.m = O, n.d = D, n.n = k);
	} while (!_);
	return T != o.length && f ? S(o, 0, T) : o.subarray(0, T);
}, E = /*#__PURE__*/ new e(0), D = function(e, t) {
	return e[t] | e[t + 1] << 8;
}, O = function(e, t) {
	return (e[t] | e[t + 1] << 8 | e[t + 2] << 16 | e[t + 3] << 24) >>> 0;
}, k = function(e, t) {
	return O(e, t) + O(e, t + 4) * 4294967296;
}, A = function(e, t) {
	return ((e[0] & 15) != 8 || e[0] >> 4 > 7 || (e[0] << 8 | e[1]) % 31) && w(6, "invalid zlib data"), (e[1] >> 5 & 1) == +!t && w(6, "invalid zlib data: " + (e[1] & 32 ? "need" : "unexpected") + " dictionary"), (e[1] >> 3 & 4) + 2;
};
function j(e, t) {
	return T(e, { i: 2 }, t && t.out, t && t.dictionary);
}
function M(e, t) {
	return T(e.subarray(A(e, t && t.dictionary), -4), { i: 2 }, t && t.out, t && t.dictionary);
}
var N = typeof TextDecoder < "u" && /*#__PURE__*/ new TextDecoder();
try {
	N.decode(E, { stream: !0 });
} catch {}
var P = function(e) {
	for (var t = "", n = 0;;) {
		var r = e[n++], i = (r > 127) + (r > 223) + (r > 239);
		if (n + i > e.length) return {
			s: t,
			r: S(e, n - 1)
		};
		i ? i == 3 ? (r = ((r & 15) << 18 | (e[n++] & 63) << 12 | (e[n++] & 63) << 6 | e[n++] & 63) - 65536, t += String.fromCharCode(55296 | r >> 10, 56320 | r & 1023)) : i & 1 ? t += String.fromCharCode((r & 31) << 6 | e[n++] & 63) : t += String.fromCharCode((r & 15) << 12 | (e[n++] & 63) << 6 | e[n++] & 63) : t += String.fromCharCode(r);
	}
};
function F(e, t) {
	if (t) {
		for (var n = "", r = 0; r < e.length; r += 16384) n += String.fromCharCode.apply(null, e.subarray(r, r + 16384));
		return n;
	}
	if (N) return N.decode(e);
	var i = P(e), a = i.s, n = i.r;
	return n.length && w(8), a;
}
var I = function(e, t) {
	return t + 30 + D(e, t + 26) + D(e, t + 28);
}, L = function(e, t, n) {
	var r = D(e, t + 28), i = F(e.subarray(t + 46, t + 46 + r), !(D(e, t + 8) & 2048)), a = t + 46 + r, o = O(e, t + 20), s = n && o == 4294967295 ? R(e, a) : [
		o,
		O(e, t + 24),
		O(e, t + 42)
	], c = s[0], l = s[1], u = s[2];
	return [
		D(e, t + 10),
		c,
		l,
		i,
		a + D(e, t + 30) + D(e, t + 32),
		u
	];
}, R = function(e, t) {
	for (; D(e, t) != 1; t += 4 + D(e, t + 2));
	return [
		k(e, t + 12),
		k(e, t + 4),
		k(e, t + 20)
	];
};
function z(t, n) {
	for (var r = {}, i = t.length - 22; O(t, i) != 101010256; --i) (!i || t.length - i > 65558) && w(13);
	var a = D(t, i + 8);
	if (!a) return {};
	var o = O(t, i + 16), s = o == 4294967295 || a == 65535;
	if (s) {
		var c = O(t, i - 12);
		s = O(t, c) == 101075792, s && (a = O(t, c + 32), o = O(t, c + 48));
	}
	for (var l = n && n.filter, u = 0; u < a; ++u) {
		var d = L(t, o, s), f = d[0], p = d[1], m = d[2], h = d[3], g = d[4], _ = d[5], v = I(t, _);
		o = g, (!l || l({
			name: h,
			size: p,
			originalSize: m,
			compression: f
		})) && (f ? f == 8 ? r[h] = j(t.subarray(v, v + p), { out: new e(m) }) : w(14, "unknown compression type " + f) : r[h] = S(t, v, v + p));
	}
	return r;
}
//#endregion
export { M as n, z as t };

//# sourceMappingURL=fflate.module-d2PQQWvd.js.map