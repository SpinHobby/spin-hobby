import { a as e, s as t } from "./Panel-C6TPnUHQ.js";
import { n, t as r } from "./useLocalApp-nvfeYzQT.js";
import { n as i, t as a } from "./theme-qdSfcbOw.js";
import { $ as o, A as s, B as c, G as l, H as u, Jn as d, Lt as f, M as p, Pt as m, Q as h, St as g, Un as _, Vn as v, Wn as y, Wt as b, _t as ee, a as x, at as S, bt as C, gr as w, hr as te, it as ne, k as T, l as E, n as re, or as ie, p as D, qn as ae, st as oe, tr as se, u as ce, vt as le, xt as ue, yt as de } from "./three.core-DIbF123p.js";
import { C as fe, a as pe, c as me, d as he, f as ge, i as _e, l as ve, m as ye, n as be, o as xe, p as Se, r as Ce, s as we, t as Te, u as Ee, w as De, y as Oe } from "./output-DBDfedHt.js";
import { t as ke } from "./GLTFLoader-Bn3T_5ox.js";
import { useEffect as Ae, useMemo as je, useRef as Me, useState as O } from "react";
import { Fragment as Ne, jsx as k, jsxs as A } from "react/jsx-runtime";
//#region ../avatar/src/math.ts
var Pe = [
	0,
	0,
	0,
	1
], Fe = Math.PI / 180, Ie = (e, t) => [
	e[0] - t[0],
	e[1] - t[1],
	e[2] - t[2]
], Le = (e, t) => [
	e[0] * t,
	e[1] * t,
	e[2] * t
], Re = (e, t) => e[0] * t[0] + e[1] * t[1] + e[2] * t[2], ze = (e, t) => [
	e[1] * t[2] - e[2] * t[1],
	e[2] * t[0] - e[0] * t[2],
	e[0] * t[1] - e[1] * t[0]
], Be = (e) => Math.hypot(e[0], e[1], e[2]), Ve = (e) => {
	let t = Be(e) || 1;
	return [
		e[0] / t,
		e[1] / t,
		e[2] / t
	];
}, He = (e) => Math.min(1, Math.max(0, e)), Ue = (e, t, n) => He((e - t) / (n - t));
function We(e, t) {
	return [
		e[3] * t[0] + e[0] * t[3] + e[1] * t[2] - e[2] * t[1],
		e[3] * t[1] - e[0] * t[2] + e[1] * t[3] + e[2] * t[0],
		e[3] * t[2] + e[0] * t[1] - e[1] * t[0] + e[2] * t[3],
		e[3] * t[3] - e[0] * t[0] - e[1] * t[1] - e[2] * t[2]
	];
}
var Ge = (e) => [
	-e[0],
	-e[1],
	-e[2],
	e[3]
];
function Ke(e) {
	let t = Math.hypot(e[0], e[1], e[2], e[3]) || 1;
	return [
		e[0] / t,
		e[1] / t,
		e[2] / t,
		e[3] / t
	];
}
function qe(e, t) {
	let [n, r, i] = Ve(e), a = Math.sin(t * Fe / 2);
	return [
		n * a,
		r * a,
		i * a,
		Math.cos(t * Fe / 2)
	];
}
function Je(e, t, n) {
	return We(We(qe([
		1,
		0,
		0
	], e), qe([
		0,
		1,
		0
	], t)), qe([
		0,
		0,
		1
	], n));
}
function Ye(e, t) {
	let n = Ve(e), r = Ve(t), i = Re(n, r);
	if (i < -.999999) return qe(Math.abs(n[0]) < .9 ? ze(n, [
		1,
		0,
		0
	]) : ze(n, [
		0,
		1,
		0
	]), 180);
	let a = ze(n, r);
	return Ke([
		a[0],
		a[1],
		a[2],
		1 + i
	]);
}
function Xe(e, t) {
	let n = We(We(e, [
		t[0],
		t[1],
		t[2],
		0
	]), Ge(e));
	return [
		n[0],
		n[1],
		n[2]
	];
}
function Ze(e, t, n) {
	let [r, i, a, o] = t, s = e[0] * r + e[1] * i + e[2] * a + e[3] * o;
	if (s < 0 && (r = -r, i = -i, a = -a, o = -o, s = -s), s > .9995) return Ke([
		e[0] + (r - e[0]) * n,
		e[1] + (i - e[1]) * n,
		e[2] + (a - e[2]) * n,
		e[3] + (o - e[3]) * n
	]);
	let c = Math.acos(s), l = Math.sin(c), u = Math.sin((1 - n) * c) / l, d = Math.sin(n * c) / l;
	return [
		e[0] * u + r * d,
		e[1] * u + i * d,
		e[2] * u + a * d,
		e[3] * u + o * d
	];
}
function Qe(e) {
	let [t, n, r, , i, a, o, , s, c, l] = e, u = Math.hypot(t, n, r) || 1, d = Math.hypot(i, a, o) || 1, f = Math.hypot(s, c, l) || 1, [p, m, h, g, _, v, y, b, ee] = [
		t / u,
		i / d,
		s / f,
		n / u,
		a / d,
		c / f,
		r / u,
		o / d,
		l / f
	], x = p + _ + ee, S;
	if (x > 0) {
		let e = Math.sqrt(x + 1) * 2;
		S = [
			(b - v) / e,
			(h - y) / e,
			(g - m) / e,
			e / 4
		];
	} else if (p > _ && p > ee) {
		let e = Math.sqrt(1 + p - _ - ee) * 2;
		S = [
			e / 4,
			(m + g) / e,
			(h + y) / e,
			(b - v) / e
		];
	} else if (_ > ee) {
		let e = Math.sqrt(1 + _ - p - ee) * 2;
		S = [
			(m + g) / e,
			e / 4,
			(v + b) / e,
			(h - y) / e
		];
	} else {
		let e = Math.sqrt(1 + ee - p - _) * 2;
		S = [
			(h + y) / e,
			(v + b) / e,
			e / 4,
			(g - m) / e
		];
	}
	return Ke(S);
}
var $e = (e) => [
	e[0],
	-e[1],
	-e[2],
	e[3]
], et = [
	"happy",
	"angry",
	"sad",
	"relaxed",
	"surprised",
	"aa",
	"ih",
	"ou",
	"ee",
	"oh",
	"blinkLeft",
	"blinkRight"
], tt = () => ({
	expressions: {},
	bones: {}
});
function nt(e, t = !0) {
	let n = (t) => e.blendshapes[t] ?? 0, [r, i] = t ? ["Right", "Left"] : ["Left", "Right"], a = Ue(n("jawOpen"), .06, .5), o = n("mouthFunnel"), s = n("mouthPucker"), c = (n("mouthSmileLeft") + n("mouthSmileRight")) / 2, l = (n("mouthStretchLeft") + n("mouthStretchRight")) / 2, u = He(c * .8 + l * 1.2), d = (n("mouthFrownLeft") + n("mouthFrownRight")) / 2, f = (n("browDownLeft") + n("browDownRight")) / 2, p = n("browInnerUp"), m = (n("eyeWideLeft") + n("eyeWideRight")) / 2, h = {
		blinkLeft: Ue(n(`eyeBlink${r}`), .35, .72),
		blinkRight: Ue(n(`eyeBlink${i}`), .35, .72),
		aa: He(a * (1 - Math.max(o, s)) * (1 - u * .4)),
		oh: He(a * o * 1.6),
		ou: He(s * (1 - a) * 1.3),
		ee: He(u * a * 1.4),
		ih: He(u * (1 - a) * .5),
		happy: Ue(c, .35, .8),
		sad: He(Math.max(Ue(d, .2, .6), Ue(p, .4, .8) * (1 - c))),
		angry: Ue(f, .35, .75),
		surprised: He(Ue(p, .45, .85) * Ue(m + a, .3, .9))
	}, g = (n("eyeLookOutLeft") - n("eyeLookInLeft") + (n("eyeLookInRight") - n("eyeLookOutRight"))) / 2, _ = (n("eyeLookUpLeft") + n("eyeLookUpRight") - n("eyeLookDownLeft") - n("eyeLookDownRight")) / 2, v = {
		expressions: h,
		bones: {},
		lookAt: {
			yaw: (t ? -1 : 1) * g * 25,
			pitch: _ * 18
		}
	};
	if (e.matrix && e.matrix.length >= 16) {
		let n = Qe(e.matrix);
		t && (n = $e(n)), v.bones.neck = Ze(Pe, n, .35), v.bones.head = Ze(Pe, n, .65);
	}
	return v;
}
var rt = {
	leftShoulder: 11,
	rightShoulder: 12,
	leftElbow: 13,
	rightElbow: 14,
	leftWrist: 15,
	rightWrist: 16,
	leftHip: 23,
	rightHip: 24
}, it = (e, t) => [
	t ? -e.x : e.x,
	-e.y,
	-e.z
];
function at() {
	return {
		leftUpperArm: qe([
			0,
			0,
			1
		], -72),
		rightUpperArm: qe([
			0,
			0,
			1
		], 72),
		leftLowerArm: qe([
			0,
			1,
			0
		], 12),
		rightLowerArm: qe([
			0,
			1,
			0
		], -12)
	};
}
function ot(e, t = !0, n = .5) {
	let r = (n) => it(e[n], t), i = (...t) => t.every((t) => (e[t]?.visibility ?? 1) >= n), a = { ...at() };
	if (e.length < 25) return a;
	let o = (e) => t ? e === "left" ? "right" : "left" : e, s = Pe;
	if (i(rt.leftShoulder, rt.rightShoulder)) {
		let e = Ie(r(rt[`${o("left")}Shoulder`]), r(rt[`${o("right")}Shoulder`])), t = Math.atan2(e[1], e[0]) * (180 / Math.PI);
		s = Je(0, st(-Math.atan2(e[2], e[0]) * (180 / Math.PI), 35), st(t, 25)), a.spine = Ze(Pe, s, .5), a.chest = Ze(Pe, s, .5);
	}
	for (let e of ["left", "right"]) {
		let t = o(e);
		if (!i(rt[`${t}Shoulder`], rt[`${t}Elbow`])) continue;
		let n = r(rt[`${t}Shoulder`]), c = r(rt[`${t}Elbow`]), l = e === "left" ? [
			1,
			0,
			0
		] : [
			-1,
			0,
			0
		], u = Ye(l, Ie(c, n));
		if (a[`${e}UpperArm`] = We(Ge(s), u), i(rt[`${t}Wrist`])) {
			let n = Ye(l, Ie(r(rt[`${t}Wrist`]), c));
			a[`${e}LowerArm`] = We(Ge(u), n);
		} else a[`${e}LowerArm`] = Pe;
	}
	return a;
}
var st = (e, t) => Math.min(t, Math.max(-t, e)), ct = [
	["Thumb", [
		1,
		2,
		3,
		4
	]],
	["Index", [
		5,
		6,
		7,
		8
	]],
	["Middle", [
		9,
		10,
		11,
		12
	]],
	["Ring", [
		13,
		14,
		15,
		16
	]],
	["Little", [
		17,
		18,
		19,
		20
	]]
], lt = [
	"Proximal",
	"Intermediate",
	"Distal"
];
function ut(e, t, n) {
	let r = Ve(Ie(t, e)), i = Ve(Ie(n, t));
	return Math.acos(Math.min(1, Math.max(-1, r[0] * i[0] + r[1] * i[1] + r[2] * i[2]))) * 180 / Math.PI;
}
function dt(e, t) {
	let n = {};
	if (e.length < 21) return n;
	let r = (t) => [
		e[t].x,
		-e[t].y,
		-e[t].z
	], i = t === "left" ? -1 : 1;
	for (let [e, a] of ct) {
		let o = [r(0), ...a.map(r)];
		lt.forEach((r, a) => {
			let s = Math.min(100, ut(o[a], o[a + 1], o[a + 2])), c = e === "Thumb" ? [
				0,
				1,
				0
			] : [
				0,
				0,
				1
			];
			n[`${t}${e}${r}`] = qe(c, i * s * (e === "Thumb" ? .7 : 1));
		});
	}
	return n;
}
function ft(e, t = !0) {
	let n = e.face ? nt(e.face, t) : tt();
	e.pose && Object.assign(n.bones, ot(e.pose, t));
	let r = t ? [[e.rightHand, "left"], [e.leftHand, "right"]] : [[e.leftHand, "left"], [e.rightHand, "right"]];
	for (let [e, t] of r) e && Object.assign(n.bones, dt(e, t));
	return n;
}
var pt = class {
	amount;
	current = tt();
	constructor(e = .5) {
		this.amount = e;
	}
	next(e) {
		let t = 1 - this.amount, n = {
			expressions: {},
			bones: {}
		};
		for (let [r, i] of Object.entries(e.expressions)) {
			let e = this.current.expressions[r] ?? 0;
			n.expressions[r] = r.startsWith("blink") ? i : e + (i - e) * t;
		}
		for (let [r, i] of Object.entries(e.bones)) {
			let e = this.current.bones[r];
			n.bones[r] = e ? Ze(e, i, t) : i;
		}
		if (e.lookAt) {
			let r = this.current.lookAt ?? e.lookAt;
			n.lookAt = {
				yaw: r.yaw + (e.lookAt.yaw - r.yaw) * t,
				pitch: r.pitch + (e.lookAt.pitch - r.pitch) * t
			};
		}
		return this.current = n, n;
	}
	reset() {
		this.current = tt();
	}
};
function mt(e, t, n) {
	let r = He(n), i = {
		expressions: { ...e.expressions },
		bones: { ...e.bones },
		lookAt: e.lookAt ?? t.lookAt
	};
	for (let [n, a] of Object.entries(t.expressions)) i.expressions[n] = (e.expressions[n] ?? 0) * (1 - r) + a * r;
	for (let [n, a] of Object.entries(t.bones)) i.bones[n] = Ze(e.bones[n] ?? Pe, a, r);
	return i;
}
//#endregion
//#region ../avatar/src/motion.ts
var ht = {
	wave: {
		label: "Wave",
		key: "1",
		seconds: 2.2
	},
	nod: {
		label: "Nod",
		key: "2",
		seconds: 1.2
	},
	shake: {
		label: "Shake head",
		key: "3",
		seconds: 1.2
	},
	thumbsUp: {
		label: "Thumbs up",
		key: "4",
		seconds: 1.8
	},
	point: {
		label: "Point",
		key: "5",
		seconds: 1.8
	},
	heart: {
		label: "Heart hands",
		key: "6",
		seconds: 2.2
	},
	bow: {
		label: "Bow",
		key: "7",
		seconds: 2
	},
	cheer: {
		label: "Cheer",
		key: "8",
		seconds: 1.8
	}
}, gt = Object.keys(ht), _t = (e) => e * e * (3 - 2 * e), vt = (e, t = .18) => e <= 0 || e >= 1 ? 0 : _t(Math.min(1, e / t, (1 - e) / t));
function yt(e, t, n, r) {
	let i = e === "left" ? [
		1,
		0,
		0
	] : [
		-1,
		0,
		0
	], a = Ye(i, Ve(t)), o = Ve(n), s = Ye(i, o);
	if (r) {
		let e = (e) => Ve(Ie(e, Le(o, Re(e, o)))), t = e(Xe(s, [
			0,
			0,
			1
		])), n = e(r);
		s = We(qe(o, Math.atan2(Re(ze(t, n), o), Re(t, n)) * 180 / Math.PI), s);
	}
	return {
		[`${e}UpperArm`]: a,
		[`${e}LowerArm`]: We(Ge(a), s)
	};
}
function bt(e, t) {
	let n = e === "left" ? -1 : 1, r = {};
	for (let [i, a] of Object.entries(t)) for (let [t, o] of [
		["Proximal", 75],
		["Intermediate", 85],
		["Distal", 60]
	]) r[`${e}${i}${t}`] = qe(i === "Thumb" ? [
		0,
		1,
		0
	] : [
		0,
		0,
		1
	], n * o * a * (i === "Thumb" ? .6 : 1));
	return r;
}
var xt = {
	Thumb: .8,
	Index: 1,
	Middle: 1,
	Ring: 1,
	Little: 1
}, St = (e) => [
	-e[0],
	e[1],
	e[2]
];
function Ct(e, t) {
	let n = vt(t), r = Math.sin(t * Math.PI * 2 * 3), i = {}, a = {};
	switch (e) {
		case "wave":
			i = {
				...yt("right", [
					-.9,
					-.1,
					.3
				], [
					-.1 + r * .35,
					1,
					.2
				], [
					1,
					0,
					0
				]),
				...bt("right", {})
			}, a = { happy: .7 };
			break;
		case "nod":
			i = {
				head: Je(14 * Math.max(0, Math.sin(t * Math.PI * 4)), 0, 0),
				neck: Je(6 * Math.max(0, Math.sin(t * Math.PI * 4)), 0, 0)
			}, a = { happy: .3 };
			break;
		case "shake":
			i = {
				head: Je(0, 18 * Math.sin(t * Math.PI * 4), 0),
				neck: Je(0, 7 * Math.sin(t * Math.PI * 4), 0)
			};
			break;
		case "thumbsUp":
			i = {
				...yt("right", [
					-.45,
					-.75,
					.45
				], [
					.15,
					.3,
					1
				], [
					0,
					1,
					0
				]),
				...bt("right", {
					...xt,
					Thumb: 0
				})
			}, a = { happy: .8 };
			break;
		case "point":
			i = {
				...yt("right", [
					-.2,
					-.25,
					.95
				], [
					.05,
					.1,
					1
				]),
				...bt("right", {
					...xt,
					Index: 0
				})
			}, a = { surprised: .25 };
			break;
		case "heart": {
			let e = [
				-.3,
				-.75,
				.55
			], n = [
				.75,
				.45,
				.45
			], r = {
				Thumb: .3,
				Index: .55,
				Middle: .55,
				Ring: .55,
				Little: .55
			};
			i = {
				...yt("right", e, n),
				...yt("left", St(e), St(n)),
				...bt("right", r),
				...bt("left", r),
				head: Je(0, 0, 6 * Math.sin(t * Math.PI))
			}, a = { happy: 1 };
			break;
		}
		case "bow":
			i = {
				spine: Je(22, 0, 0),
				chest: Je(14, 0, 0),
				head: Je(10, 0, 0),
				...yt("right", [
					-.25,
					-1,
					.15
				], [
					-.05,
					-1,
					.3
				]),
				...yt("left", [
					.25,
					-1,
					.15
				], [
					.05,
					-1,
					.3
				])
			}, a = { relaxed: .8 };
			break;
		case "cheer": {
			let e = Math.max(0, Math.sin(t * Math.PI * 6)) * .25;
			i = {
				...yt("right", [
					-.45,
					.85 + e,
					.1
				], [
					-.1,
					1,
					0
				]),
				...yt("left", [
					.45,
					.85 + e,
					.1
				], [
					.1,
					1,
					0
				]),
				...bt("right", xt),
				...bt("left", xt)
			}, a = {
				happy: 1,
				aa: .4
			};
			break;
		}
	}
	return {
		pose: {
			bones: i,
			expressions: a
		},
		weight: n
	};
}
var wt = (e) => {
	let t = Math.sin(e * 127.1 + 311.7) * 43758.5453;
	return t - Math.floor(t);
};
function Tt(e) {
	let t = .8;
	for (let n = 0; n < 1e4 && t < e + 1; n++) {
		let r = e - t, i = (e) => e >= 0 && e < .16 ? Math.sin(e / .16 * Math.PI) : 0;
		if (r > -.2 && r < .6) return Math.max(i(r), wt(n) > .8 ? i(r - .25) : 0);
		t += 2.5 + wt(n + 77) * 3.5;
	}
	return 0;
}
function Et(e) {
	return {
		chest: Je(1.2 * Math.sin(e * Math.PI * 2 / 4.2), 0, 0),
		spine: Je(0, 1.5 * Math.sin(e * .37), .8 * Math.sin(e * .23)),
		head: Je(1.5 * Math.sin(e * .31), 2.5 * Math.sin(e * .19), 1.2 * Math.sin(e * .27))
	};
}
function Dt(e, t, n) {
	let r = t / n, i = 0, a = 0, o = 0;
	for (let t = 0; t < e.length; t++) {
		let n = t * r;
		if (n < 150 || n > 4e3) continue;
		let s = (e[t] ?? 0) / 255;
		i += s * s, a += s * s * n, o++;
	}
	if (!o) return {};
	let s = Math.sqrt(i / o), c = Math.min(1, Math.max(0, (s - .12) / .35));
	if (c <= 0) return {
		aa: 0,
		ih: 0,
		ou: 0,
		ee: 0,
		oh: 0
	};
	let l = a / Math.max(1e-6, i), u = Math.min(1, Math.max(0, (l - 1100) / 1200)), d = Math.min(1, Math.max(0, (1300 - l) / 600));
	return {
		aa: c * (1 - u) * (1 - d),
		ee: c * u * .9,
		ih: c * u * .35,
		oh: c * d * .8,
		ou: c * d * .4
	};
}
//#endregion
//#region ../avatar/src/driver.ts
var Ot = [
	"aa",
	"ih",
	"ou",
	"ee",
	"oh"
], kt = [
	"happy",
	"angry",
	"sad",
	"relaxed",
	"surprised"
], At = 600, jt = class {
	tracked = null;
	trackedAt = -Infinity;
	smoother = new pt(.55);
	gestures = [];
	held = {};
	lips = null;
	mirror = !0;
	track(e, t) {
		this.tracked = this.smoother.next(ft(e, this.mirror)), this.trackedAt = t;
	}
	untrack() {
		this.tracked = null, this.trackedAt = -Infinity, this.smoother.reset();
	}
	play(e, t) {
		this.gestures = [...this.gestures.filter((t) => t.name !== e), {
			name: e,
			start: t
		}];
	}
	hold(e, t) {
		t > 0 ? this.held = { [e]: t } : delete this.held[e];
	}
	speak(e) {
		this.lips = e;
	}
	get isTracking() {
		return this.tracked !== null;
	}
	compose(e) {
		let t = e / 1e3, n = this.tracked && e - this.trackedAt < At ? this.tracked : null, r = Et(t), i = { ...at() };
		n ? i.chest = r.chest : Object.assign(i, r);
		let a = {
			expressions: {},
			bones: i
		};
		if (n) {
			a.lookAt = n.lookAt, Object.assign(a.expressions, n.expressions);
			for (let [e, t] of Object.entries(n.bones)) a.bones[e] = e === "chest" && i.chest ? We(t, i.chest) : t;
		} else {
			let e = Tt(t);
			a.expressions.blinkLeft = e, a.expressions.blinkRight = e;
		}
		if (this.lips) for (let e of Ot) a.expressions[e] = Math.max(a.expressions[e] ?? 0, this.lips[e] ?? 0);
		if (Object.keys(this.held).length) for (let e of kt) a.expressions[e] = this.held[e] ?? 0;
		this.gestures = this.gestures.filter((t) => (e - t.start) / 1e3 < ht[t.name].seconds);
		for (let t of this.gestures) {
			let { pose: n, weight: r } = Ct(t.name, (e - t.start) / 1e3 / ht[t.name].seconds);
			a = mt(a, n, r);
		}
		return a;
	}
}, Mt = (e, t, n) => new Promise((r, i) => {
	var a = (e) => {
		try {
			s(n.next(e));
		} catch (e) {
			i(e);
		}
	}, o = (e) => {
		try {
			s(n.throw(e));
		} catch (e) {
			i(e);
		}
	}, s = (e) => e.done ? r(e.value) : Promise.resolve(e.value).then(a, o);
	s((n = n.apply(e, t)).next());
}), j = (e, t, n) => new Promise((r, i) => {
	var a = (e) => {
		try {
			s(n.next(e));
		} catch (e) {
			i(e);
		}
	}, o = (e) => {
		try {
			s(n.throw(e));
		} catch (e) {
			i(e);
		}
	}, s = (e) => e.done ? r(e.value) : Promise.resolve(e.value).then(a, o);
	s((n = n.apply(e, t)).next());
}), Nt = class extends m {
	constructor(e) {
		super(), this.weight = 0, this.isBinary = !1, this.overrideBlink = "none", this.overrideLookAt = "none", this.overrideMouth = "none", this._binds = [], this.name = `VRMExpression_${e}`, this.expressionName = e, this.type = "VRMExpression", this.visible = !1;
	}
	get binds() {
		return this._binds;
	}
	get overrideBlinkAmount() {
		return this.overrideBlink === "block" ? +(0 < this.outputWeight) : this.overrideBlink === "blend" ? this.outputWeight : 0;
	}
	get overrideLookAtAmount() {
		return this.overrideLookAt === "block" ? +(0 < this.outputWeight) : this.overrideLookAt === "blend" ? this.outputWeight : 0;
	}
	get overrideMouthAmount() {
		return this.overrideMouth === "block" ? +(0 < this.outputWeight) : this.overrideMouth === "blend" ? this.outputWeight : 0;
	}
	get outputWeight() {
		return this.isBinary ? +(this.weight > .5) : this.weight;
	}
	addBind(e) {
		this._binds.push(e);
	}
	deleteBind(e) {
		let t = this._binds.indexOf(e);
		t >= 0 && this._binds.splice(t, 1);
	}
	applyWeight(e) {
		let t = this.outputWeight;
		t *= e?.multiplier ?? 1, this.isBinary && t < 1 && (t = 0), this._binds.forEach((e) => e.applyWeight(t));
	}
	clearAppliedWeight() {
		this._binds.forEach((e) => e.clearAppliedWeight());
	}
};
function Pt(e, t, n) {
	let r = e.parser.json, i = r.nodes?.[t];
	if (i == null) return console.warn(`extractPrimitivesInternal: Attempt to use nodes[${t}] of glTF but the node doesn't exist`), null;
	let a = i.mesh;
	if (a == null) return null;
	let o = r.meshes?.[a];
	if (o == null) return console.warn(`extractPrimitivesInternal: Attempt to use meshes[${a}] of glTF but the mesh doesn't exist`), null;
	let s = o.primitives.length, c = [];
	return n.traverse((e) => {
		c.length < s && e.isMesh && c.push(e);
	}), c;
}
function Ft(e, t) {
	return j(this, null, function* () {
		return Pt(e, t, yield e.parser.getDependency("node", t));
	});
}
function It(e) {
	return j(this, null, function* () {
		let t = yield e.parser.getDependencies("node"), n = /* @__PURE__ */ new Map();
		return t.forEach((t, r) => {
			let i = Pt(e, r, t);
			i != null && n.set(r, i);
		}), n;
	});
}
var Lt = {
	Aa: "aa",
	Ih: "ih",
	Ou: "ou",
	Ee: "ee",
	Oh: "oh",
	Blink: "blink",
	Happy: "happy",
	Angry: "angry",
	Sad: "sad",
	Relaxed: "relaxed",
	LookUp: "lookUp",
	Surprised: "surprised",
	LookDown: "lookDown",
	LookLeft: "lookLeft",
	LookRight: "lookRight",
	BlinkLeft: "blinkLeft",
	BlinkRight: "blinkRight",
	Neutral: "neutral"
};
function Rt(e) {
	return Math.max(Math.min(e, 1), 0);
}
var zt = class e {
	constructor() {
		this.blinkExpressionNames = [
			"blink",
			"blinkLeft",
			"blinkRight"
		], this.lookAtExpressionNames = [
			"lookLeft",
			"lookRight",
			"lookUp",
			"lookDown"
		], this.mouthExpressionNames = [
			"aa",
			"ee",
			"ih",
			"oh",
			"ou"
		], this._expressions = [], this._expressionMap = {};
	}
	get expressions() {
		return this._expressions.concat();
	}
	get expressionMap() {
		return Object.assign({}, this._expressionMap);
	}
	get presetExpressionMap() {
		let e = {}, t = new Set(Object.values(Lt));
		return Object.entries(this._expressionMap).forEach(([n, r]) => {
			t.has(n) && (e[n] = r);
		}), e;
	}
	get customExpressionMap() {
		let e = {}, t = new Set(Object.values(Lt));
		return Object.entries(this._expressionMap).forEach(([n, r]) => {
			t.has(n) || (e[n] = r);
		}), e;
	}
	copy(e) {
		return this._expressions.concat().forEach((e) => {
			this.unregisterExpression(e);
		}), e._expressions.forEach((e) => {
			this.registerExpression(e);
		}), this.blinkExpressionNames = e.blinkExpressionNames.concat(), this.lookAtExpressionNames = e.lookAtExpressionNames.concat(), this.mouthExpressionNames = e.mouthExpressionNames.concat(), this;
	}
	clone() {
		return new e().copy(this);
	}
	getExpression(e) {
		return this._expressionMap[e] ?? null;
	}
	registerExpression(e) {
		this._expressions.push(e), this._expressionMap[e.expressionName] = e;
	}
	unregisterExpression(e) {
		let t = this._expressions.indexOf(e);
		t === -1 && console.warn("VRMExpressionManager: The specified expressions is not registered"), this._expressions.splice(t, 1), delete this._expressionMap[e.expressionName];
	}
	getValue(e) {
		return this.getExpression(e)?.weight ?? null;
	}
	setValue(e, t) {
		let n = this.getExpression(e);
		n && (n.weight = Rt(t));
	}
	resetValues() {
		this._expressions.forEach((e) => {
			e.weight = 0;
		});
	}
	getExpressionTrackName(e) {
		let t = this.getExpression(e);
		return t ? `${t.name}.weight` : null;
	}
	update() {
		let e = this._calculateWeightMultipliers();
		this._expressions.forEach((e) => {
			e.clearAppliedWeight();
		}), this._expressions.forEach((t) => {
			let n = 1, r = t.expressionName;
			this.blinkExpressionNames.indexOf(r) !== -1 && (n *= e.blink), this.lookAtExpressionNames.indexOf(r) !== -1 && (n *= e.lookAt), this.mouthExpressionNames.indexOf(r) !== -1 && (n *= e.mouth), t.applyWeight({ multiplier: n });
		});
	}
	_calculateWeightMultipliers() {
		let e = 1, t = 1, n = 1;
		return this._expressions.forEach((r) => {
			e -= r.overrideBlinkAmount, t -= r.overrideLookAtAmount, n -= r.overrideMouthAmount;
		}), e = Math.max(0, e), t = Math.max(0, t), n = Math.max(0, n), {
			blink: e,
			lookAt: t,
			mouth: n
		};
	}
}, Bt = {
	Color: "color",
	EmissionColor: "emissionColor",
	ShadeColor: "shadeColor",
	MatcapColor: "matcapColor",
	RimColor: "rimColor",
	OutlineColor: "outlineColor"
}, Vt = {
	_Color: Bt.Color,
	_EmissionColor: Bt.EmissionColor,
	_ShadeColor: Bt.ShadeColor,
	_RimColor: Bt.RimColor,
	_OutlineColor: Bt.OutlineColor
}, Ht = new D(), Ut = class e {
	constructor({ material: e, type: t, targetValue: n, targetAlpha: r }) {
		this.material = e, this.type = t, this.targetValue = n, this.targetAlpha = r ?? 1;
		let i = this._initColorBindState(), a = this._initAlphaBindState();
		this._state = {
			color: i,
			alpha: a
		};
	}
	applyWeight(e) {
		let { color: t, alpha: n } = this._state;
		if (t != null) {
			let { propertyName: n, deltaValue: r } = t;
			this.material[n]?.add(Ht.copy(r).multiplyScalar(e));
		}
		if (n != null) {
			let { propertyName: t, deltaValue: r } = n;
			this.material[t] != null && (this.material[t] += r * e);
		}
	}
	clearAppliedWeight() {
		let { color: e, alpha: t } = this._state;
		if (e != null) {
			let { propertyName: t, initialValue: n } = e;
			this.material[t]?.copy(n);
		}
		if (t != null) {
			let { propertyName: e, initialValue: n } = t;
			this.material[e] != null && (this.material[e] = n);
		}
	}
	_initColorBindState() {
		let { material: e, type: t, targetValue: n } = this, r = this._getPropertyNameMap()?.[t]?.[0] ?? null;
		if (r == null) return console.warn(`Tried to add a material color bind to the material ${e.name ?? "(no name)"}, the type ${t} but the material or the type is not supported.`), null;
		let i = e[r].clone();
		return {
			propertyName: r,
			initialValue: i,
			deltaValue: new D(n.r - i.r, n.g - i.g, n.b - i.b)
		};
	}
	_initAlphaBindState() {
		let { material: e, type: t, targetAlpha: n } = this, r = this._getPropertyNameMap()?.[t]?.[1] ?? null;
		if (r == null && n !== 1) return console.warn(`Tried to add a material alpha bind to the material ${e.name ?? "(no name)"}, the type ${t} but the material or the type does not support alpha.`), null;
		if (r == null) return null;
		let i = e[r];
		return {
			propertyName: r,
			initialValue: i,
			deltaValue: n - i
		};
	}
	_getPropertyNameMap() {
		return Object.entries(e._propertyNameMapMap).find(([e]) => this.material[e] === !0)?.[1] ?? null;
	}
};
Ut._propertyNameMapMap = {
	isMeshStandardMaterial: {
		color: ["color", "opacity"],
		emissionColor: ["emissive", null]
	},
	isMeshBasicMaterial: { color: ["color", "opacity"] },
	isMToonMaterial: {
		color: ["color", "opacity"],
		emissionColor: ["emissive", null],
		outlineColor: ["outlineColorFactor", null],
		matcapColor: ["matcapFactor", null],
		rimColor: ["parametricRimColorFactor", null],
		shadeColor: ["shadeColorFactor", null]
	}
};
var Wt = Ut, Gt = class {
	constructor({ primitives: e, index: t, weight: n }) {
		this.primitives = e, this.index = t, this.weight = n;
	}
	applyWeight(e) {
		this.primitives.forEach((t) => {
			t.morphTargetInfluences?.[this.index] != null && (t.morphTargetInfluences[this.index] += this.weight * e);
		});
	}
	clearAppliedWeight() {
		this.primitives.forEach((e) => {
			e.morphTargetInfluences?.[this.index] != null && (e.morphTargetInfluences[this.index] = 0);
		});
	}
}, Kt = new te(), qt = class e {
	constructor({ material: t, scale: n, offset: r }) {
		this.material = t, this.scale = n, this.offset = r;
		let i = Object.entries(e._propertyNamesMap).find(([e]) => t[e] === !0)?.[1];
		i == null ? (console.warn(`Tried to add a texture transform bind to the material ${t.name ?? "(no name)"} but the material is not supported.`), this._properties = []) : (this._properties = [], i.forEach((e) => {
			let i = t[e]?.clone();
			if (!i) return null;
			t[e] = i;
			let a = i.offset.clone(), o = i.repeat.clone(), s = r.clone().sub(a), c = n.clone().sub(o);
			this._properties.push({
				name: e,
				initialOffset: a,
				deltaOffset: s,
				initialScale: o,
				deltaScale: c
			});
		}));
	}
	applyWeight(e) {
		this._properties.forEach((t) => {
			let n = this.material[t.name];
			n !== void 0 && (n.offset.add(Kt.copy(t.deltaOffset).multiplyScalar(e)), n.repeat.add(Kt.copy(t.deltaScale).multiplyScalar(e)));
		});
	}
	clearAppliedWeight() {
		this._properties.forEach((e) => {
			let t = this.material[e.name];
			t !== void 0 && (t.offset.copy(e.initialOffset), t.repeat.copy(e.initialScale));
		});
	}
};
qt._propertyNamesMap = {
	isMeshStandardMaterial: [
		"map",
		"emissiveMap",
		"bumpMap",
		"normalMap",
		"displacementMap",
		"roughnessMap",
		"metalnessMap",
		"alphaMap"
	],
	isMeshBasicMaterial: [
		"map",
		"specularMap",
		"alphaMap"
	],
	isMToonMaterial: [
		"map",
		"normalMap",
		"emissiveMap",
		"shadeMultiplyTexture",
		"rimMultiplyTexture",
		"outlineWidthMultiplyTexture",
		"uvAnimationMaskTexture"
	]
};
var Jt = qt, Yt = /* @__PURE__ */ new Set(["1.0", "1.0-beta"]), Xt = class e {
	get name() {
		return "VRMExpressionLoaderPlugin";
	}
	constructor(e) {
		this.parser = e;
	}
	afterRoot(e) {
		return j(this, null, function* () {
			e.userData.vrmExpressionManager = yield this._import(e);
		});
	}
	_import(e) {
		return j(this, null, function* () {
			return (yield this._v1Import(e)) || (yield this._v0Import(e)) || null;
		});
	}
	_v1Import(e) {
		return j(this, null, function* () {
			let t = this.parser.json;
			if (t.extensionsUsed?.indexOf("VRMC_vrm") === -1) return null;
			let n = t.extensions?.VRMC_vrm;
			if (!n) return null;
			let r = n.specVersion;
			if (!Yt.has(r)) return console.warn(`VRMExpressionLoaderPlugin: Unknown VRMC_vrm specVersion "${r}"`), null;
			let i = n.expressions;
			if (!i) return null;
			let a = new Set(Object.values(Lt)), o = /* @__PURE__ */ new Map();
			i.preset != null && Object.entries(i.preset).forEach(([e, t]) => {
				t != null && (a.has(e) ? o.set(e, t) : console.warn(`VRMExpressionLoaderPlugin: Unknown preset name "${e}" detected. Ignoring the expression`));
			}), i.custom != null && Object.entries(i.custom).forEach(([e, t]) => {
				a.has(e) ? console.warn(`VRMExpressionLoaderPlugin: Custom expression cannot have preset name "${e}". Ignoring the expression`) : o.set(e, t);
			});
			let s = new zt();
			return yield Promise.all(Array.from(o.entries()).map((t) => j(this, [t], function* ([t, n]) {
				var r, i, a;
				let o = new Nt(t);
				if (e.scene.add(o), o.isBinary = n.isBinary ?? !1, o.overrideBlink = n.overrideBlink ?? "none", o.overrideLookAt = n.overrideLookAt ?? "none", o.overrideMouth = n.overrideMouth ?? "none", (r = n.morphTargetBinds) == null || r.forEach((t) => j(this, null, function* () {
					if (t.node === void 0 || t.index === void 0) return;
					let r = yield Ft(e, t.node), i = t.index;
					r.every((e) => Array.isArray(e.morphTargetInfluences) && i < e.morphTargetInfluences.length) ? o.addBind(new Gt({
						primitives: r,
						index: i,
						weight: t.weight ?? 1
					})) : console.warn(`VRMExpressionLoaderPlugin: ${n.name} attempts to index morph #${i} but not found.`);
				})), n.materialColorBinds || n.textureTransformBinds) {
					let t = [];
					e.scene.traverse((e) => {
						let n = e.material;
						n && (Array.isArray(n) ? t.push(...n) : t.push(n));
					}), (i = n.materialColorBinds) == null || i.forEach((e) => j(this, null, function* () {
						t.filter((t) => {
							let n = this.parser.associations.get(t)?.materials;
							return e.material === n;
						}).forEach((t) => {
							o.addBind(new Wt({
								material: t,
								type: e.type,
								targetValue: new D().fromArray(e.targetValue),
								targetAlpha: e.targetValue[3]
							}));
						});
					})), (a = n.textureTransformBinds) == null || a.forEach((e) => j(this, null, function* () {
						t.filter((t) => {
							let n = this.parser.associations.get(t)?.materials;
							return e.material === n;
						}).forEach((t) => {
							o.addBind(new Jt({
								material: t,
								offset: new te().fromArray(e.offset ?? [0, 0]),
								scale: new te().fromArray(e.scale ?? [1, 1])
							}));
						});
					}));
				}
				s.registerExpression(o);
			}))), s;
		});
	}
	_v0Import(t) {
		return j(this, null, function* () {
			let n = this.parser.json, r = n.extensions?.VRM;
			if (!r) return null;
			let i = r.blendShapeMaster;
			if (!i) return null;
			let a = new zt(), o = i.blendShapeGroups;
			if (!o) return a;
			let s = /* @__PURE__ */ new Set();
			return yield Promise.all(o.map((r) => j(this, null, function* () {
				let i = r.presetName, o = (i != null && e.v0v1PresetNameMap[i] || null) ?? r.name;
				if (o == null) {
					console.warn("VRMExpressionLoaderPlugin: One of custom expressions has no name. Ignoring the expression");
					return;
				}
				if (s.has(o)) {
					console.warn(`VRMExpressionLoaderPlugin: An expression preset ${i} has duplicated entries. Ignoring the expression`);
					return;
				}
				s.add(o);
				let c = new Nt(o);
				t.scene.add(c), c.isBinary = r.isBinary ?? !1, r.binds && r.binds.forEach((e) => j(this, null, function* () {
					var i;
					if (e.mesh === void 0 || e.index === void 0) return;
					let a = [];
					if ((i = n.nodes) == null || i.forEach((t, n) => {
						t.mesh === e.mesh && a.push(n);
					}), a.length === 0) {
						console.warn(`VRMExpressionLoaderPlugin: ${r.name} attempts to bind a morph target to the mesh #${e.mesh} but the mesh is not found or not used in the scene. Ignoring the bind.`);
						return;
					}
					let o = e.index;
					yield Promise.all(a.map((n) => j(this, null, function* () {
						let i = yield Ft(t, n);
						i.every((e) => Array.isArray(e.morphTargetInfluences) && o < e.morphTargetInfluences.length) ? c.addBind(new Gt({
							primitives: i,
							index: o,
							weight: .01 * (e.weight ?? 100)
						})) : console.warn(`VRMExpressionLoaderPlugin: ${r.name} attempts to index ${o}th morph but not found.`);
					})));
				}));
				let l = r.materialValues;
				l && l.length !== 0 && l.forEach((e) => {
					if (e.materialName === void 0 || e.propertyName === void 0 || e.targetValue === void 0) return;
					let n = [];
					t.scene.traverse((t) => {
						if (t.material) {
							let r = t.material;
							Array.isArray(r) ? n.push(...r.filter((t) => (t.name === e.materialName || t.name === e.materialName + " (Outline)") && n.indexOf(t) === -1)) : r.name === e.materialName && n.indexOf(r) === -1 && n.push(r);
						}
					});
					let r = e.propertyName;
					n.forEach((t) => {
						if (r === "_MainTex_ST") {
							let n = new te(e.targetValue[0], e.targetValue[1]), r = new te(e.targetValue[2], e.targetValue[3]);
							r.y = 1 - r.y - n.y, c.addBind(new Jt({
								material: t,
								scale: n,
								offset: r
							}));
							return;
						}
						let n = Vt[r];
						n ? c.addBind(new Wt({
							material: t,
							type: n,
							targetValue: new D().fromArray(e.targetValue),
							targetAlpha: e.targetValue[3]
						})) : console.warn(r + " is not supported");
					});
				}), a.registerExpression(c);
			}))), a;
		});
	}
};
Xt.v0v1PresetNameMap = {
	a: "aa",
	e: "ee",
	i: "ih",
	o: "oh",
	u: "ou",
	blink: "blink",
	joy: "happy",
	angry: "angry",
	sorrow: "sad",
	fun: "relaxed",
	lookup: "lookUp",
	lookdown: "lookDown",
	lookleft: "lookLeft",
	lookright: "lookRight",
	blink_l: "blinkLeft",
	blink_r: "blinkRight",
	neutral: "neutral"
};
var Zt = Xt, Qt = class e {
	constructor(t, n) {
		this._firstPersonOnlyLayer = e.DEFAULT_FIRSTPERSON_ONLY_LAYER, this._thirdPersonOnlyLayer = e.DEFAULT_THIRDPERSON_ONLY_LAYER, this._initializedLayers = !1, this.humanoid = t, this.meshAnnotations = n;
	}
	copy(e) {
		if (this.humanoid !== e.humanoid) throw Error("VRMFirstPerson: humanoid must be same in order to copy");
		return this.meshAnnotations = e.meshAnnotations.map((e) => ({
			meshes: e.meshes.concat(),
			type: e.type
		})), this;
	}
	clone() {
		return new e(this.humanoid, this.meshAnnotations).copy(this);
	}
	get firstPersonOnlyLayer() {
		return this._firstPersonOnlyLayer;
	}
	get thirdPersonOnlyLayer() {
		return this._thirdPersonOnlyLayer;
	}
	setup({ firstPersonOnlyLayer: t = e.DEFAULT_FIRSTPERSON_ONLY_LAYER, thirdPersonOnlyLayer: n = e.DEFAULT_THIRDPERSON_ONLY_LAYER } = {}) {
		this._initializedLayers ||= (this._firstPersonOnlyLayer = t, this._thirdPersonOnlyLayer = n, this.meshAnnotations.forEach((e) => {
			e.meshes.forEach((t) => {
				e.type === "firstPersonOnly" ? (t.layers.set(this._firstPersonOnlyLayer), t.traverse((e) => e.layers.set(this._firstPersonOnlyLayer))) : e.type === "thirdPersonOnly" ? (t.layers.set(this._thirdPersonOnlyLayer), t.traverse((e) => e.layers.set(this._thirdPersonOnlyLayer))) : e.type === "auto" && this._createHeadlessModel(t);
			});
		}), !0);
	}
	_excludeTriangles(e, t, n, r) {
		let i = 0;
		if (t != null && t.length > 0) for (let a = 0; a < e.length; a += 3) {
			let o = e[a], s = e[a + 1], c = e[a + 2], l = t[o], u = n[o];
			if (l[0] > 0 && r.includes(u[0]) || l[1] > 0 && r.includes(u[1]) || l[2] > 0 && r.includes(u[2]) || l[3] > 0 && r.includes(u[3])) continue;
			let d = t[s], f = n[s];
			if (d[0] > 0 && r.includes(f[0]) || d[1] > 0 && r.includes(f[1]) || d[2] > 0 && r.includes(f[2]) || d[3] > 0 && r.includes(f[3])) continue;
			let p = t[c], m = n[c];
			p[0] > 0 && r.includes(m[0]) || p[1] > 0 && r.includes(m[1]) || p[2] > 0 && r.includes(m[2]) || p[3] > 0 && r.includes(m[3]) || (e[i++] = o, e[i++] = s, e[i++] = c);
		}
		return i;
	}
	_createErasedMesh(e, t) {
		let n = new d(e.geometry.clone(), e.material);
		n.name = `${e.name}(erase)`, n.frustumCulled = e.frustumCulled, n.layers.set(this._firstPersonOnlyLayer);
		let r = n.geometry, i = r.getAttribute("skinIndex"), a = i instanceof c ? [] : i.array, o = [];
		for (let e = 0; e < a.length; e += 4) o.push([
			a[e],
			a[e + 1],
			a[e + 2],
			a[e + 3]
		]);
		let s = r.getAttribute("skinWeight"), l = s instanceof c ? [] : s.array, u = [];
		for (let e = 0; e < l.length; e += 4) u.push([
			l[e],
			l[e + 1],
			l[e + 2],
			l[e + 3]
		]);
		let f = r.getIndex();
		if (!f) throw Error("The geometry doesn't have an index buffer");
		let p = Array.from(f.array), m = this._excludeTriangles(p, u, o, t), h = [];
		for (let e = 0; e < m; e++) h[e] = p[e];
		return r.setIndex(h), e.onBeforeRender && (n.onBeforeRender = e.onBeforeRender), n.bind(new ae(e.skeleton.bones, e.skeleton.boneInverses), new C()), n;
	}
	_createHeadlessModelForSkinnedMesh(e, t) {
		let n = [];
		if (t.skeleton.bones.forEach((e, t) => {
			this._isEraseTarget(e) && n.push(t);
		}), !n.length) {
			t.layers.enable(this._thirdPersonOnlyLayer), t.layers.enable(this._firstPersonOnlyLayer);
			return;
		}
		t.layers.set(this._thirdPersonOnlyLayer);
		let r = this._createErasedMesh(t, n);
		e.add(r);
	}
	_createHeadlessModel(e) {
		if (e.type === "Group") {
			if (e.layers.set(this._thirdPersonOnlyLayer), this._isEraseTarget(e)) e.traverse((e) => e.layers.set(this._thirdPersonOnlyLayer));
			else {
				let t = new u();
				t.name = `_headless_${e.name}`, t.layers.set(this._firstPersonOnlyLayer), e.parent.add(t), e.children.filter((e) => e.type === "SkinnedMesh").forEach((e) => {
					let n = e;
					this._createHeadlessModelForSkinnedMesh(t, n);
				});
			}
		} else if (e.type === "SkinnedMesh") {
			let t = e;
			this._createHeadlessModelForSkinnedMesh(e.parent, t);
		} else this._isEraseTarget(e) && (e.layers.set(this._thirdPersonOnlyLayer), e.traverse((e) => e.layers.set(this._thirdPersonOnlyLayer)));
	}
	_isEraseTarget(e) {
		return e === this.humanoid.getRawBoneNode("head") ? !0 : e.parent ? this._isEraseTarget(e.parent) : !1;
	}
};
Qt.DEFAULT_FIRSTPERSON_ONLY_LAYER = 9, Qt.DEFAULT_THIRDPERSON_ONLY_LAYER = 10;
var $t = Qt, en = /* @__PURE__ */ new Set(["1.0", "1.0-beta"]), tn = class {
	get name() {
		return "VRMFirstPersonLoaderPlugin";
	}
	constructor(e) {
		this.parser = e;
	}
	afterRoot(e) {
		return j(this, null, function* () {
			let t = e.userData.vrmHumanoid;
			if (t !== null) {
				if (t === void 0) throw Error("VRMFirstPersonLoaderPlugin: vrmHumanoid is undefined. VRMHumanoidLoaderPlugin have to be used first");
				e.userData.vrmFirstPerson = yield this._import(e, t);
			}
		});
	}
	_import(e, t) {
		return j(this, null, function* () {
			return t == null ? null : (yield this._v1Import(e, t)) || (yield this._v0Import(e, t)) || null;
		});
	}
	_v1Import(e, t) {
		return j(this, null, function* () {
			let n = this.parser.json;
			if (n.extensionsUsed?.indexOf("VRMC_vrm") === -1) return null;
			let r = n.extensions?.VRMC_vrm;
			if (!r) return null;
			let i = r.specVersion;
			if (!en.has(i)) return console.warn(`VRMFirstPersonLoaderPlugin: Unknown VRMC_vrm specVersion "${i}"`), null;
			let a = r.firstPerson, o = [], s = yield It(e);
			return Array.from(s.entries()).forEach(([e, t]) => {
				let n = (a?.meshAnnotations)?.find((t) => t.node === e);
				o.push({
					meshes: t,
					type: n?.type ?? "auto"
				});
			}), new $t(t, o);
		});
	}
	_v0Import(e, t) {
		return j(this, null, function* () {
			let n = this.parser.json, r = n.extensions?.VRM;
			if (!r) return null;
			let i = r.firstPerson;
			if (!i) return null;
			let a = [], o = yield It(e);
			return Array.from(o.entries()).forEach(([e, t]) => {
				let r = n.nodes[e], o = i.meshAnnotations ? i.meshAnnotations.find((e) => e.mesh === r.mesh) : void 0;
				a.push({
					meshes: t,
					type: this._convertV0FlagToV1Type(o?.firstPersonFlag)
				});
			}), new $t(t, a);
		});
	}
	_convertV0FlagToV1Type(e) {
		return e === "FirstPersonOnly" ? "firstPersonOnly" : e === "ThirdPersonOnly" ? "thirdPersonOnly" : e === "Both" ? "both" : "auto";
	}
}, nn = new w(), rn = new w(), an = new b(), on = class extends u {
	constructor(e) {
		super(), this.vrmHumanoid = e, this._boneAxesMap = /* @__PURE__ */ new Map(), Object.values(e.humanBones).forEach((e) => {
			let t = new x(1);
			t.matrixAutoUpdate = !1, t.material.depthTest = !1, t.material.depthWrite = !1, this.add(t), this._boneAxesMap.set(e, t);
		});
	}
	dispose() {
		Array.from(this._boneAxesMap.values()).forEach((e) => {
			e.geometry.dispose(), e.material.dispose();
		});
	}
	updateMatrixWorld(e) {
		Array.from(this._boneAxesMap.entries()).forEach(([e, t]) => {
			e.node.updateWorldMatrix(!0, !1), e.node.matrixWorld.decompose(nn, an, rn);
			let n = nn.set(.1, .1, .1).divide(rn);
			t.matrix.copy(e.node.matrixWorld).scale(n);
		}), super.updateMatrixWorld(e);
	}
}, sn = /* @__PURE__ */ "hips.spine.chest.upperChest.neck.head.leftEye.rightEye.jaw.leftUpperLeg.leftLowerLeg.leftFoot.leftToes.rightUpperLeg.rightLowerLeg.rightFoot.rightToes.leftShoulder.leftUpperArm.leftLowerArm.leftHand.rightShoulder.rightUpperArm.rightLowerArm.rightHand.leftThumbMetacarpal.leftThumbProximal.leftThumbDistal.leftIndexProximal.leftIndexIntermediate.leftIndexDistal.leftMiddleProximal.leftMiddleIntermediate.leftMiddleDistal.leftRingProximal.leftRingIntermediate.leftRingDistal.leftLittleProximal.leftLittleIntermediate.leftLittleDistal.rightThumbMetacarpal.rightThumbProximal.rightThumbDistal.rightIndexProximal.rightIndexIntermediate.rightIndexDistal.rightMiddleProximal.rightMiddleIntermediate.rightMiddleDistal.rightRingProximal.rightRingIntermediate.rightRingDistal.rightLittleProximal.rightLittleIntermediate.rightLittleDistal".split("."), cn = {
	hips: null,
	spine: "hips",
	chest: "spine",
	upperChest: "chest",
	neck: "upperChest",
	head: "neck",
	leftEye: "head",
	rightEye: "head",
	jaw: "head",
	leftUpperLeg: "hips",
	leftLowerLeg: "leftUpperLeg",
	leftFoot: "leftLowerLeg",
	leftToes: "leftFoot",
	rightUpperLeg: "hips",
	rightLowerLeg: "rightUpperLeg",
	rightFoot: "rightLowerLeg",
	rightToes: "rightFoot",
	leftShoulder: "upperChest",
	leftUpperArm: "leftShoulder",
	leftLowerArm: "leftUpperArm",
	leftHand: "leftLowerArm",
	rightShoulder: "upperChest",
	rightUpperArm: "rightShoulder",
	rightLowerArm: "rightUpperArm",
	rightHand: "rightLowerArm",
	leftThumbMetacarpal: "leftHand",
	leftThumbProximal: "leftThumbMetacarpal",
	leftThumbDistal: "leftThumbProximal",
	leftIndexProximal: "leftHand",
	leftIndexIntermediate: "leftIndexProximal",
	leftIndexDistal: "leftIndexIntermediate",
	leftMiddleProximal: "leftHand",
	leftMiddleIntermediate: "leftMiddleProximal",
	leftMiddleDistal: "leftMiddleIntermediate",
	leftRingProximal: "leftHand",
	leftRingIntermediate: "leftRingProximal",
	leftRingDistal: "leftRingIntermediate",
	leftLittleProximal: "leftHand",
	leftLittleIntermediate: "leftLittleProximal",
	leftLittleDistal: "leftLittleIntermediate",
	rightThumbMetacarpal: "rightHand",
	rightThumbProximal: "rightThumbMetacarpal",
	rightThumbDistal: "rightThumbProximal",
	rightIndexProximal: "rightHand",
	rightIndexIntermediate: "rightIndexProximal",
	rightIndexDistal: "rightIndexIntermediate",
	rightMiddleProximal: "rightHand",
	rightMiddleIntermediate: "rightMiddleProximal",
	rightMiddleDistal: "rightMiddleIntermediate",
	rightRingProximal: "rightHand",
	rightRingIntermediate: "rightRingProximal",
	rightRingDistal: "rightRingIntermediate",
	rightLittleProximal: "rightHand",
	rightLittleIntermediate: "rightLittleProximal",
	rightLittleDistal: "rightLittleIntermediate"
};
function ln(e) {
	return e.invert ? e.invert() : e.inverse(), e;
}
var un = new w(), dn = new b(), fn = class {
	constructor(e) {
		this.humanBones = e, this.restPose = this.getAbsolutePose();
	}
	getAbsolutePose() {
		let e = {};
		return Object.keys(this.humanBones).forEach((t) => {
			let n = t, r = this.getBoneNode(n);
			r && (un.copy(r.position), dn.copy(r.quaternion), e[n] = {
				position: un.toArray(),
				rotation: dn.toArray()
			});
		}), e;
	}
	getPose() {
		let e = {};
		return Object.keys(this.humanBones).forEach((t) => {
			let n = t, r = this.getBoneNode(n);
			if (!r) return;
			un.set(0, 0, 0), dn.identity();
			let i = this.restPose[n];
			i?.position && un.fromArray(i.position).negate(), i?.rotation && ln(dn.fromArray(i.rotation)), un.add(r.position), dn.premultiply(r.quaternion), e[n] = {
				position: un.toArray(),
				rotation: dn.toArray()
			};
		}), e;
	}
	setPose(e) {
		Object.entries(e).forEach(([e, t]) => {
			let n = e, r = this.getBoneNode(n);
			if (!r) return;
			let i = this.restPose[n];
			i && (t?.position && (r.position.fromArray(t.position), i.position && r.position.add(un.fromArray(i.position))), t?.rotation && (r.quaternion.fromArray(t.rotation), i.rotation && r.quaternion.multiply(dn.fromArray(i.rotation))));
		});
	}
	resetPose() {
		Object.entries(this.restPose).forEach(([e, t]) => {
			let n = this.getBoneNode(e);
			n && (t?.position && n.position.fromArray(t.position), t?.rotation && n.quaternion.fromArray(t.rotation));
		});
	}
	getBone(e) {
		return this.humanBones[e] ?? void 0;
	}
	getBoneNode(e) {
		return this.humanBones[e]?.node ?? null;
	}
}, pn = new w(), mn = new b(), hn = new w(), gn = class e extends fn {
	static _setupTransforms(e) {
		let t = new m();
		t.name = "VRMHumanoidRig";
		let n = {}, r = {}, i = {}, a = {};
		sn.forEach((t) => {
			var o;
			let s = e.getBoneNode(t);
			if (s) {
				let e = new w(), c = new b();
				s.updateWorldMatrix(!0, !1), s.matrixWorld.decompose(e, c, pn), n[t] = e, r[t] = c, i[t] = s.quaternion.clone();
				let l = new b();
				(o = s.parent) == null || o.matrixWorld.decompose(pn, l, pn), a[t] = l;
			}
		});
		let o = {};
		return sn.forEach((r) => {
			let i = e.getBoneNode(r);
			if (i) {
				let e = n[r], a = r, s;
				for (; s == null && (a = cn[a], a != null);) s = n[a];
				let c = new m();
				c.name = "Normalized_" + i.name, (a ? o[a]?.node : t).add(c), c.position.copy(e), s && c.position.sub(s), o[r] = { node: c };
			}
		}), {
			rigBones: o,
			root: t,
			parentWorldRotations: a,
			boneRotations: i
		};
	}
	constructor(t) {
		let { rigBones: n, root: r, parentWorldRotations: i, boneRotations: a } = e._setupTransforms(t);
		super(n), this.original = t, this.root = r, this._parentWorldRotations = i, this._boneRotations = a;
	}
	update() {
		sn.forEach((e) => {
			let t = this.original.getBoneNode(e);
			if (t != null) {
				let n = this.getBoneNode(e), r = this._parentWorldRotations[e], i = mn.copy(r).invert(), a = this._boneRotations[e];
				if (t.quaternion.copy(n.quaternion).multiply(r).premultiply(i).multiply(a), e === "hips") {
					let e = n.getWorldPosition(hn);
					t.parent.updateWorldMatrix(!0, !1);
					let r = t.parent.matrixWorld, i = e.applyMatrix4(r.invert());
					t.position.copy(i);
				}
			}
		});
	}
}, _n = class e {
	get restPose() {
		return console.warn("VRMHumanoid: restPose is deprecated. Use either rawRestPose or normalizedRestPose instead."), this.rawRestPose;
	}
	get rawRestPose() {
		return this._rawHumanBones.restPose;
	}
	get normalizedRestPose() {
		return this._normalizedHumanBones.restPose;
	}
	get humanBones() {
		return this._rawHumanBones.humanBones;
	}
	get rawHumanBones() {
		return this._rawHumanBones.humanBones;
	}
	get normalizedHumanBones() {
		return this._normalizedHumanBones.humanBones;
	}
	get normalizedHumanBonesRoot() {
		return this._normalizedHumanBones.root;
	}
	constructor(e, t) {
		this.autoUpdateHumanBones = t?.autoUpdateHumanBones ?? !0, this._rawHumanBones = new fn(e), this._normalizedHumanBones = new gn(this._rawHumanBones);
	}
	copy(e) {
		return this.autoUpdateHumanBones = e.autoUpdateHumanBones, this._rawHumanBones = new fn(e.humanBones), this._normalizedHumanBones = new gn(this._rawHumanBones), this;
	}
	clone() {
		return new e(this.humanBones, { autoUpdateHumanBones: this.autoUpdateHumanBones }).copy(this);
	}
	getAbsolutePose() {
		return console.warn("VRMHumanoid: getAbsolutePose() is deprecated. Use either getRawAbsolutePose() or getNormalizedAbsolutePose() instead."), this.getRawAbsolutePose();
	}
	getRawAbsolutePose() {
		return this._rawHumanBones.getAbsolutePose();
	}
	getNormalizedAbsolutePose() {
		return this._normalizedHumanBones.getAbsolutePose();
	}
	getPose() {
		return console.warn("VRMHumanoid: getPose() is deprecated. Use either getRawPose() or getNormalizedPose() instead."), this.getRawPose();
	}
	getRawPose() {
		return this._rawHumanBones.getPose();
	}
	getNormalizedPose() {
		return this._normalizedHumanBones.getPose();
	}
	setPose(e) {
		return console.warn("VRMHumanoid: setPose() is deprecated. Use either setRawPose() or setNormalizedPose() instead."), this.setRawPose(e);
	}
	setRawPose(e) {
		return this._rawHumanBones.setPose(e);
	}
	setNormalizedPose(e) {
		return this._normalizedHumanBones.setPose(e);
	}
	resetPose() {
		return console.warn("VRMHumanoid: resetPose() is deprecated. Use either resetRawPose() or resetNormalizedPose() instead."), this.resetRawPose();
	}
	resetRawPose() {
		return this._rawHumanBones.resetPose();
	}
	resetNormalizedPose() {
		return this._normalizedHumanBones.resetPose();
	}
	getBone(e) {
		return console.warn("VRMHumanoid: getBone() is deprecated. Use either getRawBone() or getNormalizedBone() instead."), this.getRawBone(e);
	}
	getRawBone(e) {
		return this._rawHumanBones.getBone(e);
	}
	getNormalizedBone(e) {
		return this._normalizedHumanBones.getBone(e);
	}
	getBoneNode(e) {
		return console.warn("VRMHumanoid: getBoneNode() is deprecated. Use either getRawBoneNode() or getNormalizedBoneNode() instead."), this.getRawBoneNode(e);
	}
	getRawBoneNode(e) {
		return this._rawHumanBones.getBoneNode(e);
	}
	getNormalizedBoneNode(e) {
		return this._normalizedHumanBones.getBoneNode(e);
	}
	update() {
		this.autoUpdateHumanBones && this._normalizedHumanBones.update();
	}
}, vn = {
	Hips: "hips",
	Spine: "spine",
	Head: "head",
	LeftUpperLeg: "leftUpperLeg",
	LeftLowerLeg: "leftLowerLeg",
	LeftFoot: "leftFoot",
	RightUpperLeg: "rightUpperLeg",
	RightLowerLeg: "rightLowerLeg",
	RightFoot: "rightFoot",
	LeftUpperArm: "leftUpperArm",
	LeftLowerArm: "leftLowerArm",
	LeftHand: "leftHand",
	RightUpperArm: "rightUpperArm",
	RightLowerArm: "rightLowerArm",
	RightHand: "rightHand"
}, yn = /* @__PURE__ */ new Set(["1.0", "1.0-beta"]), bn = {
	leftThumbProximal: "leftThumbMetacarpal",
	leftThumbIntermediate: "leftThumbProximal",
	rightThumbProximal: "rightThumbMetacarpal",
	rightThumbIntermediate: "rightThumbProximal"
}, xn = class {
	get name() {
		return "VRMHumanoidLoaderPlugin";
	}
	constructor(e, t) {
		this.parser = e, this.helperRoot = t?.helperRoot, this.autoUpdateHumanBones = t?.autoUpdateHumanBones;
	}
	afterRoot(e) {
		return j(this, null, function* () {
			e.userData.vrmHumanoid = yield this._import(e);
		});
	}
	_import(e) {
		return j(this, null, function* () {
			return (yield this._v1Import(e)) || (yield this._v0Import(e)) || null;
		});
	}
	_v1Import(e) {
		return j(this, null, function* () {
			let t = this.parser.json;
			if (t.extensionsUsed?.indexOf("VRMC_vrm") === -1) return null;
			let n = t.extensions?.VRMC_vrm;
			if (!n) return null;
			let r = n.specVersion;
			if (!yn.has(r)) return console.warn(`VRMHumanoidLoaderPlugin: Unknown VRMC_vrm specVersion "${r}"`), null;
			let i = n.humanoid;
			if (!i) return null;
			let a = i.humanBones.leftThumbIntermediate != null || i.humanBones.rightThumbIntermediate != null, o = {};
			i.humanBones != null && (yield Promise.all(Object.entries(i.humanBones).map((e) => j(this, [e], function* ([e, t]) {
				let n = e, r = t.node;
				if (a) {
					let e = bn[n];
					e != null && (n = e);
				}
				let i = yield this.parser.getDependency("node", r);
				i == null ? console.warn(`A glTF node bound to the humanoid bone ${n} (index = ${r}) does not exist`) : o[n] = { node: i };
			}))));
			let s = new _n(this._ensureRequiredBonesExist(o), { autoUpdateHumanBones: this.autoUpdateHumanBones });
			if (e.scene.add(s.normalizedHumanBonesRoot), this.helperRoot) {
				let e = new on(s);
				this.helperRoot.add(e), e.renderOrder = this.helperRoot.renderOrder;
			}
			return s;
		});
	}
	_v0Import(e) {
		return j(this, null, function* () {
			let t = this.parser.json.extensions?.VRM;
			if (!t) return null;
			let n = t.humanoid;
			if (!n) return null;
			let r = {};
			n.humanBones != null && (yield Promise.all(n.humanBones.map((e) => j(this, null, function* () {
				let t = e.bone, n = e.node;
				if (t == null || n == null) return;
				if (n < 0) {
					console.warn(`A glTF node index for the humanoid bone ${t} is negative (${n}), ignoring this bone.`);
					return;
				}
				let i = yield this.parser.getDependency("node", n);
				if (i == null) {
					console.warn(`A glTF node bound to the humanoid bone ${t} (index = ${n}) does not exist`);
					return;
				}
				let a = bn[t] ?? t;
				r[a] == null ? r[a] = { node: i } : console.warn(`Multiple bone entries for ${a} detected (index = ${n}), ignoring duplicated entries.`);
			}))));
			let i = new _n(this._ensureRequiredBonesExist(r), { autoUpdateHumanBones: this.autoUpdateHumanBones });
			if (e.scene.add(i.normalizedHumanBonesRoot), this.helperRoot) {
				let e = new on(i);
				this.helperRoot.add(e), e.renderOrder = this.helperRoot.renderOrder;
			}
			return i;
		});
	}
	_ensureRequiredBonesExist(e) {
		let t = Object.values(vn).filter((t) => e[t] == null);
		if (t.length > 0) throw Error(`VRMHumanoidLoaderPlugin: These humanoid bones are required but not exist: ${t.join(", ")}`);
		return e;
	}
}, Sn = class extends ce {
	constructor() {
		super(), this._currentTheta = 0, this._currentRadius = 0, this.theta = 0, this.radius = 0, this._currentTheta = 0, this._currentRadius = 0, this._attrPos = new E(/* @__PURE__ */ new Float32Array(195), 3), this.setAttribute("position", this._attrPos), this._attrIndex = new E(/* @__PURE__ */ new Uint16Array(189), 1), this.setIndex(this._attrIndex), this._buildIndex(), this.update();
	}
	update() {
		let e = !1;
		this._currentTheta !== this.theta && (this._currentTheta = this.theta, e = !0), this._currentRadius !== this.radius && (this._currentRadius = this.radius, e = !0), e && this._buildPosition();
	}
	_buildPosition() {
		this._attrPos.setXYZ(0, 0, 0, 0);
		for (let e = 0; e < 64; e++) {
			let t = e / 63 * this._currentTheta;
			this._attrPos.setXYZ(e + 1, this._currentRadius * Math.sin(t), 0, this._currentRadius * Math.cos(t));
		}
		this._attrPos.needsUpdate = !0;
	}
	_buildIndex() {
		for (let e = 0; e < 63; e++) this._attrIndex.setXYZ(e * 3, 0, e + 1, e + 2);
		this._attrIndex.needsUpdate = !0;
	}
}, Cn = class extends ce {
	constructor() {
		super(), this.radius = 0, this._currentRadius = 0, this.tail = new w(), this._currentTail = new w(), this._attrPos = new E(/* @__PURE__ */ new Float32Array(294), 3), this.setAttribute("position", this._attrPos), this._attrIndex = new E(/* @__PURE__ */ new Uint16Array(194), 1), this.setIndex(this._attrIndex), this._buildIndex(), this.update();
	}
	update() {
		let e = !1;
		this._currentRadius !== this.radius && (this._currentRadius = this.radius, e = !0), this._currentTail.equals(this.tail) || (this._currentTail.copy(this.tail), e = !0), e && this._buildPosition();
	}
	_buildPosition() {
		for (let e = 0; e < 32; e++) {
			let t = e / 16 * Math.PI;
			this._attrPos.setXYZ(e, Math.cos(t), Math.sin(t), 0), this._attrPos.setXYZ(32 + e, 0, Math.cos(t), Math.sin(t)), this._attrPos.setXYZ(64 + e, Math.sin(t), 0, Math.cos(t));
		}
		this.scale(this._currentRadius, this._currentRadius, this._currentRadius), this.translate(this._currentTail.x, this._currentTail.y, this._currentTail.z), this._attrPos.setXYZ(96, 0, 0, 0), this._attrPos.setXYZ(97, this._currentTail.x, this._currentTail.y, this._currentTail.z), this._attrPos.needsUpdate = !0;
	}
	_buildIndex() {
		for (let e = 0; e < 32; e++) {
			let t = (e + 1) % 32;
			this._attrIndex.setXY(e * 2, e, t), this._attrIndex.setXY(64 + e * 2, 32 + e, 32 + t), this._attrIndex.setXY(128 + e * 2, 64 + e, 64 + t);
		}
		this._attrIndex.setXY(192, 96, 97), this._attrIndex.needsUpdate = !0;
	}
}, wn = new b(), Tn = new b(), En = new w(), Dn = new w(), On = Math.sqrt(2) / 2, kn = new b(0, 0, -On, On), An = new w(0, 1, 0), jn = class extends u {
	constructor(e) {
		super(), this.matrixAutoUpdate = !1, this.vrmLookAt = e;
		{
			let e = new Sn();
			e.radius = .5;
			let t = new g({
				color: 65280,
				transparent: !0,
				opacity: .5,
				side: 2,
				depthTest: !1,
				depthWrite: !1
			});
			this._meshPitch = new ue(e, t), this.add(this._meshPitch);
		}
		{
			let e = new Sn();
			e.radius = .5;
			let t = new g({
				color: 16711680,
				transparent: !0,
				opacity: .5,
				side: 2,
				depthTest: !1,
				depthWrite: !1
			});
			this._meshYaw = new ue(e, t), this.add(this._meshYaw);
		}
		{
			let e = new Cn();
			e.radius = .1;
			let t = new S({
				color: 16777215,
				depthTest: !1,
				depthWrite: !1
			});
			this._lineTarget = new oe(e, t), this._lineTarget.frustumCulled = !1, this.add(this._lineTarget);
		}
	}
	dispose() {
		this._meshYaw.geometry.dispose(), this._meshYaw.material.dispose(), this._meshPitch.geometry.dispose(), this._meshPitch.material.dispose(), this._lineTarget.geometry.dispose(), this._lineTarget.material.dispose();
	}
	updateMatrixWorld(e) {
		let t = le.DEG2RAD * this.vrmLookAt.yaw;
		this._meshYaw.geometry.theta = t, this._meshYaw.geometry.update();
		let n = le.DEG2RAD * this.vrmLookAt.pitch;
		this._meshPitch.geometry.theta = n, this._meshPitch.geometry.update(), this.vrmLookAt.getLookAtWorldPosition(En), this.vrmLookAt.getLookAtWorldQuaternion(wn), wn.multiply(this.vrmLookAt.getFaceFrontQuaternion(Tn)), this._meshYaw.position.copy(En), this._meshYaw.quaternion.copy(wn), this._meshPitch.position.copy(En), this._meshPitch.quaternion.copy(wn), this._meshPitch.quaternion.multiply(Tn.setFromAxisAngle(An, t)), this._meshPitch.quaternion.multiply(kn);
		let { target: r, autoUpdate: i } = this.vrmLookAt;
		r != null && i && (r.getWorldPosition(Dn).sub(En), this._lineTarget.geometry.tail.copy(Dn), this._lineTarget.geometry.update(), this._lineTarget.position.copy(En)), super.updateMatrixWorld(e);
	}
}, Mn = new w(), Nn = new w();
function Pn(e, t) {
	return e.matrixWorld.decompose(Mn, t, Nn), t;
}
function Fn(e) {
	return [Math.atan2(-e.z, e.x), Math.atan2(e.y, Math.sqrt(e.x * e.x + e.z * e.z))];
}
function In(e) {
	let t = Math.round(e / 2 / Math.PI);
	return e - 2 * Math.PI * t;
}
var Ln = new w(0, 0, 1), Rn = new w(), zn = new w(), Bn = new w(), Vn = new b(), Hn = new b(), Un = new b(), Wn = new b(), Gn = new p(), Kn = class e {
	constructor(e, t) {
		this.offsetFromHeadBone = new w(), this.autoUpdate = !0, this.faceFront = new w(0, 0, 1), this.humanoid = e, this.applier = t, this._yaw = 0, this._pitch = 0, this._needsUpdate = !0, this._restHeadWorldQuaternion = this.getLookAtWorldQuaternion(new b());
	}
	get yaw() {
		return this._yaw;
	}
	set yaw(e) {
		this._yaw = e, this._needsUpdate = !0;
	}
	get pitch() {
		return this._pitch;
	}
	set pitch(e) {
		this._pitch = e, this._needsUpdate = !0;
	}
	get euler() {
		return console.warn("VRMLookAt: euler is deprecated. use getEuler() instead."), this.getEuler(new p());
	}
	getEuler(e) {
		return e.set(le.DEG2RAD * this._pitch, le.DEG2RAD * this._yaw, 0, "YXZ");
	}
	copy(e) {
		if (this.humanoid !== e.humanoid) throw Error("VRMLookAt: humanoid must be same in order to copy");
		return this.offsetFromHeadBone.copy(e.offsetFromHeadBone), this.applier = e.applier, this.autoUpdate = e.autoUpdate, this.target = e.target, this.faceFront.copy(e.faceFront), this;
	}
	clone() {
		return new e(this.humanoid, this.applier).copy(this);
	}
	reset() {
		this._yaw = 0, this._pitch = 0, this._needsUpdate = !0;
	}
	getLookAtWorldPosition(e) {
		let t = this.humanoid.getRawBoneNode("head");
		return e.copy(this.offsetFromHeadBone).applyMatrix4(t.matrixWorld);
	}
	getLookAtWorldQuaternion(e) {
		return Pn(this.humanoid.getRawBoneNode("head"), e);
	}
	getFaceFrontQuaternion(e) {
		if (this.faceFront.distanceToSquared(Ln) < .01) return e.copy(this._restHeadWorldQuaternion).invert();
		let [t, n] = Fn(this.faceFront);
		return Gn.set(0, .5 * Math.PI + t, n, "YZX"), e.setFromEuler(Gn).premultiply(Wn.copy(this._restHeadWorldQuaternion).invert());
	}
	getLookAtWorldDirection(e) {
		return this.getLookAtWorldQuaternion(Hn), this.getFaceFrontQuaternion(Un), e.copy(Ln).applyQuaternion(Hn).applyQuaternion(Un).applyEuler(this.getEuler(Gn));
	}
	lookAt(e) {
		let t = Vn.copy(this._restHeadWorldQuaternion).multiply(ln(this.getLookAtWorldQuaternion(Hn))), n = this.getLookAtWorldPosition(zn), r = Bn.copy(e).sub(n).applyQuaternion(t).normalize(), [i, a] = Fn(this.faceFront), [o, s] = Fn(r), c = In(o - i), l = In(a - s);
		this._yaw = le.RAD2DEG * c, this._pitch = le.RAD2DEG * l, this._needsUpdate = !0;
	}
	update(e) {
		this.target != null && this.autoUpdate && this.lookAt(this.target.getWorldPosition(Rn)), this._needsUpdate && (this._needsUpdate = !1, this.applier.applyYawPitch(this._yaw, this._pitch));
	}
};
Kn.EULER_ORDER = "YXZ";
var qn = Kn, Jn = new w(0, 0, 1), Yn = new b(), Xn = new b(), Zn = new p(0, 0, 0, "YXZ"), Qn = class {
	constructor(e, t, n, r, i) {
		this.humanoid = e, this.rangeMapHorizontalInner = t, this.rangeMapHorizontalOuter = n, this.rangeMapVerticalDown = r, this.rangeMapVerticalUp = i, this.faceFront = new w(0, 0, 1), this._restQuatLeftEye = new b(), this._restQuatRightEye = new b(), this._restLeftEyeParentWorldQuat = new b(), this._restRightEyeParentWorldQuat = new b();
		let a = this.humanoid.getRawBoneNode("leftEye"), o = this.humanoid.getRawBoneNode("rightEye");
		a && (this._restQuatLeftEye.copy(a.quaternion), Pn(a.parent, this._restLeftEyeParentWorldQuat)), o && (this._restQuatRightEye.copy(o.quaternion), Pn(o.parent, this._restRightEyeParentWorldQuat));
	}
	applyYawPitch(e, t) {
		let n = this.humanoid.getRawBoneNode("leftEye"), r = this.humanoid.getRawBoneNode("rightEye"), i = this.humanoid.getNormalizedBoneNode("leftEye"), a = this.humanoid.getNormalizedBoneNode("rightEye");
		n && (Zn.x = t < 0 ? -le.DEG2RAD * this.rangeMapVerticalDown.map(-t) : le.DEG2RAD * this.rangeMapVerticalUp.map(t), Zn.y = e < 0 ? -le.DEG2RAD * this.rangeMapHorizontalInner.map(-e) : le.DEG2RAD * this.rangeMapHorizontalOuter.map(e), Yn.setFromEuler(Zn), this._getWorldFaceFrontQuat(Xn), i.quaternion.copy(Xn).multiply(Yn).multiply(Xn.invert()), Yn.copy(this._restLeftEyeParentWorldQuat), n.quaternion.copy(i.quaternion).multiply(Yn).premultiply(Yn.invert()).multiply(this._restQuatLeftEye)), r && (Zn.x = t < 0 ? -le.DEG2RAD * this.rangeMapVerticalDown.map(-t) : le.DEG2RAD * this.rangeMapVerticalUp.map(t), Zn.y = e < 0 ? -le.DEG2RAD * this.rangeMapHorizontalOuter.map(-e) : le.DEG2RAD * this.rangeMapHorizontalInner.map(e), Yn.setFromEuler(Zn), this._getWorldFaceFrontQuat(Xn), a.quaternion.copy(Xn).multiply(Yn).multiply(Xn.invert()), Yn.copy(this._restRightEyeParentWorldQuat), r.quaternion.copy(a.quaternion).multiply(Yn).premultiply(Yn.invert()).multiply(this._restQuatRightEye));
	}
	lookAt(e) {
		console.warn("VRMLookAtBoneApplier: lookAt() is deprecated. use apply() instead.");
		let t = le.RAD2DEG * e.y, n = le.RAD2DEG * e.x;
		this.applyYawPitch(t, n);
	}
	_getWorldFaceFrontQuat(e) {
		if (this.faceFront.distanceToSquared(Jn) < .01) return e.identity();
		let [t, n] = Fn(this.faceFront);
		return Zn.set(0, .5 * Math.PI + t, n, "YZX"), e.setFromEuler(Zn);
	}
};
Qn.type = "bone";
var $n = class {
	constructor(e, t, n, r, i) {
		this.expressions = e, this.rangeMapHorizontalInner = t, this.rangeMapHorizontalOuter = n, this.rangeMapVerticalDown = r, this.rangeMapVerticalUp = i;
	}
	applyYawPitch(e, t) {
		t < 0 ? (this.expressions.setValue("lookDown", 0), this.expressions.setValue("lookUp", this.rangeMapVerticalUp.map(-t))) : (this.expressions.setValue("lookUp", 0), this.expressions.setValue("lookDown", this.rangeMapVerticalDown.map(t))), e < 0 ? (this.expressions.setValue("lookLeft", 0), this.expressions.setValue("lookRight", this.rangeMapHorizontalOuter.map(-e))) : (this.expressions.setValue("lookRight", 0), this.expressions.setValue("lookLeft", this.rangeMapHorizontalOuter.map(e)));
	}
	lookAt(e) {
		console.warn("VRMLookAtBoneApplier: lookAt() is deprecated. use apply() instead.");
		let t = le.RAD2DEG * e.y, n = le.RAD2DEG * e.x;
		this.applyYawPitch(t, n);
	}
};
$n.type = "expression";
var er = class {
	constructor(e, t) {
		this.inputMaxValue = e, this.outputScale = t;
	}
	map(e) {
		return this.outputScale * Rt(e / this.inputMaxValue);
	}
}, tr = /* @__PURE__ */ new Set(["1.0", "1.0-beta"]), nr = .01, rr = class {
	get name() {
		return "VRMLookAtLoaderPlugin";
	}
	constructor(e, t) {
		this.parser = e, this.helperRoot = t?.helperRoot;
	}
	afterRoot(e) {
		return j(this, null, function* () {
			let t = e.userData.vrmHumanoid;
			if (t === null) return;
			if (t === void 0) throw Error("VRMLookAtLoaderPlugin: vrmHumanoid is undefined. VRMHumanoidLoaderPlugin have to be used first");
			let n = e.userData.vrmExpressionManager;
			if (n !== null) {
				if (n === void 0) throw Error("VRMLookAtLoaderPlugin: vrmExpressionManager is undefined. VRMExpressionLoaderPlugin have to be used first");
				e.userData.vrmLookAt = yield this._import(e, t, n);
			}
		});
	}
	_import(e, t, n) {
		return j(this, null, function* () {
			return t == null || n == null ? null : (yield this._v1Import(e, t, n)) || (yield this._v0Import(e, t, n)) || null;
		});
	}
	_v1Import(e, t, n) {
		return j(this, null, function* () {
			let e = this.parser.json;
			if (e.extensionsUsed?.indexOf("VRMC_vrm") === -1) return null;
			let r = e.extensions?.VRMC_vrm;
			if (!r) return null;
			let i = r.specVersion;
			if (!tr.has(i)) return console.warn(`VRMLookAtLoaderPlugin: Unknown VRMC_vrm specVersion "${i}"`), null;
			let a = r.lookAt;
			if (!a) return null;
			let o = a.type === "expression" ? 1 : 10, s = this._v1ImportRangeMap(a.rangeMapHorizontalInner, o), c = this._v1ImportRangeMap(a.rangeMapHorizontalOuter, o), l = this._v1ImportRangeMap(a.rangeMapVerticalDown, o), u = this._v1ImportRangeMap(a.rangeMapVerticalUp, o), d;
			d = a.type === "expression" ? new $n(n, s, c, l, u) : new Qn(t, s, c, l, u);
			let f = this._importLookAt(t, d);
			return f.offsetFromHeadBone.fromArray(a.offsetFromHeadBone ?? [
				0,
				.06,
				0
			]), f;
		});
	}
	_v1ImportRangeMap(e, t) {
		let n = e?.inputMaxValue ?? 90, r = e?.outputScale ?? t;
		return n < nr && (console.warn("VRMLookAtLoaderPlugin: inputMaxValue of a range map is too small. Consider reviewing the range map!"), n = nr), new er(n, r);
	}
	_v0Import(e, t, n) {
		return j(this, null, function* () {
			let e = this.parser.json.extensions?.VRM;
			if (!e) return null;
			let r = e.firstPerson;
			if (!r) return null;
			let i = r.lookAtTypeName === "BlendShape" ? 1 : 10, a = this._v0ImportDegreeMap(r.lookAtHorizontalInner, i), o = this._v0ImportDegreeMap(r.lookAtHorizontalOuter, i), s = this._v0ImportDegreeMap(r.lookAtVerticalDown, i), c = this._v0ImportDegreeMap(r.lookAtVerticalUp, i), l;
			l = r.lookAtTypeName === "BlendShape" ? new $n(n, a, o, s, c) : new Qn(t, a, o, s, c);
			let u = this._importLookAt(t, l);
			return r.firstPersonBoneOffset ? u.offsetFromHeadBone.set(r.firstPersonBoneOffset.x ?? 0, r.firstPersonBoneOffset.y ?? .06, -(r.firstPersonBoneOffset.z ?? 0)) : u.offsetFromHeadBone.set(0, .06, 0), u.faceFront.set(0, 0, -1), l instanceof Qn && l.faceFront.set(0, 0, -1), u;
		});
	}
	_v0ImportDegreeMap(e, t) {
		let n = e?.curve;
		JSON.stringify(n) !== "[0,0,0,1,1,1,1,0]" && console.warn("Curves of LookAtDegreeMap defined in VRM 0.0 are not supported");
		let r = e?.xRange ?? 90, i = e?.yRange ?? t;
		return r < nr && (console.warn("VRMLookAtLoaderPlugin: xRange of a degree map is too small. Consider reviewing the degree map!"), r = nr), new er(r, i);
	}
	_importLookAt(e, t) {
		let n = new qn(e, t);
		if (this.helperRoot) {
			let e = new jn(n);
			this.helperRoot.add(e), e.renderOrder = this.helperRoot.renderOrder;
		}
		return n;
	}
};
function ir(e, t) {
	return typeof e != "string" || e === "" ? "" : (/^https?:\/\//i.test(t) && /^\//.test(e) && (t = t.replace(/(^https?:\/\/[^/]+).*/i, "$1")), /^(https?:)?\/\//i.test(e) || /^data:.*,.*$/i.test(e) || /^blob:.*$/i.test(e) ? e : t + e);
}
var ar = /* @__PURE__ */ new Set(["1.0", "1.0-beta"]), or = class {
	get name() {
		return "VRMMetaLoaderPlugin";
	}
	constructor(e, t) {
		this.parser = e, this.needThumbnailImage = t?.needThumbnailImage ?? !1, this.acceptLicenseUrls = t?.acceptLicenseUrls ?? ["https://vrm.dev/licenses/1.0/"], this.acceptV0Meta = t?.acceptV0Meta ?? !0;
	}
	afterRoot(e) {
		return j(this, null, function* () {
			e.userData.vrmMeta = yield this._import(e);
		});
	}
	_import(e) {
		return j(this, null, function* () {
			return (yield this._v1Import(e)) ?? (yield this._v0Import(e)) ?? null;
		});
	}
	_v1Import(e) {
		return j(this, null, function* () {
			let e = this.parser.json;
			if (e.extensionsUsed?.indexOf("VRMC_vrm") === -1) return null;
			let t = e.extensions?.VRMC_vrm;
			if (t == null) return null;
			let n = t.specVersion;
			if (!ar.has(n)) return console.warn(`VRMMetaLoaderPlugin: Unknown VRMC_vrm specVersion "${n}"`), null;
			let r = t.meta;
			if (!r) return null;
			let i = r.licenseUrl;
			if (!new Set(this.acceptLicenseUrls).has(i)) throw Error(`VRMMetaLoaderPlugin: The license url "${i}" is not accepted`);
			let a;
			return this.needThumbnailImage && r.thumbnailImage != null && (a = (yield this._extractGLTFImage(r.thumbnailImage)) ?? void 0), {
				metaVersion: "1",
				name: r.name,
				version: r.version,
				authors: r.authors,
				copyrightInformation: r.copyrightInformation,
				contactInformation: r.contactInformation,
				references: r.references,
				thirdPartyLicenses: r.thirdPartyLicenses,
				thumbnailImage: a,
				licenseUrl: r.licenseUrl,
				avatarPermission: r.avatarPermission,
				allowExcessivelyViolentUsage: r.allowExcessivelyViolentUsage,
				allowExcessivelySexualUsage: r.allowExcessivelySexualUsage,
				commercialUsage: r.commercialUsage,
				allowPoliticalOrReligiousUsage: r.allowPoliticalOrReligiousUsage,
				allowAntisocialOrHateUsage: r.allowAntisocialOrHateUsage,
				creditNotation: r.creditNotation,
				allowRedistribution: r.allowRedistribution,
				modification: r.modification,
				otherLicenseUrl: r.otherLicenseUrl
			};
		});
	}
	_v0Import(e) {
		return j(this, null, function* () {
			let e = this.parser.json.extensions?.VRM;
			if (!e) return null;
			let t = e.meta;
			if (!t) return null;
			if (!this.acceptV0Meta) throw Error("VRMMetaLoaderPlugin: Attempted to load VRM0.0 meta but acceptV0Meta is false");
			let n;
			return this.needThumbnailImage && t.texture != null && t.texture !== -1 && (n = yield this.parser.getDependency("texture", t.texture)), {
				metaVersion: "0",
				allowedUserName: t.allowedUserName,
				author: t.author,
				commercialUssageName: t.commercialUssageName,
				contactInformation: t.contactInformation,
				licenseName: t.licenseName,
				otherLicenseUrl: t.otherLicenseUrl,
				otherPermissionUrl: t.otherPermissionUrl,
				reference: t.reference,
				sexualUssageName: t.sexualUssageName,
				texture: n ?? void 0,
				title: t.title,
				version: t.version,
				violentUssageName: t.violentUssageName
			};
		});
	}
	_extractGLTFImage(e) {
		return j(this, null, function* () {
			let t = this.parser.json.images?.[e];
			if (t == null) return console.warn(`VRMMetaLoaderPlugin: Attempt to use images[${e}] of glTF as a thumbnail but the image doesn't exist`), null;
			let n = t.uri;
			if (t.bufferView != null) {
				let e = yield this.parser.getDependency("bufferView", t.bufferView), r = new Blob([e], { type: t.mimeType });
				n = URL.createObjectURL(r);
			}
			return n == null ? (console.warn(`VRMMetaLoaderPlugin: Attempt to use images[${e}] of glTF as a thumbnail but the image couldn't load properly`), null) : yield new l().loadAsync(ir(n, this.parser.options.path)).catch((e) => (console.error(e), console.warn("VRMMetaLoaderPlugin: Failed to load a thumbnail image"), null));
		});
	}
}, sr = class {
	constructor(e) {
		this.scene = e.scene, this.meta = e.meta, this.humanoid = e.humanoid, this.expressionManager = e.expressionManager, this.firstPerson = e.firstPerson, this.lookAt = e.lookAt;
	}
	update(e) {
		this.humanoid.update(), this.lookAt && this.lookAt.update(e), this.expressionManager && this.expressionManager.update();
	}
}, cr = class extends sr {
	constructor(e) {
		super(e), this.materials = e.materials, this.springBoneManager = e.springBoneManager, this.nodeConstraintManager = e.nodeConstraintManager;
	}
	update(e) {
		super.update(e), this.nodeConstraintManager && this.nodeConstraintManager.update(), this.springBoneManager && this.springBoneManager.update(e), this.materials && this.materials.forEach((t) => {
			t.update && t.update(e);
		});
	}
}, lr = Object.defineProperty, ur = Object.getOwnPropertySymbols, dr = Object.prototype.hasOwnProperty, fr = Object.prototype.propertyIsEnumerable, pr = (e, t, n) => t in e ? lr(e, t, {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: n
}) : e[t] = n, mr = (e, t) => {
	for (var n in t ||= {}) dr.call(t, n) && pr(e, n, t[n]);
	if (ur) for (var n of ur(t)) fr.call(t, n) && pr(e, n, t[n]);
	return e;
}, hr = (e, t, n) => new Promise((r, i) => {
	var a = (e) => {
		try {
			s(n.next(e));
		} catch (e) {
			i(e);
		}
	}, o = (e) => {
		try {
			s(n.throw(e));
		} catch (e) {
			i(e);
		}
	}, s = (e) => e.done ? r(e.value) : Promise.resolve(e.value).then(a, o);
	s((n = n.apply(e, t)).next());
});
function gr(e, t) {
	e.colorSpace = t;
}
var _r = class {
	get pending() {
		return Promise.all(this._pendings);
	}
	constructor(e, t) {
		this._parser = e, this._materialParams = t, this._pendings = [];
	}
	assignPrimitive(e, t) {
		t != null && (this._materialParams[e] = t);
	}
	assignColor(e, t, n) {
		if (t != null) {
			let r = new D().fromArray(t);
			n && r.convertSRGBToLinear(), this._materialParams[e] = r;
		}
	}
	assignTexture(e, t, n) {
		return hr(this, null, function* () {
			let r = hr(this, null, function* () {
				if (t != null) {
					let r = yield this._parser.assignTexture(this._materialParams, e, t);
					if (r == null) {
						console.warn("GLTFMToonMaterialParamsAssignHelper: Failed to load texture. The rendering result may be wrong");
						return;
					}
					n && gr(r, "srgb");
				}
			});
			return this._pendings.push(r), r;
		});
	}
	assignTextureByIndex(e, t, n) {
		return hr(this, null, function* () {
			return this.assignTexture(e, t == null ? void 0 : { index: t }, n);
		});
	}
}, vr = "// #define PHONG\n\nvarying vec3 vViewPosition;\n\n#ifndef FLAT_SHADED\n  varying vec3 vNormal;\n#endif\n\n#include <common>\n\n// #include <uv_pars_vertex>\n#ifdef MTOON_USE_UV\n  varying vec2 vUv;\n\n  // COMPAT: pre-r151 uses a common uvTransform\n  #if THREE_VRM_THREE_REVISION < 151\n    uniform mat3 uvTransform;\n  #endif\n#endif\n\n// #include <uv2_pars_vertex>\n// COMAPT: pre-r151 uses uv2 for lightMap and aoMap\n#if THREE_VRM_THREE_REVISION < 151\n  #if defined( USE_LIGHTMAP ) || defined( USE_AOMAP )\n    attribute vec2 uv2;\n    varying vec2 vUv2;\n    uniform mat3 uv2Transform;\n  #endif\n#endif\n\n// #include <displacementmap_pars_vertex>\n// #include <envmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\n\n#ifdef USE_OUTLINEWIDTHMULTIPLYTEXTURE\n  uniform sampler2D outlineWidthMultiplyTexture;\n  uniform mat3 outlineWidthMultiplyTextureUvTransform;\n#endif\n\nuniform float outlineWidthFactor;\n\nvoid main() {\n\n  // #include <uv_vertex>\n  #ifdef MTOON_USE_UV\n    // COMPAT: pre-r151 uses a common uvTransform\n    #if THREE_VRM_THREE_REVISION >= 151\n      vUv = uv;\n    #else\n      vUv = ( uvTransform * vec3( uv, 1 ) ).xy;\n    #endif\n  #endif\n\n  // #include <uv2_vertex>\n  // COMAPT: pre-r151 uses uv2 for lightMap and aoMap\n  #if THREE_VRM_THREE_REVISION < 151\n    #if defined( USE_LIGHTMAP ) || defined( USE_AOMAP )\n      vUv2 = ( uv2Transform * vec3( uv2, 1 ) ).xy;\n    #endif\n  #endif\n\n  #include <color_vertex>\n\n  #include <beginnormal_vertex>\n  #include <morphnormal_vertex>\n  #include <skinbase_vertex>\n  #include <skinnormal_vertex>\n\n  // we need this to compute the outline properly\n  objectNormal = normalize( objectNormal );\n\n  #include <defaultnormal_vertex>\n\n  #ifndef FLAT_SHADED // Normal computed with derivatives when FLAT_SHADED\n    vNormal = normalize( transformedNormal );\n  #endif\n\n  #include <begin_vertex>\n\n  #include <morphtarget_vertex>\n  #include <skinning_vertex>\n  // #include <displacementmap_vertex>\n  #include <project_vertex>\n  #include <logdepthbuf_vertex>\n  #include <clipping_planes_vertex>\n\n  vViewPosition = - mvPosition.xyz;\n\n  #ifdef OUTLINE\n    float worldNormalLength = length( transformedNormal );\n    vec3 outlineOffset = outlineWidthFactor * worldNormalLength * objectNormal;\n\n    #ifdef USE_OUTLINEWIDTHMULTIPLYTEXTURE\n      vec2 outlineWidthMultiplyTextureUv = ( outlineWidthMultiplyTextureUvTransform * vec3( vUv, 1 ) ).xy;\n      float outlineTex = texture2D( outlineWidthMultiplyTexture, outlineWidthMultiplyTextureUv ).g;\n      outlineOffset *= outlineTex;\n    #endif\n\n    #ifdef OUTLINE_WIDTH_SCREEN\n      outlineOffset *= vViewPosition.z / projectionMatrix[ 1 ].y;\n    #endif\n\n    gl_Position = projectionMatrix * modelViewMatrix * vec4( outlineOffset + transformed, 1.0 );\n\n    gl_Position.z += 1E-6 * gl_Position.w; // anti-artifact magic\n  #endif\n\n  #include <worldpos_vertex>\n  // #include <envmap_vertex>\n  #include <shadowmap_vertex>\n  #include <fog_vertex>\n\n}", yr = "// #define PHONG\n\nuniform vec3 litFactor;\n\nuniform float opacity;\n\nuniform vec3 shadeColorFactor;\n#ifdef USE_SHADEMULTIPLYTEXTURE\n  uniform sampler2D shadeMultiplyTexture;\n  uniform mat3 shadeMultiplyTextureUvTransform;\n#endif\n\nuniform float shadingShiftFactor;\nuniform float shadingToonyFactor;\n\n#ifdef USE_SHADINGSHIFTTEXTURE\n  uniform sampler2D shadingShiftTexture;\n  uniform mat3 shadingShiftTextureUvTransform;\n  uniform float shadingShiftTextureScale;\n#endif\n\nuniform float giEqualizationFactor;\n\nuniform vec3 parametricRimColorFactor;\n#ifdef USE_RIMMULTIPLYTEXTURE\n  uniform sampler2D rimMultiplyTexture;\n  uniform mat3 rimMultiplyTextureUvTransform;\n#endif\nuniform float rimLightingMixFactor;\nuniform float parametricRimFresnelPowerFactor;\nuniform float parametricRimLiftFactor;\n\n#ifdef USE_MATCAPTEXTURE\n  uniform vec3 matcapFactor;\n  uniform sampler2D matcapTexture;\n  uniform mat3 matcapTextureUvTransform;\n#endif\n\nuniform vec3 emissive;\nuniform float emissiveIntensity;\n\nuniform vec3 outlineColorFactor;\nuniform float outlineLightingMixFactor;\n\n#ifdef USE_UVANIMATIONMASKTEXTURE\n  uniform sampler2D uvAnimationMaskTexture;\n  uniform mat3 uvAnimationMaskTextureUvTransform;\n#endif\n\nuniform float uvAnimationScrollXOffset;\nuniform float uvAnimationScrollYOffset;\nuniform float uvAnimationRotationPhase;\n\n#include <common>\n#include <packing>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n\n// #include <uv_pars_fragment>\n#if ( defined( MTOON_USE_UV ) && !defined( MTOON_UVS_VERTEX_ONLY ) )\n  varying vec2 vUv;\n#endif\n\n// #include <uv2_pars_fragment>\n// COMAPT: pre-r151 uses uv2 for lightMap and aoMap\n#if THREE_VRM_THREE_REVISION < 151\n  #if defined( USE_LIGHTMAP ) || defined( USE_AOMAP )\n    varying vec2 vUv2;\n  #endif\n#endif\n\n#include <map_pars_fragment>\n\n#ifdef USE_MAP\n  uniform mat3 mapUvTransform;\n#endif\n\n// #include <alphamap_pars_fragment>\n\n#include <alphatest_pars_fragment>\n\n#include <aomap_pars_fragment>\n// #include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n\n#ifdef USE_EMISSIVEMAP\n  uniform mat3 emissiveMapUvTransform;\n#endif\n\n// #include <envmap_common_pars_fragment>\n// #include <envmap_pars_fragment>\n// #include <cube_uv_reflection_fragment>\n#include <fog_pars_fragment>\n\n// #include <bsdfs>\n// COMPAT: pre-r151 doesn't have BRDF_Lambert in <common>\n#if THREE_VRM_THREE_REVISION < 151\n  vec3 BRDF_Lambert( const in vec3 diffuseColor ) {\n    return RECIPROCAL_PI * diffuseColor;\n  }\n#endif\n\n#include <lights_pars_begin>\n\n#include <normal_pars_fragment>\n\n// #include <lights_phong_pars_fragment>\nvarying vec3 vViewPosition;\n\nstruct MToonMaterial {\n  vec3 diffuseColor;\n  vec3 shadeColor;\n  float shadingShift;\n};\n\nfloat linearstep( float a, float b, float t ) {\n  return clamp( ( t - a ) / ( b - a ), 0.0, 1.0 );\n}\n\n/**\n * Convert NdotL into toon shading factor using shadingShift and shadingToony\n */\nfloat getShading(\n  const in float dotNL,\n  const in float shadow,\n  const in float shadingShift\n) {\n  float shading = dotNL;\n  shading = shading + shadingShift;\n  shading = linearstep( -1.0 + shadingToonyFactor, 1.0 - shadingToonyFactor, shading );\n  shading *= shadow;\n  return shading;\n}\n\n/**\n * Mix diffuseColor and shadeColor using shading factor and light color\n */\nvec3 getDiffuse(\n  const in MToonMaterial material,\n  const in float shading,\n  in vec3 lightColor\n) {\n  #ifdef DEBUG_LITSHADERATE\n    return vec3( BRDF_Lambert( shading * lightColor ) );\n  #endif\n\n  vec3 col = lightColor * BRDF_Lambert( mix( material.shadeColor, material.diffuseColor, shading ) );\n\n  // The \"comment out if you want to PBR absolutely\" line\n  #ifdef V0_COMPAT_SHADE\n    col = min( col, material.diffuseColor );\n  #endif\n\n  return col;\n}\n\n// COMPAT: pre-r156 uses a struct GeometricContext\n#if THREE_VRM_THREE_REVISION >= 157\n  void RE_Direct_MToon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in MToonMaterial material, const in float shadow, inout ReflectedLight reflectedLight ) {\n    float dotNL = clamp( dot( geometryNormal, directLight.direction ), -1.0, 1.0 );\n    vec3 irradiance = directLight.color;\n\n    // directSpecular will be used for rim lighting, not an actual specular\n    reflectedLight.directSpecular += irradiance;\n\n    irradiance *= dotNL;\n\n    float shading = getShading( dotNL, shadow, material.shadingShift );\n\n    // toon shaded diffuse\n    reflectedLight.directDiffuse += getDiffuse( material, shading, directLight.color );\n  }\n\n  void RE_IndirectDiffuse_MToon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in MToonMaterial material, inout ReflectedLight reflectedLight ) {\n    // indirect diffuse will use diffuseColor, no shadeColor involved\n    reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n\n    // directSpecular will be used for rim lighting, not an actual specular\n    reflectedLight.directSpecular += irradiance;\n  }\n#else\n  void RE_Direct_MToon( const in IncidentLight directLight, const in GeometricContext geometry, const in MToonMaterial material, const in float shadow, inout ReflectedLight reflectedLight ) {\n    float dotNL = clamp( dot( geometry.normal, directLight.direction ), -1.0, 1.0 );\n    vec3 irradiance = directLight.color;\n\n    // directSpecular will be used for rim lighting, not an actual specular\n    reflectedLight.directSpecular += irradiance;\n\n    irradiance *= dotNL;\n\n    float shading = getShading( dotNL, shadow, material.shadingShift );\n\n    // toon shaded diffuse\n    reflectedLight.directDiffuse += getDiffuse( material, shading, directLight.color );\n  }\n\n  void RE_IndirectDiffuse_MToon( const in vec3 irradiance, const in GeometricContext geometry, const in MToonMaterial material, inout ReflectedLight reflectedLight ) {\n    // indirect diffuse will use diffuseColor, no shadeColor involved\n    reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n\n    // directSpecular will be used for rim lighting, not an actual specular\n    reflectedLight.directSpecular += irradiance;\n  }\n#endif\n\n#define RE_Direct RE_Direct_MToon\n#define RE_IndirectDiffuse RE_IndirectDiffuse_MToon\n#define Material_LightProbeLOD( material ) (0)\n\n#include <shadowmap_pars_fragment>\n// #include <bumpmap_pars_fragment>\n\n// #include <normalmap_pars_fragment>\n#ifdef USE_NORMALMAP\n\n  uniform sampler2D normalMap;\n  uniform mat3 normalMapUvTransform;\n  uniform vec2 normalScale;\n\n#endif\n\n// COMPAT: pre-r151\n// USE_NORMALMAP_OBJECTSPACE used to be OBJECTSPACE_NORMALMAP in pre-r151\n#if defined( USE_NORMALMAP_OBJECTSPACE ) || defined( OBJECTSPACE_NORMALMAP )\n\n  uniform mat3 normalMatrix;\n\n#endif\n\n// COMPAT: pre-r151\n// USE_NORMALMAP_TANGENTSPACE used to be TANGENTSPACE_NORMALMAP in pre-r151\n#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( TANGENTSPACE_NORMALMAP ) )\n\n  // Per-Pixel Tangent Space Normal Mapping\n  // http://hacksoflife.blogspot.ch/2009/11/per-pixel-tangent-space-normal-mapping.html\n\n  // three-vrm specific change: it requires `uv` as an input in order to support uv scrolls\n\n  // Temporary compat against shader change @ Three.js r126, r151\n  #if THREE_VRM_THREE_REVISION >= 151\n\n    mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {\n\n      vec3 q0 = dFdx( eye_pos.xyz );\n      vec3 q1 = dFdy( eye_pos.xyz );\n      vec2 st0 = dFdx( uv.st );\n      vec2 st1 = dFdy( uv.st );\n\n      vec3 N = surf_norm;\n\n      vec3 q1perp = cross( q1, N );\n      vec3 q0perp = cross( N, q0 );\n\n      vec3 T = q1perp * st0.x + q0perp * st1.x;\n      vec3 B = q1perp * st0.y + q0perp * st1.y;\n\n      float det = max( dot( T, T ), dot( B, B ) );\n      float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );\n\n      return mat3( T * scale, B * scale, N );\n\n    }\n\n  #else\n\n    vec3 perturbNormal2Arb( vec2 uv, vec3 eye_pos, vec3 surf_norm, vec3 mapN, float faceDirection ) {\n\n      vec3 q0 = vec3( dFdx( eye_pos.x ), dFdx( eye_pos.y ), dFdx( eye_pos.z ) );\n      vec3 q1 = vec3( dFdy( eye_pos.x ), dFdy( eye_pos.y ), dFdy( eye_pos.z ) );\n      vec2 st0 = dFdx( uv.st );\n      vec2 st1 = dFdy( uv.st );\n\n      vec3 N = normalize( surf_norm );\n\n      vec3 q1perp = cross( q1, N );\n      vec3 q0perp = cross( N, q0 );\n\n      vec3 T = q1perp * st0.x + q0perp * st1.x;\n      vec3 B = q1perp * st0.y + q0perp * st1.y;\n\n      // three-vrm specific change: Workaround for the issue that happens when delta of uv = 0.0\n      // TODO: Is this still required? Or shall I make a PR about it?\n      if ( length( T ) == 0.0 || length( B ) == 0.0 ) {\n        return surf_norm;\n      }\n\n      float det = max( dot( T, T ), dot( B, B ) );\n      float scale = ( det == 0.0 ) ? 0.0 : faceDirection * inversesqrt( det );\n\n      return normalize( T * ( mapN.x * scale ) + B * ( mapN.y * scale ) + N * mapN.z );\n\n    }\n\n  #endif\n\n#endif\n\n// #include <specularmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\n\n// == post correction ==========================================================\nvoid postCorrection() {\n  #include <tonemapping_fragment>\n  #include <colorspace_fragment>\n  #include <fog_fragment>\n  #include <premultiplied_alpha_fragment>\n  #include <dithering_fragment>\n}\n\n// == main procedure ===========================================================\nvoid main() {\n  #include <clipping_planes_fragment>\n\n  vec2 uv = vec2(0.5, 0.5);\n\n  #if ( defined( MTOON_USE_UV ) && !defined( MTOON_UVS_VERTEX_ONLY ) )\n    uv = vUv;\n\n    float uvAnimMask = 1.0;\n    #ifdef USE_UVANIMATIONMASKTEXTURE\n      vec2 uvAnimationMaskTextureUv = ( uvAnimationMaskTextureUvTransform * vec3( uv, 1 ) ).xy;\n      uvAnimMask = texture2D( uvAnimationMaskTexture, uvAnimationMaskTextureUv ).b;\n    #endif\n\n    float uvRotCos = cos( uvAnimationRotationPhase * uvAnimMask );\n    float uvRotSin = sin( uvAnimationRotationPhase * uvAnimMask );\n    uv = mat2( uvRotCos, -uvRotSin, uvRotSin, uvRotCos ) * ( uv - 0.5 ) + 0.5;\n    uv = uv + vec2( uvAnimationScrollXOffset, uvAnimationScrollYOffset ) * uvAnimMask;\n  #endif\n\n  #ifdef DEBUG_UV\n    gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );\n    #if ( defined( MTOON_USE_UV ) && !defined( MTOON_UVS_VERTEX_ONLY ) )\n      gl_FragColor = vec4( uv, 0.0, 1.0 );\n    #endif\n    return;\n  #endif\n\n  vec4 diffuseColor = vec4( litFactor, opacity );\n  ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n  vec3 totalEmissiveRadiance = emissive * emissiveIntensity;\n\n  #include <logdepthbuf_fragment>\n\n  // #include <map_fragment>\n  #ifdef USE_MAP\n    vec2 mapUv = ( mapUvTransform * vec3( uv, 1 ) ).xy;\n    vec4 sampledDiffuseColor = texture2D( map, mapUv );\n    #ifdef DECODE_VIDEO_TEXTURE\n      sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );\n    #endif\n    diffuseColor *= sampledDiffuseColor;\n  #endif\n\n  // #include <color_fragment>\n  #if ( defined( USE_COLOR ) && !defined( IGNORE_VERTEX_COLOR ) )\n    diffuseColor.rgb *= vColor;\n  #endif\n\n  // #include <alphamap_fragment>\n\n  #include <alphatest_fragment>\n\n  // #include <specularmap_fragment>\n\n  // #include <normal_fragment_begin>\n  float faceDirection = gl_FrontFacing ? 1.0 : -1.0;\n\n  #ifdef FLAT_SHADED\n\n    vec3 fdx = dFdx( vViewPosition );\n    vec3 fdy = dFdy( vViewPosition );\n    vec3 normal = normalize( cross( fdx, fdy ) );\n\n  #else\n\n    vec3 normal = normalize( vNormal );\n\n    #ifdef DOUBLE_SIDED\n\n      normal *= faceDirection;\n\n    #endif\n\n  #endif\n\n  #ifdef USE_NORMALMAP\n\n    vec2 normalMapUv = ( normalMapUvTransform * vec3( uv, 1 ) ).xy;\n\n  #endif\n\n  #ifdef USE_NORMALMAP_TANGENTSPACE\n\n    #ifdef USE_TANGENT\n\n      mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );\n\n    #else\n\n      mat3 tbn = getTangentFrame( - vViewPosition, normal, normalMapUv );\n\n    #endif\n\n    #if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )\n\n      tbn[0] *= faceDirection;\n      tbn[1] *= faceDirection;\n\n    #endif\n\n  #endif\n\n  #ifdef USE_CLEARCOAT_NORMALMAP\n\n    #ifdef USE_TANGENT\n\n      mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );\n\n    #else\n\n      mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );\n\n    #endif\n\n    #if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )\n\n      tbn2[0] *= faceDirection;\n      tbn2[1] *= faceDirection;\n\n    #endif\n\n  #endif\n\n  // non perturbed normal for clearcoat among others\n\n  vec3 nonPerturbedNormal = normal;\n\n  #ifdef OUTLINE\n    normal *= -1.0;\n  #endif\n\n  // #include <normal_fragment_maps>\n\n  // COMPAT: pre-r151\n  // USE_NORMALMAP_OBJECTSPACE used to be OBJECTSPACE_NORMALMAP in pre-r151\n  #if defined( USE_NORMALMAP_OBJECTSPACE ) || defined( OBJECTSPACE_NORMALMAP )\n\n    normal = texture2D( normalMap, normalMapUv ).xyz * 2.0 - 1.0; // overrides both flatShading and attribute normals\n\n    #ifdef FLIP_SIDED\n\n      normal = - normal;\n\n    #endif\n\n    #ifdef DOUBLE_SIDED\n\n      normal = normal * faceDirection;\n\n    #endif\n\n    normal = normalize( normalMatrix * normal );\n\n  // COMPAT: pre-r151\n  // USE_NORMALMAP_TANGENTSPACE used to be TANGENTSPACE_NORMALMAP in pre-r151\n  #elif defined( USE_NORMALMAP_TANGENTSPACE ) || defined( TANGENTSPACE_NORMALMAP )\n\n    vec3 mapN = texture2D( normalMap, normalMapUv ).xyz * 2.0 - 1.0;\n    mapN.xy *= normalScale;\n\n    // COMPAT: pre-r151\n    #if THREE_VRM_THREE_REVISION >= 151 || defined( USE_TANGENT )\n\n      normal = normalize( tbn * mapN );\n\n    #else\n\n      normal = perturbNormal2Arb( uv, -vViewPosition, normal, mapN, faceDirection );\n\n    #endif\n\n  #endif\n\n  // #include <emissivemap_fragment>\n  #ifdef USE_EMISSIVEMAP\n    vec2 emissiveMapUv = ( emissiveMapUvTransform * vec3( uv, 1 ) ).xy;\n    totalEmissiveRadiance *= texture2D( emissiveMap, emissiveMapUv ).rgb;\n  #endif\n\n  #ifdef DEBUG_NORMAL\n    gl_FragColor = vec4( 0.5 + 0.5 * normal, 1.0 );\n    return;\n  #endif\n\n  // -- MToon: lighting --------------------------------------------------------\n  // accumulation\n  // #include <lights_phong_fragment>\n  MToonMaterial material;\n\n  material.diffuseColor = diffuseColor.rgb;\n\n  material.shadeColor = shadeColorFactor;\n  #ifdef USE_SHADEMULTIPLYTEXTURE\n    vec2 shadeMultiplyTextureUv = ( shadeMultiplyTextureUvTransform * vec3( uv, 1 ) ).xy;\n    material.shadeColor *= texture2D( shadeMultiplyTexture, shadeMultiplyTextureUv ).rgb;\n  #endif\n\n  #if ( defined( USE_COLOR ) && !defined( IGNORE_VERTEX_COLOR ) )\n    material.shadeColor.rgb *= vColor;\n  #endif\n\n  material.shadingShift = shadingShiftFactor;\n  #ifdef USE_SHADINGSHIFTTEXTURE\n    vec2 shadingShiftTextureUv = ( shadingShiftTextureUvTransform * vec3( uv, 1 ) ).xy;\n    material.shadingShift += texture2D( shadingShiftTexture, shadingShiftTextureUv ).r * shadingShiftTextureScale;\n  #endif\n\n  // #include <lights_fragment_begin>\n\n  // MToon Specific changes:\n  // Since we want to take shadows into account of shading instead of irradiance,\n  // we had to modify the codes that multiplies the results of shadowmap into color of direct lights.\n\n  // COMPAT: pre-r156 uses a struct GeometricContext\n  #if THREE_VRM_THREE_REVISION >= 157\n    vec3 geometryPosition = - vViewPosition;\n    vec3 geometryNormal = normal;\n    vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );\n\n    vec3 geometryClearcoatNormal;\n\n    #ifdef USE_CLEARCOAT\n\n      geometryClearcoatNormal = clearcoatNormal;\n\n    #endif\n  #else\n    GeometricContext geometry;\n\n    geometry.position = - vViewPosition;\n    geometry.normal = normal;\n    geometry.viewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );\n\n    #ifdef USE_CLEARCOAT\n\n      geometry.clearcoatNormal = clearcoatNormal;\n\n    #endif\n  #endif\n\n  IncidentLight directLight;\n\n  // since these variables will be used in unrolled loop, we have to define in prior\n  float shadow;\n\n  #if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )\n\n    PointLight pointLight;\n    #if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0\n    PointLightShadow pointLightShadow;\n    #endif\n\n    #pragma unroll_loop_start\n    for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {\n\n      pointLight = pointLights[ i ];\n\n      // COMPAT: pre-r156 uses a struct GeometricContext\n      #if THREE_VRM_THREE_REVISION >= 157\n        getPointLightInfo( pointLight, geometryPosition, directLight );\n      #else\n        getPointLightInfo( pointLight, geometry, directLight );\n      #endif\n\n      shadow = 1.0;\n      #if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )\n      pointLightShadow = pointLightShadows[ i ];\n      // COMPAT: pre-r166\n      // r166 introduced shadowIntensity\n      #if THREE_VRM_THREE_REVISION >= 166\n        shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;\n      #else\n        shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;\n      #endif\n      #endif\n\n      // COMPAT: pre-r156 uses a struct GeometricContext\n      #if THREE_VRM_THREE_REVISION >= 157\n        RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, shadow, reflectedLight );\n      #else\n        RE_Direct( directLight, geometry, material, shadow, reflectedLight );\n      #endif\n\n    }\n    #pragma unroll_loop_end\n\n  #endif\n\n  #if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )\n\n    SpotLight spotLight;\n    // COMPAT: pre-r144 uses NUM_SPOT_LIGHT_SHADOWS, r144+ uses NUM_SPOT_LIGHT_COORDS\n    #if THREE_VRM_THREE_REVISION >= 144\n      #if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_COORDS > 0\n      SpotLightShadow spotLightShadow;\n      #endif\n    #elif defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0\n    SpotLightShadow spotLightShadow;\n    #endif\n\n    #pragma unroll_loop_start\n    for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {\n\n      spotLight = spotLights[ i ];\n\n      // COMPAT: pre-r156 uses a struct GeometricContext\n      #if THREE_VRM_THREE_REVISION >= 157\n        getSpotLightInfo( spotLight, geometryPosition, directLight );\n      #else\n        getSpotLightInfo( spotLight, geometry, directLight );\n      #endif\n\n      shadow = 1.0;\n      // COMPAT: pre-r144 uses NUM_SPOT_LIGHT_SHADOWS and vSpotShadowCoord, r144+ uses NUM_SPOT_LIGHT_COORDS and vSpotLightCoord\n      // COMPAT: pre-r166 does not have shadowIntensity, r166+ has shadowIntensity\n      #if THREE_VRM_THREE_REVISION >= 166\n        #if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_COORDS )\n        spotLightShadow = spotLightShadows[ i ];\n        shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;\n        #endif\n      #elif THREE_VRM_THREE_REVISION >= 144\n        #if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_COORDS )\n        spotLightShadow = spotLightShadows[ i ];\n        shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;\n        #endif\n      #elif defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )\n      spotLightShadow = spotLightShadows[ i ];\n      shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotShadowCoord[ i ] ) : 1.0;\n      #endif\n\n      // COMPAT: pre-r156 uses a struct GeometricContext\n      #if THREE_VRM_THREE_REVISION >= 157\n        RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, shadow, reflectedLight );\n      #else\n        RE_Direct( directLight, geometry, material, shadow, reflectedLight );\n      #endif\n\n    }\n    #pragma unroll_loop_end\n\n  #endif\n\n  #if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )\n\n    DirectionalLight directionalLight;\n    #if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0\n    DirectionalLightShadow directionalLightShadow;\n    #endif\n\n    #pragma unroll_loop_start\n    for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {\n\n      directionalLight = directionalLights[ i ];\n\n      // COMPAT: pre-r156 uses a struct GeometricContext\n      #if THREE_VRM_THREE_REVISION >= 157\n        getDirectionalLightInfo( directionalLight, directLight );\n      #else\n        getDirectionalLightInfo( directionalLight, geometry, directLight );\n      #endif\n\n      shadow = 1.0;\n      #if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )\n      directionalLightShadow = directionalLightShadows[ i ];\n      // COMPAT: pre-r166\n      // r166 introduced shadowIntensity\n      #if THREE_VRM_THREE_REVISION >= 166\n        shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;\n      #else\n        shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;\n      #endif\n      #endif\n\n      // COMPAT: pre-r156 uses a struct GeometricContext\n      #if THREE_VRM_THREE_REVISION >= 157\n        RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, shadow, reflectedLight );\n      #else\n        RE_Direct( directLight, geometry, material, shadow, reflectedLight );\n      #endif\n\n    }\n    #pragma unroll_loop_end\n\n  #endif\n\n  // #if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )\n\n  //   RectAreaLight rectAreaLight;\n\n  //   #pragma unroll_loop_start\n  //   for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {\n\n  //     rectAreaLight = rectAreaLights[ i ];\n  //     RE_Direct_RectArea( rectAreaLight, geometry, material, reflectedLight );\n\n  //   }\n  //   #pragma unroll_loop_end\n\n  // #endif\n\n  #if defined( RE_IndirectDiffuse )\n\n    vec3 iblIrradiance = vec3( 0.0 );\n\n    vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );\n\n    // COMPAT: pre-r156 uses a struct GeometricContext\n    // COMPAT: pre-r156 doesn't have a define USE_LIGHT_PROBES\n    #if THREE_VRM_THREE_REVISION >= 157\n      #if defined( USE_LIGHT_PROBES )\n        irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );\n      #endif\n    #else\n      irradiance += getLightProbeIrradiance( lightProbe, geometry.normal );\n    #endif\n\n    #if ( NUM_HEMI_LIGHTS > 0 )\n\n      #pragma unroll_loop_start\n      for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {\n\n        // COMPAT: pre-r156 uses a struct GeometricContext\n        #if THREE_VRM_THREE_REVISION >= 157\n          irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );\n        #else\n          irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometry.normal );\n        #endif\n\n      }\n      #pragma unroll_loop_end\n\n    #endif\n\n  #endif\n\n  // #if defined( RE_IndirectSpecular )\n\n  //   vec3 radiance = vec3( 0.0 );\n  //   vec3 clearcoatRadiance = vec3( 0.0 );\n\n  // #endif\n\n  #include <lights_fragment_maps>\n  #include <lights_fragment_end>\n\n  // modulation\n  #include <aomap_fragment>\n\n  vec3 col = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;\n\n  #ifdef DEBUG_LITSHADERATE\n    gl_FragColor = vec4( col, diffuseColor.a );\n    postCorrection();\n    return;\n  #endif\n\n  // -- MToon: rim lighting -----------------------------------------\n  vec3 viewDir = normalize( vViewPosition );\n\n  #ifndef PHYSICALLY_CORRECT_LIGHTS\n    reflectedLight.directSpecular /= PI;\n  #endif\n  vec3 rimMix = mix( vec3( 1.0 ), reflectedLight.directSpecular, rimLightingMixFactor );\n\n  vec3 rim = parametricRimColorFactor * pow( saturate( 1.0 - dot( viewDir, normal ) + parametricRimLiftFactor ), parametricRimFresnelPowerFactor );\n\n  #ifdef USE_MATCAPTEXTURE\n    {\n      vec3 x = normalize( vec3( viewDir.z, 0.0, -viewDir.x ) );\n      vec3 y = cross( viewDir, x ); // guaranteed to be normalized\n      vec2 sphereUv = 0.5 + 0.5 * vec2( dot( x, normal ), -dot( y, normal ) );\n      sphereUv = ( matcapTextureUvTransform * vec3( sphereUv, 1 ) ).xy;\n      vec3 matcap = texture2D( matcapTexture, sphereUv ).rgb;\n      rim += matcapFactor * matcap;\n    }\n  #endif\n\n  #ifdef USE_RIMMULTIPLYTEXTURE\n    vec2 rimMultiplyTextureUv = ( rimMultiplyTextureUvTransform * vec3( uv, 1 ) ).xy;\n    rim *= texture2D( rimMultiplyTexture, rimMultiplyTextureUv ).rgb;\n  #endif\n\n  col += rimMix * rim;\n\n  // -- MToon: Emission --------------------------------------------------------\n  col += totalEmissiveRadiance;\n\n  // #include <envmap_fragment>\n\n  // -- Almost done! -----------------------------------------------------------\n  #if defined( OUTLINE )\n    col = outlineColorFactor.rgb * mix( vec3( 1.0 ), col, outlineLightingMixFactor );\n  #endif\n\n  #ifdef OPAQUE\n    diffuseColor.a = 1.0;\n  #endif\n\n  gl_FragColor = vec4( col, diffuseColor.a );\n  postCorrection();\n}\n", br = {
	None: "none",
	Normal: "normal",
	LitShadeRate: "litShadeRate",
	UV: "uv"
}, xr = {
	None: "none",
	WorldCoordinates: "worldCoordinates",
	ScreenCoordinates: "screenCoordinates"
};
function Sr(e) {
	return e.colorSpace;
}
var Cr = class extends y {
	constructor(e = {}) {
		super({
			vertexShader: vr,
			fragmentShader: yr
		}), this.uvAnimationScrollXSpeedFactor = 0, this.uvAnimationScrollYSpeedFactor = 0, this.uvAnimationRotationSpeedFactor = 0, this.fog = !0, this.normalMapType = 0, this._ignoreVertexColor = !0, this._v0CompatShade = !1, this._debugMode = br.None, this._outlineWidthMode = xr.None, this._isOutline = !1, e.transparentWithZWrite && (e.depthWrite = !0), delete e.transparentWithZWrite, e.fog = !0, e.lights = !0, e.clipping = !0, this.uniforms = ie.merge([
			fe.common,
			fe.normalmap,
			fe.emissivemap,
			fe.fog,
			fe.lights,
			{
				litFactor: { value: new D(1, 1, 1) },
				mapUvTransform: { value: new de() },
				colorAlpha: { value: 1 },
				normalMapUvTransform: { value: new de() },
				shadeColorFactor: { value: new D(0, 0, 0) },
				shadeMultiplyTexture: { value: null },
				shadeMultiplyTextureUvTransform: { value: new de() },
				shadingShiftFactor: { value: 0 },
				shadingShiftTexture: { value: null },
				shadingShiftTextureUvTransform: { value: new de() },
				shadingShiftTextureScale: { value: 1 },
				shadingToonyFactor: { value: .9 },
				giEqualizationFactor: { value: .9 },
				matcapFactor: { value: new D(1, 1, 1) },
				matcapTexture: { value: null },
				matcapTextureUvTransform: { value: new de() },
				parametricRimColorFactor: { value: new D(0, 0, 0) },
				rimMultiplyTexture: { value: null },
				rimMultiplyTextureUvTransform: { value: new de() },
				rimLightingMixFactor: { value: 1 },
				parametricRimFresnelPowerFactor: { value: 5 },
				parametricRimLiftFactor: { value: 0 },
				emissive: { value: new D(0, 0, 0) },
				emissiveIntensity: { value: 1 },
				emissiveMapUvTransform: { value: new de() },
				outlineWidthMultiplyTexture: { value: null },
				outlineWidthMultiplyTextureUvTransform: { value: new de() },
				outlineWidthFactor: { value: 0 },
				outlineColorFactor: { value: new D(0, 0, 0) },
				outlineLightingMixFactor: { value: 1 },
				uvAnimationMaskTexture: { value: null },
				uvAnimationMaskTextureUvTransform: { value: new de() },
				uvAnimationScrollXOffset: { value: 0 },
				uvAnimationScrollYOffset: { value: 0 },
				uvAnimationRotationPhase: { value: 0 }
			},
			e.uniforms ?? {}
		]), this.setValues(e), this._uploadUniformsWorkaround(), this.customProgramCacheKey = () => [
			...Object.entries(this._generateDefines()).map(([e, t]) => `${e}:${t}`),
			this.matcapTexture ? `matcapTextureColorSpace:${Sr(this.matcapTexture)}` : "",
			this.shadeMultiplyTexture ? `shadeMultiplyTextureColorSpace:${Sr(this.shadeMultiplyTexture)}` : "",
			this.rimMultiplyTexture ? `rimMultiplyTextureColorSpace:${Sr(this.rimMultiplyTexture)}` : ""
		].join(","), this.onBeforeCompile = (e) => {
			let t = Object.entries(mr(mr({}, this._generateDefines()), this.defines)).filter(([e, t]) => !!t).map(([e, t]) => `#define ${e} ${t}`).join("\n") + "\n";
			e.vertexShader = t + e.vertexShader, e.fragmentShader = t + e.fragmentShader;
		};
	}
	get color() {
		return this.uniforms.litFactor.value;
	}
	set color(e) {
		this.uniforms.litFactor.value = e;
	}
	get map() {
		return this.uniforms.map.value;
	}
	set map(e) {
		this.uniforms.map.value = e;
	}
	get normalMap() {
		return this.uniforms.normalMap.value;
	}
	set normalMap(e) {
		this.uniforms.normalMap.value = e;
	}
	get normalScale() {
		return this.uniforms.normalScale.value;
	}
	set normalScale(e) {
		this.uniforms.normalScale.value = e;
	}
	get emissive() {
		return this.uniforms.emissive.value;
	}
	set emissive(e) {
		this.uniforms.emissive.value = e;
	}
	get emissiveIntensity() {
		return this.uniforms.emissiveIntensity.value;
	}
	set emissiveIntensity(e) {
		this.uniforms.emissiveIntensity.value = e;
	}
	get emissiveMap() {
		return this.uniforms.emissiveMap.value;
	}
	set emissiveMap(e) {
		this.uniforms.emissiveMap.value = e;
	}
	get shadeColorFactor() {
		return this.uniforms.shadeColorFactor.value;
	}
	set shadeColorFactor(e) {
		this.uniforms.shadeColorFactor.value = e;
	}
	get shadeMultiplyTexture() {
		return this.uniforms.shadeMultiplyTexture.value;
	}
	set shadeMultiplyTexture(e) {
		this.uniforms.shadeMultiplyTexture.value = e;
	}
	get shadingShiftFactor() {
		return this.uniforms.shadingShiftFactor.value;
	}
	set shadingShiftFactor(e) {
		this.uniforms.shadingShiftFactor.value = e;
	}
	get shadingShiftTexture() {
		return this.uniforms.shadingShiftTexture.value;
	}
	set shadingShiftTexture(e) {
		this.uniforms.shadingShiftTexture.value = e;
	}
	get shadingShiftTextureScale() {
		return this.uniforms.shadingShiftTextureScale.value;
	}
	set shadingShiftTextureScale(e) {
		this.uniforms.shadingShiftTextureScale.value = e;
	}
	get shadingToonyFactor() {
		return this.uniforms.shadingToonyFactor.value;
	}
	set shadingToonyFactor(e) {
		this.uniforms.shadingToonyFactor.value = e;
	}
	get giEqualizationFactor() {
		return this.uniforms.giEqualizationFactor.value;
	}
	set giEqualizationFactor(e) {
		this.uniforms.giEqualizationFactor.value = e;
	}
	get matcapFactor() {
		return this.uniforms.matcapFactor.value;
	}
	set matcapFactor(e) {
		this.uniforms.matcapFactor.value = e;
	}
	get matcapTexture() {
		return this.uniforms.matcapTexture.value;
	}
	set matcapTexture(e) {
		this.uniforms.matcapTexture.value = e;
	}
	get parametricRimColorFactor() {
		return this.uniforms.parametricRimColorFactor.value;
	}
	set parametricRimColorFactor(e) {
		this.uniforms.parametricRimColorFactor.value = e;
	}
	get rimMultiplyTexture() {
		return this.uniforms.rimMultiplyTexture.value;
	}
	set rimMultiplyTexture(e) {
		this.uniforms.rimMultiplyTexture.value = e;
	}
	get rimLightingMixFactor() {
		return this.uniforms.rimLightingMixFactor.value;
	}
	set rimLightingMixFactor(e) {
		this.uniforms.rimLightingMixFactor.value = e;
	}
	get parametricRimFresnelPowerFactor() {
		return this.uniforms.parametricRimFresnelPowerFactor.value;
	}
	set parametricRimFresnelPowerFactor(e) {
		this.uniforms.parametricRimFresnelPowerFactor.value = e;
	}
	get parametricRimLiftFactor() {
		return this.uniforms.parametricRimLiftFactor.value;
	}
	set parametricRimLiftFactor(e) {
		this.uniforms.parametricRimLiftFactor.value = e;
	}
	get outlineWidthMultiplyTexture() {
		return this.uniforms.outlineWidthMultiplyTexture.value;
	}
	set outlineWidthMultiplyTexture(e) {
		this.uniforms.outlineWidthMultiplyTexture.value = e;
	}
	get outlineWidthFactor() {
		return this.uniforms.outlineWidthFactor.value;
	}
	set outlineWidthFactor(e) {
		this.uniforms.outlineWidthFactor.value = e;
	}
	get outlineColorFactor() {
		return this.uniforms.outlineColorFactor.value;
	}
	set outlineColorFactor(e) {
		this.uniforms.outlineColorFactor.value = e;
	}
	get outlineLightingMixFactor() {
		return this.uniforms.outlineLightingMixFactor.value;
	}
	set outlineLightingMixFactor(e) {
		this.uniforms.outlineLightingMixFactor.value = e;
	}
	get uvAnimationMaskTexture() {
		return this.uniforms.uvAnimationMaskTexture.value;
	}
	set uvAnimationMaskTexture(e) {
		this.uniforms.uvAnimationMaskTexture.value = e;
	}
	get uvAnimationScrollXOffset() {
		return this.uniforms.uvAnimationScrollXOffset.value;
	}
	set uvAnimationScrollXOffset(e) {
		this.uniforms.uvAnimationScrollXOffset.value = e;
	}
	get uvAnimationScrollYOffset() {
		return this.uniforms.uvAnimationScrollYOffset.value;
	}
	set uvAnimationScrollYOffset(e) {
		this.uniforms.uvAnimationScrollYOffset.value = e;
	}
	get uvAnimationRotationPhase() {
		return this.uniforms.uvAnimationRotationPhase.value;
	}
	set uvAnimationRotationPhase(e) {
		this.uniforms.uvAnimationRotationPhase.value = e;
	}
	get ignoreVertexColor() {
		return this._ignoreVertexColor;
	}
	set ignoreVertexColor(e) {
		this._ignoreVertexColor = e, this.needsUpdate = !0;
	}
	get v0CompatShade() {
		return this._v0CompatShade;
	}
	set v0CompatShade(e) {
		this._v0CompatShade = e, this.needsUpdate = !0;
	}
	get debugMode() {
		return this._debugMode;
	}
	set debugMode(e) {
		this._debugMode = e, this.needsUpdate = !0;
	}
	get outlineWidthMode() {
		return this._outlineWidthMode;
	}
	set outlineWidthMode(e) {
		this._outlineWidthMode = e, this.needsUpdate = !0;
	}
	get isOutline() {
		return this._isOutline;
	}
	set isOutline(e) {
		this._isOutline = e, this.needsUpdate = !0;
	}
	get isMToonMaterial() {
		return !0;
	}
	update(e) {
		this._uploadUniformsWorkaround(), this._updateUVAnimation(e);
	}
	copy(e) {
		return super.copy(e), this.map = e.map, this.normalMap = e.normalMap, this.emissiveMap = e.emissiveMap, this.shadeMultiplyTexture = e.shadeMultiplyTexture, this.shadingShiftTexture = e.shadingShiftTexture, this.matcapTexture = e.matcapTexture, this.rimMultiplyTexture = e.rimMultiplyTexture, this.outlineWidthMultiplyTexture = e.outlineWidthMultiplyTexture, this.uvAnimationMaskTexture = e.uvAnimationMaskTexture, this.normalMapType = e.normalMapType, this.uvAnimationScrollXSpeedFactor = e.uvAnimationScrollXSpeedFactor, this.uvAnimationScrollYSpeedFactor = e.uvAnimationScrollYSpeedFactor, this.uvAnimationRotationSpeedFactor = e.uvAnimationRotationSpeedFactor, this.ignoreVertexColor = e.ignoreVertexColor, this.v0CompatShade = e.v0CompatShade, this.debugMode = e.debugMode, this.outlineWidthMode = e.outlineWidthMode, this.isOutline = e.isOutline, this.needsUpdate = !0, this;
	}
	_updateUVAnimation(e) {
		this.uniforms.uvAnimationScrollXOffset.value += e * this.uvAnimationScrollXSpeedFactor, this.uniforms.uvAnimationScrollYOffset.value += e * this.uvAnimationScrollYSpeedFactor, this.uniforms.uvAnimationRotationPhase.value += e * this.uvAnimationRotationSpeedFactor, this.uniforms.alphaTest.value = this.alphaTest, this.uniformsNeedUpdate = !0;
	}
	_uploadUniformsWorkaround() {
		this.uniforms.opacity.value = this.opacity, this._updateTextureMatrix(this.uniforms.map, this.uniforms.mapUvTransform), this._updateTextureMatrix(this.uniforms.normalMap, this.uniforms.normalMapUvTransform), this._updateTextureMatrix(this.uniforms.emissiveMap, this.uniforms.emissiveMapUvTransform), this._updateTextureMatrix(this.uniforms.shadeMultiplyTexture, this.uniforms.shadeMultiplyTextureUvTransform), this._updateTextureMatrix(this.uniforms.shadingShiftTexture, this.uniforms.shadingShiftTextureUvTransform), this._updateTextureMatrix(this.uniforms.matcapTexture, this.uniforms.matcapTextureUvTransform), this._updateTextureMatrix(this.uniforms.rimMultiplyTexture, this.uniforms.rimMultiplyTextureUvTransform), this._updateTextureMatrix(this.uniforms.outlineWidthMultiplyTexture, this.uniforms.outlineWidthMultiplyTextureUvTransform), this._updateTextureMatrix(this.uniforms.uvAnimationMaskTexture, this.uniforms.uvAnimationMaskTextureUvTransform), this.uniformsNeedUpdate = !0;
	}
	_generateDefines() {
		let e = this.outlineWidthMultiplyTexture !== null, t = this.map !== null || this.normalMap !== null || this.emissiveMap !== null || this.shadeMultiplyTexture !== null || this.shadingShiftTexture !== null || this.rimMultiplyTexture !== null || this.uvAnimationMaskTexture !== null;
		return {
			THREE_VRM_THREE_REVISION: 186,
			OUTLINE: this._isOutline,
			MTOON_USE_UV: e || t,
			MTOON_UVS_VERTEX_ONLY: e && !t,
			V0_COMPAT_SHADE: this._v0CompatShade,
			USE_SHADEMULTIPLYTEXTURE: this.shadeMultiplyTexture !== null,
			USE_SHADINGSHIFTTEXTURE: this.shadingShiftTexture !== null,
			USE_MATCAPTEXTURE: this.matcapTexture !== null,
			USE_RIMMULTIPLYTEXTURE: this.rimMultiplyTexture !== null,
			USE_OUTLINEWIDTHMULTIPLYTEXTURE: this._isOutline && this.outlineWidthMultiplyTexture !== null,
			USE_UVANIMATIONMASKTEXTURE: this.uvAnimationMaskTexture !== null,
			IGNORE_VERTEX_COLOR: this._ignoreVertexColor === !0,
			DEBUG_NORMAL: this._debugMode === "normal",
			DEBUG_LITSHADERATE: this._debugMode === "litShadeRate",
			DEBUG_UV: this._debugMode === "uv",
			OUTLINE_WIDTH_SCREEN: this._isOutline && this._outlineWidthMode === xr.ScreenCoordinates
		};
	}
	_updateTextureMatrix(e, t) {
		e.value && (e.value.matrixAutoUpdate && e.value.updateMatrix(), t.value.copy(e.value.matrix));
	}
}, wr = /* @__PURE__ */ new Set(["1.0", "1.0-beta"]), Tr = class e {
	get name() {
		return e.EXTENSION_NAME;
	}
	constructor(e, t = {}) {
		this.parser = e, this.materialType = t.materialType ?? Cr, this.renderOrderOffset = t.renderOrderOffset ?? 0, this.v0CompatShade = t.v0CompatShade ?? !1, this.debugMode = t.debugMode ?? "none", this._mToonMaterialSet = /* @__PURE__ */ new Set();
	}
	beforeRoot() {
		return hr(this, null, function* () {
			this._removeUnlitExtensionIfMToonExists();
		});
	}
	afterRoot(e) {
		return hr(this, null, function* () {
			e.userData.vrmMToonMaterials = Array.from(this._mToonMaterialSet);
		});
	}
	getMaterialType(e) {
		return this._getMToonExtension(e) ? this.materialType : null;
	}
	extendMaterialParams(e, t) {
		let n = this._getMToonExtension(e);
		return n ? this._extendMaterialParams(n, t) : null;
	}
	loadMesh(e) {
		return hr(this, null, function* () {
			let t = this.parser, n = t.json.meshes?.[e];
			if (n == null) throw Error(`MToonMaterialLoaderPlugin: Attempt to use meshes[${e}] of glTF but the mesh doesn't exist`);
			let r = n.primitives, i = yield t.loadMesh(e);
			if (r.length === 1) {
				let e = i, t = r[0].material;
				t != null && this._setupPrimitive(e, t);
			} else {
				let e = i;
				for (let t = 0; t < r.length; t++) {
					let n = e.children[t], i = r[t].material;
					i != null && this._setupPrimitive(n, i);
				}
			}
			return i;
		});
	}
	_removeUnlitExtensionIfMToonExists() {
		this.parser.json.materials?.map((e, t) => {
			this._getMToonExtension(t) && e.extensions?.KHR_materials_unlit && delete e.extensions.KHR_materials_unlit;
		});
	}
	_getMToonExtension(t) {
		let n = this.parser.json.materials?.[t];
		if (n == null) {
			console.warn(`MToonMaterialLoaderPlugin: Attempt to use materials[${t}] of glTF but the material doesn't exist`);
			return;
		}
		let r = n.extensions?.[e.EXTENSION_NAME];
		if (r == null) return;
		let i = r.specVersion;
		if (!wr.has(i)) console.warn(`MToonMaterialLoaderPlugin: Unknown ${e.EXTENSION_NAME} specVersion "${i}"`);
		else return r;
	}
	_extendMaterialParams(e, t) {
		return hr(this, null, function* () {
			delete t.metalness, delete t.roughness;
			let n = new _r(this.parser, t);
			n.assignPrimitive("transparentWithZWrite", e.transparentWithZWrite), n.assignColor("shadeColorFactor", e.shadeColorFactor), n.assignTexture("shadeMultiplyTexture", e.shadeMultiplyTexture, !0), n.assignPrimitive("shadingShiftFactor", e.shadingShiftFactor), n.assignTexture("shadingShiftTexture", e.shadingShiftTexture, !0), n.assignPrimitive("shadingShiftTextureScale", e.shadingShiftTexture?.scale), n.assignPrimitive("shadingToonyFactor", e.shadingToonyFactor), n.assignPrimitive("giEqualizationFactor", e.giEqualizationFactor), n.assignColor("matcapFactor", e.matcapFactor), n.assignTexture("matcapTexture", e.matcapTexture, !0), n.assignColor("parametricRimColorFactor", e.parametricRimColorFactor), n.assignTexture("rimMultiplyTexture", e.rimMultiplyTexture, !0), n.assignPrimitive("rimLightingMixFactor", e.rimLightingMixFactor), n.assignPrimitive("parametricRimFresnelPowerFactor", e.parametricRimFresnelPowerFactor), n.assignPrimitive("parametricRimLiftFactor", e.parametricRimLiftFactor), n.assignPrimitive("outlineWidthMode", e.outlineWidthMode), n.assignPrimitive("outlineWidthFactor", e.outlineWidthFactor), n.assignTexture("outlineWidthMultiplyTexture", e.outlineWidthMultiplyTexture, !1), n.assignColor("outlineColorFactor", e.outlineColorFactor), n.assignPrimitive("outlineLightingMixFactor", e.outlineLightingMixFactor), n.assignTexture("uvAnimationMaskTexture", e.uvAnimationMaskTexture, !1), n.assignPrimitive("uvAnimationScrollXSpeedFactor", e.uvAnimationScrollXSpeedFactor), n.assignPrimitive("uvAnimationScrollYSpeedFactor", e.uvAnimationScrollYSpeedFactor), n.assignPrimitive("uvAnimationRotationSpeedFactor", e.uvAnimationRotationSpeedFactor), n.assignPrimitive("v0CompatShade", this.v0CompatShade), n.assignPrimitive("debugMode", this.debugMode), yield n.pending;
		});
	}
	_setupPrimitive(e, t) {
		let n = this._getMToonExtension(t);
		n && (e.renderOrder = this._parseRenderOrder(n) + this.renderOrderOffset, this._generateOutline(e), this._addToMaterialSet(e));
	}
	_shouldGenerateOutline(e) {
		return typeof e.outlineWidthMode == "string" && e.outlineWidthMode !== "none" && typeof e.outlineWidthFactor == "number" && e.outlineWidthFactor > 0;
	}
	_generateOutline(e) {
		let t = e.material;
		if (!(t instanceof ee) || !this._shouldGenerateOutline(t)) return;
		e.material = [t];
		let n = t.clone();
		n.name += " (Outline)", n.isOutline = !0, n.side = 1, e.material.push(n);
		let r = e.geometry, i = r.index ? r.index.count : r.attributes.position.count / 3;
		r.addGroup(0, i, 0), r.addGroup(0, i, 1);
	}
	_addToMaterialSet(e) {
		let t = e.material, n = /* @__PURE__ */ new Set();
		Array.isArray(t) ? t.forEach((e) => n.add(e)) : n.add(t);
		for (let e of n) this._mToonMaterialSet.add(e);
	}
	_parseRenderOrder(e) {
		return (e.transparentWithZWrite ? 0 : 19) + (e.renderQueueOffsetNumber ?? 0);
	}
};
Tr.EXTENSION_NAME = "VRMC_materials_mtoon";
var Er = Tr, Dr = (e, t, n) => new Promise((r, i) => {
	var a = (e) => {
		try {
			s(n.next(e));
		} catch (e) {
			i(e);
		}
	}, o = (e) => {
		try {
			s(n.throw(e));
		} catch (e) {
			i(e);
		}
	}, s = (e) => e.done ? r(e.value) : Promise.resolve(e.value).then(a, o);
	s((n = n.apply(e, t)).next());
}), Or = class e {
	get name() {
		return e.EXTENSION_NAME;
	}
	constructor(e) {
		this.parser = e;
	}
	extendMaterialParams(e, t) {
		return Dr(this, null, function* () {
			let n = this._getHDREmissiveMultiplierExtension(e);
			n != null && (console.warn("VRMMaterialsHDREmissiveMultiplierLoaderPlugin: `VRMC_materials_hdr_emissiveMultiplier` is archived. Use `KHR_materials_emissive_strength` instead."), t.emissiveIntensity = n.emissiveMultiplier);
		});
	}
	_getHDREmissiveMultiplierExtension(t) {
		let n = this.parser.json.materials?.[t];
		if (n == null) {
			console.warn(`VRMMaterialsHDREmissiveMultiplierLoaderPlugin: Attempt to use materials[${t}] of glTF but the material doesn't exist`);
			return;
		}
		let r = n.extensions?.[e.EXTENSION_NAME];
		if (r != null) return r;
	}
};
Or.EXTENSION_NAME = "VRMC_materials_hdr_emissiveMultiplier";
var kr = Or, Ar = Object.defineProperty, jr = Object.defineProperties, Mr = Object.getOwnPropertyDescriptors, Nr = Object.getOwnPropertySymbols, Pr = Object.prototype.hasOwnProperty, Fr = Object.prototype.propertyIsEnumerable, Ir = (e, t, n) => t in e ? Ar(e, t, {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: n
}) : e[t] = n, Lr = (e, t) => {
	for (var n in t ||= {}) Pr.call(t, n) && Ir(e, n, t[n]);
	if (Nr) for (var n of Nr(t)) Fr.call(t, n) && Ir(e, n, t[n]);
	return e;
}, Rr = (e, t) => jr(e, Mr(t)), zr = (e, t, n) => new Promise((r, i) => {
	var a = (e) => {
		try {
			s(n.next(e));
		} catch (e) {
			i(e);
		}
	}, o = (e) => {
		try {
			s(n.throw(e));
		} catch (e) {
			i(e);
		}
	}, s = (e) => e.done ? r(e.value) : Promise.resolve(e.value).then(a, o);
	s((n = n.apply(e, t)).next());
});
function Br(e) {
	return e ** 2.2;
}
var Vr = class {
	get name() {
		return "VRMMaterialsV0CompatPlugin";
	}
	constructor(e) {
		this.parser = e, this._renderQueueMapTransparent = /* @__PURE__ */ new Map(), this._renderQueueMapTransparentZWrite = /* @__PURE__ */ new Map();
		let t = this.parser.json;
		t.extensionsUsed = t.extensionsUsed ?? [], t.extensionsUsed.indexOf("KHR_texture_transform") === -1 && t.extensionsUsed.push("KHR_texture_transform");
	}
	beforeRoot() {
		return zr(this, null, function* () {
			let e = this.parser.json, t = e.extensions?.VRM?.materialProperties;
			t && (this._populateRenderQueueMap(t), t.forEach((t, n) => {
				let r = e.materials?.[n];
				if (r == null) console.warn(`VRMMaterialsV0CompatPlugin: Attempt to use materials[${n}] of glTF but the material doesn't exist`);
				else if (t.shader === "VRM/MToon") {
					let i = this._parseV0MToonProperties(t, r);
					e.materials[n] = i;
				} else if (t.shader?.startsWith("VRM/Unlit")) {
					let i = this._parseV0UnlitProperties(t, r);
					e.materials[n] = i;
				} else t.shader === "VRM_USE_GLTFSHADER" || console.warn(`VRMMaterialsV0CompatPlugin: Unknown shader: ${t.shader}`);
			}));
		});
	}
	_parseV0MToonProperties(e, t) {
		let n = e.keywordMap?._ALPHABLEND_ON ?? !1, r = e.floatProperties?._ZWrite === 1 && n, i = this._v0ParseRenderQueue(e), a = e.keywordMap?._ALPHATEST_ON ?? !1, o = n ? "BLEND" : a ? "MASK" : "OPAQUE", s = a ? e.floatProperties?._Cutoff ?? .5 : void 0, c = (e.floatProperties?._CullMode ?? 2) === 0, l = this._portTextureTransform(e), u = (e.vectorProperties?._Color ?? [
			1,
			1,
			1,
			1
		]).map((e, t) => t === 3 ? e : Br(e)), d = e.textureProperties?._MainTex, f = d == null ? void 0 : {
			index: d,
			extensions: Lr({}, l)
		}, p = e.floatProperties?._BumpScale ?? 1, m = e.textureProperties?._BumpMap, h = m == null ? void 0 : {
			index: m,
			scale: p,
			extensions: Lr({}, l)
		}, g = (e.vectorProperties?._EmissionColor ?? [
			0,
			0,
			0,
			1
		]).map(Br), _ = e.textureProperties?._EmissionMap, v = _ == null ? void 0 : {
			index: _,
			extensions: Lr({}, l)
		}, y = (e.vectorProperties?._ShadeColor ?? [
			.97,
			.81,
			.86,
			1
		]).map(Br), b = e.textureProperties?._ShadeTexture, ee = b == null ? void 0 : {
			index: b,
			extensions: Lr({}, l)
		}, x = e.floatProperties?._ShadeShift ?? 0, S = e.floatProperties?._ShadeToony ?? .9;
		S = le.lerp(S, 1, .5 + .5 * x), x = -x - (1 - S);
		let C = e.floatProperties?._IndirectLightIntensity ?? .1, w = C ? 1 - C : void 0, te = e.textureProperties?._SphereAdd, ne = te == null ? void 0 : [
			1,
			1,
			1
		], T = te == null ? void 0 : { index: te }, E = e.floatProperties?._RimLightingMix ?? 0, re = e.textureProperties?._RimTexture, ie = re == null ? void 0 : {
			index: re,
			extensions: Lr({}, l)
		}, D = (e.vectorProperties?._RimColor ?? [
			0,
			0,
			0,
			1
		]).map(Br), ae = e.floatProperties?._RimFresnelPower ?? 1, oe = e.floatProperties?._RimLift ?? 0, se = [
			"none",
			"worldCoordinates",
			"screenCoordinates"
		][e.floatProperties?._OutlineWidthMode ?? 0], ce = e.floatProperties?._OutlineWidth ?? 0;
		ce = .01 * ce;
		let ue = e.textureProperties?._OutlineWidthTexture, de = ue == null ? void 0 : {
			index: ue,
			extensions: Lr({}, l)
		}, fe = (e.vectorProperties?._OutlineColor ?? [
			0,
			0,
			0
		]).map(Br), pe = (e.floatProperties?._OutlineColorMode ?? 0) === 1 ? e.floatProperties?._OutlineLightingMix ?? 1 : 0, me = e.textureProperties?._UvAnimMaskTexture, he = me == null ? void 0 : {
			index: me,
			extensions: Lr({}, l)
		}, ge = e.floatProperties?._UvAnimScrollX ?? 0, _e = e.floatProperties?._UvAnimScrollY ?? 0;
		_e != null && (_e = -_e);
		let ve = e.floatProperties?._UvAnimRotation ?? 0, ye = {
			specVersion: "1.0",
			transparentWithZWrite: r,
			renderQueueOffsetNumber: i,
			shadeColorFactor: y,
			shadeMultiplyTexture: ee,
			shadingShiftFactor: x,
			shadingToonyFactor: S,
			giEqualizationFactor: w,
			matcapFactor: ne,
			matcapTexture: T,
			rimLightingMixFactor: E,
			rimMultiplyTexture: ie,
			parametricRimColorFactor: D,
			parametricRimFresnelPowerFactor: ae,
			parametricRimLiftFactor: oe,
			outlineWidthMode: se,
			outlineWidthFactor: ce,
			outlineWidthMultiplyTexture: de,
			outlineColorFactor: fe,
			outlineLightingMixFactor: pe,
			uvAnimationMaskTexture: he,
			uvAnimationScrollXSpeedFactor: ge,
			uvAnimationScrollYSpeedFactor: _e,
			uvAnimationRotationSpeedFactor: ve
		};
		return Rr(Lr({}, t), {
			pbrMetallicRoughness: {
				baseColorFactor: u,
				baseColorTexture: f
			},
			normalTexture: h,
			emissiveTexture: v,
			emissiveFactor: g,
			alphaMode: o,
			alphaCutoff: s,
			doubleSided: c,
			extensions: { VRMC_materials_mtoon: ye }
		});
	}
	_parseV0UnlitProperties(e, t) {
		let n = e.shader === "VRM/UnlitTransparentZWrite", r = e.shader === "VRM/UnlitTransparent" || n, i = this._v0ParseRenderQueue(e), a = e.shader === "VRM/UnlitCutout", o = r ? "BLEND" : a ? "MASK" : "OPAQUE", s = a ? e.floatProperties?._Cutoff ?? .5 : void 0, c = this._portTextureTransform(e), l = (e.vectorProperties?._Color ?? [
			1,
			1,
			1,
			1
		]).map(Br), u = e.textureProperties?._MainTex, d = u == null ? void 0 : {
			index: u,
			extensions: Lr({}, c)
		}, f = {
			specVersion: "1.0",
			transparentWithZWrite: n,
			renderQueueOffsetNumber: i,
			shadeColorFactor: l,
			shadeMultiplyTexture: d
		};
		return Rr(Lr({}, t), {
			pbrMetallicRoughness: {
				baseColorFactor: l,
				baseColorTexture: d
			},
			alphaMode: o,
			alphaCutoff: s,
			extensions: { VRMC_materials_mtoon: f }
		});
	}
	_portTextureTransform(e) {
		let t = e.vectorProperties?._MainTex;
		if (t == null) return {};
		let n = [t?.[0] ?? 0, t?.[1] ?? 0], r = [t?.[2] ?? 1, t?.[3] ?? 1];
		return n[1] = 1 - r[1] - n[1], { KHR_texture_transform: {
			offset: n,
			scale: r
		} };
	}
	_v0ParseRenderQueue(e) {
		let t = e.shader === "VRM/UnlitTransparentZWrite", n = e.keywordMap?._ALPHABLEND_ON != null || e.shader === "VRM/UnlitTransparent" || t, r = e.floatProperties?._ZWrite === 1 || t, i = 0;
		if (n) {
			let t = e.renderQueue;
			t != null && (i = r ? this._renderQueueMapTransparentZWrite.get(t) : this._renderQueueMapTransparent.get(t));
		}
		return i;
	}
	_populateRenderQueueMap(e) {
		let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set();
		e.forEach((e) => {
			let r = e.shader === "VRM/UnlitTransparentZWrite", i = e.keywordMap?._ALPHABLEND_ON != null || e.shader === "VRM/UnlitTransparent" || r, a = e.floatProperties?._ZWrite === 1 || r;
			if (i) {
				let r = e.renderQueue;
				r != null && (a ? n.add(r) : t.add(r));
			}
		}), t.size > 10 && console.warn(`VRMMaterialsV0CompatPlugin: This VRM uses ${t.size} render queues for Transparent materials while VRM 1.0 only supports up to 10 render queues. The model might not be rendered correctly.`), n.size > 10 && console.warn(`VRMMaterialsV0CompatPlugin: This VRM uses ${n.size} render queues for TransparentZWrite materials while VRM 1.0 only supports up to 10 render queues. The model might not be rendered correctly.`), Array.from(t).sort().forEach((e, n) => {
			let r = Math.min(Math.max(n - t.size + 1, -9), 0);
			this._renderQueueMapTransparent.set(e, r);
		}), Array.from(n).sort().forEach((e, t) => {
			let n = Math.min(Math.max(t, 0), 9);
			this._renderQueueMapTransparentZWrite.set(e, n);
		});
	}
}, Hr = (e, t, n) => new Promise((r, i) => {
	var a = (e) => {
		try {
			s(n.next(e));
		} catch (e) {
			i(e);
		}
	}, o = (e) => {
		try {
			s(n.throw(e));
		} catch (e) {
			i(e);
		}
	}, s = (e) => e.done ? r(e.value) : Promise.resolve(e.value).then(a, o);
	s((n = n.apply(e, t)).next());
}), Ur = new w(), Wr = class extends u {
	constructor(e) {
		super(), this._attrPosition = new E(new Float32Array([
			0,
			0,
			0,
			0,
			0,
			0
		]), 3), this._attrPosition.setUsage(s);
		let t = new ce();
		t.setAttribute("position", this._attrPosition);
		let n = new S({
			color: 16711935,
			depthTest: !1,
			depthWrite: !1
		});
		this._line = new ne(t, n), this.add(this._line), this.constraint = e;
	}
	updateMatrixWorld(e) {
		Ur.setFromMatrixPosition(this.constraint.destination.matrixWorld), this._attrPosition.setXYZ(0, Ur.x, Ur.y, Ur.z), this.constraint.source && Ur.setFromMatrixPosition(this.constraint.source.matrixWorld), this._attrPosition.setXYZ(1, Ur.x, Ur.y, Ur.z), this._attrPosition.needsUpdate = !0, super.updateMatrixWorld(e);
	}
};
function Gr(e, t) {
	return t.set(e.elements[12], e.elements[13], e.elements[14]);
}
var Kr = new w(), qr = new w();
function Jr(e, t) {
	return e.decompose(Kr, t, qr), t;
}
function Yr(e) {
	return e.invert ? e.invert() : e.inverse(), e;
}
var Xr = class {
	constructor(e, t) {
		this.destination = e, this.source = t, this.weight = 1;
	}
}, Zr = new w(), Qr = new w(), $r = new w(), ei = new b(), ti = new b(), ni = new b(), ri = class extends Xr {
	get aimAxis() {
		return this._aimAxis;
	}
	set aimAxis(e) {
		this._aimAxis = e, this._v3AimAxis.set(e === "PositiveX" ? 1 : e === "NegativeX" ? -1 : 0, e === "PositiveY" ? 1 : e === "NegativeY" ? -1 : 0, e === "PositiveZ" ? 1 : e === "NegativeZ" ? -1 : 0);
	}
	get dependencies() {
		let e = /* @__PURE__ */ new Set([this.source]);
		return this.destination.parent && e.add(this.destination.parent), e;
	}
	constructor(e, t) {
		super(e, t), this._aimAxis = "PositiveX", this._v3AimAxis = new w(1, 0, 0), this._dstRestQuat = new b();
	}
	setInitState() {
		this._dstRestQuat.copy(this.destination.quaternion);
	}
	update() {
		this.destination.updateWorldMatrix(!0, !1), this.source.updateWorldMatrix(!0, !1);
		let e = ei.identity(), t = ti.identity();
		this.destination.parent && (Jr(this.destination.parent.matrixWorld, e), Yr(t.copy(e)));
		let n = Zr.copy(this._v3AimAxis).applyQuaternion(this._dstRestQuat).applyQuaternion(e), r = Gr(this.source.matrixWorld, Qr).sub(Gr(this.destination.matrixWorld, $r)).normalize(), i = ni.setFromUnitVectors(n, r).premultiply(t).multiply(e).multiply(this._dstRestQuat);
		this.destination.quaternion.copy(this._dstRestQuat).slerp(i, this.weight);
	}
};
function ii(e, t) {
	let n = [e], r = e.parent;
	for (; r !== null;) n.unshift(r), r = r.parent;
	n.forEach((e) => {
		t(e);
	});
}
var ai = class {
	constructor() {
		this._constraints = /* @__PURE__ */ new Set(), this._objectConstraintsMap = /* @__PURE__ */ new Map();
	}
	get constraints() {
		return this._constraints;
	}
	addConstraint(e) {
		this._constraints.add(e);
		let t = this._objectConstraintsMap.get(e.destination);
		t ?? (t = /* @__PURE__ */ new Set(), this._objectConstraintsMap.set(e.destination, t)), t.add(e);
	}
	deleteConstraint(e) {
		this._constraints.delete(e), this._objectConstraintsMap.get(e.destination).delete(e);
	}
	setInitState() {
		let e = /* @__PURE__ */ new Set(), t = /* @__PURE__ */ new Set();
		for (let n of this._constraints) this._processConstraint(n, e, t, (e) => e.setInitState());
	}
	update() {
		let e = /* @__PURE__ */ new Set(), t = /* @__PURE__ */ new Set();
		for (let n of this._constraints) this._processConstraint(n, e, t, (e) => e.update());
	}
	_processConstraint(e, t, n, r) {
		if (n.has(e)) return;
		if (t.has(e)) throw Error("VRMNodeConstraintManager: Circular dependency detected while updating constraints");
		t.add(e);
		let i = e.dependencies;
		for (let e of i) ii(e, (e) => {
			let i = this._objectConstraintsMap.get(e);
			if (i) for (let e of i) this._processConstraint(e, t, n, r);
		});
		r(e), n.add(e);
	}
}, oi = new b(), si = new b(), ci = class extends Xr {
	get dependencies() {
		return /* @__PURE__ */ new Set([this.source]);
	}
	constructor(e, t) {
		super(e, t), this._dstRestQuat = new b(), this._invSrcRestQuat = new b();
	}
	setInitState() {
		this._dstRestQuat.copy(this.destination.quaternion), Yr(this._invSrcRestQuat.copy(this.source.quaternion));
	}
	update() {
		let e = oi.copy(this._invSrcRestQuat).multiply(this.source.quaternion), t = si.copy(this._dstRestQuat).multiply(e);
		this.destination.quaternion.copy(this._dstRestQuat).slerp(t, this.weight);
	}
}, li = new w(), ui = new b(), di = new b(), fi = class extends Xr {
	get rollAxis() {
		return this._rollAxis;
	}
	set rollAxis(e) {
		this._rollAxis = e, this._v3RollAxis.set(+(e === "X"), +(e === "Y"), +(e === "Z"));
	}
	get dependencies() {
		return /* @__PURE__ */ new Set([this.source]);
	}
	constructor(e, t) {
		super(e, t), this._rollAxis = "X", this._v3RollAxis = new w(1, 0, 0), this._dstRestQuat = new b(), this._invDstRestQuat = new b(), this._invSrcRestQuatMulDstRestQuat = new b();
	}
	setInitState() {
		this._dstRestQuat.copy(this.destination.quaternion), Yr(this._invDstRestQuat.copy(this._dstRestQuat)), Yr(this._invSrcRestQuatMulDstRestQuat.copy(this.source.quaternion)).multiply(this._dstRestQuat);
	}
	update() {
		let e = ui.copy(this._invDstRestQuat).multiply(this.source.quaternion).multiply(this._invSrcRestQuatMulDstRestQuat), t = li.copy(this._v3RollAxis).applyQuaternion(e), n = di.setFromUnitVectors(t, this._v3RollAxis).premultiply(this._dstRestQuat).multiply(e);
		this.destination.quaternion.copy(this._dstRestQuat).slerp(n, this.weight);
	}
}, pi = /* @__PURE__ */ new Set(["1.0", "1.0-beta"]), mi = class e {
	get name() {
		return e.EXTENSION_NAME;
	}
	constructor(e, t) {
		this.parser = e, this.helperRoot = t?.helperRoot;
	}
	afterRoot(e) {
		return Hr(this, null, function* () {
			e.userData.vrmNodeConstraintManager = yield this._import(e);
		});
	}
	_import(t) {
		return Hr(this, null, function* () {
			let n = this.parser.json;
			if (n.extensionsUsed?.indexOf(e.EXTENSION_NAME) === -1) return null;
			let r = new ai(), i = yield this.parser.getDependencies("node");
			return i.forEach((t, a) => {
				let o = n.nodes[a]?.extensions?.[e.EXTENSION_NAME];
				if (o == null) return;
				let s = o.specVersion;
				if (!pi.has(s)) {
					console.warn(`VRMNodeConstraintLoaderPlugin: Unknown ${e.EXTENSION_NAME} specVersion "${s}"`);
					return;
				}
				let c = o.constraint;
				if (c.roll != null) {
					let e = this._importRollConstraint(t, i, c.roll);
					r.addConstraint(e);
				} else if (c.aim != null) {
					let e = this._importAimConstraint(t, i, c.aim);
					r.addConstraint(e);
				} else if (c.rotation != null) {
					let e = this._importRotationConstraint(t, i, c.rotation);
					r.addConstraint(e);
				}
			}), t.scene.updateMatrixWorld(), r.setInitState(), r;
		});
	}
	_importRollConstraint(e, t, n) {
		let { source: r, rollAxis: i, weight: a } = n, o = t[r], s = new fi(e, o);
		if (i != null && (s.rollAxis = i), a != null && (s.weight = a), this.helperRoot) {
			let e = new Wr(s);
			this.helperRoot.add(e);
		}
		return s;
	}
	_importAimConstraint(e, t, n) {
		let { source: r, aimAxis: i, weight: a } = n, o = t[r], s = new ri(e, o);
		if (i != null && (s.aimAxis = i), a != null && (s.weight = a), this.helperRoot) {
			let e = new Wr(s);
			this.helperRoot.add(e);
		}
		return s;
	}
	_importRotationConstraint(e, t, n) {
		let { source: r, weight: i } = n, a = t[r], o = new ci(e, a);
		if (i != null && (o.weight = i), this.helperRoot) {
			let e = new Wr(o);
			this.helperRoot.add(e);
		}
		return o;
	}
};
mi.EXTENSION_NAME = "VRMC_node_constraint";
var hi = mi, gi = (e, t, n) => new Promise((r, i) => {
	var a = (e) => {
		try {
			s(n.next(e));
		} catch (e) {
			i(e);
		}
	}, o = (e) => {
		try {
			s(n.throw(e));
		} catch (e) {
			i(e);
		}
	}, s = (e) => e.done ? r(e.value) : Promise.resolve(e.value).then(a, o);
	s((n = n.apply(e, t)).next());
}), _i = class {}, vi = new w(), yi = new w(), bi = class extends _i {
	get type() {
		return "capsule";
	}
	constructor(e) {
		super(), this.offset = e?.offset ?? new w(0, 0, 0), this.tail = e?.tail ?? new w(0, 0, 0), this.radius = e?.radius ?? 0, this.inside = e?.inside ?? !1;
	}
	calculateCollision(e, t, n, r) {
		vi.setFromMatrixPosition(e), yi.subVectors(this.tail, this.offset).applyMatrix4(e), yi.sub(vi);
		let i = yi.lengthSq();
		r.copy(t).sub(vi);
		let a = yi.dot(r);
		a <= 0 || (i <= a || yi.multiplyScalar(a / i), r.sub(yi));
		let o = r.length(), s = this.inside ? this.radius - n - o : o - n - this.radius;
		return s < 0 && (r.multiplyScalar(1 / o), this.inside && r.negate()), s;
	}
}, xi = new w(), Si = new de(), Ci = class extends _i {
	get type() {
		return "plane";
	}
	constructor(e) {
		super(), this.offset = e?.offset ?? new w(0, 0, 0), this.normal = e?.normal ?? new w(0, 0, 1);
	}
	calculateCollision(e, t, n, r) {
		r.setFromMatrixPosition(e), r.negate().add(t), Si.getNormalMatrix(e), xi.copy(this.normal).applyNormalMatrix(Si).normalize();
		let i = r.dot(xi) - n;
		return r.copy(xi), i;
	}
}, wi = new w(), Ti = class extends _i {
	get type() {
		return "sphere";
	}
	constructor(e) {
		super(), this.offset = e?.offset ?? new w(0, 0, 0), this.radius = e?.radius ?? 0, this.inside = e?.inside ?? !1;
	}
	calculateCollision(e, t, n, r) {
		r.subVectors(t, wi.setFromMatrixPosition(e));
		let i = r.length(), a = this.inside ? this.radius - n - i : i - n - this.radius;
		return a < 0 && (r.multiplyScalar(1 / i), this.inside && r.negate()), a;
	}
}, Ei = new w(), Di = class extends ce {
	constructor(e) {
		super(), this.worldScale = 1, this._currentRadius = 0, this._currentOffset = new w(), this._currentTail = new w(), this._shape = e, this._attrPos = new E(/* @__PURE__ */ new Float32Array(396), 3), this.setAttribute("position", this._attrPos), this._attrIndex = new E(/* @__PURE__ */ new Uint16Array(264), 1), this.setIndex(this._attrIndex), this._buildIndex(), this.update();
	}
	update() {
		let e = !1, t = this._shape.radius / this.worldScale;
		this._currentRadius !== t && (this._currentRadius = t, e = !0), this._currentOffset.equals(this._shape.offset) || (this._currentOffset.copy(this._shape.offset), e = !0);
		let n = Ei.copy(this._shape.tail).divideScalar(this.worldScale);
		this._currentTail.distanceToSquared(n) > 1e-10 && (this._currentTail.copy(n), e = !0), e && this._buildPosition();
	}
	_buildPosition() {
		Ei.copy(this._currentTail).sub(this._currentOffset);
		let e = Ei.length() / this._currentRadius;
		for (let t = 0; t <= 16; t++) {
			let n = t / 16 * Math.PI;
			this._attrPos.setXYZ(t, -Math.sin(n), -Math.cos(n), 0), this._attrPos.setXYZ(17 + t, e + Math.sin(n), Math.cos(n), 0), this._attrPos.setXYZ(34 + t, -Math.sin(n), 0, -Math.cos(n)), this._attrPos.setXYZ(51 + t, e + Math.sin(n), 0, Math.cos(n));
		}
		for (let t = 0; t < 32; t++) {
			let n = t / 16 * Math.PI;
			this._attrPos.setXYZ(68 + t, 0, Math.sin(n), Math.cos(n)), this._attrPos.setXYZ(100 + t, e, Math.sin(n), Math.cos(n));
		}
		let t = Math.atan2(Ei.y, Math.sqrt(Ei.x * Ei.x + Ei.z * Ei.z)), n = -Math.atan2(Ei.z, Ei.x);
		this.rotateZ(t), this.rotateY(n), this.scale(this._currentRadius, this._currentRadius, this._currentRadius), this.translate(this._currentOffset.x, this._currentOffset.y, this._currentOffset.z), this._attrPos.needsUpdate = !0;
	}
	_buildIndex() {
		for (let e = 0; e < 34; e++) {
			let t = (e + 1) % 34;
			this._attrIndex.setXY(e * 2, e, t), this._attrIndex.setXY(68 + e * 2, 34 + e, 34 + t);
		}
		for (let e = 0; e < 32; e++) {
			let t = (e + 1) % 32;
			this._attrIndex.setXY(136 + e * 2, 68 + e, 68 + t), this._attrIndex.setXY(200 + e * 2, 100 + e, 100 + t);
		}
		this._attrIndex.needsUpdate = !0;
	}
}, Oi = class extends ce {
	constructor(e) {
		super(), this.worldScale = 1, this._currentOffset = new w(), this._currentNormal = new w(), this._shape = e, this._attrPos = new E(/* @__PURE__ */ new Float32Array(18), 3), this.setAttribute("position", this._attrPos), this._attrIndex = new E(/* @__PURE__ */ new Uint16Array(10), 1), this.setIndex(this._attrIndex), this._buildIndex(), this.update();
	}
	update() {
		let e = !1;
		this._currentOffset.equals(this._shape.offset) || (this._currentOffset.copy(this._shape.offset), e = !0), this._currentNormal.equals(this._shape.normal) || (this._currentNormal.copy(this._shape.normal), e = !0), e && this._buildPosition();
	}
	_buildPosition() {
		this._attrPos.setXYZ(0, -.5, -.5, 0), this._attrPos.setXYZ(1, .5, -.5, 0), this._attrPos.setXYZ(2, .5, .5, 0), this._attrPos.setXYZ(3, -.5, .5, 0), this._attrPos.setXYZ(4, 0, 0, 0), this._attrPos.setXYZ(5, 0, 0, .25), this.translate(this._currentOffset.x, this._currentOffset.y, this._currentOffset.z), this.lookAt(this._currentNormal), this._attrPos.needsUpdate = !0;
	}
	_buildIndex() {
		this._attrIndex.setXY(0, 0, 1), this._attrIndex.setXY(2, 1, 2), this._attrIndex.setXY(4, 2, 3), this._attrIndex.setXY(6, 3, 0), this._attrIndex.setXY(8, 4, 5), this._attrIndex.needsUpdate = !0;
	}
}, ki = class extends ce {
	constructor(e) {
		super(), this.worldScale = 1, this._currentRadius = 0, this._currentOffset = new w(), this._shape = e, this._attrPos = new E(/* @__PURE__ */ new Float32Array(288), 3), this.setAttribute("position", this._attrPos), this._attrIndex = new E(/* @__PURE__ */ new Uint16Array(192), 1), this.setIndex(this._attrIndex), this._buildIndex(), this.update();
	}
	update() {
		let e = !1, t = this._shape.radius / this.worldScale;
		this._currentRadius !== t && (this._currentRadius = t, e = !0), this._currentOffset.equals(this._shape.offset) || (this._currentOffset.copy(this._shape.offset), e = !0), e && this._buildPosition();
	}
	_buildPosition() {
		for (let e = 0; e < 32; e++) {
			let t = e / 16 * Math.PI;
			this._attrPos.setXYZ(e, Math.cos(t), Math.sin(t), 0), this._attrPos.setXYZ(32 + e, 0, Math.cos(t), Math.sin(t)), this._attrPos.setXYZ(64 + e, Math.sin(t), 0, Math.cos(t));
		}
		this.scale(this._currentRadius, this._currentRadius, this._currentRadius), this.translate(this._currentOffset.x, this._currentOffset.y, this._currentOffset.z), this._attrPos.needsUpdate = !0;
	}
	_buildIndex() {
		for (let e = 0; e < 32; e++) {
			let t = (e + 1) % 32;
			this._attrIndex.setXY(e * 2, e, t), this._attrIndex.setXY(64 + e * 2, 32 + e, 32 + t), this._attrIndex.setXY(128 + e * 2, 64 + e, 64 + t);
		}
		this._attrIndex.needsUpdate = !0;
	}
}, Ai = new w(), ji = class extends u {
	constructor(e) {
		if (super(), this.matrixAutoUpdate = !1, this.collider = e, this.collider.shape instanceof Ti) this._geometry = new ki(this.collider.shape);
		else if (this.collider.shape instanceof bi) this._geometry = new Di(this.collider.shape);
		else if (this.collider.shape instanceof Ci) this._geometry = new Oi(this.collider.shape);
		else throw Error("VRMSpringBoneColliderHelper: Unknown collider shape type detected");
		let t = new S({
			color: 16711935,
			depthTest: !1,
			depthWrite: !1
		});
		this._line = new oe(this._geometry, t), this.add(this._line);
	}
	dispose() {
		this._geometry.dispose();
	}
	updateMatrixWorld(e) {
		this.collider.updateWorldMatrix(!0, !1), this.matrix.copy(this.collider.matrixWorld);
		let t = this.matrix.elements;
		this._geometry.worldScale = Ai.set(t[0], t[1], t[2]).length(), this._geometry.update(), super.updateMatrixWorld(e);
	}
}, Mi = class extends ce {
	constructor(e) {
		super(), this.worldScale = 1, this._currentRadius = 0, this._currentTail = new w(), this._springBone = e, this._attrPos = new E(/* @__PURE__ */ new Float32Array(294), 3), this.setAttribute("position", this._attrPos), this._attrIndex = new E(/* @__PURE__ */ new Uint16Array(194), 1), this.setIndex(this._attrIndex), this._buildIndex(), this.update();
	}
	update() {
		let e = !1, t = this._springBone.settings.hitRadius / this.worldScale;
		this._currentRadius !== t && (this._currentRadius = t, e = !0), this._currentTail.equals(this._springBone.initialLocalChildPosition) || (this._currentTail.copy(this._springBone.initialLocalChildPosition), e = !0), e && this._buildPosition();
	}
	_buildPosition() {
		for (let e = 0; e < 32; e++) {
			let t = e / 16 * Math.PI;
			this._attrPos.setXYZ(e, Math.cos(t), Math.sin(t), 0), this._attrPos.setXYZ(32 + e, 0, Math.cos(t), Math.sin(t)), this._attrPos.setXYZ(64 + e, Math.sin(t), 0, Math.cos(t));
		}
		this.scale(this._currentRadius, this._currentRadius, this._currentRadius), this.translate(this._currentTail.x, this._currentTail.y, this._currentTail.z), this._attrPos.setXYZ(96, 0, 0, 0), this._attrPos.setXYZ(97, this._currentTail.x, this._currentTail.y, this._currentTail.z), this._attrPos.needsUpdate = !0;
	}
	_buildIndex() {
		for (let e = 0; e < 32; e++) {
			let t = (e + 1) % 32;
			this._attrIndex.setXY(e * 2, e, t), this._attrIndex.setXY(64 + e * 2, 32 + e, 32 + t), this._attrIndex.setXY(128 + e * 2, 64 + e, 64 + t);
		}
		this._attrIndex.setXY(192, 96, 97), this._attrIndex.needsUpdate = !0;
	}
}, Ni = new w(), Pi = class extends u {
	constructor(e) {
		super(), this.matrixAutoUpdate = !1, this.springBone = e, this._geometry = new Mi(this.springBone);
		let t = new S({
			color: 16776960,
			depthTest: !1,
			depthWrite: !1
		});
		this._line = new oe(this._geometry, t), this.add(this._line);
	}
	dispose() {
		this._geometry.dispose();
	}
	updateMatrixWorld(e) {
		this.springBone.bone.updateWorldMatrix(!0, !1), this.matrix.copy(this.springBone.bone.matrixWorld);
		let t = this.matrix.elements;
		this._geometry.worldScale = Ni.set(t[0], t[1], t[2]).length(), this._geometry.update(), super.updateMatrixWorld(e);
	}
}, Fi = class extends m {
	constructor(e) {
		super(), this.colliderMatrix = new C(), this.shape = e;
	}
	updateWorldMatrix(e, t) {
		super.updateWorldMatrix(e, t), Ii(this.colliderMatrix, this.matrixWorld, this.shape.offset);
	}
};
function Ii(e, t, n) {
	let r = t.elements;
	e.copy(t), n && (e.elements[12] = r[0] * n.x + r[4] * n.y + r[8] * n.z + r[12], e.elements[13] = r[1] * n.x + r[5] * n.y + r[9] * n.z + r[13], e.elements[14] = r[2] * n.x + r[6] * n.y + r[10] * n.z + r[14]);
}
var Li = new C();
function Ri(e) {
	return e.invert ? e.invert() : e.getInverse(Li.copy(e)), e;
}
var zi = class {
	constructor(e) {
		this._inverseCache = new C(), this._shouldUpdateInverse = !0, this.matrix = e;
		let t = { set: (e, t, n) => (this._shouldUpdateInverse = !0, e[t] = n, !0) };
		this._originalElements = e.elements, e.elements = new Proxy(e.elements, t);
	}
	get inverse() {
		return this._shouldUpdateInverse &&= (Ri(this._inverseCache.copy(this.matrix)), !1), this._inverseCache;
	}
	revert() {
		this.matrix.elements = this._originalElements;
	}
}, Bi = new C(), Vi = new w(), Hi = new w(), Ui = new w(), Wi = new w(), Gi = new C(), Ki = class {
	constructor(e, t, n = {}, r = []) {
		this._currentTail = new w(), this._prevTail = new w(), this._boneAxis = new w(), this._worldSpaceBoneLength = 0, this._center = null, this._initialLocalMatrix = new C(), this._initialLocalRotation = new b(), this._initialLocalChildPosition = new w(), this.bone = e, this.bone.matrixAutoUpdate = !1, this.child = t, this.settings = {
			hitRadius: n.hitRadius ?? 0,
			stiffness: n.stiffness ?? 1,
			gravityPower: n.gravityPower ?? 0,
			gravityDir: n.gravityDir?.clone() ?? new w(0, -1, 0),
			dragForce: n.dragForce ?? .4
		}, this.colliderGroups = r;
	}
	get dependencies() {
		let e = /* @__PURE__ */ new Set(), t = this.bone.parent;
		t && e.add(t);
		for (let t = 0; t < this.colliderGroups.length; t++) for (let n = 0; n < this.colliderGroups[t].colliders.length; n++) e.add(this.colliderGroups[t].colliders[n]);
		return e;
	}
	get center() {
		return this._center;
	}
	set center(e) {
		this._center?.userData.inverseCacheProxy && (this._center.userData.inverseCacheProxy.revert(), delete this._center.userData.inverseCacheProxy), this._center = e, this._center && (this._center.userData.inverseCacheProxy || (this._center.userData.inverseCacheProxy = new zi(this._center.matrixWorld)));
	}
	get initialLocalChildPosition() {
		return this._initialLocalChildPosition;
	}
	get _parentMatrixWorld() {
		return this.bone.parent ? this.bone.parent.matrixWorld : Bi;
	}
	setInitState() {
		this._initialLocalMatrix.copy(this.bone.matrix), this._initialLocalRotation.copy(this.bone.quaternion), this.child ? this._initialLocalChildPosition.copy(this.child.position) : this._initialLocalChildPosition.copy(this.bone.position).normalize().multiplyScalar(.07);
		let e = this._getMatrixWorldToCenter();
		this.bone.localToWorld(this._currentTail.copy(this._initialLocalChildPosition)).applyMatrix4(e), this._prevTail.copy(this._currentTail), this._boneAxis.copy(this._initialLocalChildPosition).normalize();
	}
	reset() {
		this.bone.quaternion.copy(this._initialLocalRotation), this.bone.updateMatrix(), this.bone.matrixWorld.multiplyMatrices(this._parentMatrixWorld, this.bone.matrix);
		let e = this._getMatrixWorldToCenter();
		this.bone.localToWorld(this._currentTail.copy(this._initialLocalChildPosition)).applyMatrix4(e), this._prevTail.copy(this._currentTail);
	}
	update(e) {
		if (e <= 0) return;
		this._calcWorldSpaceBoneLength();
		let t = Hi.copy(this._boneAxis).transformDirection(this._initialLocalMatrix).transformDirection(this._parentMatrixWorld);
		Wi.copy(this._currentTail).add(Vi.subVectors(this._currentTail, this._prevTail).multiplyScalar(1 - this.settings.dragForce)).applyMatrix4(this._getMatrixCenterToWorld()).addScaledVector(t, this.settings.stiffness * e).addScaledVector(this.settings.gravityDir, this.settings.gravityPower * e), Ui.setFromMatrixPosition(this.bone.matrixWorld), Wi.sub(Ui).normalize().multiplyScalar(this._worldSpaceBoneLength).add(Ui), this._collision(Wi), this._prevTail.copy(this._currentTail), this._currentTail.copy(Wi).applyMatrix4(this._getMatrixWorldToCenter());
		let n = Gi.multiplyMatrices(this._parentMatrixWorld, this._initialLocalMatrix).invert();
		this.bone.quaternion.setFromUnitVectors(this._boneAxis, Vi.copy(Wi).applyMatrix4(n).normalize()).premultiply(this._initialLocalRotation), this.bone.updateMatrix(), this.bone.matrixWorld.multiplyMatrices(this._parentMatrixWorld, this.bone.matrix);
	}
	_collision(e) {
		for (let t = 0; t < this.colliderGroups.length; t++) for (let n = 0; n < this.colliderGroups[t].colliders.length; n++) {
			let r = this.colliderGroups[t].colliders[n], i = r.shape.calculateCollision(r.colliderMatrix, e, this.settings.hitRadius, Vi);
			if (i < 0) {
				e.addScaledVector(Vi, -i), e.sub(Ui);
				let t = e.length();
				e.multiplyScalar(this._worldSpaceBoneLength / t).add(Ui);
			}
		}
	}
	_calcWorldSpaceBoneLength() {
		Vi.setFromMatrixPosition(this.bone.matrixWorld), this.child ? Hi.setFromMatrixPosition(this.child.matrixWorld) : (Hi.copy(this._initialLocalChildPosition), Hi.applyMatrix4(this.bone.matrixWorld)), this._worldSpaceBoneLength = Vi.sub(Hi).length();
	}
	_getMatrixCenterToWorld() {
		return this._center ? this._center.matrixWorld : Bi;
	}
	_getMatrixWorldToCenter() {
		return this._center ? this._center.userData.inverseCacheProxy.inverse : Bi;
	}
};
function qi(e, t) {
	let n = [], r = e;
	for (; r !== null;) n.unshift(r), r = r.parent;
	n.forEach((e) => {
		t(e);
	});
}
function Ji(e, t) {
	e.children.forEach((e) => {
		t(e) || Ji(e, t);
	});
}
function Yi(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		let r = n;
		do {
			let n = (t.get(r) ?? 0) + 1;
			if (n === e.size) return r;
			t.set(r, n), r = r.parent;
		} while (r !== null);
	}
	return null;
}
var Xi = class {
	constructor() {
		this._joints = /* @__PURE__ */ new Set(), this._sortedJoints = [], this._hasWarnedCircularDependency = !1, this._ancestors = [], this._objectSpringBonesMap = /* @__PURE__ */ new Map(), this._isSortedJointsDirty = !1, this._relevantChildrenUpdated = this._relevantChildrenUpdated.bind(this);
	}
	get joints() {
		return this._joints;
	}
	get springBones() {
		return console.warn("VRMSpringBoneManager: springBones is deprecated. use joints instead."), this._joints;
	}
	get colliderGroups() {
		let e = /* @__PURE__ */ new Set();
		return this._joints.forEach((t) => {
			t.colliderGroups.forEach((t) => {
				e.add(t);
			});
		}), Array.from(e);
	}
	get colliders() {
		let e = /* @__PURE__ */ new Set();
		return this.colliderGroups.forEach((t) => {
			t.colliders.forEach((t) => {
				e.add(t);
			});
		}), Array.from(e);
	}
	addJoint(e) {
		this._joints.add(e);
		let t = this._objectSpringBonesMap.get(e.bone);
		t ?? (t = /* @__PURE__ */ new Set(), this._objectSpringBonesMap.set(e.bone, t)), t.add(e), this._isSortedJointsDirty = !0;
	}
	addSpringBone(e) {
		console.warn("VRMSpringBoneManager: addSpringBone() is deprecated. use addJoint() instead."), this.addJoint(e);
	}
	deleteJoint(e) {
		this._joints.delete(e), this._objectSpringBonesMap.get(e.bone).delete(e), this._isSortedJointsDirty = !0;
	}
	deleteSpringBone(e) {
		console.warn("VRMSpringBoneManager: deleteSpringBone() is deprecated. use deleteJoint() instead."), this.deleteJoint(e);
	}
	setInitState() {
		this._sortJoints();
		for (let e = 0; e < this._sortedJoints.length; e++) {
			let t = this._sortedJoints[e];
			t.bone.updateMatrix(), t.bone.updateWorldMatrix(!1, !1), t.setInitState();
		}
	}
	reset() {
		this._sortJoints();
		for (let e = 0; e < this._sortedJoints.length; e++) {
			let t = this._sortedJoints[e];
			t.bone.updateMatrix(), t.bone.updateWorldMatrix(!1, !1), t.reset();
		}
	}
	update(e) {
		this._sortJoints();
		for (let e = 0; e < this._ancestors.length; e++) this._ancestors[e].updateWorldMatrix(e === 0, !1);
		for (let t = 0; t < this._sortedJoints.length; t++) {
			let n = this._sortedJoints[t];
			n.bone.updateMatrix(), n.bone.updateWorldMatrix(!1, !1), n.update(e), Ji(n.bone, this._relevantChildrenUpdated);
		}
	}
	_sortJoints() {
		if (!this._isSortedJointsDirty) return;
		let e = [], t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Set();
		for (let i of this._joints) this._insertJointSort(i, t, n, e, r);
		this._sortedJoints = e;
		let i = Yi(r);
		this._ancestors = [], i && (this._ancestors.push(i), Ji(i, (e) => (this._objectSpringBonesMap.get(e)?.size ?? 0) > 0 || (this._ancestors.push(e), !1))), this._isSortedJointsDirty = !1;
	}
	_insertJointSort(e, t, n, r, i) {
		if (n.has(e)) return;
		if (t.has(e)) {
			this._hasWarnedCircularDependency ||= (console.warn("VRMSpringBoneManager: Circular dependency detected"), !0);
			return;
		}
		t.add(e);
		let a = e.dependencies;
		for (let e of a) {
			let a = !1, o = null;
			qi(e, (e) => {
				let s = this._objectSpringBonesMap.get(e);
				if (s) for (let e of s) a = !0, this._insertJointSort(e, t, n, r, i);
				else a || (o = e);
			}), o && i.add(o);
		}
		r.push(e), n.add(e);
	}
	_relevantChildrenUpdated(e) {
		return (this._objectSpringBonesMap.get(e)?.size ?? 0) > 0 || (e.updateWorldMatrix(!1, !1), !1);
	}
}, Zi = "VRMC_springBone_extended_collider", Qi = /* @__PURE__ */ new Set(["1.0", "1.0-beta"]), $i = /* @__PURE__ */ new Set(["1.0"]), ea = class e {
	get name() {
		return e.EXTENSION_NAME;
	}
	constructor(e, t) {
		this.parser = e, this.jointHelperRoot = t?.jointHelperRoot, this.colliderHelperRoot = t?.colliderHelperRoot, this.useExtendedColliders = t?.useExtendedColliders ?? !0;
	}
	afterRoot(e) {
		return gi(this, null, function* () {
			e.userData.vrmSpringBoneManager = yield this._import(e);
		});
	}
	_import(e) {
		return gi(this, null, function* () {
			return (yield this._v1Import(e)) ?? (yield this._v0Import(e)) ?? null;
		});
	}
	_v1Import(t) {
		return gi(this, null, function* () {
			var n;
			let r = t.parser.json;
			if (r.extensionsUsed?.indexOf(e.EXTENSION_NAME) === -1) return null;
			let i = new Xi(), a = yield t.parser.getDependencies("node"), o = r.extensions?.[e.EXTENSION_NAME];
			if (!o) return null;
			let s = o.specVersion;
			if (!Qi.has(s)) return console.warn(`VRMSpringBoneLoaderPlugin: Unknown ${e.EXTENSION_NAME} specVersion "${s}"`), null;
			let c = o.colliders?.map((t, n) => {
				let r = a[t.node];
				if (r == null) return console.warn(`VRMSpringBoneLoaderPlugin: The collider #${n} attempted to reference a node #${t.node} but not found. Skipping the collider`), null;
				let i = t.shape, o = t.extensions?.[Zi];
				if (this.useExtendedColliders && o != null) {
					let t = o.specVersion;
					if (!$i.has(t)) console.warn(`VRMSpringBoneLoaderPlugin: Unknown ${Zi} specVersion "${t}". Fallbacking to the ${e.EXTENSION_NAME} definition`);
					else {
						let e = o.shape;
						if (e.sphere) return this._importSphereCollider(r, {
							offset: new w().fromArray(e.sphere.offset ?? [
								0,
								0,
								0
							]),
							radius: e.sphere.radius ?? 0,
							inside: e.sphere.inside ?? !1
						});
						if (e.capsule) return this._importCapsuleCollider(r, {
							offset: new w().fromArray(e.capsule.offset ?? [
								0,
								0,
								0
							]),
							radius: e.capsule.radius ?? 0,
							tail: new w().fromArray(e.capsule.tail ?? [
								0,
								0,
								0
							]),
							inside: e.capsule.inside ?? !1
						});
						if (e.plane) return this._importPlaneCollider(r, {
							offset: new w().fromArray(e.plane.offset ?? [
								0,
								0,
								0
							]),
							normal: new w().fromArray(e.plane.normal ?? [
								0,
								0,
								1
							])
						});
					}
				}
				if (i.sphere) return this._importSphereCollider(r, {
					offset: new w().fromArray(i.sphere.offset ?? [
						0,
						0,
						0
					]),
					radius: i.sphere.radius ?? 0,
					inside: !1
				});
				if (i.capsule) return this._importCapsuleCollider(r, {
					offset: new w().fromArray(i.capsule.offset ?? [
						0,
						0,
						0
					]),
					radius: i.capsule.radius ?? 0,
					tail: new w().fromArray(i.capsule.tail ?? [
						0,
						0,
						0
					]),
					inside: !1
				});
				console.warn(`VRMSpringBoneLoaderPlugin: The collider #${n} has no valid shape. Skipping the collider`);
			}), l = o.colliderGroups?.map((e, t) => ({
				colliders: (e.colliders ?? []).map((e) => c?.[e] ?? (console.warn(`VRMSpringBoneLoaderPlugin: The collider group #${t} attempted to reference a collider #${e} but not found. Skipping the collider`), null)).filter((e) => e != null),
				name: e.name
			}));
			return (n = o.springs) == null || n.forEach((e, t) => {
				let n = e.joints, r = e.colliderGroups?.map((e) => l?.[e] ?? (console.warn(`VRMSpringBoneLoaderPlugin: The spring #${t} attempted to reference a collider group #${e} but not found. Skipping the collider group`), null)).filter((e) => e != null), o = e.center == null ? void 0 : a[e.center], s;
				n.forEach((e) => {
					if (s) {
						let t = s.node, n = a[t], c = e.node, l = a[c], u = {
							hitRadius: s.hitRadius,
							dragForce: s.dragForce,
							gravityPower: s.gravityPower,
							stiffness: s.stiffness,
							gravityDir: s.gravityDir == null ? void 0 : new w().fromArray(s.gravityDir)
						}, d = this._importJoint(n, l, u, r);
						o && (d.center = o), i.addJoint(d);
					}
					s = e;
				});
			}), i.setInitState(), i;
		});
	}
	_v0Import(e) {
		return gi(this, null, function* () {
			let t = e.parser.json;
			if (t.extensionsUsed?.indexOf("VRM") === -1) return null;
			let n = t.extensions?.VRM?.secondaryAnimation;
			if (!n) return null;
			let r = n?.boneGroups;
			if (!r) return null;
			let i = new Xi(), a = yield e.parser.getDependencies("node"), o = n.colliderGroups?.map((e, t) => {
				let n = a[e.node];
				return n == null ? (console.warn(`VRMSpringBoneLoaderPlugin: The collider group #${t} attempted to reference a node #${e.node} but not found. Skipping the collider group`), null) : { colliders: (e.colliders ?? []).map((e, t) => {
					let r = new w(0, 0, 0);
					return e.offset && r.set(e.offset.x ?? 0, e.offset.y ?? 0, e.offset.z ? -e.offset.z : 0), this._importSphereCollider(n, {
						offset: r,
						radius: e.radius ?? 0,
						inside: !1
					});
				}) };
			});
			return r?.forEach((e, t) => {
				let n = e.bones;
				n && n.forEach((n) => {
					let r = a[n];
					if (r == null) {
						console.warn(`VRMSpringBoneLoaderPlugin: The spring bone group #${t} attempted to reference a node #${n} but not found. Skipping the node`);
						return;
					}
					let s = new w();
					e.gravityDir ? s.set(e.gravityDir.x ?? 0, e.gravityDir.y ?? 0, e.gravityDir.z ?? 0) : s.set(0, -1, 0);
					let c = e.center == null ? void 0 : a[e.center], l = {
						hitRadius: e.hitRadius,
						dragForce: e.dragForce,
						gravityPower: e.gravityPower,
						stiffness: e.stiffiness,
						gravityDir: s
					}, u = e.colliderGroups?.map((e) => o?.[e] ?? (console.warn(`VRMSpringBoneLoaderPlugin: The spring #${t} attempted to reference a collider group #${e} but not found. Skipping the collider group`), null)).filter((e) => e != null);
					r.traverse((e) => {
						let t = e.children[0] ?? null, n = this._importJoint(e, t, l, u);
						c && (n.center = c), i.addJoint(n);
					});
				});
			}), e.scene.updateMatrixWorld(), i.setInitState(), i;
		});
	}
	_importJoint(e, t, n, r) {
		let i = new Ki(e, t, n, r);
		if (this.jointHelperRoot) {
			let e = new Pi(i);
			this.jointHelperRoot.add(e), e.renderOrder = this.jointHelperRoot.renderOrder;
		}
		return i;
	}
	_importSphereCollider(e, t) {
		let n = new Fi(new Ti(t));
		if (e.add(n), this.colliderHelperRoot) {
			let e = new ji(n);
			this.colliderHelperRoot.add(e), e.renderOrder = this.colliderHelperRoot.renderOrder;
		}
		return n;
	}
	_importCapsuleCollider(e, t) {
		let n = new Fi(new bi(t));
		if (e.add(n), this.colliderHelperRoot) {
			let e = new ji(n);
			this.colliderHelperRoot.add(e), e.renderOrder = this.colliderHelperRoot.renderOrder;
		}
		return n;
	}
	_importPlaneCollider(e, t) {
		let n = new Fi(new Ci(t));
		if (e.add(n), this.colliderHelperRoot) {
			let e = new ji(n);
			this.colliderHelperRoot.add(e), e.renderOrder = this.colliderHelperRoot.renderOrder;
		}
		return n;
	}
};
ea.EXTENSION_NAME = "VRMC_springBone";
var ta = ea, na = class {
	get name() {
		return "VRMLoaderPlugin";
	}
	constructor(e, t) {
		this.parser = e;
		let n = t?.helperRoot, r = t?.autoUpdateHumanBones;
		this.expressionPlugin = t?.expressionPlugin ?? new Zt(e), this.firstPersonPlugin = t?.firstPersonPlugin ?? new tn(e), this.humanoidPlugin = t?.humanoidPlugin ?? new xn(e, {
			helperRoot: n,
			autoUpdateHumanBones: r
		}), this.lookAtPlugin = t?.lookAtPlugin ?? new rr(e, { helperRoot: n }), this.metaPlugin = t?.metaPlugin ?? new or(e), this.mtoonMaterialPlugin = t?.mtoonMaterialPlugin ?? new Er(e), this.materialsHDREmissiveMultiplierPlugin = t?.materialsHDREmissiveMultiplierPlugin ?? new kr(e), this.materialsV0CompatPlugin = t?.materialsV0CompatPlugin ?? new Vr(e), this.springBonePlugin = t?.springBonePlugin ?? new ta(e, {
			colliderHelperRoot: n,
			jointHelperRoot: n
		}), this.nodeConstraintPlugin = t?.nodeConstraintPlugin ?? new hi(e, { helperRoot: n });
	}
	beforeRoot() {
		return Mt(this, null, function* () {
			yield this.materialsV0CompatPlugin.beforeRoot(), yield this.mtoonMaterialPlugin.beforeRoot();
		});
	}
	loadMesh(e) {
		return Mt(this, null, function* () {
			return yield this.mtoonMaterialPlugin.loadMesh(e);
		});
	}
	getMaterialType(e) {
		return this.mtoonMaterialPlugin.getMaterialType(e) ?? null;
	}
	extendMaterialParams(e, t) {
		return Mt(this, null, function* () {
			yield this.materialsHDREmissiveMultiplierPlugin.extendMaterialParams(e, t), yield this.mtoonMaterialPlugin.extendMaterialParams(e, t);
		});
	}
	afterRoot(e) {
		return Mt(this, null, function* () {
			yield this.metaPlugin.afterRoot(e), yield this.humanoidPlugin.afterRoot(e), yield this.expressionPlugin.afterRoot(e), yield this.lookAtPlugin.afterRoot(e), yield this.firstPersonPlugin.afterRoot(e), yield this.springBonePlugin.afterRoot(e), yield this.nodeConstraintPlugin.afterRoot(e), yield this.mtoonMaterialPlugin.afterRoot(e);
			let t = e.userData.vrmMeta, n = e.userData.vrmHumanoid;
			if (t && n) {
				let r = new cr({
					scene: e.scene,
					expressionManager: e.userData.vrmExpressionManager,
					firstPerson: e.userData.vrmFirstPerson,
					humanoid: n,
					lookAt: e.userData.vrmLookAt,
					meta: t,
					materials: e.userData.vrmMToonMaterials,
					springBoneManager: e.userData.vrmSpringBoneManager,
					nodeConstraintManager: e.userData.vrmNodeConstraintManager
				});
				e.userData.vrm = r;
			}
		});
	}
};
function ra(e) {
	let t = /* @__PURE__ */ new Set();
	return e.traverse((e) => {
		if (!e.isMesh) return;
		let n = e;
		t.add(n);
	}), t;
}
function ia(e, t, n) {
	if (t.size === 1) {
		let n = t.values().next().value;
		if (n.weight === 1) return e[n.index];
	}
	let r = new Float32Array(e[0].count * 3), i = 0;
	if (n) i = 1;
	else for (let e of t) i += e.weight;
	for (let n of t) {
		let t = e[n.index], a = n.weight / i;
		for (let e = 0; e < t.count; e++) r[e * 3 + 0] += t.getX(e) * a, r[e * 3 + 1] += t.getY(e) * a, r[e * 3 + 2] += t.getZ(e) * a;
	}
	return new E(r, 3);
}
function aa(e) {
	let t = ra(e.scene), n = /* @__PURE__ */ new Map(), r = e.expressionManager?.expressionMap;
	if (r != null) for (let [e, t] of Object.entries(r)) {
		let r = /* @__PURE__ */ new Set();
		for (let i of t.binds) if (i instanceof Gt) {
			if (i.weight !== 0) for (let t of i.primitives) {
				let r = n.get(t);
				r ?? (r = /* @__PURE__ */ new Map(), n.set(t, r));
				let a = r.get(e);
				a ?? (a = /* @__PURE__ */ new Set(), r.set(e, a)), a.add(i);
			}
			r.add(i);
		}
		for (let e of r) t.deleteBind(e);
	}
	for (let e of t) {
		let t = n.get(e);
		if (t == null) continue;
		let i = e.geometry.morphAttributes;
		e.geometry.morphAttributes = {};
		let a = e.geometry.clone();
		e.geometry = a;
		let o = a.morphTargetsRelative, s = i.position != null, c = i.normal != null, l = {}, u = {}, d = [];
		if (s || c) {
			s && (l.position = []), c && (l.normal = []);
			let n = 0;
			for (let [a, f] of t) s && (l.position[n] = ia(i.position, f, o)), c && (l.normal[n] = ia(i.normal, f, o)), r?.[a].addBind(new Gt({
				index: n,
				weight: 1,
				primitives: [e]
			})), u[a] = n, d.push(0), n++;
		}
		a.morphAttributes = l, e.morphTargetDictionary = u, e.morphTargetInfluences = d;
	}
}
function oa(e, t, n) {
	if (e.getComponent) return e.getComponent(t, n);
	{
		let r = e.array[t * e.itemSize + n];
		return e.normalized && (r = le.denormalize(r, e.array)), r;
	}
}
function sa(e, t, n, r) {
	e.setComponent ? e.setComponent(t, n, r) : (e.normalized && (r = le.normalize(r, e.array)), e.array[t * e.itemSize + n] = r);
}
function ca(e) {
	let t = la(e), n = /* @__PURE__ */ new Set();
	for (let e of t) n.has(e.geometry) && (e.geometry = ga(e.geometry)), n.add(e.geometry);
	let r = /* @__PURE__ */ new Map();
	for (let e of n) {
		let t = e.getAttribute("skinIndex"), n = r.get(t) ?? /* @__PURE__ */ new Map();
		r.set(t, n);
		let i = e.getAttribute("skinWeight"), a = ua(t, i);
		n.set(i, a);
	}
	let i = /* @__PURE__ */ new Map();
	for (let e of t) {
		let t = da(e, r);
		i.set(e, t);
	}
	let a = [];
	for (let [e, t] of i) {
		let n = !1;
		for (let r of a) if (fa(t, r.boneInverseMap)) {
			n = !0, r.meshes.add(e);
			for (let [e, n] of t) r.boneInverseMap.set(e, n);
			break;
		}
		n || a.push({
			boneInverseMap: t,
			meshes: /* @__PURE__ */ new Set([e])
		});
	}
	let o = /* @__PURE__ */ new Map(), s = new ha(), c = new ha(), l = new ha();
	for (let e of a) {
		let { boneInverseMap: t, meshes: n } = e, r = Array.from(t.keys()), i = Array.from(t.values()), a = new ae(r, i), u = c.getOrCreate(a);
		for (let e of n) {
			let t = e.geometry.getAttribute("skinIndex"), n = s.getOrCreate(t), i = e.skeleton.bones, a = `${n};${u};${i.map((e) => l.getOrCreate(e)).join(",")}`, c = o.get(a);
			c ?? (c = t.clone(), pa(c, i, r), o.set(a, c)), e.geometry.setAttribute("skinIndex", c);
		}
		for (let e of n) e.bind(a, new C());
	}
}
function la(e) {
	let t = /* @__PURE__ */ new Set();
	return e.traverse((e) => {
		if (!e.isSkinnedMesh) return;
		let n = e;
		t.add(n);
	}), t;
}
function ua(e, t) {
	let n = /* @__PURE__ */ new Set();
	for (let r = 0; r < e.count; r++) for (let i = 0; i < e.itemSize; i++) {
		let a = oa(e, r, i);
		oa(t, r, i) !== 0 && n.add(a);
	}
	return n;
}
function da(e, t) {
	let n = /* @__PURE__ */ new Map(), r = e.skeleton, i = e.geometry, a = i.getAttribute("skinIndex"), o = i.getAttribute("skinWeight"), s = t.get(a)?.get(o);
	if (!s) throw Error("Unreachable. attributeUsedIndexSetMap does not know the skin index attribute or the skin weight attribute.");
	for (let e of s) n.set(r.bones[e], r.boneInverses[e]);
	return n;
}
function fa(e, t) {
	for (let [n, r] of e.entries()) {
		let e = t.get(n);
		if (e != null && !ma(r, e)) return !1;
	}
	return !0;
}
function pa(e, t, n) {
	let r = /* @__PURE__ */ new Map();
	for (let e of t) r.set(e, r.size);
	let i = /* @__PURE__ */ new Map();
	for (let [e, t] of n.entries()) {
		let n = r.get(t);
		i.set(n, e);
	}
	for (let t = 0; t < e.count; t++) for (let n = 0; n < e.itemSize; n++) {
		let r = oa(e, t, n), a = i.get(r);
		sa(e, t, n, a);
	}
	e.needsUpdate = !0;
}
function ma(e, t, n) {
	if (n ||= 1e-4, e.elements.length != t.elements.length) return !1;
	for (let r = 0, i = e.elements.length; r < i; r++) if (Math.abs(e.elements[r] - t.elements[r]) > n) return !1;
	return !0;
}
var ha = class {
	constructor() {
		this._objectIndexMap = /* @__PURE__ */ new Map(), this._index = 0;
	}
	get(e) {
		return this._objectIndexMap.get(e);
	}
	getOrCreate(e) {
		let t = this._objectIndexMap.get(e);
		return t ?? (t = this._index, this._objectIndexMap.set(e, t), this._index++), t;
	}
};
function ga(e) {
	let t = new ce();
	t.name = e.name, t.setIndex(e.index);
	for (let [n, r] of Object.entries(e.attributes)) t.setAttribute(n, r);
	for (let [n, r] of Object.entries(e.morphAttributes)) {
		let e = n;
		t.morphAttributes[e] = r.concat();
	}
	t.morphTargetsRelative = e.morphTargetsRelative, t.groups = [];
	for (let n of e.groups) t.addGroup(n.start, n.count, n.materialIndex);
	return t.boundingSphere = e.boundingSphere?.clone() ?? null, t.boundingBox = e.boundingBox?.clone() ?? null, t.drawRange.start = e.drawRange.start, t.drawRange.count = e.drawRange.count, t.userData = e.userData, t;
}
function _a(e) {
	if (Object.values(e).forEach((e) => {
		e?.isTexture && e.dispose();
	}), e.isShaderMaterial) {
		let t = e.uniforms;
		t && Object.values(t).forEach((e) => {
			let t = e.value;
			t?.isTexture && t.dispose();
		});
	}
	e.dispose();
}
function va(e) {
	let t = e.geometry;
	t && t.dispose();
	let n = e.skeleton;
	n && n.dispose();
	let r = e.material;
	r && (Array.isArray(r) ? r.forEach((e) => _a(e)) : r && _a(r));
}
function ya(e) {
	e.traverse(va);
}
function ba(e, t) {
	console.warn("VRMUtils.removeUnnecessaryJoints: removeUnnecessaryJoints is deprecated. Use combineSkeletons instead. combineSkeletons contributes more to the performance improvement. This function will be removed in the next major version.");
	let n = t?.experimentalSameBoneCounts ?? !1, r = [];
	e.traverse((e) => {
		e.type === "SkinnedMesh" && r.push(e);
	});
	let i = /* @__PURE__ */ new Map(), a = 0;
	for (let e of r) {
		let t = e.geometry.getAttribute("skinIndex");
		if (i.has(t)) continue;
		let n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map();
		for (let e = 0; e < t.count; e++) for (let i = 0; i < t.itemSize; i++) {
			let a = oa(t, e, i), o = n.get(a);
			o ?? (o = n.size, n.set(a, o), r.set(o, a)), sa(t, e, i, o);
		}
		t.needsUpdate = !0, i.set(t, r), a = Math.max(a, n.size);
	}
	for (let e of r) {
		let t = e.geometry.getAttribute("skinIndex"), r = i.get(t), o = [], s = [], c = n ? a : r.size;
		for (let t = 0; t < c; t++) {
			let n = r.get(t) ?? 0;
			o.push(e.skeleton.bones[n]), s.push(e.skeleton.boneInverses[n]);
		}
		let l = new ae(o, s);
		e.bind(l, new C());
	}
}
function xa(e, t) {
	let n = e.position.count, r = Array(n), i = 0, a = t.array;
	for (let e = 0; e < a.length; e++) {
		let t = a[e];
		r[t] || (r[t] = !0, i++);
	}
	return {
		isVertexUsed: r,
		vertexCount: n,
		verticesUsed: i
	};
}
function Sa(e) {
	let t = [], n = [], r = 0;
	for (let i = 0; i < e.length; i++) if (e[i]) {
		let e = r++;
		t[i] = e, n[e] = i;
	}
	return {
		originalIndexNewIndexMap: t,
		newIndexOriginalIndexMap: n
	};
}
function Ca(e, t) {
	t.name = e.name, t.morphTargetsRelative = e.morphTargetsRelative, e.groups.forEach((e) => {
		t.addGroup(e.start, e.count, e.materialIndex);
	}), t.boundingBox = e.boundingBox?.clone() ?? null, t.boundingSphere = e.boundingSphere?.clone() ?? null, t.setDrawRange(e.drawRange.start, e.drawRange.count), t.userData = e.userData;
}
function wa(e, t, n) {
	let r = t.array, i = new r.constructor(r.length);
	for (let e = 0; e < r.length; e++) {
		let t = r[e];
		i[e] = n[t];
	}
	e.setIndex(new E(i, t.itemSize, t.normalized));
}
function Ta(e, t, n) {
	let r = e.constructor, i = new r(t.length * n), a = !0;
	for (let r = 0; r < t.length; r++) {
		let o = t[r] * n, s = r * n;
		for (let t = 0; t < n; t++) {
			let n = e[o + t];
			i[s + t] = n, a &&= n === 0;
		}
	}
	return [i, a];
}
function Ea(e) {
	let t = /* @__PURE__ */ new Map(), n = [];
	for (let [r, i] of Object.entries(e)) if (i.isInterleavedBufferAttribute) {
		let e = i, n = e.data, a = t.get(n) ?? [];
		t.set(n, a), a.push([r, e]);
	} else {
		let e = i;
		n.push([r, e]);
	}
	return [t, n];
}
function Da(e, t, n) {
	let [r, i] = Ea(t);
	for (let [t, i] of r) {
		let r = t.array, { stride: a } = t, [s, c] = Ta(r, n, a), l = new h(s, a);
		l.setUsage(t.usage);
		for (let [t, n] of i) {
			let { itemSize: r, offset: i, normalized: a } = n, s = new o(l, r, i, a);
			e.setAttribute(t, s);
		}
	}
	for (let [t, r] of i) {
		let i = r.array, { itemSize: a, normalized: o } = r, [s, c] = Ta(i, n, a);
		e.setAttribute(t, new E(s, a, o));
	}
}
function Oa(e) {
	let t = /* @__PURE__ */ new Map(), n = [];
	for (let [r, i] of Object.entries(e)) {
		let e = r;
		for (let r = 0; r < i.length; r++) {
			let a = i[r];
			if (a.isInterleavedBufferAttribute) {
				let n = a, i = n.data, o = t.get(i) ?? [];
				t.set(i, o), o.push([
					e,
					r,
					n
				]);
			} else {
				let t = a;
				n.push([
					e,
					r,
					t
				]);
			}
		}
	}
	return [t, n];
}
function ka(e, t, n) {
	let r = !0, [i, a] = Oa(t), s = {};
	for (let [e, t] of i) {
		let i = e.array, { stride: a } = e, [c, l] = Ta(i, n, a);
		r &&= l;
		let u = new h(c, a);
		u.setUsage(e.usage);
		for (let [e, n, r] of t) {
			let { itemSize: t, offset: i, normalized: a } = r, c = new o(u, t, i, a);
			s[e] ?? (s[e] = []), s[e][n] = c;
		}
	}
	for (let [e, t, i] of a) {
		let a = i, o = a.array, { itemSize: c, normalized: l } = a, [u, d] = Ta(o, n, c);
		r &&= d, s[e] ?? (s[e] = []), s[e][t] = new E(u, c, l);
	}
	e.morphAttributes = r ? {} : s;
}
function Aa(e) {
	let t = /* @__PURE__ */ new Map();
	e.traverse((e) => {
		if (!e.isMesh) return;
		let n = e, r = n.geometry, i = r.index;
		if (i == null) return;
		let a = t.get(r);
		if (a != null) {
			n.geometry = a;
			return;
		}
		let { isVertexUsed: o, vertexCount: s, verticesUsed: c } = xa(r.attributes, i);
		if (c === s) return;
		let { originalIndexNewIndexMap: l, newIndexOriginalIndexMap: u } = Sa(o), d = new ce();
		Ca(r, d), t.set(r, d), wa(d, i, l), Da(d, r.attributes, u), ka(d, r.morphAttributes, u), n.geometry = d;
	}), Array.from(t.keys()).forEach((e) => {
		e.dispose();
	});
}
function ja(e) {
	e.meta?.metaVersion === "0" && (e.scene.rotation.y = Math.PI);
}
var Ma = class {
	constructor() {}
};
Ma.combineMorphs = aa, Ma.combineSkeletons = ca, Ma.deepDispose = ya, Ma.removeUnnecessaryJoints = ba, Ma.removeUnnecessaryVertices = Aa, Ma.rotateVRM0 = ja;
//#endregion
//#region ../avatar/src/stage.ts
var Na = [
	{
		id: "hair",
		label: "Hair",
		test: /hair/i
	},
	{
		id: "eyes",
		label: "Eyes",
		test: /eye_?iris|iris/i
	},
	{
		id: "skin",
		label: "Skin",
		test: /skin|^body|^face_00/i
	},
	{
		id: "top",
		label: "Top",
		test: /tops?|shirt|jacket|onepiece|dress/i
	},
	{
		id: "bottom",
		label: "Bottom",
		test: /bottoms?|skirt|pants|shorts/i
	},
	{
		id: "shoes",
		label: "Shoes",
		test: /shoes?|boots?|socks?/i
	},
	{
		id: "accessory",
		label: "Accessories",
		test: /accessor|acc_|ribbon|hat/i
	}
], Pa = 30, Fa = /* @__PURE__ */ new WeakMap();
function Ia(e) {
	let t = e.map, n = t?.image;
	if (!t || !n) return new D(1, 1, 1);
	let r = Fa.get(t);
	if (r) return r;
	let i = document.createElement("canvas");
	i.width = i.height = 32;
	let a = i.getContext("2d", { willReadFrequently: !0 }), o = new D(1, 1, 1);
	try {
		a?.drawImage(n, 0, 0, 32, 32);
		let e = a?.getImageData(0, 0, 32, 32).data;
		if (e) {
			let t = 0, n = 0, r = 0, i = 0, a = new D();
			for (let o = 0; o < e.length; o += 4) {
				let s = e[o + 3] / 255;
				s < .5 || (a.setRGB(e[o] / 255, e[o + 1] / 255, e[o + 2] / 255, v), t += a.r * s, n += a.g * s, r += a.b * s, i += s);
			}
			i > 0 && (o = new D(t / i, n / i, r / i));
		}
	} catch {}
	return Fa.set(t, o), o;
}
var La = class {
	container;
	options;
	canvas;
	renderer;
	scene = new _();
	camera = new f(24, 1, .05, 50);
	vrm = null;
	pose = {
		expressions: {},
		bones: {}
	};
	framing = "bust";
	host;
	frame = 0;
	last = performance.now();
	resize;
	onFrame = null;
	backdropTexture = null;
	constructor(e, t = {}) {
		this.container = e, this.options = t, this.host = e.ownerDocument.defaultView ?? window, this.renderer = new De({
			antialias: !0,
			alpha: !0,
			preserveDrawingBuffer: !0
		}), this.renderer.setPixelRatio(t.manual ? 1 : Math.min(this.host.devicePixelRatio || 1, 2)), this.renderer.outputColorSpace = v, this.renderer.setClearColor(0, 0), this.canvas = this.renderer.domElement, Object.assign(this.canvas.style, {
			display: "block",
			width: "100%",
			height: "100%"
		}), e.appendChild(this.canvas);
		let n = new T(16777215, 2.2);
		n.position.set(.6, 1.4, 1.6);
		let r = new T(16777215, .6);
		r.position.set(-1, .5, 1), this.scene.add(n, r, new re(16777215, .6)), this.resize = new ResizeObserver(() => this.fit()), !t.manual && (this.resize.observe(e), this.fit(), this.loop());
	}
	renderFrame(e, t, n, r) {
		let i = this.renderer.getSize(new te());
		return (i.x !== n || i.y !== r) && (this.renderer.setSize(n, r, !1), this.camera.aspect = n / r, this.camera.updateProjectionMatrix(), this.frameCamera()), this.pose = e, this.apply(e), this.vrm?.update(t), this.renderer.render(this.scene, this.camera), this.canvas;
	}
	async load(e) {
		let t = new ke();
		t.register((e) => new na(e));
		let n = typeof e == "string" ? await t.loadAsync(e) : await t.parseAsync(e, ""), r = n.userData.vrm;
		if (!r) throw Error("That file is not a VRM avatar (export one from VRoid Studio as .vrm).");
		return Ma.removeUnnecessaryVertices(n.scene), Ma.combineSkeletons(n.scene), Ma.rotateVRM0(r), r.scene.traverse((e) => e.frustumCulled = !1), this.vrm && (this.scene.remove(this.vrm.scene), Ma.deepDispose(this.vrm.scene)), this.vrm = r, this.scene.add(r.scene), r.lookAt && (r.lookAt.autoUpdate = !1), this.frameCamera(), this.info(r);
	}
	info(e) {
		let t = e.meta, n = t.metaVersion === "1", r = n ? t.commercialUsage : t.commercialUssageName, i = n ? t.avatarPermission : t.allowedUserName;
		return {
			name: String(t.name ?? t.title ?? "Avatar"),
			authors: n ? t.authors ?? [] : t.author ? [String(t.author)] : [],
			licenceUrl: (n ? t.licenseUrl : t.otherLicenseUrl) || null,
			avatarPermission: i ?? null,
			commercialUse: r ?? null,
			allowsCommercial: r === "corporation" || r === "personalProfit" || r === "Allow",
			parts: this.parts(e),
			version: n ? "1" : "0"
		};
	}
	parts(e) {
		let t = /* @__PURE__ */ new Map();
		return e.scene.traverse((e) => {
			let n = e.material;
			for (let e of Array.isArray(n) ? n : n ? [n] : []) {
				let n = Na.find((t) => t.test.test(e.name));
				if (n && !t.has(n.id) && e.color) {
					let r = e.color.clone().multiply(Ia(e));
					t.set(n.id, {
						id: n.id,
						label: n.label,
						colour: `#${r.getHexString()}`
					});
				}
			}
		}), Na.filter((e) => t.has(e.id)).map((e) => t.get(e.id));
	}
	recolour(e, t) {
		let n = Na.find((t) => t.id === e);
		if (!this.vrm || !n) return;
		let r = new D(t);
		this.vrm.scene.traverse((e) => {
			let t = e.material;
			for (let e of Array.isArray(t) ? t : t ? [t] : []) {
				if (!n.test.test(e.name) || !e.color) continue;
				let t = e.color.clone(), i = Ia(e), a = new D(Math.min(Pa, r.r / Math.max(.01, i.r)), Math.min(Pa, r.g / Math.max(.01, i.g)), Math.min(Pa, r.b / Math.max(.01, i.b)));
				e.color.copy(a);
				let o = e.shadeColorFactor;
				if (o) {
					let e = (o.r + o.g + o.b) / Math.max(.001, t.r + t.g + t.b);
					o.copy(a).multiplyScalar(Math.min(1, e));
				}
			}
		});
	}
	setPose(e) {
		this.pose = e;
	}
	drive(e) {
		this.onFrame = e;
	}
	setFraming(e) {
		this.framing = e, this.frameCamera();
	}
	setBackdrop(e) {
		this.backdropTexture?.dispose(), this.backdropTexture = null, this.scene.background = null, e.kind === "colour" ? this.scene.background = new D(e.colour) : e.kind === "picture" && new se().load(e.url, (e) => {
			e.colorSpace = v, this.backdropTexture = e, this.scene.background = e, this.fitBackdrop();
		});
	}
	attach(e) {
		let t = e ?? this.container;
		this.resize.unobserve(this.container), this.container = t, t.appendChild(this.canvas), this.host = t.ownerDocument.defaultView ?? window, this.resize.observe(t), this.host.cancelAnimationFrame(this.frame), this.frame = 0, this.fit(), this.loop();
	}
	snapshot() {
		return new Promise((e, t) => this.canvas.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("No picture.")), "image/png"));
	}
	frameCamera() {
		let e = this.vrm;
		e?.scene.updateMatrixWorld(!0);
		let t = e?.humanoid.getNormalizedBoneNode("head"), n = t ? t.getWorldPosition(new w()).y : 1.4, [r, i] = this.framing === "face" ? [.38, n + .02] : this.framing === "bust" ? [.85, n - .2] : [n * 1.25, n * .55], a = r / 2 / Math.tan(this.camera.fov / 2 * Math.PI / 180);
		this.camera.position.set(0, i, a), this.camera.lookAt(0, i, 0);
	}
	fit() {
		let e = Math.max(1, this.container.clientWidth), t = Math.max(1, this.container.clientHeight);
		this.renderer.setSize(e, t, !1), this.camera.aspect = e / t, this.camera.updateProjectionMatrix(), this.fitBackdrop();
	}
	fitBackdrop() {
		let e = this.backdropTexture, t = e?.image;
		if (!e || !t?.width || !t.height) return;
		let n = this.camera.aspect, r = t.width / t.height;
		e.matrixAutoUpdate = !1;
		let [i, a] = n > r ? [1, r / n] : [n / r, 1];
		e.matrix.setUvTransform((1 - i) / 2, (1 - a) / 2, i, a, 0, 0, 0);
	}
	apply(e) {
		let t = this.vrm;
		if (!t) return;
		let n = t.humanoid;
		n.resetNormalizedPose();
		for (let [t, r] of Object.entries(e.bones)) {
			let e = n.getNormalizedBoneNode(t);
			e && e.quaternion.set(r[0], r[1], r[2], r[3]);
		}
		let r = t.expressionManager;
		if (r) for (let t of et) r.setValue(t, e.expressions[t] ?? 0);
		t.lookAt && e.lookAt && (t.lookAt.yaw = e.lookAt.yaw, t.lookAt.pitch = e.lookAt.pitch);
	}
	loop = () => {
		this.frame = this.host.requestAnimationFrame(this.loop);
		let e = performance.now(), t = Math.min(.1, (e - this.last) / 1e3);
		this.last = e;
		let n = this.onFrame?.(e);
		n && (this.pose = n), this.apply(this.pose), this.vrm?.update(t), this.renderer.render(this.scene, this.camera);
	};
	dispose() {
		this.host.cancelAnimationFrame(this.frame), this.resize.disconnect(), this.vrm && Ma.deepDispose(this.vrm.scene), this.backdropTexture?.dispose(), this.renderer.dispose(), this.canvas.remove();
	}
}, Ra = typeof self < "u" ? self : {};
function za(e, t) {
	t: {
		for (var n = ["CLOSURE_FLAGS"], r = Ra, i = 0; i < n.length; i++) if ((r = r[n[i]]) == null) {
			n = null;
			break t;
		}
		n = r;
	}
	return (e = n && n[e]) ?? t;
}
function M(e, t) {
	e = e.split(".");
	for (var n, r = Ra; e.length && (n = e.shift());) e.length || t === void 0 ? r = r[n] && r[n] !== Object.prototype[n] ? r[n] : r[n] = {} : r[n] = t;
}
function Ba() {
	throw Error("Invalid UTF8");
}
function Va(e, t) {
	return t = String.fromCharCode.apply(null, t), e == null ? t : e + t;
}
var Ha, Ua, Wa = void 0, Ga = typeof TextDecoder < "u", Ka = typeof TextEncoder < "u";
function qa(e) {
	if (Ka) e = (Ua ||= new TextEncoder()).encode(e);
	else {
		let n = 0, r = new Uint8Array(3 * e.length);
		for (let i = 0; i < e.length; i++) {
			var t = e.charCodeAt(i);
			if (t < 128) r[n++] = t;
			else {
				if (t < 2048) r[n++] = t >> 6 | 192;
				else {
					if (t >= 55296 && t <= 57343) {
						if (t <= 56319 && i < e.length) {
							let a = e.charCodeAt(++i);
							if (a >= 56320 && a <= 57343) {
								t = 1024 * (t - 55296) + a - 56320 + 65536, r[n++] = t >> 18 | 240, r[n++] = t >> 12 & 63 | 128, r[n++] = t >> 6 & 63 | 128, r[n++] = 63 & t | 128;
								continue;
							}
							i--;
						}
						t = 65533;
					}
					r[n++] = t >> 12 | 224, r[n++] = t >> 6 & 63 | 128;
				}
				r[n++] = 63 & t | 128;
			}
		}
		e = n === r.length ? r : r.subarray(0, n);
	}
	return e;
}
function Ja(e) {
	Ra.setTimeout(() => {
		throw e;
	}, 0);
}
var Ya = za(610401301, !1), Xa = za(748402147, !0);
function Za() {
	var e = Ra.navigator;
	return (e &&= e.userAgent) ? e : "";
}
var Qa, $a = Ra.navigator;
function eo(e) {
	return eo[" "](e), e;
}
Qa = $a && $a.userAgentData || null, eo[" "] = function() {};
var to = {}, no = null;
function ro(e) {
	var t = e.length, n = 3 * t / 4;
	n % 3 ? n = Math.floor(n) : "=.".indexOf(e[t - 1]) != -1 && (n = "=.".indexOf(e[t - 2]) == -1 ? n - 1 : n - 2);
	var r = new Uint8Array(n), i = 0;
	return function(e, t) {
		function n(t) {
			for (; r < e.length;) {
				let t = e.charAt(r++), n = no[t];
				if (n != null) return n;
				if (!/^[\s\xa0]*$/.test(t)) throw Error("Unknown base64 encoding at char: " + t);
			}
			return t;
		}
		io();
		for (var r = 0;;) {
			let e = n(-1), r = n(0), i = n(64), a = n(64);
			if (a === 64 && e === -1) break;
			t(e << 2 | r >> 4), i != 64 && (t(r << 4 & 240 | i >> 2), a != 64 && t(i << 6 & 192 | a));
		}
	}(e, function(e) {
		r[i++] = e;
	}), i === n ? r : r.subarray(0, i);
}
function io() {
	if (!no) {
		no = {};
		var e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), t = [
			"+/=",
			"+/",
			"-_=",
			"-_.",
			"-_"
		];
		for (let n = 0; n < 5; n++) {
			let r = e.concat(t[n].split(""));
			to[n] = r;
			for (let e = 0; e < r.length; e++) {
				let t = r[e];
				no[t] === void 0 && (no[t] = e);
			}
		}
	}
}
var ao = typeof Uint8Array < "u", oo = (!!(Ya && Qa && Qa.brands.length > 0) || Za().indexOf("Trident") == -1 && Za().indexOf("MSIE") == -1) && typeof btoa == "function", so = /[-_.]/g, co = {
	"-": "+",
	_: "/",
	".": "="
};
function lo(e) {
	return co[e] || "";
}
function uo(e) {
	if (!oo) return ro(e);
	e = so.test(e) ? e.replace(so, lo) : e, e = atob(e);
	var t = new Uint8Array(e.length);
	for (let n = 0; n < e.length; n++) t[n] = e.charCodeAt(n);
	return t;
}
function fo(e) {
	return ao && e != null && e instanceof Uint8Array;
}
var po = {};
function mo() {
	return go ||= new _o(null, po);
}
function ho(e) {
	vo(po);
	var t = e.h;
	return (t = t == null || fo(t) ? t : typeof t == "string" ? uo(t) : null) == null ? t : e.h = t;
}
var go, _o = class {
	i() {
		return new Uint8Array(ho(this) || 0);
	}
	constructor(e, t) {
		if (vo(t), this.h = e, e != null && e.length === 0) throw Error("ByteString should be constructed with non-empty values");
	}
};
function vo(e) {
	if (e !== po) throw Error("illegal external caller");
}
function yo(e, t) {
	e.__closure__error__context__984382 ||= {}, e.__closure__error__context__984382.severity = t;
}
var bo = void 0;
function xo(e) {
	return yo(e = Error(e), "warning"), e;
}
function So(e, t) {
	if (e != null) {
		var n = bo ??= {}, r = n[e] || 0;
		r >= t || (n[e] = r + 1, yo(e = Error(), "incident"), Ja(e));
	}
}
function Co() {
	return typeof BigInt == "function";
}
var wo = typeof Symbol == "function" && typeof Symbol() == "symbol";
function To(e, t, n = !1) {
	return typeof Symbol == "function" && typeof Symbol() == "symbol" ? n && Symbol.for && e ? Symbol.for(e) : e == null ? Symbol() : Symbol(e) : t;
}
var Eo, Do = To("jas", void 0, !0), Oo = To(void 0, "0di"), ko = To(void 0, "1oa"), Ao = To(void 0, Symbol()), jo = To(void 0, "0ub"), Mo = To(void 0, "0ubs"), No = To(void 0, "0ubsb"), Po = To(void 0, "0actk"), Fo = To("m_m", "lb", !0), Io = To(), Lo = { Wa: {
	value: 0,
	configurable: !0,
	writable: !0,
	enumerable: !1
} }, Ro = Object.defineProperties, N = wo ? Do : "Wa", zo = [];
function Bo(e, t) {
	wo || N in e || Ro(e, Lo), e[N] |= t;
}
function Vo(e, t) {
	wo || N in e || Ro(e, Lo), e[N] = t;
}
function Ho(e) {
	return Bo(e, 34), e;
}
function Uo(e) {
	return Bo(e, 8192), e;
}
Vo(zo, 7), Eo = Object.freeze(zo);
var Wo = {};
function Go(e) {
	return e != null && e[Fo] === Wo;
}
function Ko(e, t) {
	return t === void 0 ? e.i !== qo && !!(2 & e.B[N]) : !!(2 & t) && e.i !== qo;
}
var qo = {};
function Jo(e, t) {
	if (e != null) {
		if (typeof e == "string") e = e ? new _o(e, po) : mo();
		else if (e.constructor !== _o) {
			if (fo(e)) e = e.length ? new _o(new Uint8Array(e), po) : mo();
			else {
				if (!t) throw Error();
				e = void 0;
			}
		}
	}
	return e;
}
var Yo = class {
	constructor(e, t, n) {
		this.h = e, this.i = t, this.l = n;
	}
	next() {
		var e = this.h.next();
		return e.done || (e.value = this.i.call(this.l, e.value)), e;
	}
	[Symbol.iterator]() {
		return this;
	}
};
function Xo(e, t, n) {
	var r, i = 128 & t ? 0 : -1, a = e.length;
	(r = !!a) && (r = (r = e[a - 1]) != null && typeof r == "object" && r.constructor === Object);
	var o = a + (r ? -1 : 0);
	for (t = 128 & t ? 1 : 0; t < o; t++) n(t - i, e[t]);
	if (r) {
		e = e[a - 1];
		for (let t in e) !isNaN(t) && n(+t, e[t]);
	}
}
Object.freeze({});
var Zo = {};
function Qo(e) {
	return 128 & e ? Zo : void 0;
}
function $o(e) {
	return e.jb = !0, e;
}
var es = $o((e) => typeof e == "number"), ts = $o((e) => typeof e == "string"), ns = $o((e) => typeof e == "boolean"), rs = typeof Ra.BigInt == "function" && typeof Ra.BigInt(0) == "bigint";
function is(e) {
	var t = e;
	if (ts(t)) {
		if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(t)) throw Error(String(t));
	} else if (es(t) && !Number.isSafeInteger(t)) throw Error(String(t));
	return rs ? BigInt(e) : e = ns(e) ? e ? "1" : "0" : ts(e) ? e.trim() || "0" : String(e);
}
var as = $o((e) => rs ? e >= ss && e <= ls : e[0] === "-" ? us(e, os) : us(e, cs)), os = (-(2 ** 53 - 1)).toString(), ss = rs ? BigInt(-(2 ** 53 - 1)) : void 0, cs = (2 ** 53 - 1).toString(), ls = rs ? BigInt(2 ** 53 - 1) : void 0;
function us(e, t) {
	if (e.length > t.length) return !1;
	if (e.length < t.length || e === t) return !0;
	for (let n = 0; n < e.length; n++) {
		let r = e[n], i = t[n];
		if (r > i) return !1;
		if (r < i) return !0;
	}
}
var ds, fs = typeof Uint8Array.prototype.slice == "function", P = 0, F = 0;
function ps(e) {
	var t = e >>> 0;
	P = t, F = (e - t) / 4294967296 >>> 0;
}
function ms(e) {
	if (e < 0) {
		ps(-e);
		let [t, n] = Cs(P, F);
		P = t >>> 0, F = n >>> 0;
	} else ps(e);
}
function hs(e) {
	var t = ds ||= /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(8));
	t.setFloat32(0, +e, !0), F = 0, P = t.getUint32(0, !0);
}
function gs(e, t) {
	var n = 4294967296 * t + (e >>> 0);
	return Number.isSafeInteger(n) ? n : ys(e, t);
}
function _s(e, t) {
	return is(Co() ? BigInt.asUintN(64, (BigInt(t >>> 0) << BigInt(32)) + BigInt(e >>> 0)) : ys(e, t));
}
function vs(e, t) {
	return Co() ? is(BigInt.asIntN(64, (BigInt.asUintN(32, BigInt(t)) << BigInt(32)) + BigInt.asUintN(32, BigInt(e)))) : is(xs(e, t));
}
function ys(e, t) {
	if (e >>>= 0, (t >>>= 0) <= 2097151) var n = "" + (4294967296 * t + e);
	else Co() ? n = "" + (BigInt(t) << BigInt(32) | BigInt(e)) : (e = (16777215 & e) + 6777216 * (n = 16777215 & (e >>> 24 | t << 8)) + 6710656 * (t = t >> 16 & 65535), n += 8147497 * t, t *= 2, e >= 1e7 && (n += e / 1e7 >>> 0, e %= 1e7), n >= 1e7 && (t += n / 1e7 >>> 0, n %= 1e7), n = t + bs(n) + bs(e));
	return n;
}
function bs(e) {
	return e = String(e), "0000000".slice(e.length) + e;
}
function xs(e, t) {
	if (2147483648 & t) {
		if (Co()) e = "" + (BigInt(0 | t) << BigInt(32) | BigInt(e >>> 0));
		else {
			let [n, r] = Cs(e, t);
			e = "-" + ys(n, r);
		}
	} else e = ys(e, t);
	return e;
}
function Ss(e) {
	if (e.length < 16) ms(Number(e));
	else if (Co()) e = BigInt(e), P = Number(e & BigInt(4294967295)) >>> 0, F = Number(e >> BigInt(32) & BigInt(4294967295));
	else {
		let t = +(e[0] === "-");
		F = P = 0;
		let n = e.length;
		for (let r = t, i = (n - t) % 6 + t; i <= n; r = i, i += 6) {
			let t = Number(e.slice(r, i));
			F *= 1e6, (P = 1e6 * P + t) >= 4294967296 && (F += Math.trunc(P / 4294967296), F >>>= 0, P >>>= 0);
		}
		if (t) {
			let [e, t] = Cs(P, F);
			P = e, F = t;
		}
	}
}
function Cs(e, t) {
	return t = ~t, e ? e = 1 + ~e : t += 1, [e, t];
}
function ws(e) {
	return Array.prototype.slice.call(e);
}
var Ts = typeof BigInt == "function" ? BigInt.asIntN : void 0, Es = typeof BigInt == "function" ? BigInt.asUintN : void 0, Ds = Number.isSafeInteger, Os = Number.isFinite, ks = Math.trunc, As = is(0);
function js(e) {
	if (typeof e != "number") throw Error(`Value of float/double field must be a number, found ${typeof e}: ${e}`);
	return e;
}
function Ms(e) {
	return e == null || typeof e == "number" ? e : e === "NaN" || e === "Infinity" || e === "-Infinity" ? Number(e) : void 0;
}
function Ns(e) {
	if (typeof e != "boolean") {
		var t = typeof e;
		throw Error(`Expected boolean but got ${t == "object" ? e ? Array.isArray(e) ? "array" : t : "null" : t}: ${e}`);
	}
	return e;
}
var Ps = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
function Fs(e) {
	switch (typeof e) {
		case "bigint": return !0;
		case "number": return Os(e);
		case "string": return Ps.test(e);
		default: return !1;
	}
}
function Is(e) {
	if (e != null) {
		if (!Os(e)) throw xo("enum");
		e |= 0;
	}
	return e;
}
function Ls(e) {
	if (e == null) return e;
	if (typeof e == "string" && e) e = +e;
	else if (typeof e != "number") return;
	return Os(e) ? 0 | e : void 0;
}
function Rs(e) {
	if (e == null) return e;
	if (typeof e == "string" && e) e = +e;
	else if (typeof e != "number") return;
	return Os(e) ? e >>> 0 : void 0;
}
function zs(e, t) {
	if (t ??= 1024, !Fs(e)) throw xo("int64");
	var n = typeof e;
	switch (t) {
		case 512: switch (n) {
			case "string": return Ws(e);
			case "bigint": return String(Ts(64, e));
			default: return Us(e);
		}
		case 1024: switch (n) {
			case "string": return Gs(e);
			case "bigint": return is(Ts(64, e));
			default: return is(Ds(e) ? e : Us(e));
		}
		case 0: switch (n) {
			case "string": return Ws(e);
			case "bigint": return is(Ts(64, e));
			default: return Hs(e);
		}
		default: return function(e, t = `unexpected value ${e}!`) {
			throw Error(t);
		}(t, "Unknown format requested type for int64");
	}
}
function Bs(e) {
	var t = e.length;
	return (e[0] === "-" ? t < 20 || t === 20 && e <= "-9223372036854775808" : t < 19 || t === 19 && e <= "9223372036854775807") ? e : (Ss(e), xs(P, F));
}
function Vs(e) {
	if (e[0] === "-") var t = !1;
	else t = (t = e.length) < 20 || t === 20 && e <= "18446744073709551615";
	return t ? e : (Ss(e), ys(P, F));
}
function Hs(e) {
	if (e = ks(e), !Ds(e)) {
		ms(e);
		var t = P, n = F;
		(e = 2147483648 & n) && (n = ~n >>> 0, (t = 1 + ~t >>> 0) == 0 && (n = n + 1 >>> 0)), e = typeof (t = gs(t, n)) == "number" ? e ? -t : t : e ? "-" + t : t;
	}
	return e;
}
function Us(e) {
	return e = ks(e), Ds(e) ? e = String(e) : (ms(e), e = xs(P, F)), e;
}
function Ws(e) {
	var t = ks(Number(e));
	return Ds(t) ? String(t) : ((t = e.indexOf(".")) !== -1 && (e = e.substring(0, t)), Bs(e));
}
function Gs(e) {
	var t = ks(Number(e));
	return Ds(t) ? is(t) : ((t = e.indexOf(".")) !== -1 && (e = e.substring(0, t)), Co() ? is(Ts(64, BigInt(e))) : is(Bs(e)));
}
function Ks(e) {
	var t = typeof e;
	return e == null ? e : t === "bigint" ? is(Ts(64, e)) : Fs(e) ? t === "string" ? Gs(e) : is(Ds(e) ? e : Us(e)) : void 0;
}
function qs(e) {
	if (e == null) return e;
	var t = typeof e;
	if (t === "bigint") return String(Ts(64, e));
	if (Fs(e)) {
		if (t === "string") return Ws(e);
		if (t === "number") return Hs(e);
	}
}
function Js(e) {
	if (e == null) return e;
	var t = typeof e;
	if (t === "bigint") return String(Es(64, e));
	if (Fs(e)) {
		if (t === "string") return t = ks(Number(e)), Ds(t) && t >= 0 ? e = String(t) : ((t = e.indexOf(".")) !== -1 && (e = e.substring(0, t)), e = Vs(e)), e;
		if (t === "number") return function(e) {
			return (e = ks(e)) >= 0 && Ds(e) || (ms(e), e = gs(P, F)), e;
		}(e);
	}
}
function Ys(e) {
	if (e == null || typeof e == "string" || e instanceof _o) return e;
}
function Xs(e) {
	if (typeof e != "string") throw Error();
	return e;
}
function Zs(e) {
	if (e != null && typeof e != "string") throw Error();
	return e;
}
function Qs(e) {
	return e == null || typeof e == "string" ? e : void 0;
}
function $s(e, t, n, r) {
	return Go(e) ? e : Array.isArray(e) ? ((r = (n = 0 | e[N]) | 32 & r | 2 & r) !== n && Vo(e, r), new t(e)) : (n ? 2 & r ? ((e = t[Oo]) || (Ho((e = new t()).B), e = t[Oo] = e), t = e) : t = new t() : t = void 0, t);
}
function ec(e, t, n) {
	return t ? zs(e, 1024) : Ks(e) ?? (n ? As : void 0);
}
function tc(e) {
	return e;
}
var nc = {}, rc = function() {
	try {
		return eo(new class extends Map {
			constructor() {
				super();
			}
		}()), !1;
	} catch {
		return !0;
	}
}(), ic = class {
	constructor() {
		this.h = /* @__PURE__ */ new Map();
	}
	get(e) {
		return this.h.get(e);
	}
	set(e, t) {
		return this.h.set(e, t), this.size = this.h.size, this;
	}
	delete(e) {
		return e = this.h.delete(e), this.size = this.h.size, e;
	}
	clear() {
		this.h.clear(), this.size = this.h.size;
	}
	has(e) {
		return this.h.has(e);
	}
	entries() {
		return this.h.entries();
	}
	keys() {
		return this.h.keys();
	}
	values() {
		return this.h.values();
	}
	forEach(e, t) {
		return this.h.forEach(e, t);
	}
	[Symbol.iterator]() {
		return this.entries();
	}
}, ac = rc ? (Object.setPrototypeOf(ic.prototype, Map.prototype), Object.defineProperties(ic.prototype, { size: {
	value: 0,
	configurable: !0,
	enumerable: !0,
	writable: !0
} }), ic) : class extends Map {
	constructor() {
		super();
	}
};
function oc(e) {
	return e;
}
function sc(e) {
	if (2 & e.N) throw Error("Cannot mutate an immutable Map");
}
var cc, lc = class extends ac {
	constructor(e, t, n = oc, r = oc) {
		super(), this.N = 0 | e[N], this.O = t, this.ca = n, this.oa = this.O ? uc : r;
		for (let i = 0; i < e.length; i++) {
			let a = e[i], o = n(a[0], !1, !0), s = a[1];
			t ? s === void 0 && (s = null) : s = r(a[1], !1, !0, void 0, void 0, this.N), super.set(o, s);
		}
	}
	fa(e) {
		return Uo(Array.from(super.entries(), e));
	}
	clear() {
		sc(this), super.clear();
	}
	delete(e) {
		return sc(this), super.delete(this.ca(e, !0, !1));
	}
	entries() {
		if (this.O) {
			var e = super.keys();
			e = new Yo(e, dc, this);
		} else e = super.entries();
		return e;
	}
	values() {
		if (this.O) {
			var e = super.keys();
			e = new Yo(e, lc.prototype.get, this);
		} else e = super.values();
		return e;
	}
	forEach(e, t) {
		this.O ? super.forEach((n, r, i) => {
			e.call(t, i.get(r), r, i);
		}) : super.forEach(e, t);
	}
	set(e, t) {
		return sc(this), (e = this.ca(e, !0, !1)) == null ? this : t == null ? (super.delete(e), this) : super.set(e, this.oa(t, !0, !0, this.O, !1, this.N));
	}
	hb(e) {
		var t = this.ca(e[0], !1, !0);
		e = e[1], e = this.O ? e === void 0 ? null : e : this.oa(e, !1, !0, void 0, !1, this.N), super.set(t, e);
	}
	has(e) {
		return super.has(this.ca(e, !1, !1));
	}
	get(e) {
		e = this.ca(e, !1, !1);
		var t = super.get(e);
		if (t !== void 0) {
			var n = this.O;
			return n ? ((n = this.oa(t, !1, !0, n, this.Ga, this.N)) !== t && super.set(e, n), n) : t;
		}
	}
	[Symbol.iterator]() {
		return this.entries();
	}
};
function uc(e, t, n, r, i, a) {
	return e = $s(e, r, n, a), i && (e = jc(e)), e;
}
function dc(e) {
	return [e, this.get(e)];
}
function fc() {
	return cc ||= new lc(Ho([]), void 0, void 0, void 0, nc);
}
function pc(e) {
	return Ao ? e[Ao] : void 0;
}
function mc(e, t) {
	for (let n in e) !isNaN(n) && t(e, +n, e[n]);
}
lc.prototype.toJSON = void 0;
var hc, gc, _c = class {}, vc = { eb: !0 };
function yc(e, t) {
	t < 100 || So(Mo, 1);
}
function bc(e, t, n, r) {
	var i = r !== void 0;
	r = !!r;
	var a, o = Ao;
	!i && wo && o && (a = e[o]) && mc(a, yc), o = [];
	var s = e.length;
	a = 4294967295;
	var c = !1, l = !!(64 & t), u = l ? 128 & t ? 0 : -1 : void 0;
	if (!(1 & t)) {
		var d = s && e[s - 1];
		typeof d == "object" && d && d.constructor === Object ? a = --s : d = void 0, !l || 128 & t || i || (c = !0, a = tc(a - u, u, e, d, void 0) + u);
	}
	t = void 0;
	for (var f = 0; f < s; f++) {
		let i = e[f];
		if (i != null && (i = n(i, r)) != null) {
			if (l && f >= a) {
				let e = f - u;
				(t ??= {})[e] = i;
			} else o[f] = i;
		}
	}
	if (d) for (let e in d) {
		if ((s = d[e]) == null || (s = n(s, r)) == null) continue;
		let i;
		f = +e, l && !Number.isNaN(f) && (i = f + u) < a ? o[i] = s : (t ??= {})[e] = s;
	}
	return t && (c ? o.push(t) : o[a] = t), i && Ao && (e = pc(e)) && e instanceof _c && (o[Ao] = function(e) {
		var t = new _c();
		return mc(e, (e, n, r) => {
			t[n] = ws(r);
		}), t.la = e.la, t;
	}(e)), o;
}
function xc(e) {
	return e[0] = Sc(e[0]), e[1] = Sc(e[1]), e;
}
function Sc(e) {
	switch (typeof e) {
		case "number": return Number.isFinite(e) ? e : "" + e;
		case "bigint": return as(e) ? Number(e) : "" + e;
		case "boolean": return +!!e;
		case "object":
			if (Array.isArray(e)) {
				var t = 0 | e[N];
				return e.length === 0 && 1 & t ? void 0 : bc(e, t, Sc);
			}
			if (Go(e)) return Cc(e);
			if (e instanceof _o) {
				if ((t = e.h) == null) e = "";
				else if (typeof t == "string") e = t;
				else {
					if (oo) {
						for (var n = "", r = 0, i = t.length - 10240; r < i;) n += String.fromCharCode.apply(null, t.subarray(r, r += 10240));
						n += String.fromCharCode.apply(null, r ? t.subarray(r) : t), t = btoa(n);
					} else {
						n === void 0 && (n = 0), io(), n = to[n], r = Array(Math.floor(t.length / 3)), i = n[64] || "";
						let e = 0, l = 0;
						for (; e < t.length - 2; e += 3) {
							var a = t[e], o = t[e + 1], s = t[e + 2], c = n[a >> 2];
							a = n[(3 & a) << 4 | o >> 4], o = n[(15 & o) << 2 | s >> 6], s = n[63 & s], r[l++] = c + a + o + s;
						}
						switch (c = 0, s = i, t.length - e) {
							case 2: s = n[(15 & (c = t[e + 1])) << 2] || i;
							case 1: t = t[e], r[l] = n[t >> 2] + n[(3 & t) << 4 | c >> 4] + s + i;
						}
						t = r.join("");
					}
					e = e.h = t;
				}
				return e;
			}
			return e instanceof lc ? e = e.size === 0 ? void 0 : e.fa(xc) : void 0;
	}
	return e;
}
function Cc(e) {
	return bc(e = e.B, 0 | e[N], Sc);
}
function wc(e, t) {
	return Tc(e, t[0], t[1]);
}
function Tc(e, t, n, r = 0) {
	if (e == null) {
		var i = 32;
		n ? (e = [n], i |= 128) : e = [], t && (i = -16760833 & i | (1023 & t) << 14);
	} else {
		if (!Array.isArray(e)) throw Error("narr");
		if (i = 0 | e[N], Xa && 1 & i) throw Error("rfarr");
		if (2048 & i && !(2 & i) && function() {
			if (Xa) throw Error("carr");
			So(Po, 5);
		}(), 256 & i) throw Error("farr");
		if (64 & i) return (i | r) !== i && Vo(e, i | r), e;
		if (n && (i |= 128, n !== e[0])) throw Error("mid");
		t: {
			i |= 64;
			var a = (n = e).length;
			if (a) {
				var o = a - 1;
				let e = n[o];
				if (typeof e == "object" && e && e.constructor === Object) {
					if ((o -= t = 128 & i ? 0 : -1) >= 1024) throw Error("pvtlmt");
					for (var s in e) (a = +s) < o && (n[a + t] = e[s], delete e[s]);
					i = -16760833 & i | (1023 & o) << 14;
					break t;
				}
			}
			if (t) {
				if ((s = Math.max(t, a - (128 & i ? 0 : -1))) > 1024) throw Error("spvt");
				i = -16760833 & i | (1023 & s) << 14;
			}
		}
	}
	return Vo(e, 64 | i | r), e;
}
function Ec(e, t) {
	if (typeof e != "object") return e;
	if (Array.isArray(e)) {
		var n = 0 | e[N];
		return e.length === 0 && 1 & n ? void 0 : Dc(e, n, t);
	}
	if (Go(e)) return kc(e);
	if (e instanceof lc) {
		if (2 & (t = e.N)) return e;
		if (!e.size) return;
		if (n = Ho(e.fa()), e.O) for (e = 0; e < n.length; e++) {
			let r = n[e], i = r[1];
			i = typeof i != "object" || !i ? void 0 : Go(i) ? kc(i) : Array.isArray(i) ? Dc(i, 0 | i[N], !!(32 & t)) : void 0, r[1] = i;
		}
		return n;
	}
	return e instanceof _o ? e : void 0;
}
function Dc(e, t, n) {
	return 2 & t || (!n || 4096 & t || 16 & t ? e = Ac(e, t, !1, n && !(16 & t)) : (Bo(e, 34), 4 & t && Object.freeze(e))), e;
}
function Oc(e, t, n) {
	return e = new e.constructor(t), n && (e.i = qo), e.o = qo, e;
}
function kc(e) {
	var t = e.B, n = 0 | t[N];
	return Ko(e, n) ? e : Fc(e, t, n) ? Oc(e, t) : Ac(t, n);
}
function Ac(e, t, n, r) {
	return r ??= !!(34 & t), e = bc(e, t, Ec, r), r = 32, n && (r |= 2), Vo(e, t = 16769217 & t | r), e;
}
function jc(e) {
	var t = e.B, n = 0 | t[N];
	return Ko(e, n) ? Fc(e, t, n) ? Oc(e, t, !0) : new e.constructor(Ac(t, n, !1)) : e;
}
function Mc(e) {
	if (e.i !== qo) return !1;
	var t = e.B;
	return Bo(t = Ac(t, 0 | t[N]), 2048), e.B = t, e.i = void 0, e.o = void 0, !0;
}
function Nc(e) {
	if (!Mc(e) && Ko(e, 0 | e.B[N])) throw Error();
}
function Pc(e, t) {
	t === void 0 && (t = 0 | e[N]), 32 & t && !(4096 & t) && Vo(e, 4096 | t);
}
function Fc(e, t, n) {
	return !!(2 & n) || !(!(32 & n) || 4096 & n) && (Vo(t, 2 | n), e.i = qo, !0);
}
var Ic = is(0), Lc = {};
function Rc(e, t, n, r) {
	if ((t = zc(e.B, t, void 0, r)) !== null || n && e.o !== qo) return t;
}
function zc(e, t, n, r) {
	if (t === -1) return null;
	var i = t + (n ? 0 : -1), a = e.length - 1;
	if (!(a < 1 + (n ? 0 : -1))) {
		if (i >= a) {
			var o = e[a];
			if (typeof o == "object" && o && o.constructor === Object) {
				n = o[t];
				var s = !0;
			} else {
				if (i !== a) return;
				n = o;
			}
		} else n = e[i];
		if (r && n != null) {
			if ((r = r(n)) == null) return r;
			if (!Object.is(r, n)) return s ? o[t] = r : e[i] = r, r;
		}
		return n;
	}
}
function I(e, t, n, r) {
	Nc(e);
	var i = e.B;
	return Bc(i, 0 | i[N], t, n, r), e;
}
function Bc(e, t, n, r, i) {
	var a = n + (i ? 0 : -1), o = e.length - 1;
	if (o >= 1 + (i ? 0 : -1) && a >= o) {
		let i = e[o];
		if (typeof i == "object" && i && i.constructor === Object) return i[n] = r, t;
	}
	return a <= o ? (e[a] = r, t) : (r !== void 0 && (n >= (o = (t ??= 0 | e[N]) >> 14 & 1023 || 536870912) ? r != null && (e[o + (i ? 0 : -1)] = { [n]: r }) : e[a] = r), t);
}
function Vc(e, t) {
	return Go(e = zc(e.B, t)) || Array.isArray(e);
}
function Hc(e, t, n) {
	return Vc(e, t = Qc(e, n) === t ? t : -1);
}
function Uc(e, t, n, r, i) {
	var a = e.B, o = 0 | a[N];
	r = r && r !== 4 ? r !== 1 && Ko(e, o) ? 1 : r : 4, i = !!i || r === 3, r === 2 && Mc(e) && (o = 0 | (a = e.B)[N]);
	var s = (e = Gc(a, t)) === Eo ? 7 : 0 | e[N], c = Kc(s, o), l = !(4 & c);
	if (l) {
		let t = 0, r = 0;
		for (; t < e.length; t++) {
			let i = n(e[t]);
			i != null && (e[r++] = i);
		}
		r < t && (e.length = r), n = -513 & c | 4, c = n &= -1025, c &= -4097;
	}
	return c !== s && (Vo(e, c), 2 & c && Object.freeze(e)), Wc(e, c, a, o, t, r, l, i);
}
function Wc(e, t, n, r, i, a, o, s) {
	var c = t, l = qc(t);
	return l && a === 2 && (e = ws(e), c = 0, t = cl(t, r), r = Bc(n, r, i, e), l = !1), l || (a === 1 || a === 4 && (2 & t || !(16 & t) && 32 & r) ? ((t |= !e.length || o && !(4096 & t) || 32 & r && !(4096 & t || 16 & t) ? 2 : 256) !== c && Vo(e, t), Object.freeze(e)) : (s || (t |= 16), t !== c && Vo(e, t))), 2 & t || !(4096 & t || 16 & t) || Pc(n, r), e;
}
function Gc(e, t, n) {
	return e = zc(e, t, n), Array.isArray(e) ? e : Eo;
}
function Kc(e, t) {
	return 2 & t && (e |= 2), 1 | e;
}
function qc(e) {
	return !!(2 & e) && !!(4 & e) || !!(256 & e);
}
function Jc(e) {
	return Jo(e, !0);
}
function Yc(e) {
	e = ws(e);
	for (let t = 0; t < e.length; t++) {
		let n = e[t] = ws(e[t]);
		Array.isArray(n[1]) && (n[1] = Ho(n[1]));
	}
	return Uo(e);
}
function Xc(e, t, n, r) {
	Nc(e), Bc(e = e.B, 0 | e[N], t, (r === "0" ? Number(n) === 0 : n === r) ? void 0 : n);
}
function Zc(e, t, n) {
	if (2 & t) throw Error();
	var r = Qo(t), i = Gc(e, n, r), a = i === Eo ? 7 : 0 | i[N], o = Kc(a, t);
	return (2 & o || qc(o) || 16 & o) && (o === a || qc(o) || Vo(i, o), i = ws(i), a = 0, o = cl(o, t), Bc(e, t, n, i, r)), (o &= -13) !== a && Vo(i, o), i;
}
function Qc(e, t) {
	return tl($c(e = e.B), e, void 0, t);
}
function $c(e) {
	if (wo) return e[ko] ?? (e[ko] = /* @__PURE__ */ new Map());
	if (ko in e) return e[ko];
	var t = /* @__PURE__ */ new Map();
	return Object.defineProperty(e, ko, { value: t }), t;
}
function el(e, t, n, r, i) {
	var a = $c(e), o = tl(a, e, t, n, i);
	return o !== r && (o && (t = Bc(e, t, o, void 0, i)), a.set(n, r)), t;
}
function tl(e, t, n, r, i) {
	var a = e.get(r);
	if (a != null) return a;
	a = 0;
	for (let e = 0; e < r.length; e++) {
		let o = r[e];
		zc(t, o, i) != null && (a !== 0 && (n = Bc(t, n, a, void 0, i)), a = o);
	}
	return e.set(r, a), a;
}
function nl(e, t, n) {
	var r = 0 | e[N], i = Qo(r), a = zc(e, n, i);
	if (Go(a)) {
		if (!Ko(a)) return Mc(a), a.B;
		var o = a.B;
	} else Array.isArray(a) && (o = a);
	if (o) {
		let e = 0 | o[N];
		2 & e && (o = Ac(o, e));
	}
	return (o = wc(o, t)) !== a && Bc(e, r, n, o, i), o;
}
function L(e, t, n, r) {
	var i = e.B, a = 0 | i[N];
	if (t = function(e, t, n, r, i) {
		var a = !1;
		if ((r = zc(e, r, i, (e) => {
			var r = $s(e, n, !1, t);
			return a = r !== e && r != null, r;
		})) != null) return a && !Ko(r) && Pc(e, t), r;
	}(i, a, t, n, r), t == null) return t;
	if (!Ko(e, a = 0 | i[N])) {
		let o = jc(t);
		o !== t && (Mc(e) && (a = 0 | (i = e.B)[N]), Pc(i, a = Bc(i, a, n, t = o, r)));
	}
	return t;
}
function rl(e, t, n, r, i, a, o, s) {
	a = a && a !== 4 ? a !== 1 && Ko(e, n) ? 1 : a : 4, o = !!o || a === 3;
	var c = !!s && !Ko(e, n);
	(a === 2 || c) && Mc(e) && (n = 0 | (t = e.B)[N]);
	var l = (e = Gc(t, i)) === Eo ? 7 : 0 | e[N], u = Kc(l, n);
	if (s = !(4 & u)) {
		var d = e, f = n;
		let t = !!(2 & u);
		t && (f |= 2);
		let i = !t, a = !0, o = 0, s = 0;
		for (; o < d.length; o++) {
			let e = $s(d[o], r, !1, f);
			if (e instanceof r) {
				if (!t) {
					let t = Ko(e);
					i &&= !t, a &&= t;
				}
				d[s++] = e;
			}
		}
		s < o && (d.length = s), u |= 4, u = a ? -4097 & u : 4096 | u, u = i ? 8 | u : -9 & u;
	}
	if (u !== l && (Vo(e, u), 2 & u && Object.freeze(e)), c && !(8 & u || !e.length && (a === 1 || a === 4 && (2 & u || !(16 & u) && 32 & n)))) {
		for (qc(u) && (e = ws(e), u = cl(u, n), n = Bc(t, n, i, e)), r = e, c = u, l = 0; l < r.length; l++) (d = r[l]) !== (u = jc(d)) && (r[l] = u);
		c |= 8, Vo(e, u = c = r.length ? 4096 | c : -4097 & c);
	}
	return Wc(e, u, t, n, i, a, s, o);
}
function il(e, t, n) {
	var r = e.B;
	return rl(e, r, 0 | r[N], t, n, void 0, !1, !0);
}
function al(e) {
	return e ??= void 0, e;
}
function R(e, t, n, r, i) {
	return I(e, n, r = al(r), i), r && !Ko(r) && Pc(e.B), e;
}
function ol(e, t, n, r) {
	t: {
		var i = r = al(r);
		Nc(e);
		let a = e.B, o = 0 | a[N];
		if (i == null) {
			let e = $c(a);
			if (tl(e, a, o, n) !== t) break t;
			e.set(n, 0);
		} else o = el(a, o, n, t);
		Bc(a, o, t, i);
	}
	return r && !Ko(r) && Pc(e.B), e;
}
function sl(e, t, n) {
	Nc(e);
	var r = e.B, i = 0 | r[N];
	if (n == null) return Bc(r, i, t), e;
	var a = n === Eo ? 7 : 0 | n[N], o = a, s = qc(a), c = s || Object.isFrozen(n), l = !0, u = !0;
	for (let e = 0; e < n.length; e++) {
		var d = n[e];
		s || (d = Ko(d), l &&= !d, u &&= d);
	}
	return s || (a = l ? 13 : 5, a = u ? -4097 & a : 4096 | a), c && a === o || (n = ws(n), o = 0, a = cl(a, i)), a !== o && Vo(n, a), i = Bc(r, i, t, n), 2 & a || !(4096 & a || 16 & a) || Pc(r, i), e;
}
function cl(e, t) {
	return -273 & (2 & t ? 2 | e : -3 & e);
}
function ll(e, t, n, r) {
	var i = r;
	Nc(e), e = rl(e, r = e.B, 0 | r[N], n, t, 2, !0), i ??= new n(), e.push(i), t = n = e === Eo ? 7 : 0 | e[N], (i = Ko(i)) ? (n &= -9, e.length === 1 && (n &= -4097)) : n |= 4096, n !== t && Vo(e, n), i || Pc(r);
}
function ul(e, t, n) {
	return Ls(Rc(e, t, n));
}
function dl(e, t) {
	return Rc(e, t, void 0, Ms) ?? 0;
}
function fl(e, t, n, r) {
	return L(e, t, n = Qc(e, r) === n ? n : -1, void 0);
}
function pl(e, t) {
	Xc(e, 3, t == null ? t : Ns(t), !1);
}
function ml(e, t, n) {
	if (n != null) {
		if (typeof n != "number" || !Os(n)) throw xo("int32");
		n |= 0;
	}
	I(e, t, n);
}
function hl(e, t, n) {
	return I(e, t, n == null ? n : zs(n));
}
function gl(e, t, n) {
	return I(e, t, n == null ? n : function(e) {
		if (!Fs(e)) throw xo("uint64");
		switch (typeof e) {
			case "string":
				var t = ks(Number(e));
				return Ds(t) && t >= 0 ? e = is(t) : ((t = e.indexOf(".")) !== -1 && (e = e.substring(0, t)), e = Co() ? is(Es(64, BigInt(e))) : is(Vs(e))), e;
			case "bigint": return is(Es(64, e));
			default: return e >= 0 && Ds(e) || ((e = ks(e)) >= 0 && Ds(e) ? e = String(e) : (ms(e), e = ys(P, F))), is(e);
		}
	}(n));
}
function z(e, t, n) {
	I(e, t, n == null ? n : js(n));
}
function _l(e, t, n) {
	Xc(e, t, n == null ? n : js(n), 0);
}
function vl(e, t, n) {
	Xc(e, t, Zs(n), "");
}
function yl(e, t, n) {
	{
		Nc(e);
		let o = e.B, s = 0 | o[N];
		if (n == null) Bc(o, s, t);
		else {
			var r = e = n === Eo ? 7 : 0 | n[N], i = qc(e), a = i || Object.isFrozen(n);
			for (i || (e = 0), a ||= (n = ws(n), r = 0, e = cl(e, s), !1), e |= 5, e |= (4 & e ? 512 & e ? 512 : 1024 & e ? 1024 : 0 : void 0) ?? 1024, i = 0; i < n.length; i++) {
				let t = n[i], o = Xs(t);
				Object.is(t, o) || (a &&= (n = ws(n), r = 0, e = cl(e, s), !1), n[i] = o);
			}
			e !== r && (a && (n = ws(n), e = cl(e, s)), Vo(n, e)), Bc(o, s, t, n);
		}
	}
}
function bl(e, t, n) {
	Nc(e), Uc(e, t, Qs, 2, !0).push(Xs(n));
}
var xl = class {
	constructor(e, t, n) {
		if (this.buffer = e, n && !t) throw Error();
		this.h = t;
	}
};
function Sl(e, t) {
	if (typeof e == "string") return new xl(uo(e), t);
	if (Array.isArray(e)) return new xl(new Uint8Array(e), t);
	if (e.constructor === Uint8Array) return new xl(e, !1);
	if (e.constructor === ArrayBuffer) return e = new Uint8Array(e), new xl(e, !1);
	if (e.constructor === _o) return t = ho(e) || /* @__PURE__ */ new Uint8Array(), new xl(t, !0, e);
	if (e instanceof Uint8Array) return e = e.constructor === Uint8Array ? e : new Uint8Array(e.buffer, e.byteOffset, e.byteLength), new xl(e, !1);
	throw Error();
}
function Cl(e, t) {
	var n = 0, r = 0, i = 0, a = e.i, o = e.h;
	do {
		var s = a[o++];
		n |= (127 & s) << i, i += 7;
	} while (i < 32 && 128 & s);
	if (i > 32) for (r |= (127 & s) >> 4, i = 3; i < 32 && 128 & s; i += 7) r |= (127 & (s = a[o++])) << i;
	if (jl(e, o), !(128 & s)) return t(n >>> 0, r >>> 0);
	throw Error();
}
function wl(e) {
	for (var t = 0, n = e.h, r = n + 10, i = e.i; n < r;) {
		let r = i[n++];
		if (t |= r, !(128 & r)) return jl(e, n), !!(127 & t);
	}
	throw Error();
}
function Tl(e) {
	var t = e.i, n = e.h, r = t[n++], i = 127 & r;
	if (128 & r && (i |= (127 & (r = t[n++])) << 7, 128 & r && (i |= (127 & (r = t[n++])) << 14, 128 & r && (i |= (127 & (r = t[n++])) << 21, 128 & r && (i |= (r = t[n++]) << 28, 128 & r && 128 & t[n++] && 128 & t[n++] && 128 & t[n++] && 128 & t[n++] && 128 & t[n++]))))) throw Error();
	return jl(e, n), i;
}
function El(e) {
	return Tl(e) >>> 0;
}
function Dl(e) {
	return Cl(e, vs);
}
function Ol(e) {
	var t = e.i, n = e.h, r = t[n], i = t[n + 1], a = t[n + 2];
	return t = t[n + 3], jl(e, e.h + 4), (r | i << 8 | a << 16 | t << 24) >>> 0;
}
function kl(e) {
	var t = Ol(e);
	e = 2 * (t >> 31) + 1;
	var n = t >>> 23 & 255;
	return t &= 8388607, n == 255 ? t ? NaN : 1 / 0 * e : n == 0 ? 1401298464324817e-60 * e * t : e * 2 ** (n - 150) * (t + 8388608);
}
function Al(e) {
	return Tl(e);
}
function jl(e, t) {
	if (e.h = t, t > e.l) throw Error();
}
function Ml(e, t) {
	if (t < 0) throw Error();
	var n = e.h;
	if ((t = n + t) > e.l) throw Error();
	return e.h = t, n;
}
function Nl(e, t) {
	if (t == 0) return mo();
	var n = Ml(e, t);
	return e.ga && e.u ? n = e.i.subarray(n, n + t) : (e = e.i, n = n === (t = n + t) ? /* @__PURE__ */ new Uint8Array() : fs ? e.slice(n, t) : new Uint8Array(e.subarray(n, t))), n.length == 0 ? mo() : new _o(n, po);
}
var Pl = class {
	constructor(e, t, n, r) {
		this.i = null, this.u = !1, this.h = this.l = this.o = 0, this.init(e, t, n, r);
	}
	init(e, t, n, { ga: r = !1, na: i = !1 } = {}) {
		this.ga = r, this.na = i, e && (e = Sl(e, this.na), this.i = e.buffer, this.u = e.h, this.o = t || 0, this.l = n === void 0 ? this.i.length : this.o + n, this.h = this.o);
	}
	clear() {
		this.i = null, this.u = !1, this.h = this.l = this.o = 0, this.ga = !1;
	}
}, Fl = [], Il = 0;
function Ll(e, t, n, r) {
	if (ql.length) {
		let i = ql.pop();
		return i.A(r), i.h.init(e, t, n, r), i;
	}
	return new Kl(e, t, n, r);
}
function Rl(e) {
	e.h.clear(), e.l = -1, e.i = -1, ql.length < 100 && ql.push(e);
}
function zl(e) {
	var t = e.h;
	if (t.h == t.l) return !1;
	e.o = e.h.h;
	var n = El(e.h);
	if (t = n >>> 3, !((n &= 7) >= 0 && n <= 5) || t < 1) throw Error();
	return e.l = t, e.i = n, !0;
}
function Bl(e) {
	try {
		switch (e.i) {
			case 0:
				e.i == 0 ? wl(e.h) : Bl(e);
				break;
			case 1:
				var t = e.h;
				jl(t, t.h + 8);
				break;
			case 2:
				if (e.i != 2) Bl(e);
				else {
					var n = El(e.h), r = e.h;
					jl(r, r.h + n);
				}
				break;
			case 5:
				var i = e.h;
				jl(i, i.h + 4);
				break;
			case 3:
				Vl();
				let a = e.l;
				try {
					for (;;) {
						if (!zl(e)) throw Error();
						if (e.i == 4) {
							if (e.l != a) throw Error();
							break;
						}
						Bl(e);
					}
				} catch (e) {
					throw e instanceof RangeError ? SyntaxError() : e;
				} finally {
					Il > 0 && Il--;
				}
				break;
			default: throw Error();
		}
	} catch (e) {
		throw e instanceof RangeError ? SyntaxError() : e;
	}
}
function Vl() {
	if (Il >= 100) throw SyntaxError();
	Il++;
}
function Hl(e, t, n) {
	var r = e.h.l, i = El(e.h), a = (i = e.h.h + i) - r;
	if (a <= 0 && (e.h.l = i, n(t, e, void 0, void 0, void 0), a = i - e.h.h), a) throw Error();
	return e.h.h = i, e.h.l = r, t;
}
function Ul(e) {
	var t = El(e.h), n = Ml(e = e.h, t);
	if (e = e.i, Ga) {
		var r, i = e;
		(r = Ha) || (r = Ha = new TextDecoder("utf-8", { fatal: !0 })), t = n + t, i = n === 0 && t === i.length ? i : i.subarray(n, t);
		try {
			var a = r.decode(i);
		} catch (e) {
			if (Wa === void 0) {
				try {
					r.decode(new Uint8Array([128]));
				} catch {}
				try {
					r.decode(new Uint8Array([97])), Wa = !0;
				} catch {
					Wa = !1;
				}
			}
			throw !Wa && (Ha = void 0), e;
		}
	} else {
		t = (a = n) + t, n = [];
		let s, c = null;
		for (; a < t;) {
			var o = e[a++];
			o < 128 ? n.push(o) : o < 224 ? a >= t ? Ba() : (s = e[a++], o < 194 || (192 & s) != 128 ? (a--, Ba()) : n.push((31 & o) << 6 | 63 & s)) : o < 240 ? a >= t - 1 ? Ba() : (s = e[a++], (192 & s) != 128 || o === 224 && s < 160 || o === 237 && s >= 160 || (192 & (r = e[a++])) != 128 ? (a--, Ba()) : n.push((15 & o) << 12 | (63 & s) << 6 | 63 & r)) : o <= 244 ? a >= t - 2 ? Ba() : (s = e[a++], (192 & s) != 128 || s - 144 + (o << 28) >> 30 || (192 & (r = e[a++])) != 128 || (192 & (i = e[a++])) != 128 ? (a--, Ba()) : (o = (7 & o) << 18 | (63 & s) << 12 | (63 & r) << 6 | 63 & i, o -= 65536, n.push(55296 + (o >> 10 & 1023), 56320 + (1023 & o)))) : Ba(), n.length >= 8192 && (c = Va(c, n), n.length = 0);
		}
		a = Va(c, n);
	}
	return a;
}
function Wl(e) {
	var t = El(e.h);
	return Nl(e.h, t);
}
function Gl(e, t, n) {
	var r = El(e.h);
	for (r = e.h.h + r; e.h.h < r;) n.push(t(e.h));
}
var Kl = class {
	constructor(e, t, n, r) {
		if (Fl.length) {
			let i = Fl.pop();
			i.init(e, t, n, r), e = i;
		} else e = new Pl(e, t, n, r);
		this.h = e, this.o = this.h.h, this.i = this.l = -1, this.A(r);
	}
	A({ sa: e = !1 } = {}) {
		this.sa = e;
	}
}, ql = [];
function Jl(e) {
	return new Zl(0 | e, Math.floor(e / 4294967296));
}
function Yl(e) {
	return e ? /^\d+$/.test(e) ? (Ss(e), new Zl(P, F)) : null : Xl ||= new Zl(0, 0);
}
var Xl, Zl = class {
	constructor(e, t) {
		this.i = e >>> 0, this.h = t >>> 0;
	}
};
function Ql(e) {
	return new cu(0 | e, Math.floor(e / 4294967296));
}
function $l(e) {
	return e ? /^-?\d+$/.test(e) ? (Ss(e), new cu(P, F)) : null : eu ||= new cu(0, 0);
}
var eu, tu, nu, ru, iu, au, ou, su, cu = class {
	constructor(e, t) {
		this.i = e >>> 0, this.h = t >>> 0;
	}
};
function lu(e, t, n) {
	return typeof BigInt64Array < "u" ? (ou || (ou = /* @__PURE__ */ new BigInt64Array(1), su = new Uint32Array(ou.buffer), ou[0] = BigInt(1), au = su[0] === 1), ou[0] = e, new t(su[e = +!au], su[1 - e])) : (iu ||= (tu = BigInt(-(2 ** 53 - 1)), nu = BigInt(2 ** 53 - 1), ru = BigInt(4294967295), BigInt(32)), e >= tu && e <= nu ? n(Number(e)) : (e = BigInt.asUintN(64, e), new t(Number(e & ru), Number(e >> iu))));
}
function uu(e, t, n) {
	for (; n > 0 || t > 127;) e.h.push(127 & t | 128), t = (t >>> 7 | n << 25) >>> 0, n >>>= 7;
	e.h.push(t);
}
function du(e, t) {
	for (; t > 127;) e.h.push(127 & t | 128), t >>>= 7;
	e.h.push(t);
}
function fu(e, t) {
	if (t >= 0) du(e, t);
	else {
		for (let n = 0; n < 9; n++) e.h.push(127 & t | 128), t >>= 7;
		e.h.push(1);
	}
}
function pu(e, t) {
	Ss(t), function(e) {
		var t = F >> 31;
		e(P << 1 ^ t, (F << 1 | P >>> 31) ^ t);
	}((t, n) => {
		uu(e, t >>> 0, n >>> 0);
	});
}
function mu(e, t) {
	e.h.push(t >>> 0 & 255), e.h.push(t >>> 8 & 255), e.h.push(t >>> 16 & 255), e.h.push(t >>> 24 & 255);
}
var hu = class {
	constructor() {
		this.h = [];
	}
	length() {
		return this.h.length;
	}
	end() {
		var e = this.h;
		return this.h = [], e;
	}
};
function gu(e, t) {
	t.length !== 0 && (e.l.push(t), e.i += t.length);
}
function _u(e, t, n) {
	du(e.h, 8 * t + n);
}
function vu(e, t) {
	return _u(e, t, 2), t = e.h.end(), gu(e, t), t.push(e.i), t;
}
function yu(e, t) {
	var n = t.pop();
	for (n = e.i + e.h.length() - n; n > 127;) t.push(127 & n | 128), n >>>= 7, e.i++;
	t.push(n), e.i++;
}
function bu(e, t, n) {
	if (n != null) switch (_u(e, t, 0), typeof n) {
		case "number":
			e = e.h, ms(n), uu(e, P, F);
			break;
		case "bigint":
			n = lu(n, cu, Ql), uu(e.h, n.i, n.h);
			break;
		default: n = $l(n), uu(e.h, n.i, n.h);
	}
}
function xu(e, t, n) {
	_u(e, t, 2), du(e.h, n.length), gu(e, e.h.end()), gu(e, n);
}
function Su(e, t, n, r) {
	n != null && (t = vu(e, t), r(n, e), yu(e, t));
}
var Cu = class {
	constructor() {
		this.l = [], this.i = 0, this.h = new hu();
	}
};
function wu(e) {
	typeof e == "string" && $l(e);
}
function Tu() {
	var e = class {
		constructor() {
			throw Error();
		}
	};
	return Object.setPrototypeOf(e, e.prototype), e;
}
var Eu = Tu(), Du = Tu(), Ou = Tu(), ku = Tu(), Au = Tu(), ju = Tu(), Mu = Tu(), Nu = Tu(), Pu = Tu(), Fu = Tu(), Iu = Tu(), Lu = Tu();
function Ru(e, t, n) {
	var r = e.B;
	Ao && Ao in r && (r = r[Ao]) && delete r[t.h], t.i ? t.u(e, t.i, t.h, n, t.l) : t.u(e, t.h, n, t.l);
}
var B = class {
	constructor(e, t) {
		this.B = Tc(e, t, void 0, 2048);
	}
	toJSON() {
		return Cc(this);
	}
	u() {
		var e = Jp, t = this.B, n = e.h, r = Ao;
		if (wo && r && t[r]?.[n] != null && So(jo, 3), t = e.h, Io && Ao && Io === void 0 && (r = (n = this.B)[Ao]) && (r = r.la)) try {
			r(n, t, vc);
		} catch (e) {
			Ja(e);
		}
		return e.i ? e.o(this, e.i, e.h, e.l) : e.o(this, e.h, e.defaultValue, e.l);
	}
	clone() {
		var e = this.B, t = 0 | e[N];
		return Fc(this, e, t) ? Oc(this, e, !0) : new this.constructor(Ac(e, t, !1));
	}
};
B.prototype[Fo] = Wo, B.prototype.toString = function() {
	return this.B.toString();
};
var zu = class {
	constructor(e, t, n) {
		this.h = e, this.i = t, e = Eu, this.l = !!e && n === e || !1;
	}
};
function Bu(e, t) {
	return new zu(e, t, Eu);
}
function Vu(e, t, n, r, i) {
	Su(e, n, $u(t, r), i);
}
var Hu, Uu, Wu = Bu(function(e, t, n, r, i) {
	return e.i === 2 && (Hl(e, nl(t, r, n), i), !0);
}, Vu), Gu = Bu(function(e, t, n, r, i) {
	return e.i === 2 && (Hl(e, nl(t, r, n), i), !0);
}, Vu), Ku = Symbol(), qu = Symbol(), Ju = Symbol(), Yu = Symbol(), Xu = Symbol();
function Zu(e, t, n, r) {
	var i = r[e];
	if (i) return i;
	(i = {}).Fa = r, i.da = function(e) {
		switch (typeof e) {
			case "boolean": return hc ||= [
				0,
				void 0,
				!0
			];
			case "number": return e > 0 ? void 0 : e === 0 ? gc ||= [0, void 0] : [-e, void 0];
			case "string": return [0, e];
			case "object": return e;
		}
	}(r[0]);
	var a = r[1], o = 1;
	a && a.constructor === Object && (i.ja = a, typeof (a = r[++o]) == "function" && (i.xa = !0, Hu ??= a, Uu ??= r[o + 1], a = r[o += 2]));
	for (var s = {}; a && Array.isArray(a) && a.length && typeof a[0] == "number" && a[0] > 0;) {
		for (var c = 0; c < a.length; c++) s[a[c]] = a;
		a = r[++o];
	}
	for (c = 1; a !== void 0;) {
		let e;
		typeof a == "number" && (c += a, a = r[++o]);
		var l = void 0;
		if (a instanceof zu ? e = a : (e = Wu, o--), e?.l) {
			a = r[++o], l = r;
			var u = o;
			typeof a == "function" && (a = a(), l[u] = a), l = a;
		}
		for (u = c + 1, typeof (a = r[++o]) == "number" && a < 0 && (u -= a, a = r[++o]); c < u; c++) {
			let r = s[c];
			l ? n(i, c, e, l, r) : t(i, c, e, r);
		}
	}
	return r[e] = i;
}
function Qu(e) {
	return Array.isArray(e) ? e[0] instanceof zu ? e : [Gu, e] : [e, void 0];
}
function $u(e, t) {
	return e instanceof B ? e.B : Array.isArray(e) ? wc(e, t) : void 0;
}
function ed(e, t, n, r) {
	var i = n.h;
	e[t] = r ? (e, t, n) => i(e, t, n, r) : i;
}
function td(e, t, n, r, i) {
	var a, o, s = n.h;
	e[t] = (e, t, n) => s(e, t, n, o ||= Zu(qu, ed, td, r).da, a ||= nd(r), i);
}
function nd(e) {
	var t = e[Ju];
	if (t != null) return t;
	var n = Zu(qu, ed, td, e);
	return t = n.xa ? (e, t) => Hu(e, t, n) : (e, t) => {
		t: {
			Vl();
			try {
				for (; zl(t) && t.i != 4;) {
					let c = t.l, l = n[c];
					if (l == null) {
						let e = n.ja;
						if (e) {
							let t = e[c];
							if (t) {
								let e = id(t);
								e != null && (l = n[c] = e);
							}
						}
					}
					if (l == null || !l(t, e, c)) {
						var r = t;
						let n = r.o;
						if (Bl(r), r.sa) var i = void 0;
						else {
							let e = r.h.h - n;
							r.h.h = n, i = Nl(r.h, e);
						}
						r = void 0;
						var a = e, o = c, s = i;
						s && ((r = a[Ao] ?? (a[Ao] = new _c()))[o] ?? (r[o] = [])).push(s);
					}
				}
				let l = pc(e);
				l && (l.la = n.Fa[Xu]);
				var c = !0;
				break t;
			} catch (e) {
				throw e instanceof RangeError ? SyntaxError() : e;
			} finally {
				Il > 0 && Il--;
			}
		}
		return c;
	}, e[Ju] = t, e[Xu] = rd.bind(e), t;
}
function rd(e, t, n, r) {
	var i = this[qu], a = this[Ju], o = wc(void 0, i.da), s = pc(e);
	if (s) {
		var c = !1, l = i.ja;
		if (l) {
			if (i = (t, n, i) => {
				if (i.length !== 0) {
					if (l[n]) for (let e of i) {
						t = Ll(e);
						try {
							c = !0, a(o, t);
						} finally {
							Rl(t);
						}
					}
					else r?.(e, n, i);
				}
			}, t == null) mc(s, i);
			else if (s != null) {
				let e = s[t];
				e && i(s, t, e);
			}
			if (c) {
				let r = 0 | e[N];
				if (2 & r && 2048 & r && !n?.eb) throw Error();
				let i = Qo(r), a = (t, a) => {
					if (zc(e, t, i) != null) {
						if (n?.mb === 1) return;
						throw Error();
					}
					a != null && (r = Bc(e, r, t, a, i)), delete s[t];
				};
				t == null ? Xo(o, 0 | o[N], (e, t) => {
					a(e, t);
				}) : a(t, zc(o, t, i));
			}
		}
	}
}
function id(e) {
	var t = (e = Qu(e))[0].h;
	if (e = e[1]) {
		let n = nd(e), r = Zu(qu, ed, td, e).da;
		return (e, i, a) => t(e, i, a, r, n);
	}
	return t;
}
function ad(e, t, n) {
	e[t] = n.i;
}
function od(e, t, n, r) {
	var i, a, o = n.i;
	e[t] = (e, t, n) => o(e, t, n, a ||= Zu(Ku, ad, od, r).da, i ||= sd(r));
}
function sd(e) {
	var t = e[Yu];
	if (!t) {
		let n = Zu(Ku, ad, od, e);
		t = (e, t) => cd(e, t, n), e[Yu] = t;
	}
	return t;
}
function cd(e, t, n) {
	Xo(e, 0 | e[N], (e, r) => {
		if (r != null) {
			var i = function(e, t) {
				var n = e[t];
				if (n) return n;
				if ((n = e.ja) && (n = n[t])) {
					var r = (n = Qu(n))[0].i;
					if (n = n[1]) {
						let t = sd(n), i = Zu(Ku, ad, od, n).da;
						n = e.xa ? Uu(i, t) : (e, n, a) => r(e, n, a, i, t);
					} else n = r;
					return e[t] = n;
				}
			}(n, e);
			i ? i(t, r, e) : e < 500 || So(No, 3);
		}
	}), (e = pc(e)) && mc(e, (e, n, r) => {
		for (gu(t, t.h.end()), e = 0; e < r.length; e++) gu(t, ho(r[e]) || /* @__PURE__ */ new Uint8Array());
	});
}
var ld = is(0);
function ud(e, t, n) {
	if (Array.isArray(t)) {
		var r = 0 | t[N];
		if (4 & r) return t;
		for (var i = 0, a = 0; i < t.length; i++) {
			let n = e(t[i]);
			n != null && (t[a++] = n);
		}
		return a < i && (t.length = a), e = 1 | r, n && (e = -1537 & e | 4), e !== r && Vo(t, e), n && 2 & e && Object.freeze(t), t;
	}
}
var dd = (e, t) => {
	var n = new Cu();
	cd(e.B, n, Zu(Ku, ad, od, t)), gu(n, n.h.end()), e = new Uint8Array(n.i);
	var r = (t = n.l).length, i = 0;
	for (let n = 0; n < r; n++) {
		let r = t[n];
		e.set(r, i), i += r.length;
	}
	return n.l = [e], e;
};
function fd(e, t, n) {
	return new zu(e, t, n);
}
function pd(e, t, n) {
	return new zu(e, t, n);
}
function md(e, t, n) {
	Bc(e, 0 | e[N], t, n, Qo(0 | e[N]));
}
var hd = Bu(function(e, t, n, r, i) {
	if (e.i !== 2) return !1;
	if (e = ws(e = Hl(e, wc([void 0, void 0], r), i)), i = Qo(r = 0 | t[N]), 2 & r) throw Error();
	var a = zc(t, n, i);
	if (a instanceof lc) 2 & a.N ? ((a = a.fa()).push(e), Bc(t, r, n, a, i)) : a.hb(e);
	else if (Array.isArray(a)) {
		var o = 0 | a[N];
		8192 & o || Vo(a, o |= 8192), 2 & o && Bc(t, r, n, a = Yc(a), i), a.push(e);
	} else Bc(t, r, n, Uo([e]), i);
	return !0;
}, function(e, t, n, r, i) {
	if (t instanceof lc) t.forEach((t, a) => {
		Su(e, n, wc([a, t], r), i);
	});
	else if (Array.isArray(t)) {
		for (let a = 0; a < t.length; a++) {
			let o = t[a];
			Array.isArray(o) && Su(e, n, wc(o, r), i);
		}
		Uo(t);
	}
});
function gd(e, t, n) {
	(t = Ms(t)) != null && (_u(e, n, 5), e = e.h, hs(t), mu(e, P));
}
function _d(e, t, n) {
	(t = qs(t)) != null && (wu(t), bu(e, n, t));
}
function vd(e, t, n) {
	(t = Ls(t)) != null && t != null && (_u(e, n, 0), fu(e.h, t));
}
function yd(e, t, n) {
	(t = t == null || typeof t == "boolean" ? t : typeof t == "number" ? !!t : void 0) != null && (_u(e, n, 0), e.h.h.push(+!!t));
}
function bd(e, t, n) {
	(t = Qs(t)) != null && xu(e, n, qa(t));
}
function xd(e, t, n, r, i) {
	Su(e, n, $u(t, r), i);
}
function Sd(e, t, n) {
	(t = Ys(t)) != null && xu(e, n, Sl(t, !0).buffer);
}
function Cd(e, t, n) {
	(t = Rs(t)) != null && t != null && (_u(e, n, 0), du(e.h, t));
}
function wd(e, t, n) {
	(t = Ls(t)) != null && (t = parseInt(t, 10), _u(e, n, 0), fu(e.h, t));
}
function Td(e, t, n) {
	return (e.i === 5 || e.i === 2) && (t = Zc(t, 0 | t[N], n), e.i == 2 ? Gl(e, kl, t) : t.push(kl(e.h)), !0);
}
function Ed(e, t, n) {
	return e.i === 0 && (md(t, n, Dl(e.h)), !0);
}
function Dd(e, t, n) {
	return (e.i === 0 || e.i === 2) && (t = Zc(t, 0 | t[N], n), e.i == 2 ? Gl(e, Tl, t) : t.push(Tl(e.h)), !0);
}
function Od(e, t, n) {
	return e.i === 2 && (md(t, n, (e = Wl(e)) === mo() ? void 0 : e), !0);
}
var kd = fd(function(e, t, n) {
	if (e.i !== 1) return !1;
	var r = e.h;
	e = Ol(r);
	var i = Ol(r);
	r = 2 * (i >> 31) + 1;
	var a = i >>> 20 & 2047;
	return e = 4294967296 * (1048575 & i) + e, md(t, n, a == 2047 ? e ? NaN : 1 / 0 * r : a == 0 ? 5e-324 * r * e : r * 2 ** (a - 1075) * (e + 4503599627370496)), !0;
}, function(e, t, n) {
	(t = Ms(t)) != null && (_u(e, n, 1), e = e.h, (n = ds ||= /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(8))).setFloat64(0, +t, !0), P = n.getUint32(0, !0), F = n.getUint32(4, !0), mu(e, P), mu(e, F));
}, Fu), Ad = fd(function(e, t, n) {
	return e.i === 5 && (md(t, n, kl(e.h)), !0);
}, gd, Pu), jd = pd(Td, function(e, t, n) {
	if ((t = ud(Ms, t, !0)) != null) for (let o = 0; o < t.length; o++) {
		var r = e, i = n, a = t[o];
		a != null && (_u(r, i, 5), r = r.h, hs(a), mu(r, P));
	}
}, Pu), Md = pd(Td, function(e, t, n) {
	if ((t = ud(Ms, t, !0)) != null && t.length) {
		_u(e, n, 2), du(e.h, 4 * t.length);
		for (let r = 0; r < t.length; r++) n = e.h, hs(t[r]), mu(n, P);
	}
}, Pu), Nd = fd(function(e, t, n) {
	return e.i === 5 && (md(t, n, (e = kl(e.h)) === 0 ? void 0 : e), !0);
}, gd, Pu), Pd = fd(function(e, t, n) {
	return Ed(e, t, n);
}, _d, ju), Fd = fd(function(e, t, n) {
	return Ed(e, t, n);
}, _d, ju), Id = pd(function(e, t, n) {
	return e.i !== 0 && e.i !== 2 ? e = !1 : (t = Zc(t, 0 | t[N], n), e.i == 2 ? Gl(e, Dl, t) : t.push(Dl(e.h)), e = !0), e;
}, function(e, t, n) {
	if ((t = ud(qs, t, !1)) != null) for (let r = 0; r < t.length; r++) bu(e, n, t[r]);
}, ju), Ld = fd(function(e, t, n) {
	return e.i === 0 ? (md(t, n, (e = Dl(e.h)) === ld ? void 0 : e), t = !0) : t = !1, t;
}, _d, ju), Rd = fd(function(e, t, n) {
	return e.i === 0 ? (md(t, n, Cl(e.h, _s)), e = !0) : e = !1, e;
}, function(e, t, n) {
	if ((t = Js(t)) != null && (typeof t == "string" && Yl(t), t != null)) switch (_u(e, n, 0), typeof t) {
		case "number":
			e = e.h, ms(t), uu(e, P, F);
			break;
		case "bigint":
			n = lu(t, Zl, Jl), uu(e.h, n.i, n.h);
			break;
		default: n = Yl(t), uu(e.h, n.i, n.h);
	}
}, Mu), V = fd(function(e, t, n) {
	return e.i === 0 && (md(t, n, Tl(e.h)), !0);
}, vd, ku), zd = pd(Dd, function(e, t, n) {
	if ((t = ud(Ls, t, !0)) != null) for (let o = 0; o < t.length; o++) {
		var r = e, i = n, a = t[o];
		a != null && (_u(r, i, 0), fu(r.h, a));
	}
}, ku), Bd = pd(Dd, function(e, t, n) {
	if ((t = ud(Ls, t, !0)) != null && t.length) {
		n = vu(e, n);
		for (let n = 0; n < t.length; n++) fu(e.h, t[n]);
		yu(e, n);
	}
}, ku), Vd = fd(function(e, t, n) {
	return e.i === 0 && (md(t, n, (e = Tl(e.h)) === 0 ? void 0 : e), !0);
}, vd, ku), H = fd(function(e, t, n) {
	return e.i === 0 && (md(t, n, wl(e.h)), !0);
}, yd, Du), Hd = fd(function(e, t, n) {
	return e.i === 0 && (md(t, n, !1 === (e = wl(e.h)) ? void 0 : e), !0);
}, yd, Du), Ud = pd(function(e, t, n) {
	return e.i === 2 && (e = Ul(e), Zc(t, 0 | t[N], n).push(e), !0);
}, function(e, t, n) {
	if ((t = ud(Qs, t, !0)) != null) for (let o = 0; o < t.length; o++) {
		var r = e, i = n, a = t[o];
		a != null && xu(r, i, qa(a));
	}
}, Ou), Wd = fd(function(e, t, n) {
	return e.i === 2 && (md(t, n, (e = Ul(e)) === "" ? void 0 : e), !0);
}, bd, Ou), U = fd(function(e, t, n) {
	return e.i === 2 && (md(t, n, Ul(e)), !0);
}, bd, Ou), W = function(e, t, n = Eu) {
	return new zu(e, t, n);
}(function(e, t, n, r, i) {
	return e.i === 2 && (r = wc(void 0, r), Zc(t, 0 | t[N], n).push(r), Hl(e, r, i), !0);
}, function(e, t, n, r, i) {
	if (Array.isArray(t)) {
		for (let a = 0; a < t.length; a++) xd(e, t[a], n, r, i);
		1 & (e = 0 | t[N]) || Vo(t, 1 | e);
	}
}), G = Bu(function(e, t, n, r, i, a) {
	if (e.i !== 2) return !1;
	var o = 0 | t[N];
	return el(t, o, a, n, Qo(o)), Hl(e, t = nl(t, r, n), i), !0;
}, xd), Gd = fd(function(e, t, n) {
	return e.i === 2 && (md(t, n, Wl(e)), !0);
}, Sd, Iu), Kd = pd(function(e, t, n) {
	return e.i === 2 && (e = Wl(e), Zc(t, 0 | t[N], n).push(e), !0);
}, function(e, t, n) {
	if ((t = ud(Ys, t, !1)) != null) for (let o = 0; o < t.length; o++) {
		var r = e, i = n, a = t[o];
		a != null && xu(r, i, Sl(a, !0).buffer);
	}
}, Iu), qd = fd(function(e, t, n) {
	return e.i === 0 && (md(t, n, El(e.h)), !0);
}, Cd, Au), Jd = pd(function(e, t, n) {
	return (e.i === 0 || e.i === 2) && (t = Zc(t, 0 | t[N], n), e.i == 2 ? Gl(e, El, t) : t.push(El(e.h)), !0);
}, function(e, t, n) {
	if ((t = ud(Rs, t, !0)) != null) for (let o = 0; o < t.length; o++) {
		var r = e, i = n, a = t[o];
		a != null && (_u(r, i, 0), du(r.h, a));
	}
}, Au), Yd = fd(function(e, t, n) {
	return e.i === 0 && (md(t, n, (e = El(e.h)) === 0 ? void 0 : e), !0);
}, Cd, Au), K = fd(function(e, t, n) {
	return e.i === 0 && (md(t, n, Tl(e.h)), !0);
}, wd, Lu), Xd = fd(function(e, t, n) {
	return e.i === 0 && (md(t, n, (e = Tl(e.h)) === 0 ? void 0 : e), !0);
}, wd, Lu), Zd = fd(function(e, t, n) {
	return e.i === 0 ? (md(t, n, function(e) {
		return Cl(e, (e, t) => {
			var n = -(1 & e);
			return vs(e = (e >>> 1 | t << 31) ^ n, t >>> 1 ^ n);
		});
	}(e.h)), e = !0) : e = !1, e;
}, function(e, t, n) {
	if ((t = qs(t)) != null && (wu(t), t != null)) switch (_u(e, n, 0), typeof t) {
		case "number":
			e = e.h, t = (n = t) < 0, ps(n = 2 * Math.abs(n)), n = P;
			let r = F;
			t && (n == 0 ? r == 0 ? r = n = 4294967295 : (r--, n = 4294967295) : n--), uu(e, P = n, F = r);
			break;
		case "bigint":
			e = e.h, t = t << BigInt(1) ^ t >> BigInt(63), P = Number(BigInt.asUintN(32, t)), F = Number(BigInt.asUintN(32, t >> BigInt(32))), uu(e, P, F);
			break;
		default: pu(e.h, t);
	}
}, Nu), Qd = class {
	constructor(e, t) {
		var n = Sf;
		this.h = e, this.i = t, this.o = L, this.u = R, this.defaultValue = void 0, this.l = n.kb == null ? void 0 : Zo;
	}
	register() {
		eo(this);
	}
};
function $d(e, t) {
	return new Qd(e, t);
}
function ef(e, t) {
	return (n, r) => {
		t: {
			let a = { na: !0 };
			r && Object.assign(a, r), n = Ll(n, void 0, void 0, a);
			try {
				let r = new e(), a = r.B;
				nd(t)(a, n);
				var i = r;
				break t;
			} catch (e) {
				throw e instanceof RangeError ? SyntaxError() : e;
			} finally {
				Rl(n);
			}
		}
		return i;
	};
}
function tf(e) {
	return (t) => dd(t, e);
}
function nf(e) {
	return function() {
		return dd(this, e);
	};
}
var rf = [
	0,
	Gd,
	Kd,
	H,
	U
], af = [
	0,
	Wd,
	[
		0,
		Xd,
		[
			0,
			Ld,
			Vd
		],
		Xd,
		-1,
		[0, K],
		Xd,
		-1
	],
	fd(Od, Sd, Iu)
], of = class extends B {
	constructor(e) {
		super(e);
	}
}, sf = [
	0,
	Wd,
	fd(Od, function(e, t, n) {
		if (t != null) {
			if (t instanceof B) {
				let r = t.nb;
				r ? (t = r(t), t != null && xu(e, n, Sl(t, !0).buffer)) : So(No, 3);
				return;
			}
			if (Array.isArray(t)) return void So(No, 3);
		}
		Sd(e, t, n);
	}, Iu)
], cf = [
	0,
	1,
	[
		0,
		12,
		V,
		10,
		H
	],
	[
		0,
		7,
		[
			0,
			V,
			-1
		]
	]
];
globalThis.trustedTypes;
var lf = [
	0,
	V,
	K,
	H,
	-1,
	Bd,
	K,
	-1,
	H,
	-1
], uf = [
	0,
	K,
	-1,
	H
], df = class extends B {
	constructor(e) {
		super(e);
	}
}, ff = [
	0,
	H,
	U,
	H,
	K,
	-1,
	pd(function(e, t, n) {
		return (e.i === 0 || e.i === 2) && (t = Zc(t, 0 | t[N], n), e.i == 2 ? Gl(e, Al, t) : t.push(Tl(e.h)), !0);
	}, function(e, t, n) {
		if ((t = ud(Ls, t, !0)) != null && t.length) {
			n = vu(e, n);
			for (let n = 0; n < t.length; n++) fu(e.h, t[n]);
			yu(e, n);
		}
	}, Lu),
	U,
	-1,
	[
		0,
		H,
		-1
	],
	K,
	H,
	-1,
	uf
], pf = class extends B {
	constructor(e) {
		super(e);
	}
}, mf = class extends B {
	constructor(e) {
		super(e);
	}
}, hf = class extends B {
	constructor(e) {
		super(e);
	}
	h() {
		return Vc(this, 9);
	}
}, gf = [
	0,
	3,
	H,
	-1,
	2,
	[
		0,
		[2],
		V,
		G,
		[0, qd]
	],
	[
		0,
		K,
		H,
		K,
		H,
		K,
		4,
		[
			0,
			H,
			U,
			-1,
			H
		]
	],
	[
		0,
		[3, 4],
		U,
		-1,
		G,
		[0, V],
		G,
		[
			0,
			K,
			-1
		]
	],
	[0],
	U
], _f = [
	0,
	U,
	-2
], vf = class extends B {
	constructor(e) {
		super(e);
	}
}, yf = [0], bf = class extends B {
	constructor(e) {
		super(e);
	}
}, xf = [
	0,
	V,
	H,
	1,
	H,
	-4
], Sf = class extends B {
	constructor(e) {
		super(e, 2);
	}
}, Cf = {};
Cf[336783863] = [
	0,
	U,
	H,
	-1,
	V,
	[
		0,
		[
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9
		],
		G,
		yf,
		G,
		ff,
		G,
		_f,
		G,
		xf,
		G,
		lf,
		G,
		[
			0,
			U,
			-2
		],
		G,
		[
			0,
			U,
			K
		],
		G,
		gf,
		G,
		uf
	],
	[0, U],
	H,
	[
		0,
		[1, 3],
		[2, 4],
		G,
		[0, Bd],
		-1,
		G,
		[0, Ud],
		-1,
		W,
		[
			0,
			U,
			-1
		]
	],
	U
];
var wf = [
	0,
	Ld,
	-1,
	Hd,
	-3,
	Ld,
	Bd,
	Wd,
	Vd,
	Ld,
	-1,
	Hd,
	Vd,
	Hd,
	-2,
	Wd
];
function Tf(e, t) {
	bl(e, 3, t);
}
function q(e, t) {
	bl(e, 4, t);
}
var Ef = class extends B {
	constructor(e) {
		super(e, 500);
	}
	A(e) {
		return R(this, 0, 7, e);
	}
}, Df = [-1, {}], Of = [
	0,
	U,
	1,
	Df
], kf = [
	0,
	U,
	Ud,
	Df
];
function Af(e, t) {
	ll(e, 1, Ef, t);
}
function jf(e, t) {
	bl(e, 10, t);
}
function J(e, t) {
	bl(e, 15, t);
}
var Mf = class extends B {
	constructor(e) {
		super(e, 500);
	}
	A(e) {
		return R(this, 0, 1001, e);
	}
}, Nf = [
	-500,
	W,
	[
		-500,
		Wd,
		-1,
		Ud,
		-3,
		[
			-2,
			Cf,
			H
		],
		W,
		sf,
		Vd,
		-1,
		Of,
		kf,
		W,
		[
			0,
			Wd,
			Hd
		],
		Wd,
		wf,
		Vd,
		Ud,
		987,
		Ud
	],
	4,
	W,
	[
		-500,
		U,
		-1,
		[-1, {}],
		998,
		U
	],
	W,
	[
		-500,
		U,
		Ud,
		-1,
		[
			-2,
			{},
			H
		],
		997,
		Ud,
		-1
	],
	Vd,
	W,
	[
		-500,
		U,
		Ud,
		Df,
		998,
		Ud
	],
	Ud,
	Vd,
	Of,
	kf,
	W,
	[
		0,
		Wd,
		-1,
		Df
	],
	Ud,
	-2,
	wf,
	Wd,
	-1,
	Hd,
	[
		0,
		Hd,
		Yd
	],
	978,
	Df,
	W,
	sf
];
Mf.prototype.h = nf(Nf);
var Pf = ef(Mf, Nf), Ff = class extends B {
	constructor(e) {
		super(e);
	}
}, If = class extends B {
	constructor(e) {
		super(e);
	}
	h() {
		return il(this, Ff, 1);
	}
}, Lf = [
	0,
	W,
	[
		0,
		V,
		Ad,
		U,
		-1
	]
], Rf = ef(If, Lf), zf = class extends B {
	constructor(e) {
		super(e);
	}
}, Bf = class extends B {
	constructor(e) {
		super(e);
	}
}, Vf = class extends B {
	constructor(e) {
		super(e);
	}
	l() {
		return L(this, zf, 2);
	}
	h() {
		return il(this, Bf, 5);
	}
}, Hf = ef(class extends B {
	constructor(e) {
		super(e);
	}
}, [
	0,
	Ud,
	Bd,
	Md,
	[
		0,
		K,
		[
			0,
			V,
			-3
		],
		[
			0,
			Ad,
			-3
		],
		[
			0,
			V,
			-1,
			[
				0,
				W,
				[
					0,
					V,
					-2
				]
			]
		],
		W,
		[
			0,
			Ad,
			-1,
			U,
			Ad
		]
	],
	U,
	-1,
	Fd,
	W,
	[
		0,
		V,
		Ad
	],
	Ud,
	Fd
]), Uf = class extends B {
	constructor(e) {
		super(e);
	}
}, Wf = ef(class extends B {
	constructor(e) {
		super(e);
	}
}, [
	0,
	W,
	[
		0,
		Ad,
		-4
	]
]), Gf = class extends B {
	constructor(e) {
		super(e);
	}
}, Kf = ef(class extends B {
	constructor(e) {
		super(e);
	}
}, [
	0,
	W,
	[
		0,
		Ad,
		-4
	]
]), qf = class extends B {
	constructor(e) {
		super(e);
	}
}, Jf = [
	0,
	V,
	-1,
	Md,
	K
], Yf = class extends B {
	constructor(e) {
		super(e);
	}
};
Yf.prototype.h = nf([
	0,
	Ad,
	-4,
	Fd
]);
var Xf = class extends B {
	constructor(e) {
		super(e);
	}
}, Zf = ef(class extends B {
	constructor(e) {
		super(e);
	}
}, [
	0,
	W,
	[
		0,
		1,
		V,
		U,
		Lf
	],
	Fd
]), Qf = class extends B {
	constructor(e) {
		super(e);
	}
}, $f = class extends B {
	constructor(e) {
		super(e);
	}
	h() {
		return Rc(this, 1, void 0, Jc) ?? mo();
	}
}, ep = class extends B {
	constructor(e) {
		super(e);
	}
}, tp = [1, 2], np = ef(class extends B {
	constructor(e) {
		super(e);
	}
}, [
	0,
	W,
	[
		0,
		tp,
		G,
		[0, Md],
		G,
		[0, Gd],
		V,
		U
	],
	Fd
]), rp = class extends B {
	constructor(e) {
		super(e);
	}
}, ip = [
	0,
	U,
	V,
	Ad,
	Ud,
	-1
], ap = class extends B {
	constructor(e) {
		super(e);
	}
}, op = [
	0,
	H,
	-1
], sp = class extends B {
	constructor(e) {
		super(e);
	}
	h() {
		return Hc(this, 2, cp);
	}
	l() {
		return fl(this, hf, 6, cp);
	}
}, cp = [
	1,
	2,
	3,
	4,
	5,
	6
], lp = class extends B {
	constructor(e) {
		super(e);
	}
	h() {
		return Rc(this, 1, void 0, Jc) != null;
	}
	l() {
		return Qs(Rc(this, 2)) != null;
	}
}, up = class extends B {
	constructor(e) {
		super(e);
	}
}, dp = [
	0,
	Gd,
	U,
	[
		0,
		V,
		Fd,
		-1
	],
	[
		0,
		Rd,
		Fd
	]
], fp = [
	0,
	dp,
	H,
	[
		0,
		cp,
		G,
		xf,
		G,
		ff,
		G,
		lf,
		G,
		yf,
		G,
		_f,
		G,
		gf
	],
	K
], pp = tf(fp), mp = class extends B {
	constructor(e) {
		super(e);
	}
}, hp = [
	0,
	fp,
	Ad,
	-1,
	V
], gp = $d(502141897, mp);
Cf[502141897] = hp;
var _p = ef(class extends B {
	constructor(e) {
		super(e);
	}
}, [
	0,
	[
		0,
		K,
		-1,
		jd,
		Jd
	],
	Jf
]), vp = class extends B {
	constructor(e) {
		super(e);
	}
}, yp = class extends B {
	constructor(e) {
		super(e);
	}
}, bp = [
	0,
	fp,
	Ad,
	[0, fp],
	H
], xp = $d(508968150, yp);
Cf[508968150] = [
	0,
	fp,
	hp,
	bp,
	Ad,
	[0, [0, dp]]
], Cf[508968149] = bp;
var Sp = class extends B {
	constructor(e) {
		super(e);
	}
	l() {
		return L(this, rp, 2);
	}
	h() {
		I(this, 2);
	}
}, Cp = [
	0,
	fp,
	ip
];
Cf[478825465] = Cp;
var wp = class extends B {
	constructor(e) {
		super(e);
	}
}, Tp = class extends B {
	constructor(e) {
		super(e);
	}
}, Ep = class extends B {
	constructor(e) {
		super(e);
	}
}, Dp = class extends B {
	constructor(e) {
		super(e);
	}
}, Op = class extends B {
	constructor(e) {
		super(e);
	}
}, kp = [
	0,
	fp,
	[0, fp],
	Cp,
	-1
], Ap = [
	0,
	fp,
	Ad,
	V
], jp = [
	0,
	fp,
	Ad
], Mp = [
	0,
	fp,
	Ap,
	jp,
	Ad
], Np = $d(479097054, Op);
Cf[479097054] = [
	0,
	fp,
	Mp,
	kp
], Cf[463370452] = kp, Cf[464864288] = Ap;
var Pp = $d(462713202, Dp);
Cf[462713202] = Mp, Cf[474472470] = jp;
var Fp = class extends B {
	constructor(e) {
		super(e);
	}
}, Ip = class extends B {
	constructor(e) {
		super(e);
	}
}, Lp = class extends B {
	constructor(e) {
		super(e);
	}
}, Rp = class extends B {
	constructor(e) {
		super(e);
	}
}, zp = [
	0,
	fp,
	Ad,
	-1,
	V
], Bp = [
	0,
	fp,
	Ad,
	H
];
Rp.prototype.h = nf([
	0,
	fp,
	jp,
	[0, fp],
	hp,
	bp,
	zp,
	Bp
]);
var Vp = class extends B {
	constructor(e) {
		super(e);
	}
}, Hp = $d(456383383, Vp);
Cf[456383383] = [
	0,
	fp,
	ip
];
var Up = class extends B {
	constructor(e) {
		super(e);
	}
}, Wp = $d(476348187, Up);
Cf[476348187] = [
	0,
	fp,
	op
];
var Gp = class extends B {
	constructor(e) {
		super(e);
	}
}, Kp = class extends B {
	constructor(e) {
		super(e);
	}
}, qp = [
	0,
	K,
	-1
], Jp = $d(458105876, class extends B {
	constructor(e) {
		super(e);
	}
	h() {
		var e = this.B, t = 0 | e[N], n = Ko(this, t);
		return e = function(e, t, n, r) {
			var i = Kp;
			!r && Mc(e) && (n = 0 | (t = e.B)[N]);
			var a = zc(t, 2);
			if (e = !1, a == null) {
				if (r) return fc();
				a = [];
			} else if (a.constructor === lc) {
				if (!(2 & a.N) || r) return a;
				a = a.fa();
			} else Array.isArray(a) ? e = !!(2 & a[N]) : a = [];
			if (r) {
				if (!a.length) return fc();
				e || (e = !0, Ho(a));
			} else e && (e = !1, Uo(a), a = Yc(a));
			return !e && 32 & n && Bo(a, 32), n = Bc(t, n, 2, r = new lc(a, i, ec, void 0)), e || Pc(t, n), r;
		}(this, e, t, n), !n && Kp && (e.Ga = !0), e;
	}
});
Cf[458105876] = [
	0,
	qp,
	hd,
	[
		!0,
		Fd,
		[
			0,
			U,
			-1,
			Ud
		]
	],
	[
		0,
		Bd,
		H,
		K
	],
	H
];
var Yp = class extends B {
	constructor(e) {
		super(e);
	}
}, Xp = $d(458105758, Yp);
Cf[458105758] = [
	0,
	fp,
	U,
	qp
];
var Zp = class extends B {
	constructor(e) {
		super(e);
	}
}, Qp = class extends B {
	constructor(e) {
		super(e);
	}
}, $p = class extends B {
	constructor(e) {
		super(e);
	}
}, em = tf([
	0,
	W,
	[
		0,
		Xd,
		W,
		[
			0,
			Nd,
			-1
		],
		Hd
	]
]), tm = class extends B {
	constructor(e) {
		super(e);
	}
}, nm = [
	0,
	Nd,
	-1,
	Hd
], rm = class extends B {
	constructor(e) {
		super(e);
	}
}, im = class extends B {
	constructor(e) {
		super(e);
	}
}, am = [1, 2];
im.prototype.h = nf([
	0,
	am,
	G,
	nm,
	G,
	[
		0,
		W,
		nm
	]
]);
var om = class extends B {
	constructor(e) {
		super(e);
	}
}, sm = $d(443442058, om);
Cf[443442058] = [
	0,
	fp,
	U,
	V,
	Ad,
	Ud,
	-1,
	H,
	Ad
], Cf[514774813] = zp;
var cm = class extends B {
	constructor(e) {
		super(e);
	}
}, lm = $d(516587230, cm);
function um(e, t) {
	return t = t ? t.clone() : new rp(), e.displayNamesLocale === void 0 ? e.displayNamesLocale === void 0 && I(t, 1) : I(t, 1, Zs(e.displayNamesLocale)), e.maxResults === void 0 ? "maxResults" in e && I(t, 2) : ml(t, 2, e.maxResults), e.scoreThreshold === void 0 ? "scoreThreshold" in e && I(t, 3) : z(t, 3, e.scoreThreshold), e.categoryAllowlist === void 0 ? "categoryAllowlist" in e && I(t, 4) : yl(t, 4, e.categoryAllowlist), e.categoryDenylist === void 0 ? "categoryDenylist" in e && I(t, 5) : yl(t, 5, e.categoryDenylist), t;
}
function dm(e) {
	var t = Number(e);
	return Number.isSafeInteger(t) ? t : String(e);
}
function fm(e, t = -1, n = "") {
	return {
		categories: e.map((e) => ({
			index: ul(e, 1) ?? 0 ?? -1,
			score: dl(e, 2) ?? 0,
			categoryName: Qs(Rc(e, 3)) ?? "" ?? "",
			displayName: Qs(Rc(e, 4)) ?? "" ?? ""
		})),
		headIndex: t,
		headName: n
	};
}
function pm(e) {
	var t = { classifications: il(e, Xf, 1).map((e) => fm(L(e, If, 4)?.h() ?? [], ul(e, 2) ?? 0, Qs(Rc(e, 3)) ?? "")) };
	return function(e) {
		return e == null ? e : typeof e == "bigint" ? (as(e) ? e = Number(e) : (e = Ts(64, e), e = as(e) ? Number(e) : String(e)), e) : Fs(e) ? typeof e == "number" ? Hs(e) : Ws(e) : void 0;
	}(Rc(e, 2, void 0, Ks)) != null && (t.timestampMs = dm(Rc(e, 2, void 0, Ks) ?? Ic)), t;
}
function mm(e) {
	var t = Uc(e, 3, Ms), n = Uc(e, 2, Ls), r = Uc(e, 1, Qs), i = Uc(e, 9, Qs), a = {
		categories: [],
		keypoints: []
	};
	for (let e = 0; e < t.length; e++) a.categories.push({
		score: t[e],
		index: n[e] ?? -1,
		categoryName: r[e] ?? "",
		displayName: i[e] ?? ""
	});
	if ((t = L(e, Vf, 4)?.l()) && (a.boundingBox = {
		originX: ul(t, 1, Lc) ?? 0,
		originY: ul(t, 2, Lc) ?? 0,
		width: ul(t, 3, Lc) ?? 0,
		height: ul(t, 4, Lc) ?? 0,
		angle: 0
	}), L(e, Vf, 4)?.h().length) for (let t of L(e, Vf, 4).h()) a.keypoints.push({
		x: Rc(t, 1, Lc, Ms) ?? 0,
		y: Rc(t, 2, Lc, Ms) ?? 0,
		score: Rc(t, 4, Lc, Ms) ?? 0,
		label: Qs(Rc(t, 3, Lc)) ?? ""
	});
	return a;
}
function hm(e) {
	var t = [];
	for (let n of il(e, Gf, 1)) e = {
		x: dl(n, 1) ?? 0,
		y: dl(n, 2) ?? 0,
		z: dl(n, 3) ?? 0,
		visibility: dl(n, 4) ?? 0
	}, Rc(n, 5, void 0, Ms) != null && (e.presence = dl(n, 5) ?? 0), t.push(e);
	return t;
}
function gm(e) {
	var t = [];
	for (let n of il(e, Uf, 1)) e = {
		x: dl(n, 1) ?? 0,
		y: dl(n, 2) ?? 0,
		z: dl(n, 3) ?? 0,
		visibility: dl(n, 4) ?? 0
	}, Rc(n, 5, void 0, Ms) != null && (e.presence = dl(n, 5) ?? 0), t.push(e);
	return t;
}
function _m(e) {
	return Array.from(e, (e) => e > 127 ? e - 256 : e);
}
function vm(e, t) {
	if (e.length !== t.length) throw Error(`Cannot compute cosine similarity between embeddings of different sizes (${e.length} vs. ${t.length}).`);
	var n = 0, r = 0, i = 0;
	for (let a = 0; a < e.length; a++) n += e[a] * t[a], r += e[a] * e[a], i += t[a] * t[a];
	if (r <= 0 || i <= 0) throw Error("Cannot compute cosine similarity on embedding with 0 norm.");
	return n / Math.sqrt(r * i);
}
Cf[516587230] = [
	0,
	fp,
	zp,
	Bp,
	Ad
], Cf[518928384] = Bp, new Uint8Array([
	0,
	97,
	115,
	109,
	1,
	0,
	0,
	0,
	1,
	5,
	1,
	96,
	0,
	1,
	123,
	3,
	2,
	1,
	0,
	10,
	10,
	1,
	8,
	0,
	65,
	0,
	253,
	15,
	253,
	98,
	11
]);
function ym(e) {
	return I(new bm(), 1, Is(e));
}
var bm = class extends B {
	constructor(e) {
		super(e);
	}
}, xm = class extends B {
	constructor(e) {
		super(e);
	}
}, Sm = [
	0,
	K,
	2,
	Rd,
	-2,
	Fd,
	W,
	[
		0,
		K,
		Fd
	]
], Cm = class extends B {
	constructor(e) {
		super(e);
	}
}, wm = class extends B {
	constructor(e) {
		super(e);
	}
};
function Tm(e, t) {
	return I(e, 1, Is(t));
}
function Em(e, t) {
	return I(e, 2, Is(t));
}
var Dm = class extends B {
	constructor(e) {
		super(e);
	}
}, Om = [
	3,
	4,
	5,
	6,
	7
], km = class extends B {
	constructor(e) {
		super(e);
	}
}, Am = class extends B {
	constructor(e) {
		super(e);
	}
};
Am.prototype.h = nf([
	0,
	[
		0,
		K,
		U,
		-3,
		K
	],
	[
		0,
		Om,
		K,
		-1,
		G,
		[
			0,
			K,
			U,
			Rd
		],
		G,
		Sm,
		G,
		[
			0,
			1,
			Sm
		],
		G,
		[0, K],
		G,
		[
			0,
			K,
			U,
			Rd
		]
	]
]);
var jm = class {
	constructor() {
		this.h = typeof AbortController < "u";
	}
	async send(e, t, n) {
		var r = this.h ? new AbortController() : void 0, i = r && e.ma > 0 ? setTimeout(() => {
			r.abort();
		}, e.ma) : void 0;
		try {
			let i = await fetch(e.url, {
				method: e.cb,
				headers: { ...e.bb },
				...e.body && { body: e.body },
				...e.withCredentials && { credentials: "include" },
				signal: e.ma && r ? r.signal : null
			});
			i.status === 200 ? t?.(await i.text()) : n?.(i.status);
		} catch (e) {
			e?.name === "AbortError" ? n?.(408) : n?.(400);
		} finally {
			clearTimeout(i);
		}
	}
}, Mm = class extends B {
	constructor(e) {
		super(e, 37);
	}
}, Nm = [
	-4,
	{},
	cf,
	K,
	af
], Pm = [
	0,
	U,
	K,
	1,
	U,
	-1,
	K,
	1,
	K,
	1,
	Fd
], Fm = [
	0,
	K,
	U,
	-2
], Im = [
	0,
	U,
	K
], Lm = [
	0,
	U,
	K
], Rm = [
	0,
	H,
	-3
], zm = [
	0,
	K,
	U,
	-1,
	Fd,
	V,
	-1,
	U,
	-5,
	W,
	[
		0,
		U,
		-4
	],
	-1,
	H,
	[
		0,
		H,
		-3
	],
	K
], Bm = class extends B {
	constructor(e) {
		super(e, 19);
	}
}, Vm = tf([
	-19,
	{},
	[
		0,
		K,
		1,
		[
			0,
			U,
			-6,
			Fd,
			V,
			U,
			-1,
			Fd
		],
		1,
		[
			0,
			U,
			1,
			U,
			-5
		],
		U,
		-1,
		[
			0,
			K,
			U,
			-8
		],
		[
			0,
			U,
			-3
		],
		[
			0,
			U,
			K,
			U,
			-2
		],
		[
			0,
			U,
			-1,
			K,
			U,
			-1,
			K,
			U,
			-1,
			[
				0,
				W,
				[
					0,
					U,
					-1
				],
				H,
				U,
				-5
			],
			[
				0,
				K,
				H,
				V,
				-2
			]
		],
		Fd,
		[
			0,
			U,
			-3,
			Fd,
			V,
			U,
			-1
		],
		[
			0,
			K,
			U,
			-1
		],
		[
			0,
			U,
			-9
		],
		[
			0,
			U,
			-6,
			K,
			U,
			1,
			U,
			H,
			K,
			-1,
			H,
			U,
			-2,
			K,
			U,
			K,
			U,
			V,
			-1
		],
		1,
		[0, K],
		1,
		[
			0,
			U,
			-4
		],
		1,
		Pm,
		[
			0,
			[
				1,
				2,
				3,
				4,
				5,
				6
			],
			G,
			Pm,
			G,
			Im,
			G,
			Lm,
			G,
			[0, K],
			G,
			zm,
			G,
			Fm
		],
		Im,
		Lm,
		zm,
		[
			0,
			[
				0,
				K,
				U,
				-1,
				Fd,
				V,
				-1,
				U,
				-4,
				W,
				[
					0,
					U,
					-4
				],
				-1,
				1,
				Rm
			],
			[
				0,
				K,
				U,
				-1,
				Fd,
				V,
				-1,
				U,
				-4,
				Rm
			]
		],
		Fm,
		[
			0,
			U,
			[
				0,
				V,
				-3,
				K
			],
			K,
			-2,
			[
				0,
				V,
				-1
			],
			H
		],
		4,
		[
			0,
			U,
			K,
			U,
			-1,
			Fd,
			K,
			U,
			-1,
			K,
			V,
			-1
		]
	],
	K,
	W,
	[
		-37,
		{},
		Pd,
		U,
		W,
		[
			0,
			U,
			-1
		],
		Gd,
		1,
		Gd,
		[
			0,
			Ud,
			-1,
			zd,
			Id,
			-1
		],
		U,
		[
			0,
			V,
			U,
			-1
		],
		H,
		V,
		Fd,
		U,
		-1,
		Zd,
		rf,
		Pd,
		Gd,
		K,
		zd,
		Fd,
		-1,
		[
			0,
			K,
			-1
		],
		U,
		H,
		U,
		Bd,
		U,
		-1,
		kd,
		1,
		kd,
		Nm,
		H,
		[
			0,
			K,
			[
				0,
				Ad,
				V,
				-2
			],
			[0, Ad]
		],
		[
			0,
			K,
			Fd
		]
	],
	Pd,
	Kd,
	U,
	-1,
	Pd,
	K,
	-1,
	[
		0,
		H,
		-1,
		K,
		H
	],
	[
		0,
		Fd,
		-1,
		U
	],
	[
		0,
		Pd,
		H,
		Fd
	],
	Fd,
	1,
	qd,
	1,
	Nm
]), Hm = class {
	constructor(e) {
		this.i = [], this.o = new jm(), this.l = e ?? "", this.h = setInterval(() => {
			this.flush();
		}, 6e4);
	}
	close() {
		this.h !== void 0 && (clearInterval(this.h), this.h = void 0), this.flush();
	}
	flush(e, t) {
		if (this.error) t?.("net-send-failed");
		else if (this.i.length === 0) e?.();
		else {
			var n = this.i;
			this.i = [], n = function(e) {
				var t = new Bm();
				return sl(t = I(t, 2, Is(1786)), 3, e);
			}(n), n = Vm(n), this.o.send({
				url: "https://odml.pa.googleapis.com/v1/log",
				cb: "POST",
				ma: 1e4,
				body: n,
				ib: 2,
				bb: {
					"Content-Type": "application/x-protobuf",
					"x-goog-api-key": this.l
				},
				withCredentials: !1
			}, () => {
				e?.();
			}, (e) => {
				this.error = Error(`Logging failed with HTTP error: ${e}`), this.i = [], this.h !== void 0 && (clearInterval(this.h), this.h = void 0), t?.("net-send-failed", e);
			});
		}
	}
}, Um = class {
	constructor() {
		this.ba = this.V = this.Y = this.S = this.W = this.U = this.R = 0;
	}
};
function Wm(e, t) {
	var n = new Am();
	n = R(n, 0, 1, e.C), n = R(n, 0, 2, t), t = I(t = new Mm(), 6, Jo(n = n.h(), !1)), (e = e.m).error || e.i.push(t);
}
function Gm(e, t) {
	var n = {
		R: t.R - e.l.R,
		U: t.U - e.l.U,
		W: t.W - e.l.W,
		S: t.S - e.l.S,
		Y: t.Y - e.l.Y,
		V: t.V,
		ba: t.ba
	}, r = Em(Tm(new Dm(), e.D), 1);
	n = Km(e, n), Wm(e, r = ol(r, 4, Om, n)), e.l = t;
}
function Km(e, t) {
	var n = new xm();
	return e = gl(e = hl(e = I(n, 1, Is(e.F)), 7, t.S), 5, t.V), e = gl(e, 6, t.ba), t.W > 0 && gl(e, 4, t.Y / t.W), t.R !== 0 && (n = hl(n = ym(3), 2, t.R), ll(e, 8, bm, n)), t.U !== 0 && (t = hl(n = ym(4), 2, t.U), ll(e, 8, bm, t)), e;
}
var qm = class {
	constructor(e, t, n) {
		this.v = performance.now(), this.o = performance.now(), this.i = /* @__PURE__ */ new Map(), this.u = 0, this.h = new Um(), this.l = new Um(), this.m = new Hm(n), this.D = function(e) {
			switch (e) {
				case "AudioClassifier": return 4;
				case "AudioEmbedder": return 5;
				case "TextClassifier": return 6;
				case "TextEmbedder": return 7;
				case "GestureRecognizer": return 8;
				case "HandDetector": return 9;
				case "HandLandmarker": return 10;
				case "ImageClassifier": return 11;
				case "ImageEmbedder": return 12;
				case "ImageSegmenter": return 13;
				case "ObjectDetector": return 14;
				case "FaceDetector": return 15;
				case "FaceLandmarker": return 16;
				case "InteractiveSegmenter":
				case "InteractiveSegmenterLegacy": return 18;
				case "HolisticLandmarker": return 20;
				case "LlmInference": return 21;
				case "LanguageDetector": return 22;
				case "PoseLandmarker": return 23;
				case "UniversalEmbedder": return 28;
				case "SemanticRetriever": return 29;
				case "DecisionMaker": return 30;
				case "TextSummarizer": return 26;
				case "TextProofreader": return 27;
				case "AudioTranscriber": return 31;
				case "TextToSpeech": return 32;
				default: return 0;
			}
		}(e), this.F = function(e) {
			switch (e) {
				case "IMAGE": return 11;
				case "VIDEO": return 12;
				case "LIVE_STREAM": return 13;
				case "AUDIO_CLIPS": return 14;
				case "AUDIO_STREAM": return 15;
				default: return 10;
			}
		}(t), e = new km(), typeof navigator > "u" ? t = 0 : (t = navigator.userAgent, t = /Android/i.test(t) ? 1 : /iPhone|iPad|iPod/i.test(t) ? 2 : /Windows/i.test(t) ? 5 : /Macintosh/i.test(t) ? 4 : /Linux/i.test(t) ? 3 : 0), e = I(e, 1, Is(t)), e = I(e, 2, Zs("")), e = I(e, 3, Zs("")), e = I(e, 4, Zs("1.2.0")), e = I(e, 5, Zs("")), this.C = I(e, 6, Is(function() {
			var e = globalThis.__HOST_ENVIRONMENT__;
			if (typeof e == "string") switch (e) {
				case "ANDROID": return 1;
				case "IOS": return 2;
				case "PYTHON": return 3;
				case "WEB": break;
				case "FLUTTER": return 5;
				case "FLUTTER_WEB": return 6;
				default: return 0;
			}
			return 4;
		}()));
	}
	za() {
		var e = new wm();
		e = gl(e = I(e, 1, Is(this.F)), 3, performance.now() - this.v), Wm(this, e = ol(Em(Tm(new Dm(), this.D), 0), 3, Om, e)), this.o = performance.now();
	}
	Aa(e) {
		var t = this.i.get(e);
		if (t !== void 0 && (this.i.delete(e), e = performance.now() - t, ++this.h.W, this.h.Y += e, this.h.V = Math.max(this.h.V, e), this.u = Math.max(this.u, e), performance.now() > this.o + 3e4)) {
			for (let [n, r] of this.i.entries()) e = n, r < t && (this.h.S++, this.i.delete(e));
			t = {
				...this.h,
				ba: performance.now() - this.o
			}, this.h.V = 0, this.o = performance.now(), Gm(this, t);
		}
	}
	ya() {
		var e = {
			...this.h,
			S: this.h.S + this.i.size,
			V: this.u,
			ba: performance.now() - this.v
		};
		Gm(this, e);
		var t = new Cm();
		t = R(t, 0, 2, e = Km(this, e)), Wm(this, t = ol(e = Em(Tm(new Dm(), this.D), 2), 5, Om, t));
	}
	close() {
		var e = this.m;
		typeof e.close == "function" ? e.close() : e.flush();
	}
};
function Jm() {
	var e = navigator;
	return typeof OffscreenCanvas < "u" && (!function(e = navigator) {
		return (e = e.userAgent).includes("Safari") && !e.includes("Chrome");
	}(e) || !!((e = e.userAgent.match(/Version\/([\d]+).*Safari/)) && e.length >= 1 && Number(e[1]) >= 17));
}
async function Ym(e) {
	if (typeof importScripts != "function") {
		let t = document.createElement("script");
		return t.src = e.toString(), t.crossOrigin = "anonymous", new Promise((e, n) => {
			t.addEventListener("load", () => {
				e();
			}, !1), t.addEventListener("error", (e) => {
				n(e);
			}, !1), document.body.appendChild(t);
		});
	}
	try {
		importScripts(e.toString());
	} catch (t) {
		if (!(t instanceof TypeError)) throw t;
		{
			let t = self.import;
			t ? await t(e.toString()) : await import(e.toString());
		}
	}
}
function Xm(e) {
	return e.videoWidth === void 0 ? e.naturalWidth === void 0 ? e.displayWidth === void 0 ? [e.width, e.height] : [e.displayWidth, e.displayHeight] : [e.naturalWidth, e.naturalHeight] : [e.videoWidth, e.videoHeight];
}
function Y(e, t, n) {
	e.o || console.error("No wasm multistream support detected: ensure dependency inclusion of :gl_graph_runner_internal_multi_input target"), n(t = e.j.stringToNewUTF8(t)), e.j._free(t);
}
function Zm(e, t, n) {
	if (!e.j.canvas) throw Error("No OpenGL canvas configured.");
	if (n ? e.j._bindTextureToStream(n) : e.j._bindTextureToCanvas(), !(n = e.j.canvas.getContext("webgl2") || e.j.canvas.getContext("webgl"))) throw Error("Failed to obtain WebGL context from the provided canvas. `getContext()` should only be invoked with `webgl` or `webgl2`.");
	e.j.gpuOriginForWebTexturesIsBottomLeft && n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL, !0), n.texImage2D(n.TEXTURE_2D, 0, n.RGBA, n.RGBA, n.UNSIGNED_BYTE, t), e.j.gpuOriginForWebTexturesIsBottomLeft && n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL, !1);
	var [r, i] = Xm(t);
	return !e.l || r === e.j.canvas.width && i === e.j.canvas.height || (e.j.canvas.width = r, e.j.canvas.height = i), [r, i];
}
function Qm(e, t, n) {
	e.o || console.error("No wasm multistream support detected: ensure dependency inclusion of :gl_graph_runner_internal_multi_input target");
	var r = new Uint32Array(t.length);
	for (let n = 0; n < t.length; n++) r[n] = e.j.stringToNewUTF8(t[n]);
	t = e.j._malloc(4 * r.length), e.j.HEAPU32.set(r, t >> 2), n(t);
	for (let t of r) e.j._free(t);
	e.j._free(t);
}
function $m(e, t, n) {
	e.j.simpleListeners = e.j.simpleListeners || {}, e.j.simpleListeners[t] = n;
}
function eh(e, t, n) {
	var r = [];
	e.j.simpleListeners = e.j.simpleListeners || {}, e.j.simpleListeners[t] = (e, t, i) => {
		t ? (n(r, i), r = []) : r.push(e);
	};
}
var th = class {
	constructor(e, t) {
		this.l = !0, this.j = e, this.h = null, this.i = 0, this.o = typeof this.j._addIntToInputStream == "function", t === void 0 ? Jm() ? this.j.canvas = new OffscreenCanvas(1, 1) : (console.warn("OffscreenCanvas not supported and GraphRunner constructor glCanvas parameter is undefined. Creating backup canvas."), this.j.canvas = document.createElement("canvas")) : this.j.canvas = t;
	}
	async initializeGraph(e) {
		var t = await (await fetch(e)).arrayBuffer();
		e = !(e.endsWith(".pbtxt") || e.endsWith(".textproto")), this.setGraph(new Uint8Array(t), e);
	}
	setGraphFromString(e) {
		this.setGraph(new TextEncoder().encode(e), !1);
	}
	setGraph(e, t) {
		var n = e.length, r = this.j._malloc(n);
		this.j.HEAPU8.set(e, r), t ? this.j._changeBinaryGraph(n, r) : this.j._changeTextGraph(n, r), this.j._free(r);
	}
	configureAudio(e, t, n, r, i) {
		this.j._configureAudio || console.warn("Attempting to use configureAudio without support for input audio. Is build dep \":gl_graph_runner_audio\" missing?"), Y(this, r || "input_audio", (r) => {
			Y(this, i ||= "audio_header", (i) => {
				this.j._configureAudio(r, i, e, t ?? 0, n);
			});
		});
	}
	setAutoResizeCanvas(e) {
		this.l = e;
	}
	setAutoRenderToScreen(e) {
		this.j._setAutoRenderToScreen(e);
	}
	setGpuBufferVerticalFlip(e) {
		this.j.gpuOriginForWebTexturesIsBottomLeft = e;
	}
	ka(e) {
		$m(this, "__graph_config__", (t) => {
			e(t);
		}), Y(this, "__graph_config__", (e) => {
			this.j._getGraphConfig(e, void 0);
		}), delete this.j.simpleListeners.__graph_config__;
	}
	attachErrorListener(e) {
		this.j.errorListener = e;
	}
	attachEmptyPacketListener(e, t) {
		this.j.emptyPacketListeners = this.j.emptyPacketListeners || {}, this.j.emptyPacketListeners[e] = t;
	}
	addAudioToStream(e, t, n) {
		this.addAudioToStreamWithShape(e, 0, 0, t, n);
	}
	addAudioToStreamWithShape(e, t, n, r, i) {
		var a = 4 * e.length;
		this.i !== a && (this.h && this.j._free(this.h), this.h = this.j._malloc(a), this.i = a), this.j.HEAPF32.set(e, this.h / 4), Y(this, r, (e) => {
			this.j._addAudioToInputStream(this.h, t, n, e, i);
		});
	}
	addGpuBufferToStream(e, t, n) {
		Y(this, t, (t) => {
			var [r, i] = Zm(this, e, t);
			this.j._addBoundTextureToStream(t, r, i, n);
		});
	}
	addBoolToStream(e, t, n) {
		Y(this, t, (t) => {
			this.j._addBoolToInputStream(e, t, n);
		});
	}
	addDoubleToStream(e, t, n) {
		Y(this, t, (t) => {
			this.j._addDoubleToInputStream(e, t, n);
		});
	}
	addFloatToStream(e, t, n) {
		Y(this, t, (t) => {
			this.j._addFloatToInputStream(e, t, n);
		});
	}
	addIntToStream(e, t, n) {
		Y(this, t, (t) => {
			this.j._addIntToInputStream(e, t, n);
		});
	}
	addUintToStream(e, t, n) {
		Y(this, t, (t) => {
			this.j._addUintToInputStream(e, t, n);
		});
	}
	addStringToStream(e, t, n) {
		Y(this, t, (t) => {
			Y(this, e, (e) => {
				this.j._addStringToInputStream(e, t, n);
			});
		});
	}
	addStringRecordToStream(e, t, n) {
		Y(this, t, (t) => {
			Qm(this, Object.keys(e), (r) => {
				Qm(this, Object.values(e), (i) => {
					this.j._addFlatHashMapToInputStream(r, i, Object.keys(e).length, t, n);
				});
			});
		});
	}
	addProtoToStream(e, t, n, r) {
		Y(this, n, (n) => {
			Y(this, t, (t) => {
				var i = this.j._malloc(e.length);
				this.j.HEAPU8.set(e, i), this.j._addProtoToInputStream(i, e.length, t, n, r), this.j._free(i);
			});
		});
	}
	addEmptyPacketToStream(e, t) {
		Y(this, e, (e) => {
			this.j._addEmptyPacketToInputStream(e, t);
		});
	}
	addBoolVectorToStream(e, t, n) {
		Y(this, t, (t) => {
			var r = this.j._allocateBoolVector(e.length);
			if (!r) throw Error("Unable to allocate new bool vector on heap.");
			for (let t of e) this.j._addBoolVectorEntry(r, t);
			this.j._addBoolVectorToInputStream(r, t, n);
		});
	}
	addDoubleVectorToStream(e, t, n) {
		Y(this, t, (t) => {
			var r = this.j._allocateDoubleVector(e.length);
			if (!r) throw Error("Unable to allocate new double vector on heap.");
			for (let t of e) this.j._addDoubleVectorEntry(r, t);
			this.j._addDoubleVectorToInputStream(r, t, n);
		});
	}
	addFloatVectorToStream(e, t, n) {
		Y(this, t, (t) => {
			var r = this.j._allocateFloatVector(e.length);
			if (!r) throw Error("Unable to allocate new float vector on heap.");
			for (let t of e) this.j._addFloatVectorEntry(r, t);
			this.j._addFloatVectorToInputStream(r, t, n);
		});
	}
	addIntVectorToStream(e, t, n) {
		Y(this, t, (t) => {
			var r = this.j._allocateIntVector(e.length);
			if (!r) throw Error("Unable to allocate new int vector on heap.");
			for (let t of e) this.j._addIntVectorEntry(r, t);
			this.j._addIntVectorToInputStream(r, t, n);
		});
	}
	addUintVectorToStream(e, t, n) {
		Y(this, t, (t) => {
			var r = this.j._allocateUintVector(e.length);
			if (!r) throw Error("Unable to allocate new unsigned int vector on heap.");
			for (let t of e) this.j._addUintVectorEntry(r, t);
			this.j._addUintVectorToInputStream(r, t, n);
		});
	}
	addStringVectorToStream(e, t, n) {
		Y(this, t, (t) => {
			var r = this.j._allocateStringVector(e.length);
			if (!r) throw Error("Unable to allocate new string vector on heap.");
			for (let t of e) Y(this, t, (e) => {
				this.j._addStringVectorEntry(r, e);
			});
			this.j._addStringVectorToInputStream(r, t, n);
		});
	}
	addBoolToInputSidePacket(e, t) {
		Y(this, t, (t) => {
			this.j._addBoolToInputSidePacket(e, t);
		});
	}
	addDoubleToInputSidePacket(e, t) {
		Y(this, t, (t) => {
			this.j._addDoubleToInputSidePacket(e, t);
		});
	}
	addFloatToInputSidePacket(e, t) {
		Y(this, t, (t) => {
			this.j._addFloatToInputSidePacket(e, t);
		});
	}
	addIntToInputSidePacket(e, t) {
		Y(this, t, (t) => {
			this.j._addIntToInputSidePacket(e, t);
		});
	}
	addUintToInputSidePacket(e, t) {
		Y(this, t, (t) => {
			this.j._addUintToInputSidePacket(e, t);
		});
	}
	addStringToInputSidePacket(e, t) {
		Y(this, t, (t) => {
			Y(this, e, (e) => {
				this.j._addStringToInputSidePacket(e, t);
			});
		});
	}
	addProtoToInputSidePacket(e, t, n) {
		Y(this, n, (n) => {
			Y(this, t, (t) => {
				var r = this.j._malloc(e.length);
				this.j.HEAPU8.set(e, r), this.j._addProtoToInputSidePacket(r, e.length, t, n), this.j._free(r);
			});
		});
	}
	addBoolVectorToInputSidePacket(e, t) {
		Y(this, t, (t) => {
			var n = this.j._allocateBoolVector(e.length);
			if (!n) throw Error("Unable to allocate new bool vector on heap.");
			for (let t of e) this.j._addBoolVectorEntry(n, t);
			this.j._addBoolVectorToInputSidePacket(n, t);
		});
	}
	addDoubleVectorToInputSidePacket(e, t) {
		Y(this, t, (t) => {
			var n = this.j._allocateDoubleVector(e.length);
			if (!n) throw Error("Unable to allocate new double vector on heap.");
			for (let t of e) this.j._addDoubleVectorEntry(n, t);
			this.j._addDoubleVectorToInputSidePacket(n, t);
		});
	}
	addFloatVectorToInputSidePacket(e, t) {
		Y(this, t, (t) => {
			var n = this.j._allocateFloatVector(e.length);
			if (!n) throw Error("Unable to allocate new float vector on heap.");
			for (let t of e) this.j._addFloatVectorEntry(n, t);
			this.j._addFloatVectorToInputSidePacket(n, t);
		});
	}
	addIntVectorToInputSidePacket(e, t) {
		Y(this, t, (t) => {
			var n = this.j._allocateIntVector(e.length);
			if (!n) throw Error("Unable to allocate new int vector on heap.");
			for (let t of e) this.j._addIntVectorEntry(n, t);
			this.j._addIntVectorToInputSidePacket(n, t);
		});
	}
	addUintVectorToInputSidePacket(e, t) {
		Y(this, t, (t) => {
			var n = this.j._allocateUintVector(e.length);
			if (!n) throw Error("Unable to allocate new unsigned int vector on heap.");
			for (let t of e) this.j._addUintVectorEntry(n, t);
			this.j._addUintVectorToInputSidePacket(n, t);
		});
	}
	addStringVectorToInputSidePacket(e, t) {
		Y(this, t, (t) => {
			var n = this.j._allocateStringVector(e.length);
			if (!n) throw Error("Unable to allocate new string vector on heap.");
			for (let t of e) Y(this, t, (e) => {
				this.j._addStringVectorEntry(n, e);
			});
			this.j._addStringVectorToInputSidePacket(n, t);
		});
	}
	attachBoolListener(e, t) {
		$m(this, e, t), Y(this, e, (e) => {
			this.j._attachBoolListener(e);
		});
	}
	attachBoolVectorListener(e, t) {
		eh(this, e, t), Y(this, e, (e) => {
			this.j._attachBoolVectorListener(e);
		});
	}
	attachIntListener(e, t) {
		$m(this, e, t), Y(this, e, (e) => {
			this.j._attachIntListener(e);
		});
	}
	attachIntVectorListener(e, t) {
		eh(this, e, t), Y(this, e, (e) => {
			this.j._attachIntVectorListener(e);
		});
	}
	attachUintListener(e, t) {
		$m(this, e, t), Y(this, e, (e) => {
			this.j._attachUintListener(e);
		});
	}
	attachUintVectorListener(e, t) {
		eh(this, e, t), Y(this, e, (e) => {
			this.j._attachUintVectorListener(e);
		});
	}
	attachDoubleListener(e, t) {
		$m(this, e, t), Y(this, e, (e) => {
			this.j._attachDoubleListener(e);
		});
	}
	attachDoubleVectorListener(e, t) {
		eh(this, e, t), Y(this, e, (e) => {
			this.j._attachDoubleVectorListener(e);
		});
	}
	attachFloatListener(e, t) {
		$m(this, e, t), Y(this, e, (e) => {
			this.j._attachFloatListener(e);
		});
	}
	attachFloatVectorListener(e, t) {
		eh(this, e, t), Y(this, e, (e) => {
			this.j._attachFloatVectorListener(e);
		});
	}
	attachStringListener(e, t) {
		$m(this, e, t), Y(this, e, (e) => {
			this.j._attachStringListener(e);
		});
	}
	attachStringVectorListener(e, t) {
		eh(this, e, t), Y(this, e, (e) => {
			this.j._attachStringVectorListener(e);
		});
	}
	attachProtoListener(e, t, n) {
		$m(this, e, t), Y(this, e, (e) => {
			this.j._attachProtoListener(e, n || !1);
		});
	}
	attachProtoVectorListener(e, t, n) {
		eh(this, e, t), Y(this, e, (e) => {
			this.j._attachProtoVectorListener(e, n || !1);
		});
	}
	attachAudioListener(e, t, n) {
		this.j._attachAudioListener || console.warn("Attempting to use attachAudioListener without support for output audio. Is build dep \":gl_graph_runner_audio_out\" missing?"), $m(this, e, (e, n) => {
			e = new Float32Array(e.buffer, e.byteOffset, e.length / 4), t(e, n);
		}), Y(this, e, (e) => {
			this.j._attachAudioListener(e, n || !1);
		});
	}
	finishProcessing() {
		this.j._waitUntilIdle();
	}
	closeGraph() {
		this.j._closeGraph(), this.j.simpleListeners = void 0, this.j.emptyPacketListeners = void 0;
	}
};
function nh(e) {
	return class extends e {
		get qa() {
			return this.j;
		}
		Ta() {
			if (typeof this.qa._mediapipeLoggerGetEncodedApiKey == "function") {
				let e = this.qa._mediapipeLoggerGetEncodedApiKey();
				return this.qa._decodeBase64(e);
			}
		}
	};
}
function rh(e) {
	return class extends e {
		ab() {
			this.j._registerModelResourcesGraphService();
		}
	};
}
var ih = nh(rh(th)), ah = class extends ih {};
async function oh(e, t, n, r) {
	return e = await (async (e, t, n, r, i) => {
		if (t && await Ym(t), !self.ModuleFactory || n && (await Ym(n), !self.ModuleFactory)) throw Error("ModuleFactory not set.");
		return self.Module && i && ((t = self.Module).locateFile = i.locateFile, i.mainScriptUrlOrBlob && (t.mainScriptUrlOrBlob = i.mainScriptUrlOrBlob)), i = await self.ModuleFactory(self.Module || i), self.ModuleFactory = self.Module = void 0, new e(i, r);
	})(e, n.wasmLoaderPath, n.assetLoaderPath, t, { locateFile: (e) => e.endsWith(".wasm") ? n.wasmBinaryPath.toString() : n.assetBinaryPath && e.endsWith(".data") ? n.assetBinaryPath.toString() : e }), function(e, t) {
		t = t.runningMode ?? "";
		var n = e.h.Ta();
		e.o = new qm(e.D(), t, n);
	}(e, r), await e.A(r), e;
}
async function sh(e, t, n, r) {
	return oh(e, t, n, r);
}
function ch(e, t, n) {
	try {
		e.h.j.FS_unlink(`/${n}`);
	} catch {}
	e.h.j.FS_createDataFile("/", n, t, !0, !1, !1), lh(e, `/${n}`);
}
function lh(e, t) {
	var n = L(e.baseOptions, lp, 1) || new lp();
	typeof t == "string" ? (I(n, 2, Zs(t)), I(n, 1)) : t instanceof Uint8Array && (I(n, 1, Jo(t, !1)), I(n, 2)), R(e.baseOptions, 0, 1, n);
}
function uh(e) {
	try {
		let t = e.L.length;
		if (t === 1) throw Error(e.L[0].message);
		if (t > 1) throw Error("Encountered multiple errors: " + e.L.map((e) => e.message).join(", "));
	} finally {
		e.L = [];
	}
}
function X(e, t) {
	e.J = Math.max(e.J, t);
}
function dh(e, t) {
	e.F = new Ef(), vl(e.F, 2, "PassThroughCalculator"), Tf(e.F, "free_memory"), q(e.F, "free_memory_unused_out"), jf(t, "free_memory"), Af(t, e.F);
}
function fh(e, t) {
	Tf(e.F, t), q(e.F, t + "_unused_out");
}
function ph(e) {
	e.h.addBoolToStream(!0, "free_memory", e.J);
}
var mh = class {
	constructor(e) {
		this.h = e, this.L = [], this.J = 0, this.h.setAutoRenderToScreen(!1);
	}
	l(e, t = !0, n = !1, r = !1) {
		if (t) {
			let t = e.baseOptions || {};
			if (e.baseOptions?.modelAssetBuffer && e.baseOptions?.modelAssetPath) throw Error("Cannot set both baseOptions.modelAssetPath and baseOptions.modelAssetBuffer");
			if (!(L(this.baseOptions, lp, 1)?.h() || L(this.baseOptions, lp, 1)?.l() || e.baseOptions?.modelAssetBuffer || e.baseOptions?.modelAssetPath)) throw Error("Either baseOptions.modelAssetPath or baseOptions.modelAssetBuffer must be set");
			(function(e, t, n = !1) {
				var r = L(e.baseOptions, sp, 3);
				if (!r) {
					var i = r = new sp(), a = new vf();
					ol(i, 4, cp, a);
				}
				"delegate" in t && (t.delegate === "GPU" ? (t = r, i = new df(), ol(t, 2, cp, i)) : (t = r, i = new vf(), ol(t, 4, cp, i))), n && (n = r.l(), t = r.h() || !0 === n?.h(), n = new hf(), t ? R(n, 0, 9, t = new mf()) : R(n, 0, 8, t = new pf()), ol(r, 6, cp, n)), R(e.baseOptions, 0, 3, r);
			})(this, t, r);
			let i = n ? "model.litertlm" : "model.dat";
			if (t.modelAssetPath) return fetch(t.modelAssetPath.toString()).then((e) => {
				if (e.ok) return e.arrayBuffer();
				throw Error(`Failed to fetch model: ${t.modelAssetPath} (${e.status})`);
			}).then((e) => {
				ch(this, new Uint8Array(e), i), this.u(), this.M();
			});
			if (t.modelAssetBuffer instanceof Uint8Array) n ? ch(this, t.modelAssetBuffer, i) : lh(this, t.modelAssetBuffer);
			else if (t.modelAssetBuffer) return async function(e) {
				for (var t = [], n = 0;;) {
					let { done: r, value: i } = await e.read();
					if (r) break;
					t.push(i), n += i.length;
				}
				if (t.length === 0) return /* @__PURE__ */ new Uint8Array();
				if (t.length === 1) return t[0];
				e = new Uint8Array(n), n = 0;
				for (let r of t) e.set(r, n), n += r.length;
				return e;
			}(t.modelAssetBuffer).then((e) => {
				n ? ch(this, e, i) : lh(this, e), this.u(), this.M();
			});
		}
		return this.u(), this.M(), Promise.resolve();
	}
	M() {}
	ka() {
		var e;
		if (this.h.ka((t) => {
			e = Pf(t);
		}), !e) throw Error("Failed to retrieve CalculatorGraphConfig");
		return e;
	}
	setGraph(e, t) {
		this.h.attachErrorListener((e, t) => {
			this.L.push(Error(t));
		}), this.h.ab(), this.h.setGraph(e, t), this.o?.za(), this.F = void 0, uh(this);
	}
	finishProcessing(e) {
		this.h.finishProcessing(), uh(this), this.o && e !== void 0 && this.o.Aa(e);
	}
	close() {
		this.F = void 0, this.o?.ya(), this.o?.close(), this.h.closeGraph();
	}
};
function hh(e, t) {
	if (!e) throw Error(`Unable to obtain required WebGL resource: ${t}`);
	return e;
}
mh.prototype.close = mh.prototype.close;
var gh = class {
	constructor(e, t, n, r) {
		this.h = e, this.i = t, this.o = n, this.l = r;
	}
	bind() {
		this.h.bindVertexArray(this.i);
	}
	close() {
		this.h.deleteVertexArray(this.i), this.h.deleteBuffer(this.o), this.h.deleteBuffer(this.l);
	}
};
function _h(e, t, n) {
	var r = e.h;
	if (n = hh(r.createShader(n), "Failed to create WebGL shader"), r.shaderSource(n, t), r.compileShader(n), !r.getShaderParameter(n, r.COMPILE_STATUS)) throw Error(`Could not compile WebGL shader: ${r.getShaderInfoLog(n)}`);
	return r.attachShader(e.i, n), n;
}
function vh(e, t) {
	var n = e.h, r = hh(n.createVertexArray(), "Failed to create vertex array");
	n.bindVertexArray(r);
	var i = hh(n.createBuffer(), "Failed to create buffer");
	n.bindBuffer(n.ARRAY_BUFFER, i), n.enableVertexAttribArray(e.G), n.vertexAttribPointer(e.G, 2, n.FLOAT, !1, 0, 0), n.bufferData(n.ARRAY_BUFFER, new Float32Array([
		-1,
		-1,
		-1,
		1,
		1,
		1,
		1,
		-1
	]), n.STATIC_DRAW);
	var a = hh(n.createBuffer(), "Failed to create buffer");
	return n.bindBuffer(n.ARRAY_BUFFER, a), n.enableVertexAttribArray(e.L), n.vertexAttribPointer(e.L, 2, n.FLOAT, !1, 0, 0), n.bufferData(n.ARRAY_BUFFER, new Float32Array(t ? [
		0,
		1,
		0,
		0,
		1,
		0,
		1,
		1
	] : [
		0,
		0,
		0,
		1,
		1,
		1,
		1,
		0
	]), n.STATIC_DRAW), n.bindBuffer(n.ARRAY_BUFFER, null), n.bindVertexArray(null), new gh(n, r, i, a);
}
function yh(e, t) {
	if (e.h) {
		if (t !== e.h) throw Error("Cannot change GL context once initialized");
	} else e.h = t;
}
function bh(e, t, n, r) {
	return yh(e, t), e.i || (e.o(), e.J()), n ? (e.m || (e.m = vh(e, !0)), n = e.m) : (e.F || (e.F = vh(e, !1)), n = e.F), t.useProgram(e.i), n.bind(), e.l(), e = r(), n.h.bindVertexArray(null), e;
}
function xh(e, t, n) {
	return yh(e, t), e = hh(t.createTexture(), "Failed to create texture"), t.bindTexture(t.TEXTURE_2D, e), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_S, t.CLAMP_TO_EDGE), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_T, t.CLAMP_TO_EDGE), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MIN_FILTER, n ?? t.LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MAG_FILTER, n ?? t.LINEAR), t.bindTexture(t.TEXTURE_2D, null), e;
}
function Sh(e, t, n) {
	yh(e, t), e.D ||= hh(t.createFramebuffer(), "Failed to create framebuffe."), t.bindFramebuffer(t.FRAMEBUFFER, e.D), t.framebufferTexture2D(t.FRAMEBUFFER, t.COLOR_ATTACHMENT0, t.TEXTURE_2D, n, 0);
}
function Ch(e) {
	e.h?.bindFramebuffer(e.h.FRAMEBUFFER, null);
}
var wh = class {
	C() {
		return "\n  precision mediump float;\n  varying vec2 vTex;\n  uniform sampler2D inputTexture;\n  void main() {\n    gl_FragColor = texture2D(inputTexture, vTex);\n  }\n ";
	}
	o() {
		var e = this.h;
		if (this.i = hh(e.createProgram(), "Failed to create WebGL program"), this.ea = _h(this, "\n  attribute vec2 aVertex;\n  attribute vec2 aTex;\n  varying vec2 vTex;\n  void main(void) {\n    gl_Position = vec4(aVertex, 0.0, 1.0);\n    vTex = aTex;\n  }", e.VERTEX_SHADER), this.aa = _h(this, this.C(), e.FRAGMENT_SHADER), e.linkProgram(this.i), !e.getProgramParameter(this.i, e.LINK_STATUS)) throw Error(`Error during program linking: ${e.getProgramInfoLog(this.i)}`);
		this.G = e.getAttribLocation(this.i, "aVertex"), this.L = e.getAttribLocation(this.i, "aTex");
	}
	J() {}
	l() {}
	close() {
		if (this.i) {
			let e = this.h;
			e.deleteProgram(this.i), e.deleteShader(this.ea), e.deleteShader(this.aa);
		}
		this.D && this.h.deleteFramebuffer(this.D), this.F && this.F.close(), this.m && this.m.close();
	}
}, Th = class extends wh {
	C() {
		return "\n  precision mediump float;\n  uniform sampler2D backgroundTexture;\n  uniform sampler2D maskTexture;\n  uniform sampler2D colorMappingTexture;\n  varying vec2 vTex;\n  void main() {\n    vec4 backgroundColor = texture2D(backgroundTexture, vTex);\n    float category = texture2D(maskTexture, vTex).r;\n    vec4 categoryColor = texture2D(colorMappingTexture, vec2(category, 0.0));\n    gl_FragColor = mix(backgroundColor, categoryColor, categoryColor.a);\n  }\n ";
	}
	J() {
		var e = this.h;
		e.activeTexture(e.TEXTURE1), this.v = xh(this, e, e.LINEAR), e.activeTexture(e.TEXTURE2), this.u = xh(this, e, e.NEAREST);
	}
	o() {
		super.o();
		var e = this.h;
		this.P = hh(e.getUniformLocation(this.i, "backgroundTexture"), "Uniform location"), this.Z = hh(e.getUniformLocation(this.i, "colorMappingTexture"), "Uniform location"), this.M = hh(e.getUniformLocation(this.i, "maskTexture"), "Uniform location");
	}
	l() {
		super.l();
		var e = this.h;
		e.uniform1i(this.M, 0), e.uniform1i(this.P, 1), e.uniform1i(this.Z, 2);
	}
	close() {
		this.v && this.h.deleteTexture(this.v), this.u && this.h.deleteTexture(this.u), super.close();
	}
}, Eh = class extends wh {
	C() {
		return "\n  precision mediump float;\n  uniform sampler2D maskTexture;\n  uniform sampler2D defaultTexture;\n  uniform sampler2D overlayTexture;\n  varying vec2 vTex;\n  void main() {\n    float confidence = texture2D(maskTexture, vTex).r;\n    vec4 defaultColor = texture2D(defaultTexture, vTex);\n    vec4 overlayColor = texture2D(overlayTexture, vTex);\n    // Apply the alpha from the overlay and merge in the default color\n    overlayColor = mix(defaultColor, overlayColor, overlayColor.a);\n    gl_FragColor = mix(defaultColor, overlayColor, confidence);\n  }\n ";
	}
	J() {
		var e = this.h;
		e.activeTexture(e.TEXTURE1), this.u = xh(this, e), e.activeTexture(e.TEXTURE2), this.v = xh(this, e);
	}
	o() {
		super.o();
		var e = this.h;
		this.M = hh(e.getUniformLocation(this.i, "defaultTexture"), "Uniform location"), this.P = hh(e.getUniformLocation(this.i, "overlayTexture"), "Uniform location"), this.K = hh(e.getUniformLocation(this.i, "maskTexture"), "Uniform location");
	}
	l() {
		super.l();
		var e = this.h;
		e.uniform1i(this.K, 0), e.uniform1i(this.M, 1), e.uniform1i(this.P, 2);
	}
	close() {
		this.u && this.h.deleteTexture(this.u), this.v && this.h.deleteTexture(this.v), super.close();
	}
};
function Dh(e, t) {
	switch (t) {
		case 0: return e.h.find((e) => e instanceof Uint8Array);
		case 1: return e.h.find((e) => e instanceof Float32Array);
		case 2: return e.h.find((e) => typeof WebGLTexture < "u" && e instanceof WebGLTexture);
		default: throw Error(`Type is not supported: ${t}`);
	}
}
function Oh(e) {
	var t = Dh(e, 1);
	if (!t) {
		if (t = Dh(e, 0)) t = new Float32Array(t).map((e) => e / 255);
		else {
			t = new Float32Array(e.width * e.height);
			let r = Ah(e);
			var n = Mh(e);
			if (Sh(n, r, kh(e)), "iPad Simulator;iPhone Simulator;iPod Simulator;iPad;iPhone;iPod".split(";").includes(navigator.platform) || navigator.userAgent.includes("Mac") && "document" in self && "ontouchend" in self.document) {
				n = new Float32Array(e.width * e.height * 4), r.readPixels(0, 0, e.width, e.height, r.RGBA, r.FLOAT, n);
				for (let e = 0, r = 0; e < t.length; ++e, r += 4) t[e] = n[r];
			} else r.readPixels(0, 0, e.width, e.height, r.RED, r.FLOAT, t);
		}
		e.h.push(t);
	}
	return t;
}
function kh(e) {
	var t = Dh(e, 2);
	if (!t) {
		let n = Ah(e);
		t = Nh(e);
		let r = Oh(e), i = jh(e);
		n.texImage2D(n.TEXTURE_2D, 0, i, e.width, e.height, 0, n.RED, n.FLOAT, r), Ph(e);
	}
	return t;
}
function Ah(e) {
	if (!e.canvas) throw Error("Conversion to different image formats require that a canvas is passed when initializing the image.");
	return e.i ||= hh(e.canvas.getContext("webgl2"), "You cannot use a canvas that is already bound to a different type of rendering context."), e.i;
}
function jh(e) {
	if (e = Ah(e), !Fh) {
		if (e.getExtension("EXT_color_buffer_float") && e.getExtension("OES_texture_float_linear") && e.getExtension("EXT_float_blend")) Fh = e.R32F;
		else {
			if (!e.getExtension("EXT_color_buffer_half_float")) throw Error("GPU does not fully support 4-channel float32 or float16 formats");
			Fh = e.R16F;
		}
	}
	return Fh;
}
function Mh(e) {
	return e.l ||= new wh(), e.l;
}
function Nh(e) {
	var t = Ah(e);
	t.viewport(0, 0, e.width, e.height), t.activeTexture(t.TEXTURE0);
	var n = Dh(e, 2);
	return n || (n = xh(Mh(e), t, e.o ? t.LINEAR : t.NEAREST), e.h.push(n), e.u = !0), t.bindTexture(t.TEXTURE_2D, n), n;
}
function Ph(e) {
	e.i.bindTexture(e.i.TEXTURE_2D, null);
}
var Fh, Ih = class {
	constructor(e, t, n, r, i, a, o) {
		this.h = e, this.o = t, this.u = n, this.canvas = r, this.l = i, this.width = a, this.height = o, this.u && --Lh === 0 && console.error("You seem to be creating MPMask instances without invoking .close(). This leaks resources.");
	}
	Va() {
		return !!Dh(this, 0);
	}
	va() {
		return !!Dh(this, 1);
	}
	X() {
		return !!Dh(this, 2);
	}
	ua() {
		return (t = Dh(e = this, 0)) || (t = Oh(e), t = new Uint8Array(t.map((e) => Math.round(255 * e))), e.h.push(t)), t;
		var e, t;
	}
	ta() {
		return Oh(this);
	}
	T() {
		return kh(this);
	}
	clone() {
		var e = [];
		for (let t of this.h) {
			let n;
			if (t instanceof Uint8Array) n = new Uint8Array(t);
			else if (t instanceof Float32Array) n = new Float32Array(t);
			else {
				if (!(t instanceof WebGLTexture)) throw Error(`Type is not supported: ${t}`);
				{
					let e = Ah(this), t = Mh(this);
					e.activeTexture(e.TEXTURE1), n = xh(t, e, this.o ? e.LINEAR : e.NEAREST), e.bindTexture(e.TEXTURE_2D, n);
					let r = jh(this);
					e.texImage2D(e.TEXTURE_2D, 0, r, this.width, this.height, 0, e.RED, e.FLOAT, null), e.bindTexture(e.TEXTURE_2D, null), Sh(t, e, n), bh(t, e, !1, () => {
						Nh(this), e.clearColor(0, 0, 0, 0), e.clear(e.COLOR_BUFFER_BIT), e.drawArrays(e.TRIANGLE_FAN, 0, 4), Ph(this);
					}), Ch(t), Ph(this);
				}
			}
			e.push(n);
		}
		return new Ih(e, this.o, this.X(), this.canvas, this.l, this.width, this.height);
	}
	close() {
		this.u && Ah(this).deleteTexture(Dh(this, 2)), Lh = -1;
	}
};
Ih.prototype.close = Ih.prototype.close, Ih.prototype.clone = Ih.prototype.clone, Ih.prototype.getAsWebGLTexture = Ih.prototype.T, Ih.prototype.getAsFloat32Array = Ih.prototype.ta, Ih.prototype.getAsUint8Array = Ih.prototype.ua, Ih.prototype.hasWebGLTexture = Ih.prototype.X, Ih.prototype.hasFloat32Array = Ih.prototype.va, Ih.prototype.hasUint8Array = Ih.prototype.Va;
var Lh = 250, Rh = {
	color: "white",
	lineWidth: 4,
	radius: 6
};
function zh(e) {
	return {
		...Rh,
		fillColor: (e ||= {}).color,
		...e
	};
}
function Bh(e, t) {
	return e instanceof Function ? e(t) : e;
}
function Vh(e, t, n) {
	return Math.max(Math.min(t, n), Math.min(Math.max(t, n), e));
}
function Hh(e) {
	if (!e.l) throw Error("CPU rendering requested but CanvasRenderingContext2D not provided.");
	return e.l;
}
function Uh(e) {
	if (!e.u) throw Error("GPU rendering requested but WebGL2RenderingContext not provided.");
	return e.u;
}
function Wh(e, t, n) {
	if (t.X()) n(t.T());
	else {
		let r = t.va() ? t.ta() : t.ua();
		e.o = e.o ?? new wh();
		let i = Uh(e);
		n((e = new Ih([r], t.o, !1, i.canvas, e.o, t.width, t.height)).T()), e.close();
	}
}
function Gh(e, t, n, r) {
	var i = function(e) {
		return e.h ||= new Th(), e.h;
	}(e), a = Uh(e), o = Array.isArray(n) ? new ImageData(new Uint8ClampedArray(n), 1, 1) : n;
	bh(i, a, !0, () => {
		(function(e, t, n, r) {
			var i = e.h;
			if (i.activeTexture(i.TEXTURE0), i.bindTexture(i.TEXTURE_2D, t), i.activeTexture(i.TEXTURE1), i.bindTexture(i.TEXTURE_2D, e.v), i.texImage2D(i.TEXTURE_2D, 0, i.RGBA, i.RGBA, i.UNSIGNED_BYTE, n), e.K && function(e, t) {
				if (e !== t) return !1;
				e = e.entries(), t = t.entries();
				for (let [n, r] of e) {
					e = n;
					let i = r, a = t.next();
					if (a.done) return !1;
					let [o, s] = a.value;
					if (e !== o || i[0] !== s[0] || i[1] !== s[1] || i[2] !== s[2] || i[3] !== s[3]) return !1;
				}
				return !!t.next().done;
			}(e.K, r)) i.activeTexture(i.TEXTURE2), i.bindTexture(i.TEXTURE_2D, e.u);
			else {
				e.K = r;
				let t = Array(1024).fill(0);
				r.forEach((e, n) => {
					if (e.length !== 4) throw Error(`Color at index ${n} is not a four-channel value.`);
					t[4 * n] = e[0], t[4 * n + 1] = e[1], t[4 * n + 2] = e[2], t[4 * n + 3] = e[3];
				}), i.activeTexture(i.TEXTURE2), i.bindTexture(i.TEXTURE_2D, e.u), i.texImage2D(i.TEXTURE_2D, 0, i.RGBA, 256, 1, 0, i.RGBA, i.UNSIGNED_BYTE, new Uint8Array(t));
			}
		})(i, t, o, r), a.clearColor(0, 0, 0, 0), a.clear(a.COLOR_BUFFER_BIT), a.drawArrays(a.TRIANGLE_FAN, 0, 4);
		var e = i.h;
		e.activeTexture(e.TEXTURE0), e.bindTexture(e.TEXTURE_2D, null), e.activeTexture(e.TEXTURE1), e.bindTexture(e.TEXTURE_2D, null), e.activeTexture(e.TEXTURE2), e.bindTexture(e.TEXTURE_2D, null);
	});
}
function Kh(e, t, n, r) {
	var i = Uh(e), a = function(e) {
		return e.i ||= new Eh(), e.i;
	}(e), o = Array.isArray(n) ? new ImageData(new Uint8ClampedArray(n), 1, 1) : n, s = Array.isArray(r) ? new ImageData(new Uint8ClampedArray(r), 1, 1) : r;
	bh(a, i, !0, () => {
		var e = a.h;
		e.activeTexture(e.TEXTURE0), e.bindTexture(e.TEXTURE_2D, t), e.activeTexture(e.TEXTURE1), e.bindTexture(e.TEXTURE_2D, a.u), e.texImage2D(e.TEXTURE_2D, 0, e.RGBA, e.RGBA, e.UNSIGNED_BYTE, o), e.activeTexture(e.TEXTURE2), e.bindTexture(e.TEXTURE_2D, a.v), e.texImage2D(e.TEXTURE_2D, 0, e.RGBA, e.RGBA, e.UNSIGNED_BYTE, s), i.clearColor(0, 0, 0, 0), i.clear(i.COLOR_BUFFER_BIT), i.drawArrays(i.TRIANGLE_FAN, 0, 4), i.bindTexture(i.TEXTURE_2D, null), (e = a.h).activeTexture(e.TEXTURE0), e.bindTexture(e.TEXTURE_2D, null), e.activeTexture(e.TEXTURE1), e.bindTexture(e.TEXTURE_2D, null), e.activeTexture(e.TEXTURE2), e.bindTexture(e.TEXTURE_2D, null);
	});
}
var qh = class {
	constructor(e, t) {
		typeof CanvasRenderingContext2D < "u" && e instanceof CanvasRenderingContext2D || e instanceof OffscreenCanvasRenderingContext2D ? (this.l = e, this.u = t) : this.u = e;
	}
	Na(e, t) {
		if (e) {
			var n = Hh(this);
			t = zh(t), n.save();
			var r = n.canvas, i = 0;
			for (let a of e) n.fillStyle = Bh(t.fillColor, {
				index: i,
				from: a
			}), n.strokeStyle = Bh(t.color, {
				index: i,
				from: a
			}), n.lineWidth = Bh(t.lineWidth, {
				index: i,
				from: a
			}), (e = new Path2D()).arc(a.x * r.width, a.y * r.height, Bh(t.radius, {
				index: i,
				from: a
			}), 0, 2 * Math.PI), n.fill(e), n.stroke(e), ++i;
			n.restore();
		}
	}
	Ma(e, t, n) {
		if (e && t) {
			var r = Hh(this);
			n = zh(n), r.save();
			var i = r.canvas, a = 0;
			for (let o of t) {
				r.beginPath(), t = e[o.start];
				let s = e[o.end];
				t && s && (r.strokeStyle = Bh(n.color, {
					index: a,
					from: t,
					to: s
				}), r.lineWidth = Bh(n.lineWidth, {
					index: a,
					from: t,
					to: s
				}), r.moveTo(t.x * i.width, t.y * i.height), r.lineTo(s.x * i.width, s.y * i.height)), ++a, r.stroke();
			}
			r.restore();
		}
	}
	Ja(e, t) {
		var n = Hh(this);
		t = zh(t), n.save(), n.beginPath(), n.lineWidth = Bh(t.lineWidth, {}), n.strokeStyle = Bh(t.color, {}), n.fillStyle = Bh(t.fillColor, {}), n.moveTo(e.originX, e.originY), n.lineTo(e.originX + e.width, e.originY), n.lineTo(e.originX + e.width, e.originY + e.height), n.lineTo(e.originX, e.originY + e.height), n.lineTo(e.originX, e.originY), n.stroke(), n.fill(), n.restore();
	}
	Ka(e, t, n = [
		0,
		0,
		0,
		255
	]) {
		this.l ? function(e, t, n, r) {
			var i = Uh(e);
			Wh(e, t, (t) => {
				Gh(e, t, n, r), (t = Hh(e)).drawImage(i.canvas, 0, 0, t.canvas.width, t.canvas.height);
			});
		}(this, e, n, t) : Gh(this, e.T(), n, t);
	}
	La(e, t, n) {
		this.l ? function(e, t, n, r) {
			var i = Uh(e);
			Wh(e, t, (t) => {
				Kh(e, t, n, r), (t = Hh(e)).drawImage(i.canvas, 0, 0, t.canvas.width, t.canvas.height);
			});
		}(this, e, t, n) : Kh(this, e.T(), t, n);
	}
	close() {
		this.h?.close(), this.h = void 0, this.i?.close(), this.i = void 0, this.o?.close(), this.o = void 0;
	}
};
function Jh(e, t) {
	switch (t) {
		case 0: return e.h.find((e) => e instanceof ImageData);
		case 1: return e.h.find((e) => typeof ImageBitmap < "u" && e instanceof ImageBitmap);
		case 2: return e.h.find((e) => typeof WebGLTexture < "u" && e instanceof WebGLTexture);
		default: throw Error(`Type is not supported: ${t}`);
	}
}
function Yh(e) {
	var t = Jh(e, 0);
	if (!t) {
		t = Zh(e);
		let n = Qh(e), r = new Uint8Array(e.width * e.height * 4);
		Sh(n, t, Xh(e)), t.readPixels(0, 0, e.width, e.height, t.RGBA, t.UNSIGNED_BYTE, r), Ch(n), t = new ImageData(new Uint8ClampedArray(r.buffer), e.width, e.height), e.h.push(t);
	}
	return t;
}
function Xh(e) {
	var t = Jh(e, 2);
	if (!t) {
		let n = Zh(e);
		t = $h(e);
		let r = Jh(e, 1) || Yh(e);
		n.texImage2D(n.TEXTURE_2D, 0, n.RGBA, n.RGBA, n.UNSIGNED_BYTE, r), eg(e);
	}
	return t;
}
function Zh(e) {
	if (!e.canvas) throw Error("Conversion to different image formats require that a canvas is passed when initializing the image.");
	return e.i ||= hh(e.canvas.getContext("webgl2"), "You cannot use a canvas that is already bound to a different type of rendering context."), e.i;
}
function Qh(e) {
	return e.l ||= new wh(), e.l;
}
function $h(e) {
	var t = Zh(e);
	t.viewport(0, 0, e.width, e.height), t.activeTexture(t.TEXTURE0);
	var n = Jh(e, 2);
	return n || (n = xh(Qh(e), t), e.h.push(n), e.o = !0), t.bindTexture(t.TEXTURE_2D, n), n;
}
function eg(e) {
	e.i.bindTexture(e.i.TEXTURE_2D, null);
}
function tg(e) {
	var t = Zh(e);
	return bh(Qh(e), t, !0, () => function(e, t) {
		var n = e.canvas;
		if (n.width === e.width && n.height === e.height) return t();
		var r = n.width, i = n.height;
		return n.width = e.width, n.height = e.height, e = t(), n.width = r, n.height = i, e;
	}(e, () => {
		if (t.bindFramebuffer(t.FRAMEBUFFER, null), t.clearColor(0, 0, 0, 0), t.clear(t.COLOR_BUFFER_BIT), t.drawArrays(t.TRIANGLE_FAN, 0, 4), !(e.canvas instanceof OffscreenCanvas)) throw Error("Conversion to ImageBitmap requires that the MediaPipe Tasks is initialized with an OffscreenCanvas");
		return e.canvas.transferToImageBitmap();
	}));
}
qh.prototype.close = qh.prototype.close, qh.prototype.drawConfidenceMask = qh.prototype.La, qh.prototype.drawCategoryMask = qh.prototype.Ka, qh.prototype.drawBoundingBox = qh.prototype.Ja, qh.prototype.drawConnectors = qh.prototype.Ma, qh.prototype.drawLandmarks = qh.prototype.Na, qh.lerp = function(e, t, n, r, i) {
	return Vh(r * (1 - (e - t) / (n - t)) + i * (1 - (n - e) / (n - t)), r, i);
}, qh.clamp = Vh;
var ng = class {
	constructor(e, t, n, r, i, a, o) {
		this.h = e, this.u = t, this.o = n, this.canvas = r, this.l = i, this.width = a, this.height = o, (this.u || this.o) && --rg === 0 && console.error("You seem to be creating MPImage instances without invoking .close(). This leaks resources.");
	}
	Ua() {
		return !!Jh(this, 0);
	}
	wa() {
		return !!Jh(this, 1);
	}
	X() {
		return !!Jh(this, 2);
	}
	Ra() {
		return Yh(this);
	}
	Qa() {
		var e = Jh(this, 1);
		return e || (Xh(this), $h(this), e = tg(this), eg(this), this.h.push(e), this.u = !0), e;
	}
	T() {
		return Xh(this);
	}
	clone() {
		var e = [];
		for (let t of this.h) {
			let n;
			if (t instanceof ImageData) n = new ImageData(t.data, this.width, this.height);
			else if (t instanceof WebGLTexture) {
				let e = Zh(this), t = Qh(this);
				e.activeTexture(e.TEXTURE1), n = xh(t, e), e.bindTexture(e.TEXTURE_2D, n), e.texImage2D(e.TEXTURE_2D, 0, e.RGBA, this.width, this.height, 0, e.RGBA, e.UNSIGNED_BYTE, null), e.bindTexture(e.TEXTURE_2D, null), Sh(t, e, n), bh(t, e, !1, () => {
					$h(this), e.clearColor(0, 0, 0, 0), e.clear(e.COLOR_BUFFER_BIT), e.drawArrays(e.TRIANGLE_FAN, 0, 4), eg(this);
				}), Ch(t), eg(this);
			} else {
				if (!(t instanceof ImageBitmap)) throw Error(`Type is not supported: ${t}`);
				Xh(this), $h(this), n = tg(this), eg(this);
			}
			e.push(n);
		}
		return new ng(e, this.wa(), this.X(), this.canvas, this.l, this.width, this.height);
	}
	close() {
		this.u && Jh(this, 1).close(), this.o && Zh(this).deleteTexture(Jh(this, 2)), rg = -1;
	}
};
ng.prototype.close = ng.prototype.close, ng.prototype.clone = ng.prototype.clone, ng.prototype.getAsWebGLTexture = ng.prototype.T, ng.prototype.getAsImageBitmap = ng.prototype.Qa, ng.prototype.getAsImageData = ng.prototype.Ra, ng.prototype.hasWebGLTexture = ng.prototype.X, ng.prototype.hasImageBitmap = ng.prototype.wa, ng.prototype.hasImageData = ng.prototype.Ua;
var rg = 250;
function ig(...e) {
	return e.map(([e, t]) => ({
		start: e,
		end: t
	}));
}
var ag, og = rh((ag = nh(th), class extends ag {
	get pa() {
		return this.j;
	}
	Ea(e, t, n) {
		Y(this, t, (t) => {
			var [r, i] = Zm(this, e, t);
			this.pa._addBoundTextureAsImageToStream(t, r, i, n);
		});
	}
	ha(e, t) {
		$m(this, e, t), Y(this, e, (e) => {
			this.pa._attachImageListener(e);
		});
	}
	ia(e, t) {
		eh(this, e, t), Y(this, e, (e) => {
			this.pa._attachImageVectorListener(e);
		});
	}
})), sg = class extends og {};
async function Z(e, t, n) {
	return sh(e, n.canvas ?? (Jm() ? void 0 : document.createElement("canvas")), t, n);
}
function cg(e, t, n, r) {
	if (e.o && r !== void 0) {
		var i = L(e.baseOptions, sp, 3);
		i?.h() || i?.l()?.h() ? (++(i = e.o).h.U, i.i.set(r, performance.now())) : (++(i = e.o).h.R, i.i.set(r, performance.now()));
	}
	if (e.ra) {
		if (i = new Yf(), n?.regionOfInterest) {
			if (!e.Da) throw Error("This task doesn't support region-of-interest.");
			var a = n.regionOfInterest;
			if (a.left >= a.right || a.top >= a.bottom) throw Error("Expected RectF with left < right and top < bottom.");
			if (a.left < 0 || a.top < 0 || a.right > 1 || a.bottom > 1) throw Error("Expected RectF values to be in [0,1].");
			z(i, 1, (a.left + a.right) / 2), z(i, 2, (a.top + a.bottom) / 2), z(i, 4, a.right - a.left), z(i, 3, a.bottom - a.top);
		} else z(i, 1, .5), z(i, 2, .5), z(i, 4, 1), z(i, 3, 1);
		if (n?.rotationDegrees) {
			if (n?.rotationDegrees % 90 != 0) throw Error("Expected rotation to be a multiple of 90°.");
			if (z(i, 5, -Math.PI * n.rotationDegrees / 180), n?.rotationDegrees % 180 != 0) {
				let [e, r] = Xm(t);
				n = dl(i, 3) * r / e, a = dl(i, 4) * e / r, z(i, 4, n), z(i, 3, a);
			}
		}
		e.h.addProtoToStream(i.h(), "mediapipe.NormalizedRect", e.ra, r);
	}
	e.h.Ea(t, e.Ca, r ?? performance.now()), e.finishProcessing(r);
}
function lg(e, t, n) {
	if (e.K) throw Error("Task is not initialized with image mode. 'runningMode' must be set to 'IMAGE'.");
	cg(e, t, n, e.J + 1);
}
function ug(e, t, n, r) {
	if (!e.K) throw Error("Task is not initialized with video mode. 'runningMode' must be set to 'VIDEO'.");
	cg(e, t, n, r);
}
function dg(e, t, n, r) {
	var i = t.data, a = t.width, o = a * (t = t.height);
	if ((i instanceof Uint8Array || i instanceof Float32Array) && i.length !== o) throw Error("Unsupported channel count: " + i.length / o);
	return e = new Ih([i], n, !1, e.h.j.canvas, e.ea, a, t), r ? e.clone() : e;
}
var fg = class extends mh {
	constructor(e, t, n, r) {
		super(e), this.h = e, this.Ca = t, this.ra = n, this.Da = r, this.ea = new wh(), this.K = !1;
	}
	l(e, t = !0, n = !1, r = !1) {
		if ("runningMode" in e) {
			var i = this.K = !!e.runningMode && e.runningMode !== "IMAGE";
			I(this.baseOptions, 2, i == null ? i : Ns(i));
		}
		if (e.canvas !== void 0 && this.h.j.canvas !== e.canvas) throw Error("You must create a new task to reset the canvas.");
		return super.l(e, t, n, r);
	}
	close() {
		this.ea.close(), super.close();
	}
};
fg.prototype.close = fg.prototype.close;
var pg = class extends fg {
	constructor(e, t) {
		super(new sg(e, t), "image_in", "norm_rect_in", !1), this.m = { detections: [] }, R(e = this.i = new mp(), 0, 1, t = new up()), z(this.i, 2, .5), z(this.i, 3, .3);
	}
	D() {
		return "FaceDetector";
	}
	get baseOptions() {
		return L(this.i, up, 1);
	}
	set baseOptions(e) {
		R(this.i, 0, 1, e);
	}
	A(e) {
		return "minDetectionConfidence" in e && z(this.i, 2, e.minDetectionConfidence ?? .5), "minSuppressionThreshold" in e && z(this.i, 3, e.minSuppressionThreshold ?? .3), this.l(e);
	}
	H(e, t) {
		return this.m = { detections: [] }, lg(this, e, t), this.m;
	}
	I(e, t, n) {
		return this.m = { detections: [] }, ug(this, e, n, t), this.m;
	}
	u() {
		var e = new Mf();
		jf(e, "image_in"), jf(e, "norm_rect_in"), J(e, "detections");
		var t = new Sf();
		Ru(t, gp, this.i);
		var n = new Ef();
		vl(n, 2, "mediapipe.tasks.vision.face_detector.FaceDetectorGraph"), Tf(n, "IMAGE:image_in"), Tf(n, "NORM_RECT:norm_rect_in"), q(n, "DETECTIONS:detections"), n.A(t), Af(e, n), this.h.attachProtoVectorListener("detections", (e, t) => {
			for (let t of e) e = Hf(t), this.m.detections.push(mm(e));
			X(this, t);
		}), this.h.attachEmptyPacketListener("detections", (e) => {
			X(this, e);
		}), e = e.h(), this.setGraph(new Uint8Array(e), !0);
	}
};
pg.prototype.detectForVideo = pg.prototype.I, pg.prototype.detect = pg.prototype.H, pg.prototype.setOptions = pg.prototype.A, pg.createFromModelPath = async function(e, t) {
	return Z(pg, e, { baseOptions: { modelAssetPath: t } });
}, pg.createFromModelBuffer = function(e, t) {
	return Z(pg, e, { baseOptions: { modelAssetBuffer: t } });
}, pg.createFromOptions = function(e, t) {
	return Z(pg, e, t);
};
var mg = ig([61, 146], [146, 91], [91, 181], [181, 84], [84, 17], [17, 314], [314, 405], [405, 321], [321, 375], [375, 291], [61, 185], [185, 40], [40, 39], [39, 37], [37, 0], [0, 267], [267, 269], [269, 270], [270, 409], [409, 291], [78, 95], [95, 88], [88, 178], [178, 87], [87, 14], [14, 317], [317, 402], [402, 318], [318, 324], [324, 308], [78, 191], [191, 80], [80, 81], [81, 82], [82, 13], [13, 312], [312, 311], [311, 310], [310, 415], [415, 308]), hg = ig([263, 249], [249, 390], [390, 373], [373, 374], [374, 380], [380, 381], [381, 382], [382, 362], [263, 466], [466, 388], [388, 387], [387, 386], [386, 385], [385, 384], [384, 398], [398, 362]), gg = ig([276, 283], [283, 282], [282, 295], [295, 285], [300, 293], [293, 334], [334, 296], [296, 336]), _g = ig([474, 475], [475, 476], [476, 477], [477, 474]), vg = ig([33, 7], [7, 163], [163, 144], [144, 145], [145, 153], [153, 154], [154, 155], [155, 133], [33, 246], [246, 161], [161, 160], [160, 159], [159, 158], [158, 157], [157, 173], [173, 133]), yg = ig([46, 53], [53, 52], [52, 65], [65, 55], [70, 63], [63, 105], [105, 66], [66, 107]), bg = ig([469, 470], [470, 471], [471, 472], [472, 469]), xg = ig([10, 338], [338, 297], [297, 332], [332, 284], [284, 251], [251, 389], [389, 356], [356, 454], [454, 323], [323, 361], [361, 288], [288, 397], [397, 365], [365, 379], [379, 378], [378, 400], [400, 377], [377, 152], [152, 148], [148, 176], [176, 149], [149, 150], [150, 136], [136, 172], [172, 58], [58, 132], [132, 93], [93, 234], [234, 127], [127, 162], [162, 21], [21, 54], [54, 103], [103, 67], [67, 109], [109, 10]), Sg = [
	...mg,
	...hg,
	...gg,
	...vg,
	...yg,
	...xg
], Cg = ig([127, 34], [34, 139], [139, 127], [11, 0], [0, 37], [37, 11], [232, 231], [231, 120], [120, 232], [72, 37], [37, 39], [39, 72], [128, 121], [121, 47], [47, 128], [232, 121], [121, 128], [128, 232], [104, 69], [69, 67], [67, 104], [175, 171], [171, 148], [148, 175], [118, 50], [50, 101], [101, 118], [73, 39], [39, 40], [40, 73], [9, 151], [151, 108], [108, 9], [48, 115], [115, 131], [131, 48], [194, 204], [204, 211], [211, 194], [74, 40], [40, 185], [185, 74], [80, 42], [42, 183], [183, 80], [40, 92], [92, 186], [186, 40], [230, 229], [229, 118], [118, 230], [202, 212], [212, 214], [214, 202], [83, 18], [18, 17], [17, 83], [76, 61], [61, 146], [146, 76], [160, 29], [29, 30], [30, 160], [56, 157], [157, 173], [173, 56], [106, 204], [204, 194], [194, 106], [135, 214], [214, 192], [192, 135], [203, 165], [165, 98], [98, 203], [21, 71], [71, 68], [68, 21], [51, 45], [45, 4], [4, 51], [144, 24], [24, 23], [23, 144], [77, 146], [146, 91], [91, 77], [205, 50], [50, 187], [187, 205], [201, 200], [200, 18], [18, 201], [91, 106], [106, 182], [182, 91], [90, 91], [91, 181], [181, 90], [85, 84], [84, 17], [17, 85], [206, 203], [203, 36], [36, 206], [148, 171], [171, 140], [140, 148], [92, 40], [40, 39], [39, 92], [193, 189], [189, 244], [244, 193], [159, 158], [158, 28], [28, 159], [247, 246], [246, 161], [161, 247], [236, 3], [3, 196], [196, 236], [54, 68], [68, 104], [104, 54], [193, 168], [168, 8], [8, 193], [117, 228], [228, 31], [31, 117], [189, 193], [193, 55], [55, 189], [98, 97], [97, 99], [99, 98], [126, 47], [47, 100], [100, 126], [166, 79], [79, 218], [218, 166], [155, 154], [154, 26], [26, 155], [209, 49], [49, 131], [131, 209], [135, 136], [136, 150], [150, 135], [47, 126], [126, 217], [217, 47], [223, 52], [52, 53], [53, 223], [45, 51], [51, 134], [134, 45], [211, 170], [170, 140], [140, 211], [67, 69], [69, 108], [108, 67], [43, 106], [106, 91], [91, 43], [230, 119], [119, 120], [120, 230], [226, 130], [130, 247], [247, 226], [63, 53], [53, 52], [52, 63], [238, 20], [20, 242], [242, 238], [46, 70], [70, 156], [156, 46], [78, 62], [62, 96], [96, 78], [46, 53], [53, 63], [63, 46], [143, 34], [34, 227], [227, 143], [123, 117], [117, 111], [111, 123], [44, 125], [125, 19], [19, 44], [236, 134], [134, 51], [51, 236], [216, 206], [206, 205], [205, 216], [154, 153], [153, 22], [22, 154], [39, 37], [37, 167], [167, 39], [200, 201], [201, 208], [208, 200], [36, 142], [142, 100], [100, 36], [57, 212], [212, 202], [202, 57], [20, 60], [60, 99], [99, 20], [28, 158], [158, 157], [157, 28], [35, 226], [226, 113], [113, 35], [160, 159], [159, 27], [27, 160], [204, 202], [202, 210], [210, 204], [113, 225], [225, 46], [46, 113], [43, 202], [202, 204], [204, 43], [62, 76], [76, 77], [77, 62], [137, 123], [123, 116], [116, 137], [41, 38], [38, 72], [72, 41], [203, 129], [129, 142], [142, 203], [64, 98], [98, 240], [240, 64], [49, 102], [102, 64], [64, 49], [41, 73], [73, 74], [74, 41], [212, 216], [216, 207], [207, 212], [42, 74], [74, 184], [184, 42], [169, 170], [170, 211], [211, 169], [170, 149], [149, 176], [176, 170], [105, 66], [66, 69], [69, 105], [122, 6], [6, 168], [168, 122], [123, 147], [147, 187], [187, 123], [96, 77], [77, 90], [90, 96], [65, 55], [55, 107], [107, 65], [89, 90], [90, 180], [180, 89], [101, 100], [100, 120], [120, 101], [63, 105], [105, 104], [104, 63], [93, 137], [137, 227], [227, 93], [15, 86], [86, 85], [85, 15], [129, 102], [102, 49], [49, 129], [14, 87], [87, 86], [86, 14], [55, 8], [8, 9], [9, 55], [100, 47], [47, 121], [121, 100], [145, 23], [23, 22], [22, 145], [88, 89], [89, 179], [179, 88], [6, 122], [122, 196], [196, 6], [88, 95], [95, 96], [96, 88], [138, 172], [172, 136], [136, 138], [215, 58], [58, 172], [172, 215], [115, 48], [48, 219], [219, 115], [42, 80], [80, 81], [81, 42], [195, 3], [3, 51], [51, 195], [43, 146], [146, 61], [61, 43], [171, 175], [175, 199], [199, 171], [81, 82], [82, 38], [38, 81], [53, 46], [46, 225], [225, 53], [144, 163], [163, 110], [110, 144], [52, 65], [65, 66], [66, 52], [229, 228], [228, 117], [117, 229], [34, 127], [127, 234], [234, 34], [107, 108], [108, 69], [69, 107], [109, 108], [108, 151], [151, 109], [48, 64], [64, 235], [235, 48], [62, 78], [78, 191], [191, 62], [129, 209], [209, 126], [126, 129], [111, 35], [35, 143], [143, 111], [117, 123], [123, 50], [50, 117], [222, 65], [65, 52], [52, 222], [19, 125], [125, 141], [141, 19], [221, 55], [55, 65], [65, 221], [3, 195], [195, 197], [197, 3], [25, 7], [7, 33], [33, 25], [220, 237], [237, 44], [44, 220], [70, 71], [71, 139], [139, 70], [122, 193], [193, 245], [245, 122], [247, 130], [130, 33], [33, 247], [71, 21], [21, 162], [162, 71], [170, 169], [169, 150], [150, 170], [188, 174], [174, 196], [196, 188], [216, 186], [186, 92], [92, 216], [2, 97], [97, 167], [167, 2], [141, 125], [125, 241], [241, 141], [164, 167], [167, 37], [37, 164], [72, 38], [38, 12], [12, 72], [38, 82], [82, 13], [13, 38], [63, 68], [68, 71], [71, 63], [226, 35], [35, 111], [111, 226], [101, 50], [50, 205], [205, 101], [206, 92], [92, 165], [165, 206], [209, 198], [198, 217], [217, 209], [165, 167], [167, 97], [97, 165], [220, 115], [115, 218], [218, 220], [133, 112], [112, 243], [243, 133], [239, 238], [238, 241], [241, 239], [214, 135], [135, 169], [169, 214], [190, 173], [173, 133], [133, 190], [171, 208], [208, 32], [32, 171], [125, 44], [44, 237], [237, 125], [86, 87], [87, 178], [178, 86], [85, 86], [86, 179], [179, 85], [84, 85], [85, 180], [180, 84], [83, 84], [84, 181], [181, 83], [201, 83], [83, 182], [182, 201], [137, 93], [93, 132], [132, 137], [76, 62], [62, 183], [183, 76], [61, 76], [76, 184], [184, 61], [57, 61], [61, 185], [185, 57], [212, 57], [57, 186], [186, 212], [214, 207], [207, 187], [187, 214], [34, 143], [143, 156], [156, 34], [79, 239], [239, 237], [237, 79], [123, 137], [137, 177], [177, 123], [44, 1], [1, 4], [4, 44], [201, 194], [194, 32], [32, 201], [64, 102], [102, 129], [129, 64], [213, 215], [215, 138], [138, 213], [59, 166], [166, 219], [219, 59], [242, 99], [99, 97], [97, 242], [2, 94], [94, 141], [141, 2], [75, 59], [59, 235], [235, 75], [24, 110], [110, 228], [228, 24], [25, 130], [130, 226], [226, 25], [23, 24], [24, 229], [229, 23], [22, 23], [23, 230], [230, 22], [26, 22], [22, 231], [231, 26], [112, 26], [26, 232], [232, 112], [189, 190], [190, 243], [243, 189], [221, 56], [56, 190], [190, 221], [28, 56], [56, 221], [221, 28], [27, 28], [28, 222], [222, 27], [29, 27], [27, 223], [223, 29], [30, 29], [29, 224], [224, 30], [247, 30], [30, 225], [225, 247], [238, 79], [79, 20], [20, 238], [166, 59], [59, 75], [75, 166], [60, 75], [75, 240], [240, 60], [147, 177], [177, 215], [215, 147], [20, 79], [79, 166], [166, 20], [187, 147], [147, 213], [213, 187], [112, 233], [233, 244], [244, 112], [233, 128], [128, 245], [245, 233], [128, 114], [114, 188], [188, 128], [114, 217], [217, 174], [174, 114], [131, 115], [115, 220], [220, 131], [217, 198], [198, 236], [236, 217], [198, 131], [131, 134], [134, 198], [177, 132], [132, 58], [58, 177], [143, 35], [35, 124], [124, 143], [110, 163], [163, 7], [7, 110], [228, 110], [110, 25], [25, 228], [356, 389], [389, 368], [368, 356], [11, 302], [302, 267], [267, 11], [452, 350], [350, 349], [349, 452], [302, 303], [303, 269], [269, 302], [357, 343], [343, 277], [277, 357], [452, 453], [453, 357], [357, 452], [333, 332], [332, 297], [297, 333], [175, 152], [152, 377], [377, 175], [347, 348], [348, 330], [330, 347], [303, 304], [304, 270], [270, 303], [9, 336], [336, 337], [337, 9], [278, 279], [279, 360], [360, 278], [418, 262], [262, 431], [431, 418], [304, 408], [408, 409], [409, 304], [310, 415], [415, 407], [407, 310], [270, 409], [409, 410], [410, 270], [450, 348], [348, 347], [347, 450], [422, 430], [430, 434], [434, 422], [313, 314], [314, 17], [17, 313], [306, 307], [307, 375], [375, 306], [387, 388], [388, 260], [260, 387], [286, 414], [414, 398], [398, 286], [335, 406], [406, 418], [418, 335], [364, 367], [367, 416], [416, 364], [423, 358], [358, 327], [327, 423], [251, 284], [284, 298], [298, 251], [281, 5], [5, 4], [4, 281], [373, 374], [374, 253], [253, 373], [307, 320], [320, 321], [321, 307], [425, 427], [427, 411], [411, 425], [421, 313], [313, 18], [18, 421], [321, 405], [405, 406], [406, 321], [320, 404], [404, 405], [405, 320], [315, 16], [16, 17], [17, 315], [426, 425], [425, 266], [266, 426], [377, 400], [400, 369], [369, 377], [322, 391], [391, 269], [269, 322], [417, 465], [465, 464], [464, 417], [386, 257], [257, 258], [258, 386], [466, 260], [260, 388], [388, 466], [456, 399], [399, 419], [419, 456], [284, 332], [332, 333], [333, 284], [417, 285], [285, 8], [8, 417], [346, 340], [340, 261], [261, 346], [413, 441], [441, 285], [285, 413], [327, 460], [460, 328], [328, 327], [355, 371], [371, 329], [329, 355], [392, 439], [439, 438], [438, 392], [382, 341], [341, 256], [256, 382], [429, 420], [420, 360], [360, 429], [364, 394], [394, 379], [379, 364], [277, 343], [343, 437], [437, 277], [443, 444], [444, 283], [283, 443], [275, 440], [440, 363], [363, 275], [431, 262], [262, 369], [369, 431], [297, 338], [338, 337], [337, 297], [273, 375], [375, 321], [321, 273], [450, 451], [451, 349], [349, 450], [446, 342], [342, 467], [467, 446], [293, 334], [334, 282], [282, 293], [458, 461], [461, 462], [462, 458], [276, 353], [353, 383], [383, 276], [308, 324], [324, 325], [325, 308], [276, 300], [300, 293], [293, 276], [372, 345], [345, 447], [447, 372], [352, 345], [345, 340], [340, 352], [274, 1], [1, 19], [19, 274], [456, 248], [248, 281], [281, 456], [436, 427], [427, 425], [425, 436], [381, 256], [256, 252], [252, 381], [269, 391], [391, 393], [393, 269], [200, 199], [199, 428], [428, 200], [266, 330], [330, 329], [329, 266], [287, 273], [273, 422], [422, 287], [250, 462], [462, 328], [328, 250], [258, 286], [286, 384], [384, 258], [265, 353], [353, 342], [342, 265], [387, 259], [259, 257], [257, 387], [424, 431], [431, 430], [430, 424], [342, 353], [353, 276], [276, 342], [273, 335], [335, 424], [424, 273], [292, 325], [325, 307], [307, 292], [366, 447], [447, 345], [345, 366], [271, 303], [303, 302], [302, 271], [423, 266], [266, 371], [371, 423], [294, 455], [455, 460], [460, 294], [279, 278], [278, 294], [294, 279], [271, 272], [272, 304], [304, 271], [432, 434], [434, 427], [427, 432], [272, 407], [407, 408], [408, 272], [394, 430], [430, 431], [431, 394], [395, 369], [369, 400], [400, 395], [334, 333], [333, 299], [299, 334], [351, 417], [417, 168], [168, 351], [352, 280], [280, 411], [411, 352], [325, 319], [319, 320], [320, 325], [295, 296], [296, 336], [336, 295], [319, 403], [403, 404], [404, 319], [330, 348], [348, 349], [349, 330], [293, 298], [298, 333], [333, 293], [323, 454], [454, 447], [447, 323], [15, 16], [16, 315], [315, 15], [358, 429], [429, 279], [279, 358], [14, 15], [15, 316], [316, 14], [285, 336], [336, 9], [9, 285], [329, 349], [349, 350], [350, 329], [374, 380], [380, 252], [252, 374], [318, 402], [402, 403], [403, 318], [6, 197], [197, 419], [419, 6], [318, 319], [319, 325], [325, 318], [367, 364], [364, 365], [365, 367], [435, 367], [367, 397], [397, 435], [344, 438], [438, 439], [439, 344], [272, 271], [271, 311], [311, 272], [195, 5], [5, 281], [281, 195], [273, 287], [287, 291], [291, 273], [396, 428], [428, 199], [199, 396], [311, 271], [271, 268], [268, 311], [283, 444], [444, 445], [445, 283], [373, 254], [254, 339], [339, 373], [282, 334], [334, 296], [296, 282], [449, 347], [347, 346], [346, 449], [264, 447], [447, 454], [454, 264], [336, 296], [296, 299], [299, 336], [338, 10], [10, 151], [151, 338], [278, 439], [439, 455], [455, 278], [292, 407], [407, 415], [415, 292], [358, 371], [371, 355], [355, 358], [340, 345], [345, 372], [372, 340], [346, 347], [347, 280], [280, 346], [442, 443], [443, 282], [282, 442], [19, 94], [94, 370], [370, 19], [441, 442], [442, 295], [295, 441], [248, 419], [419, 197], [197, 248], [263, 255], [255, 359], [359, 263], [440, 275], [275, 274], [274, 440], [300, 383], [383, 368], [368, 300], [351, 412], [412, 465], [465, 351], [263, 467], [467, 466], [466, 263], [301, 368], [368, 389], [389, 301], [395, 378], [378, 379], [379, 395], [412, 351], [351, 419], [419, 412], [436, 426], [426, 322], [322, 436], [2, 164], [164, 393], [393, 2], [370, 462], [462, 461], [461, 370], [164, 0], [0, 267], [267, 164], [302, 11], [11, 12], [12, 302], [268, 12], [12, 13], [13, 268], [293, 300], [300, 301], [301, 293], [446, 261], [261, 340], [340, 446], [330, 266], [266, 425], [425, 330], [426, 423], [423, 391], [391, 426], [429, 355], [355, 437], [437, 429], [391, 327], [327, 326], [326, 391], [440, 457], [457, 438], [438, 440], [341, 382], [382, 362], [362, 341], [459, 457], [457, 461], [461, 459], [434, 430], [430, 394], [394, 434], [414, 463], [463, 362], [362, 414], [396, 369], [369, 262], [262, 396], [354, 461], [461, 457], [457, 354], [316, 403], [403, 402], [402, 316], [315, 404], [404, 403], [403, 315], [314, 405], [405, 404], [404, 314], [313, 406], [406, 405], [405, 313], [421, 418], [418, 406], [406, 421], [366, 401], [401, 361], [361, 366], [306, 408], [408, 407], [407, 306], [291, 409], [409, 408], [408, 291], [287, 410], [410, 409], [409, 287], [432, 436], [436, 410], [410, 432], [434, 416], [416, 411], [411, 434], [264, 368], [368, 383], [383, 264], [309, 438], [438, 457], [457, 309], [352, 376], [376, 401], [401, 352], [274, 275], [275, 4], [4, 274], [421, 428], [428, 262], [262, 421], [294, 327], [327, 358], [358, 294], [433, 416], [416, 367], [367, 433], [289, 455], [455, 439], [439, 289], [462, 370], [370, 326], [326, 462], [2, 326], [326, 370], [370, 2], [305, 460], [460, 455], [455, 305], [254, 449], [449, 448], [448, 254], [255, 261], [261, 446], [446, 255], [253, 450], [450, 449], [449, 253], [252, 451], [451, 450], [450, 252], [256, 452], [452, 451], [451, 256], [341, 453], [453, 452], [452, 341], [413, 464], [464, 463], [463, 413], [441, 413], [413, 414], [414, 441], [258, 442], [442, 441], [441, 258], [257, 443], [443, 442], [442, 257], [259, 444], [444, 443], [443, 259], [260, 445], [445, 444], [444, 260], [467, 342], [342, 445], [445, 467], [459, 458], [458, 250], [250, 459], [289, 392], [392, 290], [290, 289], [290, 328], [328, 460], [460, 290], [376, 433], [433, 435], [435, 376], [250, 290], [290, 392], [392, 250], [411, 416], [416, 433], [433, 411], [341, 463], [463, 464], [464, 341], [453, 464], [464, 465], [465, 453], [357, 465], [465, 412], [412, 357], [343, 412], [412, 399], [399, 343], [360, 363], [363, 440], [440, 360], [437, 399], [399, 456], [456, 437], [420, 456], [456, 363], [363, 420], [401, 435], [435, 288], [288, 401], [372, 383], [383, 353], [353, 372], [339, 255], [255, 249], [249, 339], [448, 261], [261, 255], [255, 448], [133, 243], [243, 190], [190, 133], [133, 155], [155, 112], [112, 133], [33, 246], [246, 247], [247, 33], [33, 130], [130, 25], [25, 33], [398, 384], [384, 286], [286, 398], [362, 398], [398, 414], [414, 362], [362, 463], [463, 341], [341, 362], [263, 359], [359, 467], [467, 263], [263, 249], [249, 255], [255, 263], [466, 467], [467, 260], [260, 466], [75, 60], [60, 166], [166, 75], [238, 239], [239, 79], [79, 238], [162, 127], [127, 139], [139, 162], [72, 11], [11, 37], [37, 72], [121, 232], [232, 120], [120, 121], [73, 72], [72, 39], [39, 73], [114, 128], [128, 47], [47, 114], [233, 232], [232, 128], [128, 233], [103, 104], [104, 67], [67, 103], [152, 175], [175, 148], [148, 152], [119, 118], [118, 101], [101, 119], [74, 73], [73, 40], [40, 74], [107, 9], [9, 108], [108, 107], [49, 48], [48, 131], [131, 49], [32, 194], [194, 211], [211, 32], [184, 74], [74, 185], [185, 184], [191, 80], [80, 183], [183, 191], [185, 40], [40, 186], [186, 185], [119, 230], [230, 118], [118, 119], [210, 202], [202, 214], [214, 210], [84, 83], [83, 17], [17, 84], [77, 76], [76, 146], [146, 77], [161, 160], [160, 30], [30, 161], [190, 56], [56, 173], [173, 190], [182, 106], [106, 194], [194, 182], [138, 135], [135, 192], [192, 138], [129, 203], [203, 98], [98, 129], [54, 21], [21, 68], [68, 54], [5, 51], [51, 4], [4, 5], [145, 144], [144, 23], [23, 145], [90, 77], [77, 91], [91, 90], [207, 205], [205, 187], [187, 207], [83, 201], [201, 18], [18, 83], [181, 91], [91, 182], [182, 181], [180, 90], [90, 181], [181, 180], [16, 85], [85, 17], [17, 16], [205, 206], [206, 36], [36, 205], [176, 148], [148, 140], [140, 176], [165, 92], [92, 39], [39, 165], [245, 193], [193, 244], [244, 245], [27, 159], [159, 28], [28, 27], [30, 247], [247, 161], [161, 30], [174, 236], [236, 196], [196, 174], [103, 54], [54, 104], [104, 103], [55, 193], [193, 8], [8, 55], [111, 117], [117, 31], [31, 111], [221, 189], [189, 55], [55, 221], [240, 98], [98, 99], [99, 240], [142, 126], [126, 100], [100, 142], [219, 166], [166, 218], [218, 219], [112, 155], [155, 26], [26, 112], [198, 209], [209, 131], [131, 198], [169, 135], [135, 150], [150, 169], [114, 47], [47, 217], [217, 114], [224, 223], [223, 53], [53, 224], [220, 45], [45, 134], [134, 220], [32, 211], [211, 140], [140, 32], [109, 67], [67, 108], [108, 109], [146, 43], [43, 91], [91, 146], [231, 230], [230, 120], [120, 231], [113, 226], [226, 247], [247, 113], [105, 63], [63, 52], [52, 105], [241, 238], [238, 242], [242, 241], [124, 46], [46, 156], [156, 124], [95, 78], [78, 96], [96, 95], [70, 46], [46, 63], [63, 70], [116, 143], [143, 227], [227, 116], [116, 123], [123, 111], [111, 116], [1, 44], [44, 19], [19, 1], [3, 236], [236, 51], [51, 3], [207, 216], [216, 205], [205, 207], [26, 154], [154, 22], [22, 26], [165, 39], [39, 167], [167, 165], [199, 200], [200, 208], [208, 199], [101, 36], [36, 100], [100, 101], [43, 57], [57, 202], [202, 43], [242, 20], [20, 99], [99, 242], [56, 28], [28, 157], [157, 56], [124, 35], [35, 113], [113, 124], [29, 160], [160, 27], [27, 29], [211, 204], [204, 210], [210, 211], [124, 113], [113, 46], [46, 124], [106, 43], [43, 204], [204, 106], [96, 62], [62, 77], [77, 96], [227, 137], [137, 116], [116, 227], [73, 41], [41, 72], [72, 73], [36, 203], [203, 142], [142, 36], [235, 64], [64, 240], [240, 235], [48, 49], [49, 64], [64, 48], [42, 41], [41, 74], [74, 42], [214, 212], [212, 207], [207, 214], [183, 42], [42, 184], [184, 183], [210, 169], [169, 211], [211, 210], [140, 170], [170, 176], [176, 140], [104, 105], [105, 69], [69, 104], [193, 122], [122, 168], [168, 193], [50, 123], [123, 187], [187, 50], [89, 96], [96, 90], [90, 89], [66, 65], [65, 107], [107, 66], [179, 89], [89, 180], [180, 179], [119, 101], [101, 120], [120, 119], [68, 63], [63, 104], [104, 68], [234, 93], [93, 227], [227, 234], [16, 15], [15, 85], [85, 16], [209, 129], [129, 49], [49, 209], [15, 14], [14, 86], [86, 15], [107, 55], [55, 9], [9, 107], [120, 100], [100, 121], [121, 120], [153, 145], [145, 22], [22, 153], [178, 88], [88, 179], [179, 178], [197, 6], [6, 196], [196, 197], [89, 88], [88, 96], [96, 89], [135, 138], [138, 136], [136, 135], [138, 215], [215, 172], [172, 138], [218, 115], [115, 219], [219, 218], [41, 42], [42, 81], [81, 41], [5, 195], [195, 51], [51, 5], [57, 43], [43, 61], [61, 57], [208, 171], [171, 199], [199, 208], [41, 81], [81, 38], [38, 41], [224, 53], [53, 225], [225, 224], [24, 144], [144, 110], [110, 24], [105, 52], [52, 66], [66, 105], [118, 229], [229, 117], [117, 118], [227, 34], [34, 234], [234, 227], [66, 107], [107, 69], [69, 66], [10, 109], [109, 151], [151, 10], [219, 48], [48, 235], [235, 219], [183, 62], [62, 191], [191, 183], [142, 129], [129, 126], [126, 142], [116, 111], [111, 143], [143, 116], [118, 117], [117, 50], [50, 118], [223, 222], [222, 52], [52, 223], [94, 19], [19, 141], [141, 94], [222, 221], [221, 65], [65, 222], [196, 3], [3, 197], [197, 196], [45, 220], [220, 44], [44, 45], [156, 70], [70, 139], [139, 156], [188, 122], [122, 245], [245, 188], [139, 71], [71, 162], [162, 139], [149, 170], [170, 150], [150, 149], [122, 188], [188, 196], [196, 122], [206, 216], [216, 92], [92, 206], [164, 2], [2, 167], [167, 164], [242, 141], [141, 241], [241, 242], [0, 164], [164, 37], [37, 0], [11, 72], [72, 12], [12, 11], [12, 38], [38, 13], [13, 12], [70, 63], [63, 71], [71, 70], [31, 226], [226, 111], [111, 31], [36, 101], [101, 205], [205, 36], [203, 206], [206, 165], [165, 203], [126, 209], [209, 217], [217, 126], [98, 165], [165, 97], [97, 98], [237, 220], [220, 218], [218, 237], [237, 239], [239, 241], [241, 237], [210, 214], [214, 169], [169, 210], [140, 171], [171, 32], [32, 140], [241, 125], [125, 237], [237, 241], [179, 86], [86, 178], [178, 179], [180, 85], [85, 179], [179, 180], [181, 84], [84, 180], [180, 181], [182, 83], [83, 181], [181, 182], [194, 201], [201, 182], [182, 194], [177, 137], [137, 132], [132, 177], [184, 76], [76, 183], [183, 184], [185, 61], [61, 184], [184, 185], [186, 57], [57, 185], [185, 186], [216, 212], [212, 186], [186, 216], [192, 214], [214, 187], [187, 192], [139, 34], [34, 156], [156, 139], [218, 79], [79, 237], [237, 218], [147, 123], [123, 177], [177, 147], [45, 44], [44, 4], [4, 45], [208, 201], [201, 32], [32, 208], [98, 64], [64, 129], [129, 98], [192, 213], [213, 138], [138, 192], [235, 59], [59, 219], [219, 235], [141, 242], [242, 97], [97, 141], [97, 2], [2, 141], [141, 97], [240, 75], [75, 235], [235, 240], [229, 24], [24, 228], [228, 229], [31, 25], [25, 226], [226, 31], [230, 23], [23, 229], [229, 230], [231, 22], [22, 230], [230, 231], [232, 26], [26, 231], [231, 232], [233, 112], [112, 232], [232, 233], [244, 189], [189, 243], [243, 244], [189, 221], [221, 190], [190, 189], [222, 28], [28, 221], [221, 222], [223, 27], [27, 222], [222, 223], [224, 29], [29, 223], [223, 224], [225, 30], [30, 224], [224, 225], [113, 247], [247, 225], [225, 113], [99, 60], [60, 240], [240, 99], [213, 147], [147, 215], [215, 213], [60, 20], [20, 166], [166, 60], [192, 187], [187, 213], [213, 192], [243, 112], [112, 244], [244, 243], [244, 233], [233, 245], [245, 244], [245, 128], [128, 188], [188, 245], [188, 114], [114, 174], [174, 188], [134, 131], [131, 220], [220, 134], [174, 217], [217, 236], [236, 174], [236, 198], [198, 134], [134, 236], [215, 177], [177, 58], [58, 215], [156, 143], [143, 124], [124, 156], [25, 110], [110, 7], [7, 25], [31, 228], [228, 25], [25, 31], [264, 356], [356, 368], [368, 264], [0, 11], [11, 267], [267, 0], [451, 452], [452, 349], [349, 451], [267, 302], [302, 269], [269, 267], [350, 357], [357, 277], [277, 350], [350, 452], [452, 357], [357, 350], [299, 333], [333, 297], [297, 299], [396, 175], [175, 377], [377, 396], [280, 347], [347, 330], [330, 280], [269, 303], [303, 270], [270, 269], [151, 9], [9, 337], [337, 151], [344, 278], [278, 360], [360, 344], [424, 418], [418, 431], [431, 424], [270, 304], [304, 409], [409, 270], [272, 310], [310, 407], [407, 272], [322, 270], [270, 410], [410, 322], [449, 450], [450, 347], [347, 449], [432, 422], [422, 434], [434, 432], [18, 313], [313, 17], [17, 18], [291, 306], [306, 375], [375, 291], [259, 387], [387, 260], [260, 259], [424, 335], [335, 418], [418, 424], [434, 364], [364, 416], [416, 434], [391, 423], [423, 327], [327, 391], [301, 251], [251, 298], [298, 301], [275, 281], [281, 4], [4, 275], [254, 373], [373, 253], [253, 254], [375, 307], [307, 321], [321, 375], [280, 425], [425, 411], [411, 280], [200, 421], [421, 18], [18, 200], [335, 321], [321, 406], [406, 335], [321, 320], [320, 405], [405, 321], [314, 315], [315, 17], [17, 314], [423, 426], [426, 266], [266, 423], [396, 377], [377, 369], [369, 396], [270, 322], [322, 269], [269, 270], [413, 417], [417, 464], [464, 413], [385, 386], [386, 258], [258, 385], [248, 456], [456, 419], [419, 248], [298, 284], [284, 333], [333, 298], [168, 417], [417, 8], [8, 168], [448, 346], [346, 261], [261, 448], [417, 413], [413, 285], [285, 417], [326, 327], [327, 328], [328, 326], [277, 355], [355, 329], [329, 277], [309, 392], [392, 438], [438, 309], [381, 382], [382, 256], [256, 381], [279, 429], [429, 360], [360, 279], [365, 364], [364, 379], [379, 365], [355, 277], [277, 437], [437, 355], [282, 443], [443, 283], [283, 282], [281, 275], [275, 363], [363, 281], [395, 431], [431, 369], [369, 395], [299, 297], [297, 337], [337, 299], [335, 273], [273, 321], [321, 335], [348, 450], [450, 349], [349, 348], [359, 446], [446, 467], [467, 359], [283, 293], [293, 282], [282, 283], [250, 458], [458, 462], [462, 250], [300, 276], [276, 383], [383, 300], [292, 308], [308, 325], [325, 292], [283, 276], [276, 293], [293, 283], [264, 372], [372, 447], [447, 264], [346, 352], [352, 340], [340, 346], [354, 274], [274, 19], [19, 354], [363, 456], [456, 281], [281, 363], [426, 436], [436, 425], [425, 426], [380, 381], [381, 252], [252, 380], [267, 269], [269, 393], [393, 267], [421, 200], [200, 428], [428, 421], [371, 266], [266, 329], [329, 371], [432, 287], [287, 422], [422, 432], [290, 250], [250, 328], [328, 290], [385, 258], [258, 384], [384, 385], [446, 265], [265, 342], [342, 446], [386, 387], [387, 257], [257, 386], [422, 424], [424, 430], [430, 422], [445, 342], [342, 276], [276, 445], [422, 273], [273, 424], [424, 422], [306, 292], [292, 307], [307, 306], [352, 366], [366, 345], [345, 352], [268, 271], [271, 302], [302, 268], [358, 423], [423, 371], [371, 358], [327, 294], [294, 460], [460, 327], [331, 279], [279, 294], [294, 331], [303, 271], [271, 304], [304, 303], [436, 432], [432, 427], [427, 436], [304, 272], [272, 408], [408, 304], [395, 394], [394, 431], [431, 395], [378, 395], [395, 400], [400, 378], [296, 334], [334, 299], [299, 296], [6, 351], [351, 168], [168, 6], [376, 352], [352, 411], [411, 376], [307, 325], [325, 320], [320, 307], [285, 295], [295, 336], [336, 285], [320, 319], [319, 404], [404, 320], [329, 330], [330, 349], [349, 329], [334, 293], [293, 333], [333, 334], [366, 323], [323, 447], [447, 366], [316, 15], [15, 315], [315, 316], [331, 358], [358, 279], [279, 331], [317, 14], [14, 316], [316, 317], [8, 285], [285, 9], [9, 8], [277, 329], [329, 350], [350, 277], [253, 374], [374, 252], [252, 253], [319, 318], [318, 403], [403, 319], [351, 6], [6, 419], [419, 351], [324, 318], [318, 325], [325, 324], [397, 367], [367, 365], [365, 397], [288, 435], [435, 397], [397, 288], [278, 344], [344, 439], [439, 278], [310, 272], [272, 311], [311, 310], [248, 195], [195, 281], [281, 248], [375, 273], [273, 291], [291, 375], [175, 396], [396, 199], [199, 175], [312, 311], [311, 268], [268, 312], [276, 283], [283, 445], [445, 276], [390, 373], [373, 339], [339, 390], [295, 282], [282, 296], [296, 295], [448, 449], [449, 346], [346, 448], [356, 264], [264, 454], [454, 356], [337, 336], [336, 299], [299, 337], [337, 338], [338, 151], [151, 337], [294, 278], [278, 455], [455, 294], [308, 292], [292, 415], [415, 308], [429, 358], [358, 355], [355, 429], [265, 340], [340, 372], [372, 265], [352, 346], [346, 280], [280, 352], [295, 442], [442, 282], [282, 295], [354, 19], [19, 370], [370, 354], [285, 441], [441, 295], [295, 285], [195, 248], [248, 197], [197, 195], [457, 440], [440, 274], [274, 457], [301, 300], [300, 368], [368, 301], [417, 351], [351, 465], [465, 417], [251, 301], [301, 389], [389, 251], [394, 395], [395, 379], [379, 394], [399, 412], [412, 419], [419, 399], [410, 436], [436, 322], [322, 410], [326, 2], [2, 393], [393, 326], [354, 370], [370, 461], [461, 354], [393, 164], [164, 267], [267, 393], [268, 302], [302, 12], [12, 268], [312, 268], [268, 13], [13, 312], [298, 293], [293, 301], [301, 298], [265, 446], [446, 340], [340, 265], [280, 330], [330, 425], [425, 280], [322, 426], [426, 391], [391, 322], [420, 429], [429, 437], [437, 420], [393, 391], [391, 326], [326, 393], [344, 440], [440, 438], [438, 344], [458, 459], [459, 461], [461, 458], [364, 434], [434, 394], [394, 364], [428, 396], [396, 262], [262, 428], [274, 354], [354, 457], [457, 274], [317, 316], [316, 402], [402, 317], [316, 315], [315, 403], [403, 316], [315, 314], [314, 404], [404, 315], [314, 313], [313, 405], [405, 314], [313, 421], [421, 406], [406, 313], [323, 366], [366, 361], [361, 323], [292, 306], [306, 407], [407, 292], [306, 291], [291, 408], [408, 306], [291, 287], [287, 409], [409, 291], [287, 432], [432, 410], [410, 287], [427, 434], [434, 411], [411, 427], [372, 264], [264, 383], [383, 372], [459, 309], [309, 457], [457, 459], [366, 352], [352, 401], [401, 366], [1, 274], [274, 4], [4, 1], [418, 421], [421, 262], [262, 418], [331, 294], [294, 358], [358, 331], [435, 433], [433, 367], [367, 435], [392, 289], [289, 439], [439, 392], [328, 462], [462, 326], [326, 328], [94, 2], [2, 370], [370, 94], [289, 305], [305, 455], [455, 289], [339, 254], [254, 448], [448, 339], [359, 255], [255, 446], [446, 359], [254, 253], [253, 449], [449, 254], [253, 252], [252, 450], [450, 253], [252, 256], [256, 451], [451, 252], [256, 341], [341, 452], [452, 256], [414, 413], [413, 463], [463, 414], [286, 441], [441, 414], [414, 286], [286, 258], [258, 441], [441, 286], [258, 257], [257, 442], [442, 258], [257, 259], [259, 443], [443, 257], [259, 260], [260, 444], [444, 259], [260, 467], [467, 445], [445, 260], [309, 459], [459, 250], [250, 309], [305, 289], [289, 290], [290, 305], [305, 290], [290, 460], [460, 305], [401, 376], [376, 435], [435, 401], [309, 250], [250, 392], [392, 309], [376, 411], [411, 433], [433, 376], [453, 341], [341, 464], [464, 453], [357, 453], [453, 465], [465, 357], [343, 357], [357, 412], [412, 343], [437, 343], [343, 399], [399, 437], [344, 360], [360, 440], [440, 344], [420, 437], [437, 456], [456, 420], [360, 420], [420, 363], [363, 360], [361, 401], [401, 288], [288, 361], [265, 372], [372, 353], [353, 265], [390, 339], [339, 249], [249, 390], [339, 448], [448, 255], [255, 339]);
function wg(e) {
	e.m = {
		faceLandmarks: [],
		faceBlendshapes: [],
		facialTransformationMatrixes: []
	};
}
var Q = class extends fg {
	constructor(e, t) {
		super(new sg(e, t), "image_in", "norm_rect", !1), this.m = {
			faceLandmarks: [],
			faceBlendshapes: [],
			facialTransformationMatrixes: []
		}, this.outputFacialTransformationMatrixes = this.outputFaceBlendshapes = !1, R(e = this.i = new yp(), 0, 1, t = new up()), this.C = new vp(), R(this.i, 0, 3, this.C), this.v = new mp(), R(this.i, 0, 2, this.v), ml(this.v, 4, 1), z(this.v, 2, .5), z(this.C, 2, .5), z(this.i, 4, .5);
	}
	D() {
		return "FaceLandmarker";
	}
	get baseOptions() {
		return L(this.i, up, 1);
	}
	set baseOptions(e) {
		R(this.i, 0, 1, e);
	}
	A(e) {
		return "numFaces" in e && ml(this.v, 4, e.numFaces ?? 1), "minFaceDetectionConfidence" in e && z(this.v, 2, e.minFaceDetectionConfidence ?? .5), "minTrackingConfidence" in e && z(this.i, 4, e.minTrackingConfidence ?? .5), "minFacePresenceConfidence" in e && z(this.C, 2, e.minFacePresenceConfidence ?? .5), "outputFaceBlendshapes" in e && (this.outputFaceBlendshapes = !!e.outputFaceBlendshapes), "outputFacialTransformationMatrixes" in e && (this.outputFacialTransformationMatrixes = !!e.outputFacialTransformationMatrixes), this.l(e);
	}
	H(e, t) {
		return wg(this), lg(this, e, t), this.m;
	}
	I(e, t, n) {
		return wg(this), ug(this, e, n, t), this.m;
	}
	u() {
		var e = new Mf();
		jf(e, "image_in"), jf(e, "norm_rect"), J(e, "face_landmarks");
		var t = new Sf();
		Ru(t, xp, this.i);
		var n = new Ef();
		vl(n, 2, "mediapipe.tasks.vision.face_landmarker.FaceLandmarkerGraph"), Tf(n, "IMAGE:image_in"), Tf(n, "NORM_RECT:norm_rect"), q(n, "NORM_LANDMARKS:face_landmarks"), n.A(t), Af(e, n), this.h.attachProtoVectorListener("face_landmarks", (e, t) => {
			for (let t of e) e = Kf(t), this.m.faceLandmarks.push(hm(e));
			X(this, t);
		}), this.h.attachEmptyPacketListener("face_landmarks", (e) => {
			X(this, e);
		}), this.outputFaceBlendshapes && (J(e, "blendshapes"), q(n, "BLENDSHAPES:blendshapes"), this.h.attachProtoVectorListener("blendshapes", (e, t) => {
			if (this.outputFaceBlendshapes) for (let t of e) e = Rf(t), this.m.faceBlendshapes.push(fm(e.h() ?? []));
			X(this, t);
		}), this.h.attachEmptyPacketListener("blendshapes", (e) => {
			X(this, e);
		})), this.outputFacialTransformationMatrixes && (J(e, "face_geometry"), q(n, "FACE_GEOMETRY:face_geometry"), this.h.attachProtoVectorListener("face_geometry", (e, t) => {
			if (this.outputFacialTransformationMatrixes) for (let t of e) (e = L(e = _p(t), qf, 2)) && this.m.facialTransformationMatrixes.push({
				rows: ul(e, 1) ?? 0 ?? 0,
				columns: ul(e, 2) ?? 0 ?? 0,
				data: Uc(e, 3, Ms).slice() ?? []
			});
			X(this, t);
		}), this.h.attachEmptyPacketListener("face_geometry", (e) => {
			X(this, e);
		})), e = e.h(), this.setGraph(new Uint8Array(e), !0);
	}
};
Q.prototype.detectForVideo = Q.prototype.I, Q.prototype.detect = Q.prototype.H, Q.prototype.setOptions = Q.prototype.A, Q.createFromModelPath = function(e, t) {
	return Z(Q, e, { baseOptions: { modelAssetPath: t } });
}, Q.createFromModelBuffer = function(e, t) {
	return Z(Q, e, { baseOptions: { modelAssetBuffer: t } });
}, Q.createFromOptions = function(e, t) {
	return Z(Q, e, t);
}, Q.FACE_LANDMARKS_LIPS = mg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_LIPS", Q.FACE_LANDMARKS_LIPS), Q.FACE_LANDMARKS_LEFT_EYE = hg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_LEFT_EYE", Q.FACE_LANDMARKS_LEFT_EYE), Q.FACE_LANDMARKS_LEFT_EYEBROW = gg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_LEFT_EYEBROW", Q.FACE_LANDMARKS_LEFT_EYEBROW), Q.FACE_LANDMARKS_LEFT_IRIS = _g, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_LEFT_IRIS", Q.FACE_LANDMARKS_LEFT_IRIS), Q.FACE_LANDMARKS_RIGHT_EYE = vg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_RIGHT_EYE", Q.FACE_LANDMARKS_RIGHT_EYE), Q.FACE_LANDMARKS_RIGHT_EYEBROW = yg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_RIGHT_EYEBROW", Q.FACE_LANDMARKS_RIGHT_EYEBROW), Q.FACE_LANDMARKS_RIGHT_IRIS = bg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_RIGHT_IRIS", Q.FACE_LANDMARKS_RIGHT_IRIS), Q.FACE_LANDMARKS_FACE_OVAL = xg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_FACE_OVAL", Q.FACE_LANDMARKS_FACE_OVAL), Q.FACE_LANDMARKS_CONTOURS = Sg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_CONTOURS", Q.FACE_LANDMARKS_CONTOURS), Q.FACE_LANDMARKS_TESSELATION = Cg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_TESSELATION", Q.FACE_LANDMARKS_TESSELATION);
var Tg = ig([0, 1], [1, 2], [2, 3], [3, 4], [0, 5], [5, 6], [6, 7], [7, 8], [5, 9], [9, 10], [10, 11], [11, 12], [9, 13], [13, 14], [14, 15], [15, 16], [13, 17], [0, 17], [17, 18], [18, 19], [19, 20]);
function Eg(e) {
	e.gestures = [], e.landmarks = [], e.worldLandmarks = [], e.handedness = [];
}
function Dg(e) {
	return e.gestures.length === 0 ? {
		gestures: [],
		landmarks: [],
		worldLandmarks: [],
		handedness: [],
		handednesses: []
	} : {
		gestures: e.gestures,
		landmarks: e.landmarks,
		worldLandmarks: e.worldLandmarks,
		handedness: e.handedness,
		handednesses: e.handedness
	};
}
function Og(e, t = !0) {
	var n = [];
	for (let i of e) {
		var r = Rf(i);
		e = [];
		for (let n of r.h()) r = t && ul(n, 1) != null ? ul(n, 1) ?? 0 : -1, e.push({
			score: dl(n, 2) ?? 0,
			index: r,
			categoryName: Qs(Rc(n, 3)) ?? "" ?? "",
			displayName: Qs(Rc(n, 4)) ?? "" ?? ""
		});
		n.push(e);
	}
	return n;
}
var kg = class extends fg {
	constructor(e, t) {
		super(new sg(e, t), "image_in", "norm_rect", !1), this.gestures = [], this.landmarks = [], this.worldLandmarks = [], this.handedness = [], R(e = this.m = new Op(), 0, 1, t = new up()), this.v = new Dp(), R(this.m, 0, 2, this.v), this.G = new Ep(), R(this.v, 0, 3, this.G), this.C = new Tp(), R(this.v, 0, 2, this.C), this.i = new wp(), R(this.m, 0, 3, this.i), z(this.C, 2, .5), z(this.v, 4, .5), z(this.G, 2, .5);
	}
	D() {
		return "GestureRecognizer";
	}
	get baseOptions() {
		return L(this.m, up, 1);
	}
	set baseOptions(e) {
		R(this.m, 0, 1, e);
	}
	A(e) {
		if (ml(this.C, 3, e.numHands ?? 1), "minHandDetectionConfidence" in e && z(this.C, 2, e.minHandDetectionConfidence ?? .5), "minTrackingConfidence" in e && z(this.v, 4, e.minTrackingConfidence ?? .5), "minHandPresenceConfidence" in e && z(this.G, 2, e.minHandPresenceConfidence ?? .5), e.cannedGesturesClassifierOptions) {
			var t = new Sp(), n = t, r = um(e.cannedGesturesClassifierOptions, L(this.i, Sp, 3)?.l());
			R(n, 0, 2, r), R(this.i, 0, 3, t);
		} else e.cannedGesturesClassifierOptions === void 0 && L(this.i, Sp, 3)?.h();
		return e.customGesturesClassifierOptions ? (R(n = t = new Sp(), 0, 2, r = um(e.customGesturesClassifierOptions, L(this.i, Sp, 4)?.l())), R(this.i, 0, 4, t)) : e.customGesturesClassifierOptions === void 0 && L(this.i, Sp, 4)?.h(), this.l(e);
	}
	Ya(e, t) {
		return Eg(this), lg(this, e, t), Dg(this);
	}
	Za(e, t, n) {
		return Eg(this), ug(this, e, n, t), Dg(this);
	}
	u() {
		var e = new Mf();
		jf(e, "image_in"), jf(e, "norm_rect"), J(e, "hand_gestures"), J(e, "hand_landmarks"), J(e, "world_hand_landmarks"), J(e, "handedness");
		var t = new Sf();
		Ru(t, Np, this.m);
		var n = new Ef();
		vl(n, 2, "mediapipe.tasks.vision.gesture_recognizer.GestureRecognizerGraph"), Tf(n, "IMAGE:image_in"), Tf(n, "NORM_RECT:norm_rect"), q(n, "HAND_GESTURES:hand_gestures"), q(n, "LANDMARKS:hand_landmarks"), q(n, "WORLD_LANDMARKS:world_hand_landmarks"), q(n, "HANDEDNESS:handedness"), n.A(t), Af(e, n), this.h.attachProtoVectorListener("hand_landmarks", (e, t) => {
			for (let t of e) e = Kf(t), this.landmarks.push(hm(e));
			X(this, t);
		}), this.h.attachEmptyPacketListener("hand_landmarks", (e) => {
			X(this, e);
		}), this.h.attachProtoVectorListener("world_hand_landmarks", (e, t) => {
			for (let t of e) e = Wf(t), this.worldLandmarks.push(gm(e));
			X(this, t);
		}), this.h.attachEmptyPacketListener("world_hand_landmarks", (e) => {
			X(this, e);
		}), this.h.attachProtoVectorListener("hand_gestures", (e, t) => {
			this.gestures.push(...Og(e, !1)), X(this, t);
		}), this.h.attachEmptyPacketListener("hand_gestures", (e) => {
			X(this, e);
		}), this.h.attachProtoVectorListener("handedness", (e, t) => {
			this.handedness.push(...Og(e)), X(this, t);
		}), this.h.attachEmptyPacketListener("handedness", (e) => {
			X(this, e);
		}), e = e.h(), this.setGraph(new Uint8Array(e), !0);
	}
};
function Ag(e) {
	return {
		landmarks: e.landmarks,
		worldLandmarks: e.worldLandmarks,
		handednesses: e.handedness,
		handedness: e.handedness
	};
}
kg.prototype.recognizeForVideo = kg.prototype.Za, kg.prototype.recognize = kg.prototype.Ya, kg.prototype.setOptions = kg.prototype.A, kg.createFromModelPath = function(e, t) {
	return Z(kg, e, { baseOptions: { modelAssetPath: t } });
}, kg.createFromModelBuffer = function(e, t) {
	return Z(kg, e, { baseOptions: { modelAssetBuffer: t } });
}, kg.createFromOptions = function(e, t) {
	return Z(kg, e, t);
}, kg.HAND_CONNECTIONS = Tg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$gesture_recognizer$gesture_recognizer.GestureRecognizer.HAND_CONNECTIONS", kg.HAND_CONNECTIONS);
var jg = class extends fg {
	constructor(e, t) {
		super(new sg(e, t), "image_in", "norm_rect", !1), this.landmarks = [], this.worldLandmarks = [], this.handedness = [], R(e = this.i = new Dp(), 0, 1, t = new up()), this.v = new Ep(), R(this.i, 0, 3, this.v), this.m = new Tp(), R(this.i, 0, 2, this.m), ml(this.m, 3, 1), z(this.m, 2, .5), z(this.v, 2, .5), z(this.i, 4, .5);
	}
	D() {
		return "HandLandmarker";
	}
	get baseOptions() {
		return L(this.i, up, 1);
	}
	set baseOptions(e) {
		R(this.i, 0, 1, e);
	}
	A(e) {
		return "numHands" in e && ml(this.m, 3, e.numHands ?? 1), "minHandDetectionConfidence" in e && z(this.m, 2, e.minHandDetectionConfidence ?? .5), "minTrackingConfidence" in e && z(this.i, 4, e.minTrackingConfidence ?? .5), "minHandPresenceConfidence" in e && z(this.v, 2, e.minHandPresenceConfidence ?? .5), this.l(e);
	}
	H(e, t) {
		return this.landmarks = [], this.worldLandmarks = [], this.handedness = [], lg(this, e, t), Ag(this);
	}
	I(e, t, n) {
		return this.landmarks = [], this.worldLandmarks = [], this.handedness = [], ug(this, e, n, t), Ag(this);
	}
	u() {
		var e = new Mf();
		jf(e, "image_in"), jf(e, "norm_rect"), J(e, "hand_landmarks"), J(e, "world_hand_landmarks"), J(e, "handedness");
		var t = new Sf();
		Ru(t, Pp, this.i);
		var n = new Ef();
		vl(n, 2, "mediapipe.tasks.vision.hand_landmarker.HandLandmarkerGraph"), Tf(n, "IMAGE:image_in"), Tf(n, "NORM_RECT:norm_rect"), q(n, "LANDMARKS:hand_landmarks"), q(n, "WORLD_LANDMARKS:world_hand_landmarks"), q(n, "HANDEDNESS:handedness"), n.A(t), Af(e, n), this.h.attachProtoVectorListener("hand_landmarks", (e, t) => {
			for (let t of e) e = Kf(t), this.landmarks.push(hm(e));
			X(this, t);
		}), this.h.attachEmptyPacketListener("hand_landmarks", (e) => {
			X(this, e);
		}), this.h.attachProtoVectorListener("world_hand_landmarks", (e, t) => {
			for (let t of e) e = Wf(t), this.worldLandmarks.push(gm(e));
			X(this, t);
		}), this.h.attachEmptyPacketListener("world_hand_landmarks", (e) => {
			X(this, e);
		}), this.h.attachProtoVectorListener("handedness", (e, t) => {
			var n = this.handedness, r = n.push, i = [];
			for (let t of e) {
				e = Rf(t);
				let n = [];
				for (let t of e.h()) n.push({
					score: dl(t, 2) ?? 0,
					index: ul(t, 1) ?? 0 ?? -1,
					categoryName: Qs(Rc(t, 3)) ?? "" ?? "",
					displayName: Qs(Rc(t, 4)) ?? "" ?? ""
				});
				i.push(n);
			}
			r.call(n, ...i), X(this, t);
		}), this.h.attachEmptyPacketListener("handedness", (e) => {
			X(this, e);
		}), e = e.h(), this.setGraph(new Uint8Array(e), !0);
	}
};
jg.prototype.detectForVideo = jg.prototype.I, jg.prototype.detect = jg.prototype.H, jg.prototype.setOptions = jg.prototype.A, jg.createFromModelPath = function(e, t) {
	return Z(jg, e, { baseOptions: { modelAssetPath: t } });
}, jg.createFromModelBuffer = function(e, t) {
	return Z(jg, e, { baseOptions: { modelAssetBuffer: t } });
}, jg.createFromOptions = function(e, t) {
	return Z(jg, e, t);
}, jg.HAND_CONNECTIONS = Tg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$hand_landmarker$hand_landmarker.HandLandmarker.HAND_CONNECTIONS", jg.HAND_CONNECTIONS);
var Mg = ig([0, 1], [1, 2], [2, 3], [3, 7], [0, 4], [4, 5], [5, 6], [6, 8], [9, 10], [11, 12], [11, 13], [13, 15], [15, 17], [15, 19], [15, 21], [17, 19], [12, 14], [14, 16], [16, 18], [16, 20], [16, 22], [18, 20], [11, 23], [12, 24], [23, 24], [23, 25], [24, 26], [25, 27], [26, 28], [27, 29], [28, 30], [29, 31], [30, 32], [27, 31], [28, 32]);
function Ng(e) {
	e.i = {
		faceLandmarks: [],
		faceBlendshapes: [],
		poseLandmarks: [],
		poseWorldLandmarks: [],
		poseSegmentationMasks: [],
		leftHandLandmarks: [],
		leftHandWorldLandmarks: [],
		rightHandLandmarks: [],
		rightHandWorldLandmarks: []
	};
}
function Pg(e) {
	try {
		if (!e.G) return e.i;
		e.G(e.i);
	} finally {
		ph(e);
	}
}
function Fg(e, t) {
	e = Kf(e), t.push(hm(e));
}
var $ = class extends fg {
	constructor(e, t) {
		super(new sg(e, t), "input_frames_image", null, !1), this.i = {
			faceLandmarks: [],
			faceBlendshapes: [],
			poseLandmarks: [],
			poseWorldLandmarks: [],
			poseSegmentationMasks: [],
			leftHandLandmarks: [],
			leftHandWorldLandmarks: [],
			rightHandLandmarks: [],
			rightHandWorldLandmarks: []
		}, this.outputPoseSegmentationMasks = this.outputFaceBlendshapes = !1, R(e = this.m = new Rp(), 0, 1, t = new up()), this.Z = new Ep(), R(this.m, 0, 2, this.Z), this.Ba = new Fp(), R(this.m, 0, 3, this.Ba), this.v = new mp(), R(this.m, 0, 4, this.v), this.P = new vp(), R(this.m, 0, 5, this.P), this.C = new Ip(), R(this.m, 0, 6, this.C), this.aa = new Lp(), R(this.m, 0, 7, this.aa), z(this.v, 2, .5), z(this.v, 3, .3), z(this.P, 2, .5), z(this.C, 2, .5), z(this.C, 3, .3), z(this.aa, 2, .5), z(this.Z, 2, .5);
	}
	D() {
		return "HolisticLandmarker";
	}
	get baseOptions() {
		return L(this.m, up, 1);
	}
	set baseOptions(e) {
		R(this.m, 0, 1, e);
	}
	A(e) {
		return "minFaceDetectionConfidence" in e && z(this.v, 2, e.minFaceDetectionConfidence ?? .5), "minFaceSuppressionThreshold" in e && z(this.v, 3, e.minFaceSuppressionThreshold ?? .3), "minFacePresenceConfidence" in e && z(this.P, 2, e.minFacePresenceConfidence ?? .5), "outputFaceBlendshapes" in e && (this.outputFaceBlendshapes = !!e.outputFaceBlendshapes), "minPoseDetectionConfidence" in e && z(this.C, 2, e.minPoseDetectionConfidence ?? .5), "minPoseSuppressionThreshold" in e && z(this.C, 3, e.minPoseSuppressionThreshold ?? .3), "minPosePresenceConfidence" in e && z(this.aa, 2, e.minPosePresenceConfidence ?? .5), "outputPoseSegmentationMasks" in e && (this.outputPoseSegmentationMasks = !!e.outputPoseSegmentationMasks), "minHandLandmarksConfidence" in e && z(this.Z, 2, e.minHandLandmarksConfidence ?? .5), this.l(e);
	}
	H(e, t, n) {
		var r = typeof t == "function" ? {} : t;
		return this.G = typeof t == "function" ? t : n, Ng(this), lg(this, e, r), Pg(this);
	}
	I(e, t, n, r) {
		var i = typeof n == "function" ? {} : n;
		return this.G = typeof n == "function" ? n : r, Ng(this), ug(this, e, i, t), Pg(this);
	}
	u() {
		var e = new Mf();
		jf(e, "input_frames_image"), J(e, "pose_landmarks"), J(e, "pose_world_landmarks"), J(e, "face_landmarks"), J(e, "left_hand_landmarks"), J(e, "left_hand_world_landmarks"), J(e, "right_hand_landmarks"), J(e, "right_hand_world_landmarks");
		var t = new Sf(), n = new of();
		vl(n, 1, "type.googleapis.com/mediapipe.tasks.vision.holistic_landmarker.proto.HolisticLandmarkerGraphOptions"), function(e, t) {
			if (t != null) {
				if (Array.isArray(t)) I(e, 2, bc(t, 0, Sc));
				else {
					if (!(typeof t == "string" || t instanceof _o || fo(t))) throw Error("invalid value in Any.value field: " + t + " expected a ByteString, a base64 encoded string, a Uint8Array or a jspb array");
					Xc(e, 2, Jo(t, !1), mo());
				}
			}
		}(n, this.m.h());
		var r = new Ef();
		vl(r, 2, "mediapipe.tasks.vision.holistic_landmarker.HolisticLandmarkerGraph"), ll(r, 8, of, n), Tf(r, "IMAGE:input_frames_image"), q(r, "POSE_LANDMARKS:pose_landmarks"), q(r, "POSE_WORLD_LANDMARKS:pose_world_landmarks"), q(r, "FACE_LANDMARKS:face_landmarks"), q(r, "LEFT_HAND_LANDMARKS:left_hand_landmarks"), q(r, "LEFT_HAND_WORLD_LANDMARKS:left_hand_world_landmarks"), q(r, "RIGHT_HAND_LANDMARKS:right_hand_landmarks"), q(r, "RIGHT_HAND_WORLD_LANDMARKS:right_hand_world_landmarks"), r.A(t), Af(e, r), dh(this, e), this.h.attachProtoListener("pose_landmarks", (e, t) => {
			Fg(e, this.i.poseLandmarks), X(this, t);
		}), this.h.attachEmptyPacketListener("pose_landmarks", (e) => {
			X(this, e);
		}), this.h.attachProtoListener("pose_world_landmarks", (e, t) => {
			var n = this.i.poseWorldLandmarks;
			e = Wf(e), n.push(gm(e)), X(this, t);
		}), this.h.attachEmptyPacketListener("pose_world_landmarks", (e) => {
			X(this, e);
		}), this.outputPoseSegmentationMasks && (q(r, "POSE_SEGMENTATION_MASK:pose_segmentation_mask"), fh(this, "pose_segmentation_mask"), this.h.ha("pose_segmentation_mask", (e, t) => {
			this.i.poseSegmentationMasks = [dg(this, e, !0, !this.G)], X(this, t);
		}), this.h.attachEmptyPacketListener("pose_segmentation_mask", (e) => {
			this.i.poseSegmentationMasks = [], X(this, e);
		})), this.h.attachProtoListener("face_landmarks", (e, t) => {
			Fg(e, this.i.faceLandmarks), X(this, t);
		}), this.h.attachEmptyPacketListener("face_landmarks", (e) => {
			X(this, e);
		}), this.outputFaceBlendshapes && (J(e, "extra_blendshapes"), q(r, "FACE_BLENDSHAPES:extra_blendshapes"), this.h.attachProtoListener("extra_blendshapes", (e, t) => {
			var n = this.i.faceBlendshapes;
			this.outputFaceBlendshapes && (e = Rf(e), n.push(fm(e.h() ?? []))), X(this, t);
		}), this.h.attachEmptyPacketListener("extra_blendshapes", (e) => {
			X(this, e);
		})), this.h.attachProtoListener("left_hand_landmarks", (e, t) => {
			Fg(e, this.i.leftHandLandmarks), X(this, t);
		}), this.h.attachEmptyPacketListener("left_hand_landmarks", (e) => {
			X(this, e);
		}), this.h.attachProtoListener("left_hand_world_landmarks", (e, t) => {
			var n = this.i.leftHandWorldLandmarks;
			e = Wf(e), n.push(gm(e)), X(this, t);
		}), this.h.attachEmptyPacketListener("left_hand_world_landmarks", (e) => {
			X(this, e);
		}), this.h.attachProtoListener("right_hand_landmarks", (e, t) => {
			Fg(e, this.i.rightHandLandmarks), X(this, t);
		}), this.h.attachEmptyPacketListener("right_hand_landmarks", (e) => {
			X(this, e);
		}), this.h.attachProtoListener("right_hand_world_landmarks", (e, t) => {
			var n = this.i.rightHandWorldLandmarks;
			e = Wf(e), n.push(gm(e)), X(this, t);
		}), this.h.attachEmptyPacketListener("right_hand_world_landmarks", (e) => {
			X(this, e);
		}), e = e.h(), this.setGraph(new Uint8Array(e), !0);
	}
};
$.prototype.detectForVideo = $.prototype.I, $.prototype.detect = $.prototype.H, $.prototype.setOptions = $.prototype.A, $.createFromModelPath = function(e, t) {
	return Z($, e, { baseOptions: { modelAssetPath: t } });
}, $.createFromModelBuffer = function(e, t) {
	return Z($, e, { baseOptions: { modelAssetBuffer: t } });
}, $.createFromOptions = function(e, t) {
	return Z($, e, t);
}, $.HAND_CONNECTIONS = Tg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.HAND_CONNECTIONS", $.HAND_CONNECTIONS), $.POSE_CONNECTIONS = Mg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.POSE_CONNECTIONS", $.POSE_CONNECTIONS), $.FACE_LANDMARKS_LIPS = mg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_LIPS", $.FACE_LANDMARKS_LIPS), $.FACE_LANDMARKS_LEFT_EYE = hg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_LEFT_EYE", $.FACE_LANDMARKS_LEFT_EYE), $.FACE_LANDMARKS_LEFT_EYEBROW = gg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_LEFT_EYEBROW", $.FACE_LANDMARKS_LEFT_EYEBROW), $.FACE_LANDMARKS_LEFT_IRIS = _g, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_LEFT_IRIS", $.FACE_LANDMARKS_LEFT_IRIS), $.FACE_LANDMARKS_RIGHT_EYE = vg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_RIGHT_EYE", $.FACE_LANDMARKS_RIGHT_EYE), $.FACE_LANDMARKS_RIGHT_EYEBROW = yg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_RIGHT_EYEBROW", $.FACE_LANDMARKS_RIGHT_EYEBROW), $.FACE_LANDMARKS_RIGHT_IRIS = bg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_RIGHT_IRIS", $.FACE_LANDMARKS_RIGHT_IRIS), $.FACE_LANDMARKS_FACE_OVAL = xg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_FACE_OVAL", $.FACE_LANDMARKS_FACE_OVAL), $.FACE_LANDMARKS_CONTOURS = Sg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_CONTOURS", $.FACE_LANDMARKS_CONTOURS), $.FACE_LANDMARKS_TESSELATION = Cg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_TESSELATION", $.FACE_LANDMARKS_TESSELATION);
var Ig = class extends fg {
	constructor(e, t) {
		super(new sg(e, t), "input_image", "norm_rect", !0), this.m = { classifications: [] }, R(e = this.i = new Vp(), 0, 1, t = new up());
	}
	D() {
		return "ImageClassifier";
	}
	get baseOptions() {
		return L(this.i, up, 1);
	}
	set baseOptions(e) {
		R(this.i, 0, 1, e);
	}
	A(e) {
		return R(this.i, 0, 2, um(e, L(this.i, rp, 2))), this.l(e);
	}
	Ha(e, t) {
		return this.m = { classifications: [] }, lg(this, e, t), this.m;
	}
	Ia(e, t, n) {
		return this.m = { classifications: [] }, ug(this, e, n, t), this.m;
	}
	u() {
		var e = new Mf();
		jf(e, "input_image"), jf(e, "norm_rect"), J(e, "classifications");
		var t = new Sf();
		Ru(t, Hp, this.i);
		var n = new Ef();
		vl(n, 2, "mediapipe.tasks.vision.image_classifier.ImageClassifierGraph"), Tf(n, "IMAGE:input_image"), Tf(n, "NORM_RECT:norm_rect"), q(n, "CLASSIFICATIONS:classifications"), n.A(t), Af(e, n), this.h.attachProtoListener("classifications", (e, t) => {
			this.m = pm(Zf(e)), X(this, t);
		}), this.h.attachEmptyPacketListener("classifications", (e) => {
			X(this, e);
		}), e = e.h(), this.setGraph(new Uint8Array(e), !0);
	}
};
Ig.prototype.classifyForVideo = Ig.prototype.Ia, Ig.prototype.classify = Ig.prototype.Ha, Ig.prototype.setOptions = Ig.prototype.A, Ig.createFromModelPath = function(e, t) {
	return Z(Ig, e, { baseOptions: { modelAssetPath: t } });
}, Ig.createFromModelBuffer = function(e, t) {
	return Z(Ig, e, { baseOptions: { modelAssetBuffer: t } });
}, Ig.createFromOptions = function(e, t) {
	return Z(Ig, e, t);
};
var Lg = class extends fg {
	constructor(e, t) {
		super(new sg(e, t), "image_in", "norm_rect", !0), this.i = new Up(), this.embeddings = { embeddings: [] }, R(e = this.i, 0, 1, t = new up());
	}
	D() {
		return "ImageEmbedder";
	}
	get baseOptions() {
		return L(this.i, up, 1);
	}
	set baseOptions(e) {
		R(this.i, 0, 1, e);
	}
	A(e) {
		var t = this.i, n = L(this.i, ap, 2);
		if (n = n ? n.clone() : new ap(), e.l2Normalize !== void 0) {
			var r = e.l2Normalize;
			I(n, 1, r == null ? r : Ns(r));
		} else "l2Normalize" in e && I(n, 1);
		return e.quantize === void 0 ? "quantize" in e && I(n, 2) : I(n, 2, (r = e.quantize) == null ? r : Ns(r)), R(t, 0, 2, n), this.l(e);
	}
	Oa(e, t) {
		return lg(this, e, t), this.embeddings;
	}
	Pa(e, t, n) {
		return ug(this, e, n, t), this.embeddings;
	}
	u() {
		var e = new Mf();
		jf(e, "image_in"), jf(e, "norm_rect"), J(e, "embeddings_out");
		var t = new Sf();
		Ru(t, Wp, this.i);
		var n = new Ef();
		vl(n, 2, "mediapipe.tasks.vision.image_embedder.ImageEmbedderGraph"), Tf(n, "IMAGE:image_in"), Tf(n, "NORM_RECT:norm_rect"), q(n, "EMBEDDINGS:embeddings_out"), n.A(t), Af(e, n), this.h.attachProtoListener("embeddings_out", (e, t) => {
			e = np(e), this.embeddings = function(e) {
				return {
					embeddings: il(e, ep, 1).map((e) => {
						var t = {
							headIndex: ul(e, 3) ?? 0 ?? -1,
							headName: Qs(Rc(e, 4)) ?? "" ?? ""
						};
						if (Hc(e, 1, tp)) e = Uc(e = fl(e, Qf, 1, tp), 1, Ms), t.floatEmbedding = e.slice();
						else {
							let n = /* @__PURE__ */ new Uint8Array();
							t.quantizedEmbedding = fl(e, $f, 2, tp)?.h()?.i() ?? n;
						}
						return t;
					}),
					timestampMs: dm(Rc(e, 2, void 0, Ks) ?? Ic)
				};
			}(e), X(this, t);
		}), this.h.attachEmptyPacketListener("embeddings_out", (e) => {
			X(this, e);
		}), e = e.h(), this.setGraph(new Uint8Array(e), !0);
	}
};
Lg.cosineSimilarity = function(e, t) {
	if (e.floatEmbedding && t.floatEmbedding) e = vm(e.floatEmbedding, t.floatEmbedding);
	else {
		if (!e.quantizedEmbedding || !t.quantizedEmbedding) throw Error("Cannot compute cosine similarity between quantized and float embeddings.");
		e = vm(_m(e.quantizedEmbedding), _m(t.quantizedEmbedding));
	}
	return e;
}, Lg.prototype.embedForVideo = Lg.prototype.Pa, Lg.prototype.embed = Lg.prototype.Oa, Lg.prototype.setOptions = Lg.prototype.A, Lg.createFromModelPath = function(e, t) {
	return Z(Lg, e, { baseOptions: { modelAssetPath: t } });
}, Lg.createFromModelBuffer = function(e, t) {
	return Z(Lg, e, { baseOptions: { modelAssetBuffer: t } });
}, Lg.createFromOptions = function(e, t) {
	return Z(Lg, e, t);
};
var Rg = class {
	constructor(e, t, n) {
		this.confidenceMasks = e, this.categoryMask = t, this.qualityScores = n;
	}
	close() {
		this.confidenceMasks?.forEach((e) => {
			e.close();
		}), this.categoryMask?.close();
	}
};
function zg(e) {
	var t = function(e) {
		return il(e, Ef, 1);
	}(e.ka()).filter((e) => (Qs(Rc(e, 1)) ?? "").includes("mediapipe.tasks.TensorsToSegmentationCalculator"));
	if (e.v = [], t.length > 1) throw Error("The graph has more than one mediapipe.tasks.TensorsToSegmentationCalculator.");
	t.length === 1 && (L(t[0], Sf, 7)?.u()?.h() ?? /* @__PURE__ */ new Map()).forEach((t, n) => {
		e.v[Number(n)] = Qs(Rc(t, 1)) ?? "";
	});
}
function Bg(e) {
	e.categoryMask = void 0, e.confidenceMasks = void 0, e.qualityScores = void 0;
}
function Vg(e) {
	try {
		let t = new Rg(e.confidenceMasks, e.categoryMask, e.qualityScores);
		if (!e.m) return t;
		e.m(t);
	} finally {
		ph(e);
	}
}
Rg.prototype.close = Rg.prototype.close;
var Hg = class extends fg {
	constructor(e, t) {
		super(new sg(e, t), "image_in", "norm_rect", !1), this.v = [], this.outputCategoryMask = !1, this.outputConfidenceMasks = !0, this.i = new Yp(), this.C = new Gp(), R(this.i, 0, 3, this.C), R(e = this.i, 0, 1, t = new up());
	}
	D() {
		return "ImageSegmenter";
	}
	get baseOptions() {
		return L(this.i, up, 1);
	}
	set baseOptions(e) {
		R(this.i, 0, 1, e);
	}
	A(e) {
		return e.displayNamesLocale === void 0 ? "displayNamesLocale" in e && I(this.i, 2) : I(this.i, 2, Zs(e.displayNamesLocale)), "outputCategoryMask" in e && (this.outputCategoryMask = e.outputCategoryMask ?? !1), "outputConfidenceMasks" in e && (this.outputConfidenceMasks = e.outputConfidenceMasks ?? !0), super.l(e);
	}
	M() {
		zg(this);
	}
	segment(e, t, n) {
		var r = typeof t == "function" ? {} : t;
		return this.m = typeof t == "function" ? t : n, Bg(this), lg(this, e, r), Vg(this);
	}
	fb(e, t, n, r) {
		var i = typeof n == "function" ? {} : n;
		return this.m = typeof n == "function" ? n : r, Bg(this), ug(this, e, i, t), Vg(this);
	}
	Sa() {
		return this.v;
	}
	u() {
		var e = new Mf();
		jf(e, "image_in"), jf(e, "norm_rect");
		var t = new Sf();
		Ru(t, Xp, this.i);
		var n = new Ef();
		vl(n, 2, "mediapipe.tasks.vision.image_segmenter.ImageSegmenterGraph"), Tf(n, "IMAGE:image_in"), Tf(n, "NORM_RECT:norm_rect"), n.A(t), Af(e, n), dh(this, e), this.outputConfidenceMasks && (J(e, "confidence_masks"), q(n, "CONFIDENCE_MASKS:confidence_masks"), fh(this, "confidence_masks"), this.h.ia("confidence_masks", (e, t) => {
			this.confidenceMasks = e.map((e) => dg(this, e, !0, !this.m)), X(this, t);
		}), this.h.attachEmptyPacketListener("confidence_masks", (e) => {
			this.confidenceMasks = [], X(this, e);
		})), this.outputCategoryMask && (J(e, "category_mask"), q(n, "CATEGORY_MASK:category_mask"), fh(this, "category_mask"), this.h.ha("category_mask", (e, t) => {
			this.categoryMask = dg(this, e, !1, !this.m), X(this, t);
		}), this.h.attachEmptyPacketListener("category_mask", (e) => {
			this.categoryMask = void 0, X(this, e);
		})), J(e, "quality_scores"), q(n, "QUALITY_SCORES:quality_scores"), this.h.attachFloatVectorListener("quality_scores", (e, t) => {
			this.qualityScores = e, X(this, t);
		}), this.h.attachEmptyPacketListener("quality_scores", (e) => {
			this.categoryMask = void 0, X(this, e);
		}), e = e.h(), this.setGraph(new Uint8Array(e), !0);
	}
};
Hg.prototype.getLabels = Hg.prototype.Sa, Hg.prototype.segmentForVideo = Hg.prototype.fb, Hg.prototype.segment = Hg.prototype.segment, Hg.prototype.setOptions = Hg.prototype.A, Hg.createFromModelPath = function(e, t) {
	return Z(Hg, e, { baseOptions: { modelAssetPath: t } });
}, Hg.createFromModelBuffer = function(e, t) {
	return Z(Hg, e, { baseOptions: { modelAssetBuffer: t } });
}, Hg.createFromOptions = function(e, t) {
	return Z(Hg, e, t);
};
var Ug = {
	0: 0,
	1: 1,
	2: 2,
	3: 3
};
function Wg() {
	return Jm() ? void 0 : document.createElement("canvas");
}
var Gg = class extends mh {
	constructor(e, t) {
		super(new ah(e, t)), this.v = new wh(), this.delegate = "CPU", this.i = 0, this.baseOptions = new up(), this.C = this.m = 0;
	}
	D() {
		return "InteractiveSegmenter";
	}
	get j() {
		return this.h.j;
	}
	A(e) {
		return this.delegate = e.baseOptions?.delegate ?? "CPU", super.l(e);
	}
	gb(e) {
		if (this.i === 0) throw Error("Segmenter is not initialized.");
		var t;
		if (this.m !== 0 && (this.j._free(this.m), this.m = 0), !(t = typeof ImageData < "u" && e instanceof ImageData)) {
			if (typeof e != "object" || !e) t = !1;
			else {
				t = e.data;
				var n = e.width, r = e.height;
				t = Number.isInteger(n) && n > 0 && Number.isInteger(r) && r > 0 && (t instanceof Uint8ClampedArray || t instanceof Uint8Array);
			}
		}
		if (t) t = e.width, n = e.height, e = e.data;
		else {
			if ([t, n] = Xm(e), typeof OffscreenCanvas < "u") r = new OffscreenCanvas(t, n);
			else {
				if (typeof document > "u") throw Error("Canvas is not supported in this environment.");
				r = document.createElement("canvas");
			}
			if (r.width = t, r.height = n, !(r = r.getContext("2d"))) throw Error("Canvas 2D context is not supported in this environment.");
			r.drawImage(e, 0, 0), e = r.getImageData(0, 0, t, n).data;
		}
		if (!e) throw Error("Unsupported image source or failed to extract image pixels.");
		r = function({ Xa: e, width: t, height: n }) {
			if (t <= 0 || n <= 0) throw Error(`Invalid image dimensions: ${t}x${n}. Dimensions must be positive.`);
			if (e % (t * n) !== 0) throw Error(`Invalid image dimensions or pixel data length. Pixel data length ${e} is not a multiple of the number of pixels (${t * n}).`);
			if ((e /= t * n) !== 4 && e !== 3 && e !== 1) throw Error(`Invalid image dimensions or pixel data length. Calculated channels: ${e}. Expected 1, 3, or 4.`);
			return e;
		}({
			Xa: e.length,
			width: t,
			height: n
		});
		var i = this.j._malloc(e.length);
		if (this.j.HEAPU8.set(e, i), this.m = i, !this.j._interactive_segmenter_set_image(this.i, i, t, n, r)) throw Error("Failed to set image on native engine.");
	}
	segment(e) {
		if (this.i === 0) throw Error("Segmenter is not initialized.");
		var t = function(e) {
			e = e.map(({ isCompleted: e, brushMode: t, point: n }) => {
				t = Ug[t] ?? 0, n = n.map(({ x: e, y: t }) => {
					var n = new Zp();
					return _l(n, 1, e), _l(n, 2, t), n;
				});
				var r = new Qp();
				return pl(r, e), Xc(r, 1, Is(t), 0), sl(r, 2, n), r;
			});
			var t = new $p();
			return sl(t, 1, e), em(t);
		}(e);
		e = this.j._malloc(t.length), this.j.HEAPU8.set(t, e);
		var n = this.j._malloc(12), r = n + 4, i = n + 8, a = 0, o = this.C++;
		try {
			if (this.o) {
				if (this.delegate === "GPU") {
					var s = this.o;
					++s.h.U, s.i.set(o, performance.now());
				} else {
					var c = this.o;
					++c.h.R, c.i.set(o, performance.now());
				}
			}
			if ((a = this.j._interactive_segmenter_segment(this.i, e, t.length, n, r, i)) === 0) throw Error("Segmentation failed.");
			this.o?.Aa(o);
			let u = this.j.HEAPU32[n / 4], d = this.j.HEAPU32[r / 4], f = new Float32Array(this.j.HEAPU8.buffer, a, this.j.HEAPU32[i / 4] / 4);
			var l = new Float32Array(f);
			if (s = u * d, (l instanceof Uint8Array || l instanceof Float32Array) && l.length !== s) throw Error("Unsupported channel count: " + l.length / s);
			return new Ih([l], !0, !1, this.h.j.canvas ?? void 0, this.v, u, d);
		} finally {
			e !== 0 && this.j._free(e), n !== 0 && this.j._free(n), a !== 0 && this.j._free(a);
		}
	}
	u() {
		this.i !== 0 && (this.o?.ya(), this.j._interactive_segmenter_close(this.i), this.i = 0), this.m !== 0 && (this.j._free(this.m), this.m = 0);
		var e = new sp();
		if (this.delegate === "GPU") {
			var t = new df();
			ol(e, 2, cp, t);
		} else ml(t = new bf(), 1, 4), ol(e, 1, cp, t);
		if (R(this.baseOptions, 0, 3, e), e = pp(this.baseOptions), t = this.j._malloc(e.length), this.j.HEAPU8.set(e, t), this.i = this.j._interactive_segmenter_create(t, e.length), this.j._free(t), this.i === 0) throw Error("Failed to create native InteractiveSegmenter engine.");
		this.o?.za();
	}
	close() {
		this.i !== 0 && (this.j._interactive_segmenter_close(this.i), this.i = 0), this.m !== 0 && (this.j._free(this.m), this.m = 0), this.v.close(), super.close();
	}
};
Gg.prototype.close = Gg.prototype.close, Gg.prototype.segment = Gg.prototype.segment, Gg.prototype.setImage = Gg.prototype.gb, Gg.prototype.setOptions = Gg.prototype.A, Gg.createFromModelPath = function(e, t) {
	return sh(Gg, Wg(), e, { baseOptions: { modelAssetPath: t } });
}, Gg.createFromModelBuffer = function(e, t) {
	return sh(Gg, Wg(), e, { baseOptions: { modelAssetBuffer: t } });
}, Gg.createFromOptions = function(e, t) {
	return sh(Gg, t.canvas ?? Wg(), e, t);
};
var Kg = class {
	constructor(e, t, n) {
		this.confidenceMasks = e, this.categoryMask = t, this.qualityScores = n;
	}
	close() {
		this.confidenceMasks?.forEach((e) => {
			e.close();
		}), this.categoryMask?.close();
	}
};
Kg.prototype.close = Kg.prototype.close;
var qg = class extends fg {
	constructor(e, t) {
		super(new sg(e, t), "image_in", "norm_rect_in", !1), this.outputCategoryMask = !1, this.outputConfidenceMasks = !0, this.i = new Yp(), this.v = new Gp(), R(this.i, 0, 3, this.v), R(e = this.i, 0, 1, t = new up());
	}
	D() {
		return "InteractiveSegmenterLegacy";
	}
	get baseOptions() {
		return L(this.i, up, 1);
	}
	set baseOptions(e) {
		R(this.i, 0, 1, e);
	}
	A(e) {
		return "outputCategoryMask" in e && (this.outputCategoryMask = e.outputCategoryMask ?? !1), "outputConfidenceMasks" in e && (this.outputConfidenceMasks = e.outputConfidenceMasks ?? !0), super.l(e);
	}
	segment(e, t, n, r) {
		var i = typeof n == "function" ? {} : n;
		if (this.m = typeof n == "function" ? n : r, this.qualityScores = this.categoryMask = this.confidenceMasks = void 0, n = this.J + 1, r = new im(), t.keypoint && t.scribble) throw Error("Cannot provide both keypoint and scribble.");
		if (t.keypoint) {
			var a = new tm();
			pl(a, !0), _l(a, 1, t.keypoint.x), _l(a, 2, t.keypoint.y), ol(r, 1, am, a);
		} else {
			if (!t.scribble) throw Error("Must provide either a keypoint or a scribble.");
			{
				let e = new rm();
				for (a of t.scribble) pl(t = new tm(), !0), _l(t, 1, a.x), _l(t, 2, a.y), ll(e, 1, tm, t);
				ol(r, 2, am, e);
			}
		}
		this.h.addProtoToStream(r.h(), "mediapipe.tasks.vision.interactive_segmenter_legacy.proto.RegionOfInterest", "roi_in", n), lg(this, e, i);
		t: {
			try {
				let e = new Kg(this.confidenceMasks, this.categoryMask, this.qualityScores);
				if (!this.m) {
					var o = e;
					break t;
				}
				this.m(e);
			} finally {
				ph(this);
			}
			o = void 0;
		}
		return o;
	}
	u() {
		var e = new Mf();
		jf(e, "image_in"), jf(e, "roi_in"), jf(e, "norm_rect_in");
		var t = new Sf();
		Ru(t, Xp, this.i);
		var n = new Ef();
		vl(n, 2, "mediapipe.tasks.vision.interactive_segmenter_legacy.InteractiveSegmenterLegacyGraph"), Tf(n, "IMAGE:image_in"), Tf(n, "ROI:roi_in"), Tf(n, "NORM_RECT:norm_rect_in"), n.A(t), Af(e, n), dh(this, e), this.outputConfidenceMasks && (J(e, "confidence_masks"), q(n, "CONFIDENCE_MASKS:confidence_masks"), fh(this, "confidence_masks"), this.h.ia("confidence_masks", (e, t) => {
			this.confidenceMasks = e.map((e) => dg(this, e, !0, !this.m)), X(this, t);
		}), this.h.attachEmptyPacketListener("confidence_masks", (e) => {
			this.confidenceMasks = [], X(this, e);
		})), this.outputCategoryMask && (J(e, "category_mask"), q(n, "CATEGORY_MASK:category_mask"), fh(this, "category_mask"), this.h.ha("category_mask", (e, t) => {
			this.categoryMask = dg(this, e, !1, !this.m), X(this, t);
		}), this.h.attachEmptyPacketListener("category_mask", (e) => {
			this.categoryMask = void 0, X(this, e);
		})), J(e, "quality_scores"), q(n, "QUALITY_SCORES:quality_scores"), this.h.attachFloatVectorListener("quality_scores", (e, t) => {
			this.qualityScores = e, X(this, t);
		}), this.h.attachEmptyPacketListener("quality_scores", (e) => {
			this.categoryMask = void 0, X(this, e);
		}), e = e.h(), this.setGraph(new Uint8Array(e), !0);
	}
};
qg.prototype.segment = qg.prototype.segment, qg.prototype.setOptions = qg.prototype.A, qg.createFromModelPath = function(e, t) {
	return Z(qg, e, { baseOptions: { modelAssetPath: t } });
}, qg.createFromModelBuffer = function(e, t) {
	return Z(qg, e, { baseOptions: { modelAssetBuffer: t } });
}, qg.createFromOptions = function(e, t) {
	return Z(qg, e, t);
};
var Jg = class extends fg {
	constructor(e, t) {
		super(new sg(e, t), "input_frame_gpu", "norm_rect", !1), this.m = { detections: [] }, R(e = this.i = new om(), 0, 1, t = new up());
	}
	D() {
		return "ObjectDetector";
	}
	get baseOptions() {
		return L(this.i, up, 1);
	}
	set baseOptions(e) {
		R(this.i, 0, 1, e);
	}
	A(e) {
		return e.displayNamesLocale === void 0 ? "displayNamesLocale" in e && I(this.i, 2) : I(this.i, 2, Zs(e.displayNamesLocale)), e.maxResults === void 0 ? "maxResults" in e && I(this.i, 3) : ml(this.i, 3, e.maxResults), e.scoreThreshold === void 0 ? "scoreThreshold" in e && I(this.i, 4) : z(this.i, 4, e.scoreThreshold), e.categoryAllowlist === void 0 ? "categoryAllowlist" in e && I(this.i, 5) : yl(this.i, 5, e.categoryAllowlist), e.categoryDenylist === void 0 ? "categoryDenylist" in e && I(this.i, 6) : yl(this.i, 6, e.categoryDenylist), this.l(e);
	}
	H(e, t) {
		return this.m = { detections: [] }, lg(this, e, t), this.m;
	}
	I(e, t, n) {
		return this.m = { detections: [] }, ug(this, e, n, t), this.m;
	}
	u() {
		var e = new Mf();
		jf(e, "input_frame_gpu"), jf(e, "norm_rect"), J(e, "detections");
		var t = new Sf();
		Ru(t, sm, this.i);
		var n = new Ef();
		vl(n, 2, "mediapipe.tasks.vision.ObjectDetectorGraph"), Tf(n, "IMAGE:input_frame_gpu"), Tf(n, "NORM_RECT:norm_rect"), q(n, "DETECTIONS:detections"), n.A(t), Af(e, n), this.h.attachProtoVectorListener("detections", (e, t) => {
			for (let t of e) e = Hf(t), this.m.detections.push(mm(e));
			X(this, t);
		}), this.h.attachEmptyPacketListener("detections", (e) => {
			X(this, e);
		}), e = e.h(), this.setGraph(new Uint8Array(e), !0);
	}
};
Jg.prototype.detectForVideo = Jg.prototype.I, Jg.prototype.detect = Jg.prototype.H, Jg.prototype.setOptions = Jg.prototype.A, Jg.createFromModelPath = async function(e, t) {
	return Z(Jg, e, { baseOptions: { modelAssetPath: t } });
}, Jg.createFromModelBuffer = function(e, t) {
	return Z(Jg, e, { baseOptions: { modelAssetBuffer: t } });
}, Jg.createFromOptions = function(e, t) {
	return Z(Jg, e, t);
};
var Yg = class {
	constructor(e, t, n) {
		this.landmarks = e, this.worldLandmarks = t, this.segmentationMasks = n;
	}
	close() {
		this.segmentationMasks?.forEach((e) => {
			e.close();
		});
	}
};
function Xg(e) {
	e.landmarks = [], e.worldLandmarks = [], e.segmentationMasks = void 0;
}
function Zg(e) {
	try {
		let t = new Yg(e.landmarks, e.worldLandmarks, e.segmentationMasks);
		if (!e.v) return t;
		e.v(t);
	} finally {
		ph(e);
	}
}
Yg.prototype.close = Yg.prototype.close;
var Qg = class extends fg {
	constructor(e, t) {
		super(new sg(e, t), "image_in", "norm_rect", !1), this.landmarks = [], this.worldLandmarks = [], this.outputSegmentationMasks = !1, R(e = this.i = new cm(), 0, 1, t = new up()), this.C = new Lp(), R(this.i, 0, 3, this.C), this.m = new Ip(), R(this.i, 0, 2, this.m), ml(this.m, 4, 1), z(this.m, 2, .5), z(this.C, 2, .5), z(this.i, 4, .5);
	}
	D() {
		return "PoseLandmarker";
	}
	get baseOptions() {
		return L(this.i, up, 1);
	}
	set baseOptions(e) {
		R(this.i, 0, 1, e);
	}
	A(e) {
		return "numPoses" in e && ml(this.m, 4, e.numPoses ?? 1), "minPoseDetectionConfidence" in e && z(this.m, 2, e.minPoseDetectionConfidence ?? .5), "minTrackingConfidence" in e && z(this.i, 4, e.minTrackingConfidence ?? .5), "minPosePresenceConfidence" in e && z(this.C, 2, e.minPosePresenceConfidence ?? .5), "outputSegmentationMasks" in e && (this.outputSegmentationMasks = e.outputSegmentationMasks ?? !1), this.l(e);
	}
	H(e, t, n) {
		var r = typeof t == "function" ? {} : t;
		return this.v = typeof t == "function" ? t : n, Xg(this), lg(this, e, r), Zg(this);
	}
	I(e, t, n, r) {
		var i = typeof n == "function" ? {} : n;
		return this.v = typeof n == "function" ? n : r, Xg(this), ug(this, e, i, t), Zg(this);
	}
	u() {
		var e = new Mf();
		jf(e, "image_in"), jf(e, "norm_rect"), J(e, "normalized_landmarks"), J(e, "world_landmarks"), J(e, "segmentation_masks");
		var t = new Sf();
		Ru(t, lm, this.i);
		var n = new Ef();
		vl(n, 2, "mediapipe.tasks.vision.pose_landmarker.PoseLandmarkerGraph"), Tf(n, "IMAGE:image_in"), Tf(n, "NORM_RECT:norm_rect"), q(n, "NORM_LANDMARKS:normalized_landmarks"), q(n, "WORLD_LANDMARKS:world_landmarks"), n.A(t), Af(e, n), dh(this, e), this.h.attachProtoVectorListener("normalized_landmarks", (e, t) => {
			this.landmarks = [];
			for (let t of e) e = Kf(t), this.landmarks.push(hm(e));
			X(this, t);
		}), this.h.attachEmptyPacketListener("normalized_landmarks", (e) => {
			this.landmarks = [], X(this, e);
		}), this.h.attachProtoVectorListener("world_landmarks", (e, t) => {
			this.worldLandmarks = [];
			for (let t of e) e = Wf(t), this.worldLandmarks.push(gm(e));
			X(this, t);
		}), this.h.attachEmptyPacketListener("world_landmarks", (e) => {
			this.worldLandmarks = [], X(this, e);
		}), this.outputSegmentationMasks && (q(n, "SEGMENTATION_MASK:segmentation_masks"), fh(this, "segmentation_masks"), this.h.ia("segmentation_masks", (e, t) => {
			this.segmentationMasks = e.map((e) => dg(this, e, !0, !this.v)), X(this, t);
		}), this.h.attachEmptyPacketListener("segmentation_masks", (e) => {
			this.segmentationMasks = [], X(this, e);
		})), e = e.h(), this.setGraph(new Uint8Array(e), !0);
	}
};
Qg.prototype.detectForVideo = Qg.prototype.I, Qg.prototype.detect = Qg.prototype.H, Qg.prototype.setOptions = Qg.prototype.A, Qg.createFromModelPath = function(e, t) {
	return Z(Qg, e, { baseOptions: { modelAssetPath: t } });
}, Qg.createFromModelBuffer = function(e, t) {
	return Z(Qg, e, { baseOptions: { modelAssetBuffer: t } });
}, Qg.createFromOptions = function(e, t) {
	return Z(Qg, e, t);
}, Qg.POSE_CONNECTIONS = Mg, M("module$exports$google3$third_party$mediapipe$tasks$web$vision$pose_landmarker$pose_landmarker.PoseLandmarker.POSE_CONNECTIONS", Qg.POSE_CONNECTIONS);
//#endregion
//#region ../../node_modules/@mediapipe/tasks-vision/wasm/vision_wasm_internal.js?url
var $g = new URL("./assets/vision_wasm_internal.js", import.meta.url).href, e_ = new URL("./assets/vision_wasm_internal.wasm", import.meta.url).href, t_ = {
	face: "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task",
	pose: "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task",
	hands: "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
};
async function n_(e) {
	try {
		let t = await caches.open("gleamshelf-avatar-models"), n = await t.match(e);
		if (n) return new Uint8Array(await n.arrayBuffer());
		let r = await fetch(e);
		if (!r.ok) throw Error(`The tracking model could not be fetched (${r.status}).`);
		return await t.put(e, r.clone()), new Uint8Array(await r.arrayBuffer());
	} catch (t) {
		if (t instanceof Error && /fetched/.test(t.message)) throw t;
		let n = await fetch(e);
		if (!n.ok) throw Error("The tracking model could not be fetched: check the internet the first time.");
		return new Uint8Array(await n.arrayBuffer());
	}
}
var r_ = {
	wasmLoaderPath: $g,
	wasmBinaryPath: e_
}, i_ = class e {
	face;
	pose;
	hands;
	running = !1;
	lastVideoTime = -1;
	handle = 0;
	constructor(e, t, n) {
		this.face = e, this.pose = t, this.hands = n;
	}
	static async create(t = {}, n) {
		let { face: r = !0, body: i = !0, hands: a = !0 } = t, o = (e) => ({
			modelAssetBuffer: e,
			delegate: "GPU"
		});
		n?.("Loading face tracking…");
		let s = r ? await Q.createFromOptions(r_, {
			baseOptions: o(await n_(t_.face)),
			runningMode: "VIDEO",
			numFaces: 1,
			outputFaceBlendshapes: !0,
			outputFacialTransformationMatrixes: !0
		}) : null;
		n?.(i ? "Loading body tracking…" : "");
		let c = i ? await Qg.createFromOptions(r_, {
			baseOptions: o(await n_(t_.pose)),
			runningMode: "VIDEO",
			numPoses: 1
		}) : null;
		n?.(a ? "Loading hand tracking…" : "");
		let l = a ? await jg.createFromOptions(r_, {
			baseOptions: o(await n_(t_.hands)),
			runningMode: "VIDEO",
			numHands: 2
		}) : null;
		return new e(s, c, l);
	}
	start(e, t) {
		this.running = !0;
		let n = () => {
			if (!this.running || (this.handle = requestAnimationFrame(n), e.readyState < 2 || e.currentTime === this.lastVideoTime)) return;
			this.lastVideoTime = e.currentTime;
			let r = performance.now();
			t(this.detect(e, r), r);
		};
		n();
	}
	detect(e, t) {
		let n = {}, r = this.face?.detectForVideo(e, t);
		if (r?.faceBlendshapes?.[0]) {
			let e = {};
			for (let t of r.faceBlendshapes[0].categories) e[t.categoryName] = t.score;
			n.face = {
				blendshapes: e,
				matrix: r.facialTransformationMatrixes?.[0]?.data
			};
		}
		let i = this.pose?.detectForVideo(e, t), a = i?.worldLandmarks?.[0], o = i?.landmarks?.[0];
		a && o && (n.pose = a.map((e, t) => ({
			x: e.x,
			y: e.y,
			z: e.z,
			visibility: o[t]?.visibility ?? e.visibility
		})));
		let s = this.hands?.detectForVideo(e, t);
		return s?.worldLandmarks?.forEach((e, t) => {
			let r = s.landmarks[t]?.[0], i;
			i = r && o?.[15] && o[16] ? Math.hypot(r.x - o[15].x, r.y - o[15].y) < Math.hypot(r.x - o[16].x, r.y - o[16].y) ? "left" : "right" : s.handedness[t]?.[0]?.categoryName === "Left" ? "right" : "left";
			let a = e.map((e) => ({
				x: e.x,
				y: e.y,
				z: e.z
			}));
			i === "left" ? n.leftHand = a : n.rightHand = a;
		}), n;
	}
	stop() {
		this.running = !1, cancelAnimationFrame(this.handle);
	}
	dispose() {
		this.stop(), this.face?.close(), this.pose?.close(), this.hands?.close();
	}
}, a_ = 16e3;
function o_(e) {
	let t = new Float32Array(e.reduce((e, t) => e + t.length, 0)), n = 0;
	for (let r of e) t.set(r, n), n += r.length;
	return t;
}
function s_(e, t, n = a_) {
	if (n >= t) return e;
	let r = t / n, i = new Float32Array(Math.floor(e.length / r));
	for (let t = 0; t < i.length; t++) {
		let n = Math.floor(t * r), a = Math.min(e.length, Math.floor((t + 1) * r)), o = 0;
		for (let t = n; t < a; t++) o += e[t];
		i[t] = o / Math.max(1, a - n);
	}
	return i;
}
function c_(e, t) {
	let n = /* @__PURE__ */ new ArrayBuffer(44 + e.length * 2), r = new DataView(n), i = (e, t) => [...t].forEach((t, n) => r.setUint8(e + n, t.charCodeAt(0)));
	i(0, "RIFF"), r.setUint32(4, 36 + e.length * 2, !0), i(8, "WAVE"), i(12, "fmt "), r.setUint32(16, 16, !0), r.setUint16(20, 1, !0), r.setUint16(22, 1, !0), r.setUint32(24, t, !0), r.setUint32(28, t * 2, !0), r.setUint16(32, 2, !0), r.setUint16(34, 16, !0), i(36, "data"), r.setUint32(40, e.length * 2, !0);
	for (let t = 0; t < e.length; t++) r.setInt16(44 + t * 2, Math.round(Math.max(-1, Math.min(1, e[t])) * 32767), !0);
	return n;
}
function l_(e) {
	let t = 0;
	for (let n = 0; n < e.length; n++) t += e[n] * e[n];
	return e.length ? Math.sqrt(t / e.length) : 0;
}
var u_ = class {
	o;
	noise = .01;
	loudFor = 0;
	quietFor = 0;
	open = !1;
	kept = [];
	keptMs = 0;
	before = [];
	beforeMs = 0;
	constructor(e = {}) {
		this.o = {
			startMs: 120,
			pauseMs: 750,
			beforeMs: 300,
			shortestMs: 450,
			longestMs: 2e4,
			...e
		};
	}
	get hearing() {
		return this.open;
	}
	get threshold() {
		return Math.max(.012, this.noise * 3);
	}
	reset() {
		this.open = !1, this.kept = [], this.keptMs = 0, this.loudFor = 0, this.quietFor = 0;
	}
	push(e, t) {
		let n = e.length / t * 1e3, r = l_(e), i = r > this.threshold;
		if (this.open || (this.noise = r < this.noise ? this.noise * .7 + r * .3 : this.noise * .995 + r * .005), !this.open) {
			for (this.before.push(e), this.beforeMs += n; this.before.length > 1 && this.beforeMs - this.before[0].length / t * 1e3 >= this.o.beforeMs;) this.beforeMs -= this.before.shift().length / t * 1e3;
			return this.loudFor = i ? this.loudFor + n : 0, this.loudFor >= this.o.startMs && (this.open = !0, this.kept = [...this.before], this.keptMs = this.beforeMs, this.before = [], this.beforeMs = 0, this.quietFor = 0), null;
		}
		if (this.kept.push(e), this.keptMs += n, this.quietFor = i ? 0 : this.quietFor + n, this.quietFor < this.o.pauseMs && this.keptMs < this.o.longestMs) return null;
		let a = this.keptMs - this.quietFor, o = o_(this.kept);
		return this.reset(), a >= this.o.shortestMs ? o : null;
	}
}, d_ = class {
	size;
	raw = [];
	at = 0;
	out = [];
	constructor(e = 2560) {
		this.size = e;
	}
	push(e, t) {
		let n = t / a_;
		for (let t = 0; t < e.length; t++) this.raw.push(e[t]);
		for (; this.at + n <= this.raw.length;) {
			let e = Math.floor(this.at), t = Math.min(this.raw.length, Math.max(e + 1, Math.floor(this.at + n))), r = 0;
			for (let n = e; n < t; n++) r += this.raw[n];
			this.out.push(r / (t - e)), this.at += n;
		}
		let r = Math.floor(this.at);
		this.raw = this.raw.slice(r), this.at -= r;
		let i = [];
		for (; this.out.length >= this.size;) i.push(Float32Array.from(this.out.splice(0, this.size)));
		return i;
	}
	reset() {
		this.raw = [], this.at = 0, this.out = [];
	}
};
function f_(e, t, n, r = 2048, i = null, a = .5) {
	let o = Math.round(n * t), s = new Float64Array(r), c = new Float64Array(r);
	for (let t = 0; t < r; t++) {
		let n = o - r + t, i = n >= 0 && n < e.length ? e[n] : 0, a = 2 * Math.PI * t / (r - 1);
		s[t] = i * (.42 - .5 * Math.cos(a) + .08 * Math.cos(2 * a));
	}
	p_(s, c);
	let l = r / 2, u = new Float32Array(l), d = new Uint8Array(l);
	for (let e = 0; e < l; e++) {
		let t = Math.hypot(s[e], c[e]) / r, n = i ? a * i[e] + (1 - a) * t : t;
		u[e] = n;
		let o = 20 * Math.log10(n || 1e-12);
		d[e] = Math.max(0, Math.min(255, Math.round((o + 100) / 70 * 255)));
	}
	return {
		bytes: d,
		magnitudes: u
	};
}
function p_(e, t) {
	let n = e.length;
	for (let r = 1, i = 0; r < n; r++) {
		let a = n >> 1;
		for (; i & a; a >>= 1) i ^= a;
		i ^= a, r < i && ([e[r], e[i]] = [e[i], e[r]], [t[r], t[i]] = [t[i], t[r]]);
	}
	for (let r = 2; r <= n; r <<= 1) {
		let i = -2 * Math.PI / r;
		for (let a = 0; a < n; a += r) for (let n = 0; n < r / 2; n++) {
			let o = Math.cos(i * n), s = Math.sin(i * n), c = a + n, l = a + n + r / 2, u = e[l] * o - t[l] * s, d = e[l] * s + t[l] * o;
			e[l] = e[c] - u, t[l] = t[c] - d, e[c] = e[c] + u, t[c] = t[c] + d;
		}
	}
}
var m_ = [
	"Spin Hobby",
	"Nendoroid",
	"figma",
	"Gunpla",
	"Gundam",
	"Bandai",
	"Banpresto",
	"Kotobukiya",
	"Good Smile",
	"Max Factory",
	"Hatsune Miku",
	"Pokémon",
	"Sanrio",
	"Kuromi",
	"Chiikawa",
	"Labubu",
	"Pop Mart",
	"Funko",
	"Ichiban Kuji",
	"gacha",
	"plushie"
];
function h_(e) {
	let t = [], n = {};
	for (let r of e.split("\n")) {
		let [e, i] = r.split("=").map((e) => e.trim());
		!e || e.length > 60 || (t.push(e), i && !/\s/.test(e) && i.length <= 120 && (n[e] = i));
	}
	return {
		names: [...new Set(t)].slice(0, 60),
		sounds: n
	};
}
//#endregion
//#region ../avatar/assets/default.vrm?url
var g_ = new URL("./assets/default.vrm", import.meta.url).href, __ = "gleamshelf-avatar", v_ = "files";
function y_() {
	return new Promise((e, t) => {
		let n = indexedDB.open(__, 1);
		n.onupgradeneeded = () => n.result.createObjectStore(v_), n.onsuccess = () => e(n.result), n.onerror = () => t(n.error ?? /* @__PURE__ */ Error("No storage"));
	});
}
async function b_() {
	try {
		let e = await y_();
		return await new Promise((t) => {
			let n = e.transaction(v_).objectStore(v_).get("avatar");
			n.onsuccess = () => t(n.result ?? null), n.onerror = () => t(null);
		});
	} catch {
		return null;
	}
}
async function x_(e) {
	try {
		let t = await y_();
		await new Promise((n) => {
			let r = t.transaction(v_, "readwrite");
			e ? r.objectStore(v_).put(e, "avatar") : r.objectStore(v_).delete("avatar"), r.oncomplete = () => n(), r.onerror = () => n();
		});
	} catch {}
}
var S_ = "gleamshelf.avatar.colours";
function C_(e) {
	try {
		return JSON.parse(localStorage.getItem(S_) ?? "{}")[e] ?? {};
	} catch {
		return {};
	}
}
function w_(e, t) {
	try {
		let n = JSON.parse(localStorage.getItem(S_) ?? "{}");
		n[e] = t, localStorage.setItem(S_, JSON.stringify(n));
	} catch {}
}
//#endregion
//#region src/avatar/voice.ts
var T_ = [
	"aa",
	"ih",
	"ou",
	"ee",
	"oh"
], E_ = 1024, D_ = 2560, O_ = .04, k_ = class {
	context;
	analyser;
	out;
	bins;
	source = null;
	processor = null;
	gate = new u_();
	held = null;
	playing = null;
	queue = Promise.resolve();
	chunker = new d_(D_);
	liveAt = 0;
	mode = "hold";
	live = !1;
	onVoice = null;
	onLiveChunk = null;
	listening = !1;
	onSentence = null;
	onHearing = null;
	constructor() {
		this.context = new AudioContext(), this.analyser = this.context.createAnalyser(), this.analyser.fftSize = 2048, this.analyser.smoothingTimeConstant = .5, this.out = this.context.createGain(), this.analyser.connect(this.out), this.out.connect(this.context.destination), this.bins = new Uint8Array(this.analyser.frequencyBinCount);
	}
	set audible(e) {
		this.out.gain.value = +!!e;
	}
	wake() {
		this.context.state === "suspended" && this.context.resume();
	}
	attach(e) {
		this.processor?.disconnect(), this.source?.disconnect(), this.processor = null, this.source = null, this.gate.reset(), e && (this.context.resume(), this.source = this.context.createMediaStreamSource(e), this.processor = this.context.createScriptProcessor(E_, 1, 1), this.processor.onaudioprocess = (e) => this.heard(new Float32Array(e.inputBuffer.getChannelData(0))), this.source.connect(this.processor), this.processor.connect(this.context.destination));
	}
	heard(e) {
		if (!this.listening) return;
		if (this.live) {
			for (let t of this.chunker.push(e, this.context.sampleRate)) this.onLiveChunk?.(new Blob([c_(t, a_)], { type: "audio/wav" }), performance.now());
			return;
		}
		if (this.mode === "hold") {
			this.held?.push(e);
			return;
		}
		if (this.playing) return;
		let t = this.gate.hearing, n = this.gate.push(e, this.context.sampleRate);
		this.gate.hearing !== t && this.onHearing?.(this.gate.hearing), n && this.send(n);
	}
	hold(e) {
		if (this.wake(), this.mode !== "hold" || !this.listening) return;
		if (e) {
			this.held ??= [], this.onHearing?.(!0);
			return;
		}
		let t = this.held;
		this.held = null, this.onHearing?.(!1), t?.length && this.send(o_(t));
	}
	send(e) {
		let t = s_(e, this.context.sampleRate, a_);
		this.onSentence?.(new Blob([c_(t, a_)], { type: "audio/wav" }), performance.now());
	}
	play(e) {
		let t, n = new Promise((e) => t = e);
		return this.queue = this.queue.then(async () => {
			try {
				let n = await this.context.decodeAudioData(await e.arrayBuffer());
				this.context.resume();
				let r = this.context.createBufferSource();
				r.buffer = n, r.connect(this.analyser), this.onVoice?.("clip", e);
				let i = new Promise((e) => r.onended = () => e());
				this.playing = r, r.start(), t(), await i;
			} catch {
				t();
			} finally {
				this.playing = null, this.gate.reset();
			}
		}), n;
	}
	async playLive(e) {
		let t = await this.context.decodeAudioData(await e.arrayBuffer()), n = this.context.currentTime;
		this.liveAt < n + .005 && (this.liveAt = n + O_);
		let r = this.context.createBufferSource();
		r.buffer = t, r.connect(this.analyser), r.start(this.liveAt), this.onVoice?.("live", e);
		let i = this.liveAt - n;
		return this.liveAt += t.duration, i;
	}
	resetLive() {
		this.chunker.reset(), this.liveAt = 0;
	}
	hush() {
		try {
			this.playing?.stop();
		} catch {}
	}
	get talking() {
		return this.playing !== null || this.context.currentTime < this.liveAt;
	}
	lips() {
		if (!this.talking) return null;
		this.analyser.getByteFrequencyData(this.bins);
		let e = Dt(this.bins, this.context.sampleRate, this.analyser.fftSize);
		return T_.some((t) => (e[t] ?? 0) > 0) ? e : {
			aa: 0,
			ih: 0,
			ou: 0,
			ee: 0,
			oh: 0
		};
	}
	close() {
		this.attach(null), this.hush(), this.context.close();
	}
};
async function A_(e, t, n, r, i) {
	i("listening");
	let a = await e.listen(t, { words: r.names });
	if (!a.text) return null;
	let o = a.text, s = a.language && a.language !== "en";
	(n.fix || s) && (i("fixing", a.text), o = await e.fixWording(a.text, {
		language: a.language,
		words: r.names
	})), i("speaking", a.text);
	let c = await e.speak(o, {
		voice: n.voice,
		speed: n.speed,
		words: r.sounds
	});
	return {
		heard: a.text,
		said: o,
		language: a.language,
		audio: c
	};
}
var j_ = "gleamshelf.avatar.voice", M_ = {
	voice: "af_heart",
	speed: 1,
	fix: !0,
	talk: "hold",
	words: ""
};
function N_() {
	try {
		return {
			...M_,
			...JSON.parse(localStorage.getItem(j_) ?? "{}")
		};
	} catch {
		return M_;
	}
}
function P_(e) {
	try {
		localStorage.setItem(j_, JSON.stringify(e));
	} catch {}
}
//#endregion
//#region src/avatar/VoicePanel.tsx
var F_ = {
	listening: "Hearing it…",
	fixing: "Tidying the words…",
	speaking: "Saying it…"
}, I_ = "Hi everyone, welcome to the shop! Today's new arrivals are a Nendoroid and some Gunpla.", L_ = 4, R_ = .22;
function z_() {
	let e = 2560, t = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(5164)), n = (e, n) => [...n].forEach((n, r) => t.setUint8(e + r, n.charCodeAt(0)));
	n(0, "RIFF"), t.setUint32(4, 5156, !0), n(8, "WAVEfmt "), t.setUint32(16, 16, !0), t.setUint16(20, 1, !0), t.setUint16(22, 1, !0), t.setUint32(24, 16e3, !0), t.setUint32(28, 32e3, !0), t.setUint16(32, 2, !0), t.setUint16(34, 16, !0), n(36, "data"), t.setUint32(40, e * 2, !0);
	for (let n = 0; n < e; n++) t.setInt16(44 + n * 2, Math.round(6e3 * Math.sin(n / 16e3 * 2 * Math.PI * 180)), !0);
	return new Blob([t.buffer], { type: "audio/wav" });
}
function B_({ desk: e, mode: i, onMode: a, micOn: o, startMic: s, settings: c, onSettings: l }) {
	let u = r(), [d, f] = O(null), [p, m] = O(null), [h, g] = O(!1), [_, v] = O([]), [y, b] = O(""), [ee, x] = O(null), [S, C] = O(null), w = Me(Promise.resolve()), te = i === "clear", ne = je(() => {
		let e = h_(c.words);
		return {
			names: [.../* @__PURE__ */ new Set([...e.names, ...m_])].slice(0, 60),
			sounds: e.sounds
		};
	}, [c.words]), T = u.state === "ready" && d?.ok === !0, E = d?.live, re = !!E?.voices.includes(c.voice), ie = T && !!E?.ok && re, D = (e) => {
		let t = {
			...c,
			...e
		};
		P_(t), l(t);
	};
	Ae(() => {
		if (u.state !== "ready") return f(null);
		let e = !1;
		return u.client.voiceStatus().then((t) => !e && f(t ?? {
			ok: !1,
			missing: ["a newer Gleamshelf app"],
			setup: "git pull, then npm run local:start"
		})).catch(() => !e && f(null)), () => {
			e = !0;
		};
	}, [u.state, u.client]), Ae(() => {
		if (!te || !T) return;
		let e = () => w.current = w.current.then(async () => {
			try {
				let e = await u.client.speak("Ready.", { voice: c.voice });
				await u.client.listen(e), c.fix && await u.client.fixWording("Ready.");
			} catch {}
		});
		m("Getting the voice ready…"), e().finally(() => m(null));
		let t = setInterval(() => void e(), 48e4);
		return () => clearInterval(t);
	}, [te, T]), Ae(() => {
		if (e) return e.mode = c.talk, e.listening = te && o && T, e.onHearing = g, e.onSentence = (t, n) => {
			w.current = w.current.then(async () => {
				try {
					let r = await A_(u.client, t, c, ne, (e, t) => {
						m(F_[e]), t && v((e) => [{
							heard: t,
							said: "…",
							delayMs: 0,
							language: ""
						}, ...e.slice(0, 3)]);
					});
					if (!r) return;
					await e.play(r.audio);
					let i = {
						heard: r.heard,
						said: r.said,
						delayMs: performance.now() - n,
						language: r.language
					};
					v((e) => [i, ...e.slice(+(e[0]?.said === "…"), 4)]);
				} catch (e) {
					x(e instanceof Error ? e.message : "That sentence could not be said again.");
				} finally {
					m(null);
				}
			});
		}, () => {
			e.onSentence = null, e.onHearing = null, e.listening = !1;
		};
	}, [
		e,
		te,
		o,
		T,
		c,
		ne,
		u.client
	]), Ae(() => {
		if (!e || i !== "live" || !ie || !o) return;
		let t = Math.random().toString(36).slice(2, 12), n = Promise.resolve(), r = 0, a = !0, s = [];
		return e.resetLive(), e.live = !0, e.listening = !0, m("Getting the live voice ready…"), n = n.then(() => u.client.convertLive(z_(), {
			voice: c.voice,
			session: `${t}-warm`
		}).then(() => void 0).catch((e) => x(e instanceof Error ? e.message : "The live voice could not start.")).finally(() => m(null))), e.onLiveChunk = (i, o) => {
			if (r >= L_) return;
			r++;
			let l = a;
			a = !1, n = n.then(async () => {
				try {
					let n = await u.client.convertLive(i, {
						voice: c.voice,
						session: t,
						reset: l
					}), r = await e.playLive(n);
					s.push((performance.now() - o) / 1e3 + r + R_), s.length >= 12 && C(s.splice(0).reduce((e, t) => e + t, 0) / 12);
				} catch (e) {
					x(e instanceof Error ? e.message : "The live voice stopped.");
				} finally {
					r--;
				}
			});
		}, () => {
			e.onLiveChunk = null, e.live = !1, e.listening = !1, C(null);
		};
	}, [
		e,
		i,
		ie,
		o,
		c.voice,
		u.client
	]);
	let ae = () => {
		x(null), w.current = w.current.then(async () => {
			try {
				m("Making the live voice… (about a minute; it is reading its practice lines)"), await u.client.buildLiveVoice(c.voice), f(await u.client.voiceStatus());
			} catch (e) {
				x(e instanceof Error ? e.message : "The live voice could not be made.");
			} finally {
				m(null);
			}
		});
	}, oe = (t) => {
		e && t.trim() && (e.wake(), x(null), w.current = w.current.then(async () => {
			try {
				m(F_.speaking), await e.play(await u.client.speak(t.trim(), {
					voice: c.voice,
					speed: c.speed,
					words: ne.sounds
				}));
			} catch (e) {
				x(e instanceof Error ? e.message : "That could not be said.");
			} finally {
				m(null);
			}
		}));
	};
	return /* @__PURE__ */ A("section", { children: [
		/* @__PURE__ */ k("h4", { children: "Voice" }),
		/* @__PURE__ */ k(ye, {
			label: "Viewers hear",
			value: i,
			options: [
				"own",
				"clear",
				"live"
			],
			labels: {
				own: "My own",
				clear: "Clear",
				live: "Live"
			},
			onChange: (t) => {
				e?.wake(), a(t), t !== "own" && !o && s();
			}
		}),
		/* @__PURE__ */ k("p", {
			className: "gs-m3d__note",
			children: T ? "Free: heard, tidied and spoken by the models on this computer; your voice is never sent anywhere." : u.state === "ready" ? d ? `Set up the voice once with: ${d.setup} (free, about 0.9 GB, on this computer). Missing: ${d.missing.join(", ")}.` : "Checking the voice…" : "The clear voice and Say it need the Gleamshelf app running on this computer (free)."
		}),
		/* @__PURE__ */ A("label", {
			className: "gs-m3d__field",
			children: [/* @__PURE__ */ k("span", { children: "Its voice" }), /* @__PURE__ */ k("select", {
				value: c.voice,
				onChange: (e) => D({ voice: e.target.value }),
				children: ["American", "British"].map((e) => /* @__PURE__ */ k("optgroup", {
					label: e,
					children: n.filter((t) => t.accent === e).map((e) => /* @__PURE__ */ A("option", {
						value: e.id,
						children: [
							e.label,
							" (",
							e.kind,
							")"
						]
					}, e.id))
				}, e))
			})]
		}),
		/* @__PURE__ */ A("label", {
			className: "gs-m3d__field",
			children: [/* @__PURE__ */ k("span", { children: "Speed" }), /* @__PURE__ */ k("input", {
				type: "range",
				min: .7,
				max: 1.4,
				step: .05,
				value: c.speed,
				onChange: (e) => D({ speed: Number(e.target.value) })
			})]
		}),
		/* @__PURE__ */ k(t, { id: "avVoice" }),
		i === "live" && /* @__PURE__ */ A(Ne, { children: [
			/* @__PURE__ */ k("p", {
				className: "gs-m3d__note",
				children: T ? E?.ok ? re ? o ? S === null ? "Live: talk, and viewers hear the avatar's voice. Wear headphones, or it hears itself." : `Live: viewers hear the avatar's voice about ${S.toFixed(1)} s after you. Wear headphones.` : "Turn the mic on to talk." : "This voice has no live voice yet: make it once (about a minute, free, on this computer)." : `Set up the live voice once with: ${E?.setup ?? "npm run voice:setup -- --live"} (free, about 1.3 GB, on this computer).` : "The live voice needs the Gleamshelf app and its voice (see above)."
			}),
			T && E?.ok && !re && /* @__PURE__ */ k("button", {
				type: "button",
				className: "gs-m3d__btn gs-m3d__btn--primary",
				disabled: !!p,
				onClick: ae,
				children: "Make the live voice"
			}),
			p && /* @__PURE__ */ k("p", {
				className: "gs-m3d__note",
				role: "status",
				children: p
			}),
			/* @__PURE__ */ k(t, { id: "avLive" })
		] }),
		te && /* @__PURE__ */ A(Ne, { children: [
			/* @__PURE__ */ A("label", {
				className: "gs-m3d__check",
				children: [/* @__PURE__ */ k("input", {
					type: "checkbox",
					checked: c.fix,
					onChange: (e) => D({ fix: e.target.checked })
				}), " Fix the wording (and say it in English)"]
			}),
			/* @__PURE__ */ k(ye, {
				label: "Talk",
				value: c.talk,
				options: ["hold", "free"],
				labels: {
					hold: "Hold Space",
					free: "Hands-free"
				},
				onChange: (e) => D({ talk: e })
			}),
			c.talk === "hold" ? /* @__PURE__ */ k("button", {
				type: "button",
				className: `gs-m3d__btn gs-m3d__btn--primary gs-av__talk ${h ? "is-on" : ""}`,
				disabled: !T || !o,
				onPointerDown: (t) => {
					t.currentTarget.setPointerCapture(t.pointerId), e?.hold(!0);
				},
				onPointerUp: () => e?.hold(!1),
				onPointerCancel: () => e?.hold(!1),
				children: h ? "Listening… let go to send" : "Hold to talk (or hold Space)"
			}) : /* @__PURE__ */ k("p", {
				className: "gs-m3d__note",
				children: h ? "Hearing you…" : "Talk normally; a pause sends the sentence. Wear headphones so it does not hear itself."
			}),
			p && /* @__PURE__ */ k("p", {
				className: "gs-m3d__note",
				role: "status",
				children: p
			}),
			_.length > 0 && /* @__PURE__ */ k("ol", {
				className: "gs-av__lines",
				"aria-label": "What the avatar said",
				children: _.map((e, t) => /* @__PURE__ */ A("li", { children: [
					/* @__PURE__ */ k("span", {
						className: "gs-av__heard",
						children: e.heard
					}),
					e.said !== "…" && e.said !== e.heard && /* @__PURE__ */ k("span", {
						className: "gs-av__said",
						children: e.said
					}),
					e.delayMs > 0 && /* @__PURE__ */ A("small", { children: [(e.delayMs / 1e3).toFixed(1), " s after you"] })
				] }, t))
			}),
			/* @__PURE__ */ k(t, { id: "avClear" })
		] }),
		/* @__PURE__ */ A("label", {
			className: "gs-m3d__field gs-m3d__field--top",
			children: [/* @__PURE__ */ k("span", { children: "Say it" }), /* @__PURE__ */ k("textarea", {
				rows: 2,
				maxLength: 2e3,
				value: y,
				placeholder: "Type a line for the avatar to say",
				onChange: (e) => b(e.target.value)
			})]
		}),
		/* @__PURE__ */ A("div", {
			className: "gs-m3d__row",
			children: [
				/* @__PURE__ */ k("button", {
					type: "button",
					className: "gs-m3d__btn gs-m3d__btn--primary",
					disabled: !T || !y.trim(),
					onClick: () => oe(y),
					children: "Say it"
				}),
				/* @__PURE__ */ k("button", {
					type: "button",
					className: "gs-m3d__btn",
					disabled: !T,
					onClick: () => oe(I_),
					children: "Try the voice"
				}),
				/* @__PURE__ */ k("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => e?.hush(),
					children: "Stop"
				})
			]
		}),
		/* @__PURE__ */ k(t, { id: "avSay" }),
		/* @__PURE__ */ A("label", {
			className: "gs-m3d__field gs-m3d__field--top",
			children: [/* @__PURE__ */ k("span", { children: "Shop words" }), /* @__PURE__ */ k("textarea", {
				rows: 3,
				maxLength: 4e3,
				value: c.words,
				placeholder: "Tamashii Nations\nGunpla = GUN plah",
				onChange: (e) => D({ words: e.target.value })
			})]
		}),
		/* @__PURE__ */ k(t, { id: "avShopWords" }),
		ee && /* @__PURE__ */ k("p", {
			className: "gs-m3d__note",
			children: ee
		})
	] });
}
//#endregion
//#region src/avatar/productvideo.ts
var V_ = {
	tall: [1080, 1920],
	wide: [1920, 1080]
}, H_ = 30, U_ = .5, W_ = .3, G_ = 1.2, K_ = 48e3;
function q_(e) {
	let [t, n] = V_[e];
	return e === "tall" ? {
		product: {
			x: 90,
			y: 150,
			w: t - 180,
			h: 900
		},
		avatar: {
			x: t - 760,
			y: n - 1e3,
			w: 760,
			h: 1e3
		},
		card: {
			x: 70,
			y: 1110,
			w: 520,
			h: 260
		},
		caption: {
			x: 60,
			y: n - 330,
			w: t - 120,
			h: 230
		}
	} : {
		product: {
			x: 90,
			y: 90,
			w: 1e3,
			h: 720
		},
		avatar: {
			x: t - 820,
			y: 40,
			w: 820,
			h: n - 40
		},
		card: {
			x: 90,
			y: 830,
			w: 640,
			h: 190
		},
		caption: {
			x: 760,
			y: n - 230,
			w: t - 820,
			h: 180
		}
	};
}
function J_(e) {
	return e.replace(/\s+/g, " ").trim().split(/(?<=[.!?])\s+/).map((e) => e.trim()).filter(Boolean).slice(0, 12);
}
function Y_(e) {
	let t = U_;
	return e.map((e) => {
		let n = {
			start: t,
			end: t + e
		};
		return t += e + W_, n;
	});
}
function X_(e, t, n, r = 3) {
	let i = [], a = "";
	for (let r of t.split(" ")) {
		let t = a ? `${a} ${r}` : r;
		e.measureText(t).width > n && a ? (i.push(a), a = r) : a = t;
	}
	return a && i.push(a), i.slice(0, r);
}
async function Z_(e) {
	let t = await new OfflineAudioContext(1, 1, K_).decodeAudioData(await e.arrayBuffer());
	if (t.sampleRate === K_) return t.getChannelData(0).slice();
	let n = new OfflineAudioContext(1, Math.ceil(t.duration * K_), K_), r = n.createBufferSource();
	return r.buffer = t, r.connect(n.destination), r.start(), (await n.startRendering()).getChannelData(0).slice();
}
async function Q_(e) {
	if (!/svg/.test(e.type)) try {
		return await createImageBitmap(e);
	} catch {}
	let t = URL.createObjectURL(e);
	try {
		let e = new Image();
		return e.src = t, await e.decode(), (!e.naturalWidth || !e.naturalHeight) && (e.width = 1e3, e.height = 1e3), await createImageBitmap(e, {
			resizeWidth: e.naturalWidth >= 600 ? e.naturalWidth : 1200,
			resizeQuality: "high"
		});
	} finally {
		URL.revokeObjectURL(t);
	}
}
function $_(e, t, n, r) {
	let a = Math.min(n.w / t.width, n.h / t.height), o = t.width * a, s = t.height * a;
	e.save(), e.shadowColor = i(r.shade, .45), e.shadowBlur = 40, e.shadowOffsetY = 16, e.drawImage(t, n.x + (n.w - o) / 2, n.y + (n.h - s) / 2, o, s), e.restore();
}
function ev(e, t, n, r) {
	e.beginPath(), e.roundRect(t.x, t.y, t.w, t.h, n), e.fillStyle = r, e.fill();
}
async function tv(e, t, n = 320) {
	let r = new La(document.createElement("div"), { manual: !0 });
	try {
		await r.load(e);
		for (let [e, n] of Object.entries(t)) r.recolour(e, n);
		r.setFraming("face"), r.setBackdrop({ kind: "clear" });
		let i = r.renderFrame({
			expressions: { happy: .45 },
			bones: {}
		}, 0, n, n), o = document.createElement("canvas");
		o.width = o.height = n;
		let s = o.getContext("2d");
		return s.fillStyle = a().stage, s.fillRect(0, 0, n, n), s.drawImage(i, 0, 0), await new Promise((e, t) => o.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("No portrait.")), "image/jpeg", .88));
	} finally {
		r.dispose();
	}
}
async function nv(e) {
	let { client: t, voice: n, shape: r, onStep: o, signal: s } = e, c = J_(e.script);
	if (!c.length) throw Error("Write what the avatar says first.");
	let [l, u] = V_[r], d = q_(r), f = a(), p = [];
	for (let [e, r] of c.entries()) s?.throwIfAborted(), o(`Saying sentence ${e + 1} of ${c.length}…`), p.push(await Z_(await t.speak(r, {
		voice: n.voice,
		speed: n.speed,
		words: n.words
	})));
	let m = Y_(p.map((e) => e.length / K_)), h = m[m.length - 1].end + G_, g = new Float32Array(Math.ceil(h * K_));
	p.forEach((e, t) => g.set(e, Math.round(m[t].start * K_)));
	let _ = await he("avc", {
		width: l,
		height: u
	}) && await Ee("aac", {
		numberOfChannels: 1,
		sampleRate: K_
	}), v = !_ && await he("vp9", {
		width: l,
		height: u
	}) && await Ee("opus", {
		numberOfChannels: 1,
		sampleRate: K_
	});
	if (!_ && !v) throw Error("This browser cannot make video with sound. Try Chrome, Edge or Safari.");
	o("Getting the avatar ready…");
	let y = new La(document.createElement("div"), { manual: !0 }), b = null;
	try {
		await y.load(e.avatar);
		for (let [t, n] of Object.entries(e.colours)) y.recolour(t, n);
		y.setFraming("bust"), y.setBackdrop({ kind: "clear" });
		let t = null;
		if (e.visual?.kind === "picture" && (t = await Q_(e.visual.blob)), e.visual?.kind === "video") {
			let t = new we({
				source: new Se(e.visual.blob),
				formats: ge
			}), n = await t.getPrimaryVideoTrack();
			if (!n) throw Error("That file has no video in it.");
			b = {
				input: t,
				sink: new me(n, {
					width: d.product.w,
					height: d.product.h,
					fit: "contain"
				}),
				duration: await t.computeDuration()
			};
		}
		let n = new jt();
		n.hold("happy", .35), n.play("wave", 150), m[1] && n.play("point", m[1].start * 1e3);
		let a = document.createElement("canvas");
		a.width = l, a.height = u;
		let p = a.getContext("2d"), v = new Te({
			format: _ ? new be({ fastStart: "in-memory" }) : new Ce(),
			target: new xe()
		}), ee = new pe(a, {
			codec: _ ? "avc" : "vp9",
			bitrate: ve
		}), x = new _e({
			codec: _ ? "aac" : "opus",
			bitrate: 128e3
		});
		v.addVideoTrack(ee, { frameRate: H_ }), v.addAudioTrack(x), await v.start();
		let S = new AudioBuffer({
			length: g.length,
			numberOfChannels: 1,
			sampleRate: K_
		});
		S.copyToChannel(g, 0), await x.add(S);
		let C = Math.ceil(h * H_), w = null, te = !1;
		for (let a = 0; a < C; a++) {
			s?.throwIfAborted();
			let h = a / H_, _ = f_(g, K_, h, 2048, w);
			w = _.magnitudes;
			let v = m.some((e) => h >= e.start && h <= e.end + .1);
			n.speak(v ? Dt(_.bytes, K_, 2048) : null);
			let x = m[m.length - 1];
			!te && h >= x.end && (n.play("nod", h * 1e3), te = !0);
			let S = n.compose(h * 1e3), ne = p.createLinearGradient(0, 0, 0, u);
			if (ne.addColorStop(0, i(f.tint, .08)), ne.addColorStop(1, i(f.tint, 0)), p.fillStyle = f.stage, p.fillRect(0, 0, l, u), p.fillStyle = ne, p.fillRect(0, 0, l, u), t && $_(p, t, d.product, f), b) {
				let e = await b.sink.getCanvas(b.duration > 0 ? h % b.duration : 0);
				e && $_(p, e.canvas, d.product, f);
			}
			let T = y.renderFrame(S, 1 / H_, d.avatar.w, d.avatar.h);
			if (p.drawImage(T, d.avatar.x, d.avatar.y, d.avatar.w, d.avatar.h), e.product) {
				let t = d.card;
				ev(p, t, 28, i(f.bg, .82)), p.fillStyle = f.text, p.font = `700 ${r === "tall" ? 44 : 40}px system-ui, sans-serif`, X_(p, e.product.name, t.w - 64, 2).forEach((e, n) => p.fillText(e, t.x + 32, t.y + 70 + n * 52)), e.product.price && (p.fillStyle = f.accent, p.font = `800 ${r === "tall" ? 60 : 52}px system-ui, sans-serif`, p.fillText(e.product.price, t.x + 32, t.y + t.h - 40));
				let n = e.product.status === "pre" ? "Pre-order" : e.product.status === "low" ? "Only a few left" : null;
				if (n) {
					p.font = "700 30px system-ui, sans-serif";
					let e = p.measureText(n).width + 36;
					ev(p, {
						x: t.x + t.w - e - 28,
						y: t.y + t.h - 82,
						w: e,
						h: 50
					}, 25, f.accent), p.fillStyle = f.onAccent, p.fillText(n, t.x + t.w - e - 10, t.y + t.h - 46);
				}
			}
			let E = m.findIndex((e) => h >= e.start - .05 && h <= e.end + W_ * .8);
			if (E >= 0) {
				let e = d.caption;
				p.font = `600 ${r === "tall" ? 50 : 44}px system-ui, sans-serif`;
				let t = X_(p, c[E], e.w - 80, 3), n = r === "tall" ? 62 : 56, a = {
					x: e.x,
					y: e.y + e.h - t.length * n - 40,
					w: e.w,
					h: t.length * n + 40
				};
				ev(p, a, 24, i(f.shade, .6)), p.fillStyle = f.text, p.textAlign = "center", t.forEach((e, t) => p.fillText(e, a.x + a.w / 2, a.y + 20 + n * .8 + t * n)), p.textAlign = "left";
			}
			if (p.font = "700 36px system-ui, sans-serif", p.fillStyle = i(f.text, .85), e.shop && p.fillText(e.shop, 60, 80), e.aiMark) {
				p.font = "600 26px system-ui, sans-serif";
				let e = "AI voice", t = p.measureText(e).width + 28;
				ev(p, {
					x: l - t - 50,
					y: 48,
					w: t,
					h: 44
				}, 22, i(f.bg, .7)), p.fillStyle = f.muted, p.fillText(e, l - t - 36, 79);
			}
			await ee.add(h, 1 / H_), a % 15 == 0 && o("Making the video…", a / C);
		}
		o("Finishing…", 1), await v.finalize();
		let ne = v.target.buffer;
		return {
			blob: new Blob([ne], { type: _ ? "video/mp4" : "video/webm" }),
			extension: _ ? "mp4" : "webm",
			seconds: h
		};
	} finally {
		b?.input.dispose(), y.dispose();
	}
}
//#endregion
//#region src/avatar/AgentPanel.tsx
var rv = "gleamshelf.avatar.agent", iv = /^(hi|hello|hey|yo|good (morning|evening|afternoon)|konnichiwa|hiya)\b/i;
function av() {
	try {
		let e = JSON.parse(localStorage.getItem(rv) ?? "{}");
		return {
			name: typeof e.name == "string" && e.name.trim() ? e.name : "Gleam",
			away: !1
		};
	} catch {
		return {
			name: "Gleam",
			away: !1
		};
	}
}
function ov({ desk: e, voice: n, onGesture: i, colours: a }) {
	let o = r(), [s, c] = O(null), [l, u] = O(av), [d, f] = O(""), [p, m] = O([]), h = Me(1), g = Me(Promise.resolve()), _ = o.state === "ready" && s?.ok === !0, [v, y] = O(null), [b, ee] = O(!1);
	Ae(() => {
		if (o.state !== "ready") return y(null);
		let e = !1, t = () => void o.client.websiteStatus().then((t) => !e && y(t)).catch(() => {});
		t();
		let n = setInterval(t, 5e3);
		return () => {
			e = !0, clearInterval(n);
		};
	}, [o.state, o.client]);
	let x = async (e) => {
		ee(!0);
		try {
			if (e) {
				let e = await b_() ?? await (await fetch(new URL("./assets/default.vrm", import.meta.url).href)).arrayBuffer();
				await o.client.setWebsitePortrait(await tv(e, a));
			}
			y(await o.client.setWebsite({
				on: e,
				name: l.name,
				voice: !0,
				voiceId: n.voice,
				speed: n.speed,
				words: h_(n.words).sounds
			}));
		} catch (e) {
			y((t) => t && {
				...t,
				problem: e instanceof Error ? e.message : "It could not be turned on."
			});
		} finally {
			ee(!1);
		}
	};
	Ae(() => {
		if (o.state !== "ready") return c(null);
		let e = !1;
		return o.client.agentStatus().then((t) => !e && c(t ?? {
			ok: !1,
			setup: "a newer Gleamshelf app (git pull, then restart it)"
		})).catch(() => !e && c(null)), () => {
			e = !0;
		};
	}, [o.state, o.client]);
	let S = (e, t) => m((n) => n.map((n) => n.id === e ? {
		...n,
		...t
	} : n)), C = (t) => {
		if (!e || !t.answer) return;
		e.wake();
		let r = t.answer;
		g.current = g.current.then(async () => {
			try {
				iv.test(t.question) && i("wave");
				let a = await o.client.speak(r, {
					voice: n.voice,
					speed: n.speed,
					words: h_(n.words).sounds
				});
				await e.play(a), S(t.id, { state: "said" });
			} catch (e) {
				S(t.id, {
					state: "failed",
					error: e instanceof Error ? e.message : "It could not be said."
				});
			}
		});
	}, w = (t) => {
		let n = t.trim();
		if (!n || !_) return;
		e?.wake();
		let r = /^([^:\n]{1,30}):\s+(.+)$/s.exec(n), i = {
			id: h.current++,
			question: r ? r[2].trim() : n,
			from: r ? r[1].trim() : null,
			answer: null,
			products: [],
			state: "thinking"
		}, a = p.filter((e) => e.answer && e.state !== "skipped").slice(0, 4).reverse().map((e) => ({
			question: e.question,
			answer: e.answer
		}));
		m((e) => [i, ...e].slice(0, 30));
		let s = l.away;
		g.current = g.current.then(async () => {
			try {
				let e = await o.client.askAgent(i.question, {
					name: l.name,
					history: a
				});
				S(i.id, {
					answer: e.answer,
					products: e.products,
					state: s ? "said" : "draft"
				}), s && C({
					id: i.id,
					answer: e.answer,
					question: i.question
				});
			} catch (e) {
				S(i.id, {
					state: "failed",
					error: e instanceof Error ? e.message : "No answer came."
				});
			}
		});
	}, te = (e) => {
		let t = {
			...l,
			...e
		};
		u(t);
		try {
			localStorage.setItem(rv, JSON.stringify({ name: t.name }));
		} catch {}
	};
	return /* @__PURE__ */ A("section", { children: [
		/* @__PURE__ */ k("h4", { children: "AI assistant" }),
		/* @__PURE__ */ k("p", {
			className: "gs-m3d__note",
			children: _ ? "Free: answers come from your shop’s catalogue and the model on this computer. Its replies are marked AI." : o.state === "ready" ? s ? `Set it up once with: ${s.setup}` : "Checking…" : "Needs the Gleamshelf app running on this computer (free)."
		}),
		/* @__PURE__ */ A("label", {
			className: "gs-m3d__field",
			children: [/* @__PURE__ */ k("span", { children: "Its name" }), /* @__PURE__ */ k("input", {
				value: l.name,
				maxLength: 30,
				onChange: (e) => te({ name: e.target.value })
			})]
		}),
		/* @__PURE__ */ A("label", {
			className: "gs-m3d__check",
			children: [/* @__PURE__ */ k("input", {
				type: "checkbox",
				checked: l.away,
				onChange: (e) => te({ away: e.target.checked })
			}), " Away: it answers out loud by itself"]
		}),
		/* @__PURE__ */ A("form", {
			className: "gs-av__ask",
			onSubmit: (e) => {
				e.preventDefault(), w(d), f("");
			},
			children: [/* @__PURE__ */ k("input", {
				value: d,
				maxLength: 500,
				placeholder: "A viewer’s question (or paste “name: message”)",
				"aria-label": "A viewer's question",
				onChange: (e) => f(e.target.value),
				disabled: !_
			}), /* @__PURE__ */ k("button", {
				type: "submit",
				className: "gs-m3d__btn gs-m3d__btn--primary",
				disabled: !_ || !d.trim(),
				children: "Ask"
			})]
		}),
		p.length > 0 && /* @__PURE__ */ k("ol", {
			className: "gs-av__chat",
			"aria-label": "Chat",
			children: p.map((e) => /* @__PURE__ */ A("li", { children: [
				/* @__PURE__ */ A("p", {
					className: "gs-av__q",
					children: [e.from && /* @__PURE__ */ A("b", { children: [e.from, ": "] }), e.question]
				}),
				e.state === "thinking" && /* @__PURE__ */ k("p", {
					className: "gs-m3d__note",
					children: "Thinking…"
				}),
				e.answer && /* @__PURE__ */ A("p", {
					className: "gs-av__a",
					children: [
						/* @__PURE__ */ k("span", {
							className: "gs-av__ai",
							title: "Written by the AI assistant",
							children: "AI"
						}),
						" ",
						e.answer
					]
				}),
				e.products.length > 0 && /* @__PURE__ */ A("p", {
					className: "gs-av__looked",
					children: ["Looked at: ", e.products.map((e) => `${e.name} (${e.price})`).join(", ")]
				}),
				e.state === "draft" && /* @__PURE__ */ A("div", {
					className: "gs-m3d__row",
					children: [/* @__PURE__ */ k("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						onClick: () => C(e),
						children: "Say it"
					}), /* @__PURE__ */ k("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => S(e.id, { state: "skipped" }),
						children: "Skip"
					})]
				}),
				e.state === "failed" && /* @__PURE__ */ k("p", {
					className: "gs-m3d__note",
					children: e.error
				})
			] }, e.id))
		}),
		/* @__PURE__ */ k(t, { id: "avAgent" }),
		v && /* @__PURE__ */ A(Ne, { children: [
			/* @__PURE__ */ A("label", {
				className: "gs-m3d__check",
				children: [
					/* @__PURE__ */ k("input", {
						type: "checkbox",
						checked: v.on,
						disabled: !_ || b,
						onChange: (e) => void x(e.target.checked)
					}),
					" ",
					"Answer the shop website’s visitors"
				]
			}),
			/* @__PURE__ */ k("p", {
				className: "gs-m3d__note",
				children: b ? "Turning it on…" : v.problem ? v.problem : v.on && v.answering ? `On the shop website: ${v.answered === 1 ? "1 visitor answered" : `${v.answered} visitors answered`} from this computer. Keep it awake.` : v.on ? "Connecting to the shop…" : "Off: the shop website answers visitors with text and says the talking assistant is away."
			}),
			v.last && /* @__PURE__ */ A("p", {
				className: "gs-av__looked",
				children: [
					"Last: “",
					v.last.question,
					"”"
				]
			}),
			/* @__PURE__ */ k(t, { id: "avWebsite" })
		] })
	] });
}
//#endregion
//#region src/avatar/VideoPanel.tsx
var sv = [
	"10",
	"20",
	"30"
];
function cv({ voice: e, colours: n }) {
	let i = r(), a = i.state === "ready", [o, s] = O(""), [c, l] = O(null), [u, d] = O(null), [f, p] = O(null), [m, h] = O(null), [g, _] = O(""), [v, y] = O("20"), [b, ee] = O("tall"), [x, S] = O(!0), [C, w] = O(null), [te, ne] = O(null), [T, E] = O(null), [re, ie] = O(null), D = Me(null), ae = Me(null);
	Ae(() => () => {
		m && URL.revokeObjectURL(m.url);
	}, [m]), Ae(() => () => {
		T && URL.revokeObjectURL(T.url);
	}, [T]);
	let oe = async (e, t) => {
		w(e), ie(null);
		try {
			await t();
		} catch (e) {
			e?.name !== "AbortError" && ie(e instanceof Error ? e.message : "That did not work.");
		} finally {
			w(null), ne(null);
		}
	}, se = () => oe("Looking in the shop…", async () => {
		let e = await i.client.shopProducts(o);
		l(e.products), d(e.shop);
	}), ce = (e) => oe("Getting its picture…", async () => {
		if (p(e), l(null), e.image) {
			let t = await i.client.shopImage(e.image);
			h({
				kind: "picture",
				blob: t,
				url: URL.createObjectURL(t),
				name: e.name
			});
		} else h(null);
	}), le = () => f && oe("Writing the script… (a few seconds)", async () => _(await i.client.writeScript(f.id, Number(v)))), ue = () => oe("Making the video…", async () => {
		let t = new AbortController();
		ae.current = t;
		let r = await b_() ?? await (await fetch(new URL("./assets/default.vrm", import.meta.url).href)).arrayBuffer(), a = await nv({
			client: i.client,
			script: g,
			voice: {
				voice: e.voice,
				speed: e.speed,
				words: h_(e.words).sounds
			},
			avatar: r,
			colours: n,
			product: f ? {
				name: f.name,
				price: f.status === "out" || f.status === "closed" ? null : f.price,
				status: f.status
			} : null,
			visual: m ? {
				kind: m.kind,
				blob: m.blob
			} : null,
			shape: b,
			shop: f ? u : null,
			aiMark: x,
			signal: t.signal,
			onStep: (e, t) => {
				w(e), t !== void 0 && ne(t);
			}
		});
		E({
			url: URL.createObjectURL(a.blob),
			extension: a.extension,
			seconds: a.seconds
		});
	});
	return /* @__PURE__ */ A("section", { children: [
		/* @__PURE__ */ k("h4", { children: "Product video" }),
		/* @__PURE__ */ k("p", {
			className: "gs-m3d__note",
			children: a ? "Free: the script, the voice and the video are all made on this computer. About a minute for 20 seconds of video." : "Needs the Gleamshelf app running on this computer (free)."
		}),
		/* @__PURE__ */ A("form", {
			className: "gs-av__ask",
			onSubmit: (e) => {
				e.preventDefault(), se();
			},
			children: [/* @__PURE__ */ k("input", {
				value: o,
				placeholder: "Find a product in the shop",
				"aria-label": "Find a product",
				onChange: (e) => s(e.target.value),
				disabled: !a || !!C
			}), /* @__PURE__ */ k("button", {
				type: "submit",
				className: "gs-m3d__btn",
				disabled: !a || !!C,
				children: "Find"
			})]
		}),
		c && /* @__PURE__ */ A("ul", {
			className: "gs-av__found",
			"aria-label": "Products found",
			children: [c.length === 0 && /* @__PURE__ */ k("li", {
				className: "gs-m3d__note",
				children: "Nothing in the shop matches."
			}), c.map((e) => /* @__PURE__ */ k("li", { children: /* @__PURE__ */ A("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => void ce(e),
				disabled: !!C,
				children: [
					e.name,
					" ",
					/* @__PURE__ */ k("span", {
						className: "gs-av__price",
						children: e.price
					})
				]
			}) }, e.id))]
		}),
		(f || m) && /* @__PURE__ */ A("div", {
			className: "gs-av__picked",
			children: [
				m?.kind === "picture" && /* @__PURE__ */ k("img", {
					src: m.url,
					alt: ""
				}),
				m?.kind === "video" && /* @__PURE__ */ k("video", {
					src: m.url,
					muted: !0,
					loop: !0,
					autoPlay: !0,
					playsInline: !0
				}),
				/* @__PURE__ */ A("p", { children: [/* @__PURE__ */ k("b", { children: f?.name ?? m?.name }), f && ` · ${f.price}`] })
			]
		}),
		/* @__PURE__ */ A("div", {
			className: "gs-m3d__row",
			children: [/* @__PURE__ */ k("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => D.current?.click(),
				disabled: !!C,
				children: "Use a picture or video…"
			}), /* @__PURE__ */ k("input", {
				ref: D,
				type: "file",
				accept: "image/png,image/jpeg,image/webp,video/mp4,video/webm,video/quicktime",
				hidden: !0,
				onChange: (e) => {
					let t = e.target.files?.[0];
					e.target.value = "", t && h({
						kind: t.type.startsWith("video/") ? "video" : "picture",
						blob: t,
						url: URL.createObjectURL(t),
						name: t.name
					});
				}
			})]
		}),
		/* @__PURE__ */ A("label", {
			className: "gs-m3d__field gs-m3d__field--top",
			children: [/* @__PURE__ */ k("span", { children: "It says" }), /* @__PURE__ */ k("textarea", {
				rows: 4,
				maxLength: 900,
				value: g,
				placeholder: "What the avatar says (or let it write this from the product)",
				onChange: (e) => _(e.target.value)
			})]
		}),
		/* @__PURE__ */ k(ye, {
			label: "About",
			value: v,
			options: sv,
			labels: {
				10: "10 s",
				20: "20 s",
				30: "30 s"
			},
			onChange: y
		}),
		/* @__PURE__ */ k("button", {
			type: "button",
			className: "gs-m3d__btn",
			disabled: !a || !f || !!C,
			onClick: () => void le(),
			children: "Write it for me"
		}),
		/* @__PURE__ */ k(ye, {
			label: "Shape",
			value: b,
			options: ["tall", "wide"],
			labels: {
				tall: "Tall (phones)",
				wide: "Wide"
			},
			onChange: ee
		}),
		/* @__PURE__ */ A("label", {
			className: "gs-m3d__check",
			children: [/* @__PURE__ */ k("input", {
				type: "checkbox",
				checked: x,
				onChange: (e) => S(e.target.checked)
			}), " Mark the voice as AI in the corner"]
		}),
		/* @__PURE__ */ A("div", {
			className: "gs-m3d__row",
			children: [/* @__PURE__ */ k("button", {
				type: "button",
				className: "gs-m3d__btn gs-m3d__btn--primary",
				disabled: !a || !g.trim() || !!C,
				onClick: () => void ue(),
				children: "Make the video"
			}), C && ae.current && /* @__PURE__ */ k("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => ae.current?.abort(),
				children: "Stop"
			})]
		}),
		C && /* @__PURE__ */ A("p", {
			className: "gs-m3d__note",
			role: "status",
			children: [C, te !== null && ` ${Math.round(te * 100)}%`]
		}),
		T && /* @__PURE__ */ A("div", {
			className: "gs-av__made",
			children: [/* @__PURE__ */ k("video", {
				src: T.url,
				controls: !0,
				playsInline: !0
			}), /* @__PURE__ */ A("button", {
				type: "button",
				className: "gs-m3d__btn gs-m3d__btn--primary",
				onClick: () => {
					if (!T) return;
					let e = document.createElement("a");
					e.href = T.url, e.download = `${(f?.name ?? "product video").replace(/[^\p{L}\p{N} _-]+/gu, "").trim() || "product video"}.${T.extension}`, e.click();
				},
				children: [
					"Save the video (",
					Math.round(T.seconds),
					" s, ",
					T.extension.toUpperCase(),
					")"
				]
			})]
		}),
		re && /* @__PURE__ */ k("p", {
			className: "gs-m3d__note",
			children: re
		}),
		/* @__PURE__ */ k(t, { id: "avVideo" })
	] });
}
//#endregion
//#region src/avatar/CallsGuide.tsx
var lv = typeof navigator < "u" && /Mac|iPhone|iPad/.test(navigator.userAgent);
function uv({ onCopyLink: e }) {
	let n = lv ? {
		name: "BlackHole 2ch",
		url: "https://existential.audio/blackhole/",
		monitor: "BlackHole 2ch",
		mic: "BlackHole 2ch"
	} : {
		name: "VB-Cable",
		url: "https://vb-audio.com/Cable/",
		monitor: "CABLE Input",
		mic: "CABLE Output"
	};
	return /* @__PURE__ */ A("details", {
		className: "gs-av__calls",
		children: [
			/* @__PURE__ */ k("summary", { children: "Use it in Google Meet, Zoom or Teams" }),
			/* @__PURE__ */ k("p", {
				className: "gs-m3d__note",
				children: "The call sees the avatar as your camera. Free, once set up (about 5 minutes)."
			}),
			/* @__PURE__ */ k("p", {
				className: "gs-m3d__note",
				children: "Keep Avatar mode in its own window during the call: in a hidden tab, Chrome stops it moving the avatar."
			}),
			/* @__PURE__ */ k("h5", { children: "The avatar as your camera" }),
			/* @__PURE__ */ A("ol", { children: [
				/* @__PURE__ */ A("li", { children: [
					"Install",
					" ",
					/* @__PURE__ */ k("a", {
						href: "https://obsproject.com/",
						target: "_blank",
						rel: "noreferrer",
						children: "OBS Studio"
					}),
					" ",
					"(free)."
				] }),
				/* @__PURE__ */ A("li", { children: [
					"Tick ",
					/* @__PURE__ */ k("b", { children: "Stream to OBS" }),
					" above, then",
					" ",
					/* @__PURE__ */ k("button", {
						type: "button",
						className: "gs-av__inline",
						onClick: e,
						children: "copy the OBS link"
					}),
					"."
				] }),
				/* @__PURE__ */ A("li", { children: [
					"In OBS, under ",
					/* @__PURE__ */ k("b", { children: "Sources" }),
					": ",
					/* @__PURE__ */ k("b", { children: "+" }),
					", ",
					/* @__PURE__ */ k("b", { children: "Color Source" }),
					" (the background the call shows behind the avatar). Then ",
					/* @__PURE__ */ k("b", { children: "+" }),
					",",
					" ",
					/* @__PURE__ */ k("b", { children: "Browser" }),
					": paste the link, width ",
					/* @__PURE__ */ k("b", { children: "1280" }),
					", height ",
					/* @__PURE__ */ k("b", { children: "720" }),
					", tick ",
					/* @__PURE__ */ k("b", { children: "Control audio via OBS" }),
					"."
				] }),
				/* @__PURE__ */ A("li", { children: [
					"Click ",
					/* @__PURE__ */ k("b", { children: "Start Virtual Camera" }),
					" (bottom right of OBS)."
				] }),
				/* @__PURE__ */ A("li", { children: [
					"In the call's settings, choose the camera ",
					/* @__PURE__ */ k("b", { children: "OBS Virtual Camera" }),
					". (In Meet: the three dots, ",
					/* @__PURE__ */ k("b", { children: "Settings" }),
					", ",
					/* @__PURE__ */ k("b", { children: "Video" }),
					".)"
				] })
			] }),
			/* @__PURE__ */ k("h5", { children: "Its voice as your mic (Clear or Live voice only)" }),
			/* @__PURE__ */ k("p", {
				className: "gs-m3d__note",
				children: "With My own voice, keep your usual mic in the call: the avatar's mouth still follows it."
			}),
			/* @__PURE__ */ A("ol", { children: [
				/* @__PURE__ */ A("li", { children: [
					"Install",
					" ",
					/* @__PURE__ */ k("a", {
						href: n.url,
						target: "_blank",
						rel: "noreferrer",
						children: n.name
					}),
					" ",
					"(free), a cable inside the computer that carries sound from one app to another."
				] }),
				/* @__PURE__ */ A("li", { children: [
					"In OBS: ",
					/* @__PURE__ */ k("b", { children: "Settings" }),
					", ",
					/* @__PURE__ */ k("b", { children: "Audio" }),
					", ",
					/* @__PURE__ */ k("b", { children: "Advanced" }),
					", ",
					/* @__PURE__ */ k("b", { children: "Monitoring Device" }),
					": ",
					/* @__PURE__ */ k("b", { children: n.monitor }),
					"."
				] }),
				/* @__PURE__ */ A("li", { children: [
					"Right-click the Browser source, ",
					/* @__PURE__ */ k("b", { children: "Advanced Audio Properties" }),
					", ",
					/* @__PURE__ */ k("b", { children: "Audio Monitoring" }),
					": ",
					/* @__PURE__ */ k("b", { children: "Monitor Only" }),
					"."
				] }),
				/* @__PURE__ */ A("li", { children: [
					"In the call's settings, choose the microphone ",
					/* @__PURE__ */ k("b", { children: n.mic }),
					"."
				] }),
				/* @__PURE__ */ k("li", { children: "Leave “Hear the voice here too” off and wear headphones, so the call does not hear itself." })
			] }),
			/* @__PURE__ */ k("h5", { children: "Without OBS, in Chrome" }),
			/* @__PURE__ */ A("p", {
				className: "gs-m3d__note",
				children: [
					"The Gleamshelf Avatar Camera extension adds the camera ",
					/* @__PURE__ */ k("b", { children: "Gleamshelf avatar" }),
					" and the mic ",
					/* @__PURE__ */ k("b", { children: "Gleamshelf avatar voice" }),
					" to Meet, Teams and Zoom on the web: paste the same OBS link into it. It is not in the Chrome Web Store yet."
				]
			}),
			/* @__PURE__ */ k(t, { id: "avCalls" })
		]
	});
}
//#endregion
//#region src/avatar/stage-link.ts
var dv = 30, fv = 262144, pv = class {
	url;
	token;
	ws = null;
	stopped = !1;
	retry = 500;
	lastPose = 0;
	look = null;
	onViewers = null;
	onOpen = null;
	onRefused = null;
	constructor(e, t) {
		this.url = e, this.token = t, this.connect();
	}
	connect() {
		if (this.stopped) return;
		let e = new WebSocket(this.url);
		this.ws = e, e.onopen = () => {
			e.send(JSON.stringify({
				role: "publish",
				token: this.token
			})), this.retry = 500, this.onOpen?.(!0), this.look && e.send(JSON.stringify({
				t: "look",
				...this.look
			}));
		}, e.onmessage = (e) => {
			try {
				let t = JSON.parse(String(e.data));
				t.t === "viewers" && this.onViewers?.(t.count ?? 0);
			} catch {}
		}, e.onclose = (e) => {
			if (this.ws = null, this.onOpen?.(!1), this.onViewers?.(0), e.code === 4003) return this.onRefused?.(e.reason || "The app did not accept the pairing token.");
			this.stopped || setTimeout(() => this.connect(), this.retry = Math.min(this.retry * 2, 5e3));
		};
	}
	get open() {
		return this.ws?.readyState === WebSocket.OPEN;
	}
	pose(e, t = performance.now()) {
		!this.open || t - this.lastPose < dv || this.ws.bufferedAmount > fv || (this.lastPose = t, this.ws.send(JSON.stringify({
			t: "pose",
			p: e
		})));
	}
	setLook(e) {
		this.look = e, this.open && this.ws.send(JSON.stringify({
			t: "look",
			...e
		}));
	}
	async voice(e, t) {
		if (!this.open) return;
		let n = new Uint8Array(await t.arrayBuffer()), r = new Uint8Array(n.length + 1);
		r[0] = e, r.set(n, 1), this.open && this.ws.send(r);
	}
	stop() {
		this.stopped = !0, this.ws?.close(), this.ws = null;
	}
}, mv = [
	{
		name: "neutral",
		label: "Neutral",
		key: "Q"
	},
	{
		name: "happy",
		label: "Happy",
		key: "W"
	},
	{
		name: "surprised",
		label: "Surprised",
		key: "E"
	},
	{
		name: "sad",
		label: "Sad",
		key: "R"
	},
	{
		name: "angry",
		label: "Angry",
		key: "T"
	},
	{
		name: "relaxed",
		label: "Relaxed",
		key: "Y"
	}
], hv = [
	"clear",
	"green",
	"colour",
	"scene"
], gv = {
	clear: "See-through",
	green: "Green screen",
	colour: "Colour",
	scene: "Last scene"
}, _v = "#00b140";
function vv({ onClose: n, title: i = "Live avatar" }) {
	let a = Me(null), o = Me(null), s = Me(null), c = Me(new jt()), l = Me(null), u = Me(null), d = Me(null), f = Me(null), p = Me(null), [m, h] = O(null), [g, _] = O({}), [v, y] = O("Loading the avatar…"), [b, ee] = O(null), [x, S] = O(!1), [C, w] = O(!1), [te, ne] = O({
		face: !0,
		body: !0,
		hands: !0
	}), [T, E] = O(!0), [re, ie] = O("neutral"), [D, ae] = O("bust"), [oe, se] = O("clear"), [ce, le] = O("#1b1530"), [ue, de] = O(!1), [fe, pe] = O(!0), [me, he] = O(null), ge = Me(null);
	Ae(() => {
		let e = null;
		try {
			e = new k_();
		} catch {}
		return ge.current = e, he(e), e && d.current && e.attach(d.current.stream), () => {
			e?.close(), ge.current = null;
		};
	}, []);
	let [_e, ve] = O("own"), be = Me("own");
	be.current = _e;
	let xe = _e === "clear", [Se, Ce] = O(N_), we = Oe(), Te = r(), [Ee, De] = O(!1), [ke, je] = O(0), [Pe, Fe] = O(!1), [Ie, Le] = O(null), Re = Me(null);
	Ae(() => {
		if (!a.current) return;
		let e;
		try {
			e = new La(a.current);
		} catch (e) {
			ee(e instanceof Error ? `The avatar could not be drawn here: ${e.message}` : "The avatar could not be drawn here."), y(null);
			return;
		}
		return s.current = e, e.drive((e) => {
			let t = d.current, n = ge.current?.lips() ?? null;
			if (n) c.current.speak(n);
			else if (t && be.current === "own") {
				let e = new Uint8Array(t.analyser.frequencyBinCount);
				t.analyser.getByteFrequencyData(e), c.current.speak(Dt(e, t.context.sampleRate, t.analyser.fftSize));
			} else c.current.speak(null);
			let r = c.current.compose(e);
			return Re.current?.pose(r, e), r;
		}), (async () => {
			try {
				let t = await b_(), n = await e.load(t ?? new URL("./assets/default.vrm", import.meta.url).href);
				ze(n, e);
			} catch (e) {
				ee(e instanceof Error ? e.message : "The avatar could not be loaded.");
			} finally {
				y(null);
			}
		})(), () => {
			e.dispose(), s.current = null;
		};
	}, []);
	let ze = (e, t) => {
		let n = C_(e.name);
		for (let [e, r] of Object.entries(n)) t.recolour(e, r);
		h(e), _(Object.fromEntries(e.parts.map((e) => [e.id, n[e.id] ?? e.colour])));
	};
	Ae(() => s.current?.setFraming(D), [D]);
	let Be = Te.state === "ready";
	Ae(() => {
		if (!Ee || !Be) return;
		let e = new pv(Te.client.stageSocket, Te.client.pairingToken);
		return e.onViewers = je, e.onRefused = (e) => Le(e), Re.current = e, me && (me.onVoice = (t, n) => void e.voice(t === "clip" ? 1 : 2, n)), () => {
			e.stop(), Re.current = null, me && (me.onVoice = null), je(0);
		};
	}, [
		Ee,
		Be,
		Te.client,
		me
	]), Ae(() => {
		me && (me.audible = !Ee || Pe);
	}, [
		me,
		Ee,
		Pe
	]), Ae(() => {
		Ee && Re.current?.setLook({
			framing: D,
			colours: g
		});
	}, [
		Ee,
		D,
		g,
		Be
	]), Ae(() => {
		if (!Ee || !Be || !m) return;
		let e = !1;
		return (async () => {
			try {
				let t = await b_() ?? await (await fetch(new URL("./assets/default.vrm", import.meta.url).href)).arrayBuffer();
				e || await Te.client.setStageAvatar(new Blob([t], { type: "model/gltf-binary" }));
			} catch (t) {
				e || Le(t instanceof Error ? t.message : "The stage did not get the avatar.");
			}
		})(), () => {
			e = !0;
		};
	}, [
		Ee,
		Be,
		m,
		Te.client
	]);
	let Ve = async (e = !1) => {
		Le(null);
		try {
			let t = e ? await Te.client.newStageLink() : (await Te.client.stageLink())?.url;
			if (!t) return Le("This Gleamshelf app has no stage yet: update it (git pull), then restart it.");
			await navigator.clipboard.writeText(t), Le(`${e ? "A new link is" : "The link is"} copied. In OBS: Sources, +, Browser; paste it as the URL; width 1080, height 1920 (or 1920 by 1080); tick Control audio via OBS.`);
		} catch (e) {
			Le(e instanceof Error ? e.message : "The link could not be copied.");
		}
	};
	Ae(() => {
		let e = oe === "green" ? {
			kind: "colour",
			colour: _v
		} : oe === "colour" ? {
			kind: "colour",
			colour: ce
		} : oe === "scene" && we ? {
			kind: "picture",
			url: we
		} : { kind: "clear" };
		s.current?.setBackdrop(e);
	}, [
		oe,
		ce,
		we
	]), Ae(() => {
		c.current.mirror = T;
	}, [T]), Ae(() => {
		c.current.hold("happy", 0);
		for (let e of mv) e.name !== "neutral" && c.current.hold(e.name, 0);
		re !== "neutral" && c.current.hold(re, 1);
	}, [re]), Ae(() => () => {
		l.current?.dispose(), u.current?.getTracks().forEach((e) => e.stop()), d.current?.stream.getTracks().forEach((e) => e.stop()), d.current?.context.close(), f.current?.close();
	}, []);
	let He = async (e, t) => {
		y(e), ee(null);
		try {
			await t();
		} catch (e) {
			ee(e instanceof Error ? e.message : "That did not work.");
		} finally {
			y(null);
		}
	}, Ue = () => He("Starting the camera…", async () => {
		if (!navigator.mediaDevices?.getUserMedia) throw Error("This browser cannot use a camera here.");
		let e = await navigator.mediaDevices.getUserMedia({ video: {
			width: 640,
			height: 480,
			facingMode: "user"
		} }).catch(() => {
			throw Error("The camera was not allowed: allow it for this page in the browser, then try again.");
		});
		u.current = e;
		let t = o.current;
		t.srcObject = e, await t.play(), l.current?.dispose(), l.current = await i_.create(te, (e) => e && y(e)), l.current.start(t, (e, t) => c.current.track(e, t)), S(!0);
	}), We = () => {
		l.current?.dispose(), l.current = null, u.current?.getTracks().forEach((e) => e.stop()), u.current = null, c.current.untrack(), S(!1);
	}, Ge = () => He("Starting the mic…", async () => {
		let e = await navigator.mediaDevices.getUserMedia({ audio: {
			echoCancellation: !0,
			noiseSuppression: !0
		} }).catch(() => {
			throw Error("The mic was not allowed: allow it for this page in the browser, then try again.");
		}), t = new AudioContext(), n = t.createAnalyser();
		n.fftSize = 2048, n.smoothingTimeConstant = .5, t.createMediaStreamSource(e).connect(n), d.current = {
			stream: e,
			context: t,
			analyser: n
		}, ge.current?.attach(e), w(!0);
	}), Ke = () => {
		d.current?.stream.getTracks().forEach((e) => e.stop()), d.current?.context.close(), d.current = null, ge.current?.attach(null), c.current.speak(null), w(!1);
	}, qe = (e) => He("Reading the avatar…", async () => {
		let t = await e.arrayBuffer(), n = await s.current.load(t);
		await x_(t), ze(n, s.current), n.allowsCommercial || ee(`${n.name}'s own licence does not allow commercial use: use it for yourself, not for the shop's streams or ads.`);
	}), Je = () => He("Loading the avatar…", async () => {
		await x_(null), ze(await s.current.load(g_), s.current);
	}), Ye = (e, t) => {
		s.current?.recolour(e, t);
		let n = {
			...g,
			[e]: t
		};
		_(n), m && w_(m.name, n);
	}, Xe = () => He("Loading the avatar…", async () => {
		m && w_(m.name, {});
		let e = await b_();
		ze(await s.current.load(e ?? new URL("./assets/default.vrm", import.meta.url).href), s.current);
	}), Ze = () => {
		if (f.current && !f.current.closed) return f.current.focus();
		let e = window.open("", "gleamshelf-avatar", "width=720,height=960");
		if (!e) return ee("The browser blocked the window: allow pop-ups for this page.");
		e.document.title = "Gleamshelf avatar", e.document.body.style.cssText = "margin:0;overflow:hidden;background:transparent";
		let t = e.document.createElement("div");
		t.style.cssText = "position:fixed;inset:0", e.document.body.appendChild(t), s.current?.attach(t), f.current = e, de(!0), e.addEventListener("pagehide", () => {
			s.current?.attach(a.current), f.current = null, de(!1);
		});
	}, Qe = (e) => c.current.play(e, performance.now()), $e = (e) => {
		let t = e.target;
		return t.tagName === "INPUT" || t.tagName === "SELECT" || t.tagName === "TEXTAREA" || e.metaKey || e.ctrlKey;
	}, et = (e) => xe && Se.talk === "hold" && e.code === "Space" && !$e(e);
	return /* @__PURE__ */ A("div", {
		className: "gs-m3d gs-av",
		tabIndex: -1,
		onKeyDown: (e) => {
			if (et(e)) {
				e.preventDefault(), e.repeat || me?.hold(!0);
				return;
			}
			if ($e(e)) return;
			let t = gt.find((t) => ht[t].key === e.key);
			if (t) return Qe(t);
			let n = mv.find((t) => t.key.toLowerCase() === e.key.toLowerCase());
			n && ie(n.name);
		},
		onKeyUp: (e) => {
			et(e) && (e.preventDefault(), me?.hold(!1));
		},
		children: [/* @__PURE__ */ A("header", {
			className: "gs-m3d__top",
			children: [
				/* @__PURE__ */ k("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: n,
					children: "← Back"
				}),
				/* @__PURE__ */ k("strong", {
					className: "gs-m3d__title",
					children: i
				}),
				/* @__PURE__ */ k("button", {
					type: "button",
					className: `gs-m3d__btn ${x ? "is-on" : ""}`,
					onClick: () => x ? We() : void Ue(),
					disabled: !!v,
					children: x ? "Camera on" : "Camera off"
				}),
				/* @__PURE__ */ k("button", {
					type: "button",
					className: `gs-m3d__btn ${C ? "is-on" : ""}`,
					onClick: () => C ? Ke() : void Ge(),
					disabled: !!v,
					children: C ? "Mic on" : "Mic off"
				}),
				/* @__PURE__ */ k("span", { className: "gs-m3d__spacer" }),
				/* @__PURE__ */ k("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: Ze,
					title: "Its own window, for OBS or other streaming software to capture",
					children: ue ? "In its own window" : "Pop out for streaming"
				}),
				/* @__PURE__ */ k("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => void s.current?.snapshot().then((e) => {
						let t = document.createElement("a");
						t.href = URL.createObjectURL(e), t.download = `${m?.name ?? "avatar"}.png`, t.click(), setTimeout(() => URL.revokeObjectURL(t.href), 1e3);
					}),
					children: "Save picture"
				})
			]
		}), /* @__PURE__ */ A("div", {
			className: "gs-m3d__body",
			children: [
				/* @__PURE__ */ k("aside", {
					className: "gs-m3d__left",
					"aria-label": "Avatar",
					children: /* @__PURE__ */ A("div", {
						className: "gs-m3d__panel",
						children: [
							/* @__PURE__ */ A("section", { children: [
								/* @__PURE__ */ k("h4", { children: "Avatar" }),
								/* @__PURE__ */ A("p", {
									className: "gs-m3d__meta",
									children: [m ? m.name : "…", m?.authors.length ? ` · ${m.authors.join(", ")}` : ""]
								}),
								m && /* @__PURE__ */ A("p", {
									className: `gs-av__licence ${m.allowsCommercial ? "is-ok" : "is-no"}`,
									children: [m.allowsCommercial ? "Its licence allows commercial use" : "Its licence does not allow commercial use", m.licenceUrl && /* @__PURE__ */ A(Ne, { children: [" · ", /* @__PURE__ */ k("a", {
										href: m.licenceUrl,
										target: "_blank",
										rel: "noreferrer",
										children: "licence"
									})] })]
								}),
								/* @__PURE__ */ A("div", {
									className: "gs-m3d__row",
									children: [/* @__PURE__ */ k("button", {
										type: "button",
										className: "gs-m3d__btn",
										onClick: () => p.current?.click(),
										disabled: !!v,
										children: "Import a VRM…"
									}), /* @__PURE__ */ k("button", {
										type: "button",
										className: "gs-m3d__btn",
										onClick: () => void Je(),
										disabled: !!v,
										children: "Starting avatar"
									})]
								}),
								/* @__PURE__ */ k("input", {
									ref: p,
									type: "file",
									accept: ".vrm",
									hidden: !0,
									onChange: (e) => {
										let t = e.target.files?.[0];
										e.target.value = "", t && qe(t);
									}
								}),
								/* @__PURE__ */ k(t, { id: "avAvatar" })
							] }),
							m && m.parts.length > 0 && /* @__PURE__ */ A("section", { children: [
								/* @__PURE__ */ k("h4", { children: "Colours" }),
								m.parts.map((e) => /* @__PURE__ */ A("label", {
									className: "gs-m3d__colour gs-av__part",
									children: [
										/* @__PURE__ */ k("input", {
											type: "color",
											value: g[e.id] ?? e.colour,
											onChange: (t) => Ye(e.id, t.target.value)
										}),
										" ",
										e.label
									]
								}, e.id)),
								/* @__PURE__ */ k("div", {
									className: "gs-m3d__row",
									children: /* @__PURE__ */ k("button", {
										type: "button",
										className: "gs-m3d__btn",
										onClick: () => void Xe(),
										disabled: !!v,
										children: "Its own colours"
									})
								}),
								/* @__PURE__ */ k(t, { id: "avColours" })
							] }),
							/* @__PURE__ */ k(B_, {
								desk: me,
								mode: _e,
								onMode: ve,
								micOn: C,
								startMic: () => void Ge(),
								settings: Se,
								onSettings: Ce
							}),
							/* @__PURE__ */ k(ov, {
								desk: me,
								voice: Se,
								onGesture: Qe,
								colours: g
							})
						]
					})
				}),
				/* @__PURE__ */ A("main", {
					className: "gs-m3d__stage gs-av__stage",
					children: [
						/* @__PURE__ */ k("div", {
							className: "gs-m3d__viewport",
							ref: a
						}),
						ue && /* @__PURE__ */ k("p", {
							className: "gs-av__away",
							children: "The avatar is in its own window. Close that window to bring it back here."
						}),
						/* @__PURE__ */ k("video", {
							ref: o,
							className: `gs-av__camera ${x && fe ? "" : "is-hidden"}`,
							muted: !0,
							playsInline: !0
						}),
						v && /* @__PURE__ */ A("div", {
							className: "gs-m3d__busy",
							role: "status",
							children: [
								/* @__PURE__ */ k("span", {
									className: "gs-m3d__spin",
									"aria-hidden": "true"
								}),
								" ",
								v
							]
						}),
						b && /* @__PURE__ */ A("div", {
							className: "gs-m3d__problem",
							role: "alert",
							children: [b, /* @__PURE__ */ k("button", {
								type: "button",
								onClick: () => ee(null),
								children: "Dismiss"
							})]
						})
					]
				}),
				/* @__PURE__ */ A("aside", {
					className: "gs-m3d__right",
					"aria-label": "Moves",
					children: [/* @__PURE__ */ A("div", {
						className: "gs-m3d__panel",
						children: [
							/* @__PURE__ */ A("section", { children: [
								/* @__PURE__ */ k("h4", { children: "Mood" }),
								/* @__PURE__ */ k("div", {
									className: "gs-av__grid",
									children: mv.map((e) => /* @__PURE__ */ A("button", {
										type: "button",
										className: `gs-m3d__btn ${re === e.name ? "is-on" : ""}`,
										onClick: () => ie(e.name),
										children: [
											e.label,
											" ",
											/* @__PURE__ */ k("kbd", { children: e.key })
										]
									}, e.name))
								}),
								/* @__PURE__ */ k(t, { id: "avMood" })
							] }),
							/* @__PURE__ */ A("section", { children: [
								/* @__PURE__ */ k("h4", { children: "Gestures" }),
								/* @__PURE__ */ k("div", {
									className: "gs-av__grid",
									children: gt.map((e) => /* @__PURE__ */ A("button", {
										type: "button",
										className: "gs-m3d__btn",
										onClick: () => Qe(e),
										children: [
											ht[e].label,
											" ",
											/* @__PURE__ */ k("kbd", { children: ht[e].key })
										]
									}, e))
								}),
								/* @__PURE__ */ k(t, { id: "avGestures" })
							] }),
							/* @__PURE__ */ A("section", { children: [
								/* @__PURE__ */ k("h4", { children: "Tracking" }),
								[
									"face",
									"body",
									"hands"
								].map((e) => /* @__PURE__ */ A("label", {
									className: "gs-m3d__check",
									children: [
										/* @__PURE__ */ k("input", {
											type: "checkbox",
											checked: te[e],
											disabled: x,
											onChange: (t) => ne({
												...te,
												[e]: t.target.checked
											})
										}),
										" ",
										e === "face" ? "Face and head" : e === "body" ? "Upper body" : "Hands and fingers"
									]
								}, e)),
								/* @__PURE__ */ A("label", {
									className: "gs-m3d__check",
									children: [/* @__PURE__ */ k("input", {
										type: "checkbox",
										checked: T,
										onChange: (e) => E(e.target.checked)
									}), " Move like a mirror"]
								}),
								/* @__PURE__ */ A("label", {
									className: "gs-m3d__check",
									children: [/* @__PURE__ */ k("input", {
										type: "checkbox",
										checked: fe,
										onChange: (e) => pe(e.target.checked)
									}), " Show my camera"]
								}),
								/* @__PURE__ */ k(t, { id: "avCamera" }),
								/* @__PURE__ */ k(t, { id: "avMic" })
							] }),
							/* @__PURE__ */ A("section", { children: [
								/* @__PURE__ */ k("h4", { children: "Shot" }),
								/* @__PURE__ */ k(ye, {
									label: "Framing",
									value: D,
									options: [
										"face",
										"bust",
										"body"
									],
									labels: {
										face: "Face",
										bust: "Upper body",
										body: "Whole"
									},
									onChange: ae
								}),
								/* @__PURE__ */ k(ye, {
									label: "Backdrop",
									value: oe,
									options: we ? hv : hv.filter((e) => e !== "scene"),
									labels: gv,
									onChange: se
								}),
								oe === "colour" && /* @__PURE__ */ A("label", {
									className: "gs-m3d__colour",
									children: [/* @__PURE__ */ k("input", {
										type: "color",
										value: ce,
										onChange: (e) => le(e.target.value)
									}), " Backdrop colour"]
								}),
								/* @__PURE__ */ k(t, { id: "avBackdrop" }),
								/* @__PURE__ */ k(t, { id: "avPopout" })
							] }),
							/* @__PURE__ */ A("section", { children: [
								/* @__PURE__ */ k("h4", { children: "Stream to OBS" }),
								/* @__PURE__ */ A("label", {
									className: "gs-m3d__check",
									children: [
										/* @__PURE__ */ k("input", {
											type: "checkbox",
											checked: Ee,
											disabled: !Be,
											onChange: (e) => {
												me?.wake(), De(e.target.checked);
											}
										}),
										" ",
										"Stream to OBS"
									]
								}),
								/* @__PURE__ */ k("p", {
									className: "gs-m3d__note",
									children: Be ? Ee ? ke > 0 ? `Live in OBS (${ke === 1 ? "one scene" : `${ke} scenes`} watching). The avatar's voice plays there.` : "On. Copy the OBS link and add it to OBS as a Browser source." : "OBS shows the avatar see-through, with its voice; no green screen." : "Needs the Gleamshelf app running on this computer (free)."
								}),
								/* @__PURE__ */ A("div", {
									className: "gs-m3d__row",
									children: [/* @__PURE__ */ k("button", {
										type: "button",
										className: "gs-m3d__btn",
										disabled: !Be,
										onClick: () => void Ve(),
										children: "Copy the OBS link"
									}), /* @__PURE__ */ k("button", {
										type: "button",
										className: "gs-m3d__btn",
										disabled: !Be,
										title: "Makes the old link stop working (if it was shared by mistake)",
										onClick: () => void Ve(!0),
										children: "New link"
									})]
								}),
								Ee && /* @__PURE__ */ A("label", {
									className: "gs-m3d__check",
									children: [/* @__PURE__ */ k("input", {
										type: "checkbox",
										checked: Pe,
										onChange: (e) => Fe(e.target.checked)
									}), " Hear the voice here too"]
								}),
								Ie && /* @__PURE__ */ k("p", {
									className: "gs-m3d__note",
									children: Ie
								}),
								/* @__PURE__ */ k(t, { id: "avStage" }),
								/* @__PURE__ */ k(uv, { onCopyLink: () => void Ve() })
							] }),
							/* @__PURE__ */ k(cv, {
								voice: Se,
								colours: g
							})
						]
					}), /* @__PURE__ */ k("footer", {
						className: "gs-m3d__foot",
						children: /* @__PURE__ */ k(e, {})
					})]
				})
			]
		})]
	});
}
//#endregion
export { vv as AvatarMode };

//# sourceMappingURL=AvatarMode-D7CZA7R0.js.map