import type { PixelData } from './document.js';
import type { Clip } from './paint.js';
export declare const invertColours: (src: PixelData, clip?: Clip) => PixelData;
export declare const greyscale: (src: PixelData, clip?: Clip) => PixelData;
/** Brightness and contrast, each -100 to 100. */
export declare function brightnessContrast(src: PixelData, brightness: number, contrast: number, clip?: Clip): PixelData;
/** Hue (degrees, -180 to 180), saturation and lightness (-100 to 100). */
export declare function hueSaturation(src: PixelData, hue: number, saturation: number, lightness: number, clip?: Clip): PixelData;
/**
 * Levels: the input range `inBlack`-`inWhite` (0-255) is stretched to `outBlack`-`outWhite`, with `gamma` bending the midtones (above 1 lighter,
 * below 1 darker), as in a photo editor's Levels.
 */
export declare function levels(src: PixelData, inBlack: number, inWhite: number, gamma: number, outBlack: number, outWhite: number, clip?: Clip): PixelData;
/**
 * Curves through five points: black and white stay put, and the shadows (a quarter), midtones (half) and highlights (three quarters) are lifted or
 * lowered by -100 to 100. A smooth curve that never turns back (monotone cubic), so tones keep their order.
 */
export declare function curves(src: PixelData, shadows: number, midtones: number, highlights: number, clip?: Clip): PixelData;
/** Vibrance (-100 to 100): more colour where there is little, less change where there is already a lot; skin and greys move least. */
export declare function vibrance(src: PixelData, amount: number, clip?: Clip): PixelData;
/** Colour balance: warmer or cooler (-100 to 100, blue to amber) and a tint (-100 to 100, green to magenta), lightness kept. */
export declare function colourBalance(src: PixelData, warmth: number, tint: number, clip?: Clip): PixelData;
/** Posterize: each channel in `steps` levels (2-32). */
export declare function posterize(src: PixelData, steps: number, clip?: Clip): PixelData;
/** Threshold: black below `level` (0-255), white from it up, by lightness. */
export declare function threshold(src: PixelData, level: number, clip?: Clip): PixelData;
/** Gaussian-like blur of `radius` pixels (three box blurs), alpha included, weighted so transparent pixels do not darken the edges. */
export declare function blur(src: PixelData, radius: number, clip?: Clip): PixelData;
/** Unsharp mask: the picture plus `amount` (0-3) times its difference from a blur of `radius`. */
export declare function sharpen(src: PixelData, amount: number, radius?: number, clip?: Clip): PixelData;
export declare function rgbToHsl(r: number, g: number, b: number): [number, number, number];
export declare function hslToRgb(h: number, s: number, l: number): [number, number, number];
