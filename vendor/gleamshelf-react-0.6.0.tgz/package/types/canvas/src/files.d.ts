import { type CanvasDocument, PixelStore, type PixelData } from './document.js';
/**
 * The document as SVG, for vector tools and the web: shapes and text stay editable vectors, raster layers are embedded pictures, masks become SVG
 * masks, blend modes become `mix-blend-mode`, layer styles become SVG filters. `encode` turns a PixelStore id into a data URL (PNG).
 */
export declare function toSvg(doc: CanvasDocument, encode: (id: string) => string): string;
/** A saved project: the document and every picture it uses, as one JSON file (`.gleam`). */
export interface ProjectFile {
    format: 'gleamshelf-canvas';
    version: 1;
    doc: CanvasDocument;
    /** PixelStore id -> PNG data URL. */
    pixels: Record<string, string>;
}
export declare function toProject(doc: CanvasDocument, encode: (id: string) => string): ProjectFile;
/** Reads a project back; `decode` turns each data URL into pixels. Throws a plain message for anything that is not a project. */
export declare function fromProject(input: unknown, decode: (dataUrl: string) => Promise<PixelData>): Promise<{
    doc: CanvasDocument;
    store: PixelStore;
}>;
