import type { CanvasDocument, Layer, PathData, PixelStore, Transform } from './document.js';
/** A 2D affine matrix as Canvas 2D takes it: x' = a*x + c*y + e, y' = b*x + d*y + f. */
export interface Matrix {
    a: number;
    b: number;
    c: number;
    d: number;
    e: number;
    f: number;
}
export interface Point {
    x: number;
    y: number;
}
export interface Rect {
    x: number;
    y: number;
    width: number;
    height: number;
}
/** Layer coordinates to document coordinates: scale, then rotate, then move. */
export declare function layerMatrix(t: Transform): Matrix;
export declare function invert(m: Matrix): Matrix;
export declare const apply: (m: Matrix, p: Point) => Point;
/** A document point in the layer's own coordinates. */
export declare const toLayer: (layer: Layer, p: Point) => Point;
/** The layer's own box (before its transform). */
export declare function localBounds(layer: Layer, store?: PixelStore): Rect;
/** The four corners of the layer's box in document coordinates (top-left, top-right, bottom-right, bottom-left). */
export declare function corners(layer: Layer, store?: PixelStore): Point[];
/** The upright box round the layer in document coordinates. */
export declare function documentBounds(layer: Layer, store?: PixelStore): Rect;
/**
 * The topmost visible, unlocked layer under a document point. A raster layer counts only where its pixels are not transparent, so clicking the
 * empty part of a cut-out picks what is underneath.
 */
export declare function layerAt(doc: CanvasDocument, store: PixelStore, p: Point): Layer | undefined;
export declare function pathBounds(path: PathData): Rect;
/** The path as SVG path data (also what Path2D takes). Points with handles become cubic curves. */
export declare function pathD(path: PathData): string;
/** The SVG path data of any shape, in the layer's own coordinates. */
export declare function shapeD(shape: Extract<Layer, {
    kind: 'shape';
}>['shape']): string;
/** Snaps an angle to the nearest multiple of 15 degrees (Shift while rotating or drawing a line). */
export declare const snapAngle: (radians: number, step?: number) => number;
