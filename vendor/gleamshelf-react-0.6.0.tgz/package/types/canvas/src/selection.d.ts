import type { PixelData } from './document.js';
import type { Point, Rect } from './geometry.js';
/**
 * A selection: how much each document pixel is selected, 0-255. A bitmap rather than shapes, so every way of selecting (box, oval, lasso, magic
 * wand) combines with every other (add, take away, keep the overlap) and edges can be soft.
 */
export interface Selection {
    width: number;
    height: number;
    mask: Uint8Array;
}
export type Combine = 'replace' | 'add' | 'subtract' | 'intersect';
export declare function selectAll(width: number, height: number): Selection;
/** A box, clipped to the canvas. */
export declare function selectRect(width: number, height: number, r: Rect): Selection;
/** An oval inside the box, with a one-pixel soft edge. */
export declare function selectEllipse(width: number, height: number, r: Rect): Selection;
/** A free-hand or point-by-point outline, closed back to its start (even-odd fill, as an outline drawn across itself would be). */
export declare function selectPolygon(width: number, height: number, points: readonly Point[]): Selection;
/** `next` combined with `current` (which may be none). */
export declare function combine(current: Selection | null, next: Selection, how: Combine): Selection;
export declare function invertSelection(s: Selection): Selection;
/** The box round everything selected, or null when nothing is. */
export declare function selectionBounds(s: Selection): Rect | null;
/** Softens the selection's edge by `radius` pixels (a box blur run three times, which is close to a Gaussian). */
export declare function feather(s: Selection, radius: number): Selection;
/**
 * Magic wand: the pixels whose colour is within `tolerance` (0-255, the largest channel difference) of the clicked one. `contiguous` keeps to
 * the patch connected to the click; otherwise every matching pixel in the picture is selected. `picture` is the canvas as it looks (document size).
 */
export declare function magicWand(picture: PixelData, at: Point, tolerance: number, contiguous?: boolean): Selection;
/** The selection's edge, as the pixels to draw the moving outline on: selected pixels next to an unselected one (or the canvas edge). */
export declare function selectionEdge(s: Selection): Uint8Array;
