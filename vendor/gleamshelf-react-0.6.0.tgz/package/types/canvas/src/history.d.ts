import type { CanvasDocument, PixelStore } from './document.js';
export interface Step {
    doc: CanvasDocument;
    /** What the change was ("Brush", "Move layer"), for the history list. */
    label: string;
}
/**
 * Undo and redo over whole documents. Documents are immutable and share everything that did not change, so keeping many is cheap; raster pixels
 * are kept in the store while any remembered step uses them, and let go once the step falls off the end.
 */
export declare class History {
    private readonly store;
    private readonly limit;
    private past;
    private future;
    private current;
    constructor(doc: CanvasDocument, store: PixelStore, limit?: number);
    get doc(): CanvasDocument;
    get canUndo(): boolean;
    get canRedo(): boolean;
    /** The steps, oldest first, and which one is showing. */
    list(): {
        steps: Step[];
        at: number;
    };
    push(doc: CanvasDocument, label: string): void;
    /** Replaces the showing step without adding one (a slider being dragged, a stroke in progress). */
    replace(doc: CanvasDocument): void;
    undo(): CanvasDocument;
    redo(): CanvasDocument;
    /** Jumps to a step from `list()`. */
    goTo(index: number): CanvasDocument;
}
