import type { CanvasDocument, Layer, TextLayer } from './document.js';
/** The part of Canvas 2D drawing uses (a browser canvas, an OffscreenCanvas, or a stand-in in tests). */
export type Ctx = Pick<CanvasRenderingContext2D, 'save' | 'restore' | 'setTransform' | 'transform' | 'globalAlpha' | 'globalCompositeOperation' | 'fillStyle' | 'strokeStyle' | 'lineWidth' | 'lineJoin' | 'lineCap' | 'font' | 'textAlign' | 'textBaseline' | 'fillRect' | 'clearRect' | 'drawImage' | 'fill' | 'stroke' | 'fillText' | 'measureText' | 'filter'>;
/** What drawing needs from its surroundings: raster pixels as something drawable, scratch surfaces for masks, and Path2D. */
export interface RenderHost {
    /** A drawable for a PixelStore id (the UI keeps a canvas per id). */
    image(id: string): CanvasImageSource | undefined;
    /** A cleared scratch surface of this size. Surfaces with different `slot`s can be in use at the same time (a layer style needs three). */
    surface(width: number, height: number, slot?: number): {
        ctx: Ctx;
        canvas: CanvasImageSource;
    };
    path(d: string): Path2D;
}
export interface RenderOptions {
    /** Draw the canvas colour (default true; false for a transparent export or when the view draws a checkerboard). */
    background?: boolean;
    /** Layers to leave out (one being edited as live text, for example). */
    hide?: ReadonlySet<string>;
}
export declare const fontOf: (l: Pick<TextLayer, "italic" | "weight" | "size" | "font">) => string;
/** The drawn size of a text layer's lines (stored as its `box` whenever the text or its style changes). */
export declare function measureText(ctx: Pick<Ctx, 'font' | 'measureText'>, l: TextLayer): {
    width: number;
    height: number;
};
/** Draws one layer onto `ctx` (whose transform maps document coordinates to the surface), with its opacity, blend mode, mask and style. */
export declare function drawLayer(ctx: Ctx, doc: CanvasDocument, layer: Layer, host: RenderHost): void;
/** Draws the whole document in document coordinates (set the context's transform first to zoom or pan). */
export declare function renderDocument(ctx: Ctx, doc: CanvasDocument, host: RenderHost, options?: RenderOptions): void;
