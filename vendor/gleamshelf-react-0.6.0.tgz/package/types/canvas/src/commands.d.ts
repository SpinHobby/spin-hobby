import { type CanvasDocument, type Layer, type PixelData, type Transform, PixelStore } from './document.js';
import { History } from './history.js';
import { type Clip } from './paint.js';
import { type Ctx, type RenderHost } from './render.js';
import { type Selection } from './selection.js';
/** A drawing surface the backend made: Canvas 2D, and a way to read its pixels back. */
export interface Surface {
    ctx: Ctx;
    canvas: CanvasImageSource;
    read(): PixelData;
}
/** What commands need from the platform: surfaces to draw on, drawables for stored pixels, Path2D, and picture encoding. */
export interface Backend {
    /** A fresh, cleared surface (a new one on every call: drawing may nest). */
    surface(width: number, height: number): Surface;
    /** Something drawable for stored pixels; the backend may cache it by id. */
    image(id: string, pixels: PixelData): CanvasImageSource;
    path(d: string): Path2D;
    encode(pixels: PixelData, type: 'png' | 'jpeg', quality?: number): Promise<Uint8Array>;
    decode(bytes: Uint8Array): Promise<PixelData>;
}
export interface Colours {
    main: string;
    second: string;
}
/** One open design: its document and history, and the state commands share (selection, picked layer, colours, clipboard). */
export declare class DesignSession {
    readonly backend: Backend;
    history: History;
    store: PixelStore;
    selection: Selection | null;
    selectedId: string | null;
    colours: Colours;
    clipboard: {
        pixels: PixelData;
        transform: Transform;
    } | null;
    /** While set, commits land in `preview` instead of the history (a settings dialog showing its result). */
    dry: boolean;
    preview: CanvasDocument | null;
    constructor(backend: Backend, doc: CanvasDocument, store?: PixelStore);
    get doc(): CanvasDocument;
    get selected(): Layer | undefined;
    commit(doc: CanvasDocument, label: string): void;
    /** Starts over with another document (a new canvas, an opened file). */
    replace(doc: CanvasDocument, store?: PixelStore): void;
    /** Drawing through the backend, for rendering this session's document. */
    host(): RenderHost;
    /** The canvas as it looks. */
    flatten(doc?: CanvasDocument, background?: boolean): PixelData;
}
export type ParamType = 'number' | 'integer' | 'string' | 'boolean' | 'color' | 'enum' | 'points' | 'image';
export interface Param {
    name: string;
    type: ParamType;
    label: string;
    description?: string;
    min?: number;
    max?: number;
    step?: number;
    unit?: string;
    options?: readonly string[];
    /** May be left out (and has no default). */
    optional?: boolean;
    /** The value when left out; a function reads it from the session (the main colour, the canvas size). */
    default?: unknown | ((s: DesignSession) => unknown);
    /** Color params only: null (none) is allowed. */
    nullable?: boolean;
}
export type Menu = 'File' | 'Edit' | 'Select' | 'Layer' | 'Adjust' | 'Canvas';
export interface CommandResult {
    message?: string;
    /** A file the command made (an export); the screen downloads it, the CLI and MCP write it. */
    file?: {
        name: string;
        type: string;
        data: Uint8Array;
    };
    /** Information a command reports (the layer list). */
    data?: unknown;
}
export interface Command {
    id: string;
    label: string;
    description: string;
    menu?: Menu;
    /** Shown in menus; the screen binds the keys itself. */
    keys?: string;
    params?: readonly Param[];
    /** The screen shows its settings dialog with the result live (adjustments). */
    preview?: boolean;
    /** Null when it can run, otherwise why not (also greys it out in menus). */
    blocked?: (s: DesignSession) => string | null;
    run: (s: DesignSession, p: Record<string, any>) => CommandResult | void | Promise<CommandResult | void>;
}
export declare class CommandError extends Error {
}
/** The layer a command acts on: by id, then by name (the topmost of that name), else the picked one. */
export declare function resolveLayer(s: DesignSession, ref?: string): Layer;
/** How much of a layer pixel the selection allows (mapped through the layer's position), or of a document pixel for masks. */
export declare function selectionClip(s: DesignSession, layer: Layer | null): Clip | undefined;
/** A summary of the design: size, colours, selection and every layer (top first), for agents and scripts. */
export declare function describe(s: DesignSession): {
    width: number;
    height: number;
    background: string | null;
    picked: string | null;
    selection: import("./geometry.js").Rect | null;
    colours: Colours;
    canUndo: boolean;
    canRedo: boolean;
    layers: ({
        id: string;
        name: string;
        kind: "raster" | "shape" | "text";
        visible: boolean;
        locked: boolean;
        opacity: number;
        blend: import("./document.js").BlendMode;
        x: number;
        y: number;
        width: number;
        height: number;
        rotation: number;
        mask: string | null;
    } | {
        text: string;
        font: string;
        size: number;
        color: string;
        id: string;
        name: string;
        kind: "raster" | "shape" | "text";
        visible: boolean;
        locked: boolean;
        opacity: number;
        blend: import("./document.js").BlendMode;
        x: number;
        y: number;
        width: number;
        height: number;
        rotation: number;
        mask: string | null;
    } | {
        shape: "rect" | "ellipse" | "line" | "path";
        fill: string | null;
        stroke: string | null;
        strokeWidth: number;
        id: string;
        name: string;
        kind: "raster" | "shape" | "text";
        visible: boolean;
        locked: boolean;
        opacity: number;
        blend: import("./document.js").BlendMode;
        x: number;
        y: number;
        width: number;
        height: number;
        rotation: number;
        mask: string | null;
    })[];
};
export declare const COMMANDS: readonly Command[];
export declare const findCommand: (id: string) => Command | undefined;
/** Checks and fills in a command's settings: defaults, numbers from text (the command line), ranges, choices and colours. */
export declare function resolveParams(s: DesignSession, cmd: Command, raw?: Record<string, unknown>): Promise<Record<string, any>>;
/** Runs a command by id with raw settings, as every caller does (the screen, the command line, MCP). Throws CommandError with a plain message. */
export declare function runCommand(s: DesignSession, id: string, raw?: Record<string, unknown>): Promise<CommandResult | void>;
/** The registry as plain data (for MCP and the command line): ids, what they do, and their settings. */
export declare function commandList(): {
    id: string;
    label: string;
    description: string;
    params: {
        nullable?: boolean | undefined;
        default?: {} | null | undefined;
        optional?: boolean | undefined;
        options?: readonly string[] | undefined;
        max?: number | undefined;
        min?: number | undefined;
        description?: string | undefined;
        name: string;
        type: ParamType;
    }[];
}[];
