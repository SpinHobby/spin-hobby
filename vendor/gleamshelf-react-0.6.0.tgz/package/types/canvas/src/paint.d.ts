import type { PixelData } from './document.js';
import type { Point, Rect } from './geometry.js';
/** 0-255 RGB. */
export type Rgb = [number, number, number];
export declare const hexToRgb: (hex: string) => Rgb;
export declare const rgbToHex: ([r, g, b]: readonly number[]) => string;
/**
 * How much of a pixel an edit may touch, 0-1, from the selection (in the target's own coordinates). Undefined means everywhere.
 * The UI builds it from the selection and the layer's position, so these functions need not know about either.
 */
export type Clip = (x: number, y: number) => number;
export interface BrushOptions {
    /** Diameter, pixels. */
    size: number;
    /** 0 (soft, fades from the centre) to 1 (a hard edge). */
    hardness: number;
    /** How much each dab covers, 0-1. */
    flow: number;
    color: Rgb;
    /** paint: colour on; erase: make transparent; reveal/hide: raise or lower the alpha only (painting a mask). */
    mode: 'paint' | 'erase' | 'reveal' | 'hide';
}
/** One dab of the brush at `at`; returns the box it touched (or null when it was off the picture). */
export declare function dab(target: PixelData, at: Point, o: BrushOptions, clip?: Clip): Rect | null;
/** Where a stroke has got to, so dabs stay evenly spaced across pointer events. */
export interface Stroke {
    last: Point | null;
    /** Distance travelled since the last dab. */
    carry: number;
}
export declare const startStroke: () => Stroke;
export declare const union: (a: Rect | null, b: Rect | null) => Rect | null;
/**
 * Continues a stroke to `to`, calling `place` at points `spacing` apart (carrying the remainder to the next call, so dabs stay even across pointer
 * events). Returns the union of the boxes `place` reports.
 */
export declare function walkStroke(stroke: Stroke, to: Point, spacing: number, place: (at: Point) => Rect | null): Rect | null;
/** The spacing between dabs for a brush size. */
export declare const brushSpacing: (size: number) => number;
/** Continues a brush stroke to `to`. Returns the box that changed. */
export declare function strokeTo(target: PixelData, stroke: Stroke, to: Point, o: BrushOptions, clip?: Clip): Rect | null;
/**
 * Paint bucket: fills the patch of similar colour round `at` (or every similar pixel when not `contiguous`) with `color`. Tolerance 0-255 is the
 * largest channel difference that still counts as the same colour.
 */
export declare function floodFill(target: PixelData, at: Point, color: Rgb, tolerance: number, contiguous?: boolean, clip?: Clip): Rect | null;
/** Fills everything `clip` allows (the selection) with a colour. */
export declare function fillArea(target: PixelData, color: Rgb, clip?: Clip): void;
/** Makes everything `clip` allows (the selection) transparent. */
export declare function clearArea(target: PixelData, clip?: Clip): void;
/** A copy of the pixels `clip` allows, the rest transparent (copy to a new layer). */
export declare function copyArea(source: PixelData, clip?: Clip): PixelData;
/** A straight gradient from `from` (colour a) to `to` (colour b), over what `clip` allows. */
export declare function linearGradient(target: PixelData, from: Point, to: Point, a: Rgb, b: Rgb, clip?: Clip): void;
/** The colour at a point of a picture (eyedropper). */
export declare function sample(picture: PixelData, at: Point): Rgb | null;
/**
 * Clone stamp: one dab of `source` copied from `at + offset` to `at`. Source and target may be the same picture; reading from a snapshot taken
 * at the start of the stroke (as the UI does) keeps the stamp from copying what it just painted.
 */
export declare function cloneDab(target: PixelData, source: PixelData, at: Point, offset: Point, o: Pick<BrushOptions, 'size' | 'hardness' | 'flow'>, clip?: Clip): Rect | null;
