/**
 * The layered document Edit mode works on. Plain, immutable data: every change makes a new document (the history keeps the old ones), and raster
 * pixels live in a PixelStore under ids, so a document is cheap to copy and to keep many of. Layers are listed bottom to top.
 */
/** How a layer mixes with what is under it. The ids are the Canvas 2D / CSS names, so drawing and SVG export use them as they are. */
export type BlendMode = 'normal' | 'multiply' | 'screen' | 'overlay' | 'darken' | 'lighten' | 'color-dodge' | 'color-burn' | 'hard-light' | 'soft-light' | 'difference' | 'exclusion' | 'hue' | 'saturation' | 'color' | 'luminosity';
/** The blend modes in the order the layer panel lists them, with the names it shows (grouped: darker, lighter, contrast, compare, colour). */
export declare const BLEND_MODES: readonly {
    id: BlendMode;
    label: string;
}[];
/** Where a layer sits: moved by (x, y), turned by `rotation` (radians, about its own top-left corner), scaled. */
export interface Transform {
    x: number;
    y: number;
    scaleX: number;
    scaleY: number;
    rotation: number;
}
export declare const IDENTITY: Transform;
interface LayerBase {
    id: string;
    name: string;
    visible: boolean;
    locked: boolean;
    /** 0-1. */
    opacity: number;
    blend: BlendMode;
    transform: Transform;
    /** A mask in document coordinates (a PixelStore id; its alpha is how much of the layer shows). */
    mask?: string;
    /** A mask can be switched off without throwing it away. */
    maskOff?: boolean;
    /** Effects drawn with the layer and kept editable: a drop shadow, an outer glow, a stroke round its edge. */
    style?: LayerStyle;
}
/** A layer's effects, drawn every time from the layer's own pixels, so they follow it when it changes. */
export interface LayerStyle {
    /** `angle`: where the light comes from, in degrees as in a photo editor (0 from the right, 90 from above, 120 from the upper left); `distance` and `blur` in pixels, `opacity` 0-1. */
    shadow?: {
        color: string;
        opacity: number;
        angle: number;
        distance: number;
        blur: number;
    };
    /** A soft halo all round: `size` in pixels. */
    glow?: {
        color: string;
        opacity: number;
        size: number;
    };
    /** A line round the layer's edge, outside it, `width` pixels. */
    stroke?: {
        color: string;
        width: number;
    };
}
export interface RasterLayer extends LayerBase {
    kind: 'raster';
    /** PixelStore id of the layer's pixels. */
    pixels: string;
    /** The 3D design these pixels were drawn from (a ModelDocument, see packages/scene3d/src/model): 3D mode reopens it, and the layer is drawn again. */
    model3d?: unknown;
}
/** A point of a vector path, with optional curve handles relative to the point. */
export interface PathPoint {
    x: number;
    y: number;
    in?: {
        x: number;
        y: number;
    };
    out?: {
        x: number;
        y: number;
    };
}
export interface PathData {
    points: PathPoint[];
    closed: boolean;
}
export type Shape = {
    type: 'rect';
    width: number;
    height: number;
    radius: number;
} | {
    type: 'ellipse';
    width: number;
    height: number;
} | {
    type: 'line';
    x2: number;
    y2: number;
} | {
    type: 'path';
    path: PathData;
};
export interface ShapeLayer extends LayerBase {
    kind: 'shape';
    shape: Shape;
    /** `#rrggbb`, or null for none. */
    fill: string | null;
    stroke: string | null;
    strokeWidth: number;
}
export interface TextLayer extends LayerBase {
    kind: 'text';
    text: string;
    font: string;
    size: number;
    weight: number;
    italic: boolean;
    color: string;
    align: 'left' | 'center' | 'right';
    /** Line height as a multiple of the size. */
    lineHeight: number;
    /** The drawn size of the text block, measured when the text changes (the document has no fonts of its own to measure with). */
    box: {
        width: number;
        height: number;
    };
}
export type Layer = RasterLayer | ShapeLayer | TextLayer;
export interface CanvasDocument {
    width: number;
    height: number;
    /** The canvas colour under every layer, or null for transparent. */
    background: string | null;
    layers: Layer[];
}
/** Pixels of a raster layer or a mask: RGBA, 8 bits per channel, not premultiplied (the same layout as ImageData). */
export interface PixelData {
    width: number;
    height: number;
    data: Uint8ClampedArray;
}
/** A fresh id; unique within a session, which is all documents and stores need. */
export declare const newId: (prefix: string) => string;
export declare const blankPixels: (width: number, height: number) => PixelData;
export declare const clonePixels: (p: PixelData) => PixelData;
/**
 * Where raster pixels live, by id. Append-only while editing (an edit stores new pixels under a new id, so older documents in the history still
 * find theirs); `keepOnly` drops what no kept document uses.
 */
export declare class PixelStore {
    private readonly map;
    get(id: string): PixelData | undefined;
    add(pixels: PixelData, prefix?: string): string;
    /** Stores pixels under an id from a saved project. */
    set(id: string, pixels: PixelData): void;
    get size(): number;
    /** Forgets every entry that none of `docs` refers to. */
    keepOnly(docs: readonly CanvasDocument[]): void;
}
/** Every PixelStore id a document refers to (layer pixels and masks). */
export declare function pixelIds(doc: CanvasDocument): string[];
export declare function createDocument(width: number, height: number, background?: string | null): CanvasDocument;
export declare const rasterLayer: (name: string, pixels: string, at?: Partial<Transform>) => RasterLayer;
export declare const shapeLayer: (name: string, shape: Shape, style?: Partial<Pick<ShapeLayer, "fill" | "stroke" | "strokeWidth">>, at?: Partial<Transform>) => ShapeLayer;
export declare const textLayer: (text: string, style?: Partial<Omit<TextLayer, "kind" | "id" | "text">>, at?: Partial<Transform>) => TextLayer;
export declare const findLayer: (doc: CanvasDocument, id: string) => Layer | undefined;
/** Adds a layer above `aboveId` (or on top). */
export declare function addLayer(doc: CanvasDocument, layer: Layer, aboveId?: string): CanvasDocument;
export declare function updateLayer<L extends Layer>(doc: CanvasDocument, id: string, patch: Partial<L>): CanvasDocument;
export declare const removeLayer: (doc: CanvasDocument, id: string) => CanvasDocument;
/** Moves a layer up (+1) or down (-1) the stack, or to the top/bottom with +/-Infinity. */
export declare function moveLayer(doc: CanvasDocument, id: string, by: number): CanvasDocument;
/** A copy of a layer just above it; raster pixels and masks are copied too, so painting one does not paint the other. */
export declare function duplicateLayer(doc: CanvasDocument, store: PixelStore, id: string): {
    doc: CanvasDocument;
    id: string;
};
/** The canvas made a new size: layers keep their place relative to the anchor (0 = left/top, 0.5 = centre, 1 = right/bottom). */
export declare function resizeCanvas(doc: CanvasDocument, width: number, height: number, anchorX?: number, anchorY?: number): CanvasDocument;
export {};
