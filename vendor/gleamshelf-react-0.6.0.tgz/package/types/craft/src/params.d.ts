/**
 * PhotoCraft describes each command's parameters in a short text form, e.g.
 * `{"radius":0.1..1000=1,"method":"spin|zoom","monochromatic":bool,"seed":u32=0} (notes)`. This reads that text into fields a form can show:
 * number ranges become sliders, `bool` a switch, `"a|b"` a choice, integers and strings boxes, and anything richer (`json`, points, ids) an
 * optional JSON box, so every parameter can still be set.
 */
export type ParamField = {
    key: string;
    kind: 'range';
    min: number;
    max: number;
    default: number;
    optional: boolean;
    integer: boolean;
} | {
    key: string;
    kind: 'bool';
    default: boolean;
    optional: boolean;
} | {
    key: string;
    kind: 'choice';
    options: string[];
    default: string;
    optional: boolean;
} | {
    key: string;
    kind: 'number';
    default: number | null;
    optional: boolean;
    integer: boolean;
} | {
    key: string;
    kind: 'text';
    default: string | null;
    optional: boolean;
    hint: string;
} | {
    key: string;
    kind: 'json';
    optional: true;
    hint: string;
};
export interface ParamSpec {
    fields: ParamField[];
    /** The text after the braces, if any: how the parameters fit together. */
    notes: string;
}
/** Reads a command's parameter description. Text it can't read gives no fields (the command then runs with its defaults, or a JSON box). */
export declare function parseParams(text: string): ParamSpec;
/** The parameters a form's values make: optional fields left empty are not sent, so the command uses its own default. */
export declare function paramsFrom(spec: ParamSpec, values: Record<string, unknown>): Record<string, unknown>;
/** Starting values for a form: each field's default. */
export declare function defaultsOf(spec: ParamSpec): Record<string, unknown>;
