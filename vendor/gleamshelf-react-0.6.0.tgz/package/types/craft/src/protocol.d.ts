/** What the page asks Photo lab's worker for (see worker.ts). */
/** A picture: straight (not premultiplied) RGBA bytes, the layout of ImageData. */
export interface Pic {
    width: number;
    height: number;
    rgba: Uint8Array;
}
export type CraftRequest = {
    op: 'init';
    wasmUrl: string;
} | {
    op: 'open';
    name: string;
    bytes: Uint8Array;
} | {
    op: 'openRgba';
    name: string;
    pic: Pic;
} | {
    op: 'execute';
    id: string;
    params?: unknown;
} | {
    op: 'commands';
} | {
    op: 'disabledReason';
    id: string;
} | {
    op: 'undo';
} | {
    op: 'redo';
} | {
    op: 'info';
} | {
    op: 'composite';
} | {
    op: 'selection';
} | {
    op: 'activeRgba';
} | {
    op: 'place';
    name: string;
    x: number;
    y: number;
    pic: Pic;
} | {
    op: 'replaceActive';
    label: string;
    pic: Pic;
} | {
    op: 'export';
    ext: string;
    options?: {
        quality?: number;
        lossless?: boolean;
    };
} | {
    op: 'developControls';
} | {
    op: 'developDefaults';
} | {
    op: 'developPresets';
} | {
    op: 'developApplyPreset';
    settings: unknown;
    preset: DevelopPreset;
    amount: number;
} | {
    op: 'developSet';
    settings: unknown;
    id: string;
    value: number;
} | {
    op: 'developSource';
    pic: Pic;
} | {
    op: 'developRender';
    settings: unknown;
    maxW: number;
    maxH: number;
    draft: boolean;
};
/** One PhotoCraft command, as `commands()` lists it. */
export interface CraftCommand {
    id: string;
    label: string;
    /** Where its own app files it, e.g. ["Filter", "Blur"]; empty for commands kept off menus. */
    menu: string[];
    shortcut?: string | null;
    /** The parameter description (see params.ts). */
    params: string;
    enabled: boolean;
    /** Why it can't run now, when it can't. */
    disabledReason?: string | null;
    /** Other names it is found by (its own app's tool names). */
    keywords?: string;
}
/** One LightCraft develop control. */
export interface DevelopControl {
    id: string;
    label: string;
    section: string;
    sectionLabel: string;
    min: number;
    max: number;
    default: number;
    step: number;
    decimals: number;
    track: unknown;
}
/** A LightCraft look: partial develop settings. */
export interface DevelopPreset {
    id: string;
    name: string;
    group: string;
    settings: Record<string, unknown>;
    builtin?: boolean;
    favorite?: boolean;
}
