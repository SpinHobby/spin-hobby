/**
 * @gleamshelf/craft: Photo lab's engines in the browser. PhotoCraft's editing engine (every command, layers, selections, retouching, PSD) and
 * LightCraft's develop pipeline, both open source (MIT OR Apache-2.0, see NOTICE), compiled to WebAssembly and run in a worker.
 *
 *   const craft = openCraft();
 *   await craft.openPicture('photo', pic);
 *   await craft.execute('filter.blur.gaussianBlur', { radius: 4 });
 *   const shown = await craft.composite();
 */
import type { CraftCommand, DevelopControl, DevelopPreset, Pic } from './protocol';
export type { CraftCommand, DevelopControl, DevelopPreset, Pic } from './protocol';
export { defaultsOf, paramsFrom, parseParams, type ParamField, type ParamSpec } from './params';
export interface Craft {
    /** Opens a file (PSD, PSB, PNG, JPEG, WebP, TIFF, ...) as the document. */
    openFile(name: string, bytes: Uint8Array): Promise<{
        warnings: string[];
    }>;
    /** Opens a picture as a one-layer document. */
    openPicture(name: string, pic: Pic): Promise<void>;
    /** Runs any PhotoCraft command by id; returns its result. */
    execute(id: string, params?: unknown): Promise<unknown>;
    commands(): Promise<CraftCommand[]>;
    undo(): Promise<boolean>;
    redo(): Promise<boolean>;
    info(): Promise<{
        revision: number;
        width: number;
        height: number;
    }>;
    composite(): Promise<Pic>;
    selection(): Promise<Pic | null>;
    activePixels(): Promise<Pic>;
    place(name: string, x: number, y: number, pic: Pic): Promise<void>;
    replaceActive(label: string, pic: Pic): Promise<void>;
    /** The document saved by extension: psd keeps the layers, png/jpg/webp/tiff are flat. */
    export(ext: string, options?: {
        quality?: number;
        lossless?: boolean;
    }): Promise<Uint8Array>;
    develop: {
        controls(): Promise<DevelopControl[]>;
        defaults(): Promise<Record<string, unknown>>;
        presets(): Promise<DevelopPreset[]>;
        applyPreset(settings: unknown, preset: DevelopPreset, amount: number): Promise<Record<string, unknown>>;
        set(settings: unknown, id: string, value: number): Promise<Record<string, unknown>>;
        /** The picture the next renders develop. */
        source(pic: Pic): Promise<void>;
        render(settings: unknown, maxW: number, maxH: number, draft?: boolean): Promise<Pic>;
    };
    close(): void;
}
export interface CraftOptions {
    /** Where gleamshelf_craft_bg.wasm is served, when the host serves it somewhere else than next to this code. */
    wasmUrl?: string;
}
/** Starts the engines in a worker. The WebAssembly (about 10 MB to download) loads once, when this is called. */
export declare function openCraft(options?: CraftOptions): Craft;
