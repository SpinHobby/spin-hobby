import * as THREE from 'three';
import type { StageName } from './scene.js';
/** A built display: its meshes, and the height of the surface the item stands on. Units: the item is 1 tall. */
export interface Stage {
    group: THREE.Group;
    standY: number;
    dispose(): void;
}
/** Builds one of the display templates in the given backdrop and surface colours. */
export declare function buildStage(name: StageName, color: string, accent: string): Stage;
