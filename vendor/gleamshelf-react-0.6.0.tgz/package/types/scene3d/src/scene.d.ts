import { type ParamSpec, type Path, type ShaderStep } from '../../core/src/index.js';
export declare const STAGES: readonly ["studio", "pedestal", "shelf", "table"];
export type StageName = (typeof STAGES)[number];
export declare const LIGHTS: readonly ["soft", "bright", "dramatic"];
export type LightName = (typeof LIGHTS)[number];
export declare const MOTIONS: readonly ["still", "sway"];
/**
 * Everything editable in a scene, by path. The values live in the document under the same paths
 * (`stage/template`, `item/scale`, …), so the document is plain JSON that hosts can save and reopen.
 */
export declare const SCENE_PARAMS: Readonly<Record<string, ParamSpec>>;
export interface SceneItem {
    /** Width ÷ height of the item's image, so it stands at the right shape before the image loads. */
    aspect: number;
}
export interface SceneDocument {
    schema: 'gleamshelf/scene';
    version: 1;
    stage: {
        template: StageName;
        color: string;
        accent: string;
    };
    light: {
        preset: LightName;
        angle: number;
    };
    item: SceneItem & {
        scale: number;
        turn: number;
        offset: number;
        base: boolean;
    };
    motion: {
        mode: (typeof MOTIONS)[number];
    };
    /** Shader effects over the finished picture, in order (see packages/shaders/fragment). */
    effects: ShaderStep[];
    /** One vertex shader that moves the product's surface, or none (see packages/shaders/vertex). */
    vertex: ShaderStep | null;
}
export declare function sceneParam(path: Path): ParamSpec | undefined;
export declare function createScene(aspect: number): SceneDocument;
/** Reads a saved scene from untrusted JSON: unknown values are dropped, invalid ones fall back to defaults. */
export declare function loadScene(aspect: number, saved: unknown): SceneDocument;
