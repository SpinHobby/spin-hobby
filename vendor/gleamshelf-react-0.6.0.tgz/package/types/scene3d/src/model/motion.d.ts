import type { ModelDocument, Shape3D, Vec3 } from './document.js';
/**
 * Motion for each shape (or a whole group): it spins, floats, bounces, sways, pulses, wiggles, goes round the middle or pops in, while a clip
 * plays. Motions count in whole cycles per clip, so every clip loops without a jump; `delay` starts one later in its cycle, so letters can follow
 * each other. `animate` gives the design at a moment of the clip; the video and the live preview both draw from it.
 */
export declare const MOTION_LABEL: {
    readonly spin: "Spin";
    readonly float: "Float";
    readonly bounce: "Bounce";
    readonly sway: "Sway";
    readonly pulse: "Pulse";
    readonly wiggle: "Wiggle";
    readonly orbit: "Go round";
    readonly pop: "Pop in";
};
export type MotionKind = keyof typeof MOTION_LABEL;
export declare const MOTION_KINDS: MotionKind[];
export interface Motion {
    kind: MotionKind;
    /** Whole cycles in the clip (1-8): turns for a spin, hops for a bounce. */
    times: number;
    /** How far (0-1): the height of a float or bounce, the angle of a sway or wiggle, the size of a pulse. */
    amount: number;
    /** Starts this share of a cycle later (0-1). */
    delay: number;
    /** spin and sway: the axis it turns about (y: upright, as a turntable). */
    axis: 'x' | 'y' | 'z';
    /** spin and orbit: the other way round. */
    reverse: boolean;
}
export declare const DEFAULT_MOTION: Motion;
/** A motion made safe for a file; undefined for none. */
export declare function checkMotion(raw: unknown): Motion | undefined;
type M3 = number[];
/** Euler degrees (x, y, z order, as rotationMatrix) of a rotation matrix. */
export declare function eulerOf(m: M3): Vec3;
/** How a body (a shape, or a group's shapes) is moved at a moment: turned and grown about a pivot, then shifted. */
interface Pose {
    pivot: Vec3;
    turn: M3;
    grow: Vec3;
    move: Vec3;
}
/** The pose of a body with a motion at time `t` (0-1 of the clip); `centre` is what orbit goes round. */
export declare function poseAt(body: Shape3D, m: Motion, t: number, centre: Vec3): Pose;
/** Whether any shape in a design moves. */
export declare const hasMotion: (doc: Pick<ModelDocument, "shapes">) => boolean;
/** The design at time `t` (0-1) of a clip: every shape with a motion moved (a group's shapes first by their own, then all by the group's). */
export declare function animate(doc: ModelDocument, t: number): ModelDocument;
export {};
