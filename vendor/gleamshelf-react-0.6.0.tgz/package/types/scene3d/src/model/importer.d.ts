import type { ModelAsset } from './document.js';
/**
 * Importing a 3D model in the browser: the person picks the model (and, for a .gltf or .obj, the files beside it: .bin, .mtl, pictures), a Three.js
 * loader reads it (Draco and meshopt compression decoded here, nothing fetched from the internet), and it becomes the plain GLB a design keeps.
 * Each loader is fetched only when its kind of file is imported, so 3D mode opens quickly.
 */
/** The model files 3D mode opens, by extension. */
export declare const MODEL_EXTENSIONS: readonly ["glb", "gltf", "fbx", "obj", "stl", "ply", "3mf"];
/** For a file input's accept: the models and the files that come with them. */
export declare const MODEL_ACCEPT = ".glb,.gltf,.fbx,.obj,.stl,.ply,.3mf,.bin,.mtl,.png,.jpg,.jpeg,.webp,.tga,.bmp";
export interface ImportedModel {
    asset: ModelAsset;
    /** Things the person should know (textures that could not come along, a rigged model in its resting pose). */
    warnings: string[];
}
/**
 * Reads a model the person picked: `files` holds the model and any files it points at. Returns it in the form a design keeps, or throws a plain
 * message.
 */
export declare function importModelFiles(files: File[]): Promise<ImportedModel>;
