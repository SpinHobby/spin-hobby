import { type ModelDocument, type Shape3D, type Step, type Vec3 } from './document.js';
/**
 * A shape's rotation as a 3x3 matrix (row-major), local to world. Euler angles in x, y, z order as Three.js reads them (R = Rx · Ry · Rz), so the
 * gizmo and the field agree.
 */
export declare function rotationMatrix([ax, ay, az]: Vec3): number[];
/** A world point in a shape's own frame: moved to its centre, then turned back (the transpose of its rotation). */
export declare function toLocal(s: Pick<Shape3D, 'position' | 'rotation'>, p: Vec3): Vec3;
/** One shape's distance in its own frame. Kept line for line with `shapeDist` in glsl.ts. */
export declare function shapeDistance(s: Shape3D, p: Vec3): number;
/** How soft a blend is in scene units. */
export declare const blendRadius: (s: Pick<Shape3D, "blend">) => number;
/**
 * Joins a shape (distance `di`) onto what came before (`d`): added, cut away or intersected, softly over `k`. Returns the new distance and how much
 * the shape now decides the surface (0-1), for its colour. Kept in step with `join` in glsl.ts.
 */
export declare function join(d: number, di: number, combine: Shape3D['combine'], k: number): {
    d: number;
    h: number;
};
export interface FieldSample {
    d: number;
    /** The colour there, mixed across soft joins (0-1 sRGB), and the finish's shininess and metalness. */
    color: Vec3;
    shine: number;
    metal: number;
    /** The shape that decides the surface there: its place in the design (index, or group index and index in the group), or null. */
    owner: [number] | [number, number] | null;
}
export declare const FINISH: Record<Shape3D['finish'], [number, number]>;
/** The design at a world point: distance, colour and finish, walking its shapes in order (a group joins its own shapes first). */
export declare function sampleScene(doc: Pick<ModelDocument, 'shapes'>, p: Vec3, walk?: Step[]): FieldSample;
/** The design's distance at a world point, and which shape the surface there belongs to (its place in the design). */
export declare function sceneDistance(doc: Pick<ModelDocument, 'shapes'>, p: Vec3): {
    d: number;
    shape: [number] | [number, number] | null;
};
/** Marches a ray into the design: the first surface it meets, or null. */
export declare function march(doc: Pick<ModelDocument, 'shapes'>, origin: Vec3, dir: Vec3, maxDistance?: number): {
    t: number;
    shape: [number] | [number, number] | null;
} | null;
