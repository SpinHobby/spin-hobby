import type { ModelDocument } from './document.js';
/**
 * Short clips of a 3D design, made in the browser: the shapes move as their motions say (motion.ts), while the camera stays, goes once round
 * (turntable), rocks side to side (`bounce`, kept as the name for designs and agents that use it) or the light goes once round (light sweep). Every frame is drawn by the shader off screen and encoded by the browser's own video encoder
 * (WebCodecs, through Mediabunny): H.264 in MP4 where the browser has it, VP9 in WebM otherwise.
 */
export declare const CLIPS: {
    readonly still: "Camera still";
    readonly turntable: "Turntable";
    readonly bounce: "Camera sway";
    readonly light: "Light sweep";
};
export type ClipKind = keyof typeof CLIPS;
export interface ClipOptions {
    kind: ClipKind;
    /** Length in seconds (1-20). */
    seconds?: number;
    fps?: number;
    /** Pixels on the long side (frames are even-sized for the encoder). */
    size?: number;
    /** Width over height of the frame. */
    aspect?: number;
    onProgress?: (done: number) => void;
}
/** The design at time `t` (0-1) of a clip: its shapes' motions, then the camera's or the light's. */
export declare function clipFrame(design: ModelDocument, kind: ClipKind, t: number): ModelDocument;
export declare function recordClip(doc: ModelDocument, options: ClipOptions): Promise<{
    blob: Blob;
    type: string;
    extension: string;
}>;
