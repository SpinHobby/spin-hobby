/**
 * Flat outlines for 3D mode: a pen path, a ready-made outline (a star, a heart), the letters of a text, or any layer's shape from Edit mode, pushed
 * out into a solid (the `extrude` and `text` shapes). An outline is a list of closed contours in a unit box (-0.5 to 0.5 each way, y up); holes are
 * contours inside others, read even-odd. The solid is drawn from a 2D distance field of the outline (fieldOf), the same on the CPU and in the shader.
 */
export type Point2 = [number, number];
export type Contour = Point2[];
/** Texels on a side of an outline's distance field. */
export declare const FIELD_SIZE = 256;
/** How far, in texels, the field measures before it is clamped (it is stored as bytes). */
export declare const FIELD_RANGE = 24;
/** The outline's own width over height (its box), and the outline stretched to fill the unit box. */
export declare function normalizeContours(contours: Contour[]): {
    contours: Contour[];
    aspect: number;
};
/** Fills contours into a mask (even-odd, so holes stay open): `map` takes a contour point to pixel coordinates. */
export declare function rasterize(contours: Contour[], width: number, height: number, map: (p: Point2) => Point2): Uint8Array;
/** Distance in pixels from every pixel to the nearest pixel where `inside` is true (exact Euclidean). */
export declare function distanceTransform(mask: Uint8Array, width: number, height: number, inside: boolean): Float64Array;
/** An outline's 2D distance field for a shape `sx` wide and `sy` tall, and what a texel is in the shape's units. */
export interface Field {
    /** The signed distance at each texel centre, in texels (inside negative), clamped to ±FIELD_RANGE. */
    grid: Float32Array;
    /** Half the field's side, in the shape's units: the field covers -half to half on x and y. */
    half: number;
    /** One texel in the shape's units. */
    texel: number;
}
/**
 * The distance field of an outline at a size (the outline stretched to `sx` by `sy`, so distances are true at that size). Cached: a shape that only
 * moves or turns reuses it.
 */
export declare function fieldOf(contours: Contour[], sx: number, sy: number): Field;
/**
 * The distance from every pixel centre to the nearest edge of the contours (in pixels), exact, up to `reach` (farther pixels get `reach`). Each edge
 * only visits the pixels within `reach` of it, so a long outline stays quick.
 */
export declare function segmentDistances(contours: Contour[], width: number, height: number, reach: number): Float32Array;
/** The field's distance at a point in the shape's own x, y (bilinear, as the shader's texture lookup), in the shape's units. */
export declare function sampleField(field: Field, x: number, y: number): number;
/**
 * The outlines of a mask, as closed contours in pixel coordinates (marching squares on the pixel corners, so every edge between a set and an unset
 * pixel is on exactly one contour), simplified to within `tolerance` pixels.
 */
export declare function traceContours(mask: Uint8Array, width: number, height: number, tolerance?: number, 
/**
 * For a smooth outline of a picture: each pixel's coverage (0-1, `mask` is coverage >= 0.5). The edge then runs where the coverage crosses
 * one half between pixel centres (sub-pixel, so anti-aliased edges trace true), and the stair steps left are smoothed away before simplifying.
 */
coverage?: Float32Array): Contour[];
/** A closed contour with points dropped while it stays within `tolerance` (Ramer-Douglas-Peucker, split at the farthest point from the first). */
export declare function simplify(loop: Contour, tolerance: number): Contour;
/** The signed area of a contour (positive counter-clockwise with y up). */
export declare const area: (c: Contour) => number;
/** Ready-made outlines to push out into a solid. */
export declare const OUTLINES: Record<string, {
    label: string;
    contours: Contour[];
}>;
