import { type Contour, type Point2 } from './outline.js';
/**
 * SVG files into 3D mode: a logo or drawing read from its own paths (not a picture of it), one outline per fill colour. Each outline is the part of
 * its colour still showing once everything is painted in the file's order, so the pieces sit side by side, like the flat logo, and nothing hides
 * inside another. Pure code (no DOM), so the browser and Node read a file the same way.
 *
 * Read: path, rect, circle, ellipse, polygon, polyline, groups and nested svg, use, transforms, fill and fill-rule (attributes, style="" and
 * simple <style> rules by tag, .class and #id), gradients (as their middle colour). Left out, with a warning: strokes, text, pictures.
 */
export interface SvgPart {
    /** A plain colour name ("Red", "Blue 2"). */
    name: string;
    color: string;
    /** The part's own outline (unit box, y up) and its width over height. */
    outline: Contour[];
    aspect: number;
    /** Where the part sits in the drawing: its centre and size, with the drawing's long side 1 and its centre at 0, y up. */
    box: {
        x: number;
        y: number;
        w: number;
        h: number;
    };
}
export interface SvgOutlines {
    parts: SvgPart[];
    /** The whole drawing's width over height. */
    aspect: number;
    warnings: string[];
}
/** A plain name for a colour, by hue and lightness. */
export declare function colourName(hex: string): string;
/** A subpath as cubic pieces from its start: each piece [control 1, control 2, end]. */
interface Subpath {
    start: Point2;
    pieces: [Point2, Point2, Point2][];
}
/** Path data as subpaths of cubic pieces (lines are pieces with their controls at the ends). */
export declare function parsePathData(d: string): Subpath[];
/**
 * Reads an SVG file into outlines, one per colour (at most `maxParts`: the smallest colours are merged into their nearest), each with where it sits
 * in the drawing. Throws when the file has no filled shapes.
 */
export declare function svgOutlines(svg: string, options?: {
    maxParts?: number;
}): SvgOutlines;
export {};
