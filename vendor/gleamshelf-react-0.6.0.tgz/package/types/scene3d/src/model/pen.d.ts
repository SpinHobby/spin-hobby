import type { Contour, Point2 } from './outline.js';
/**
 * Pen paths for 3D mode's outlines: points joined by straight lines or curves, as a drawing app's pen draws them. A point with handles is
 * smooth (the curve passes through it); without, it is a corner. Kept on the shape (`Shape3D.pen`) so the outline can be edited again; the solid
 * is drawn from the outline flattened from it (penContours).
 */
export interface PenNode {
    p: Point2;
    /** The handle the curve arrives along, and the one it leaves along (absolute positions). None: a corner on that side. */
    in?: Point2;
    out?: Point2;
}
export interface PenPath {
    nodes: PenNode[];
    closed: boolean;
}
/**
 * The closed contours of pen paths (an open path is closed by a line back to its start): each curve cut into `steps` lines. Paths with fewer than
 * three points' worth of outline are left out. Holes are paths inside others (even-odd), as everywhere in 3D mode.
 */
export declare function penContours(paths: PenPath[], steps?: number): Contour[];
/** Pen paths made safe for a file: at most 16 paths of 400 points, numbers in -1 to 1. */
export declare function checkPen(raw: unknown): PenPath[] | undefined;
/** Corner points for a contour (a ready-made outline), so it can be edited with the pen. */
export declare const penFromContours: (contours: Contour[]) => PenPath[];
