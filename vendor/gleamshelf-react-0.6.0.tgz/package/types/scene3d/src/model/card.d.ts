import type { ModelAsset } from './document.js';
/**
 * A photo card: a picture (a product's cut-out, PNG with its see-through background) on a flat card in the 3D design. It is drawn unlit, so
 * its pixels are the photo's own, with no light, shade or gloss added; its see-through parts are holes that cast no shadow. The front and the
 * back show the photo the right way round. Width over height follows the picture; it stands on its bottom edge.
 */
export declare function pictureCard(bytes: Uint8Array, mime: 'image/png' | 'image/webp' | 'image/jpeg', width: number, height: number, name?: string): ModelAsset;
