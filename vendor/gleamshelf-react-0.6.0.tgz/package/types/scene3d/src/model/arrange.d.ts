import { type ModelAsset, type ModelDocument, type Shape3D, type Vec3 } from './document.js';
/**
 * Arranging shapes: the box each one fills in the scene (turned shapes included), and the moves that line several up, spread them evenly or set
 * them on the ground. Each move is an offset; a group moves by moving its shapes. Used by ModelEditor's align, spread and toGround.
 */
export interface Box {
    min: Vec3;
    max: Vec3;
}
/** The scene-space box a shape fills (its own box, turned), or a group's shapes' box; null for a group with nothing showing. */
export declare function shapeBox(s: Shape3D): Box | null;
export declare function unionBox(shapes: readonly Shape3D[]): Box | null;
/** The fields that move a shape by `by` (a group: its shapes). */
export declare function movedBy(s: Shape3D, by: Vec3): Partial<Shape3D>;
export type AlignTo = 'min' | 'mid' | 'max';
export type Axis = 0 | 1 | 2;
/** Offsets that line shapes up along one axis: their low sides, middles or high sides on the selection's (one shape: on the scene's middle). */
export declare function alignMoves(shapes: readonly Shape3D[], axis: Axis, to: AlignTo): Vec3[];
/** Offsets that spread three or more shapes evenly along an axis: the outer two stay, the gaps between the boxes become equal. */
export declare function spreadMoves(shapes: readonly Shape3D[], axis: Axis): Vec3[];
/** Offsets that set each shape's bottom on the ground (y = 0). */
export declare const groundMoves: (shapes: readonly Shape3D[]) => Vec3[];
/** Copies of shapes for pasting: new ids (a group's shapes too), moved by `by`. */
export declare function copiesOf(shapes: readonly Shape3D[], by: Vec3): Shape3D[];
/** The imported models a set of shapes draws, so copied shapes can be pasted into another design with them. */
export declare function assetsOf(doc: Pick<ModelDocument, 'assets'>, shapes: readonly Shape3D[]): Record<string, ModelAsset>;
