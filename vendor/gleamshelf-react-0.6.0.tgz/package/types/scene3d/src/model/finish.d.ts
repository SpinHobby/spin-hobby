import type { ModelDocument } from './document.js';
/**
 * The last steps of a picture of a design, after the 3D drawing: the pixel look (drawn small, then made big with hard edges) and the scene
 * behind (a picture under everything, filling the view). Shared by the shader's painter, the live view and the CPU renderer, so a design looks
 * the same in each. Pure code: the pictures are RGBA arrays.
 */
export interface Rgba {
    width: number;
    height: number;
    data: Uint8ClampedArray | Uint8Array;
}
/** One pixel's size in the pixel look, in pixels of a picture `height` tall (1 for other looks). */
export declare const pixelBlock: (doc: Pick<ModelDocument, "style">, height: number) => number;
/** The size a design is drawn at before its last steps: smaller by the pixel look's block. */
export declare function drawSize(doc: Pick<ModelDocument, 'style'>, width: number, height: number): [number, number];
/** Whether a design needs its last steps (otherwise it is drawn straight at its size). */
export declare const needsFinish: (doc: Pick<ModelDocument, "style" | "background">) => boolean;
/**
 * The design as the 3D drawing sees it: the pixel look shaded as toon with an outline at least one big pixel wide, and see-through where a scene
 * goes behind it (drawn at `height` pixels tall).
 */
export declare function drawnAs(doc: ModelDocument, height: number): ModelDocument;
/** Bytes and type of a data URL. */
export declare function fromDataUrl(url: string): {
    bytes: Uint8Array;
    mime: string;
} | null;
/**
 * The finished picture: the drawing (`small`, see-through where empty) made `width` x `height` (hard edges when `hard`), over the scene
 * picture cut to fill (centred), or over the background colour, or left see-through.
 */
export declare function finishPicture(small: Rgba, width: number, height: number, options: {
    hard: boolean;
    scene?: Rgba | null;
    colour?: string | null;
}): Rgba;
