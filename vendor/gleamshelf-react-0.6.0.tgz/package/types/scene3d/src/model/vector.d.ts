import type { ModelDocument } from './document.js';
import { type CpuPicture } from './cpu.js';
import type { DecodePicture } from './meshcpu.js';
import { type Contour } from './outline.js';
/**
 * A 3D design as editable vectors: drawn flat, in a few steps of light (cpu.ts with `tones`), then each region of one colour traced into an SVG
 * path (holes kept, even-odd). The floor shadow is one see-through path. Opens in Illustrator, Figma or a browser, every region its own shape.
 */
export interface VectorOptions {
    /** The traced picture's size in pixels (the SVG has the same size); bigger traces finer. */
    width: number;
    height: number;
    /** Steps of light (2-6; 3 is the toon look). */
    tones?: number;
    /** Widens the view from the same camera (the same `frame` as the picture). */
    frame?: number;
    /** Crops to the design with this much space round it (pixels); only without a background. Default 12; -1 keeps the whole view. */
    trim?: number;
    /** Decodes imported models' pictures (the browser's own when left out). */
    decodeImage?: DecodePicture;
    onProgress?: (done: number) => void | Promise<void>;
}
/** The contours as SVG path data. */
export declare const pathData: (contours: Contour[]) => string;
/** The regions of a flat picture, by colour: each a set of contours, largest region first. */
export declare function regionsOf(picture: CpuPicture): {
    fill: string;
    opacity: number;
    contours: Contour[];
}[];
/** The design as an SVG of flat regions. */
export declare function modelToSvg(doc: ModelDocument, options: VectorOptions): Promise<string>;
