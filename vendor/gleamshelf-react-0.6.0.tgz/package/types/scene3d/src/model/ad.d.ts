import { type ModelAsset, type ModelDocument, type TextSpec } from './document.js';
import type { Contour } from './outline.js';
import type { SvgOutlines } from './svg.js';
/**
 * 3D ads from a listing: the product's photo on a card (its own pixels, card.ts), a 3D headline, a small line above it, a price badge and the
 * shop's logo, on a podium, in front of a starburst, or on a shop shelf, each piece with a motion so the clip plays at once. Everything is an
 * ordinary 3D design afterwards: every piece can be moved, recoloured or changed.
 */
export declare const AD_STYLES: {
    readonly podium: "Podium";
    readonly burst: "Starburst";
    readonly shelf: "Shop shelf";
};
export type AdStyle = keyof typeof AD_STYLES;
export interface AdColours {
    background: string;
    /** The podium, shelf or panel. */
    main: string;
    /** The price badge and the burst. */
    accent: string;
    /** The headline and the small line. */
    text: string;
    /** The price on its badge. */
    priceText: string;
}
/** Colour sets that read well behind a product photo. */
export declare const AD_PALETTES: Record<string, {
    label: string;
    colours: AdColours;
}>;
/** Draws a text's outline (textOutline with the browser's or Node's canvas). */
export type TextDrawer = (text: TextSpec) => {
    outline: Contour[];
    aspect: number;
} | null;
export interface AdOptions {
    style: AdStyle;
    colours: AdColours;
    /** The product photo as a card (pictureCard), with its width over height. */
    picture?: {
        asset: ModelAsset;
        aspect: number;
    };
    headline?: string;
    /** The small line above the headline ("New arrival", the series). */
    tagline?: string;
    /** As it should read ("$45", "¥4,800"); no badge when left out. */
    price?: string;
    logo?: SvgOutlines;
    font?: string;
    /** Every piece gets a motion (on by default). */
    moving?: boolean;
    text: TextDrawer;
}
/** A long headline goes on two lines, split at the space nearest its middle. */
export declare function headlineLines(value: string): string;
/** Builds the ad as a new 3D design, framed for a view `aspect` wide over high. */
export declare function buildAd(o: AdOptions, aspect?: number): ModelDocument;
