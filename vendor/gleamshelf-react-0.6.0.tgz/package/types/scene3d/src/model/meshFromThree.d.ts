import * as THREE from 'three';
import type { ModelAsset } from './document.js';
import { type MeshAsset } from './mesh.js';
/**
 * Any model a Three.js loader read (glTF, FBX, OBJ, STL, PLY, 3MF) turned into the plain form a design keeps: every mesh's triangles with their
 * transforms baked in (instances expanded), split by material, the colour pictures re-encoded. Runs in Node too (with no pictures there).
 */
type Picture = {
    mime: string;
    bytes: Uint8Array;
};
/**
 * Encodes a texture's picture, or null when it cannot be read (a compressed GPU texture). A colour picture may be JPEG; a data picture (a
 * normal or roughness map) stays exact (PNG).
 */
export type EncodeTexture = (texture: THREE.Texture, kind: 'color' | 'data') => Promise<Picture | null>;
/** Packs separate roughness and metalness pictures into one, glTF's way: roughness in green, metalness in blue (each read from those channels). */
export type PackRoughness = (roughness: THREE.Texture | null, metalness: THREE.Texture | null) => Promise<Picture | null>;
/** The most triangles a model may bring (drawing on the CPU builds a BVH over them all). */
export declare const MAX_TRIANGLES = 1500000;
export declare function assetFromObject3D(root: THREE.Object3D, encode?: EncodeTexture, pack?: PackRoughness): Promise<{
    asset: MeshAsset;
    warnings: string[];
}>;
/** The plain form as a design keeps it: the GLB as base64, with its box. */
export declare function toModelAsset(asset: MeshAsset, name: string): ModelAsset;
export {};
