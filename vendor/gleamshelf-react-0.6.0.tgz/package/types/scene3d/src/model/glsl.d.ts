/**
 * The design drawn by ray marching its distance field on a full-screen quad. The shapes come in as uniform arrays (see uniforms in renderer.ts), so
 * changing a shape is a uniform update, never a recompile. `shapeDist` and `map` are kept line for line with sdf.ts.
 */
export declare const MODEL_VERTEX = "\nout vec2 vUv;\nvoid main() {\n  vUv = uv;\n  gl_Position = vec4(position.xy, 0.0, 1.0);\n}\n";
/** The shapes' pass: the field ray marched on a full-screen quad, writing colour and depth. */
export declare const MODEL_FRAGMENT: string;
/** Imported models: their triangles in world space, for the same shading as the shapes. */
export declare const MESH_VERTEX = "\nin vec3 aColor;\nuniform mat3 uNormalWorld;\nout vec3 vWorld;\nout vec3 vNormal;\nout vec2 vMeshUv;\nout vec3 vColor;\nvoid main() {\n  vec4 w = modelMatrix * vec4(position, 1.0);\n  vWorld = w.xyz;\n  vNormal = uNormalWorld * normal;\n  vMeshUv = uv;\n  vColor = aColor;\n  gl_Position = projectionMatrix * viewMatrix * w;\n}\n";
/** An imported model's surface: its colour (material, texture, vertex colour) or the shape's one colour, shaded like the shapes. */
export declare const MESH_FRAGMENT: string;
/** The toon outline round an imported model: its back faces pushed out a few pixels on screen, in the outline colour. */
export declare const HULL_VERTEX = "\nin vec3 aHull;\nuniform mat3 uNormalWorld;\nuniform float uOutline;\nuniform vec2 uRes;\nvoid main() {\n  vec4 clip = projectionMatrix * viewMatrix * modelMatrix * vec4(position, 1.0);\n  vec4 nclip = projectionMatrix * viewMatrix * vec4(normalize(uNormalWorld * aHull), 0.0);\n  vec2 dir = nclip.xy;\n  float l = length(dir);\n  dir = l > 1e-6 ? dir / l : vec2(0.0);\n  clip.xy += dir * (uOutline * uRes.y / 1000.0) * 2.0 / uRes * clip.w;\n  gl_Position = clip;\n}\n";
export declare const HULL_FRAGMENT = "\nprecision highp float;\nuniform vec3 uOutlineCol;\nout vec4 fragColor;\nvoid main() {\n  fragColor = vec4(pow(uOutlineCol, vec3(1.0 / 2.2)), 1.0);\n}\n";
