import type { SceneDocument } from './scene.js';
export interface SceneExportOptions {
    width: number;
    height: number;
    type?: 'image/png' | 'image/jpeg' | 'image/webp';
    quality?: number;
}
/**
 * Shows a scene document with Three.js: the display, the lighting, and the product image standing in it.
 *
 * The product is drawn unlit (exactly its own colours, no tone mapping) so the scene never changes how the item
 * looks; only the display around it is lit. It still casts a shadow shaped like its cut-out.
 */
export declare class SceneViewer {
    private readonly canvas;
    private readonly renderer;
    private readonly scene;
    private readonly camera;
    private readonly controls;
    private readonly ambient;
    private readonly key;
    private readonly item;
    private readonly front;
    private readonly back;
    private readonly base;
    private readonly contact;
    private stage;
    private stageKey;
    private doc;
    private texture;
    private dirty;
    private framed;
    private readonly startedAt;
    private vertexId;
    private vertexDef;
    private vertexUniforms;
    private composer;
    private effectKey;
    private effectPasses;
    private animated;
    constructor(canvas: HTMLCanvasElement);
    /** The product image; transparent areas (a cut-out) are see-through and cast no shadow. */
    setImage(image: TexImageSource): void;
    /** Applies a scene document. Cheap to call on every change: the display is only rebuilt when it changes. */
    update(doc: SceneDocument): void;
    /** Points the camera at the item from a slightly raised three-quarter view. */
    resetView(): void;
    /** Size of the canvas in CSS pixels; the drawing buffer follows the screen's pixel density. */
    resize(width: number, height: number): void;
    /** Renders the current view at an exact pixel size (independent of the on-screen size) and encodes it. */
    exportImage({ width, height, type, quality }: SceneExportOptions): Promise<Blob>;
    dispose(): void;
    private tick;
    /** Draws the scene, through the effect passes when there are any. */
    private renderFrame;
    private syncComposerSize;
    /** Brings the vertex shader and the effect passes in line with the document: rebuilt only when the choice changes, sliders update live. */
    private applyShaders;
    private applyVertex;
    private applyEffects;
}
