import { DocumentStore, type ShaderStep, type ShaderValue, type StoreSnapshot } from '../../core/src/index.js';
import { type SceneDocument } from './scene.js';
export type SceneSnapshot = StoreSnapshot<SceneDocument>;
/** Edits a scene document by path (`set('stage/template', 'shelf')`), with the same undo model as photos. */
export declare class SceneEditor extends DocumentStore<SceneDocument> {
    constructor(doc: SceneDocument);
    get effects(): readonly ShaderStep[];
    addEffect(id: string, params: Record<string, ShaderValue>, label?: string): void;
    removeEffect(index: number, label?: string): void;
    moveEffect(index: number, direction: 1 | -1): void;
    setEffectParam(index: number, key: string, value: ShaderValue, label?: string): void;
    /** Chooses the vertex shader that moves the product (or null for none). */
    setVertex(step: ShaderStep | null, label?: string): void;
    setVertexParam(key: string, value: ShaderValue, label?: string): void;
    /** Puts every setting back to its default, as one undoable step. */
    reset(): void;
}
