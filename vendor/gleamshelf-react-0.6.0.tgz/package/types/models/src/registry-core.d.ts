import type { ModelInfo } from './types';
/** The valid models among some parsed registry files, recommended ones first. A file that is not a valid model is skipped. */
export declare function parseRegistry(entries: Iterable<unknown>): ModelInfo[];
export declare function makeRegistry(models: ModelInfo[]): {
    MODELS: ModelInfo[];
    findModel: (id: string) => ModelInfo | undefined;
    modelsFor: (task: ModelInfo["task"]) => ModelInfo[];
};
