export declare const MODELS: import("./types").ModelInfo[], findModel: (id: string) => import("./types").ModelInfo | undefined, modelsFor: (task: import("./types").ModelInfo["task"]) => import("./types").ModelInfo[];
export * from './types';
export * from './local-client';
