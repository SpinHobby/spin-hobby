export type ModelTask = 'cutout' | 'inpaint' | 'text-detect' | 'text-read' | 'upscale' | 'redraw' | 'enhance';
/** Where a model can run. `local-server` is the companion app on the user's own computer. */
export type RunsOn = 'local-server' | 'browser' | 'hosted';
export interface ModelInfo {
    id: string;
    name: string;
    task: ModelTask;
    summary: string;
    /** Shown first, with a "recommended" mark. */
    recommended: boolean;
    license: {
        name: string;
        commercialUse: 'allowed' | 'check' | 'not-allowed';
        url: string;
    };
    sizeMb: number;
    runsOn: RunsOn[];
    links: {
        modelCard: string;
        download: string;
    };
    file: {
        name: string;
        bytes: number;
    };
    /** `size` is the square the model works at (a fixed 512 for the fill model; the detector takes any size in steps of 32). */
    input: {
        size: number;
        mean: [number, number, number];
        std: [number, number, number];
    };
    /**
     * `logits-mask`: one channel of raw scores, 0 and above means product (cut-out). `image`: a repainted picture (fill).
     * `probability-map`: how likely each pixel is text (text finder).
     */
    output: 'logits-mask' | 'image' | 'probability-map';
}
/** What the companion app says about one model it knows. */
export interface LocalModelStatus extends Pick<ModelInfo, 'id' | 'name' | 'task' | 'sizeMb'> {
    installed: boolean;
}
export interface LocalHealth {
    ok: true;
    app: 'gleamshelf-local';
    version: string;
    /** What the app can do beyond the models: 'process' is the whole listing chain as a background job. Absent on older apps. */
    features?: string[];
}
