/**
 * The sound side of the avatar's voice, as pure code: recordings made smaller and written as WAV files for the speech-to-text model, and the
 * hands-free gate that hears where a sentence starts and ends (by loudness against the room's own noise), so nothing has to be held down.
 */
/** The rate the speech-to-text model listens at. */
export declare const LISTEN_RATE = 16000;
/** Joins recorded chunks into one recording. */
export declare function joinChunks(chunks: readonly Float32Array[]): Float32Array;
/** A recording at a lower rate: each new sample the average of the old ones it covers (which also keeps out sounds too high for the new rate). */
export declare function downsample(samples: Float32Array, from: number, to?: number): Float32Array;
/** A mono 16-bit WAV file of `samples` (-1..1). */
export declare function encodeWav(samples: Float32Array, rate: number): ArrayBuffer;
/** How loud a chunk is (root mean square, 0-1). */
export declare function rms(chunk: Float32Array): number;
export interface GateOptions {
    /** How long the voice must be on before a sentence counts as started. */
    startMs?: number;
    /** How long a pause ends the sentence. */
    pauseMs?: number;
    /** Sound kept from just before the start (the first sound of a word is quiet). */
    beforeMs?: number;
    /** Shorter sentences are dropped (a cough, a click). */
    shortestMs?: number;
    /** A sentence this long is sent as it is, even without a pause. */
    longestMs?: number;
}
/**
 * Hands-free listening: fed the mic's chunks, it answers a whole sentence when it hears one end. The voice counts as on when it is clearly
 * louder than the room's noise, which it learns as it goes (the quietest it has been lately), so a fan or a noisy shop does not keep it open.
 */
export declare class SpeechGate {
    private readonly o;
    private noise;
    private loudFor;
    private quietFor;
    private open;
    private kept;
    private keptMs;
    private before;
    private beforeMs;
    constructor(options?: GateOptions);
    /** Whether a sentence is being heard now. */
    get hearing(): boolean;
    /** How loud the voice must be to count, now. */
    get threshold(): number;
    /** Forgets what it was hearing (the avatar started talking, or the mic went off). */
    reset(): void;
    /** One chunk of the mic at `rate`; returns a finished sentence (at the same rate) when one has just ended. */
    push(chunk: Float32Array, rate: number): Float32Array | null;
}
/**
 * The live voice's chunks: the mic's buffers (any rate) cut into chunks of exactly `size` samples at LISTEN_RATE. Each new sample is the average
 * of the mic's samples it covers, and the fraction of a sample left over is carried to the next buffer, so no sound is lost or doubled.
 */
export declare class LiveChunker {
    readonly size: number;
    private raw;
    private at;
    private out;
    constructor(size?: number);
    push(samples: Float32Array, rate: number): Float32Array[];
    reset(): void;
}
/**
 * What a Web Audio AnalyserNode's getByteFrequencyData would give for the `fftSize` samples ending at `at` seconds: a Blackman window, an FFT,
 * decibels from -100 to -30 as 0-255, and the same smoothing over time (pass the last call's result as `before`). For videos made frame by
 * frame, faster than real time, where no AnalyserNode can listen; the lips then come from `visemes` exactly as they do live.
 */
export declare function byteSpectrum(samples: Float32Array, rate: number, at: number, fftSize?: number, before?: Float32Array | null, smoothing?: number): {
    bytes: Uint8Array;
    magnitudes: Float32Array;
};
/** Names a hobby shop says, given to the speech-to-text model so it spells them right (the voice model already knows how to say them). */
export declare const SHOP_NAMES: readonly ["Spin Hobby", "Nendoroid", "figma", "Gunpla", "Gundam", "Bandai", "Banpresto", "Kotobukiya", "Good Smile", "Max Factory", "Hatsune Miku", "Pokémon", "Sanrio", "Kuromi", "Chiikawa", "Labubu", "Pop Mart", "Funko", "Ichiban Kuji", "gacha", "plushie"];
/**
 * The shop's own word list, one a line: a name to spell right ("Tamashii Nations"), or a name and how it sounds in ordinary letters
 * ("Gunpla = GUN plah"; capitals mark the stressed part). Answers the names for the speech-to-text model and the sounds for the voice.
 */
export declare function parseShopWords(text: string): {
    names: string[];
    sounds: Record<string, string>;
};
