import { IDENTITY } from './math.js';
import type { AvatarPose, ExpressionName } from './rig.js';
/**
 * The avatar's own motion: gestures played on a key or a button (wave, nod, point, heart...), set over the tracked pose; idle breathing,
 * sway and blinks when nothing tracks it; and lip-sync from a voice's sound. Pure code: functions of time and sound.
 */
export declare const GESTURES: {
    readonly wave: {
        readonly label: "Wave";
        readonly key: "1";
        readonly seconds: 2.2;
    };
    readonly nod: {
        readonly label: "Nod";
        readonly key: "2";
        readonly seconds: 1.2;
    };
    readonly shake: {
        readonly label: "Shake head";
        readonly key: "3";
        readonly seconds: 1.2;
    };
    readonly thumbsUp: {
        readonly label: "Thumbs up";
        readonly key: "4";
        readonly seconds: 1.8;
    };
    readonly point: {
        readonly label: "Point";
        readonly key: "5";
        readonly seconds: 1.8;
    };
    readonly heart: {
        readonly label: "Heart hands";
        readonly key: "6";
        readonly seconds: 2.2;
    };
    readonly bow: {
        readonly label: "Bow";
        readonly key: "7";
        readonly seconds: 2;
    };
    readonly cheer: {
        readonly label: "Cheer";
        readonly key: "8";
        readonly seconds: 1.8;
    };
};
export type GestureName = keyof typeof GESTURES;
export declare const GESTURE_NAMES: GestureName[];
/** In over the first part, out over the last: how much of the gesture shows at `t` (0-1). */
export declare const envelope: (t: number, edge?: number) => number;
/** A gesture's pose at `t` (0-1 of the gesture), with how strongly it shows. Right-handed gestures use the avatar's right arm. */
export declare function gestureAt(name: GestureName, t: number): {
    pose: AvatarPose;
    weight: number;
};
/** How shut the eyes are at time `t` (seconds) when nothing tracks them: a blink every 2.5-6 seconds, sometimes a double one. */
export declare function idleBlink(t: number): number;
/** Breathing and a little sway: added to whatever else moves the avatar. */
export declare function idleMotion(t: number): AvatarPose['bones'];
/**
 * The five mouth shapes from a voice's sound: how loud it is opens the mouth, and where its energy sits (low or high in the spectrum) picks the
 * shape: low and round for "oh" and "oo", high and wide for "ee" and "ih", in between for "ah". `bins` is an AnalyserNode's byte frequency data.
 */
export declare function visemes(bins: Uint8Array | readonly number[], sampleRate: number, fftSize: number): Partial<Record<ExpressionName, number>>;
export { IDENTITY };
