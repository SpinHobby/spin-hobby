/** Small vector and quaternion maths for the rig (pure, so the solver runs and is tested without Three.js). Quaternions are [x, y, z, w]. */
export type Vec3 = [number, number, number];
export type Quat = [number, number, number, number];
export declare const IDENTITY: Quat;
export declare const sub: (a: Vec3, b: Vec3) => Vec3;
export declare const add: (a: Vec3, b: Vec3) => Vec3;
export declare const scale: (a: Vec3, k: number) => Vec3;
export declare const dot: (a: Vec3, b: Vec3) => number;
export declare const cross: (a: Vec3, b: Vec3) => Vec3;
export declare const length: (a: Vec3) => number;
export declare const normalize: (a: Vec3) => Vec3;
export declare const clamp01: (v: number) => number;
/** `v` from [lo, hi] to [0, 1], clamped. */
export declare const ramp: (v: number, lo: number, hi: number) => number;
export declare function qMul(a: Quat, b: Quat): Quat;
export declare const qConj: (q: Quat) => Quat;
export declare function qNorm(q: Quat): Quat;
/** A turn of `deg` degrees about an axis. */
export declare function qAxis(axis: Vec3, deg: number): Quat;
/** Euler degrees about x, then y, then z (applied in that order, as Three.js's 'XYZ'). */
export declare function qEuler(x: number, y: number, z: number): Quat;
/** The smallest turn that takes direction `from` to direction `to`. */
export declare function qFromTo(from: Vec3, to: Vec3): Quat;
export declare function qRotate(q: Quat, v: Vec3): Vec3;
/** Spherical blend from a to b by t. */
export declare function qSlerp(a: Quat, b: Quat, t: number): Quat;
/** A quaternion from the rotation part of a 4x4 matrix stored column by column (as MediaPipe and Three.js keep them). */
export declare function qFromMatrix(m: readonly number[]): Quat;
/** A turn mirrored left for right (across the plane x = 0). */
export declare const qMirror: (q: Quat) => Quat;
/** The angle of a turn, in degrees. */
export declare const qAngle: (q: Quat) => number;
