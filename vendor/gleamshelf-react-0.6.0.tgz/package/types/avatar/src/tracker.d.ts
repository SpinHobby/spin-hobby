import type { TrackFrame } from './rig.js';
export interface TrackOptions {
    face?: boolean;
    body?: boolean;
    hands?: boolean;
}
export declare class Tracker {
    private readonly face;
    private readonly pose;
    private readonly hands;
    private running;
    private lastVideoTime;
    private handle;
    private constructor();
    /** Loads the models asked for (face at least), on the graphics card where it can. */
    static create(options?: TrackOptions, onProgress?: (step: string) => void): Promise<Tracker>;
    /** Tracks every new frame of the video until stop(), handing each frame's result to `onFrame`. */
    start(video: HTMLVideoElement, onFrame: (frame: TrackFrame, now: number) => void): void;
    /** One frame's tracking. */
    detect(source: HTMLVideoElement | HTMLImageElement | HTMLCanvasElement, now: number): TrackFrame;
    stop(): void;
    dispose(): void;
}
