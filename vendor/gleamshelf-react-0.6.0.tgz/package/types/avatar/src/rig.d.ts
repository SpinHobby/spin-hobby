import { type Quat, type Vec3 } from './math.js';
/**
 * From webcam tracking to the avatar: MediaPipe's face blendshapes and head matrix become VRM expressions, a gaze and a head turn; its body
 * points become the spine and arm bones; its hand points become finger curls. Everything is mirrored by default (the avatar moves like a mirror
 * of the person). Pure code: the stage (stage.ts) applies the result to the VRM's normalized bones.
 *
 * Bones are VRM humanoid names; their rotations are local to the parent bone, in the normalized rig (rest pose: T-pose, facing +Z, the avatar's
 * left at +X, y up).
 */
export declare const EXPRESSIONS: readonly ["happy", "angry", "sad", "relaxed", "surprised", "aa", "ih", "ou", "ee", "oh", "blinkLeft", "blinkRight"];
export type ExpressionName = (typeof EXPRESSIONS)[number];
export type BoneName = 'hips' | 'spine' | 'chest' | 'upperChest' | 'neck' | 'head' | `${'left' | 'right'}${'Shoulder' | 'UpperArm' | 'LowerArm' | 'Hand'}` | `${'left' | 'right'}${'Thumb' | 'Index' | 'Middle' | 'Ring' | 'Little'}${'Metacarpal' | 'Proximal' | 'Intermediate' | 'Distal'}`;
export interface AvatarPose {
    expressions: Partial<Record<ExpressionName, number>>;
    bones: Partial<Record<BoneName, Quat>>;
    /** Where the eyes look, degrees (yaw to the avatar's left is positive, pitch up is positive). */
    lookAt?: {
        yaw: number;
        pitch: number;
    };
}
export interface Landmark {
    x: number;
    y: number;
    z: number;
    visibility?: number;
}
/** One frame of tracking. Body and hand points are MediaPipe world points (metres; x to the image's right, y down, z away from the camera). */
export interface TrackFrame {
    face?: {
        blendshapes: Record<string, number>;
        matrix?: readonly number[];
    };
    pose?: readonly Landmark[];
    /** The person's own left and right hands. */
    leftHand?: readonly Landmark[];
    rightHand?: readonly Landmark[];
}
export declare const emptyPose: () => AvatarPose;
/** Expressions, gaze and head from the face's 52 blendshapes and its head matrix. */
export declare function solveFace(face: NonNullable<TrackFrame['face']>, mirror?: boolean): AvatarPose;
/** A MediaPipe world point in the avatar's space (y up, toward the camera +z), mirrored or not. */
export declare const toAvatarSpace: (p: Landmark, mirror: boolean) => Vec3;
/** Arms resting by the sides: the rest pose when an arm is not seen (the T-pose looks wrong on camera). */
export declare function armsDown(): Partial<Record<BoneName, Quat>>;
/** The spine's lean and the arms from the body's points (upper body only; the hips stay put). */
export declare function solveBody(pose: readonly Landmark[], mirror?: boolean, minVisibility?: number): AvatarPose['bones'];
/**
 * The avatar's fingers from one hand's 21 points: each joint bends by the angle the person's finger bends (fingers curl toward the palm:
 * about -Z on the left hand, +Z on the right in the rest pose; the thumb about Y).
 */
export declare function solveHand(hand: readonly Landmark[], avatarSide: 'left' | 'right'): AvatarPose['bones'];
/** The avatar's pose from one frame of tracking; parts not seen are left out (the stage keeps them as they were, or at rest). */
export declare function solveFrame(frame: TrackFrame, mirror?: boolean): AvatarPose;
/**
 * Smooths poses over time so the avatar does not jitter: each value moves part of the way to the new one each frame (more when it moves fast,
 * so quick motions are not dragged).
 */
export declare class PoseSmoother {
    private readonly amount;
    private current;
    constructor(amount?: number);
    next(target: AvatarPose): AvatarPose;
    reset(): void;
}
/** One pose over another: `top`'s values replace `base`'s by `weight` (0-1); expressions blend the same way. */
export declare function blendPose(base: AvatarPose, top: AvatarPose, weight: number): AvatarPose;
