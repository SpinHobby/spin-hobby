import { type AvatarPose } from './rig.js';
/**
 * The avatar on screen: a VRM drawn with Three.js and three-vrm, posed every frame from an AvatarPose (driver.ts), with springy hair and
 * clothes, a backdrop (see-through, a colour, green screen for a colour key, or a picture), its parts recoloured, and the canvas able to move
 * into a pop-out window for streaming software to capture.
 */
export type Backdrop = {
    kind: 'clear';
} | {
    kind: 'colour';
    colour: string;
} | {
    kind: 'picture';
    url: string;
};
export type Framing = 'face' | 'bust' | 'body';
/** A part of the avatar to recolour: the materials that share a role, by VRoid's naming (Hair, EyeIris, Tops, ...). */
export interface AvatarPart {
    id: string;
    label: string;
    colour: string;
}
/** What the VRM file says about itself, its licence included. */
export interface AvatarInfo {
    name: string;
    authors: string[];
    licenceUrl: string | null;
    /** Who may use the avatar as theirs, and whether commercial use is allowed (from the file's own licence). */
    avatarPermission: string | null;
    commercialUse: string | null;
    allowsCommercial: boolean;
    parts: AvatarPart[];
    /** VRM 0.x files face the other way and are turned at load. */
    version: '0' | '1';
}
export declare class AvatarStage {
    private container;
    private readonly options;
    readonly canvas: HTMLCanvasElement;
    private readonly renderer;
    private readonly scene;
    private readonly camera;
    private vrm;
    private pose;
    private framing;
    private host;
    private frame;
    private last;
    private readonly resize;
    private onFrame;
    private backdropTexture;
    /**
     * `manual`: no loop of its own and no fitting to the container: each frame is drawn by `renderFrame` at a given size (a video being made
     * frame by frame, faster or slower than real time).
     */
    constructor(container: HTMLElement, options?: {
        manual?: boolean;
    });
    /** Manual stages: draws one frame of `pose`, `dt` seconds after the last (springy hair and clothes move on by that much), at width x height. */
    renderFrame(pose: AvatarPose, dt: number, width: number, height: number): HTMLCanvasElement;
    /** Loads a VRM (a file's bytes, or its URL): the avatar shown from now on. */
    load(source: ArrayBuffer | string): Promise<AvatarInfo>;
    private info;
    /** The avatar's materials, grouped into parts to recolour, each with the colour it shows now (its colour times its picture's). */
    private parts;
    /**
     * Recolours every material of a part so it shows `colour`: its picture's own colour is divided out, so a brown hair texture turned blue
     * looks the blue picked, not brown times blue. Its shade colour stays as dark relative to the lit colour as before.
     */
    recolour(partId: string, colour: string): void;
    /** The pose shown from the next frame on. */
    setPose(pose: AvatarPose): void;
    /** Asked every frame for the pose (the driver composes tracking, gestures and idle motion), before it is drawn. */
    drive(onFrame: ((now: number) => AvatarPose | null) | null): void;
    setFraming(framing: Framing): void;
    setBackdrop(b: Backdrop): void;
    /** Moves the canvas into another window (a pop-out for streaming software) and draws on that window's clock; back with `null`. */
    attach(target: HTMLElement | null): void;
    /** The canvas as a picture (PNG). */
    snapshot(): Promise<Blob>;
    private frameCamera;
    private fit;
    /** A backdrop picture fills the view, cut to fit, centred. */
    private fitBackdrop;
    private apply;
    private loop;
    dispose(): void;
}
