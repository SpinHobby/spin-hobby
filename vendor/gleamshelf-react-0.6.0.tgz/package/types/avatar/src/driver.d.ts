import { type GestureName } from './motion.js';
import { type AvatarPose, type ExpressionName, type TrackFrame } from './rig.js';
export declare class AvatarDriver {
    private tracked;
    private trackedAt;
    private readonly smoother;
    private gestures;
    private held;
    private lips;
    mirror: boolean;
    /** A frame of webcam tracking. */
    track(frame: TrackFrame, now: number): void;
    /** Forgets the tracking (the camera was turned off). */
    untrack(): void;
    play(name: GestureName, now: number): void;
    /** Holds a mood (happy, sad...) at a strength (0 lets go); the face still blinks and talks. */
    hold(name: ExpressionName, amount: number): void;
    /** The mouth from a voice's sound (visemes in motion.ts); null when no voice drives it. */
    speak(shapes: Partial<Record<ExpressionName, number>> | null): void;
    get isTracking(): boolean;
    /** The pose at `now` (milliseconds, the same clock as `track` and `play`). */
    compose(now: number): AvatarPose;
}
