import './edit.css';
/** A picture to open as a layer, bottom first. */
export interface EditLayerInput {
    name: string;
    picture: CanvasImageSource & {
        width: number;
        height: number;
    };
    x?: number;
    y?: number;
}
export type EditOpen = {
    kind: 'blank';
    width: number;
    height: number;
    background?: string | null;
} | {
    kind: 'pictures';
    width: number;
    height: number;
    background?: string | null;
    layers: EditLayerInput[];
} | {
    kind: 'project';
    file: unknown;
};
export interface EditModeProps {
    open: EditOpen;
    title?: string;
    /** Hands the finished picture (PNG, canvas size) back to the host. Without it, Edit mode only exports. */
    onDone?: (picture: Blob) => void;
    doneLabel?: string;
    onClose: () => void;
}
export declare function EditMode({ open, title, onDone, doneLabel, onClose }: EditModeProps): import("react").JSX.Element;
