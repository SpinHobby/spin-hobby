/** Edit mode's tools, grouped as the dock shows them, each with its key, a one-line hint shown while it is picked, and a line for developers. */
export type ToolId = 'move' | 'crop' | 'hand' | 'zoom' | 'box' | 'oval' | 'lasso' | 'wand' | 'brush' | 'eraser' | 'clone' | 'bucket' | 'gradient' | 'dropper' | 'rect' | 'ellipse' | 'line' | 'pen' | 'text';
export interface ToolDef {
    id: ToolId;
    label: string;
    /** The key that picks it (Shift+key where `shift`). */
    key: string;
    shift?: boolean;
    hint: string;
    /** For developers: what the tool calls, and the command that does the same headless (docs/MCP.md). */
    dev: string;
}
export declare const TOOL_GROUPS: readonly {
    name: string;
    tools: readonly ToolDef[];
}[];
export declare const TOOLS: readonly ToolDef[];
export declare const toolDef: (id: ToolId) => ToolDef;
