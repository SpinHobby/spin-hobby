import type { ReactElement } from 'react';
/** Edit mode's tool icons: plain line drawings on a 24-unit grid, drawn in the current text colour. */
declare const paths: Record<string, ReactElement>;
export declare function Icon({ name, size, title }: {
    name: keyof typeof paths | string;
    size?: number;
    title?: string;
}): import("react").JSX.Element;
export {};
