import type { ParamSpec, ShaderStep, ShaderValue } from '../../core/src/index.js';
import { defaultParams, type ShaderDef } from '../../shaders/src/index.js';
/** What the controls need from whoever owns the list (a photo editor or a scene editor). */
export interface ShaderListHandlers {
    onAdd: (def: ShaderDef) => void;
    onRemove: (index: number) => void;
    onMove: (index: number, direction: 1 | -1) => void;
    onParam: (index: number, key: string, value: ShaderValue, label: string) => void;
    /** A drag or a colour pick starts / ends: the owner makes the whole gesture one undo step. */
    onBegin: (label: string) => void;
    onCommit: () => void;
}
interface FieldProps {
    spec: ParamSpec;
    value: ShaderValue;
    onChange: (value: ShaderValue) => void;
    onBegin: () => void;
    onCommit: () => void;
}
/** One slider, toggle, colour or list, made from a shader's own description of its parameter. */
export declare function ShaderField({ spec, value, onChange, onBegin, onCommit }: FieldProps): import("react").JSX.Element;
interface ListProps extends ShaderListHandlers {
    steps: readonly ShaderStep[];
    /** Everything that may be added. A step whose shader is not in `known` (a file that was removed) is shown greyed out. */
    catalog: readonly ShaderDef[];
    known: (id: string) => ShaderDef | undefined;
    title: string;
    /** What to say when nothing is added yet. */
    empty: string;
}
/** The effects added to a photo or scene, each with its sliders, and a menu to add more from the shaders folder. */
export declare function ShaderList({ steps, catalog, known, title, empty, onAdd, onRemove, onMove, onParam, onBegin, onCommit }: ListProps): import("react").JSX.Element;
export { defaultParams };
