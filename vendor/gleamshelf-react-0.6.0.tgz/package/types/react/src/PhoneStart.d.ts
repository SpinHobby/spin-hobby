import './gleamshelf.css';
/**
 * A "From phone" button for a host's own start screen, before any photo is open: the same QR panel as the editor's, and the photo picked there is handed to
 * `onOpen`. Renders nothing until the Gleamshelf app is found on this computer and can take phone photos.
 */
export declare function PhoneStart({ onOpen, className, label, }: {
    onOpen: (photo: Blob, name: string) => void;
    className?: string;
    label?: string;
}): import("react").JSX.Element | null;
