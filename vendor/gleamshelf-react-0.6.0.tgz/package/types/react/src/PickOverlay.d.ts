import { type Editor } from '../../core/src/index.js';
interface Props {
    editor: Editor;
    /** On-screen size of the finished image the overlay covers. */
    width: number;
    height: number;
    /** Called with the point clicked, as fractions (0-1) of the original photo. */
    onPick: (x: number, y: number) => void;
}
/** Waits for one click on the preview and reports where it landed on the original photo, whatever the crop or turn. */
export declare function PickOverlay({ editor, width, height, onPick }: Props): import("react").JSX.Element;
export {};
