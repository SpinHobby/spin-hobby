import './photolab.css';
/**
 * Photo lab: hand editing on one photo. The photo opens in PhotoCraft's engine (layers, selections, retouching, every filter and adjustment)
 * and LightCraft's develop pipeline, both running as WebAssembly in a worker (@gleamshelf/craft). The screen is ours: a rail of panels, the
 * photo in the middle, and every change goes through one engine command, so undo, history and saving to PSD all just work.
 */
export interface PhotoLabProps {
    /** The photo to open (any picture the browser can draw). */
    picture: Blob | ImageBitmap;
    title?: string;
    doneLabel?: string;
    /** The result as a PNG. */
    onDone: (png: Blob) => void;
    onClose: () => void;
}
export declare function PhotoLab({ picture, title, doneLabel, onDone, onClose }: PhotoLabProps): import("react").JSX.Element;
