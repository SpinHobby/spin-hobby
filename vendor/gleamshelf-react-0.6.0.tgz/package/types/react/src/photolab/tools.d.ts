/**
 * Photo lab's pointer tools. Each one turns what the pointer did on the photo (a drag, a stroke, a click, a line) into one engine command
 * (packages/craft: every id below is a PhotoCraft command run through Craft.execute), with a one-line hint shown while it is picked and a line
 * for developers.
 */
/** What the pointer does with the tool: drag a box, paint a stroke, draw round something, click once, drag a line, or move the view. */
export type Gesture = 'box' | 'stroke' | 'lasso' | 'click' | 'line' | 'pan';
export type LabToolId = 'hand' | 'crop' | 'dropper' | 'box' | 'oval' | 'lasso' | 'quick' | 'object' | 'wand' | 'remove' | 'spot' | 'heal' | 'clone' | 'redEye' | 'dodge' | 'burn' | 'sponge' | 'soften' | 'crisp' | 'smudge' | 'shift' | 'patch' | 'brush' | 'pencil' | 'eraser' | 'bgEraser' | 'magicEraser' | 'bucket' | 'gradient' | 'mixer' | 'recolour';
/** Settings the tool options bar shows for the picked tool. */
export type ToolOption = 'size' | 'hardness' | 'opacity' | 'flow' | 'tolerance' | 'mode' | 'colors';
export interface LabTool {
    id: LabToolId;
    label: string;
    group: 'View' | 'Select' | 'Retouch' | 'Paint';
    gesture: Gesture;
    /** The engine command it runs (none for the view tools). */
    command?: string;
    options: readonly ToolOption[];
    /** Alt-click sets where it copies from first. */
    source?: boolean;
    /** Needs a selection to work on. */
    needsSelection?: boolean;
    hint: string;
    dev: string;
}
export declare const LAB_TOOLS: readonly LabTool[];
export declare const LAB_TOOL_GROUPS: readonly ["View", "Select", "Retouch", "Paint"];
/** Selection modes the options bar offers, and the keys that pick them while dragging. */
export declare const SELECT_MODES: readonly [{
    readonly id: "replace";
    readonly label: "New";
}, {
    readonly id: "add";
    readonly label: "Add (Shift)";
}, {
    readonly id: "subtract";
    readonly label: "Take away (Alt)";
}, {
    readonly id: "intersect";
    readonly label: "Overlap";
}];
export type SelectMode = (typeof SELECT_MODES)[number]['id'];
