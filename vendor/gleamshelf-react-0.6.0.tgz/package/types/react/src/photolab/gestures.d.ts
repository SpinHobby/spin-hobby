import type { LabTool, SelectMode } from './tools';
/** What the pointer did, in document pixels. */
export type GestureInput = {
    kind: 'box';
    x0: number;
    y0: number;
    x1: number;
    y1: number;
} | {
    kind: 'stroke' | 'lasso';
    points: [number, number][];
} | {
    kind: 'click';
    x: number;
    y: number;
} | {
    kind: 'line';
    x0: number;
    y0: number;
    x1: number;
    y1: number;
};
export interface ToolSettings {
    size: number;
    /** 0-1. */
    hardness: number;
    /** 0-1. */
    opacity: number;
    /** 0-1. */
    flow: number;
    tolerance: number;
    mode: SelectMode;
    paint: string;
    second: string;
    /** Where Heal and Copy paint copy from (Alt-click). */
    source: [number, number] | null;
}
export declare const DEFAULT_TOOL_SETTINGS: ToolSettings;
/** The engine command (id and parameters) a gesture with `tool` makes, or an error to show when it can't run yet. */
export declare function gestureCommand(tool: LabTool, g: GestureInput, s: ToolSettings): {
    id: string;
    params: Record<string, unknown>;
} | {
    error: string;
};
/** Shift adds and Alt takes away while selecting, as the hints say. */
export declare function modeFor(base: SelectMode, e: {
    shiftKey: boolean;
    altKey: boolean;
}): SelectMode;
