import { type Editor, type PhotoDocument } from '../../core/src/index.js';
export type CutoutTool = 'tap' | 'erase' | 'restore';
export interface CutoutSettings {
    tool: CutoutTool;
    /** Brush radius as a fraction of the photo's longest side. */
    brush: number;
    /** 0–100, for taps. */
    tolerance: number;
}
interface Props {
    editor: Editor;
    doc: PhotoDocument;
    settings: CutoutSettings;
    /** On-screen size of the finished image the overlay covers. */
    width: number;
    height: number;
}
/**
 * Captures cut-out input over the preview: a tap removes the touched background region, a drag erases or
 * restores along the stroke. Screen positions are mapped back to the original photo, so crop and rotation
 * don't matter. Each tap or stroke is one undo step.
 */
export declare function CutoutOverlay({ editor, doc, settings, width, height }: Props): import("react").JSX.Element;
export {};
