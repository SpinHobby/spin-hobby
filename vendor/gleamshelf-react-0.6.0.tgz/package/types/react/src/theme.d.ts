/**
 * The theme's colours (theme.css) for what is drawn on a canvas, where CSS variables cannot reach: Edit mode's selection and handles, Photo
 * lab's marks, the see-through checkerboards. Read from the page, so a new theme (or a host's own values) is used.
 */
export interface CanvasTheme {
    bg: string;
    tint: string;
    shade: string;
    accent3: string;
    focus: string;
    /** Selection lines and handles drawn over a picture. */
    select: string;
    handle: string;
    /** The see-through checkerboard of the dark editors, and the light one behind a design's page in Edit mode. */
    checkerA: string;
    checkerB: string;
    pageCheckerA: string;
    pageCheckerB: string;
    /** Text, quieter text, the accent and text on it, and the stage behind a 3D view: for product videos' titles, captions and backgrounds. */
    text: string;
    muted: string;
    accent: string;
    onAccent: string;
    stage: string;
}
/** The theme's colours as they apply at `el` (the page's when left out). */
export declare function canvasTheme(el?: Element | null): CanvasTheme;
/** A theme colour (#rgb or #rrggbb) see-through by `alpha` (0-1), as a canvas takes it. */
export declare function withAlpha(colour: string, alpha: number): string;
