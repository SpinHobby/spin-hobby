import { type Editor, type PhotoDocument } from '../../core/src/index.js';
import { type CSSProperties, type ReactNode } from 'react';
import type { AutoWatch } from './GleamEditor';
import type { CutoutSettings } from './CutoutOverlay';
interface Props {
    editor: Editor;
    doc: PhotoDocument;
    cropping: boolean;
    onToggleCrop: () => void;
    cutout: boolean;
    onToggleCutout: () => void;
    cutSettings: CutoutSettings;
    onCutSettings: (change: Partial<CutoutSettings>) => void;
    /** Frames the cut-out product on a square canvas. Only offered once something is cut out. */
    onFitProduct: () => void;
    /** White background, centred on a square, soft shadow: a listing-ready picture in one click. */
    onStudio?: () => void;
    /** Straightens a card or box front photographed at an angle, from its cut-out's four corners. */
    flatten?: {
        run: () => void;
        busy: boolean;
        note: string | null;
    };
    /** Every marketplace's picture from this one cut-out, saved together as a zip. */
    listingSet?: {
        run: (presetIds: string[]) => void;
        busy: boolean;
        note: string | null;
    };
    /** Called with a photo the user chose to put behind the product. */
    onBackgroundPhoto: (file: File) => void;
    /** Whether a background photo is loaded, so choosing "Photo" has something to show. */
    hasBackgroundPhoto: boolean;
    backgroundName?: string;
    /** The AI cut-out controls, shown under the cut-out tools. */
    aiCutout?: ReactNode;
    hasCutout?: boolean;
    /** Whether the lettering is being worked out right now, and how many pixels it painted over. */
    lettering?: {
        busy: boolean;
        filled: number;
        aiReady: boolean;
    };
    /** Turns the lettering removal on, and fills with AI straight away when a fill model is available. */
    onRemoveLettering?: () => void;
    /** Whether AI steps also make the picture brighter and sharper, and how to change that. */
    autoEnhance?: boolean;
    onAutoEnhance?: (on: boolean) => void;
    /** The AI fill controls, shown under the lettering settings. */
    aiFill?: ReactNode;
    /** The AI sharpen-and-enlarge controls, shown in the Look section. */
    aiEnlarge?: ReactNode;
    /** The AI redraw controls (complete the antenna, redraw an area), shown in their own section. */
    aiFinish?: ReactNode;
    /** The price sticker button. */
    stickers?: {
        run: () => void;
        busy: boolean;
        note: string | null;
        picking: boolean;
        setPicking: (on: boolean) => void;
        pickingText?: boolean;
        setPickingText?: (on: boolean) => void;
    };
    /** Opens the guide to every feature. */
    onOpenGuide?: () => void;
    /** The one-button chain. */
    auto?: {
        run: () => void;
        busy: boolean;
        mode: 'product' | 'character' | 'auto';
        setMode: (mode: 'product' | 'character' | 'auto') => void;
        steps: {
            label: string;
            state: 'todo' | 'running' | 'done' | 'skipped';
            note?: string;
            startedAt?: number;
            seconds?: number;
        }[] | null;
        /** A run in the companion app: its signs of life, for the live indicator. */
        watch?: AutoWatch | null;
        /** How the last run ended when it did not finish (failed, or stopped by the person), and how to clear that. */
        end?: {
            kind: 'failed' | 'stopped';
            message: string;
        } | null;
        dismissEnd?: () => void;
        /** The slow extra sharpening with the tile model: whether it is set up, and whether it is switched on. */
        detail?: {
            available: boolean;
            on: boolean;
            set: (on: boolean) => void;
        };
        /** Studio gloss: the product redrawn by AI. Off unless ticked; it changes the product. */
        gloss?: {
            available: boolean;
            on: boolean;
            set: (on: boolean) => void;
        };
        appReady: boolean;
        greenBackdrop: boolean;
        /** The app can run the whole chain itself (the same as the batch command): its options, and what the last run reported. */
        full?: {
            available: boolean;
            /** Every step of the chain, in order, each switchable and on by default. */
            steps: {
                key: string;
                label: string;
                title: string;
                on: boolean;
                disabled: boolean;
            }[];
            setStep: (key: string, on: boolean) => void;
            report: {
                notes: string[];
                flags: string[];
                modeUsed: string;
                lookup?: {
                    state: 'off' | 'found' | 'no-match' | 'no-pictures';
                    read: string | null;
                    detail: string;
                };
                listing: {
                    title: string;
                    description: string;
                    category: string;
                    series: string | null;
                    highlights: string[];
                    unsupported: string[];
                    unverifiedNumbers: string[];
                    sources: string[];
                } | null;
                quality?: {
                    cutout: {
                        score: number;
                        reasons: string[];
                    };
                    fidelity: {
                        original: number;
                    };
                };
                health?: {
                    score: number;
                    level: 'good' | 'fair' | 'poor';
                    checks: {
                        id: string;
                        ok: boolean;
                        label: string;
                    }[];
                    fixes: string[];
                };
                changesUrl?: string;
                /** The app's id for this run: what is sent to the shop. */
                runId?: string;
            } | null;
            /** Set while the picture open is the chain's result: goes back to the photo as it was. */
            goBack?: () => void;
            /** Finished runs the app kept: each opens again instantly (no waiting, no internet). */
            recent?: {
                runs: {
                    id: string;
                    title: string;
                    finishedAt: number;
                    health: number | null;
                    thumb?: string;
                }[];
                open: (id: string) => void;
            };
            /** The connected shop: a finished run goes there as a draft (see ShopSend). Missing when the app cannot send to a shop. */
            shop?: ShopLinkProps;
            /** Opens 3D mode's ad maker with the run's cut-out, title and series. Missing when the run kept no cut-out. */
            makeAd?: () => Promise<void>;
            /** What the run found online: shown before any of it is used, while the run waits for the person (see FoundPhotos). */
            found?: FoundPhotosProps | null;
        };
    };
}
export interface FoundPhotosProps {
    identity: {
        printedTitle: string | null;
        character: string | null;
        franchise: string | null;
        maker?: string | null;
        variant?: string | null;
    } | null;
    photos: {
        index: number;
        purpose: 'product' | 'unboxed';
        linesUp: boolean;
        shows?: 'box' | 'figure';
        inliers: number;
        page?: string;
        title?: string;
        thumb?: string;
    }[];
    ticked: number[];
    /** The run waits for the choice; false once it has gone. */
    waiting: boolean;
    toggle: (index: number) => void;
    use: () => void;
    skip: () => void;
}
type ShopStatus = {
    connected: false;
} | {
    connected: true;
    url: string;
    label: string;
    answering: boolean;
};
interface ShopLinkProps {
    status: () => Promise<ShopStatus>;
    connect: (address: string, code: string) => Promise<{
        url: string;
        label: string;
    }>;
    send: (id: string) => Promise<{
        sent: 'new' | 'replaced' | 'kept';
        status: string;
        shop: string;
    }>;
}
export declare function Panel(props: Props): import("react").JSX.Element;
/** How far along a slider is, for its filled track (see the range styles in gleamshelf.css). */
export declare const rangeFill: (value: number, min: number, max: number) => CSSProperties;
export declare function Glyph({ name, size }: {
    name: string;
    size?: number;
}): import("react").JSX.Element;
export {};
