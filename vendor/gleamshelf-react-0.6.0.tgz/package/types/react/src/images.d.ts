import { type PhotoDocument } from '../../core/src/index.js';
/** The largest texture this device's GPU accepts (often 4096 on phones, 16384 on desktops). */
export declare function gpuMaxTextureSize(): number;
/** Decodes a photo with its EXIF orientation applied, shrinking it if the GPU can't hold it at full size. */
export declare function decodePhoto(file: Blob, maxTextureSize?: number): Promise<ImageBitmap>;
/**
 * Crops away fully transparent margins, so a cut-out's visible content fills the image edge to edge (a product
 * then stands on its base instead of floating above empty space). Images without transparency come back as is.
 */
export declare function trimTransparent(image: ImageBitmap): Promise<ImageBitmap>;
/**
 * Fetches a photo by URL. The server must allow cross-origin reads (CORS), otherwise the browser forbids
 * the editor from reading its pixels.
 */
export declare function fetchPhoto(url: string, signal?: AbortSignal): Promise<Blob>;
/** A cut-out mask as a small grey PNG, so a host can store it beside the recipe. */
export declare function maskToBlob(mask: {
    alpha: Uint8Array;
    width: number;
    height: number;
}): Promise<Blob>;
/** Reads a mask PNG written by `maskToBlob` (or any grey picture) back into one byte per pixel. */
export declare function blobToMask(blob: Blob): Promise<{
    alpha: Uint8Array;
    width: number;
    height: number;
}>;
/** The photo shrunk to at most `longest` pixels and saved as a JPEG: enough for a model that works at a fixed size. */
export declare function photoForModel(image: ImageBitmap, longest?: number): Promise<Blob>;
/**
 * The photo as it looks inside the crop (turned, straightened, flipped), as a JPEG of at most `longest` pixels, with no
 * edits to light or colour. Used to ask a model about just the part of the photo the person framed.
 */
export declare function photoForCrop(image: ImageBitmap, doc: PhotoDocument, longest?: number): Promise<Blob>;
