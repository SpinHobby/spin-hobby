import { type GleamEditorProps } from './GleamEditor';
export interface GleamEditorModalProps extends GleamEditorProps {
    open: boolean;
}
/** The editor full-screen over the host page. Closing is up to the host: `onDone` / `onCancel` set `open` to false. */
export declare function GleamEditorModal({ open, ...props }: GleamEditorModalProps): import("react").ReactPortal | null;
