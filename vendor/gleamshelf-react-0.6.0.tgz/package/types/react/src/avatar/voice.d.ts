import { type ExpressionName } from '../../../avatar/src/index.js';
import type { AvatarVoiceId, LocalModelClient } from '../../../models/src/index.js';
/**
 * The avatar's voice in the browser. The mic is listened to (never played back) and cut into sentences, by holding a key or hands-free; each
 * sentence goes to the Gleamshelf app on this computer (speech to text, the wording fix, text to speech) and comes back in the avatar's voice,
 * played in turn, with the avatar's lips following that voice. Live, the mic goes in 160 ms chunks instead, each changed into the avatar's voice
 * and played straight after the one before. Nothing is sent anywhere else.
 */
export type TalkMode = 'hold' | 'free';
/** What viewers hear: the owner's own voice, clear voice (each sentence said again), or live voice (changed as they talk). */
export type VoiceMode = 'own' | 'clear' | 'live';
export interface VoiceSettings {
    voice: AvatarVoiceId;
    speed: number;
    /** Tidy the grammar and misheard words (and translate into English) before saying it again. */
    fix: boolean;
    talk: TalkMode;
    /** The shop's word list (see parseShopWords). */
    words: string;
}
export interface SaidLine {
    heard: string;
    said: string;
    /** From the end of the sentence to the avatar starting to say it. */
    delayMs: number;
    language: string;
}
/** The live voice's chunk: 160 ms at 16 kHz. */
export declare const LIVE_CHUNK = 2560;
export declare class VoiceDesk {
    readonly context: AudioContext;
    private readonly analyser;
    private readonly out;
    private readonly bins;
    private source;
    private processor;
    private readonly gate;
    private held;
    private playing;
    private queue;
    private readonly chunker;
    private liveAt;
    mode: TalkMode;
    /** Live: every chunk of the mic goes to `onLiveChunk` (hold and hands-free do not apply). */
    live: boolean;
    /** Every clip and live chunk the avatar says (the stage for OBS plays them too). */
    onVoice: ((kind: 'clip' | 'live', wav: Blob) => void) | null;
    /** Live: a 160 ms chunk of the mic (16 kHz WAV), with when it ended (performance.now). */
    onLiveChunk: ((wav: Blob, endedAt: number) => void) | null;
    /** Listening is on (the mic's sentences are sent); off, the mic is ignored. */
    listening: boolean;
    /** A sentence was heard, at the mic's rate, ready to be sent. */
    onSentence: ((wav: Blob, endedAt: number) => void) | null;
    /** Hands-free: whether a sentence is being heard now (for the screen). */
    onHearing: ((hearing: boolean) => void) | null;
    constructor();
    /** Whether the avatar's voice is heard on this computer's speakers (off while the stage for OBS plays it). */
    set audible(on: boolean);
    /** Lets the avatar's voice be heard: browsers allow sound only after a click or key press, so every one that can make it talk calls this. */
    wake(): void;
    /** Listens to a mic stream (never played back). */
    attach(stream: MediaStream | null): void;
    private heard;
    /** Hold to talk: starts (true) or ends (false) a sentence. */
    hold(down: boolean): void;
    private send;
    /** Plays a WAV in the avatar's voice after whatever is playing; resolves when it starts. */
    play(wav: Blob): Promise<void>;
    /**
     * Live: plays a changed chunk right after the one before (or a moment from now, if the voice had stopped). Answers how long until it is
     * heard, in seconds.
     */
    playLive(wav: Blob): Promise<number>;
    /** Live: a new start (the chunks before are forgotten). */
    resetLive(): void;
    /** Stops the avatar talking now. */
    hush(): void;
    get talking(): boolean;
    /** The mouth's shapes from the avatar's own voice this frame, or null when it is not talking. */
    lips(): Partial<Record<ExpressionName, number>> | null;
    close(): void;
}
/**
 * Clear mode for one sentence: what the app heard, tidied (when asked), said in the avatar's voice. `onStep` shows where it is; the heard words
 * come back first so the screen can show them while the rest is made.
 */
export declare function sayAgain(client: LocalModelClient, wav: Blob, settings: VoiceSettings, shop: {
    names: string[];
    sounds: Record<string, string>;
}, onStep: (step: 'listening' | 'fixing' | 'speaking', heard?: string) => void): Promise<{
    heard: string;
    said: string;
    language: string;
    audio: Blob;
} | null>;
export declare const DEFAULT_VOICE_SETTINGS: VoiceSettings;
export declare function loadVoiceSettings(): VoiceSettings;
export declare function saveVoiceSettings(s: VoiceSettings): void;
