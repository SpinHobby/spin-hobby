import type { AvatarPose } from '../../../avatar/src/index.js';
/**
 * Avatar mode's side of the stage for OBS: one WebSocket to the Gleamshelf app (stagehub.ts), kept open while Stream to OBS is on. It sends
 * the pose (at most every 30 ms), the look (framing and colours) when it changes, and the avatar's voice, which the stage plays itself.
 */
export declare const VOICE_CLIP = 1;
export declare const VOICE_LIVE = 2;
export interface StageLook {
    framing: string;
    colours: Record<string, string>;
}
export declare class StageLink {
    private readonly url;
    private readonly token;
    private ws;
    private stopped;
    private retry;
    private lastPose;
    private look;
    /** How many stages (OBS scenes, browser tabs) are watching. */
    onViewers: ((count: number) => void) | null;
    /** Connected to the app (true) or not (false). */
    onOpen: ((open: boolean) => void) | null;
    /** The app refused (a wrong pairing token): it will not start working by itself. */
    onRefused: ((reason: string) => void) | null;
    constructor(url: string, token: string);
    private connect;
    private get open();
    pose(p: AvatarPose, now?: number): void;
    setLook(look: StageLook): void;
    /** The avatar's voice: a whole clip (said after the last) or a live chunk (said straight on). */
    voice(kind: typeof VOICE_CLIP | typeof VOICE_LIVE, wav: Blob): Promise<void>;
    stop(): void;
}
