import { type GestureName } from '../../../avatar/src/index.js';
import type { VoiceDesk, VoiceSettings } from './voice';
export declare function AgentPanel({ desk, voice, onGesture, colours, }: {
    desk: VoiceDesk | null;
    voice: VoiceSettings;
    onGesture: (g: GestureName) => void;
    /** The avatar's colours, for the website's portrait. */
    colours: Record<string, string>;
}): import("react").JSX.Element;
