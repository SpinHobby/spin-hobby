/**
 * What Avatar mode keeps on this computer: an imported avatar file (in the browser's IndexedDB, since VRM files are several MB) and each
 * avatar's colours (by its name, in localStorage). Lost if the browser's site data is cleared; the starting avatar is used then.
 */
/** The imported avatar's bytes, or null for the starting avatar. */
export declare function loadAvatarFile(): Promise<ArrayBuffer | null>;
/** Keeps an imported avatar (null forgets it: the starting avatar again). */
export declare function saveAvatarFile(bytes: ArrayBuffer | null): Promise<void>;
export declare function loadColours(avatar: string): Record<string, string>;
export declare function saveColours(avatar: string, colours: Record<string, string>): void;
