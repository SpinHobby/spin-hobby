import type { VoiceSettings } from './voice';
export declare function VideoPanel({ voice, colours }: {
    voice: VoiceSettings;
    colours: Record<string, string>;
}): import("react").JSX.Element;
