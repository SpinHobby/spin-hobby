import type { AvatarVoiceId, LocalModelClient } from '../../../models/src/index.js';
/**
 * Product videos: the avatar says a short script beside the product (its photo from the shop, or a picture or video file such as a 3D ad
 * from 3D mode), with the product's name and price and the words as captions, saved as an MP4 (H.264 and AAC; WebM where the browser has
 * no H.264). Made frame by frame in the browser: each sentence is spoken by the app's voice model, the lips come from that sound
 * (byteSpectrum, as live), and every frame is drawn and encoded by the browser's own encoder. Free, on this computer.
 */
export type VideoShape = 'tall' | 'wide';
export declare const VIDEO_SIZES: Record<VideoShape, [number, number]>;
export interface Box {
    x: number;
    y: number;
    w: number;
    h: number;
}
/** Where everything goes in a frame: the product, the avatar, the name card and the captions. */
export declare function layout(shape: VideoShape): {
    product: Box;
    avatar: Box;
    card: Box;
    caption: Box;
};
/** A script split into sentences (each is spoken, and captioned, on its own). */
export declare function sentences(script: string): string[];
/** When each sentence is said: after a short lead, with a pause between sentences. */
export declare function timeline(durations: number[]): {
    start: number;
    end: number;
}[];
/** Lines of `text` that fit `width` on `ctx` (its font set), at most `max` lines. */
export declare function wrap(ctx: Pick<CanvasRenderingContext2D, 'measureText'>, text: string, width: number, max?: number): string[];
export interface ProductVideoInput {
    client: LocalModelClient;
    script: string;
    voice: {
        voice: AvatarVoiceId;
        speed: number;
        words: Record<string, string>;
    };
    /** The avatar file (a VRM) and its colours, as in Avatar mode. */
    avatar: ArrayBuffer;
    colours: Record<string, string>;
    product: {
        name: string;
        price: string | null;
        status: string | null;
    } | null;
    /** Beside the avatar: a picture (a product photo) or a video file (a 3D ad); none leaves the avatar alone. */
    visual: {
        kind: 'picture';
        blob: Blob;
    } | {
        kind: 'video';
        blob: Blob;
    } | null;
    shape: VideoShape;
    shop: string | null;
    /** A small "AI voice" mark in the corner (on by default: viewers are told the voice is made). */
    aiMark: boolean;
    onStep: (step: string, done?: number) => void;
    signal?: AbortSignal;
}
/** The avatar's face as a small JPEG on the theme's stage colour: the shop assistant's portrait on the shop's website. */
export declare function avatarPortrait(avatar: ArrayBuffer, colours: Record<string, string>, size?: number): Promise<Blob>;
export declare function makeProductVideo(input: ProductVideoInput): Promise<{
    blob: Blob;
    extension: string;
    seconds: number;
}>;
