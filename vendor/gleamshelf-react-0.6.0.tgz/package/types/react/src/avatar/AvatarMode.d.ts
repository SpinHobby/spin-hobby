import '../model3d/model3d.css';
import './avatar.css';
/**
 * Avatar mode: the shop's own vtuber. A VRM avatar (the starting one, recoloured, or one imported from VRoid Studio) moved by the webcam (face,
 * body and hands), by gestures and expressions on keys and buttons, and by the mic for lip-sync; on a backdrop for streams (see-through,
 * green screen, a colour or a scene), and poppable into its own window for streaming software to capture. Everything runs on this computer:
 * the webcam's and mic's frames never leave it. Its voice: the owner's own, or clear voice (each sentence said again in the avatar's voice by
 * the models in the Gleamshelf app, VoicePanel). The AI agent comes next (docs/AVATAR.md).
 */
export interface AvatarModeProps {
    onClose: () => void;
    title?: string;
}
export declare function AvatarMode({ onClose, title }: AvatarModeProps): import("react").JSX.Element;
