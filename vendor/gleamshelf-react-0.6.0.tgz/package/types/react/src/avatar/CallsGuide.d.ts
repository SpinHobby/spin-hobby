export declare function CallsGuide({ onCopyLink }: {
    onCopyLink: () => void;
}): import("react").JSX.Element;
