import { type VoiceDesk, type VoiceMode, type VoiceSettings } from './voice';
export declare function VoicePanel({ desk, mode, onMode, micOn, startMic, settings, onSettings, }: {
    desk: VoiceDesk | null;
    mode: VoiceMode;
    onMode: (mode: VoiceMode) => void;
    micOn: boolean;
    startMic: () => void;
    settings: VoiceSettings;
    onSettings: (s: VoiceSettings) => void;
}): import("react").JSX.Element;
