/**
 * Fonts for 3D text: the standard ones every computer has, a choice of free online fonts (Google Fonts, loaded only when picked or listed), the
 * fonts installed on this computer (where the browser can list them), and font files the person loads. The letters are traced into the design's
 * outline, so a design keeps its look on a computer without the font; only changing the text needs the font again.
 */
export type FontSource = 'standard' | 'online' | 'computer' | 'file';
export interface FontChoice {
    family: string;
    source: FontSource;
    /** Weights it has (the browser makes others up, less well). */
    weights: number[];
    /** Online fonts: a few words on what it suits. */
    note?: string;
}
export declare const STANDARD_FONTS: FontChoice[];
/** Free online fonts (SIL Open Font License or Apache), chosen for signs, sales and anime-style ads, Japanese among them. */
export declare const ONLINE_FONTS: FontChoice[];
/** Loads an online font's weights, ready to draw with. */
export declare function loadOnlineFont(f: FontChoice, weight: number, text: string): Promise<void>;
/** The online fonts' names drawn in their own letters, with only those letters fetched (one small request). */
export declare function previewOnlineFonts(fonts: FontChoice[]): Promise<void>;
interface LocalFontData {
    family: string;
    style: string;
}
declare global {
    interface Window {
        queryLocalFonts?: () => Promise<LocalFontData[]>;
    }
}
/** Whether this browser can list the computer's fonts (Chrome and Edge; it asks once). */
export declare const canListComputerFonts: () => boolean;
/** The fonts installed on this computer, one entry a family with the weights its styles name. */
export declare function listComputerFonts(): Promise<FontChoice[]>;
export declare const loadedFontFiles: () => FontChoice[];
/** Loads a font file (TTF, OTF, WOFF, WOFF2) for this session, named after its file; it stands for every weight. */
export declare function loadFontFile(file: File): Promise<FontChoice>;
/** Whether a font draws on this computer now (its letters differ from the fallbacks'), so a text can be drawn in it. */
export declare function fontAvailable(family: string): boolean;
/** Makes sure a font can be drawn with before its letters are traced: online ones are fetched, others are checked. */
export declare function readyFont(family: string, weight: number, text: string): Promise<void>;
export {};
