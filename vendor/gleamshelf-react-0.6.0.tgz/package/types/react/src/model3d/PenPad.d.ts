import type { PenPath } from '../../../scene3d/src/index.js';
export declare function PenPad({ initial, onPaths }: {
    initial?: PenPath[];
    onPaths: (paths: PenPath[]) => void;
}): import("react").JSX.Element;
