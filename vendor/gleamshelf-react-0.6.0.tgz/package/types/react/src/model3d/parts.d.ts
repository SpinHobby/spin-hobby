import type { ShapeKind, Vec3 } from '../../../scene3d/src/index.js';
/** Small pieces of 3D mode's screen: shape icons, sliders whose drag is one undo step, exact x/y/z fields, segmented choices. */
/** Little line drawings of the shapes, for the add buttons and the list. */
export declare function ShapeIcon({ kind }: {
    kind: ShapeKind | 'svg' | 'ad';
}): import("react").JSX.Element;
/** A slider whose whole drag is one undo step. */
export declare function Slider(props: {
    label: string;
    value: number;
    min: number;
    max: number;
    step: number;
    format?: (v: number) => string;
    onBegin: () => void;
    onChange: (v: number) => void;
    onEnd: () => void;
}): import("react").JSX.Element;
/** Three numbers in a row (x, y, z), typed exactly. */
export declare function Triple({ label, value, step, min, onChange, }: {
    label: string;
    value: Vec3;
    step: number;
    min?: number;
    onChange: (v: Vec3) => void;
}): import("react").JSX.Element;
export declare function Segments<T extends string>({ value, options, labels, onChange, label, }: {
    value: T;
    options: readonly T[];
    labels: Record<T, string>;
    onChange: (v: T) => void;
    label: string;
}): import("react").JSX.Element;
