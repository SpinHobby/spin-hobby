import type { ModelDocument, ModelEditor } from '../../../scene3d/src/index.js';
/**
 * The Scene behind section: a scene painted by the image model on this computer (free, about a minute; nothing is sent anywhere), or any
 * picture, drawn behind the design. The design stays exactly as made.
 */
export declare function ScenePanel({ editor, doc, aspect }: {
    editor: ModelEditor;
    doc: ModelDocument;
    aspect: () => number;
}): import("react").JSX.Element;
