import { type ModelEditor, type Shape3D, type ShapeRef } from '../../../scene3d/src/index.js';
export declare function MotionSection({ editor, items, playing, onPlay, }: {
    editor: ModelEditor;
    /** The shapes it sets: one, or the picked top-level ones (a group moves as one). */
    items: {
        ref: ShapeRef;
        shape: Shape3D;
    }[];
    playing: boolean;
    onPlay: () => void;
}): import("react").JSX.Element;
