import { type ModelDocument, type ModelEditor, type Shape3D, type ShapeRef } from '../../../scene3d/src/index.js';
/** The shapes a look or join applies to: each picked shape, or every shape in a picked group. */
export declare function leavesOf(doc: ModelDocument, picked: number[]): {
    ref: ShapeRef;
    shape: Shape3D;
}[];
export declare function MultiPanel({ editor, doc, picked, onDuplicate, onDelete, onGroup, motion, }: {
    editor: ModelEditor;
    doc: ModelDocument;
    picked: number[];
    onDuplicate: () => void;
    onDelete: () => void;
    onGroup: () => void;
    /** The Motion section, for all of them. */
    motion?: React.ReactNode;
}): import("react").JSX.Element | null;
