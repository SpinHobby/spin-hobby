import { type Finish, type ModelAsset, type ModelDocument, type Shape3D } from '../../../scene3d/src/index.js';
export declare function copyShapes(doc: ModelDocument, list: Shape3D[]): void;
export declare const copiedShapes: () => {
    shapes: Shape3D[];
    assets: Record<string, ModelAsset>;
    pastes: number;
} | null;
/** How far the next paste lands from the copied shapes: each paste a step further, so copies do not stack on each other. */
export declare function nextPasteOffset(): [number, number, number];
export declare function copyLook(s: Pick<Shape3D, 'color' | 'finish'>): void;
export declare const copiedLook: () => {
    color: string;
    finish: Finish;
} | null;
/** A picture on the computer's clipboard (PNG), for pasting into a slide, a chat or another app. */
export declare function copyPicture(picture: Promise<Blob>): Promise<void>;
/** Vectors on the computer's clipboard: as SVG where the browser allows it, and always as its text (which drawing apps paste as shapes). */
export declare function copyVectors(svg: Promise<string>): Promise<void>;
