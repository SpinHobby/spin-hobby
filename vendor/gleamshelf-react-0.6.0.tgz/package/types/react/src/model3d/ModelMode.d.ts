import { type ModelDocument } from '../../../scene3d/src/index.js';
import { type AdStart } from './AdDialog';
import './model3d.css';
/**
 * 3D mode: build a 3D design from simple shapes, outlines and text, joined, cut and softly blended (and grouped), then light it, give it a look, and
 * place it in a 2D design as a picture, or save it as a picture, an SVG of flat regions, or a short video. The design is a ModelDocument
 * (packages/scene3d/src/model), drawn live by ray marching.
 */
export interface ModelModeProps {
    /** A design to reopen (from a 3D layer, or made from a layer's outline); a new one with a single box when left out. */
    open?: ModelDocument | null;
    title?: string;
    /** The finished picture (PNG, transparent where there is nothing) and the design, to keep beside it. */
    onDone?: (picture: Blob, design: ModelDocument) => void;
    doneLabel?: string;
    onClose: () => void;
    /** Pixel size of the finished picture (long side). */
    renderSize?: number;
    /** Opens with the 3D ad dialog, filled in (a finished run's cut-out, title and series). */
    ad?: AdStart;
}
export declare function ModelMode({ open, title, onDone, doneLabel, onClose, renderSize, ad, }: ModelModeProps): import("react").JSX.Element;
