import { type ClipKind, type Contour, type PenPath, type TextSpec } from '../../../scene3d/src/index.js';
import { type FontChoice } from './fonts';
/** 3D mode's dialogs: an outline to push out (a ready-made one, or drawn with the pen), a text and its font, and a video clip. */
export declare function Dialog({ title, onClose, children }: {
    title: string;
    onClose: () => void;
    children: React.ReactNode;
}): import("react").JSX.Element;
export declare function OutlineDialog({ initial, onPick, onClose, }: {
    /** Editing a shape drawn with the pen: its points. */
    initial?: PenPath[];
    onPick: (outline: Contour[], aspect: number, name: string, pen?: PenPath[]) => void;
    onClose: () => void;
}): import("react").JSX.Element;
export declare function TextDialog({ initial, onDone, onClose }: {
    initial?: TextSpec;
    onDone: (text: TextSpec) => void;
    onClose: () => void;
}): import("react").JSX.Element;
/** The font a saved text names, wherever it comes from. */
export declare function findFont(family: string): FontChoice;
/** Fonts to pick from: standard ones, free online ones, this computer's, or a font file; with a search. */
export declare function FontPicker({ value, onPick }: {
    value: FontChoice;
    onPick: (f: FontChoice) => void;
}): import("react").JSX.Element;
export declare function VideoDialog({ initialKind, initialSeconds, moving, onMake, onClose, }: {
    initialKind?: ClipKind;
    initialSeconds?: number;
    /** Some shapes have a motion: they move in every clip, whatever the camera does. */
    moving?: boolean;
    onMake: (kind: ClipKind, seconds: number, size: number) => void;
    onClose: () => void;
}): import("react").JSX.Element;
