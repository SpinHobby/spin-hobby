import type { Combine, Finish } from '../../../scene3d/src/index.js';
/** Words and colours 3D mode's panels share. */
export declare const COMBINE_LABEL: Record<Combine, string>;
export declare const FINISH_LABEL: Record<Finish, string>;
export declare const SWATCHES: string[];
