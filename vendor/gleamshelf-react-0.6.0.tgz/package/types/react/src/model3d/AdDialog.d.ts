import { type AdColours, type AdStyle } from '../../../scene3d/src/index.js';
import type { FontChoice } from './fonts';
/**
 * The 3D ad dialog: the product's picture (the run's cut-out, or any picture with a see-through background), the headline, a small line, the
 * price and the shop's logo, a layout and colours. The logo is remembered on this computer for the next ad.
 */
export interface AdStart {
    picture?: Blob;
    headline?: string;
    tagline?: string;
    price?: string;
}
export interface AdChoice {
    picture: Blob | null;
    headline: string;
    tagline: string;
    price: string;
    logo: {
        name: string;
        svg: string;
    } | null;
    style: AdStyle;
    colours: AdColours;
    font: FontChoice;
    moving: boolean;
    /** A scene to put behind the ad (the last one painted or chosen), or none. */
    scene: string | null;
}
export declare function AdDialog({ start, onMake, onClose }: {
    start?: AdStart;
    onMake: (choice: AdChoice) => void;
    onClose: () => void;
}): import("react").JSX.Element;
