import { useLocalApp } from './useLocalApp';
interface Props {
    /** The picture to enlarge, at most about 1024 pixels on its long side (the result is 4 times larger). */
    getPicture: () => Promise<Blob>;
    /** Called with the enlarged picture. */
    onEnlarged: (model: string, picture: Blob) => void;
    /** Takes the AI enlarging off again. */
    onRemove: () => void;
    /** Whether an enlarging is applied now, and by what factor the finished picture is bigger. */
    applied: {
        factor: number;
    } | null;
    app: ReturnType<typeof useLocalApp>;
    /** The slow sharpening with the tile model, run on the picture before it is enlarged. Null when it is not set up. */
    sharpen?: ((picture: Blob) => Promise<Blob>) | null;
}
/** Makes the picture sharper and larger with an AI model on this computer: free, nothing is uploaded. */
export declare function AiEnlarge({ getPicture, onEnlarged, onRemove, applied, app, sharpen }: Props): import("react").JSX.Element;
export {};
