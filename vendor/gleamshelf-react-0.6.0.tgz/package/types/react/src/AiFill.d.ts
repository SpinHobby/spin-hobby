import { type TextBox } from '../../models/src/index.js';
import { useLocalApp } from './useLocalApp';
interface Props {
    /** The picture to repaint: PNG whose transparent pixels are the lettering (and, if asked, any other printed text). */
    buildInput: (options: {
        otherText: boolean;
        textModel?: string;
        client: ReturnType<typeof useLocalApp>['client'];
    }) => Promise<{
        picture: Blob;
        cutAway: TextBox[];
    } | null>;
    /** Called with the repainted picture, and the text on the cut-out's edge that should be cut away instead of repainted. */
    onFilled: (model: string, picture: Blob, cutAway: TextBox[]) => void;
    /** An AI fill has already been applied to the current settings. */
    applied: boolean;
    /** The connection to the companion app, shared with the other AI controls. */
    app: ReturnType<typeof useLocalApp>;
    /** Shown as busy while a fill started elsewhere (the one-click removal) is running. */
    busyOutside?: boolean;
}
/**
 * Repaints the lettering with an AI fill model running on the user's computer: it invents believable hair, fabric and
 * skin where the words were, which the free fill cannot. Optionally also finds and removes other printed text.
 */
export declare function AiFill({ buildInput, onFilled, applied, app, busyOutside }: Props): import("react").JSX.Element;
export {};
