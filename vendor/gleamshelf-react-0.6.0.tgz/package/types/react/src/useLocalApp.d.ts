import { LocalModelClient, type LocalModelStatus } from '../../models/src/index.js';
interface Saved {
    url: string;
    token: string;
}
export type LocalAppState = 'checking' | 'offline' | 'blocked' | 'needs-token' | 'ready';
/**
 * Finds the Gleamshelf companion app on this computer and reports where things stand: not running, blocked by the browser,
 * needs the pairing token, or ready with a list of models. Keeps looking while it is not found, so starting the app in a
 * terminal is noticed without clicking anything. Shared by every control that uses a local model.
 */
export declare function useLocalApp(override?: {
    url?: string;
    token?: string;
}): {
    state: LocalAppState;
    saved: Saved;
    client: LocalModelClient;
    models: LocalModelStatus[] | null;
    installed: (task: LocalModelStatus["task"]) => LocalModelStatus[];
    problem: string | null;
    setProblem: import("react").Dispatch<import("react").SetStateAction<string | null>>;
    check: () => Promise<void>;
    connect: (token: string) => void;
    canProcess: boolean;
    canPhone: boolean;
    canShop: boolean;
};
export {};
