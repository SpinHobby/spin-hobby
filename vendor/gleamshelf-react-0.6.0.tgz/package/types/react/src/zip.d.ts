/**
 * A zip file of finished pictures, made in the browser with no library: pictures are already compressed (JPEG, PNG, WebP), so the files are
 * stored as they are. Enough for "save every marketplace's picture at once".
 */
export declare function crc32(bytes: Uint8Array): number;
/** The zip's bytes for these files (names with forward slashes for folders). */
export declare function zipFiles(files: readonly {
    name: string;
    bytes: Uint8Array;
}[]): Uint8Array;
