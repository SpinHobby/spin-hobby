import type { LocalModelClient } from '../../models/src/index.js';
/**
 * Photos from a phone: a QR code the phone scans on the shop's Wi-Fi, and the photos it sends, newest first, each one click from being edited here. The
 * companion app serves the phone page (apps/local/src/phone.ts); photos never leave this computer and the network.
 */
export declare function PhoneCapture({ client, onOpen, onClose, }: {
    client: LocalModelClient;
    onOpen: (photo: Blob, name: string) => void;
    onClose: () => void;
}): import("react").JSX.Element;
