import { type HelpId } from './instructions';
export declare function setDevNotes(on: boolean): void;
export declare function useDevNotes(): boolean;
/** A developer line on its own, for help kept beside its feature (Edit mode's tools). */
export declare function DevNote({ text }: {
    text: string;
}): import("react").JSX.Element | null;
/** A feature's instructions: the plain line always, the developer line when the switch is on. `inline` for inside a label (spans shown as lines). */
export declare function Help({ id, inline }: {
    id: HelpId;
    inline?: boolean;
}): import("react").JSX.Element;
/** The switch, wherever it is offered. */
export declare function DevNotesSwitch(): import("react").JSX.Element;
/** Every feature with how to use it, grouped as the editor shows them. */
export declare function Guide({ onClose }: {
    onClose: () => void;
}): import("react").JSX.Element;
