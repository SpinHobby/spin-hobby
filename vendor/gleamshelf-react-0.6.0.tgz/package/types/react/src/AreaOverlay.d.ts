interface Props {
    /** On-screen size of the finished image the overlay covers. */
    width: number;
    height: number;
    /** Called with the rectangle dragged, as fractions (0-1) of the finished image: x, y, width, height. */
    onArea: (box: [number, number, number, number]) => void;
}
/** Waits for one rectangle to be dragged on the preview. */
export declare function AreaOverlay({ width, height, onArea }: Props): import("react").JSX.Element;
export {};
