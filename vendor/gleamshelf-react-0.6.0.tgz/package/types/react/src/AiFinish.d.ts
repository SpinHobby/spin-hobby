import { useLocalApp } from './useLocalApp';
interface Props {
    app: ReturnType<typeof useLocalApp>;
    /** Finishing touches are applied now. */
    applied: boolean;
    /** Waits for a rectangle to be dragged on the picture, then redraws it as `prompt`. */
    onRedrawArea: (prompt: string, keepShape: boolean) => void;
    onCancelArea: () => void;
    /** Whether the picture is waiting for a rectangle to be dragged. */
    picking: boolean;
    onRemove: () => void;
    /** The last result of a redraw started from the picture, to show here. */
    note: string | null;
    /** True while a redraw started elsewhere is running. */
    busyOutside: boolean;
}
/**
 * Redraws a chosen part of the finished picture with an image model on this computer.
 * Free and private, but it draws new pixels, so the result must be checked against the real product.
 */
export declare function AiFinish({ app, applied, onRedrawArea, onCancelArea, picking, onRemove, note, busyOutside }: Props): import("react").JSX.Element;
export {};
