/** Types and a small client for the Gleamshelf API. Works in Node 22+, Cloudflare Workers and browsers (fetch + WebCrypto only). */
export interface AssetRef {
    id: string;
    url: string;
}
export interface SessionImage {
    index: number;
    name?: string;
    original: AssetRef;
    result?: AssetRef & {
        recipe?: unknown;
    };
}
export interface Session {
    id: string;
    status: 'open' | 'completed' | 'expired';
    createdAt: string;
    expiresAt: string;
    completedAt?: string;
    metadata?: Record<string, string>;
    images: SessionImage[];
    scene?: AssetRef;
    webhook?: {
        status: 'delivered' | 'failed';
        httpStatus?: number;
        attemptedAt: string;
    };
}
export interface CreatedSession extends Session {
    /** Where to send the person who will edit: opens the hosted editor on this session. */
    editUrl: string;
    /** For embedding the editor in your own page instead: pass to `GleamshelfEditor`. Treat like a password for this one session. */
    editorToken: string;
}
export interface NewSession {
    /** Photos to edit. A `url` is downloaded by Gleamshelf (https only); an `assetId` is a file you uploaded earlier. */
    images: ({
        url: string;
        name?: string;
    } | {
        assetId: string;
        name?: string;
    })[];
    /** Where to send the signed `session.completed` event. Optional: you can poll `getSession` instead. */
    webhookUrl?: string;
    /** Up to 20 text values that come back untouched, e.g. your product id. */
    metadata?: Record<string, string>;
    expiresInHours?: number;
}
export declare class GleamshelfError extends Error {
    readonly status: number;
    readonly code: string;
    constructor(status: number, code: string, message: string);
}
type Fetch = typeof fetch;
/** For your server. Keep the API key out of browsers. */
export declare class Gleamshelf {
    private readonly options;
    private readonly base;
    private readonly doFetch;
    constructor(options: {
        apiKey: string;
        baseUrl: string;
        fetch?: Fetch;
    });
    private headers;
    createSession(input: NewSession): Promise<CreatedSession>;
    getSession(id: string): Promise<Session>;
    uploadPhoto(bytes: Uint8Array | ArrayBuffer, name?: string): Promise<AssetRef & {
        contentType: string;
        size: number;
    }>;
    deleteAsset(id: string): Promise<void>;
}
/** For the editor, in a browser. Holds only a token for one session, never the API key. */
export declare class GleamshelfEditor {
    private readonly options;
    private readonly base;
    private readonly doFetch;
    constructor(options: {
        baseUrl: string;
        token: string;
        fetch?: Fetch;
    });
    private headers;
    getSession(): Promise<Session>;
    uploadPhoto(bytes: Blob | Uint8Array | ArrayBuffer, name?: string): Promise<AssetRef & {
        contentType: string;
        size: number;
    }>;
    /** Saves an edited photo as the result for photo `index`. The recipe (what was done) is kept with it so the edit can be reopened. */
    saveResult(index: number, assetId: string, recipe?: unknown): Promise<Session>;
    /** Saves a 3D scene (JSON) that a shop can embed with `<gleam-scene src="...">`. */
    saveScene(scene: unknown): Promise<Session>;
    /** Tells the shop the work is done. Sends the webhook, if one was set. */
    complete(): Promise<Session>;
    /** Reads the session id and token out of an `editUrl` ( `https://editor/edit/<id>#token=<token>` ). */
    static fromEditUrl(editUrl: string, baseUrl: string, fetchImpl?: Fetch): GleamshelfEditor;
}
export interface WebhookEvent {
    id: string;
    type: 'session.completed';
    createdAt: string;
    data: Session;
}
/**
 * Checks a webhook really came from Gleamshelf and is recent, then returns the event. Pass the RAW request body (the exact
 * text received, before any JSON parsing) and the `Gleamshelf-Signature` header. Throws if anything is wrong.
 */
export declare function verifyWebhook(rawBody: string, signatureHeader: string | null | undefined, secret: string, options?: {
    toleranceSeconds?: number;
    nowSeconds?: number;
}): Promise<WebhookEvent>;
export {};
