/**
 * Cut-outs as recipe data: a list of operations replayed over the original photo to build an alpha mask.
 * Coordinates are normalized (0–1) on the original, before crop and rotation, so geometry edits never disturb
 * the mask. Nothing raster is stored: the recipe stays small JSON and every step can be undone.
 */
export type MaskMode = 'remove' | 'keep';
/** Removes (or brings back) the region of similar colour connected to a point: "tap the background". */
export interface FillOp {
    kind: 'fill';
    mode: MaskMode;
    x: number;
    y: number;
    /** 0–100: how different a colour may be from the tapped one and still count as the same region. */
    tolerance: number;
}
/** A brush stroke that erases (or restores) along a path. */
export interface BrushOp {
    kind: 'brush';
    mode: MaskMode;
    /** Brush radius as a fraction of the photo's longest side. */
    radius: number;
    /** Flat list of normalized points: x0, y0, x1, y1, … */
    points: number[];
}
/**
 * Removes a green backdrop (a photo shot on a green cloth or screen) everywhere in the photo, in one step. How green a
 * pixel is, compared with its own brightness, decides how transparent it becomes, so shadowed parts of the cloth go too.
 * The renderer also pulls green spill off the product's edges whenever this op is present.
 */
export interface GreenOp {
    kind: 'green';
    mode: 'remove';
}
/**
 * A cut-out made by an AI model. The mask itself is a picture, kept by whoever stores the edit (like a background
 * photo) and found again through `ref`; the recipe only records which model made it. Without its picture the step is
 * skipped, so an edit never breaks, it just needs the cut-out run again.
 */
export interface ModelOp {
    kind: 'model';
    mode: 'remove';
    model: string;
    ref: string;
}
/**
 * Cuts away rectangles: used for printed text that sits on the cut-out's edge, which is better removed than repainted.
 * `boxes` is a flat list of normalized (0-1) x, y, width, height, four numbers per box.
 */
export interface EraseOp {
    kind: 'erase';
    mode: 'remove';
    boxes: number[];
}
/**
 * Fades the cut-out out along its bottom edge instead of ending in a hard line: for a figure cut off at the waist, or a bust. The fade
 * covers the lowest `size` of the cut-out's height (0.02-0.4) and is worked out from what is visible at that point in the list.
 */
export interface FadeOp {
    kind: 'fade';
    mode: 'remove';
    edge: 'bottom';
    size: number;
}
export type MaskOp = FillOp | BrushOp | GreenOp | ModelOp | EraseOp | FadeOp;
/** A cut-out mask picture: one byte per pixel, 255 keeps the pixel, 0 removes it. It covers the whole original photo. */
export interface BitmapMask {
    alpha: Uint8Array;
    width: number;
    height: number;
}
/** Longest side the mask is computed at; the renderer scales it up smoothly. */
export declare const MASK_SIZE = 1024;
/** A valid mask list, or undefined if `value` isn't one (used to validate edits). */
export declare function checkMask(value: unknown): MaskOp[] | undefined;
/** Reads a saved mask from untrusted JSON, keeping the valid operations. */
export declare function normalizeMask(value: unknown): MaskOp[];
/** Size of the grid the mask is computed on for a photo of the given size. */
export declare function maskSize(width: number, height: number): {
    width: number;
    height: number;
};
/**
 * Replays the operations over the photo's pixels (RGBA, `width` × `height`, at mask size) and returns one alpha
 * value per pixel: 255 keeps the pixel, 0 cuts it out. Edges get a one-pixel soften so cut-outs aren't jagged.
 */
export declare function computeMask(pixels: Uint8ClampedArray, width: number, height: number, ops: readonly MaskOp[], bitmaps?: ReadonlyMap<string, BitmapMask>): Uint8Array;
/**
 * How much of a photo's outer frame is green (0 to 1). A photo shot on a green cloth is green all the way round, so a high
 * value means the free green-backdrop tool will cut it out, and an AI model is not needed.
 */
export declare function greenBorderShare(pixels: Uint8ClampedArray, width: number, height: number): number;
/** True when the cut-out list includes the green-backdrop step (the renderer then removes green spill). */
export declare const hasGreenKey: (ops: readonly MaskOp[]) => boolean;
/**
 * A crease or a shadow on the cloth beside the product is not cloth-coloured enough to be removed, and is left as a translucent haze that reaches out from the product's
 * edge (found on a box photographed on a creased cloth). The product itself is solid. So: the solid part (alpha 230 and up; every piece at least 5% as big as the biggest, so a second
 * box stays) is the core, and a translucent pixel farther than `reach` from the core goes. Soft edges, anti-aliasing and thin things next to the core stay. In place.
 */
export declare function dropWisps(alpha: Uint8Array, w: number, h: number, reach?: number): number;
/**
 * The transparency a green backdrop gives each pixel (0 = backdrop, 255 = product), with its edge shrunk a pixel so no green fringe is left. This is the one copy of the
 * rule: the editor uses it directly and the pipeline's `keyOutGreen` calls it. A pixel is cloth when it has the backdrop's proportions of red and green (so cloth in more or
 * less light is still cloth) or is strongly green for its brightness; a dark pixel counts only if it is green by a clear margin; cloth must reach the photo's edge (a green
 * stripe printed on the box does not); and a translucent haze far from the product goes.
 */
export declare function greenKeyAlpha(pixels: Uint8ClampedArray, width: number, height: number): Uint8Array;
/** Fades the bottom `size` (a fraction, 0.02-0.4) of the cut-out's height out to nothing, in place. Also used by the batch runner. */
export declare function fadeBottomEdge(alpha: Uint8Array, width: number, height: number, size: number): void;
/** Which AI cut-outs in the list have no mask picture to go with them. */
export declare function missingMasks(ops: readonly MaskOp[], bitmaps?: ReadonlyMap<string, BitmapMask>): ModelOp[];
/** The visible part of a cut-out as a box in normalized (0–1) photo coordinates, or null if nothing is visible. */
export declare function maskBounds(alpha: Uint8Array, width: number, height: number, threshold?: number): {
    x: number;
    y: number;
    width: number;
    height: number;
} | null;
/**
 * Drops the small stray pieces of a cut-out (bits of printed text, specks) and keeps the main piece or pieces: every connected
 * part at least `minShare` as large as the biggest one stays. Works on a mask picture in place and returns it.
 */
export declare function keepMainPieces(mask: BitmapMask, minShare?: number, threshold?: number): BitmapMask;
/**
 * Takes out the pieces of a cut-out that touch the photo's edge when the product is elsewhere: the wall beside the backdrop, the backdrop's darker
 * corners, a table edge. A product photo has the product inside the frame; whatever reaches the edge as a separate piece is the room around the
 * backdrop. Only done when a piece that does not touch the edge covers at least `minInterior` of the photo (a close-up whose box touches the edge
 * is left alone). Returns how many pixels were taken out.
 */
export declare function dropEdgePieces(mask: BitmapMask, minInterior?: number, threshold?: number): number;
