import { type MaskOp } from './mask.js';
import { type ShaderStep } from './shaders.js';
import { type ParamValue } from './ops.js';
export declare const RECIPE_VERSION = 1;
export type OpParams = Record<string, ParamValue>;
/**
 * Everything done to one photo, as plain JSON. Rendering a recipe over the untouched original always gives
 * the same result, so hosts can store it and reopen the edit later.
 */
export interface Recipe {
    version: typeof RECIPE_VERSION;
    ops: Record<string, OpParams>;
    /** Cut-out operations; empty keeps the whole photo. */
    mask: MaskOp[];
    /** Shader effects applied after the adjustments, in order (see packages/shaders). */
    effects: ShaderStep[];
    /** Removal of white printed lettering inside the cut-out, or null for none. */
    words: WordsStep | null;
    /** An AI enlarging of the whole picture, or null. The enlarged picture is kept by the host, like a cut-out mask. */
    upscale: UpscaleStep | null;
    /**
     * An AI redraw of the whole finished picture (the antenna completed, an area repainted), or null. The picture is kept by the host, like
     * a cut-out mask, and replaces the pipeline's output; any other edit drops it, because the picture was drawn from the picture as it was.
     */
    finish: FinishStep | null;
}
export interface FinishStep {
    model: string;
    /** Names the redrawn picture the host keeps with the edit. */
    ref: string;
}
/** A valid finish step from untrusted JSON, or null. */
export declare function readFinish(value: unknown): FinishStep | null;
export interface UpscaleStep {
    model: string;
    /** Names the enlarged picture the host keeps with the edit. */
    ref: string;
    /** How many times larger the finished picture is than the original (1-4); the enlarged picture supplies the detail. */
    factor: number;
}
export declare const DEFAULT_UPSCALE_FACTOR = 2;
/** A valid upscale step from untrusted JSON, or null. */
export declare function readUpscale(value: unknown): UpscaleStep | null;
/** How white lettering is found (see `findWhiteWords` in the pipeline). */
export interface WordsStep {
    /** 150-255: how bright a pixel must be on every channel. */
    lightness: number;
    /** 4-80: the thickest stroke, in thousandths of the picture's longest side. */
    maxWidth: number;
    /** 5-200: the shortest piece of lettering, in thousandths of the longest side. */
    minLength: number;
    /** Whether white lettering is searched for (default true). Off means only the stickers below are repainted. */
    lettering?: boolean;
    /**
     * Price stickers (and anything else pointed out) to repaint, as flat normalized x, y, width, height (four numbers per box). Found by
     * reading the text on the photo; kept in the recipe so the repaint can be done again.
     */
    stickers?: number[];
    /**
     * Set once an AI fill model has repainted the lettering. The repainted picture is kept by whoever stores the edit, found
     * again through `ref` (like a cut-out mask); without it the free fill is used instead. Changing any setting clears it.
     */
    ai?: {
        model: string;
        ref: string;
    };
}
export declare const WORDS_LIMITS: {
    readonly lightness: readonly [150, 255];
    readonly maxWidth: readonly [4, 80];
    readonly minLength: readonly [5, 200];
};
export declare const DEFAULT_WORDS_STEP: WordsStep;
/** A valid words step from untrusted JSON (values clamped into range), or null. */
export declare function readWords(value: unknown): WordsStep | null;
export declare function defaultRecipe(): Recipe;
/**
 * Reads a recipe from untrusted JSON (a host's database, an older editor version): unknown ops and params are
 * dropped, missing or invalid values fall back to defaults, numbers are clamped into range.
 */
export declare function normalizeRecipe(input: unknown): Recipe;
export declare function isDefaultRecipe(recipe: Recipe): boolean;
export declare function readNumber(recipe: Recipe, type: string, name: string): number;
export declare function readBoolean(recipe: Recipe, type: string, name: string): boolean;
export declare function readChoice(recipe: Recipe, type: string, name: string): string;
