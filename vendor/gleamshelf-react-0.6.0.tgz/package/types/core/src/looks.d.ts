import type { ShaderStep } from './shaders.js';
/**
 * Ready-made settings for the light and colour sliders (and a sharpen effect), so one click makes a photo livelier. They only
 * change how the real pixels are shown: nothing is drawn that was not in the photo.
 */
export interface Look {
    id: string;
    label: string;
    description: string;
    ops: Record<string, Record<string, number>>;
    /** Added to the effect list, replacing an earlier effect with the same id. */
    effects: ShaderStep[];
}
export declare const LOOKS: readonly Look[];
export declare const findLook: (id: string) => Look | undefined;
