import { type ParamSpec } from './ops.js';
import { type Path } from './path.js';
export type SetStatus = 'ok' | 'unchanged' | 'invalid-path' | 'invalid-value';
/** What a UI needs to render: replaced (never mutated) whenever anything changes. */
export interface StoreSnapshot<D> {
    doc: D;
    canUndo: boolean;
    canRedo: boolean;
    undoLabel?: string;
    redoLabel?: string;
}
/** Decides whether `value` may be written at `path`, and in what cleaned-up form. */
export type Validate = (path: Path, value: unknown) => {
    value: unknown;
    label: string;
} | 'invalid-path' | 'invalid-value';
/**
 * An editable JSON document with undo. Every change goes through `set(path, value)` (or a subclass command
 * built on `apply`), is checked by the document type's `validate`, and lands in the history. A UI, a keyboard
 * shortcut, a test or, later, an AI tool call all edit the same way.
 *
 * Continuous edits (a slider drag, an orbit) are wrapped in `begin()` … `commit()`: the document updates on
 * every move, but the whole gesture becomes a single undo step.
 */
export declare class DocumentStore<D> {
    private readonly validate;
    protected doc: D;
    private readonly history;
    private gesture;
    private snapshot;
    private readonly listeners;
    constructor(doc: D, validate: Validate);
    /** Stable between changes; suitable for React's useSyncExternalStore. */
    getSnapshot: () => StoreSnapshot<D>;
    subscribe: (listener: () => void) => (() => void);
    get document(): D;
    set(path: Path, value: unknown, label?: string): SetStatus;
    /** Starts a continuous edit. Changes until `commit()` become one undo step. */
    begin(label: string): void;
    commit(): void;
    /** Abandons the current continuous edit and restores the document as it was when it began. */
    cancel(): void;
    undo(): boolean;
    redo(): boolean;
    /** Replaces the document entirely and forgets the undo history. */
    load(doc: D): void;
    /** Validates and applies several values as one step (merged into the gesture if one is open). */
    protected apply(label: string, values: [Path, unknown][]): void;
    private makeSnapshot;
    private emit;
}
/** A validator for documents whose editable values are each described by a ParamSpec, looked up by path. */
export declare function paramValidator(lookup: (path: Path) => ParamSpec | undefined): Validate;
