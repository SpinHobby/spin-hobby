/**
 * Shader steps as recipe data: which shader, and the values of its sliders. The shader's code lives in the shaders
 * folder (`packages/shaders`); a document only names it, so it stays small JSON that any host can store.
 */
export type ShaderValue = number | boolean | string;
export interface ShaderStep {
    /** The shader file's name without its extension, e.g. `sharpen`. */
    id: string;
    /** Slider values by parameter key (the uniform name without its leading `u`, in camelCase: `uAmount` is `amount`). */
    params: Record<string, ShaderValue>;
}
export declare const MAX_SHADER_STEPS = 12;
/** A valid list of steps, or undefined if `value` isn't one (used to validate edits). */
export declare function checkShaderSteps(value: unknown): ShaderStep[] | undefined;
/** Reads saved steps from untrusted JSON, keeping the valid ones. Whether a shader still exists is checked where it is used. */
export declare function normalizeShaderSteps(value: unknown): ShaderStep[];
/** The list with one step's slider changed (a new array, so documents stay immutable). */
export declare function withStepParam(steps: readonly ShaderStep[], index: number, key: string, value: ShaderValue): ShaderStep[];
export declare function movedStep(steps: readonly ShaderStep[], index: number, direction: 1 | -1): ShaderStep[];
