/**
 * Recolouring the product: every pixel whose hue is close to `from` takes the hue of `to`, with its saturation and brightness scaled by how
 * `to` differs from `from`, so shading, folds and highlights stay where they were. Grey pixels (no hue to speak of) are left alone, and the
 * change fades out over the last part of `range` so there is no hard edge. The renderer's shader (render2d) does the same per pixel; this
 * is the reference it is tested against.
 *
 * It changes the product's own colour, unlike everything else in the editor, so the op is off by default and says so.
 */
export type Rgb = readonly [number, number, number];
export interface RecolourSettings {
    /** The colour to change and the new colour, 0-1 RGB. */
    from: Rgb;
    to: Rgb;
    /** Degrees of hue either side of `from` that count as the same colour (5-90). */
    range: number;
}
export declare function rgbToHsv([r, g, b]: Rgb): [number, number, number];
export declare function hsvToRgb(h: number, s: number, v: number): [number, number, number];
/** How strongly a pixel is recoloured, 0-1: close in hue to `from`, and coloured enough to have a hue. */
export declare function recolourWeight(rgb: Rgb, settings: RecolourSettings): number;
export declare function recolourPixel(rgb: Rgb, settings: RecolourSettings): [number, number, number];
/** `#rrggbb` as 0-1 RGB. */
export declare const hexToRgb: (hex: string) => [number, number, number];
