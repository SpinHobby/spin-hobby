import type { PhotoDocument } from './document.js';
import { type CropRect } from './geometry.js';
import { type MaskOp } from './mask.js';
import { type ShaderStep, type ShaderValue } from './shaders.js';
import { type CropAspect } from './ops.js';
import { type Path } from './path.js';
import { type WordsStep } from './recipe.js';
import { DocumentStore, type StoreSnapshot } from './store.js';
export type EditorSnapshot = StoreSnapshot<PhotoDocument>;
/**
 * Edits one photo document: any recipe parameter by path (`set('recipe/ops/light/exposure', 0.5)`), plus
 * commands that change several values at once as a single undo step (`rotate(1)` also moves the crop).
 */
export declare class Editor extends DocumentStore<PhotoDocument> {
    constructor(doc: PhotoDocument);
    /**
     * Any edit other than the finishing touches themselves drops them: that picture was redrawn from the picture as it was, so it would no
     * longer match. Undo brings it back.
     */
    protected apply(label: string, values: [Path, unknown][]): void;
    get finish(): import("./recipe.js").FinishStep | null;
    /** Records a finishing redraw of the whole picture; `ref` names the redrawn picture the host keeps. */
    setFinish(model: string, ref: string): void;
    clearFinish(): void;
    get mask(): readonly MaskOp[];
    get words(): WordsStep | null;
    /**
     * Turns the clean-up on (with its defaults) or off. `lettering: false` searches only for the given price `stickers` (flat normalized
     * x, y, width, height boxes) and leaves white lettering alone.
     */
    setWords(on: boolean, options?: {
        lettering?: boolean;
        stickers?: number[];
    }): void;
    /** Records that an AI fill model repainted the lettering; `ref` names the repainted picture the host keeps. */
    setWordsAi(model: string, ref: string): void;
    /** Changes one setting of the lettering removal. Wrap a drag in `begin()` and `commit()` to make it one undo step. */
    setWordsParam(key: keyof WordsStep, value: number, label?: string): void;
    /** An enlarged picture was made from the picture as it was; once the lettering changes it no longer matches, so it is dropped. */
    private dropUpscale;
    get upscale(): import("./recipe.js").UpscaleStep | null;
    /** Records an AI enlarging; `ref` names the enlarged picture the host keeps. The finished picture becomes `factor` times larger. */
    setUpscale(model: string, ref: string, factor?: number): void;
    clearUpscale(): void;
    get effects(): readonly ShaderStep[];
    /** Adds a shader to the end of the effect list, with the given slider values (the shader's defaults, normally). */
    addEffect(id: string, params: Record<string, ShaderValue>, label?: string): void;
    removeEffect(index: number, label?: string): void;
    /** Moves an effect earlier (-1) or later (+1): the list runs top to bottom. */
    moveEffect(index: number, direction: 1 | -1): void;
    /** Changes one slider of one effect. Wrap a drag in `begin()` and `commit()` to make it a single undo step. */
    setEffectParam(index: number, key: string, value: ShaderValue, label?: string): void;
    /** Applies a ready-made look (Vivid, Extra vivid): the light and colour sliders, plus its effects, as one undo step. */
    applyLook(id: string): void;
    /** Puts the light and colour sliders back to neutral and drops the effects a look adds. */
    clearLook(): void;
    /** Fades the cut-out out along its bottom edge instead of ending in a hard line. `size` is the share of its height that fades. */
    fadeBottom(size?: number): void;
    /** Cuts away boxes (normalized x, y, width, height each), as one undo step: printed text on the cut-out's edge, for example. */
    eraseBoxes(boxes: {
        x: number;
        y: number;
        width: number;
        height: number;
    }[]): void;
    /** Adds a cut-out made by an AI model. `ref` names the mask picture the host keeps with the edit. */
    addModelCutout(model: string, ref: string, options?: {
        replace?: boolean;
    }): void;
    /** Removes a green backdrop from the whole photo (free, instant). Taps and brushes can still touch up the edges after. */
    removeGreenBackdrop(): void;
    /**
     * Frames the cut-out product on a square canvas: crops to the product (`bounds`, the visible part of the cut-out in
     * original-photo coordinates) and leaves `space` (a fraction, 0.06 = 6%) around it. One undo step.
     */
    fitSquareToProduct(bounds: CropRect, space?: number): void;
    /** Adds a cut-out operation (a background tap, or the first point of a brush stroke). */
    addMaskOp(op: MaskOp): void;
    /** Replaces the latest cut-out operation: a brush stroke growing while the pointer moves. */
    updateLastMaskOp(op: MaskOp): void;
    /** Brings back the whole photo. */
    clearMask(): void;
    /** Turns the photo a quarter clockwise (+1) or anticlockwise (−1), carrying the crop and flips along. */
    rotate(direction: 1 | -1): void;
    flip(axis: 'horizontal' | 'vertical'): void;
    /** Chooses a crop aspect ratio and replaces the crop with the largest centred rectangle of that ratio. */
    setCropAspect(aspect: CropAspect): void;
    setCrop(crop: CropRect): void;
    /** Removes every edit, as one undoable step. */
    reset(): void;
    private cropValues;
}
