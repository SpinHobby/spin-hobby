import type { PhotoDocument } from './document.js';
import type { CropRect } from './geometry.js';
/**
 * Where a listing picture is going, and what that marketplace asks of it: the size, how much of the picture the product fills, and what is
 * behind it. One cut-out gives every one of them, so a shop never edits the same photo twice.
 */
export interface MarketplacePreset {
    id: string;
    name: string;
    /** Edge of the square picture, in pixels. */
    size: number;
    /** Space round the product on each side, as a fraction of the picture (0.075: the product fills 85%). */
    margin: number;
    /** White, or the backdrop the photo already has (the shop's own colour or background photo). */
    background: 'white' | 'keep';
    type: 'image/jpeg' | 'image/png' | 'image/webp';
    /** The largest file the marketplace takes, when it says. */
    maxBytes?: number;
    /** The marketplace's rule, in a line, shown beside the preset. */
    rule: string;
}
/** The marketplaces a shop sells on most. Sizes are each one's recommended size, not its minimum. */
export declare const MARKETPLACE_PRESETS: readonly MarketplacePreset[];
export declare function findPreset(id: string): MarketplacePreset | undefined;
/**
 * The document as one marketplace wants it: the product (its box in the original, as fractions) centred on a square with the preset's margin,
 * on white or on the backdrop it already has. The document passed in is not changed.
 */
export declare function presetDocument(doc: PhotoDocument, productBox: CropRect, preset: MarketplacePreset): PhotoDocument;
/** A safe file name for one preset's picture: "<photo name>-<preset>.<ext>". */
export declare function presetFileName(photoName: string, preset: MarketplacePreset): string;
