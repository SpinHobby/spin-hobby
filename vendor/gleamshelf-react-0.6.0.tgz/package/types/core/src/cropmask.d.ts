import type { PhotoDocument } from './document.js';
import { type BitmapMask } from './mask.js';
/**
 * An AI mask made from the cropped view of a photo (so it covers only the crop) becomes a mask over the whole original,
 * which is what the recipe stores. Everything outside the crop is cut away. Turns, flips and straightening are accounted for.
 */
export declare function cropMaskToSource(doc: PhotoDocument, mask: BitmapMask): BitmapMask;
