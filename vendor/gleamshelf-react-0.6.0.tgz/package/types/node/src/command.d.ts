import type { Background } from '../../pipeline/src/index.js';
import type { StickerClient } from './stickers';
export declare const USAGE = "gleamshelf polish <photo...> --out <folder> [options]\n\nTurns product photos into square listing photos. Free: nothing is sent anywhere. Your originals are never changed or deleted.\n\n  --out <folder>        where the finished photos go (required, and must not be a photo's own folder)\n  --size <px>           square edge length, default 1600\n  --sizes <px,px,...>   also write other sizes, e.g. 1600,800,200 (files are named name-800.jpg)\n  --background <bg>     white (default), transparent, or a colour like #f4efe6\n  --padding <0-0.4>     space around the product, default 0.06\n  --shadow              add a soft shadow under the product\n  --cutout <mode>       auto (default: remove a green backdrop if the photo has one), green, or none\n  --enhance             a gentle brightness, contrast, vibrance and sharpness lift\n  --stickers <boxes>    paint over price stickers you point out: x,y,w,h as fractions, several separated by ; (free)\n  --find-stickers       let the AI find price stickers and shop labels for you. COSTS about 2 cents a photo and needs\n                        ANTHROPIC_API_KEY set; the cost is printed. Without this flag nothing is sent anywhere.\n  --quad <8 numbers>    straighten a box face; corners as fractions: tlx,tly,trx,try,brx,bry,blx,bly\n  --crop <x,y,w,h>      keep only this part of the photo first, as fractions\n  --format <fmt>        jpeg, png or webp. Default jpeg, or png if the result is transparent\n  --quality <1-100>     for jpeg and webp, default 90\n  --force               overwrite files that already exist in the output folder\n";
export declare class UsageError extends Error {
}
export declare function parseBackground(text: string): Background;
export interface RunResult {
    written: string[];
    skipped: string[];
    /** What the AI sticker search cost in US dollars; 0 when it was not used. */
    costUsd: number;
}
/** Runs the `polish` command. Throws UsageError for bad input; the caller prints it. */
export declare function runPolish(argv: string[], log?: (line: string) => void, hooks?: {
    stickerClient?: StickerClient;
}): Promise<RunResult>;
