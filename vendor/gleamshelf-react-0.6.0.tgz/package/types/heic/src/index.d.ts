import type { Img } from '../../pipeline/src/index.js';
/**
 * True for a HEIC/HEIF photo, as iPhones save them. Looks at the file's own first bytes (its "ftyp" box), not its name,
 * so a mislabelled file is still recognised. AVIF files are not HEIC: sharp and browsers read those on their own.
 */
export declare function isHeic(bytes: Uint8Array): boolean;
/**
 * Decodes a HEIC photo to RGBA pixels, upright (the camera's rotation is applied). The decoder is loaded the first time
 * this is called, so a page that never meets a HEIC file never downloads it.
 */
export declare function decodeHeic(bytes: Uint8Array): Promise<Img>;
