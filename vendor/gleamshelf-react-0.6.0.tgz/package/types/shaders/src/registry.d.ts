import { type ShaderDef, type ShaderScope } from './parse';
export interface ShaderLibrary {
    fragment: ShaderDef[];
    vertex: ShaderDef[];
    /** Files that could not be read, with the reason. A bad file is skipped; it never breaks the others. */
    errors: string[];
}
/** Builds a library from `{ path: file text }`. Paths ending `.frag.glsl` and `.vert.glsl` are the two kinds. */
export declare function loadShaders(files: Record<string, string>): ShaderLibrary;
export declare const SHADERS: ShaderLibrary;
export declare const findFragment: (id: string) => ShaderDef | undefined;
export declare const findVertex: (id: string) => ShaderDef | undefined;
/** Effects to offer in a menu. Photos accept both scopes; a 3D scene only has a finished picture, so only `image`. */
export declare function listEffects(scopes?: readonly ShaderScope[]): ShaderDef[];
/** 3D vertex shaders to offer in a menu (the system `fullscreen` shader is left out). */
export declare function listDisplacements(): ShaderDef[];
export declare const FULLSCREEN_VERTEX: string;
