import { type ParamSpec, type ShaderStep, type ShaderValue } from '../../core/src/index.js';
export type ShaderKind = 'fragment' | 'vertex';
/** `effect` changes the colours of a picture, `displace` moves the vertices of a 3D object, `fullscreen` is a system shader. */
export type ShaderContract = 'effect' | 'displace' | 'fullscreen';
/** `product` effects run on the cut-out before the background is added (a shadow needs that); `image` effects run on the finished picture. */
export type ShaderScope = 'image' | 'product';
export interface ShaderParam {
    /** The GLSL uniform, e.g. `uAmount`. */
    uniform: string;
    /** Where its value is kept in a recipe or scene, e.g. `amount`. */
    key: string;
    glslType: 'float' | 'int' | 'bool' | 'vec3';
    spec: ParamSpec;
}
export interface ShaderDef {
    /** The file name without its extension. */
    id: string;
    kind: ShaderKind;
    name: string;
    description: string;
    contract: ShaderContract;
    scope: ShaderScope;
    /** Changes over time, so a 3D scene keeps redrawing while it is in use. */
    animated: boolean;
    params: ShaderParam[];
    /** The file's text, as written. */
    source: string;
}
export declare class ShaderParseError extends Error {
    constructor(file: string, message: string, line?: number);
}
/** `uBlurRadius` becomes `blurRadius`. */
export declare const paramKey: (uniform: string) => string;
/** Reads one shader file. Throws a ShaderParseError that names the file and line, so a mistake is easy to find. */
export declare function parseShader(id: string, kind: ShaderKind, source: string): ShaderDef;
/** The slider values to start from. */
export declare function defaultParams(def: ShaderDef): Record<string, ShaderValue>;
/** Every slider's value, clamped into its range; anything missing or invalid falls back to the default. */
export declare function resolveParams(def: ShaderDef, saved: Record<string, ShaderValue> | undefined): Record<string, ShaderValue>;
/** What to hand to the GPU for one slider: a number, or three numbers for a colour. */
export declare function uniformValue(param: ShaderParam, value: ShaderValue): number | [number, number, number];
export type { ShaderStep };
