import type { ShaderDef } from './parse';
/**
 * What every effect gets for free, so a shader file only holds its own idea:
 *   uInput        the picture so far            uResolution   its size in pixels
 *   uTime         seconds (always 0 when saving a still, so a saved picture is the same every time)
 *   sampleInput(uv)   the colour of the picture at uv (0,0 is the top-left corner, 1,1 the bottom-right)
 *   perMille(n)   a distance of n thousandths of the picture's longest side, as a uv offset. Use it for blur sizes and
 *                 offsets so an effect looks the same in the small preview and in the full-size save.
 */
export declare const EFFECT_PRELUDE = "#version 300 es\nprecision highp float;\nuniform sampler2D uInput;\nuniform vec2 uResolution;\nuniform float uTime;\nuniform bool uFlipY;\nuniform bool uInputFlipped;\nout vec4 outColor;\nvec4 sampleInput(vec2 uv) { return texture(uInput, uInputFlipped ? vec2(uv.x, 1.0 - uv.y) : uv); }\nvec2 perMille(float v) { return v * 0.001 * max(uResolution.x, uResolution.y) / uResolution; }\n";
/** The complete fragment shader for an effect: the prelude, the file, and a `main` that calls `effect`. */
export declare function composeEffectFragment(def: ShaderDef): string;
/**
 * The pieces that put a `displace` shader into a Three.js material: `declarations` goes where the vertex shader declares
 * its uniforms and functions, `call` replaces the line that sets the vertex position. `uTime` is provided.
 */
export declare function composeDisplace(def: ShaderDef): {
    declarations: string;
    call: string;
};
