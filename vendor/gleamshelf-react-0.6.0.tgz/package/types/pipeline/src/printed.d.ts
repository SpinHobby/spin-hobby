import type { Img, Rect } from './image';
import { type Mask } from './inpaint';
/**
 * The pixels of printed text inside a text box: the ones whose colour clearly differs from the paper around the box. Repainting these
 * (instead of the whole rectangle) leaves everything behind the lettering untouched, so a repaint model only has to rebuild thin strokes.
 *
 * `box` is in fractions of the picture. Returns a picture-sized mask. When the paper is so busy that most of the box differs, the box is
 * left alone (an empty result): a rectangle of invented picture is worse than a word that stays.
 */
export declare function printedPixels(img: Img, box: Rect, distance?: number): Mask;
/** Pixels in the box that are thinner than about a quarter of its height and clearly darker or lighter than their surroundings. */
export declare function thinStrokes(img: Img, x0: number, y0: number, x1: number, y1: number, contrast?: number): Mask;
/** Why a click selected nothing: there was no print at that point, or that colour covers so much of the text's area that it is surely picture. */
export interface KeyedProblem {
    problem: 'no-print' | 'too-much';
}
export interface KeyedStrokes {
    mask: Mask;
    /** The colour of the stroke that was clicked. */
    color: [number, number, number];
}
/**
 * For a click on printed text: finds the colour of the letter that was clicked (the pixel near the click that differs most from what is around it) and
 * selects every pixel of that colour inside `region` (pixels, x0 y0 x1 y1). The person did the hard part of telling print from picture by clicking, so
 * this works over any background. A `problem` when there is nothing printed at the point, or when so much of the region has that colour that it is surely
 * picture, not print (a black title selects its black, and a second click on the red part selects the red).
 */
export declare function colourKeyedStrokes(img: Img, region: {
    x0: number;
    y0: number;
    x1: number;
    y1: number;
}, point: {
    x: number;
    y: number;
}, tolerance?: number): KeyedStrokes | KeyedProblem;
/**
 * The ink of a big printed title, found without anyone clicking on it: `region` (pixels) is the title's box. The ink is the colour that stands furthest from
 * the box's own middle colour (dark or light), then a second and third colour if clear strokes of another colour remain (a red accent in a black title). Every pixel near an ink colour is a
 * candidate; only the pieces that are stroke-shaped are kept (nothing wider than `maxStroke` across, judged in a window a little bigger than the box, so the box's edge does
 * not make a big dark area of the artwork look thin), and a colour that covers most of the box is the paper, not the ink, and is skipped. Small areas the strokes enclose are
 * filled (the body of a light letter with a dark outline). The mask is grown by `grow` pixels for the soft edge. Returns it and the ink colours found, or a `problem`.
 */
export declare function titleInk(img: Img, region: {
    x0: number;
    y0: number;
    x1: number;
    y1: number;
}, options?: {
    tolerance?: number;
    maxStroke?: number;
    grow?: number;
    maxShare?: number;
    /** The least mean edge sharpness (0-255 of brightness) a piece of ink needs: print is crisp, shading in a photograph is soft (default 45). */ crisp?: number;
    log?: (line: string) => void;
}): {
    mask: Mask;
    colors: [number, number, number][];
} | KeyedProblem;
