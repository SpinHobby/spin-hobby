/** A picture as plain pixels: RGBA, 4 bytes per pixel, row by row. No browser or Node API is needed to work on one. */
export interface Img {
    width: number;
    height: number;
    data: Uint8ClampedArray;
}
export interface Point {
    x: number;
    y: number;
}
/** A four-cornered area of a photo as fractions (0-1) of its width and height, in the order top-left, top-right, bottom-right, bottom-left. */
export type Quad = [Point, Point, Point, Point];
/** A box as fractions (0-1) of the picture's width and height, measured from the top-left corner. */
export interface Rect {
    x: number;
    y: number;
    width: number;
    height: number;
}
export declare const createImg: (width: number, height: number, fill?: [number, number, number, number]) => Img;
export declare const cloneImg: (img: Img) => Img;
