import type { Img } from './image';
/** The share of a photo's border that is green. A photo shot on a green backdrop has a green frame all the way round. */
export declare function greenBorderShare(img: Img): number;
/**
 * Makes a green backdrop transparent. The transparency is worked out in the editor's core (one copy of the rule, so the browser and the command line cut a backdrop out
 * identically); green spill on the product's edges is pulled back here. Free, instant, and it works on any computer.
 */
export declare function keyOutGreen(src: Img): Img;
/**
 * Takes the green the backdrop reflects onto the product (a glossy box top, a pale edge) back off, and returns the share of the product it changed. Only a muted
 * green tint is touched: a pixel whose green leads by under 30% of its brightness loses it fully, fading to untouched at 42%, so printed greens (a logo, a glow,
 * far more saturated than a reflection) stay as they are. Only pixels inside the cut-out (alpha over 0) change. `mirrored` marks pixels the key took for backdrop
 * that belong to the product (filled back to the box's outline): a glossy face mirroring the cloth, so they lose their green however strong it is.
 */
export declare function pullGreenSpill(img: Img, alpha: Uint8Array, mirrored?: Uint8Array): number;
export { dropWisps } from '../../core/src/index.js';
/** The picture cropped to its visible (non-transparent) part, with a little room around it. Null if nothing is visible. */
export declare function trimToContent(src: Img, padFraction?: number, threshold?: number): Img | null;
