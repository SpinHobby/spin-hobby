import type { Img, Quad } from './image';
/** How far each corner moves toward the centre, as a fraction: leaves the very edge of a face (and the backdrop beyond it) out. */
export declare function insetQuad(quad: Quad, k: number): Quad;
/**
 * The real width/height of a flat face, read from a photo of it: the mean of the top and bottom edges over the mean of the
 * side edges, measured in pixels (the photo's own width and height matter because the corners are fractions).
 */
export declare function quadAspect(quad: Quad, width: number, height: number): number;
/**
 * Cuts a four-cornered area out of a photo and flattens it into a straight rectangle (perspective correction and crop
 * in one step). Everything outside the corners, a hand, a table, a bottle, is gone.
 */
export declare function flattenQuad(src: Img, quad: Quad, outWidth: number, outHeight: number): Img;
export interface FoundQuad {
    /** The four corners as fractions of the picture: top-left, top-right, bottom-right, bottom-left. */
    quad: Quad;
    /** How much of the cut-out the four corners cover, and how much of the area between them the cut-out fills: both near 1 for a flat card or box front. */
    covers: number;
    fills: number;
    /** Whether it is a four-cornered flat thing worth flattening (a card, a box front, a print), not a figure or an angled box. */
    flat: boolean;
}
/**
 * Finds the four corners of a flat four-cornered product (a trading card, a box's front cover, a print) from its cut-out: the largest four-cornered shape that
 * fits in the outline's hull. `flat` says whether the cut-out really is one (the corners cover nearly all of it, and it nearly fills them).
 */
export declare function quadFromMask(alpha: Uint8Array, w: number, h: number): FoundQuad | null;
/**
 * A flat product (card, box front, print) photographed at an angle, made straight: the four corners found from its cut-out are pulled to a rectangle of its
 * real shape, keeping only the photo's own pixels. Null when the cut-out is not four-cornered and flat (a figure, an angled box showing two sides).
 */
export declare function flattenCutout(src: Img, alpha: Uint8Array, maskWidth: number, maskHeight: number): {
    image: Img;
    quad: Quad;
} | null;
