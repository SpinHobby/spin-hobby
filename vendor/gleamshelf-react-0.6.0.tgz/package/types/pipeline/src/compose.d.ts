import type { Img } from './image';
export type Background = {
    r: number;
    g: number;
    b: number;
} | {
    top: [number, number, number];
    bottom: [number, number, number];
} | 'transparent';
export interface SquareOptions {
    /** Edge length of the square in pixels. */
    size: number;
    /** Space around the product, as a fraction of the size (0.06 = 6%). */
    padding?: number;
    /** A solid colour, a top-to-bottom gradient, or 'transparent' (the product keeps its own alpha). */
    background?: Background;
    /** A soft shadow under the product, taken from its own shape. */
    shadow?: {
        opacity: number;
        blur: number;
        offsetY: number;
    };
}
/**
 * Puts a picture (usually a transparent cut-out) in the middle of a square canvas on the chosen background, with an optional
 * soft shadow. The same cut-out can be put on white for a marketplace, on a colour for the shop, or left transparent, so
 * swapping a seasonal background never means touching the photo again.
 */
export declare function composeOnSquare(product: Img, options: SquareOptions): Img;
