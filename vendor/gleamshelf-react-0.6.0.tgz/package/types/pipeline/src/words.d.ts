import type { Img } from './image';
import { type Mask } from './inpaint';
export interface WordsOptions {
    /** How bright a pixel must be, 0-255 on every channel, to count as white lettering. */
    lightness: number;
    /** The thickest a stroke can be, in thousandths of the picture's longest side. Anything fatter (a white bow, a pompom) is kept. */
    maxWidth: number;
    /** The shortest a piece of lettering can be, in thousandths of the longest side. Anything smaller (a glint in an eye) is kept. */
    minLength: number;
}
export declare const DEFAULT_WORDS: WordsOptions;
/**
 * Finds white lettering: pieces of white that are thin (not a big white area), long (not a small glint), and inside
 * `inside` (the cut-out, so nothing outside the product is touched). Returns a mask of where the letters are, grown a little
 * so their soft edges are included.
 */
export declare function findWhiteWords(img: Img, options?: WordsOptions, inside?: Mask): Mask;
/** Paints over white lettering with what surrounds it. Returns the repaired picture and how many pixels were filled in. */
export declare function removeWhiteWords(img: Img, options?: WordsOptions, inside?: Mask, extra?: Mask, lettering?: boolean): {
    image: Img;
    filled: number;
};
