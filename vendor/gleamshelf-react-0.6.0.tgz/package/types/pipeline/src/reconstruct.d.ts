import type { Img } from './image';
import { type Mask } from './inpaint';
export interface InkOptions {
    /** Pixels to grow the ink by, to take in its soft edge (default 2). */
    grow?: number;
    /** The smallest piece of ink kept, in pixels (default 14). */
    minPiece?: number;
    /** The smallest difference (CIE Lab) that can count as ink (default 8). */
    floor?: number;
}
/**
 * The ink of printed text, found by reconstruction: `filled` is the picture with the loose `region` (a rectangle round each line of text) filled in
 * from its surroundings, so it shows what is behind the print. What differs strongly from it inside the region is the print. This works over any
 * background, which colour tests cannot, and it gives a mask as tight as the strokes themselves, so a second fill changes as little as possible.
 */
export declare function inkByReconstruction(original: Img, filled: Img, region: Mask, options?: InkOptions): Mask;
