import type { Img, Rect } from './image';
/**
 * An AI (or a person) points at a sticker roughly. This snaps that box to the sticker itself: the connected light, colourless
 * patch (white or cream paper) that sits mostly inside the rough box, plus a little room for the dark rules printed on the
 * label's edges. A rough box that is too wide would smear the box artwork around it; one that is too short would leave a strip
 * of the sticker behind. If no clear sticker is found, or the patch runs on into the box's own white areas, the rough box is
 * returned unchanged.
 */
export declare function tightenStickerBox(img: Img, rough: Rect): Rect;
