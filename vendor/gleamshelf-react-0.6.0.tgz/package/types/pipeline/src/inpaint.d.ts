import type { Img, Rect } from './image';
/** A mask is one byte per pixel: 1 where the pixel is to be filled in, 0 where it is kept. */
export type Mask = Uint8Array;
/** A mask covering the given boxes, each grown by a margin (as fractions of the picture's size). */
export declare function maskFromRects(width: number, height: number, rects: Rect[], marginX?: number, marginY?: number): Mask;
export declare function dilateMask(mask: Mask, width: number, height: number, radius: number): Mask;
export declare const unionMasks: (...masks: Mask[]) => Mask;
/**
 * Fills the masked pixels from what surrounds them, so a sticker or a small mark disappears into soft artwork. It solves a
 * small copy of the picture first and refines it at full size, which gives a natural result instead of a flat smear.
 * It cannot invent detail: over busy artwork (a big printed title across a patterned dress) the fill is blurry. That is
 * the honest limit of a free, non-generative fill.
 */
export declare function inpaint(src: Img, mask: Mask): Img;
