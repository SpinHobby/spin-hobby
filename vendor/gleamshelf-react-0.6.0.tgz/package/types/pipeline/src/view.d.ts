/**
 * Is this photo of a box seen square-on (a flat front cover), or at an angle (a top face and a side face showing)?
 *
 * Only the box's silhouette is used. Seen square-on, a box is a four-cornered shape, even if the camera is a little off (a trapezoid) or the photo is
 * tilted. At an angle, the top and the side show too, so the outline has extra corners and bulges out of the best four-cornered shape that fits it.
 * `extra` is how much: the area of the silhouette's convex hull over the area of the largest quadrilateral that can be drawn between points of the hull,
 * minus one. On seven real photos square-on boxes measured 0.022-0.027 and angled ones 0.090-0.105, and the line is drawn between them at 0.06. Seven photos is a small sample: check it on yours.
 * It cannot be sure of a silhouette that is not a box at all (a hand holding it, a room round it): that is 'unknown', decided by `solidity` (mask area over hull
 * area: real boxes 0.964-0.993, the failed cut-out of a box held in a hand 0.827; the line is 0.9).
 */
export type BoxView = 'front' | 'angled' | 'unknown';
export interface BoxViewResult {
    view: BoxView;
    /** Hull area over best-quadrilateral area, minus one. 0 for a perfect four-cornered shape. */
    extra: number;
    /** How much of its convex hull the silhouette fills: 1 for a solid convex shape like a box, far less for a figure or a hand with fingers out. Turning the photo does not change it. */
    solidity: number;
    /** The best four corners, as fractions of the picture (clockwise from the top-left-most), when a silhouette was found. */
    corners?: {
        x: number;
        y: number;
    }[];
}
type P = {
    x: number;
    y: number;
};
/** The convex hull (Andrew's monotone chain), counter-clockwise in image coordinates, without repeating the first point. */
export declare function convexHull(points: P[]): P[];
export declare const polygonArea: (poly: P[]) => number;
/** A closed polygon with points that lie within `eps` of the line between their neighbours dropped. Corners survive. */
export declare function simplifyPolygon(poly: P[], eps: number): P[];
/** The four of `poly`'s points (kept in order) that enclose the most area. */
export declare function bestQuad(poly: P[]): {
    area: number;
    quad: P[];
};
/**
 * Classifies the box's silhouette (`alpha`, 0-255 at `width` by `height`). A silhouette below `minSolidity` is not box-shaped at all and the answer is 'unknown'; so is one under 4% of the picture.
 */
export declare function classifyBoxView(alpha: Uint8Array, width: number, height: number, options?: {
    threshold?: number;
    line?: number;
    minSolidity?: number;
}): BoxViewResult;
/**
 * Fills a box's silhouette up to its convex outline, in place: a box has no dents, so a bite taken out of its edge is a part of the picture the cut-out lost (a bright green
 * glow printed on the cover that a green-screen key took for cloth), not background. Only the largest piece counts; pixels outside the outline are left alone. Returns
 * how many pixels were added, so a caller can tell a small repair from a silhouette that was not a box after all (check `classifyBoxView` first).
 */
export declare function fillToHull(alpha: Uint8Array, width: number, height: number, threshold?: number): number;
export {};
