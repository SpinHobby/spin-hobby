import type { Img, Rect } from './image';
export interface EnhanceOptions {
    /** Brightness in photographic stops: 0 leaves it, +0.3 is a little brighter. */
    exposure?: number;
    /** -1 to 1. More separates light from dark. */
    contrast?: number;
    /** 0 to 1. Lifts muted colours more than already-strong ones, so the picture gets vivid without going garish. */
    vibrance?: number;
    /** Plain saturation, -1 to 1. Usually vibrance is the better choice. */
    saturation?: number;
    /** 0 to 2. Sharpening strength. */
    sharpen?: number;
}
/** Unsharp mask on the brightness only, so edges get crisper without colour fringes or noisy colour. */
export declare function sharpen(src: Img, amount: number, radius?: number): Img;
/** Exposure, contrast, vibrance, saturation and sharpening in one pass. Order matters little for small adjustments. */
export declare function enhance(src: Img, options?: EnhanceOptions): Img;
/**
 * Corrects a colour cast: the average colour of an area that should be neutral (a white card, a grey patch, plain white
 * backdrop) is scaled to neutral grey for the whole picture.
 */
export declare function whiteBalance(src: Img, reference: Rect): Img;
/**
 * Resizes to exact pixel dimensions. Shrinking averages the pixels it covers (clean, no jaggies); enlarging uses bicubic
 * interpolation. This is a plain, honest resize: it does not invent detail. A learned upscaler would be a separate,
 * optional and labelled step.
 */
export declare function resize(src: Img, outWidth: number, outHeight: number): Img;
export interface ToneOptions {
    /** Lightness contrast around `pivot`: lightness becomes L + contrast * (L - pivot). 0 leaves it; 0.25 is gentle. Hue and colour are kept, unlike a per-channel contrast. */
    contrast?: number;
    /** The lightness (0-100) that stays where it is. Darker tones get darker, lighter ones lighter. Default 54. */
    pivot?: number;
    /** Colour strength: 1 leaves it, 1.1 is 10% richer. Scales Lab a and b, so hue stays. */
    chroma?: number;
}
/**
 * Changes lightness contrast and colour strength in CIE Lab, where lightness is separate from colour, so brightening a skin tone does not make it more
 * yellow and a darker hair tone does not turn. On a cover photographed through shrink-wrap (hazy, low contrast) a gentle contrast lifts the lights.
 */
export declare function tone(src: Img, options?: ToneOptions): Img;
/** sRGB (0-255) to CIE Lab (D65): [L, a, b]. */
export declare function rgbToLab(r: number, g: number, b: number): [number, number, number];
/** CIE Lab (D65) back to sRGB (0-255, clamped): [r, g, b]. */
export declare function labToRgb(L: number, a: number, b: number): [number, number, number];
