import { At as e, Et as t, F as n, Fn as r, H as i, I as a, Ot as o, Vn as s, Wt as c, Xn as l, b as u, bt as d, ct as f, f as p, gr as m, kt as h, l as g, lt as _, p as v, pt as y, tr as b, u as x, xt as S } from "./three.core-DIbF123p.js";
import { t as C } from "./fflate.module-d2PQQWvd.js";
import { t as w } from "./BufferGeometryUtils-BdA1pL-e.js";
//#region ../../node_modules/three/examples/jsm/loaders/3MFLoader.js
var T = s, E = "http://schemas.microsoft.com/3dmanufacturing/beamlattice/2017/02", D = "http://schemas.microsoft.com/3dmanufacturing/beamlattice/balls/2020/07", O = class extends y {
	constructor(e) {
		super(e), this.availableExtensions = [];
	}
	load(e, t, r, i) {
		let a = this, o = new n(a.manager);
		o.setPath(a.path), o.setResponseType("arraybuffer"), o.setRequestHeader(a.requestHeader), o.setWithCredentials(a.withCredentials), o.load(e, function(n) {
			try {
				t(a.parse(n));
			} catch (t) {
				i ? i(t) : console.error(t), a.manager.itemError(e);
			}
		}, r, i);
	}
	parse(n) {
		let s = this, O = new b(this.manager);
		function k(e) {
			let t = null, n = null, r, i, a = [], o = [], s, c = {}, l = {}, u = {}, d = new TextDecoder();
			try {
				t = C(new Uint8Array(e));
			} catch (e) {
				if (e instanceof ReferenceError) return console.error("THREE.3MFLoader: fflate missing and file is compressed."), null;
			}
			let f = null;
			for (n in t) n.match(/\_rels\/.rels$/) ? r = n : n.match(/3D\/_rels\/.*\.model\.rels$/) ? i = n : n.match(/^3D\/[^\/]*\.model$/) ? f = n : n.match(/^3D\/.*\/.*\.model$/) ? a.push(n) : n.match(/^3D\/Textures?\/.*/) && o.push(n);
			if (a.push(f), r === void 0) throw Error("THREE.ThreeMFLoader: Cannot find relationship file `rels` in 3MF archive.");
			let p = t[r], m = A(d.decode(p));
			if (i) {
				let e = t[i];
				s = A(d.decode(e));
			}
			for (let e = 0; e < a.length; e++) {
				let n = a[e], r = t[n], i = d.decode(r), o = new DOMParser().parseFromString(i, "application/xml");
				o.documentElement.nodeName.toLowerCase() !== "model" && console.error("THREE.3MFLoader: Error loading 3MF - no 3MF document found: ", n);
				let s = o.querySelector("model"), l = {};
				for (let e = 0; e < s.attributes.length; e++) {
					let t = s.attributes[e];
					t.name.match(/^xmlns:(.+)$/) && (l[t.value] = RegExp.$1);
				}
				let u = G(s);
				u.xml = s, 0 < Object.keys(l).length && (u.extensions = l), c[n] = u;
			}
			for (let e = 0; e < o.length; e++) {
				let n = o[e];
				u[n] = t[n].buffer;
			}
			return {
				rels: m,
				modelRels: s,
				model: c,
				printTicket: l,
				texture: u
			};
		}
		function A(e) {
			let t = [], n = new DOMParser().parseFromString(e, "application/xml").querySelectorAll("Relationship");
			for (let e = 0; e < n.length; e++) {
				let r = n[e], i = {
					target: r.getAttribute("Target"),
					id: r.getAttribute("Id"),
					type: r.getAttribute("Type")
				};
				t.push(i);
			}
			return t;
		}
		function j(e) {
			let t = {};
			for (let n = 0; n < e.length; n++) {
				let r = e[n], i = r.getAttribute("name");
				0 <= [
					"Title",
					"Designer",
					"Description",
					"Copyright",
					"LicenseTerms",
					"Rating",
					"CreationDate",
					"ModificationDate"
				].indexOf(i) && (t[i] = r.textContent);
			}
			return t;
		}
		function ee(e) {
			let t = {
				id: e.getAttribute("id"),
				basematerials: []
			}, n = e.querySelectorAll("base");
			for (let e = 0; e < n.length; e++) {
				let r = n[e], i = I(r);
				i.index = e, t.basematerials.push(i);
			}
			return t;
		}
		function te(e) {
			return {
				id: e.getAttribute("id"),
				path: e.getAttribute("path"),
				contenttype: e.getAttribute("contenttype"),
				tilestyleu: e.getAttribute("tilestyleu"),
				tilestylev: e.getAttribute("tilestylev"),
				filter: e.getAttribute("filter")
			};
		}
		function ne(e) {
			let t = {
				id: e.getAttribute("id"),
				texid: e.getAttribute("texid"),
				displaypropertiesid: e.getAttribute("displaypropertiesid")
			}, n = e.querySelectorAll("tex2coord"), r = [];
			for (let e = 0; e < n.length; e++) {
				let t = n[e], i = t.getAttribute("u"), a = t.getAttribute("v");
				r.push(parseFloat(i), parseFloat(a));
			}
			return t.uvs = new Float32Array(r), t;
		}
		function M(e) {
			let t = {
				id: e.getAttribute("id"),
				displaypropertiesid: e.getAttribute("displaypropertiesid")
			}, n = e.querySelectorAll("color"), r = [], i = new v();
			for (let e = 0; e < n.length; e++) {
				let t = n[e].getAttribute("color");
				i.setStyle(t.substring(0, 7), T), r.push(i.r, i.g, i.b);
			}
			return t.colors = new Float32Array(r), t;
		}
		function N(e) {
			let t = e.children, n = {};
			for (let e = 0; e < t.length; e++) {
				let r = { type: t[e].nodeName.substring(2) };
				for (let n = 0; n < t[e].attributes.length; n++) {
					let i = t[e].attributes[n];
					i.specified && (r[i.name] = i.value);
				}
				n[t[e].getAttribute("identifier")] = r;
			}
			return n;
		}
		function P(e) {
			let t = {
				id: e.getAttribute("id"),
				displayname: e.getAttribute("displayname")
			}, n = e.children, r = {};
			for (let e = 0; e < n.length; e++) {
				let t = n[e];
				if (t.nodeName === "i:in" || t.nodeName === "i:out") r[t.nodeName === "i:in" ? "inputs" : "outputs"] = N(t);
				else {
					let e = t.children, n = {
						op: t.nodeName.substring(2),
						identifier: t.getAttribute("identifier")
					};
					for (let t = 0; t < e.length; t++) n[e[t].nodeName.substring(2)] = N(e[t]);
					r[n.identifier] = n;
				}
			}
			return t.operations = r, t;
		}
		function F(e) {
			let t = { id: e.getAttribute("id") }, n = e.querySelectorAll("pbmetallic"), r = [];
			for (let e = 0; e < n.length; e++) {
				let t = n[e];
				r.push({
					name: t.getAttribute("name"),
					metallicness: parseFloat(t.getAttribute("metallicness")),
					roughness: parseFloat(t.getAttribute("roughness"))
				});
			}
			return t.data = r, t;
		}
		function I(e) {
			let t = {};
			return t.name = e.getAttribute("name"), t.displaycolor = e.getAttribute("displaycolor"), t.displaypropertiesid = e.getAttribute("displaypropertiesid"), t;
		}
		function L(e) {
			let t = {}, n = [], r = e.querySelectorAll("vertices vertex");
			for (let e = 0; e < r.length; e++) {
				let t = r[e], i = t.getAttribute("x"), a = t.getAttribute("y"), o = t.getAttribute("z");
				n.push(parseFloat(i), parseFloat(a), parseFloat(o));
			}
			t.vertices = new Float32Array(n);
			let i = [], a = [], o = e.querySelectorAll("triangles triangle");
			for (let e = 0; e < o.length; e++) {
				let t = o[e], n = t.getAttribute("v1"), r = t.getAttribute("v2"), s = t.getAttribute("v3"), c = t.getAttribute("p1"), l = t.getAttribute("p2"), u = t.getAttribute("p3"), d = t.getAttribute("pid"), f = {};
				f.v1 = parseInt(n, 10), f.v2 = parseInt(r, 10), f.v3 = parseInt(s, 10), a.push(f.v1, f.v2, f.v3), c && (f.p1 = parseInt(c, 10)), l && (f.p2 = parseInt(l, 10)), u && (f.p3 = parseInt(u, 10)), d && (f.pid = d), 0 < Object.keys(f).length && i.push(f);
			}
			t.triangleProperties = i, t.triangles = new Uint32Array(a);
			let s = e.getElementsByTagNameNS(E, "beamlattice")[0];
			return s !== void 0 && (t.beamlattice = R(s)), t;
		}
		function R(e) {
			let t = {
				radius: parseFloat(e.getAttribute("radius")),
				minLength: parseFloat(e.getAttribute("minlength")),
				cap: e.getAttribute("cap") || "sphere",
				ballMode: e.getAttributeNS(D, "ballmode") || "none",
				ballRadius: parseFloat(e.getAttributeNS(D, "ballradius")),
				beams: [],
				balls: []
			}, n = e.getAttribute("clippingmode") || e.getAttribute("clipping");
			n !== null && n !== "none" && console.warn("THREE.3MFLoader: Beam lattice clipping is not supported. The lattice is rendered unclipped.");
			let r = e.getElementsByTagNameNS(E, "beam");
			for (let e = 0; e < r.length; e++) {
				let n = r[e], i = {
					v1: parseInt(n.getAttribute("v1"), 10),
					v2: parseInt(n.getAttribute("v2"), 10)
				}, a = n.getAttribute("r1"), o = n.getAttribute("r2");
				a !== null && (i.r1 = parseFloat(a)), o !== null && (i.r2 = parseFloat(o)), t.beams.push(i);
			}
			let i = e.getElementsByTagNameNS(D, "ball");
			for (let e = 0; e < i.length; e++) {
				let n = i[e], r = { vindex: parseInt(n.getAttribute("vindex"), 10) }, a = n.getAttribute("r");
				a !== null && (r.r = parseFloat(a)), t.balls.push(r);
			}
			return t;
		}
		function z(e) {
			let t = [], n = e.querySelectorAll("component");
			for (let e = 0; e < n.length; e++) {
				let r = n[e], i = B(r);
				t.push(i);
			}
			return t;
		}
		function B(e) {
			let t = {};
			t.objectId = e.getAttribute("objectid");
			let n = e.getAttribute("transform");
			return n && (t.transform = V(n)), t;
		}
		function V(e) {
			let t = [];
			e.split(" ").forEach(function(e) {
				t.push(parseFloat(e));
			});
			let n = new d();
			return n.set(t[0], t[3], t[6], t[9], t[1], t[4], t[7], t[10], t[2], t[5], t[8], t[11], 0, 0, 0, 1), n;
		}
		function H(e) {
			let t = { type: e.getAttribute("type") }, n = e.getAttribute("id");
			n && (t.id = n);
			let r = e.getAttribute("pid");
			r && (t.pid = r);
			let i = e.getAttribute("pindex");
			i && (t.pindex = i);
			let a = e.getAttribute("thumbnail");
			a && (t.thumbnail = a);
			let o = e.getAttribute("partnumber");
			o && (t.partnumber = o);
			let s = e.getAttribute("name");
			s && (t.name = s);
			let c = e.querySelector("mesh");
			c && (t.mesh = L(c));
			let l = e.querySelector("components");
			return l && (t.components = z(l)), t;
		}
		function U(e) {
			let t = {};
			t.basematerials = {};
			let n = e.querySelectorAll("basematerials");
			for (let e = 0; e < n.length; e++) {
				let r = n[e], i = ee(r);
				t.basematerials[i.id] = i;
			}
			t.texture2d = {};
			let r = e.querySelectorAll("texture2d");
			for (let e = 0; e < r.length; e++) {
				let n = r[e], i = te(n);
				t.texture2d[i.id] = i;
			}
			t.colorgroup = {};
			let i = e.querySelectorAll("colorgroup");
			for (let e = 0; e < i.length; e++) {
				let n = i[e], r = M(n);
				t.colorgroup[r.id] = r;
			}
			let a = e.querySelectorAll("implicitfunction");
			a.length > 0 && (t.implicitfunction = {});
			for (let e = 0; e < a.length; e++) {
				let n = a[e], r = P(n);
				t.implicitfunction[r.id] = r;
			}
			t.pbmetallicdisplayproperties = {};
			let o = e.querySelectorAll("pbmetallicdisplayproperties");
			for (let e = 0; e < o.length; e++) {
				let n = o[e], r = F(n);
				t.pbmetallicdisplayproperties[r.id] = r;
			}
			t.texture2dgroup = {};
			let s = e.querySelectorAll("texture2dgroup");
			for (let e = 0; e < s.length; e++) {
				let n = s[e], r = ne(n);
				t.texture2dgroup[r.id] = r;
			}
			t.object = {};
			let c = e.querySelectorAll("object");
			for (let e = 0; e < c.length; e++) {
				let n = c[e], r = H(n);
				t.object[r.id] = r;
			}
			return t;
		}
		function W(e) {
			let t = [], n = e.querySelectorAll("item");
			for (let e = 0; e < n.length; e++) {
				let r = n[e], i = { objectId: r.getAttribute("objectid") }, a = r.getAttribute("transform");
				a && (i.transform = V(a)), t.push(i);
			}
			return t;
		}
		function G(e) {
			let t = { unit: e.getAttribute("unit") || "millimeter" }, n = e.querySelectorAll("metadata");
			n && (t.metadata = j(n));
			let r = e.querySelector("resources");
			r && (t.resources = U(r));
			let i = e.querySelector("build");
			return i && (t.build = W(i)), t;
		}
		function K(t, n, i, a) {
			let o = t.texid, s = i.resources.texture2d[o];
			if (s) {
				let t = a[s.path], n = s.contenttype, i = new Blob([t], { type: n }), o = URL.createObjectURL(i), c = O.load(o, function() {
					URL.revokeObjectURL(o);
				});
				switch (c.colorSpace = T, s.tilestyleu) {
					case "wrap":
						c.wrapS = r;
						break;
					case "mirror":
						c.wrapS = h;
						break;
					case "none":
					case "clamp":
						c.wrapS = p;
						break;
					default: c.wrapS = r;
				}
				switch (s.tilestylev) {
					case "wrap":
						c.wrapT = r;
						break;
					case "mirror":
						c.wrapT = h;
						break;
					case "none":
					case "clamp":
						c.wrapT = p;
						break;
					default: c.wrapT = r;
				}
				switch (s.filter) {
					case "auto":
						c.magFilter = f, c.minFilter = _;
						break;
					case "linear":
						c.magFilter = f, c.minFilter = f, c.generateMipmaps = !1;
						break;
					case "nearest":
						c.magFilter = e, c.minFilter = e, c.generateMipmaps = !1;
						break;
					default: c.magFilter = f, c.minFilter = _;
				}
				return c;
			}
			return null;
		}
		function q(e, t, n, r, i, o, s) {
			let c = s.pindex, l = {};
			for (let e = 0, n = t.length; e < n; e++) {
				let n = t[e], r = n.p1 === void 0 ? c : n.p1;
				l[r] === void 0 && (l[r] = []), l[r].push(n);
			}
			let u = Object.keys(l), d = [];
			for (let t = 0, c = u.length; t < c; t++) {
				let c = u[t], f = l[c], p = e.basematerials[c], m = Z(p, r, i, o, s, le), h = new x(), g = [], _ = n.vertices;
				for (let e = 0, t = f.length; e < t; e++) {
					let t = f[e];
					g.push(_[t.v1 * 3 + 0]), g.push(_[t.v1 * 3 + 1]), g.push(_[t.v1 * 3 + 2]), g.push(_[t.v2 * 3 + 0]), g.push(_[t.v2 * 3 + 1]), g.push(_[t.v2 * 3 + 2]), g.push(_[t.v3 * 3 + 0]), g.push(_[t.v3 * 3 + 1]), g.push(_[t.v3 * 3 + 2]);
				}
				h.setAttribute("position", new a(g, 3));
				let v = new S(h, m);
				d.push(v);
			}
			return d;
		}
		function re(e, n, r, i, o, s, c) {
			let l = new x(), u = [], d = [], f = r.vertices, p = e.uvs;
			for (let e = 0, t = n.length; e < t; e++) {
				let t = n[e];
				u.push(f[t.v1 * 3 + 0]), u.push(f[t.v1 * 3 + 1]), u.push(f[t.v1 * 3 + 2]), u.push(f[t.v2 * 3 + 0]), u.push(f[t.v2 * 3 + 1]), u.push(f[t.v2 * 3 + 2]), u.push(f[t.v3 * 3 + 0]), u.push(f[t.v3 * 3 + 1]), u.push(f[t.v3 * 3 + 2]), d.push(p[t.p1 * 2 + 0]), d.push(p[t.p1 * 2 + 1]), d.push(p[t.p2 * 2 + 0]), d.push(p[t.p2 * 2 + 1]), d.push(p[t.p3 * 2 + 0]), d.push(p[t.p3 * 2 + 1]);
			}
			l.setAttribute("position", new a(u, 3)), l.setAttribute("uv", new a(d, 2));
			let m = Z(e, i, o, s, c, K), h = new t({
				map: m,
				flatShading: !0
			});
			return new S(l, h);
		}
		function J(e, n, r, i) {
			let o = new x(), s = [], c = [], l = r.vertices, u = e.colors;
			for (let e = 0, t = n.length; e < t; e++) {
				let t = n[e], r = t.v1, a = t.v2, o = t.v3;
				s.push(l[r * 3 + 0]), s.push(l[r * 3 + 1]), s.push(l[r * 3 + 2]), s.push(l[a * 3 + 0]), s.push(l[a * 3 + 1]), s.push(l[a * 3 + 2]), s.push(l[o * 3 + 0]), s.push(l[o * 3 + 1]), s.push(l[o * 3 + 2]);
				let d = t.p1 === void 0 ? i.pindex : t.p1, f = t.p2 === void 0 ? d : t.p2, p = t.p3 === void 0 ? d : t.p3;
				c.push(u[d * 3 + 0]), c.push(u[d * 3 + 1]), c.push(u[d * 3 + 2]), c.push(u[f * 3 + 0]), c.push(u[f * 3 + 1]), c.push(u[f * 3 + 2]), c.push(u[p * 3 + 0]), c.push(u[p * 3 + 1]), c.push(u[p * 3 + 2]);
			}
			o.setAttribute("position", new a(s, 3)), o.setAttribute("color", new a(c, 3));
			let d = new t({
				vertexColors: !0,
				flatShading: !0
			});
			return new S(o, d);
		}
		function Y(e) {
			let n = new x();
			n.setIndex(new g(e.triangles, 1)), n.setAttribute("position", new g(e.vertices, 3));
			let r = new t({
				name: y.DEFAULT_MATERIAL_NAME,
				color: 16777215,
				flatShading: !0
			});
			return new S(n, r);
		}
		function X(e) {
			let n = e.beamlattice, r = e.vertices, i = [], a = new m(), o = new m(), s = new m(), f = new m(0, 1, 0), p = new c(), h = new d(), g = n.beams, _ = n.cap !== "butt", v = /* @__PURE__ */ new Map();
			for (let e = 0; e < g.length; e++) {
				let t = g[e];
				a.fromArray(r, t.v1 * 3), o.fromArray(r, t.v2 * 3);
				let c = a.distanceTo(o);
				if (c < n.minLength) continue;
				let l = t.r1 === void 0 ? n.radius : t.r1, d = t.r2 === void 0 ? l : t.r2, m = new u(d, l, c, 8, 1, _);
				s.subVectors(o, a).divideScalar(c), p.setFromUnitVectors(f, s), h.makeRotationFromQuaternion(p), h.setPosition(a.add(o).multiplyScalar(.5)), m.applyMatrix4(h), i.push(m), _ && (v.set(t.v1, Math.max(l, v.get(t.v1) || 0)), v.set(t.v2, Math.max(d, v.get(t.v2) || 0))), n.ballMode === "all" && (v.set(t.v1, Math.max(n.ballRadius, v.get(t.v1) || 0)), v.set(t.v2, Math.max(n.ballRadius, v.get(t.v2) || 0)));
			}
			let b = n.balls;
			for (let e = 0; e < b.length; e++) {
				let t = b[e], r = t.r === void 0 ? n.ballRadius : t.r;
				v.set(t.vindex, Math.max(r, v.get(t.vindex) || 0));
			}
			for (let [e, t] of v) {
				let n = new l(t, 8, 6);
				a.fromArray(r, e * 3), n.translate(a.x, a.y, a.z), i.push(n);
			}
			let x = w(i), C = new t({
				name: y.DEFAULT_MATERIAL_NAME,
				color: 16777215
			});
			return new S(x, C);
		}
		function ie(e, t, n, r, i, a) {
			let o = Object.keys(e), s = [];
			for (let c = 0, l = o.length; c < l; c++) {
				let l = o[c], u = e[l];
				switch (ae(l, r)) {
					case "material":
						let e = r.resources.basematerials[l], o = q(e, u, t, n, r, i, a);
						for (let e = 0, t = o.length; e < t; e++) s.push(o[e]);
						break;
					case "texture":
						let c = r.resources.texture2dgroup[l];
						s.push(re(c, u, t, n, r, i, a));
						break;
					case "vertexColors":
						let d = r.resources.colorgroup[l];
						s.push(J(d, u, t, a));
						break;
					case "default":
						s.push(Y(t));
						break;
					default: console.error("THREE.3MFLoader: Unsupported resource type.");
				}
			}
			if (a.name) for (let e = 0; e < s.length; e++) s[e].name = a.name;
			return s;
		}
		function ae(e, t) {
			if (t.resources.texture2dgroup[e] !== void 0) return "texture";
			if (t.resources.basematerials[e] !== void 0) return "material";
			if (t.resources.colorgroup[e] !== void 0) return "vertexColors";
			if (e === "default") return "default";
		}
		function oe(e, t) {
			let n = {}, r = e.triangleProperties, i = t.pid;
			for (let e = 0, t = r.length; e < t; e++) {
				let t = r[e], a = t.pid === void 0 ? i : t.pid;
				a === void 0 && (a = "default"), n[a] === void 0 && (n[a] = []), n[a].push(t);
			}
			return n;
		}
		function se(e, t, n, r, a) {
			let o = new i(), s = ie(oe(e, a), e, t, n, r, a);
			if (e.beamlattice !== void 0) {
				let t = X(e);
				a.name && (t.name = a.name), s.push(t);
			}
			for (let e = 0, t = s.length; e < t; e++) o.add(s[e]);
			return o;
		}
		function ce(e, t, n) {
			if (!e) return;
			let r = [], i = Object.keys(e);
			for (let e = 0; e < i.length; e++) {
				let t = i[e];
				for (let e = 0; e < s.availableExtensions.length; e++) {
					let n = s.availableExtensions[e];
					n.ns === t && r.push(n);
				}
			}
			for (let i = 0; i < r.length; i++) {
				let a = r[i];
				a.apply(n, e[a.ns], t);
			}
		}
		function Z(e, t, n, r, i, a) {
			return e.build === void 0 && (e.build = a(e, t, n, r, i)), e.build;
		}
		function le(e, n, r) {
			let i, a = e.displaypropertiesid, s = r.resources.pbmetallicdisplayproperties;
			if (a !== null && s[a] !== void 0) {
				let t = s[a].data[e.index];
				i = new o({
					flatShading: !0,
					roughness: t.roughness,
					metalness: t.metallicness
				});
			} else i = new t({ flatShading: !0 });
			i.name = e.name;
			let c = e.displaycolor, l = c.substring(0, 7);
			return i.color.setStyle(l, T), c.length === 9 && (i.opacity = parseInt(c.charAt(7) + c.charAt(8), 16) / 255), i;
		}
		function ue(e, t, n, r) {
			let a = new i();
			for (let i = 0; i < e.length; i++) {
				let o = e[i], s = t[o.objectId];
				s === void 0 && (Q(o.objectId, t, n, r), s = t[o.objectId]);
				let c = s.clone(), l = o.transform;
				l && c.applyMatrix4(l), a.add(c);
			}
			return a;
		}
		function Q(e, t, n, r) {
			let i = n.resources.object[e];
			if (i.mesh) {
				let e = i.mesh, a = n.extensions, o = n.xml;
				ce(a, e, o), t[i.id] = Z(e, t, n, r, i, se);
			} else {
				let e = i.components;
				t[i.id] = Z(e, t, n, r, i, ue);
			}
			i.name && (t[i.id].name = i.name), n.resources.implicitfunction && console.warn("THREE.ThreeMFLoader: Implicit Functions are implemented in data-only.", n.resources.implicitfunction);
		}
		function de(e) {
			let t = e.model, n = e.modelRels, r = {}, i = Object.keys(t), a = {};
			if (n) for (let t = 0, r = n.length; t < r; t++) {
				let r = n[t], i = r.target.substring(1);
				e.texture[i] && (a[r.target] = e.texture[i]);
			}
			for (let e = 0; e < i.length; e++) {
				let n = t[i[e]], o = Object.keys(n.resources.object);
				for (let e = 0; e < o.length; e++) {
					let t = o[e];
					Q(t, r, n, a);
				}
			}
			return r;
		}
		function fe(e) {
			for (let t = 0; t < e.length; t++) {
				let n = e[t];
				if (n.target.split(".").pop().toLowerCase() === "model") return n;
			}
		}
		function pe(e, t) {
			let n = new i(), r = fe(t.rels), a = t.model[r.target.substring(1)].build;
			for (let t = 0; t < a.length; t++) {
				let r = a[t], i = e[r.objectId].clone(), o = r.transform;
				o && i.applyMatrix4(o), n.add(i);
			}
			return n;
		}
		let $ = k(n);
		return pe(de($), $);
	}
	addExtension(e) {
		this.availableExtensions.push(e);
	}
};
//#endregion
export { O as ThreeMFLoader };

//# sourceMappingURL=3MFLoader-BnlKyf6T.js.map