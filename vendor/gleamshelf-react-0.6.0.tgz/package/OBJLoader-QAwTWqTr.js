import { Et as e, F as t, H as n, Ht as r, I as i, Vn as a, Vt as o, _t as s, at as c, gr as l, p as u, pt as d, st as f, u as p, xt as m } from "./three.core-DIbF123p.js";
//#region ../../node_modules/three/examples/jsm/loaders/OBJLoader.js
var h = /^[og]\s*(.+)?/, g = /^mtllib /, _ = /^usemtl /, v = /^usemap /, y = /\s+/, b = new l(), x = new l(), S = new l(), C = new l(), w = new l(), T = new u();
function E() {
	let e = {
		objects: [],
		object: {},
		vertices: [],
		normals: [],
		colors: [],
		uvs: [],
		materials: {},
		materialLibraries: [],
		startObject: function(e, t) {
			if (this.object && this.object.fromDeclaration === !1) {
				this.object.name = e, this.object.fromDeclaration = t !== !1;
				return;
			}
			let n = this.object && typeof this.object.currentMaterial == "function" ? this.object.currentMaterial() : void 0;
			if (this.object && typeof this.object._finalize == "function" && this.object._finalize(!0), this.object = {
				name: e || "",
				fromDeclaration: t !== !1,
				geometry: {
					vertices: [],
					normals: [],
					colors: [],
					uvs: [],
					hasUVIndices: !1
				},
				materials: [],
				smooth: !0,
				startMaterial: function(e, t) {
					let n = this._finalize(!1);
					n && (n.inherited || n.groupCount <= 0) && this.materials.splice(n.index, 1);
					let r = {
						index: this.materials.length,
						name: e || "",
						mtllib: Array.isArray(t) && t.length > 0 ? t[t.length - 1] : "",
						smooth: n === void 0 ? this.smooth : n.smooth,
						groupStart: n === void 0 ? 0 : n.groupEnd,
						groupEnd: -1,
						groupCount: -1,
						inherited: !1,
						clone: function(e) {
							let t = {
								index: typeof e == "number" ? e : this.index,
								name: this.name,
								mtllib: this.mtllib,
								smooth: this.smooth,
								groupStart: 0,
								groupEnd: -1,
								groupCount: -1,
								inherited: !1
							};
							return t.clone = this.clone.bind(t), t;
						}
					};
					return this.materials.push(r), r;
				},
				currentMaterial: function() {
					if (this.materials.length > 0) return this.materials[this.materials.length - 1];
				},
				_finalize: function(e) {
					let t = this.currentMaterial();
					if (t && t.groupEnd === -1 && (t.groupEnd = this.geometry.vertices.length / 3, t.groupCount = t.groupEnd - t.groupStart, t.inherited = !1), e && this.materials.length > 1) for (let e = this.materials.length - 1; e >= 0; e--) this.materials[e].groupCount <= 0 && this.materials.splice(e, 1);
					return e && this.materials.length === 0 && this.materials.push({
						name: "",
						smooth: this.smooth
					}), t;
				}
			}, n && n.name && typeof n.clone == "function") {
				let e = n.clone(0);
				e.inherited = !0, this.object.materials.push(e);
			}
			this.objects.push(this.object);
		},
		finalize: function() {
			this.object && typeof this.object._finalize == "function" && this.object._finalize(!0);
		},
		parseVertexIndex: function(e, t) {
			let n = parseInt(e, 10);
			return (n >= 0 ? n - 1 : n + t / 3) * 3;
		},
		parseNormalIndex: function(e, t) {
			let n = parseInt(e, 10);
			return (n >= 0 ? n - 1 : n + t / 3) * 3;
		},
		parseUVIndex: function(e, t) {
			let n = parseInt(e, 10);
			return (n >= 0 ? n - 1 : n + t / 2) * 2;
		},
		addVertex: function(e, t, n) {
			let r = this.vertices, i = this.object.geometry.vertices;
			i.push(r[e + 0], r[e + 1], r[e + 2]), i.push(r[t + 0], r[t + 1], r[t + 2]), i.push(r[n + 0], r[n + 1], r[n + 2]);
		},
		addVertexPoint: function(e) {
			let t = this.vertices;
			this.object.geometry.vertices.push(t[e + 0], t[e + 1], t[e + 2]);
		},
		addVertexLine: function(e) {
			let t = this.vertices;
			this.object.geometry.vertices.push(t[e + 0], t[e + 1], t[e + 2]);
		},
		addNormal: function(e, t, n) {
			let r = this.normals, i = this.object.geometry.normals;
			i.push(r[e + 0], r[e + 1], r[e + 2]), i.push(r[t + 0], r[t + 1], r[t + 2]), i.push(r[n + 0], r[n + 1], r[n + 2]);
		},
		addFaceNormal: function(e, t, n) {
			let r = this.vertices, i = this.object.geometry.normals;
			b.fromArray(r, e), x.fromArray(r, t), S.fromArray(r, n), w.subVectors(S, x), C.subVectors(b, x), w.cross(C), w.normalize(), i.push(w.x, w.y, w.z), i.push(w.x, w.y, w.z), i.push(w.x, w.y, w.z);
		},
		addColor: function(e, t, n) {
			let r = this.colors, i = this.object.geometry.colors;
			r[e] !== void 0 && i.push(r[e + 0], r[e + 1], r[e + 2]), r[t] !== void 0 && i.push(r[t + 0], r[t + 1], r[t + 2]), r[n] !== void 0 && i.push(r[n + 0], r[n + 1], r[n + 2]);
		},
		addUV: function(e, t, n) {
			let r = this.uvs, i = this.object.geometry.uvs;
			i.push(r[e + 0], r[e + 1]), i.push(r[t + 0], r[t + 1]), i.push(r[n + 0], r[n + 1]);
		},
		addDefaultUV: function() {
			let e = this.object.geometry.uvs;
			e.push(0, 0), e.push(0, 0), e.push(0, 0);
		},
		addUVLine: function(e) {
			let t = this.uvs;
			this.object.geometry.uvs.push(t[e + 0], t[e + 1]);
		},
		addFace: function(e, t, n, r, i, a, o, s, c) {
			let l = this.vertices.length, u = this.parseVertexIndex(e, l), d = this.parseVertexIndex(t, l), f = this.parseVertexIndex(n, l);
			if (this.addVertex(u, d, f), this.addColor(u, d, f), o !== void 0 && o !== "") {
				let e = this.normals.length;
				u = this.parseNormalIndex(o, e), d = this.parseNormalIndex(s, e), f = this.parseNormalIndex(c, e), this.addNormal(u, d, f);
			} else this.addFaceNormal(u, d, f);
			if (r !== void 0 && r !== "") {
				let e = this.uvs.length;
				u = this.parseUVIndex(r, e), d = this.parseUVIndex(i, e), f = this.parseUVIndex(a, e), this.addUV(u, d, f), this.object.geometry.hasUVIndices = !0;
			} else this.addDefaultUV();
		},
		addPointGeometry: function(e) {
			this.object.geometry.type = "Points";
			let t = this.vertices.length;
			for (let n = 0, r = e.length; n < r; n++) {
				let r = this.parseVertexIndex(e[n], t);
				this.addVertexPoint(r), this.addColor(r);
			}
		},
		addLineGeometry: function(e, t) {
			this.object.geometry.type = "Line";
			let n = this.vertices.length, r = this.uvs.length;
			for (let t = 0, r = e.length; t < r; t++) this.addVertexLine(this.parseVertexIndex(e[t], n));
			for (let e = 0, n = t.length; e < n; e++) this.addUVLine(this.parseUVIndex(t[e], r));
		}
	};
	return e.startObject("", !1), e;
}
var D = class extends d {
	constructor(e) {
		super(e), this.materials = null;
	}
	load(e, n, r, i) {
		let a = this, o = new t(this.manager);
		o.setPath(this.path), o.setRequestHeader(this.requestHeader), o.setWithCredentials(this.withCredentials), o.load(e, function(t) {
			try {
				n(a.parse(t));
			} catch (t) {
				i ? i(t) : console.error(t), a.manager.itemError(e);
			}
		}, r, i);
	}
	setMaterials(e) {
		return this.materials = e, this;
	}
	parse(t) {
		let l = new E();
		t.indexOf("\r\n") !== -1 && (t = t.replace(/\r\n/g, "\n")), t.indexOf("\\\n") !== -1 && (t = t.replace(/\\\n/g, ""));
		let u = t.split("\n"), d = [];
		for (let e = 0, t = u.length; e < t; e++) {
			let t = u[e].trimStart();
			if (t.length === 0) continue;
			let n = t.charAt(0);
			if (n !== "#") {
				if (n === "v") {
					let e = t.split(y);
					switch (e[0]) {
						case "v":
							l.vertices.push(parseFloat(e[1]), parseFloat(e[2]), parseFloat(e[3])), e.length >= 7 ? (T.setRGB(parseFloat(e[4]), parseFloat(e[5]), parseFloat(e[6]), a), l.colors.push(T.r, T.g, T.b)) : l.colors.push(void 0, void 0, void 0);
							break;
						case "vn":
							l.normals.push(parseFloat(e[1]), parseFloat(e[2]), parseFloat(e[3]));
							break;
						case "vt": l.uvs.push(parseFloat(e[1]), parseFloat(e[2]));
					}
				} else if (n === "f") {
					let e = t.slice(1).trim().split(y), n = [];
					for (let t = 0, r = e.length; t < r; t++) {
						let r = e[t];
						if (r.length > 0) {
							let e = r.split("/");
							n.push(e);
						}
					}
					let r = n[0];
					for (let e = 1, t = n.length - 1; e < t; e++) {
						let t = n[e], i = n[e + 1];
						l.addFace(r[0], t[0], i[0], r[1], t[1], i[1], r[2], t[2], i[2]);
					}
				} else if (n === "l") {
					let e = t.substring(1).trim().split(" "), n = [], r = [];
					if (t.indexOf("/") === -1) n = e;
					else for (let t = 0, i = e.length; t < i; t++) {
						let i = e[t].split("/");
						i[0] !== "" && n.push(i[0]), i[1] !== "" && r.push(i[1]);
					}
					l.addLineGeometry(n, r);
				} else if (n === "p") {
					let e = t.slice(1).trim().split(" ");
					l.addPointGeometry(e);
				} else if ((d = h.exec(t)) !== null) {
					let e = (" " + d[0].slice(1).trim()).slice(1);
					l.startObject(e);
				} else if (_.test(t)) l.object.startMaterial(t.substring(7).trim(), l.materialLibraries);
				else if (g.test(t)) l.materialLibraries.push(t.substring(7).trim());
				else if (v.test(t)) console.warn("THREE.OBJLoader: Rendering identifier \"usemap\" not supported. Textures must be defined in MTL files.");
				else if (n === "s") {
					if (d = t.split(" "), d.length > 1) {
						let e = d[1].trim().toLowerCase();
						l.object.smooth = e !== "0" && e !== "off";
					} else l.object.smooth = !0;
					let e = l.object.currentMaterial();
					e && (e.smooth = l.object.smooth);
				} else {
					if (t === "\0") continue;
					console.warn("THREE.OBJLoader: Unexpected line: \"" + t + "\"");
				}
			}
		}
		l.finalize();
		let b = new n();
		if (b.materialLibraries = [].concat(l.materialLibraries), l.objects.length !== 1 || l.objects[0].geometry.vertices.length !== 0) for (let t = 0, n = l.objects.length; t < n; t++) {
			let n = l.objects[t], a = n.geometry, u = n.materials, d = a.type === "Line", h = a.type === "Points", g = !1;
			if (a.vertices.length === 0) continue;
			let _ = new p();
			_.setAttribute("position", new i(a.vertices, 3)), a.normals.length > 0 && _.setAttribute("normal", new i(a.normals, 3)), a.colors.length > 0 && (g = !0, _.setAttribute("color", new i(a.colors, 3))), a.hasUVIndices === !0 && _.setAttribute("uv", new i(a.uvs, 2));
			let v = [];
			for (let t = 0, n = u.length; t < n; t++) {
				let n = u[t], i = n.name + "_" + n.smooth + "_" + g, a = l.materials[i];
				if (this.materials !== null) {
					if (a = this.materials.create(n.name), d && a && !(a instanceof c)) {
						let e = new c();
						s.prototype.copy.call(e, a), e.color.copy(a.color), a = e;
					} else if (h && a && !(a instanceof r)) {
						let e = new r({
							size: 10,
							sizeAttenuation: !1
						});
						s.prototype.copy.call(e, a), e.color.copy(a.color), e.map = a.map, a = e;
					}
				}
				a === void 0 && (a = d ? new c() : h ? new r({
					size: 1,
					sizeAttenuation: !1
				}) : new e(), a.name = n.name, a.flatShading = !n.smooth, a.vertexColors = g, l.materials[i] = a), v.push(a);
			}
			let y;
			if (v.length > 1) {
				for (let e = 0, t = u.length; e < t; e++) {
					let t = u[e];
					_.addGroup(t.groupStart, t.groupCount, e);
				}
				y = d ? new f(_, v) : h ? new o(_, v) : new m(_, v);
			} else y = d ? new f(_, v[0]) : h ? new o(_, v[0]) : new m(_, v[0]);
			y.name = n.name, b.add(y);
		}
		else if (l.vertices.length > 0) {
			let e = new r({
				size: 1,
				sizeAttenuation: !1
			}), t = new p();
			t.setAttribute("position", new i(l.vertices, 3)), l.colors.length > 0 && l.colors[0] !== void 0 && (t.setAttribute("color", new i(l.colors, 3)), e.vertexColors = !0);
			let n = new o(t, e);
			b.add(n);
		}
		return b;
	}
};
//#endregion
export { D as OBJLoader };

//# sourceMappingURL=OBJLoader-QAwTWqTr.js.map