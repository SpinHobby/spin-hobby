import { n as e } from "./rolldown-runtime-DArdT4gl.js";
import { a as t, c as n, i as r, l as i, s as a, t as o, u as s } from "./Panel-C6TPnUHQ.js";
import { n as c, t as l } from "./theme-qdSfcbOw.js";
import { useCallback as u, useEffect as d, useMemo as ee, useRef as f, useState as p } from "react";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
//#region ../craft/src/worker.ts?worker&inline
var _ = "(function(){var e=class{__destroy_into_raw(){let e=this.__wbg_ptr;return this.__wbg_ptr=0,l.unregister(this),e}free(){let e=this.__destroy_into_raw();E.__wbg_developsource_free(e,0)}constructor(e,t,n){let r=v(n,E.__wbindgen_malloc),i=T,a=E.developsource_new(e,t,r,i);if(a[2])throw b(a[1]);return this.__wbg_ptr=a[0],l.register(this,this.__wbg_ptr,this),this}render(e,t,r,i){let a=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),o=T,s=E.developsource_render(this.__wbg_ptr,a,o,t,r,i);if(s[2])throw b(s[1]);return n.__wrap(s[0])}};Symbol.dispose&&(e.prototype[Symbol.dispose]=e.prototype.free);var t=class{__destroy_into_raw(){let e=this.__wbg_ptr;return this.__wbg_ptr=0,u.unregister(this),e}free(){let e=this.__destroy_into_raw();E.__wbg_photosession_free(e,0)}active_rgba(){let e=E.photosession_active_rgba(this.__wbg_ptr);if(e[2])throw b(e[1]);return n.__wrap(e[0])}commands(){let e,t;try{let i=E.photosession_commands(this.__wbg_ptr);var n=i[0],r=i[1];if(i[3])throw n=0,r=0,b(i[2]);return e=n,t=r,h(n,r)}finally{E.__wbindgen_free(e,t,1)}}composite(){let e=E.photosession_composite(this.__wbg_ptr);if(e[2])throw b(e[1]);return n.__wrap(e[0])}disabled_reason(e){let t=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),n=T,r=E.photosession_disabled_reason(this.__wbg_ptr,t,n),i;return r[0]!==0&&(i=h(r[0],r[1]),E.__wbindgen_free(r[0],r[1]*1,1)),i}execute(e,t){let n,r;try{let o=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),s=T,c=y(t,E.__wbindgen_malloc,E.__wbindgen_realloc),l=T,u=E.photosession_execute(this.__wbg_ptr,o,s,c,l);var i=u[0],a=u[1];if(u[3])throw i=0,a=0,b(u[2]);return n=i,r=a,h(i,a)}finally{E.__wbindgen_free(n,r,1)}}export(e,t){let n=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),r=T,i=y(t,E.__wbindgen_malloc,E.__wbindgen_realloc),a=T,o=E.photosession_export(this.__wbg_ptr,n,r,i,a);if(o[3])throw b(o[2]);var s=f(o[0],o[1]).slice();return E.__wbindgen_free(o[0],o[1]*1,1),s}height(){return E.photosession_height(this.__wbg_ptr)>>>0}constructor(){let e=E.photosession_new();return this.__wbg_ptr=e,u.register(this,this.__wbg_ptr,this),this}open(e,t){let n,r;try{let o=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),s=T,c=v(t,E.__wbindgen_malloc),l=T,u=E.photosession_open(this.__wbg_ptr,o,s,c,l);var i=u[0],a=u[1];if(u[3])throw i=0,a=0,b(u[2]);return n=i,r=a,h(i,a)}finally{E.__wbindgen_free(n,r,1)}}open_rgba(e,t,n,r){let i=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),a=T,o=v(r,E.__wbindgen_malloc),s=T,c=E.photosession_open_rgba(this.__wbg_ptr,i,a,t,n,o,s);if(c[1])throw b(c[0])}place_rgba(e,t,n,r,i,a){let o=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),s=T,c=v(a,E.__wbindgen_malloc),l=T,u=E.photosession_place_rgba(this.__wbg_ptr,o,s,t,n,r,i,c,l);if(u[1])throw b(u[0])}redo(){return E.photosession_redo(this.__wbg_ptr)!==0}replace_active_rgba(e,t,n,r){let i=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),a=T,o=v(r,E.__wbindgen_malloc),s=T,c=E.photosession_replace_active_rgba(this.__wbg_ptr,i,a,t,n,o,s);if(c[1])throw b(c[0])}revision(){let e=E.photosession_revision(this.__wbg_ptr);return BigInt.asUintN(64,e)}selection(){let e=E.photosession_selection(this.__wbg_ptr);return e===0?void 0:n.__wrap(e)}undo(){return E.photosession_undo(this.__wbg_ptr)!==0}width(){return E.photosession_width(this.__wbg_ptr)>>>0}};Symbol.dispose&&(t.prototype[Symbol.dispose]=t.prototype.free);var n=class e{static __wrap(t){let n=Object.create(e.prototype);return n.__wbg_ptr=t,d.register(n,n.__wbg_ptr,n),n}__destroy_into_raw(){let e=this.__wbg_ptr;return this.__wbg_ptr=0,d.unregister(this),e}free(){let e=this.__destroy_into_raw();E.__wbg_picture_free(e,0)}get height(){return E.picture_height(this.__wbg_ptr)>>>0}take(){let e=E.picture_take(this.__wbg_ptr);var t=f(e[0],e[1]).slice();return E.__wbindgen_free(e[0],e[1]*1,1),t}get width(){return E.picture_width(this.__wbg_ptr)>>>0}};Symbol.dispose&&(n.prototype[Symbol.dispose]=n.prototype.free);function r(e,t,n){let r,i;try{let s=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),c=T,l=y(t,E.__wbindgen_malloc,E.__wbindgen_realloc),u=T,d=E.develop_apply_preset(s,c,l,u,n);var a=d[0],o=d[1];if(d[3])throw a=0,o=0,b(d[2]);return r=a,i=o,h(a,o)}finally{E.__wbindgen_free(r,i,1)}}function i(){let e,t;try{let n=E.develop_controls();return e=n[0],t=n[1],h(n[0],n[1])}finally{E.__wbindgen_free(e,t,1)}}function a(){let e,t;try{let n=E.develop_defaults();return e=n[0],t=n[1],h(n[0],n[1])}finally{E.__wbindgen_free(e,t,1)}}function o(){let e,t;try{let n=E.develop_presets();return e=n[0],t=n[1],h(n[0],n[1])}finally{E.__wbindgen_free(e,t,1)}}function s(e,t,n){let r,i;try{let s=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),c=T,l=y(t,E.__wbindgen_malloc,E.__wbindgen_realloc),u=T,d=E.develop_set(s,c,l,u,n);var a=d[0],o=d[1];if(d[3])throw a=0,o=0,b(d[2]);return r=a,i=o,h(a,o)}finally{E.__wbindgen_free(r,i,1)}}function c(){return{__proto__:null,\"./gleamshelf_craft_bg.js\":{__proto__:null,__wbg___wbindgen_throw_41e9ee4f547fc59a:function(e,t){throw Error(h(e,t))},__wbg_error_757e9472f8410341:function(e,t){let n,r;try{n=e,r=t,console.error(h(e,t))}finally{E.__wbindgen_free(n,r,1)}},__wbg_new_227d7c05414eb861:function(){return/* @__PURE__ */ Error()},__wbg_stack_3b0d974bbf31e44f:function(e,t){let n=t.stack,r=y(n,E.__wbindgen_malloc,E.__wbindgen_realloc),i=T;m().setInt32(e+4,i,!0),m().setInt32(e+0,r,!0)},__wbindgen_generic_0000000000000001:function(e,t){return h(e,t)},__wbindgen_init_externref_table:function(){let e=E.__wbindgen_externrefs,t=e.grow(4);e.set(0,void 0),e.set(t+0,void 0),e.set(t+1,null),e.set(t+2,!0),e.set(t+3,!1)}}}}let l=typeof FinalizationRegistry>`u`?{register:()=>{},unregister:()=>{}}:new FinalizationRegistry(e=>E.__wbg_developsource_free(e,1)),u=typeof FinalizationRegistry>`u`?{register:()=>{},unregister:()=>{}}:new FinalizationRegistry(e=>E.__wbg_photosession_free(e,1)),d=typeof FinalizationRegistry>`u`?{register:()=>{},unregister:()=>{}}:new FinalizationRegistry(e=>E.__wbg_picture_free(e,1));function f(e,t){return e>>>=0,_().subarray(e/1,e/1+t)}let p=null;function m(){return(p===null||p.buffer.detached===!0||p.buffer.detached===void 0&&p.buffer!==E.memory.buffer)&&(p=new DataView(E.memory.buffer)),p}function h(e,t){return C(e>>>0,t)}let g=null;function _(){return(g===null||g.byteLength===0)&&(g=new Uint8Array(E.memory.buffer)),g}function v(e,t){let n=t(e.length*1,1)>>>0;return _().set(e,n/1),T=e.length,n}function y(e,t,n){if(n===void 0){let n=w.encode(e),r=t(n.length,1)>>>0;return _().subarray(r,r+n.length).set(n),T=n.length,r}let r=e.length,i=t(r,1)>>>0,a=_(),o=0;for(;o<r;o++){let t=e.charCodeAt(o);if(t>127)break;a[i+o]=t}if(o!==r){o!==0&&(e=e.slice(o)),i=n(i,r,r=o+e.length*3,1)>>>0;let t=_().subarray(i+o,i+r),a=w.encodeInto(e,t);o+=a.written,i=n(i,r,o,1)>>>0}return T=o,i}function b(e){let t=E.__wbindgen_externrefs.get(e);return E.__externref_table_dealloc(e),t}let x=new TextDecoder(`utf-8`,{ignoreBOM:!0,fatal:!0});x.decode();let S=0;function C(e,t){return S+=t,S>=2146435072&&(x=new TextDecoder(`utf-8`,{ignoreBOM:!0,fatal:!0}),x.decode(),S=t),x.decode(_().subarray(e,e+t))}let w=new TextEncoder;`encodeInto`in w||(w.encodeInto=function(e,t){let n=w.encode(e);return t.set(n),{read:e.length,written:n.length}});let T=0,E;function D(e,t){return E=e.exports,p=null,g=null,E.__wbindgen_start(),E}async function O(e,t){if(typeof Response==`function`&&e instanceof Response){if(!e.ok)throw Error(`failed to fetch Wasm: ${e.status} ${e.statusText} fetching '${e.url}'`);if(typeof WebAssembly.instantiateStreaming==`function`)try{return await WebAssembly.instantiateStreaming(e,t)}catch(t){if(n(e.type)&&e.headers.get(`Content-Type`)!==`application/wasm`)console.warn(\"`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\\n\",t);else throw t}let r=await e.arrayBuffer();return await WebAssembly.instantiate(r,t)}{let n=await WebAssembly.instantiate(e,t);return n instanceof WebAssembly.Instance?{instance:n,module:e}:n}function n(e){switch(e){case`basic`:case`cors`:case`default`:return!0}return!1}}async function k(e){if(E!==void 0)return E;if(e!==void 0&&(Object.getPrototypeOf(e)===Object.prototype?{module_or_path:e}=e:console.warn(`using deprecated parameters for the initialization function; pass a single object instead`)),e===void 0)throw Error(`Pass the WebAssembly URL to init().`);let t=c();(typeof e==`string`||typeof Request==`function`&&e instanceof Request||typeof URL==`function`&&e instanceof URL)&&(e=fetch(e));let{instance:n,module:r}=await O(await e,t);return D(n,r)}let A=null,j=null,M=null,N=()=>j??=new t,P=e=>{let t={width:e.width,height:e.height,rgba:e.take()};return e.free(),t},F=e=>e?JSON.parse(e):null;async function I(t){if(t.op===`init`)return A??=k({module_or_path:t.wasmUrl}),await A,null;if(!A)throw Error(`Photo lab has not started yet.`);switch(await A,t.op){case`open`:return F(N().open(t.name,t.bytes));case`openRgba`:return N().open_rgba(t.name,t.pic.width,t.pic.height,t.pic.rgba);case`execute`:return F(N().execute(t.id,JSON.stringify(t.params??{})));case`commands`:return F(N().commands());case`disabledReason`:return N().disabled_reason(t.id)??null;case`undo`:return N().undo();case`redo`:return N().redo();case`info`:{let e=N();return{revision:Number(e.revision()),width:e.width(),height:e.height()}}case`composite`:return P(N().composite());case`selection`:{let e=N().selection();return e?P(e):null}case`activeRgba`:return P(N().active_rgba());case`place`:return N().place_rgba(t.name,t.x,t.y,t.pic.width,t.pic.height,t.pic.rgba);case`replaceActive`:return N().replace_active_rgba(t.label,t.pic.width,t.pic.height,t.pic.rgba);case`export`:return N().export(t.ext,JSON.stringify(t.options??{}));case`developControls`:return F(i());case`developDefaults`:return F(a());case`developPresets`:return F(o());case`developApplyPreset`:return F(r(JSON.stringify(t.settings),JSON.stringify(t.preset),t.amount));case`developSet`:return F(s(JSON.stringify(t.settings),t.id,t.value));case`developSource`:return M?.free(),M=new e(t.pic.width,t.pic.height,t.pic.rgba),null;case`developRender`:if(!M)throw Error(`Nothing to develop yet.`);return P(M.render(JSON.stringify(t.settings),t.maxW,t.maxH,t.draft))}}let L=e=>e instanceof Uint8Array?[e.buffer]:e&&typeof e==`object`&&`rgba`in e&&e.rgba instanceof Uint8Array?[e.rgba.buffer]:[];self.onmessage=async e=>{let{seq:t,req:n}=e.data;try{let e=await I(n);self.postMessage({seq:t,ok:!0,result:e},L(e))}catch(e){self.postMessage({seq:t,ok:!1,error:typeof e==`string`?e:e instanceof Error?e.message:String(e)})}}})();\n//# sourceMappingURL=worker-C2mdyG4l.js.map", te = typeof self < "u" && self.Blob && new Blob(["(self.URL || self.webkitURL).revokeObjectURL(self.location.href);", _], { type: "text/javascript;charset=utf-8" });
function ne(e) {
	let t;
	try {
		if (t = te && (self.URL || self.webkitURL).createObjectURL(te), !t) throw "";
		let n = new Worker(t, { name: e?.name });
		return n.addEventListener("error", () => {
			(self.URL || self.webkitURL).revokeObjectURL(t);
		}), n;
	} catch {
		return new Worker("data:text/javascript;charset=utf-8," + encodeURIComponent(_), { name: e?.name });
	}
}
new URL("./assets/gleamshelf_craft_bg.wasm", import.meta.url).href;
//#endregion
//#region ../craft/src/params.ts
function re(e) {
	let t = [], n = 0, r = !1, i = 0;
	for (let a = 0; a < e.length; a++) {
		let o = e[a];
		o === "\"" && e[a - 1] !== "\\" ? r = !r : !r && (o === "{" || o === "[" || o === "(") ? n++ : !r && (o === "}" || o === "]" || o === ")") ? n-- : !r && n === 0 && o === "," && (t.push(e.slice(i, a)), i = a + 1);
	}
	return t.push(e.slice(i)), t.map((e) => e.trim()).filter(Boolean);
}
function v(e) {
	let t = e.trimStart();
	if (!t.startsWith("{")) return null;
	let n = 0, r = !1;
	for (let e = 0; e < t.length; e++) {
		let i = t[e];
		if (i === "\"" && t[e - 1] !== "\\") r = !r;
		else if (!r && i === "{") n++;
		else if (!r && i === "}" && --n === 0) return {
			body: t.slice(1, e),
			rest: t.slice(e + 1).trim()
		};
	}
	return null;
}
var y = String.raw`-?\d+(?:\.\d+)?`, ie = new RegExp(String.raw`^(${y})\s*\.\.\s*(${y})(?:\s*=\s*(${y}))?(\?)?(?:\s.*)?$`), b = /^(u8|u16|u32|u64|i8|i16|i32|i64|usize|int|integer|px)\b/, x = /^(f32|f64|float|number|num)\b/;
function S(e, t, n) {
	let r = t.trim(), i = n, a = ie.exec(r);
	if (a) {
		let [, t, n, r, o] = a, s = Number(t), c = Number(n), l = !`${t}${n}${r ?? ""}`.includes(".");
		return {
			key: e,
			kind: "range",
			min: s,
			max: c,
			default: r === void 0 ? Math.min(c, Math.max(s, 0)) : Number(r),
			optional: i || !!o,
			integer: l
		};
	}
	r.endsWith("?") && (i = !0, r = r.slice(0, -1).trim());
	let o = /^bool(?:ean)?(?:\s*=\s*(true|false))?(\?)?$/.exec(r);
	if (o) return {
		key: e,
		kind: "bool",
		default: o[1] === "true",
		optional: i || !!o[2]
	};
	let s = /^"([^"]*\|[^"]*)"(?:\s*=\s*"([^"]*)")?(\?)?$/.exec(r);
	if (s) {
		let t = s[1].split("|").map((e) => e.trim()).filter(Boolean);
		return {
			key: e,
			kind: "choice",
			options: t,
			default: s[2] ?? t[0],
			optional: i || !!s[3]
		};
	}
	if (b.exec(r) && !r.includes("|") && !r.includes("[")) {
		let t = /=\s*(-?\d+)/.exec(r);
		return {
			key: e,
			kind: "number",
			default: t ? Number(t[1]) : null,
			optional: i || !t,
			integer: !0
		};
	}
	if (x.exec(r) && !r.includes("|") && !r.includes("[")) {
		let t = new RegExp(String.raw`=\s*(${y})`).exec(r);
		return {
			key: e,
			kind: "number",
			default: t ? Number(t[1]) : null,
			optional: i || !t,
			integer: !1
		};
	}
	let c = /^(str|string|text|name)\b(?:\s*=\s*"([^"]*)")?/.exec(r) ?? /^"([^"|]*)"$/.exec(r);
	if (c) {
		let t = c.length > 2 ? c[2] ?? null : null;
		return {
			key: e,
			kind: "text",
			default: t,
			optional: i || t === null,
			hint: r
		};
	}
	return /^("#rrggbb"|#rrggbb|color|colour)/i.test(r) ? {
		key: e,
		kind: "text",
		default: null,
		optional: !0,
		hint: "#rrggbb"
	} : {
		key: e,
		kind: "json",
		optional: !0,
		hint: r
	};
}
function C(e) {
	let t = v(e ?? "");
	if (!t) return {
		fields: [],
		notes: (e ?? "").trim()
	};
	let n = [];
	for (let e of re(t.body)) {
		let t = /^"([^"]+)"(\?)?\s*:\s*([\s\S]*)$/.exec(e);
		t && n.push(S(t[1], t[3], !!t[2]));
	}
	return {
		fields: n,
		notes: t.rest.replace(/^\(|\)$/g, "").trim()
	};
}
function w(e, t) {
	let n = {};
	for (let r of e.fields) {
		let e = t[r.key];
		if (e === void 0 || e === "" || e === null) {
			if (!r.optional && "default" in r) {
				let e = r.default;
				e != null && (n[r.key] = e);
			}
		} else if (r.kind === "json") try {
			n[r.key] = typeof e == "string" ? JSON.parse(e) : e;
		} catch {
			throw Error(`${r.key}: not valid JSON`);
		}
		else n[r.key] = e;
	}
	return n;
}
function ae(e) {
	let t = {};
	for (let n of e.fields) "default" in n && n.default !== null && !n.optional && (t[n.key] = n.default);
	return t;
}
//#endregion
//#region ../craft/src/index.ts
function oe(e = {}) {
	let t = new ne({ name: "gleamshelf-craft" }), n = /* @__PURE__ */ new Map(), r = 0;
	t.onmessage = (e) => {
		let t = n.get(e.data.seq);
		t && (n.delete(e.data.seq), e.data.ok ? t.resolve(e.data.result) : t.reject(Error(e.data.error ?? "Photo lab failed.")));
	}, t.onerror = (e) => {
		let t = Error(e.message || "Photo lab could not start.");
		for (let e of n.values()) e.reject(t);
		n.clear();
	};
	let i = (e, i = []) => new Promise((a, o) => {
		let s = ++r;
		n.set(s, {
			resolve: a,
			reject: o
		}), t.postMessage({
			seq: s,
			req: e
		}, i);
	});
	i({
		op: "init",
		wasmUrl: new URL(e.wasmUrl ?? new URL("./assets/gleamshelf_craft_bg.wasm", import.meta.url).href, location.href).href
	}).catch(() => {});
	let a = (e) => {
		let t = e.rgba.slice();
		return [{
			width: e.width,
			height: e.height,
			rgba: t
		}, [t.buffer]];
	};
	return {
		openFile: (e, t) => i({
			op: "open",
			name: e,
			bytes: t.slice()
		}),
		openPicture: (e, t) => {
			let [n, r] = a(t);
			return i({
				op: "openRgba",
				name: e,
				pic: n
			}, r);
		},
		execute: (e, t) => i({
			op: "execute",
			id: e,
			params: t
		}),
		commands: () => i({ op: "commands" }),
		undo: () => i({ op: "undo" }),
		redo: () => i({ op: "redo" }),
		info: () => i({ op: "info" }),
		composite: () => i({ op: "composite" }),
		selection: () => i({ op: "selection" }),
		activePixels: () => i({ op: "activeRgba" }),
		place: (e, t, n, r) => {
			let [o, s] = a(r);
			return i({
				op: "place",
				name: e,
				x: t,
				y: n,
				pic: o
			}, s);
		},
		replaceActive: (e, t) => {
			let [n, r] = a(t);
			return i({
				op: "replaceActive",
				label: e,
				pic: n
			}, r);
		},
		export: (e, t) => i({
			op: "export",
			ext: e,
			options: t
		}),
		develop: {
			controls: () => i({ op: "developControls" }),
			defaults: () => i({ op: "developDefaults" }),
			presets: () => i({ op: "developPresets" }),
			applyPreset: (e, t, n) => i({
				op: "developApplyPreset",
				settings: e,
				preset: t,
				amount: n
			}),
			set: (e, t, n) => i({
				op: "developSet",
				settings: e,
				id: t,
				value: n
			}),
			source: (e) => {
				let [t, n] = a(e);
				return i({
					op: "developSource",
					pic: t
				}, n);
			},
			render: (e, t, n, r = !1) => i({
				op: "developRender",
				settings: e,
				maxW: t,
				maxH: n,
				draft: r
			})
		},
		close: () => {
			t.terminate();
			for (let e of n.values()) e.reject(/* @__PURE__ */ Error("Photo lab closed."));
			n.clear();
		}
	};
}
//#endregion
//#region src/photolab/gestures.ts
var se = {
	size: 40,
	hardness: .7,
	opacity: 1,
	flow: 1,
	tolerance: 32,
	mode: "replace",
	paint: "#1a1a1a",
	second: "#ffffff",
	source: null
}, T = (e) => Math.round(e * 100) / 100, E = (e) => Math.max(1, Math.min(100, Math.round(e * 100)));
function ce(e, t, n) {
	let r = e.command;
	if (!r) return { error: "This tool only moves the view." };
	if (t.kind === "box") {
		let i = Math.round(Math.min(t.x0, t.x1)), a = Math.round(Math.min(t.y0, t.y1)), o = Math.round(Math.abs(t.x1 - t.x0)), s = Math.round(Math.abs(t.y1 - t.y0));
		return o < 2 || s < 2 ? { error: "Drag a bigger box." } : e.id === "crop" ? {
			id: r,
			params: {
				x: i,
				y: a,
				width: o,
				height: s
			}
		} : e.id === "object" ? {
			id: r,
			params: {
				rect: [
					i,
					a,
					o,
					s
				],
				mode: n.mode
			}
		} : {
			id: r,
			params: {
				x: i,
				y: a,
				width: o,
				height: s,
				mode: n.mode,
				ellipse: e.id === "oval"
			}
		};
	}
	if (t.kind === "click") {
		let i = Math.round(t.x), a = Math.round(t.y);
		return e.id === "wand" ? {
			id: r,
			params: {
				x: i,
				y: a,
				tolerance: n.tolerance,
				mode: n.mode
			}
		} : e.id === "bucket" ? {
			id: r,
			params: {
				x: i,
				y: a,
				tolerance: n.tolerance,
				color: n.paint
			}
		} : e.id === "magicEraser" ? {
			id: r,
			params: {
				x: i,
				y: a,
				tolerance: n.tolerance
			}
		} : {
			id: r,
			params: {
				x: i,
				y: a
			}
		};
	}
	if (t.kind === "line") {
		let i = Math.round(t.x1 - t.x0), a = Math.round(t.y1 - t.y0);
		return e.id === "gradient" ? {
			id: r,
			params: {
				from: [T(t.x0), T(t.y0)],
				to: [T(t.x1), T(t.y1)],
				colors: [n.paint, n.second]
			}
		} : !i && !a ? { error: "Drag to where it should go." } : e.id === "patch" ? {
			id: r,
			params: {
				offset: [i, a],
				mode: "source"
			}
		} : {
			id: r,
			params: {
				offset: [i, a],
				mode: "move"
			}
		};
	}
	let i = t.points.map(([e, t]) => [T(e), T(t)]);
	if (!i.length) return { error: "Draw on the photo." };
	if (t.kind === "lasso") return i.length < 3 ? { error: "Draw all the way round." } : {
		id: r,
		params: {
			points: i,
			mode: n.mode
		}
	};
	switch (e.id) {
		case "quick": return {
			id: r,
			params: {
				points: i,
				size: Math.round(n.size),
				mode: n.mode === "subtract" ? "subtract" : "add"
			}
		};
		case "remove": return {
			id: r,
			params: {
				points: i,
				size: Math.round(n.size)
			}
		};
		case "brush":
		case "eraser": return {
			id: r,
			params: {
				points: i,
				size: n.size,
				hardness: n.hardness,
				opacity: n.opacity,
				flow: n.flow,
				...e.id === "eraser" ? { erase: !0 } : { color: n.paint }
			}
		};
		case "pencil": return {
			id: r,
			params: {
				points: i,
				size: n.size,
				opacity: n.opacity,
				color: n.paint
			}
		};
		case "mixer": return {
			id: r,
			params: {
				points: i,
				size: n.size,
				color: n.paint
			}
		};
		case "recolour": return {
			id: r,
			params: {
				points: i,
				size: n.size,
				tolerance: Math.min(100, n.tolerance),
				color: n.paint
			}
		};
		case "bgEraser": return {
			id: r,
			params: {
				points: i,
				size: n.size,
				hardness: n.hardness,
				tolerance: Math.min(100, n.tolerance)
			}
		};
		case "heal":
		case "clone": return n.source ? {
			id: r,
			params: {
				points: i,
				size: Math.round(n.size),
				hardness: E(n.hardness),
				opacity: E(n.opacity),
				flow: E(n.flow),
				source: n.source,
				aligned: !0
			}
		} : { error: "Alt-click where to copy from first." };
		default: return {
			id: r,
			params: {
				points: i,
				size: Math.round(n.size),
				hardness: E(n.hardness),
				opacity: E(n.opacity),
				flow: E(n.flow)
			}
		};
	}
}
function le(e, t) {
	return t.shiftKey && t.altKey ? "intersect" : t.shiftKey ? "add" : t.altKey ? "subtract" : e;
}
//#endregion
//#region src/photolab/PhotoLab.tsx
var D = /* @__PURE__ */ e({ PhotoLab: () => j }), ue = [
	{
		id: "develop",
		label: "Develop",
		glyph: "sliders"
	},
	{
		id: "looks",
		label: "Looks",
		glyph: "spark"
	},
	{
		id: "tools",
		label: "Tools",
		glyph: "brush"
	},
	{
		id: "everything",
		label: "Everything",
		glyph: "help"
	},
	{
		id: "layers",
		label: "Layers",
		glyph: "layers"
	},
	{
		id: "history",
		label: "History",
		glyph: "undo"
	}
], de = /* @__PURE__ */ new Set([
	"File",
	"View",
	"Help",
	"Window"
]), fe = /* @__PURE__ */ new Set([
	"Edit › Preferences",
	"Edit › Presets",
	"Edit › Purge",
	"Filter › Plug-ins",
	"Filter › Video"
]), pe = /(^|\.)(list|inspect|get|info|pixel|hitTest|caret|navigate|bounds|measure)$|^(tools|ui|prefs|command|document|actions|view|window|history|app|engine|paint|select\.(rect|lasso|quick|object|magicWand|magneticLasso))\b/, me = /* @__PURE__ */ "Normal.Dissolve.Darken.Multiply.Color Burn.Linear Burn.Darker Color.Lighten.Screen.Color Dodge.Linear Dodge.Lighter Color.Overlay.Soft Light.Hard Light.Vivid Light.Linear Light.Pin Light.Hard Mix.Difference.Exclusion.Subtract.Divide.Hue.Saturation.Color.Luminosity".split("."), he = [
	{
		ext: "psd",
		label: "PSD (keeps layers)"
	},
	{
		ext: "png",
		label: "PNG"
	},
	{
		ext: "jpg",
		label: "JPEG"
	},
	{
		ext: "webp",
		label: "WebP"
	},
	{
		ext: "tif",
		label: "TIFF"
	}
], ge = ".psd,.psb,.png,.jpg,.jpeg,.webp,.tif,.tiff,.bmp,.gif,.tga,.pcraft,.kra,.ora,.pdn", _e = 1600, ve = (e, t) => `${e} ${t}${e === 1 ? "" : "s"}`, ye = (e) => e.replace(/…$|\.\.\.$/, ""), be = (e, t) => JSON.stringify(e) === JSON.stringify(t);
async function xe(e) {
	let t = e instanceof Blob ? await createImageBitmap(e, { premultiplyAlpha: "none" }) : e, n = new OffscreenCanvas(t.width, t.height).getContext("2d");
	n.drawImage(t, 0, 0);
	let r = n.getImageData(0, 0, t.width, t.height).data;
	return {
		width: t.width,
		height: t.height,
		rgba: new Uint8Array(r.buffer, r.byteOffset, r.byteLength)
	};
}
var Se = (e) => createImageBitmap(new ImageData(new Uint8ClampedArray(e.rgba.buffer, e.rgba.byteOffset, e.rgba.byteLength), e.width, e.height), { premultiplyAlpha: "none" });
async function Ce(e) {
	let { width: t, height: n } = e, r = (r, i) => r >= 0 && i >= 0 && r < t && i < n && e.rgba[(i * t + r) * 4 + 3] >= 128, i = Math.max(1, Math.round(Math.max(t, n) / 900)), a = new Uint8ClampedArray(t * n * 4);
	for (let o = 0; o < n; o++) for (let n = 0; n < t; n++) {
		let s = (o * t + n) * 4, c = e.rgba[s + 3];
		c && (c >= 128 && (!r(n - i, o) || !r(n + i, o) || !r(n, o - i) || !r(n, o + i)) ? a.set([
			255,
			255,
			255,
			255
		], s) : a.set([
			255,
			122,
			182,
			Math.round(c * .3)
		], s));
	}
	return createImageBitmap(new ImageData(a, t, n));
}
function we(e, t, n) {
	let r = structuredClone(e), i = t.split("."), a = r;
	for (let e = 0; e < i.length; e++) {
		let t = i[e], r = t in a ? t : t.replace(/[A-Z]/g, (e) => `_${e.toLowerCase()}`);
		if (!(r in a)) return null;
		if (e === i.length - 1) {
			if (typeof a[r] != "number") return null;
			a[r] = n;
		} else {
			let e = a[r];
			if (!e || typeof e != "object") return null;
			a = e;
		}
	}
	return r;
}
function Te(e, t) {
	let n = e;
	for (let e of t.split(".")) {
		if (!n || typeof n != "object") return null;
		let t = n;
		n = e in t ? t[e] : t[e.replace(/[A-Z]/g, (e) => `_${e.toLowerCase()}`)];
	}
	return typeof n == "number" ? n : null;
}
var O = [
	"#e5484d",
	"#f08c2e",
	"#f5d90a",
	"#46a758",
	"#12a594",
	"#3e63dd",
	"#8e4ec6",
	"#d6409f"
];
function Ee(e) {
	let t = e.track, n = O[t?.band ?? 0] ?? "#888";
	switch (t?.kind) {
		case "temp": return "linear-gradient(90deg, #3d7bff, #f2f2f2 50%, #ffbf3d)";
		case "tint": return "linear-gradient(90deg, #39c36a, #f2f2f2, #d94fd9)";
		case "rainbow": return "linear-gradient(90deg, red, yellow, lime, cyan, blue, magenta, red)";
		case "gradient": return `linear-gradient(90deg, ${t.from}, ${t.to})`;
		case "hue": return `linear-gradient(90deg, ${O[((t.band ?? 0) + 7) % 8]}, ${n}, ${O[((t.band ?? 0) + 1) % 8]})`;
		case "sat": return `linear-gradient(90deg, #7a7a7a, ${n})`;
		case "lum": return `linear-gradient(90deg, #1a1a1a, ${n}, #ffffff)`;
		default: return;
	}
}
var k = 7e3, A = 1e3;
function De(e, t) {
	if (e.id === "wb.temp" && e.min < k && k < e.max) {
		let n = Math.log(1 + (e.max - k) / A);
		return t > k ? .5 + .5 * Math.log(1 + (t - k) / A) / n : .5 * (t - e.min) / (k - e.min);
	}
	return (t - e.min) / (e.max - e.min || 1);
}
function Oe(e, t) {
	let n;
	if (e.id === "wb.temp" && e.min < k && k < e.max) {
		let r = Math.log(1 + (e.max - k) / A);
		n = t > .5 ? k + A * (Math.exp((2 * t - 1) * r) - 1) : e.min + 2 * t * (k - e.min);
	} else n = e.min + t * (e.max - e.min);
	return Math.min(e.max, Math.max(e.min, Math.round(n / e.step) * e.step));
}
function j({ picture: e, title: _ = "Photo", doneLabel: te = "Done", onDone: ne, onClose: re }) {
	let v = f(null), [y, ie] = p("starting"), [b, x] = p(null), [S, C] = p(null), [w, ae] = p("develop"), [T, E] = p({
		width: 0,
		height: 0
	}), [D, O] = p(0), [k, A] = p(null), [j, Ae] = p(null), [M, je] = p(null), [Me, N] = p(!1), [P, Ne] = p([]), [Pe, Fe] = p(/* @__PURE__ */ new Map()), [Ie, Le] = p([]), [Re, ze] = p([]), [F, I] = p({
		zoom: 1,
		x: 0,
		y: 0
	}), [Be, Ve] = p("hand"), [L, R] = p(se), [He, Ue] = p([]), [We, Ge] = p(null), [z, B] = p(null), [Ke, qe] = p([]), [V, Je] = p(null), [Ye, Xe] = p(null), [Ze, Qe] = p(!1), H = f(-1), $e = f(!1), et = f(0), U = f(null), W = f(null), G = f(null), [K, tt] = p(null), [nt, rt] = p(!1), it = f(null), q = n.find((e) => e.id === Be), J = !!z && !!We && !be(z, We), at = (w === "develop" || w === "looks") && J && !!Ye, Y = (e, t = !1) => C({
		text: e,
		bad: t
	}), X = u(async () => {
		let e = v.current;
		if (!e) return;
		let [t, n, r, i, a] = await Promise.all([
			e.info(),
			e.composite(),
			e.selection(),
			e.execute("layer.list", { flat: !0 }),
			e.execute("document.inspect")
		]), o = /* @__PURE__ */ new Map(), s = (e = []) => {
			for (let t of e) o.set(t.id, {
				opacity: t.opacity ?? 1,
				blend: t.blend ?? "Normal"
			}), s(t.children);
		};
		s(a.layers), Fe(o), E({
			width: t.width,
			height: t.height
		}), O(t.revision), A(await Se(n)), je(r ? await Ce(r) : null), Ne(i.layers.map((e) => ({
			...e,
			depth: e.depth ?? 0
		}))), Le(a.history ?? []);
	}, []), ot = u((e, t) => {
		let n = U.current;
		if (!n || !e || !t) return;
		let r = n.getBoundingClientRect();
		if (r.width < 120 || r.height < 120) return;
		$e.current = !0;
		let i = Math.min(1, (r.width - 48) / e, (r.height - 48) / t);
		I({
			zoom: i,
			x: (r.width - e * i) / 2,
			y: (r.height - t * i) / 2
		});
	}, []);
	d(() => {
		let t = !1, n = oe();
		return v.current = n, (async () => {
			try {
				let r = await xe(e);
				Ae(await Se(r)), await n.openPicture(_, r);
				let [i, a, o] = await Promise.all([
					n.develop.controls(),
					n.develop.defaults(),
					n.develop.presets()
				]);
				if (t) return;
				Ue(i), Ge(a), B(a), qe(o), await X(), ze(await n.commands()), ie("ready"), ot(r.width, r.height);
			} catch (e) {
				if (t) return;
				ie("failed"), Y(e instanceof Error ? e.message : "Photo lab could not start.", !0);
			}
		})(), () => {
			t = !0, n.close(), v.current = null;
		};
	}, []);
	let Z = u(async (e, t, n) => {
		let r = v.current;
		if (!r) return null;
		x(n);
		try {
			let n = await r.execute(e, t);
			return await X(), w === "everything" && ze(await r.commands()), C(null), n;
		} catch (e) {
			return Y(e instanceof Error ? e.message : String(e), !0), null;
		} finally {
			x(null);
		}
	}, [X, w]), st = async () => {
		let e = v.current;
		e && !b && await e.undo() && await X();
	}, ct = async () => {
		let e = v.current;
		e && !b && await e.redo() && await X();
	};
	d(() => {
		let e = v.current;
		if (!e || y !== "ready" || !z || !J || w !== "develop" && w !== "looks") return;
		let t = ++et.current, n = setTimeout(async () => {
			try {
				H.current !== D && (await e.develop.source(await e.activePixels()), H.current = D);
				let n = Math.min(1, _e / Math.max(T.width, T.height)), r = await e.develop.render(z, Math.round(T.width * n), Math.round(T.height * n), Ze);
				t === et.current && Xe(await Se(r));
			} catch (e) {
				t === et.current && Y(e instanceof Error ? e.message : String(e), !0);
			}
		}, Ze ? 0 : 30);
		return () => clearTimeout(n);
	}, [
		z,
		J,
		w,
		D,
		T,
		Ze,
		y
	]);
	let lt = async (e, t) => {
		if (!z) return;
		let n = Math.min(e.max, Math.max(e.min, t)), r = we(z, e.id, n);
		r ? B(r) : v.current && B(await v.current.develop.set(z, e.id, n)), Je(null);
	}, ut = async (e, t = 1) => {
		let n = v.current;
		if (!n || !z) return;
		let r = V ? V.base : z;
		B(await n.develop.applyPreset(r, e, t)), Je({
			preset: e,
			amount: t,
			base: r
		});
	}, dt = () => {
		B(We), Je(null), Xe(null);
	}, ft = async () => {
		let e = v.current;
		if (e && z && J) {
			x("Applying");
			try {
				H.current !== D && (await e.develop.source(await e.activePixels()), H.current = D);
				let t = await e.develop.render(z, T.width, T.height, !1);
				t.width === T.width && t.height === T.height ? await e.replaceActive(V ? `Look: ${V.preset.name}` : "Develop", t) : await e.place("Developed", Math.round((T.width - t.width) / 2), Math.round((T.height - t.height) / 2), t), dt(), await X(), Y(V ? `${V.preset.name} applied.` : "Develop applied.");
			} catch (e) {
				Y(e instanceof Error ? e.message : String(e), !0);
			} finally {
				x(null);
			}
		}
	};
	d(() => {
		let e = W.current, t = U.current;
		if (!e || !t) return;
		let n = window.devicePixelRatio || 1, r = t.getBoundingClientRect();
		e.width = Math.round(r.width * n), e.height = Math.round(r.height * n);
		let i = e.getContext("2d"), a = l(e);
		i.setTransform(n, 0, 0, n, 0, 0), i.clearRect(0, 0, r.width, r.height);
		let o = Me ? j : at ? Ye : k;
		if (!o || !T.width) return;
		let s = T.width * F.zoom, u = T.height * F.zoom;
		i.save(), i.beginPath(), i.rect(F.x, F.y, s, u), i.clip();
		for (let e = 0; e < u; e += 10) for (let t = 0; t < s; t += 10) i.fillStyle = (t + e) / 10 % 2 ? a.checkerA : a.checkerB, i.fillRect(F.x + t, F.y + e, 10, 10);
		if (i.imageSmoothingQuality = "high", i.imageSmoothingEnabled = F.zoom < 2, i.drawImage(o, F.x, F.y, s, u), M && !Me && i.drawImage(M, F.x, F.y, s, u), i.restore(), K && K.points.length) {
			let e = K.points.map(([e, t]) => [F.x + e * F.zoom, F.y + t * F.zoom]);
			if (i.strokeStyle = a.handle, i.lineWidth = 1.5, i.setLineDash(K.tool.gesture === "stroke" ? [] : [6, 4]), i.beginPath(), K.tool.gesture === "box") {
				let [t, n] = [e[0], e[e.length - 1]];
				K.tool.id === "oval" ? i.ellipse((t[0] + n[0]) / 2, (t[1] + n[1]) / 2, Math.abs(n[0] - t[0]) / 2, Math.abs(n[1] - t[1]) / 2, 0, 0, Math.PI * 2) : i.rect(t[0], t[1], n[0] - t[0], n[1] - t[1]);
			} else K.tool.gesture === "line" ? (i.moveTo(e[0][0], e[0][1]), i.lineTo(e[e.length - 1][0], e[e.length - 1][1])) : (e.forEach(([e, t], n) => n ? i.lineTo(e, t) : i.moveTo(e, t)), K.tool.gesture === "lasso" && i.closePath(), K.tool.gesture === "stroke" && (i.globalAlpha = .35, i.lineWidth = Math.max(1, L.size * F.zoom), i.lineCap = "round", i.lineJoin = "round"));
			i.stroke(), i.globalAlpha = 1, i.setLineDash([]);
		}
		if (it.current && q.options.includes("size")) {
			let [e, t] = it.current;
			i.strokeStyle = c(a.handle, .8), i.lineWidth = 1, i.beginPath(), i.arc(F.x + e * F.zoom, F.y + t * F.zoom, Math.max(2, L.size / 2 * F.zoom), 0, Math.PI * 2), i.stroke();
		}
		if (q.source && L.source) {
			let [e, t] = L.source, n = F.x + e * F.zoom, r = F.y + t * F.zoom;
			i.strokeStyle = a.accent3, i.beginPath(), i.moveTo(n - 8, r), i.lineTo(n + 8, r), i.moveTo(n, r - 8), i.lineTo(n, r + 8), i.stroke();
		}
	});
	let [, pt] = p(0);
	d(() => {
		let e = U.current;
		if (!e) return;
		let t = new ResizeObserver(() => pt((e) => e + 1));
		return t.observe(e), () => t.disconnect();
	}, []), d(() => {
		!$e.current && T.width && ot(T.width, T.height);
	});
	let mt = (e) => {
		let t = W.current.getBoundingClientRect();
		return [(e.clientX - t.left - F.x) / F.zoom, (e.clientY - t.top - F.y) / F.zoom];
	}, ht = (e) => {
		if (y !== "ready" || b) return;
		e.currentTarget.setPointerCapture(e.pointerId);
		let t = mt(e);
		q.gesture === "pan" || nt || e.button === 1 ? G.current = {
			tool: n[0],
			start: [e.clientX, e.clientY],
			points: [],
			pan: {
				x: F.x,
				y: F.y
			}
		} : q.source && e.altKey ? (R((e) => ({
			...e,
			source: [Math.round(t[0]), Math.round(t[1])]
		})), Y("Copying from there. Now paint where it should go.")) : q.needsSelection && !M ? Y("Select the thing first (Tools › Select).", !0) : at ? Y("Apply or reset the develop first, so the tools work on what you see.", !0) : (G.current = {
			tool: q,
			start: t,
			points: [t]
		}, tt({
			points: [t],
			tool: q
		}));
	}, gt = (e) => {
		let t = mt(e);
		it.current = t;
		let n = G.current;
		n ? n.pan ? I((t) => ({
			...t,
			x: n.pan.x + e.clientX - n.start[0],
			y: n.pan.y + e.clientY - n.start[1]
		})) : (n.tool.gesture === "box" || n.tool.gesture === "line" ? n.points = [n.start, t] : n.points.push(t), tt({
			points: [...n.points],
			tool: n.tool
		})) : q.options.includes("size") && pt((e) => e + 1);
	}, _t = async (e) => {
		let t = G.current;
		if (G.current = null, tt(null), !t || t.pan) return;
		let n = mt(e), r = {
			...L,
			mode: le(L.mode, e)
		}, i;
		if (i = t.tool.gesture === "box" ? {
			kind: "box",
			x0: t.start[0],
			y0: t.start[1],
			x1: n[0],
			y1: n[1]
		} : t.tool.gesture === "line" ? {
			kind: "line",
			x0: t.start[0],
			y0: t.start[1],
			x1: n[0],
			y1: n[1]
		} : t.tool.gesture === "click" ? {
			kind: "click",
			x: n[0],
			y: n[1]
		} : {
			kind: t.tool.gesture === "lasso" ? "lasso" : "stroke",
			points: t.points
		}, t.tool.id === "dropper") {
			let e = await v.current?.execute("document.pixel", {
				x: Math.round(n[0]),
				y: Math.round(n[1])
			});
			if (e) {
				let t = `#${e.slice(0, 3).map((e) => Math.round(Math.min(1, Math.max(0, e)) * 255).toString(16).padStart(2, "0")).join("")}`;
				R((e) => ({
					...e,
					paint: t
				})), Y(`Paint colour is now ${t}.`);
			}
			return;
		}
		let a = ce(t.tool, i, r);
		"error" in a ? Y(a.error, !0) : await Z(a.id, a.params, t.tool.label);
	}, vt = (e) => {
		let t = W.current.getBoundingClientRect(), n = e.clientX - t.left, r = e.clientY - t.top, i = Math.exp(-e.deltaY * .0015);
		I((e) => {
			let t = Math.min(32, Math.max(.02, e.zoom * i));
			return {
				zoom: t,
				x: n - (n - e.x) * t / e.zoom,
				y: r - (r - e.y) * t / e.zoom
			};
		});
	};
	d(() => {
		let e = (e) => {
			if (e.target.closest("input, textarea, select")) return;
			let t = e.ctrlKey || e.metaKey;
			if (e.type === "keydown" && e.code === "Space" ? (rt(!0), e.preventDefault()) : e.type === "keyup" && e.code === "Space" && rt(!1), e.type !== "keydown") return;
			let n = e.key.toLowerCase();
			t && n === "z" ? (e.preventDefault(), e.shiftKey ? ct() : st()) : t && n === "y" ? (e.preventDefault(), ct()) : n === "[" ? R((e) => ({
				...e,
				size: Math.max(1, Math.round(e.size / 1.2))
			})) : n === "]" ? R((e) => ({
				...e,
				size: Math.min(2e3, Math.round(e.size * 1.2))
			})) : e.key === "\\" ? N(!0) : e.key === "Escape" && (G.current = null, tt(null));
		}, t = (t) => {
			t.key === "\\" && N(!1), e(t);
		};
		return window.addEventListener("keydown", e), window.addEventListener("keyup", t), () => {
			window.removeEventListener("keydown", e), window.removeEventListener("keyup", t);
		};
	});
	let yt = f(null), bt = async (e) => {
		let t = v.current;
		if (t) {
			x("Opening");
			try {
				let { warnings: n } = await t.openFile(e.name, new Uint8Array(await e.arrayBuffer()));
				dt(), H.current = -1, await X();
				let r = await t.info();
				ot(r.width, r.height), ze(await t.commands()), Y(n.length ? `Opened ${e.name}. ${n.slice(0, 2).join(" ")}` : `Opened ${e.name}.`);
			} catch (e) {
				Y(e instanceof Error ? e.message : String(e), !0);
			} finally {
				x(null);
			}
		}
	}, xt = async (e) => {
		let t = v.current;
		if (t) {
			x("Saving");
			try {
				let n = await t.export(e, e === "jpg" || e === "webp" ? { quality: 92 } : void 0), r = {
					psd: "image/vnd.adobe.photoshop",
					png: "image/png",
					jpg: "image/jpeg",
					webp: "image/webp",
					tif: "image/tiff"
				}[e] ?? "application/octet-stream", i = URL.createObjectURL(new Blob([n], { type: r })), a = document.createElement("a");
				a.href = i, a.download = `${_}.${e}`, a.click(), setTimeout(() => URL.revokeObjectURL(i), 1e4);
			} catch (e) {
				Y(e instanceof Error ? e.message : String(e), !0);
			} finally {
				x(null);
			}
		}
	}, St = async () => {
		let e = v.current;
		if (e && (!J || confirm("The develop changes are not applied yet. Finish without them?"))) {
			x("Finishing");
			try {
				let t = await e.export("png");
				ne(new Blob([t], { type: "image/png" }));
			} catch (e) {
				Y(e instanceof Error ? e.message : String(e), !0), x(null);
			}
		}
	}, Ct = ee(() => {
		let e = /* @__PURE__ */ new Map();
		for (let t of He) {
			if (t.id.startsWith("hdr.")) continue;
			let n = e.get(t.sectionLabel) ?? [];
			n.push(t), e.set(t.sectionLabel, n);
		}
		return [...e.entries()];
	}, [He]), [wt, Tt] = p(() => /* @__PURE__ */ new Set(["Light", "Color"])), Et = ee(() => {
		let e = /* @__PURE__ */ new Map();
		for (let t of Ke) e.set(t.group, [...e.get(t.group) ?? [], t]);
		return [...e.entries()];
	}, [Ke]), Dt = J && /* @__PURE__ */ g("div", {
		className: "gs-lab__applybar",
		children: [
			/* @__PURE__ */ h("span", { children: V ? `Trying ${V.preset.name}` : "Previewing the develop" }),
			/* @__PURE__ */ h("button", {
				type: "button",
				className: "gs-lab__btn",
				onClick: dt,
				children: "Reset"
			}),
			/* @__PURE__ */ h("button", {
				type: "button",
				className: "gs-lab__btn gs-lab__btn--primary",
				disabled: !!b,
				onClick: () => void ft(),
				children: "Apply"
			})
		]
	}), Ot = /* @__PURE__ */ g("div", {
		className: "gs-lab__panel-body",
		children: [
			/* @__PURE__ */ h(a, { id: "labDevelop" }),
			Dt,
			Ct.map(([e, t]) => {
				let n = wt.has(e);
				return /* @__PURE__ */ g("section", {
					className: "gs-lab__section",
					children: [/* @__PURE__ */ g("button", {
						type: "button",
						className: "gs-lab__section-head",
						"aria-expanded": n,
						onClick: () => Tt((t) => {
							let n = new Set(t);
							return n.has(e) ? n.delete(e) : n.add(e), n;
						}),
						children: [/* @__PURE__ */ h("span", { children: e }), /* @__PURE__ */ h("span", {
							className: "gs-lab__count",
							children: t.length
						})]
					}), n && t.map((e) => {
						let t = Te(z, e.id) ?? e.default, n = Ee(e);
						return /* @__PURE__ */ g("label", {
							className: "gs-lab__slider",
							children: [/* @__PURE__ */ g("span", {
								className: "gs-lab__slider-label",
								children: [e.label, /* @__PURE__ */ h("output", { children: t > 0 && e.min < 0 ? `+${t.toFixed(e.decimals)}` : t.toFixed(e.decimals) })]
							}), /* @__PURE__ */ h("input", {
								type: "range",
								min: 0,
								max: 1e3,
								step: 1,
								value: Math.round(De(e, t) * 1e3),
								style: n ? { background: n } : void 0,
								onPointerDown: () => Qe(!0),
								onPointerUp: () => Qe(!1),
								onDoubleClick: () => void lt(e, e.default),
								onChange: (t) => void lt(e, Oe(e, Number(t.target.value) / 1e3)),
								title: "Double-click to reset"
							})]
						}, e.id);
					})]
				}, e);
			})
		]
	}), kt = /* @__PURE__ */ g("div", {
		className: "gs-lab__panel-body",
		children: [
			/* @__PURE__ */ h(a, { id: "labLooks" }),
			Dt,
			V && /* @__PURE__ */ g("label", {
				className: "gs-lab__slider",
				children: [/* @__PURE__ */ g("span", {
					className: "gs-lab__slider-label",
					children: ["Strength", /* @__PURE__ */ g("output", { children: [Math.round(V.amount * 100), "%"] })]
				}), /* @__PURE__ */ h("input", {
					type: "range",
					min: 0,
					max: 2,
					step: .05,
					value: V.amount,
					onChange: (e) => void ut(V.preset, Number(e.target.value))
				})]
			}),
			Et.map(([e, t]) => /* @__PURE__ */ g("section", {
				className: "gs-lab__section",
				children: [/* @__PURE__ */ h("h4", {
					className: "gs-lab__group",
					children: e
				}), /* @__PURE__ */ h("div", {
					className: "gs-lab__chips",
					children: t.map((e) => /* @__PURE__ */ h("button", {
						type: "button",
						className: `gs-lab__chip${V?.preset.id === e.id ? " is-on" : ""}`,
						onClick: () => void ut(e, V?.preset.id === e.id ? V.amount : 1),
						children: e.name
					}, e.id))
				})]
			}, e))
		]
	}), At = /* @__PURE__ */ g("div", {
		className: "gs-lab__panel-body",
		children: [/* @__PURE__ */ h(a, { id: "labTools" }), i.map((e) => /* @__PURE__ */ g("section", {
			className: "gs-lab__section",
			children: [
				/* @__PURE__ */ h("h4", {
					className: "gs-lab__group",
					children: e
				}),
				/* @__PURE__ */ h("div", {
					className: "gs-lab__tools",
					children: n.filter((t) => t.group === e).map((e) => /* @__PURE__ */ h("button", {
						type: "button",
						className: `gs-lab__tool${e.id === Be ? " is-on" : ""}`,
						onClick: () => Ve(e.id),
						title: e.hint,
						children: e.label
					}, e.id))
				}),
				e === "Select" && /* @__PURE__ */ g(m, { children: [
					/* @__PURE__ */ g("div", {
						className: "gs-lab__chips",
						children: [
							/* @__PURE__ */ h("button", {
								type: "button",
								className: "gs-lab__chip",
								onClick: () => void Z("select.subject", {}, "Selecting the main thing"),
								children: "Main thing"
							}),
							/* @__PURE__ */ h("button", {
								type: "button",
								className: "gs-lab__chip",
								onClick: () => void Z("select.sky", {}, "Selecting the sky"),
								children: "Sky"
							}),
							/* @__PURE__ */ h("button", {
								type: "button",
								className: "gs-lab__chip",
								onClick: () => void Z("select.focusArea", {}, "Selecting what is sharp"),
								children: "In focus"
							}),
							/* @__PURE__ */ h("button", {
								type: "button",
								className: "gs-lab__chip",
								onClick: () => void Z("select.all", {}, "Selecting all"),
								children: "All"
							}),
							/* @__PURE__ */ h("button", {
								type: "button",
								className: "gs-lab__chip",
								disabled: !M,
								onClick: () => void Z("select.inverse", {}, "Inverting"),
								children: "Invert"
							}),
							/* @__PURE__ */ h("button", {
								type: "button",
								className: "gs-lab__chip",
								disabled: !M,
								onClick: () => void Z("select.deselect", {}, "Clearing"),
								children: "Clear"
							})
						]
					}),
					/* @__PURE__ */ g("div", {
						className: "gs-lab__chips",
						children: [
							/* @__PURE__ */ h("button", {
								type: "button",
								className: "gs-lab__chip",
								disabled: !M,
								onClick: () => void Z("select.refineEdge", {
									radius: 6,
									smartRadius: !0,
									smooth: 10,
									decontaminate: !0
								}, "Refining the edge"),
								children: "Refine edge"
							}),
							/* @__PURE__ */ h("button", {
								type: "button",
								className: "gs-lab__chip",
								disabled: !M,
								onClick: () => void Z("edit.contentAwareFill", {}, "Filling from around it"),
								children: "Fill from around"
							}),
							/* @__PURE__ */ h("button", {
								type: "button",
								className: "gs-lab__chip",
								disabled: !M,
								onClick: () => void Z("layer.new.layerViaCopy", {}, "Copying to a layer"),
								children: "Copy to new layer"
							})
						]
					}),
					/* @__PURE__ */ h(a, { id: "labSelect" })
				] })
			]
		}, e))]
	}), [jt, Mt] = p(""), [Nt, Pt] = p(null), Ft = ee(() => {
		let e = jt.trim().toLowerCase(), t = /* @__PURE__ */ new Map();
		for (let n of Re) {
			let r = n.menu[0];
			if (r && de.has(r) || !r && pe.test(n.id)) continue;
			let i = r ? n.menu.join(" › ") : "More";
			fe.has(i) || (!e || [
				n.label,
				n.id,
				n.keywords ?? "",
				i
			].some((t) => t.toLowerCase().includes(e))) && t.set(i, [...t.get(i) ?? [], n]);
		}
		return [...t.entries()].sort(([e], [t]) => e === "More" ? 1 : t === "More" ? -1 : e.localeCompare(t));
	}, [Re, jt]), It = /* @__PURE__ */ g("div", {
		className: "gs-lab__panel-body",
		children: [
			/* @__PURE__ */ h(a, { id: "labEverything" }),
			/* @__PURE__ */ h("input", {
				className: "gs-lab__search",
				type: "search",
				placeholder: "Search: blur, levels, warp, sharpen…",
				value: jt,
				onChange: (e) => Mt(e.target.value)
			}),
			/* @__PURE__ */ h("p", {
				className: "gs-lab__muted",
				children: ve(Ft.reduce((e, [, t]) => e + t.length, 0), "command")
			}),
			Ft.map(([e, t]) => /* @__PURE__ */ g("details", {
				className: "gs-lab__menu",
				open: !!jt.trim(),
				children: [/* @__PURE__ */ g("summary", { children: [
					e,
					" ",
					/* @__PURE__ */ h("span", {
						className: "gs-lab__count",
						children: t.length
					})
				] }), t.map((e) => /* @__PURE__ */ h(ke, {
					command: e,
					open: Nt === e.id,
					busy: !!b,
					onOpen: () => Pt(Nt === e.id ? null : e.id),
					onRun: (t) => void Z(e.id, t, ye(e.label))
				}, e.id))]
			}, e))
		]
	}), Q = P.find((e) => e.active), Lt = Q ? Pe.get(Q.id) : void 0, [$, Rt] = p(100);
	d(() => Rt(Math.round((Lt?.opacity ?? 1) * 100)), [Lt?.opacity, Q?.id]);
	let zt = {
		develop: Ot,
		looks: kt,
		tools: At,
		everything: It,
		layers: /* @__PURE__ */ g("div", {
			className: "gs-lab__panel-body",
			children: [
				/* @__PURE__ */ h(a, { id: "labLayers" }),
				/* @__PURE__ */ g("div", {
					className: "gs-lab__chips",
					children: [
						/* @__PURE__ */ h("button", {
							type: "button",
							className: "gs-lab__chip",
							onClick: () => void Z("layer.new.layer", {}, "New layer"),
							children: "New"
						}),
						/* @__PURE__ */ h("button", {
							type: "button",
							className: "gs-lab__chip",
							disabled: !Q,
							onClick: () => void Z("layer.duplicate", {}, "Duplicate"),
							children: "Duplicate"
						}),
						/* @__PURE__ */ h("button", {
							type: "button",
							className: "gs-lab__chip",
							disabled: !Q || P.length < 2,
							onClick: () => void Z("layer.mergeDown", {}, "Merge down"),
							children: "Merge down"
						}),
						/* @__PURE__ */ h("button", {
							type: "button",
							className: "gs-lab__chip",
							disabled: P.length < 2,
							onClick: () => void Z("layer.flattenImage", {}, "Flatten"),
							children: "Flatten"
						}),
						/* @__PURE__ */ h("button", {
							type: "button",
							className: "gs-lab__chip",
							disabled: !Q || P.length < 2,
							onClick: () => void Z("layer.delete", {}, "Delete layer"),
							children: "Delete"
						})
					]
				}),
				Q && /* @__PURE__ */ g("div", {
					className: "gs-lab__layer-props",
					children: [/* @__PURE__ */ g("label", {
						className: "gs-lab__slider",
						children: [/* @__PURE__ */ g("span", {
							className: "gs-lab__slider-label",
							children: ["Opacity", /* @__PURE__ */ g("output", { children: [$, "%"] })]
						}), /* @__PURE__ */ h("input", {
							type: "range",
							min: 0,
							max: 100,
							value: $,
							onChange: (e) => Rt(Number(e.target.value)),
							onPointerUp: () => void Z("layer.setProps", {
								layer: Q.id,
								opacity: $ / 100
							}, "Opacity"),
							onKeyUp: () => void Z("layer.setProps", {
								layer: Q.id,
								opacity: $ / 100
							}, "Opacity")
						})]
					}), /* @__PURE__ */ g("label", {
						className: "gs-lab__field",
						children: ["Blend", /* @__PURE__ */ h("select", {
							value: Lt?.blend ?? "Normal",
							onChange: (e) => void Z("layer.setProps", {
								layer: Q.id,
								blend: e.target.value
							}, "Blend"),
							children: me.map((e) => /* @__PURE__ */ h("option", {
								value: e,
								children: e
							}, e))
						})]
					})]
				}),
				/* @__PURE__ */ h("ul", {
					className: "gs-lab__layers",
					children: P.map((e) => /* @__PURE__ */ g("li", {
						className: e.active ? "is-on" : void 0,
						style: { paddingLeft: 8 + e.depth * 14 },
						children: [/* @__PURE__ */ h("button", {
							type: "button",
							className: "gs-lab__eye",
							"aria-label": e.visible ? "Hide" : "Show",
							onClick: () => void Z("layer.setProps", {
								layer: e.id,
								visible: !e.visible
							}, e.visible ? "Hide" : "Show"),
							children: e.visible ? "●" : "○"
						}), /* @__PURE__ */ g("button", {
							type: "button",
							className: "gs-lab__layer-name",
							onClick: () => void Z("layer.select", { layer: e.id }, "Select layer"),
							children: [e.name, /* @__PURE__ */ g("span", {
								className: "gs-lab__muted",
								children: [" ", e.kind]
							})]
						})]
					}, e.id))
				})
			]
		}),
		history: /* @__PURE__ */ g("div", {
			className: "gs-lab__panel-body",
			children: [/* @__PURE__ */ h(a, { id: "labHistory" }), /* @__PURE__ */ h("ol", {
				className: "gs-lab__history",
				children: Ie.map((e, t) => /* @__PURE__ */ h("li", { children: /* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => void Z("history.selectState", { state: t }, `Back to ${e}`),
					children: e
				}) }, `${t}-${e}`))
			})]
		})
	}[w], Bt = w === "tools" && /* @__PURE__ */ g("div", {
		className: "gs-lab__options",
		children: [
			/* @__PURE__ */ h("strong", { children: q.label }),
			q.options.includes("size") && /* @__PURE__ */ g("label", { children: [
				"Size",
				/* @__PURE__ */ h("input", {
					type: "range",
					min: 1,
					max: 500,
					value: L.size,
					onChange: (e) => R({
						...L,
						size: Number(e.target.value)
					})
				}),
				/* @__PURE__ */ g("output", { children: [L.size, "px"] })
			] }),
			q.options.includes("hardness") && /* @__PURE__ */ g("label", { children: ["Hardness", /* @__PURE__ */ h("input", {
				type: "range",
				min: 0,
				max: 1,
				step: .05,
				value: L.hardness,
				onChange: (e) => R({
					...L,
					hardness: Number(e.target.value)
				})
			})] }),
			q.options.includes("opacity") && /* @__PURE__ */ g("label", { children: ["Strength", /* @__PURE__ */ h("input", {
				type: "range",
				min: .05,
				max: 1,
				step: .05,
				value: L.opacity,
				onChange: (e) => R({
					...L,
					opacity: Number(e.target.value)
				})
			})] }),
			q.options.includes("flow") && /* @__PURE__ */ g("label", { children: ["Flow", /* @__PURE__ */ h("input", {
				type: "range",
				min: .05,
				max: 1,
				step: .05,
				value: L.flow,
				onChange: (e) => R({
					...L,
					flow: Number(e.target.value)
				})
			})] }),
			q.options.includes("tolerance") && /* @__PURE__ */ g("label", { children: [
				"Tolerance",
				/* @__PURE__ */ h("input", {
					type: "range",
					min: 0,
					max: 255,
					value: L.tolerance,
					onChange: (e) => R({
						...L,
						tolerance: Number(e.target.value)
					})
				}),
				/* @__PURE__ */ h("output", { children: L.tolerance })
			] }),
			q.options.includes("mode") && /* @__PURE__ */ g("label", { children: ["Selection", /* @__PURE__ */ h("select", {
				value: L.mode,
				onChange: (e) => R({
					...L,
					mode: e.target.value
				}),
				children: s.map((e) => /* @__PURE__ */ h("option", {
					value: e.id,
					children: e.label
				}, e.id))
			})] }),
			q.options.includes("colors") && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("label", { children: ["Paint", /* @__PURE__ */ h("input", {
				type: "color",
				value: L.paint,
				onChange: (e) => R({
					...L,
					paint: e.target.value
				})
			})] }), /* @__PURE__ */ g("label", { children: ["Second", /* @__PURE__ */ h("input", {
				type: "color",
				value: L.second,
				onChange: (e) => R({
					...L,
					second: e.target.value
				})
			})] })] }),
			/* @__PURE__ */ g("span", {
				className: "gs-lab__hint",
				children: [q.hint, /* @__PURE__ */ h(r, { text: q.dev })]
			})
		]
	});
	return /* @__PURE__ */ g("div", {
		className: "gs-lab",
		tabIndex: -1,
		children: [/* @__PURE__ */ g("header", {
			className: "gs-lab__top",
			children: [
				/* @__PURE__ */ h("button", {
					type: "button",
					className: "gs-lab__btn",
					onClick: re,
					"aria-label": "Close Photo lab",
					children: /* @__PURE__ */ h(o, { name: "close" })
				}),
				/* @__PURE__ */ g("strong", {
					className: "gs-lab__title",
					children: ["Photo lab ", /* @__PURE__ */ h("span", {
						className: "gs-lab__muted",
						children: _
					})]
				}),
				/* @__PURE__ */ h("button", {
					type: "button",
					className: "gs-lab__btn",
					disabled: y !== "ready" || !!b,
					onClick: () => void st(),
					title: "Undo (Ctrl+Z)",
					children: /* @__PURE__ */ h(o, { name: "undo" })
				}),
				/* @__PURE__ */ h("button", {
					type: "button",
					className: "gs-lab__btn",
					disabled: y !== "ready" || !!b,
					onClick: () => void ct(),
					title: "Redo (Ctrl+Shift+Z)",
					children: /* @__PURE__ */ h(o, { name: "redo" })
				}),
				/* @__PURE__ */ g("button", {
					type: "button",
					className: "gs-lab__btn",
					disabled: !j,
					onPointerDown: () => N(!0),
					onPointerUp: () => N(!1),
					onPointerLeave: () => N(!1),
					title: "Hold to see the photo as it came in (\\)",
					children: [/* @__PURE__ */ h(o, { name: "compare" }), " Before"]
				}),
				/* @__PURE__ */ h("button", {
					type: "button",
					className: "gs-lab__btn",
					onClick: () => ot(T.width, T.height),
					children: "Fit"
				}),
				/* @__PURE__ */ h("button", {
					type: "button",
					className: "gs-lab__btn",
					onClick: () => {
						let e = U.current.getBoundingClientRect();
						I({
							zoom: 1,
							x: (e.width - T.width) / 2,
							y: (e.height - T.height) / 2
						});
					},
					children: "100%"
				}),
				/* @__PURE__ */ g("span", {
					className: "gs-lab__muted",
					children: [
						T.width,
						" × ",
						T.height,
						" · ",
						Math.round(F.zoom * 100),
						"%"
					]
				}),
				/* @__PURE__ */ h("span", { className: "gs-lab__spacer" }),
				/* @__PURE__ */ h("button", {
					type: "button",
					className: "gs-lab__btn",
					disabled: y !== "ready",
					onClick: () => yt.current?.click(),
					title: "Open a PSD or any photo",
					children: "Open file"
				}),
				/* @__PURE__ */ h("input", {
					ref: yt,
					type: "file",
					accept: ge,
					hidden: !0,
					onChange: (e) => {
						let t = e.target.files?.[0];
						e.target.value = "", t && bt(t);
					}
				}),
				/* @__PURE__ */ g("select", {
					className: "gs-lab__btn",
					value: "",
					disabled: y !== "ready",
					onChange: (e) => e.target.value && void xt(e.target.value),
					"aria-label": "Save a copy",
					children: [/* @__PURE__ */ h("option", {
						value: "",
						children: "Save a copy…"
					}), he.map((e) => /* @__PURE__ */ h("option", {
						value: e.ext,
						children: e.label
					}, e.ext))]
				}),
				/* @__PURE__ */ h(t, {}),
				/* @__PURE__ */ h("button", {
					type: "button",
					className: "gs-lab__btn gs-lab__btn--primary",
					disabled: y !== "ready" || !!b,
					onClick: () => void St(),
					children: te
				})
			]
		}), /* @__PURE__ */ g("div", {
			className: "gs-lab__main",
			children: [
				/* @__PURE__ */ h("nav", {
					className: "gs-lab__rail",
					"aria-label": "Photo lab panels",
					children: ue.map((e) => /* @__PURE__ */ g("button", {
						type: "button",
						className: `gs-lab__rail-btn${w === e.id ? " is-on" : ""}`,
						onClick: () => ae(e.id),
						children: [/* @__PURE__ */ h(o, {
							name: e.glyph,
							size: 18
						}), /* @__PURE__ */ h("span", { children: e.label })]
					}, e.id))
				}),
				/* @__PURE__ */ h("aside", {
					className: "gs-lab__panel",
					children: y === "ready" ? zt : /* @__PURE__ */ h("p", {
						className: "gs-lab__muted",
						children: y === "starting" ? "Starting Photo lab…" : "Photo lab could not start."
					})
				}),
				/* @__PURE__ */ g("div", {
					className: "gs-lab__stagewrap",
					children: [
						Bt,
						/* @__PURE__ */ g("div", {
							ref: U,
							className: `gs-lab__stage${nt || q.gesture === "pan" ? " is-pan" : ""}`,
							onDragOver: (e) => e.preventDefault(),
							onDrop: (e) => {
								e.preventDefault();
								let t = e.dataTransfer.files?.[0];
								t && bt(t);
							},
							children: [
								/* @__PURE__ */ h("canvas", {
									ref: W,
									onPointerDown: ht,
									onPointerMove: gt,
									onPointerUp: (e) => void _t(e),
									onPointerLeave: () => {
										it.current = null, pt((e) => e + 1);
									},
									onWheel: vt
								}),
								at && /* @__PURE__ */ h("span", {
									className: "gs-lab__badge",
									children: "Preview: press Apply to keep it"
								}),
								Me && /* @__PURE__ */ h("span", {
									className: "gs-lab__badge",
									children: "Before"
								}),
								(b || y === "starting") && /* @__PURE__ */ h("span", {
									className: "gs-lab__busy",
									children: b ?? "Starting the engines…"
								})
							]
						}),
						S && /* @__PURE__ */ g("div", {
							className: `gs-lab__message${S.bad ? " is-bad" : ""}`,
							role: "status",
							children: [S.text, /* @__PURE__ */ h("button", {
								type: "button",
								onClick: () => C(null),
								"aria-label": "Dismiss",
								children: "×"
							})]
						})
					]
				})
			]
		})]
	});
}
function ke({ command: e, open: t, busy: n, onOpen: i, onRun: a }) {
	let o = ee(() => C(e.params), [e.params]), [s, c] = p(() => ae(o)), [l, u] = p(null), d = o.fields.filter((e) => e.kind !== "json"), f = o.fields.filter((e) => e.kind === "json"), m = !e.enabled, _ = () => {
		try {
			u(null), a(w(o, s));
		} catch (e) {
			u(e instanceof Error ? e.message : String(e));
		}
	};
	return /* @__PURE__ */ g("div", {
		className: `gs-lab__cmd${t ? " is-open" : ""}${m ? " is-off" : ""}`,
		children: [/* @__PURE__ */ g("button", {
			type: "button",
			className: "gs-lab__cmd-head",
			onClick: () => o.fields.length ? i() : !m && !n && _(),
			title: m ? e.disabledReason ?? "Not available right now" : e.id,
			children: [
				ye(e.label),
				e.shortcut && /* @__PURE__ */ h("kbd", { children: e.shortcut }),
				!o.fields.length && !m && /* @__PURE__ */ h("span", {
					className: "gs-lab__muted",
					children: " · runs now"
				})
			]
		}), t && /* @__PURE__ */ g("div", {
			className: "gs-lab__cmd-form",
			children: [
				m && /* @__PURE__ */ h("p", {
					className: "gs-lab__muted",
					children: e.disabledReason ?? "Not available right now."
				}),
				d.map((e) => /* @__PURE__ */ h(M, {
					field: e,
					value: s[e.key],
					onChange: (t) => c({
						...s,
						[e.key]: t
					})
				}, e.key)),
				f.length > 0 && /* @__PURE__ */ g("details", { children: [/* @__PURE__ */ h("summary", { children: "More settings" }), f.map((e) => /* @__PURE__ */ h(M, {
					field: e,
					value: s[e.key],
					onChange: (t) => c({
						...s,
						[e.key]: t
					})
				}, e.key))] }),
				o.notes && /* @__PURE__ */ h("p", {
					className: "gs-lab__muted",
					children: o.notes
				}),
				/* @__PURE__ */ h(r, { text: `${e.id} ${e.params}` }),
				l && /* @__PURE__ */ h("p", {
					className: "gs-lab__error",
					children: l
				}),
				/* @__PURE__ */ g("div", {
					className: "gs-lab__chips",
					children: [/* @__PURE__ */ h("button", {
						type: "button",
						className: "gs-lab__btn",
						onClick: () => c(ae(o)),
						children: "Reset"
					}), /* @__PURE__ */ h("button", {
						type: "button",
						className: "gs-lab__btn gs-lab__btn--primary",
						disabled: m || n,
						onClick: _,
						children: "Apply"
					})]
				})
			]
		})]
	});
}
var Ae = (e) => e.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/^./, (e) => e.toUpperCase());
function M({ field: e, value: t, onChange: n }) {
	let r = Ae(e.key);
	switch (e.kind) {
		case "range": {
			let i = typeof t == "number" ? t : e.default, a = e.max - e.min, o = e.integer ? 1 : a > 100 ? .1 : a > 10 ? .05 : .01, s = e.min >= 0 && e.max >= 200 && e.max / Math.max(e.min, .1) >= 100, c = (t) => (s ? Math.cbrt((t - e.min) / a) : (t - e.min) / a) * 1e3, l = (t) => {
				let n = t / 1e3, r = e.min + (s ? n * n * n : n) * a;
				return e.integer ? Math.round(r) : Math.round(r / o) * o;
			};
			return /* @__PURE__ */ g("label", {
				className: "gs-lab__slider",
				children: [/* @__PURE__ */ g("span", {
					className: "gs-lab__slider-label",
					children: [r, /* @__PURE__ */ h("input", {
						className: "gs-lab__num",
						type: "number",
						min: e.min,
						max: e.max,
						step: o,
						value: i,
						onChange: (e) => n(e.target.value === "" ? void 0 : Number(e.target.value))
					})]
				}), /* @__PURE__ */ h("input", {
					type: "range",
					min: 0,
					max: 1e3,
					step: 1,
					value: Math.round(c(i)),
					onChange: (e) => n(l(Number(e.target.value)))
				})]
			});
		}
		case "bool": return /* @__PURE__ */ g("label", {
			className: "gs-lab__check",
			children: [/* @__PURE__ */ h("input", {
				type: "checkbox",
				checked: typeof t == "boolean" ? t : e.default,
				onChange: (e) => n(e.target.checked)
			}), r]
		});
		case "choice": return /* @__PURE__ */ g("label", {
			className: "gs-lab__field",
			children: [r, /* @__PURE__ */ h("select", {
				value: t ?? e.default,
				onChange: (e) => n(e.target.value),
				children: e.options.map((e) => /* @__PURE__ */ h("option", {
					value: e,
					children: Ae(e)
				}, e))
			})]
		});
		case "number": return /* @__PURE__ */ g("label", {
			className: "gs-lab__field",
			children: [r, /* @__PURE__ */ h("input", {
				type: "number",
				step: e.integer ? 1 : "any",
				value: t == null ? "" : String(t),
				placeholder: e.optional ? "default" : void 0,
				onChange: (e) => n(e.target.value === "" ? void 0 : Number(e.target.value))
			})]
		});
		case "text": return /* @__PURE__ */ g("label", {
			className: "gs-lab__field",
			children: [r, /* @__PURE__ */ h("input", {
				type: "text",
				value: t ?? "",
				placeholder: e.optional ? "default" : e.hint,
				onChange: (e) => n(e.target.value)
			})]
		});
		case "json": return /* @__PURE__ */ g("label", {
			className: "gs-lab__field",
			children: [r, /* @__PURE__ */ h("input", {
				type: "text",
				value: t ?? "",
				placeholder: e.hint.slice(0, 60),
				onChange: (e) => n(e.target.value)
			})]
		});
	}
}
//#endregion
export { D as n, j as t };

//# sourceMappingURL=PhotoLab-Dqdwd0gL.js.map