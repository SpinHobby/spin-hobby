import { n as e } from "./rolldown-runtime-DArdT4gl.js";
import { l as t, s as n } from "./src-L5EyMOAw.js";
import { i as r, n as i, r as a, t as o } from "./ModelMode-hMcQJ25f.js";
function s(e) {
	let t = e.flat();
	if (!t.length) return {
		contours: [],
		aspect: 1
	};
	let n = t.map((e) => e[0]), r = t.map((e) => e[1]), [i, a, o, s] = [
		Math.min(...n),
		Math.max(...n),
		Math.min(...r),
		Math.max(...r)
	], l = Math.max(a - i, 1e-6), u = Math.max(s - o, 1e-6);
	return {
		contours: e.map((e) => e.map(([e, t]) => [c((e - i) / l - .5), c((t - o) / u - .5)])),
		aspect: l / u
	};
}
var c = (e) => Math.round(e * 1e4) / 1e4;
function l(e, t, n, r) {
	let i = new Uint8Array(t * n), a = [];
	for (let t of e) for (let e = 0; e < t.length; e++) {
		let n = r(t[e]), i = r(t[(e + 1) % t.length]);
		n[1] !== i[1] && a.push([
			n[0],
			n[1],
			i[0],
			i[1]
		]);
	}
	let o = [];
	for (let e = 0; e < n; e++) {
		let n = e + .5;
		o.length = 0;
		for (let [e, t, r, i] of a) (t <= n && i > n || i <= n && t > n) && o.push(e + (n - t) / (i - t) * (r - e));
		o.sort((e, t) => e - t);
		for (let n = 0; n + 1 < o.length; n += 2) {
			let r = Math.max(0, Math.ceil(o[n] - .5)), a = Math.min(t - 1, Math.floor(o[n + 1] - .5));
			for (let n = r; n <= a; n++) i[e * t + n] = 1;
		}
	}
	return i;
}
var u = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new WeakMap();
function f(e, t, n) {
	let r = d.get(e);
	if (r && r.sx === t && r.sy === n) return r.field;
	let i = `${t.toFixed(4)}x${n.toFixed(4)}:${JSON.stringify(e)}`, a = u.get(i);
	if (a) return d.set(e, {
		sx: t,
		sy: n,
		field: a
	}), a;
	let o = Math.max(t, n) / 2 * 1.3, s = 2 * o / 256, c = ([e, r]) => [(e * t + o) / s, (o - r * n) / s], f = l(e, 256, 256, c), m = p(e.map((e) => e.map(c)), 256, 256, 25), h = /* @__PURE__ */ new Float32Array(65536);
	for (let e = 0; e < h.length; e++) {
		let t = f[e] ? -m[e] : m[e];
		h[e] = Math.min(24, Math.max(-24, t));
	}
	let g = {
		grid: h,
		half: o,
		texel: s
	};
	return u.size > 64 && u.delete(u.keys().next().value), u.set(i, g), d.set(e, {
		sx: t,
		sy: n,
		field: g
	}), g;
}
function p(e, t, n, r) {
	let i = new Float32Array(t * n).fill(r);
	for (let a of e) for (let e = 0; e < a.length; e++) {
		let [o, s] = a[e], [c, l] = a[(e + 1) % a.length], u = c - o, d = l - s, f = u * u + d * d || 1e-12, p = Math.max(0, Math.floor(Math.min(o, c) - r)), m = Math.min(t - 1, Math.ceil(Math.max(o, c) + r)), h = Math.max(0, Math.floor(Math.min(s, l) - r)), g = Math.min(n - 1, Math.ceil(Math.max(s, l) + r));
		for (let e = h; e <= g; e++) {
			let n = e + .5;
			for (let r = p; r <= m; r++) {
				let a = r + .5, c = Math.min(1, Math.max(0, ((a - o) * u + (n - s) * d) / f)), l = a - o - u * c, p = n - s - d * c, m = Math.sqrt(l * l + p * p), h = e * t + r;
				m < i[h] && (i[h] = m);
			}
		}
	}
	return i;
}
function m(e, t, n) {
	let r = Math.min(255, Math.max(0, (t + e.half) / e.texel - .5)), i = Math.min(255, Math.max(0, (e.half - n) / e.texel - .5)), a = Math.floor(r), o = Math.floor(i), s = Math.min(255, a + 1), c = Math.min(255, o + 1), l = r - a, u = i - o, d = e.grid, f = ((d[o * 256 + a] * (1 - l) + d[o * 256 + s] * l) * (1 - u) + (d[c * 256 + a] * (1 - l) + d[c * 256 + s] * l) * u) * e.texel, p = Math.max(Math.abs(t) - e.half * .98, 0), m = Math.max(Math.abs(n) - e.half * .98, 0);
	return f + Math.hypot(p, m);
}
function h(e, t, n, r) {
	let i = (e, i) => e >= 0 && i >= 0 && e < n && i < r ? t[i * n + e] : 0;
	return e.map(([t, n], r) => {
		let [a, o] = e[(r + 1) % e.length], [s, c] = [a - t, o - n], [l, u] = [(t + a) / 2, (n + o) / 2], [d, f] = [l + c * .5, u - s * .5], [p, m] = [l - c * .5, u + s * .5], h = i(Math.floor(d), Math.floor(f)), g = i(Math.floor(p), Math.floor(m)), _ = h - g > 1e-6 ? Math.min(1, Math.max(0, (h - .5) / (h - g))) : .5;
		return [d + (p - d) * _, f + (m - f) * _];
	});
}
function g(e) {
	let t = e;
	for (let e = 0; e < 2; e++) t = t.map(([e, n], r) => {
		let [i, a] = t[(r + t.length - 1) % t.length], [o, s] = t[(r + 1) % t.length];
		return [(i + 2 * e + o) / 4, (a + 2 * n + s) / 4];
	});
	return t;
}
function _(e, t, n, r = .75, i) {
	let a = (r, i) => r >= 0 && i >= 0 && r < t && i < n ? e[i * t + r] : 0, o = /* @__PURE__ */ new Map(), s = (e, n) => n * (t + 1) + e, c = (e, t, n, r) => {
		let i = s(e, t), a = o.get(i);
		a ? a.push(s(n, r)) : o.set(i, [s(n, r)]);
	};
	for (let e = 0; e <= n; e++) for (let r = 0; r <= t; r++) {
		if (r < t) {
			let t = a(r, e - 1), n = a(r, e);
			t && !n ? c(r, e, r + 1, e) : n && !t && c(r + 1, e, r, e);
		}
		if (e < n) {
			let t = a(r - 1, e), n = a(r, e);
			n && !t ? c(r, e, r, e + 1) : t && !n && c(r, e + 1, r, e);
		}
	}
	let l = [];
	for (let [e] of o) for (; o.get(e)?.length;) {
		let a = [], s = e;
		for (let r = 0; r < 4 * (t + 1) * (n + 1); r++) {
			a.push([s % (t + 1), Math.floor(s / (t + 1))]);
			let n = o.get(s), r = n.pop();
			if (n.length || o.delete(s), s = r, s === e) break;
		}
		a.length >= 4 && l.push(v(i ? g(h(a, i, t, n)) : a, r));
	}
	return l.filter((e) => e.length >= 3);
}
function v(e, t) {
	if (e.length < 8 || t <= 0) return e;
	let n = 0, r = -1;
	for (let t = 1; t < e.length; t++) {
		let i = Math.hypot(e[t][0] - e[0][0], e[t][1] - e[0][1]);
		i > r && (r = i, n = t);
	}
	let i = (e) => {
		if (e.length < 3) return e;
		let [n, r] = [e[0], e[e.length - 1]], a = Math.hypot(r[0] - n[0], r[1] - n[1]) || 1e-9, o = 0, s = 0;
		for (let t = 1; t < e.length - 1; t++) {
			let i = e[t], c = Math.abs((r[0] - n[0]) * (n[1] - i[1]) - (n[0] - i[0]) * (r[1] - n[1])) / a;
			c > o && (o = c, s = t);
		}
		return o <= t ? [n, r] : [...i(e.slice(0, s + 1)).slice(0, -1), ...i(e.slice(s))];
	}, a = i(e.slice(0, n + 1)), o = i([...e.slice(n), e[0]]);
	return [...a.slice(0, -1), ...o.slice(0, -1)];
}
var y = (e) => e.reduce((t, n, r) => t + (n[0] * e[(r + 1) % e.length][1] - e[(r + 1) % e.length][0] * n[1]), 0) / 2, b = (e, t, n = Math.PI / 2) => Array.from({ length: e }, (r, i) => {
	let a = n + i / e * Math.PI * 2;
	return [Math.cos(a) * t(i), Math.sin(a) * t(i)];
}), x = {
	star: {
		label: "Star",
		contours: [b(10, (e) => e % 2 ? .2 : .5)]
	},
	heart: {
		label: "Heart",
		contours: [Array.from({ length: 72 }, (e, t) => {
			let n = t / 72 * Math.PI * 2;
			return [16 * Math.sin(n) ** 3, 13 * Math.cos(n) - 5 * Math.cos(2 * n) - 2 * Math.cos(3 * n) - Math.cos(4 * n)];
		})]
	},
	hexagon: {
		label: "Hexagon",
		contours: [b(6, () => .5, 0)]
	},
	arrow: {
		label: "Arrow",
		contours: [[
			[-.5, -.12],
			[.1, -.12],
			[.1, -.3],
			[.5, 0],
			[.1, .3],
			[.1, .12],
			[-.5, .12]
		]]
	},
	cross: {
		label: "Plus",
		contours: [[
			[-.15, -.5],
			[.15, -.5],
			[.15, -.15],
			[.5, -.15],
			[.5, .15],
			[.15, .15],
			[.15, .5],
			[-.15, .5],
			[-.15, .15],
			[-.5, .15],
			[-.5, -.15],
			[-.15, -.15]
		]]
	},
	donut: {
		label: "Washer",
		contours: [b(48, () => .5), b(48, () => .22)]
	},
	bolt: {
		label: "Bolt",
		contours: [[
			[.1, .5],
			[-.3, -.05],
			[-.02, -.05],
			[-.15, -.5],
			[.3, .08],
			[.02, .08]
		]]
	}
}, S = Math.PI / 180;
function C([e, t, n]) {
	let [r, i, a, o, s, c] = [
		Math.cos(e * S),
		Math.sin(e * S),
		Math.cos(t * S),
		Math.sin(t * S),
		Math.cos(n * S),
		Math.sin(n * S)
	];
	return [
		a * s,
		-a * c,
		o,
		r * c + i * o * s,
		r * s - i * o * c,
		-i * a,
		i * c - r * o * s,
		i * s + r * o * c,
		r * a
	];
}
function w(e, t) {
	let n = C(e.rotation), r = [
		t[0] - e.position[0],
		t[1] - e.position[1],
		t[2] - e.position[2]
	];
	return [
		n[0] * r[0] + n[3] * r[1] + n[6] * r[2],
		n[1] * r[0] + n[4] * r[1] + n[7] * r[2],
		n[2] * r[0] + n[5] * r[1] + n[8] * r[2]
	];
}
var T = (e, t) => Math.hypot(e, t), E = (e, t, n) => Math.hypot(e, t, n), D = (e, t, n) => Math.min(n, Math.max(t, e));
function O(e, t) {
	let [n, r, i] = [
		e.size[0] / 2,
		e.size[1] / 2,
		e.size[2] / 2
	], a = e.round * Math.min(e.size[0], e.size[1], e.size[2]), [o, s, c] = t;
	switch (e.kind) {
		case "box": {
			let e = Math.abs(o) - n + a, t = Math.abs(s) - r + a, l = Math.abs(c) - i + a;
			return E(Math.max(e, 0), Math.max(t, 0), Math.max(l, 0)) + Math.min(Math.max(e, t, l), 0) - a;
		}
		case "sphere": {
			let e = E(o / n, s / r, c / i), t = E(o / (n * n), s / (r * r), c / (i * i));
			return t > 0 ? e * (e - 1) / t : -Math.min(n, r, i);
		}
		case "cylinder": {
			let e = Math.min(n, i), t = Math.min(a, e, r), l = T(o * e / n, c * e / i) - e + t, u = Math.abs(s) - r + t;
			return Math.min(Math.max(l, u), 0) + T(Math.max(l, 0), Math.max(u, 0)) - t;
		}
		case "cone": {
			let e = Math.min(n, i), t = T(o * e / n, c * e / i), l = s, u = r, d = -e, f = 2 * u, p = t - Math.min(t, l < 0 ? e : 0), m = Math.abs(l) - u, h = D((-t * d + (u - l) * f) / (d * d + f * f), 0, 1), g = t + d * h, _ = l - u + f * h;
			return (g < 0 && m < 0 ? -1 : 1) * Math.sqrt(Math.min(p * p + m * m, g * g + _ * _)) - a * .5;
		}
		case "torus": {
			let t = Math.min(e.thickness * n, r), a = Math.max(n - t, .001);
			return T(T(o, c * n / i) - a, s) - t;
		}
		case "capsule": {
			let e = Math.min(n, i), t = Math.max(r - e, 0), a = s - D(s, -t, t);
			return E(o * e / n, a, c * e / i) - e;
		}
		case "pyramid": {
			let e = Math.min(n, i), t = 2 * r / (2 * e), l = Math.abs(o * e / n) / (2 * e), u = Math.abs(c * e / i) / (2 * e), d = (s + r) / (2 * e);
			u > l && ([l, u] = [u, l]), l -= .5, u -= .5;
			let f = t * t + .25, p = u, m = t * d - .5 * l, h = t * l + .5 * d, g = Math.max(-p, 0), _ = D((m - .5 * u) / (f + .25), 0, 1), v = f * (p + g) * (p + g) + m * m, y = f * (p + .5 * _) * (p + .5 * _) + (m - f * _) * (m - f * _), b = Math.min(m, -p * f - m * .5) > 0 ? 0 : Math.min(v, y);
			return 2 * e * Math.sqrt((b + h * h) / f) * Math.sign(Math.max(h, -d)) - a * .5;
		}
		case "extrude":
		case "text": {
			if (!e.outline) return 1e9;
			let t = m(f(e.outline, e.size[0], e.size[1]), o, s), n = Math.min(a, i * .95), r = t + n, l = Math.abs(c) - i + n;
			return Math.min(Math.max(r, l), 0) + T(Math.max(r, 0), Math.max(l, 0)) - n;
		}
		case "group":
		case "mesh": return 1e9;
	}
}
var k = (e) => e.blend * .6;
function A(e, t, n, r) {
	if (n === "add") {
		if (r > 1e-4) {
			let n = D(.5 + .5 * (e - t) / r, 0, 1);
			return {
				d: e * (1 - n) + t * n - r * n * (1 - n),
				h: n
			};
		}
		return t < e ? {
			d: t,
			h: 1
		} : {
			d: e,
			h: 0
		};
	}
	if (n === "subtract") {
		let n = -t;
		if (r > 1e-4) {
			let t = D(.5 - .5 * (n - e) / r, 0, 1);
			return {
				d: e * (1 - t) + n * t + r * t * (1 - t),
				h: t
			};
		}
		return n > e ? {
			d: n,
			h: 1
		} : {
			d: e,
			h: 0
		};
	}
	if (r > 1e-4) {
		let n = D(.5 - .5 * (t - e) / r, 0, 1);
		return {
			d: e * (1 - n) + t * n + r * n * (1 - n),
			h: n
		};
	}
	return t > e ? {
		d: t,
		h: 1
	} : {
		d: e,
		h: 0
	};
}
var j = {
	matte: [8, 0],
	satin: [32, 0],
	glossy: [140, 0],
	metal: [64, 1]
}, ee = (e) => {
	let t = parseInt(e.slice(1), 16);
	return [
		(t >> 16 & 255) / 255,
		(t >> 8 & 255) / 255,
		(t & 255) / 255
	];
}, M = (e, t, n) => [
	e[0] + (t[0] - e[0]) * n,
	e[1] + (t[1] - e[1]) * n,
	e[2] + (t[2] - e[2]) * n
];
function N(e, t, n = Qe(e)) {
	let r = {
		d: 1e9,
		color: [
			.8,
			.8,
			.8
		],
		shine: 32,
		metal: 0,
		owner: null
	}, i = r;
	for (let e of n) {
		if (e.op === "begin") {
			i = r, r = {
				d: 1e9,
				color: [
					.8,
					.8,
					.8
				],
				shine: 32,
				metal: 0,
				owner: null
			};
			continue;
		}
		let n = e.op === "end" ? e.group : e.shape, a = e.op === "end" ? r.d : O(n, w(n, t)), o = e.op === "end" ? r.color : ee(n.color), [s, c] = e.op === "end" ? [r.shine, r.metal] : j[n.finish], l = e.op === "end" ? r.owner : e.path, u = e.op === "end" ? i : r, { d, h: f } = A(u.d, a, n.combine, k(n));
		r = {
			d,
			color: M(u.color, o, f),
			shine: u.shine + (s - u.shine) * f,
			metal: u.metal + (c - u.metal) * f,
			owner: f > .5 ? l : u.owner
		};
	}
	return r;
}
function te(e, t, n, r = 200) {
	let i = Qe(e), a = 0;
	for (let o = 0; o < 256 && a < r; o++) {
		let r = N(e, [
			t[0] + n[0] * a,
			t[1] + n[1] * a,
			t[2] + n[2] * a
		], i);
		if (r.d < .001 * Math.max(1, a)) return {
			t: a,
			shape: r.owner
		};
		a += Math.max(r.d * .9, 1e-4);
	}
	return null;
}
//#endregion
//#region ../scene3d/src/model/arrange.ts
function P(e) {
	if (e.kind === "group") return F((e.children ?? []).filter((e) => !e.hidden));
	let t = C(e.rotation), n = [
		0,
		1,
		2
	].map((n) => [
		0,
		1,
		2
	].reduce((r, i) => r + Math.abs(t[n * 3 + i]) * e.size[i] / 2, 0));
	return {
		min: e.position.map((e, t) => e - n[t]),
		max: e.position.map((e, t) => e + n[t])
	};
}
function F(e) {
	let t = null;
	for (let n of e) {
		let e = P(n);
		e && (t = t ? {
			min: t.min.map((t, n) => Math.min(t, e.min[n])),
			max: t.max.map((t, n) => Math.max(t, e.max[n]))
		} : e);
	}
	return t;
}
var I = (e) => Math.round(e * 1e3) / 1e3, L = (e, t) => [
	I(e[0] + t[0]),
	I(e[1] + t[1]),
	I(e[2] + t[2])
];
function ne(e, t) {
	return e.kind === "group" ? { children: (e.children ?? []).map((e) => ({
		...e,
		position: L(e.position, t)
	})) } : { position: L(e.position, t) };
}
var R = () => [
	0,
	0,
	0
];
function z(e, t, n) {
	let r = e.map(P), i = F(e);
	if (!i) return e.map(R);
	let a = (e) => n === "min" ? e.min[t] : n === "max" ? e.max[t] : (e.min[t] + e.max[t]) / 2, o = e.length === 1 ? 0 : a(i);
	return r.map((r) => {
		let i = R();
		return r && (i[t] = o - (e.length === 1 && n === "mid" ? (r.min[t] + r.max[t]) / 2 : a(r))), i;
	});
}
function re(e, t) {
	let n = e.map(R), r = e.map(P), i = e.map((e, t) => t).filter((e) => r[e]).sort((e, n) => r[e].min[t] - r[n].min[t]);
	if (i.length < 3) return n;
	let a = r[i[0]], o = r[i[i.length - 1]], s = i.map((e) => r[e].max[t] - r[e].min[t]), c = (o.max[t] - a.min[t] - s.reduce((e, t) => e + t, 0)) / (i.length - 1), l = a.min[t];
	return i.forEach((e, i) => {
		n[e][t] = l - r[e].min[t], l += s[i] + c;
	}), n;
}
var ie = (e) => e.map((e) => {
	let t = P(e);
	return [
		0,
		t && 0 - t.min[1] || 0,
		0
	];
});
function ae(e, t) {
	let n = (e) => ({
		...e,
		id: Le(),
		position: L(e.position, t),
		children: e.children?.map(n)
	});
	return e.map((e) => {
		let t = n(e);
		return t.children || delete t.children, t;
	});
}
function B(e, t) {
	let n = {}, r = (t) => {
		t.asset && e.assets?.[t.asset] && (n[t.asset] = e.assets[t.asset]), t.children?.forEach(r);
	};
	return t.forEach(r), n;
}
//#endregion
//#region ../scene3d/src/model/motion.ts
var V = {
	spin: "Spin",
	float: "Float",
	bounce: "Bounce",
	sway: "Sway",
	pulse: "Pulse",
	wiggle: "Wiggle",
	orbit: "Go round",
	pop: "Pop in"
}, H = Object.keys(V), oe = {
	kind: "spin",
	times: 1,
	amount: .5,
	delay: 0,
	axis: "y",
	reverse: !1
}, se = (e, t, n, r) => typeof e == "number" && Number.isFinite(e) ? Math.min(n, Math.max(t, e)) : r;
function U(e) {
	if (!e || typeof e != "object") return;
	let t = e;
	if (H.includes(t.kind)) return {
		kind: t.kind,
		times: Math.round(se(t.times, 1, 8, 1)),
		amount: se(t.amount, 0, 1, oe.amount),
		delay: se(t.delay, 0, 1, 0),
		axis: t.axis === "x" || t.axis === "z" ? t.axis : "y",
		reverse: t.reverse === !0
	};
}
var ce = (e, t) => [
	0,
	1,
	2
].flatMap((n) => [
	0,
	1,
	2
].map((r) => e[n * 3] * t[r] + e[n * 3 + 1] * t[3 + r] + e[n * 3 + 2] * t[6 + r])), le = (e, t) => [
	0,
	1,
	2
].map((n) => e[n * 3] * t[0] + e[n * 3 + 1] * t[1] + e[n * 3 + 2] * t[2]), ue = [
	1,
	0,
	0,
	0,
	1,
	0,
	0,
	0,
	1
], de = (e, t) => C(e === "x" ? [
	t,
	0,
	0
] : e === "y" ? [
	0,
	t,
	0
] : [
	0,
	0,
	t
]);
function fe(e) {
	let t = Math.min(1, Math.max(-1, e[2])), n = Math.asin(t), r, i;
	Math.abs(t) < .9999999 ? (r = Math.atan2(-e[5], e[8]), i = Math.atan2(-e[1], e[0])) : (r = Math.atan2(e[7], e[4]), i = 0);
	let a = (e) => Math.round(e * 180 / Math.PI * 1e3) / 1e3;
	return [
		a(r),
		a(n),
		a(i)
	];
}
var pe = Math.PI * 2, me = (e) => e - Math.floor(e), he = (e) => 1 + 2.70158 * (e - 1) ** 3 + 1.70158 * (e - 1) ** 2;
function ge(e, t, n, r) {
	let i = P(e) ?? {
		min: e.position,
		max: e.position
	}, a = i.min.map((e, t) => (e + i.max[t]) / 2), o = Math.max(.05, i.max[1] - i.min[1]), s = Math.abs(i.min[1]) < .02 ? [
		a[0],
		i.min[1],
		a[2]
	] : a, c = t.times * n + t.delay, l = Math.sin(pe * c), u = {
		pivot: a,
		turn: ue,
		grow: [
			1,
			1,
			1
		],
		move: [
			0,
			0,
			0
		]
	}, d = t.reverse ? -1 : 1;
	switch (t.kind) {
		case "spin":
			u.turn = de(t.axis, d * 360 * me(c));
			break;
		case "float":
			u.move = [
				0,
				t.amount * o * .5 * l,
				0
			];
			break;
		case "bounce": {
			let e = Math.abs(Math.sin(Math.PI * c)), n = Math.max(0, 1 - e * 5) * .18 * t.amount;
			u.pivot = s, u.grow = [
				1 + n * .5,
				1 - n,
				1 + n * .5
			], u.move = [
				0,
				t.amount * o * e,
				0
			];
			break;
		}
		case "sway":
			u.pivot = s, u.turn = de(t.axis === "y" ? "z" : t.axis, t.amount * 30 * l);
			break;
		case "pulse": {
			let e = 1 + t.amount * .25 * l;
			u.pivot = s, u.grow = [
				e,
				e,
				e
			];
			break;
		}
		case "wiggle": {
			let e = me(c), n = e < .4 ? Math.sin(pe * 3 * e / .4) * Math.sin(Math.PI * e / .4) : 0;
			u.pivot = s, u.turn = de("z", t.amount * 12 * n);
			break;
		}
		case "orbit":
			u.pivot = [
				r[0],
				a[1],
				r[2]
			], u.turn = de("y", d * 360 * me(c));
			break;
		case "pop": {
			let e = me(c), t = e < .3 ? Math.max(.001, he(e / .3)) : 1;
			u.pivot = s, u.grow = [
				t,
				t,
				t
			];
			break;
		}
	}
	return u;
}
var _e = (e, t) => t ? Math.round(e * 50) / 50 : e;
function ve(e, t) {
	let n = e.position.map((e, n) => (e - t.pivot[n]) * t.grow[n]), r = le(t.turn, n), i = !!e.outline;
	return {
		...e,
		position: r.map((e, n) => e + t.pivot[n] + t.move[n]),
		rotation: t.turn === ue ? e.rotation : fe(ce(t.turn, C(e.rotation))),
		size: e.size.map((e, n) => Math.max(.001, e * _e(t.grow[n], i)))
	};
}
var ye = (e) => e.shapes.some((e) => e.motion || e.children?.some((e) => e.motion));
function be(e, t) {
	if (!ye(e)) return e;
	let n = e.camera.target, r = (e) => e.motion ? ve(e, ge(e, e.motion, t, n)) : e;
	return {
		...e,
		shapes: e.shapes.map((e) => {
			if (e.kind !== "group") return r(e);
			let i = (e.children ?? []).map(r);
			if (!e.motion) return {
				...e,
				children: i
			};
			let a = ge({
				...e,
				children: i
			}, e.motion, t, n);
			return {
				...e,
				children: i.map((e) => ve(e, a))
			};
		})
	};
}
//#endregion
//#region ../scene3d/src/model/pen.ts
function xe(e, t, n) {
	let [r, i, a, o] = [
		e.p,
		e.out ?? e.p,
		t.in ?? t.p,
		t.p
	];
	if (!e.out && !t.in) return [o];
	let s = [];
	for (let e = 1; e <= n; e++) {
		let t = e / n, c = 1 - t;
		s.push([c * c * c * r[0] + 3 * c * c * t * i[0] + 3 * c * t * t * a[0] + t * t * t * o[0], c * c * c * r[1] + 3 * c * c * t * i[1] + 3 * c * t * t * a[1] + t * t * t * o[1]]);
	}
	return s;
}
function Se(e, t = 24) {
	let n = [];
	for (let r of e) {
		let e = r.nodes;
		if (e.length < 2) continue;
		let i = [e[0].p];
		for (let n = 1; n < e.length; n++) i.push(...xe(e[n - 1], e[n], t));
		let a = xe(e[e.length - 1], e[0], t);
		i.push(...a.slice(0, -1)), i.length >= 3 && n.push(i);
	}
	return n;
}
function Ce(e) {
	if (!Array.isArray(e)) return;
	let t = (e) => Array.isArray(e) && Number.isFinite(e[0]) && Number.isFinite(e[1]) ? [Math.min(1, Math.max(-1, e[0])), Math.min(1, Math.max(-1, e[1]))] : void 0, n = e.slice(0, 16).filter((e) => !!e && typeof e == "object").map((e) => ({
		closed: e.closed !== !1,
		nodes: (Array.isArray(e.nodes) ? e.nodes : []).slice(0, 400).map((e) => {
			let n = e && typeof e == "object" ? e : {}, r = t(n.p);
			if (!r) return null;
			let i = { p: r }, [a, o] = [t(n.in), t(n.out)];
			return a && (i.in = a), o && (i.out = o), i;
		}).filter((e) => !!e)
	})).filter((e) => e.nodes.length >= 2);
	return n.length ? n : void 0;
}
var we = (e) => e.map((e) => ({
	closed: !0,
	nodes: e.map((e) => ({ p: [e[0], e[1]] }))
})), Te = [
	"box",
	"sphere",
	"cylinder",
	"cone",
	"torus",
	"capsule",
	"pyramid"
], Ee = [
	...Te,
	"extrude",
	"text",
	"mesh",
	"group"
], De = [
	"add",
	"subtract",
	"intersect"
], Oe = [
	"matte",
	"satin",
	"glossy",
	"metal"
], ke = [
	"soft",
	"toon",
	"flat",
	"clay",
	"pixel"
], Ae = [
	"left",
	"center",
	"right"
], je = 64e6, Me = 128e6, Ne = {
	box: "Box",
	sphere: "Sphere",
	cylinder: "Cylinder",
	cone: "Cone",
	torus: "Ring",
	capsule: "Capsule",
	pyramid: "Pyramid",
	extrude: "Outline",
	text: "Text",
	mesh: "Model",
	group: "Group"
}, Pe = {
	box: [
		1,
		1,
		1
	],
	sphere: [
		1,
		1,
		1
	],
	cylinder: [
		.8,
		1.2,
		.8
	],
	cone: [
		1,
		1.2,
		1
	],
	torus: [
		1.2,
		.36,
		1.2
	],
	capsule: [
		.6,
		1.4,
		.6
	],
	pyramid: [
		1,
		1,
		1
	],
	extrude: [
		1,
		1,
		.35
	],
	text: [
		2,
		.6,
		.3
	],
	mesh: [
		1,
		1,
		1
	],
	group: [
		1,
		1,
		1
	]
}, Fe = [
	"#ff7ab6",
	"#a78bfa",
	"#67e8f9",
	"#fbbf24",
	"#34d399",
	"#f87171",
	"#60a5fa"
], Ie = 0, Le = () => `s${Date.now().toString(36)}${(Ie++).toString(36)}`;
function W(e, t = 0, n = {}) {
	let r = Pe[e];
	return {
		id: Le(),
		name: Ne[e],
		kind: e,
		position: [
			0,
			r[1] / 2,
			0
		],
		rotation: [
			0,
			0,
			0
		],
		size: [...r],
		round: e === "box" || e === "pyramid" ? .08 : e === "extrude" || e === "text" ? .05 : 0,
		thickness: .3,
		combine: "add",
		blend: 0,
		color: Fe[t % Fe.length],
		finish: "satin",
		hidden: !1,
		...n
	};
}
function Re() {
	return {
		version: 1,
		shapes: [W("box", 0, { position: [
			0,
			.5,
			0
		] })],
		light: {
			azimuth: -40,
			elevation: 50,
			intensity: 1.4,
			ambient: .35,
			color: "#ffffff",
			shadows: !0
		},
		style: {
			look: "soft",
			outline: 0,
			outlineColor: "#1b1530",
			bands: 3,
			pixel: 10
		},
		background: {
			transparent: !0,
			color: "#f4f1fb",
			picture: ""
		},
		ground: {
			on: !0,
			shadow: .35
		},
		camera: {
			yaw: 30,
			pitch: 22,
			distance: 5.5,
			target: [
				0,
				.5,
				0
			],
			fov: 35,
			projection: "perspective"
		}
	};
}
var G = (e, t, n, r) => Math.min(n, Math.max(t, typeof e == "number" && Number.isFinite(e) ? e : r)), ze = (e, t) => typeof e == "string" && /^#[0-9a-f]{6}$/i.test(e) ? e.toLowerCase() : t, Be = (e, t, n, r) => Array.isArray(e) && e.length === 3 ? [
	G(e[0], t, n, r[0]),
	G(e[1], t, n, r[1]),
	G(e[2], t, n, r[2])
] : r, Ve = (e, t, n) => t.includes(e) ? e : n;
function He(e) {
	if (!Array.isArray(e)) return;
	let t = e.slice(0, 64).filter(Array.isArray).map((e) => e.slice(0, 2e3).filter((e) => Array.isArray(e) && Number.isFinite(e[0]) && Number.isFinite(e[1])).map(([e, t]) => [Math.min(.5, Math.max(-.5, e)), Math.min(.5, Math.max(-.5, t))])).filter((e) => e.length >= 3);
	return t.length ? t : void 0;
}
function Ue(e) {
	let t = s(e);
	return {
		outline: t.contours,
		aspect: t.aspect
	};
}
function We(e) {
	let t = 0, n = 0, r = 0, i = (e) => {
		e.kind === "mesh" ? r += 1 : (t += 1, n += +!!e.outline);
	};
	for (let n of e) n.kind === "group" ? (t += 2, (n.children ?? []).forEach(i)) : i(n);
	return {
		slots: t,
		fields: n,
		meshes: r
	};
}
var Ge = (e) => {
	let t = We(e);
	return t.slots <= 48 && t.fields <= 16 && t.meshes <= 16;
};
function K(e, t = 0, n = !1) {
	let r = e && typeof e == "object" ? e : {}, i = n ? Ee.filter((e) => e !== "group") : Ee, a = Ve(r.kind, i, "box"), o = He(r.outline);
	(a === "extrude" || a === "text") && !o && (a = "box");
	let s = typeof r.asset == "string" && /^[\w-]{1,40}$/.test(r.asset) ? r.asset : void 0;
	a === "mesh" && !s && (a = "box");
	let c = W(a, t), l = r.text ?? {}, u = {};
	if ((a === "extrude" || a === "text") && (u.outline = o), a === "text" && (u.text = {
		value: typeof l.value == "string" ? l.value.slice(0, 200).split("\n").slice(0, 8).join("\n") : "Text",
		font: typeof l.font == "string" && l.font.trim() ? l.font.slice(0, 80) : "Arial",
		weight: Math.round(G(l.weight, 100, 900, 700) / 100) * 100
	}, l.align !== void 0 && (u.text.align = Ve(l.align, Ae, "center")), l.lineHeight !== void 0 && (u.text.lineHeight = G(l.lineHeight, .6, 3, 1.15)), l.spacing !== void 0 && (u.text.spacing = G(l.spacing, -.3, 1, 0))), a === "extrude") {
		let e = Ce(r.pen);
		e && (u.pen = e);
	}
	return a === "group" && (u.children = Array.isArray(r.children) ? r.children.slice(0, 48).map((e, n) => K(e, t + n, !0)) : []), a === "mesh" && (u.asset = s, u.ownColors = r.ownColors !== !1), {
		id: typeof r.id == "string" && r.id ? r.id.slice(0, 40) : c.id,
		name: typeof r.name == "string" && r.name.trim() ? r.name.slice(0, 60) : c.name,
		kind: a,
		position: Be(r.position, -100, 100, c.position),
		rotation: Be(r.rotation, -360, 360, c.rotation),
		size: Be(r.size, .01, 100, c.size),
		round: G(r.round, 0, .5, c.round),
		thickness: G(r.thickness, .05, .5, c.thickness),
		combine: Ve(r.combine, De, "add"),
		blend: G(r.blend, 0, 1, 0),
		color: ze(r.color, c.color),
		finish: Ve(r.finish, Oe, "satin"),
		hidden: r.hidden === !0,
		...r.locked === !0 ? { locked: !0 } : {},
		...U(r.motion) ? { motion: U(r.motion) } : {},
		...u
	};
}
function Ke(e) {
	let t = [...e];
	for (; t.length && !Ge(t);) t.pop();
	return t;
}
function qe(e) {
	let t = {};
	if (!e || typeof e != "object") return t;
	let n = 0;
	for (let [r, i] of Object.entries(e)) {
		let e = i ?? {};
		!/^[\w-]{1,40}$/.test(r) || typeof e.data != "string" || !e.data || e.data.length > 64e6 || n + e.data.length > 128e6 || !/^[A-Za-z0-9+/]+={0,2}$/.test(e.data) || (n += e.data.length, t[r] = {
			name: typeof e.name == "string" && e.name.trim() ? e.name.slice(0, 80) : "Model",
			data: e.data,
			triangles: Math.max(0, Math.round(G(e.triangles, 0, 1e8, 0))),
			size: Be(e.size, 0, 1e6, [
				1,
				1,
				1
			]),
			centre: Be(e.centre, -1e6, 1e6, [
				0,
				0,
				0
			])
		});
	}
	return t;
}
function Je(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e) for (let e of n.kind === "group" ? n.children ?? [] : [n]) e.kind === "mesh" && e.asset && t.add(e.asset);
	return t;
}
function Ye(e) {
	if (!e.assets) return e;
	let t = Je(e.shapes), n = Object.fromEntries(Object.entries(e.assets).filter(([e]) => t.has(e))), { assets: r, ...i } = e;
	return Object.keys(n).length ? {
		...i,
		assets: n
	} : i;
}
function Xe(e) {
	let t = [];
	return e.shapes.forEach((n, r) => {
		if (n.hidden) return;
		let i = n.kind === "group" ? (n.children ?? []).map((e, t) => [e, [r, t]]) : [[n, [r]]];
		for (let [n, r] of i) {
			let i = n.kind === "mesh" && !n.hidden && n.asset ? e.assets?.[n.asset] : void 0;
			i && t.push({
				shape: n,
				path: r,
				asset: i
			});
		}
	}), t;
}
function Ze(e, t) {
	if (!t) return;
	let n = e.shapes[t[0]];
	return t.length === 1 ? n : n?.children?.[t[1]];
}
function Qe(e) {
	let t = [];
	return e.shapes.forEach((e, n) => {
		if (e.hidden || e.kind === "mesh") return;
		if (e.kind !== "group") return void t.push({
			op: "shape",
			shape: e,
			path: [n]
		});
		let r = (e.children ?? []).map((e, t) => ({
			c: e,
			j: t
		})).filter(({ c: e }) => !e.hidden && e.kind !== "mesh");
		if (r.length) {
			t.push({
				op: "begin",
				group: e,
				path: [n]
			});
			for (let { c: e, j: i } of r) t.push({
				op: "shape",
				shape: e,
				path: [n, i]
			});
			t.push({
				op: "end",
				group: e,
				path: [n]
			});
		}
	}), t;
}
var $e = 12e6, et = (e) => typeof e == "string" && e.length <= 12e6 && /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+=*$/.test(e) ? e : "";
function tt(e) {
	let t = Re(), n = e && typeof e == "object" ? e : {}, r = n.light ?? {}, i = n.style ?? {}, a = n.background ?? {}, o = n.ground ?? {}, s = n.camera ?? {}, c = qe(n.assets), l = (e) => e.kind !== "mesh" || e.asset !== void 0 && e.asset in c, u = Array.isArray(n.shapes) ? Ke(n.shapes.slice(0, 48).map((e, t) => K(e, t)).filter(l).map((e) => e.kind === "group" ? {
		...e,
		children: (e.children ?? []).filter(l)
	} : e)) : t.shapes, d = Je(u), f = Object.fromEntries(Object.entries(c).filter(([e]) => d.has(e)));
	return {
		version: 1,
		shapes: u,
		...Object.keys(f).length ? { assets: f } : {},
		light: {
			azimuth: G(r.azimuth, -180, 180, t.light.azimuth),
			elevation: G(r.elevation, 0, 90, t.light.elevation),
			intensity: G(r.intensity, 0, 3, t.light.intensity),
			ambient: G(r.ambient, 0, 1, t.light.ambient),
			color: ze(r.color, t.light.color),
			shadows: r.shadows !== !1
		},
		style: {
			look: Ve(i.look, ke, t.style.look),
			outline: G(i.outline, 0, 12, t.style.outline),
			outlineColor: ze(i.outlineColor, t.style.outlineColor),
			bands: Math.round(G(i.bands, 2, 6, t.style.bands)),
			pixel: Math.round(G(i.pixel, 3, 40, t.style.pixel))
		},
		background: {
			transparent: a.transparent !== !1,
			color: ze(a.color, t.background.color),
			picture: et(a.picture)
		},
		ground: {
			on: o.on !== !1,
			shadow: G(o.shadow, 0, 1, t.ground.shadow)
		},
		camera: {
			yaw: G(s.yaw, -360, 360, t.camera.yaw),
			pitch: G(s.pitch, -89, 89, t.camera.pitch),
			distance: G(s.distance, .5, 200, t.camera.distance),
			target: Be(s.target, -100, 100, t.camera.target),
			fov: G(s.fov, 10, 90, t.camera.fov),
			projection: Ve(s.projection, ["perspective", "orthographic"], "perspective")
		}
	};
}
var nt = {
	front: {
		yaw: 0,
		pitch: 0,
		projection: "orthographic"
	},
	side: {
		yaw: 90,
		pitch: 0,
		projection: "orthographic"
	},
	left: {
		yaw: -90,
		pitch: 0,
		projection: "orthographic"
	},
	back: {
		yaw: 180,
		pitch: 0,
		projection: "orthographic"
	},
	top: {
		yaw: 0,
		pitch: 89,
		projection: "orthographic"
	},
	bottom: {
		yaw: 0,
		pitch: -89,
		projection: "orthographic"
	},
	isometric: {
		yaw: 45,
		pitch: 35.264,
		projection: "orthographic"
	},
	"isometric-left": {
		yaw: -45,
		pitch: 35.264,
		projection: "orthographic"
	},
	"isometric-below": {
		yaw: 45,
		pitch: -35.264,
		projection: "orthographic"
	},
	"isometric-below-left": {
		yaw: -45,
		pitch: -35.264,
		projection: "orthographic"
	},
	perspective: {
		yaw: 30,
		pitch: 22,
		projection: "perspective"
	}
}, rt = [
	"light",
	"style",
	"background",
	"ground",
	"camera"
], it = Object.keys(W("box")).concat([
	"locked",
	"motion",
	"outline",
	"text",
	"pen",
	"children",
	"asset",
	"ownColors"
]);
function at(e, t, n) {
	return e === "outline" ? K({
		kind: "extrude",
		outline: t
	}, 0, n).outline : e === "pen" ? K({
		kind: "extrude",
		outline: [[
			[0, 0],
			[1, 0],
			[0, 1]
		]],
		pen: t
	}, 0, n).pen : e === "text" ? K({
		kind: "text",
		outline: [[
			[0, 0],
			[1, 0],
			[0, 1]
		]],
		text: t
	}, 0, n).text : e === "children" ? K({
		kind: "group",
		children: t
	}, 0).children : e === "asset" ? K({
		kind: "mesh",
		asset: t
	}, 0, n).asset : e === "ownColors" ? K({
		kind: "mesh",
		asset: "a",
		ownColors: t
	}, 0, n).ownColors : K({
		...W("box"),
		kind: e === "kind" ? t : void 0,
		[e]: t
	}, 0, n)[e];
}
var ot = (e, n) => {
	let r = t(e), [i, a] = r;
	if (i === "shapes") {
		if (r.length === 1) {
			if (!Array.isArray(n)) return "invalid-value";
			let e = n.map((e, t) => K(e, t));
			return Ge(e) ? {
				value: e,
				label: "Shapes"
			} : "invalid-value";
		}
		let e = Number(a);
		if (!Number.isInteger(e) || e < 0 || e >= 48) return "invalid-path";
		if (r.length === 2) return {
			value: K(n, e),
			label: "Shape"
		};
		if (r[2] === "children" && r.length >= 4) {
			let e = Number(r[3]);
			if (!Number.isInteger(e) || e < 0 || e >= 48) return "invalid-path";
			if (r.length === 4) return {
				value: K(n, e, !0),
				label: "Shape"
			};
			let t = r[4];
			return r.length !== 5 || !it.includes(t) || t === "id" || t === "children" ? "invalid-path" : {
				value: at(t, n, !0),
				label: t
			};
		}
		let t = r[2];
		return r.length !== 3 || !it.includes(t) || t === "id" ? "invalid-path" : {
			value: at(t, n, !1),
			label: t
		};
	}
	if (i === "assets" && r.length === 1) return {
		value: qe(n),
		label: "Models"
	};
	if (rt.includes(i ?? "") && r.length === 2 && a) {
		let e = i, t = tt({});
		return a in t[e] ? {
			value: tt({ [e]: {
				...t[e],
				[a]: n
			} })[e][a],
			label: `${e} ${a}`
		} : "invalid-path";
	}
	return "invalid-path";
}, st = (e) => e.length === 1 ? `shapes/${e[0]}` : `shapes/${e[0]}/children/${e[1]}`, ct = class extends n {
	constructor(e) {
		super(tt(e), ot);
	}
	get shapes() {
		return this.doc.shapes;
	}
	fits(e) {
		return Ge([...this.doc.shapes, e]);
	}
	addShape(e, t = {}) {
		let n = K(W(e, this.doc.shapes.length, t), this.doc.shapes.length);
		if (n.kind !== e || !this.fits(n)) return -1;
		if (!t.position) {
			let [e, , t] = this.doc.camera.target, r = this.doc.shapes.length;
			n.position = [
				e + (r ? (r % 2 ? 1 : -1) * .7 * Math.ceil(r / 2) : 0),
				n.size[1] / 2,
				t
			];
		}
		return this.apply(`Add ${n.name.toLowerCase()}`, [["shapes", [...this.doc.shapes, n]]]), this.doc.shapes.length - 1;
	}
	addModel(e, t = {}, n = 1.5) {
		let r = Le(), i = Math.max(...e.size, 1e-9), a = e.size.map((e) => Math.max(.01, e / i * n)), o = K(W("mesh", this.doc.shapes.length, {
			name: e.name.slice(0, 60),
			size: a,
			asset: r,
			ownColors: !0,
			...t
		}), this.doc.shapes.length);
		if (o.kind !== "mesh" || !this.fits(o)) return -1;
		if (!t.position) {
			let [e, , t] = this.doc.camera.target, n = this.doc.shapes.length;
			o.position = [
				e + (n ? (n % 2 ? 1 : -1) * .9 * Math.ceil(n / 2) : 0),
				o.size[1] / 2,
				t
			];
		}
		return this.apply(`Import ${o.name}`, [["assets", {
			...this.doc.assets ?? {},
			[r]: e
		}], ["shapes", [...this.doc.shapes, o]]]), this.doc.shapes.length - 1;
	}
	addShapes(e, t, n) {
		let r = e.map((e, t) => K(e, this.doc.shapes.length + t, !0));
		if (!r.length) return -1;
		let i = r.length > 1 && n ? [W("group", 0, {
			name: n.slice(0, 60),
			children: r,
			combine: "add",
			blend: 0
		})] : r, a = [...this.doc.shapes, ...i];
		return Ge(a) ? (this.apply(t, [["shapes", a]]), this.doc.shapes.length - i.length) : -1;
	}
	updateShapeAt(e, t, n = "Change shape") {
		Ze(this.doc, e) && this.apply(n, Object.entries(t).filter(([e]) => e !== "id").map(([t, n]) => [`${st(e)}/${t}`, n]));
	}
	updateShapesAt(e, t = "Change shapes") {
		let n = e.filter(([e]) => Ze(this.doc, e)).flatMap(([e, t]) => Object.entries(t).filter(([e]) => e !== "id").map(([t, n]) => [`${st(e)}/${t}`, n]));
		n.length && this.apply(t, n);
	}
	moveShapes(e, t, n = "Move") {
		this.updateShapesAt(e.flatMap((e, n) => {
			let r = this.doc.shapes[e], i = t[n];
			return r && i && i.some((e) => Math.abs(e) > 1e-9) ? [[[e], ne(r, i)]] : [];
		}), n);
	}
	align(e, t, n) {
		let r = e.map((e) => this.doc.shapes[e]).filter((e) => !!e);
		this.moveShapes(e, z(r, t, n), "Line up");
	}
	spread(e, t) {
		let n = e.map((e) => this.doc.shapes[e]).filter((e) => !!e);
		this.moveShapes(e, re(n, t), "Spread evenly");
	}
	toGround(e) {
		let t = e.map((e) => this.doc.shapes[e]).filter((e) => !!e);
		this.moveShapes(e, ie(t), "Put on the ground");
	}
	pasteShapes(e, t = {}, n = [
		.5,
		0,
		.5
	]) {
		let r = ae(e, n).map((e, t) => K(e, this.doc.shapes.length + t)), i = [...this.doc.shapes, ...r];
		if (!r.length || !Ge(i)) return null;
		let a = Object.fromEntries(Object.entries(t).filter(([e]) => !this.doc.assets?.[e]));
		return this.apply(`Paste ${r.length > 1 ? `${r.length} shapes` : r[0].name}`, [...Object.keys(a).length ? [["assets", {
			...this.doc.assets ?? {},
			...a
		}]] : [], ["shapes", i]]), r.map((e, t) => this.doc.shapes.length - r.length + t);
	}
	replaceDesign(e, t = "New design") {
		let n = tt(e), r = [["assets", n.assets ?? {}], ["shapes", n.shapes]];
		for (let e of rt) for (let [t, i] of Object.entries(n[e])) r.push([`${e}/${t}`, i]);
		this.apply(t, r);
	}
	updateShape(e, t, n = "Change shape") {
		this.updateShapeAt([e], t, n);
	}
	setChildren(e, t) {
		this.doc.shapes[e]?.kind === "group" && this.apply("Move group", [[`shapes/${e}/children`, t]]);
	}
	listOf(e) {
		if (e.length === 1) return this.doc.shapes[e[0]] ? {
			list: [...this.doc.shapes],
			at: e[0],
			write: (e, t) => this.apply(t, [["shapes", e]])
		} : null;
		let t = this.doc.shapes[e[0]];
		return t?.children?.[e[1]] ? {
			list: [...t.children],
			at: e[1],
			write: (t, n) => this.apply(n, [[`shapes/${e[0]}/children`, t]])
		} : null;
	}
	removeShapeAt(e) {
		let t = this.listOf(e);
		if (!t) return;
		let n = t.list[t.at].name;
		t.write(t.list.filter((e, n) => n !== t.at), `Delete ${n}`);
	}
	removeShapes(e) {
		let t = new Set(e);
		e.some((e) => this.doc.shapes[e]) && this.apply(`Delete ${t.size} shapes`, [["shapes", this.doc.shapes.filter((e, n) => !t.has(n))]]);
	}
	removeShape(e) {
		this.removeShapeAt([e]);
	}
	duplicateShapeAt(e) {
		let t = this.listOf(e);
		if (!t) return null;
		let n = t.list[t.at], r = (e) => ({
			...e,
			id: Le(),
			position: [
				e.position[0] + (n.kind === "group" ? 1 : n.size[0] * .6),
				e.position[1],
				e.position[2]
			],
			children: e.children?.map(r)
		}), i = {
			...r(n),
			name: `${n.name} copy`
		};
		return this.fits(i) ? (t.list.splice(t.at + 1, 0, i), t.write(t.list, `Duplicate ${n.name}`), e.length === 1 ? [t.at + 1] : [e[0], t.at + 1]) : null;
	}
	duplicateShape(e) {
		return this.duplicateShapeAt([e])?.[0] ?? -1;
	}
	moveShapeAt(e, t) {
		let n = this.listOf(e);
		if (!n) return e;
		let r = n.at + t;
		return r < 0 || r >= n.list.length ? e : ([n.list[n.at], n.list[r]] = [n.list[r], n.list[n.at]], n.write(n.list, "Reorder shapes"), e.length === 1 ? [r] : [e[0], r]);
	}
	moveShape(e, t) {
		return this.moveShapeAt([e], t)[0];
	}
	group(e) {
		let t = [...new Set(e)].filter((e) => this.doc.shapes[e] && this.doc.shapes[e].kind !== "group").sort((e, t) => e - t);
		if (!t.length) return -1;
		let n = W("group", 0, {
			name: "Group",
			children: t.map((e) => this.doc.shapes[e]),
			combine: "add",
			blend: 0
		}), r = this.doc.shapes.filter((e, n) => !t.includes(n)), i = t[0] - t.filter((e) => e < t[0]).length;
		return r.splice(i, 0, n), Ge(r) ? (this.apply("Group", [["shapes", r]]), i) : -1;
	}
	ungroup(e) {
		let t = this.doc.shapes[e];
		if (t?.kind !== "group") return -1;
		let n = [...this.doc.shapes];
		return n.splice(e, 1, ...t.children ?? []), this.apply("Ungroup", [["shapes", n]]), e;
	}
	setSetting(e, t, n, r) {
		this.apply(r ?? `${e} ${t}`, [[`${e}/${t}`, n]]);
	}
	setView(e) {
		let t = nt[e];
		this.apply(`${e[0].toUpperCase()}${e.slice(1).replace(/-/g, " ")} view`, [
			["camera/yaw", t.yaw],
			["camera/pitch", t.pitch],
			["camera/projection", t.projection]
		]);
	}
	snapOrbit(e, t) {
		let { yaw: n, pitch: r } = this.doc.camera, i = e ? (Math.round(n / 45) + e) * 45 : n, a = t ? Math.min(89, Math.max(-89, (Math.round(r / 30) + t) * 30)) : r;
		this.apply("Turn the view", [["camera/yaw", ((i + 180) % 360 + 360) % 360 - 180], ["camera/pitch", a]]);
	}
	frameAll(e = 1) {
		let t = this.doc.shapes.flatMap((e) => e.hidden ? [] : e.kind === "group" ? (e.children ?? []).filter((e) => !e.hidden) : [e]).filter((e) => e.combine === "add");
		if (!t.length) return;
		let n = [
			Infinity,
			Infinity,
			Infinity
		], r = [
			-Infinity,
			-Infinity,
			-Infinity
		];
		for (let e of t) {
			let t = Math.hypot(...e.size) / 2;
			for (let i = 0; i < 3; i++) n[i] = Math.min(n[i], e.position[i] - t), r[i] = Math.max(r[i], e.position[i] + t);
		}
		let i = n.map((e, t) => (e + r[t]) / 2), a = Math.max(...r.map((e, t) => e - n[t])) / 2 * 1.25 / Math.min(1, e), o = Math.min(200, Math.max(1.5, a / Math.tan(this.doc.camera.fov / 2 * Math.PI / 180)));
		this.apply("Frame all", [["camera/target", i], ["camera/distance", o]]);
	}
	setCamera(e) {
		this.apply("Turn the view", Object.entries(e).map(([e, t]) => [`camera/${e}`, t]));
	}
};
function lt(e, t, n = {}) {
	let { color: r, name: i, depth: a = .35, long: o = 2, viewAspect: s = 1 } = n, [c, l] = t >= 1 ? [o, o / t] : [o * t, o], u = new ct({
		...Re(),
		shapes: []
	});
	return u.addShape("extrude", {
		outline: e,
		size: [
			c,
			l,
			a
		],
		position: [
			0,
			l / 2,
			0
		],
		...r ? { color: r } : {},
		...i ? { name: i } : {}
	}), u.frameAll(s), u.document;
}
function ut(e, t = {}) {
	let { long: n = 2, depth: r = .3, at: i = [0, 0] } = t, a = n * (e.aspect >= 1 ? 1 / e.aspect : 1);
	return e.parts.map((e, t) => W("extrude", t, {
		name: e.name,
		outline: e.outline,
		color: e.color,
		size: [
			Math.max(.01, e.box.w * n),
			Math.max(.01, e.box.h * n),
			r
		],
		position: [
			i[0] + e.box.x * n,
			a / 2 + e.box.y * n,
			i[1]
		],
		round: .03,
		finish: "satin"
	}));
}
//#endregion
//#region ../scene3d/src/model/text.ts
function dt(e, t, n, r = 128) {
	let i = new Uint8Array(t * n), a = new Float32Array(t * n);
	for (let o = 0; o < t * n; o++) {
		let t = e[o * 4 + 3];
		i[o] = +(t >= r), a[o] = Math.min(1, Math.max(0, .5 + (t - r) / 255));
	}
	let o = _(i, t, n, Math.max(.25, Math.max(t, n) / 2e3), a).filter((e) => Math.abs(y(e)) > t * n / 4e4).map((e) => e.map(([e, t]) => [e, -t]));
	return o.length ? Ue(o) : null;
}
function ft(e, t, n) {
	let r = /* @__PURE__ */ new Map();
	for (let i = 0; i < t * n; i++) {
		if (e[i * 4 + 3] < 200) continue;
		let [t, n, a] = [
			e[i * 4],
			e[i * 4 + 1],
			e[i * 4 + 2]
		], o = t >> 4 << 8 | n >> 4 << 4 | a >> 4, s = r.get(o) ?? {
			n: 0,
			r: 0,
			g: 0,
			b: 0
		};
		r.set(o, {
			n: s.n + 1,
			r: s.r + t,
			g: s.g + n,
			b: s.b + a
		});
	}
	let i;
	for (let e of r.values()) (!i || e.n > i.n) && (i = e);
	return i ? `#${[
		i.r,
		i.g,
		i.b
	].map((e) => Math.round(e / i.n).toString(16).padStart(2, "0")).join("")}` : null;
}
function pt(e, t, n, r = {}) {
	let i = dt(e, t, n);
	return i ? lt(i.outline, i.aspect, {
		...r,
		color: ft(e, t, n) ?? void 0
	}) : null;
}
function mt(e, t, n, r, i = {}) {
	let a = e.split("\n").map((e) => e.trimEnd()).slice(0, 8);
	for (; a.length > 1 && !a[a.length - 1].trim();) a.pop();
	for (; a.length > 1 && !a[0].trim();) a.shift();
	if (!a.some((e) => e.trim())) return null;
	let { align: o = "center", lineHeight: s = 1.15, spacing: c = 0 } = i, l = a.length > 3 ? 160 : 240, u = `${n} ${l}px ${/[\s,]/.test(t) ? t : `"${t}"`}, sans-serif`, d = (e) => {
		e.font = u, c && "letterSpacing" in e && (e.letterSpacing = `${Math.round(c * l)}px`);
	}, f = r(8, 8).getContext("2d");
	if (!f) return null;
	d(f);
	let p = a.map((e) => f.measureText(e || " ").width), m = Math.max(...p, 1), h = l * .15, g = l * s, _ = Math.ceil(m + 2 * h + Math.abs(c) * l), v = Math.ceil(g * (a.length - 1) + l * 1.5), y = r(_, v).getContext("2d");
	return y ? (d(y), y.fillStyle = "#000", y.textBaseline = "middle", a.forEach((e, t) => {
		let n = o === "left" ? h : o === "right" ? h + m - p[t] : h + (m - p[t]) / 2;
		y.fillText(e, n, l * .75 + t * g);
	}), dt(y.getImageData(0, 0, _, v).data, _, v)) : null;
}
var ht = (e, t) => {
	if (typeof OffscreenCanvas < "u") return new OffscreenCanvas(e, t);
	let n = document.createElement("canvas");
	return n.width = e, n.height = t, n;
}, gt = (e, t) => e.style.look === "pixel" ? Math.max(1, e.style.pixel * t / 1e3) : 1;
function _t(e, t, n) {
	let r = gt(e, n);
	return [Math.max(1, Math.round(t / r)), Math.max(1, Math.round(n / r))];
}
var vt = (e) => e.style.look === "pixel" || !!e.background.picture;
function yt(e, t) {
	let n = e.style.look === "pixel";
	return !n && !e.background.picture ? e : {
		...e,
		style: n ? {
			...e.style,
			look: "toon",
			outline: e.style.outline > 0 ? Math.max(e.style.outline, 1e3 / Math.max(1, t)) : 0
		} : e.style,
		background: e.background.picture ? {
			...e.background,
			transparent: !0
		} : e.background
	};
}
function bt(e) {
	let t = /^data:(image\/[a-z]+);base64,(.*)$/.exec(e);
	if (!t) return null;
	let n = typeof atob == "function" ? atob(t[2]) : Buffer.from(t[2], "base64").toString("binary"), r = new Uint8Array(n.length);
	for (let e = 0; e < n.length; e++) r[e] = n.charCodeAt(e);
	return {
		bytes: r,
		mime: t[1]
	};
}
function xt(e, t, n, r) {
	let i = new Uint8ClampedArray(t * n * 4), { scene: a, colour: o } = r, s = o ? [
		1,
		3,
		5
	].map((e) => parseInt(o.slice(e, e + 2), 16)) : null, c = a ? Math.max(t / a.width, n / a.height) : 1, l = a ? (a.width * c - t) / 2 : 0, u = a ? (a.height * c - n) / 2 : 0, d = e.width / t, f = e.height / n;
	for (let o = 0; o < n; o++) for (let n = 0; n < t; n++) {
		let p = (o * t + n) * 4, m = Math.min(e.width - 1, Math.floor(r.hard ? n * d : (n + .5) * d)), h = (Math.min(e.height - 1, Math.floor(r.hard ? o * f : (o + .5) * f)) * e.width + m) * 4, g = e.data[h + 3] / 255, _ = s;
		if (a) {
			let e = Math.min(a.width - 1, Math.max(0, Math.floor((n + l) / c))), t = (Math.min(a.height - 1, Math.max(0, Math.floor((o + u) / c))) * a.width + e) * 4;
			_ = [
				a.data[t],
				a.data[t + 1],
				a.data[t + 2]
			];
		}
		if (_) {
			for (let t = 0; t < 3; t++) i[p + t] = e.data[h + t] * g + _[t] * (1 - g);
			i[p + 3] = 255;
		} else for (let t = 0; t < 4; t++) i[p + t] = e.data[h + t];
	}
	return {
		width: t,
		height: n,
		data: i
	};
}
//#endregion
//#region ../scene3d/src/model/mesh.ts
var St = () => ({
	color: [
		.8,
		.8,
		.8
	],
	opacity: 1,
	metalness: 0,
	roughness: .6,
	texture: -1,
	normalTexture: -1,
	normalScale: 1,
	roughnessTexture: -1,
	occlusionTexture: -1,
	occlusionStrength: 1,
	emissive: [
		0,
		0,
		0
	],
	emissiveTexture: -1,
	clearcoat: 0,
	clearcoatTexture: -1,
	clearcoatRoughness: 0,
	clearcoatRoughnessTexture: -1,
	clearcoatNormalTexture: -1,
	clearcoatNormalScale: 1,
	sheenColor: [
		0,
		0,
		0
	],
	sheenColorTexture: -1,
	sheenRoughness: 0,
	sheenRoughnessTexture: -1,
	transmission: 0,
	transmissionTexture: -1,
	ior: 1.5,
	cutout: !1,
	doubleSided: !1
});
function Ct(e) {
	let t = globalThis.Buffer;
	if (t) return t.from(e).toString("base64");
	let n = "";
	for (let t = 0; t < e.length; t += 32768) n += String.fromCharCode(...e.subarray(t, t + 32768));
	return btoa(n);
}
function wt(e) {
	let t = globalThis.Buffer;
	if (t) return new Uint8Array(t.from(e, "base64"));
	let n = atob(e), r = new Uint8Array(n.length);
	for (let e = 0; e < n.length; e++) r[e] = n.charCodeAt(e);
	return r;
}
function Tt(e) {
	let t = [
		Infinity,
		Infinity,
		Infinity
	], n = [
		-Infinity,
		-Infinity,
		-Infinity
	];
	for (let r of e) for (let e = 0; e < r.positions.length; e += 3) for (let i = 0; i < 3; i++) {
		let a = r.positions[e + i];
		a < t[i] && (t[i] = a), a > n[i] && (n[i] = a);
	}
	return t[0] === Infinity ? {
		min: [
			0,
			0,
			0
		],
		max: [
			0,
			0,
			0
		]
	} : {
		min: t,
		max: n
	};
}
function Et(e, t) {
	let n = new Float32Array(e.length);
	for (let r = 0; r < t.length; r += 3) {
		let [i, a, o] = [
			t[r] * 3,
			t[r + 1] * 3,
			t[r + 2] * 3
		], s = [
			e[a] - e[i],
			e[a + 1] - e[i + 1],
			e[a + 2] - e[i + 2]
		], c = [
			e[o] - e[i],
			e[o + 1] - e[i + 1],
			e[o + 2] - e[i + 2]
		], l = [
			s[1] * c[2] - s[2] * c[1],
			s[2] * c[0] - s[0] * c[2],
			s[0] * c[1] - s[1] * c[0]
		];
		for (let e of [
			i,
			a,
			o
		]) for (let t = 0; t < 3; t++) n[e + t] += l[t];
	}
	for (let e = 0; e < n.length; e += 3) {
		let t = Math.hypot(n[e], n[e + 1], n[e + 2]) || 1;
		n[e] /= t, n[e + 1] /= t, n[e + 2] /= t;
	}
	return n;
}
var Dt = 1179937895, Ot = 1313821514, kt = 5130562, At = (e) => e + 3 & -4, jt = (e, t = {}) => e >= 0 ? {
	index: e,
	...t
} : void 0, Mt = (e) => Object.fromEntries(Object.entries(e).filter(([, e]) => e !== void 0));
function Nt(e) {
	let t = {}, n = {}, r = Math.max(...e.emissive);
	if (r > 0 || e.emissiveTexture >= 0) {
		let i = Math.max(1, r);
		t.emissiveFactor = e.emissive.map((e) => e / i), e.emissiveTexture >= 0 && (t.emissiveTexture = { index: e.emissiveTexture }), i > 1 && (n.KHR_materials_emissive_strength = { emissiveStrength: i });
	}
	return e.unlit && (n.KHR_materials_unlit = {}), e.clearcoat > 0 && (n.KHR_materials_clearcoat = Mt({
		clearcoatFactor: e.clearcoat,
		clearcoatTexture: jt(e.clearcoatTexture),
		clearcoatRoughnessFactor: e.clearcoatRoughness,
		clearcoatRoughnessTexture: jt(e.clearcoatRoughnessTexture),
		clearcoatNormalTexture: jt(e.clearcoatNormalTexture, { scale: e.clearcoatNormalScale })
	})), Math.max(...e.sheenColor) > 0 && (n.KHR_materials_sheen = Mt({
		sheenColorFactor: e.sheenColor,
		sheenColorTexture: jt(e.sheenColorTexture),
		sheenRoughnessFactor: e.sheenRoughness,
		sheenRoughnessTexture: jt(e.sheenRoughnessTexture)
	})), e.transmission > 0 && (n.KHR_materials_transmission = Mt({
		transmissionFactor: e.transmission,
		transmissionTexture: jt(e.transmissionTexture)
	})), e.ior !== 1.5 && (n.KHR_materials_ior = { ior: e.ior }), Object.keys(n).length && (t.extensions = n), t;
}
function Pt(e) {
	let t = [], n = [], r = [], i = 0, a = (e, n) => {
		t.push({
			buffer: 0,
			byteOffset: i,
			byteLength: e.byteLength,
			...n ? { target: n } : {}
		}), r.push(e);
		let a = At(e.byteLength);
		return a > e.byteLength && r.push(new Uint8Array(a - e.byteLength)), i += a, t.length - 1;
	}, o = (e, t, r, i = !1) => {
		let o = a(new Uint8Array(e.buffer, e.byteOffset, e.byteLength), r), s = t === "VEC3" ? 3 : t === "VEC2" ? 2 : 1, c = {
			bufferView: o,
			componentType: e instanceof Float32Array ? 5126 : 5125,
			count: e.length / s,
			type: t
		};
		if (i) {
			let t = [
				Infinity,
				Infinity,
				Infinity
			].slice(0, s), n = [
				-Infinity,
				-Infinity,
				-Infinity
			].slice(0, s);
			for (let r = 0; r < e.length; r++) {
				let i = r % s;
				t[i] = Math.min(t[i], e[r]), n[i] = Math.max(n[i], e[r]);
			}
			Object.assign(c, {
				min: t,
				max: n
			});
		}
		return n.push(c), n.length - 1;
	}, s = e.parts.map((e) => {
		let t = {
			POSITION: o(e.positions, "VEC3", 34962, !0),
			NORMAL: o(e.normals, "VEC3", 34962)
		};
		return e.uvs && (t.TEXCOORD_0 = o(e.uvs, "VEC2", 34962)), e.colors && (t.COLOR_0 = o(e.colors, "VEC3", 34962)), {
			attributes: t,
			indices: o(e.indices, "SCALAR", 34963),
			material: e.material,
			mode: 4
		};
	}), c = e.textures.map((e) => ({
		bufferView: a(e.bytes),
		mimeType: e.mime
	})), l = [...new Set(e.materials.flatMap((e) => Object.keys(Nt(e).extensions ?? {})))], u = {
		asset: {
			version: "2.0",
			generator: "Gleamshelf"
		},
		...l.length ? { extensionsUsed: l } : {},
		scene: 0,
		scenes: [{ nodes: [0] }],
		nodes: [{ mesh: 0 }],
		meshes: [{ primitives: s }],
		materials: e.materials.map((e) => ({
			pbrMetallicRoughness: {
				baseColorFactor: [...e.color, e.opacity],
				metallicFactor: e.metalness,
				roughnessFactor: e.roughness,
				...e.texture >= 0 ? { baseColorTexture: { index: e.texture } } : {},
				...e.roughnessTexture >= 0 ? { metallicRoughnessTexture: { index: e.roughnessTexture } } : {}
			},
			...e.normalTexture >= 0 ? { normalTexture: {
				index: e.normalTexture,
				scale: e.normalScale
			} } : {},
			...e.occlusionTexture >= 0 ? { occlusionTexture: {
				index: e.occlusionTexture,
				strength: e.occlusionStrength
			} } : {},
			...Nt(e),
			...e.cutout ? {
				alphaMode: "MASK",
				alphaCutoff: .5
			} : {},
			...e.doubleSided ? { doubleSided: !0 } : {}
		})),
		...c.length ? {
			images: c,
			textures: c.map((e, t) => ({
				source: t,
				sampler: 0
			})),
			samplers: [{
				magFilter: 9729,
				minFilter: 9987,
				wrapS: 10497,
				wrapT: 10497
			}]
		} : {},
		accessors: n,
		bufferViews: t,
		buffers: [{ byteLength: i }]
	}, d = new TextEncoder().encode(JSON.stringify(u)), f = At(d.byteLength), p = 20 + f + 8 + i, m = new Uint8Array(p), h = new DataView(m.buffer);
	h.setUint32(0, Dt, !0), h.setUint32(4, 2, !0), h.setUint32(8, p, !0), h.setUint32(12, f, !0), h.setUint32(16, Ot, !0), m.set(d, 20), m.fill(32, 20 + d.byteLength, 20 + f);
	let g = 20 + f;
	h.setUint32(g, i, !0), h.setUint32(g + 4, kt, !0), g += 8;
	for (let e of r) m.set(e, g), g += e.byteLength;
	return m;
}
var Ft = {
	KHR_draco_mesh_compression: "Draco compression",
	EXT_meshopt_compression: "meshopt compression",
	KHR_meshopt_compression: "meshopt compression",
	KHR_texture_basisu: "KTX2 textures"
}, It = [
	1,
	0,
	0,
	0,
	0,
	1,
	0,
	0,
	0,
	0,
	1,
	0,
	0,
	0,
	0,
	1
];
function Lt(e, t) {
	let n = Array(16).fill(0);
	for (let r = 0; r < 4; r++) for (let i = 0; i < 4; i++) for (let a = 0; a < 4; a++) n[r * 4 + i] += e[a * 4 + i] * t[r * 4 + a];
	return n;
}
function Rt(e = [
	0,
	0,
	0
], t = [
	0,
	0,
	0,
	1
], n = [
	1,
	1,
	1
]) {
	let [r, i, a, o] = t, [s, c, l] = n;
	return [
		(1 - 2 * (i * i + a * a)) * s,
		2 * (r * i + a * o) * s,
		2 * (r * a - i * o) * s,
		0,
		2 * (r * i - a * o) * c,
		(1 - 2 * (r * r + a * a)) * c,
		2 * (i * a + r * o) * c,
		0,
		2 * (r * a + i * o) * l,
		2 * (i * a - r * o) * l,
		(1 - 2 * (r * r + i * i)) * l,
		0,
		e[0],
		e[1],
		e[2],
		1
	];
}
function zt(e) {
	let [t, n, r, i, a, o, s, c, l] = [
		e[0],
		e[4],
		e[8],
		e[1],
		e[5],
		e[9],
		e[2],
		e[6],
		e[10]
	], u = t * (a * l - o * c) - n * (i * l - o * s) + r * (i * c - a * s), d = 1 / (u || 1);
	return {
		n: [
			(a * l - o * c) * d,
			-(i * l - o * s) * d,
			(i * c - a * s) * d,
			-(n * l - r * c) * d,
			(t * l - r * s) * d,
			-(t * c - n * s) * d,
			(n * o - r * a) * d,
			-(t * o - r * i) * d,
			(t * a - n * i) * d
		],
		mirrored: u < 0
	};
}
var Bt = {
	SCALAR: 1,
	VEC2: 2,
	VEC3: 3,
	VEC4: 4,
	MAT4: 16
};
function Vt(e, t, n) {
	let r = e.accessors?.[n];
	if (!r) throw Error(`The model points at accessor ${n}, which is missing.`);
	if (r.sparse) throw Error("The model uses sparse accessors, which are not read here; open it in 3D mode instead.");
	let i = Bt[r.type] ?? 1, a = new Float32Array(r.count * i);
	if (r.bufferView === void 0) return {
		data: a,
		size: i
	};
	let o = e.bufferViews[r.bufferView], s = t[o.buffer ?? 0], c = {
		5120: 1,
		5121: 1,
		5122: 2,
		5123: 2,
		5125: 4,
		5126: 4
	}[r.componentType] ?? 4, l = o.byteStride || c * i, u = s.byteOffset + (o.byteOffset ?? 0) + (r.byteOffset ?? 0), d = new DataView(s.buffer), f = r.normalized === !0;
	for (let e = 0; e < r.count; e++) for (let t = 0; t < i; t++) {
		let n = u + e * l + t * c, o;
		switch (r.componentType) {
			case 5126:
				o = d.getFloat32(n, !0);
				break;
			case 5125:
				o = d.getUint32(n, !0);
				break;
			case 5123:
				o = d.getUint16(n, !0), f && (o /= 65535);
				break;
			case 5122:
				o = d.getInt16(n, !0), f && (o = Math.max(o / 32767, -1));
				break;
			case 5121:
				o = d.getUint8(n), f && (o /= 255);
				break;
			default: o = d.getInt8(n), f && (o = Math.max(o / 127, -1));
		}
		a[e * i + t] = o;
	}
	return {
		data: a,
		size: i
	};
}
var Ht = (e) => {
	let t = /^data:([^;,]*)(;base64)?,(.*)$/s.exec(e);
	return t ? {
		mime: t[1] || "application/octet-stream",
		bytes: t[2] ? wt(t[3]) : new TextEncoder().encode(decodeURIComponent(t[3]))
	} : null;
};
function Ut(e, t, n = () => null) {
	let r = (e.extensionsRequired ?? []).filter((e) => Ft[e]);
	if (r.length) throw Error(`This model uses ${r.map((e) => Ft[e]).join(" and ")}; import it in 3D mode, which decodes it.`);
	let i = (e.buffers ?? []).map((e, r) => {
		if (e.uri === void 0) {
			if (r === 0 && t) return t;
			throw Error("The model’s data is missing.");
		}
		let i = Ht(e.uri)?.bytes ?? n(decodeURIComponent(e.uri));
		if (!i) throw Error(`The model needs "${e.uri}" beside it.`);
		return i;
	}), a = /* @__PURE__ */ new Map(), o = [], s = (t) => {
		if (!t || typeof t.index != "number" || (t.texCoord ?? 0) !== 0) return -1;
		if (a.has(t.index)) return a.get(t.index);
		let r = e.textures?.[t.index], s = r?.source ?? r?.extensions?.EXT_texture_webp?.source, c = e.images?.[s], l = null;
		if (c?.bufferView !== void 0) {
			let t = e.bufferViews[c.bufferView], n = i[t.buffer ?? 0];
			l = {
				mime: c.mimeType ?? "image/png",
				bytes: n.slice(t.byteOffset ?? 0, (t.byteOffset ?? 0) + t.byteLength)
			};
		} else if (typeof c?.uri == "string" && (l = Ht(c.uri), !l)) {
			let e = n(decodeURIComponent(c.uri));
			e && (l = {
				mime: /\.jpe?g$/i.test(c.uri) ? "image/jpeg" : /\.webp$/i.test(c.uri) ? "image/webp" : "image/png",
				bytes: e
			});
		}
		let u = l && /^image\/(png|jpeg|webp)$/.test(l.mime) ? o.push(l) - 1 : -1;
		return a.set(t.index, u), u;
	}, c = (e.materials ?? []).map((e) => {
		let t = e.pbrMetallicRoughness ?? {}, n = t.baseColorFactor ?? [
			1,
			1,
			1,
			1
		];
		return {
			color: [
				n[0] ?? 1,
				n[1] ?? 1,
				n[2] ?? 1
			],
			opacity: n[3] ?? 1,
			metalness: t.metallicFactor ?? 1,
			roughness: t.roughnessFactor ?? 1,
			texture: s(t.baseColorTexture),
			normalTexture: s(e.normalTexture),
			normalScale: typeof e.normalTexture?.scale == "number" ? e.normalTexture.scale : 1,
			roughnessTexture: s(t.metallicRoughnessTexture),
			occlusionTexture: s(e.occlusionTexture),
			occlusionStrength: typeof e.occlusionTexture?.strength == "number" ? e.occlusionTexture.strength : 1,
			emissive: (e.emissiveFactor ?? [
				0,
				0,
				0
			]).slice(0, 3).map((t) => t * (e.extensions?.KHR_materials_emissive_strength?.emissiveStrength ?? 1)),
			emissiveTexture: s(e.emissiveTexture),
			...Wt(e.extensions ?? {}, s),
			cutout: e.alphaMode === "MASK" || e.alphaMode === "BLEND",
			doubleSided: e.doubleSided === !0,
			...e.extensions?.KHR_materials_unlit ? { unlit: !0 } : {}
		};
	}), l = -1, u = [], d = (t, n, r) => {
		let a = e.nodes?.[t];
		if (!a || r > 64) return;
		let o = Lt(n, a.matrix ?? Rt(a.translation, a.rotation, a.scale)), s = e.meshes?.[a.mesh];
		if (s) {
			let { n: t, mirrored: n } = zt(o);
			for (let r of s.primitives ?? []) {
				if ((r.mode ?? 4) !== 4 || r.attributes?.POSITION === void 0) continue;
				let a = Vt(e, i, r.attributes.POSITION).data, s = a.length / 3, d = new Float32Array(a.length);
				for (let e = 0; e < s; e++) {
					let [t, n, r] = [
						a[e * 3],
						a[e * 3 + 1],
						a[e * 3 + 2]
					];
					for (let i = 0; i < 3; i++) d[e * 3 + i] = o[i] * t + o[4 + i] * n + o[8 + i] * r + o[12 + i];
				}
				let f = r.indices === void 0 ? Uint32Array.from({ length: s }, (e, t) => t) : Uint32Array.from(Vt(e, i, r.indices).data);
				if (n) for (let e = 0; e < f.length; e += 3) [f[e + 1], f[e + 2]] = [f[e + 2], f[e + 1]];
				let p;
				if (r.attributes.NORMAL !== void 0) {
					let n = Vt(e, i, r.attributes.NORMAL).data;
					p = new Float32Array(n.length);
					for (let e = 0; e < s; e++) {
						let [r, i, a] = [
							n[e * 3],
							n[e * 3 + 1],
							n[e * 3 + 2]
						], o = [
							t[0] * r + t[1] * i + t[2] * a,
							t[3] * r + t[4] * i + t[5] * a,
							t[6] * r + t[7] * i + t[8] * a
						], s = Math.hypot(o[0], o[1], o[2]) || 1;
						p.set([
							o[0] / s,
							o[1] / s,
							o[2] / s
						], e * 3);
					}
				} else p = Et(d, f);
				let m = r.attributes.TEXCOORD_0 === void 0 ? null : Vt(e, i, r.attributes.TEXCOORD_0).data, h = null;
				if (r.attributes.COLOR_0 !== void 0) {
					let t = Vt(e, i, r.attributes.COLOR_0);
					h = new Float32Array(s * 3);
					for (let e = 0; e < s; e++) h.set([
						t.data[e * t.size],
						t.data[e * t.size + 1],
						t.data[e * t.size + 2]
					], e * 3);
				}
				let g = typeof r.material == "number" && c[r.material] ? r.material : -1;
				g < 0 && (l < 0 && (l = c.push(St()) - 1), g = l), u.push({
					positions: d,
					normals: p,
					uvs: m,
					colors: h,
					indices: f,
					material: g
				});
			}
		}
		for (let e of a.children ?? []) d(e, o, r + 1);
	}, f = e.scenes?.[e.scene ?? 0]?.nodes ?? (e.nodes ?? []).map((e, t) => t);
	for (let e of f) d(e, It, 0);
	if (!u.length) throw Error("The model has no triangles to draw.");
	return Gt(u, c, o);
}
function Wt(e, t) {
	let n = e.KHR_materials_clearcoat ?? {}, r = e.KHR_materials_sheen ?? {}, i = e.KHR_materials_transmission ?? {}, a = (e, t) => typeof e == "number" && Number.isFinite(e) ? e : t;
	return {
		clearcoat: a(n.clearcoatFactor, 0),
		clearcoatTexture: t(n.clearcoatTexture),
		clearcoatRoughness: a(n.clearcoatRoughnessFactor, 0),
		clearcoatRoughnessTexture: t(n.clearcoatRoughnessTexture),
		clearcoatNormalTexture: t(n.clearcoatNormalTexture),
		clearcoatNormalScale: a(n.clearcoatNormalTexture?.scale, 1),
		sheenColor: e.KHR_materials_sheen ? (r.sheenColorFactor ?? [
			0,
			0,
			0
		]).slice(0, 3).map((e) => a(e, 0)) : [
			0,
			0,
			0
		],
		sheenColorTexture: t(r.sheenColorTexture),
		sheenRoughness: a(r.sheenRoughnessFactor, 0),
		sheenRoughnessTexture: t(r.sheenRoughnessTexture),
		transmission: a(i.transmissionFactor, 0),
		transmissionTexture: t(i.transmissionTexture),
		ior: Math.min(3, Math.max(1, a(e.KHR_materials_ior?.ior, 1.5)))
	};
}
function Gt(e, t, n) {
	let { min: r, max: i } = Tt(e);
	return {
		parts: e,
		materials: t,
		textures: n,
		min: r,
		max: i,
		triangles: e.reduce((e, t) => e + t.indices.length / 3, 0)
	};
}
function Kt(e, t) {
	let n = new DataView(e.buffer, e.byteOffset, e.byteLength);
	if (e.byteLength >= 12 && n.getUint32(0, !0) === Dt) {
		let r = 12, i = null, a = null;
		for (; r + 8 <= e.byteLength;) {
			let t = n.getUint32(r, !0), o = n.getUint32(r + 4, !0), s = e.subarray(r + 8, r + 8 + t);
			o === Ot ? i = JSON.parse(new TextDecoder().decode(s)) : o === kt && (a = s), r += 8 + At(t);
		}
		if (!i) throw Error("That GLB has no model description in it.");
		return Ut(i, a, t);
	}
	try {
		return Ut(JSON.parse(new TextDecoder().decode(e)), null, t);
	} catch (e) {
		throw e instanceof SyntaxError ? Error("That is not a glTF or GLB model.") : e;
	}
}
var qt = /* @__PURE__ */ new Map();
function Jt(e, t) {
	let n = qt.get(e);
	if (n && n.data === t) return n.asset;
	let r = Kt(wt(t));
	return qt.set(e, {
		data: t,
		asset: r
	}), qt.size > 24 && qt.delete(qt.keys().next().value), r;
}
var Yt = /* @__PURE__ */ new WeakMap();
function Xt(e) {
	let t = Yt.get(e);
	if (t) return t;
	let n = e.triangles, r = new Float32Array(n * 9), i = new Uint32Array(n * 4), a = 0;
	e.parts.forEach((e, t) => {
		for (let n = 0; n < e.indices.length; n += 3, a++) {
			for (let t = 0; t < 3; t++) {
				let o = e.indices[n + t];
				r.set([
					e.positions[o * 3],
					e.positions[o * 3 + 1],
					e.positions[o * 3 + 2]
				], a * 9 + t * 3), i[a * 4 + 1 + t] = o;
			}
			i[a * 4] = t;
		}
	});
	let o = Uint32Array.from({ length: n }, (e, t) => t), s = new Float32Array(n * 3);
	for (let e = 0; e < n; e++) for (let t = 0; t < 3; t++) s[e * 3 + t] = (r[e * 9 + t] + r[e * 9 + 3 + t] + r[e * 9 + 6 + t]) / 3;
	let c = [], l = [], u = (e, t) => {
		let n = l.length / 3;
		l.push(0, 0, 0);
		let [i, a, d, f, p, m] = [
			Infinity,
			Infinity,
			Infinity,
			-Infinity,
			-Infinity,
			-Infinity
		];
		for (let n = e; n < t; n++) {
			let e = o[n] * 9;
			for (let t = 0; t < 9; t += 3) i = Math.min(i, r[e + t]), a = Math.min(a, r[e + t + 1]), d = Math.min(d, r[e + t + 2]), f = Math.max(f, r[e + t]), p = Math.max(p, r[e + t + 1]), m = Math.max(m, r[e + t + 2]);
		}
		if (c.push(i, a, d, f, p, m), t - e <= 4) return l[n * 3] = 1, l[n * 3 + 1] = e, l[n * 3 + 2] = t - e, n;
		let h = f - i >= p - a && f - i >= m - d ? 0 : p - a >= m - d ? 1 : 2, g = Array.from(o.subarray(e, t)).sort((e, t) => s[e * 3 + h] - s[t * 3 + h]);
		o.set(g, e);
		let _ = e + t >> 1;
		u(e, _);
		let v = u(_, t);
		return l[n * 3] = 0, l[n * 3 + 1] = v, n;
	};
	n && u(0, n);
	let d = Float32Array.from(c), f = Uint32Array.from(l), p = (e, t, a, s, c) => {
		if (!n) return null;
		let l = [
			1 / t[0],
			1 / t[1],
			1 / t[2]
		], u = null, p = s, m = [0];
		for (; m.length;) {
			let n = m.pop(), s = a, h = p;
			for (let t = 0; t < 3; t++) {
				let r = (d[n * 6 + t] - e[t]) * l[t], i = (d[n * 6 + 3 + t] - e[t]) * l[t];
				if (r > i && ([r, i] = [i, r]), s = Math.max(s, r), h = Math.min(h, i), s > h) break;
			}
			if (!(s > h)) {
				if (f[n * 3] === 1) {
					let s = f[n * 3 + 1], l = f[n * 3 + 2];
					for (let n = s; n < s + l; n++) {
						let s = o[n], l = s * 9, d = [
							r[l + 3] - r[l],
							r[l + 4] - r[l + 1],
							r[l + 5] - r[l + 2]
						], f = [
							r[l + 6] - r[l],
							r[l + 7] - r[l + 1],
							r[l + 8] - r[l + 2]
						], m = [
							t[1] * f[2] - t[2] * f[1],
							t[2] * f[0] - t[0] * f[2],
							t[0] * f[1] - t[1] * f[0]
						], h = d[0] * m[0] + d[1] * m[1] + d[2] * m[2];
						if (Math.abs(h) < 1e-12) continue;
						let g = 1 / h, _ = [
							e[0] - r[l],
							e[1] - r[l + 1],
							e[2] - r[l + 2]
						], v = (_[0] * m[0] + _[1] * m[1] + _[2] * m[2]) * g;
						if (v < 0 || v > 1) continue;
						let y = [
							_[1] * d[2] - _[2] * d[1],
							_[2] * d[0] - _[0] * d[2],
							_[0] * d[1] - _[1] * d[0]
						], b = (t[0] * y[0] + t[1] * y[1] + t[2] * y[2]) * g;
						if (b < 0 || v + b > 1) continue;
						let x = (f[0] * y[0] + f[1] * y[1] + f[2] * y[2]) * g;
						if (!(x <= a || x >= p) && (p = x, u = {
							t: x,
							part: i[s * 4],
							a: i[s * 4 + 1],
							b: i[s * 4 + 2],
							c: i[s * 4 + 3],
							u: v,
							v: b
						}, c)) return u;
					}
				} else m.push(f[n * 3 + 1], n + 1);
			}
		}
		return u;
	}, m = {
		intersect: (e, t, n = 0, r = Infinity) => p(e, t, n, r, !1),
		occluded: (e, t, n = 0, r = Infinity) => p(e, t, n, r, !0) !== null
	};
	return Yt.set(e, m), m;
}
//#endregion
//#region ../scene3d/src/model/meshcpu.ts
var Zt = typeof createImageBitmap == "function" && typeof OffscreenCanvas < "u" ? async (e, t) => {
	try {
		let n = await createImageBitmap(new Blob([e], { type: t }), {
			premultiplyAlpha: "none",
			colorSpaceConversion: "none"
		}), r = new OffscreenCanvas(n.width, n.height), i = r.getContext("2d");
		return i.drawImage(n, 0, 0), n.close(), i.getImageData(0, 0, r.width, r.height);
	} catch {
		return null;
	}
} : void 0, Qt = /* @__PURE__ */ new WeakMap();
async function $t(e, t = Zt) {
	let n = [];
	for (let { shape: r, asset: i } of Xe(e)) {
		let e = Jt(r.asset, i.data), a = Qt.get(e);
		a || Qt.set(e, a = /* @__PURE__ */ new Map());
		let o = t ? a.get(t) : void 0;
		o || (o = t ? Promise.all(e.textures.map((e) => t(e.bytes, e.mime))) : Promise.resolve(e.textures.map(() => null)), t && a.set(t, o));
		let s = e.max.map((t, n) => Math.max(t - e.min[n], 1e-9));
		n.push({
			shape: r,
			asset: e,
			bvh: Xt(e),
			textures: await o,
			rot: C(r.rotation),
			scale: r.size.map((e, t) => e / s[t]),
			centre: e.min.map((t, n) => (t + e.max[n]) / 2),
			position: r.position
		});
	}
	return n;
}
function en(e, t, n) {
	let r = e.rot, i = [
		t[0] - e.position[0],
		t[1] - e.position[1],
		t[2] - e.position[2]
	];
	return [[
		0,
		1,
		2
	].map((t) => (r[t] * i[0] + r[3 + t] * i[1] + r[6 + t] * i[2]) / e.scale[t] + e.centre[t]), [
		0,
		1,
		2
	].map((t) => (r[t] * n[0] + r[3 + t] * n[1] + r[6 + t] * n[2]) / e.scale[t])];
}
var tn = (e) => (e / 255) ** 2.2, q = (e, t, n) => {
	let r = Math.min(e.width - 1, Math.floor((t - Math.floor(t)) * e.width));
	return (Math.min(e.height - 1, Math.floor((n - Math.floor(n)) * e.height)) * e.width + r) * 4;
}, nn = (e, t) => {
	let n = [
		t[0] * e.scale[0],
		t[1] * e.scale[1],
		t[2] * e.scale[2]
	], r = e.rot;
	return [
		0,
		1,
		2
	].map((e) => r[e * 3] * n[0] + r[e * 3 + 1] * n[1] + r[e * 3 + 2] * n[2]);
};
function rn(e, t, n, r, i, a, o, s) {
	let c = (e) => [
		t.positions[e * 3],
		t.positions[e * 3 + 1],
		t.positions[e * 3 + 2]
	], l = (e) => [t.uvs[e * 2], t.uvs[e * 2 + 1]], [u, d, f] = n.map(c), [p, m, h] = n.map(l), g = [
		0,
		1,
		2
	].map((e) => d[e] - u[e]), _ = [
		0,
		1,
		2
	].map((e) => f[e] - u[e]), [v, y, b, x] = [
		m[0] - p[0],
		m[1] - p[1],
		h[0] - p[0],
		h[1] - p[1]
	], S = v * x - b * y;
	if (Math.abs(S) <= 1e-12) return r;
	let C = [
		0,
		1,
		2
	].map((e) => (g[e] * x - _[e] * y) / S), w = [
		0,
		1,
		2
	].map((e) => (_[e] * v - g[e] * b) / S), T = (e) => an([
		0,
		1,
		2
	].map((t) => e[t] - r[t] * (e[0] * r[0] + e[1] * r[1] + e[2] * r[2]))), E = T(nn(e, C)), D = T(nn(e, w)), O = q(i, a, o), k = (i.data[O] / 255 * 2 - 1) * s, A = (i.data[O + 1] / 255 * 2 - 1) * s, j = i.data[O + 2] / 255 * 2 - 1;
	return an([
		0,
		1,
		2
	].map((e) => E[e] * k - D[e] * A + r[e] * j));
}
var an = (e) => {
	let t = Math.hypot(e[0], e[1], e[2]) || 1;
	return [
		e[0] / t,
		e[1] / t,
		e[2] / t
	];
};
function on(e, t, n, r = Infinity) {
	let i = null, a = r;
	for (let r of e) {
		let [e, o] = en(r, t, n), s = 1e-5;
		for (let t = 0; t < 6; t++) {
			let t = r.bvh.intersect(e, o, s, a);
			if (!t) break;
			let c = r.asset.parts[t.part], l = r.asset.materials[c.material], u = [
				1 - t.u - t.v,
				t.u,
				t.v
			], d = [
				t.a,
				t.b,
				t.c
			], f = (e, t, n) => d.reduce((r, i, a) => r + e[i * t + n] * u[a], 0), p = [...l.color], m = l.opacity, [h, g] = c.uvs ? [f(c.uvs, 2, 0), f(c.uvs, 2, 1)] : [0, 0], _ = l.texture >= 0 && c.uvs ? r.textures[l.texture] : null;
			if (_) {
				let e = q(_, h, g);
				p = [
					p[0] * tn(_.data[e]),
					p[1] * tn(_.data[e + 1]),
					p[2] * tn(_.data[e + 2])
				], m *= _.data[e + 3] / 255;
			}
			let v = l.unlit && r.shape.ownColors !== !1 && [
				0,
				1,
				2
			].reduce((e, t) => e + f(c.normals, 3, t) * o[t], 0) > 0;
			if (l.cutout && m < .5 || v) {
				s = t.t + 1e-5;
				continue;
			}
			c.colors && (p = [
				p[0] * f(c.colors, 3, 0),
				p[1] * f(c.colors, 3, 1),
				p[2] * f(c.colors, 3, 2)
			]);
			let y = [
				0,
				1,
				2
			].map((e) => f(c.normals, 3, e) / r.scale[e]), b = r.rot, x = an([
				0,
				1,
				2
			].map((e) => b[e * 3] * y[0] + b[e * 3 + 1] * y[1] + b[e * 3 + 2] * y[2])), S = x, C = l.normalTexture >= 0 && c.uvs ? r.textures[l.normalTexture] : null;
			C && (x = rn(r, c, d, x, C, h, g, l.normalScale)), x[0] * n[0] + x[1] * n[1] + x[2] * n[2] > 0 && (x = x.map((e) => -e));
			let w = r.shape.ownColors !== !1, [T, E] = [l.roughness, l.metalness], D = w && l.roughnessTexture >= 0 && c.uvs ? r.textures[l.roughnessTexture] : null;
			if (D) {
				let e = q(D, h, g);
				T *= D.data[e + 1] / 255, E *= D.data[e + 2] / 255;
			}
			let [O, k] = w ? [6 + (1 - T) ** 2 * 134, E] : j[r.shape.finish], A = l.occlusionTexture >= 0 && c.uvs ? r.textures[l.occlusionTexture] : null, ee = A ? 1 + l.occlusionStrength * (A.data[q(A, h, g)] / 255 - 1) : 1, M = w ? [...l.emissive] : [
				0,
				0,
				0
			], N = w && l.emissiveTexture >= 0 && c.uvs ? r.textures[l.emissiveTexture] : null;
			if (N && Math.max(...M) > 0) {
				let e = q(N, h, g);
				M = [
					M[0] * tn(N.data[e]),
					M[1] * tn(N.data[e + 1]),
					M[2] * tn(N.data[e + 2])
				];
			}
			if (!w) {
				let e = parseInt(r.shape.color.slice(1), 16);
				p = [
					(e >> 16 & 255) / 255,
					(e >> 8 & 255) / 255,
					(e & 255) / 255
				].map((e) => e ** 2.2);
			}
			a = t.t;
			let te = (e) => w && e >= 0 && c.uvs ? r.textures[e] : null, P = (e, t, n = 1) => {
				let r = te(e);
				return r ? r.data[q(r, h, g) + t] / 255 : n;
			}, F = S, I = S, L = te(l.clearcoatNormalTexture);
			L && (I = rn(r, c, d, S, L, h, g, l.clearcoatNormalScale));
			let ne = (e) => e[0] * n[0] + e[1] * n[1] + e[2] * n[2] > 0 ? e.map((e) => -e) : e;
			F = ne(F), I = ne(I);
			let R = te(l.sheenColorTexture), z = w ? [...l.sheenColor] : [
				0,
				0,
				0
			];
			if (R) {
				let e = q(R, h, g);
				for (let t = 0; t < 3; t++) z[t] = z[t] * tn(R.data[e + t]);
			}
			i = {
				t: t.t,
				unlit: w && l.unlit === !0,
				normal: x,
				color: p,
				shine: O,
				metal: k,
				occ: ee,
				emissive: M,
				shapeNormal: F,
				clearcoat: w ? l.clearcoat * P(l.clearcoatTexture, 0) : 0,
				clearcoatRoughness: l.clearcoatRoughness * P(l.clearcoatRoughnessTexture, 1),
				coatNormal: I,
				sheen: z,
				sheenRoughness: l.sheenRoughness * P(l.sheenRoughnessTexture, 3),
				transmission: w ? l.transmission * P(l.transmissionTexture, 0) : 0,
				ior: l.ior
			};
			break;
		}
	}
	return i;
}
function sn(e, t, n, r = Infinity) {
	for (let i of e) {
		let [e, a] = en(i, t, n), o = i.shape.ownColors !== !1, s = 1e-4;
		for (let t = 0; t < 6; t++) {
			let t = i.bvh.intersect(e, a, s, r);
			if (!t) break;
			let n = i.asset.parts[t.part], c = i.asset.materials[n.material];
			if (o && c.transmission > .5) {
				s = t.t + 1e-5;
				continue;
			}
			let l = c.cutout && c.texture >= 0 && n.uvs ? i.textures[c.texture] : null;
			if (l) {
				let e = [
					1 - t.u - t.v,
					t.u,
					t.v
				], r = [
					t.a,
					t.b,
					t.c
				], i = [0, 1].map((t) => r.reduce((r, i, a) => r + n.uvs[i * 2 + t] * e[a], 0));
				if (l.data[q(l, i[0], i[1]) + 3] / 255 * c.opacity < .5) {
					s = t.t + 1e-5;
					continue;
				}
			}
			return !0;
		}
	}
	return !1;
}
//#endregion
//#region ../scene3d/src/model/cpu.ts
var cn = (e, t) => [
	e[0] - t[0],
	e[1] - t[1],
	e[2] - t[2]
], J = (e, t) => [
	e[0] + t[0],
	e[1] + t[1],
	e[2] + t[2]
], Y = (e, t) => [
	e[0] * t,
	e[1] * t,
	e[2] * t
], X = (e, t) => e[0] * t[0] + e[1] * t[1] + e[2] * t[2], ln = (e, t) => [
	e[1] * t[2] - e[2] * t[1],
	e[2] * t[0] - e[0] * t[2],
	e[0] * t[1] - e[1] * t[0]
], Z = (e) => Y(e, 1 / (Math.hypot(...e) || 1)), Q = (e, t, n) => e + (t - e) * n, un = (e) => Math.min(1, Math.max(0, e)), dn = (e, t, n) => {
	let r = un((n - e) / (t - e));
	return r * r * (3 - 2 * r);
}, fn = (e) => {
	let t = parseInt(e.slice(1), 16);
	return [
		((t >> 16 & 255) / 255) ** 2.2,
		((t >> 8 & 255) / 255) ** 2.2,
		((t & 255) / 255) ** 2.2
	];
}, $ = Math.PI / 180;
async function pn(e, t) {
	if (!vt(e)) return mn(e, t);
	let { width: n, height: r, region: i } = t, [a, o] = _t(e, n, r), s = a / n, c = await mn(yt(e, o), {
		...t,
		width: a,
		height: o,
		...e.style.look === "pixel" ? { samples: 1 } : {},
		...i ? { region: i.map((e, t) => Math.round(e * (t % 2 ? o / r : s))) } : {}
	}), [l, u] = i ? [i[2] - i[0], i[3] - i[1]] : [n, r], d = null, f = e.background.picture ? bt(e.background.picture) : null, p = t.decodeImage ?? Zt;
	return f && p && (d = await p(f.bytes, f.mime)), xt(c, l, u, {
		hard: e.style.look === "pixel",
		scene: d,
		colour: e.background.transparent ? null : e.background.color
	});
}
async function mn(e, t) {
	let { width: n, height: r, samples: i = 1, frame: a = 1, tones: o, region: s, onProgress: c } = t, l = t.meshes ?? await $t(e, t.decodeImage ?? Zt), u = Qe(e), d = (t) => N(e, t, u), f = (e) => d(e).d, p = e.camera, m = p.target, h = J(m, Y([
		Math.sin(p.yaw * $) * Math.cos(p.pitch * $),
		Math.sin(p.pitch * $),
		Math.cos(p.yaw * $) * Math.cos(p.pitch * $)
	], p.distance)), g = Z(cn(m, h)), _ = Z(ln(g, [
		0,
		1,
		0
	])), v = ln(_, g), y = Math.tan(p.fov / 2 * $) * a, b = p.projection === "orthographic", x = p.distance * y, S = n / r, C = Z([
		Math.sin(e.light.azimuth * $) * Math.cos(e.light.elevation * $),
		Math.sin(e.light.elevation * $),
		Math.cos(e.light.azimuth * $) * Math.cos(e.light.elevation * $)
	]), w = fn(e.light.color), { intensity: T, ambient: E } = e.light, D = e.style.look, O = o ? 0 : e.style.outline * r / 1e3, k = fn(e.style.outlineColor), A = fn(e.background.color), j = b ? 2 * x / r : 2 * y / r, ee = (e, t) => {
		let n = 5e-4 * Math.max(1, t), r = [
			1,
			-1,
			-1
		], i = [
			-1,
			-1,
			1
		], a = [
			-1,
			1,
			-1
		], o = [
			1,
			1,
			1
		];
		return Z(J(J(Y(r, f(J(e, Y(r, n)))), Y(i, f(J(e, Y(i, n))))), J(Y(a, f(J(e, Y(a, n)))), Y(o, f(J(e, Y(o, n)))))));
	}, M = (t, n, r = !1) => {
		if (!e.light.shadows) return 1;
		if (l.length && sn(l, t, n, 60)) return 0;
		let i = 1, a = .02;
		for (let e = 0; e < 48; e++) {
			let e = f(J(t, Y(n, a)));
			if (r && e < .002) return 0;
			if (i = Math.min(i, 10 * e / a), a += Math.min(Math.max(e, .02), .4), i < .002 || a > 30) break;
		}
		return r ? 1 : un(i);
	}, te = (e, t) => {
		let n = 0, r = 1;
		for (let i = 0; i < 5; i++) {
			let a = .02 + .12 * i;
			n += (a - f(J(e, Y(t, a)))) * r, r *= .75;
		}
		return un(1 - 1.6 * n);
	}, P = (t, n, r, i, a, s, c = 1) => {
		D === "clay" && (i = [
			.86,
			.84,
			.82
		]);
		let l = Math.max(X(n, C), 0);
		if (o) {
			let e = l > 0 ? l * M(J(t, Y(n, .003)), C, !0) : 0, r = Math.floor(e * o + .5) / o;
			return Y(i, E * .9 + T * .75 * r);
		}
		let u = l > 0 ? M(J(t, Y(n, .003)), C) : 0, d = te(t, n) * c, f = Z(cn(C, r)), p = Math.max(X(n, f), 0) ** a * l * u, m = .5 + .5 * n[1];
		if (D === "flat") return Y(i, .82 + .18 * l);
		if (D === "toon") {
			let t = Math.floor(l * u * e.style.bands + .5) / e.style.bands, a = (1 - Math.max(X(n, Y(r, -1)), 0)) ** 3 * .25, o = (p >= .92) * .35;
			return J(Y(i, E * .9 * c + T * .75 * t), Y(w, o + a * t));
		}
		let h = [
			Q(1, i[0], s),
			Q(1, i[1], s),
			Q(1, i[2], s)
		], g = Y(i, 1 - .6 * s), _ = Z([
			-C[0],
			.3,
			-C[2]
		]), v = Math.max(X(n, _), 0), y = (1 - Math.max(X(n, Y(r, -1)), 0)) ** 4, b = [
			0,
			0,
			0
		];
		for (let e = 0; e < 3; e++) b[e] = g[e] * w[e] * l * u * T + g[e] * [
			.72,
			.82,
			1
		][e] * E * (.25 + .75 * v) * d + g[e] * E * .45 * m * d + w[e] * y * .22 * T * d * m + h[e] * w[e] * p * T * Q(.35, 1.6, s) * (a > 60 ? 1 : .6) + g[e] * [
			1,
			.9,
			.8
		][e] * .05 * Math.max(-n[1], 0);
		return b;
	}, F = (e, t) => {
		let i = e / n * 2 - 1, a = 1 - t / r * 2, o, s;
		return b ? (o = J(h, J(Y(_, i * x * S), Y(v, a * x))), s = g) : (o = h, s = Z(J(g, J(Y(_, i * y * S), Y(v, a * y))))), R(o, s, 0);
	}, I = (e) => {
		let t = dn(-.25, .6, e[1]), n = dn(.22, .32, e[1]) * (1 - dn(.5, .62, e[1]));
		return [
			0,
			1,
			2
		].map((e) => (Q([
			.3,
			.28,
			.27
		][e], [
			.85,
			.9,
			1
		][e], t) + 1.6 * n) * (.5 + E) * w[e]);
	}, L = (e, t) => t + (1 - t) * (1 - e) ** 5, ne = (e, t) => cn(e, Y(t, 2 * X(e, t))), R = (t, n, r) => {
		let i = e.ground.on && n[1] < -1e-4 ? -t[1] / n[1] : 1e9, a = r === 0 ? O : 0, s = r ? 5e-4 : b ? 0 : .01, c = 1e9, u = !1, f = d(t);
		for (let e = 0; e < 200; e++) {
			let e = J(t, Y(n, s));
			f = d(e);
			let r = b ? j : j * Math.max(s, .01);
			if (c = Math.min(c, f.d / r), f.d < 4e-4 * Math.max(1, s)) {
				u = !0;
				break;
			}
			if (s += f.d * .92, s > 120 || s > i + .5) break;
		}
		let p = l.length ? on(l, t, n, Math.min(u && s < i + .001 ? s : Infinity, i)) : null;
		if (p?.unlit) return [...p.color, 1];
		if (p) {
			let e = J(t, Y(n, p.t)), i = p.normal, s = P(e, i, n, p.color, p.shine, p.metal, p.occ), c = 1, l = Y(n, -1), u = D === "soft" && !o, d = u && (p.clearcoat > 0 || Math.max(...p.sheen) > 0 || p.transmission > 0) ? M(J(e, Y(p.shapeNormal, .003)), C) : 1;
			if (p.transmission > 0 && D !== "clay" && !o && r < 4) {
				let t = ((p.ior - 1) / (p.ior + 1)) ** 2, a = L(Math.max(X(i, l), 0), t), o = R(J(e, Y(n, .001)), n, r + 1), u = [
					o[0] * p.color[0],
					o[1] * p.color[1],
					o[2] * p.color[2]
				], f = p.transmission * (1 - a), m = Z(J(C, l)), h = Math.max(X(i, m), 0) ** Math.max(p.shine, 60) * Math.max(X(i, C), 0) * d * T, g = I(ne(n, i));
				s = [
					0,
					1,
					2
				].map((e) => Q(s[e], u[e], f) + g[e] * a * p.transmission + w[e] * h), c = un(Q(1, o[3], f) + h + a * p.transmission);
			}
			if (u && Math.max(...p.sheen) > 0) {
				let e = (1 - Math.max(X(i, l), 0)) ** Q(5, 1.5, p.sheenRoughness), t = T * Math.max(X(i, C), 0) * d * .8;
				s = [
					0,
					1,
					2
				].map((n) => s[n] + p.sheen[n] * e * (w[n] * t + E * .6 * p.occ));
			}
			if (u && p.clearcoat > 0) {
				let e = p.coatNormal, t = L(Math.max(X(e, l), 0), .04), r = Z(J(C, l)), i = 8 + (1 - p.clearcoatRoughness) ** 2 * 600, a = Math.max(X(e, r), 0) ** i * Math.max(X(e, C), 0) * d * T * (1 + i / 120), o = Y(I(ne(n, e)), Q(1, .35, p.clearcoatRoughness));
				s = [
					0,
					1,
					2
				].map((e) => s[e] * (1 - p.clearcoat * t) + p.clearcoat * (w[e] * a + o[e] * t));
			}
			if (D !== "clay" && (s = J(s, p.emissive)), a > 0) {
				let e = dn(.12 + .02 * a, .02, Math.abs(X(i, n)));
				s = [
					Q(s[0], k[0], e),
					Q(s[1], k[1], e),
					Q(s[2], k[2], e)
				], c = Q(c, 1, e);
			}
			return [...s, c];
		}
		if (u && s < i + .001) {
			let e = J(t, Y(n, s)), r = ee(e, s), i = P(e, r, n, f.color.map((e) => e ** 2.2), f.shine, f.metal);
			if (a > 0) {
				let e = dn(.12 + .02 * a, .02, Math.abs(X(r, n)));
				i = [
					Q(i[0], k[0], e),
					Q(i[1], k[1], e),
					Q(i[2], k[2], e)
				];
			}
			return [...i, 1];
		}
		if (a > 0 && c < a) return [...k, dn(a, a * .6, c)];
		if (i < 1e8) {
			let r = J(t, Y(n, i)), a = 1 - M(J(r, [
				0,
				.002,
				0
			]), C, !!o), s = o ? 1 : Math.exp(-.08 * Math.hypot(r[0], r[2])), c = a * e.ground.shadow * s;
			return e.background.transparent ? [
				0,
				0,
				0,
				o ? c > .05 ? e.ground.shadow : 0 : c
			] : [
				A[0] * (1 - c),
				A[1] * (1 - c),
				A[2] * (1 - c),
				1
			];
		}
		return e.background.transparent ? [
			0,
			0,
			0,
			0
		] : [...A, 1];
	}, [z, re, ie, ae] = s ? [
		Math.max(0, s[0]),
		Math.max(0, s[1]),
		Math.min(n, s[2]),
		Math.min(r, s[3])
	] : [
		0,
		0,
		n,
		r
	], [B, V] = [Math.max(0, ie - z), Math.max(0, ae - re)], H = new Float32Array(B * V * 4), oe = i > 1 && !o, se = V || 1;
	for (let e = 0; e < V; e++) {
		for (let t = 0; t < B; t++) {
			let n = F(z + t + .5, re + e + .5), r = (e * B + t) * 4;
			H[r] = n[0] * n[3], H[r + 1] = n[1] * n[3], H[r + 2] = n[2] * n[3], H[r + 3] = n[3];
		}
		c && e % 16 == 15 && await c((e + 1) / se * (oe ? .75 : 1));
	}
	if (oe) {
		let e = (e, t) => Math.abs(H[e] - H[t]) + Math.abs(H[e + 1] - H[t + 1]) + Math.abs(H[e + 2] - H[t + 2]) > .06 || Math.abs(H[e + 3] - H[t + 3]) > .1, t = new Uint8Array(B * V);
		for (let n = 0; n < V; n++) for (let r = 0; r < B; r++) {
			let i = (n * B + r) * 4;
			(r + 1 < B && e(i, i + 4) || n + 1 < V && e(i, i + B * 4)) && (t[n * B + r] = 1, r + 1 < B && (t[n * B + r + 1] = 1), n + 1 < V && (t[(n + 1) * B + r] = 1));
		}
		let n = [
			[-.375, -.125],
			[.125, -.375],
			[.375, .125],
			[-.125, .375]
		], r = new Float32Array(H);
		for (let e = 0; e < V; e++) {
			for (let i = 0; i < B; i++) {
				if (!t[e * B + i]) continue;
				let a = (e * B + i) * 4;
				for (let [t, o] of n) {
					let n = F(z + i + .5 + t, re + e + .5 + o);
					r[a] += n[0] * n[3], r[a + 1] += n[1] * n[3], r[a + 2] += n[2] * n[3], r[a + 3] += n[3];
				}
				for (let e = 0; e < 4; e++) r[a + e] /= 5;
			}
			c && e % 16 == 15 && await c(.75 + (e + 1) / se * .25);
		}
		H.set(r);
	}
	let U = new Uint8ClampedArray(B * V * 4);
	for (let e = 0; e < B * V; e++) {
		let t = H[e * 4 + 3];
		t > 0 && (U[e * 4] = 255 * Math.max(0, H[e * 4] / t) ** (1 / 2.2), U[e * 4 + 1] = 255 * Math.max(0, H[e * 4 + 1] / t) ** (1 / 2.2), U[e * 4 + 2] = 255 * Math.max(0, H[e * 4 + 2] / t) ** (1 / 2.2)), U[e * 4 + 3] = 255 * t;
	}
	return {
		width: B,
		height: V,
		data: U
	};
}
//#endregion
//#region ../scene3d/src/model/vector.ts
var hn = (e, t, n) => `#${[
	e,
	t,
	n
].map((e) => e.toString(16).padStart(2, "0")).join("")}`, gn = (e) => String(Math.round(e * 10) / 10), _n = (e) => e.map((e) => `M${e.map(([e, t]) => `${gn(e)} ${gn(t)}`).join("L")}Z`).join("");
function vn(e) {
	let { width: t, height: n, data: r } = e, i = /* @__PURE__ */ new Map();
	for (let e = 0; e < t * n; e++) {
		let t = r[e * 4 + 3];
		if (t < 8) continue;
		let n = (r[e * 4] << 16 | r[e * 4 + 1] << 8 | r[e * 4 + 2]) * 256 + Math.round(t / 32);
		i.set(n, (i.get(n) ?? 0) + 1);
	}
	let a = [];
	for (let [e, o] of i) {
		if (o < 6) continue;
		let i = new Uint8Array(t * n);
		for (let a = 0; a < t * n; a++) {
			let t = r[a * 4 + 3];
			t < 8 || (r[a * 4] << 16 | r[a * 4 + 1] << 8 | r[a * 4 + 2]) * 256 + Math.round(t / 32) === e && (i[a] = 1);
		}
		let s = Math.floor(e / 256);
		a.push({
			fill: hn(s >> 16 & 255, s >> 8 & 255, s & 255),
			opacity: Math.min(1, e % 256 * 32 / 255),
			contours: _(i, t, n, .6),
			size: o
		});
	}
	return a.sort((e, t) => Number(t.opacity < 1) - Number(e.opacity < 1) || t.size - e.size).map(({ fill: e, opacity: t, contours: n }) => ({
		fill: e,
		opacity: t,
		contours: n
	}));
}
async function yn(e, t) {
	let { width: n, height: r, tones: i = 3, frame: a = 1, trim: o = 12, decodeImage: s, onProgress: c } = t, l = e.background.picture, u = vn(await pn(l ? {
		...e,
		background: {
			...e.background,
			transparent: !0,
			picture: ""
		}
	} : e, {
		width: n,
		height: r,
		tones: Math.min(6, Math.max(2, i)),
		frame: a,
		decodeImage: s,
		onProgress: c
	})).filter((e) => e.contours.length), [d, f, p, m] = [
		0,
		0,
		n,
		r
	];
	if (e.background.transparent && !l && o >= 0 && u.length) {
		let e = u.flatMap((e) => e.contours.flat()), t = e.map((e) => e[0]), i = e.map((e) => e[1]);
		d = Math.max(0, Math.floor(Math.min(...t)) - o), f = Math.max(0, Math.floor(Math.min(...i)) - o), p = Math.min(n, Math.ceil(Math.max(...t)) + o) - d, m = Math.min(r, Math.ceil(Math.max(...i)) + o) - f;
	}
	let h = u.map((e) => `<path d="${_n(e.contours)}" fill="${e.fill}"${e.opacity < 1 ? ` fill-opacity="${gn(e.opacity)}"` : ""} fill-rule="evenodd"/>`).join("\n"), g = l ? `<image href="${l}" width="${n}" height="${r}" preserveAspectRatio="xMidYMid slice"/>\n` : e.background.transparent ? "" : `<rect width="${n}" height="${r}" fill="${e.background.color}"/>\n`;
	return `<svg xmlns="http://www.w3.org/2000/svg" width="${p}" height="${m}" viewBox="${d} ${f} ${p} ${m}">\n${g}${h}\n</svg>\n`;
}
//#endregion
//#region ../scene3d/src/model/svg.ts
var bn = {
	amp: "&",
	lt: "<",
	gt: ">",
	quot: "\"",
	apos: "'"
}, xn = (e) => e.replace(/&(#x[0-9a-f]+|#\d+|\w+);/gi, (e, t) => t[0] === "#" ? String.fromCodePoint(t[1] === "x" || t[1] === "X" ? parseInt(t.slice(2), 16) : parseInt(t.slice(1), 10)) : bn[t] ?? e);
function Sn(e) {
	let t = {
		tag: "#root",
		attrs: {},
		children: [],
		text: ""
	}, n = [t], r = e.replace(/<!--[\s\S]*?-->/g, "").replace(/<\?[\s\S]*?\?>/g, "").replace(/<!DOCTYPE[^>[]*(\[[\s\S]*?\])?\s*>/gi, "").replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, (e, t) => t.replace(/</g, "&lt;")), i = /<(\/?)([\w:.-]+)((?:\s+[\w:.-]+\s*=\s*(?:"[^"]*"|'[^']*'))*)\s*(\/?)>|([^<]+)/g;
	for (let e = i.exec(r); e; e = i.exec(r)) {
		let t = n[n.length - 1];
		if (e[5] !== void 0) {
			t.text += xn(e[5]);
			continue;
		}
		let r = e[2].replace(/^svg:/, "");
		if (e[1]) {
			let e = n.map((e) => e.tag).lastIndexOf(r);
			e > 0 && (n.length = e);
			continue;
		}
		let i = {}, a = /([\w:.-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g;
		for (let t = a.exec(e[3] ?? ""); t; t = a.exec(e[3] ?? "")) i[t[1]] = xn(t[2] ?? t[3] ?? "");
		let o = {
			tag: r,
			attrs: i,
			children: [],
			text: ""
		};
		t.children.push(o), e[4] || n.push(o);
	}
	return t;
}
var Cn = {
	black: "#000000",
	white: "#ffffff",
	red: "#ff0000",
	green: "#008000",
	lime: "#00ff00",
	blue: "#0000ff",
	yellow: "#ffff00",
	cyan: "#00ffff",
	aqua: "#00ffff",
	magenta: "#ff00ff",
	fuchsia: "#ff00ff",
	gray: "#808080",
	grey: "#808080",
	silver: "#c0c0c0",
	maroon: "#800000",
	olive: "#808000",
	navy: "#000080",
	purple: "#800080",
	teal: "#008080",
	orange: "#ffa500",
	pink: "#ffc0cb",
	brown: "#a52a2a",
	gold: "#ffd700",
	indigo: "#4b0082",
	violet: "#ee82ee",
	crimson: "#dc143c",
	coral: "#ff7f50",
	salmon: "#fa8072",
	tomato: "#ff6347",
	darkred: "#8b0000",
	darkgreen: "#006400",
	darkblue: "#00008b",
	lightblue: "#add8e6",
	lightgray: "#d3d3d3",
	lightgrey: "#d3d3d3",
	darkgray: "#a9a9a9",
	darkgrey: "#a9a9a9",
	beige: "#f5f5dc",
	khaki: "#f0e68c",
	turquoise: "#40e0d0",
	skyblue: "#87ceeb",
	royalblue: "#4169e1",
	steelblue: "#4682b4",
	hotpink: "#ff69b4",
	deeppink: "#ff1493",
	orchid: "#da70d6",
	plum: "#dda0dd",
	tan: "#d2b48c",
	chocolate: "#d2691e",
	sienna: "#a0522d",
	forestgreen: "#228b22",
	seagreen: "#2e8b57",
	limegreen: "#32cd32",
	dodgerblue: "#1e90ff",
	slategray: "#708090",
	slategrey: "#708090",
	whitesmoke: "#f5f5f5",
	ivory: "#fffff0",
	lavender: "#e6e6fa"
};
function wn(e, t) {
	if (e === void 0) return;
	let n = e.trim().toLowerCase();
	if (!n || n === "none" || n === "transparent") return null;
	if (n === "currentcolor") return t;
	if (Cn[n]) return Cn[n];
	let r = /^#([0-9a-f]{3,4})$/.exec(n);
	if (r) return `#${[...r[1].slice(0, 3)].map((e) => e + e).join("")}`;
	if (r = /^#([0-9a-f]{6})([0-9a-f]{2})?$/.exec(n), r) return `#${r[1]}`;
	if (r = /^rgba?\(\s*([\d.]+)(%?)[\s,]+([\d.]+)(%?)[\s,]+([\d.]+)(%?)/.exec(n), r) {
		let e = (e, t) => Math.round(Math.min(255, Math.max(0, t ? Number(e) / 100 * 255 : Number(e))));
		return `#${[
			e(r[1], r[2]),
			e(r[3], r[4]),
			e(r[5], r[6])
		].map((e) => e.toString(16).padStart(2, "0")).join("")}`;
	}
}
var Tn = (e) => [
	1,
	3,
	5
].map((t) => parseInt(e.slice(t, t + 2), 16)), En = (e, t) => {
	let [n, r] = [Tn(e), Tn(t)];
	return (n[0] - r[0]) ** 2 + (n[1] - r[1]) ** 2 + (n[2] - r[2]) ** 2;
};
function Dn(e) {
	let [t, n, r] = Tn(e).map((e) => e / 255), i = Math.max(t, n, r), a = Math.min(t, n, r), o = (i + a) / 2;
	if ((i === a ? 0 : (i - a) / (1 - Math.abs(2 * o - 1))) < .15 || i - a < .08) return o > .9 ? "White" : o < .12 ? "Black" : "Grey";
	let s = 0;
	return s = i === t ? ((n - r) / (i - a) + 6) % 6 : i === n ? (r - t) / (i - a) + 2 : (t - n) / (i - a) + 4, s *= 60, s < 15 || s >= 345 ? o > .75 ? "Pink" : "Red" : s < 45 ? o < .4 ? "Brown" : "Orange" : s < 70 ? "Yellow" : s < 160 ? "Green" : s < 195 ? "Teal" : s < 255 ? "Blue" : s < 290 ? "Purple" : "Pink";
}
var On = [
	1,
	0,
	0,
	1,
	0,
	0
], kn = (e, t) => [
	e[0] * t[0] + e[2] * t[1],
	e[1] * t[0] + e[3] * t[1],
	e[0] * t[2] + e[2] * t[3],
	e[1] * t[2] + e[3] * t[3],
	e[0] * t[4] + e[2] * t[5] + e[4],
	e[1] * t[4] + e[3] * t[5] + e[5]
], An = (e, [t, n]) => [e[0] * t + e[2] * n + e[4], e[1] * t + e[3] * n + e[5]], jn = (e) => (e.match(/[-+]?(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?/gi) ?? []).map(Number);
function Mn(e) {
	let t = On;
	if (!e) return t;
	let n = /(matrix|translate|scale|rotate|skewX|skewY)\s*\(([^)]*)\)/g;
	for (let r = n.exec(e); r; r = n.exec(e)) {
		let e = jn(r[2]), n = (e[0] ?? 0) * Math.PI / 180, i = On;
		if (r[1] === "matrix" && e.length >= 6) i = e.slice(0, 6);
		else if (r[1] === "translate") i = [
			1,
			0,
			0,
			1,
			e[0] ?? 0,
			e[1] ?? 0
		];
		else if (r[1] === "scale") i = [
			e[0] ?? 1,
			0,
			0,
			e[1] ?? e[0] ?? 1,
			0,
			0
		];
		else if (r[1] === "rotate") {
			let [t, r] = [Math.cos(n), Math.sin(n)], [a, o] = [e[1] ?? 0, e[2] ?? 0];
			i = kn(kn([
				1,
				0,
				0,
				1,
				a,
				o
			], [
				t,
				r,
				-r,
				t,
				0,
				0
			]), [
				1,
				0,
				0,
				1,
				-a,
				-o
			]);
		} else r[1] === "skewX" ? i = [
			1,
			0,
			Math.tan(n),
			1,
			0,
			0
		] : r[1] === "skewY" && (i = [
			1,
			Math.tan(n),
			0,
			1,
			0,
			0
		]);
		t = kn(t, i);
	}
	return t;
}
function Nn(e) {
	let t = [], n = /([MLHVCSQTAZmlhvcsqtaz])|([-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?)/g, r = "", i = 0;
	for (let a = n.exec(e); a; a = n.exec(e)) a[1] ? (t.push(a[1]), r = a[1].toLowerCase(), i = 0) : (r === "a" && (i % 7 == 3 || i % 7 == 4) && /^[01]./.test(a[2]) ? (t.push(Number(a[2][0])), n.lastIndex = a.index + 1) : t.push(Number(a[2])), i++);
	return t;
}
function Pn(e, t, n, r, i, a, o) {
	if (t === 0 || n === 0 || e[0] === o[0] && e[1] === o[1]) return e[0] === o[0] && e[1] === o[1] ? [] : [[
		e,
		o,
		o
	]];
	t = Math.abs(t), n = Math.abs(n);
	let [s, c] = [Math.cos(r), Math.sin(r)], l = (e[0] - o[0]) / 2, u = (e[1] - o[1]) / 2, d = s * l + c * u, f = -c * l + s * u, p = d * d / (t * t) + f * f / (n * n);
	p > 1 && (t *= Math.sqrt(p), n *= Math.sqrt(p));
	let m = t * t * n * n - t * t * f * f - n * n * d * d, h = t * t * f * f + n * n * d * d, g = (i === a ? -1 : 1) * Math.sqrt(Math.max(0, m / h)), _ = g * t * f / n, v = -g * n * d / t, y = s * _ - c * v + (e[0] + o[0]) / 2, b = c * _ + s * v + (e[1] + o[1]) / 2, x = (e, t, n, r) => Math.atan2(e * r - t * n, e * n + t * r), S = x(1, 0, (d - _) / t, (f - v) / n), C = x((d - _) / t, (f - v) / n, (-d - _) / t, (-f - v) / n);
	!a && C > 0 ? C -= 2 * Math.PI : a && C < 0 && (C += 2 * Math.PI);
	let w = Math.max(1, Math.ceil(Math.abs(C) / (Math.PI / 2) - 1e-9)), T = C / w, E = 4 / 3 * Math.tan(T / 4), D = (e) => [y + t * Math.cos(e) * s - n * Math.sin(e) * c, b + t * Math.cos(e) * c + n * Math.sin(e) * s], O = (e) => [-t * Math.sin(e) * s - n * Math.cos(e) * c, -t * Math.sin(e) * c + n * Math.cos(e) * s], k = [];
	for (let e = 0; e < w; e++) {
		let t = S + e * T, n = t + T, [r, i, a, s] = [
			D(t),
			e === w - 1 ? o : D(n),
			O(t),
			O(n)
		];
		k.push([
			[r[0] + E * a[0], r[1] + E * a[1]],
			[i[0] - E * s[0], i[1] - E * s[1]],
			i
		]);
	}
	return k;
}
function Fn(e) {
	let t = Nn(e), n = [], r = null, i = [0, 0], a = null, o = null, s = 0, c = "", l = () => {
		let e = t[s++];
		return typeof e == "number" ? e : NaN;
	}, u = (e) => {
		r.pieces.push([
			i,
			e,
			e
		]), i = e;
	};
	for (; s < t.length;) {
		if (typeof t[s] == "string") c = t[s++];
		else if (!c) {
			s++;
			continue;
		}
		let e = c === c.toLowerCase(), d = c.toUpperCase(), f = e ? i : [0, 0], p = () => {
			let e = l(), t = l();
			return [f[0] + e, f[1] + t];
		};
		if (d === "Z") {
			r && ((i[0] !== r.start[0] || i[1] !== r.start[1]) && u(r.start), i = r.start), r = null, a = o = null, c = "";
			continue;
		}
		if (d === "M") {
			let t = p();
			if ([...t].some(Number.isNaN)) break;
			r = {
				start: t,
				pieces: []
			}, n.push(r), i = t, c = e ? "l" : "L", a = o = null;
			continue;
		}
		r || (r = {
			start: i,
			pieces: []
		}, n.push(r));
		let m = null, h = null;
		if (d === "L") {
			let e = p();
			if ([...e].some(Number.isNaN)) break;
			u(e);
		} else if (d === "H") {
			let t = l();
			if (Number.isNaN(t)) break;
			u([e ? i[0] + t : t, i[1]]);
		} else if (d === "V") {
			let t = l();
			if (Number.isNaN(t)) break;
			u([i[0], e ? i[1] + t : t]);
		} else if (d === "C" || d === "S") {
			let e = d === "C" ? p() : a ? [2 * i[0] - a[0], 2 * i[1] - a[1]] : i, t = p(), n = p();
			if ([
				...e,
				...t,
				...n
			].some(Number.isNaN)) break;
			r.pieces.push([
				e,
				t,
				n
			]), i = n, m = t;
		} else if (d === "Q" || d === "T") {
			let e = d === "Q" ? p() : o ? [2 * i[0] - o[0], 2 * i[1] - o[1]] : i, t = p();
			if ([...e, ...t].some(Number.isNaN)) break;
			r.pieces.push([
				[i[0] + 2 / 3 * (e[0] - i[0]), i[1] + 2 / 3 * (e[1] - i[1])],
				[t[0] + 2 / 3 * (e[0] - t[0]), t[1] + 2 / 3 * (e[1] - t[1])],
				t
			]), i = t, h = e;
		} else if (d === "A") {
			let [e, t, n, a, o] = [
				l(),
				l(),
				l(),
				l(),
				l()
			], s = p();
			if ([
				e,
				t,
				n,
				a,
				o,
				...s
			].some(Number.isNaN)) break;
			r.pieces.push(...Pn(i, e, t, n * Math.PI / 180, !!a, !!o, s)), i = s;
		} else {
			s++;
			continue;
		}
		a = m, o = h;
	}
	return n;
}
var In = (e) => {
	let t = {};
	for (let n of e.split(";")) {
		let e = n.indexOf(":");
		e > 0 && (t[n.slice(0, e).trim().toLowerCase()] = n.slice(e + 1).replace(/!important/i, "").trim());
	}
	return t;
};
function Ln(e) {
	let t = [], n = e.replace(/\/\*[\s\S]*?\*\//g, ""), r = /([^{}]+)\{([^}]*)\}/g;
	for (let e = r.exec(n); e; e = r.exec(n)) {
		let n = In(e[2]);
		for (let r of e[1].split(",")) r.trim() && !r.includes("@") && t.push({
			selector: r.trim(),
			decls: n
		});
	}
	return t;
}
function Rn(e, t) {
	if (/[\s>+~[:*]/.test(e)) return !1;
	let n = /^([\w-]*)((?:[.#][\w-]+)*)$/.exec(e);
	if (!n || n[1] && n[1] !== t.tag) return !1;
	let r = (t.attrs.class ?? "").split(/\s+/);
	for (let e of n[2].match(/[.#][\w-]+/g) ?? []) if (e[0] === "." && !r.includes(e.slice(1)) || e[0] === "#" && t.attrs.id !== e.slice(1)) return !1;
	return !0;
}
var zn = /* @__PURE__ */ new Set([
	"defs",
	"clipPath",
	"mask",
	"symbol",
	"marker",
	"pattern",
	"metadata",
	"title",
	"desc",
	"style",
	"script",
	"filter",
	"linearGradient",
	"radialGradient",
	"foreignObject"
]);
function Bn(e, t, n) {
	let r = [An(t, e.start)], i = e.start;
	for (let [a, o, s] of e.pieces) {
		let e = a[0] === i[0] && a[1] === i[1] && o[0] === s[0] && o[1] === s[1] || a[0] === s[0] && a[1] === s[1] && o[0] === s[0] && o[1] === s[1], c = Math.hypot(a[0] - i[0], a[1] - i[1]) + Math.hypot(o[0] - a[0], o[1] - a[1]) + Math.hypot(s[0] - o[0], s[1] - o[1]), l = e ? 1 : Math.min(64, Math.max(2, Math.ceil(c / n)));
		for (let e = 1; e <= l; e++) {
			let n = e / l, c = 1 - n, u = c * c * c * i[0] + 3 * c * c * n * a[0] + 3 * c * n * n * o[0] + n * n * n * s[0], d = c * c * c * i[1] + 3 * c * c * n * a[1] + 3 * c * n * n * o[1] + n * n * n * s[1];
			r.push(An(t, [u, d]));
		}
		i = s;
	}
	return r;
}
var Vn = (e) => {
	let t = e.attrs, n = (e, n = 0) => {
		let r = parseFloat(t[e] ?? "");
		return Number.isFinite(r) ? r : n;
	};
	if (e.tag === "path") return t.d ?? null;
	if (e.tag === "rect") {
		let [e, r, i, a] = [
			n("x"),
			n("y"),
			n("width"),
			n("height")
		];
		if (i <= 0 || a <= 0) return null;
		let o = t.rx === void 0 ? t.ry === void 0 ? 0 : n("ry") : n("rx"), s = t.ry === void 0 ? o : n("ry");
		return o = Math.min(Math.max(0, o), i / 2), s = Math.min(Math.max(0, s), a / 2), !o || !s ? `M${e} ${r}H${e + i}V${r + a}H${e}Z` : `M${e + o} ${r}H${e + i - o}A${o} ${s} 0 0 1 ${e + i} ${r + s}V${r + a - s}A${o} ${s} 0 0 1 ${e + i - o} ${r + a}H${e + o}A${o} ${s} 0 0 1 ${e} ${r + a - s}V${r + s}A${o} ${s} 0 0 1 ${e + o} ${r}Z`;
	}
	if (e.tag === "circle" || e.tag === "ellipse") {
		let [t, r] = [n("cx"), n("cy")], i = e.tag === "circle" ? n("r") : n("rx"), a = e.tag === "circle" ? n("r") : n("ry");
		return i <= 0 || a <= 0 ? null : `M${t - i} ${r}A${i} ${a} 0 1 0 ${t + i} ${r}A${i} ${a} 0 1 0 ${t - i} ${r}Z`;
	}
	if (e.tag === "polygon" || e.tag === "polyline") {
		let e = jn(t.points ?? "");
		return e.length < 6 ? null : `M${e.slice(0, 2).join(" ")}L${e.slice(2, e.length - e.length % 2).join(" ")}Z`;
	}
	return null;
};
function Hn(e, t) {
	let n = /* @__PURE__ */ new Map(), r = [], i = (e) => {
		e.attrs.id && n.set(e.attrs.id, e), e.tag === "style" && r.push(e.text), e.children.forEach(i);
	};
	i(e);
	let a = Ln(r.join("\n")), o = /* @__PURE__ */ new Map(), s = (e, t = 0) => {
		let r = e.children.filter((e) => e.tag === "stop");
		if (!r.length) {
			let r = (e.attrs.href ?? e.attrs["xlink:href"] ?? "").replace(/^#/, ""), i = n.get(r);
			return i && t < 4 ? s(i, t + 1) : null;
		}
		let i = r[Math.floor((r.length - 1) / 2)];
		return wn({ ...In(i.attrs.style ?? "") }["stop-color"] ?? i.attrs["stop-color"] ?? "black", "#000000") ?? null;
	};
	for (let [e, t] of n) (t.tag === "linearGradient" || t.tag === "radialGradient") && o.set(e, s(t) ?? "#000000");
	let c = [], l = [], u = (e) => {
		let t = {};
		for (let n of [
			"fill",
			"fill-rule",
			"stroke",
			"stroke-width",
			"color",
			"display",
			"visibility",
			"opacity",
			"fill-opacity"
		]) e.attrs[n] !== void 0 && (t[n] = e.attrs[n]);
		for (let n of a) Rn(n.selector, e) && Object.assign(t, n.decls);
		return Object.assign(t, In(e.attrs.style ?? "")), t;
	}, d = (e, r, i, a) => {
		if (a > 40 || zn.has(e.tag)) return;
		let s = u(e);
		if (s.display === "none") return;
		let c = wn(s.color, i.color) ?? i.color, f = i.fill;
		if (s.fill !== void 0) {
			let e = /url\(\s*['"]?#([^'")]+)['"]?\s*\)/.exec(s.fill);
			if (e) f = o.get(e[1]) ?? null;
			else {
				let e = wn(s.fill, c);
				e !== void 0 && (f = e);
			}
		}
		(Number(s.opacity) === 0 || Number(s["fill-opacity"]) === 0) && (f = null);
		let p = {
			fill: f,
			color: c,
			evenOdd: s["fill-rule"] === void 0 ? i.evenOdd : s["fill-rule"].trim() === "evenodd",
			stroked: s.stroke === void 0 ? i.stroked : wn(s.stroke, c) !== null && parseFloat(s["stroke-width"] ?? "1") !== 0
		}, m = kn(r, Mn(e.attrs.transform));
		if (e.tag === "svg" && a > 1 && (m = kn(m, [
			1,
			0,
			0,
			1,
			parseFloat(e.attrs.x ?? "0") || 0,
			parseFloat(e.attrs.y ?? "0") || 0
		])), e.tag === "text") t.add("Text in the file was left out: turn it into outlines in your drawing app (Create outlines), then import again.");
		else if (e.tag === "image") t.add("Pictures inside the file were left out; only its vector shapes are read.");
		else if (e.tag === "line") p.stroked && t.add("Lines drawn as strokes were left out: outline the strokes in your drawing app first.");
		else if (e.tag === "use") {
			let t = n.get((e.attrs.href ?? e.attrs["xlink:href"] ?? "").replace(/^#/, ""));
			if (!t) return;
			let r = kn(m, [
				1,
				0,
				0,
				1,
				parseFloat(e.attrs.x ?? "0") || 0,
				parseFloat(e.attrs.y ?? "0") || 0
			]), i = t.tag === "symbol" ? {
				...t,
				tag: "g"
			} : t;
			d(i, r, p, a + 1);
		} else if (Vn(e) !== null) p.stroked && t.add("Strokes (outlines drawn as lines) were left out: outline them in your drawing app to keep them."), p.fill && s.visibility !== "hidden" && l.push({
			node: e,
			m,
			style: p
		});
		else for (let t of e.children) d(t, m, p, a + 1);
	};
	d(e, On, {
		fill: "#000000",
		color: "#000000",
		evenOdd: !1,
		stroked: !1
	}, 0);
	let f = l.map((e) => ({
		...e,
		subs: Fn(Vn(e.node))
	})), [p, m, h, g] = [
		Infinity,
		Infinity,
		-Infinity,
		-Infinity
	];
	for (let e of f) for (let t of e.subs) for (let n of [t.start, ...t.pieces.flat()]) {
		let [t, r] = An(e.m, n);
		[p, m, h, g] = [
			Math.min(p, t),
			Math.min(m, r),
			Math.max(h, t),
			Math.max(g, r)
		];
	}
	let _ = Math.max(h - p, g - m);
	if (!Number.isFinite(_) || _ <= 0) return c;
	let v = (function e(t) {
		return t.tag === "svg" ? t : t.children.reduce((t, n) => t ?? e(n), null);
	})(e), y = jn(v?.attrs.viewBox ?? ""), b = y.length === 4 ? [
		y[0],
		y[1],
		y[2],
		y[3]
	] : v?.attrs.width && v.attrs.height && !/%/.test(v.attrs.width + v.attrs.height) ? [
		0,
		0,
		parseFloat(v.attrs.width),
		parseFloat(v.attrs.height)
	] : null;
	if (b && f.length > 1) {
		let e = f[0], n = e.subs.flatMap((t) => Bn(t, e.m, _ / 50)), r = n.map((e) => e[0]), i = n.map((e) => e[1]), [a, o, s, c] = [
			Math.min(...r),
			Math.max(...r),
			Math.min(...i),
			Math.max(...i)
		], l = (e, t) => Math.abs(e - t) <= Math.max(b[2], b[3]) * .01, u = l(a, b[0]) && l(s, b[1]) && l(o, b[0] + b[2]) && l(c, b[1] + b[3]), d = Math.abs(n.reduce((e, t, r) => e + t[0] * n[(r + 1) % n.length][1] - n[(r + 1) % n.length][0] * t[1], 0) / 2), p = Math.min(...Tn(e.style.fill)) >= 235;
		u && p && e.subs.length === 1 && d >= (o - a) * (c - s) * .99 && (f.shift(), t.add("The drawing’s background rectangle was left out, so only the logo itself becomes 3D."));
	}
	for (let e of f) {
		let t = Math.sqrt(Math.abs(e.m[0] * e.m[3] - e.m[1] * e.m[2])) || 1, n = e.subs.map((n) => Bn(n, e.m, _ / 400 / t)).filter((e) => e.length >= 3);
		n.length && c.push({
			colour: e.style.fill,
			evenOdd: e.style.evenOdd,
			polygons: n
		});
	}
	return c;
}
function Un(e, t, n, r, i, a) {
	let o = [], s = Infinity, c = -Infinity;
	for (let e of r) for (let t = 0; t < e.length; t++) {
		let n = e[t], r = e[(t + 1) % e.length];
		if (n[1] === r[1]) continue;
		let i = r[1] > n[1] ? 1 : -1, [a, l] = i > 0 ? [n, r] : [r, n];
		o.push({
			x0: a[0],
			y0: a[1],
			x1: l[0],
			y1: l[1],
			dir: i
		}), s = Math.min(s, a[1]), c = Math.max(c, l[1]);
	}
	if (!o.length) return;
	o.sort((e, t) => e.y0 - t.y0);
	let l = [], u = 0, d = [], f = Math.max(0, Math.floor(s - .5)), p = Math.min(n - 1, Math.ceil(c));
	for (let n = f; n <= p; n++) {
		let r = n + .5;
		for (; u < o.length && o[u].y0 <= r;) l.push(o[u++]);
		for (let e = l.length - 1; e >= 0; e--) l[e].y1 <= r && l.splice(e, 1);
		d.length = 0;
		for (let e of l) e.y0 <= r && e.y1 > r && d.push({
			x: e.x0 + (r - e.y0) / (e.y1 - e.y0) * (e.x1 - e.x0),
			dir: e.dir
		});
		d.sort((e, t) => e.x - t.x);
		let s = 0;
		for (let r = 0; r + 1 < d.length; r++) {
			if (s += i ? 1 : d[r].dir, !(i ? s % 2 == 1 : s !== 0)) continue;
			let o = Math.max(0, Math.ceil(d[r].x - .5)), c = Math.min(t - 1, Math.floor(d[r + 1].x - .5));
			e.fill(a, n * t + o, n * t + c + 1);
		}
	}
}
var Wn = 4, Gn = 64;
function Kn(e, t = {}) {
	let n = Math.max(1, t.maxParts ?? 16), r = /* @__PURE__ */ new Set(), i = Sn(e);
	if (!i.children.some(function e(t) {
		return t.tag === "svg" || t.children.some(e);
	})) throw Error("That file is not an SVG drawing.");
	let a = Hn(i, r);
	if (!a.length) throw Error("The SVG has no filled shapes to push out (only lines, text or pictures).");
	let [o, s, c, l] = [
		Infinity,
		Infinity,
		-Infinity,
		-Infinity
	];
	for (let e of a) for (let t of e.polygons) for (let [e, n] of t) [o, s, c, l] = [
		Math.min(o, e),
		Math.min(s, n),
		Math.max(c, e),
		Math.max(l, n)
	];
	let u = 1020 / Math.max(c - o, l - s), d = Math.max(8, Math.ceil((c - o) * u) + 4), f = Math.max(8, Math.ceil((l - s) * u) + 4), [p, m] = [d * Wn, f * Wn], h = new Uint8Array(p * m).fill(255), g = [], b = (e) => {
		let t = g.indexOf(e);
		return t < 0 && g.length < 254 && (t = g.push(e) - 1), t < 0 && (t = g.reduce((t, n, r) => En(n, e) < En(g[t], e) ? r : t, 0)), t;
	};
	for (let e of a) Un(h, p, m, e.polygons.map((e) => e.map(([e, t]) => [((e - o) * u + 2) * Wn, ((t - s) * u + 2) * Wn])), e.evenOdd, b(e.colour));
	let x = g.map(() => null), S = g.map(() => 0);
	for (let e = 0; e < m; e++) {
		let t = e / Wn | 0;
		for (let n = 0; n < p; n++) {
			let r = h[e * p + n];
			if (r === 255) continue;
			let i = x[r] ??= new Uint8Array(d * f), a = t * d + (n / Wn | 0);
			i[a] = i[a] + 1, S[r] = S[r] + 1;
		}
	}
	let C = g.map((e, t) => t).filter((e) => S[e] > 0), w = p * m * 2e-4, T = (e) => {
		let t = C.filter((t) => t !== e);
		if (!t.length) return;
		let n = t.reduce((t, n) => En(g[n], g[e]) < En(g[t], g[e]) ? n : t, t[0]), [r, i] = [x[n], x[e]];
		for (let e = 0; e < r.length; e++) r[e] = r[e] + i[e];
		S[n] = S[n] + S[e], C.splice(C.indexOf(e), 1);
	};
	for (;;) {
		let e = C.reduce((e, t) => S[t] < S[e] ? t : e, C[0]);
		if (C.length > n) r.add(`The drawing has more colours than fit; the smallest were joined to the nearest colour (${n} parts).`), T(e);
		else if (C.length > 1 && S[e] < w) T(e);
		else break;
	}
	let E = [];
	for (let e of C) {
		let t = x[e], n = new Uint8Array(d * f), i = new Float32Array(d * f);
		for (let e = 0; e < t.length; e++) n[e] = +(t[e] * 2 >= 16), i[e] = Math.min(1, t[e] / 16);
		let a = _(n, d, f, .35, i).filter((e) => Math.abs(y(e)) > d * f / 4e4).map((e) => {
			let t = .7;
			for (; e.length > 1800 && t < 8;) e = v(e, t), t *= 2;
			return e;
		});
		a.length > Gn && (r.add("Some of the tiniest details were left out: one colour holds at most 64 separate pieces."), a = [...a].sort((e, t) => Math.abs(y(t)) - Math.abs(y(e))).slice(0, Gn)), a.length && E.push({
			colour: g[e],
			contours: a
		});
	}
	if (!E.length) throw Error("The SVG’s shapes are too small to push out.");
	let [D, O, k, A] = [
		Infinity,
		Infinity,
		-Infinity,
		-Infinity
	];
	for (let e of E) for (let t of e.contours) for (let [e, n] of t) [D, O, k, A] = [
		Math.min(D, e),
		Math.min(O, n),
		Math.max(k, e),
		Math.max(A, n)
	];
	let j = Math.max(k - D, A - O), [ee, M] = [(D + k) / 2, (O + A) / 2], N = /* @__PURE__ */ new Map();
	return {
		parts: E.map((e) => {
			let t = e.contours.flat(), n = t.map((e) => e[0]), r = t.map((e) => e[1]), [i, a, o, s] = [
				Math.min(...n),
				Math.max(...n),
				Math.min(...r),
				Math.max(...r)
			], c = Ue(e.contours.map((e) => e.map(([e, t]) => [e, -t]))), l = Dn(e.colour), u = (N.get(l) ?? 0) + 1;
			return N.set(l, u), {
				name: u > 1 ? `${l} ${u}` : l,
				color: e.colour,
				outline: c.outline,
				aspect: c.aspect,
				box: {
					x: ((i + a) / 2 - ee) / j,
					y: -((o + s) / 2 - M) / j,
					w: (a - i) / j,
					h: (s - o) / j
				}
			};
		}),
		aspect: (k - D) / (A - O),
		warnings: [...r]
	};
}
//#endregion
//#region ../scene3d/src/model/ad.ts
var qn = {
	podium: "Podium",
	burst: "Starburst",
	shelf: "Shop shelf"
}, Jn = {
	blossom: {
		label: "Blossom",
		colours: {
			background: "#fde8ef",
			main: "#ffffff",
			accent: "#ff4d8d",
			text: "#2b1d3a",
			priceText: "#ffffff"
		}
	},
	night: {
		label: "Night",
		colours: {
			background: "#141826",
			main: "#2a3150",
			accent: "#ffd23f",
			text: "#ffffff",
			priceText: "#141826"
		}
	},
	mint: {
		label: "Mint",
		colours: {
			background: "#e6f6ef",
			main: "#ffffff",
			accent: "#00a37a",
			text: "#10302a",
			priceText: "#ffffff"
		}
	},
	sunset: {
		label: "Sunset",
		colours: {
			background: "#fff1e0",
			main: "#ffcf99",
			accent: "#ff5a36",
			text: "#3a1a0b",
			priceText: "#ffffff"
		}
	},
	studio: {
		label: "Studio grey",
		colours: {
			background: "#eceef1",
			main: "#ffffff",
			accent: "#1f2937",
			text: "#1f2937",
			priceText: "#ffffff"
		}
	}
};
function Yn(e) {
	let t = e.replace(/\s+/g, " ").trim();
	if (t.length <= 18 || t.includes("\n")) return t;
	let n = t.length / 2, r = -1;
	for (let e = 0; e < t.length; e++) t[e] === " " && (r < 0 || Math.abs(e - n) < Math.abs(r - n)) && (r = e);
	return r < 0 ? t : `${t.slice(0, r)}\n${t.slice(r + 1)}`;
}
var Xn = (e) => ({
	...oe,
	...e
});
function Zn(e, t) {
	return Array.from({ length: e * 2 }, (n, r) => {
		let i = Math.PI / 2 + r / (e * 2) * Math.PI * 2, a = r % 2 ? .5 * t : .5;
		return [Math.cos(i) * a, Math.sin(i) * a];
	});
}
function Qn(e, t, n, r, i, a, o = .22) {
	let s = e(t);
	if (!s) return null;
	let c = Math.min(i, r / s.aspect);
	return W("text", 0, {
		name: t.value.replace(/\s+/g, " ").slice(0, 30),
		text: t,
		outline: s.outline,
		size: [
			c * s.aspect,
			c,
			o
		],
		position: n,
		color: a,
		finish: "satin",
		round: .06
	});
}
function $n(e, t = 1) {
	let n = e.colours, r = e.font ?? "Arial", i = e.moving !== !1, a = [], o = {}, s = e.picture?.aspect ?? .75, c = Math.min(2.2, 2.8 / s), l = c * s, u = e.style === "podium" ? .4 : e.style === "shelf" ? .95 : 0, d = e.style === "shelf" ? .1 : 0;
	e.style === "podium" && a.push(W("cylinder", 0, {
		name: "Podium",
		size: [
			Math.max(2.2, l + .6),
			u,
			Math.max(2.2, l + .6)
		],
		position: [
			0,
			u / 2,
			0
		],
		color: n.main,
		finish: "satin",
		round: .08
	})), e.style === "burst" && a.push(W("extrude", 0, {
		name: "Starburst",
		outline: [Zn(16, .78)],
		size: [
			c * 1.75,
			c * 1.75,
			.15
		],
		position: [
			0,
			c * .6,
			-.7
		],
		color: n.accent,
		finish: "satin",
		round: .04,
		...i ? { motion: Xn({
			kind: "spin",
			axis: "z",
			times: 1
		}) } : {}
	})), e.style === "shelf" && a.push(W("box", 0, {
		name: "Back panel",
		size: [
			5.4,
			3.9,
			.2
		],
		position: [
			0,
			1.95,
			-.9
		],
		color: n.main,
		finish: "matte",
		round: .03
	}), W("box", 0, {
		name: "Shelf",
		size: [
			4.6,
			.14,
			1.3
		],
		position: [
			0,
			u - .07,
			-.2
		],
		color: n.accent,
		finish: "satin",
		round: .05
	}));
	let f = null;
	if (e.picture) {
		let t = Le();
		o[t] = e.picture.asset, f = W("mesh", 0, {
			name: "Product photo",
			asset: t,
			ownColors: !0,
			size: [
				l,
				c,
				.01
			],
			position: [
				0,
				u + c / 2,
				d
			],
			...i ? { motion: Xn({
				kind: "float",
				amount: .12,
				times: 1
			}) } : {}
		}), a.push(f);
	}
	let p = u + c + .25, m = e.headline?.trim() ? Qn(e.text, {
		value: Yn(e.headline),
		font: r,
		weight: 900,
		align: "center",
		lineHeight: 1
	}, [
		0,
		0,
		.1
	], 4.6, 1.1, n.text, .26) : null;
	m && (m.position = [
		0,
		p + m.size[1] / 2,
		-.15
	], i && (m.motion = Xn({
		kind: "pop",
		delay: .05
	})), p += m.size[1] + .12, a.push(m));
	let h = e.tagline?.trim() ? Qn(e.text, {
		value: e.tagline.trim().toUpperCase(),
		font: r,
		weight: 700,
		spacing: .08
	}, [
		0,
		0,
		0
	], 3.6, .3, n.text, .12) : null;
	h && (h.position = [
		0,
		p + h.size[1] / 2,
		-.15
	], i && (h.motion = Xn({
		kind: "pop",
		delay: 0
	})), p += h.size[1], a.push(h));
	let g = a.find((e) => e.name === "Back panel");
	if (g) {
		let e = Math.max(3.9, p + .35);
		g.size = [
			Math.max(5.4, (m?.size[0] ?? 0) + .8),
			e,
			g.size[2]
		], g.position = [
			0,
			e / 2,
			g.position[2]
		];
	}
	if (e.price?.trim()) {
		let t = l / 2 + .55, o = u + c * .32, s = 1.15, d = e.style === "shelf" ? W("box", 0, {
			name: "Price tag",
			size: [
				1.3,
				.75,
				.12
			],
			round: .35
		}) : W("extrude", 0, {
			name: "Price badge",
			outline: [Zn(14, .84)],
			size: [
				s,
				s,
				.14
			],
			round: .05
		});
		Object.assign(d, {
			position: [
				t,
				o,
				.55
			],
			rotation: [
				0,
				0,
				-10
			],
			color: n.accent,
			finish: "glossy"
		});
		let f = Qn(e.text, {
			value: e.price.trim(),
			font: r,
			weight: 900
		}, [
			t,
			o,
			.65
		], d.size[0] * .68, d.size[1] * .42, n.priceText, .08);
		f && (f.rotation = [
			0,
			0,
			-10
		], a.push(W("group", 0, {
			name: "Price",
			children: [d, f],
			combine: "add",
			blend: 0,
			...i ? { motion: Xn({
				kind: "pulse",
				amount: .35,
				times: 2
			}) } : {}
		})));
	}
	let _ = new ct({
		...Re(),
		shapes: a,
		assets: o,
		background: {
			transparent: !1,
			color: n.background,
			picture: ""
		},
		ground: {
			on: !0,
			shadow: .45
		},
		light: {
			azimuth: -30,
			elevation: 48,
			intensity: 1.35,
			ambient: .45,
			color: "#ffffff",
			shadows: !0
		},
		camera: {
			yaw: 12,
			pitch: 10,
			distance: 8,
			target: [
				0,
				1.6,
				0
			],
			fov: 30,
			projection: "perspective"
		}
	});
	if (e.logo?.parts.length) {
		let t = ut(e.logo, {
			long: 1,
			depth: .12,
			at: [-(l / 2 + .75), .9]
		});
		t.length === 1 && (t[0].name = "Logo"), _.addShapes(t, "Logo", "Logo");
	}
	return er(_, t), _.document;
}
function er(e, t) {
	let n = F(e.document.shapes.filter((e) => !e.hidden));
	if (!n) return e.frameAll(t);
	let r = e.document.camera, i = [
		0,
		1,
		2
	].map((e) => (n.max[e] - n.min[e]) / 2), a = Math.tan(r.fov * Math.PI / 360), o = Math.max(i[1], i[0] / Math.max(.1, t)) / a * 1.12 + i[2];
	e.setCamera({
		target: n.min.map((e, t) => (e + n.max[t]) / 2),
		distance: o
	});
}
//#endregion
//#region ../scene3d/src/model/core.ts
var tr = /* @__PURE__ */ e({
	AD_PALETTES: () => Jn,
	AD_STYLES: () => qn,
	ALL_KINDS: () => Ee,
	COMBINE: () => De,
	DEFAULT_MOTION: () => oe,
	FIELD_RANGE: () => 24,
	FIELD_SIZE: () => 256,
	FINISH: () => j,
	FINISHES: () => Oe,
	LOOKS: () => ke,
	MAX_ASSETS_CHARS: () => Me,
	MAX_ASSET_CHARS: () => je,
	MAX_FIELDS: () => 16,
	MAX_MESHES: () => 16,
	MAX_PICTURE_CHARS: () => $e,
	MAX_SHAPES: () => 48,
	MAX_TRIANGLES: () => i,
	MOTION_KINDS: () => H,
	MOTION_LABEL: () => V,
	ModelEditor: () => ct,
	OUTLINES: () => x,
	SHAPE_KINDS: () => Te,
	SHAPE_LABELS: () => Ne,
	TEXT_ALIGNS: () => Ae,
	VIEWS: () => nt,
	alignMoves: () => z,
	animate: () => be,
	area: () => y,
	assetFromObject3D: () => a,
	assetsOf: () => B,
	blendRadius: () => k,
	boundsOf: () => Tt,
	browserCanvas: () => ht,
	browserDecode: () => Zt,
	budget: () => We,
	buildAd: () => $n,
	checkAssets: () => qe,
	checkModel: () => tt,
	checkMotion: () => U,
	checkOutline: () => He,
	checkPen: () => Ce,
	checkShape: () => K,
	colourName: () => Dn,
	computeNormals: () => Et,
	copiesOf: () => ae,
	createModel: () => Re,
	createShape: () => W,
	defaultMaterial: () => St,
	drawSize: () => _t,
	drawnAs: () => yt,
	eulerOf: () => fe,
	fieldOf: () => f,
	finish: () => Gt,
	finishPicture: () => xt,
	fitsBudget: () => Ge,
	fromBase64: () => wt,
	fromDataUrl: () => bt,
	groundMoves: () => ie,
	hasMotion: () => ye,
	headlineLines: () => Yn,
	join: () => A,
	mainColour: () => ft,
	march: () => te,
	meshAsset: () => Jt,
	meshBlocks: () => sn,
	meshBvh: () => Xt,
	meshShapes: () => Xe,
	modelFromOutline: () => lt,
	modelFromPicture: () => pt,
	modelToSvg: () => yn,
	movedBy: () => ne,
	needsFinish: () => vt,
	newId: () => Le,
	normalizeContours: () => s,
	outlineFrom: () => Ue,
	outlineFromAlpha: () => dt,
	parsePathData: () => Fn,
	pathData: () => _n,
	penContours: () => Se,
	penFromContours: () => we,
	pictureCard: () => o,
	pixelBlock: () => gt,
	poseAt: () => ge,
	prepareMeshes: () => $t,
	pruneAssets: () => Ye,
	rasterize: () => l,
	readGltf: () => Ut,
	readModelFile: () => Kt,
	regionsOf: () => vn,
	renderModelCpu: () => pn,
	rotationMatrix: () => C,
	sampleField: () => m,
	sampleScene: () => N,
	segmentDistances: () => p,
	shapeAt: () => Ze,
	shapeBox: () => P,
	shapeDistance: () => O,
	shapesFromSvg: () => ut,
	simplify: () => v,
	spreadMoves: () => re,
	steps: () => Qe,
	svgOutlines: () => Kn,
	textOutline: () => mt,
	toBase64: () => Ct,
	toLocal: () => w,
	toModelAsset: () => r,
	traceContours: () => _,
	traceMeshes: () => on,
	unionBox: () => F,
	usedAssets: () => Je,
	writeGlb: () => Pt
});
//#endregion
export { Ye as A, B, ke as C, Re as D, We as E, oe as F, C as H, H as I, V as L, Qe as M, Se as N, Xe as O, we as P, be as R, Oe as S, Ne as T, x as U, te as V, f as W, ht as _, Kn as a, ut as b, Et as c, Jt as d, Ct as f, vt as g, yt as h, $n as i, Ze as j, Ue as k, St as l, _t as m, Jn as n, yn as o, Pt as p, qn as r, _n as s, tr as t, Gt as u, mt as v, Te as w, De as x, ct as y, ye as z };

//# sourceMappingURL=core-Cvn4RcxH.js.map