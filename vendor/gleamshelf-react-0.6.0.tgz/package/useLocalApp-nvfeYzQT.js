import { useCallback as e, useEffect as t, useMemo as n, useState as r } from "react";
var i = {
	id: "birefnet-general-fp16",
	name: "BiRefNet (whole box, larger)",
	task: "cutout",
	summary: "Cuts a whole box or product out of any background. Four times the size of the compact model, and it was never fooled by artwork on a cover (the compact one took a girl on the cover for the object on one box in ten).",
	recommended: !1,
	license: {
		name: "MIT",
		commercialUse: "allowed",
		url: "https://huggingface.co/ZhengPeng7/BiRefNet"
	},
	sizeMb: 489.7,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/ZhengPeng7/BiRefNet",
		download: "https://huggingface.co/onnx-community/BiRefNet-ONNX/resolve/main/onnx/model_fp16.onnx"
	},
	file: {
		name: "birefnet-general-fp16.onnx",
		bytes: 489666272
	},
	input: {
		size: 1024,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "logits-mask"
}, a = {
	id: "birefnet-lite-fp16",
	name: "BiRefNet lite (compact)",
	task: "cutout",
	summary: "Separates the product from any background, with clean edges. The compact version: half the download, nearly the same quality.",
	recommended: !0,
	license: {
		name: "MIT",
		commercialUse: "allowed",
		url: "https://huggingface.co/ZhengPeng7/BiRefNet_lite"
	},
	sizeMb: 114.5,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/ZhengPeng7/BiRefNet_lite",
		download: "https://huggingface.co/onnx-community/BiRefNet_lite-ONNX/resolve/main/onnx/model_fp16.onnx"
	},
	file: {
		name: "birefnet-lite-fp16.onnx",
		bytes: 114538221
	},
	input: {
		size: 1024,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "logits-mask"
}, o = {
	id: "birefnet-lite",
	name: "BiRefNet lite (full precision)",
	task: "cutout",
	summary: "The same cut-out model at full precision. A bigger download for slightly finer edges.",
	recommended: !1,
	license: {
		name: "MIT",
		commercialUse: "allowed",
		url: "https://huggingface.co/ZhengPeng7/BiRefNet_lite"
	},
	sizeMb: 224,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/ZhengPeng7/BiRefNet_lite",
		download: "https://huggingface.co/onnx-community/BiRefNet_lite-ONNX/resolve/main/onnx/model.onnx"
	},
	file: {
		name: "birefnet-lite.onnx",
		bytes: 224005088
	},
	input: {
		size: 1024,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "logits-mask"
}, s = {
	id: "lama-fp32",
	name: "LaMa fill (removes marks and lettering)",
	task: "inpaint",
	summary: "Paints over what you mask (printed words, stickers, marks) with realistic detail from around it. Much cleaner than the free fill on hair and fabric. Takes a few seconds per patch on a laptop.",
	recommended: !0,
	license: {
		name: "Apache-2.0",
		commercialUse: "allowed",
		url: "https://huggingface.co/Carve/LaMa-ONNX"
	},
	sizeMb: 208,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/Carve/LaMa-ONNX",
		download: "https://huggingface.co/Carve/LaMa-ONNX/resolve/main/lama_fp32.onnx"
	},
	file: {
		name: "lama-fp32.onnx",
		bytes: 208044816
	},
	input: {
		size: 512,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image"
}, c = {
	id: "ppocr-det-v4",
	name: "Text finder (PaddleOCR v4, compact)",
	task: "text-detect",
	summary: "Finds where printed text is on a picture (any colour, many languages including Japanese), so it can be filled in. Tiny and quick.",
	recommended: !0,
	license: {
		name: "Apache-2.0",
		commercialUse: "allowed",
		url: "https://huggingface.co/SWHL/RapidOCR"
	},
	sizeMb: 4.7,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/SWHL/RapidOCR",
		download: "https://huggingface.co/SWHL/RapidOCR/resolve/main/PP-OCRv4/ch_PP-OCRv4_det_infer.onnx"
	},
	file: {
		name: "ppocr-det-v4.onnx",
		bytes: 4745517
	},
	input: {
		size: 960,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "probability-map"
}, l = {
	id: "ppocr-rec-v4",
	name: "Text reader (PaddleOCR v4, compact)",
	task: "text-read",
	summary: "Reads what printed text says (numbers, prices, English, Chinese, Japanese kana), so a shop's price sticker can be told apart from the box's own printing. Used together with the text finder.",
	recommended: !0,
	license: {
		name: "Apache-2.0",
		commercialUse: "allowed",
		url: "https://huggingface.co/SWHL/RapidOCR"
	},
	sizeMb: 10.9,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/SWHL/RapidOCR",
		download: "https://huggingface.co/SWHL/RapidOCR/resolve/main/PP-OCRv4/ch_PP-OCRv4_rec_infer.onnx"
	},
	file: {
		name: "ppocr-rec-v4.onnx",
		bytes: 10857958
	},
	input: {
		size: 48,
		mean: [
			.5,
			.5,
			.5
		],
		std: [
			.5,
			.5,
			.5
		]
	},
	output: "probability-map"
}, u = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realesr-general-x4",
	name: "Sharpen & enlarge (fast, small)",
	recommended: !1,
	summary: "Makes a picture 4 times larger and clearly sharper, adding believable fine detail. The small, quick one (about a quarter of a second for a face-sized area). Best first choice for photos of figures and boxes. In the benchmark it over-sharpened (1.13 times the original's edge detail) and lost some structure, so the x4plus model is the default.",
	sizeMb: 4.95,
	license: {
		name: "BSD-3-Clause (Real-ESRGAN)",
		commercialUse: "check",
		url: "https://github.com/xinntao/Real-ESRGAN/blob/master/LICENSE"
	},
	links: {
		modelCard: "https://huggingface.co/baker76/upscale-models",
		download: "https://huggingface.co/baker76/upscale-models/resolve/main/RealESR_General_x4.onnx"
	},
	file: {
		name: "realesr-general-x4.onnx",
		bytes: 4954907
	}
}, d = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realesrgan-anime-x4",
	name: "Sharpen & enlarge (illustrations)",
	recommended: !1,
	summary: "Tuned for drawn art: very clean lines and flat colour, but it smooths skin and plastic texture, so it suits flat box illustrations more than photos of figures.",
	sizeMb: 18.7,
	license: {
		name: "BSD-3-Clause (Real-ESRGAN)",
		commercialUse: "check",
		url: "https://github.com/xinntao/Real-ESRGAN/blob/master/LICENSE"
	},
	links: {
		modelCard: "https://huggingface.co/baker76/upscale-models",
		download: "https://huggingface.co/baker76/upscale-models/resolve/main/RealESRGAN_anime_x4.onnx"
	},
	file: {
		name: "realesrgan-anime-x4.onnx",
		bytes: 18688425
	}
}, f = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realesrgan-x4plus",
	name: "Sharpen & enlarge (best photo quality)",
	recommended: !1,
	summary: "Sharpens and enlarges 4x with the larger photo model. On a benchmark (half-size, compressed crops restored and compared with the originals) it was the most faithful and best balanced of the Real-ESRGAN models: highest SSIM and sharpness closest to the original. Slower (a few seconds for a face-sized area).",
	sizeMb: 69.9,
	license: {
		name: "BSD-3-Clause (Real-ESRGAN)",
		commercialUse: "check",
		url: "https://github.com/xinntao/Real-ESRGAN/blob/master/LICENSE"
	},
	links: {
		modelCard: "https://huggingface.co/baker76/upscale-models",
		download: "https://huggingface.co/baker76/upscale-models/resolve/main/RealESRGAN_x4plus.onnx"
	},
	file: {
		name: "realesrgan-x4plus.onnx",
		bytes: 69879921
	}
}, p = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realplksr-x4",
	name: "Photo restore 4x (RealPLKSR, small and fast)",
	recommended: !0,
	summary: "A small 4x restoration model from darktable (MIT), trained for photographs. Best of every enlarging method on ten real product photos (bench/enlarge): sharper and truer than Real-ESRGAN, and it keeps printed text readable.",
	sizeMb: 29.7,
	license: {
		name: "MIT (darktable RealPLKSR)",
		commercialUse: "yes",
		url: "https://huggingface.co/darktable-org/upscale-realplksr-onnx"
	},
	links: {
		modelCard: "https://huggingface.co/darktable-org/upscale-realplksr-onnx",
		download: "https://huggingface.co/darktable-org/upscale-realplksr-onnx/resolve/main/onnx/model_x4.onnx"
	},
	file: {
		name: "realplksr-x4.onnx",
		bytes: 29711010
	}
}, m = {
	id: "sdxl-inpaint",
	name: "Redraw (Stable Diffusion XL inpainting)",
	task: "redraw",
	summary: "Redraws part of a picture with a believable continuation: a missing antenna, an edge that was cut off. Runs on this computer's GPU (about 30 seconds). It invents what it draws, so use it where the picture really is missing a part.",
	recommended: !0,
	license: {
		name: "OpenRAIL++-M (commercial use of the pictures is allowed; see the licence for its use restrictions)",
		commercialUse: "check",
		url: "https://huggingface.co/diffusers/stable-diffusion-xl-1.0-inpainting-0.1"
	},
	sizeMb: 6940,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/diffusers/stable-diffusion-xl-1.0-inpainting-0.1",
		download: "https://huggingface.co/diffusers/stable-diffusion-xl-1.0-inpainting-0.1"
	},
	file: {
		name: "sdxl-inpaint/unet/diffusion_pytorch_model.fp16.safetensors",
		bytes: 5135178560
	},
	input: {
		size: 1024,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image"
}, h = {
	id: "sdxl-tile",
	name: "Sharpen with detail (SDXL tile ControlNet)",
	task: "enhance",
	summary: "Makes a picture crisper and cleaner while every shape stays where it was: hair strands, fabric folds, edges. The original colours are kept. Runs on this computer's GPU (about half a minute to a minute for a 1024 pixel picture once the models are loaded). Works together with the redraw model.",
	recommended: !0,
	license: {
		name: "Apache-2.0 (used with SDXL, OpenRAIL++-M)",
		commercialUse: "allowed",
		url: "https://huggingface.co/xinsir/controlnet-tile-sdxl-1.0"
	},
	sizeMb: 2502,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/xinsir/controlnet-tile-sdxl-1.0",
		download: "https://huggingface.co/xinsir/controlnet-tile-sdxl-1.0"
	},
	file: {
		name: "sdxl-tile/diffusion_pytorch_model.safetensors",
		bytes: 2502139104
	},
	input: {
		size: 1024,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image"
}, g = (e) => {
	let t = e;
	return !!t && typeof t.id == "string" && /^[a-z0-9][a-z0-9-]*$/.test(t.id) && typeof t.name == "string" && (t.task === "cutout" || t.task === "inpaint" || t.task === "text-detect" || t.task === "text-read" || t.task === "upscale" || t.task === "redraw" || t.task === "enhance") && typeof t.file?.name == "string" && typeof t.links?.download == "string" && typeof t.input?.size == "number";
};
function _(e) {
	return [...e].filter(g).sort((e, t) => Number(t.recommended) - Number(e.recommended) || e.name.localeCompare(t.name));
}
function v(e) {
	return {
		MODELS: e,
		findModel: (t) => e.find((e) => e.id === t),
		modelsFor: (t) => e.filter((e) => e.task === t)
	};
}
var { MODELS: y, findModel: b, modelsFor: x } = v(_(Object.values(/* @__PURE__ */ Object.assign({
	"../registry/birefnet-general-fp16.json": i,
	"../registry/birefnet-lite-fp16.json": a,
	"../registry/birefnet-lite.json": o,
	"../registry/lama-fp32.json": s,
	"../registry/ppocr-det-v4.json": c,
	"../registry/ppocr-rec-v4.json": l,
	"../registry/realesr-general-x4.json": u,
	"../registry/realesrgan-anime-x4.json": d,
	"../registry/realesrgan-x4plus.json": f,
	"../registry/realplksr-x4.json": p,
	"../registry/sdxl-inpaint.json": m,
	"../registry/sdxl-tile.json": h
})))), S = {
	strength: .5,
	control: .6,
	guidance: 6,
	keepColour: !1,
	seed: 7,
	prompt: "professional studio product photograph of a collectible, clean even soft lighting, glossy finish, crisp detail, true to the original colours, e-commerce pack shot",
	negativePrompt: "blurry, low quality, noise, artifacts, deformed, extra parts, changed design, text, watermark, logo"
}, C = class extends Error {
	status;
	constructor(e, t) {
		super(t), this.status = e;
	}
}, w = "http://127.0.0.1:47321", T = {
	start: "npm run local:start",
	token: "npm run local:token",
	models: "npm run models",
	redrawSetup: "npm run redraw:setup",
	install: (e) => e && e !== "birefnet-lite-fp16" ? `npm run models:install -- ${e}` : "npm run models:install"
}, E = [
	{
		id: "af_heart",
		label: "Heart",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_bella",
		label: "Bella",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_nicole",
		label: "Nicole (soft)",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_sarah",
		label: "Sarah",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_sky",
		label: "Sky",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_nova",
		label: "Nova",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_river",
		label: "River",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_aoede",
		label: "Aoede",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_kore",
		label: "Kore",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_jessica",
		label: "Jessica",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_alloy",
		label: "Alloy",
		accent: "American",
		kind: "female"
	},
	{
		id: "am_michael",
		label: "Michael",
		accent: "American",
		kind: "male"
	},
	{
		id: "am_adam",
		label: "Adam",
		accent: "American",
		kind: "male"
	},
	{
		id: "am_eric",
		label: "Eric",
		accent: "American",
		kind: "male"
	},
	{
		id: "am_liam",
		label: "Liam",
		accent: "American",
		kind: "male"
	},
	{
		id: "am_puck",
		label: "Puck",
		accent: "American",
		kind: "male"
	},
	{
		id: "am_echo",
		label: "Echo",
		accent: "American",
		kind: "male"
	},
	{
		id: "am_fenrir",
		label: "Fenrir",
		accent: "American",
		kind: "male"
	},
	{
		id: "am_onyx",
		label: "Onyx (deep)",
		accent: "American",
		kind: "male"
	},
	{
		id: "bf_emma",
		label: "Emma",
		accent: "British",
		kind: "female"
	},
	{
		id: "bf_isabella",
		label: "Isabella",
		accent: "British",
		kind: "female"
	},
	{
		id: "bf_alice",
		label: "Alice",
		accent: "British",
		kind: "female"
	},
	{
		id: "bf_lily",
		label: "Lily",
		accent: "British",
		kind: "female"
	},
	{
		id: "bm_george",
		label: "George",
		accent: "British",
		kind: "male"
	},
	{
		id: "bm_fable",
		label: "Fable",
		accent: "British",
		kind: "male"
	},
	{
		id: "bm_lewis",
		label: "Lewis",
		accent: "British",
		kind: "male"
	},
	{
		id: "bm_daniel",
		label: "Daniel",
		accent: "British",
		kind: "male"
	}
], D = class {
	options;
	base;
	doFetch;
	constructor(e = {}) {
		this.options = e, this.base = (e.url ?? "http://127.0.0.1:47321").replace(/\/$/, "");
		let t = e.fetch;
		this.doFetch = (e, n) => (t ?? fetch)(e, n);
	}
	headers(e = {}) {
		return this.options.token ? {
			Authorization: `Bearer ${this.options.token}`,
			...e
		} : e;
	}
	async probe() {
		if (await this.health()) return "ok";
		try {
			return await this.doFetch(`${this.base}/health`, {
				mode: "no-cors",
				signal: AbortSignal.timeout(2500)
			}), "blocked";
		} catch {
			return "offline";
		}
	}
	async health() {
		try {
			let e = await this.doFetch(`${this.base}/health`, { signal: AbortSignal.timeout(2500) });
			if (!e.ok) return null;
			let t = await e.json();
			return t.app === "gleamshelf-local" ? t : null;
		} catch {
			return null;
		}
	}
	async inpaint(e, t, n) {
		let r = await this.doFetch(`${this.base}/inpaint?model=${encodeURIComponent(t)}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "image/png" }),
			body: e,
			signal: n
		});
		if (!r.ok) throw new C(r.status, await O(r));
		return new Blob([await r.arrayBuffer()], { type: "image/png" });
	}
	async upscale(e, t, n) {
		let r = await this.doFetch(`${this.base}/upscale?model=${encodeURIComponent(t)}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!r.ok) throw new C(r.status, await O(r));
		return new Blob([await r.arrayBuffer()], { type: "image/png" });
	}
	async redraw(e, t, n) {
		let r = new URLSearchParams({ prompt: t.prompt });
		t.stacked && r.set("stacked", "true"), t.box && r.set("box", t.box.join(",")), t.negative && r.set("negative", t.negative);
		for (let e of [
			"strength",
			"steps",
			"guidance",
			"candidates",
			"seed"
		]) t[e] !== void 0 && r.set(e, String(t[e]));
		let i = await this.doFetch(`${this.base}/redraw?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "image/png" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new C(i.status, await O(i));
		return new Blob([await i.arrayBuffer()], { type: "image/png" });
	}
	async enhance(e, t = {}, n) {
		let r = new URLSearchParams();
		t.prompt && r.set("prompt", t.prompt), t.negativePrompt && r.set("negativePrompt", t.negativePrompt);
		for (let e of [
			"strength",
			"seed",
			"control",
			"guidance"
		]) t[e] !== void 0 && r.set(e, String(t[e]));
		t.keepColour === !1 && r.set("keepColour", "false");
		let i = await this.doFetch(`${this.base}/enhance?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "image/png" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new C(i.status, await O(i));
		return new Blob([await i.arrayBuffer()], { type: "image/png" });
	}
	gloss(e, t) {
		return this.enhance(e, S, t);
	}
	async readText(e, t) {
		let n = await this.doFetch(`${this.base}/read-text`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: t
		});
		if (!n.ok) throw new C(n.status, await O(n));
		return (await n.json()).boxes;
	}
	async detectText(e, t, n) {
		let r = await this.doFetch(`${this.base}/detect-text?model=${encodeURIComponent(t)}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!r.ok) throw new C(r.status, await O(r));
		return (await r.json()).boxes;
	}
	async voiceStatus(e) {
		let t = await this.doFetch(`${this.base}/voice`, {
			headers: this.headers(),
			signal: e
		});
		if (t.status === 404 || t.status === 501) return null;
		if (!t.ok) throw new C(t.status, await O(t));
		return await t.json();
	}
	async listen(e, t = {}, n) {
		let r = new URLSearchParams();
		t.language && r.set("language", t.language), t.words?.length && r.set("words", t.words.join(","));
		let i = await this.doFetch(`${this.base}/voice/listen?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "audio/wav" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new C(i.status, await O(i));
		return await i.json();
	}
	async fixWording(e, t = {}, n) {
		let r = await this.doFetch(`${this.base}/voice/fix`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify({
				text: e,
				...t
			}),
			signal: n
		});
		if (!r.ok) throw new C(r.status, await O(r));
		return (await r.json()).text;
	}
	async speak(e, t = {}, n) {
		let r = await this.doFetch(`${this.base}/voice/speak`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify({
				text: e,
				...t
			}),
			signal: n
		});
		if (!r.ok) throw new C(r.status, await O(r));
		return new Blob([await r.arrayBuffer()], { type: "audio/wav" });
	}
	async agentStatus(e) {
		let t = await this.doFetch(`${this.base}/agent`, {
			headers: this.headers(),
			signal: e
		});
		if (t.status === 404 || t.status === 501) return null;
		if (!t.ok) throw new C(t.status, await O(t));
		return await t.json();
	}
	async askAgent(e, t = {}, n) {
		let r = await this.doFetch(`${this.base}/agent/ask`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify({
				question: e,
				...t
			}),
			signal: n
		});
		if (!r.ok) throw new C(r.status, await O(r));
		return await r.json();
	}
	async shopProducts(e = "", t) {
		let n = await this.doFetch(`${this.base}/agent/products?q=${encodeURIComponent(e)}`, {
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new C(n.status, await O(n));
		return await n.json();
	}
	async shopImage(e, t) {
		let n = await this.doFetch(`${this.base}/agent/image?url=${encodeURIComponent(e)}`, {
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new C(n.status, await O(n));
		return n.blob();
	}
	async writeScript(e, t = 20, n) {
		let r = await this.doFetch(`${this.base}/agent/script`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify({
				id: e,
				seconds: t
			}),
			signal: n
		});
		if (!r.ok) throw new C(r.status, await O(r));
		return (await r.json()).script;
	}
	async websiteStatus(e) {
		let t = await this.doFetch(`${this.base}/agent/website`, {
			headers: this.headers(),
			signal: e
		});
		if (t.status === 404 || t.status === 501) return null;
		if (!t.ok) throw new C(t.status, await O(t));
		return await t.json();
	}
	async setWebsite(e, t) {
		let n = await this.doFetch(`${this.base}/agent/website`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify(e),
			signal: t
		});
		if (!n.ok) throw new C(n.status, await O(n));
		return await n.json();
	}
	async setWebsitePortrait(e, t) {
		let n = await this.doFetch(`${this.base}/agent/website/portrait`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "image/jpeg" }),
			body: e,
			signal: t
		});
		if (!n.ok) throw new C(n.status, await O(n));
	}
	async stageLink(e) {
		let t = await this.doFetch(`${this.base}/stage/link`, {
			headers: this.headers(),
			signal: e
		});
		if (t.status === 404 || t.status === 501) return null;
		if (!t.ok) throw new C(t.status, await O(t));
		return await t.json();
	}
	async newStageLink(e) {
		let t = await this.doFetch(`${this.base}/stage/key`, {
			method: "POST",
			headers: this.headers(),
			signal: e
		});
		if (!t.ok) throw new C(t.status, await O(t));
		return (await t.json()).url;
	}
	async setStageAvatar(e, t) {
		let n = await this.doFetch(`${this.base}/stage/avatar`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "model/gltf-binary" }),
			body: e,
			signal: t
		});
		if (!n.ok) throw new C(n.status, await O(n));
		return (await n.json()).version;
	}
	get stageSocket() {
		return `${this.base.replace(/^http/, "ws")}/stage/live`;
	}
	get pairingToken() {
		return this.options.token ?? "";
	}
	async buildLiveVoice(e, t) {
		let n = await this.doFetch(`${this.base}/voice/live/build?voice=${e}`, {
			method: "POST",
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new C(n.status, await O(n));
		return await n.json();
	}
	async convertLive(e, t, n) {
		let r = new URLSearchParams({
			voice: t.voice,
			session: t.session
		});
		t.reset && r.set("reset", "1");
		let i = await this.doFetch(`${this.base}/voice/live?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "audio/wav" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new C(i.status, await O(i));
		return new Blob([await i.arrayBuffer()], { type: "audio/wav" });
	}
	async startProcess(e, t = {}, n) {
		let r = new URLSearchParams();
		t.mode && r.set("mode", t.mode), t.vivid !== void 0 && r.set("vivid", String(t.vivid));
		for (let e of [
			"find",
			"listing",
			"enlarge",
			"stickers",
			"lettering",
			"thinParts",
			"colour",
			"look",
			"gloss",
			"review"
		]) t[e] !== void 0 && r.set(e, t[e] ? "1" : "0");
		let i = await this.doFetch(`${this.base}/process?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new C(i.status, await O(i));
		return (await i.json()).id;
	}
	async processStatus(e, t) {
		let n = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}`, {
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new C(n.status, await O(n));
		return await n.json();
	}
	async foundPicture(e, t, n) {
		let r = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/found/${t}.jpg`, {
			headers: this.headers(),
			signal: n
		});
		if (!r.ok) throw new C(r.status, await O(r));
		return new Blob([await r.arrayBuffer()], { type: "image/jpeg" });
	}
	async chooseReferences(e, t, n) {
		let r = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/choose`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify({ use: t }),
			signal: n
		});
		if (!r.ok) throw new C(r.status, await O(r));
	}
	async cancelProcess(e, t) {
		let n = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/cancel`, {
			method: "POST",
			headers: this.headers(),
			signal: t
		});
		if (!n.ok && n.status !== 404) throw new C(n.status, await O(n));
	}
	async processPicture(e, t = "cutout", n) {
		let r = t === "cutout" ? "cutout.png" : t === "changes" ? "changes.png" : "studio.jpg", i = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/${r}`, {
			headers: this.headers(),
			signal: n
		});
		if (!i.ok) throw new C(i.status, await O(i));
		return new Blob([await i.arrayBuffer()], { type: t === "studio" ? "image/jpeg" : "image/png" });
	}
	async recentRuns(e) {
		let t = await this.doFetch(`${this.base}/process/recent`, {
			headers: this.headers(),
			signal: e
		});
		if (!t.ok) throw new C(t.status, await O(t));
		return (await t.json()).runs;
	}
	async shopStatus(e) {
		let t = await this.doFetch(`${this.base}/shop`, {
			headers: this.headers(),
			signal: e
		});
		if (!t.ok) throw new C(t.status, await O(t));
		return await t.json();
	}
	async shopConnect(e, t, n) {
		let r = await this.doFetch(`${this.base}/shop/connect`, {
			method: "POST",
			headers: {
				...this.headers(),
				"Content-Type": "application/json"
			},
			body: JSON.stringify({
				address: e,
				code: t
			}),
			signal: n
		});
		if (!r.ok) throw new C(r.status, await O(r));
		return await r.json();
	}
	async sendRun(e, t) {
		let n = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/send`, {
			method: "POST",
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new C(n.status, await O(n));
		return await n.json();
	}
	async phoneStart(e) {
		let t = await this.doFetch(`${this.base}/phone/start`, {
			method: "POST",
			headers: this.headers(),
			signal: e
		});
		if (!t.ok) throw new C(t.status, await O(t));
		return await t.json();
	}
	async phonePhotos(e) {
		let t = await this.doFetch(`${this.base}/phone/photos`, {
			headers: this.headers(),
			signal: e
		});
		if (!t.ok) throw new C(t.status, await O(t));
		return (await t.json()).photos;
	}
	async phonePhoto(e, t) {
		let n = await this.doFetch(`${this.base}/phone/photos/${encodeURIComponent(e)}`, {
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new C(n.status, await O(n));
		return new Blob([await n.arrayBuffer()], { type: n.headers.get("Content-Type") ?? "image/jpeg" });
	}
	async models() {
		let e = await this.doFetch(`${this.base}/models`, { headers: this.headers() });
		if (!e.ok) throw new C(e.status, await O(e));
		return (await e.json()).models;
	}
	async cutout(e, t, n, r = {}) {
		let i = await this.doFetch(`${this.base}/cutout?model=${encodeURIComponent(t)}${r.thinParts ? "&refine=thin" : ""}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new C(i.status, await O(i));
		let a = Number(i.headers.get("X-Mask-Width")), o = Number(i.headers.get("X-Mask-Height")), s = new Uint8Array(await i.arrayBuffer());
		if (!(a > 0 && o > 0) || s.length !== a * o) throw new C(502, "The companion app sent a mask in a format this editor does not understand.");
		return {
			alpha: s,
			width: a,
			height: o,
			...i.headers.get("X-Mask-Parts") === "kept" ? { partsKept: !0 } : {}
		};
	}
};
async function O(e) {
	let t = await e.json().catch(() => null);
	return e.status === 401 ? "The companion app did not accept the pairing token. Copy it again from the app and paste it in." : t?.error ?? `The companion app answered ${e.status}.`;
}
//#endregion
//#region src/useLocalApp.ts
var k = "gleamshelf:local-app";
function A() {
	try {
		let e = /(?:^#|&)pair=([A-Za-z0-9_-]{16,128})/.exec(window.location.hash);
		return e ? (window.history.replaceState(null, "", window.location.pathname + window.location.search), e[1]) : null;
	} catch {
		return null;
	}
}
function j() {
	let e = A();
	if (e) {
		let t = w;
		try {
			let e = JSON.parse(localStorage.getItem(k) ?? "{}");
			typeof e.url == "string" && (t = e.url);
		} catch {}
		return M({
			url: t,
			token: e
		}), {
			url: t,
			token: e
		};
	}
	try {
		let e = JSON.parse(localStorage.getItem(k) ?? "{}");
		return {
			url: typeof e.url == "string" ? e.url : w,
			token: typeof e.token == "string" ? e.token : ""
		};
	} catch {
		return {
			url: w,
			token: ""
		};
	}
}
function M(e) {
	try {
		localStorage.setItem(k, JSON.stringify(e));
	} catch {}
}
function N(i) {
	let [a, o] = r(() => ({
		...j(),
		...i?.url ? { url: i.url } : {},
		...i?.token ? { token: i.token } : {}
	})), [s, c] = r("checking"), [l, u] = r(null), [d, f] = r(null), [p, m] = r([]), h = n(() => new D({
		url: a.url,
		token: a.token
	}), [a]), g = e(async () => {
		f(null);
		let e = await h.probe();
		if (e === "ok" && m((await h.health())?.features ?? []), e !== "ok") c(e === "blocked" ? "blocked" : "offline"), u(null);
		else if (!a.token) c("needs-token"), u(null);
		else try {
			u(await h.models()), c("ready");
		} catch (e) {
			u(null), f(e instanceof Error ? e.message : "The companion app did not answer."), e instanceof C && e.status === 401 ? (o((e) => ({
				...e,
				token: ""
			})), c("needs-token")) : c("offline");
		}
	}, [h, a.token]);
	return t(() => {
		g();
	}, [g]), t(() => {
		if (s !== "offline" && s !== "blocked") return;
		let e = setInterval(() => void g(), 3e3);
		return () => clearInterval(e);
	}, [s, g]), {
		state: s,
		saved: a,
		client: h,
		models: l,
		installed: (e) => l?.filter((t) => t.task === e && t.installed) ?? [],
		problem: d,
		setProblem: f,
		check: g,
		connect: (e) => {
			let t = {
				...a,
				token: e.trim()
			};
			M(t), o(t);
		},
		canProcess: p.includes("process"),
		canPhone: p.includes("phone"),
		canShop: p.includes("shop")
	};
}
//#endregion
export { x as a, b as i, E as n, T as r, N as t };

//# sourceMappingURL=useLocalApp-nvfeYzQT.js.map