//#region src/theme.ts
var e = {
	bg: "#0b0c12",
	tint: "#ffffff",
	shade: "#000000",
	accent3: "#67e8f9",
	focus: "#b38bff",
	select: "#7cc4ff",
	handle: "#ffffff",
	checkerA: "#22232b",
	checkerB: "#1b1c22",
	pageCheckerA: "#ffffff",
	pageCheckerB: "#e4e4ea",
	text: "#f2f1f8",
	muted: "#a0a3b6",
	accent: "#ff7ab6",
	onAccent: "#14091c",
	stage: "#191a24"
}, t = {
	bg: "--gs-bg",
	tint: "--gs-tint",
	shade: "--gs-shade",
	accent3: "--gs-accent-3",
	focus: "--gs-focus",
	select: "--gs-select",
	handle: "--gs-handle",
	checkerA: "--gs-checker-a",
	checkerB: "--gs-checker-b",
	pageCheckerA: "--gs-page-checker-a",
	pageCheckerB: "--gs-page-checker-b",
	text: "--gs-text",
	muted: "--gs-muted",
	accent: "--gs-accent",
	onAccent: "--gs-on-accent",
	stage: "--gs-stage"
};
function n(n) {
	if (typeof document > "u") return e;
	let r = getComputedStyle(n ?? document.documentElement), i = { ...e };
	for (let n of Object.keys(t)) i[n] = r.getPropertyValue(t[n]).trim() || e[n];
	return i;
}
function r(e, t) {
	let n = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(e.trim());
	if (!n) return e;
	let r = n[1].length === 3 ? [...n[1]].map((e) => e + e).join("") : n[1], [i, a, o] = [
		0,
		2,
		4
	].map((e) => parseInt(r.slice(e, e + 2), 16));
	return `rgba(${i},${a},${o},${t})`;
}
//#endregion
export { r as n, n as t };

//# sourceMappingURL=theme-qdSfcbOw.js.map