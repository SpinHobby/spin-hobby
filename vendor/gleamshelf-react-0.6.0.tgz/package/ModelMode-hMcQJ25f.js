import { c as e, l as t } from "./src-L5EyMOAw.js";
import { a as n, s as r } from "./Panel-C6TPnUHQ.js";
import { t as i } from "./useLocalApp-nvfeYzQT.js";
import { c as a } from "./images-CjCrqZ-i.js";
import { $n as o, C as s, Ct as c, Fn as l, Ft as u, I as d, It as f, Lt as p, M as m, Mn as h, Nn as g, O as _, Ot as v, Pt as y, R as b, Rt as x, S, St as C, U as w, Un as T, V as E, Wn as D, Wt as O, Xn as ee, Zn as k, _r as A, at as j, b as M, br as te, bt as ne, c as N, ct as P, er as re, gr as F, gt as ie, h as ae, hr as I, ht as L, it as R, j as oe, jn as se, l as z, nr as ce, p as le, s as ue, st as de, u as fe, vt as B, w as pe, xt as V, yt as me, zt as he } from "./three.core-DIbF123p.js";
import { S as ge, _ as _e, a as ve, b as ye, d as be, g as H, h as xe, l as Se, m as Ce, n as we, o as Te, r as Ee, t as De, v as Oe, w as ke, x as Ae, y as je } from "./output-DBDfedHt.js";
import { A as Me, B as Ne, C as Pe, D as Fe, E as Ie, F as Le, H as Re, I as ze, L as Be, M as Ve, N as He, O as Ue, P as We, R as Ge, S as Ke, T as qe, U as Je, V as Ye, W as Xe, _ as Ze, a as Qe, b as $e, c as et, d as tt, f as nt, g as rt, h as it, i as at, j as ot, k as st, l as ct, m as lt, n as ut, o as dt, p as ft, r as pt, s as mt, u as ht, v as gt, w as _t, x as vt, y as yt, z as bt } from "./core-Cvn4RcxH.js";
import { useEffect as xt, useRef as U, useState as W, useSyncExternalStore as St } from "react";
import { Fragment as Ct, jsx as G, jsxs as K } from "react/jsx-runtime";
var wt = {
	"stage/template": {
		kind: "choice",
		label: "Display",
		options: [
			"studio",
			"pedestal",
			"shelf",
			"table"
		],
		default: "studio"
	},
	"stage/color": {
		kind: "color",
		label: "Backdrop",
		default: "#e9e4ef"
	},
	"stage/accent": {
		kind: "color",
		label: "Surface",
		default: "#c9b8d8"
	},
	"light/preset": {
		kind: "choice",
		label: "Lighting",
		options: [
			"soft",
			"bright",
			"dramatic"
		],
		default: "soft"
	},
	"light/angle": {
		kind: "number",
		label: "Light direction",
		min: -180,
		max: 180,
		step: 1,
		default: -55,
		unit: "°"
	},
	"item/scale": {
		kind: "number",
		label: "Size",
		min: .4,
		max: 1.6,
		step: .01,
		default: 1,
		unit: "×"
	},
	"item/turn": {
		kind: "number",
		label: "Turn",
		min: -60,
		max: 60,
		step: 1,
		default: 0,
		unit: "°"
	},
	"item/offset": {
		kind: "number",
		label: "Position",
		min: -1,
		max: 1,
		step: .01,
		default: 0
	},
	"item/base": {
		kind: "boolean",
		label: "Stand base",
		default: !0
	},
	"motion/mode": {
		kind: "choice",
		label: "Motion",
		options: ["still", "sway"],
		default: "still"
	}
};
function Tt(e) {
	let n = t(e).join("/");
	return Object.hasOwn(wt, n) ? wt[n] : void 0;
}
e(Tt);
//#endregion
//#region ../../node_modules/three/examples/jsm/controls/OrbitControls.js
var Et = { type: "change" }, Dt = { type: "start" }, Ot = { type: "end" }, kt = new se(), At = new x(), jt = Math.cos(70 * B.DEG2RAD), q = new F(), J = 2 * Math.PI, Y = {
	NONE: -1,
	ROTATE: 0,
	DOLLY: 1,
	PAN: 2,
	TOUCH_ROTATE: 3,
	TOUCH_PAN: 4,
	TOUCH_DOLLY_PAN: 5,
	TOUCH_DOLLY_ROTATE: 6
}, Mt = 1e-6, Nt = class extends ae {
	constructor(e, t = null) {
		super(e, t), this.state = Y.NONE, this.target = new F(), this.cursor = new F(), this.minDistance = 0, this.maxDistance = Infinity, this.minZoom = 0, this.maxZoom = Infinity, this.minTargetRadius = 0, this.maxTargetRadius = Infinity, this.minPolarAngle = 0, this.maxPolarAngle = Math.PI, this.minAzimuthAngle = -Infinity, this.maxAzimuthAngle = Infinity, this.enableDamping = !1, this.dampingFactor = .05, this.enableZoom = !0, this.zoomSpeed = 1, this.enableRotate = !0, this.rotateSpeed = 1, this.keyRotateSpeed = 1, this.enablePan = !0, this.panSpeed = 1, this.screenSpacePanning = !0, this.keyPanSpeed = 7, this.zoomToCursor = !1, this.autoRotate = !1, this.autoRotateSpeed = 2, this.keys = {
			LEFT: "ArrowLeft",
			UP: "ArrowUp",
			RIGHT: "ArrowRight",
			BOTTOM: "ArrowDown"
		}, this.mouseButtons = {
			LEFT: ie.ROTATE,
			MIDDLE: ie.DOLLY,
			RIGHT: ie.PAN
		}, this.touches = {
			ONE: o.ROTATE,
			TWO: o.DOLLY_PAN
		}, this.target0 = this.target.clone(), this.position0 = this.object.position.clone(), this.zoom0 = this.object.zoom, this._cursorStyle = "auto", this._domElementKeyEvents = null, this._lastPosition = new F(), this._lastQuaternion = new O(), this._lastTargetPosition = new F(), this._quat = new O().setFromUnitVectors(e.up, new F(0, 1, 0)), this._quatInverse = this._quat.clone().invert(), this._spherical = new k(), this._sphericalDelta = new k(), this._scale = 1, this._panOffset = new F(), this._rotateStart = new I(), this._rotateEnd = new I(), this._rotateDelta = new I(), this._panStart = new I(), this._panEnd = new I(), this._panDelta = new I(), this._dollyStart = new I(), this._dollyEnd = new I(), this._dollyDelta = new I(), this._dollyDirection = new F(), this._mouse = new I(), this._performCursorZoom = !1, this._pointers = [], this._pointerPositions = {}, this._controlActive = !1, this._onPointerMove = Ft.bind(this), this._onPointerDown = Pt.bind(this), this._onPointerUp = It.bind(this), this._onContextMenu = Ut.bind(this), this._onMouseWheel = zt.bind(this), this._onKeyDown = Bt.bind(this), this._onTouchStart = Vt.bind(this), this._onTouchMove = Ht.bind(this), this._onMouseDown = Lt.bind(this), this._onMouseMove = Rt.bind(this), this._interceptControlDown = Wt.bind(this), this._interceptControlUp = Gt.bind(this), this.domElement !== null && this.connect(this.domElement), this.update();
	}
	set cursorStyle(e) {
		this._cursorStyle = e, e === "grab" ? this.domElement.style.cursor = "grab" : this.domElement.style.cursor = "auto";
	}
	get cursorStyle() {
		return this._cursorStyle;
	}
	connect(e) {
		super.connect(e), this.domElement.addEventListener("pointerdown", this._onPointerDown), this.domElement.addEventListener("pointercancel", this._onPointerUp), this.domElement.addEventListener("contextmenu", this._onContextMenu), this.domElement.addEventListener("wheel", this._onMouseWheel, { passive: !1 }), this.domElement.getRootNode().addEventListener("keydown", this._interceptControlDown, {
			passive: !0,
			capture: !0
		}), this.domElement.style.touchAction = "none";
	}
	disconnect() {
		this.state = Y.NONE, this.domElement.removeEventListener("pointerdown", this._onPointerDown), this.domElement.ownerDocument.removeEventListener("pointermove", this._onPointerMove), this.domElement.ownerDocument.removeEventListener("pointerup", this._onPointerUp), this.domElement.removeEventListener("pointercancel", this._onPointerUp), this.domElement.removeEventListener("wheel", this._onMouseWheel), this.domElement.removeEventListener("contextmenu", this._onContextMenu), this.stopListenToKeyEvents();
		let e = this.domElement.getRootNode();
		e.removeEventListener("keydown", this._interceptControlDown, { capture: !0 }), e.removeEventListener("keyup", this._interceptControlUp, { capture: !0 }), this._controlActive = !1, this._pointers.length = 0, this._pointerPositions = {}, this.domElement.style.touchAction = "", this.domElement.style.cursor = "auto";
	}
	dispose() {
		this.disconnect();
	}
	getPolarAngle() {
		return this._spherical.phi;
	}
	getAzimuthalAngle() {
		return this._spherical.theta;
	}
	getDistance() {
		return this.object.position.distanceTo(this.target);
	}
	listenToKeyEvents(e) {
		e.addEventListener("keydown", this._onKeyDown), this._domElementKeyEvents = e;
	}
	stopListenToKeyEvents() {
		this._domElementKeyEvents !== null && (this._domElementKeyEvents.removeEventListener("keydown", this._onKeyDown), this._domElementKeyEvents = null);
	}
	saveState() {
		this.target0.copy(this.target), this.position0.copy(this.object.position), this.zoom0 = this.object.zoom;
	}
	reset() {
		this.target.copy(this.target0), this.object.position.copy(this.position0), this.object.zoom = this.zoom0, this.object.updateProjectionMatrix(), this.dispatchEvent(Et), this.update(), this.state = Y.NONE;
	}
	pan(e, t) {
		this._pan(e, t), this.update();
	}
	dollyIn(e) {
		this._dollyIn(e), this.update();
	}
	dollyOut(e) {
		this._dollyOut(e), this.update();
	}
	rotateLeft(e) {
		this._rotateLeft(e), this.update();
	}
	rotateUp(e) {
		this._rotateUp(e), this.update();
	}
	update(e = null) {
		let t = this.object.position;
		q.copy(t).sub(this.target), q.applyQuaternion(this._quat), this._spherical.setFromVector3(q), this.autoRotate && this.state === Y.NONE && this._rotateLeft(this._getAutoRotationAngle(e)), this.enableDamping ? (this._spherical.theta += this._sphericalDelta.theta * this.dampingFactor, this._spherical.phi += this._sphericalDelta.phi * this.dampingFactor) : (this._spherical.theta += this._sphericalDelta.theta, this._spherical.phi += this._sphericalDelta.phi);
		let n = this.minAzimuthAngle, r = this.maxAzimuthAngle;
		isFinite(n) && isFinite(r) && (n < -Math.PI ? n += J : n > Math.PI && (n -= J), r < -Math.PI ? r += J : r > Math.PI && (r -= J), n <= r ? this._spherical.theta = Math.max(n, Math.min(r, this._spherical.theta)) : this._spherical.theta = this._spherical.theta > (n + r) / 2 ? Math.max(n, this._spherical.theta) : Math.min(r, this._spherical.theta)), this._spherical.phi = Math.max(this.minPolarAngle, Math.min(this.maxPolarAngle, this._spherical.phi)), this._spherical.makeSafe(), this.enableDamping === !0 ? this.target.addScaledVector(this._panOffset, this.dampingFactor) : this.target.add(this._panOffset), this.target.sub(this.cursor), this.target.clampLength(this.minTargetRadius, this.maxTargetRadius), this.target.add(this.cursor);
		let i = !1;
		if (this.zoomToCursor && this._performCursorZoom || this.object.isOrthographicCamera) this._spherical.radius = this._clampDistance(this._spherical.radius);
		else {
			let e = this._spherical.radius;
			this._spherical.radius = this._clampDistance(this._spherical.radius * this._scale), i = e != this._spherical.radius;
		}
		if (q.setFromSpherical(this._spherical), q.applyQuaternion(this._quatInverse), t.copy(this.target).add(q), this.object.lookAt(this.target), this.enableDamping === !0 ? (this._sphericalDelta.theta *= 1 - this.dampingFactor, this._sphericalDelta.phi *= 1 - this.dampingFactor, this._panOffset.multiplyScalar(1 - this.dampingFactor)) : (this._sphericalDelta.set(0, 0, 0), this._panOffset.set(0, 0, 0)), this.zoomToCursor && this._performCursorZoom) {
			let e = null;
			if (this.object.isPerspectiveCamera) {
				let t = q.length();
				e = this._clampDistance(t * this._scale);
				let n = t - e;
				this.object.position.addScaledVector(this._dollyDirection, n), this.object.updateMatrixWorld(), i = !!n;
			} else if (this.object.isOrthographicCamera) {
				let t = new F(this._mouse.x, this._mouse.y, 0);
				t.unproject(this.object);
				let n = this.object.zoom;
				this.object.zoom = Math.max(this.minZoom, Math.min(this.maxZoom, this.object.zoom / this._scale)), this.object.updateProjectionMatrix(), i = n !== this.object.zoom;
				let r = new F(this._mouse.x, this._mouse.y, 0);
				r.unproject(this.object), this.object.position.sub(r).add(t), this.object.updateMatrixWorld(), e = q.length();
			} else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."), this.zoomToCursor = !1;
			e !== null && (this.screenSpacePanning ? this.target.set(0, 0, -1).transformDirection(this.object.matrix).multiplyScalar(e).add(this.object.position) : (kt.origin.copy(this.object.position), kt.direction.set(0, 0, -1).transformDirection(this.object.matrix), Math.abs(this.object.up.dot(kt.direction)) < jt ? this.object.lookAt(this.target) : (At.setFromNormalAndCoplanarPoint(this.object.up, this.target), kt.intersectPlane(At, this.target))));
		} else if (this.object.isOrthographicCamera) {
			let e = this.object.zoom;
			this.object.zoom = Math.max(this.minZoom, Math.min(this.maxZoom, this.object.zoom / this._scale)), e !== this.object.zoom && (this.object.updateProjectionMatrix(), i = !0);
		}
		return this._scale = 1, this._performCursorZoom = !1, i || this._lastPosition.distanceToSquared(this.object.position) > Mt || 8 * (1 - this._lastQuaternion.dot(this.object.quaternion)) > Mt || this._lastTargetPosition.distanceToSquared(this.target) > Mt ? (this.dispatchEvent(Et), this._lastPosition.copy(this.object.position), this._lastQuaternion.copy(this.object.quaternion), this._lastTargetPosition.copy(this.target), !0) : !1;
	}
	_getAutoRotationAngle(e) {
		return e === null ? J / 60 / 60 * this.autoRotateSpeed : J / 60 * this.autoRotateSpeed * e;
	}
	_getZoomScale(e) {
		let t = Math.abs(e * .01);
		return .95 ** (this.zoomSpeed * t);
	}
	_rotateLeft(e) {
		this._sphericalDelta.theta -= e;
	}
	_rotateUp(e) {
		this._sphericalDelta.phi -= e;
	}
	_panLeft(e, t) {
		q.setFromMatrixColumn(t, 0), q.multiplyScalar(-e), this._panOffset.add(q);
	}
	_panUp(e, t) {
		this.screenSpacePanning === !0 ? q.setFromMatrixColumn(t, 1) : (q.setFromMatrixColumn(t, 0), q.crossVectors(this.object.up, q)), q.multiplyScalar(e), this._panOffset.add(q);
	}
	_pan(e, t) {
		let n = this.domElement;
		if (this.object.isPerspectiveCamera) {
			let r = this.object.position;
			q.copy(r).sub(this.target);
			let i = q.length();
			i *= Math.tan(this.object.fov / 2 * Math.PI / 180), this._panLeft(2 * e * i / n.clientHeight, this.object.matrix), this._panUp(2 * t * i / n.clientHeight, this.object.matrix);
		} else this.object.isOrthographicCamera ? (this._panLeft(e * (this.object.right - this.object.left) / this.object.zoom / n.clientWidth, this.object.matrix), this._panUp(t * (this.object.top - this.object.bottom) / this.object.zoom / n.clientHeight, this.object.matrix)) : (console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."), this.enablePan = !1);
	}
	_dollyOut(e) {
		this.object.isPerspectiveCamera || this.object.isOrthographicCamera ? this._scale /= e : (console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."), this.enableZoom = !1);
	}
	_dollyIn(e) {
		this.object.isPerspectiveCamera || this.object.isOrthographicCamera ? this._scale *= e : (console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."), this.enableZoom = !1);
	}
	_updateZoomParameters(e, t) {
		if (!this.zoomToCursor) return;
		this._performCursorZoom = !0;
		let n = this.domElement.getBoundingClientRect(), r = e - n.left, i = t - n.top, a = n.width, o = n.height;
		this._mouse.x = r / a * 2 - 1, this._mouse.y = -(i / o) * 2 + 1, this._dollyDirection.set(this._mouse.x, this._mouse.y, 1).unproject(this.object).sub(this.object.position).normalize();
	}
	_clampDistance(e) {
		return Math.max(this.minDistance, Math.min(this.maxDistance, e));
	}
	_handleMouseDownRotate(e) {
		this._rotateStart.set(e.clientX, e.clientY);
	}
	_handleMouseDownDolly(e) {
		this._updateZoomParameters(e.clientX, e.clientX), this._dollyStart.set(e.clientX, e.clientY);
	}
	_handleMouseDownPan(e) {
		this._panStart.set(e.clientX, e.clientY);
	}
	_handleMouseMoveRotate(e) {
		this._rotateEnd.set(e.clientX, e.clientY), this._rotateDelta.subVectors(this._rotateEnd, this._rotateStart).multiplyScalar(this.rotateSpeed);
		let t = this.domElement;
		this._rotateLeft(J * this._rotateDelta.x / t.clientHeight), this._rotateUp(J * this._rotateDelta.y / t.clientHeight), this._rotateStart.copy(this._rotateEnd), this.update();
	}
	_handleMouseMoveDolly(e) {
		this._dollyEnd.set(e.clientX, e.clientY), this._dollyDelta.subVectors(this._dollyEnd, this._dollyStart), this._dollyDelta.y > 0 ? this._dollyOut(this._getZoomScale(this._dollyDelta.y)) : this._dollyDelta.y < 0 && this._dollyIn(this._getZoomScale(this._dollyDelta.y)), this._dollyStart.copy(this._dollyEnd), this.update();
	}
	_handleMouseMovePan(e) {
		this._panEnd.set(e.clientX, e.clientY), this._panDelta.subVectors(this._panEnd, this._panStart).multiplyScalar(this.panSpeed), this._pan(this._panDelta.x, this._panDelta.y), this._panStart.copy(this._panEnd), this.update();
	}
	_handleMouseWheel(e) {
		this._updateZoomParameters(e.clientX, e.clientY), e.deltaY < 0 ? this._dollyIn(this._getZoomScale(e.deltaY)) : e.deltaY > 0 && this._dollyOut(this._getZoomScale(e.deltaY)), this.update();
	}
	_handleKeyDown(e) {
		let t = !1;
		switch (e.code) {
			case this.keys.UP:
				e.ctrlKey || e.metaKey || e.shiftKey ? this.enableRotate && this._rotateUp(J * this.keyRotateSpeed / this.domElement.clientHeight) : this.enablePan && this._pan(0, this.keyPanSpeed), t = !0;
				break;
			case this.keys.BOTTOM:
				e.ctrlKey || e.metaKey || e.shiftKey ? this.enableRotate && this._rotateUp(-J * this.keyRotateSpeed / this.domElement.clientHeight) : this.enablePan && this._pan(0, -this.keyPanSpeed), t = !0;
				break;
			case this.keys.LEFT:
				e.ctrlKey || e.metaKey || e.shiftKey ? this.enableRotate && this._rotateLeft(J * this.keyRotateSpeed / this.domElement.clientHeight) : this.enablePan && this._pan(this.keyPanSpeed, 0), t = !0;
				break;
			case this.keys.RIGHT: e.ctrlKey || e.metaKey || e.shiftKey ? this.enableRotate && this._rotateLeft(-J * this.keyRotateSpeed / this.domElement.clientHeight) : this.enablePan && this._pan(-this.keyPanSpeed, 0), t = !0;
		}
		t && (e.preventDefault(), this.update());
	}
	_handleTouchStartRotate(e) {
		if (this._pointers.length === 1) this._rotateStart.set(e.pageX, e.pageY);
		else {
			let t = this._getSecondPointerPosition(e), n = .5 * (e.pageX + t.x), r = .5 * (e.pageY + t.y);
			this._rotateStart.set(n, r);
		}
	}
	_handleTouchStartPan(e) {
		if (this._pointers.length === 1) this._panStart.set(e.pageX, e.pageY);
		else {
			let t = this._getSecondPointerPosition(e), n = .5 * (e.pageX + t.x), r = .5 * (e.pageY + t.y);
			this._panStart.set(n, r);
		}
	}
	_handleTouchStartDolly(e) {
		let t = this._getSecondPointerPosition(e), n = e.pageX - t.x, r = e.pageY - t.y, i = Math.sqrt(n * n + r * r);
		this._dollyStart.set(0, i);
	}
	_handleTouchStartDollyPan(e) {
		this.enableZoom && this._handleTouchStartDolly(e), this.enablePan && this._handleTouchStartPan(e);
	}
	_handleTouchStartDollyRotate(e) {
		this.enableZoom && this._handleTouchStartDolly(e), this.enableRotate && this._handleTouchStartRotate(e);
	}
	_handleTouchMoveRotate(e) {
		if (this._pointers.length == 1) this._rotateEnd.set(e.pageX, e.pageY);
		else {
			let t = this._getSecondPointerPosition(e), n = .5 * (e.pageX + t.x), r = .5 * (e.pageY + t.y);
			this._rotateEnd.set(n, r);
		}
		this._rotateDelta.subVectors(this._rotateEnd, this._rotateStart).multiplyScalar(this.rotateSpeed);
		let t = this.domElement;
		this._rotateLeft(J * this._rotateDelta.x / t.clientHeight), this._rotateUp(J * this._rotateDelta.y / t.clientHeight), this._rotateStart.copy(this._rotateEnd);
	}
	_handleTouchMovePan(e) {
		if (this._pointers.length === 1) this._panEnd.set(e.pageX, e.pageY);
		else {
			let t = this._getSecondPointerPosition(e), n = .5 * (e.pageX + t.x), r = .5 * (e.pageY + t.y);
			this._panEnd.set(n, r);
		}
		this._panDelta.subVectors(this._panEnd, this._panStart).multiplyScalar(this.panSpeed), this._pan(this._panDelta.x, this._panDelta.y), this._panStart.copy(this._panEnd);
	}
	_handleTouchMoveDolly(e) {
		let t = this._getSecondPointerPosition(e), n = e.pageX - t.x, r = e.pageY - t.y, i = Math.sqrt(n * n + r * r);
		this._dollyEnd.set(0, i), this._dollyDelta.set(0, (this._dollyEnd.y / this._dollyStart.y) ** +this.zoomSpeed), this._dollyOut(this._dollyDelta.y), this._dollyStart.copy(this._dollyEnd);
		let a = (e.pageX + t.x) * .5, o = (e.pageY + t.y) * .5;
		this._updateZoomParameters(a, o);
	}
	_handleTouchMoveDollyPan(e) {
		this.enableZoom && this._handleTouchMoveDolly(e), this.enablePan && this._handleTouchMovePan(e);
	}
	_handleTouchMoveDollyRotate(e) {
		this.enableZoom && this._handleTouchMoveDolly(e), this.enableRotate && this._handleTouchMoveRotate(e);
	}
	_addPointer(e) {
		this._pointers.push(e.pointerId);
	}
	_removePointer(e) {
		delete this._pointerPositions[e.pointerId];
		for (let t = 0; t < this._pointers.length; t++) if (this._pointers[t] == e.pointerId) {
			this._pointers.splice(t, 1);
			return;
		}
	}
	_isTrackingPointer(e) {
		for (let t = 0; t < this._pointers.length; t++) if (this._pointers[t] == e.pointerId) return !0;
		return !1;
	}
	_trackPointer(e) {
		let t = this._pointerPositions[e.pointerId];
		t === void 0 && (t = new I(), this._pointerPositions[e.pointerId] = t), t.set(e.pageX, e.pageY);
	}
	_getSecondPointerPosition(e) {
		let t = e.pointerId === this._pointers[0] ? this._pointers[1] : this._pointers[0];
		return this._pointerPositions[t];
	}
	_customWheelEvent(e) {
		let t = e.deltaMode, n = {
			clientX: e.clientX,
			clientY: e.clientY,
			deltaY: e.deltaY
		};
		switch (t) {
			case 1:
				n.deltaY *= 16;
				break;
			case 2: n.deltaY *= 100;
		}
		return e.ctrlKey && !this._controlActive && (n.deltaY *= 10), n;
	}
};
function Pt(e) {
	this.enabled !== !1 && (this._pointers.length === 0 && (this.domElement.setPointerCapture(e.pointerId), this.domElement.ownerDocument.addEventListener("pointermove", this._onPointerMove), this.domElement.ownerDocument.addEventListener("pointerup", this._onPointerUp)), !this._isTrackingPointer(e) && (this._addPointer(e), e.pointerType === "touch" ? this._onTouchStart(e) : this._onMouseDown(e), this._cursorStyle === "grab" && (this.domElement.style.cursor = "grabbing")));
}
function Ft(e) {
	this.enabled !== !1 && (e.pointerType === "touch" ? this._onTouchMove(e) : this._onMouseMove(e));
}
function It(e) {
	switch (this._removePointer(e), this._pointers.length) {
		case 0:
			this.domElement.releasePointerCapture(e.pointerId), this.domElement.ownerDocument.removeEventListener("pointermove", this._onPointerMove), this.domElement.ownerDocument.removeEventListener("pointerup", this._onPointerUp), this.dispatchEvent(Ot), this.state = Y.NONE, this._cursorStyle === "grab" && (this.domElement.style.cursor = "grab");
			break;
		case 1:
			let t = this._pointers[0], n = this._pointerPositions[t];
			this._onTouchStart({
				pointerId: t,
				pageX: n.x,
				pageY: n.y
			});
	}
}
function Lt(e) {
	let t;
	switch (e.button) {
		case 0:
			t = this.mouseButtons.LEFT;
			break;
		case 1:
			t = this.mouseButtons.MIDDLE;
			break;
		case 2:
			t = this.mouseButtons.RIGHT;
			break;
		default: t = -1;
	}
	switch (t) {
		case ie.DOLLY:
			if (this.enableZoom === !1) return;
			this._handleMouseDownDolly(e), this.state = Y.DOLLY;
			break;
		case ie.ROTATE:
			if (e.ctrlKey || e.metaKey || e.shiftKey) {
				if (this.enablePan === !1) return;
				this._handleMouseDownPan(e), this.state = Y.PAN;
			} else {
				if (this.enableRotate === !1) return;
				this._handleMouseDownRotate(e), this.state = Y.ROTATE;
			}
			break;
		case ie.PAN:
			if (e.ctrlKey || e.metaKey || e.shiftKey) {
				if (this.enableRotate === !1) return;
				this._handleMouseDownRotate(e), this.state = Y.ROTATE;
			} else {
				if (this.enablePan === !1) return;
				this._handleMouseDownPan(e), this.state = Y.PAN;
			}
			break;
		default: this.state = Y.NONE;
	}
	this.state !== Y.NONE && this.dispatchEvent(Dt);
}
function Rt(e) {
	switch (this.state) {
		case Y.ROTATE:
			if (this.enableRotate === !1) return;
			this._handleMouseMoveRotate(e);
			break;
		case Y.DOLLY:
			if (this.enableZoom === !1) return;
			this._handleMouseMoveDolly(e);
			break;
		case Y.PAN:
			if (this.enablePan === !1) return;
			this._handleMouseMovePan(e);
	}
}
function zt(e) {
	this.enabled !== !1 && this.enableZoom !== !1 && this.state === Y.NONE && (e.preventDefault(), this.dispatchEvent(Dt), this._handleMouseWheel(this._customWheelEvent(e)), this.dispatchEvent(Ot));
}
function Bt(e) {
	this.enabled !== !1 && this._handleKeyDown(e);
}
function Vt(e) {
	switch (this._trackPointer(e), this._pointers.length) {
		case 1:
			switch (this.touches.ONE) {
				case o.ROTATE:
					if (this.enableRotate === !1) return;
					this._handleTouchStartRotate(e), this.state = Y.TOUCH_ROTATE;
					break;
				case o.PAN:
					if (this.enablePan === !1) return;
					this._handleTouchStartPan(e), this.state = Y.TOUCH_PAN;
					break;
				default: this.state = Y.NONE;
			}
			break;
		case 2:
			switch (this.touches.TWO) {
				case o.DOLLY_PAN:
					if (this.enableZoom === !1 && this.enablePan === !1) return;
					this._handleTouchStartDollyPan(e), this.state = Y.TOUCH_DOLLY_PAN;
					break;
				case o.DOLLY_ROTATE:
					if (this.enableZoom === !1 && this.enableRotate === !1) return;
					this._handleTouchStartDollyRotate(e), this.state = Y.TOUCH_DOLLY_ROTATE;
					break;
				default: this.state = Y.NONE;
			}
			break;
		default: this.state = Y.NONE;
	}
	this.state !== Y.NONE && this.dispatchEvent(Dt);
}
function Ht(e) {
	switch (this._trackPointer(e), this.state) {
		case Y.TOUCH_ROTATE:
			if (this.enableRotate === !1) return;
			this._handleTouchMoveRotate(e), this.update();
			break;
		case Y.TOUCH_PAN:
			if (this.enablePan === !1) return;
			this._handleTouchMovePan(e), this.update();
			break;
		case Y.TOUCH_DOLLY_PAN:
			if (this.enableZoom === !1 && this.enablePan === !1) return;
			this._handleTouchMoveDollyPan(e), this.update();
			break;
		case Y.TOUCH_DOLLY_ROTATE:
			if (this.enableZoom === !1 && this.enableRotate === !1) return;
			this._handleTouchMoveDollyRotate(e), this.update();
			break;
		default: this.state = Y.NONE;
	}
}
function Ut(e) {
	this.enabled !== !1 && e.preventDefault();
}
function Wt(e) {
	e.key === "Control" && (this._controlActive = !0, this.domElement.getRootNode().addEventListener("keyup", this._interceptControlUp, {
		passive: !0,
		capture: !0
	}));
}
function Gt(e) {
	e.key === "Control" && (this._controlActive = !1, this.domElement.getRootNode().removeEventListener("keyup", this._interceptControlUp, {
		passive: !0,
		capture: !0
	}));
}
//#endregion
//#region ../scene3d/src/model/meshFromThree.ts
var Kt = (e) => {
	let t = e;
	return t?.map ?? t?.normalMap ?? t?.roughnessMap ?? t?.metalnessMap ?? t?.aoMap ?? t?.emissiveMap ?? null;
}, qt = 15e5;
async function Jt(e, t, n) {
	e.updateMatrixWorld(!0);
	let r = [], i = [], a = [], o = /* @__PURE__ */ new Set(), s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map(), l = [], u = (e, n) => {
		let r = c.get(e);
		return r || (r = n().then((e) => e ? a.push(e) - 1 : (t && o.add("Some textures could not be read (compressed GPU textures); those parts do without them."), -1)), c.set(e, r)), r;
	}, d = (e, n) => u(`${e.uuid}:${n}`, () => t ? t(e, n) : Promise.resolve(null)), f = (e) => {
		if (!e) return i.push(ct()) - 1;
		let t = s.get(e);
		if (t !== void 0) return t;
		let r = e, a = r.color ?? new le(1, 1, 1), c = (e) => e && e.channel !== 0 ? (o.add("Some maps use a second set of texture coordinates and were left out."), null) : e ?? null;
		for (let e of [
			"map",
			"normalMap",
			"roughnessMap",
			"metalnessMap",
			"aoMap",
			"emissiveMap",
			"clearcoatMap",
			"clearcoatRoughnessMap",
			"clearcoatNormalMap",
			"sheenColorMap",
			"sheenRoughnessMap",
			"transmissionMap"
		]) r[e] = c(r[e]);
		let f = (r.sheenColor ?? new le(0, 0, 0)).clone().multiplyScalar(r.sheen ?? 0), p = (r.emissive ?? new le(0, 0, 0)).clone().multiplyScalar(r.emissiveIntensity ?? 1), m = r.roughness ?? (r.shininess === void 0 ? .6 : 1 - Math.min(1, Math.sqrt(r.shininess / 100))), h = {
			color: [
				a.r,
				a.g,
				a.b
			],
			opacity: e.opacity ?? 1,
			metalness: r.metalness ?? 0,
			roughness: m,
			texture: -1,
			normalTexture: -1,
			normalScale: Math.abs(r.normalScale?.x ?? 1) || 1,
			roughnessTexture: -1,
			occlusionTexture: -1,
			occlusionStrength: r.aoMapIntensity ?? 1,
			emissive: [
				p.r,
				p.g,
				p.b
			],
			emissiveTexture: -1,
			clearcoat: r.clearcoat ?? 0,
			clearcoatTexture: -1,
			clearcoatRoughness: r.clearcoatRoughness ?? 0,
			clearcoatRoughnessTexture: -1,
			clearcoatNormalTexture: -1,
			clearcoatNormalScale: Math.abs(r.clearcoatNormalScale?.x ?? 1) || 1,
			sheenColor: [
				f.r,
				f.g,
				f.b
			],
			sheenColorTexture: -1,
			sheenRoughness: r.sheenRoughness ?? 0,
			sheenRoughnessTexture: -1,
			transmission: r.transmission ?? 0,
			transmissionTexture: -1,
			ior: Math.min(3, Math.max(1, r.ior ?? 1.5)),
			cutout: e.alphaTest > 0 || e.transparent,
			doubleSided: e.side === 2
		}, g = i.push(h) - 1;
		s.set(e, g), r.map && l.push(d(r.map, "color").then((e) => void (h.texture = e))), r.normalMap && l.push(d(r.normalMap, "data").then((e) => void (h.normalTexture = e))), r.aoMap && l.push(d(r.aoMap, "data").then((e) => void (h.occlusionTexture = e))), r.emissiveMap && l.push(d(r.emissiveMap, "color").then((e) => void (h.emissiveTexture = e)));
		let _ = [
			[
				r.clearcoatMap,
				"data",
				(e) => h.clearcoatTexture = e
			],
			[
				r.clearcoatRoughnessMap,
				"data",
				(e) => h.clearcoatRoughnessTexture = e
			],
			[
				r.clearcoatNormalMap,
				"data",
				(e) => h.clearcoatNormalTexture = e
			],
			[
				r.sheenColorMap,
				"color",
				(e) => h.sheenColorTexture = e
			],
			[
				r.sheenRoughnessMap,
				"data",
				(e) => h.sheenRoughnessTexture = e
			],
			[
				r.transmissionMap,
				"data",
				(e) => h.transmissionTexture = e
			]
		];
		for (let [e, t, n] of _) e && l.push(d(e, t).then(n));
		let v = r.roughnessMap ?? null, y = r.metalnessMap ?? null;
		if (v || y) {
			let e = v && v === y ? v : null;
			l.push((e ? d(e, "data") : u(`${v?.uuid}+${y?.uuid}`, () => n ? n(v, y) : Promise.resolve(null))).then((e) => void (h.roughnessTexture = e)));
		}
		return g;
	}, p = 0;
	if (e.traverse((e) => {
		let t = e;
		if (!t.isMesh || !t.visible) return;
		let n = t.geometry, i = n.getAttribute("position");
		if (!i) return;
		let a = n.getIndex(), s = n.getAttribute("normal"), c = n.getAttribute("uv"), l = n.getAttribute("color"), u = Array.isArray(t.material) ? t.material : [t.material], d = n.groups.length ? n.groups : [{
			start: 0,
			count: a ? a.count : i.count,
			materialIndex: 0
		}], m = t.isInstancedMesh ? t : null, h = [];
		if (m) for (let e = 0; e < m.count; e++) {
			let n = new ne();
			m.getMatrixAt(e, n), h.push(t.matrixWorld.clone().multiply(n));
		}
		else h.push(t.matrixWorld);
		t.isSkinnedMesh && o.add("Rigged models come in their resting pose.");
		for (let e of h) {
			let t = new me().getNormalMatrix(e), n = e.determinant() < 0;
			for (let o of d) {
				let d = u[o.materialIndex ?? 0] ?? u[0], m = f(d), h = !!l && d?.vertexColors === !0, g = Kt(d);
				g && g.updateMatrix();
				let _ = Math.min(o.start + o.count, a ? a.count : i.count), v = /* @__PURE__ */ new Map(), y = [];
				for (let e = o.start; e + 2 < _; e += 3) {
					let t = [
						0,
						1,
						2
					].map((t) => a ? a.getX(e + t) : e + t);
					n && ([t[1], t[2]] = [t[2], t[1]]);
					for (let e of t) v.has(e) || v.set(e, v.size), y.push(v.get(e));
				}
				if (!y.length) continue;
				let b = v.size, x = new Float32Array(b * 3), S = s ? new Float32Array(b * 3) : null, C = c ? new Float32Array(b * 2) : null, w = h ? new Float32Array(b * 3) : null, T = new F(), E = new I();
				for (let [n, r] of v) T.fromBufferAttribute(i, n).applyMatrix4(e), x.set([
					T.x,
					T.y,
					T.z
				], r * 3), S && (T.fromBufferAttribute(s, n).applyMatrix3(t).normalize(), S.set([
					T.x,
					T.y,
					T.z
				], r * 3)), C && (E.set(c.getX(n), c.getY(n)), g && (E.applyMatrix3(g.matrix), g.flipY && (E.y = 1 - E.y)), C.set([E.x, E.y], r * 2)), w && w.set([
					l.getX(n),
					l.getY(n),
					l.getZ(n)
				], r * 3);
				let D = Uint32Array.from(y);
				if (p += D.length / 3, p > 15e5) throw Error(`This model has more than ${qt.toLocaleString("en")} triangles; simplify it first (Blender's Decimate does it).`);
				let O = !!S;
				for (let e = 0; O && e < b; e++) Math.hypot(S[e * 3], S[e * 3 + 1], S[e * 3 + 2]) > 1e-4 || (O = !1);
				r.push({
					positions: x,
					normals: O ? S : et(x, D),
					uvs: C,
					colors: w,
					indices: D,
					material: m
				});
			}
		}
	}), await Promise.all(l), !r.length) throw Error("There is nothing to draw in that file (no triangles).");
	return {
		asset: ht(r, i, a),
		warnings: [...o]
	};
}
function Yt(e, t) {
	return {
		name: t.slice(0, 80) || "Model",
		data: nt(ft(e)),
		triangles: e.triangles,
		size: e.max.map((t, n) => t - e.min[n]),
		centre: e.min.map((t, n) => (t + e.max[n]) / 2)
	};
}
//#endregion
//#region ../scene3d/src/model/card.ts
function Xt(e, t, n, r, i = "Product photo") {
	let a = Math.max(.01, n / Math.max(1, r)), [o, s] = [-a / 2, a / 2], c = (e, t, n) => ({
		positions: new Float32Array([
			o,
			0,
			e,
			s,
			0,
			e,
			s,
			1,
			e,
			o,
			1,
			e
		]),
		normals: new Float32Array([
			0,
			0,
			t,
			0,
			0,
			t,
			0,
			0,
			t,
			0,
			0,
			t
		]),
		uvs: new Float32Array(n ? [
			1,
			1,
			0,
			1,
			0,
			0,
			1,
			0
		] : [
			0,
			1,
			1,
			1,
			1,
			0,
			0,
			0
		]),
		colors: null,
		indices: new Uint32Array(t === 1 ? [
			0,
			1,
			2,
			0,
			2,
			3
		] : [
			0,
			2,
			1,
			0,
			3,
			2
		]),
		material: 0
	}), l = {
		...ct(),
		color: [
			1,
			1,
			1
		],
		roughness: 1,
		texture: 0,
		cutout: !0,
		unlit: !0
	};
	return Yt(ht([c(0, 1, !1), c(-.002, -1, !0)], [l], [{
		mime: t,
		bytes: e
	}]), i);
}
//#endregion
//#region ../../node_modules/three/examples/jsm/controls/TransformControls.js
var Zt = new h(), X = new F(), Qt = new F(), Z = new O(), $t = {
	X: new F(1, 0, 0),
	Y: new F(0, 1, 0),
	Z: new F(0, 0, 1)
}, en = { type: "change" }, tn = {
	type: "mouseDown",
	mode: null
}, nn = {
	type: "mouseUp",
	mode: null
}, rn = { type: "objectChange" }, an = class extends ae {
	constructor(e, t = null) {
		super(void 0, t);
		let n = new Tn(this);
		this._root = n;
		let r = new En();
		this._gizmo = r, n.add(r);
		let i = new Dn();
		this._plane = i, n.add(i);
		let a = this;
		function o(e, t) {
			let n = t;
			Object.defineProperty(a, e, {
				get: function() {
					return n === void 0 ? t : n;
				},
				set: function(t) {
					n !== t && (n = t, i[e] = t, r[e] = t, a.dispatchEvent({
						type: e + "-changed",
						value: t
					}), a.dispatchEvent(en));
				}
			}), a[e] = t, i[e] = t, r[e] = t;
		}
		o("camera", e), o("object", void 0), o("enabled", !0), o("axis", null), o("mode", "translate"), o("translationSnap", null), o("rotationSnap", null), o("scaleSnap", null), o("space", "world"), o("size", 1), this.viewport = null, o("dragging", !1), o("showX", !0), o("showY", !0), o("showZ", !0), o("showXY", !0), o("showYZ", !0), o("showXZ", !0), o("showXYZE", !0), o("showE", !0), o("minX", -Infinity), o("maxX", Infinity), o("minY", -Infinity), o("maxY", Infinity), o("minZ", -Infinity), o("maxZ", Infinity);
		let s = new F(), c = new F(), l = new O(), u = new O(), d = new F(), f = new O(), p = new F(), m = new F(), h = new F(), g = new F();
		o("worldPosition", s), o("worldPositionStart", c), o("worldQuaternion", l), o("worldQuaternionStart", u), o("cameraPosition", d), o("cameraQuaternion", f), o("pointStart", p), o("pointEnd", m), o("rotationAxis", h), o("rotationAngle", 0), o("eye", g), this._offset = new F(), this._startNorm = new F(), this._endNorm = new F(), this._cameraScale = new F(), this._parentPosition = new F(), this._parentQuaternion = new O(), this._parentQuaternionInv = new O(), this._parentScale = new F(), this._worldScaleStart = new F(), this._worldQuaternionInv = new O(), this._worldScale = new F(), this._positionStart = new F(), this._quaternionStart = new O(), this._scaleStart = new F(), this._getPointer = on.bind(this), this._onPointerDown = cn.bind(this), this._onPointerHover = sn.bind(this), this._onPointerMove = ln.bind(this), this._onPointerUp = un.bind(this), t !== null && this.connect(t);
	}
	connect(e) {
		super.connect(e), this.domElement.addEventListener("pointerdown", this._onPointerDown), this.domElement.addEventListener("pointermove", this._onPointerHover), this.domElement.addEventListener("pointerup", this._onPointerUp), this.domElement.style.touchAction = "none";
	}
	disconnect() {
		this.domElement.removeEventListener("pointerdown", this._onPointerDown), this.domElement.removeEventListener("pointermove", this._onPointerHover), this.domElement.removeEventListener("pointermove", this._onPointerMove), this.domElement.removeEventListener("pointerup", this._onPointerUp), this.domElement.style.touchAction = "";
	}
	getHelper() {
		return this._root;
	}
	pointerHover(e) {
		if (this.object === void 0 || this.dragging === !0) return;
		e !== null && Zt.setFromCamera(e, this.camera);
		let t = dn(this._gizmo.picker[this.mode], Zt);
		this.axis = t ? t.object.name : null;
	}
	pointerDown(e) {
		if (!(this.object === void 0 || this.dragging === !0 || e != null && e.button !== 0) && this.axis !== null) {
			e !== null && Zt.setFromCamera(e, this.camera);
			let t = dn(this._plane, Zt, !0);
			t && (this.object.updateMatrixWorld(), this.object.parent.updateMatrixWorld(), this._positionStart.copy(this.object.position), this._quaternionStart.copy(this.object.quaternion), this._scaleStart.copy(this.object.scale), this.object.matrixWorld.decompose(this.worldPositionStart, this.worldQuaternionStart, this._worldScaleStart), this.pointStart.copy(t.point).sub(this.worldPositionStart)), this.dragging = !0, tn.mode = this.mode, this.dispatchEvent(tn);
		}
	}
	pointerMove(e) {
		let t = this.axis, n = this.mode, r = this.object, i = this.space;
		if (n === "scale" ? i = "local" : (t === "E" || t === "XYZE" || t === "XYZ") && (i = "world"), r === void 0 || t === null || this.dragging === !1 || e !== null && e.button !== -1) return;
		e !== null && Zt.setFromCamera(e, this.camera);
		let a = dn(this._plane, Zt, !0);
		if (a) {
			if (this.pointEnd.copy(a.point).sub(this.worldPositionStart), n === "translate") this._offset.copy(this.pointEnd).sub(this.pointStart), i === "local" && t !== "XYZ" && this._offset.applyQuaternion(this._worldQuaternionInv), t.indexOf("X") === -1 && (this._offset.x = 0), t.indexOf("Y") === -1 && (this._offset.y = 0), t.indexOf("Z") === -1 && (this._offset.z = 0), i === "local" && t !== "XYZ" ? this._offset.applyQuaternion(this._quaternionStart).divide(this._parentScale) : this._offset.applyQuaternion(this._parentQuaternionInv).divide(this._parentScale), r.position.copy(this._offset).add(this._positionStart), this.translationSnap && (i === "local" && (r.position.applyQuaternion(Z.copy(this._quaternionStart).invert()), t.search("X") !== -1 && (r.position.x = Math.round(r.position.x / this.translationSnap) * this.translationSnap), t.search("Y") !== -1 && (r.position.y = Math.round(r.position.y / this.translationSnap) * this.translationSnap), t.search("Z") !== -1 && (r.position.z = Math.round(r.position.z / this.translationSnap) * this.translationSnap), r.position.applyQuaternion(this._quaternionStart)), i === "world" && (r.getWorldPosition(X), t.search("X") !== -1 && (X.x = Math.round(X.x / this.translationSnap) * this.translationSnap), t.search("Y") !== -1 && (X.y = Math.round(X.y / this.translationSnap) * this.translationSnap), t.search("Z") !== -1 && (X.z = Math.round(X.z / this.translationSnap) * this.translationSnap), r.position.copy(r.parent.worldToLocal(X)))), r.position.x = Math.max(this.minX, Math.min(this.maxX, r.position.x)), r.position.y = Math.max(this.minY, Math.min(this.maxY, r.position.y)), r.position.z = Math.max(this.minZ, Math.min(this.maxZ, r.position.z));
			else if (n === "scale") {
				if (t.search("XYZ") !== -1) {
					let e = this.pointEnd.length() / this.pointStart.length();
					this.pointEnd.dot(this.pointStart) < 0 && (e *= -1), Qt.set(e, e, e);
				} else X.copy(this.pointStart), Qt.copy(this.pointEnd), X.applyQuaternion(this._worldQuaternionInv), Qt.applyQuaternion(this._worldQuaternionInv), Qt.divide(X), t.search("X") === -1 && (Qt.x = 1), t.search("Y") === -1 && (Qt.y = 1), t.search("Z") === -1 && (Qt.z = 1);
				r.scale.copy(this._scaleStart).multiply(Qt), this.scaleSnap && (t.search("X") !== -1 && (r.scale.x = Math.round(r.scale.x / this.scaleSnap) * this.scaleSnap || this.scaleSnap), t.search("Y") !== -1 && (r.scale.y = Math.round(r.scale.y / this.scaleSnap) * this.scaleSnap || this.scaleSnap), t.search("Z") !== -1 && (r.scale.z = Math.round(r.scale.z / this.scaleSnap) * this.scaleSnap || this.scaleSnap));
			} else if (n === "rotate") {
				this._offset.copy(this.pointEnd).sub(this.pointStart);
				let e = 20 / this.worldPosition.distanceTo(X.setFromMatrixPosition(this.camera.matrixWorld)), n = !1;
				t === "XYZE" ? (this.rotationAxis.copy(this._offset).cross(this.eye).normalize(), this.rotationAngle = this._offset.dot(X.copy(this.rotationAxis).cross(this.eye)) * e) : (t === "X" || t === "Y" || t === "Z") && (this.rotationAxis.copy($t[t]), X.copy($t[t]), i === "local" && X.applyQuaternion(this.worldQuaternion), X.cross(this.eye), X.length() === 0 ? n = !0 : this.rotationAngle = this._offset.dot(X.normalize()) * e), (t === "E" || n) && (this.rotationAxis.copy(this.eye), this.rotationAngle = this.pointEnd.angleTo(this.pointStart), this._startNorm.copy(this.pointStart).normalize(), this._endNorm.copy(this.pointEnd).normalize(), this.rotationAngle *= this._endNorm.cross(this._startNorm).dot(this.eye) < 0 ? 1 : -1), this.rotationSnap && (this.rotationAngle = Math.round(this.rotationAngle / this.rotationSnap) * this.rotationSnap), i === "local" && t !== "E" && t !== "XYZE" ? (r.quaternion.copy(this._quaternionStart), r.quaternion.multiply(Z.setFromAxisAngle(this.rotationAxis, this.rotationAngle)).normalize()) : (this.rotationAxis.applyQuaternion(this._parentQuaternionInv), r.quaternion.copy(Z.setFromAxisAngle(this.rotationAxis, this.rotationAngle)), r.quaternion.multiply(this._quaternionStart).normalize());
			}
			this.dispatchEvent(en), this.dispatchEvent(rn);
		}
	}
	pointerUp(e) {
		(e === null || e.button === 0) && (this.dragging && this.axis !== null && (nn.mode = this.mode, this.dispatchEvent(nn)), this.dragging = !1, this.axis = null);
	}
	dispose() {
		this.disconnect(), this._root.dispose();
	}
	attach(e) {
		return this.object = e, this._root.visible = !0, this;
	}
	detach() {
		return this.object = void 0, this.axis = null, this._root.visible = !1, this;
	}
	reset() {
		this.enabled && this.dragging && (this.object.position.copy(this._positionStart), this.object.quaternion.copy(this._quaternionStart), this.object.scale.copy(this._scaleStart), this.dispatchEvent(en), this.dispatchEvent(rn), this.pointStart.copy(this.pointEnd));
	}
	getRaycaster() {
		return Zt;
	}
	getMode() {
		return this.mode;
	}
	setMode(e) {
		this.mode = e;
	}
	setTranslationSnap(e) {
		this.translationSnap = e;
	}
	setRotationSnap(e) {
		this.rotationSnap = e;
	}
	setScaleSnap(e) {
		this.scaleSnap = e;
	}
	setSize(e) {
		this.size = e;
	}
	setSpace(e) {
		this.space = e;
	}
	setColors(e, t, n, r) {
		let i = this._gizmo.materialLib;
		i.xAxis.color.set(e), i.yAxis.color.set(t), i.zAxis.color.set(n), i.active.color.set(r), i.xAxisTransparent.color.set(e), i.yAxisTransparent.color.set(t), i.zAxisTransparent.color.set(n), i.activeTransparent.color.set(r), i.xAxis._color && i.xAxis._color.set(e), i.yAxis._color && i.yAxis._color.set(t), i.zAxis._color && i.zAxis._color.set(n), i.active._color && i.active._color.set(r), i.xAxisTransparent._color && i.xAxisTransparent._color.set(e), i.yAxisTransparent._color && i.yAxisTransparent._color.set(t), i.zAxisTransparent._color && i.zAxisTransparent._color.set(n), i.activeTransparent._color && i.activeTransparent._color.set(r);
	}
};
function on(e) {
	if (this.domElement.ownerDocument.pointerLockElement) return {
		x: 0,
		y: 0,
		button: e.button
	};
	{
		let t = this.domElement.getBoundingClientRect(), n = this.viewport, r, i, a, o;
		return n === null ? (r = 0, i = 0, a = t.width, o = t.height) : (r = n.x, i = t.height - n.y - n.w, a = n.z, o = n.w), {
			x: (e.clientX - t.left - r) / a * 2 - 1,
			y: -(e.clientY - t.top - i) / o * 2 + 1,
			button: e.button
		};
	}
}
function sn(e) {
	if (this.enabled) switch (e.pointerType) {
		case "mouse":
		case "pen": this.pointerHover(this._getPointer(e));
	}
}
function cn(e) {
	this.enabled && (document.pointerLockElement || this.domElement.setPointerCapture(e.pointerId), this.domElement.addEventListener("pointermove", this._onPointerMove), this.pointerHover(this._getPointer(e)), this.pointerDown(this._getPointer(e)));
}
function ln(e) {
	this.enabled && this.pointerMove(this._getPointer(e));
}
function un(e) {
	this.enabled && (this.domElement.releasePointerCapture(e.pointerId), this.domElement.removeEventListener("pointermove", this._onPointerMove), this.pointerUp(this._getPointer(e)));
}
function dn(e, t, n) {
	let r = t.intersectObject(e, !0);
	for (let e = 0; e < r.length; e++) if (r[e].object.visible || n) return r[e];
	return !1;
}
var fn = new m(), Q = new F(0, 1, 0), pn = new F(0, 0, 0), mn = new ne(), hn = new O(), gn = new O(), _n = new F(), vn = new ne(), yn = new F(1, 0, 0), bn = new F(0, 1, 0), xn = new F(0, 0, 1), Sn = new F(), Cn = new F(), wn = new F(), Tn = class extends y {
	constructor(e) {
		super(), this.isTransformControlsRoot = !0, this.controls = e, this.visible = !1;
	}
	updateMatrixWorld(e) {
		let t = this.controls;
		t.object !== void 0 && (t.object.updateMatrixWorld(), t.object.parent === null ? console.error("TransformControls: The attached 3D object must be a part of the scene graph.") : t.object.parent.matrixWorld.decompose(t._parentPosition, t._parentQuaternion, t._parentScale), t.object.matrixWorld.decompose(t.worldPosition, t.worldQuaternion, t._worldScale), t._parentQuaternionInv.copy(t._parentQuaternion).invert(), t._worldQuaternionInv.copy(t.worldQuaternion).invert()), t.camera.updateMatrixWorld(), t.camera.matrixWorld.decompose(t.cameraPosition, t.cameraQuaternion, t._cameraScale), t.camera.isOrthographicCamera ? t.camera.getWorldDirection(t.eye).negate() : t.eye.copy(t.cameraPosition).sub(t.worldPosition).normalize(), this.parent && (vn.copy(this.parent.matrixWorld).invert(), vn.decompose(this.position, this.quaternion, this.scale)), super.updateMatrixWorld(e);
	}
	dispose() {
		this.traverse(function(e) {
			e.geometry && e.geometry.dispose(), e.material && e.material.dispose();
		});
	}
}, En = class extends y {
	constructor() {
		super(), this.isTransformControlsGizmo = !0, this.type = "TransformControlsGizmo";
		let e = new C({
			depthTest: !1,
			depthWrite: !1,
			fog: !1,
			toneMapped: !1,
			transparent: !0
		}), t = new j({
			depthTest: !1,
			depthWrite: !1,
			fog: !1,
			toneMapped: !1,
			transparent: !0
		}), n = e.clone();
		n.opacity = .15;
		let r = t.clone();
		r.opacity = .5;
		let i = e.clone();
		i.color.setHex(16711680);
		let a = e.clone();
		a.color.setHex(65280);
		let o = e.clone();
		o.color.setHex(255);
		let s = e.clone();
		s.color.setHex(16711680), s.opacity = .5;
		let c = e.clone();
		c.color.setHex(65280), c.opacity = .5;
		let l = e.clone();
		l.color.setHex(255), l.opacity = .5;
		let f = e.clone();
		f.opacity = .25;
		let p = e.clone();
		p.color.setHex(16776960), p.opacity = .25;
		let m = e.clone();
		m.color.setHex(16776960);
		let h = e.clone();
		h.color.setHex(7895160), this.materialLib = {
			xAxis: i,
			yAxis: a,
			zAxis: o,
			active: m,
			xAxisTransparent: s,
			yAxisTransparent: c,
			zAxisTransparent: l,
			activeTransparent: p
		};
		let g = new M(0, .04, .1, 12);
		g.translate(0, .05, 0);
		let _ = new N(.08, .08, .08);
		_.translate(0, .04, 0);
		let v = new fe();
		v.setAttribute("position", new d([
			0,
			0,
			0,
			1,
			0,
			0
		], 3));
		let b = new M(.0075, .0075, .5, 3);
		b.translate(0, .25, 0);
		function x(e, t) {
			let n = new ce(e, .0075, 3, 64, t * Math.PI * 2);
			return n.rotateY(Math.PI / 2), n.rotateX(Math.PI / 2), n;
		}
		function S() {
			let e = new fe();
			return e.setAttribute("position", new d([
				0,
				0,
				0,
				1,
				1,
				1
			], 3)), e;
		}
		let w = {
			X: [
				[
					new V(g, i),
					[
						.5,
						0,
						0
					],
					[
						0,
						0,
						-Math.PI / 2
					]
				],
				[
					new V(g, i),
					[
						-.5,
						0,
						0
					],
					[
						0,
						0,
						Math.PI / 2
					]
				],
				[
					new V(b, i),
					[
						0,
						0,
						0
					],
					[
						0,
						0,
						-Math.PI / 2
					]
				]
			],
			Y: [
				[new V(g, a), [
					0,
					.5,
					0
				]],
				[
					new V(g, a),
					[
						0,
						-.5,
						0
					],
					[
						Math.PI,
						0,
						0
					]
				],
				[new V(b, a)]
			],
			Z: [
				[
					new V(g, o),
					[
						0,
						0,
						.5
					],
					[
						Math.PI / 2,
						0,
						0
					]
				],
				[
					new V(g, o),
					[
						0,
						0,
						-.5
					],
					[
						-Math.PI / 2,
						0,
						0
					]
				],
				[
					new V(b, o),
					null,
					[
						Math.PI / 2,
						0,
						0
					]
				]
			],
			XYZ: [[new V(new u(.1, 0), f), [
				0,
				0,
				0
			]]],
			XY: [[new V(new N(.15, .15, .01), l), [
				.15,
				.15,
				0
			]]],
			YZ: [[
				new V(new N(.15, .15, .01), s),
				[
					0,
					.15,
					.15
				],
				[
					0,
					Math.PI / 2,
					0
				]
			]],
			XZ: [[
				new V(new N(.15, .15, .01), c),
				[
					.15,
					0,
					.15
				],
				[
					-Math.PI / 2,
					0,
					0
				]
			]]
		}, T = {
			X: [[
				new V(new M(.2, 0, .6, 4), n),
				[
					.3,
					0,
					0
				],
				[
					0,
					0,
					-Math.PI / 2
				]
			], [
				new V(new M(.2, 0, .6, 4), n),
				[
					-.3,
					0,
					0
				],
				[
					0,
					0,
					Math.PI / 2
				]
			]],
			Y: [[new V(new M(.2, 0, .6, 4), n), [
				0,
				.3,
				0
			]], [
				new V(new M(.2, 0, .6, 4), n),
				[
					0,
					-.3,
					0
				],
				[
					0,
					0,
					Math.PI
				]
			]],
			Z: [[
				new V(new M(.2, 0, .6, 4), n),
				[
					0,
					0,
					.3
				],
				[
					Math.PI / 2,
					0,
					0
				]
			], [
				new V(new M(.2, 0, .6, 4), n),
				[
					0,
					0,
					-.3
				],
				[
					-Math.PI / 2,
					0,
					0
				]
			]],
			XYZ: [[new V(new u(.2, 0), n)]],
			XY: [[new V(new N(.2, .2, .01), n), [
				.15,
				.15,
				0
			]]],
			YZ: [[
				new V(new N(.2, .2, .01), n),
				[
					0,
					.15,
					.15
				],
				[
					0,
					Math.PI / 2,
					0
				]
			]],
			XZ: [[
				new V(new N(.2, .2, .01), n),
				[
					.15,
					0,
					.15
				],
				[
					-Math.PI / 2,
					0,
					0
				]
			]]
		}, E = {
			START: [[
				new V(new u(.01, 2), r),
				null,
				null,
				null,
				"helper"
			]],
			END: [[
				new V(new u(.01, 2), r),
				null,
				null,
				null,
				"helper"
			]],
			DELTA: [[
				new R(S(), r),
				null,
				null,
				null,
				"helper"
			]],
			X: [[
				new R(v, r),
				[
					-1e3,
					0,
					0
				],
				null,
				[
					1e6,
					1,
					1
				],
				"helper"
			]],
			Y: [[
				new R(v, r),
				[
					0,
					-1e3,
					0
				],
				[
					0,
					0,
					Math.PI / 2
				],
				[
					1e6,
					1,
					1
				],
				"helper"
			]],
			Z: [[
				new R(v, r),
				[
					0,
					0,
					-1e3
				],
				[
					0,
					-Math.PI / 2,
					0
				],
				[
					1e6,
					1,
					1
				],
				"helper"
			]]
		}, D = {
			XYZE: [[
				new V(x(.5, 1), h),
				null,
				[
					0,
					Math.PI / 2,
					0
				]
			]],
			X: [[new V(x(.5, .5), i)]],
			Y: [[
				new V(x(.5, .5), a),
				null,
				[
					0,
					0,
					-Math.PI / 2
				]
			]],
			Z: [[
				new V(x(.5, .5), o),
				null,
				[
					0,
					Math.PI / 2,
					0
				]
			]],
			E: [[
				new V(x(.75, 1), p),
				null,
				[
					0,
					Math.PI / 2,
					0
				]
			]]
		}, O = { AXIS: [[
			new R(v, r),
			[
				-1e3,
				0,
				0
			],
			null,
			[
				1e6,
				1,
				1
			],
			"helper"
		]] }, k = {
			XYZE: [[new V(new ee(.25, 10, 8), n)]],
			X: [[
				new V(new ce(.5, .1, 4, 24), n),
				[
					0,
					0,
					0
				],
				[
					0,
					-Math.PI / 2,
					-Math.PI / 2
				]
			]],
			Y: [[
				new V(new ce(.5, .1, 4, 24), n),
				[
					0,
					0,
					0
				],
				[
					Math.PI / 2,
					0,
					0
				]
			]],
			Z: [[
				new V(new ce(.5, .1, 4, 24), n),
				[
					0,
					0,
					0
				],
				[
					0,
					0,
					-Math.PI / 2
				]
			]],
			E: [[new V(new ce(.75, .1, 2, 24), n)]]
		}, A = {
			X: [
				[
					new V(_, i),
					[
						.5,
						0,
						0
					],
					[
						0,
						0,
						-Math.PI / 2
					]
				],
				[
					new V(b, i),
					[
						0,
						0,
						0
					],
					[
						0,
						0,
						-Math.PI / 2
					]
				],
				[
					new V(_, i),
					[
						-.5,
						0,
						0
					],
					[
						0,
						0,
						Math.PI / 2
					]
				]
			],
			Y: [
				[new V(_, a), [
					0,
					.5,
					0
				]],
				[new V(b, a)],
				[
					new V(_, a),
					[
						0,
						-.5,
						0
					],
					[
						0,
						0,
						Math.PI
					]
				]
			],
			Z: [
				[
					new V(_, o),
					[
						0,
						0,
						.5
					],
					[
						Math.PI / 2,
						0,
						0
					]
				],
				[
					new V(b, o),
					[
						0,
						0,
						0
					],
					[
						Math.PI / 2,
						0,
						0
					]
				],
				[
					new V(_, o),
					[
						0,
						0,
						-.5
					],
					[
						-Math.PI / 2,
						0,
						0
					]
				]
			],
			XY: [[new V(new N(.15, .15, .01), l), [
				.15,
				.15,
				0
			]]],
			YZ: [[
				new V(new N(.15, .15, .01), s),
				[
					0,
					.15,
					.15
				],
				[
					0,
					Math.PI / 2,
					0
				]
			]],
			XZ: [[
				new V(new N(.15, .15, .01), c),
				[
					.15,
					0,
					.15
				],
				[
					-Math.PI / 2,
					0,
					0
				]
			]],
			XYZ: [[new V(new N(.1, .1, .1), f)]]
		}, te = {
			X: [[
				new V(new M(.2, 0, .6, 4), n),
				[
					.3,
					0,
					0
				],
				[
					0,
					0,
					-Math.PI / 2
				]
			], [
				new V(new M(.2, 0, .6, 4), n),
				[
					-.3,
					0,
					0
				],
				[
					0,
					0,
					Math.PI / 2
				]
			]],
			Y: [[new V(new M(.2, 0, .6, 4), n), [
				0,
				.3,
				0
			]], [
				new V(new M(.2, 0, .6, 4), n),
				[
					0,
					-.3,
					0
				],
				[
					0,
					0,
					Math.PI
				]
			]],
			Z: [[
				new V(new M(.2, 0, .6, 4), n),
				[
					0,
					0,
					.3
				],
				[
					Math.PI / 2,
					0,
					0
				]
			], [
				new V(new M(.2, 0, .6, 4), n),
				[
					0,
					0,
					-.3
				],
				[
					-Math.PI / 2,
					0,
					0
				]
			]],
			XY: [[new V(new N(.2, .2, .01), n), [
				.15,
				.15,
				0
			]]],
			YZ: [[
				new V(new N(.2, .2, .01), n),
				[
					0,
					.15,
					.15
				],
				[
					0,
					Math.PI / 2,
					0
				]
			]],
			XZ: [[
				new V(new N(.2, .2, .01), n),
				[
					.15,
					0,
					.15
				],
				[
					-Math.PI / 2,
					0,
					0
				]
			]],
			XYZ: [[new V(new N(.2, .2, .2), n), [
				0,
				0,
				0
			]]]
		}, ne = {
			X: [[
				new R(v, r),
				[
					-1e3,
					0,
					0
				],
				null,
				[
					1e6,
					1,
					1
				],
				"helper"
			]],
			Y: [[
				new R(v, r),
				[
					0,
					-1e3,
					0
				],
				[
					0,
					0,
					Math.PI / 2
				],
				[
					1e6,
					1,
					1
				],
				"helper"
			]],
			Z: [[
				new R(v, r),
				[
					0,
					0,
					-1e3
				],
				[
					0,
					-Math.PI / 2,
					0
				],
				[
					1e6,
					1,
					1
				],
				"helper"
			]]
		};
		function P(e) {
			let t = new y();
			for (let n in e) for (let r = e[n].length; r--;) {
				let i = e[n][r][0].clone(), a = e[n][r][1], o = e[n][r][2], s = e[n][r][3], c = e[n][r][4];
				i.name = n, i.tag = c, a && i.position.set(a[0], a[1], a[2]), o && i.rotation.set(o[0], o[1], o[2]), s && i.scale.set(s[0], s[1], s[2]), i.updateMatrix();
				let l = i.geometry.clone();
				l.applyMatrix4(i.matrix), i.geometry = l, i.renderOrder = Infinity, i.position.set(0, 0, 0), i.rotation.set(0, 0, 0), i.scale.set(1, 1, 1), t.add(i);
			}
			return t;
		}
		this.gizmo = {}, this.picker = {}, this.helper = {}, this.add(this.gizmo.translate = P(w)), this.add(this.gizmo.rotate = P(D)), this.add(this.gizmo.scale = P(A)), this.add(this.picker.translate = P(T)), this.add(this.picker.rotate = P(k)), this.add(this.picker.scale = P(te)), this.add(this.helper.translate = P(E)), this.add(this.helper.rotate = P(O)), this.add(this.helper.scale = P(ne)), this.picker.translate.visible = !1, this.picker.rotate.visible = !1, this.picker.scale.visible = !1;
	}
	updateMatrixWorld(e) {
		let t = (this.mode === "scale" ? "local" : this.space) === "local" ? this.worldQuaternion : gn;
		this.gizmo.translate.visible = this.mode === "translate", this.gizmo.rotate.visible = this.mode === "rotate", this.gizmo.scale.visible = this.mode === "scale", this.helper.translate.visible = this.mode === "translate", this.helper.rotate.visible = this.mode === "rotate", this.helper.scale.visible = this.mode === "scale";
		let n = [];
		n = n.concat(this.picker[this.mode].children), n = n.concat(this.gizmo[this.mode].children), n = n.concat(this.helper[this.mode].children);
		for (let e = 0; e < n.length; e++) {
			let r = n[e];
			r.visible = !0, r.rotation.set(0, 0, 0), r.position.copy(this.worldPosition);
			let i;
			if (i = this.camera.isOrthographicCamera ? (this.camera.top - this.camera.bottom) / this.camera.zoom : this.worldPosition.distanceTo(this.cameraPosition) * Math.min(1.9 * Math.tan(Math.PI * this.camera.fov / 360) / this.camera.zoom, 7), r.scale.set(1, 1, 1).multiplyScalar(i * this.size / 4), r.tag === "helper") r.visible = !1, r.name === "AXIS" ? (r.visible = !!this.axis, this.axis === "X" && (Z.setFromEuler(fn.set(0, 0, 0)), r.quaternion.copy(t).multiply(Z), Math.abs(Q.copy(yn).applyQuaternion(t).dot(this.eye)) > .9 && (r.visible = !1)), this.axis === "Y" && (Z.setFromEuler(fn.set(0, 0, Math.PI / 2)), r.quaternion.copy(t).multiply(Z), Math.abs(Q.copy(bn).applyQuaternion(t).dot(this.eye)) > .9 && (r.visible = !1)), this.axis === "Z" && (Z.setFromEuler(fn.set(0, Math.PI / 2, 0)), r.quaternion.copy(t).multiply(Z), Math.abs(Q.copy(xn).applyQuaternion(t).dot(this.eye)) > .9 && (r.visible = !1)), this.axis === "XYZE" && (Z.setFromEuler(fn.set(0, Math.PI / 2, 0)), Q.copy(this.rotationAxis), r.quaternion.setFromRotationMatrix(mn.lookAt(pn, Q, bn)), r.quaternion.multiply(Z), r.visible = this.dragging), this.axis === "E" && (r.visible = !1)) : r.name === "START" ? (r.position.copy(this.worldPositionStart), r.visible = this.dragging) : r.name === "END" ? (r.position.copy(this.worldPosition), r.visible = this.dragging) : r.name === "DELTA" ? (r.position.copy(this.worldPositionStart), r.quaternion.copy(this.worldQuaternionStart), X.set(1e-10, 1e-10, 1e-10).add(this.worldPositionStart).sub(this.worldPosition).multiplyScalar(-1), X.applyQuaternion(this.worldQuaternionStart.clone().invert()), r.scale.copy(X), r.visible = this.dragging) : (r.quaternion.copy(t), this.dragging ? r.position.copy(this.worldPositionStart) : r.position.copy(this.worldPosition), this.axis && (r.visible = this.axis.search(r.name) !== -1));
			else {
				if (r.quaternion.copy(t), this.mode === "translate" || this.mode === "scale") {
					let e = .99, n = .2;
					r.name === "X" && Math.abs(Q.copy(yn).applyQuaternion(t).dot(this.eye)) > e && (r.scale.set(1e-10, 1e-10, 1e-10), r.visible = !1), r.name === "Y" && Math.abs(Q.copy(bn).applyQuaternion(t).dot(this.eye)) > e && (r.scale.set(1e-10, 1e-10, 1e-10), r.visible = !1), r.name === "Z" && Math.abs(Q.copy(xn).applyQuaternion(t).dot(this.eye)) > e && (r.scale.set(1e-10, 1e-10, 1e-10), r.visible = !1), r.name === "XY" && Math.abs(Q.copy(xn).applyQuaternion(t).dot(this.eye)) < n && (r.scale.set(1e-10, 1e-10, 1e-10), r.visible = !1), r.name === "YZ" && Math.abs(Q.copy(yn).applyQuaternion(t).dot(this.eye)) < n && (r.scale.set(1e-10, 1e-10, 1e-10), r.visible = !1), r.name === "XZ" && Math.abs(Q.copy(bn).applyQuaternion(t).dot(this.eye)) < n && (r.scale.set(1e-10, 1e-10, 1e-10), r.visible = !1);
				} else this.mode === "rotate" && (hn.copy(t), Q.copy(this.eye).applyQuaternion(Z.copy(t).invert()), r.name.search("E") !== -1 && r.quaternion.setFromRotationMatrix(mn.lookAt(this.eye, pn, bn)), r.name === "X" && (Z.setFromAxisAngle(yn, Math.atan2(-Q.y, Q.z)), Z.multiplyQuaternions(hn, Z), r.quaternion.copy(Z)), r.name === "Y" && (Z.setFromAxisAngle(bn, Math.atan2(Q.x, Q.z)), Z.multiplyQuaternions(hn, Z), r.quaternion.copy(Z)), r.name === "Z" && (Z.setFromAxisAngle(xn, Math.atan2(Q.y, Q.x)), Z.multiplyQuaternions(hn, Z), r.quaternion.copy(Z)));
				r.visible = r.visible && (r.name.indexOf("X") === -1 || this.showX), r.visible = r.visible && (r.name.indexOf("Y") === -1 || this.showY), r.visible = r.visible && (r.name.indexOf("Z") === -1 || this.showZ), r.visible = r.visible && (r.name.indexOf("E") === -1 || this.showX && this.showY && this.showZ), r.visible = r.visible && (r.name.indexOf("XY") === -1 || this.showXY), r.visible = r.visible && (r.name.indexOf("YZ") === -1 || this.showYZ), r.visible = r.visible && (r.name.indexOf("XZ") === -1 || this.showXZ), r.visible = r.visible && (r.name !== "E" || this.showE), r.visible = r.visible && (r.name !== "XYZE" || this.showXYZE), r.material._color = r.material._color || r.material.color.clone(), r.material._opacity = r.material._opacity || r.material.opacity, r.material.color.copy(r.material._color), r.material.opacity = r.material._opacity, this.enabled && this.axis && (r.name === this.axis || this.axis.split("").some(function(e) {
					return r.name === e;
				})) && (r.material.color.copy(this.materialLib.active.color), r.material.opacity = 1);
			}
		}
		super.updateMatrixWorld(e);
	}
}, Dn = class extends V {
	constructor() {
		super(new he(1e5, 1e5, 2, 2), new C({
			visible: !1,
			wireframe: !0,
			side: 2,
			transparent: !0,
			opacity: .1,
			toneMapped: !1
		})), this.isTransformControlsPlane = !0, this.type = "TransformControlsPlane";
	}
	updateMatrixWorld(e) {
		let t = this.space;
		switch (this.position.copy(this.worldPosition), this.mode === "scale" && (t = "local"), Sn.copy(yn).applyQuaternion(t === "local" ? this.worldQuaternion : gn), Cn.copy(bn).applyQuaternion(t === "local" ? this.worldQuaternion : gn), wn.copy(xn).applyQuaternion(t === "local" ? this.worldQuaternion : gn), Q.copy(Cn), this.mode) {
			case "translate":
			case "scale":
				switch (this.axis) {
					case "X":
						Q.copy(this.eye).cross(Sn), _n.copy(Sn).cross(Q);
						break;
					case "Y":
						Q.copy(this.eye).cross(Cn), _n.copy(Cn).cross(Q);
						break;
					case "Z":
						Q.copy(this.eye).cross(wn), _n.copy(wn).cross(Q);
						break;
					case "XY":
						_n.copy(wn);
						break;
					case "YZ":
						_n.copy(Sn);
						break;
					case "XZ":
						Q.copy(wn), _n.copy(Cn);
						break;
					case "XYZ":
					case "E": _n.set(0, 0, 0);
				}
				break;
			default: _n.set(0, 0, 0);
		}
		_n.length() === 0 ? this.quaternion.copy(this.cameraQuaternion) : (vn.lookAt(X.set(0, 0, 0), _n, Q), this.quaternion.setFromRotationMatrix(vn)), super.updateMatrixWorld(e);
	}
}, On = "\nout vec2 vUv;\nvoid main() {\n  vUv = uv;\n  gl_Position = vec4(position.xy, 0.0, 1.0);\n}\n", kn = "\nprecision highp float;\nprecision highp int;\nprecision highp sampler2DArray;\n#define MAXS 48\nout vec4 fragColor;\n\nuniform int uCount;\nuniform int uKind[MAXS];      // 0-6 solids, 7 an outline pushed out, 20 a group starts, 21 it ends\nuniform sampler2DArray uFields; // outline distance fields, one layer each (signed distance in texels)\nuniform vec4 uF[MAXS];        // x field layer, y the field's half size, z one texel, in the shape's units\nuniform mat3 uRot[MAXS];      // world to local\nuniform vec3 uPos[MAXS];\nuniform vec3 uHalf[MAXS];\nuniform vec4 uP[MAXS];        // x rounding radius, y torus thickness, z blend radius, w combine (0 add, 1 subtract, 2 intersect)\nuniform vec3 uCol[MAXS];      // linear colour\nuniform vec2 uMat[MAXS];      // x shininess, y metal\n\nuniform vec2 uRes;\nuniform vec2 uTileOffset;     // the part of the picture this draw covers (a tile of a big export, or all of it)\nuniform vec2 uTileSize;\nuniform vec3 uCamPos;\nuniform mat3 uCamRot;          // camera to world: columns right, up, back\nuniform float uTanHalf;\nuniform int uOrtho;\nuniform float uOrthoHalf;\n\nuniform vec3 uLightDir;\nuniform vec3 uLightCol;\nuniform float uIntensity;\nuniform float uAmbient;\nuniform int uShadows;\n\nuniform int uLook;             // 0 soft, 1 toon, 2 flat, 3 clay\nuniform float uOutline;        // pixels\nuniform vec3 uOutlineCol;\nuniform float uBands;\nuniform int uTransparent;\nuniform vec3 uBg;\nuniform int uGround;\nuniform float uGroundShadow;\nuniform int uSamples;          // 1 or 2 (2x2 samples per pixel)\nuniform float uGrid;           // the editing grid's cell on the ground (scene units), 0 for none (pictures and video never have one)\nuniform mat4 uViewProj;        // world to clip: the depth written, so imported models and shapes hide each other\nuniform sampler2D uMeshShadow; // imported models' depth seen from the light, for the shadows they cast\nuniform mat4 uLightViewProj;\nuniform int uMeshShadowOn;\nuniform float uShadowBias;\n\nfloat len2(vec2 v) { return length(v); }\n\nfloat shapeDist(int i, vec3 p) {\n  vec3 hs = uHalf[i];\n  float r = uP[i].x;\n  int k = uKind[i];\n  if (k == 0) { // box\n    vec3 q = abs(p) - hs + r;\n    return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0) - r;\n  }\n  if (k == 1) { // sphere, an ellipsoid\n    float k0 = length(p / hs);\n    float k1 = length(p / (hs * hs));\n    return k1 > 0.0 ? k0 * (k0 - 1.0) / k1 : -min(hs.x, min(hs.y, hs.z));\n  }\n  if (k == 2) { // cylinder\n    float ra = min(hs.x, hs.z);\n    float rr = min(r, min(ra, hs.y));\n    vec2 d = vec2(len2(vec2(p.x * ra / hs.x, p.z * ra / hs.z)) - ra + rr, abs(p.y) - hs.y + rr);\n    return min(max(d.x, d.y), 0.0) + length(max(d, 0.0)) - rr;\n  }\n  if (k == 3) { // cone, base down\n    float ra = min(hs.x, hs.z);\n    vec2 q = vec2(len2(vec2(p.x * ra / hs.x, p.z * ra / hs.z)), p.y);\n    float h = hs.y;\n    vec2 k1 = vec2(0.0, h);\n    vec2 k2 = vec2(-ra, 2.0 * h);\n    vec2 ca = vec2(q.x - min(q.x, q.y < 0.0 ? ra : 0.0), abs(q.y) - h);\n    vec2 cb = q - k1 + k2 * clamp(dot(k1 - q, k2) / dot(k2, k2), 0.0, 1.0);\n    float s = (cb.x < 0.0 && ca.y < 0.0) ? -1.0 : 1.0;\n    return s * sqrt(min(dot(ca, ca), dot(cb, cb))) - r * 0.5;\n  }\n  if (k == 4) { // torus\n    float tube = min(uP[i].y * hs.x, hs.y);\n    float ring = max(hs.x - tube, 0.001);\n    return len2(vec2(len2(vec2(p.x, p.z * hs.x / hs.z)) - ring, p.y)) - tube;\n  }\n  if (k == 5) { // capsule\n    float ra = min(hs.x, hs.z);\n    float h = max(hs.y - ra, 0.0);\n    float cy = p.y - clamp(p.y, -h, h);\n    return length(vec3(p.x * ra / hs.x, cy, p.z * ra / hs.z)) - ra;\n  }\n  if (k == 7) { // an outline pushed out along z, rounded\n    vec4 f = uF[i];\n    vec2 uv = vec2(p.x + f.y, f.y - p.y) / (2.0 * f.y);\n    float inner = texture(uFields, vec3(clamp(uv, 0.0, 1.0), f.x)).r * f.z;\n    float d2 = inner + length(max(abs(p.xy) - f.y * 0.98, 0.0));\n    float rr = min(r, hs.z * 0.95);\n    vec2 w = vec2(d2 + rr, abs(p.z) - hs.z + rr);\n    return min(max(w.x, w.y), 0.0) + length(max(w, 0.0)) - rr;\n  }\n  // pyramid, base down\n  float b = min(hs.x, hs.z);\n  float hgt = 2.0 * hs.y / (2.0 * b);\n  vec3 pp = vec3(abs(p.x * b / hs.x), p.y + hs.y, abs(p.z * b / hs.z)) / (2.0 * b);\n  if (pp.z > pp.x) pp.xz = pp.zx;\n  pp.xz -= 0.5;\n  float m2 = hgt * hgt + 0.25;\n  vec3 q = vec3(pp.z, hgt * pp.y - 0.5 * pp.x, hgt * pp.x + 0.5 * pp.y);\n  float s = max(-q.x, 0.0);\n  float t = clamp((q.y - 0.5 * pp.z) / (m2 + 0.25), 0.0, 1.0);\n  float a = m2 * (q.x + s) * (q.x + s) + q.y * q.y;\n  float bb = m2 * (q.x + 0.5 * t) * (q.x + 0.5 * t) + (q.y - m2 * t) * (q.y - m2 * t);\n  float d2 = min(q.y, -q.x * m2 - q.y * 0.5) > 0.0 ? 0.0 : min(a, bb);\n  return 2.0 * b * sqrt((d2 + q.z * q.z) / m2) * sign(max(q.z, -pp.y)) - r * 0.5;\n}\n\n// joins a shape (di, its colour and finish) onto what came before, added, cut or intersected, softly over k. Kept in step with join in sdf.ts\nvoid join(inout float d, inout vec3 col, inout vec2 mat, float di, vec3 ci, vec2 mi, float k, int op) {\n  float h;\n  if (op == 0) {\n    if (k > 1e-4) { h = clamp(0.5 + 0.5 * (d - di) / k, 0.0, 1.0); d = mix(d, di, h) - k * h * (1.0 - h); }\n    else { h = di < d ? 1.0 : 0.0; d = min(d, di); }\n  } else if (op == 1) {\n    float cut = -di;\n    if (k > 1e-4) { h = clamp(0.5 - 0.5 * (cut - d) / k, 0.0, 1.0); d = mix(d, cut, h) + k * h * (1.0 - h); }\n    else { h = cut > d ? 1.0 : 0.0; d = max(d, cut); }\n  } else {\n    if (k > 1e-4) { h = clamp(0.5 - 0.5 * (di - d) / k, 0.0, 1.0); d = mix(d, di, h) + k * h * (1.0 - h); }\n    else { h = di > d ? 1.0 : 0.0; d = max(d, di); }\n  }\n  col = mix(col, ci, h);\n  mat = mix(mat, mi, h);\n}\n\n// the design: shapes joined in order; a group joins its own shapes first, then joins what came before as one. Kept in step with sampleScene in sdf.ts\nfloat map(vec3 p, out vec3 col, out vec2 mat) {\n  float d = 1e9;\n  col = vec3(0.8);\n  mat = vec2(32.0, 0.0);\n  float gd = 1e9;\n  vec3 gcol = vec3(0.8);\n  vec2 gmat = vec2(32.0, 0.0);\n  for (int i = 0; i < MAXS; i++) {\n    if (i >= uCount) break;\n    int k = uKind[i];\n    if (k == 20) {\n      gd = d; gcol = col; gmat = mat;\n      d = 1e9; col = vec3(0.8); mat = vec2(32.0, 0.0);\n      continue;\n    }\n    if (k == 21) {\n      float di = d; vec3 ci = col; vec2 mi = mat;\n      d = gd; col = gcol; mat = gmat;\n      join(d, col, mat, di, ci, mi, uP[i].z, int(uP[i].w + 0.5));\n      continue;\n    }\n    float di = shapeDist(i, uRot[i] * (p - uPos[i]));\n    join(d, col, mat, di, uCol[i], uMat[i], uP[i].z, int(uP[i].w + 0.5));\n  }\n  return d;\n}\n\nfloat mapD(vec3 p) { vec3 c; vec2 m; return map(p, c, m); }\n\nvec3 normalAt(vec3 p, float t) {\n  float e = 0.0005 * max(1.0, t);\n  vec2 k = vec2(1.0, -1.0);\n  return normalize(k.xyy * mapD(p + k.xyy * e) + k.yyx * mapD(p + k.yyx * e) + k.yxy * mapD(p + k.yxy * e) + k.xxx * mapD(p + k.xxx * e));\n}\n\n// imported models in the way of the light, from their depth map (a little soft: nine taps)\nfloat meshShadow(vec3 p) {\n  if (uMeshShadowOn == 0) return 1.0;\n  vec4 c = uLightViewProj * vec4(p, 1.0);\n  vec3 q = c.xyz / c.w * 0.5 + 0.5;\n  if (q.x < 0.0 || q.y < 0.0 || q.x > 1.0 || q.y > 1.0) return 1.0;\n  // beyond the far side of the light's box still takes the shadow of what is in it\n  float z = min(q.z, 1.0) - uShadowBias;\n  vec2 texel = 1.5 / vec2(textureSize(uMeshShadow, 0));\n  float lit = 0.0;\n  for (int x = -1; x <= 1; x++)\n    for (int y = -1; y <= 1; y++) lit += step(z, texture(uMeshShadow, q.xy + vec2(float(x), float(y)) * texel).r);\n  return lit / 9.0;\n}\n\nfloat softShadow(vec3 ro, vec3 rd) {\n  if (uShadows == 0) return 1.0;\n  float res = 1.0;\n  float t = 0.02;\n  for (int i = 0; i < 64; i++) {\n    float h = mapD(ro + rd * t);\n    res = min(res, 10.0 * h / t);\n    t += clamp(h, 0.02, 0.4);\n    if (res < 0.002 || t > 30.0) break;\n  }\n  return clamp(res, 0.0, 1.0);\n}\n\nfloat ambientOcclusion(vec3 p, vec3 n) {\n  float occ = 0.0;\n  float sca = 1.0;\n  for (int i = 0; i < 5; i++) {\n    float h = 0.02 + 0.12 * float(i);\n    occ += (h - mapD(p + n * h)) * sca;\n    sca *= 0.75;\n  }\n  return clamp(1.0 - 1.6 * occ, 0.0, 1.0);\n}\n\n// occ: a model's own ambient occlusion (1 for none); like the field's, it darkens only the light that is not direct\nvec3 shade(vec3 p, vec3 n, vec3 rd, vec3 albedo, vec2 mat, float occ) {\n  if (uLook == 3) albedo = vec3(0.86, 0.84, 0.82);\n  vec3 l = normalize(uLightDir);\n  float diff = max(dot(n, l), 0.0);\n  float sh = diff > 0.0 ? softShadow(p + n * 0.003, l) * meshShadow(p + n * 0.01) : 0.0;\n  float ao = ambientOcclusion(p, n) * occ;\n  vec3 h = normalize(l - rd);\n  float spec = pow(max(dot(n, h), 0.0), mat.x) * diff * sh;\n  float sky = 0.5 + 0.5 * n.y;\n  if (uLook == 2) return albedo * (0.82 + 0.18 * diff);\n  if (uLook == 1) {\n    float lit = diff * sh;\n    float stepped = floor(lit * uBands + 0.5) / uBands;\n    float rim = pow(1.0 - max(dot(n, -rd), 0.0), 3.0) * 0.25;\n    float highlight = step(0.92, spec / max(diff, 0.001) * diff) * 0.35;\n    return albedo * (uAmbient * 0.9 * occ + uIntensity * 0.75 * stepped) + uLightCol * (highlight + rim * stepped);\n  }\n  // soft: a key light, a cool fill from the other side so the shadow side keeps its form, sky from above, a rim, and the finish's highlight\n  vec3 specCol = mix(vec3(1.0), albedo, mat.y);\n  vec3 base = albedo * (1.0 - 0.6 * mat.y);\n  vec3 fillDir = normalize(vec3(-l.x, 0.3, -l.z));\n  float fill = max(dot(n, fillDir), 0.0);\n  float rim = pow(1.0 - max(dot(n, -rd), 0.0), 4.0);\n  vec3 c = base * uLightCol * diff * sh * uIntensity;\n  c += base * vec3(0.72, 0.82, 1.0) * uAmbient * (0.25 + 0.75 * fill) * ao;\n  c += base * uAmbient * 0.45 * sky * ao;\n  c += uLightCol * rim * 0.22 * uIntensity * ao * sky;\n  c += specCol * uLightCol * spec * uIntensity * mix(0.35, 1.6, mat.y) * (mat.x > 60.0 ? 1.0 : 0.6);\n  // a warm bounce from below\n  c += base * vec3(1.0, 0.9, 0.8) * 0.05 * max(-n.y, 0.0);\n  return c;\n}\n\n// the ray through a point of the picture\nvoid rayFor(vec2 frag, out vec3 ro, out vec3 rd) {\n  vec2 ndc = (frag / uRes) * 2.0 - 1.0;\n  float aspect = uRes.x / uRes.y;\n  if (uOrtho == 1) {\n    ro = uCamPos + uCamRot * vec3(ndc.x * uOrthoHalf * aspect, ndc.y * uOrthoHalf, 0.0);\n    rd = normalize(uCamRot * vec3(0.0, 0.0, -1.0));\n  } else {\n    ro = uCamPos;\n    rd = normalize(uCamRot * vec3(ndc.x * uTanHalf * aspect, ndc.y * uTanHalf, -1.0));\n  }\n}\n\n// where a ray meets the ground plane (x, z), or far away when it never does\nvec2 onGround(vec3 ro, vec3 rd) {\n  return rd.y < -1e-5 && ro.y > 0.0 || rd.y > 1e-5 && ro.y < 0.0 ? (ro + rd * (-ro.y / rd.y)).xz : vec2(1e6);\n}\n\n// lines at whole numbers of c, about one pixel wide (fw: how far c moves across a pixel)\nfloat gridLines(vec2 c, vec2 fw) {\n  vec2 d = abs(fract(c - 0.5) - 0.5) / max(fw, vec2(1e-6));\n  return 1.0 - min(min(d.x, d.y), 1.0);\n}\n\n// The editing grid on the ground: a thin line every cell, a stronger one every fifth, the x axis red and the z axis blue. Lines fade where the\n// cells get too small to tell apart, so far away there is no shimmer. Straight colour and alpha.\nvec4 gridAt(vec2 frag, vec3 ro, vec3 rd) {\n  vec2 g = onGround(ro, rd);\n  if (uGrid <= 0.0 || g.x > 1e5) return vec4(0.0);\n  // how far the ground point moves across one pixel, from the rays through the neighbouring pixels\n  vec3 ro1, rd1, ro2, rd2;\n  rayFor(frag + vec2(1.0, 0.0), ro1, rd1);\n  rayFor(frag + vec2(0.0, 1.0), ro2, rd2);\n  vec2 fw = min(abs(onGround(ro1, rd1) - g) + abs(onGround(ro2, rd2) - g), vec2(1e3));\n  float big = uGrid * 5.0;\n  float minor = gridLines(g / uGrid, fw / uGrid) * (1.0 - smoothstep(0.12, 0.3, max(fw.x, fw.y) / uGrid));\n  float major = gridLines(g / big, fw / big) * (1.0 - smoothstep(0.12, 0.3, max(fw.x, fw.y) / big));\n  vec2 axis = (1.0 - min(abs(g) / max(fw * 1.9, vec2(1e-6)), 1.0)) * (1.0 - smoothstep(0.5, 2.0, fw.yx / uGrid));\n  vec3 ink = uTransparent == 0 && dot(uBg, vec3(0.299, 0.587, 0.114)) > 0.5 ? vec3(0.12, 0.1, 0.18) : vec3(0.82, 0.8, 0.9);\n  vec4 c = vec4(ink, max(minor * 0.22, major * 0.42));\n  // the x axis runs where z = 0, the z axis where x = 0\n  if (axis.y > 0.0) c = mix(c, vec4(1.0, 0.36, 0.4, 0.95), axis.y);\n  if (axis.x > 0.0) c = mix(c, vec4(0.38, 0.6, 1.0, 0.95), axis.x);\n  return c;\n}\n\n// b drawn over a (straight colours)\nvec4 over(vec4 a, vec4 b) {\n  float alpha = b.a + a.a * (1.0 - b.a);\n  return alpha > 0.0 ? vec4((b.rgb * b.a + a.rgb * a.a * (1.0 - b.a)) / alpha, alpha) : vec4(0.0);\n}\n\n", An = kn + "\nin vec2 vUv;\n// the depth of what this pixel shows (1 for nothing)\nfloat gDepth;\nfloat depthOf(vec3 p) {\n  vec4 c = uViewProj * vec4(p, 1.0);\n  return clamp(c.z / c.w * 0.5 + 0.5, 0.0, 1.0);\n}\n\nvec4 render(vec2 frag) {\n  vec3 ro, rd;\n  rayFor(frag, ro, rd);\n  // a pixel's width in scene units at distance t: the outline is measured in pixels\n  float pixel = uOrtho == 1 ? 2.0 * uOrthoHalf / uRes.y : 2.0 * uTanHalf / uRes.y;\n  float outlinePx = uOutline * uRes.y / 1000.0;\n\n  float tGround = (uGround == 1 && rd.y < -1e-4) ? -ro.y / rd.y : 1e9;\n  float t = uOrtho == 1 ? 0.0 : 0.01;\n  float closest = 1e9;\n  bool hit = false;\n  vec3 col; vec2 mat;\n  for (int i = 0; i < 200; i++) {\n    vec3 p = ro + rd * t;\n    float d = map(p, col, mat);\n    float w = uOrtho == 1 ? pixel : pixel * max(t, 0.01);\n    closest = min(closest, d / w);\n    if (d < 0.0004 * max(1.0, t)) { hit = true; break; }\n    t += d * 0.92;\n    if (t > 120.0 || t > tGround + 0.5) break;\n  }\n  if (hit && t < tGround + 1e-3) {\n    vec3 p = ro + rd * t;\n    vec3 n = normalAt(p, t);\n    vec3 c = shade(p, n, rd, col, mat, 1.0);\n    gDepth = depthOf(p);\n    // an inked edge where the surface turns away from the eye\n    if (outlinePx > 0.0) {\n      float facing = abs(dot(n, rd));\n      float edge = smoothstep(0.12 + 0.02 * outlinePx, 0.02, facing);\n      c = mix(c, uOutlineCol, edge);\n    }\n    return vec4(c, 1.0);\n  }\n  if (outlinePx > 0.0 && closest < outlinePx) return vec4(uOutlineCol, smoothstep(outlinePx, outlinePx * 0.6, closest));\n  vec4 bg = uTransparent == 1 ? vec4(0.0) : vec4(uBg, 1.0);\n  if (tGround < 1e8) {\n    vec3 g = ro + rd * tGround;\n    // the floor hides what is under it\n    gDepth = depthOf(g);\n    float sh = 1.0 - softShadow(g + vec3(0.0, 0.002, 0.0), normalize(uLightDir)) * meshShadow(g);\n    // fades out away from the middle, so the floor has no edge\n    float fade = exp(-0.08 * length(g.xz));\n    float a = sh * uGroundShadow * fade;\n    bg = uTransparent == 1 ? vec4(0.0, 0.0, 0.0, a) : vec4(bg.rgb * (1.0 - a), 1.0);\n  }\n  return over(bg, gridAt(frag, ro, rd));\n}\n\nvoid main() {\n  vec2 frag = uTileOffset + vUv * uTileSize;\n  vec4 acc = vec4(0.0);\n  float depth = 1.0;\n  if (uSamples > 1) {\n    for (int sy = 0; sy < 2; sy++)\n      for (int sx = 0; sx < 2; sx++) {\n        gDepth = 1.0;\n        vec4 c = render(frag + (vec2(float(sx), float(sy)) - 0.5) * 0.5);\n        acc += vec4(c.rgb * c.a, c.a);\n        depth = min(depth, gDepth);\n      }\n    acc /= 4.0;\n  } else {\n    gDepth = 1.0;\n    vec4 c = render(frag);\n    acc = vec4(c.rgb * c.a, c.a);\n    depth = gDepth;\n  }\n  gl_FragDepth = depth;\n  // to sRGB, alpha not premultiplied\n  vec3 rgb = acc.a > 0.0 ? acc.rgb / acc.a : vec3(0.0);\n  fragColor = vec4(pow(max(rgb, 0.0), vec3(1.0 / 2.2)), acc.a);\n}\n", jn = "\nin vec3 aColor;\nuniform mat3 uNormalWorld;\nout vec3 vWorld;\nout vec3 vNormal;\nout vec2 vMeshUv;\nout vec3 vColor;\nvoid main() {\n  vec4 w = modelMatrix * vec4(position, 1.0);\n  vWorld = w.xyz;\n  vNormal = uNormalWorld * normal;\n  vMeshUv = uv;\n  vColor = aColor;\n  gl_Position = projectionMatrix * viewMatrix * w;\n}\n", Mn = kn + "\nin vec3 vWorld;\nin vec3 vNormal;\nin vec2 vMeshUv;\nin vec3 vColor;\nuniform vec3 uAlbedo;     // linear\nuniform sampler2D uMap;   // sRGB\nuniform int uHasMap;\nuniform vec2 uFinish;     // shininess, metal (the shape's finish, or the model's when it has no roughness)\nuniform int uCutout;\nuniform int uUnlit;          // 1: the colours as they are, no light (a photo card)\nuniform sampler2D uNormalMap;\nuniform int uHasNormal;\nuniform float uNormalScale;\nuniform sampler2D uRoughMap; // glTF: roughness in green, metalness in blue\nuniform int uPbr;            // 1: the finish from the model's roughness and metalness (uRoughMetal, scaled by uRoughMap)\nuniform int uHasRough;\nuniform vec2 uRoughMetal;\nuniform sampler2D uAoMap;     // red: ambient occlusion\nuniform int uHasAo;\nuniform float uAoStrength;\nuniform vec3 uEmissive;       // linear, strength included\nuniform sampler2D uEmissiveMap; // sRGB\nuniform int uHasEmissive;\nuniform float uClearcoat;      // 0 for none\nuniform float uCoatRough;\nuniform sampler2D uCoatMap;    // red: amount\nuniform int uHasCoatMap;\nuniform sampler2D uCoatRoughMap; // green: roughness\nuniform int uHasCoatRoughMap;\nuniform sampler2D uCoatNormalMap;\nuniform int uHasCoatNormal;\nuniform float uCoatNormalScale;\nuniform vec3 uSheen;           // linear colour, black for none\nuniform float uSheenRough;\nuniform sampler2D uSheenMap;   // sRGB colour\nuniform int uHasSheenMap;\nuniform sampler2D uSheenRoughMap; // alpha: roughness\nuniform int uHasSheenRoughMap;\nuniform float uTransmission;   // 0 for none\nuniform sampler2D uTransmissionMap; // red: amount\nuniform int uHasTransmissionMap;\nuniform float uIor;\nuniform sampler2D uBackdrop;   // what was drawn behind (sRGB, straight alpha), for light passing through\nuniform int uHasBackdrop;\n\n// a soft studio around the design, for what a glossy layer reflects: a dark floor, a bright sky, and a long softbox above the horizon (the\n// band a varnished or glass surface shows). Kept in step with studio in cpu.ts\nvec3 studio(vec3 dir) {\n  float box = smoothstep(0.22, 0.32, dir.y) * (1.0 - smoothstep(0.5, 0.62, dir.y));\n  return (mix(vec3(0.3, 0.28, 0.27), vec3(0.85, 0.9, 1.0), smoothstep(-0.25, 0.6, dir.y)) + 1.6 * box) * (0.5 + uAmbient) * uLightCol;\n}\nfloat fresnel(float cosTheta, float f0) {\n  return f0 + (1.0 - f0) * pow(1.0 - cosTheta, 5.0);\n}\n\n// a normal map's normal, in a tangent frame made from how the position and texture coordinates change across the pixel (no stored tangents).\n// glTF's normal maps have +Y up the picture, which is against v here (v runs down the picture)\nvec3 mappedNormal(sampler2D map, float strength, vec3 n, vec2 uv, vec3 dp1, vec3 dp2, vec2 duv1, vec2 duv2) {\n  vec3 dp2perp = cross(dp2, n), dp1perp = cross(n, dp1);\n  vec3 t = dp2perp * duv1.x + dp1perp * duv2.x;\n  vec3 b = dp2perp * duv1.y + dp1perp * duv2.y;\n  float scale = max(dot(t, t), dot(b, b));\n  if (scale < 1e-20) return n;\n  // a back face's frame was made with the turned-round normal: turned back\n  float k = (gl_FrontFacing ? 1.0 : -1.0) * inversesqrt(scale);\n  vec3 m = texture(map, uv).xyz * 2.0 - 1.0;\n  m.xy *= strength;\n  return normalize(mat3(t * k, -b * k, n) * m);\n}\n\nvoid main() {\n  // the changes across the pixel, taken before anything can discard it\n  vec3 dp1 = dFdx(vWorld), dp2 = dFdy(vWorld);\n  vec2 duv1 = dFdx(vMeshUv), duv2 = dFdy(vMeshUv);\n  vec4 tex = uHasMap == 1 ? texture(uMap, vMeshUv) : vec4(1.0);\n  if (uCutout == 1 && tex.a < 0.5) discard;\n  if (uUnlit == 1) {\n    fragColor = vec4(uAlbedo * tex.rgb * vColor, 1.0);\n    return;\n  }\n  vec3 n = normalize(vNormal);\n  if (!gl_FrontFacing) n = -n;\n  // the surface's own shape, before the normal map (a clear coat lies over it)\n  vec3 shapeN = n;\n  if (uHasNormal == 1) n = mappedNormal(uNormalMap, uNormalScale, n, vMeshUv, dp1, dp2, duv1, duv2);\n  vec2 finish = uFinish;\n  if (uPbr == 1) {\n    vec2 rm = uRoughMetal;\n    if (uHasRough == 1) rm *= texture(uRoughMap, vMeshUv).gb;\n    finish = vec2(6.0 + (1.0 - rm.x) * (1.0 - rm.x) * 134.0, rm.y);\n  }\n  vec3 rd = uOrtho == 1 ? normalize(uCamRot * vec3(0.0, 0.0, -1.0)) : normalize(vWorld - uCamPos);\n  vec3 albedo = uAlbedo * pow(tex.rgb, vec3(2.2)) * vColor;\n  float occ = uHasAo == 1 ? 1.0 + uAoStrength * (texture(uAoMap, vMeshUv).r - 1.0) : 1.0;\n  vec3 c = shade(vWorld, n, rd, albedo, finish, occ);\n  vec3 l = normalize(uLightDir);\n  vec3 v = -rd;\n  float alpha = 1.0;\n  // the layers a physical material adds (clay shows the form only; toon and flat stay drawn)\n  bool layered = uLook == 0 && (uClearcoat > 0.0 || max(uSheen.r, max(uSheen.g, uSheen.b)) > 0.0 || uTransmission > 0.0);\n  float vis = layered ? softShadow(vWorld + shapeN * 0.003, l) * meshShadow(vWorld + shapeN * 0.01) : 1.0;\n  // light passing through, like glass: what was drawn behind, bent a little and tinted by the surface's colour\n  float trans = uLook != 3 ? uTransmission * (uHasTransmissionMap == 1 ? texture(uTransmissionMap, vMeshUv).r : 1.0) : 0.0;\n  if (trans > 0.0 && uHasBackdrop == 1) {\n    float f0 = pow((uIor - 1.0) / (uIor + 1.0), 2.0);\n    float f = fresnel(max(dot(n, v), 0.0), f0);\n    vec3 nv = normalize(mat3(viewMatrix) * n);\n    vec2 size = vec2(textureSize(uBackdrop, 0));\n    vec2 uv = gl_FragCoord.xy / size - nv.xy * (1.0 - 1.0 / uIor) * 0.08;\n    vec4 behind = texture(uBackdrop, clamp(uv, vec2(0.0), vec2(1.0)));\n    vec3 through = pow(behind.rgb, vec3(2.2)) * albedo;\n    float k = trans * (1.0 - f);\n    vec3 h = normalize(l + v);\n    float glint = pow(max(dot(n, h), 0.0), max(finish.x, 60.0)) * max(dot(n, l), 0.0) * vis * uIntensity;\n    c = mix(c, through, k) + studio(reflect(rd, n)) * f * trans + uLightCol * glint;\n    alpha = mix(1.0, behind.a, k);\n    alpha = clamp(alpha + glint + f * trans, 0.0, 1.0);\n  }\n  // a velvet glow at grazing angles\n  if (uLook == 0 && max(uSheen.r, max(uSheen.g, uSheen.b)) > 0.0) {\n    vec3 sheen = uSheen * (uHasSheenMap == 1 ? pow(texture(uSheenMap, vMeshUv).rgb, vec3(2.2)) : vec3(1.0));\n    float rough = uSheenRough * (uHasSheenRoughMap == 1 ? texture(uSheenRoughMap, vMeshUv).a : 1.0);\n    float rim = pow(1.0 - max(dot(n, v), 0.0), mix(5.0, 1.5, rough));\n    c += sheen * rim * (uLightCol * uIntensity * max(dot(n, l), 0.0) * vis * 0.8 + uAmbient * 0.6 * occ);\n  }\n  // a clear varnish on top: a sharp highlight and the studio reflected, more at grazing angles, the surface below a little dimmer\n  if (uLook == 0 && uClearcoat > 0.0) {\n    float coat = uClearcoat * (uHasCoatMap == 1 ? texture(uCoatMap, vMeshUv).r : 1.0);\n    float rough = uCoatRough * (uHasCoatRoughMap == 1 ? texture(uCoatRoughMap, vMeshUv).g : 1.0);\n    vec3 nc = uHasCoatNormal == 1 ? mappedNormal(uCoatNormalMap, uCoatNormalScale, shapeN, vMeshUv, dp1, dp2, duv1, duv2) : shapeN;\n    float f = fresnel(max(dot(nc, v), 0.0), 0.04);\n    vec3 h = normalize(l + v);\n    float shine = 8.0 + (1.0 - rough) * (1.0 - rough) * 600.0;\n    float spec = pow(max(dot(nc, h), 0.0), shine) * max(dot(nc, l), 0.0) * vis * uIntensity * (1.0 + shine / 120.0);\n    vec3 reflected = studio(reflect(rd, nc)) * mix(1.0, 0.35, rough);\n    c = c * (1.0 - coat * f) + coat * (uLightCol * spec + reflected * f);\n  }\n  // the light it gives off, on top (clay shows the form only)\n  if (uLook != 3) c += uEmissive * (uHasEmissive == 1 ? pow(texture(uEmissiveMap, vMeshUv).rgb, vec3(2.2)) : vec3(1.0));\n  if (uOutline > 0.0) {\n    float outlinePx = uOutline * uRes.y / 1000.0;\n    float edge = smoothstep(0.12 + 0.02 * outlinePx, 0.02, abs(dot(n, rd)));\n    c = mix(c, uOutlineCol, edge);\n    alpha = mix(alpha, 1.0, edge);\n  }\n  fragColor = vec4(pow(max(c, 0.0), vec3(1.0 / 2.2)), alpha);\n}\n", Nn = "\nin vec3 aHull;\nuniform mat3 uNormalWorld;\nuniform float uOutline;\nuniform vec2 uRes;\nvoid main() {\n  vec4 clip = projectionMatrix * viewMatrix * modelMatrix * vec4(position, 1.0);\n  vec4 nclip = projectionMatrix * viewMatrix * vec4(normalize(uNormalWorld * aHull), 0.0);\n  vec2 dir = nclip.xy;\n  float l = length(dir);\n  dir = l > 1e-6 ? dir / l : vec2(0.0);\n  clip.xy += dir * (uOutline * uRes.y / 1000.0) * 2.0 / uRes * clip.w;\n  gl_Position = clip;\n}\n", Pn = "\nprecision highp float;\nuniform vec3 uOutlineCol;\nout vec4 fragColor;\nvoid main() {\n  fragColor = vec4(pow(uOutlineCol, vec3(1.0 / 2.2)), 1.0);\n}\n", Fn = {
	box: 0,
	sphere: 1,
	cylinder: 2,
	cone: 3,
	torus: 4,
	capsule: 5,
	pyramid: 6,
	extrude: 7,
	text: 7
}, In = {
	matte: [8, 0],
	satin: [32, 0],
	glossy: [140, 0],
	metal: [64, 1]
}, Ln = {
	soft: 0,
	toon: 1,
	flat: 2,
	clay: 3,
	pixel: 1
}, Rn = {
	add: 0,
	subtract: 1,
	intersect: 2
}, zn = (e) => {
	let t = new le(e);
	return new F(t.r ** 2.2, t.g ** 2.2, t.b ** 2.2);
};
function Bn(e) {
	let t = B.degToRad(e.yaw), n = B.degToRad(e.pitch), r = new F(...e.target), i = new F(Math.sin(t) * Math.cos(n), Math.sin(n), Math.cos(t) * Math.cos(n)).multiplyScalar(e.distance);
	return {
		position: r.clone().add(i),
		target: r
	};
}
var Vn = class {
	texture;
	grids = [];
	constructor() {
		let e = (/* @__PURE__ */ new Uint16Array(1048576)).fill(pe.toHalfFloat(24));
		this.texture = new S(e, 256, 256, 16), this.texture.format = g, this.texture.type = w, this.texture.minFilter = this.texture.magFilter = P, this.texture.unpackAlignment = 1, this.texture.needsUpdate = !0;
	}
	put(e, t) {
		let n = Xe(t.outline, t.size[0], t.size[1]);
		if (this.grids[e] !== n.grid) {
			this.grids[e] = n.grid;
			let t = this.texture.image.data, r = e * 256 * 256;
			for (let e = 0; e < n.grid.length; e++) t[r + e] = pe.toHalfFloat(n.grid[e]);
			this.texture.addLayerUpdate(e), this.texture.needsUpdate = !0;
		}
		return {
			half: n.half,
			texel: n.texel
		};
	}
	dispose() {
		this.texture.dispose();
	}
}, $ = new s(new Uint8Array([
	255,
	255,
	255,
	255
]), 1, 1);
$.needsUpdate = !0;
function Hn(e, t, n = 1) {
	let { position: r, target: i } = Bn(e.camera), a = Math.tan(B.degToRad(e.camera.fov / 2)) * n, o;
	if (e.camera.projection === "orthographic") {
		let n = e.camera.distance * a;
		o = new f(-n * t, n * t, n, -n, .05, 500);
	} else o = new p(B.radToDeg(2 * Math.atan(a)), t, .05, 500);
	return o.position.copy(r), o.up.set(0, 1, 0), o.lookAt(i), o.updateMatrixWorld(), o.updateProjectionMatrix(), o.layers.enable(2), o;
}
function Un(e) {
	return {
		uCount: { value: 0 },
		uKind: { value: Array(48).fill(0) },
		uFields: { value: e.texture },
		uF: { value: Array.from({ length: 48 }, () => new A()) },
		uRot: { value: Array.from({ length: 48 }, () => new me()) },
		uPos: { value: Array.from({ length: 48 }, () => new F()) },
		uHalf: { value: Array.from({ length: 48 }, () => new F(.5, .5, .5)) },
		uP: { value: Array.from({ length: 48 }, () => new A()) },
		uCol: { value: Array.from({ length: 48 }, () => new F(.8, .8, .8)) },
		uMat: { value: Array.from({ length: 48 }, () => new I(32, 0)) },
		uRes: { value: new I(1, 1) },
		uTileOffset: { value: new I(0, 0) },
		uTileSize: { value: new I(1, 1) },
		uCamPos: { value: new F() },
		uCamRot: { value: new me() },
		uTanHalf: { value: .3 },
		uOrtho: { value: 0 },
		uOrthoHalf: { value: 1 },
		uLightDir: { value: new F(.5, .8, .5) },
		uLightCol: { value: new F(1, 1, 1) },
		uIntensity: { value: 1.4 },
		uAmbient: { value: .35 },
		uShadows: { value: 1 },
		uLook: { value: 0 },
		uOutline: { value: 0 },
		uOutlineCol: { value: new F() },
		uBands: { value: 3 },
		uTransparent: { value: 1 },
		uBg: { value: new F(1, 1, 1) },
		uGround: { value: 1 },
		uGroundShadow: { value: .35 },
		uSamples: { value: 1 },
		uGrid: { value: 0 },
		uViewProj: { value: new ne() },
		uMeshShadow: { value: $ },
		uLightViewProj: { value: new ne() },
		uMeshShadowOn: { value: 0 },
		uShadowBias: { value: .0015 }
	};
}
function Wn(e, t, n, r, i, a = 1) {
	let o = Ve(n).slice(0, 48);
	e.uCount.value = o.length;
	let s = 0;
	o.forEach((n, r) => {
		if (n.op !== "shape") {
			e.uKind.value[r] = n.op === "begin" ? 20 : 21, e.uP.value[r].set(0, 0, n.group.blend * .6, Rn[n.group.combine]);
			return;
		}
		let i = n.shape;
		if (i.kind === "group" || i.kind === "mesh") return;
		if (e.uKind.value[r] = Fn[i.kind], i.outline && s < 16) {
			let n = t.put(s, i);
			e.uF.value[r].set(s++, n.half, n.texel, 0);
		}
		let a = Re(i.rotation);
		e.uRot.value[r].set(a[0], a[3], a[6], a[1], a[4], a[7], a[2], a[5], a[8]), e.uPos.value[r].set(...i.position), e.uHalf.value[r].set(i.size[0] / 2, i.size[1] / 2, i.size[2] / 2), e.uP.value[r].set(i.round * Math.min(...i.size), i.thickness, i.blend * .6, Rn[i.combine]), e.uCol.value[r].copy(zn(i.color)), e.uMat.value[r].set(...In[i.finish]);
	}), e.uRes.value.set(r, i), e.uTileOffset.value.set(0, 0), e.uTileSize.value.set(r, i);
	let { position: c, target: l } = Bn(n.camera), u = new ne().lookAt(c, l, new F(0, 1, 0));
	e.uCamPos.value.copy(c), e.uCamRot.value.setFromMatrix4(u);
	let d = Math.tan(B.degToRad(n.camera.fov / 2)) * a;
	e.uTanHalf.value = d, e.uOrtho.value = +(n.camera.projection === "orthographic"), e.uOrthoHalf.value = n.camera.distance * d;
	let f = B.degToRad(n.light.azimuth), p = B.degToRad(n.light.elevation);
	e.uLightDir.value.set(Math.sin(f) * Math.cos(p), Math.sin(p), Math.cos(f) * Math.cos(p)), e.uLightCol.value.copy(zn(n.light.color)), e.uIntensity.value = n.light.intensity, e.uAmbient.value = n.light.ambient, e.uShadows.value = +!!n.light.shadows, e.uLook.value = Ln[n.style.look], e.uOutline.value = n.style.outline, e.uOutlineCol.value.copy(zn(n.style.outlineColor)), e.uBands.value = n.style.bands, e.uTransparent.value = +!!n.background.transparent, e.uBg.value.copy(zn(n.background.color)), e.uGround.value = +!!n.ground.on, e.uGroundShadow.value = n.ground.shadow;
	let m = Hn(n, r / i, a);
	return e.uViewProj.value.multiplyMatrices(m.projectionMatrix, m.matrixWorldInverse), m;
}
function Gn(e) {
	return new D({
		glslVersion: E,
		vertexShader: On,
		fragmentShader: An,
		uniforms: e,
		depthTest: !0,
		depthFunc: 1,
		depthWrite: !0,
		blending: 0
	});
}
function Kn(e, t) {
	let n = /* @__PURE__ */ new Map(), r = (t) => `${Math.round(e[t * 3] * 1e4)},${Math.round(e[t * 3 + 1] * 1e4)},${Math.round(e[t * 3 + 2] * 1e4)}`, i = e.length / 3;
	for (let e = 0; e < i; e++) {
		let i = r(e), a = n.get(i) ?? [
			0,
			0,
			0
		];
		a[0] += t[e * 3], a[1] += t[e * 3 + 1], a[2] += t[e * 3 + 2], n.set(i, a);
	}
	let a = new Float32Array(e.length);
	for (let e = 0; e < i; e++) {
		let t = n.get(r(e)), i = Math.hypot(...t) || 1;
		a.set([
			t[0] / i,
			t[1] / i,
			t[2] / i
		], e * 3);
	}
	return a;
}
var qn = class {
	uniforms;
	onReady;
	scene = new T();
	glass = new T();
	backdrop = null;
	built = /* @__PURE__ */ new Map();
	materials = /* @__PURE__ */ new Map();
	shadowTarget;
	depthMaterial = new c({ side: 2 });
	holedDepths = /* @__PURE__ */ new Map();
	holedDepth(e) {
		let t = this.holedDepths.get(e);
		return t || (t = new c({
			side: 2,
			map: e,
			alphaTest: .5
		}), this.holedDepths.set(e, t)), t;
	}
	lightCamera = new f(-1, 1, 1, -1, .01, 10);
	count = 0;
	constructor(e, t = () => {}) {
		this.uniforms = e, this.onReady = t, this.shadowTarget = new te(2048, 2048, { depthTexture: new _(2048, 2048) }), this.lightCamera.layers.set(1);
	}
	build(e, t) {
		let n = this.built.get(e);
		if (n && n.data === t) return n.ready;
		let r = tt(e, t), i = r.parts.map((e) => {
			let t = new fe();
			return t.setAttribute("position", new z(e.positions, 3)), t.setAttribute("normal", new z(e.normals, 3)), e.uvs && t.setAttribute("uv", new z(e.uvs, 2)), t.setAttribute("aColor", new z(e.colors ?? new Float32Array(e.positions.length).fill(1), 3)), t.setIndex(new z(e.indices, 1)), t.setAttribute("aHull", new z(Kn(e.positions, e.normals), 3)), t.computeBoundingBox(), t.computeBoundingSphere(), t;
		}), a = {
			data: t,
			ready: Promise.resolve(null)
		};
		return a.ready = Promise.all(r.textures.map(async (e) => {
			try {
				let t = await createImageBitmap(new Blob([e.bytes], { type: e.mime }), {
					premultiplyAlpha: "none",
					colorSpaceConversion: "none"
				}), n = new re(t);
				return n.flipY = !1, n.wrapS = n.wrapT = l, n.colorSpace = "", n.anisotropy = 4, n.needsUpdate = !0, n;
			} catch {
				return null;
			}
		})).then((e) => (a.value = {
			asset: r,
			geometries: i,
			textures: e
		}, this.onReady(), a.value)), this.built.set(e, a), a.ready;
	}
	async ready(e) {
		await Promise.all(Ue(e).map(({ shape: e, asset: t }) => this.build(e.asset, t.data)));
	}
	sync(e) {
		this.scene.clear(), this.glass.clear(), this.count = 0;
		let t = /* @__PURE__ */ new Set();
		for (let { shape: n, path: r, asset: i } of Ue(e)) {
			this.build(n.asset, i.data);
			let a = this.built.get(n.asset)?.value;
			if (!a) continue;
			let { asset: o } = a, s = o.max.map((e, t) => Math.max(e - o.min[t], 1e-9)), c = o.min.map((e, t) => (e + o.max[t]) / 2), l = new ne().compose(new F(...n.position), new O().setFromEuler(Jn(n.rotation)), new F(...n.size.map((e, t) => e / s[t]))).multiply(new ne().makeTranslation(-c[0], -c[1], -c[2])), u = new me().getNormalMatrix(l), d = n.ownColors !== !1;
			o.parts.forEach((i, s) => {
				let c = `${n.id}:${s}`;
				t.add(c);
				let f = o.materials[i.material], p = d && f.texture >= 0 ? a.textures[f.texture] : null, m = this.materials.get(c);
				if (!m) {
					let e = new D({
						glslVersion: E,
						vertexShader: jn,
						fragmentShader: Mn,
						uniforms: {
							...this.uniforms,
							uNormalWorld: { value: new me() },
							uAlbedo: { value: new F() },
							uMap: { value: $ },
							uHasMap: { value: 0 },
							uFinish: { value: new I() },
							uCutout: { value: 0 },
							uUnlit: { value: 0 },
							uNormalMap: { value: $ },
							uHasNormal: { value: 0 },
							uNormalScale: { value: 1 },
							uRoughMap: { value: $ },
							uPbr: { value: 0 },
							uHasRough: { value: 0 },
							uRoughMetal: { value: new I(.6, 0) },
							uAoMap: { value: $ },
							uHasAo: { value: 0 },
							uAoStrength: { value: 1 },
							uEmissive: { value: new F() },
							uEmissiveMap: { value: $ },
							uHasEmissive: { value: 0 },
							uClearcoat: { value: 0 },
							uCoatRough: { value: 0 },
							uCoatMap: { value: $ },
							uHasCoatMap: { value: 0 },
							uCoatRoughMap: { value: $ },
							uHasCoatRoughMap: { value: 0 },
							uCoatNormalMap: { value: $ },
							uHasCoatNormal: { value: 0 },
							uCoatNormalScale: { value: 1 },
							uSheen: { value: new F() },
							uSheenRough: { value: 0 },
							uSheenMap: { value: $ },
							uHasSheenMap: { value: 0 },
							uSheenRoughMap: { value: $ },
							uHasSheenRoughMap: { value: 0 },
							uTransmission: { value: 0 },
							uTransmissionMap: { value: $ },
							uHasTransmissionMap: { value: 0 },
							uIor: { value: 1.5 },
							uBackdrop: { value: $ },
							uHasBackdrop: { value: 0 }
						},
						side: 2
					});
					m = {
						mesh: e,
						hull: new D({
							glslVersion: E,
							vertexShader: Nn,
							fragmentShader: Pn,
							uniforms: {
								uNormalWorld: e.uniforms.uNormalWorld,
								uOutline: this.uniforms.uOutline,
								uRes: this.uniforms.uRes,
								uOutlineCol: this.uniforms.uOutlineCol
							},
							side: 1
						})
					}, this.materials.set(c, m);
				}
				let h = m.mesh.uniforms, g = d && f.unlit ? 0 : 2;
				m.mesh.side !== g && (m.mesh.side = g, m.mesh.needsUpdate = !0), h.uNormalWorld.value.copy(u), h.uAlbedo.value.copy(d ? new F(...f.color) : zn(n.color)), h.uMap.value = p ?? $, h.uHasMap.value = p && i.uvs ? 1 : 0, h.uFinish.value.set(...d ? [6 + (1 - f.roughness) ** 2 * 134, f.metalness] : In[n.finish]), h.uCutout.value = d && f.cutout ? 1 : 0, h.uUnlit.value = d && f.unlit ? 1 : 0;
				let _ = f.normalTexture >= 0 && i.uvs ? a.textures[f.normalTexture] : null;
				h.uNormalMap.value = _ ?? $, h.uHasNormal.value = +!!_, h.uNormalScale.value = f.normalScale;
				let v = d && f.roughnessTexture >= 0 && i.uvs ? a.textures[f.roughnessTexture] : null;
				h.uRoughMap.value = v ?? $, h.uHasRough.value = +!!v, h.uPbr.value = +!!d, h.uRoughMetal.value.set(f.roughness, f.metalness);
				let y = f.occlusionTexture >= 0 && i.uvs ? a.textures[f.occlusionTexture] : null;
				h.uAoMap.value = y ?? $, h.uHasAo.value = +!!y, h.uAoStrength.value = f.occlusionStrength, h.uEmissive.value.set(...d ? f.emissive : [
					0,
					0,
					0
				]);
				let b = d && f.emissiveTexture >= 0 && i.uvs ? a.textures[f.emissiveTexture] : null;
				h.uEmissiveMap.value = b ?? $, h.uHasEmissive.value = +!!b;
				let x = (e) => d && e >= 0 && i.uvs ? a.textures[e] ?? null : null, S = (e, t, n) => {
					h[e].value = n ?? $, h[t].value = +!!n;
				};
				h.uClearcoat.value = d ? f.clearcoat : 0, h.uCoatRough.value = f.clearcoatRoughness, S("uCoatMap", "uHasCoatMap", x(f.clearcoatTexture)), S("uCoatRoughMap", "uHasCoatRoughMap", x(f.clearcoatRoughnessTexture)), S("uCoatNormalMap", "uHasCoatNormal", x(f.clearcoatNormalTexture)), h.uCoatNormalScale.value = f.clearcoatNormalScale, h.uSheen.value.set(...d ? f.sheenColor : [
					0,
					0,
					0
				]), h.uSheenRough.value = f.sheenRoughness, S("uSheenMap", "uHasSheenMap", x(f.sheenColorTexture)), S("uSheenRoughMap", "uHasSheenRoughMap", x(f.sheenRoughnessTexture));
				let C = d ? f.transmission : 0;
				h.uTransmission.value = C, S("uTransmissionMap", "uHasTransmissionMap", x(f.transmissionTexture)), h.uIor.value = f.ior;
				let w = a.geometries[s], T = new V(w, m.mesh);
				if (T.matrixAutoUpdate = !1, T.matrix.copy(l), T.userData.ref = r, C <= .5 && T.layers.enable(1), (C > 0 ? this.glass : this.scene).add(T), e.style.outline > 0) {
					let e = new V(w, m.hull);
					e.matrixAutoUpdate = !1, e.matrix.copy(l), e.layers.set(2), this.scene.add(e);
				}
			}), this.count++;
		}
		for (let [e, n] of this.materials) t.has(e) || (n.mesh.dispose(), n.hull.dispose(), this.materials.delete(e));
	}
	draw(e, t, n, r) {
		if (this.count && (e.render(this.scene, t), this.glass.children.length)) {
			(!this.backdrop || this.backdrop.image.width !== n || this.backdrop.image.height !== r) && (this.backdrop?.dispose(), this.backdrop = new b(n, r)), e.copyFramebufferToTexture(this.backdrop);
			for (let e of this.glass.children) {
				let t = e.material.uniforms;
				t.uBackdrop.value = this.backdrop, t.uHasBackdrop.value = 1;
			}
			e.render(this.glass, t);
		}
	}
	pickables() {
		return [...this.scene.children, ...this.glass.children].filter((e) => e.userData.ref);
	}
	renderShadow(e, t) {
		let n = this.uniforms;
		if (!this.count || !t.light.shadows) {
			n.uMeshShadowOn.value = 0, n.uMeshShadow.value = $;
			return;
		}
		this.scene.updateMatrixWorld(), this.glass.updateMatrixWorld();
		let r = new ue();
		for (let e of this.pickables()) r.expandByObject(e);
		let i = r.getCenter(new F()), a = Math.max(r.getSize(new F()).length() / 2, .01), o = B.degToRad(t.light.azimuth), s = B.degToRad(t.light.elevation), c = new F(Math.sin(o) * Math.cos(s), Math.sin(s), Math.cos(o) * Math.cos(s)).normalize(), l = this.lightCamera;
		l.position.copy(i).addScaledVector(c, a * 2), l.up.set(0, Math.abs(c.y) > .99 ? 0 : 1, +(Math.abs(c.y) > .99)), l.lookAt(i), Object.assign(l, {
			left: -a,
			right: a,
			top: a,
			bottom: -a,
			near: .01,
			far: a * 4
		}), l.updateProjectionMatrix(), l.updateMatrixWorld();
		let u = e.getRenderTarget();
		e.setRenderTarget(this.shadowTarget), e.setScissorTest(!1), e.clear();
		let d = [];
		this.scene.traverse((e) => {
			let t = e, n = t.material?.uniforms;
			t.isMesh && n?.uCutout && n.uCutout.value === 1 && n.uHasMap?.value === 1 && (d.push({
				object: t,
				material: t.material
			}), t.material = this.holedDepth(n.uMap.value));
		}), this.scene.overrideMaterial = null, this.glass.overrideMaterial = this.depthMaterial;
		let f = /* @__PURE__ */ new Map();
		this.scene.traverse((e) => {
			let t = e;
			t.isMesh && !d.some((e) => e.object === t) && (f.set(t, t.material), t.material = this.depthMaterial);
		}), e.render(this.scene, l), e.autoClear = !1, e.render(this.glass, l);
		for (let e of d) e.object.material = e.material;
		for (let [e, t] of f) e.material = t;
		this.glass.overrideMaterial = null, e.setRenderTarget(u), n.uLightViewProj.value.multiplyMatrices(l.projectionMatrix, l.matrixWorldInverse), n.uMeshShadow.value = this.shadowTarget.depthTexture, n.uMeshShadowOn.value = 1, n.uShadowBias.value = Math.max(8e-4, .01 / (a * 4));
	}
	dispose() {
		for (let e of this.built.values()) e.ready.then((e) => (e.geometries.forEach((e) => e.dispose()), e.textures.forEach((e) => e?.dispose())));
		for (let e of this.materials.values()) e.mesh.dispose(), e.hull.dispose();
		this.shadowTarget.dispose(), this.backdrop?.dispose(), this.depthMaterial.dispose();
		for (let e of this.holedDepths.values()) e.dispose();
	}
}, Jn = (e) => new m(...e.map((e) => B.degToRad(e)), "XYZ");
function Yn(e) {
	let t = new ue();
	for (let n of e.children ?? []) {
		if (n.hidden) continue;
		let e = new ne().compose(new F(...n.position), new O().setFromEuler(Jn(n.rotation)), new F(...n.size));
		t.union(new ue(new F(-.5, -.5, -.5), new F(.5, .5, .5)).applyMatrix4(e));
	}
	return t.isEmpty() ? {
		centre: new F(),
		size: new F(1, 1, 1)
	} : {
		centre: t.getCenter(new F()),
		size: t.getSize(new F())
	};
}
var Xn = (e, t = 1e3) => Math.round(e * t) / t, Zn = (e) => [
	e.x,
	e.y,
	e.z
].map((e) => Xn(B.radToDeg(e), 100)), Qn = class {
	container;
	editor;
	hooks;
	canvas;
	renderer;
	atlas = new Vn();
	uniforms = Un(this.atlas);
	meshes;
	quadScene = new T();
	quadCamera = new f(-1, 1, 1, -1, 0, 1);
	overlay = new T();
	perspective = new p(35, 1, .05, 500);
	ortho = new f(-1, 1, 1, -1, .05, 500);
	orbit;
	gizmo;
	proxy = new y();
	outline;
	selected = null;
	several = [];
	playing = null;
	doc;
	width = 1;
	height = 1;
	frame = 0;
	applying = !1;
	resize;
	gizmoStart = null;
	down = null;
	unsubscribe;
	grid = 0;
	snap = !1;
	constructor(e, t, n = {}) {
		this.container = e, this.editor = t, this.hooks = n, this.doc = t.document, this.renderer = new ke({
			antialias: !0,
			alpha: !0,
			premultipliedAlpha: !1,
			preserveDrawingBuffer: !0
		}), this.meshes = new qn(this.uniforms, () => {
			this.meshes.sync(this.doc), this.request();
		}), this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5)), this.renderer.setClearColor(0, 0), this.renderer.autoClear = !1, this.canvas = this.renderer.domElement, this.canvas.style.display = "block", this.canvas.style.width = "100%", this.canvas.style.height = "100%", e.appendChild(this.canvas), this.quadScene.add(new V(new he(2, 2), Gn(this.uniforms))), this.orbit = this.makeOrbit(this.activeCamera()), this.gizmo = new an(this.activeCamera(), this.canvas), this.gizmo.setSize(.85), this.gizmo.addEventListener("dragging-changed", (e) => {
			this.orbit.enabled = !e.value;
		}), this.gizmo.addEventListener("mouseDown", () => this.gizmoBegin()), this.gizmo.addEventListener("objectChange", () => this.gizmoChange()), this.gizmo.addEventListener("mouseUp", () => this.gizmoEnd()), this.overlay.add(this.proxy), this.overlay.add(this.gizmo.getHelper()), this.outline = new de(new oe(new N(1, 1, 1)), new j({
			color: new le(getComputedStyle(e).getPropertyValue("--gs-focus").trim() || "#b38bff"),
			transparent: !0,
			opacity: .9,
			depthTest: !1
		})), this.outline.renderOrder = 10, this.proxy.add(this.outline), this.proxy.visible = !1, this.canvas.addEventListener("pointerdown", this.onPointerDown), this.canvas.addEventListener("pointerup", this.onPointerUp), this.resize = new ResizeObserver(() => this.fit()), this.resize.observe(e), this.unsubscribe = t.subscribe(() => this.setDocument(t.document)), this.fit(), this.setDocument(this.doc);
	}
	activeCamera() {
		return this.doc.camera.projection === "orthographic" ? this.ortho : this.perspective;
	}
	makeOrbit(e) {
		let t = new Nt(e, this.canvas);
		return t.enableDamping = !1, t.zoomToCursor = !0, t.addEventListener("start", () => this.editor.begin("Turn the view")), t.addEventListener("change", () => this.orbitChange()), t.addEventListener("end", () => this.editor.commit()), t;
	}
	setDocument(e) {
		let t = e.camera.projection !== this.doc.camera.projection;
		if (this.doc = e, t) {
			let e = this.orbit.target.clone();
			this.orbit.dispose(), this.orbit = this.makeOrbit(this.activeCamera()), this.orbit.target.copy(e), this.gizmo.camera = this.activeCamera();
		}
		this.fitted !== `${e.style.look}:${e.style.pixel}` && this.fit(), this.showScene(e.background.picture), this.applyCamera(), this.meshes.sync(this.playing ?? e), this.placeProxy(), this.request();
	}
	showFrame(e) {
		this.playing = e, this.meshes.sync(e ?? this.doc), e ? (this.proxy.visible = !1, this.gizmo.detach()) : this.placeProxy(), this.request();
	}
	select(e) {
		this.several = [], this.selected = e, this.placeProxy(), this.request();
	}
	selectSeveral(e) {
		if (e.length < 2) return this.select(e.length ? [e[0]] : null);
		this.several = [...e], this.selected = null, this.placeProxy(), this.request();
	}
	items() {
		let e = this.several.length ? this.several : this.selected?.length === 1 ? [this.selected[0]] : [];
		if (!this.several.length && this.selected?.length === 2) {
			let e = ot(this.doc, this.selected);
			return e ? [{
				ref: this.selected,
				shape: e
			}] : [];
		}
		return e.flatMap((e) => {
			let t = this.doc.shapes[e];
			return t ? t.kind === "group" ? (t.children ?? []).map((t, n) => ({
				ref: [e, n],
				shape: t
			})) : [{
				ref: [e],
				shape: t
			}] : [];
		});
	}
	setGizmo(e) {
		this.gizmo.setMode(e), this.request();
	}
	setGrid(e, t = !1) {
		this.grid = Math.max(0, e), this.snap = t, this.gizmo.setRotationSnap(t ? B.degToRad(15) : null), this.request();
	}
	placeProxy() {
		if (this.gizmoStart || this.playing) return;
		let e = this.several.length ? this.several.map((e) => this.doc.shapes[e]) : [ot(this.doc, this.selected)], t = this.selected?.length === 2 && this.doc.shapes[this.selected[0]]?.hidden, n = e.filter((e) => !!e && !e.hidden);
		if (!n.length || t) {
			this.proxy.visible = !1, this.gizmo.detach();
			return;
		}
		this.proxy.visible = !0, this.proxy.scale.set(1, 1, 1);
		let r = n[0];
		if (n.length > 1 || r.kind === "group") {
			let e = Yn({
				...r,
				children: n.flatMap((e) => e.kind === "group" ? e.children ?? [] : [e])
			});
			this.proxy.position.copy(e.centre), this.proxy.rotation.set(0, 0, 0), this.outline.scale.copy(e.size);
		} else this.proxy.position.set(...r.position), this.proxy.rotation.copy(Jn(r.rotation)), this.outline.scale.set(...r.size);
		n.some((e) => e.locked) || this.selected?.length === 2 && this.doc.shapes[this.selected[0]]?.locked ? this.gizmo.detach() : this.gizmo.object !== this.proxy && this.gizmo.attach(this.proxy);
	}
	gizmoBegin() {
		let e = this.items();
		if (!e.length) return;
		let t = this.several.length ? void 0 : ot(this.doc, this.selected);
		this.gizmoStart = {
			items: e.map((e) => ({
				ref: e.ref,
				shape: { ...e.shape }
			})),
			single: !!t && t.kind !== "group",
			pivot: this.proxy.position.clone(),
			size: [
				this.outline.scale.x,
				this.outline.scale.y,
				this.outline.scale.z
			]
		}, this.editor.begin(this.gizmo.mode === "translate" ? "Move" : this.gizmo.mode === "rotate" ? "Turn" : "Resize");
	}
	gizmoChange() {
		let e = this.gizmoStart;
		if (!e) return;
		let t = this.proxy;
		if (this.snap && this.grid > 0 && this.gizmo.mode === "translate") {
			let n = this.grid, r = t.position.clone().sub(e.pivot);
			t.position.copy(e.pivot).add(new F(...r.toArray().map((e) => Math.round(e / n) * n)));
		}
		if (e.single) {
			let n = e.items[0], r = n.shape.size.map((e, n) => Math.max(.02, e * Math.abs(t.scale.getComponent(n))));
			this.outline.scale.set(...r), this.editor.updateShapeAt(n.ref, {
				position: [
					t.position.x,
					t.position.y,
					t.position.z
				],
				rotation: Zn(t.rotation),
				size: r
			});
			return;
		}
		let n = (Math.abs(t.scale.x) + Math.abs(t.scale.y) + Math.abs(t.scale.z)) / 3, r = new O().setFromEuler(t.rotation), i = t.position.clone().sub(e.pivot);
		this.outline.scale.set(e.size[0] * n, e.size[1] * n, e.size[2] * n);
		let a = e.items.map(({ shape: t }) => {
			let a = new F(...t.position).sub(e.pivot).multiplyScalar(n).applyQuaternion(r), o = r.clone().multiply(new O().setFromEuler(Jn(t.rotation)));
			return {
				...t,
				position: e.pivot.clone().add(i).add(a).toArray().map((e) => Xn(e)),
				rotation: Zn(new m().setFromQuaternion(o, "XYZ")),
				size: t.size.map((e) => Math.max(.02, Xn(e * n)))
			};
		});
		this.editor.updateShapesAt(e.items.map((e, t) => {
			let n = a[t];
			return [e.ref, {
				position: n.position,
				rotation: n.rotation,
				size: n.size
			}];
		}), "Move");
	}
	gizmoEnd() {
		this.gizmoStart = null, this.editor.commit(), this.placeProxy();
	}
	applyCamera() {
		let { position: e, target: t } = Bn(this.doc.camera), n = this.width / this.height;
		this.applying = !0;
		for (let n of [this.perspective, this.ortho]) n.position.copy(e), n.up.set(0, 1, 0), n.lookAt(t);
		this.perspective.fov = this.doc.camera.fov, this.perspective.aspect = n, this.perspective.updateProjectionMatrix();
		let r = this.doc.camera.distance * Math.tan(B.degToRad(this.doc.camera.fov / 2));
		Object.assign(this.ortho, {
			left: -r * n,
			right: r * n,
			top: r,
			bottom: -r,
			zoom: 1
		}), this.ortho.updateProjectionMatrix(), this.orbit.target.copy(t), this.orbit.update(), this.applying = !1;
	}
	orbitChange() {
		if (this.applying) return;
		let e = this.activeCamera(), t = this.orbit.target, n = e.position.clone().sub(t), r = n.length();
		e instanceof f && e.zoom !== 1 && (r /= e.zoom, e.zoom = 1), this.editor.setCamera({
			yaw: Xn(B.radToDeg(Math.atan2(n.x, n.z)), 100),
			pitch: Xn(B.radToDeg(Math.asin(B.clamp(n.y / n.length(), -1, 1))), 100),
			distance: Xn(r),
			target: [
				t.x,
				t.y,
				t.z
			].map((e) => Xn(e))
		});
	}
	onPointerDown = (e) => {
		this.down = {
			x: e.clientX,
			y: e.clientY
		};
	};
	onPointerUp = (e) => {
		let t = this.down;
		if (this.down = null, !t || Math.hypot(e.clientX - t.x, e.clientY - t.y) > 4 || this.gizmo.dragging || this.gizmo.axis) return;
		let n = this.canvas.getBoundingClientRect(), r = new I((e.clientX - n.left) / n.width * 2 - 1, -((e.clientY - n.top) / n.height) * 2 + 1), i = new h();
		i.setFromCamera(r, this.activeCamera());
		let a = i.ray.origin, o = i.ray.direction, s = this.doc.shapes.some((e) => e.locked) ? { shapes: this.doc.shapes.map((e) => e.locked ? {
			...e,
			hidden: !0
		} : e) } : this.doc, c = Ye(s, [
			a.x,
			a.y,
			a.z
		], [
			o.x,
			o.y,
			o.z
		]), l = { extend: e.shiftKey || e.metaKey || e.ctrlKey };
		this.meshes.scene.updateMatrixWorld();
		let u = i.intersectObjects(this.meshes.pickables(), !1).find((e) => !this.doc.shapes[e.object.userData.ref[0]]?.locked);
		if (u && u.distance < (c?.t ?? Infinity)) return this.hooks.onPick?.(u.object.userData.ref, l);
		this.hooks.onPick?.(c?.shape ?? null, l);
	};
	fit() {
		let e = Math.max(1, this.container.clientWidth), t = Math.max(1, this.container.clientHeight);
		this.width = e, this.height = t;
		let n = this.doc.style.look === "pixel";
		this.renderer.setPixelRatio(n ? 1 : Math.min(window.devicePixelRatio || 1, 1.5));
		let [r, i] = n ? lt(this.doc, e, t) : [e, t];
		this.renderer.setSize(r, i, !1), this.canvas.style.imageRendering = n ? "pixelated" : "", this.fitted = `${this.doc.style.look}:${this.doc.style.pixel}`, this.applyCamera(), this.request();
	}
	fitted = "";
	showScene(e) {
		this.container.dataset.scene !== e && (this.container.dataset.scene = e, Object.assign(this.container.style, e ? {
			backgroundImage: `url("${e}")`,
			backgroundSize: "cover",
			backgroundPosition: "center"
		} : {
			backgroundImage: "",
			backgroundSize: "",
			backgroundPosition: ""
		}));
	}
	request() {
		this.frame ||= requestAnimationFrame(() => {
			this.frame = 0, this.draw();
		});
	}
	draw() {
		let e = this.renderer.getDrawingBufferSize(new I()), t = it(this.playing ?? this.doc, e.y), n = Wn(this.uniforms, this.atlas, t, e.x, e.y);
		this.uniforms.uGrid.value = this.doc.style.look === "pixel" ? 0 : this.grid, this.meshes.renderShadow(this.renderer, t);
		let r = this.renderer.getSize(new I());
		this.renderer.setViewport(0, 0, r.x, r.y), this.renderer.clear(), this.renderer.render(this.quadScene, this.quadCamera), this.meshes.draw(this.renderer, n, e.x, e.y), this.renderer.clearDepth(), this.renderer.render(this.overlay, this.activeCamera());
	}
	dispose() {
		cancelAnimationFrame(this.frame), this.unsubscribe(), this.resize.disconnect(), this.canvas.removeEventListener("pointerdown", this.onPointerDown), this.canvas.removeEventListener("pointerup", this.onPointerUp), this.gizmo.dispose(), this.orbit.dispose(), this.meshes.dispose(), this.atlas.dispose(), this.renderer.dispose(), this.canvas.remove();
	}
}, $n = class {
	canvas;
	output = document.createElement("canvas");
	backdrop = null;
	renderer;
	atlas = new Vn();
	uniforms = Un(this.atlas);
	meshes = new qn(this.uniforms);
	scene = new T();
	camera = new f(-1, 1, 1, -1, 0, 1);
	constructor() {
		this.canvas = document.createElement("canvas"), this.renderer = new ke({
			canvas: this.canvas,
			antialias: !0,
			alpha: !0,
			premultipliedAlpha: !1,
			preserveDrawingBuffer: !0
		}), this.renderer.setPixelRatio(1), this.renderer.setClearColor(0, 0), this.renderer.autoClear = !1, this.scene.add(new V(new he(2, 2), Gn(this.uniforms)));
	}
	async paint(e, t, n, r = {}) {
		if (!rt(e)) return this.draw(e, t, n, r);
		let i = e.style.look === "pixel", [a, o] = lt(e, t, n), s = await this.draw(it(e, o), a, o, i ? {
			...r,
			samples: 1
		} : r), c = this.output;
		c.width = t, c.height = n;
		let l = c.getContext("2d");
		l.clearRect(0, 0, t, n);
		let u = await this.scenePicture(e.background.picture);
		if (u) {
			let e = Math.max(t / u.width, n / u.height);
			l.imageSmoothingEnabled = !0, l.drawImage(u, (t - u.width * e) / 2, (n - u.height * e) / 2, u.width * e, u.height * e);
		} else e.background.transparent || (l.fillStyle = e.background.color, l.fillRect(0, 0, t, n));
		return l.imageSmoothingEnabled = !i, l.drawImage(s, 0, 0, t, n), c;
	}
	surfaceFor(e) {
		return rt(e) ? this.output : this.canvas;
	}
	async scenePicture(e) {
		return e ? (this.backdrop?.url !== e && (this.backdrop?.picture.close(), this.backdrop = {
			url: e,
			picture: await createImageBitmap(await (await fetch(e)).blob())
		}), this.backdrop.picture) : null;
	}
	async draw(e, t, n, r) {
		let { samples: i = 2, frame: a = 1, tile: o = 384 } = r;
		await this.meshes.ready(e), this.meshes.sync(e), this.renderer.setSize(t, n, !1);
		let s = Wn(this.uniforms, this.atlas, e, t, n, a);
		this.meshes.renderShadow(this.renderer, e), this.renderer.setScissorTest(!1), this.renderer.setViewport(0, 0, t, n), this.renderer.clear(), this.uniforms.uSamples.value = i, this.renderer.setScissorTest(!0);
		for (let e = 0; e < n; e += o) for (let r = 0; r < t; r += o) {
			let i = Math.min(o, t - r), a = Math.min(o, n - e);
			this.renderer.setViewport(r, e, i, a), this.renderer.setScissor(r, e, i, a), this.uniforms.uTileOffset.value.set(r, e), this.uniforms.uTileSize.value.set(i, a), this.renderer.render(this.scene, this.camera), t * n > 7e5 && await new Promise((e) => setTimeout(e, 0));
		}
		return this.renderer.setScissorTest(!1), this.meshes.count && (this.renderer.setViewport(0, 0, t, n), this.meshes.draw(this.renderer, s, t, n)), this.canvas;
	}
	dispose() {
		this.backdrop?.picture.close(), this.meshes.dispose(), this.atlas.dispose(), this.renderer.dispose();
	}
};
async function er(e, t, n, r = "image/png", i = 1) {
	let a = new $n();
	try {
		let o = await a.paint(e, t, n, { frame: i });
		return await new Promise((e, t) => o.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be made.")), r, .92));
	} finally {
		a.dispose();
	}
}
//#endregion
//#region ../scene3d/src/model/video.ts
var tr = {
	still: "Camera still",
	turntable: "Turntable",
	bounce: "Camera sway",
	light: "Light sweep"
};
function nr(e, t, n) {
	let r = Ge(e, n);
	return t === "still" ? r : t === "turntable" ? {
		...r,
		camera: {
			...r.camera,
			yaw: r.camera.yaw + 360 * n
		}
	} : t === "bounce" ? {
		...r,
		camera: {
			...r.camera,
			yaw: r.camera.yaw + 25 * Math.sin(2 * Math.PI * n)
		}
	} : {
		...r,
		light: {
			...r.light,
			azimuth: (r.light.azimuth + 360 * n + 180) % 360 - 180
		}
	};
}
async function rr(e, t) {
	let { kind: n, seconds: r = 4, fps: i = 30, size: a = 1080, aspect: o = 1, onProgress: s } = t, c = (e) => Math.max(2, Math.round(e / 2) * 2), [l, u] = o >= 1 ? [c(a), c(a / o)] : [c(a * o), c(a)], d = {
		...e,
		background: {
			...e.background,
			transparent: !1
		}
	}, f = await be("avc", {
		width: l,
		height: u
	}), p = !f && await be("vp9", {
		width: l,
		height: u
	});
	if (!f && !p) throw Error("This browser cannot make video (it has no H.264 or VP9 encoder). Try Chrome, Edge or Safari.");
	let m = new $n();
	try {
		let e = new De({
			format: f ? new we({ fastStart: "in-memory" }) : new Ee(),
			target: new Te()
		}), t = new ve(m.surfaceFor(d), {
			codec: f ? "avc" : "vp9",
			bitrate: Se
		});
		e.addVideoTrack(t, { frameRate: i }), await e.start();
		let a = Math.max(2, Math.round(Math.min(20, Math.max(1, r)) * i));
		for (let e = 0; e < a; e++) await m.paint(nr(d, n, e / a), l, u, { samples: 1 }), await t.add(e / i, 1 / i), s?.((e + 1) / a);
		await e.finalize();
		let o = e.target.buffer, c = f ? "video/mp4" : "video/webm";
		return {
			blob: new Blob([o], { type: c }),
			type: c,
			extension: f ? "mp4" : "webm"
		};
	} finally {
		m.dispose();
	}
}
//#endregion
//#region ../../node_modules/three/examples/jsm/libs/draco/gltf/draco_wasm_wrapper.js?url
var ir = new URL("./assets/draco_wasm_wrapper.js", import.meta.url).href, ar = new URL("./assets/draco_decoder.wasm", import.meta.url).href, or = [
	"glb",
	"gltf",
	"fbx",
	"obj",
	"stl",
	"ply",
	"3mf"
], sr = ".glb,.gltf,.fbx,.obj,.stl,.ply,.3mf,.bin,.mtl,.png,.jpg,.jpeg,.webp,.tga,.bmp", cr = (e) => e.toLowerCase().split(".").pop() ?? "", lr = (e) => decodeURIComponent(e.split(/[?#]/)[0].split(/[\\/]/).pop() ?? "").toLowerCase();
function ur(e, t, n = 2048) {
	let r = e.image;
	if (!r || !r.width || !r.height || e.isCompressedTexture) return null;
	let i = Math.min(1, n / Math.max(r.width, r.height)), [a, o] = t ?? [Math.max(1, Math.round(r.width * i)), Math.max(1, Math.round(r.height * i))], s = new OffscreenCanvas(a, o).getContext("2d", { willReadFrequently: !0 });
	try {
		if (r.data) {
			let e = r.data, t = e.length / (r.width * r.height);
			if (t !== 3 && t !== 4) return null;
			let n = new Uint8ClampedArray(r.width * r.height * 4);
			for (let i = 0; i < r.width * r.height; i++) n[i * 4] = e[i * t], n[i * 4 + 1] = e[i * t + 1], n[i * 4 + 2] = e[i * t + 2], n[i * 4 + 3] = t === 4 ? e[i * t + 3] : 255;
			let i = new OffscreenCanvas(r.width, r.height);
			i.getContext("2d").putImageData(new ImageData(n, r.width, r.height), 0, 0), s.drawImage(i, 0, 0, a, o);
		} else s.drawImage(r, 0, 0, a, o);
	} catch {
		return null;
	}
	return s;
}
var dr = async (e, t) => {
	let n = await e.convertToBlob({
		type: t,
		quality: .9
	});
	return {
		mime: n.type,
		bytes: new Uint8Array(await n.arrayBuffer())
	};
}, fr = async (e, t) => {
	let n = ur(e);
	if (!n) return null;
	let r = t === "data";
	if (!r) {
		let e = n.getImageData(0, 0, n.canvas.width, n.canvas.height).data;
		for (let t = 3; t < e.length; t += 4) if (e[t] < 250) {
			r = !0;
			break;
		}
	}
	return dr(n.canvas, r ? "image/png" : "image/jpeg");
}, pr = async (e, t) => {
	let n = ur(e ?? t);
	if (!n) return null;
	let r = [n.canvas.width, n.canvas.height], i = e ? ur(e, r)?.getImageData(0, 0, ...r).data : null, a = t ? ur(t, r)?.getImageData(0, 0, ...r).data : null, o = new ImageData(...r);
	for (let e = 0; e < o.data.length; e += 4) o.data[e] = 255, o.data[e + 1] = i ? i[e + 1] : 255, o.data[e + 2] = a ? a[e + 2] : 255, o.data[e + 3] = 255;
	let s = new OffscreenCanvas(...r);
	return s.getContext("2d").putImageData(o, 0, 0), dr(s, "image/png");
};
function mr(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(n.name.toLowerCase(), URL.createObjectURL(n));
	let n = new L(), r = 0, i = null;
	n.setURLModifier((e) => e.startsWith("blob:") || e.startsWith("data:") ? e : t.get(lr(e)) ?? e), n.itemStart = ((e) => (t) => {
		r++, e(t);
	})(n.itemStart.bind(n));
	let a = (e) => (r = Math.max(0, r - 1), r || i?.(), e);
	return n.itemEnd = ((e) => (t) => e(a(t)))(n.itemEnd.bind(n)), n.itemError = ((e) => (t) => e(a(t)))(n.itemError.bind(n)), {
		manager: n,
		settled: () => new Promise((e) => {
			if (!r) return e();
			i = e, setTimeout(e, 2e4);
		}),
		dispose: () => t.forEach((e) => URL.revokeObjectURL(e))
	};
}
async function hr(e) {
	let t = e.find((e) => or.includes(cr(e.name)));
	if (!t) throw Error(`Pick a 3D model: ${or.map((e) => `.${e}`).join(", ")}.`);
	if (t.size > 2e8) throw Error("That model is over 200 MB; make it smaller first.");
	let n = cr(t.name), { manager: r, settled: i, dispose: a } = mr(e);
	try {
		let a, o = await t.arrayBuffer();
		if (n === "glb" || n === "gltf") {
			let [{ GLTFLoader: e }, { DRACOLoader: t }, { MeshoptDecoder: n }] = await Promise.all([
				import("./GLTFLoader-Bn3T_5ox.js").then((e) => e.n),
				import("./DRACOLoader-BOrKZrWV.js"),
				import("./meshopt_decoder.module-B2eONCO9.js")
			]), i = new e(r), s = new t(r);
			s.setDecoderPath({
				js: ir,
				wasm: ar
			}), i.setDRACOLoader(s), i.setMeshoptDecoder(n);
			try {
				a = (await i.parseAsync(o, "")).scene;
			} finally {
				s.dispose();
			}
		} else if (n === "fbx") {
			let { FBXLoader: e } = await import("./FBXLoader-DHwcHHbj.js");
			a = new e(r).parse(o, "");
		} else if (n === "obj") {
			let [{ OBJLoader: t }, { MTLLoader: n }] = await Promise.all([import("./OBJLoader-QAwTWqTr.js"), import("./MTLLoader-Bh8vFbur.js")]), i = new t(r), s = e.find((e) => cr(e.name) === "mtl");
			if (s) {
				let e = new n(r).parse(await s.text(), "");
				e.preload(), i.setMaterials(e);
			}
			a = i.parse(new TextDecoder().decode(o));
		} else if (n === "stl") {
			let { STLLoader: e } = await import("./STLLoader-Cw8BdM6O.js"), t = new e(r).parse(o);
			t.computeVertexNormals();
			let n = !!t.getAttribute("color");
			a = new V(t, new v({
				color: 14210268,
				roughness: .55,
				vertexColors: n
			})), a.rotation.x = -Math.PI / 2;
		} else if (n === "ply") {
			let { PLYLoader: e } = await import("./PLYLoader-C9_TTyPM.js"), t = new e(r).parse(o), n = !!t.getAttribute("color");
			a = new V(t, new v({
				color: 14210268,
				roughness: .55,
				vertexColors: n
			}));
		} else {
			let { ThreeMFLoader: e } = await import("./3MFLoader-BnlKyf6T.js");
			a = new e(r).parse(o);
		}
		await i();
		let { asset: s, warnings: c } = await Jt(a, fr, pr);
		return {
			asset: Yt(s, t.name.replace(/\.[^.]+$/, "")),
			warnings: c
		};
	} catch (e) {
		let t = e instanceof Error ? e.message : String(e);
		throw Error(t.startsWith("This model") || t.startsWith("There is") ? t : `That model could not be read: ${t}`);
	} finally {
		a();
	}
}
//#endregion
//#region src/model3d/fonts.ts
var gr = [
	100,
	200,
	300,
	400,
	500,
	600,
	700,
	800,
	900
], _r = (e, t) => gr.filter((n) => n >= e && n <= t), vr = [
	"Arial",
	"Helvetica",
	"Georgia",
	"Times New Roman",
	"Verdana",
	"Trebuchet MS",
	"Impact",
	"Courier New",
	"Comic Sans MS"
].map((e) => ({
	family: e,
	source: "standard",
	weights: [400, 700]
})), yr = [
	[
		"Bebas Neue",
		[400],
		"tall headline"
	],
	[
		"Anton",
		[400],
		"bold headline"
	],
	[
		"Archivo Black",
		[400],
		"heavy"
	],
	[
		"Montserrat",
		_r(100, 900),
		"clean"
	],
	[
		"Poppins",
		_r(100, 900),
		"round, clean"
	],
	[
		"Oswald",
		_r(200, 700),
		"narrow"
	],
	[
		"Rubik",
		_r(300, 900),
		"soft corners"
	],
	[
		"Fredoka",
		_r(300, 700),
		"round, friendly"
	],
	[
		"Baloo 2",
		_r(400, 800),
		"chunky, friendly"
	],
	[
		"Lilita One",
		[400],
		"chunky"
	],
	[
		"Titan One",
		[400],
		"chunky"
	],
	[
		"Luckiest Guy",
		[400],
		"comic"
	],
	[
		"Bangers",
		[400],
		"comic"
	],
	[
		"Bungee",
		[400],
		"signs"
	],
	[
		"Russo One",
		[400],
		"sporty"
	],
	[
		"Black Ops One",
		[400],
		"stencil"
	],
	[
		"Righteous",
		[400],
		"retro"
	],
	[
		"Monoton",
		[400],
		"neon lines"
	],
	[
		"Press Start 2P",
		[400],
		"pixel"
	],
	[
		"Permanent Marker",
		[400],
		"marker"
	],
	[
		"Pacifico",
		[400],
		"script"
	],
	[
		"Lobster",
		[400],
		"script"
	],
	[
		"Dancing Script",
		_r(400, 700),
		"script"
	],
	[
		"Great Vibes",
		[400],
		"elegant script"
	],
	[
		"Playfair Display",
		_r(400, 900),
		"elegant"
	],
	[
		"Abril Fatface",
		[400],
		"fashion"
	],
	[
		"Shrikhand",
		[400],
		"bold italic"
	],
	[
		"Comfortaa",
		_r(300, 700),
		"rounded"
	],
	[
		"Noto Sans JP",
		_r(100, 900),
		"Japanese, clean"
	],
	[
		"M PLUS Rounded 1c",
		[
			100,
			300,
			400,
			500,
			700,
			800,
			900
		],
		"Japanese, rounded"
	],
	[
		"Zen Maru Gothic",
		[
			300,
			400,
			500,
			700,
			900
		],
		"Japanese, soft"
	],
	[
		"Kosugi Maru",
		[400],
		"Japanese, rounded"
	],
	[
		"Dela Gothic One",
		[400],
		"Japanese, heavy"
	],
	[
		"Mochiy Pop One",
		[400],
		"Japanese, pop"
	],
	[
		"Reggae One",
		[400],
		"Japanese, bold"
	],
	[
		"RocknRoll One",
		[400],
		"Japanese, playful"
	],
	[
		"Yusei Magic",
		[400],
		"Japanese, marker"
	],
	[
		"DotGothic16",
		[400],
		"Japanese, pixel"
	]
].map(([e, t, n]) => ({
	family: e,
	source: "online",
	weights: [...t],
	note: n
})), br = (e) => `family=${encodeURIComponent(e.family).replace(/%20/g, "+")}${e.weights.length > 1 ? `:wght@${e.weights.join(";")}` : ""}`, xr = /* @__PURE__ */ new Set();
function Sr(e) {
	return xr.has(e) ? Promise.resolve() : (xr.add(e), new Promise((t, n) => {
		let r = document.createElement("link");
		r.rel = "stylesheet", r.href = e, r.onload = () => t(), r.onerror = () => {
			xr.delete(e), r.remove(), n(/* @__PURE__ */ Error("The online font could not be loaded (no internet?)."));
		}, document.head.appendChild(r);
	}));
}
async function Cr(e, t, n) {
	await Sr(`https://fonts.googleapis.com/css2?${br(e)}&display=block`), await document.fonts.load(`${t} 48px "${e.family}"`, n || e.family);
}
function wr(e) {
	let t = [...new Set(e.map((e) => e.family).join(""))].join("");
	return Sr(`https://fonts.googleapis.com/css2?${e.map((e) => `family=${encodeURIComponent(e.family).replace(/%20/g, "+")}`).join("&")}&text=${encodeURIComponent(t)}&display=swap`).catch(() => void 0);
}
var Tr = () => typeof window < "u" && typeof window.queryLocalFonts == "function", Er = [
	[/thin|hairline/i, 100],
	[/extra ?light|ultra ?light/i, 200],
	[/light/i, 300],
	[/medium/i, 500],
	[/semi ?bold|demi ?bold/i, 600],
	[/extra ?bold|ultra ?bold/i, 800],
	[/black|heavy/i, 900],
	[/bold/i, 700]
];
async function Dr() {
	if (!window.queryLocalFonts) return [];
	let e = await window.queryLocalFonts(), t = /* @__PURE__ */ new Map();
	for (let n of e) {
		let e = Er.find(([e]) => e.test(n.style))?.[1] ?? 400, r = t.get(n.family) ?? /* @__PURE__ */ new Set();
		r.add(e), t.set(n.family, r);
	}
	return [...t].sort(([e], [t]) => e.localeCompare(t)).map(([e, t]) => ({
		family: e,
		source: "computer",
		weights: [...t].sort((e, t) => e - t)
	}));
}
var Or = /* @__PURE__ */ new Map(), kr = () => [...Or.values()];
async function Ar(e) {
	let t = e.name.replace(/\.(ttf|otf|woff2?)$/i, "").replace(/[^\w -]+/g, " ").trim().slice(0, 60) || "My font", n = new FontFace(t, await e.arrayBuffer(), { weight: "100 900" });
	try {
		await n.load();
	} catch {
		throw Error("That file is not a font this browser can read (TTF, OTF, WOFF or WOFF2).");
	}
	document.fonts.add(n);
	let r = {
		family: t,
		source: "file",
		weights: [400]
	};
	return Or.set(t, r), r;
}
function jr(e) {
	if (vr.some((t) => t.family === e)) return !0;
	let t = document.createElement("canvas").getContext("2d");
	if (!t) return !0;
	let n = "mmmmmmmmmmlli WQ@#";
	return ["monospace", "serif"].some((r) => {
		t.font = `72px ${r}`;
		let i = t.measureText(n).width;
		return t.font = `72px "${e}", ${r}`, t.measureText(n).width !== i;
	});
}
async function Mr(e, t, n) {
	let r = yr.find((t) => t.family === e);
	if (r) return Cr(r, t, n);
	if (await document.fonts.load(`${t} 48px "${e}"`, n).catch(() => void 0), !jr(e)) throw Error(`“${e}” is not on this computer: pick another font, or load its font file.`);
}
//#endregion
//#region src/model3d/PenPad.tsx
var Nr = 300, Pr = 15, Fr = ([e, t]) => [(e + .5) * Nr, (.5 - t) * Nr], Ir = ([e, t]) => [Math.round((e / Nr - .5) * 1e4) / 1e4, Math.round((.5 - t / Nr) * 1e4) / 1e4], Lr = (e) => e.map((e) => ({
	closed: e.closed,
	nodes: e.nodes.map((e) => ({
		p: Fr(e.p),
		...e.in ? { in: Fr(e.in) } : {},
		...e.out ? { out: Fr(e.out) } : {}
	}))
})), Rr = (e) => e.map((e) => ({
	closed: e.closed,
	nodes: e.nodes.map((e) => ({
		p: Ir(e.p),
		...e.in ? { in: Ir(e.in) } : {},
		...e.out ? { out: Ir(e.out) } : {}
	}))
})), zr = (e, t) => [e[0] - t[0], e[1] - t[1]], Br = (e, t) => [e[0] + t[0], e[1] + t[1]], Vr = (e) => Math.hypot(e[0], e[1]), Hr = (e) => e.map((e) => ({
	closed: e.closed,
	nodes: e.nodes.map((e) => ({ ...e }))
}));
function Ur(e, t = e.closed) {
	let n = e.nodes;
	if (!n.length) return "";
	let r = (e, t) => e.out || t.in ? `C${(e.out ?? e.p).join(" ")} ${(t.in ?? t.p).join(" ")} ${t.p.join(" ")}` : `L${t.p.join(" ")}`, i = `M${n[0].p.join(" ")}`;
	for (let e = 1; e < n.length; e++) i += r(n[e - 1], n[e]);
	return t && n.length > 1 && (i += `${r(n[n.length - 1], n[0])}Z`), i;
}
function Wr(e, t) {
	let n = e.nodes, r = n[t];
	if (r.in || r.out) {
		delete r.in, delete r.out;
		return;
	}
	let i = n[(t - 1 + n.length) % n.length].p, a = n[(t + 1) % n.length].p, o = zr(a, i), s = Vr(o) || 1, c = Math.min(Vr(zr(a, r.p)), Vr(zr(r.p, i))) / 3 || 20, l = [o[0] / s * c, o[1] / s * c];
	r.in = zr(r.p, l), r.out = Br(r.p, l);
}
function Gr({ initial: e, onPaths: t }) {
	let [n, r] = W(() => Lr(e ?? [])), [i, a] = W(null), [o, s] = W(null), [c, l] = W(null), [u, d] = W(!1), f = U([]), p = U(null), m = U(null), h = U({
		paths: n,
		active: i
	});
	h.current = {
		paths: n,
		active: i
	}, xt(() => t(Rr(n)), [n, t]);
	let g = () => {
		f.current.push(Hr(h.current.paths)), f.current.length > 100 && f.current.shift();
	}, _ = () => {
		let e = f.current.pop();
		e && (r(e), a(null), s(null));
	}, v = () => {
		let { paths: e, active: t } = h.current;
		if (t === null) return;
		let n = e[t], i = Hr(e);
		n.nodes.length < 2 ? i.splice(t, 1) : i[t].closed = !0, r(i), a(null);
	}, y = () => {
		if (!o) return;
		g();
		let e = Hr(n);
		e[o[0]].nodes.splice(o[1], 1), e[o[0]].nodes.length < 2 && i !== o[0] && e.splice(o[0], 1), r(e.filter((e) => e.nodes.length)), s(null), i !== null && !e[i]?.nodes.length && a(null);
	};
	xt(() => {
		let e = (e) => {
			e.key === "Escape" && h.current.active !== null && (e.stopImmediatePropagation(), v());
		};
		return window.addEventListener("keydown", e, !0), () => window.removeEventListener("keydown", e, !0);
	}, []);
	let b = (e, t, n = !1) => {
		let r = m.current.getBoundingClientRect(), i = [(e.clientX - r.left) / r.width * Nr, (e.clientY - r.top) / r.height * Nr];
		if (n && t) {
			let e = zr(i, t), n = Math.round(Math.atan2(e[1], e[0]) / (Math.PI / 4)) * (Math.PI / 4), r = Vr(e);
			i = [t[0] + Math.cos(n) * r, t[1] + Math.sin(n) * r];
		}
		return u && (i = [Math.round(i[0] / Pr) * Pr, Math.round(i[1] / Pr) * Pr]), [Math.min(Nr, Math.max(0, i[0])), Math.min(Nr, Math.max(0, i[1]))];
	}, x = () => i === null ? null : n[i]?.nodes.at(-1)?.p ?? null, S = (e) => {
		if (e.button !== 0) return;
		m.current.setPointerCapture(e.pointerId), m.current.focus();
		let t = b(e, x(), e.shiftKey);
		g();
		let o = Hr(n), c = i;
		(c === null || !o[c]) && (o.push({
			closed: !1,
			nodes: []
		}), c = o.length - 1, a(c)), o[c].nodes.push({ p: t }), r(o);
		let l = o[c].nodes.length - 1;
		s([c, l]), p.current = {
			kind: "new",
			path: c,
			node: l,
			from: t,
			moved: !1
		};
	}, C = (e, t, o) => {
		if (e.button !== 0) return;
		e.stopPropagation(), m.current.setPointerCapture(e.pointerId), m.current.focus(), g();
		let c = Hr(n);
		i === t && o === 0 && c[t].nodes.length >= 2 ? (c[t].closed = !0, r(c), a(null), s([t, 0]), p.current = {
			kind: "new",
			path: t,
			node: 0,
			from: c[t].nodes[0].p,
			moved: !1
		}) : e.altKey ? (Wr(c[t], o), r(c), s([t, o])) : (s([t, o]), p.current = {
			kind: "node",
			path: t,
			node: o,
			from: b(e),
			moved: !1
		});
	}, w = (e, t, n, r) => {
		e.button === 0 && (e.stopPropagation(), m.current.setPointerCapture(e.pointerId), g(), p.current = {
			kind: "handle",
			path: t,
			node: n,
			side: r,
			moved: !1
		});
	}, T = (e) => {
		let t = p.current;
		if (!t) {
			l(i === null ? null : b(e, x(), e.shiftKey));
			return;
		}
		let n = Hr(h.current.paths), a = n[t.path]?.nodes[t.node];
		if (a) {
			if (t.kind === "new") {
				let n = b(e);
				if (!t.moved && Vr(zr(n, t.from)) < 3) return;
				t.moved = !0, a.out = n, a.in = zr(a.p, zr(n, a.p));
			} else if (t.kind === "node") {
				let n = b(e), r = zr(n, t.from);
				if (!t.moved && Vr(r) < 1) return;
				t.moved = !0, t.from = n, a.p = Br(a.p, r), a.in &&= Br(a.in, r), a.out &&= Br(a.out, r);
			} else {
				let n = b(e);
				t.moved = !0, a[t.side] = n;
				let r = t.side === "in" ? "out" : "in", i = a[r];
				if (i && !e.altKey) {
					let e = zr(a.p, n), t = Vr(e) || 1, o = Vr(zr(i, a.p));
					a[r] = Br(a.p, [e[0] / t * o, e[1] / t * o]);
				}
			}
			r(n);
		}
	}, E = () => {
		let e = p.current;
		p.current = null, e && e.kind !== "new" && !e.moved && f.current.pop();
	}, D = (e) => {
		(e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "z" ? (e.preventDefault(), e.stopPropagation(), _()) : e.key === "Delete" || e.key === "Backspace" ? (e.preventDefault(), e.stopPropagation(), y()) : e.key === "Enter" && (e.preventDefault(), v());
	}, O = (e, t) => {
		g();
		let i = Hr(n);
		Wr(i[e], t), r(i);
	}, ee = n.map((e, t) => e.closed || t === i && e.nodes.length >= 3 ? Ur(e, !0) : "").filter(Boolean).join(""), k = i === null ? void 0 : n[i], A = k?.nodes.at(-1), j = (e, t) => o?.[0] === e && o[1] === t || e === i && t === (k?.nodes.length ?? 0) - 1;
	return /* @__PURE__ */ K("div", {
		className: "gs-pen",
		children: [/* @__PURE__ */ K("svg", {
			ref: m,
			className: "gs-m3d__pad gs-pen__pad",
			viewBox: `0 0 ${Nr} ${Nr}`,
			tabIndex: 0,
			"aria-label": "Pen: click for a corner, drag for a curve, click the first point to close",
			onPointerDown: S,
			onPointerMove: T,
			onPointerUp: E,
			onPointerLeave: () => l(null),
			onKeyDown: D,
			children: [
				/* @__PURE__ */ G("defs", { children: /* @__PURE__ */ G("pattern", {
					id: "gs-pen-grid",
					width: 30,
					height: 30,
					patternUnits: "userSpaceOnUse",
					children: /* @__PURE__ */ G("path", {
						className: "gs-pen__gridline",
						d: "M30 0H0V30"
					})
				}) }),
				/* @__PURE__ */ G("rect", {
					width: Nr,
					height: Nr,
					fill: "url(#gs-pen-grid)"
				}),
				ee && /* @__PURE__ */ G("path", {
					className: "gs-pen__fill",
					d: ee,
					fillRule: "evenodd"
				}),
				n.map((e, t) => /* @__PURE__ */ G("path", {
					className: "gs-pen__line",
					d: Ur(e),
					strokeWidth: 2
				}, t)),
				A && c && /* @__PURE__ */ G("path", {
					d: `M${A.p.join(" ")}${A.out ? `C${A.out.join(" ")} ${c.join(" ")} ${c.join(" ")}` : `L${c.join(" ")}`}`,
					className: "gs-pen__line",
					strokeDasharray: "4 4",
					strokeWidth: 1.5,
					pointerEvents: "none"
				}),
				n.map((e, t) => e.nodes.map((e, n) => j(t, n) ? /* @__PURE__ */ G("g", { children: ["in", "out"].map((r) => e[r] ? /* @__PURE__ */ K("g", { children: [/* @__PURE__ */ G("line", {
					x1: e.p[0],
					y1: e.p[1],
					x2: e[r][0],
					y2: e[r][1],
					className: "gs-pen__arm",
					strokeWidth: 1,
					pointerEvents: "none"
				}), /* @__PURE__ */ G("circle", {
					className: "gs-pen__handle",
					cx: e[r][0],
					cy: e[r][1],
					r: 4.5,
					onPointerDown: (e) => w(e, t, n, r)
				})] }, r) : null) }, `h${t}-${n}`) : null)),
				n.map((e, t) => e.nodes.map((n, r) => {
					let a = o?.[0] === t && o[1] === r, s = t === i && r === 0 && e.nodes.length >= 2, c = !!(n.in || n.out), l = {
						className: `gs-pen__node${a ? " is-on" : ""}${s ? " is-first" : ""}`,
						onPointerDown: (e) => C(e, t, r),
						onDoubleClick: () => O(t, r)
					};
					return c ? /* @__PURE__ */ G("circle", {
						cx: n.p[0],
						cy: n.p[1],
						r: s ? 7 : 5,
						...l
					}, `n${t}-${r}`) : /* @__PURE__ */ G("rect", {
						x: n.p[0] - (s ? 6 : 4.5),
						y: n.p[1] - (s ? 6 : 4.5),
						width: s ? 12 : 9,
						height: s ? 12 : 9,
						...l
					}, `n${t}-${r}`);
				}))
			]
		}), /* @__PURE__ */ K("div", {
			className: "gs-m3d__actions",
			children: [
				/* @__PURE__ */ G("button", {
					type: "button",
					className: "gs-m3d__btn",
					disabled: !f.current.length && !n.length,
					onClick: _,
					title: "Undo (Ctrl Z)",
					children: "Undo"
				}),
				/* @__PURE__ */ G("button", {
					type: "button",
					className: "gs-m3d__btn",
					disabled: !o,
					onClick: y,
					title: "Delete the picked point (Delete)",
					children: "Delete point"
				}),
				/* @__PURE__ */ G("button", {
					type: "button",
					className: "gs-m3d__btn",
					disabled: !n.length,
					onClick: () => {
						g(), r([]), a(null), s(null);
					},
					children: "Clear"
				}),
				/* @__PURE__ */ K("label", {
					className: "gs-m3d__check",
					children: [/* @__PURE__ */ G("input", {
						type: "checkbox",
						checked: u,
						onChange: (e) => d(e.target.checked)
					}), " Snap to grid"]
				})
			]
		})]
	});
}
//#endregion
//#region src/model3d/dialogs.tsx
function Kr({ title: e, onClose: t, children: n }) {
	return xt(() => {
		let e = (e) => {
			e.key === "Escape" && (e.stopPropagation(), t());
		};
		return window.addEventListener("keydown", e, !0), () => window.removeEventListener("keydown", e, !0);
	}, [t]), /* @__PURE__ */ G("div", {
		className: "gs-m3d__scrim",
		onPointerDown: t,
		children: /* @__PURE__ */ K("div", {
			className: "gs-m3d__dialog",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": e,
			onPointerDown: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ G("h3", { children: e }), n]
		})
	});
}
var qr = (e) => mt(e.map((e) => e.map(([e, t]) => [50 + e * 90, 50 - t * 90]))), Jr = 24;
function Yr({ initial: e, onPick: t, onClose: n }) {
	let [i, a] = W(e ?? []), o = He(i);
	return /* @__PURE__ */ K(Kr, {
		title: e ? "Change the outline" : "Push out an outline",
		onClose: n,
		children: [
			!e && /* @__PURE__ */ G(r, { id: "m3dOutlineShape" }),
			!e && /* @__PURE__ */ G("div", {
				className: "gs-m3d__presets",
				children: Object.entries(Je).map(([e, n]) => /* @__PURE__ */ K("button", {
					type: "button",
					onClick: () => {
						let e = st(n.contours), r = e.outline.reduce((e, t) => e + t.length, 0);
						t(e.outline, e.aspect, n.label, r <= Jr ? We(e.outline.map((e) => e.map(([e, t]) => [e * .8, t * .8]))) : void 0);
					},
					children: [/* @__PURE__ */ G("svg", {
						viewBox: "0 0 100 100",
						width: "48",
						height: "48",
						"aria-hidden": "true",
						children: /* @__PURE__ */ G("path", {
							d: qr(st(n.contours).outline),
							fill: "currentColor",
							fillRule: "evenodd"
						})
					}), /* @__PURE__ */ G("span", { children: n.label })]
				}, e))
			}),
			!e && /* @__PURE__ */ G("h4", { children: "Or draw one with the pen" }),
			/* @__PURE__ */ G(r, { id: "m3dPen" }),
			/* @__PURE__ */ G(Gr, {
				initial: e,
				onPaths: a
			}),
			/* @__PURE__ */ K("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ G("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ G("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: n,
						children: "Cancel"
					}),
					/* @__PURE__ */ G("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: !o.length,
						onClick: () => {
							if (!o.length) return;
							let e = st(o);
							t(e.outline, e.aspect, "Drawn outline", i);
						},
						children: e ? "Change" : "Use outline"
					})
				]
			})
		]
	});
}
var Xr = {
	100: "Thin",
	200: "Extra light",
	300: "Light",
	400: "Regular",
	500: "Medium",
	600: "Semi-bold",
	700: "Bold",
	800: "Extra bold",
	900: "Black"
}, Zr = {
	left: "Left",
	center: "Middle",
	right: "Right"
};
function Qr({ initial: e, onDone: t, onClose: n }) {
	let [i, a] = W(e?.value ?? "Sale"), [o, s] = W(() => $r(e?.font ?? "Arial")), [c, l] = W(e?.weight ?? 800), [u, d] = W(e?.align ?? "center"), [f, p] = W(e?.lineHeight ?? 1.15), [m, h] = W(e?.spacing ?? 0), [g, _] = W(null), v = e && !jr(e.font) && !yr.some((t) => t.family === e.font) && o.family === e.font, y = i.split("\n").length, b = o.source === "online" || o.source === "file" ? o.weights : [
		400,
		500,
		600,
		700,
		800,
		900
	], x = b.includes(c) ? c : b.reduce((e, t) => Math.abs(t - c) < Math.abs(e - c) ? t : e), S = () => {
		let n = i.replace(/\s+$/, "").replace(/^\s*\n/, "");
		n.trim() && t({
			value: n,
			font: o.family,
			weight: x,
			...y > 1 || e?.align ? {
				align: u,
				lineHeight: f
			} : {},
			...m || e?.spacing ? { spacing: m } : {}
		});
	};
	return /* @__PURE__ */ K(Kr, {
		title: e ? "Change the text" : "3D text",
		onClose: n,
		children: [
			/* @__PURE__ */ G(r, { id: "m3dText" }),
			/* @__PURE__ */ K("label", {
				className: "gs-m3d__field gs-m3d__field--top",
				children: [/* @__PURE__ */ G("span", { children: "Text" }), /* @__PURE__ */ G("textarea", {
					autoFocus: !0,
					rows: Math.min(5, Math.max(2, y)),
					value: i,
					maxLength: 200,
					onChange: (e) => a(e.target.value.split("\n").slice(0, 8).join("\n")),
					onKeyDown: (e) => {
						e.key === "Enter" && (e.metaKey || e.ctrlKey) && S();
					}
				})]
			}),
			/* @__PURE__ */ K("div", {
				className: "gs-m3d__field gs-m3d__field--top",
				children: [/* @__PURE__ */ G("span", { children: "Font" }), /* @__PURE__ */ G(ni, {
					value: o,
					onPick: (e) => {
						if (s(e), e.source !== "online") return _(null);
						_("Loading the font…"), Cr(e, e.weights.includes(c) ? c : e.weights[0], i).then(() => _(null)).catch((e) => _(e instanceof Error ? e.message : "The font could not be loaded."));
					}
				})]
			}),
			v && /* @__PURE__ */ K("p", {
				className: "gs-m3d__note",
				children: [
					"“",
					e.font,
					"” is not on this computer: pick a font, or load its file under Font file."
				]
			}),
			/* @__PURE__ */ K("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ G("span", { children: "Weight" }), /* @__PURE__ */ G("select", {
					value: x,
					onChange: (e) => l(Number(e.target.value)),
					children: b.map((e) => /* @__PURE__ */ G("option", {
						value: e,
						children: Xr[e] ?? e
					}, e))
				})]
			}),
			y > 1 && /* @__PURE__ */ K(Ct, { children: [/* @__PURE__ */ K("div", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ G("span", { children: "Lines" }), /* @__PURE__ */ G("div", {
					className: "gs-m3d__segments",
					role: "group",
					"aria-label": "Line up",
					children: [
						"left",
						"center",
						"right"
					].map((e) => /* @__PURE__ */ G("button", {
						type: "button",
						className: u === e ? "is-on" : "",
						onClick: () => d(e),
						children: Zr[e]
					}, e))
				})]
			}), /* @__PURE__ */ K("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ G("span", { children: "Line gap" }), /* @__PURE__ */ G("input", {
					type: "range",
					min: .7,
					max: 2,
					step: .05,
					value: f,
					onChange: (e) => p(Number(e.target.value))
				})]
			})] }),
			/* @__PURE__ */ K("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ G("span", { children: "Spacing" }), /* @__PURE__ */ G("input", {
					type: "range",
					min: -.1,
					max: .6,
					step: .01,
					value: m,
					onChange: (e) => h(Number(e.target.value))
				})]
			}),
			/* @__PURE__ */ G("p", {
				className: "gs-m3d__textpreview",
				style: {
					fontFamily: `"${o.family}", sans-serif`,
					fontWeight: x,
					textAlign: u,
					lineHeight: f,
					letterSpacing: `${m}em`,
					whiteSpace: "pre"
				},
				children: i || " "
			}),
			g && /* @__PURE__ */ G("p", {
				className: "gs-m3d__note",
				children: g
			}),
			/* @__PURE__ */ K("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ G("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ G("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: n,
						children: "Cancel"
					}),
					/* @__PURE__ */ G("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: !i.trim(),
						onClick: S,
						children: e ? "Change" : "Add text"
					})
				]
			})
		]
	});
}
function $r(e) {
	return [
		...vr,
		...yr,
		...kr()
	].find((t) => t.family === e) ?? {
		family: e,
		source: "computer",
		weights: [400, 700]
	};
}
var ei = {
	standard: "Standard",
	online: "Online",
	computer: "This computer",
	file: "Font file"
}, ti = null;
function ni({ value: e, onPick: t }) {
	let [n, r] = W(e.source), [i, a] = W(""), [o, s] = W(ti), [c, l] = W(null), [u, d] = W(""), [, f] = W(0), p = U(null);
	xt(() => {
		n === "online" && wr(yr);
	}, [n]);
	let m = n === "standard" ? vr : n === "online" ? yr : n === "computer" ? o ?? [] : kr(), h = i.trim().toLowerCase(), g = h ? m.filter((e) => e.family.toLowerCase().includes(h) || e.note?.toLowerCase().includes(h)) : m;
	return /* @__PURE__ */ K("div", {
		className: "gs-fonts",
		children: [
			/* @__PURE__ */ G("div", {
				className: "gs-m3d__segments",
				role: "group",
				"aria-label": "Fonts from",
				children: Object.keys(ei).map((e) => /* @__PURE__ */ G("button", {
					type: "button",
					className: n === e ? "is-on" : "",
					onClick: () => r(e),
					children: ei[e]
				}, e))
			}),
			n === "online" && /* @__PURE__ */ G("p", {
				className: "gs-m3d__note",
				children: "Free fonts from Google Fonts: each loads from the internet when picked."
			}),
			n === "computer" && /* @__PURE__ */ K("div", {
				className: "gs-fonts__ask",
				children: [o?.length ? null : Tr() ? /* @__PURE__ */ G("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => {
						l(null), Dr().then((e) => {
							ti = e, s(e), e.length || l("The browser shared no fonts (it may have been told not to). Type a font’s name instead.");
						}).catch(() => l("The browser did not share this computer’s fonts."));
					},
					children: "Show this computer’s fonts"
				}) : /* @__PURE__ */ G("p", {
					className: "gs-m3d__note",
					children: "This browser cannot list fonts."
				}), /* @__PURE__ */ K("form", {
					className: "gs-fonts__typed",
					onSubmit: (e) => {
						e.preventDefault();
						let n = u.trim();
						if (n) {
							if (!jr(n)) return l(`“${n}” is not on this computer.`);
							l(null), t({
								family: n,
								source: "computer",
								weights: [400, 700]
							});
						}
					},
					children: [/* @__PURE__ */ G("input", {
						value: u,
						placeholder: "Or type an installed font’s name",
						"aria-label": "Font name",
						onChange: (e) => d(e.target.value)
					}), /* @__PURE__ */ G("button", {
						type: "submit",
						className: "gs-m3d__btn",
						children: "Use"
					})]
				})]
			}),
			n === "file" && /* @__PURE__ */ K(Ct, { children: [
				/* @__PURE__ */ G("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => p.current?.click(),
					children: "Load a font file…"
				}),
				/* @__PURE__ */ G("input", {
					ref: p,
					type: "file",
					accept: ".ttf,.otf,.woff,.woff2",
					hidden: !0,
					onChange: (e) => {
						let n = e.target.files?.[0];
						e.target.value = "", n && (l(null), Ar(n).then((e) => {
							f((e) => e + 1), t(e);
						}).catch((e) => l(e instanceof Error ? e.message : "That font file could not be read.")));
					}
				}),
				/* @__PURE__ */ G("p", {
					className: "gs-m3d__note",
					children: "Kept until the page closes; the letters stay in the design after that."
				})
			] }),
			m.length > 8 && /* @__PURE__ */ G("input", {
				className: "gs-fonts__search",
				value: i,
				placeholder: "Search fonts",
				"aria-label": "Search fonts",
				onChange: (e) => a(e.target.value)
			}),
			g.length > 0 && /* @__PURE__ */ G("ul", {
				className: "gs-fonts__list",
				role: "listbox",
				"aria-label": "Fonts",
				children: g.slice(0, 400).map((n) => /* @__PURE__ */ G("li", { children: /* @__PURE__ */ K("button", {
					type: "button",
					role: "option",
					"aria-selected": e.family === n.family,
					className: e.family === n.family ? "is-on" : "",
					onClick: () => t(n),
					children: [/* @__PURE__ */ G("span", {
						style: { fontFamily: `"${n.family}", sans-serif` },
						children: n.family
					}), n.note && /* @__PURE__ */ G("small", { children: n.note })]
				}) }, `${n.source}-${n.family}`))
			}),
			c && /* @__PURE__ */ G("p", {
				className: "gs-m3d__note",
				children: c
			})
		]
	});
}
function ri({ initialKind: e = "turntable", initialSeconds: t = 4, moving: n = !1, onMake: i, onClose: a }) {
	let [o, s] = W(e), [c, l] = W(t), [u, d] = W(1080);
	return /* @__PURE__ */ K(Kr, {
		title: "Make a video",
		onClose: a,
		children: [
			/* @__PURE__ */ G(r, { id: "m3dVideo" }),
			n && /* @__PURE__ */ G("p", {
				className: "gs-m3d__note",
				children: "The shapes move as their Motion says, fitted to the clip’s length; pick what the camera does too."
			}),
			/* @__PURE__ */ G("div", {
				className: "gs-m3d__segments",
				role: "group",
				"aria-label": "Clip",
				children: Object.keys(tr).map((e) => /* @__PURE__ */ G("button", {
					type: "button",
					className: o === e ? "is-on" : "",
					onClick: () => s(e),
					children: tr[e]
				}, e))
			}),
			/* @__PURE__ */ K("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ G("span", { children: "Length" }), /* @__PURE__ */ G("select", {
					value: c,
					onChange: (e) => l(Number(e.target.value)),
					children: [
						2,
						4,
						6,
						8,
						12
					].map((e) => /* @__PURE__ */ K("option", {
						value: e,
						children: [e, " seconds"]
					}, e))
				})]
			}),
			/* @__PURE__ */ K("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ G("span", { children: "Size" }), /* @__PURE__ */ K("select", {
					value: u,
					onChange: (e) => d(Number(e.target.value)),
					children: [
						/* @__PURE__ */ G("option", {
							value: 720,
							children: "720 px"
						}),
						/* @__PURE__ */ G("option", {
							value: 1080,
							children: "1080 px"
						}),
						/* @__PURE__ */ G("option", {
							value: 1440,
							children: "1440 px"
						})
					]
				})]
			}),
			/* @__PURE__ */ K("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ G("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ G("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: a,
						children: "Cancel"
					}),
					/* @__PURE__ */ G("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						onClick: () => i(o, c, u),
						children: "Make video"
					})
				]
			})
		]
	});
}
//#endregion
//#region src/model3d/AdDialog.tsx
var ii = "gleamshelf.shop.logo";
function ai() {
	try {
		let e = JSON.parse(localStorage.getItem(ii) ?? "null");
		return e && typeof e.svg == "string" && typeof e.name == "string" ? {
			name: e.name,
			svg: e.svg
		} : null;
	} catch {
		return null;
	}
}
function oi(e) {
	try {
		e ? localStorage.setItem(ii, JSON.stringify(e)) : localStorage.removeItem(ii);
	} catch {}
}
var si = "gleamshelf.ad.look";
function ci() {
	let e = {
		style: "podium",
		palette: "blossom",
		font: "Arial"
	};
	try {
		let t = JSON.parse(localStorage.getItem(si) ?? "null");
		return {
			style: t?.style && t.style in pt ? t.style : e.style,
			palette: t?.palette && t.palette in ut ? t.palette : e.palette,
			font: typeof t?.font == "string" && t.font ? t.font : e.font
		};
	} catch {
		return e;
	}
}
function li(e) {
	try {
		localStorage.setItem(si, JSON.stringify(e));
	} catch {}
}
function ui({ start: e, onMake: t, onClose: n }) {
	let [i, a] = W(e?.picture ?? null), [o, s] = W(null), [c, l] = W(e?.headline ?? ""), [u, d] = W(e?.tagline ?? "New arrival"), [f, p] = W(e?.price ?? ""), [m, h] = W(ai), [g, _] = W(() => ci().style), [v, y] = W(() => ci().palette), [b, x] = W(() => $r(ci().font)), [S, C] = W(!0), [w] = W(je), [T, E] = W(!!w), [D, O] = W(null), ee = U(null), k = U(null);
	xt(() => {
		if (!i) return s(null);
		let e = URL.createObjectURL(i);
		return s(e), () => URL.revokeObjectURL(e);
	}, [i]);
	let A = !!(i || c.trim() || f.trim());
	return /* @__PURE__ */ K(Kr, {
		title: "Make a 3D ad",
		onClose: n,
		children: [
			/* @__PURE__ */ G(r, { id: "m3dAd" }),
			/* @__PURE__ */ K("div", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ G("span", { children: "Product" }), /* @__PURE__ */ K("div", {
					className: "gs-ad__picture",
					children: [
						o ? /* @__PURE__ */ G("img", {
							src: o,
							alt: "The product"
						}) : /* @__PURE__ */ G("span", {
							className: "gs-m3d__note",
							children: "No picture"
						}),
						/* @__PURE__ */ G("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: () => ee.current?.click(),
							children: i ? "Change…" : "Choose a picture…"
						}),
						/* @__PURE__ */ G("input", {
							ref: ee,
							type: "file",
							accept: "image/png,image/webp,image/jpeg",
							hidden: !0,
							onChange: (e) => {
								let t = e.target.files?.[0];
								e.target.value = "", t && a(t);
							}
						})
					]
				})]
			}),
			/* @__PURE__ */ K("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ G("span", { children: "Headline" }), /* @__PURE__ */ G("input", {
					value: c,
					maxLength: 60,
					placeholder: "What it is",
					onChange: (e) => l(e.target.value)
				})]
			}),
			/* @__PURE__ */ K("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ G("span", { children: "Small line" }), /* @__PURE__ */ G("input", {
					value: u,
					maxLength: 40,
					placeholder: "New arrival",
					onChange: (e) => d(e.target.value)
				})]
			}),
			/* @__PURE__ */ K("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ G("span", { children: "Price" }), /* @__PURE__ */ G("input", {
					value: f,
					maxLength: 14,
					placeholder: "$45 (none: no badge)",
					onChange: (e) => p(e.target.value)
				})]
			}),
			/* @__PURE__ */ K("div", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ G("span", { children: "Logo" }), /* @__PURE__ */ K("div", {
					className: "gs-ad__picture",
					children: [
						/* @__PURE__ */ G("span", {
							className: "gs-m3d__note",
							children: m ? m.name : "None"
						}),
						/* @__PURE__ */ G("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: () => k.current?.click(),
							children: m ? "Change…" : "Choose an SVG…"
						}),
						m && /* @__PURE__ */ G("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: () => {
								h(null), oi(null);
							},
							children: "No logo"
						}),
						/* @__PURE__ */ G("input", {
							ref: k,
							type: "file",
							accept: ".svg,image/svg+xml",
							hidden: !0,
							onChange: (e) => {
								let t = e.target.files?.[0];
								if (e.target.value = "", t) {
									if (t.size > 4e5) return O("That SVG is very large; a logo is usually a few kilobytes.");
									t.text().then((e) => {
										let n = {
											name: t.name.replace(/\.svg$/i, ""),
											svg: e
										};
										h(n), oi(n), O(null);
									});
								}
							}
						})
					]
				})]
			}),
			/* @__PURE__ */ K("div", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ G("span", { children: "Layout" }), /* @__PURE__ */ G("div", {
					className: "gs-m3d__segments",
					role: "group",
					"aria-label": "Layout",
					children: Object.keys(pt).map((e) => /* @__PURE__ */ G("button", {
						type: "button",
						className: g === e ? "is-on" : "",
						onClick: () => _(e),
						children: pt[e]
					}, e))
				})]
			}),
			/* @__PURE__ */ K("div", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ G("span", { children: "Colours" }), /* @__PURE__ */ G("div", {
					className: "gs-ad__palettes",
					role: "group",
					"aria-label": "Colours",
					children: Object.entries(ut).map(([e, t]) => /* @__PURE__ */ G("button", {
						type: "button",
						className: v === e ? "is-on" : "",
						title: t.label,
						"aria-label": t.label,
						onClick: () => y(e),
						children: [
							t.colours.background,
							t.colours.main,
							t.colours.accent,
							t.colours.text
						].map((e, t) => /* @__PURE__ */ G("span", { style: { background: e } }, t))
					}, e))
				})]
			}),
			/* @__PURE__ */ K("div", {
				className: "gs-m3d__field gs-m3d__field--top",
				children: [/* @__PURE__ */ G("span", { children: "Font" }), /* @__PURE__ */ G(ni, {
					value: b,
					onPick: x
				})]
			}),
			w && /* @__PURE__ */ K("div", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ G("span", { children: "Scene" }), /* @__PURE__ */ K("label", {
					className: "gs-m3d__check gs-ad__scene",
					children: [
						/* @__PURE__ */ G("input", {
							type: "checkbox",
							checked: T,
							onChange: (e) => E(e.target.checked)
						}),
						/* @__PURE__ */ G("img", {
							src: w,
							alt: "The last scene"
						}),
						" Use the last scene behind it"
					]
				})]
			}),
			/* @__PURE__ */ K("label", {
				className: "gs-m3d__check",
				children: [/* @__PURE__ */ G("input", {
					type: "checkbox",
					checked: S,
					onChange: (e) => C(e.target.checked)
				}), " Make it move (the product floats, the words pop in, the price pulses)"]
			}),
			D && /* @__PURE__ */ G("p", {
				className: "gs-m3d__note",
				children: D
			}),
			/* @__PURE__ */ K("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ G("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ G("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: n,
						children: "Cancel"
					}),
					/* @__PURE__ */ G("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: !A,
						onClick: () => {
							li({
								style: g,
								palette: v,
								font: b.family
							}), t({
								picture: i,
								headline: c,
								tagline: u,
								price: f,
								logo: m,
								style: g,
								colours: ut[v].colours,
								font: b,
								moving: S,
								scene: T ? w : null
							});
						},
						children: "Make the ad"
					})
				]
			})
		]
	});
}
//#endregion
//#region src/model3d/clipboard.ts
var di = null, fi = null;
function pi(e, t) {
	di = {
		shapes: structuredClone(t),
		assets: Ne(e, t),
		pastes: 0
	};
}
var mi = () => di;
function hi() {
	let e = di ? ++di.pastes : 1;
	return [
		.5 * e,
		0,
		.5 * e
	];
}
function gi(e) {
	fi = {
		color: e.color,
		finish: e.finish
	};
}
var _i = () => fi;
async function vi(e) {
	if (!navigator.clipboard?.write || typeof ClipboardItem > "u") throw Error("This browser cannot put pictures on the clipboard.");
	await navigator.clipboard.write([new ClipboardItem({ "image/png": e })]).catch(yi);
}
function yi(e) {
	throw e instanceof Error && /denied|not allowed|permission|focus/i.test(e.message) ? Error("The browser did not allow copying here. Use Save instead, or allow the clipboard for this page.") : e;
}
async function bi(e) {
	let t = e.then((e) => new Blob([e], { type: "text/plain" }));
	if (navigator.clipboard?.write && typeof ClipboardItem < "u") {
		let n = ClipboardItem.supports?.("image/svg+xml"), r = { "text/plain": t };
		n && (r["image/svg+xml"] = e.then((e) => new Blob([e], { type: "image/svg+xml" }))), await navigator.clipboard.write([new ClipboardItem(r)]).catch(yi);
	} else await navigator.clipboard.writeText(await e).catch(yi);
}
//#endregion
//#region src/model3d/MotionSection.tsx
var xi = {
	spin: "turns",
	float: "rises",
	bounce: "hops",
	sway: "sways",
	pulse: "pulses",
	wiggle: "wiggles",
	orbit: "times round",
	pop: "pops"
}, Si = [
	"float",
	"bounce",
	"sway",
	"pulse",
	"wiggle"
];
function Ci({ editor: e, items: t, playing: n, onPlay: i }) {
	let a = t.find((e) => e.shape.motion)?.shape.motion, o = t.some((e) => e.shape.motion?.kind !== a?.kind), s = (n, r) => e.updateShapesAt(t.map(({ ref: e, shape: t }) => [e, { motion: n === null ? void 0 : {
		...Le,
		...t.motion ?? a ?? {},
		...n
	} }]), r), c = (n, r, i) => a && /* @__PURE__ */ G(H, {
		label: n,
		value: a[r],
		min: 0,
		max: 1,
		step: .01,
		format: i,
		onBegin: () => e.begin(n),
		onChange: (n) => e.updateShapesAt(t.map(({ ref: e, shape: t }) => [e, { motion: {
			...Le,
			...t.motion ?? a,
			[r]: n
		} }])),
		onEnd: () => e.commit()
	});
	return /* @__PURE__ */ K("section", { children: [
		/* @__PURE__ */ G("h4", { children: "Motion" }),
		/* @__PURE__ */ K("label", {
			className: "gs-m3d__field",
			children: [/* @__PURE__ */ G("span", { children: "Moves" }), /* @__PURE__ */ K("select", {
				value: o ? "" : a?.kind ?? "none",
				onChange: (e) => {
					let t = e.target.value;
					t === "none" ? s(null, "No motion") : t && s({ kind: t }, Be[t]);
				},
				children: [
					o && /* @__PURE__ */ G("option", {
						value: "",
						children: "Different ones"
					}),
					/* @__PURE__ */ G("option", {
						value: "none",
						children: "Does not move"
					}),
					ze.map((e) => /* @__PURE__ */ G("option", {
						value: e,
						children: Be[e]
					}, e))
				]
			})]
		}),
		a && !o && /* @__PURE__ */ K(Ct, { children: [
			/* @__PURE__ */ K("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ G("span", { children: "Times" }), /* @__PURE__ */ G("select", {
					value: a.times,
					onChange: (e) => s({ times: Number(e.target.value) }, "Motion times"),
					children: [
						1,
						2,
						3,
						4,
						6,
						8
					].map((e) => /* @__PURE__ */ K("option", {
						value: e,
						children: [
							e,
							" ",
							xi[a.kind],
							" a clip"
						]
					}, e))
				})]
			}),
			Si.includes(a.kind) && c("How far", "amount", (e) => `${Math.round(e * 100)}%`),
			a.kind === "spin" && /* @__PURE__ */ G(Ce, {
				label: "About",
				value: a.axis,
				options: [
					"y",
					"x",
					"z"
				],
				labels: {
					y: "Upright",
					x: "Tumble",
					z: "Roll"
				},
				onChange: (e) => s({ axis: e }, "Spin axis")
			}),
			a.kind === "sway" && /* @__PURE__ */ G(Ce, {
				label: "Sways",
				value: a.axis === "x" ? "x" : "z",
				options: ["z", "x"],
				labels: {
					z: "Side to side",
					x: "Front to back"
				},
				onChange: (e) => s({ axis: e }, "Sway direction")
			}),
			(a.kind === "spin" || a.kind === "orbit") && /* @__PURE__ */ K("label", {
				className: "gs-m3d__check",
				children: [/* @__PURE__ */ G("input", {
					type: "checkbox",
					checked: a.reverse,
					onChange: (e) => s({ reverse: e.target.checked }, "Motion direction")
				}), " The other way"]
			}),
			c("Start later", "delay", (e) => `${Math.round(e * 100)}%`)
		] }),
		/* @__PURE__ */ K("div", {
			className: "gs-m3d__row",
			children: [/* @__PURE__ */ G("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: i,
				title: "Space",
				children: n ? "Stop" : "Play"
			}), t.length > 1 && a && /* @__PURE__ */ G("button", {
				type: "button",
				className: "gs-m3d__btn",
				title: "Each one starts a little after the one before, in the list's order",
				onClick: () => e.updateShapesAt([...t].sort((e, t) => e.ref[0] - t.ref[0]).map(({ ref: e, shape: n }, r) => [e, { motion: {
					...Le,
					...n.motion ?? a,
					delay: r / t.length / 2
				} }]), "Stagger"),
				children: "Stagger"
			})]
		}),
		/* @__PURE__ */ G(r, { id: "m3dMotion" })
	] });
}
//#endregion
//#region src/model3d/ScenePanel.tsx
function wi({ editor: e, doc: t, aspect: n }) {
	let a = i(), [o, s] = W(Oe[0]), [c, l] = W(null), [u, d] = W(null), f = U(null), p = a.state === "ready" ? a.installed("redraw")[0] : void 0, m = t.background.picture, h = (t, n) => {
		e.setSetting("background", "picture", t, n), Ae(t);
	}, g = async () => {
		d(null);
		try {
			h(await ye(a.client, n(), o.trim() || Oe[0], l), "Scene behind");
		} catch (e) {
			d(e instanceof Error ? e.message : "The scene could not be made.");
		} finally {
			l(null);
		}
	};
	return /* @__PURE__ */ K("section", { children: [
		/* @__PURE__ */ G("h4", { children: "Scene behind" }),
		m && /* @__PURE__ */ K("div", {
			className: "gs-scene__now",
			children: [/* @__PURE__ */ G("img", {
				src: m,
				alt: "The scene behind the design"
			}), /* @__PURE__ */ G("button", {
				type: "button",
				className: "gs-m3d__btn",
				disabled: !!c,
				onClick: () => h("", "No scene"),
				children: "Remove the scene"
			})]
		}),
		/* @__PURE__ */ K("label", {
			className: "gs-m3d__field gs-m3d__field--top",
			children: [/* @__PURE__ */ G("span", { children: "Paint" }), /* @__PURE__ */ G("textarea", {
				rows: 2,
				value: o,
				maxLength: 200,
				onChange: (e) => s(e.target.value),
				disabled: !!c
			})]
		}),
		/* @__PURE__ */ G("div", {
			className: "gs-scene__ideas",
			children: Oe.map((e) => /* @__PURE__ */ G("button", {
				type: "button",
				className: o === e ? "is-on" : "",
				disabled: !!c,
				onClick: () => s(e),
				children: e.split(",")[0]
			}, e))
		}),
		/* @__PURE__ */ G("p", {
			className: "gs-m3d__note",
			children: p ? "Free: painted by the image model on this computer, about a minute; nothing is sent anywhere. The scene goes behind; every shape and the product photo stay as they are." : a.state === "ready" ? "Painting a scene needs the image model, set up once with: npm run redraw:setup (free, on this computer). Your own picture works without it." : "Painting a scene needs the Gleamshelf app running on this computer. Your own picture works without it."
		}),
		/* @__PURE__ */ K("div", {
			className: "gs-m3d__row",
			children: [
				/* @__PURE__ */ G("button", {
					type: "button",
					className: "gs-m3d__btn gs-m3d__btn--primary",
					disabled: !p || !!c,
					onClick: () => void g(),
					children: c ?? (m ? "Paint another" : "Paint a scene")
				}),
				/* @__PURE__ */ G("button", {
					type: "button",
					className: "gs-m3d__btn",
					disabled: !!c,
					onClick: () => f.current?.click(),
					children: "Use my own picture…"
				}),
				/* @__PURE__ */ G("input", {
					ref: f,
					type: "file",
					accept: "image/png,image/jpeg,image/webp",
					hidden: !0,
					onChange: (e) => {
						let t = e.target.files?.[0];
						e.target.value = "", t && ge(t).then((e) => h(e, "Scene behind"));
					}
				})
			]
		}),
		u && /* @__PURE__ */ G("p", {
			className: "gs-m3d__note",
			children: u
		}),
		/* @__PURE__ */ G(r, { id: "m3dScene" })
	] });
}
//#endregion
//#region src/model3d/labels.ts
var Ti = {
	add: "Add",
	subtract: "Cut",
	intersect: "Intersect"
}, Ei = {
	matte: "Matte",
	satin: "Satin",
	glossy: "Glossy",
	metal: "Metal"
}, Di = [
	"#ff7ab6",
	"#f87171",
	"#fbbf24",
	"#34d399",
	"#67e8f9",
	"#60a5fa",
	"#a78bfa",
	"#f4f1fb",
	"#9ca3af",
	"#1f2937"
], Oi = [
	{
		axis: 0,
		name: "Across",
		labels: {
			min: "Left",
			mid: "Middle",
			max: "Right"
		}
	},
	{
		axis: 1,
		name: "Up",
		labels: {
			min: "Bottom",
			mid: "Middle",
			max: "Top"
		}
	},
	{
		axis: 2,
		name: "Depth",
		labels: {
			min: "Back",
			mid: "Middle",
			max: "Front"
		}
	}
];
function ki(e, t) {
	return t.flatMap((t) => {
		let n = e.shapes[t];
		return n ? n.kind === "group" ? (n.children ?? []).map((e, n) => ({
			ref: [t, n],
			shape: e
		})) : [{
			ref: [t],
			shape: n
		}] : [];
	});
}
var Ai = (e, t) => e.kind === "mesh" && e.ownColors !== !1 && ("color" in t || "finish" in t) ? {
	...t,
	ownColors: !1
} : t;
function ji({ editor: e, doc: t, picked: n, onDuplicate: i, onDelete: a, onGroup: o, motion: s }) {
	let c = ki(t, n), l = c[0]?.shape, u = n.map((e) => t.shapes[e]).filter((e) => !!e), d = (t, n) => e.updateShapesAt(c.map(({ ref: e, shape: n }) => [e, Ai(n, t)]), n), f = c.filter((e) => e.shape.kind !== "mesh"), p = u.every((e) => e.locked), m = u.every((e) => e.hidden), h = _i();
	return l ? /* @__PURE__ */ K("div", {
		className: "gs-m3d__panel",
		children: [
			/* @__PURE__ */ K("section", { children: [
				/* @__PURE__ */ K("h4", { children: [n.length, " shapes picked"] }),
				/* @__PURE__ */ K("div", {
					className: "gs-m3d__row",
					children: [
						/* @__PURE__ */ G("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: o,
							title: "Group them (Ctrl G)",
							children: "Group"
						}),
						/* @__PURE__ */ G("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: i,
							title: "Duplicate them (Ctrl D)",
							children: "Duplicate"
						}),
						/* @__PURE__ */ G("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: a,
							title: "Delete them (Delete)",
							children: "Delete"
						}),
						/* @__PURE__ */ G("button", {
							type: "button",
							className: "gs-m3d__btn",
							title: "Locked shapes are not picked or dragged in the view (Ctrl Alt L)",
							onClick: () => e.updateShapesAt(n.map((e) => [[e], { locked: !p }]), p ? "Unlock" : "Lock"),
							children: p ? "Unlock" : "Lock"
						}),
						/* @__PURE__ */ G("button", {
							type: "button",
							className: "gs-m3d__btn",
							title: "Ctrl Shift H",
							onClick: () => e.updateShapesAt(n.map((e) => [[e], { hidden: !m }]), m ? "Show" : "Hide"),
							children: m ? "Show" : "Hide"
						})
					]
				}),
				/* @__PURE__ */ G(r, { id: "m3dMulti" })
			] }),
			/* @__PURE__ */ K("section", { children: [
				/* @__PURE__ */ G("h4", { children: "Line up" }),
				Oi.map(({ axis: t, name: r, labels: i }) => /* @__PURE__ */ K("div", {
					className: "gs-m3d__align",
					children: [/* @__PURE__ */ G("span", { children: r }), [
						"min",
						"mid",
						"max"
					].map((r) => /* @__PURE__ */ G("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => e.align(n, t, r),
						children: i[r]
					}, r))]
				}, t)),
				/* @__PURE__ */ K("div", {
					className: "gs-m3d__align",
					children: [/* @__PURE__ */ G("span", { children: "Spread" }), Oi.map(({ axis: t, name: r }) => /* @__PURE__ */ G("button", {
						type: "button",
						className: "gs-m3d__btn",
						disabled: n.length < 3,
						title: n.length < 3 ? "Pick three or more to spread them" : `Equal gaps ${r.toLowerCase()}`,
						onClick: () => e.spread(n, t),
						children: r
					}, t))]
				}),
				/* @__PURE__ */ G("div", {
					className: "gs-m3d__row",
					children: /* @__PURE__ */ G("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => e.toGround(n),
						children: "Put them on the ground"
					})
				}),
				/* @__PURE__ */ G(r, { id: "m3dAlign" })
			] }),
			/* @__PURE__ */ K("section", { children: [
				/* @__PURE__ */ G("h4", { children: "Colour and finish" }),
				/* @__PURE__ */ K("div", {
					className: "gs-m3d__swatches",
					children: [Di.map((e) => /* @__PURE__ */ G("button", {
						type: "button",
						style: { background: e },
						className: c.every((t) => t.shape.color === e) ? "is-on" : "",
						"aria-label": `Colour ${e}`,
						onClick: () => d({ color: e }, "Colour")
					}, e)), /* @__PURE__ */ G("input", {
						type: "color",
						value: l.color,
						"aria-label": "Any colour",
						onChange: (e) => d({ color: e.target.value }, "Colour")
					})]
				}),
				/* @__PURE__ */ G(Ce, {
					label: "Finish",
					value: c.every((e) => e.shape.finish === l.finish) ? l.finish : "",
					options: Ke,
					labels: Ei,
					onChange: (e) => d({ finish: e }, Ei[e])
				}),
				/* @__PURE__ */ K("div", {
					className: "gs-m3d__row",
					children: [/* @__PURE__ */ G("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => gi(l),
						title: "Copy the first one's colour and finish (Ctrl Alt C)",
						children: "Copy look"
					}), /* @__PURE__ */ G("button", {
						type: "button",
						className: "gs-m3d__btn",
						disabled: !h,
						title: "Give them all the copied colour and finish (Ctrl Alt V)",
						onClick: () => h && d({
							color: h.color,
							finish: h.finish
						}, "Paste look"),
						children: "Paste look"
					})]
				}),
				/* @__PURE__ */ G(r, { id: "m3dLookCopy" })
			] }),
			s,
			f.length > 0 && /* @__PURE__ */ K("section", { children: [
				/* @__PURE__ */ G("h4", { children: "Combine" }),
				/* @__PURE__ */ G(Ce, {
					label: "Combine",
					value: f.every((e) => e.shape.combine === f[0].shape.combine) ? f[0].shape.combine : "",
					options: vt,
					labels: Ti,
					onChange: (t) => e.updateShapesAt(f.map((e) => [e.ref, { combine: t }]), Ti[t])
				}),
				/* @__PURE__ */ G(H, {
					label: "Blend",
					value: f[0].shape.blend,
					min: 0,
					max: 1,
					step: .01,
					format: (e) => `${Math.round(e * 100)}%`,
					onBegin: () => e.begin("Blend"),
					onChange: (t) => e.updateShapesAt(f.map((e) => [e.ref, { blend: t }])),
					onEnd: () => e.commit()
				})
			] })
		]
	}) : null;
}
//#endregion
//#region src/model3d/ModelMode.tsx
var Mi = {
	soft: "Soft",
	toon: "Toon",
	flat: "Flat",
	clay: "Clay",
	pixel: "Pixel"
}, Ni = {
	perspective: "Perspective (0)",
	front: "Front (5)",
	left: "Left (4)",
	side: "Right (6)",
	back: "Back",
	top: "Top (8)",
	bottom: "Bottom (2)",
	"isometric-left": "Isometric, left (7)",
	isometric: "Isometric, right (9)",
	"isometric-below-left": "From below, left (1)",
	"isometric-below": "From below, right (3)"
}, Pi = {
	0: "perspective",
	5: "front",
	4: "left",
	6: "side",
	8: "top",
	2: "bottom",
	7: "isometric-left",
	9: "isometric",
	1: "isometric-below-left",
	3: "isometric-below"
}, Fi = [
	{
		mode: "translate",
		label: "Move",
		key: "W"
	},
	{
		mode: "rotate",
		label: "Turn",
		key: "E"
	},
	{
		mode: "scale",
		label: "Resize",
		key: "R"
	}
], Ii = "gleamshelf.model3d.grid", Li = [
	.1,
	.25,
	.5,
	1,
	2
], Ri = (e) => Math.min(10, Math.max(.05, Math.round(e * 100) / 100));
function zi() {
	try {
		let e = JSON.parse(localStorage.getItem(Ii) ?? "null");
		if (e && typeof e.size == "number" && Number.isFinite(e.size)) return {
			on: e.on !== !1,
			size: Ri(e.size),
			snap: !!e.snap
		};
	} catch {}
	return {
		on: !0,
		size: .5,
		snap: !1
	};
}
var Bi = (e, t) => !!e && !!t && e.length === t.length && e[0] === t[0] && e[1] === t[1], Vi = (e, t) => {
	let n = document.createElement("a");
	n.href = URL.createObjectURL(e), n.download = t, n.click(), setTimeout(() => URL.revokeObjectURL(n.href), 4e3);
};
function Hi({ open: e, title: t = "3D design", onDone: i, doneLabel: o = "Use in design", onClose: s, renderSize: c = 2e3, ad: l }) {
	let u = U(null);
	u.current ||= new yt(e ?? Fe());
	let d = u.current, f = St(d.subscribe, d.getSnapshot), p = f.doc, m = U(null), h = U(null), g = U(null), [_, v] = W(e ? null : [0]), [y, b] = W([]), [x, S] = W("translate"), [C, w] = W(zi), [T, E] = W("shape"), [D, O] = W(null), [ee, k] = W(null), [A, j] = W(l ? "ad" : null), M = t.replace(/[^\w -]+/g, "").trim() || "3d-design", te = U(null), ne = U(null), [N, P] = W(!1), [re, F] = W(!1), [ie, ae] = W(4);
	xt(() => {
		if (m.current) try {
			let e = new Qn(m.current, d, { onPick: (e, t) => {
				if (t.extend && e) {
					let t = e[0];
					b((e) => e.includes(t) ? e.filter((e) => e !== t) : [...e, t]), v([t]);
				} else v(e), b(e ? [e[0]] : []);
			} });
			return h.current = e, () => {
				e.dispose(), h.current = null;
			};
		} catch (e) {
			k(e instanceof Error ? `3D drawing could not start: ${e.message}` : "3D drawing could not start on this computer.");
		}
	}, [d]), xt(() => {
		y.length > 1 ? h.current?.selectSeveral(y) : h.current?.select(_);
	}, [_, y]), xt(() => h.current?.setGizmo(x), [x]), xt(() => {
		h.current?.setGrid(C.on ? C.size : 0, C.on && C.snap);
		try {
			localStorage.setItem(Ii, JSON.stringify(C));
		} catch {}
	}, [C]), xt(() => g.current?.focus(), []), xt(() => {
		_ && !ot(p, _) && v(null), b((e) => e.filter((e) => p.shapes[e]));
	}, [p, _]), xt(() => {
		y.length === 1 && _?.[0] !== y[0] && v([y[0]]);
	}, [y, _]);
	let I = ot(p, _), L = (e, t) => _ && d.updateShapeAt(_, e, t), R = (e) => () => d.begin(e), oe = () => d.commit(), se = () => k("The design is full: it holds 48 shapes (a group counts two more) and 16 outlines or texts."), z = (e, t) => {
		v(e), e.length === 1 && b((n) => t ? n.includes(e[0]) ? n.filter((t) => t !== e[0]) : [...n, e[0]] : [e[0]]);
	}, ce = (e) => {
		let t = d.addShape(e);
		if (t < 0) return se();
		z([t], !1), E("shape");
	}, le = (e, t, n, r) => {
		j(null);
		let i = t >= 1 ? 1 / t : 1, a = t >= 1 ? 1 : t, o = d.addShape("extrude", {
			name: n,
			outline: e,
			size: [
				a * 1.4,
				i * 1.4,
				.35
			],
			...r ? { pen: r } : {}
		});
		if (o < 0) return se();
		z([o], !1), E("shape");
	}, ue = (e, t, n, r) => {
		if (j(null), !I || I.kind !== "extrude") return;
		let i = I.size[1];
		L({
			outline: e,
			pen: r,
			size: [
				i * t,
				i,
				I.size[2]
			]
		}, "Change outline");
	}, de = (e) => e.value.replace(/\s+/g, " ").trim().slice(0, 30), fe = async (e) => {
		await Mr(e.font, e.weight, e.value);
		let t = gt(e.value, e.font, e.weight, Ze, e);
		if (!t) throw Error("That text draws nothing in this font.");
		return t;
	}, B = (e) => {
		j(null), ze("Drawing the letters…", async () => {
			let t = await fe(e), n = .6 * Math.max(1, e.value.split("\n").length * .8), r = d.addShape("text", {
				name: de(e),
				text: e,
				outline: t.outline,
				size: [
					n * t.aspect,
					n,
					.3
				]
			});
			if (r < 0) return se();
			z([r], !1), E("shape");
		});
	}, pe = (e) => {
		if (j(null), !I || I.kind !== "text") return;
		let t = _, [n, r] = [I.size[1], I.size[2]];
		ze("Drawing the letters…", async () => {
			let i = await fe(e);
			t && d.updateShapeAt(t, {
				text: e,
				outline: i.outline,
				name: de(e),
				size: [
					n * i.aspect,
					n,
					r
				]
			}, "Change text");
		});
	}, V = (e) => ze("Reading the SVG…", async () => {
		let t = Ie(d.document.shapes), n = Math.min(16 - t.fields, 48 - t.slots - 2);
		if (n < 1) return se();
		let r = Qe(await e.text(), { maxParts: n }), [i, , a] = d.document.camera.target, o = e.name.replace(/\.svg$/i, "").slice(0, 60) || "Logo", s = $e(r, {
			long: 2,
			at: [i, a]
		});
		s.length === 1 && (s[0].name = o);
		let c = d.addShapes(s, `Import ${o}`, o);
		if (c < 0) return se();
		z([c], !1), E("shape"), d.frameAll(Ne()), r.warnings.length && k(`Imported. ${r.warnings.join(" ")}`);
	}), me = (e) => {
		j(null), ze("Making the ad…", async () => {
			let t = [], n;
			if (e.picture) {
				let r = await Wi(e.picture);
				n = {
					asset: Xt(r.bytes, "image/png", r.width, r.height, "Product photo"),
					aspect: r.width / r.height
				}, r.seeThrough < .02 && t.push("The picture has no see-through background, so its rectangle shows: a cut-out looks best.");
			}
			let r = [
				e.headline,
				e.tagline,
				e.price
			].join(" ");
			await Mr(e.font.family, 900, r);
			let i = e.logo ? Qe(e.logo.svg, { maxParts: 6 }) : void 0, a = at({
				style: e.style,
				colours: e.colours,
				picture: n,
				headline: e.headline,
				tagline: e.tagline,
				price: e.price,
				logo: i,
				font: e.font.family,
				moving: e.moving,
				text: (e) => gt(e.value, e.font, e.weight, Ze, e)
			}, Ne());
			e.scene && (a.background = {
				...a.background,
				picture: e.scene
			}), d.replaceDesign(a, "Make an ad"), v(null), b([]), E("shape"), e.moving && F(!0), i && t.push(...i.warnings.filter((e) => /^(Text|Lines|Strokes|Pictures)/.test(e))), t.length && k(t.join(" "));
		});
	}, he = (e) => {
		let t = e.find((e) => /\.svg$/i.test(e.name) || e.type === "image/svg+xml");
		t ? V(t) : Be(e);
	}, ge = () => {
		let e = d.group(y.length ? y : _?.length === 1 ? [_[0]] : []);
		if (e < 0) return se();
		z([e], !1);
	}, ve = () => {
		_ && _.length === 1 && I?.kind === "group" && z([d.ungroup(_[0])], !1);
	}, ye = () => {
		if (y.length > 1) d.removeShapes(y);
		else if (_) d.removeShapeAt(_);
		else return;
		v(null), b([]);
	}, be = () => {
		if (y.length > 1) {
			let e = d.pasteShapes(y.map((e) => p.shapes[e]).filter(Boolean), {}, [
				.6,
				0,
				0
			]);
			if (!e) return se();
			b(e), v([e[e.length - 1]]);
			return;
		}
		if (!_) return;
		let e = d.duplicateShapeAt(_);
		if (!e) return se();
		z(e, !1);
	}, Se = () => (y.length ? y : _ ? [_[0]] : []).filter((e) => p.shapes[e]), we = (e = !1) => {
		let t = Se();
		t.length && (pi(d.document, t.map((e) => p.shapes[e])), e && (d.removeShapes(t), v(null), b([])));
	}, Te = () => {
		let e = mi();
		if (!e) return !1;
		let t = d.pasteShapes(e.shapes, e.assets, hi());
		return t ? (b(t), v([t[t.length - 1]]), E("shape"), !0) : (se(), !0);
	}, Ee = U(null), De = (e) => {
		if (Ee.current && clearTimeout(Ee.current), Ee.current = null, A) return;
		let t = e.target;
		if (t.tagName === "INPUT" || t.tagName === "TEXTAREA") return;
		let n = e.clipboardData.getData("text/plain");
		/^\s*(<\?xml[^>]*>\s*)?(<!--[\s\S]*?-->\s*)*<svg[\s>]/i.test(n) ? (e.preventDefault(), V(new File([n], "Pasted logo.svg", { type: "image/svg+xml" }))) : Te() && e.preventDefault();
	}, Oe = (e) => {
		let t = Se();
		if (!t.length) return;
		let n = !t.every((t) => p.shapes[t][e]);
		d.updateShapesAt(t.map((t) => [[t], { [e]: n }]), e === "locked" ? n ? "Lock" : "Unlock" : n ? "Hide" : "Show");
	}, ke = () => {
		let e = _i();
		if (!e) return;
		let t = y.length > 1 ? ki(p, y) : _ ? I?.kind === "group" ? ki(p, [_[0]]) : [{
			ref: _,
			shape: I
		}] : [];
		d.updateShapesAt(t.map(({ ref: t, shape: n }) => [t, {
			color: e.color,
			finish: e.finish,
			...n.kind === "mesh" ? { ownColors: !1 } : {}
		}]), "Paste look");
	}, Ae = (e, t = !1) => {
		if (!_) return;
		let n = _;
		for (let r = 0; r < (t ? 48 : 1); r++) {
			let t = d.moveShapeAt(n, e);
			if (Bi(t, n)) break;
			n = t;
		}
		z(n, !1);
	}, je = (e) => {
		if (A) return;
		let t = e.target;
		if (t.tagName === "INPUT" && t.type !== "range" || t.tagName === "SELECT") return;
		let n = e.metaKey || e.ctrlKey, r = e.code.startsWith("Key") ? e.code.slice(3).toLowerCase() : e.key.toLowerCase(), i = /^(?:Digit|Numpad)(\d)$/.exec(e.code)?.[1], a = (t) => {
			e.preventDefault(), t();
		};
		n && r === "z" ? a(() => e.shiftKey ? d.redo() : d.undo()) : n && r === "y" ? a(() => d.redo()) : n && r === "a" ? a(() => {
			b(p.shapes.map((e, t) => t)), v(p.shapes.length ? [p.shapes.length - 1] : null);
		}) : n && e.altKey && r === "c" ? a(() => I && I.kind !== "group" && gi(I)) : n && e.altKey && r === "v" ? a(ke) : n && e.altKey && r === "l" ? a(() => Oe("locked")) : n && e.shiftKey && r === "h" ? a(() => Oe("hidden")) : n && e.shiftKey && r === "c" ? a(() => void Je()) : n && r === "c" ? a(() => we()) : n && r === "x" ? a(() => we(!0)) : n && r === "v" && !e.shiftKey ? (Ee.current && clearTimeout(Ee.current), Ee.current = setTimeout(() => {
			Ee.current = null, Te();
		}, 80)) : n && r === "d" ? a(be) : n && r === "g" ? a(() => e.shiftKey ? ve() : ge()) : n && (e.code === "BracketRight" || e.code === "BracketLeft") ? a(() => Ae(e.code === "BracketRight" ? 1 : -1, e.altKey)) : n && e.key.startsWith("Arrow") ? a(() => d.snapOrbit(e.key === "ArrowLeft" ? -1 : +(e.key === "ArrowRight"), e.key === "ArrowUp" ? 1 : e.key === "ArrowDown" ? -1 : 0)) : !n && i && Pi[i] ? a(() => d.setView(Pi[i])) : !n && r === "w" ? S("translate") : !n && r === "e" ? S("rotate") : !n && r === "r" ? S("scale") : !n && r === "f" ? d.frameAll(Ne()) : !n && r === "g" ? w((e) => ({
			...e,
			on: !e.on
		})) : !n && (e.code === "Space" || e.key === " ") ? a(Xe) : (e.key === "Delete" || e.key === "Backspace") && (_ || y.length) ? a(ye) : e.key === "Escape" && (v(null), b([]));
	}, Ne = () => {
		let e = m.current?.getBoundingClientRect();
		return e && e.height > 0 ? e.width / e.height : 1;
	}, Le = async () => {
		let e = Ne(), t = d.document.background.transparent && !d.document.background.picture, n = t ? 1.8 : 1, r = Math.round(c * n), [i, o] = e >= 1 ? [r, Math.round(r / e)] : [Math.round(r * e), r], s = await er(d.document, i, o, "image/png", n);
		if (!t) return s;
		let l = await a(await createImageBitmap(s)), u = document.createElement("canvas");
		return u.width = l.width, u.height = l.height, u.getContext("2d").drawImage(l, 0, 0), l.close(), new Promise((e, t) => u.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be made.")), "image/png"));
	}, ze = async (e, t) => {
		O(e);
		try {
			await t();
		} catch (e) {
			k(e instanceof Error ? e.message : "That did not work.");
		} finally {
			O(null);
		}
	}, Be = (e) => ze("Reading the model…", async () => {
		let { asset: t, warnings: n } = await hr(e), r = d.addModel(t);
		r < 0 ? k("The design holds 16 imported models; remove one first.") : (z([r], !1), E("shape"), d.frameAll(Ne()), n.length && k(`Imported. ${n.join(" ")}`));
	}), Ve = (e) => {
		let t = Re(e.rotation);
		return [
			0,
			1,
			2
		].reduce((n, r) => n + Math.abs(t[3 + r]) * e.size[r] / 2, 0);
	}, He = () => ze("Drawing the picture…", async () => Vi(await Le(), `${M}.png`)), Ue = async () => {
		let e = Ne(), t = d.document.background.transparent && !d.document.background.picture, n = t ? 1200 : 900, [r, i] = e >= 1 ? [n, Math.round(n / e)] : [Math.round(n * e), n];
		return dt(d.document, {
			width: r,
			height: i,
			frame: t ? 1.6 : 1,
			tones: d.document.style.look === "toon" ? d.document.style.bands : 3,
			onProgress: async (e) => {
				O(`Tracing the vectors… ${Math.round(e * 100)}%`), await new Promise((e) => setTimeout(e, 0));
			}
		});
	}, We = () => ze("Tracing the vectors…", async () => Vi(new Blob([await Ue()], { type: "image/svg+xml" }), `${M}.svg`)), Je = () => ze("Copying the picture…", async () => {
		await vi(Le()), k("Picture copied: paste it into another app.");
	}), Ye = () => ze("Tracing the vectors…", async () => {
		await bi(Ue()), k("Vectors copied: paste them into a drawing app.");
	});
	xt(() => {
		let e = h.current;
		if (!re || !e) return;
		let t = performance.now(), n = 0, r = (i) => {
			e.showFrame(Ge(d.document, ((i - t) / 1e3 / ie % 1 + 1) % 1)), n = requestAnimationFrame(r);
		};
		return n = requestAnimationFrame(r), () => {
			cancelAnimationFrame(n), e.showFrame(null);
		};
	}, [
		re,
		ie,
		d
	]);
	let Xe = () => F((e) => !e), et = (e, t, n) => {
		ae(t), j(null), ze("Making the video…", async () => {
			let r = await rr(d.document, {
				kind: e,
				seconds: t,
				size: n,
				aspect: Ne(),
				onProgress: (e) => O(`Making the video… ${Math.round(e * 100)}%`)
			});
			Vi(r.blob, `${M}-${e}.${r.extension}`);
		});
	}, tt = () => i && ze("Drawing the picture…", async () => i(await Le(), Me(d.document))), nt = p.light, rt = p.style, it = (e) => e.kind === "text" ? "text" : e.kind, st = (y.length ? y : _?.length === 1 ? [_[0]] : []).some((e) => p.shapes[e] && p.shapes[e].kind !== "group"), ct = (e, t, n) => /* @__PURE__ */ K("li", {
		className: `${Bi(t, _) ? "is-on" : ""} ${t.length === 1 && y.includes(t[0]) && !Bi(t, _) ? "is-picked" : ""}`,
		style: { paddingLeft: n * 14 },
		children: [
			/* @__PURE__ */ K("button", {
				type: "button",
				className: "gs-m3d__item",
				onClick: (e) => z(t, e.shiftKey || e.metaKey || e.ctrlKey),
				children: [
					e.kind === "group" ? /* @__PURE__ */ G(xe, { kind: "group" }) : /* @__PURE__ */ G("span", {
						className: "gs-m3d__dot",
						style: { background: e.color }
					}),
					/* @__PURE__ */ G("span", {
						className: "gs-m3d__name",
						children: e.name
					}),
					e.combine !== "add" && /* @__PURE__ */ G("span", {
						className: "gs-m3d__tag",
						children: Ti[e.combine]
					})
				]
			}),
			t.length === 1 && /* @__PURE__ */ G("button", {
				type: "button",
				className: `gs-m3d__icon ${e.locked ? "is-locked" : "gs-m3d__icon--quiet"}`,
				title: e.locked ? "Unlock: it can be picked and dragged again" : "Lock: it cannot be picked or dragged in the view",
				"aria-pressed": !!e.locked,
				onClick: () => d.updateShapeAt(t, { locked: !e.locked }, e.locked ? "Unlock" : "Lock"),
				children: /* @__PURE__ */ G(Ui, { open: !e.locked })
			}),
			/* @__PURE__ */ G("button", {
				type: "button",
				className: "gs-m3d__icon",
				title: e.hidden ? "Show" : "Hide",
				onClick: () => d.updateShapeAt(t, { hidden: !e.hidden }, e.hidden ? "Show" : "Hide"),
				children: e.hidden ? "◌" : "●"
			})
		]
	}, e.id);
	return /* @__PURE__ */ K("div", {
		className: "gs-m3d",
		ref: g,
		tabIndex: -1,
		onKeyDown: je,
		onPaste: De,
		children: [
			/* @__PURE__ */ K("header", {
				className: "gs-m3d__top",
				children: [
					/* @__PURE__ */ G("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: s,
						children: "← Back"
					}),
					/* @__PURE__ */ G("strong", {
						className: "gs-m3d__title",
						children: t
					}),
					/* @__PURE__ */ G("button", {
						type: "button",
						className: `gs-m3d__btn ${re ? "is-on" : ""}`,
						onClick: Xe,
						title: bt(p) ? "Play the shapes’ motion (Space)" : "Give a shape a motion (in its panel), then play it here (Space)",
						children: re ? "■ Stop" : "▶ Play"
					}),
					/* @__PURE__ */ G("div", {
						className: "gs-m3d__group",
						role: "group",
						"aria-label": "Gizmo",
						children: Fi.map((e) => /* @__PURE__ */ K("button", {
							type: "button",
							className: `gs-m3d__btn ${x === e.mode ? "is-on" : ""}`,
							onClick: () => S(e.mode),
							title: `${e.label} (${e.key})`,
							children: [
								e.label,
								" ",
								/* @__PURE__ */ G("kbd", { children: e.key })
							]
						}, e.mode))
					}),
					/* @__PURE__ */ K("select", {
						className: "gs-m3d__select",
						"aria-label": "View",
						value: "",
						onChange: (e) => {
							e.target.value === "frame" ? d.frameAll(Ne()) : e.target.value && d.setView(e.target.value), e.currentTarget.blur();
						},
						children: [
							/* @__PURE__ */ G("option", {
								value: "",
								children: "View…"
							}),
							Object.keys(Ni).map((e) => /* @__PURE__ */ G("option", {
								value: e,
								children: Ni[e]
							}, e)),
							/* @__PURE__ */ G("option", {
								value: "frame",
								children: "Frame all (F)"
							})
						]
					}),
					/* @__PURE__ */ K("div", {
						className: "gs-m3d__group",
						role: "group",
						"aria-label": "Grid",
						children: [
							/* @__PURE__ */ K("button", {
								type: "button",
								className: `gs-m3d__btn ${C.on ? "is-on" : ""}`,
								onClick: () => w((e) => ({
									...e,
									on: !e.on
								})),
								title: "Show the grid on the ground (G); it is never in saved pictures or video",
								children: ["Grid ", /* @__PURE__ */ G("kbd", { children: "G" })]
							}),
							/* @__PURE__ */ G("input", {
								className: "gs-m3d__cell",
								type: "number",
								list: "gs-m3d-cells",
								min: .05,
								max: 10,
								step: .05,
								value: C.size,
								disabled: !C.on,
								"aria-label": "Grid cell size",
								title: "Grid cell size, in the same units as Size and Place (the starter box is 1 across)",
								onChange: (e) => {
									let t = Number(e.target.value);
									Number.isFinite(t) && t > 0 && w((e) => ({
										...e,
										size: Ri(t)
									}));
								}
							}),
							/* @__PURE__ */ G("datalist", {
								id: "gs-m3d-cells",
								children: Li.map((e) => /* @__PURE__ */ G("option", { value: e }, e))
							}),
							/* @__PURE__ */ G("button", {
								type: "button",
								className: `gs-m3d__btn ${C.on && C.snap ? "is-on" : ""}`,
								disabled: !C.on,
								onClick: () => w((e) => ({
									...e,
									snap: !e.snap
								})),
								title: "Snap: moving goes in whole grid cells, turning in 15° steps",
								children: "Snap"
							})
						]
					}),
					/* @__PURE__ */ G("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ G("button", {
						type: "button",
						className: "gs-m3d__btn",
						disabled: !f.canUndo,
						onClick: () => d.undo(),
						title: f.undoLabel ? `Undo ${f.undoLabel}` : "Undo",
						children: "Undo"
					}),
					/* @__PURE__ */ G("button", {
						type: "button",
						className: "gs-m3d__btn",
						disabled: !f.canRedo,
						onClick: () => d.redo(),
						title: f.redoLabel ? `Redo ${f.redoLabel}` : "Redo",
						children: "Redo"
					}),
					/* @__PURE__ */ K("select", {
						className: "gs-m3d__select",
						"aria-label": "Save",
						value: "",
						disabled: !!D,
						onChange: (e) => {
							let t = e.target.value;
							e.currentTarget.blur(), t === "png" ? He() : t === "svg" ? We() : t === "copy-png" ? Je() : t === "copy-svg" ? Ye() : t === "video" && j("video");
						},
						children: [
							/* @__PURE__ */ G("option", {
								value: "",
								children: "Save…"
							}),
							/* @__PURE__ */ G("option", {
								value: "png",
								children: "Picture (PNG)"
							}),
							/* @__PURE__ */ G("option", {
								value: "svg",
								children: "Vectors (SVG)"
							}),
							/* @__PURE__ */ G("option", {
								value: "video",
								children: "Video…"
							}),
							/* @__PURE__ */ G("option", {
								value: "copy-png",
								children: "Copy the picture (Ctrl Shift C)"
							}),
							/* @__PURE__ */ G("option", {
								value: "copy-svg",
								children: "Copy as vectors (SVG)"
							})
						]
					}),
					i && /* @__PURE__ */ G("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: !!D,
						onClick: () => void tt(),
						children: o
					})
				]
			}),
			/* @__PURE__ */ K("div", {
				className: "gs-m3d__body",
				children: [
					/* @__PURE__ */ K("aside", {
						className: "gs-m3d__left",
						"aria-label": "Shapes",
						children: [
							/* @__PURE__ */ G("h3", { children: "Add a shape" }),
							/* @__PURE__ */ K("div", {
								className: "gs-m3d__add",
								children: [
									_t.map((e) => /* @__PURE__ */ K("button", {
										type: "button",
										onClick: () => ce(e),
										title: `Add a ${qe[e].toLowerCase()}`,
										children: [/* @__PURE__ */ G(xe, { kind: e }), /* @__PURE__ */ G("span", { children: qe[e] })]
									}, e)),
									/* @__PURE__ */ K("button", {
										type: "button",
										onClick: () => j("outline"),
										title: "Push out an outline: a star, a heart, or one you draw",
										children: [/* @__PURE__ */ G(xe, { kind: "extrude" }), /* @__PURE__ */ G("span", { children: "Outline" })]
									}),
									/* @__PURE__ */ K("button", {
										type: "button",
										onClick: () => j("text"),
										title: "3D text",
										children: [/* @__PURE__ */ G(xe, { kind: "text" }), /* @__PURE__ */ G("span", { children: "Text" })]
									}),
									/* @__PURE__ */ K("button", {
										type: "button",
										onClick: () => j("ad"),
										title: "A 3D ad: the product's photo, a headline, the price and your logo",
										children: [/* @__PURE__ */ G(xe, { kind: "ad" }), /* @__PURE__ */ G("span", { children: "Ad" })]
									}),
									/* @__PURE__ */ K("button", {
										type: "button",
										onClick: () => ne.current?.click(),
										title: "A logo or drawing from an SVG file: one 3D piece per colour",
										children: [/* @__PURE__ */ G(xe, { kind: "svg" }), /* @__PURE__ */ G("span", { children: "SVG logo" })]
									}),
									/* @__PURE__ */ K("button", {
										type: "button",
										onClick: () => te.current?.click(),
										title: "Import a 3D model: GLB, glTF, FBX, OBJ, STL, PLY or 3MF",
										children: [/* @__PURE__ */ G(xe, { kind: "mesh" }), /* @__PURE__ */ G("span", { children: "Import" })]
									}),
									/* @__PURE__ */ G("input", {
										ref: ne,
										type: "file",
										accept: ".svg,image/svg+xml",
										hidden: !0,
										onChange: (e) => {
											let t = e.target.files?.[0];
											e.target.value = "", t && V(t);
										}
									}),
									/* @__PURE__ */ G("input", {
										ref: te,
										type: "file",
										multiple: !0,
										accept: sr,
										hidden: !0,
										onChange: (e) => {
											let t = [...e.target.files ?? []];
											e.target.value = "", t.length && he(t);
										}
									})
								]
							}),
							/* @__PURE__ */ G(r, { id: "m3dAdd" }),
							/* @__PURE__ */ G("h3", { children: "Shapes" }),
							/* @__PURE__ */ G("ul", {
								className: "gs-m3d__list",
								children: p.shapes.map((e, t) => [ct(e, [t], 0), ...e.kind === "group" ? (e.children ?? []).map((e, n) => ct(e, [t, n], 1)) : []])
							}),
							/* @__PURE__ */ K("div", {
								className: "gs-m3d__listtools",
								children: [
									_ && /* @__PURE__ */ K(Ct, { children: [
										/* @__PURE__ */ G("button", {
											type: "button",
											onClick: () => v(d.moveShapeAt(_, -1)),
											title: "Earlier: joined before the ones below",
											children: "↑"
										}),
										/* @__PURE__ */ G("button", {
											type: "button",
											onClick: () => v(d.moveShapeAt(_, 1)),
											title: "Later: joined onto the ones above",
											children: "↓"
										}),
										/* @__PURE__ */ G("button", {
											type: "button",
											onClick: be,
											title: "Duplicate (Ctrl D)",
											children: "Duplicate"
										}),
										/* @__PURE__ */ G("button", {
											type: "button",
											onClick: ye,
											title: "Delete",
											children: "Delete"
										})
									] }),
									st && /* @__PURE__ */ K("button", {
										type: "button",
										onClick: ge,
										title: "Group the picked shapes (Ctrl G); Shift-click to pick several",
										children: ["Group", y.length > 1 ? ` ${y.length}` : ""]
									}),
									I?.kind === "group" && /* @__PURE__ */ G("button", {
										type: "button",
										onClick: ve,
										title: "Ungroup (Ctrl Shift G)",
										children: "Ungroup"
									})
								]
							}),
							/* @__PURE__ */ G(r, { id: "m3dShapes" }),
							/* @__PURE__ */ G(r, { id: "m3dGroup" })
						]
					}),
					/* @__PURE__ */ K("main", {
						className: `gs-m3d__stage ${N ? "is-dropping" : ""}`,
						onDragOver: (e) => {
							e.dataTransfer.types.includes("Files") && (e.preventDefault(), P(!0));
						},
						onDragLeave: () => P(!1),
						onDrop: (e) => {
							e.preventDefault(), P(!1);
							let t = [...e.dataTransfer.files];
							t.length && he(t);
						},
						children: [
							/* @__PURE__ */ G("div", {
								className: "gs-m3d__viewport",
								ref: m
							}),
							/* @__PURE__ */ G("div", {
								className: "gs-m3d__hint",
								children: /* @__PURE__ */ G(r, { id: I ? "m3dGizmo" : "m3dView" })
							}),
							D && /* @__PURE__ */ K("div", {
								className: "gs-m3d__busy",
								role: "status",
								children: [
									/* @__PURE__ */ G("span", {
										className: "gs-m3d__spin",
										"aria-hidden": "true"
									}),
									" ",
									D
								]
							}),
							ee && /* @__PURE__ */ K("div", {
								className: "gs-m3d__problem",
								role: "alert",
								children: [ee, /* @__PURE__ */ G("button", {
									type: "button",
									onClick: () => k(null),
									children: "Dismiss"
								})]
							})
						]
					}),
					/* @__PURE__ */ K("aside", {
						className: "gs-m3d__right",
						"aria-label": "Settings",
						children: [
							/* @__PURE__ */ K("nav", {
								className: "gs-m3d__tabs",
								role: "tablist",
								children: [/* @__PURE__ */ G("button", {
									type: "button",
									role: "tab",
									"aria-selected": T === "shape",
									className: T === "shape" ? "is-on" : "",
									onClick: () => E("shape"),
									children: "Shape"
								}), /* @__PURE__ */ G("button", {
									type: "button",
									role: "tab",
									"aria-selected": T === "scene",
									className: T === "scene" ? "is-on" : "",
									onClick: () => E("scene"),
									children: "Light and look"
								})]
							}),
							T === "shape" && (y.length > 1 ? /* @__PURE__ */ G(ji, {
								editor: d,
								doc: p,
								picked: y,
								onDuplicate: be,
								onDelete: ye,
								onGroup: ge,
								motion: /* @__PURE__ */ G(Ci, {
									editor: d,
									items: y.flatMap((e) => p.shapes[e] ? [{
										ref: [e],
										shape: p.shapes[e]
									}] : []),
									playing: re,
									onPlay: Xe
								})
							}) : I ? /* @__PURE__ */ K("div", {
								className: "gs-m3d__panel",
								children: [
									/* @__PURE__ */ G("input", {
										className: "gs-m3d__rename",
										value: I.name,
										"aria-label": "Shape name",
										onChange: (e) => L({ name: e.target.value }, "Rename")
									}),
									(I.locked || _?.length === 2 && p.shapes[_[0]]?.locked) && /* @__PURE__ */ G("p", {
										className: "gs-m3d__note",
										children: "Locked: it is not picked or dragged in the view. Unlock it in the list to move it there."
									}),
									I.kind === "mesh" && /* @__PURE__ */ K("section", { children: [
										/* @__PURE__ */ G("h4", { children: "Imported model" }),
										/* @__PURE__ */ K("p", {
											className: "gs-m3d__meta",
											children: [
												p.assets?.[I.asset ?? ""]?.name ?? "Model",
												" ·",
												" ",
												(p.assets?.[I.asset ?? ""]?.triangles ?? 0).toLocaleString("en"),
												" triangles"
											]
										}),
										/* @__PURE__ */ G(Ce, {
											label: "Colours",
											value: I.ownColors === !1 ? "one" : "own",
											options: ["own", "one"],
											labels: {
												own: "Its own",
												one: "One colour"
											},
											onChange: (e) => L({ ownColors: e === "own" }, e === "own" ? "Own colours" : "One colour")
										}),
										/* @__PURE__ */ K("div", {
											className: "gs-m3d__row",
											children: [/* @__PURE__ */ G("button", {
												type: "button",
												className: "gs-m3d__btn",
												title: "For a model made lying down (z up): turns it a quarter round to stand on the ground",
												onClick: () => {
													let e = [
														I.rotation[0] === -90 ? 0 : -90,
														I.rotation[1],
														I.rotation[2]
													];
													L({
														rotation: e,
														position: [
															I.position[0],
															Ve({
																...I,
																rotation: e
															}),
															I.position[2]
														]
													}, "Stand it up");
												},
												children: "Stand it up"
											}), /* @__PURE__ */ G("button", {
												type: "button",
												className: "gs-m3d__btn",
												onClick: () => L({ position: [
													I.position[0],
													Ve(I),
													I.position[2]
												] }, "Put on the ground"),
												children: "Put on the ground"
											})]
										}),
										/* @__PURE__ */ G(r, { id: "m3dImport" })
									] }),
									/* @__PURE__ */ K("section", { children: [/* @__PURE__ */ G("h4", { children: I.kind === "group" ? "How the group joins" : "Combine" }), I.kind === "mesh" ? /* @__PURE__ */ G("p", {
										className: "gs-m3d__meta",
										children: "An imported model is always added as it is: Cut and Blend work between the shapes you build, not on a model."
									}) : /* @__PURE__ */ K(Ct, { children: [
										/* @__PURE__ */ G(Ce, {
											label: "Combine",
											value: I.combine,
											options: vt,
											labels: Ti,
											onChange: (e) => L({ combine: e }, Ti[e])
										}),
										/* @__PURE__ */ G(H, {
											label: "Blend",
											value: I.blend,
											min: 0,
											max: 1,
											step: .01,
											format: (e) => `${Math.round(e * 100)}%`,
											onBegin: R("Blend"),
											onChange: (e) => L({ blend: e }),
											onEnd: oe
										}),
										/* @__PURE__ */ G(r, { id: I.kind === "group" ? "m3dGroup" : "m3dCombine" })
									] })] }),
									_ && /* @__PURE__ */ G(Ci, {
										editor: d,
										items: [{
											ref: _,
											shape: I
										}],
										playing: re,
										onPlay: Xe
									}),
									it(I) === "text" && I.text && /* @__PURE__ */ K("section", { children: [
										/* @__PURE__ */ G("h4", { children: "Text" }),
										/* @__PURE__ */ G("p", {
											className: "gs-m3d__textpreview",
											style: {
												fontFamily: `"${I.text.font}", sans-serif`,
												fontWeight: I.text.weight,
												whiteSpace: "pre",
												textAlign: I.text.align ?? "center"
											},
											children: I.text.value
										}),
										/* @__PURE__ */ G("button", {
											type: "button",
											className: "gs-m3d__btn",
											onClick: () => j("edit-text"),
											children: "Change text or font…"
										}),
										/* @__PURE__ */ G(r, { id: "m3dText" })
									] }),
									I.kind === "extrude" && /* @__PURE__ */ K("section", { children: [
										/* @__PURE__ */ G("h4", { children: "Outline" }),
										I.pen ? /* @__PURE__ */ G("button", {
											type: "button",
											className: "gs-m3d__btn",
											onClick: () => j("edit-outline"),
											children: "Edit points…"
										}) : /* @__PURE__ */ G("p", {
											className: "gs-m3d__note",
											children: "Made from a picture or a logo, so it has no pen points to edit."
										}),
										/* @__PURE__ */ G(r, { id: "m3dPen" })
									] }),
									I.kind !== "group" && /* @__PURE__ */ K(Ct, { children: [(I.kind !== "mesh" || I.ownColors === !1) && /* @__PURE__ */ K("section", { children: [
										/* @__PURE__ */ G("h4", { children: "Colour and finish" }),
										/* @__PURE__ */ K("div", {
											className: "gs-m3d__swatches",
											children: [Di.map((e) => /* @__PURE__ */ G("button", {
												type: "button",
												style: { background: e },
												className: I.color === e ? "is-on" : "",
												"aria-label": `Colour ${e}`,
												onClick: () => L({ color: e }, "Colour")
											}, e)), /* @__PURE__ */ G("input", {
												type: "color",
												value: I.color,
												"aria-label": "Any colour",
												onChange: (e) => L({ color: e.target.value }, "Colour")
											})]
										}),
										/* @__PURE__ */ G(Ce, {
											label: "Finish",
											value: I.finish,
											options: Ke,
											labels: Ei,
											onChange: (e) => L({ finish: e }, Ei[e])
										}),
										/* @__PURE__ */ K("div", {
											className: "gs-m3d__row",
											children: [/* @__PURE__ */ G("button", {
												type: "button",
												className: "gs-m3d__btn",
												onClick: () => gi(I),
												title: "Ctrl Alt C",
												children: "Copy look"
											}), /* @__PURE__ */ G("button", {
												type: "button",
												className: "gs-m3d__btn",
												disabled: !_i(),
												onClick: ke,
												title: "Ctrl Alt V",
												children: "Paste look"
											})]
										}),
										/* @__PURE__ */ G(r, { id: "m3dMaterial" })
									] }), /* @__PURE__ */ K("section", { children: [
										/* @__PURE__ */ G("h4", { children: "Size and place" }),
										/* @__PURE__ */ G(_e, {
											label: I.outline ? "W, H, depth" : "Size",
											value: I.size,
											step: .05,
											min: .01,
											onChange: (e) => L({ size: e }, "Size")
										}),
										/* @__PURE__ */ G(_e, {
											label: "Place",
											value: I.position,
											step: .05,
											onChange: (e) => L({ position: e }, "Move")
										}),
										/* @__PURE__ */ G(_e, {
											label: "Turn",
											value: I.rotation,
											step: 5,
											onChange: (e) => L({ rotation: e }, "Turn")
										}),
										_?.length === 1 && /* @__PURE__ */ K("div", {
											className: "gs-m3d__row",
											children: [/* @__PURE__ */ G("button", {
												type: "button",
												className: "gs-m3d__btn",
												onClick: () => d.toGround([_[0]]),
												children: "On the ground"
											}), /* @__PURE__ */ G("button", {
												type: "button",
												className: "gs-m3d__btn",
												title: "To the middle of the scene, left to right and front to back",
												onClick: () => {
													d.begin("To the middle"), d.align([_[0]], 0, "mid"), d.align([_[0]], 2, "mid"), d.commit();
												},
												children: "To the middle"
											})]
										}),
										I.kind !== "sphere" && I.kind !== "torus" && I.kind !== "capsule" && I.kind !== "mesh" && /* @__PURE__ */ G(H, {
											label: I.outline ? "Bevel" : "Rounding",
											value: I.round,
											min: 0,
											max: .5,
											step: .01,
											format: (e) => `${Math.round(e * 200)}%`,
											onBegin: R("Rounding"),
											onChange: (e) => L({ round: e }),
											onEnd: oe
										}),
										I.kind === "torus" && /* @__PURE__ */ G(H, {
											label: "Tube",
											value: I.thickness,
											min: .05,
											max: .5,
											step: .01,
											format: (e) => `${Math.round(e * 100)}%`,
											onBegin: R("Tube"),
											onChange: (e) => L({ thickness: e }),
											onEnd: oe
										}),
										/* @__PURE__ */ G(r, { id: I.outline ? "m3dOutlineShape" : "m3dSize" })
									] })] })
								]
							}) : /* @__PURE__ */ K("div", {
								className: "gs-m3d__panel",
								children: [/* @__PURE__ */ G("p", {
									className: "gs-m3d__empty",
									children: "Pick a shape in the view or the list to change it, or add one on the left."
								}), /* @__PURE__ */ G(r, { id: "m3dView" })]
							})),
							T === "scene" && /* @__PURE__ */ K("div", {
								className: "gs-m3d__panel",
								children: [
									/* @__PURE__ */ K("section", { children: [
										/* @__PURE__ */ G("h4", { children: "Look" }),
										/* @__PURE__ */ G(Ce, {
											label: "Look",
											value: rt.look,
											options: Pe,
											labels: Mi,
											onChange: (e) => d.setSetting("style", "look", e, `${Mi[e]} look`)
										}),
										rt.look === "pixel" && /* @__PURE__ */ G(H, {
											label: "Pixel size",
											value: rt.pixel,
											min: 3,
											max: 40,
											step: 1,
											format: (e) => `${e}`,
											onBegin: R("Pixel size"),
											onChange: (e) => d.setSetting("style", "pixel", e),
											onEnd: oe
										}),
										(rt.look === "toon" || rt.look === "pixel") && /* @__PURE__ */ G(H, {
											label: "Steps of light",
											value: rt.bands,
											min: 2,
											max: 6,
											step: 1,
											onBegin: R("Steps of light"),
											onChange: (e) => d.setSetting("style", "bands", e),
											onEnd: oe
										}),
										/* @__PURE__ */ G(r, { id: "m3dLook" })
									] }),
									/* @__PURE__ */ K("section", { children: [
										/* @__PURE__ */ G("h4", { children: "Outline" }),
										/* @__PURE__ */ G(H, {
											label: "Width",
											value: rt.outline,
											min: 0,
											max: 12,
											step: .5,
											format: (e) => e ? `${e} px` : "None",
											onBegin: R("Outline"),
											onChange: (e) => d.setSetting("style", "outline", e),
											onEnd: oe
										}),
										rt.outline > 0 && /* @__PURE__ */ K("label", {
											className: "gs-m3d__colour",
											children: [
												/* @__PURE__ */ G("input", {
													type: "color",
													value: rt.outlineColor,
													onChange: (e) => d.setSetting("style", "outlineColor", e.target.value, "Outline colour")
												}),
												" ",
												"Outline colour"
											]
										}),
										/* @__PURE__ */ G(r, { id: "m3dOutline" })
									] }),
									/* @__PURE__ */ K("section", { children: [
										/* @__PURE__ */ G("h4", { children: "Light" }),
										/* @__PURE__ */ G(H, {
											label: "Around",
											value: nt.azimuth,
											min: -180,
											max: 180,
											step: 1,
											format: (e) => `${e}°`,
											onBegin: R("Light around"),
											onChange: (e) => d.setSetting("light", "azimuth", e),
											onEnd: oe
										}),
										/* @__PURE__ */ G(H, {
											label: "Height",
											value: nt.elevation,
											min: 0,
											max: 90,
											step: 1,
											format: (e) => `${e}°`,
											onBegin: R("Light height"),
											onChange: (e) => d.setSetting("light", "elevation", e),
											onEnd: oe
										}),
										/* @__PURE__ */ G(H, {
											label: "Brightness",
											value: nt.intensity,
											min: 0,
											max: 3,
											step: .05,
											onBegin: R("Brightness"),
											onChange: (e) => d.setSetting("light", "intensity", e),
											onEnd: oe
										}),
										/* @__PURE__ */ G(H, {
											label: "Fill",
											value: nt.ambient,
											min: 0,
											max: 1,
											step: .01,
											format: (e) => `${Math.round(e * 100)}%`,
											onBegin: R("Fill light"),
											onChange: (e) => d.setSetting("light", "ambient", e),
											onEnd: oe
										}),
										/* @__PURE__ */ K("label", {
											className: "gs-m3d__check",
											children: [
												/* @__PURE__ */ G("input", {
													type: "checkbox",
													checked: nt.shadows,
													onChange: (e) => d.setSetting("light", "shadows", e.target.checked, "Shadows")
												}),
												" ",
												"Shadows"
											]
										}),
										/* @__PURE__ */ K("label", {
											className: "gs-m3d__colour",
											children: [
												/* @__PURE__ */ G("input", {
													type: "color",
													value: nt.color,
													onChange: (e) => d.setSetting("light", "color", e.target.value, "Light colour")
												}),
												" ",
												"Light colour"
											]
										}),
										/* @__PURE__ */ G(r, { id: "m3dLight" })
									] }),
									/* @__PURE__ */ K("section", { children: [
										/* @__PURE__ */ G("h4", { children: "Floor and background" }),
										/* @__PURE__ */ K("label", {
											className: "gs-m3d__check",
											children: [
												/* @__PURE__ */ G("input", {
													type: "checkbox",
													checked: p.ground.on,
													onChange: (e) => d.setSetting("ground", "on", e.target.checked, "Floor")
												}),
												" ",
												"Floor shadow"
											]
										}),
										p.ground.on && /* @__PURE__ */ G(H, {
											label: "Shadow strength",
											value: p.ground.shadow,
											min: 0,
											max: 1,
											step: .01,
											format: (e) => `${Math.round(e * 100)}%`,
											onBegin: R("Floor shadow"),
											onChange: (e) => d.setSetting("ground", "shadow", e),
											onEnd: oe
										}),
										/* @__PURE__ */ K("label", {
											className: "gs-m3d__check",
											children: [
												/* @__PURE__ */ G("input", {
													type: "checkbox",
													checked: p.background.transparent,
													onChange: (e) => d.setSetting("background", "transparent", e.target.checked, "Background")
												}),
												" ",
												"See-through background"
											]
										}),
										!p.background.transparent && /* @__PURE__ */ K("label", {
											className: "gs-m3d__colour",
											children: [
												/* @__PURE__ */ G("input", {
													type: "color",
													value: p.background.color,
													onChange: (e) => d.setSetting("background", "color", e.target.value, "Background colour")
												}),
												" ",
												"Background colour"
											]
										}),
										/* @__PURE__ */ G(r, { id: "m3dFloor" })
									] }),
									/* @__PURE__ */ G(wi, {
										editor: d,
										doc: p,
										aspect: Ne
									}),
									/* @__PURE__ */ K("section", { children: [
										/* @__PURE__ */ G("h4", { children: "Camera" }),
										/* @__PURE__ */ G(Ce, {
											label: "Projection",
											value: p.camera.projection,
											options: ["perspective", "orthographic"],
											labels: {
												perspective: "Perspective",
												orthographic: "Flat (no perspective)"
											},
											onChange: (e) => d.setSetting("camera", "projection", e, "Projection")
										}),
										p.camera.projection === "perspective" && /* @__PURE__ */ G(H, {
											label: "Lens",
											value: p.camera.fov,
											min: 10,
											max: 90,
											step: 1,
											format: (e) => `${e}°`,
											onBegin: R("Lens"),
											onChange: (e) => d.setSetting("camera", "fov", e),
											onEnd: oe
										}),
										/* @__PURE__ */ G(r, { id: "m3dView" }),
										/* @__PURE__ */ G(r, { id: "m3dGrid" })
									] }),
									/* @__PURE__ */ K("section", { children: [
										/* @__PURE__ */ G("h4", { children: "Finish" }),
										i && /* @__PURE__ */ G(r, { id: "m3dUse" }),
										/* @__PURE__ */ G(r, { id: "m3dSave" }),
										/* @__PURE__ */ G(r, { id: "m3dSvg" }),
										/* @__PURE__ */ G(r, { id: "m3dVideo" })
									] })
								]
							}),
							/* @__PURE__ */ G("footer", {
								className: "gs-m3d__foot",
								children: /* @__PURE__ */ G(n, {})
							})
						]
					})
				]
			}),
			A === "outline" && /* @__PURE__ */ G(Yr, {
				onPick: le,
				onClose: () => j(null)
			}),
			A === "text" && /* @__PURE__ */ G(Qr, {
				onDone: B,
				onClose: () => j(null)
			}),
			A === "edit-text" && I?.text && /* @__PURE__ */ G(Qr, {
				initial: I.text,
				onDone: pe,
				onClose: () => j(null)
			}),
			A === "edit-outline" && I?.pen && /* @__PURE__ */ G(Yr, {
				initial: I.pen,
				onPick: ue,
				onClose: () => j(null)
			}),
			A === "ad" && /* @__PURE__ */ G(ui, {
				start: l,
				onMake: me,
				onClose: () => j(null)
			}),
			A === "video" && /* @__PURE__ */ G(ri, {
				initialKind: bt(p) ? "still" : "turntable",
				initialSeconds: ie,
				moving: bt(p),
				onMake: et,
				onClose: () => j(null)
			})
		]
	});
}
function Ui({ open: e }) {
	return /* @__PURE__ */ K("svg", {
		width: "12",
		height: "12",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: 2.2,
		"aria-hidden": "true",
		children: [/* @__PURE__ */ G("rect", {
			x: "5",
			y: "11",
			width: "14",
			height: "10",
			rx: "2"
		}), /* @__PURE__ */ G("path", { d: e ? "M8 11V7a4 4 0 0 1 7.5-2" : "M8 11V7a4 4 0 0 1 8 0v4" })]
	});
}
async function Wi(e) {
	let t = await createImageBitmap(e), n = Math.min(1, 1600 / Math.max(t.width, t.height)), [r, i] = [Math.max(1, Math.round(t.width * n)), Math.max(1, Math.round(t.height * n))], a = document.createElement("canvas");
	a.width = r, a.height = i;
	let o = a.getContext("2d");
	o.drawImage(t, 0, 0, r, i), t.close();
	let s = o.getImageData(0, 0, r, i).data, c = 0;
	for (let e = 3; e < s.length; e += 16) s[e] < 128 && c++;
	let l = await new Promise((e, t) => a.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be read.")), "image/png"));
	return {
		bytes: new Uint8Array(await l.arrayBuffer()),
		width: r,
		height: i,
		seeThrough: c / (s.length / 16)
	};
}
//#endregion
export { Hi as ModelMode, Yt as i, qt as n, Jt as r, Xt as t };

//# sourceMappingURL=ModelMode-hMcQJ25f.js.map