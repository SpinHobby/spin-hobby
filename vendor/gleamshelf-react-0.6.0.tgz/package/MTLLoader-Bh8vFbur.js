import { Et as e, F as t, Fn as n, T as r, Vn as i, hr as a, m as o, mt as s, p as c, pt as l, tr as u } from "./three.core-DIbF123p.js";
//#region ../../node_modules/three/examples/jsm/loaders/MTLLoader.js
var d = class extends l {
	constructor(e) {
		super(e);
	}
	load(e, n, r, i) {
		let a = this, o = this.path === "" ? s.extractUrlBase(e) : this.path, c = new t(this.manager);
		c.setPath(this.path), c.setRequestHeader(this.requestHeader), c.setWithCredentials(this.withCredentials), c.load(e, function(t) {
			try {
				n(a.parse(t, o));
			} catch (t) {
				i ? i(t) : console.error(t), a.manager.itemError(e);
			}
		}, r, i);
	}
	setMaterialOptions(e) {
		return this.materialOptions = e, this;
	}
	parse(e, t) {
		let n = e.split("\n"), r = {}, i = /\s+/, a = {};
		for (let e = 0; e < n.length; e++) {
			let t = n[e];
			if (t = t.trim(), t.length === 0 || t.charAt(0) === "#") continue;
			let o = t.indexOf(" "), s = o >= 0 ? t.substring(0, o) : t;
			s = s.toLowerCase();
			let c = o >= 0 ? t.substring(o + 1) : "";
			if (c = c.trim(), s === "newmtl") r = { name: c }, a[c] = r;
			else if (s === "ka" || s === "kd" || s === "ks" || s === "ke") {
				let e = c.split(i, 3);
				r[s] = [
					parseFloat(e[0]),
					parseFloat(e[1]),
					parseFloat(e[2])
				];
			} else r[s] = c;
		}
		let o = new f(this.resourcePath || t, this.materialOptions);
		return o.setCrossOrigin(this.crossOrigin), o.setManager(this.manager), o.setMaterials(a), o;
	}
}, f = class {
	constructor(e = "", t = {}) {
		this.baseUrl = e, this.options = t, this.materialsInfo = {}, this.materials = {}, this.materialsArray = [], this.nameLookup = {}, this.crossOrigin = "anonymous", this.side = this.options.side === void 0 ? 0 : this.options.side, this.wrap = this.options.wrap === void 0 ? n : this.options.wrap;
	}
	setCrossOrigin(e) {
		return this.crossOrigin = e, this;
	}
	setManager(e) {
		this.manager = e;
	}
	setMaterials(e) {
		this.materialsInfo = this.convert(e), this.materials = {}, this.materialsArray = [], this.nameLookup = {};
	}
	convert(e) {
		if (!this.options) return e;
		let t = {};
		for (let n in e) {
			let r = e[n], i = {};
			t[n] = i;
			for (let e in r) {
				let t = !0, n = r[e], a = e.toLowerCase();
				switch (a) {
					case "kd":
					case "ka":
					case "ks": this.options && this.options.normalizeRGB && (n = [
						n[0] / 255,
						n[1] / 255,
						n[2] / 255
					]), this.options && this.options.ignoreZeroRGBs && n[0] === 0 && n[1] === 0 && n[2] === 0 && (t = !1);
				}
				t && (i[a] = n);
			}
		}
		return t;
	}
	preload() {
		for (let e in this.materialsInfo) this.create(e);
	}
	getIndex(e) {
		return this.nameLookup[e];
	}
	getAsArray() {
		let e = 0;
		for (let t in this.materialsInfo) this.materialsArray[e] = this.create(t), this.nameLookup[t] = e, e++;
		return this.materialsArray;
	}
	create(e) {
		return this.materials[e] === void 0 && this.createMaterial_(e), this.materials[e];
	}
	createMaterial_(t) {
		let n = this, r = this.materialsInfo[t], a = {
			name: t,
			side: this.side
		};
		function s(e, t) {
			return typeof t != "string" || t === "" ? "" : /^https?:\/\//i.test(t) ? t : e + t;
		}
		function l(e, t) {
			if (a[e]) return;
			let r = n.getTextureParams(t, a), o = n.loadTexture(s(n.baseUrl, r.url));
			o.repeat.copy(r.scale), o.offset.copy(r.offset), o.wrapS = n.wrap, o.wrapT = n.wrap, (e === "map" || e === "emissiveMap") && (o.colorSpace = i), a[e] = o;
		}
		for (let e in r) {
			let t = r[e], n;
			if (t !== "") switch (e.toLowerCase()) {
				case "kd":
					a.color = o.colorSpaceToWorking(new c().fromArray(t), i);
					break;
				case "ks":
					a.specular = o.colorSpaceToWorking(new c().fromArray(t), i);
					break;
				case "ke":
					a.emissive = o.colorSpaceToWorking(new c().fromArray(t), i);
					break;
				case "map_kd":
					l("map", t);
					break;
				case "map_ks":
					l("specularMap", t);
					break;
				case "map_ke":
					l("emissiveMap", t);
					break;
				case "norm":
					l("normalMap", t);
					break;
				case "map_bump":
				case "bump":
					l("bumpMap", t);
					break;
				case "disp":
					l("displacementMap", t);
					break;
				case "map_d":
					l("alphaMap", t), a.transparent = !0;
					break;
				case "ns":
					a.shininess = parseFloat(t);
					break;
				case "d":
					n = parseFloat(t), n < 1 && (a.opacity = n, a.transparent = !0);
					break;
				case "tr": n = parseFloat(t), this.options && this.options.invertTrProperty && (n = 1 - n), n > 0 && (a.opacity = 1 - n, a.transparent = !0);
			}
		}
		return this.materials[t] = new e(a), this.materials[t];
	}
	getTextureParams(e, t) {
		let n = {
			scale: new a(1, 1),
			offset: new a(0, 0)
		}, r = e.split(/\s+/), i;
		return i = r.indexOf("-bm"), i >= 0 && (t.bumpScale = parseFloat(r[i + 1]), r.splice(i, 2)), i = r.indexOf("-mm"), i >= 0 && (t.displacementBias = parseFloat(r[i + 1]), t.displacementScale = parseFloat(r[i + 2]), r.splice(i, 3)), i = r.indexOf("-s"), i >= 0 && (n.scale.set(parseFloat(r[i + 1]), parseFloat(r[i + 2])), r.splice(i, 4)), i = r.indexOf("-o"), i >= 0 && (n.offset.set(parseFloat(r[i + 1]), parseFloat(r[i + 2])), r.splice(i, 4)), n.url = r.join(" ").trim(), n;
	}
	loadTexture(e, t, n, i, a) {
		let o = this.manager === void 0 ? r : this.manager, s = o.getHandler(e);
		s === null && (s = new u(o)), s.setCrossOrigin && s.setCrossOrigin(this.crossOrigin);
		let c = s.load(e, n, i, a);
		return t !== void 0 && (c.mapping = t), c;
	}
};
//#endregion
export { d as MTLLoader };

//# sourceMappingURL=MTLLoader-Bh8vFbur.js.map