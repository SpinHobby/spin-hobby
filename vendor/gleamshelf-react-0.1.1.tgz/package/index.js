import { r as e } from "./rolldown-runtime-DldpqzEl.js";
import { useCallback as t, useEffect as n, useMemo as r, useRef as i, useState as a, useSyncExternalStore as o } from "react";
import { Fragment as s, jsx as c, jsxs as l } from "react/jsx-runtime";
import { createPortal as u } from "react-dom";
//#region ../core/src/mask.ts
var d = /^[a-z0-9][a-z0-9-]{0,59}$/, f = /^[a-z0-9]{6,32}$/, p = 1024, m = 500, h = 2e4, g = (e) => typeof e == "number" && Number.isFinite(e) && e >= 0 && e <= 1;
function _(e) {
	if (!e || typeof e != "object") return;
	let t = e, n = t.mode === "remove" || t.mode === "keep" ? t.mode : void 0;
	if (n) {
		if (t.kind === "green") return n === "remove" ? {
			kind: "green",
			mode: n
		} : void 0;
		if (t.kind === "fade") return n === "remove" && t.edge === "bottom" && typeof t.size == "number" && Number.isFinite(t.size) ? {
			kind: "fade",
			mode: n,
			edge: "bottom",
			size: Math.min(.4, Math.max(.02, t.size))
		} : void 0;
		if (t.kind === "erase") {
			let e = t.boxes;
			return n !== "remove" || !Array.isArray(e) || e.length === 0 || e.length % 4 || e.length > 400 || !e.every(g) ? void 0 : {
				kind: "erase",
				mode: n,
				boxes: e
			};
		}
		if (t.kind === "model") return n === "remove" && typeof t.model == "string" && d.test(t.model) && typeof t.ref == "string" && f.test(t.ref) ? {
			kind: "model",
			mode: n,
			model: t.model,
			ref: t.ref
		} : void 0;
		if (t.kind === "fill") return !g(t.x) || !g(t.y) || typeof t.tolerance != "number" || !Number.isFinite(t.tolerance) ? void 0 : {
			kind: "fill",
			mode: n,
			x: t.x,
			y: t.y,
			tolerance: Math.min(100, Math.max(0, t.tolerance))
		};
		if (t.kind === "brush") {
			let e = t.points;
			return !Array.isArray(e) || e.length < 2 || e.length % 2 || e.length > h || !e.every(g) || typeof t.radius != "number" || !(t.radius > 0) || t.radius > .5 ? void 0 : {
				kind: "brush",
				mode: n,
				radius: t.radius,
				points: e
			};
		}
	}
}
function v(e) {
	if (!Array.isArray(e) || e.length > m) return;
	let t = e.map(_);
	return t.every((e) => e !== void 0) ? t : void 0;
}
function y(e) {
	return Array.isArray(e) ? e.slice(0, m).map(_).filter((e) => e !== void 0) : [];
}
function b(e, t) {
	let n = Math.min(1, p / Math.max(e, t));
	return {
		width: Math.max(1, Math.round(e * n)),
		height: Math.max(1, Math.round(t * n))
	};
}
function x(e, t, n, r, i) {
	let a = new Uint8Array(t * n).fill(255);
	for (let o of r) o.kind === "fill" ? se(e, a, t, n, o) : o.kind === "green" ? ae(e, a, t, n) : o.kind === "fade" ? ne(a, t, n, o.size) : o.kind === "erase" ? E(a, t, n, o.boxes) : o.kind === "model" ? ie(a, t, n, i?.get(o.ref)) : D(a, t, n, o);
	return r.length ? ce(a, t, n) : a;
}
function S(e, t, n) {
	let r = Math.max(2, Math.round(Math.min(t, n) * .02)), i = 0, a = 0, o = (n, r) => {
		let o = (r * t + n) * 4, s = e[o + 1] - Math.max(e[o], e[o + 2]);
		a++, s > 12 && s / Math.max(e[o + 1], 1) > .2 && i++;
	};
	for (let e = 0; e < n; e += 2) for (let n = 0; n < r; n++) o(n, e), o(t - 1 - n, e);
	for (let e = 0; e < t; e += 2) for (let t = 0; t < r; t++) o(e, t), o(e, n - 1 - t);
	return a ? i / a : 0;
}
var C = (e) => e.some((e) => e.kind === "green");
function w(e, t, n) {
	let r = Math.max(4, Math.round(Math.min(t, n) * .03)), i = [], a = [], o = (n, r) => {
		let o = (r * t + n) * 4, s = e[o], c = e[o + 1], l = e[o + 2];
		if (c - Math.max(s, l) < 20 || (c - Math.max(s, l)) / Math.max(c, 1) < .15) return;
		let u = s + c + l;
		i.push(s / u), a.push(c / u);
	};
	for (let e = 0; e < n; e += 2) for (let n = 0; n < r; n += 2) o(n, e), o(t - 1 - n, e);
	for (let e = 0; e < t; e += 2) for (let t = 0; t < r; t += 2) o(e, t), o(e, n - 1 - t);
	if (i.length < 200) return null;
	let s = (e) => [...e].sort((e, t) => e - t)[Math.floor(e.length / 2)];
	return {
		r: s(i),
		g: s(a)
	};
}
function T(e, t, n) {
	let r = new Uint8Array(t * n), i = [], a = (t) => {
		!r[t] && e[t] < 255 && (r[t] = 1, i.push(t));
	};
	for (let e = 0; e < t; e++) a(e), a((n - 1) * t + e);
	for (let e = 0; e < n; e++) a(e * t), a(e * t + t - 1);
	for (; i.length;) {
		let e = i.pop(), r = e % t, o = (e - r) / t;
		r > 0 && a(e - 1), r < t - 1 && a(e + 1), o > 0 && a(e - t), o < n - 1 && a(e + t);
	}
	for (let t = 0; t < e.length; t++) r[t] || (e[t] = 255);
}
function ee(e, t, n, r = Math.max(4, Math.round(Math.min(t, n) * .012))) {
	let i = new Int32Array(t * n).fill(-1), a = [], o = [];
	for (let n = 0; n < e.length; n++) {
		if (e[n] < 230 || i[n] !== -1) continue;
		let r = 0;
		for (i[n] = a.length, o.push(n); o.length;) {
			let n = o.pop();
			r++;
			let s = n % t;
			for (let r of [
				s > 0 ? n - 1 : -1,
				s < t - 1 ? n + 1 : -1,
				n - t,
				n + t
			]) r < 0 || r >= e.length || e[r] < 230 || i[r] !== -1 || (i[r] = a.length, o.push(r));
		}
		a.push(r);
	}
	if (!a.length) return 0;
	let s = Math.max(...a), c = new Float32Array(t * n);
	for (let e = 0; e < c.length; e++) c[e] = i[e] >= 0 && a[i[e]] >= .05 * s ? 0 : 1e9;
	for (let e = 0; e < n; e++) for (let n = 0; n < t; n++) {
		let r = e * t + n, i = c[r];
		n > 0 && (i = Math.min(i, c[r - 1] + 1)), e > 0 && (i = Math.min(i, c[r - t] + 1), n > 0 && (i = Math.min(i, c[r - t - 1] + 1.4)), n < t - 1 && (i = Math.min(i, c[r - t + 1] + 1.4))), c[r] = i;
	}
	let l = 0;
	for (let i = n - 1; i >= 0; i--) for (let a = t - 1; a >= 0; a--) {
		let o = i * t + a, s = c[o];
		a < t - 1 && (s = Math.min(s, c[o + 1] + 1)), i < n - 1 && (s = Math.min(s, c[o + t] + 1), a < t - 1 && (s = Math.min(s, c[o + t + 1] + 1.4)), a > 0 && (s = Math.min(s, c[o + t - 1] + 1.4))), c[o] = s, e[o] > 0 && e[o] < 230 && s > r && (e[o] = 0, l++);
	}
	return l;
}
function te(e, t, n) {
	let r = t, i = n, a = new Uint8Array(r * i), o = w(e, r, i);
	for (let t = 0; t < r * i; t++) {
		let n = e[t * 4], r = e[t * 4 + 1], i = e[t * 4 + 2], s = r - Math.max(n, i), c = s / Math.max(r, 1), l = s <= 6 ? 1 : c >= .42 ? 0 : c <= .16 ? 1 : 1 - (c - .16) / .26;
		if (o && s > 6) {
			let e = n + r + i || 1, t = Math.hypot(n / e - o.r, r / e - o.g);
			l = Math.min(l, t <= .07 ? 0 : t >= .14 ? 1 : (t - .07) / .07);
		}
		let u = Math.min(1, Math.max(0, (s - 14) / 10));
		a[t] = Math.round((1 - u * (1 - l)) * 255);
	}
	T(a, r, i);
	let s = new Uint8Array(a.length);
	for (let e = 0; e < i; e++) for (let t = 0; t < r; t++) {
		let n = 255;
		for (let o = -1; o <= 1; o++) for (let s = -1; s <= 1; s++) n = Math.min(n, a[Math.min(i - 1, Math.max(0, e + o)) * r + Math.min(r - 1, Math.max(0, t + s))]);
		s[e * r + t] = n;
	}
	return ee(s, r, i), s;
}
function ne(e, t, n, r) {
	let i = oe(e, t, n);
	if (!i) return;
	let a = i.y * n, o = (i.y + i.height) * n, s = Math.max(1, (o - a) * r);
	for (let r = Math.max(0, Math.floor(o - s)); r < Math.min(n, Math.ceil(o)); r++) {
		let n = Math.max(0, Math.min(1, (o - r) / s)), i = n * n * (3 - 2 * n);
		for (let n = 0; n < t; n++) e[r * t + n] = Math.round(e[r * t + n] * i);
	}
}
function E(e, t, n, r) {
	for (let i = 0; i < r.length; i += 4) {
		let a = Math.max(0, Math.floor(r[i] * t)), o = Math.max(0, Math.floor(r[i + 1] * n)), s = Math.min(t, Math.ceil((r[i] + r[i + 2]) * t)), c = Math.min(n, Math.ceil((r[i + 1] + r[i + 3]) * n));
		for (let n = o; n < c; n++) for (let r = a; r < s; r++) e[n * t + r] = 0;
	}
}
function re(e, t) {
	return e.filter((e) => e.kind === "model" && !t?.has(e.ref));
}
function ie(e, t, n, r) {
	if (r) for (let i = 0; i < n; i++) {
		let a = Math.min(r.height - 1, Math.max(0, (i + .5) / n * r.height - .5)), o = Math.floor(a), s = Math.min(r.height - 1, o + 1), c = a - o;
		for (let n = 0; n < t; n++) {
			let a = Math.min(r.width - 1, Math.max(0, (n + .5) / t * r.width - .5)), l = Math.floor(a), u = Math.min(r.width - 1, l + 1), d = a - l, f = r.alpha[o * r.width + l] * (1 - d) + r.alpha[o * r.width + u] * d, p = r.alpha[s * r.width + l] * (1 - d) + r.alpha[s * r.width + u] * d, m = f * (1 - c) + p * c, h = i * t + n;
			e[h] = Math.min(e[h], Math.round(m));
		}
	}
}
function ae(e, t, n, r) {
	let i = te(e, n, r);
	for (let e = 0; e < t.length; e++) t[e] = Math.min(t[e], i[e]);
}
function oe(e, t, n, r = 24) {
	let i = t, a = n, o = -1, s = -1;
	for (let c = 0; c < n; c++) for (let n = 0; n < t; n++) e[c * t + n] > r && (n < i && (i = n), n > o && (o = n), c < a && (a = c), c > s && (s = c));
	return o < 0 ? null : {
		x: i / t,
		y: a / n,
		width: (o + 1 - i) / t,
		height: (s + 1 - a) / n
	};
}
function se(e, t, n, r, i) {
	let a = Math.min(n - 1, Math.floor(i.x * n)), o = Math.min(r - 1, Math.floor(i.y * r)), s = (o * n + a) * 4, c = e[s], l = e[s + 1], u = e[s + 2], d = (i.tolerance / 100 * 160) ** 2, f = i.mode === "remove" ? 0 : 255, p = new Uint8Array(n * r), m = [o * n + a];
	for (p[m[0]] = 1; m.length;) {
		let i = m.pop(), a = i * 4, o = e[a] - c, s = e[a + 1] - l, h = e[a + 2] - u;
		if (o * o + s * s + h * h > d) continue;
		t[i] = f;
		let g = i % n;
		g > 0 && !p[i - 1] && (p[i - 1] = 1, m.push(i - 1)), g < n - 1 && !p[i + 1] && (p[i + 1] = 1, m.push(i + 1)), i >= n && !p[i - n] && (p[i - n] = 1, m.push(i - n)), i < n * (r - 1) && !p[i + n] && (p[i + n] = 1, m.push(i + n));
	}
}
function D(e, t, n, r) {
	let i = Math.max(1, r.radius * Math.max(t, n)), a = r.mode === "remove" ? 0 : 255, o = (r, o) => {
		let s = Math.max(0, Math.floor(r - i)), c = Math.min(t - 1, Math.ceil(r + i)), l = Math.max(0, Math.floor(o - i)), u = Math.min(n - 1, Math.ceil(o + i)), d = i * i;
		for (let n = l; n <= u; n++) for (let i = s; i <= c; i++) (i - r) ** 2 + (n - o) ** 2 <= d && (e[n * t + i] = a);
	}, s = r.points, c = s[0] * t, l = s[1] * n;
	o(c, l);
	for (let e = 2; e < s.length; e += 2) {
		let r = s[e] * t, a = s[e + 1] * n, u = Math.max(1, Math.ceil(Math.hypot(r - c, a - l) / (i / 3)));
		for (let e = 1; e <= u; e++) o(c + (r - c) * e / u, l + (a - l) * e / u);
		c = r, l = a;
	}
}
function ce(e, t, n) {
	let r = new Uint8Array(e.length);
	for (let i = 0; i < n; i++) for (let a = 0; a < t; a++) {
		let o = 0, s = 0;
		for (let r = -1; r <= 1; r++) {
			let c = i + r;
			if (!(c < 0 || c >= n)) for (let n = -1; n <= 1; n++) {
				let r = a + n;
				r < 0 || r >= t || (o += e[c * t + r], s++);
			}
		}
		r[i * t + a] = Math.round(o / s);
	}
	return r;
}
function le(e, t = .12, n = 127) {
	let { alpha: r, width: i, height: a } = e, o = new Int32Array(i * a).fill(-1), s = [], c = [];
	for (let e = 0; e < r.length; e++) {
		if (r[e] <= n || o[e] !== -1) continue;
		let t = s.length, a = 0;
		for (o[e] = t, c.push(e); c.length;) {
			let e = c.pop();
			a++;
			let s = e % i;
			for (let a of [
				s > 0 ? e - 1 : -1,
				s < i - 1 ? e + 1 : -1,
				e - i,
				e + i
			]) a < 0 || a >= r.length || r[a] <= n || o[a] !== -1 || (o[a] = t, c.push(a));
		}
		s.push(a);
	}
	let l = Math.max(0, ...s);
	for (let e = 0; e < r.length; e++) {
		let i = o[e];
		(i === -1 ? r[e] > 0 && r[e] <= n : s[i] < l * t) && (r[e] = 0);
	}
	return e;
}
var ue = 24, de = /^[a-z0-9][a-z0-9-]{0,59}$/, O = /^[a-z][A-Za-z0-9]{0,39}$/;
function fe(e) {
	if (!e || typeof e != "object") return;
	let { id: t, params: n } = e;
	if (typeof t != "string" || !de.test(t)) return;
	let r = {};
	if (n !== void 0) {
		if (!n || typeof n != "object" || Array.isArray(n)) return;
		let e = Object.entries(n);
		if (e.length > ue) return;
		for (let [t, n] of e) {
			if (!O.test(t) || (typeof n == "number" ? !Number.isFinite(n) : typeof n == "string" ? n.length > 40 : typeof n != "boolean")) return;
			r[t] = n;
		}
	}
	return {
		id: t,
		params: r
	};
}
function pe(e) {
	if (!Array.isArray(e) || e.length > 12) return;
	let t = e.map(fe);
	return t.every((e) => e !== void 0) ? t : void 0;
}
function me(e) {
	return Array.isArray(e) ? e.slice(0, 12).map(fe).filter((e) => e !== void 0) : [];
}
function he(e, t, n, r) {
	return e.map((e, i) => i === t ? {
		...e,
		params: {
			...e.params,
			[n]: r
		}
	} : e);
}
function ge(e, t, n) {
	let r = t + n;
	if (r < 0 || r >= e.length) return [...e];
	let i = [...e];
	return [i[t], i[r]] = [i[r], i[t]], i;
}
//#endregion
//#region ../core/src/ops.ts
var _e = [
	"free",
	"original",
	"1:1",
	"4:5",
	"3:4",
	"2:3",
	"16:9"
], k = (e) => ({
	kind: "number",
	label: e,
	min: -100,
	max: 100,
	step: 1,
	default: 0
}), ve = (e, t) => ({
	kind: "number",
	label: e,
	min: 0,
	max: 1,
	step: .001,
	default: t,
	hidden: !0
}), ye = [
	{
		type: "orient",
		label: "Orientation",
		group: "geometry",
		params: {
			quarterTurns: {
				kind: "number",
				label: "Quarter turns clockwise",
				min: 0,
				max: 3,
				step: 1,
				default: 0,
				hidden: !0
			},
			flipH: {
				kind: "boolean",
				label: "Flip horizontally",
				default: !1,
				hidden: !0
			},
			flipV: {
				kind: "boolean",
				label: "Flip vertically",
				default: !1,
				hidden: !0
			}
		}
	},
	{
		type: "straighten",
		label: "Straighten",
		group: "geometry",
		params: { angle: {
			kind: "number",
			label: "Straighten",
			min: -45,
			max: 45,
			step: .1,
			default: 0,
			unit: "°"
		} }
	},
	{
		type: "crop",
		label: "Crop",
		group: "geometry",
		params: {
			aspect: {
				kind: "choice",
				label: "Aspect ratio",
				options: _e,
				default: "free",
				hidden: !0
			},
			x: ve("Left", 0),
			y: ve("Top", 0),
			width: ve("Width", 1),
			height: ve("Height", 1)
		}
	},
	{
		type: "canvas",
		label: "Canvas",
		group: "geometry",
		params: {
			square: {
				kind: "boolean",
				label: "Square canvas",
				default: !1,
				hidden: !0
			},
			margin: {
				kind: "number",
				label: "Space around",
				min: 0,
				max: 40,
				step: .5,
				default: 0,
				unit: "%",
				hidden: !0
			}
		}
	},
	{
		type: "light",
		label: "Light",
		group: "light",
		params: {
			exposure: {
				kind: "number",
				label: "Exposure",
				min: -3,
				max: 3,
				step: .01,
				default: 0,
				unit: " EV"
			},
			contrast: k("Contrast"),
			highlights: k("Highlights"),
			shadows: k("Shadows")
		}
	},
	{
		type: "color",
		label: "Color",
		group: "color",
		params: {
			temperature: k("Temperature"),
			tint: k("Tint"),
			vibrance: k("Vibrance"),
			saturation: k("Saturation")
		}
	},
	{
		type: "backdrop",
		label: "Backdrop",
		group: "background",
		params: {
			mode: {
				kind: "choice",
				label: "Behind the product",
				options: [
					"transparent",
					"color",
					"image"
				],
				default: "transparent",
				hidden: !0
			},
			color: {
				kind: "color",
				label: "Colour",
				default: "#ffffff",
				hidden: !0
			}
		}
	},
	{
		type: "effects",
		label: "Effects",
		group: "effects",
		params: { vignette: k("Vignette") }
	}
], be = new Map(ye.map((e) => [e.type, e]));
function A(e, t) {
	let n = be.get(e)?.params;
	return n && Object.hasOwn(n, t) ? n[t] : void 0;
}
function j(e, t) {
	switch (e.kind) {
		case "number": {
			if (typeof t != "number" || !Number.isFinite(t)) return;
			let n = Math.min(e.max, Math.max(e.min, t));
			return Number.isInteger(e.step) && e.step >= 1 ? Math.round(n) : n;
		}
		case "boolean": return typeof t == "boolean" ? t : void 0;
		case "choice": return typeof t == "string" && e.options.includes(t) ? t : void 0;
		case "color": return typeof t == "string" && /^#[0-9a-f]{6}$/i.test(t) ? t.toLowerCase() : void 0;
	}
}
function xe(e) {
	if (!e || typeof e != "object") return null;
	let t = e;
	return typeof t.model != "string" || !/^[a-z0-9][a-z0-9-]{0,59}$/.test(t.model) || typeof t.ref != "string" || !/^[a-z0-9]{6,32}$/.test(t.ref) ? null : {
		model: t.model,
		ref: t.ref
	};
}
function Se(e) {
	if (!e || typeof e != "object") return null;
	let t = e;
	if (typeof t.model != "string" || !/^[a-z0-9][a-z0-9-]{0,59}$/.test(t.model) || typeof t.ref != "string" || !/^[a-z0-9]{6,32}$/.test(t.ref)) return null;
	let n = typeof t.factor == "number" && Number.isFinite(t.factor) ? Math.min(4, Math.max(1, Math.round(t.factor))) : 2;
	return {
		model: t.model,
		ref: t.ref,
		factor: n
	};
}
var Ce = {
	lightness: [150, 255],
	maxWidth: [4, 80],
	minLength: [5, 200]
}, we = {
	lightness: 225,
	maxWidth: 30,
	minLength: 35
};
function Te(e) {
	if (!e || typeof e != "object") return null;
	let t = e, n = {};
	for (let [e, [r, i]] of Object.entries(Ce)) {
		let a = t[e];
		if (typeof a != "number" || !Number.isFinite(a)) return null;
		n[e] = Math.min(i, Math.max(r, Math.round(a)));
	}
	let r = n;
	t.lettering === !1 && (r.lettering = !1);
	let i = t.stickers;
	Array.isArray(i) && i.length > 0 && i.length % 4 == 0 && i.length <= 32 && i.every((e) => typeof e == "number" && Number.isFinite(e) && e >= 0 && e <= 1) && (r.stickers = i);
	let a = t.ai;
	return a && typeof a.model == "string" && /^[a-z0-9][a-z0-9-]{0,59}$/.test(a.model) && typeof a.ref == "string" && /^[a-z0-9]{6,32}$/.test(a.ref) && (r.ai = {
		model: a.model,
		ref: a.ref
	}), r;
}
function M(e) {
	return Object.fromEntries(Object.entries(e.params).map(([e, t]) => [e, t.default]));
}
function Ee() {
	return {
		version: 1,
		ops: Object.fromEntries(ye.map((e) => [e.type, M(e)])),
		mask: [],
		effects: [],
		words: null,
		upscale: null,
		finish: null
	};
}
function De(e) {
	let t = Ee();
	t.mask = y(e?.mask), t.effects = me(e?.effects), t.words = Te(e?.words), t.upscale = Se(e?.upscale), t.finish = xe(e?.finish);
	let n = e?.ops;
	if (!n || typeof n != "object") return t;
	for (let e of ye) {
		let r = n[e.type];
		if (r && typeof r == "object") for (let [n, i] of Object.entries(e.params)) {
			let a = j(i, r[n]);
			a !== void 0 && (t.ops[e.type][n] = a);
		}
	}
	return t;
}
function N(e, t, n) {
	let r = e.ops[t]?.[n];
	return typeof r == "number" ? r : 0;
}
function P(e, t, n) {
	return e.ops[t]?.[n] === !0;
}
function F(e, t, n) {
	let r = e.ops[t]?.[n];
	return typeof r == "string" ? r : "";
}
//#endregion
//#region ../core/src/document.ts
function Oe(e, t = Ee()) {
	if (!(e.width > 0 && e.height > 0)) throw Error("A photo needs a positive width and height.");
	return {
		schema: "gleamshelf/photo",
		version: 1,
		source: { ...e },
		recipe: t
	};
}
function ke(e, t) {
	return Oe(e, De(t));
}
//#endregion
//#region ../core/src/geometry.ts
var Ae = {
	a: 1,
	b: 0,
	c: 0,
	d: 1,
	e: 0,
	f: 0
}, I = (e) => ({
	...Ae,
	...e
});
function je(e, t) {
	return {
		a: e.a * t.a + e.c * t.b,
		b: e.b * t.a + e.d * t.b,
		c: e.a * t.c + e.c * t.d,
		d: e.b * t.c + e.d * t.d,
		e: e.a * t.e + e.c * t.f + e.e,
		f: e.b * t.e + e.d * t.f + e.f
	};
}
function L(e, t, n) {
	return [e.a * t + e.c * n + e.e, e.b * t + e.d * n + e.f];
}
function R(e) {
	let { width: t, height: n } = e.source;
	return N(e.recipe, "orient", "quarterTurns") % 2 == 1 ? {
		width: n,
		height: t
	} : {
		width: t,
		height: n
	};
}
function Me(e, t, n) {
	let r = Math.abs(n) * Math.PI / 180, i = Math.cos(r), a = Math.sin(r);
	return Math.max((e * i + t * a) / e, (e * a + t * i) / t);
}
function z(e) {
	let t = e.recipe;
	return {
		x: N(t, "crop", "x"),
		y: N(t, "crop", "y"),
		width: N(t, "crop", "width"),
		height: N(t, "crop", "height")
	};
}
function Ne(e) {
	let t = R(e), n = z(e), r = e.recipe.upscale?.factor ?? 1, i = Math.max(1, n.width * t.width * r), a = Math.max(1, n.height * t.height * r), o = 1 + 2 * (N(e.recipe, "canvas", "margin") / 100);
	if (P(e.recipe, "canvas", "square")) {
		let e = Math.max(i, a) * o;
		return {
			crop: {
				width: i,
				height: a
			},
			canvas: {
				width: e,
				height: e
			}
		};
	}
	return {
		crop: {
			width: i,
			height: a
		},
		canvas: {
			width: i * o,
			height: a * o
		}
	};
}
function Pe(e, t) {
	let { width: n, height: r } = Ne(e).canvas;
	if (t && Math.max(n, r) > t) {
		let e = t / Math.max(n, r);
		n *= e, r *= e;
	}
	return {
		width: Math.max(1, Math.round(n)),
		height: Math.max(1, Math.round(r))
	};
}
function Fe(e) {
	let t = e.recipe, { width: n, height: r } = R(e), i = z(e), a = N(t, "straighten", "angle"), o = Me(n, r, a), s = a * Math.PI / 180, c = Math.cos(s) / o, l = Math.sin(s) / o, { crop: u, canvas: d } = Ne(e), f = d.width / u.width, p = d.height / u.height, m = [
		I({
			a: f,
			d: p,
			e: .5 - .5 * f,
			f: .5 - .5 * p
		}),
		I({
			a: i.width,
			d: i.height,
			e: i.x,
			f: i.y
		}),
		I({
			a: n,
			d: r,
			e: -n / 2,
			f: -r / 2
		}),
		I({
			a: c,
			b: -l,
			c: l,
			d: c
		}),
		I({
			a: 1 / n,
			d: 1 / r,
			e: .5,
			f: .5
		})
	];
	P(t, "orient", "flipH") && m.push(I({
		a: -1,
		e: 1
	})), P(t, "orient", "flipV") && m.push(I({
		d: -1,
		f: 1
	}));
	for (let e = 0; e < N(t, "orient", "quarterTurns"); e++) m.push(I({
		a: 0,
		b: -1,
		c: 1,
		d: 0,
		f: 1
	}));
	return m.reduce((e, t) => je(t, e), Ae);
}
function Ie(e, t) {
	if (e === "original") return t.width / t.height;
	let n = /^(\d+):(\d+)$/.exec(e);
	return n ? Number(n[1]) / Number(n[2]) : null;
}
function Le(e) {
	return Ie(F(e.recipe, "crop", "aspect"), R(e));
}
function Re(e) {
	let t = {
		...e.recipe.ops.crop,
		x: 0,
		y: 0,
		width: 1,
		height: 1
	}, n = {
		...e.recipe.ops.canvas,
		square: !1,
		margin: 0
	};
	return {
		...e,
		recipe: {
			...e.recipe,
			ops: {
				...e.recipe.ops,
				crop: t,
				canvas: n
			}
		}
	};
}
function ze(e) {
	let t = e.a * e.d - e.b * e.c;
	return Math.abs(t) < 1e-12 ? null : {
		a: e.d / t,
		b: -e.b / t,
		c: -e.c / t,
		d: e.a / t,
		e: (e.c * e.f - e.d * e.e) / t,
		f: (e.b * e.e - e.a * e.f) / t
	};
}
function Be(e, t) {
	let n = ze(Fe(Re(e)));
	if (!n) return {
		x: 0,
		y: 0,
		width: 1,
		height: 1
	};
	let r = [
		[t.x, t.y],
		[t.x + t.width, t.y],
		[t.x, t.y + t.height],
		[t.x + t.width, t.y + t.height]
	].map(([e, t]) => L(n, e, t)), i = r.map((e) => e[0]), a = r.map((e) => e[1]), o = Math.max(0, Math.min(...i)), s = Math.max(0, Math.min(...a)), c = Math.min(1, Math.max(...i)), l = Math.min(1, Math.max(...a));
	return {
		x: o,
		y: s,
		width: Math.max(.001, c - o),
		height: Math.max(.001, l - s)
	};
}
function Ve(e, t) {
	let n = e.width / e.height, r = t < n ? t / n : 1, i = t < n ? 1 : n / t;
	return {
		x: (1 - r) / 2,
		y: (1 - i) / 2,
		width: r,
		height: i
	};
}
var B = .02, V = (e, t, n) => Math.min(n, Math.max(t, e));
function He(e, t, n, r, i, a) {
	if (t === "move") return {
		...e,
		x: V(e.x + n, 0, 1 - e.width),
		y: V(e.y + r, 0, 1 - e.height)
	};
	let o = t.includes("w"), s = t.includes("e"), c = t.includes("n"), l = t.includes("s"), u = e.x, d = e.y, f = e.x + e.width, p = e.y + e.height;
	if (a === null) return o && (u = V(u + n, 0, f - B)), s && (f = V(f + n, u + B, 1)), c && (d = V(d + r, 0, p - B)), l && (p = V(p + r, d + B, 1)), {
		x: u,
		y: d,
		width: f - u,
		height: p - d
	};
	let m = a * i.height / i.width, h = o || s, g = c || l, _ = o ? f : s ? u : (u + f) / 2, v = c ? p : l ? d : (d + p) / 2, y = o ? _ : s ? 1 - _ : 2 * Math.min(_, 1 - _), b = c ? v : l ? 1 - v : 2 * Math.min(v, 1 - v), x = e.width + (o ? -n : s ? n : 0), S = e.height + (c ? -r : l ? r : 0), C = h && g ? Math.max(x, S * m) : h ? x : S * m, w = Math.max(B, B * m);
	C = V(C, w, Math.min(y, b * m));
	let T = C / m;
	return {
		x: o ? _ - C : s ? _ : _ - C / 2,
		y: c ? v - T : l ? v : v - T / 2,
		width: C,
		height: T
	};
}
function H(e, t) {
	return t === 1 ? {
		x: 1 - e.y - e.height,
		y: e.x,
		width: e.height,
		height: e.width
	} : {
		x: e.y,
		y: 1 - e.x - e.width,
		width: e.height,
		height: e.width
	};
}
//#endregion
//#region ../core/src/looks.ts
var U = [
	{
		id: "bright-sharp",
		label: "Bright & sharp",
		description: "A little brighter, richer colour and clearly sharper detail. What AI results get automatically.",
		ops: {
			light: {
				exposure: .3,
				contrast: 12,
				highlights: -4,
				shadows: 20
			},
			color: {
				vibrance: 35,
				saturation: 8
			}
		},
		effects: [{
			id: "sharpen",
			params: {
				amount: .9,
				radius: 1.2
			}
		}]
	},
	{
		id: "vivid",
		label: "Vivid",
		description: "Richer colour and a little more punch, with crisper detail. Good for printed box art.",
		ops: {
			light: {
				exposure: .1,
				contrast: 14,
				shadows: 12
			},
			color: {
				vibrance: 45,
				saturation: 10
			}
		},
		effects: [{
			id: "sharpen",
			params: {
				amount: .5,
				radius: 1.2
			}
		}]
	},
	{
		id: "extra-vivid",
		label: "Extra vivid",
		description: "A stronger version of Vivid for dull or faded photos.",
		ops: {
			light: {
				exposure: .15,
				contrast: 24,
				highlights: -8,
				shadows: 20
			},
			color: {
				vibrance: 70,
				saturation: 18
			}
		},
		effects: [{
			id: "sharpen",
			params: {
				amount: .8,
				radius: 1.2
			}
		}]
	}
], Ue = (e) => U.find((t) => t.id === e);
//#endregion
//#region ../core/src/path.ts
function We(e) {
	return e.split("/").filter(Boolean);
}
function Ge(e, t) {
	let n = e;
	for (let e of We(t)) {
		if (typeof n != "object" || !n) return;
		n = n[e];
	}
	return n;
}
function Ke(e, t, n) {
	let r = We(t), i = (e, t) => {
		if (t === r.length) return n;
		let a = r[t], o = typeof e == "object" && e ? e : {}, s = Array.isArray(o) ? [...o] : { ...o };
		return s[a] = i(o[a], t + 1), s;
	};
	return i(e, 0);
}
//#endregion
//#region ../core/src/history.ts
var qe = class {
	limit;
	past = [];
	future = [];
	constructor(e = 200) {
		this.limit = e;
	}
	push(e) {
		this.past.push(e), this.past.length > this.limit && this.past.shift(), this.future = [];
	}
	undo() {
		let e = this.past.pop();
		return e && this.future.push(e), e;
	}
	redo() {
		let e = this.future.pop();
		return e && this.past.push(e), e;
	}
	clear() {
		this.past = [], this.future = [];
	}
	get canUndo() {
		return this.past.length > 0;
	}
	get canRedo() {
		return this.future.length > 0;
	}
	get undoLabel() {
		return this.past.at(-1)?.label;
	}
	get redoLabel() {
		return this.future.at(-1)?.label;
	}
}, Je = class {
	validate;
	doc;
	history = new qe();
	gesture = null;
	snapshot;
	listeners = /* @__PURE__ */ new Set();
	constructor(e, t) {
		this.validate = t, this.doc = e, this.snapshot = this.makeSnapshot();
	}
	getSnapshot = () => this.snapshot;
	subscribe = (e) => (this.listeners.add(e), () => this.listeners.delete(e));
	get document() {
		return this.doc;
	}
	set(e, t, n) {
		let r = this.validate(e, t);
		return typeof r == "string" ? r : Ge(this.doc, e) === r.value ? "unchanged" : (this.apply(n ?? r.label, [[e, r.value]]), "ok");
	}
	begin(e) {
		this.commit(), this.gesture = {
			label: e,
			start: this.doc,
			changes: /* @__PURE__ */ new Map()
		};
	}
	commit() {
		let e = this.gesture;
		if (!e) return;
		this.gesture = null;
		let t = [...e.changes.values()].filter((e) => e.before !== e.after);
		t.length && this.history.push({
			label: e.label,
			changes: t
		}), this.emit();
	}
	cancel() {
		this.gesture && (this.doc = this.gesture.start, this.gesture = null, this.emit());
	}
	undo() {
		this.commit();
		let e = this.history.undo();
		return e ? (this.doc = [...e.changes].reverse().reduce((e, t) => Ke(e, t.path, t.before), this.doc), this.emit(), !0) : !1;
	}
	redo() {
		this.commit();
		let e = this.history.redo();
		return e ? (this.doc = e.changes.reduce((e, t) => Ke(e, t.path, t.after), this.doc), this.emit(), !0) : !1;
	}
	load(e) {
		this.gesture = null, this.history.clear(), this.doc = e, this.emit();
	}
	apply(e, t) {
		let n = [], r = this.doc;
		for (let [e, i] of t) {
			let t = this.validate(e, i);
			if (typeof t == "string") throw Error(`Invalid edit (${t}): ${e} = ${String(i)}`);
			let a = Ge(r, e);
			a !== t.value && (r = Ke(r, e, t.value), n.push({
				path: e,
				before: a,
				after: t.value
			}));
		}
		if (n.length) {
			if (this.doc = r, this.gesture) for (let e of n) {
				let t = this.gesture.changes.get(e.path);
				this.gesture.changes.set(e.path, {
					...e,
					before: t ? t.before : e.before
				});
			}
			else this.history.push({
				label: e,
				changes: n
			});
			this.emit();
		}
	}
	makeSnapshot() {
		return {
			doc: this.doc,
			canUndo: this.history.canUndo || !!this.gesture?.changes.size,
			canRedo: this.history.canRedo,
			undoLabel: this.history.undoLabel,
			redoLabel: this.history.redoLabel
		};
	}
	emit() {
		this.snapshot = this.makeSnapshot();
		for (let e of this.listeners) e();
	}
};
function Ye(e) {
	return (t, n) => {
		let r = e(t);
		if (!r) return "invalid-path";
		let i = j(r, n);
		return i === void 0 ? "invalid-value" : {
			value: i,
			label: r.label
		};
	};
}
//#endregion
//#region ../core/src/editor.ts
var W = (e, t) => `recipe/ops/${e}/${t}`;
function Xe(e) {
	let [t, n, r, i, ...a] = We(e);
	if (t === "recipe" && n === "ops" && r && i && !a.length) return A(r, i);
}
var G = "recipe/mask", K = "recipe/effects", Ze = "recipe/words", Qe = "recipe/upscale", $e = "recipe/finish", et = Ye(Xe), tt = (e, t) => {
	let n = We(e).join("/");
	if (n === $e) {
		if (t === null) return {
			value: null,
			label: "Finishing touches"
		};
		let e = xe(t);
		return e ? {
			value: e,
			label: "Finishing touches"
		} : "invalid-value";
	}
	if (n === Qe) {
		if (t === null) return {
			value: null,
			label: "Enlarge"
		};
		let e = Se(t);
		return e ? {
			value: e,
			label: "Enlarge"
		} : "invalid-value";
	}
	if (n === Ze) {
		if (t === null) return {
			value: null,
			label: "Lettering"
		};
		let e = Te(t);
		return e ? {
			value: e,
			label: "Lettering"
		} : "invalid-value";
	}
	if (n === K) {
		let e = pe(t);
		return e ? {
			value: e,
			label: "Effects"
		} : "invalid-value";
	}
	if (n !== G) return et(e, t);
	let r = v(t);
	return r ? {
		value: r,
		label: "Cut-out"
	} : "invalid-value";
}, nt = class extends Je {
	constructor(e) {
		super(e, tt);
	}
	apply(e, t) {
		let n = this.doc.recipe.finish && !t.some(([e]) => e === $e);
		super.apply(e, n ? [...t, [$e, null]] : t);
	}
	get finish() {
		return this.doc.recipe.finish;
	}
	setFinish(e, t) {
		this.apply("Finishing touches (AI)", [[$e, {
			model: e,
			ref: t
		}]]);
	}
	clearFinish() {
		this.finish && this.apply("Remove finishing touches", [[$e, null]]);
	}
	get mask() {
		return this.doc.recipe.mask;
	}
	get words() {
		return this.doc.recipe.words;
	}
	setWords(e, t = {}) {
		let n = { ...we };
		t.lettering === !1 && (n.lettering = !1), t.stickers?.length && (n.stickers = t.stickers), this.apply(e ? t.lettering === !1 ? "Remove price stickers" : "Remove lettering" : "Put lettering back", [[Ze, e ? n : null], ...this.dropUpscale()]);
	}
	setWordsAi(e, t) {
		this.words && this.apply("Fill lettering with AI", [[Ze, {
			...this.words,
			ai: {
				model: e,
				ref: t
			}
		}], ...this.dropUpscale()]);
	}
	setWordsParam(e, t, n = "Lettering") {
		this.words && this.apply(n, [[Ze, {
			...this.words,
			ai: void 0,
			[e]: t
		}], ...this.dropUpscale()]);
	}
	dropUpscale() {
		return this.doc.recipe.upscale ? [[Qe, null]] : [];
	}
	get upscale() {
		return this.doc.recipe.upscale;
	}
	setUpscale(e, t, n = 2) {
		this.apply("Enlarge with AI", [[Qe, {
			model: e,
			ref: t,
			factor: n
		}]]);
	}
	clearUpscale() {
		this.upscale && this.apply("Remove AI enlarging", [[Qe, null]]);
	}
	get effects() {
		return this.doc.recipe.effects;
	}
	addEffect(e, t, n = "Add effect") {
		this.apply(n, [[K, [...this.effects, {
			id: e,
			params: t
		}]]]);
	}
	removeEffect(e, t = "Remove effect") {
		this.apply(t, [[K, this.effects.filter((t, n) => n !== e)]]);
	}
	moveEffect(e, t) {
		this.apply("Reorder effects", [[K, ge(this.effects, e, t)]]);
	}
	setEffectParam(e, t, n, r = "Adjust effect") {
		this.effects[e] && this.apply(r, [[K, he(this.effects, e, t, n)]]);
	}
	applyLook(e) {
		let t = Ue(e);
		if (!t) return;
		let n = [];
		for (let [e, r] of Object.entries(t.ops)) for (let [t, i] of Object.entries(r)) n.push([W(e, t), i]);
		let r = new Set(t.effects.map((e) => e.id));
		n.push([K, [...this.effects.filter((e) => !r.has(e.id)), ...t.effects]]), this.apply(t.label, n);
	}
	clearLook() {
		let e = [];
		for (let t of ["light", "color"]) for (let [n, r] of Object.entries(Ee().ops[t] ?? {})) e.push([W(t, n), r]);
		let t = new Set(U.flatMap((e) => e.effects.map((e) => e.id)));
		e.push([K, this.effects.filter((e) => !t.has(e.id))]), this.apply("Natural", e);
	}
	fadeBottom(e = .1) {
		this.apply("Fade the bottom edge", [[G, [...this.mask.filter((e) => e.kind !== "fade"), {
			kind: "fade",
			mode: "remove",
			edge: "bottom",
			size: e
		}]]]);
	}
	eraseBoxes(e) {
		let t = (e) => Math.min(1, Math.max(0, e)), n = e.slice(0, 100).flatMap((e) => [
			t(e.x),
			t(e.y),
			t(e.width),
			t(e.height)
		]);
		n.length && this.apply("Cut away text", [[G, [...this.mask, {
			kind: "erase",
			mode: "remove",
			boxes: n
		}]]]);
	}
	addModelCutout(e, t, n = {}) {
		let r = n.replace ? this.mask.filter((e) => e.kind !== "model") : this.mask;
		this.apply("AI cut-out", [[G, [...r, {
			kind: "model",
			mode: "remove",
			model: e,
			ref: t
		}]]]);
	}
	removeGreenBackdrop() {
		this.mask.some((e) => e.kind === "green") || this.apply("Remove green backdrop", [[G, [...this.mask, {
			kind: "green",
			mode: "remove"
		}]]]);
	}
	fitSquareToProduct(e, t = .06) {
		let n = Be(this.doc, e);
		this.apply("Fit square to product", [
			[W("crop", "aspect"), "free"],
			...this.cropValues(n),
			[W("canvas", "square"), !0],
			[W("canvas", "margin"), Math.round(Math.min(40, Math.max(0, t * 100)) * 2) / 2]
		]);
	}
	addMaskOp(e) {
		this.apply(e.kind === "fill" ? e.mode === "remove" ? "Remove background" : "Restore area" : e.mode === "remove" ? "Erase" : "Restore", [[G, [...this.mask, e]]]);
	}
	updateLastMaskOp(e) {
		if (!this.mask.length) return this.addMaskOp(e);
		this.apply("Brush", [[G, [...this.mask.slice(0, -1), e]]]);
	}
	clearMask() {
		this.mask.length && this.apply("Clear cut-out", [[G, []]]);
	}
	rotate(e) {
		let t = this.doc.recipe, n = (N(t, "orient", "quarterTurns") + e + 4) % 4, r = F(t, "crop", "aspect");
		this.apply(e === 1 ? "Rotate right" : "Rotate left", [
			[W("orient", "quarterTurns"), n],
			[W("orient", "flipH"), P(t, "orient", "flipV")],
			[W("orient", "flipV"), P(t, "orient", "flipH")],
			...this.cropValues(H(z(this.doc), e)),
			[W("crop", "aspect"), r === "original" || r === "1:1" ? r : "free"]
		]);
	}
	flip(e) {
		let t = z(this.doc), n = e === "horizontal", r = n ? "flipH" : "flipV";
		this.apply(n ? "Flip horizontally" : "Flip vertically", [[W("orient", r), !P(this.doc.recipe, "orient", r)], ...this.cropValues(n ? {
			...t,
			x: 1 - t.x - t.width
		} : {
			...t,
			y: 1 - t.y - t.height
		})]);
	}
	setCropAspect(e) {
		let t = Ie(e, R(this.doc));
		this.apply("Crop aspect", [[W("crop", "aspect"), e], ...t === null ? [] : this.cropValues(Ve(R(this.doc), t))]);
	}
	setCrop(e) {
		this.apply("Crop", this.cropValues(e));
	}
	reset() {
		let e = Object.entries(Ee().ops).flatMap(([e, t]) => Object.entries(t).map(([t, n]) => [W(e, t), n]));
		this.apply("Reset", [
			...e,
			[G, []],
			[K, []],
			[Ze, null],
			[Qe, null],
			[$e, null]
		]);
	}
	cropValues(e) {
		let t = Math.min(1, Math.max(.001, e.width)), n = Math.min(1, Math.max(.001, e.height));
		return [
			[W("crop", "x"), Math.min(1 - t, Math.max(0, e.x))],
			[W("crop", "y"), Math.min(1 - n, Math.max(0, e.y))],
			[W("crop", "width"), t],
			[W("crop", "height"), n]
		];
	}
};
//#endregion
//#region ../core/src/cropmask.ts
function rt(e, t) {
	let n = ze(Fe({
		...e,
		recipe: {
			...e.recipe,
			ops: {
				...e.recipe.ops,
				canvas: {
					...e.recipe.ops.canvas,
					square: !1,
					margin: 0
				}
			}
		}
	})), { width: r, height: i } = b(e.source.width, e.source.height), a = new Uint8Array(r * i);
	if (!n) return {
		alpha: a,
		width: r,
		height: i
	};
	for (let e = 0; e < i; e++) for (let o = 0; o < r; o++) {
		let [s, c] = L(n, (o + .5) / r, (e + .5) / i);
		if (s < 0 || s > 1 || c < 0 || c > 1) continue;
		let l = Math.min(t.width - 1, Math.max(0, s * t.width - .5)), u = Math.min(t.height - 1, Math.max(0, c * t.height - .5)), d = Math.floor(l), f = Math.floor(u), p = Math.min(t.width - 1, d + 1), m = Math.min(t.height - 1, f + 1), h = l - d, g = u - f, _ = t.alpha[f * t.width + d] * (1 - h) + t.alpha[f * t.width + p] * h, v = t.alpha[m * t.width + d] * (1 - h) + t.alpha[m * t.width + p] * h;
		a[e * r + o] = Math.round(_ * (1 - g) + v * g);
	}
	return {
		alpha: a,
		width: r,
		height: i
	};
}
//#endregion
//#region ../pipeline/src/image.ts
var it = (e) => ({
	width: e.width,
	height: e.height,
	data: new Uint8ClampedArray(e.data)
});
//#endregion
//#region ../pipeline/src/inpaint.ts
function at(e, t, n, r = 0, i = r) {
	let a = new Uint8Array(e * t);
	for (let o of n) {
		let n = Math.max(0, Math.floor((o.x - r) * e)), s = Math.max(0, Math.floor((o.y - i) * t)), c = Math.min(e, Math.ceil((o.x + o.width + r) * e)), l = Math.min(t, Math.ceil((o.y + o.height + i) * t));
		for (let t = s; t < l; t++) for (let r = n; r < c; r++) a[t * e + r] = 1;
	}
	return a;
}
function ot(e, t, n, r) {
	let i = new Uint8Array(e.length);
	for (let a = 0; a < n; a++) for (let o = 0; o < t; o++) if (e[a * t + o]) for (let e = -r; e <= r; e++) for (let s = -r; s <= r; s++) {
		let r = o + s, c = a + e;
		r >= 0 && c >= 0 && r < t && c < n && (i[c * t + r] = 1);
	}
	return i;
}
var st = (...e) => {
	let t = new Uint8Array(e[0].length);
	for (let n of e) for (let e = 0; e < t.length; e++) n[e] && (t[e] = 1);
	return t;
};
function ct(e, t) {
	let { width: n, height: r, data: i } = e, a = null, o = 0, s = 0;
	for (let e of [
		8,
		4,
		2,
		1
	]) {
		let c = Math.max(2, Math.floor(n / e)), l = Math.max(2, Math.floor(r / e)), u = new Float32Array(c * l * 3), d = new Uint8Array(c * l);
		for (let e = 0; e < l; e++) for (let f = 0; f < c; f++) {
			let p = Math.floor(f * n / c), m = Math.floor(e * r / l), h = Math.max(p + 1, Math.floor((f + 1) * n / c)), g = Math.max(m + 1, Math.floor((e + 1) * r / l)), _ = 0, v = 0, y = 0, b = 0, x = 0;
			for (let e = m; e < g; e++) for (let r = p; r < h; r++) if (v++, !t[e * n + r]) {
				_++;
				let t = (e * n + r) * 4;
				y += i[t], b += i[t + 1], x += i[t + 2];
			}
			let S = e * c + f;
			if (_ === v) u[S * 3] = y / _, u[S * 3 + 1] = b / _, u[S * 3 + 2] = x / _;
			else if (d[S] = 1, a) {
				let t = (Math.min(s - 1, Math.floor(e * s / l)) * o + Math.min(o - 1, Math.floor(f * o / c))) * 3;
				u[S * 3] = a[t], u[S * 3 + 1] = a[t + 1], u[S * 3 + 2] = a[t + 2];
			} else _ ? (u[S * 3] = y / _, u[S * 3 + 1] = b / _, u[S * 3 + 2] = x / _) : u[S * 3] = u[S * 3 + 1] = u[S * 3 + 2] = 128;
		}
		let f = e === 1 ? 60 : 250;
		for (let e = 0; e < f; e++) for (let e = 0; e < l; e++) for (let t = 0; t < c; t++) {
			let n = e * c + t;
			if (!d[n]) continue;
			let r = t > 0 ? n - 1 : n, i = t < c - 1 ? n + 1 : n, a = e > 0 ? n - c : n, o = e < l - 1 ? n + c : n;
			for (let e = 0; e < 3; e++) u[n * 3 + e] = (u[r * 3 + e] + u[i * 3 + e] + u[a * 3 + e] + u[o * 3 + e]) / 4;
		}
		a = u, o = c, s = l;
	}
	let c = it(e);
	if (a) {
		for (let e = 0; e < n * r; e++) if (t[e]) for (let t = 0; t < 3; t++) c.data[e * 4 + t] = a[e * 3 + t] + e * (7 + 4 * t) % 5 - 2;
	}
	return c;
}
//#endregion
//#region ../pipeline/src/stickers.ts
var q = (e) => Math.min(1, Math.max(0, e));
function lt(e, t) {
	let { width: n, height: r, data: i } = e, a = t.width * 1, o = t.height * 1, s = Math.max(0, Math.floor((t.x - a) * n)), c = Math.max(0, Math.floor((t.y - o) * r)), l = Math.min(n, Math.ceil((t.x + t.width + a) * n)), u = Math.min(r, Math.ceil((t.y + t.height + o) * r)), d = l - s, f = u - c;
	if (d < 4 || f < 4) return t;
	let p = (e, t) => {
		let r = (t * n + e) * 4, a = Math.min(i[r], i[r + 1], i[r + 2]);
		return a >= 150 && Math.max(i[r], i[r + 1], i[r + 2]) - a <= 26;
	}, m = (e, i) => e >= t.x * n && e < (t.x + t.width) * n && i >= t.y * r && i < (t.y + t.height) * r, h = new Uint8Array(d * f), g = null, _ = [];
	for (let e = 0; e < f; e++) for (let t = 0; t < d; t++) {
		if (h[e * d + t] || !p(s + t, c + e)) continue;
		let n = 0, r = t, i = t, a = e, o = e;
		for (h[e * d + t] = 1, _.push(e * d + t); _.length;) {
			let e = _.pop(), t = e % d, l = (e - t) / d;
			m(s + t, c + l) && n++, t < r && (r = t), t > i && (i = t), l < a && (a = l), l > o && (o = l);
			for (let [e, n] of [
				[1, 0],
				[-1, 0],
				[0, 1],
				[0, -1]
			]) {
				let r = t + e, i = l + n;
				r < 0 || i < 0 || r >= d || i >= f || h[i * d + r] || !p(s + r, c + i) || (h[i * d + r] = 1, _.push(i * d + r));
			}
		}
		(!g || n > g.overlap) && (g = {
			overlap: n,
			minX: r,
			maxX: i,
			minY: a,
			maxY: o
		});
	}
	let v = t.width * n * t.height * r;
	if (!g || g.overlap < v * .2 || g.minX === 0 || g.minY === 0 || g.maxX === d - 1 || g.maxY === f - 1 || g.maxX - g.minX + 1 > t.width * n * 2 || g.maxY - g.minY + 1 > t.height * r * 2.5) return t;
	let y = Math.max(3, (g.maxX - g.minX) * .02), b = Math.max(3, (g.maxY - g.minY) * .04), x = q((s + g.minX - y) / n), S = q((c + g.minY - b) / r);
	return {
		x,
		y: S,
		width: q((s + g.maxX + 1 + y) / n) - x,
		height: q((c + g.maxY + 1 + b) / r) - S
	};
}
//#endregion
//#region ../pipeline/src/words.ts
var ut = {
	lightness: 225,
	maxWidth: 30,
	minLength: 35
};
function dt(e, t) {
	let { width: n, height: r, data: i } = e, a = new Uint8Array(n * r);
	for (let e = 0; e < n * r; e++) {
		if (i[e * 4 + 3] < 128) continue;
		let n = i[e * 4], r = i[e * 4 + 1], o = i[e * 4 + 2], s = Math.min(n, r, o);
		s >= t && Math.max(n, r, o) - s <= 34 && (a[e] = 1);
	}
	return a;
}
function ft(e, t, n, r, i) {
	let a = (e, a) => {
		let o = new Uint8Array(e.length), s = a ? t : n, c = a ? n : t;
		for (let n = 0; n < c; n++) for (let c = 0; c < s; c++) {
			let l = +!i;
			for (let o = -r; o <= r; o++) {
				let r = c + o, u = r < 0 || r >= s ? 0 : e[a ? n * t + r : r * t + n];
				if (i ? u : !u) {
					l = +!!i;
					break;
				}
			}
			o[a ? n * t + c : c * t + n] = l;
		}
		return o;
	};
	return a(a(e, !0), !1);
}
function pt(e, t = ut, n) {
	let { width: r, height: i } = e, a = Math.max(r, i), o = dt(e, t.lightness), s = Math.max(1, Math.round(t.maxWidth / 1e3 * a * .5)), c = ft(ft(o, r, i, s, !1), r, i, s, !0), l = t.minLength / 1e3 * a, u = new Uint8Array(r * i), d = new Uint8Array(r * i), f = [], p = [];
	for (let e = 0; e < o.length; e++) {
		if (!o[e] || u[e] || n && !n[e]) continue;
		let t = [], a = r, s = 0, m = i, h = 0, g = 0;
		for (u[e] = 1, f.push(e); f.length;) {
			let e = f.pop();
			t.push(e), c[e] && g++;
			let i = e % r, l = (e - i) / r;
			i < a && (a = i), i > s && (s = i), l < m && (m = l), l > h && (h = l);
			for (let t of [
				e - 1,
				e + 1,
				e - r,
				e + r,
				e - r - 1,
				e - r + 1,
				e + r - 1,
				e + r + 1
			]) {
				if (t < 0 || t >= o.length || !o[t] || u[t] || n && !n[t]) continue;
				let e = t % r;
				Math.abs(e - i) > 1 || (u[t] = 1, f.push(t));
			}
		}
		let _ = Math.hypot(s - a, h - m);
		if (_ >= l && g / t.length < .5) for (let e of t) d[e] = 1;
		else _ >= l * .4 && p.push({
			members: t,
			thickShare: g / t.length
		});
	}
	let m = ft(d, r, i, Math.max(2, Math.round(a * .03)), !0);
	for (let e of p) if (e.thickShare < .85 && e.members.some((e) => m[e])) for (let t of e.members) d[t] = 1;
	let h = dt(e, Math.max(150, t.lightness - 40)), g = d;
	for (let e = 0; e < 4; e++) {
		let e = new Uint8Array(g);
		for (let t = 0; t < e.length; t++) {
			if (e[t] || !h[t] || n && !n[t]) continue;
			let i = t % r;
			(i > 0 && g[t - 1] || i < r - 1 && g[t + 1] || t >= r && g[t - r] || t + r < e.length && g[t + r]) && (e[t] = 1);
		}
		g = e;
	}
	return ot(g, r, i, Math.max(2, Math.round(a * .0045)));
}
function mt(e, t = ut, n, r, i = !0) {
	let a = i ? pt(e, t, n) : new Uint8Array(e.width * e.height);
	r && (a = a.map((e, t) => e || r[t] ? 1 : 0));
	let o = 0;
	for (let e of a) o += e;
	return {
		image: o ? ct(e, a) : it(e),
		filled: o
	};
}
//#endregion
//#region ../pipeline/src/printed.ts
var ht = (e) => {
	let t = [...e].sort((e, t) => e - t);
	return t[Math.floor(t.length / 2)] ?? 0;
};
function gt(e, t, n = 40) {
	let { width: r, height: i, data: a } = e, o = new Uint8Array(r * i), s = Math.max(0, Math.floor(t.x * r)), c = Math.max(0, Math.floor(t.y * i)), l = Math.min(r, Math.ceil((t.x + t.width) * r)), u = Math.min(i, Math.ceil((t.y + t.height) * i));
	if (l - s < 2 || u - c < 2) return o;
	let d = Math.max(2, Math.round(Math.min(l - s, u - c) * .25)), f = [], p = [], m = [], h = (e, t) => {
		let n = (t * r + e) * 4;
		f.push(a[n]), p.push(a[n + 1]), m.push(a[n + 2]);
	};
	for (let e = Math.max(0, c - d); e < Math.min(i, u + d); e++) for (let t = Math.max(0, s - d); t < Math.min(r, l + d); t++) (t < s || t >= l || e < c || e >= u) && h(t, e);
	if (f.length < 8) {
		for (let e = s; e < l; e++) h(e, c), h(e, u - 1);
		for (let e = c; e < u; e++) h(s, e), h(l - 1, e);
	}
	let g = [
		ht(f),
		ht(p),
		ht(m)
	];
	if ([
		f,
		p,
		m
	].reduce((e, t, n) => e + ht(t.map((e) => Math.abs(e - g[n]))), 0) / 3 > 18) return _t(e, s, c, l, u);
	for (let e of [n, n * 1.8]) {
		let t = 0;
		o.fill(0);
		for (let n = c; n < u; n++) for (let i = s; i < l; i++) {
			let s = (n * r + i) * 4;
			(Math.abs(a[s] - g[0]) + Math.abs(a[s + 1] - g[1]) + Math.abs(a[s + 2] - g[2])) / 3 > e && (o[n * r + i] = 1, t++);
		}
		if (t <= (l - s) * (u - c) * .6) return o;
	}
	return _t(e, s, c, l, u);
}
function _t(e, t, n, r, i, a = 70) {
	let { width: o, height: s, data: c } = e, l = r - t, u = i - n, d = new Uint8Array(o * s), f = new Float32Array(l * u);
	for (let e = 0; e < u; e++) for (let r = 0; r < l; r++) {
		let i = ((n + e) * o + t + r) * 4;
		f[e * l + r] = .299 * c[i] + .587 * c[i + 1] + .114 * c[i + 2];
	}
	let p = Math.max(2, Math.round(u * .09)), m = (e, t) => {
		let n = (e, n) => {
			let r = new Float32Array(e.length), i = n ? l : u, a = n ? u : l;
			for (let o = 0; o < a; o++) for (let a = 0; a < i; a++) {
				let s = t ? -Infinity : Infinity;
				for (let r = Math.max(0, a - p); r <= Math.min(i - 1, a + p); r++) {
					let i = e[n ? o * l + r : r * l + o];
					(t ? i > s : i < s) && (s = i);
				}
				r[n ? o * l + a : a * l + o] = s;
			}
			return r;
		};
		return n(n(e, !0), !1);
	}, h = m(m(f, !0), !1), g = m(m(f, !1), !0), _ = 0, v = new Uint8Array(l * u);
	for (let e = 0; e < f.length; e++) (h[e] - f[e] > a || f[e] - g[e] > a) && (v[e] = 1, _++);
	if (_ > l * u * .4) return d;
	for (let e = 0; e < u; e++) for (let r = 0; r < l; r++) v[e * l + r] && (d[(n + e) * o + t + r] = 1);
	return d;
}
function vt(e, t, n, r = 48) {
	let { width: i, height: a, data: o } = e, s = (e, t) => {
		let n = (Math.min(a - 1, Math.max(0, t)) * i + Math.min(i - 1, Math.max(0, e))) * 4;
		return [
			o[n],
			o[n + 1],
			o[n + 2]
		];
	}, c = (e, t) => (Math.abs(e[0] - t[0]) + Math.abs(e[1] - t[1]) + Math.abs(e[2] - t[2])) / 3, l = Math.round(n.x), u = Math.round(n.y), d = Math.min(44, Math.max(14, Math.round((t.y1 - t.y0) * .2))), f = [], p = [], m = [];
	for (let e = -d - 2; e <= d + 2; e++) for (let t = -d - 2; t <= d + 2; t++) {
		if (Math.max(Math.abs(t), Math.abs(e)) < d) continue;
		let [n, r, i] = s(l + t, u + e);
		f.push(n), p.push(r), m.push(i);
	}
	let h = (e) => [...e].sort((e, t) => e - t)[Math.floor(e.length / 2)], g = [
		h(f),
		h(p),
		h(m)
	], _ = Math.min(22, Math.max(8, Math.round(d * .5))), v = null, y = 0;
	for (let e = 0; e <= _ && !v; e++) {
		for (let t = -e; t <= e; t++) for (let n = -e; n <= e; n++) {
			if (Math.max(Math.abs(n), Math.abs(t)) !== e) continue;
			let r = s(l + n, u + t), i = c(r, g);
			i >= 60 && i > y && (y = i, v = r);
		}
		if (v) for (let t = -(e + 2); t <= e + 2; t++) for (let n = -(e + 2); n <= e + 2; n++) {
			let e = s(l + n, u + t), r = c(e, g);
			r > y && (y = r, v = e);
		}
	}
	if (!v) return { problem: "no-print" };
	let b = new Uint8Array(i * a), x = 0, S = Math.max(0, Math.round(t.x0)), C = Math.max(0, Math.round(t.y0)), w = Math.min(i, Math.round(t.x1)), T = Math.min(a, Math.round(t.y1));
	for (let e = C; e < T; e++) for (let t = S; t < w; t++) {
		let n = (e * i + t) * 4;
		(Math.abs(o[n] - v[0]) + Math.abs(o[n + 1] - v[1]) + Math.abs(o[n + 2] - v[2])) / 3 < r && (b[e * i + t] = 1, x++);
	}
	return x < 12 ? { problem: "no-print" } : x > (w - S) * (T - C) * .45 ? { problem: "too-much" } : {
		mask: b,
		color: v
	};
}
//#endregion
//#region ../pipeline/src/reconstruct.ts
function yt(e, t, n) {
	let r = (e) => {
		let t = e / 255;
		return t <= .04045 ? t / 12.92 : ((t + .055) / 1.055) ** 2.4;
	}, i = r(e), a = r(t), o = r(n), s = (e) => e > .008856 ? Math.cbrt(e) : 7.787 * e + 16 / 116, c = s((.4124 * i + .3576 * a + .1805 * o) / .95047), l = s(.2126 * i + .7152 * a + .0722 * o), u = s((.0193 * i + .1192 * a + .9505 * o) / 1.08883);
	return [
		116 * l - 16,
		500 * (c - l),
		200 * (l - u)
	];
}
function bt(e, t) {
	let n = /* @__PURE__ */ new Float64Array(128);
	for (let r of e) n[Math.min(127, Math.floor(r / t * 128))]++;
	let r = e.length, i = 0;
	for (let e = 0; e < 128; e++) i += e * n[e];
	let a = 0, o = 0, s = 0, c = 0;
	for (let e = 0; e < 128; e++) {
		if (a += n[e], !a) continue;
		let t = r - a;
		if (!t) break;
		o += e * n[e];
		let l = a * t * (o / a - (i - o) / t) ** 2;
		l > s && (s = l, c = e);
	}
	return (c + 1) / 128 * t;
}
function xt(e, t, n, r) {
	let i = new Uint8Array(t * n), a = new Uint8Array(t * n), o = [];
	for (let s = 0; s < t * n; s++) {
		if (!e[s] || a[s]) continue;
		let c = [];
		for (a[s] = 1, o.push(s); o.length;) {
			let r = o.pop();
			c.push(r);
			let i = r % t;
			for (let s of [
				i > 0 ? r - 1 : -1,
				i < t - 1 ? r + 1 : -1,
				r - t,
				r + t
			]) s < 0 || s >= t * n || !e[s] || a[s] || (a[s] = 1, o.push(s));
		}
		if (c.length >= r) for (let e of c) i[e] = 1;
	}
	return i;
}
function St(e, t, n, r = {}) {
	let { width: i, height: a } = e, { grow: o = 2, minPiece: s = 14, floor: c = 8 } = r, l = new Float32Array(i * a), u = [];
	for (let r = 0; r < i * a; r++) {
		if (!n[r]) continue;
		let i = yt(e.data[r * 4], e.data[r * 4 + 1], e.data[r * 4 + 2]), a = yt(t.data[r * 4], t.data[r * 4 + 1], t.data[r * 4 + 2]);
		l[r] = Math.hypot(i[0] - a[0], i[1] - a[1], i[2] - a[2]), u.push(l[r]);
	}
	if (!u.length) return new Uint8Array(i * a);
	let d = new Float32Array(i * a);
	for (let e = 0; e < a; e++) for (let t = 0; t < i; t++) {
		let n = 0, r = 0;
		for (let o = -1; o <= 1; o++) for (let s = -1; s <= 1; s++) {
			let c = t + s, u = e + o;
			if (c < 0 || u < 0 || c >= i || u >= a) continue;
			let d = (2 - Math.abs(s)) * (2 - Math.abs(o));
			n += l[u * i + c] * d, r += d;
		}
		d[e * i + t] = n / r;
	}
	l.set(d);
	let f = [];
	for (let e = 0; e < i * a; e++) n[e] && f.push(l[e]);
	let p = f.reduce((e, t) => Math.max(e, t), 0), m = Math.max(c, bt(f, Math.max(p, 1)) * .6), h = new Uint8Array(i * a);
	for (let e = 0; e < i * a; e++) n[e] && l[e] > m && (h[e] = 1);
	h = xt(h, i, a, s);
	let g = ot(h, i, a, o);
	for (let e = 0; e < g.length; e++) n[e] || (g[e] = 0);
	return g;
}
//#endregion
//#region ../shaders/src/parse.ts
var J = class extends Error {
	constructor(e, t, n) {
		super(`${e}${n ? `:${n}` : ""}: ${t}`);
	}
}, Ct = [
	"uInput",
	"uResolution",
	"uTime",
	"uFlipY"
], wt = /^\s*uniform\s+(\w+)\s+(\w+)\s*;\s*(?:\/\/\s*@param\b(.*))?$/, Tt = /^#[0-9a-fA-F]{6}$/, Et = (e) => e.slice(1, 2).toLowerCase() + e.slice(2);
function Dt(e) {
	let t = /^\s*"([^"]*)"/.exec(e)?.[1], n = {};
	for (let [, t, r] of e.matchAll(/(\w+)=("[^"]*"|\S+)/g)) n[t] = r.replace(/^"|"$/g, "");
	return {
		label: t,
		values: n
	};
}
function Ot(e, t, n, r, i = !0) {
	let a = n[r];
	if (a === void 0) {
		if (i) throw new J(e, `this slider needs ${r}=… (for example min=0 max=1 step=0.01 default=0.5)`, t);
		return;
	}
	let o = Number(a);
	if (!Number.isFinite(o)) throw new J(e, `${r}=${a} is not a number`, t);
	return o;
}
function kt(e, t, n, r, i) {
	if (!/^u[A-Z]\w*$/.test(r)) throw new J(e, `uniform "${r}" should start with u and a capital letter, like uAmount`, t);
	let { label: a = r.slice(1), values: o } = Dt(i), s;
	if (n === "float" || n === "int") {
		if (o.options !== void 0) {
			if (n !== "int") throw new J(e, "a list of options goes on an int uniform (the chosen position)", t);
			let r = o.options.split("|").map((e) => e.trim()).filter(Boolean);
			if (r.length < 2) throw new J(e, "options=… needs at least two choices separated by |", t);
			let i = o.default ?? r[0];
			if (!r.includes(i)) throw new J(e, `default=${i} is not one of the options`, t);
			s = {
				kind: "choice",
				label: a,
				options: r,
				default: i
			};
		} else {
			let r = Ot(e, t, o, "min"), i = Ot(e, t, o, "max"), c = Ot(e, t, o, "step", !1) ?? (n === "int" ? 1 : (i - r) / 100), l = Ot(e, t, o, "default");
			if (!(r < i)) throw new J(e, "min must be smaller than max", t);
			if (!(c > 0)) throw new J(e, "step must be above 0", t);
			if (l < r || l > i) throw new J(e, `default=${l} is outside min=${r} max=${i}`, t);
			if (n === "int" && !(Number.isInteger(r) && Number.isInteger(i) && Number.isInteger(l) && Number.isInteger(c))) throw new J(e, "an int slider needs whole numbers for min, max, step and default", t);
			s = {
				kind: "number",
				label: a,
				min: r,
				max: i,
				step: c,
				default: l,
				...o.unit ? { unit: o.unit } : {}
			};
		}
	} else if (n === "bool") {
		if (o.default !== "true" && o.default !== "false") throw new J(e, "a bool needs default=true or default=false", t);
		s = {
			kind: "boolean",
			label: a,
			default: o.default === "true"
		};
	} else if (n === "vec3") {
		if (!Tt.test(o.default ?? "")) throw new J(e, "a vec3 is a colour and needs default=#rrggbb", t);
		s = {
			kind: "color",
			label: a,
			default: o.default.toLowerCase()
		};
	} else throw new J(e, `uniforms of type ${n} are not supported (use float, int, bool or vec3)`, t);
	return {
		uniform: r,
		key: Et(r),
		glslType: n,
		spec: s
	};
}
function At(e, t, n) {
	let r = `${e}.${t === "fragment" ? "frag" : "vert"}.glsl`, i = n.split(/\r?\n/), a = {}, o = [], s = /* @__PURE__ */ new Set();
	i.forEach((e, n) => {
		let i = n + 1, c = /^\s*\/\/\s*@(shader|description|scope|contract|animated)\b\s*(.*)$/.exec(e);
		if (c) {
			a[c[1]] = c[2].trim();
			return;
		}
		if (/^\s*#\s*version\b/.test(e) && (t !== "vertex" || n !== 0)) throw new J(r, "leave out #version: it is added for you", i);
		let l = wt.exec(e);
		if (!l) {
			if (/^\s*uniform\b/.test(e)) throw new J(r, "write each uniform on its own line like: uniform float uAmount; // @param \"Amount\" min=0 max=1 default=0.5", i);
			return;
		}
		let [, u, d, f] = l;
		if (Ct.includes(d)) throw new J(r, `${d} is provided for you; remove this line`, i);
		if (f === void 0) throw new J(r, `uniform ${d} has no slider. Add // @param "Label" min=… max=… default=… (or remove the uniform)`, i);
		let p = kt(r, i, u, d, f);
		if (s.has(p.key)) throw new J(r, `two uniforms would both be called "${p.key}"`, i);
		s.add(p.key), o.push(p);
	});
	let c = t === "fragment" ? "effect" : a.contract === "fullscreen" || /\bvoid\s+main\s*\(/.test(n) ? "fullscreen" : "displace";
	if (c === "effect" && !/\bvec4\s+effect\s*\(\s*vec2\s+\w+\s*,\s*vec4\s+\w+\s*\)/.test(n)) throw new J(r, "write a function vec4 effect(vec2 uv, vec4 color) that returns the new colour");
	if (c === "displace" && !/\bvec3\s+displace\s*\(\s*vec3\s+\w+\s*,\s*vec3\s+\w+\s*,\s*vec2\s+\w+\s*\)/.test(n)) throw new J(r, "write a function vec3 displace(vec3 position, vec3 normal, vec2 uv) that returns the new position");
	let l = a.scope === "product" ? "product" : "image";
	if (a.scope && a.scope !== "image" && a.scope !== "product") throw new J(r, "@scope must be image or product");
	return {
		id: e,
		kind: t,
		name: a.shader || e,
		description: a.description ?? "",
		contract: c,
		scope: l,
		animated: "animated" in a,
		params: o,
		source: n
	};
}
function jt(e) {
	return Object.fromEntries(e.params.map((e) => [e.key, e.spec.default]));
}
function Mt(e, t) {
	return Object.fromEntries(e.params.map((e) => [e.key, j(e.spec, t?.[e.key]) ?? e.spec.default]));
}
function Nt(e, t) {
	let n = e.spec, r = j(n, t) ?? n.default;
	if (n.kind === "boolean") return +!!r;
	if (n.kind === "choice") return Math.max(0, n.options.indexOf(String(r)));
	if (n.kind === "color") {
		let e = String(r);
		return [
			parseInt(e.slice(1, 3), 16) / 255,
			parseInt(e.slice(3, 5), 16) / 255,
			parseInt(e.slice(5, 7), 16) / 255
		];
	}
	return Number(r);
}
//#endregion
//#region ../shaders/src/compose.ts
var Pt = "#version 300 es\nprecision highp float;\nuniform sampler2D uInput;\nuniform vec2 uResolution;\nuniform float uTime;\nuniform bool uFlipY;\nuniform bool uInputFlipped;\nout vec4 outColor;\nvec4 sampleInput(vec2 uv) { return texture(uInput, uInputFlipped ? vec2(uv.x, 1.0 - uv.y) : uv); }\nvec2 perMille(float v) { return v * 0.001 * max(uResolution.x, uResolution.y) / uResolution; }\n", Ft = "\nvoid main() {\n  vec2 uv = gl_FragCoord.xy / uResolution;\n  if (uFlipY) uv.y = 1.0 - uv.y;\n  outColor = effect(uv, sampleInput(uv));\n}\n";
function It(e) {
	return Pt + e.source + Ft;
}
//#endregion
//#region ../shaders/fragment/chromatic-aberration.frag.glsl?raw
var Lt = "// @shader Colour fringe\n// @description Splits red and blue slightly towards the edges, like a vintage lens.\n// @scope image\n\nuniform float uAmount; // @param \"Amount\" min=0 max=12 step=0.1 default=2.5\n\nvec4 effect(vec2 uv, vec4 color) {\n  vec2 away = (uv - 0.5) * uAmount * 0.003;\n  vec4 r = sampleInput(uv + away);\n  vec4 b = sampleInput(uv - away);\n  return vec4(r.r, color.g, b.b, max(color.a, max(r.a, b.a)));\n}\n", Rt = "// @shader Drop shadow\n// @description A soft shadow cast by the product onto whatever is behind it. Works on the product, before the background is added.\n// @scope product\n\nuniform float uOpacity;  // @param \"Darkness\" min=0 max=1 step=0.01 default=0.35\nuniform float uBlur;     // @param \"Softness\" min=1 max=80 step=0.5 default=18\nuniform float uOffsetX;  // @param \"Across\" min=-60 max=60 step=0.5 default=0\nuniform float uOffsetY;  // @param \"Down\" min=-60 max=60 step=0.5 default=22\nuniform vec3 uColor;     // @param \"Colour\" default=#000000\n\nvec4 effect(vec2 uv, vec4 color) {\n  vec2 origin = uv - perMille(1.0) * vec2(uOffsetX, uOffsetY);\n  float seen = 0.0;\n  for (int i = 0; i < 28; i++) {\n    float angle = float(i) * 2.39996;\n    float dist = sqrt((float(i) + 0.5) / 28.0) * uBlur;\n    seen += sampleInput(origin + perMille(dist) * vec2(cos(angle), sin(angle))).a;\n  }\n  float shadow = seen / 28.0 * uOpacity;\n  float alpha = color.a + shadow * (1.0 - color.a);\n  vec3 rgb = alpha > 0.0 ? (color.rgb * color.a + uColor * shadow * (1.0 - color.a)) / alpha : vec3(0.0);\n  return vec4(rgb, alpha);\n}\n", zt = "// @shader Duotone\n// @description Repaints the picture with two colours: one for the darks, one for the lights.\n// @scope image\n\nuniform vec3 uShadow;     // @param \"Darks\" default=#1b1b3a\nuniform vec3 uHighlight;  // @param \"Lights\" default=#ffd6a5\nuniform float uStrength;  // @param \"Strength\" min=0 max=1 step=0.01 default=1\n\nvec4 effect(vec2 uv, vec4 color) {\n  float luma = dot(color.rgb, vec3(0.2126, 0.7152, 0.0722));\n  vec3 toned = mix(uShadow, uHighlight, luma);\n  return vec4(mix(color.rgb, toned, uStrength), color.a);\n}\n", Bt = "// @shader Film grain\n// @description Fine speckle like photographic film. It also hides banding in smooth areas.\n// @scope image\n// @animated\n\nuniform float uAmount; // @param \"Amount\" min=0 max=0.5 step=0.005 default=0.08\nuniform float uSize;   // @param \"Grain size\" min=0.5 max=6 step=0.1 default=1.2\nuniform bool uMono;    // @param \"Black and white grain\" default=true\n\nfloat hash(vec2 p) {\n  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);\n}\n\nvec4 effect(vec2 uv, vec4 color) {\n  float cell = max(1.0, uSize * max(uResolution.x, uResolution.y) * 0.001);\n  vec2 id = floor(uv * uResolution / cell) + floor(uTime * 24.0);\n  vec3 n = uMono ? vec3(hash(id) - 0.5) : vec3(hash(id) - 0.5, hash(id + 17.0) - 0.5, hash(id + 41.0) - 0.5);\n  // Most visible in the midtones, like real film.\n  float luma = dot(color.rgb, vec3(0.2126, 0.7152, 0.0722));\n  float weight = 1.0 - abs(luma - 0.5) * 1.4;\n  return vec4(clamp(color.rgb + n * uAmount * weight, 0.0, 1.0), color.a);\n}\n", Vt = "// @shader Pixelate\n// @description Chunky square pixels, like an old video game.\n// @scope image\n\nuniform int uCells; // @param \"Pixels across\" min=16 max=400 step=1 default=96\n\nvec4 effect(vec2 uv, vec4 color) {\n  vec2 grid = uResolution / max(uResolution.x, uResolution.y) * float(uCells);\n  return sampleInput((floor(uv * grid) + 0.5) / grid);\n}\n", Ht = "// @shader Sharpen\n// @description Crisper fine detail, like the print on a box. Gentle amounts look best.\n// @scope image\n\nuniform float uAmount; // @param \"Amount\" min=0 max=2 step=0.01 default=0.6\nuniform float uRadius; // @param \"Radius\" min=0.5 max=4 step=0.1 default=1.2\n\n// `uv` is where we are in the picture (0,0 top-left to 1,1 bottom-right); `color` is what is there now.\n// Return the new colour (red, green, blue, alpha, each 0 to 1).\nvec4 effect(vec2 uv, vec4 color) {\n  vec2 r = perMille(uRadius);\n  vec3 blur = (sampleInput(uv + vec2(r.x, 0.0)).rgb + sampleInput(uv - vec2(r.x, 0.0)).rgb +\n               sampleInput(uv + vec2(0.0, r.y)).rgb + sampleInput(uv - vec2(0.0, r.y)).rgb) * 0.25;\n  return vec4(clamp(color.rgb + (color.rgb - blur) * uAmount * 2.0, 0.0, 1.0), color.a);\n}\n", Y = "// @shader Soft glow\n// @description Bright areas bloom softly, for a dreamy, polished look.\n// @scope image\n\nuniform float uThreshold; // @param \"Only brighter than\" min=0 max=0.95 step=0.01 default=0.7\nuniform float uStrength;  // @param \"Strength\" min=0 max=2 step=0.01 default=0.5\nuniform float uRadius;    // @param \"Spread\" min=1 max=40 step=0.5 default=10\n\nvec4 effect(vec2 uv, vec4 color) {\n  vec3 glow = vec3(0.0);\n  // 20 samples spread over a disc (the golden angle keeps them evenly scattered).\n  for (int i = 0; i < 20; i++) {\n    float angle = float(i) * 2.39996;\n    float dist = sqrt((float(i) + 0.5) / 20.0) * uRadius;\n    vec3 s = sampleInput(uv + perMille(dist) * vec2(cos(angle), sin(angle))).rgb;\n    glow += max(s - uThreshold, 0.0) / (1.0 - uThreshold + 0.001);\n  }\n  glow /= 20.0;\n  vec3 screen = 1.0 - (1.0 - color.rgb) * (1.0 - clamp(glow * uStrength, 0.0, 1.0));\n  return vec4(screen, color.a);\n}\n", Ut = "// @shader Bulge\n// @description Puffs the middle of the product towards the viewer, like a pillow. Shows in the 3D scene.\n// @contract displace\n\nuniform float uAmount; // @param \"Puff\" min=-0.2 max=0.3 step=0.005 default=0.08\nuniform float uSpread; // @param \"Spread\" min=0.1 max=1 step=0.01 default=0.55\n\nvec3 displace(vec3 position, vec3 normal, vec2 uv) {\n  float centre = 1.0 - smoothstep(0.0, uSpread, length(position.xy));\n  position.z += uAmount * centre;\n  return position;\n}\n", Wt = "#version 300 es\n// @shader Fullscreen triangle\n// @description Used by every effect to cover the whole picture. A system shader: it is not offered as an effect.\n// @contract fullscreen\n\n// One triangle that covers the viewport; no vertex buffers needed.\nvoid main() {\n  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));\n  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);\n}\n", Gt = "// @shader Sway\n// @description The product leans gently from side to side, as if in a breeze. Shows in the 3D scene.\n// @contract displace\n// @animated\n\nuniform float uAmount; // @param \"Lean\" min=0 max=0.2 step=0.002 default=0.04\nuniform float uSpeed;  // @param \"Speed\" min=0.1 max=4 step=0.05 default=1\n\n// Called for every vertex of the product. Returns where it should be. `position` is where it normally sits.\nvec3 displace(vec3 position, vec3 normal, vec2 uv) {\n  float height = position.y + 0.5;                         // 0 at the bottom, 1 at the top\n  position.x += sin(uTime * uSpeed) * uAmount * height;    // the top moves most, the base stays put\n  return position;\n}\n", Kt = "// @shader Ripple\n// @description A soft wave runs across the product, like a flag or a poster in a draught. Shows in the 3D scene.\n// @contract displace\n// @animated\n\nuniform float uAmount;    // @param \"Height\" min=0 max=0.15 step=0.002 default=0.025\nuniform float uFrequency; // @param \"Waves\" min=1 max=16 step=0.1 default=6\nuniform float uSpeed;     // @param \"Speed\" min=0 max=6 step=0.05 default=1.5\n\nvec3 displace(vec3 position, vec3 normal, vec2 uv) {\n  position.z += sin(position.x * uFrequency + uTime * uSpeed) * uAmount;\n  return position;\n}\n", qt = (e, t) => e.slice(e.lastIndexOf("/") + 1).replace(t, "");
function Jt(e) {
	let t = {
		fragment: [],
		vertex: [],
		errors: []
	};
	for (let [n, r] of Object.entries(e)) {
		let e = n.endsWith(".frag.glsl") ? "fragment" : n.endsWith(".vert.glsl") ? "vertex" : null;
		if (!e) continue;
		let i = qt(n, e === "fragment" ? ".frag.glsl" : ".vert.glsl");
		try {
			t[e].push(At(i, e, r));
		} catch (e) {
			t.errors.push(e instanceof J ? e.message : `${n}: ${String(e)}`);
		}
	}
	for (let e of [t.fragment, t.vertex]) e.sort((e, t) => e.name.localeCompare(t.name));
	return t;
}
var Yt = Jt(/* @__PURE__ */ Object.assign({
	"../fragment/chromatic-aberration.frag.glsl": Lt,
	"../fragment/drop-shadow.frag.glsl": Rt,
	"../fragment/duotone.frag.glsl": zt,
	"../fragment/film-grain.frag.glsl": Bt,
	"../fragment/pixelate.frag.glsl": Vt,
	"../fragment/sharpen.frag.glsl": Ht,
	"../fragment/soft-glow.frag.glsl": Y,
	"../vertex/bulge.vert.glsl": Ut,
	"../vertex/fullscreen.vert.glsl": Wt,
	"../vertex/sway.vert.glsl": Gt,
	"../vertex/wave.vert.glsl": Kt
}));
Yt.errors.length && console.warn(`Some shaders were skipped:\n${Yt.errors.join("\n")}`);
var Xt = (e) => Yt.fragment.find((t) => t.id === e);
function Zt(e = ["image", "product"]) {
	return Yt.fragment.filter((t) => e.includes(t.scope));
}
var Qt = (Yt.vertex.find((e) => e.id === "fullscreen")?.source ?? "").replace(/^\s*\/\/.*\n/gm, ""), $t = "#version 300 es\nvoid main() {\n  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));\n  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);\n}", en = "#version 300 es\nprecision highp float;\n\nuniform sampler2D uSource;\nuniform sampler2D uMask;   // cut-out alpha, same coordinates as the source\nuniform bool uHasMask;\nuniform vec2 uMaskTexel;   // size of one mask pixel in source coordinates\nuniform bool uDespill;     // pull green spill off the product's cut edge\nuniform sampler2D uBackground;\nuniform int uBgMode;       // 0 transparent, 1 colour, 2 photo\nuniform vec3 uBgColor;\nuniform vec4 uBgTransform; // output uv -> photo uv: scale.xy, offset.xy (\"cover\")\nuniform mat3 uOutputToSource;\nuniform vec2 uOutputSize;\nuniform bool uFlipY;\n\nuniform float uExposure;   // stops\nuniform float uContrast;   // -1..1\nuniform float uHighlights; // -1..1\nuniform float uShadows;    // -1..1\nuniform vec3 uWhiteBalance; // per-channel gains, luminance-neutral\nuniform float uVibrance;   // -1..1\nuniform float uSaturation; // -1..1\nuniform float uVignette;   // -1..1\n\nout vec4 outColor;\n\nvec3 toLinear(vec3 c) {\n  return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), step(0.04045, c));\n}\n\nvec3 toDisplay(vec3 c) {\n  c = max(c, 0.0);\n  return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c));\n}\n\nfloat luma(vec3 c) {\n  return dot(c, vec3(0.2126, 0.7152, 0.0722));\n}\n\nvoid main() {\n  vec2 uv = gl_FragCoord.xy / uOutputSize;\n  if (uFlipY) uv.y = 1.0 - uv.y;\n\n  // The product, if this output pixel falls inside the photo (a square canvas can reach past its edges).\n  vec4 product = vec4(0.0);\n  vec2 src = (uOutputToSource * vec3(uv, 1.0)).xy;\n  if (!(any(lessThan(src, vec2(0.0))) || any(greaterThan(src, vec2(1.0))))) {\n    vec4 texel = texture(uSource, src);\n    float maskAlpha = uHasMask ? texture(uMask, src).r : 1.0;\n\n    if (uDespill && uHasMask) {\n      // Only where the cut edge is close: elsewhere a green pixel is the product's own colour.\n      vec2 d = uMaskTexel * 3.0;\n      float nearest = min(min(texture(uMask, src + vec2(d.x, 0.0)).r, texture(uMask, src - vec2(d.x, 0.0)).r),\n                          min(texture(uMask, src + vec2(0.0, d.y)).r, texture(uMask, src - vec2(0.0, d.y)).r));\n      float dom = texel.g - max(texel.r, texel.b);\n      if (nearest < 0.99 && dom > 0.0) texel.g = max(texel.r, texel.b) + dom * 0.15;\n    }\n\n    vec3 linear = toLinear(texel.rgb) * exp2(uExposure) * uWhiteBalance;\n    vec3 c = toDisplay(linear);\n\n    float y = luma(c);\n    c *= 1.0 + uShadows * 0.6 * (1.0 - smoothstep(0.0, 0.55, y));\n    c *= 1.0 + uHighlights * 0.5 * smoothstep(0.45, 1.0, y);\n    c = (c - 0.5) * (1.0 + uContrast * 0.8) + 0.5;\n\n    y = luma(c);\n    float chroma = max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b));\n    c = mix(vec3(y), c, 1.0 + uVibrance * (1.0 - clamp(chroma, 0.0, 1.0)));\n    c = mix(vec3(y), c, 1.0 + uSaturation);\n\n    float edge = smoothstep(0.35, 1.0, length(uv - 0.5) * 1.41421);\n    c *= 1.0 + uVignette * edge;\n\n    product = vec4(clamp(c, 0.0, 1.0), texel.a * maskAlpha);\n  }\n\n  // Put the product over whatever is behind it.\n  vec3 behind = vec3(0.0);\n  float behindAlpha = 0.0;\n  if (uBgMode == 1) {\n    behind = uBgColor;\n    behindAlpha = 1.0;\n  } else if (uBgMode == 2) {\n    behind = texture(uBackground, uv * uBgTransform.xy + uBgTransform.zw).rgb;\n    behindAlpha = 1.0;\n  }\n  float a = product.a + behindAlpha * (1.0 - product.a);\n  vec3 rgb = a > 0.0 ? (product.rgb * product.a + behind * behindAlpha * (1.0 - product.a)) / a : vec3(0.0);\n  outColor = vec4(rgb, a);\n}", X = [
	"uSource",
	"uMask",
	"uHasMask",
	"uMaskTexel",
	"uDespill",
	"uBackground",
	"uBgMode",
	"uBgColor",
	"uBgTransform",
	"uOutputToSource",
	"uOutputSize",
	"uFlipY",
	"uExposure",
	"uContrast",
	"uHighlights",
	"uShadows",
	"uWhiteBalance",
	"uVibrance",
	"uSaturation",
	"uVignette"
], tn = "#version 300 es\nprecision highp float;\nuniform sampler2D uProduct;\nuniform sampler2D uBackground;\nuniform vec2 uResolution;\nuniform bool uFlipY;\nuniform int uBgMode;\nuniform vec3 uBgColor;\nuniform vec4 uBgTransform;\nout vec4 outColor;\nvoid main() {\n  vec2 uv = gl_FragCoord.xy / uResolution;\n  if (uFlipY) uv.y = 1.0 - uv.y;\n  vec4 product = texture(uProduct, uv);\n  vec3 behind = vec3(0.0);\n  float behindAlpha = 0.0;\n  if (uBgMode == 1) { behind = uBgColor; behindAlpha = 1.0; }\n  else if (uBgMode == 2) { behind = texture(uBackground, uv * uBgTransform.xy + uBgTransform.zw).rgb; behindAlpha = 1.0; }\n  float a = product.a + behindAlpha * (1.0 - product.a);\n  vec3 rgb = a > 0.0 ? (product.rgb * product.a + behind * behindAlpha * (1.0 - product.a)) / a : vec3(0.0);\n  outColor = vec4(rgb, a);\n}";
function nn(e, t, n) {
	let r = e.createShader(t);
	if (e.shaderSource(r, n), e.compileShader(r), !e.getShaderParameter(r, e.COMPILE_STATUS)) {
		let t = e.getShaderInfoLog(r);
		throw e.deleteShader(r), Error(`Shader failed to compile: ${t}`);
	}
	return r;
}
function rn(e, t) {
	let n = e / 100, r = t / 100, i = [
		1 + .25 * n,
		1 - .2 * r,
		1 - .25 * n
	], a = .2126 * i[0] + .7152 * i[1] + .0722 * i[2];
	return i.map((e) => e / a);
}
function an(e, t, n) {
	return new Promise((r, i) => e.toBlob((e) => e ? r(e) : i(/* @__PURE__ */ Error("This browser could not encode the image.")), t, n));
}
var on = class {
	canvas;
	maxTextureSize;
	gl;
	program;
	vao;
	uniforms;
	source = null;
	mask = null;
	maskTexel = [0, 0];
	despill = !1;
	background = null;
	backgroundSize = [1, 1];
	effectPrograms = /* @__PURE__ */ new Map();
	composite = null;
	scratch = null;
	noMask;
	constructor(e) {
		this.canvas = e;
		let t = e.getContext("webgl2", {
			alpha: !0,
			premultipliedAlpha: !1,
			antialias: !1
		});
		if (!t) throw Error("This browser does not support WebGL2, which the editor needs.");
		this.gl = t, this.maxTextureSize = t.getParameter(t.MAX_TEXTURE_SIZE);
		let n = t.createProgram();
		if (t.attachShader(n, nn(t, t.VERTEX_SHADER, $t)), t.attachShader(n, nn(t, t.FRAGMENT_SHADER, en)), t.linkProgram(n), !t.getProgramParameter(n, t.LINK_STATUS)) throw Error(`Shader failed to link: ${t.getProgramInfoLog(n)}`);
		this.program = n, this.vao = t.createVertexArray(), this.noMask = t.createTexture(), t.bindTexture(t.TEXTURE_2D, this.noMask), t.texImage2D(t.TEXTURE_2D, 0, t.R8, 1, 1, 0, t.RED, t.UNSIGNED_BYTE, new Uint8Array([255])), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MIN_FILTER, t.NEAREST), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MAG_FILTER, t.NEAREST), this.uniforms = Object.fromEntries(X.map((e) => [e, t.getUniformLocation(n, e)]));
	}
	setSource(e) {
		let t = this.gl;
		this.source && t.deleteTexture(this.source), this.source = t.createTexture(), t.bindTexture(t.TEXTURE_2D, this.source), t.pixelStorei(t.UNPACK_FLIP_Y_WEBGL, !1), t.pixelStorei(t.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !1), t.texImage2D(t.TEXTURE_2D, 0, t.RGBA8, t.RGBA, t.UNSIGNED_BYTE, e), t.generateMipmap(t.TEXTURE_2D), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MIN_FILTER, t.LINEAR_MIPMAP_LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MAG_FILTER, t.LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_S, t.CLAMP_TO_EDGE), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_T, t.CLAMP_TO_EDGE);
	}
	setMask(e, t = 0, n = 0, r = {}) {
		let i = this.gl;
		this.mask && i.deleteTexture(this.mask), this.mask = null, this.despill = !1, e && (this.despill = r.despill === !0, this.maskTexel = [1 / t, 1 / n], this.mask = i.createTexture(), i.bindTexture(i.TEXTURE_2D, this.mask), i.pixelStorei(i.UNPACK_ALIGNMENT, 1), i.texImage2D(i.TEXTURE_2D, 0, i.R8, t, n, 0, i.RED, i.UNSIGNED_BYTE, e), i.pixelStorei(i.UNPACK_ALIGNMENT, 4), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_MIN_FILTER, i.LINEAR), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_MAG_FILTER, i.LINEAR), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_WRAP_S, i.CLAMP_TO_EDGE), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_WRAP_T, i.CLAMP_TO_EDGE));
	}
	setBackground(e) {
		let t = this.gl;
		this.background && t.deleteTexture(this.background), this.background = null, e && (this.backgroundSize = [e.width, e.height], this.background = t.createTexture(), t.bindTexture(t.TEXTURE_2D, this.background), t.pixelStorei(t.UNPACK_FLIP_Y_WEBGL, !1), t.pixelStorei(t.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !1), t.texImage2D(t.TEXTURE_2D, 0, t.RGBA8, t.RGBA, t.UNSIGNED_BYTE, e), t.generateMipmap(t.TEXTURE_2D), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MIN_FILTER, t.LINEAR_MIPMAP_LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MAG_FILTER, t.LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_S, t.CLAMP_TO_EDGE), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_T, t.CLAMP_TO_EDGE));
	}
	draw(e, t, n) {
		this.canvas.width !== t && (this.canvas.width = t), this.canvas.height !== n && (this.canvas.height = n), this.render(e, t, n, !0, null);
	}
	async export(e, t = {}) {
		let n = this.gl, r = Math.min(this.maxTextureSize, n.getParameter(n.MAX_RENDERBUFFER_SIZE)), { width: i, height: a } = Pe(e, Math.min(t.maxSize ?? Infinity, r)), o = n.createTexture();
		n.bindTexture(n.TEXTURE_2D, o), n.texStorage2D(n.TEXTURE_2D, 1, n.RGBA8, i, a);
		let s = n.createFramebuffer();
		n.bindFramebuffer(n.FRAMEBUFFER, s), n.framebufferTexture2D(n.FRAMEBUFFER, n.COLOR_ATTACHMENT0, n.TEXTURE_2D, o, 0);
		let c = new Uint8ClampedArray(i * a * 4);
		try {
			this.render(e, i, a, !1, s), n.readPixels(0, 0, i, a, n.RGBA, n.UNSIGNED_BYTE, c);
		} finally {
			n.bindFramebuffer(n.FRAMEBUFFER, null), n.deleteFramebuffer(s), n.deleteTexture(o);
		}
		let l = t.type ?? "image/webp", u = document.createElement("canvas");
		u.width = i, u.height = a, u.getContext("2d").putImageData(new ImageData(c, i, a), 0, 0);
		let d = async (e, n) => {
			if (e !== "image/jpeg") return an(u, e, n);
			let r = document.createElement("canvas");
			r.width = i, r.height = a;
			let o = r.getContext("2d");
			return o.fillStyle = t.background ?? "#ffffff", o.fillRect(0, 0, i, a), o.drawImage(u, 0, 0), an(r, e, n);
		}, f = t.quality ?? .88, p = await d(l, f), m = p.type === l ? l : l === "image/webp" ? "image/jpeg" : p.type;
		if (m !== p.type && (p = await d(m, f)), t.maxBytes && m !== "image/png") for (; p.size > t.maxBytes && f > .4;) f -= .08, p = await d(m, f);
		return {
			blob: p,
			width: i,
			height: a,
			type: p.type
		};
	}
	dispose() {
		let e = this.gl;
		this.source && e.deleteTexture(this.source), this.mask && e.deleteTexture(this.mask), this.background && e.deleteTexture(this.background), e.deleteTexture(this.noMask), this.freeScratch();
		for (let t of this.effectPrograms.values()) typeof t != "string" && e.deleteProgram(t.program);
		this.effectPrograms.clear(), this.composite && e.deleteProgram(this.composite.program), e.deleteProgram(this.program), e.deleteVertexArray(this.vao), this.source = null;
	}
	compileEffect(e) {
		let t = this.effectProgram(e);
		return typeof t == "string" ? t : null;
	}
	effectProgram(e) {
		let t = `${e.id}:${e.source.length}:${e.source.slice(-40)}`, n = this.effectPrograms.get(t);
		if (n) return n;
		let r = this.gl, i;
		try {
			let t = r.createProgram();
			if (r.attachShader(t, nn(r, r.VERTEX_SHADER, Qt)), r.attachShader(t, nn(r, r.FRAGMENT_SHADER, It(e))), r.linkProgram(t), !r.getProgramParameter(t, r.LINK_STATUS)) throw Error(`Shader failed to link: ${r.getProgramInfoLog(t)}`);
			i = {
				program: t,
				inputs: {
					uInput: r.getUniformLocation(t, "uInput"),
					uResolution: r.getUniformLocation(t, "uResolution"),
					uTime: r.getUniformLocation(t, "uTime"),
					uFlipY: r.getUniformLocation(t, "uFlipY"),
					uInputFlipped: r.getUniformLocation(t, "uInputFlipped")
				},
				params: new Map(e.params.map((e) => [e.uniform, r.getUniformLocation(t, e.uniform)]))
			};
		} catch (t) {
			i = `${e.id}: ${t instanceof Error ? t.message : String(t)}`, console.warn(`The "${e.name}" effect was skipped. ${i}`);
		}
		return this.effectPrograms.set(t, i), i;
	}
	freeScratch() {
		if (this.scratch) {
			for (let e of this.scratch.targets) this.gl.deleteFramebuffer(e.framebuffer), this.gl.deleteTexture(e.texture);
			this.scratch = null;
		}
	}
	scratchTargets(e, t) {
		let n = this.gl;
		if (this.scratch && this.scratch.width === e && this.scratch.height === t) return this.scratch.targets;
		this.freeScratch();
		let r = () => {
			let r = n.createTexture();
			n.bindTexture(n.TEXTURE_2D, r), n.texStorage2D(n.TEXTURE_2D, 1, n.RGBA8, e, t), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MIN_FILTER, n.LINEAR), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MAG_FILTER, n.LINEAR), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_S, n.CLAMP_TO_EDGE), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_T, n.CLAMP_TO_EDGE);
			let i = n.createFramebuffer();
			return n.bindFramebuffer(n.FRAMEBUFFER, i), n.framebufferTexture2D(n.FRAMEBUFFER, n.COLOR_ATTACHMENT0, n.TEXTURE_2D, r, 0), {
				texture: r,
				framebuffer: i
			};
		}, i = [r(), r()];
		return this.scratch = {
			width: e,
			height: t,
			targets: i
		}, i;
	}
	runEffect(e, t, n, r, i, a, o, s) {
		let c = this.gl;
		c.bindFramebuffer(c.FRAMEBUFFER, i), c.viewport(0, 0, a, o), c.useProgram(e.program), c.bindVertexArray(this.vao), c.activeTexture(c.TEXTURE0), c.bindTexture(c.TEXTURE_2D, r), c.uniform1i(e.inputs.uInput, 0), c.uniform2f(e.inputs.uResolution, a, o), c.uniform1f(e.inputs.uTime, 0), c.uniform1i(e.inputs.uFlipY, +!!s), c.uniform1i(e.inputs.uInputFlipped, 0);
		for (let r of t.params) {
			let t = e.params.get(r.uniform);
			if (!t) continue;
			let i = Nt(r, n[r.key]);
			Array.isArray(i) ? c.uniform3f(t, i[0], i[1], i[2]) : r.glslType === "float" ? c.uniform1f(t, i) : c.uniform1i(t, i);
		}
		c.drawArrays(c.TRIANGLES, 0, 3);
	}
	runComposite(e, t, n, r, i, a) {
		let o = this.gl;
		if (!this.composite) {
			let e = o.createProgram();
			if (o.attachShader(e, nn(o, o.VERTEX_SHADER, $t)), o.attachShader(e, nn(o, o.FRAGMENT_SHADER, tn)), o.linkProgram(e), !o.getProgramParameter(e, o.LINK_STATUS)) throw Error(`Shader failed to link: ${o.getProgramInfoLog(e)}`);
			let t = [
				"uProduct",
				"uBackground",
				"uResolution",
				"uFlipY",
				"uBgMode",
				"uBgColor",
				"uBgTransform"
			];
			this.composite = {
				program: e,
				uniforms: Object.fromEntries(t.map((t) => [t, o.getUniformLocation(e, t)]))
			};
		}
		let s = this.composite.uniforms;
		o.bindFramebuffer(o.FRAMEBUFFER, n), o.viewport(0, 0, r, i), o.useProgram(this.composite.program), o.bindVertexArray(this.vao), o.activeTexture(o.TEXTURE0), o.bindTexture(o.TEXTURE_2D, t), o.uniform1i(s.uProduct, 0);
		let c = F(e.recipe, "backdrop", "mode") === "image" && this.background;
		o.activeTexture(o.TEXTURE1), o.bindTexture(o.TEXTURE_2D, c ? this.background : this.noMask), o.uniform1i(s.uBackground, 1), o.uniform2f(s.uResolution, r, i), o.uniform1i(s.uFlipY, +!!a), this.setBackdropUniforms(e, r, i, s.uBgMode, s.uBgColor, s.uBgTransform), o.activeTexture(o.TEXTURE0), o.drawArrays(o.TRIANGLES, 0, 3);
	}
	setBackdropUniforms(e, t, n, r, i, a) {
		let o = this.gl, s = e.recipe, c = F(s, "backdrop", "mode"), l = c === "image" && this.background;
		o.uniform1i(r, l ? 2 : +(c === "color"));
		let u = F(s, "backdrop", "color") || "#ffffff";
		o.uniform3f(i, parseInt(u.slice(1, 3), 16) / 255, parseInt(u.slice(3, 5), 16) / 255, parseInt(u.slice(5, 7), 16) / 255);
		let d = t / n, f = this.backgroundSize[0] / this.backgroundSize[1], p = f > d ? d / f : 1, m = f > d ? 1 : f / d;
		o.uniform4f(a, p, m, (1 - p) / 2, (1 - m) / 2);
	}
	render(e, t, n, r, i) {
		let a = e.recipe.effects.map((e) => ({
			step: e,
			def: Xt(e.id)
		})).filter((e) => !!e.def).map((e) => ({
			...e,
			program: this.effectProgram(e.def)
		})).filter((e) => typeof e.program != "string");
		if (!a.length) {
			this.gl.bindFramebuffer(this.gl.FRAMEBUFFER, i), this.drawPhoto(e, t, n, r, !0);
			return;
		}
		let [o, s] = this.scratchTargets(t, n);
		this.gl.bindFramebuffer(this.gl.FRAMEBUFFER, o.framebuffer), this.drawPhoto(e, t, n, !1, !1);
		let c = o, l = s, u = () => {
			[c, l] = [l, c];
		}, d = a.filter((e) => e.def.scope === "product"), f = a.filter((e) => e.def.scope !== "product");
		for (let e of d) this.runEffect(e.program, e.def, Mt(e.def, e.step.params), c.texture, l.framebuffer, t, n, !1), u();
		this.runComposite(e, c.texture, f.length ? l.framebuffer : i, t, n, !f.length && r), f.length && (u(), f.forEach((e, a) => {
			let o = a === f.length - 1;
			this.runEffect(e.program, e.def, Mt(e.def, e.step.params), c.texture, o ? i : l.framebuffer, t, n, o ? r : !1), u();
		}));
	}
	drawPhoto(e, t, n, r, i) {
		let a = this.gl, o = this.uniforms, s = e.recipe, c = Fe(e);
		if (a.viewport(0, 0, t, n), a.clearColor(0, 0, 0, 0), a.clear(a.COLOR_BUFFER_BIT), !this.source) return;
		a.useProgram(this.program), a.bindVertexArray(this.vao), a.activeTexture(a.TEXTURE0), a.bindTexture(a.TEXTURE_2D, this.source), a.uniform1i(o.uSource, 0), a.activeTexture(a.TEXTURE1), a.bindTexture(a.TEXTURE_2D, this.mask ?? this.noMask), a.uniform1i(o.uMask, 1), a.uniform1i(o.uHasMask, +!!this.mask), a.uniform2f(o.uMaskTexel, this.maskTexel[0], this.maskTexel[1]), a.uniform1i(o.uDespill, +!!this.despill);
		let l = i && F(s, "backdrop", "mode") === "image" && this.background;
		a.activeTexture(a.TEXTURE2), a.bindTexture(a.TEXTURE_2D, l ? this.background : this.noMask), a.uniform1i(o.uBackground, 2), i ? this.setBackdropUniforms(e, t, n, o.uBgMode, o.uBgColor, o.uBgTransform) : a.uniform1i(o.uBgMode, 0), a.activeTexture(a.TEXTURE0), a.uniformMatrix3fv(o.uOutputToSource, !1, [
			c.a,
			c.b,
			0,
			c.c,
			c.d,
			0,
			c.e,
			c.f,
			1
		]), a.uniform2f(o.uOutputSize, t, n), a.uniform1i(o.uFlipY, +!!r), a.uniform1f(o.uExposure, N(s, "light", "exposure")), a.uniform1f(o.uContrast, N(s, "light", "contrast") / 100), a.uniform1f(o.uHighlights, N(s, "light", "highlights") / 100), a.uniform1f(o.uShadows, N(s, "light", "shadows") / 100), a.uniform3fv(o.uWhiteBalance, rn(N(s, "color", "temperature"), N(s, "color", "tint"))), a.uniform1f(o.uVibrance, N(s, "color", "vibrance") / 100), a.uniform1f(o.uSaturation, N(s, "color", "saturation") / 100), a.uniform1f(o.uVignette, N(s, "effects", "vignette") / 100), a.drawArrays(a.TRIANGLES, 0, 3);
	}
}, sn = [
	"nw",
	"n",
	"ne",
	"e",
	"se",
	"s",
	"sw",
	"w"
], cn = (e) => `${e * 100}%`;
function ln({ editor: e, doc: t, width: n, height: r }) {
	let a = i(null), o = z(t), s = (t) => (n) => {
		n.preventDefault(), n.stopPropagation(), n.currentTarget.setPointerCapture(n.pointerId), a.current = {
			handle: t,
			start: z(e.document),
			x: n.clientX,
			y: n.clientY
		}, e.begin(t === "move" ? "Move crop" : "Resize crop");
	}, u = (t) => {
		let i = a.current;
		if (!i) return;
		let o = e.document;
		e.setCrop(He(i.start, i.handle, (t.clientX - i.x) / n, (t.clientY - i.y) / r, R(o), Le(o)));
	}, d = () => {
		a.current && (a.current = null, e.commit());
	};
	return /* @__PURE__ */ c("div", {
		className: "atl-crop",
		style: {
			width: n,
			height: r
		},
		onPointerMove: u,
		onPointerUp: d,
		onPointerCancel: d,
		children: /* @__PURE__ */ l("div", {
			className: "atl-crop__box",
			style: {
				left: cn(o.x),
				top: cn(o.y),
				width: cn(o.width),
				height: cn(o.height)
			},
			onPointerDown: s("move"),
			children: [/* @__PURE__ */ c("div", { className: "atl-crop__thirds" }), sn.map((e) => /* @__PURE__ */ c("div", {
				className: `atl-crop__handle atl-crop__handle--${e}`,
				onPointerDown: s(e)
			}, e))]
		})
	});
}
//#endregion
//#region src/CutoutOverlay.tsx
var un = .002;
function dn({ editor: e, doc: t, settings: n, width: r, height: o }) {
	let s = i(null), [l, u] = a(null), d = (t) => {
		let n = t.currentTarget.getBoundingClientRect(), [r, i] = L(Fe(e.document), (t.clientX - n.left) / n.width, (t.clientY - n.top) / n.height);
		return [Math.min(1, Math.max(0, r)), Math.min(1, Math.max(0, i))];
	}, f = (e) => ({
		kind: "brush",
		mode: n.tool === "erase" ? "remove" : "keep",
		radius: n.brush,
		points: e
	}), p = (t) => {
		t.preventDefault();
		let [r, i] = d(t);
		n.tool === "tap" ? e.addMaskOp({
			kind: "fill",
			mode: "remove",
			x: r,
			y: i,
			tolerance: n.tolerance
		}) : (t.currentTarget.setPointerCapture(t.pointerId), s.current = [r, i], e.begin(n.tool === "erase" ? "Erase" : "Restore"), e.addMaskOp(f(s.current)));
	}, m = (t) => {
		let n = t.currentTarget.getBoundingClientRect();
		u({
			x: t.clientX - n.left,
			y: t.clientY - n.top
		});
		let r = s.current;
		if (!r) return;
		let [i, a] = d(t);
		Math.hypot(i - r[r.length - 2], a - r[r.length - 1]) < un || (r.push(i, a), e.updateLastMaskOp(f([...r])));
	}, h = () => {
		s.current && (s.current = null, e.commit());
	}, g = Pe(t), _ = n.brush * Math.max(t.source.width, t.source.height) * (r / g.width);
	return /* @__PURE__ */ c("div", {
		className: `atl-cutout atl-cutout--${n.tool}`,
		style: {
			width: r,
			height: o
		},
		onPointerDown: p,
		onPointerMove: m,
		onPointerUp: h,
		onPointerCancel: h,
		onPointerLeave: () => u(null),
		children: l && n.tool !== "tap" && /* @__PURE__ */ c("div", {
			className: "atl-cutout__brush",
			style: {
				left: l.x - _,
				top: l.y - _,
				width: _ * 2,
				height: _ * 2
			}
		})
	});
}
var fn = {
	id: "birefnet-general-fp16",
	name: "BiRefNet (whole box, larger)",
	task: "cutout",
	summary: "Cuts a whole box or product out of any background. Four times the size of the compact model, and it was never fooled by artwork on a cover (the compact one took a girl on the cover for the object on one box in ten).",
	recommended: !1,
	license: {
		name: "MIT",
		commercialUse: "allowed",
		url: "https://huggingface.co/ZhengPeng7/BiRefNet"
	},
	sizeMb: 489.7,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/ZhengPeng7/BiRefNet",
		download: "https://huggingface.co/onnx-community/BiRefNet-ONNX/resolve/main/onnx/model_fp16.onnx"
	},
	file: {
		name: "birefnet-general-fp16.onnx",
		bytes: 489666272
	},
	input: {
		size: 1024,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "logits-mask"
}, pn = {
	id: "birefnet-lite-fp16",
	name: "BiRefNet lite (compact)",
	task: "cutout",
	summary: "Separates the product from any background, with clean edges. The compact version: half the download, nearly the same quality.",
	recommended: !0,
	license: {
		name: "MIT",
		commercialUse: "allowed",
		url: "https://huggingface.co/ZhengPeng7/BiRefNet_lite"
	},
	sizeMb: 114.5,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/ZhengPeng7/BiRefNet_lite",
		download: "https://huggingface.co/onnx-community/BiRefNet_lite-ONNX/resolve/main/onnx/model_fp16.onnx"
	},
	file: {
		name: "birefnet-lite-fp16.onnx",
		bytes: 114538221
	},
	input: {
		size: 1024,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "logits-mask"
}, mn = {
	id: "birefnet-lite",
	name: "BiRefNet lite (full precision)",
	task: "cutout",
	summary: "The same cut-out model at full precision. A bigger download for slightly finer edges.",
	recommended: !1,
	license: {
		name: "MIT",
		commercialUse: "allowed",
		url: "https://huggingface.co/ZhengPeng7/BiRefNet_lite"
	},
	sizeMb: 224,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/ZhengPeng7/BiRefNet_lite",
		download: "https://huggingface.co/onnx-community/BiRefNet_lite-ONNX/resolve/main/onnx/model.onnx"
	},
	file: {
		name: "birefnet-lite.onnx",
		bytes: 224005088
	},
	input: {
		size: 1024,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "logits-mask"
}, hn = {
	id: "lama-fp32",
	name: "LaMa fill (removes marks and lettering)",
	task: "inpaint",
	summary: "Paints over what you mask (printed words, stickers, marks) with realistic detail from around it. Much cleaner than the free fill on hair and fabric. Takes a few seconds per patch on a laptop.",
	recommended: !0,
	license: {
		name: "Apache-2.0",
		commercialUse: "allowed",
		url: "https://huggingface.co/Carve/LaMa-ONNX"
	},
	sizeMb: 208,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/Carve/LaMa-ONNX",
		download: "https://huggingface.co/Carve/LaMa-ONNX/resolve/main/lama_fp32.onnx"
	},
	file: {
		name: "lama-fp32.onnx",
		bytes: 208044816
	},
	input: {
		size: 512,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image"
}, gn = {
	id: "ppocr-det-v4",
	name: "Text finder (PaddleOCR v4, compact)",
	task: "text-detect",
	summary: "Finds where printed text is on a picture (any colour, many languages including Japanese), so it can be filled in. Tiny and quick.",
	recommended: !0,
	license: {
		name: "Apache-2.0",
		commercialUse: "allowed",
		url: "https://huggingface.co/SWHL/RapidOCR"
	},
	sizeMb: 4.7,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/SWHL/RapidOCR",
		download: "https://huggingface.co/SWHL/RapidOCR/resolve/main/PP-OCRv4/ch_PP-OCRv4_det_infer.onnx"
	},
	file: {
		name: "ppocr-det-v4.onnx",
		bytes: 4745517
	},
	input: {
		size: 960,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "probability-map"
}, _n = {
	id: "ppocr-rec-v4",
	name: "Text reader (PaddleOCR v4, compact)",
	task: "text-read",
	summary: "Reads what printed text says (numbers, prices, English, Chinese, Japanese kana), so a shop's price sticker can be told apart from the box's own printing. Used together with the text finder.",
	recommended: !0,
	license: {
		name: "Apache-2.0",
		commercialUse: "allowed",
		url: "https://huggingface.co/SWHL/RapidOCR"
	},
	sizeMb: 10.9,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/SWHL/RapidOCR",
		download: "https://huggingface.co/SWHL/RapidOCR/resolve/main/PP-OCRv4/ch_PP-OCRv4_rec_infer.onnx"
	},
	file: {
		name: "ppocr-rec-v4.onnx",
		bytes: 10857958
	},
	input: {
		size: 48,
		mean: [
			.5,
			.5,
			.5
		],
		std: [
			.5,
			.5,
			.5
		]
	},
	output: "probability-map"
}, vn = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realesr-general-x4",
	name: "Sharpen & enlarge (fast, small)",
	recommended: !1,
	summary: "Makes a picture 4 times larger and clearly sharper, adding believable fine detail. The small, quick one (about a quarter of a second for a face-sized area). Best first choice for photos of figures and boxes. In the benchmark it over-sharpened (1.13 times the original's edge detail) and lost some structure, so the x4plus model is the default.",
	sizeMb: 4.95,
	license: {
		name: "BSD-3-Clause (Real-ESRGAN)",
		commercialUse: "check",
		url: "https://github.com/xinntao/Real-ESRGAN/blob/master/LICENSE"
	},
	links: {
		modelCard: "https://huggingface.co/baker76/upscale-models",
		download: "https://huggingface.co/baker76/upscale-models/resolve/main/RealESR_General_x4.onnx"
	},
	file: {
		name: "realesr-general-x4.onnx",
		bytes: 4954907
	}
}, yn = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realesrgan-anime-x4",
	name: "Sharpen & enlarge (illustrations)",
	recommended: !1,
	summary: "Tuned for drawn art: very clean lines and flat colour, but it smooths skin and plastic texture, so it suits flat box illustrations more than photos of figures.",
	sizeMb: 18.7,
	license: {
		name: "BSD-3-Clause (Real-ESRGAN)",
		commercialUse: "check",
		url: "https://github.com/xinntao/Real-ESRGAN/blob/master/LICENSE"
	},
	links: {
		modelCard: "https://huggingface.co/baker76/upscale-models",
		download: "https://huggingface.co/baker76/upscale-models/resolve/main/RealESRGAN_anime_x4.onnx"
	},
	file: {
		name: "realesrgan-anime-x4.onnx",
		bytes: 18688425
	}
}, bn = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realesrgan-x4plus",
	name: "Sharpen & enlarge (best photo quality)",
	recommended: !1,
	summary: "Sharpens and enlarges 4x with the larger photo model. On a benchmark (half-size, compressed crops restored and compared with the originals) it was the most faithful and best balanced of the Real-ESRGAN models: highest SSIM and sharpness closest to the original. Slower (a few seconds for a face-sized area).",
	sizeMb: 69.9,
	license: {
		name: "BSD-3-Clause (Real-ESRGAN)",
		commercialUse: "check",
		url: "https://github.com/xinntao/Real-ESRGAN/blob/master/LICENSE"
	},
	links: {
		modelCard: "https://huggingface.co/baker76/upscale-models",
		download: "https://huggingface.co/baker76/upscale-models/resolve/main/RealESRGAN_x4plus.onnx"
	},
	file: {
		name: "realesrgan-x4plus.onnx",
		bytes: 69879921
	}
}, xn = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realplksr-x4",
	name: "Photo restore 4x (RealPLKSR, small and fast)",
	recommended: !0,
	summary: "A small 4x restoration model from darktable (MIT), trained for photographs. Best of every enlarging method on ten real product photos (bench/enlarge): sharper and truer than Real-ESRGAN, and it keeps printed text readable.",
	sizeMb: 29.7,
	license: {
		name: "MIT (darktable RealPLKSR)",
		commercialUse: "yes",
		url: "https://huggingface.co/darktable-org/upscale-realplksr-onnx"
	},
	links: {
		modelCard: "https://huggingface.co/darktable-org/upscale-realplksr-onnx",
		download: "https://huggingface.co/darktable-org/upscale-realplksr-onnx/resolve/main/onnx/model_x4.onnx"
	},
	file: {
		name: "realplksr-x4.onnx",
		bytes: 29711010
	}
}, Sn = {
	id: "sdxl-inpaint",
	name: "Redraw (Stable Diffusion XL inpainting)",
	task: "redraw",
	summary: "Redraws part of a picture with a believable continuation: a missing antenna, an edge that was cut off. Runs on this computer's GPU (about 30 seconds). It invents what it draws, so use it where the picture really is missing a part.",
	recommended: !0,
	license: {
		name: "OpenRAIL++-M (commercial use of the pictures is allowed; see the licence for its use restrictions)",
		commercialUse: "check",
		url: "https://huggingface.co/diffusers/stable-diffusion-xl-1.0-inpainting-0.1"
	},
	sizeMb: 6940,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/diffusers/stable-diffusion-xl-1.0-inpainting-0.1",
		download: "https://huggingface.co/diffusers/stable-diffusion-xl-1.0-inpainting-0.1"
	},
	file: {
		name: "sdxl-inpaint/unet/diffusion_pytorch_model.fp16.safetensors",
		bytes: 5135178560
	},
	input: {
		size: 1024,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image"
}, Cn = {
	id: "sdxl-tile",
	name: "Sharpen with detail (SDXL tile ControlNet)",
	task: "enhance",
	summary: "Makes a picture crisper and cleaner while every shape stays where it was: hair strands, fabric folds, edges. The original colours are kept. Runs on this computer's GPU (about half a minute to a minute for a 1024 pixel picture once the models are loaded). Works together with the redraw model.",
	recommended: !0,
	license: {
		name: "Apache-2.0 (used with SDXL, OpenRAIL++-M)",
		commercialUse: "allowed",
		url: "https://huggingface.co/xinsir/controlnet-tile-sdxl-1.0"
	},
	sizeMb: 2502,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/xinsir/controlnet-tile-sdxl-1.0",
		download: "https://huggingface.co/xinsir/controlnet-tile-sdxl-1.0"
	},
	file: {
		name: "sdxl-tile/diffusion_pytorch_model.safetensors",
		bytes: 2502139104
	},
	input: {
		size: 1024,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image"
}, wn = (e) => {
	let t = e;
	return !!t && typeof t.id == "string" && /^[a-z0-9][a-z0-9-]*$/.test(t.id) && typeof t.name == "string" && (t.task === "cutout" || t.task === "inpaint" || t.task === "text-detect" || t.task === "text-read" || t.task === "upscale" || t.task === "redraw" || t.task === "enhance") && typeof t.file?.name == "string" && typeof t.links?.download == "string" && typeof t.input?.size == "number";
};
function Tn(e) {
	return [...e].filter(wn).sort((e, t) => Number(t.recommended) - Number(e.recommended) || e.name.localeCompare(t.name));
}
function En(e) {
	return {
		MODELS: e,
		findModel: (t) => e.find((e) => e.id === t),
		modelsFor: (t) => e.filter((e) => e.task === t)
	};
}
var { MODELS: Dn, findModel: On, modelsFor: kn } = En(Tn(Object.values(/* @__PURE__ */ Object.assign({
	"../registry/birefnet-general-fp16.json": fn,
	"../registry/birefnet-lite-fp16.json": pn,
	"../registry/birefnet-lite.json": mn,
	"../registry/lama-fp32.json": hn,
	"../registry/ppocr-det-v4.json": gn,
	"../registry/ppocr-rec-v4.json": _n,
	"../registry/realesr-general-x4.json": vn,
	"../registry/realesrgan-anime-x4.json": yn,
	"../registry/realesrgan-x4plus.json": bn,
	"../registry/realplksr-x4.json": xn,
	"../registry/sdxl-inpaint.json": Sn,
	"../registry/sdxl-tile.json": Cn
})))), Z = class extends Error {
	status;
	constructor(e, t) {
		super(t), this.status = e;
	}
}, An = "http://127.0.0.1:47321", Q = {
	start: "npm run local:start",
	token: "npm run local:token",
	models: "npm run models",
	redrawSetup: "npm run redraw:setup",
	install: (e) => e && e !== "birefnet-lite-fp16" ? `npm run models:install -- ${e}` : "npm run models:install"
}, jn = class {
	options;
	base;
	doFetch;
	constructor(e = {}) {
		this.options = e, this.base = (e.url ?? "http://127.0.0.1:47321").replace(/\/$/, "");
		let t = e.fetch;
		this.doFetch = (e, n) => (t ?? fetch)(e, n);
	}
	headers(e = {}) {
		return this.options.token ? {
			Authorization: `Bearer ${this.options.token}`,
			...e
		} : e;
	}
	async probe() {
		if (await this.health()) return "ok";
		try {
			return await this.doFetch(`${this.base}/health`, {
				mode: "no-cors",
				signal: AbortSignal.timeout(2500)
			}), "blocked";
		} catch {
			return "offline";
		}
	}
	async health() {
		try {
			let e = await this.doFetch(`${this.base}/health`, { signal: AbortSignal.timeout(2500) });
			if (!e.ok) return null;
			let t = await e.json();
			return t.app === "gleamshelf-local" ? t : null;
		} catch {
			return null;
		}
	}
	async inpaint(e, t, n) {
		let r = await this.doFetch(`${this.base}/inpaint?model=${encodeURIComponent(t)}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "image/png" }),
			body: e,
			signal: n
		});
		if (!r.ok) throw new Z(r.status, await $(r));
		return new Blob([await r.arrayBuffer()], { type: "image/png" });
	}
	async upscale(e, t, n) {
		let r = await this.doFetch(`${this.base}/upscale?model=${encodeURIComponent(t)}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!r.ok) throw new Z(r.status, await $(r));
		return new Blob([await r.arrayBuffer()], { type: "image/png" });
	}
	async redraw(e, t, n) {
		let r = new URLSearchParams({ prompt: t.prompt });
		t.stacked && r.set("stacked", "true"), t.box && r.set("box", t.box.join(",")), t.negative && r.set("negative", t.negative);
		for (let e of [
			"strength",
			"steps",
			"guidance",
			"candidates",
			"seed"
		]) t[e] !== void 0 && r.set(e, String(t[e]));
		let i = await this.doFetch(`${this.base}/redraw?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "image/png" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new Z(i.status, await $(i));
		return new Blob([await i.arrayBuffer()], { type: "image/png" });
	}
	async enhance(e, t = {}, n) {
		let r = new URLSearchParams();
		t.prompt && r.set("prompt", t.prompt);
		for (let e of ["strength", "seed"]) t[e] !== void 0 && r.set(e, String(t[e]));
		t.keepColour === !1 && r.set("keepColour", "false");
		let i = await this.doFetch(`${this.base}/enhance?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "image/png" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new Z(i.status, await $(i));
		return new Blob([await i.arrayBuffer()], { type: "image/png" });
	}
	async readText(e, t) {
		let n = await this.doFetch(`${this.base}/read-text`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: t
		});
		if (!n.ok) throw new Z(n.status, await $(n));
		return (await n.json()).boxes;
	}
	async detectText(e, t, n) {
		let r = await this.doFetch(`${this.base}/detect-text?model=${encodeURIComponent(t)}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!r.ok) throw new Z(r.status, await $(r));
		return (await r.json()).boxes;
	}
	async startProcess(e, t = {}, n) {
		let r = new URLSearchParams();
		t.mode && r.set("mode", t.mode), t.vivid !== void 0 && r.set("vivid", String(t.vivid));
		for (let e of [
			"find",
			"listing",
			"enlarge",
			"stickers",
			"lettering",
			"thinParts",
			"colour",
			"look"
		]) t[e] !== void 0 && r.set(e, t[e] ? "1" : "0");
		let i = await this.doFetch(`${this.base}/process?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new Z(i.status, await $(i));
		return (await i.json()).id;
	}
	async processStatus(e, t) {
		let n = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}`, {
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new Z(n.status, await $(n));
		return await n.json();
	}
	async processPicture(e, t = "cutout", n) {
		let r = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/${t === "cutout" ? "cutout.png" : "studio.jpg"}`, {
			headers: this.headers(),
			signal: n
		});
		if (!r.ok) throw new Z(r.status, await $(r));
		return new Blob([await r.arrayBuffer()], { type: t === "cutout" ? "image/png" : "image/jpeg" });
	}
	async models() {
		let e = await this.doFetch(`${this.base}/models`, { headers: this.headers() });
		if (!e.ok) throw new Z(e.status, await $(e));
		return (await e.json()).models;
	}
	async cutout(e, t, n, r = {}) {
		let i = await this.doFetch(`${this.base}/cutout?model=${encodeURIComponent(t)}${r.thinParts ? "&refine=thin" : ""}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new Z(i.status, await $(i));
		let a = Number(i.headers.get("X-Mask-Width")), o = Number(i.headers.get("X-Mask-Height")), s = new Uint8Array(await i.arrayBuffer());
		if (!(a > 0 && o > 0) || s.length !== a * o) throw new Z(502, "The companion app sent a mask in a format this editor does not understand.");
		return {
			alpha: s,
			width: a,
			height: o,
			...i.headers.get("X-Mask-Parts") === "kept" ? { partsKept: !0 } : {}
		};
	}
};
async function $(e) {
	let t = await e.json().catch(() => null);
	return e.status === 401 ? "The companion app did not accept the pairing token. Copy it again from the app and paste it in." : t?.error ?? `The companion app answered ${e.status}.`;
}
//#endregion
//#region src/useLocalApp.ts
var Mn = "gleamshelf:local-app";
function Nn() {
	try {
		let e = JSON.parse(localStorage.getItem(Mn) ?? "{}");
		return {
			url: typeof e.url == "string" ? e.url : An,
			token: typeof e.token == "string" ? e.token : ""
		};
	} catch {
		return {
			url: An,
			token: ""
		};
	}
}
function Pn(e) {
	try {
		localStorage.setItem(Mn, JSON.stringify(e));
	} catch {}
}
function Fn(e) {
	let [i, o] = a(() => ({
		...Nn(),
		...e?.url ? { url: e.url } : {},
		...e?.token ? { token: e.token } : {}
	})), [s, c] = a("checking"), [l, u] = a(null), [d, f] = a(null), [p, m] = a([]), h = r(() => new jn({
		url: i.url,
		token: i.token
	}), [i]), g = t(async () => {
		f(null);
		let e = await h.probe();
		if (e === "ok" && m((await h.health())?.features ?? []), e !== "ok") c(e === "blocked" ? "blocked" : "offline"), u(null);
		else if (!i.token) c("needs-token"), u(null);
		else try {
			u(await h.models()), c("ready");
		} catch (e) {
			u(null), f(e instanceof Error ? e.message : "The companion app did not answer."), e instanceof Z && e.status === 401 ? (o((e) => ({
				...e,
				token: ""
			})), c("needs-token")) : c("offline");
		}
	}, [h, i.token]);
	return n(() => {
		g();
	}, [g]), n(() => {
		if (s !== "offline" && s !== "blocked") return;
		let e = setInterval(() => void g(), 3e3);
		return () => clearInterval(e);
	}, [s, g]), {
		state: s,
		saved: i,
		client: h,
		models: l,
		installed: (e) => l?.filter((t) => t.task === e && t.installed) ?? [],
		problem: d,
		setProblem: f,
		check: g,
		connect: (e) => {
			let t = {
				...i,
				token: e.trim()
			};
			Pn(t), o(t);
		},
		canProcess: p.includes("process")
	};
}
//#endregion
//#region src/AiCutout.tsx
function In({ app: e, what: t }) {
	let [n, r] = a("");
	return e.state === "checking" ? /* @__PURE__ */ c("p", {
		className: "atl-hint",
		children: "Looking for the Gleamshelf app on this computer…"
	}) : e.state === "blocked" ? /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ l("p", {
		className: "atl-error",
		children: [
			"The Gleamshelf app is running at ",
			e.saved.url,
			", but this browser will not let the page talk to it. Safari does this. Open the editor in Chrome or Edge, or serve it from",
			" ",
			/* @__PURE__ */ c("code", { children: "http://localhost" }),
			"."
		]
	}), /* @__PURE__ */ c("button", {
		type: "button",
		className: "atl-button",
		onClick: () => void e.check(),
		children: "Check again"
	})] }) : e.state === "offline" ? /* @__PURE__ */ l(s, { children: [
		/* @__PURE__ */ l("p", {
			className: "atl-hint",
			children: [
				t.intro,
				" It needs the small Gleamshelf app running on this computer (your photos never leave it). Nothing answered at ",
				/* @__PURE__ */ c("code", { children: e.saved.url }),
				". This page keeps looking, so it will notice as soon as the app starts."
			]
		}),
		/* @__PURE__ */ l("ol", {
			className: "atl-steps",
			children: [/* @__PURE__ */ l("li", { children: [
				"Open a terminal in the Gleamshelf folder and run ",
				/* @__PURE__ */ c("code", { children: Q.start }),
				". ",
				/* @__PURE__ */ c("strong", { children: "Leave it running" }),
				" while you edit."
			] }), /* @__PURE__ */ l("li", { children: [
				"Once, if you have not yet: ",
				/* @__PURE__ */ c("code", { children: t.install }),
				" (it says \"Already installed\" when the model is there; that is fine, the app still has to be started)."
			] })]
		}),
		/* @__PURE__ */ c("button", {
			type: "button",
			className: "atl-button",
			onClick: () => void e.check(),
			children: "Check now"
		})
	] }) : e.state === "needs-token" ? /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ l("p", {
		className: "atl-hint",
		children: [
			"The app is running. Paste its pairing token to connect. The token is a 32-character code. It is printed when you start the app, and again by ",
			/* @__PURE__ */ c("code", { children: Q.token }),
			" (it is the last line of the output)."
		]
	}), /* @__PURE__ */ l("div", {
		className: "atl-crop-tools",
		children: [/* @__PURE__ */ c("input", {
			type: "password",
			className: "atl-input",
			"aria-label": "Pairing token",
			placeholder: "Pairing token",
			value: n,
			onChange: (e) => r(e.target.value)
		}), /* @__PURE__ */ c("button", {
			type: "button",
			className: "atl-button",
			disabled: !n.trim(),
			onClick: () => {
				e.connect(n), r("");
			},
			children: "Connect"
		})]
	})] }) : null;
}
function Ln({ getPhoto: e, onMask: t, greenBackdrop: n, app: r }) {
	let [i, o] = a(""), [u, d] = a(!1), [f, p] = a("product"), m = kn("cutout"), h = r.installed("cutout"), g = i && h.some((e) => e.id === i) ? i : h[0]?.id ?? "", _ = On(g), v = async () => {
		d(!0), r.setProblem(null);
		try {
			t(g, await r.client.cutout(await e(f), g, void 0, { thinParts: f === "character" }), f);
		} catch (e) {
			r.setProblem(e instanceof Error ? e.message : "The cut-out did not work.");
		} finally {
			d(!1);
		}
	};
	return /* @__PURE__ */ l("div", {
		className: "atl-ai",
		children: [
			/* @__PURE__ */ l("div", {
				className: "atl-ai__title",
				children: [/* @__PURE__ */ c("strong", { children: "AI cut-out" }), /* @__PURE__ */ c("span", {
					className: "atl-badge atl-badge--free",
					title: "The model runs on your computer. Nothing is sent anywhere and nothing is charged.",
					children: "free · on your computer"
				})]
			}),
			/* @__PURE__ */ c(In, {
				app: r,
				what: {
					intro: "Works for any background, not just green.",
					install: Q.install(m.find((e) => e.recommended)?.id)
				}
			}),
			r.state === "ready" && /* @__PURE__ */ l(s, { children: [h.length === 0 ? /* @__PURE__ */ l("p", {
				className: "atl-hint",
				children: [
					"No cut-out model is installed yet. Run ",
					/* @__PURE__ */ c("code", { children: Q.install(m.find((e) => e.recommended)?.id) }),
					", then",
					" ",
					/* @__PURE__ */ c("button", {
						type: "button",
						className: "atl-link",
						onClick: () => void r.check(),
						children: "check again"
					}),
					"."
				]
			}) : /* @__PURE__ */ l(s, { children: [
				/* @__PURE__ */ l("label", {
					className: "atl-control",
					children: [/* @__PURE__ */ c("span", {
						className: "atl-control__row",
						children: /* @__PURE__ */ c("span", { children: "Model" })
					}), /* @__PURE__ */ c("select", {
						value: g,
						onChange: (e) => o(e.target.value),
						children: h.map((e) => /* @__PURE__ */ c("option", {
							value: e.id,
							children: e.name
						}, e.id))
					})]
				}),
				/* @__PURE__ */ l("div", {
					className: "atl-segmented",
					role: "group",
					"aria-label": "What to cut out",
					children: [/* @__PURE__ */ c("button", {
						type: "button",
						className: `atl-button ${f === "product" ? "is-active" : ""}`,
						"aria-pressed": f === "product",
						onClick: () => p("product"),
						title: "The whole box or product, without its background",
						children: "Whole product"
					}), /* @__PURE__ */ c("button", {
						type: "button",
						className: `atl-button ${f === "character" ? "is-active" : ""}`,
						"aria-pressed": f === "character",
						onClick: () => p("character"),
						title: "Only the character in the artwork on a box cover",
						children: "Character on cover"
					})]
				}),
				f === "product" && n && /* @__PURE__ */ l("p", {
					className: "atl-hint",
					children: [
						/* @__PURE__ */ c("strong", { children: "This photo has a green backdrop." }),
						" The free ",
						/* @__PURE__ */ c("em", { children: "Remove green backdrop" }),
						" button above does the same job instantly, so AI is not needed here. AI is for photos on any other background, or for picking out the character on a box cover."
					]
				}),
				f === "character" && /* @__PURE__ */ l("p", {
					className: "atl-hint",
					children: [
						"Use ",
						/* @__PURE__ */ c("strong", { children: "Crop" }),
						" first to frame just the artwork (leave out the logos, price tags and title text), then cut out. The character is found inside the crop. Printed words that cross the character stay with it; remove them with ",
						/* @__PURE__ */ c("strong", { children: "Printed lettering" }),
						" below."
					]
				}),
				_ && /* @__PURE__ */ l("p", {
					className: "atl-hint",
					children: [
						_.summary,
						" ",
						/* @__PURE__ */ c("a", {
							href: _.links.modelCard,
							target: "_blank",
							rel: "noreferrer",
							children: "About this model"
						}),
						" ",
						"· ",
						_.license.name,
						" licence, commercial use ",
						_.license.commercialUse
					]
				}),
				/* @__PURE__ */ c("button", {
					type: "button",
					className: "atl-button atl-button--primary",
					disabled: u || !g,
					onClick: () => void v(),
					children: u ? f === "character" ? "Working… also looking for thin parts, about 30 seconds" : "Working… the first run loads the model" : f === "character" ? "Cut out the character" : "Cut out with AI"
				})
			] }), m.some((e) => !r.models?.find((t) => t.id === e.id)?.installed) && /* @__PURE__ */ l("details", {
				className: "atl-hint",
				children: [/* @__PURE__ */ c("summary", { children: "More models" }), /* @__PURE__ */ c("ul", {
					className: "atl-models",
					children: m.filter((e) => !r.models?.find((t) => t.id === e.id)?.installed).map((e) => /* @__PURE__ */ l("li", { children: [
						/* @__PURE__ */ c("strong", { children: e.name }),
						" · ",
						e.sizeMb,
						" MB · ",
						e.license.name,
						/* @__PURE__ */ c("br", {}),
						e.summary,
						" ",
						/* @__PURE__ */ c("a", {
							href: e.links.modelCard,
							target: "_blank",
							rel: "noreferrer",
							children: "Read about it"
						}),
						/* @__PURE__ */ c("br", {}),
						/* @__PURE__ */ c("code", { children: Q.install(e.id) })
					] }, e.id))
				})]
			})] }),
			r.problem && /* @__PURE__ */ c("p", {
				className: "atl-error",
				children: r.problem
			})
		]
	});
}
//#endregion
//#region src/AiEnlarge.tsx
function Rn({ getPicture: e, onEnlarged: t, onRemove: n, applied: r, app: i, sharpen: o }) {
	let [u, d] = a(!1), [f, p] = a(!1), [m, h] = a(""), g = kn("upscale"), _ = i.installed("upscale"), v = m && _.some((e) => e.id === m) ? m : _[0]?.id ?? "", y = On(v), b = g.find((e) => e.recommended), x = async () => {
		d(!0), i.setProblem(null);
		try {
			let n = await e();
			f && o && (n = await o(n)), t(v, await i.client.upscale(n, v));
		} catch (e) {
			i.setProblem(e instanceof Error ? e.message : "The enlarging did not work.");
		} finally {
			d(!1);
		}
	};
	return /* @__PURE__ */ l("div", {
		className: "atl-ai",
		children: [
			/* @__PURE__ */ l("div", {
				className: "atl-ai__title",
				children: [/* @__PURE__ */ c("strong", { children: "Sharpen & enlarge" }), /* @__PURE__ */ c("span", {
					className: "atl-badge atl-badge--free",
					title: "The model runs on your computer. Nothing is sent anywhere and nothing is charged.",
					children: "free · on your computer"
				})]
			}),
			/* @__PURE__ */ c(In, {
				app: i,
				what: {
					intro: "Rebuilds fine detail so the picture is clearly sharper and can be saved larger.",
					install: Q.install(b?.id)
				}
			}),
			i.state === "ready" && (_.length === 0 ? /* @__PURE__ */ l("p", {
				className: "atl-hint",
				children: [
					"No enlarging model is installed yet. Run ",
					/* @__PURE__ */ c("code", { children: Q.install(b?.id) }),
					" (",
					b?.sizeMb,
					" MB), then",
					" ",
					/* @__PURE__ */ c("button", {
						type: "button",
						className: "atl-link",
						onClick: () => void i.check(),
						children: "check again"
					}),
					"."
				]
			}) : /* @__PURE__ */ l(s, { children: [
				/* @__PURE__ */ l("label", {
					className: "atl-control",
					children: [/* @__PURE__ */ c("span", {
						className: "atl-control__row",
						children: /* @__PURE__ */ c("span", { children: "Model" })
					}), /* @__PURE__ */ c("select", {
						value: v,
						onChange: (e) => h(e.target.value),
						children: _.map((e) => /* @__PURE__ */ c("option", {
							value: e.id,
							children: e.name
						}, e.id))
					})]
				}),
				y && /* @__PURE__ */ l("p", {
					className: "atl-hint",
					children: [
						y.summary,
						" ",
						/* @__PURE__ */ c("a", {
							href: y.links.modelCard,
							target: "_blank",
							rel: "noreferrer",
							children: "About this model"
						}),
						" ",
						"· ",
						y.license.name,
						"; check it allows your use. It adds believable detail that was not in the photo."
					]
				}),
				o && /* @__PURE__ */ l("label", {
					className: "atl-control atl-control--inline",
					title: "Re-draws the picture slightly with Stable Diffusion, pinned to the original shapes, so hair, fabric and edges come back crisper. Colours are kept. Free, on your computer.",
					children: [/* @__PURE__ */ c("input", {
						type: "checkbox",
						checked: f,
						onChange: (e) => p(e.target.checked)
					}), "Add detail first (slower, about a minute). Not for a box with small print: it redraws small text as gibberish."]
				}),
				/* @__PURE__ */ l("div", {
					className: "atl-crop-tools",
					children: [/* @__PURE__ */ c("button", {
						type: "button",
						className: "atl-button atl-button--primary",
						disabled: u || !v,
						onClick: () => void x(),
						children: u ? f && o ? "Sharpening… about a minute" : "Enlarging… a few seconds" : r ? "Enlarge again" : "Sharpen & enlarge"
					}), r && /* @__PURE__ */ c("button", {
						type: "button",
						className: "atl-button",
						onClick: n,
						children: "Remove"
					})]
				}),
				r && /* @__PURE__ */ l("p", {
					className: "atl-hint",
					children: [
						"Applied: the saved picture is ",
						r.factor,
						" times larger than the original photo. Do the lettering first: changing it later removes this."
					]
				})
			] })),
			i.problem && /* @__PURE__ */ c("p", {
				className: "atl-error",
				children: i.problem
			})
		]
	});
}
//#endregion
//#region src/PickOverlay.tsx
function zn({ editor: e, width: t, height: n, onPick: r }) {
	return /* @__PURE__ */ c("div", {
		className: "atl-pick",
		style: {
			width: t,
			height: n
		},
		onPointerDown: (t) => {
			t.preventDefault();
			let n = t.currentTarget.getBoundingClientRect(), [i, a] = L(Fe(e.document), (t.clientX - n.left) / n.width, (t.clientY - n.top) / n.height);
			r(Math.min(1, Math.max(0, i)), Math.min(1, Math.max(0, a)));
		}
	});
}
//#endregion
//#region src/AiFill.tsx
function Bn({ buildInput: e, onFilled: t, applied: n, app: r, busyOutside: i }) {
	let [o, u] = a(!1), d = o || !!i, [f, p] = a(!0), m = kn("inpaint"), h = kn("text-detect"), g = r.installed("inpaint")[0], _ = r.installed("text-detect")[0], v = On(g?.id ?? m[0]?.id ?? ""), y = m.find((e) => e.recommended), b = async () => {
		if (g) {
			u(!0), r.setProblem(null);
			try {
				let n = await e({
					otherText: f && !!_,
					textModel: _?.id,
					client: r.client
				});
				n ? t(g.id, await r.client.inpaint(n.picture, g.id), n.cutAway) : r.setProblem("Nothing to fill: no lettering or printed text was found. Try a lower \"How white\" above.");
			} catch (e) {
				r.setProblem(e instanceof Error ? e.message : "The fill did not work.");
			} finally {
				u(!1);
			}
		}
	};
	return /* @__PURE__ */ l("div", {
		className: "atl-ai",
		children: [
			/* @__PURE__ */ l("div", {
				className: "atl-ai__title",
				children: [/* @__PURE__ */ c("strong", { children: "AI fill" }), /* @__PURE__ */ c("span", {
					className: "atl-badge atl-badge--free",
					title: "The model runs on your computer. Nothing is sent anywhere and nothing is charged.",
					children: "free · on your computer"
				})]
			}),
			/* @__PURE__ */ c(In, {
				app: r,
				what: {
					intro: "A cleaner fill than the free one: it repaints hair, fabric and skin where the words were.",
					install: Q.install(y?.id)
				}
			}),
			r.state === "ready" && /* @__PURE__ */ c(s, { children: g ? /* @__PURE__ */ l(s, { children: [
				/* @__PURE__ */ l("p", {
					className: "atl-hint",
					children: [
						v?.summary,
						" ",
						/* @__PURE__ */ c("a", {
							href: v?.links.modelCard,
							target: "_blank",
							rel: "noreferrer",
							children: "About this model"
						}),
						" ",
						"· ",
						v?.license.name,
						" licence. It invents the part hidden under the words, so look closely at the result."
					]
				}),
				/* @__PURE__ */ l("label", {
					className: "atl-control atl-control--inline",
					title: _ ? "Finds other printed text (any colour) and fills it in too" : `Needs the text finder: ${Q.install(h[0]?.id)}`,
					children: [
						/* @__PURE__ */ c("input", {
							type: "checkbox",
							checked: f && !!_,
							disabled: !_,
							onChange: (e) => p(e.target.checked)
						}),
						"Also fill other printed text",
						_ ? "" : " (needs the text finder)"
					]
				}),
				!_ && h[0] && /* @__PURE__ */ l("p", {
					className: "atl-hint",
					children: [
						"Text finder: ",
						h[0].name,
						", ",
						h[0].sizeMb,
						" MB, ",
						h[0].license.name,
						". ",
						/* @__PURE__ */ c("code", { children: Q.install(h[0].id) })
					]
				}),
				/* @__PURE__ */ c("button", {
					type: "button",
					className: "atl-button atl-button--primary",
					disabled: d,
					onClick: () => void b(),
					children: d ? "Filling… a few seconds" : n ? "Fill again with AI" : "Fill with AI"
				})
			] }) : /* @__PURE__ */ l("p", {
				className: "atl-hint",
				children: [
					"No fill model is installed yet (",
					v ? `${v.name}, ${v.sizeMb} MB, ${v.license.name}` : "LaMa",
					"). Run ",
					/* @__PURE__ */ c("code", { children: Q.install(y?.id) }),
					", then",
					" ",
					/* @__PURE__ */ c("button", {
						type: "button",
						className: "atl-link",
						onClick: () => void r.check(),
						children: "check again"
					}),
					"."
				]
			}) }),
			r.problem && /* @__PURE__ */ c("p", {
				className: "atl-error",
				children: r.problem
			})
		]
	});
}
//#endregion
//#region src/AiFinish.tsx
function Vn({ app: e, applied: t, onRedrawArea: n, onCancelArea: r, picking: i, onRemove: o, note: u, busyOutside: d }) {
	let [f, p] = a(!1), m = f || d, [h, g] = a(""), [_, v] = a(!0), y = e.state === "ready" && e.installed("redraw").length > 0;
	return /* @__PURE__ */ l("div", {
		className: "atl-ai",
		children: [
			/* @__PURE__ */ l("div", {
				className: "atl-ai__title",
				children: [/* @__PURE__ */ c("strong", { children: "Finishing touches (AI redraw)" }), /* @__PURE__ */ c("span", {
					className: "atl-badge atl-badge--free",
					title: "The model runs on your computer. Nothing is sent anywhere and nothing is charged.",
					children: "free · on your computer · about 30 s"
				})]
			}),
			/* @__PURE__ */ c(In, {
				app: e,
				what: {
					intro: "Redraws an area you choose, for a part the photo cuts off or something the fill missed. Nothing is invented elsewhere.",
					install: Q.redrawSetup
				}
			}),
			e.state === "ready" && !y && /* @__PURE__ */ l("p", {
				className: "atl-hint",
				children: [
					"The redraw model is not set up yet. Run ",
					/* @__PURE__ */ c("code", { children: Q.redrawSetup }),
					" once (about 7 GB; it asks first), then",
					" ",
					/* @__PURE__ */ c("button", {
						type: "button",
						className: "atl-link",
						onClick: () => void e.check(),
						children: "check again"
					}),
					"."
				]
			}),
			y && /* @__PURE__ */ l(s, { children: [
				/* @__PURE__ */ l("label", {
					className: "atl-control",
					children: [/* @__PURE__ */ c("span", {
						className: "atl-control__row",
						children: /* @__PURE__ */ c("span", { children: "Redraw an area as…" })
					}), /* @__PURE__ */ c("input", {
						className: "atl-input",
						value: h,
						maxLength: 400,
						placeholder: "e.g. smooth blue plastic hair",
						onChange: (e) => g(e.target.value)
					})]
				}),
				/* @__PURE__ */ l("label", {
					className: "atl-control atl-control--inline",
					children: [/* @__PURE__ */ c("input", {
						type: "checkbox",
						checked: _,
						onChange: (e) => v(e.target.checked)
					}), "Keep what is there as a guide (less change)"]
				}),
				/* @__PURE__ */ l("div", {
					className: "atl-crop-tools",
					children: [/* @__PURE__ */ c("button", {
						type: "button",
						className: "atl-button",
						disabled: m || t || !h.trim(),
						onClick: () => i ? r() : n(h.trim(), _),
						children: i ? "Cancel" : "Choose the area…"
					}), t && /* @__PURE__ */ c("button", {
						type: "button",
						className: "atl-button",
						disabled: m,
						onClick: o,
						children: "Remove"
					})]
				}),
				t && /* @__PURE__ */ c("p", {
					className: "atl-hint",
					children: "Applied. This is the last step: changing anything else in the editor takes it off (Undo brings it back)."
				}),
				/* @__PURE__ */ c("p", {
					className: "atl-hint",
					children: "The model draws new pixels, so it can differ from the real item. Check the result before listing, and do not use it where a buyer needs to see the actual condition."
				})
			] }),
			u && /* @__PURE__ */ c("p", {
				className: "atl-hint",
				children: u
			}),
			e.problem && /* @__PURE__ */ c("p", {
				className: "atl-error",
				children: e.problem
			})
		]
	});
}
//#endregion
//#region src/AreaOverlay.tsx
function Hn({ width: e, height: t, onArea: n }) {
	let r = i(null), [o, s] = a(null), l = (e) => {
		let t = e.currentTarget.getBoundingClientRect();
		return {
			x: Math.min(1, Math.max(0, (e.clientX - t.left) / t.width)),
			y: Math.min(1, Math.max(0, (e.clientY - t.top) / t.height))
		};
	}, u = (e, t) => ({
		x: Math.min(e.x, t.x),
		y: Math.min(e.y, t.y),
		width: Math.abs(e.x - t.x),
		height: Math.abs(e.y - t.y)
	});
	return /* @__PURE__ */ c("div", {
		className: "atl-pick",
		style: {
			width: e,
			height: t
		},
		onPointerDown: (e) => {
			e.preventDefault(), e.currentTarget.setPointerCapture(e.pointerId), r.current = l(e), s(null);
		},
		onPointerMove: (e) => r.current && s(u(r.current, l(e))),
		onPointerUp: (e) => {
			if (!r.current) return;
			let t = u(r.current, l(e));
			r.current = null, s(null), t.width > .02 && t.height > .02 && n([
				t.x,
				t.y,
				t.width,
				t.height
			]);
		},
		children: o && /* @__PURE__ */ c("div", {
			className: "atl-area",
			style: {
				left: `${o.x * 100}%`,
				top: `${o.y * 100}%`,
				width: `${o.width * 100}%`,
				height: `${o.height * 100}%`
			}
		})
	});
}
//#endregion
//#region ../heic/src/index.ts
var Un = (e, t, n) => String.fromCharCode(...e.subarray(t, n)), Wn = /* @__PURE__ */ new Set([
	"heic",
	"heix",
	"hevc",
	"hevx",
	"heim",
	"heis"
]);
function Gn(e) {
	if (e.length < 16 || Un(e, 4, 8) !== "ftyp") return !1;
	let t = Math.min(e.length, new DataView(e.buffer, e.byteOffset, e.byteLength).getUint32(0), 256), n = [Un(e, 8, 12)];
	for (let r = 16; r + 4 <= t; r += 4) n.push(Un(e, r, r + 4));
	return n.includes("avif") || n.includes("avis") ? !1 : n.some((e) => Wn.has(e));
}
async function Kn(t) {
	let { default: n } = await import("./heic-decode-CgioNn1B.js").then((t) => /* @__PURE__ */ e(t.default, 1)), { width: r, height: i, data: a } = await n({ buffer: t });
	return {
		width: r,
		height: i,
		data: a instanceof Uint8ClampedArray ? a : new Uint8ClampedArray(a.buffer, a.byteOffset, a.byteLength)
	};
}
//#endregion
//#region src/images.ts
var qn;
function Jn() {
	if (qn === void 0) {
		let e = document.createElement("canvas").getContext("webgl2");
		qn = e ? e.getParameter(e.MAX_TEXTURE_SIZE) : 4096, e?.getExtension("WEBGL_lose_context")?.loseContext();
	}
	return qn;
}
var Yn = 2048;
async function Xn(e) {
	let t = URL.createObjectURL(e);
	try {
		let n = new Image();
		n.src = t, await n.decode();
		let r = n.naturalWidth || Yn, i = n.naturalHeight || Yn;
		if (e.type === "image/svg+xml") {
			let e = Yn / Math.max(r, i);
			r = Math.round(r * e), i = Math.round(i * e);
		}
		let a = document.createElement("canvas");
		return a.width = r, a.height = i, a.getContext("2d").drawImage(n, 0, 0, r, i), await createImageBitmap(a);
	} catch {
		throw Error("This file couldn't be opened as an image. Try a JPEG, PNG, WebP or HEIC.");
	} finally {
		URL.revokeObjectURL(t);
	}
}
async function Zn(e) {
	if (!Gn(new Uint8Array(await e.slice(0, 512).arrayBuffer()))) return null;
	let { width: t, height: n, data: r } = await Kn(new Uint8Array(await e.arrayBuffer()));
	return createImageBitmap(new ImageData(new Uint8ClampedArray(r), t, n));
}
async function Qn(e, t = Jn()) {
	let n;
	try {
		n = await createImageBitmap(e, { imageOrientation: "from-image" });
	} catch {
		n = await Zn(e).catch(() => null) ?? await Xn(e);
	}
	let r = Math.max(n.width, n.height);
	if (r <= t) return n;
	let i = t / r, a = await createImageBitmap(n, {
		resizeWidth: Math.floor(n.width * i),
		resizeHeight: Math.floor(n.height * i),
		resizeQuality: "high"
	});
	return n.close(), a;
}
async function $n(e) {
	let t = Math.min(1, 512 / Math.max(e.width, e.height)), n = Math.max(1, Math.round(e.width * t)), r = Math.max(1, Math.round(e.height * t)), i = document.createElement("canvas");
	i.width = n, i.height = r;
	let a = i.getContext("2d", { willReadFrequently: !0 });
	a.drawImage(e, 0, 0, n, r);
	let o = a.getImageData(0, 0, n, r).data, s = n, c = -1, l = r, u = -1;
	for (let e = 0; e < r; e++) for (let t = 0; t < n; t++) o[(e * n + t) * 4 + 3] > 16 && (t < s && (s = t), t > c && (c = t), e < l && (l = e), e > u && (u = e));
	if (c < 0 || s === 0 && l === 0 && c === n - 1 && u === r - 1) return e;
	let d = Math.max(0, Math.floor((s - 1) / t)), f = Math.max(0, Math.floor((l - 1) / t)), p = Math.min(e.width, Math.ceil((c + 2) / t)), m = Math.min(e.height, Math.ceil((u + 2) / t));
	return createImageBitmap(e, d, f, p - d, m - f);
}
async function er(e, t) {
	let n;
	try {
		n = await fetch(e, {
			mode: "cors",
			signal: t
		});
	} catch (e) {
		throw t?.aborted ? e : Error("The photo couldn't be downloaded. Its server may not allow other sites to read it (CORS).");
	}
	if (!n.ok) throw Error(`The photo couldn't be downloaded (${n.status}).`);
	return n.blob();
}
async function tr(e) {
	let t = document.createElement("canvas");
	t.width = e.width, t.height = e.height;
	let n = new Uint8ClampedArray(e.width * e.height * 4);
	for (let t = 0; t < e.alpha.length; t++) n.set([
		e.alpha[t],
		e.alpha[t],
		e.alpha[t],
		255
	], t * 4);
	return t.getContext("2d").putImageData(new ImageData(n, e.width, e.height), 0, 0), new Promise((e, n) => t.toBlob((t) => t ? e(t) : n(/* @__PURE__ */ Error("The mask could not be saved.")), "image/png"));
}
async function nr(e) {
	let t = await createImageBitmap(e, { colorSpaceConversion: "none" }), n = document.createElement("canvas");
	n.width = t.width, n.height = t.height;
	let r = n.getContext("2d", { willReadFrequently: !0 });
	r.drawImage(t, 0, 0);
	let { data: i } = r.getImageData(0, 0, t.width, t.height), a = new Uint8Array(t.width * t.height);
	for (let e = 0; e < a.length; e++) a[e] = i[e * 4];
	let o = {
		alpha: a,
		width: t.width,
		height: t.height
	};
	return t.close(), o;
}
async function rr(e, t = 1536) {
	let n = Math.min(1, t / Math.max(e.width, e.height)), r = document.createElement("canvas");
	return r.width = Math.max(1, Math.round(e.width * n)), r.height = Math.max(1, Math.round(e.height * n)), r.getContext("2d").drawImage(e, 0, 0, r.width, r.height), new Promise((e, t) => r.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The photo could not be prepared.")), "image/jpeg", .92));
}
async function ir(e, t, n = 1536) {
	let r = {
		...t,
		recipe: {
			...t.recipe,
			ops: {
				...t.recipe.ops,
				canvas: {
					...t.recipe.ops.canvas,
					square: !1,
					margin: 0
				}
			}
		}
	}, { width: i, height: a } = Pe(r, n), o = ze(Fe(r));
	if (!o) throw Error("This crop cannot be used.");
	let s = document.createElement("canvas");
	s.width = i, s.height = a;
	let c = s.getContext("2d");
	return c.fillStyle = "#ffffff", c.fillRect(0, 0, i, a), c.setTransform(i * o.a / e.width, a * o.b / e.width, i * o.c / e.height, a * o.d / e.height, i * o.e, a * o.f), c.drawImage(e, 0, 0), new Promise((e, t) => s.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The crop could not be prepared.")), "image/jpeg", .92));
}
//#endregion
//#region src/ShaderControls.tsx
function ar(e, t, n) {
	let r = t < .1 ? 2 : +(t < 1);
	return `${e.toFixed(r)}${n ?? ""}`;
}
function or({ spec: e, value: t, onChange: n, onBegin: r, onCommit: i }) {
	if (e.kind === "number") {
		let a = Number(t);
		return /* @__PURE__ */ l("label", {
			className: "atl-control",
			children: [/* @__PURE__ */ l("span", {
				className: "atl-control__row",
				children: [/* @__PURE__ */ c("span", { children: e.label }), /* @__PURE__ */ c("output", {
					className: a === e.default ? "" : "is-changed",
					children: ar(a, e.step, e.unit)
				})]
			}), /* @__PURE__ */ c("input", {
				type: "range",
				min: e.min,
				max: e.max,
				step: e.step,
				value: a,
				onPointerDown: r,
				onPointerUp: i,
				onLostPointerCapture: i,
				onChange: (e) => n(Number(e.target.value)),
				onDoubleClick: () => n(e.default)
			})]
		});
	}
	return e.kind === "boolean" ? /* @__PURE__ */ l("label", {
		className: "atl-control atl-control--inline",
		children: [/* @__PURE__ */ c("input", {
			type: "checkbox",
			checked: t === !0,
			onChange: (e) => n(e.target.checked)
		}), e.label]
	}) : e.kind === "color" ? /* @__PURE__ */ l("label", {
		className: "atl-control atl-control--inline",
		children: [/* @__PURE__ */ c("input", {
			type: "color",
			value: String(t),
			"aria-label": e.label,
			onFocus: r,
			onBlur: i,
			onChange: (e) => n(e.target.value)
		}), e.label]
	}) : /* @__PURE__ */ l("label", {
		className: "atl-control",
		children: [/* @__PURE__ */ c("span", {
			className: "atl-control__row",
			children: /* @__PURE__ */ c("span", { children: e.label })
		}), /* @__PURE__ */ c("select", {
			value: String(t),
			onChange: (e) => n(e.target.value),
			children: e.options.map((e) => /* @__PURE__ */ c("option", {
				value: e,
				children: e
			}, e))
		})]
	});
}
function sr({ steps: e, catalog: t, known: n, title: r, empty: i, onAdd: a, onRemove: o, onMove: s, onParam: u, onBegin: d, onCommit: f }) {
	return /* @__PURE__ */ l("section", { children: [
		/* @__PURE__ */ c("h2", { children: r }),
		e.length === 0 && /* @__PURE__ */ c("p", {
			className: "atl-hint",
			children: i
		}),
		e.map((t, r) => {
			let i = n(t.id), a = i ? Mt(i, t.params) : t.params;
			return /* @__PURE__ */ l("div", {
				className: "atl-effect",
				children: [
					/* @__PURE__ */ l("div", {
						className: "atl-effect__head",
						children: [/* @__PURE__ */ c("strong", {
							title: i?.description,
							children: i?.name ?? t.id
						}), /* @__PURE__ */ l("span", {
							className: "atl-effect__buttons",
							children: [
								/* @__PURE__ */ c("button", {
									type: "button",
									className: "atl-button atl-button--small",
									disabled: r === 0,
									onClick: () => s(r, -1),
									"aria-label": "Move up",
									title: "Move up (it runs earlier)",
									children: "↑"
								}),
								/* @__PURE__ */ c("button", {
									type: "button",
									className: "atl-button atl-button--small",
									disabled: r === e.length - 1,
									onClick: () => s(r, 1),
									"aria-label": "Move down",
									title: "Move down (it runs later)",
									children: "↓"
								}),
								/* @__PURE__ */ c("button", {
									type: "button",
									className: "atl-button atl-button--small",
									onClick: () => o(r),
									"aria-label": `Remove ${i?.name ?? t.id}`,
									title: "Remove",
									children: "✕"
								})
							]
						})]
					}),
					!i && /* @__PURE__ */ c("p", {
						className: "atl-hint",
						children: "This effect's shader file is not installed, so it is skipped."
					}),
					i?.params.map((e) => /* @__PURE__ */ c(or, {
						spec: e.spec,
						value: a[e.key] ?? e.spec.default,
						onChange: (t) => u(r, e.key, t, `${i.name}: ${e.spec.label}`),
						onBegin: () => d(`${i.name}: ${e.spec.label}`),
						onCommit: f
					}, e.key))
				]
			}, `${t.id}-${r}`);
		}),
		e.length < 12 && t.length > 0 && /* @__PURE__ */ l("select", {
			className: "atl-effect__add",
			"aria-label": `Add to ${r.toLowerCase()}`,
			value: "",
			onChange: (e) => {
				let n = t.find((t) => t.id === e.target.value);
				n && a(n), e.currentTarget.blur();
			},
			children: [/* @__PURE__ */ c("option", {
				value: "",
				children: "+ Add…"
			}), t.map((e) => /* @__PURE__ */ c("option", {
				value: e.id,
				title: e.description,
				children: e.name
			}, e.id))]
		})
	] });
}
//#endregion
//#region src/Panel.tsx
var cr = [
	{
		tool: "tap",
		label: "Tap",
		title: "Tap the background to remove everything of a similar colour around that point"
	},
	{
		tool: "erase",
		label: "Erase",
		title: "Paint over what should be removed"
	},
	{
		tool: "restore",
		label: "Restore",
		title: "Paint over what should come back"
	}
];
function lr({ editor: e, doc: t, cutout: n, onToggleCutout: r, cutSettings: i, onCutSettings: a, aiCutout: o }) {
	let u = t.recipe.mask.length > 0, d = t.recipe.mask.some((e) => e.kind === "green");
	return /* @__PURE__ */ l("section", { children: [
		/* @__PURE__ */ c("h2", { children: "Background" }),
		/* @__PURE__ */ c("div", {
			className: "atl-crop-tools",
			children: /* @__PURE__ */ c("button", {
				type: "button",
				className: "atl-button",
				disabled: d,
				onClick: () => e.removeGreenBackdrop(),
				title: "For photos shot on a green cloth or screen: makes the green transparent in one click. Free.",
				children: d ? "Green removed" : "Remove green backdrop"
			})
		}),
		/* @__PURE__ */ l("div", {
			className: "atl-crop-tools",
			children: [/* @__PURE__ */ c("button", {
				type: "button",
				className: `atl-button ${n ? "atl-button--primary" : ""}`,
				onClick: r,
				children: n ? "Done" : u ? "Edit cut-out" : "Cut out product"
			}), u && /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("button", {
				type: "button",
				className: "atl-button",
				onClick: () => e.fadeBottom(.1),
				title: "Fade the bottom edge of the cut-out out softly, instead of ending in a hard line (good for a figure cut off at the waist)",
				children: "Fade bottom"
			}), /* @__PURE__ */ c("button", {
				type: "button",
				className: "atl-button",
				onClick: () => e.clearMask(),
				title: "Bring back the whole photo",
				children: "Clear"
			})] })]
		}),
		n && /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("div", {
			className: "atl-segmented",
			role: "group",
			"aria-label": "Cut-out tool",
			children: cr.map(({ tool: e, label: t, title: n }) => /* @__PURE__ */ c("button", {
				type: "button",
				className: `atl-button ${i.tool === e ? "is-active" : ""}`,
				"aria-pressed": i.tool === e,
				title: n,
				onClick: () => a({ tool: e }),
				children: t
			}, e))
		}), i.tool === "tap" ? /* @__PURE__ */ l("label", {
			className: "atl-control",
			children: [/* @__PURE__ */ l("span", {
				className: "atl-control__row",
				children: [/* @__PURE__ */ c("span", { children: "Tolerance" }), /* @__PURE__ */ c("output", { children: i.tolerance })]
			}), /* @__PURE__ */ c("input", {
				type: "range",
				min: 1,
				max: 100,
				step: 1,
				value: i.tolerance,
				onChange: (e) => a({ tolerance: Number(e.target.value) })
			})]
		}) : /* @__PURE__ */ l("label", {
			className: "atl-control",
			children: [/* @__PURE__ */ l("span", {
				className: "atl-control__row",
				children: [/* @__PURE__ */ c("span", { children: "Brush size" }), /* @__PURE__ */ l("output", { children: [Math.round(i.brush * 1e3) / 10, "%"] })]
			}), /* @__PURE__ */ c("input", {
				type: "range",
				min: .003,
				max: .08,
				step: .001,
				value: i.brush,
				onChange: (e) => a({ brush: Number(e.target.value) })
			})]
		})] }),
		o
	] });
}
var ur = [
	{
		key: "lightness",
		label: "How white",
		min: 150,
		max: 255,
		step: 1,
		help: "Lower catches creamier lettering. Too low starts to catch light parts of the picture."
	},
	{
		key: "maxWidth",
		label: "Thickest stroke",
		min: 4,
		max: 80,
		step: 1,
		help: "Fatter white shapes (a bow, a pompom) are left alone."
	},
	{
		key: "minLength",
		label: "Shortest piece",
		min: 5,
		max: 200,
		step: 1,
		help: "Smaller white specks (a glint in an eye) are left alone."
	}
];
function dr({ lookup: e }) {
	let t = {
		found: "✓ Product found online",
		"no-match": "✗ Product not found online",
		"no-pictures": "✗ Product not found online",
		off: "– Web lookup not used"
	}[e.state];
	return /* @__PURE__ */ l("div", {
		className: `atl-lookup is-${e.state}`,
		role: "status",
		children: [
			/* @__PURE__ */ c("strong", { children: t }),
			e.read && /* @__PURE__ */ l("span", {
				className: "atl-hint",
				children: [" · the cover reads: ", e.read]
			}),
			/* @__PURE__ */ c("p", {
				className: "atl-hint",
				children: e.detail
			}),
			e.state === "no-match" || e.state === "no-pictures" ? /* @__PURE__ */ c("p", {
				className: "atl-hint",
				children: "The picture was finished without it. For this product you can give the batch command official pictures with --ref-dir."
			}) : null
		]
	});
}
function fr({ auto: e }) {
	let t = {
		todo: "·",
		running: "…",
		done: "✓",
		skipped: "–"
	}, n = e.full, [r, i] = a(!1), o = n?.report?.listing ? `${n.report.listing.title}\n\nCategory: ${n.report.listing.category}\nSeries: ${n.report.listing.series ?? "(not found)"}\n\n${n.report.listing.description}${n.report.listing.highlights.length ? `\n\n${n.report.listing.highlights.map((e) => `- ${e}`).join("\n")}` : ""}` : "";
	return /* @__PURE__ */ l("section", { children: [
		/* @__PURE__ */ c("h2", { children: "One click" }),
		/* @__PURE__ */ c("button", {
			type: "button",
			className: "atl-button atl-button--primary atl-auto__button",
			disabled: e.busy || !!n && !n.available,
			onClick: e.run,
			title: "Cut out, remove lettering, brighten and sharpen, enlarge, and finish as a white square photo",
			children: e.busy ? "Working…" : "Make it listing-ready"
		}),
		/* @__PURE__ */ l("div", {
			className: "atl-segmented",
			role: "group",
			"aria-label": "What to cut out",
			children: [
				/* @__PURE__ */ c("button", {
					type: "button",
					className: `atl-button ${e.mode === "product" ? "is-active" : ""}`,
					"aria-pressed": e.mode === "product",
					disabled: e.busy,
					onClick: () => e.setMode("product"),
					title: "Keep the whole box or product",
					children: "Whole box"
				}),
				/* @__PURE__ */ c("button", {
					type: "button",
					className: `atl-button ${e.mode === "character" ? "is-active" : ""}`,
					"aria-pressed": e.mode === "character",
					disabled: e.busy,
					onClick: () => e.setMode("character"),
					title: "Keep only the character in the artwork on the cover",
					children: "Character on cover"
				}),
				n && /* @__PURE__ */ c("button", {
					type: "button",
					className: `atl-button ${e.mode === "auto" ? "is-active" : ""}`,
					"aria-pressed": e.mode === "auto",
					disabled: e.busy,
					onClick: () => e.setMode("auto"),
					title: "The character for a flat front cover, the whole box for a box seen at an angle",
					children: "Auto"
				})
			]
		}),
		n && /* @__PURE__ */ l("fieldset", {
			className: "atl-steps",
			disabled: e.busy,
			children: [/* @__PURE__ */ c("legend", { children: "Steps (all on; untick to skip)" }), n.steps.map((t) => /* @__PURE__ */ l("label", {
				className: "atl-control atl-control--inline",
				title: t.title,
				children: [/* @__PURE__ */ c("input", {
					type: "checkbox",
					checked: t.on && !t.disabled,
					disabled: e.busy || t.disabled,
					onChange: (e) => n.setStep(t.key, e.target.checked)
				}), t.label]
			}, t.key))]
		}),
		e.detail?.available && !n && /* @__PURE__ */ l("label", {
			className: "atl-control atl-control--inline",
			title: "Re-draws the picture slightly with Stable Diffusion, pinned to the original shapes, so hair, fabric and edges come back crisper. Free, on your computer, about a minute. Colours are kept.",
			children: [/* @__PURE__ */ c("input", {
				type: "checkbox",
				checked: e.detail.on,
				disabled: e.busy,
				onChange: (t) => e.detail.set(t.target.checked)
			}), "Extra detail (slower, about 1 more minute)"]
		}),
		/* @__PURE__ */ l("p", {
			className: "atl-hint",
			children: [n ? "The Gleamshelf app runs the whole chain on this computer, the same as the batch command, and the finished figure opens here. It takes a few minutes. " : e.greenBackdrop ? "Green backdrop found: it is removed for free. " : e.appReady ? "" : "For anything but a green backdrop, start the Gleamshelf app first (see AI cut-out below). ", !n && "Runs cut-out, brighter and sharper, enlarge, then a white square studio photo. With \"Character on cover\" it first repaints the lettering and printed text from the rest of the picture, then cuts the character out of the clean picture. Every step is still adjustable below, and Undo steps back one at a time."]
		}),
		n?.goBack && /* @__PURE__ */ c("button", {
			type: "button",
			className: "atl-button",
			onClick: n.goBack,
			title: "Close this picture and open the photo as it was",
			children: "Back to the original photo"
		}),
		e.steps && /* @__PURE__ */ c("ul", {
			className: "atl-auto__steps",
			children: e.steps.map((e) => /* @__PURE__ */ l("li", {
				className: `is-${e.state}`,
				children: [
					/* @__PURE__ */ c("span", {
						"aria-hidden": "true",
						children: t[e.state]
					}),
					" ",
					e.label,
					e.note && /* @__PURE__ */ l("span", {
						className: "atl-hint",
						children: [" · ", e.note]
					})
				]
			}, e.label))
		}),
		n?.report && /* @__PURE__ */ l("div", {
			className: "atl-auto__report",
			children: [
				n.report.lookup && /* @__PURE__ */ c(dr, { lookup: n.report.lookup }),
				n.report.notes.map((e) => /* @__PURE__ */ c("p", {
					className: "atl-hint",
					children: e
				}, e)),
				n.report.flags.length > 0 && /* @__PURE__ */ c("ul", {
					className: "atl-auto__flags",
					"aria-label": "Worth a look",
					children: n.report.flags.map((e) => /* @__PURE__ */ c("li", { children: e }, e))
				}),
				n.report.listing && /* @__PURE__ */ l("details", { children: [
					/* @__PURE__ */ c("summary", { children: n.report.listing.title }),
					/* @__PURE__ */ c("textarea", {
						readOnly: !0,
						rows: 11,
						value: o,
						"aria-label": "Title and description"
					}),
					n.report.listing.unsupported.length > 0 && /* @__PURE__ */ l("p", {
						className: "atl-hint",
						children: ["Not found, add by hand: ", n.report.listing.unsupported.join("; ")]
					}),
					n.report.listing.unverifiedNumbers.length > 0 && /* @__PURE__ */ l("p", {
						className: "atl-hint atl-auto__flags",
						children: ["Check these numbers, no source gave them: ", n.report.listing.unverifiedNumbers.join(", ")]
					}),
					/* @__PURE__ */ c("button", {
						type: "button",
						className: "atl-button",
						onClick: () => void navigator.clipboard.writeText(`${n.report.listing.title}\n\n${o.split("\n\n").slice(1).join("\n\n")}`).then(() => i(!0), () => i(!1)),
						children: r ? "Copied" : "Copy"
					})
				] })
			]
		})
	] });
}
function pr({ stickers: e }) {
	return /* @__PURE__ */ l("section", { children: [
		/* @__PURE__ */ c("h2", { children: "Price stickers and printed text" }),
		/* @__PURE__ */ c("button", {
			type: "button",
			className: "atl-button",
			disabled: e.busy,
			onClick: e.run,
			title: "Reads the prices on the photo and paints the shop's price stickers out. Free; needs the Gleamshelf app with the text finder, the text reader and the AI fill.",
			children: e.busy ? "Working…" : "Remove price stickers"
		}),
		/* @__PURE__ */ c("button", {
			type: "button",
			className: `atl-button ${e.picking && !e.pickingText ? "is-active" : ""}`,
			disabled: e.busy,
			onClick: () => e.setPicking(!(e.picking && !e.pickingText)),
			title: "If a sticker was missed, click it on the picture and it is painted out",
			children: e.picking && !e.pickingText ? "Cancel" : "Click a sticker"
		}),
		e.setPickingText && /* @__PURE__ */ c("button", {
			type: "button",
			className: `atl-button ${e.pickingText ? "is-active" : ""}`,
			disabled: e.busy,
			onClick: () => e.setPickingText(!e.pickingText),
			title: "For printed text the automatic search left, such as a big title: click one letter and every letter of that colour in the same text is painted out",
			children: e.pickingText ? "Cancel" : "Click printed text"
		}),
		/* @__PURE__ */ c("p", {
			className: "atl-hint",
			children: e.note ?? "Reads the prices and paints the stickers out, so the photo stays right when the price changes. Free, on your computer."
		})
	] });
}
function mr({ editor: e, doc: t, hasCutout: n, lettering: r, aiFill: i, onRemoveLettering: a }) {
	let o = t.recipe.words;
	return /* @__PURE__ */ l("section", { children: [/* @__PURE__ */ c("h2", { children: "Printed lettering" }), o ? /* @__PURE__ */ l(s, { children: [
		/* @__PURE__ */ l("div", {
			className: "atl-crop-tools",
			children: [/* @__PURE__ */ c("button", {
				type: "button",
				className: "atl-button",
				onClick: () => e.setWords(!1),
				children: "Put lettering back"
			}), /* @__PURE__ */ c("span", {
				className: "atl-hint",
				children: r?.busy ? "Working…" : r && r.filled === 0 ? "No lettering found: try a lower \"How white\"." : r?.filled === -1 ? "Filled with AI." : r?.aiReady ? "Free fill shown; AI fill is ready below." : "Soft free fill. For a clean result set up the AI fill below."
			})]
		}),
		ur.map(({ key: t, label: n, min: r, max: i, step: a, help: s }) => /* @__PURE__ */ l("label", {
			className: "atl-control",
			title: s,
			children: [/* @__PURE__ */ l("span", {
				className: "atl-control__row",
				children: [/* @__PURE__ */ c("span", { children: n }), /* @__PURE__ */ c("output", { children: o[t] })]
			}), /* @__PURE__ */ c("input", {
				type: "range",
				min: r,
				max: i,
				step: a,
				value: o[t],
				onPointerDown: () => e.begin(`Lettering: ${n}`),
				onPointerUp: () => e.commit(),
				onLostPointerCapture: () => e.commit(),
				onChange: (r) => e.setWordsParam(t, Number(r.target.value), `Lettering: ${n}`)
			})]
		}, t)),
		i
	] }) : /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("button", {
		type: "button",
		className: "atl-button",
		onClick: () => a ? a() : e.setWords(!0),
		title: "Paints over white lettering, such as a title written across the picture",
		children: "Remove white lettering"
	}), /* @__PURE__ */ l("p", {
		className: "atl-hint",
		children: [
			"Paints over white words written across the picture, and over other printed text. Free. ",
			n ? "Only the cut-out is touched." : "With no cut-out, the whole picture is searched: cut out first to keep it to the product.",
			" The result is cleanest with the AI fill (set up below once you turn this on); without it the fill is soft."
		]
	})] })] });
}
var hr = [
	{
		mode: "transparent",
		label: "None",
		title: "Keep the cut-out transparent (saves as PNG or WebP)"
	},
	{
		mode: "color",
		label: "Colour",
		title: "A flat colour behind the product"
	},
	{
		mode: "image",
		label: "Photo",
		title: "Your own background photo"
	}
];
function gr({ editor: e, doc: t, onFitProduct: n, onStudio: r, onBackgroundPhoto: i, hasBackgroundPhoto: a, backgroundName: o }) {
	let u = F(t.recipe, "backdrop", "mode"), d = F(t.recipe, "backdrop", "color") || "#ffffff", f = t.recipe.mask.length > 0, p = P(t.recipe, "canvas", "square");
	return /* @__PURE__ */ l("section", { children: [
		/* @__PURE__ */ c("h2", { children: "Behind the product" }),
		r && /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("button", {
			type: "button",
			className: "atl-button atl-button--primary",
			disabled: !f,
			onClick: r,
			title: f ? "White background, the product centred on a square, and a soft shadow" : "Cut the product out first",
			children: "Studio photo: white and square"
		}), /* @__PURE__ */ c("p", {
			className: "atl-hint",
			children: f ? "A listing-ready picture in one click. Change anything below afterwards." : "Cut the product out first."
		})] }),
		/* @__PURE__ */ c("div", {
			className: "atl-segmented",
			role: "group",
			"aria-label": "What is behind the product",
			children: hr.map(({ mode: t, label: n, title: r }) => /* @__PURE__ */ c("button", {
				type: "button",
				className: `atl-button ${u === t ? "is-active" : ""}`,
				"aria-pressed": u === t,
				title: r,
				onClick: () => e.set("recipe/ops/backdrop/mode", t, `Backdrop: ${n}`),
				children: n
			}, t))
		}),
		u === "color" && /* @__PURE__ */ l("label", {
			className: "atl-control atl-control--inline",
			children: [/* @__PURE__ */ c("input", {
				type: "color",
				value: d,
				"aria-label": "Backdrop colour",
				onChange: (t) => e.set("recipe/ops/backdrop/color", t.target.value, "Backdrop colour")
			}), d]
		}),
		u === "image" && /* @__PURE__ */ l("div", {
			className: "atl-control",
			children: [/* @__PURE__ */ l("label", {
				className: "atl-button atl-file",
				children: [a ? "Choose another photo" : "Choose background photo", /* @__PURE__ */ c("input", {
					type: "file",
					accept: "image/*,.heic,.heif",
					onChange: (e) => {
						let t = e.target.files?.[0];
						e.target.value = "", t && i(t);
					}
				})]
			}), /* @__PURE__ */ c("span", {
				className: "atl-hint",
				children: a ? o ?? "Background photo" : "The photo fills the whole picture behind the product."
			})]
		}),
		u !== "transparent" && !f && /* @__PURE__ */ c("p", {
			className: "atl-hint",
			children: "Cut the product out above first, or the photo will cover it."
		}),
		/* @__PURE__ */ l("div", {
			className: "atl-control",
			children: [/* @__PURE__ */ c("span", {
				className: "atl-control__row",
				children: /* @__PURE__ */ c("span", { children: "Square picture" })
			}), /* @__PURE__ */ l("div", {
				className: "atl-crop-tools",
				children: [/* @__PURE__ */ c("button", {
					type: "button",
					className: "atl-button",
					disabled: !f,
					onClick: n,
					title: f ? "Crop to the product and centre it on a square, with space around it" : "Cut the product out first",
					children: "Fit square to product"
				}), /* @__PURE__ */ l("label", {
					className: "atl-control atl-control--inline",
					children: [/* @__PURE__ */ c("input", {
						type: "checkbox",
						checked: p,
						onChange: (t) => e.set("recipe/ops/canvas/square", t.target.checked, "Square canvas")
					}), "Square"]
				})]
			})]
		}),
		p && /* @__PURE__ */ c(br, {
			editor: e,
			type: "canvas",
			name: "margin",
			spec: A("canvas", "margin"),
			value: t.recipe.ops.canvas?.margin
		})
	] });
}
var _r = {
	free: "Free",
	original: "Original",
	"1:1": "Square 1:1",
	"4:5": "Portrait 4:5",
	"3:4": "Portrait 3:4",
	"2:3": "Portrait 2:3",
	"16:9": "Wide 16:9"
};
function vr(e, t) {
	let n = t.step < .1 ? 2 : +(t.step < 1);
	return `${e > 0 && t.min < 0 ? "+" : ""}${e.toFixed(n)}${t.unit ?? ""}`;
}
function yr({ editor: e, path: t, spec: n, value: r }) {
	return /* @__PURE__ */ l("label", {
		className: "atl-control",
		children: [/* @__PURE__ */ l("span", {
			className: "atl-control__row",
			children: [/* @__PURE__ */ c("span", { children: n.label }), /* @__PURE__ */ c("output", {
				className: r === n.default ? "" : "is-changed",
				children: vr(r, n)
			})]
		}), /* @__PURE__ */ c("input", {
			type: "range",
			min: n.min,
			max: n.max,
			step: n.step,
			value: r,
			onPointerDown: () => e.begin(n.label),
			onPointerUp: () => e.commit(),
			onLostPointerCapture: () => e.commit(),
			onChange: (n) => e.set(t, Number(n.target.value)),
			onDoubleClick: () => e.set(t, n.default, `Reset ${n.label}`)
		})]
	});
}
function br({ editor: e, type: t, name: n, spec: r, value: i }) {
	let a = `recipe/ops/${t}/${n}`;
	return r.kind === "number" ? /* @__PURE__ */ c(yr, {
		editor: e,
		path: a,
		spec: r,
		value: typeof i == "number" ? i : r.default
	}) : r.kind === "boolean" ? /* @__PURE__ */ l("label", {
		className: "atl-control atl-control--inline",
		children: [/* @__PURE__ */ c("input", {
			type: "checkbox",
			checked: i === !0,
			onChange: (t) => e.set(a, t.target.checked)
		}), r.label]
	}) : null;
}
function xr(e) {
	let { editor: t, doc: n, cropping: r, onToggleCrop: i, autoEnhance: a, onAutoEnhance: o, aiEnlarge: s } = e, u = F(n.recipe, "crop", "aspect");
	return /* @__PURE__ */ l("div", {
		className: "atl-panel",
		children: [
			e.auto && /* @__PURE__ */ c(fr, { auto: e.auto }),
			/* @__PURE__ */ l("section", { children: [
				/* @__PURE__ */ c("h2", { children: "Geometry" }),
				/* @__PURE__ */ l("div", {
					className: "atl-button-row",
					children: [
						/* @__PURE__ */ c("button", {
							type: "button",
							className: "atl-button",
							onClick: () => t.rotate(-1),
							title: "Rotate left",
							children: "⟲ Left"
						}),
						/* @__PURE__ */ c("button", {
							type: "button",
							className: "atl-button",
							onClick: () => t.rotate(1),
							title: "Rotate right",
							children: "⟳ Right"
						}),
						/* @__PURE__ */ c("button", {
							type: "button",
							className: "atl-button",
							onClick: () => t.flip("horizontal"),
							children: "Flip ↔"
						}),
						/* @__PURE__ */ c("button", {
							type: "button",
							className: "atl-button",
							onClick: () => t.flip("vertical"),
							children: "Flip ↕"
						})
					]
				}),
				/* @__PURE__ */ l("div", {
					className: "atl-control",
					children: [/* @__PURE__ */ c("span", {
						className: "atl-control__row",
						children: /* @__PURE__ */ c("span", { children: "Crop" })
					}), /* @__PURE__ */ l("div", {
						className: "atl-crop-tools",
						children: [/* @__PURE__ */ c("button", {
							type: "button",
							className: `atl-button ${r ? "atl-button--primary" : ""}`,
							onClick: i,
							title: "Crop (C)",
							children: r ? "Done" : "Crop"
						}), /* @__PURE__ */ c("select", {
							"aria-label": "Aspect ratio",
							value: u,
							onChange: (e) => {
								t.setCropAspect(e.target.value), e.currentTarget.blur();
							},
							children: _e.map((e) => /* @__PURE__ */ c("option", {
								value: e,
								children: _r[e]
							}, e))
						})]
					})]
				}),
				/* @__PURE__ */ c(br, {
					editor: t,
					type: "straighten",
					name: "angle",
					spec: A("straighten", "angle"),
					value: n.recipe.ops.straighten?.angle
				})
			] }),
			/* @__PURE__ */ c(lr, { ...e }),
			e.stickers && /* @__PURE__ */ c(pr, { stickers: e.stickers }),
			/* @__PURE__ */ c(mr, { ...e }),
			/* @__PURE__ */ c(gr, { ...e }),
			/* @__PURE__ */ l("section", { children: [
				/* @__PURE__ */ c("h2", { children: "Look" }),
				/* @__PURE__ */ l("div", {
					className: "atl-segmented",
					role: "group",
					"aria-label": "Look",
					children: [/* @__PURE__ */ c("button", {
						type: "button",
						className: "atl-button",
						title: "Back to the photo's own light and colour",
						onClick: () => t.clearLook(),
						children: "Natural"
					}), U.map((e) => /* @__PURE__ */ c("button", {
						type: "button",
						className: "atl-button",
						title: e.description,
						onClick: () => t.applyLook(e.id),
						children: e.label
					}, e.id))]
				}),
				/* @__PURE__ */ c("p", {
					className: "atl-hint",
					children: "Livelier colour and detail, from the photo's own pixels. Fine-tune with the sliders below."
				}),
				o && /* @__PURE__ */ l("label", {
					className: "atl-control atl-control--inline",
					title: "After an AI cut-out or fill, apply the Bright & sharp look, unless you have already set your own",
					children: [/* @__PURE__ */ c("input", {
						type: "checkbox",
						checked: !!a,
						onChange: (e) => o(e.target.checked)
					}), "Brighter and sharper after an AI step"]
				}),
				s
			] }),
			e.aiFinish && /* @__PURE__ */ l("section", { children: [/* @__PURE__ */ c("h2", { children: "Finishing touches" }), e.aiFinish] }),
			ye.filter((e) => e.group !== "geometry" && Object.values(e.params).some((e) => !e.hidden)).map((e) => /* @__PURE__ */ l("section", { children: [/* @__PURE__ */ c("h2", { children: e.label }), Object.entries(e.params).filter(([, e]) => !e.hidden).map(([r, i]) => /* @__PURE__ */ c(br, {
				editor: t,
				type: e.type,
				name: r,
				spec: i,
				value: n.recipe.ops[e.type]?.[r]
			}, r))] }, e.type)),
			/* @__PURE__ */ c(sr, {
				title: "Effects",
				empty: "Add a look from the shaders folder: sharpen, shadow, glow, grain and more.",
				steps: n.recipe.effects,
				catalog: Zt(),
				known: Xt,
				onAdd: (e) => t.addEffect(e.id, jt(e), `Add ${e.name}`),
				onRemove: (e) => t.removeEffect(e),
				onMove: (e, n) => t.moveEffect(e, n),
				onParam: (e, n, r, i) => t.setEffectParam(e, n, r, i),
				onBegin: (e) => t.begin(e),
				onCommit: () => t.commit()
			})
		]
	});
}
//#endregion
//#region src/GleamEditor.tsx
var Sr = (e) => e.ops.backdrop?.mode, Cr = {
	maxSize: 2048,
	type: "image/webp",
	quality: .88
}, wr = 32, Tr = "the same photograph, the surface continued smoothly with the same material, colour and lighting as right around it, nothing new added, sharp focus", Er = "text, letters, words, logo, writing, new objects, pom pom, ball, flower, jewelry, pattern, stain, blotch, blurry, smudge", Dr = (e) => Array.from({ length: Math.floor((e?.length ?? 0) / 4) }, (t, n) => ({
	x: e[n * 4],
	y: e[n * 4 + 1],
	width: e[n * 4 + 2],
	height: e[n * 4 + 3]
})), Or = [
	{
		key: "stickers",
		label: "Remove price stickers",
		title: "Reads the prices on the photo and paints the shop's price stickers out, so the photo stays right when the price changes."
	},
	{
		key: "lettering",
		label: "Repaint lettering and printed text",
		title: "For a character on a cover: paints the title and printed text out from the rest of the picture before the character is cut out. Does nothing for a whole box."
	},
	{
		key: "find",
		label: "Look the product up on the web (free; sends search words, not the photo)",
		title: "Reads the cover with a local model, searches the web (DuckDuckGo) with those words and uses the official pictures it finds. Free. The search words leave this computer; your photo never does."
	},
	{
		key: "thinParts",
		label: "Complete thin parts the box hides",
		title: "Looks again along the character's outline for thin or detached parts, such as an antenna, and completes ones the cover cuts off from the official pictures."
	},
	{
		key: "colour",
		label: "Match colours to the official picture",
		title: "Brings the box's colours to the product's own published picture. Needs the web lookup to find it.",
		needs: "find"
	},
	{
		key: "vivid",
		label: "Punchier colours",
		title: "After colours are matched to an official picture, make them 40% stronger: the punchy look of a ChatGPT redraw. Off keeps the published, softer colours.",
		needs: "colour"
	},
	{
		key: "look",
		label: "Brighten and sharpen",
		title: "The colour and sharpness look applied at the end."
	},
	{
		key: "enlarge",
		label: "Enlarge",
		title: "Makes the picture bigger with a local model. Printed text is enlarged the plain way, so the model cannot rewrite it; everything else gets its extra detail."
	},
	{
		key: "listing",
		label: "Write a title and description",
		title: "Writes a title and description with a local model, only from what was found. Needs the web lookup and the vision model (npm run vlm:setup).",
		needs: "find"
	}
];
function kr({ source: e, name: t, recipe: r, background: o, masks: s, repairs: u, enlargements: d, finishes: f, localApp: p, exportOptions: m, onDone: h, onCancel: g, doneLabel: _ = "Done" }) {
	let [v, y] = a(null), [b, x] = a(null), [S, C] = a(e), [w, T] = a(null), [ee, te] = a(null);
	n(() => {
		C(e), T(null), te(null);
	}, [e]);
	let ne = i(r);
	return n(() => {
		let n = new AbortController(), r = null;
		return y(null), x(null), (async () => {
			try {
				let i = typeof S == "string" ? await er(S, n.signal) : S;
				if (r = await Qn(i), n.signal.aborted) return;
				let a = t ?? (e instanceof File ? e.name : typeof e == "string" ? e.split("/").pop()?.split("?")[0] : void 0), o = ke({
					width: r.width,
					height: r.height,
					name: a
				}, ne.current);
				y({
					image: r,
					editor: new nt(o),
					blob: i
				});
			} catch (e) {
				n.signal.aborted || x(e instanceof Error ? e.message : "This photo couldn't be opened.");
			}
		})(), () => {
			n.abort(), r?.close();
		};
	}, [S, t]), b ? /* @__PURE__ */ l("div", {
		className: "atl-editor atl-editor--message",
		children: [/* @__PURE__ */ c("p", {
			className: "atl-error",
			children: b
		}), g && /* @__PURE__ */ c("button", {
			type: "button",
			className: "atl-button",
			onClick: g,
			children: "Close"
		})]
	}) : v ? /* @__PURE__ */ c(Ar, {
		editor: v.editor,
		image: v.image,
		initialBackground: o,
		initialMasks: s,
		initialRepairs: u,
		initialEnlargements: d,
		initialFinishes: f,
		localApp: p,
		sourceBlob: w ? null : v.blob,
		startFrom: w,
		fullReport: ee,
		onOpenProcessed: async (e, t, n) => {
			let r = await createImageBitmap(e, { premultiplyAlpha: "none" }), i = document.createElement("canvas");
			i.width = r.width, i.height = r.height;
			let a = i.getContext("2d", { willReadFrequently: !0 });
			a.drawImage(r, 0, 0);
			let o = a.getImageData(0, 0, i.width, i.height).data, s = new Uint8Array(i.width * i.height);
			for (let e = 0; e < s.length; e++) s[e] = o[e * 4 + 3];
			a.globalCompositeOperation = "destination-over", a.fillStyle = "#ffffff", a.fillRect(0, 0, i.width, i.height);
			let c = await new Promise((e, t) => i.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png")), l = {
				alpha: s,
				width: i.width,
				height: i.height
			};
			r.close(), T({
				mask: l,
				shadow: t
			}), te(n), C(c);
		},
		onBackToOriginal: w ? () => (T(null), te(null), C(e)) : void 0,
		exportOptions: {
			...Cr,
			...m
		},
		onDone: h,
		onCancel: g,
		doneLabel: _
	}) : /* @__PURE__ */ c("div", {
		className: "atl-editor atl-editor--message",
		children: "Opening photo…"
	});
}
function Ar({ editor: e, image: t, initialBackground: s, initialMasks: u, initialRepairs: d, initialEnlargements: f, initialFinishes: p, localApp: m, sourceBlob: h, startFrom: g, fullReport: _, onOpenProcessed: v, onBackToOriginal: y, exportOptions: w, onDone: T, onCancel: ee, doneLabel: te }) {
	let ne = o(e.subscribe, e.getSnapshot), { doc: E } = ne, ie = i(null), ae = i(null), se = i(null), [D, ce] = a(null), [ue, de] = a({
		width: 0,
		height: 0
	}), [O, fe] = a(!1), [pe, me] = a(!1), [he, ge] = a(!1), [_e, k] = a({
		tool: "tap",
		brush: .02,
		tolerance: 25
	}), [ve, ye] = a(!1), [be, A] = a(null), [j, xe] = a(null), [Se, Ce] = a(() => /* @__PURE__ */ new Map()), Te = E.recipe.finish, M = Te ? Se.get(Te.ref)?.bitmap : void 0, Ee = r(() => M ? Oe({
		width: M.width,
		height: M.height
	}) : null, [M]), De = () => {
		pe || e.clearFinish(), ge(!1), me((e) => !e);
	}, N = () => {
		he || e.clearFinish(), me(!1), ge((e) => !e);
	}, P = r(() => {
		let { width: e, height: n } = b(t.width, t.height), r = document.createElement("canvas");
		r.width = e, r.height = n;
		let i = r.getContext("2d", { willReadFrequently: !0 });
		return i.drawImage(t, 0, 0, e, n), {
			pixels: i.getImageData(0, 0, e, n).data,
			width: e,
			height: n
		};
	}, [t]);
	n(() => {
		try {
			let e = new on(se.current);
			return e.setSource(t), ce(e), () => e.dispose();
		} catch (e) {
			A(e instanceof Error ? e.message : "The preview could not start.");
		}
	}, [t]), n(() => {
		let e = new ResizeObserver(([e]) => {
			let { width: t, height: n } = e.contentRect;
			de({
				width: t,
				height: n
			});
		});
		return e.observe(ae.current), ie.current?.focus({ preventScroll: !0 }), () => e.disconnect();
	}, []);
	let F = r(() => O ? Oe(E.source) : Ee ?? (pe ? Re(E) : E), [
		O,
		pe,
		E,
		Ee
	]), ke = Pe(F), Ae = Pe(Ee ?? E, w.maxSize), I = Math.min((ue.width - wr) / ke.width, (ue.height - wr) / ke.height, 1), je = Math.max(1, Math.floor(ke.width * I)), L = Math.max(1, Math.floor(ke.height * I)), R = E.recipe.mask, Me = r(() => S(P.pixels, P.width, P.height) > .5, [P]), [z, Ne] = a(() => /* @__PURE__ */ new Map()), Fe = i(/* @__PURE__ */ new Map()), Ie = (e, t) => {
		Fe.current.set(e, t), Ne((n) => new Map(n).set(e, t));
	}, Le = () => {
		let t = e.document.recipe.mask;
		return t.length ? x(P.pixels, P.width, P.height, t, Fe.current) : null;
	}, ze = r(() => R.length ? x(P.pixels, P.width, P.height, R, z) : null, [
		R,
		P,
		z
	]), Ve = re(R, z).length;
	n(() => {
		if (!u) return;
		let e = !1;
		return (async () => {
			for (let [t, n] of Object.entries(u)) try {
				let r = await nr(typeof n == "string" ? await er(n) : n);
				e || Ie(t, r);
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [u]);
	let B = (t, n, r, i = !0) => {
		let a = r === "character" ? rt(e.document, n.partsKept ? n : le(n)) : n, o = Array.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(6)), (e) => e.toString(16).padStart(2, "0")).join("");
		Ie(o, a), e.addModelCutout(t, o, { replace: r === "character" }), i && Ke();
	};
	n(() => {
		D && (O || !ze || M ? D.setMask(null) : D.setMask(ze, P.width, P.height, { despill: C(R) }));
	}, [
		D,
		ze,
		R,
		O,
		P,
		M
	]);
	let V = async (e, t) => {
		let n = await Qn(e, Math.min(4096, D?.maxTextureSize ?? 4096));
		xe((r) => (r?.bitmap.close(), {
			bitmap: n,
			blob: e,
			name: t
		}));
	}, He = (t) => {
		A(null), V(t, t.name).then(() => e.set("recipe/ops/backdrop/mode", "image", "Backdrop: Photo"), (e) => A(e instanceof Error ? e.message : "That background photo couldn't be opened."));
	};
	n(() => {
		if (!s) return;
		let e = !1;
		return (async () => {
			try {
				let t = typeof s == "string" ? await er(s) : s;
				e || await V(t, t instanceof File ? t.name : void 0);
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [s, D]), n(() => {
		D?.setBackground(j?.bitmap ?? null);
	}, [D, j]), n(() => () => j?.bitmap.close(), [j]);
	let H = E.recipe.words, U = Fn(m), [Ue, We] = a(() => {
		try {
			return localStorage.getItem("gleamshelf:auto-enhance") !== "off";
		} catch {
			return !0;
		}
	}), Ge = (e) => {
		We(e);
		try {
			localStorage.setItem("gleamshelf:auto-enhance", e ? "on" : "off");
		} catch {}
	}, Ke = () => {
		let t = e.document.recipe, n = t.ops.light?.exposure === 0 && t.ops.color?.vibrance === 0 && !t.effects.some((e) => e.id === "sharpen");
		Ue && n && e.applyLook("bright-sharp");
	}, [qe, Je] = a(!1), [Ye, W] = a(() => /* @__PURE__ */ new Map()), Xe = i(/* @__PURE__ */ new Map()), G = (e, t) => {
		Xe.current.set(e, t), W((n) => new Map(n).set(e, t));
	}, [K, Ze] = a(null), [Qe, $e] = a(!1);
	n(() => {
		if (!d) return;
		let e = !1;
		return (async () => {
			for (let [t, n] of Object.entries(d)) try {
				let r = typeof n == "string" ? await er(n) : n, i = await createImageBitmap(r);
				e || G(t, {
					bitmap: i,
					blob: r
				});
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [d]);
	let et = (e = t) => {
		let n = Math.min(1, 2048 / Math.max(e.width, e.height)), r = Math.max(1, Math.round(e.width * n)), i = Math.max(1, Math.round(e.height * n)), a = document.createElement("canvas");
		a.width = r, a.height = i;
		let o = a.getContext("2d", { willReadFrequently: !0 });
		o.drawImage(e, 0, 0, r, i);
		let s = o.getImageData(0, 0, r, i), c = Le(), l = new Uint8Array(r * i).fill(+!c);
		if (c) for (let e = 0; e < i; e++) {
			let t = Math.min(P.height - 1, Math.floor(e / i * P.height));
			for (let n = 0; n < r; n++) l[e * r + n] = +(c[t * P.width + Math.min(P.width - 1, Math.floor(n / r * P.width))] > 140);
		}
		return {
			w: r,
			h: i,
			pixels: s,
			inside: l
		};
	}, tt = () => U.state === "ready" ? U.installed("inpaint")[0] ?? U.installed("redraw")[0] : void 0, nt = (e, t) => e.task === "redraw" ? U.client.redraw(t.picture, {
		prompt: Tr,
		negative: Er,
		strength: .99,
		steps: 24,
		guidance: 5,
		candidates: 3,
		seed: 5,
		stacked: !!t.region
	}) : U.client.inpaint(t.picture, e.id), it = async (e, n, r = t) => {
		let i = document.createElement("canvas");
		i.width = n.fullWidth, i.height = n.fullHeight;
		let a = i.getContext("2d");
		a.drawImage(r, 0, 0, n.fullWidth, n.fullHeight);
		let o = await createImageBitmap(e);
		return a.drawImage(o, n.x, n.y), o.close(), new Promise((e, t) => i.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be saved.")), "image/png"));
	}, q = () => {
		let n = e.document.recipe.words?.ai;
		return n && Xe.current.get(n.ref)?.bitmap || t;
	}, ut = H?.ai ? Ye.get(H.ai.ref)?.bitmap : void 0;
	n(() => {
		if (!H) {
			Ze((e) => e && (e.owned && e.bitmap.close(), null));
			return;
		}
		if (ut) {
			Ze((e) => (e?.owned && e.bitmap.close(), {
				bitmap: ut,
				filled: -1,
				owned: !1
			})), $e(!1);
			return;
		}
		let e = !1;
		$e(!0);
		let t = setTimeout(async () => {
			let { w: t, h: n, pixels: r, inside: i } = et(), a = Dr(H.stickers), o = a.length ? at(t, n, a, .003) : void 0, { image: s, filled: c } = mt({
				width: t,
				height: n,
				data: r.data
			}, H, i, o, H.lettering !== !1), l = await createImageBitmap(new ImageData(new Uint8ClampedArray(s.data), t, n));
			if (e) return l.close();
			Ze((e) => (e?.owned && e.bitmap.close(), {
				bitmap: l,
				filled: c,
				owned: !0
			})), $e(!1);
		}, 60);
		return () => {
			e = !0, clearTimeout(t);
		};
	}, [
		H,
		ze,
		t,
		P,
		ut
	]), n(() => () => void (K?.owned && K.bitmap.close()), [K]);
	let [dt, ft] = a(() => /* @__PURE__ */ new Map());
	n(() => {
		if (!f) return;
		let e = !1;
		return (async () => {
			for (let [t, n] of Object.entries(f)) try {
				let r = typeof n == "string" ? await er(n) : n, i = await createImageBitmap(r);
				e || ft((e) => new Map(e).set(t, {
					bitmap: i,
					blob: r
				}));
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [f]);
	let ht = E.recipe.upscale, _t = ht ? dt.get(ht.ref)?.bitmap : void 0;
	n(() => {
		if (!D) return;
		let e = M ?? _t ?? K?.bitmap ?? t;
		D.setSource(O ? t : e);
	}, [
		D,
		K,
		_t,
		O,
		t,
		M
	]), n(() => {
		if (!p) return;
		let e = !1;
		return (async () => {
			for (let [t, n] of Object.entries(p)) try {
				let r = typeof n == "string" ? await er(n) : n, i = await createImageBitmap(r);
				e || Ce((e) => new Map(e).set(t, {
					bitmap: i,
					blob: r
				}));
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [p]);
	let [yt, bt] = a(!1), [xt, J] = a(null), [Ct, wt] = a(null), Tt = async () => {
		if (!D) throw Error("The preview is not ready yet.");
		return (await D.export(e.document, {
			type: "image/png",
			maxSize: 1024
		})).blob;
	}, Et = async (t, n) => {
		let r = U.state === "ready" ? U.installed("upscale")[0] : void 0, i = n;
		if (r) try {
			i = await U.client.upscale(n, r.id);
		} catch {}
		let a = await createImageBitmap(i), o = Math.min(2048, D?.maxTextureSize ?? 2048);
		if (Math.max(a.width, a.height) > o) {
			let e = o / Math.max(a.width, a.height), t = await createImageBitmap(a, {
				resizeWidth: Math.floor(a.width * e),
				resizeHeight: Math.floor(a.height * e),
				resizeQuality: "high"
			});
			a.close(), a = t;
			let n = document.createElement("canvas");
			n.width = a.width, n.height = a.height, n.getContext("2d").drawImage(a, 0, 0), i = await new Promise((e, t) => n.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be saved.")), "image/png"));
		}
		let s = Array.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(6)), (e) => e.toString(16).padStart(2, "0")).join("");
		Ce((e) => new Map(e).set(s, {
			bitmap: a,
			blob: i
		})), e.setFinish(t, s);
	}, Dt = () => {
		let e = U.state === "ready" ? U.installed("redraw")[0] : void 0;
		if (!e) throw Error("The redraw model is not ready: start the Gleamshelf app and set it up first.");
		return e;
	}, Ot = async (t) => {
		let n = Ct;
		if (wt(null), n) {
			bt(!0), J(null), A(null);
			try {
				let r = Dt();
				e.commit();
				let i = await U.client.redraw(await Tt(), {
					prompt: n.prompt,
					strength: n.keepShape ? .6 : .99,
					steps: 25,
					box: t
				});
				await Et(r.id, i), J("The area was redrawn. Compare it with the real item before listing.");
			} catch (e) {
				A(e instanceof Error ? `The redraw did not work: ${e.message}` : "The redraw did not work.");
			} finally {
				bt(!1);
			}
		}
	}, kt = async () => {
		let n = e.document.recipe.words?.ai, r = n && Xe.current.get(n.ref)?.bitmap || K?.bitmap || t, i = Math.min(1, 1024 / Math.max(r.width, r.height)), a = document.createElement("canvas");
		return a.width = Math.max(1, Math.round(r.width * i)), a.height = Math.max(1, Math.round(r.height * i)), a.getContext("2d").drawImage(r, 0, 0, a.width, a.height), new Promise((e, t) => a.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png"));
	}, At = async (t, n) => {
		let r = await createImageBitmap(n), i = D?.maxTextureSize ?? 4096;
		if (Math.max(r.width, r.height) > i) {
			let e = i / Math.max(r.width, r.height), t = await createImageBitmap(r, {
				resizeWidth: Math.floor(r.width * e),
				resizeHeight: Math.floor(r.height * e),
				resizeQuality: "high"
			});
			r.close(), r = t;
		}
		let a = Array.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(6)), (e) => e.toString(16).padStart(2, "0")).join("");
		ft((e) => new Map(e).set(a, {
			bitmap: r,
			blob: n
		})), e.setUpscale(t, a);
	}, jt = async (e, { otherText: n, textModel: r, client: i, rebuild: a = !1, from: o = t, smoothOnly: s = !1, body: c, extra: l }) => {
		let u = et(o), { w: d, h: f, pixels: p } = u, m = Math.max(d, f), h = a ? ot(u.inside, d, f, Math.max(4, Math.round(m * .06))) : u.inside, g = e.lettering === !1 ? new Uint8Array(d * f) : pt({
			width: d,
			height: f,
			data: p.data
		}, e, h), _ = Dr(e.stickers);
		_.length && (g = st(g, at(d, f, _, .003)));
		let v = [], y = new Uint8Array(d * f), b = new Uint8Array(d * f), x = 0;
		if (n && r) {
			let e = await i.detectText(await rr(o), r), t = new Uint8Array(d * f);
			for (let n of e) {
				if (n.width * n.height > (a ? .2 : .05)) continue;
				let e = Math.max(0, Math.floor(n.x * d)), r = Math.min(d, Math.ceil((n.x + n.width) * d)), i = Math.max(0, Math.floor(n.y * f)), o = Math.min(f, Math.ceil((n.y + n.height) * f)), s = 0, l = 0;
				for (let t = i; t < o; t++) for (let n = e; n < r; n++) s++, h[t * d + n] || l++;
				if (s) {
					if (a && c) {
						let t = 0, n = 0;
						for (let a = i; a < o; a += 2) for (let i = e; i < r; i += 2) {
							let e = Math.min(c.width - 1, Math.floor(i / d * c.width)), r = Math.min(c.height - 1, Math.floor(a / f * c.height));
							n++, c.alpha[r * c.width + e] > 140 && t++;
						}
						if (n && t / n < .35) {
							let t = Math.max(2, Math.round(m * .004));
							v.push({
								x: Math.max(0, (e - t) / d),
								y: Math.max(0, (i - t) / f),
								width: Math.min(1, (r - e + 2 * t) / d),
								height: Math.min(1, (o - i + 2 * t) / f)
							});
							continue;
						}
					}
					if (l / s >= .2 && !a) {
						let t = Math.max(2, Math.round(m * .004));
						v.push({
							x: Math.max(0, (e - t) / d),
							y: Math.max(0, (i - t) / f),
							width: Math.min(1, (r - e + 2 * t) / d),
							height: Math.min(1, (o - i + 2 * t) / f)
						});
					} else if (a) {
						let e = gt({
							width: d,
							height: f,
							data: p.data
						}, n), r = 0;
						for (let t = 0; t < e.length; t++) r += +!!e[t];
						if (r === 0 && n.width * n.height > .004 && x++, r > n.width * d * n.height * f * .4) {
							x++;
							continue;
						}
						let i = n.height < .02 ? b : t;
						for (let t = 0; t < e.length; t++) e[t] && (i[t] = 1);
					} else for (let n = i; n < o; n++) for (let i = e; i < r; i++) h[n * d + i] && (t[n * d + i] = 1);
				}
			}
			a ? y = t : g = st(g, t);
		}
		if (s) {
			for (let e = 0; e < g.length; e++) (g[e] || y[e]) && (b[e] = 1);
			g = new Uint8Array(d * f), y = new Uint8Array(d * f);
		}
		if (l) {
			if (a) for (let e = 0; e < l.length; e++) y[e] ||= l[e];
			else g = st(g, l);
		}
		let S = b.some(Boolean), C = x;
		if (!g.some(Boolean) && !y.some(Boolean) && !S && v.length === 0) return null;
		g = ot(g, d, f, Math.max(2, Math.round(m * (a ? .0015 : .005)))), y.some(Boolean) && (g = st(g, ot(y, d, f, Math.max(3, Math.round(m * .006)))));
		let w = S ? st(g, ot(b, d, f, Math.max(3, Math.round(m * .009)))) : g;
		if (a) {
			let e = (() => {
				let e = Le();
				return e ? oe(e, P.width, P.height) : null;
			})(), t = .05, n = e ? Math.max(0, Math.floor((e.x - t) * d)) : 0, r = e ? Math.max(0, Math.floor((e.y - t) * f)) : 0, i = e ? Math.min(d, Math.ceil((e.x + e.width + t) * d)) : d, a = e ? Math.min(f, Math.ceil((e.y + e.height + t) * f)) : f, o = i - n, s = a - r, c = ct({
				width: d,
				height: f,
				data: p.data
			}, w).data, l = new Uint8ClampedArray(o * s * 2 * 4);
			for (let e = 0; e < s; e++) for (let t = 0; t < o; t++) {
				let i = ((r + e) * d + n + t) * 4, a = (e * o + t) * 4;
				l[a] = c[i], l[a + 1] = c[i + 1], l[a + 2] = c[i + 2], l[a + 3] = 255;
				let u = ((s + e) * o + t) * 4, f = g[(r + e) * d + n + t] ? 255 : 0;
				l[u] = l[u + 1] = l[u + 2] = f, l[u + 3] = 255;
			}
			let u = 0;
			for (let e = 0; e < w.length; e++) u += +!!w[e];
			if (!g.some(Boolean)) {
				let e = document.createElement("canvas");
				return e.width = o, e.height = s, e.getContext("2d").putImageData(new ImageData(l.slice(0, o * s * 4), o, s), 0, 0), {
					picture: await new Promise((t, n) => e.toBlob((e) => e ? t(e) : n(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png")),
					cutAway: v,
					region: {
						x: n,
						y: r,
						width: o,
						height: s,
						fullWidth: d,
						fullHeight: f
					},
					share: u / w.length,
					skipped: C,
					done: !0
				};
			}
			let m = document.createElement("canvas");
			return m.width = o, m.height = s * 2, m.getContext("2d").putImageData(new ImageData(l, o, s * 2), 0, 0), {
				picture: await new Promise((e, t) => m.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png")),
				cutAway: v,
				region: {
					x: n,
					y: r,
					width: o,
					height: s,
					fullWidth: d,
					fullHeight: f
				},
				share: u / w.length,
				skipped: C
			};
		}
		let T = new Uint8ClampedArray(p.data);
		for (let e = 0; e < d * f; e++) T[e * 4 + 3] = g[e] ? 0 : 255;
		let ee = document.createElement("canvas");
		return ee.width = d, ee.height = f, ee.getContext("2d").putImageData(new ImageData(T, d, f), 0, 0), {
			picture: await new Promise((e, t) => ee.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png")),
			cutAway: v,
			share: 0
		};
	}, Mt = async () => {
		let e = U.installed("text-detect")[0], n = U.installed("text-read")[0];
		if (!e || !n) throw Error("Reading prices needs the text finder and the text reader: install both with the commands in the AI panel.");
		let r = await U.client.readText(await rr(t)), i = /[$＄¥￥]\s*\d|\d\s*[$＄]|\d+\s*円/, { w: a, h: o, pixels: s } = et(), c = {
			width: a,
			height: o,
			data: s.data
		}, l = [];
		for (let e of r) {
			if (!i.test(e.text) || e.score < .5) continue;
			let t = {
				x: Math.max(0, e.x - e.width * .6),
				y: Math.max(0, e.y - e.height * 1),
				width: Math.min(1, e.width * 2.6),
				height: Math.min(1, e.height * 3.2)
			}, n = lt(c, t);
			(n.width * n.height > .06 || n.x === t.x && n.y === t.y && n.width === t.width) && (n = {
				x: Math.max(0, e.x - e.width * .25),
				y: Math.max(0, e.y - e.height * .5),
				width: Math.min(1, e.width * 1.5),
				height: Math.min(1, e.height * 2)
			}), l.length < 28 && l.push(n.x, n.y, Math.min(n.width, 1 - n.x), Math.min(n.height, 1 - n.y));
		}
		return l;
	}, Nt = async (e, { lettering: t, stickerBoxes: n, body: r }) => {
		let i = q(), { w: a, h: o, pixels: s, inside: c } = et(i), l = Math.max(a, o), u = s.data, d = (e) => {
			let t = document.createElement("canvas");
			return t.width = a, t.height = o, t.getContext("2d").putImageData(new ImageData(new Uint8ClampedArray(e), a, o), 0, 0), new Promise((e, n) => t.toBlob((t) => t ? e(t) : n(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png"));
		}, f = async (t) => {
			let n = new Uint8ClampedArray(u);
			for (let e = 0; e < a * o; e++) t[e] && (n[e * 4 + 3] = 0);
			let r = await createImageBitmap(await U.client.inpaint(await d(n), e.id)), i = document.createElement("canvas");
			i.width = a, i.height = o;
			let s = i.getContext("2d", { willReadFrequently: !0 });
			s.drawImage(r, 0, 0, a, o), r.close();
			let c = s.getImageData(0, 0, a, o).data, l = new Uint8ClampedArray(u);
			for (let e = 0; e < a * o; e++) if (t[e]) for (let t = 0; t < 3; t++) l[e * 4 + t] = c[e * 4 + t];
			return l;
		}, p = () => new Uint8Array(a * o), m = p();
		if (t) {
			let e = ot(c, a, o, Math.max(4, Math.round(l * .06)));
			m = ot(pt({
				width: a,
				height: o,
				data: u
			}, { ...we }, e), a, o, Math.max(1, Math.round(l * .001)));
		}
		let h = n.length ? at(a, o, Dr(n), .003) : p(), g = [], _ = 0, v = p(), y = U.installed("text-detect")[0];
		if (t && y) {
			let e = p();
			for (let t of await U.client.detectText(await rr(i), y.id)) {
				if (t.width * t.height > .05) {
					_++;
					continue;
				}
				let n = Math.max(0, Math.floor(t.x * a)), i = Math.min(a, Math.ceil((t.x + t.width) * a)), s = Math.max(0, Math.floor(t.y * o)), c = Math.min(o, Math.ceil((t.y + t.height) * o));
				if (r) {
					let e = 0, t = 0;
					for (let l = s; l < c; l += 2) for (let s = n; s < i; s += 2) {
						let n = Math.min(r.width - 1, Math.floor(s / a * r.width)), i = Math.min(r.height - 1, Math.floor(l / o * r.height));
						t++, r.alpha[i * r.width + n] > 140 && e++;
					}
					if (t && e / t < .35) {
						let e = Math.max(2, Math.round(l * .004));
						g.push({
							x: Math.max(0, (n - e) / a),
							y: Math.max(0, (s - e) / o),
							width: Math.min(1, (i - n + 2 * e) / a),
							height: Math.min(1, (c - s + 2 * e) / o)
						});
						continue;
					}
				}
				let u = Math.max(4, Math.round(l * .005));
				for (let t = Math.max(0, s - u); t < Math.min(o, c + u); t++) for (let r = Math.max(0, n - u); r < Math.min(a, i + u); r++) e[t * a + r] = 1;
			}
			e.some(Boolean) && (v = St({
				width: a,
				height: o,
				data: u
			}, {
				width: a,
				height: o,
				data: await f(e)
			}, e));
		}
		let b = st(st(m, h), v);
		return b.some(Boolean) ? {
			picture: await d(await f(b)),
			cutAway: g,
			skipped: _
		} : {
			picture: null,
			cutAway: g,
			skipped: _
		};
	}, Pt = async ({ lettering: t, stickers: n, add: r = [], body: i }) => {
		let a = tt();
		if (!a) return {
			result: "no-ai",
			stickersFound: 0
		};
		let o = U.installed("text-detect")[0], s = [...e.document.recipe.words?.stickers ?? []], c;
		if (n) {
			s = [];
			try {
				s = await Mt();
			} catch (e) {
				c = e instanceof Error ? e.message : "Price stickers could not be searched for.";
			}
		}
		if (s = [...s, ...r].slice(0, 28), a.task === "inpaint") {
			let n = await Nt(a, {
				lettering: t,
				stickerBoxes: s,
				body: i
			});
			return n.picture ? (e.setWords(!0, {
				lettering: t,
				stickers: s
			}), await Gt(a.id, n.picture, n.cutAway, !1), {
				result: "filled",
				stickersFound: s.length / 4,
				stickerNote: c,
				skipped: n.skipped
			}) : {
				result: "nothing",
				stickersFound: 0,
				stickerNote: c,
				skipped: n.skipped
			};
		}
		let l = {
			...we,
			...t ? {} : { lettering: !1 },
			...s.length ? { stickers: s } : {}
		}, u = await jt(l, {
			otherText: t && !!o,
			textModel: o?.id,
			client: U.client,
			rebuild: a.task === "redraw",
			body: i
		});
		if (!u) return {
			result: "nothing",
			stickersFound: 0,
			stickerNote: c
		};
		let d = u.skipped ?? 0;
		e.setWords(!0, {
			lettering: t,
			stickers: s
		});
		let f = u.done ? u.picture : await nt(a, u);
		if (await Gt(a.id, u.region ? await it(f, u.region) : f, u.cutAway, a.task !== "redraw"), a.task === "redraw" && t) try {
			let e = await jt({ ...we }, {
				otherText: !!o,
				textModel: o?.id,
				client: U.client,
				rebuild: !0,
				from: q(),
				smoothOnly: !0
			});
			if (e?.region && e.share > 0 && e.share < u.share * .5) {
				let t = q(), n = e.done ? e.picture : await nt(a, e);
				await Gt(a.id, await it(n, e.region, t), []);
			}
		} catch {}
		return {
			result: "filled",
			stickersFound: s.length / 4,
			stickerNote: c,
			skipped: d
		};
	}, Ft = async () => {
		if (!tt()) return void e.setWords(!0);
		Je(!0);
		try {
			(await Pt({
				lettering: !0,
				stickers: !!U.installed("text-read")[0]
			})).result === "nothing" && e.setWords(!0);
		} catch (e) {
			A(e instanceof Error ? `The AI fill did not work: ${e.message}` : "The AI fill did not work.");
		} finally {
			Je(!1);
		}
	}, [It, Lt] = a(!1), [Rt, zt] = a("sticker"), Bt = async (t, n) => {
		Lt(!1), Y(null), Je(!0);
		try {
			let { w: r, h: i, pixels: a } = et(), o = {
				x: Math.max(0, t - .06),
				y: Math.max(0, n - .035),
				width: .12,
				height: .07
			}, s = lt({
				width: r,
				height: i,
				data: a.data
			}, o);
			s.width * s.height > .05 && (s = {
				x: Math.max(0, t - .03),
				y: Math.max(0, n - .02),
				width: .06,
				height: .04
			});
			let c = e.document.recipe.words ? e.document.recipe.words.lettering !== !1 : !1, { result: l } = await Pt({
				lettering: c,
				stickers: !1,
				add: [
					s.x,
					s.y,
					Math.min(s.width, 1 - s.x),
					Math.min(s.height, 1 - s.y)
				]
			});
			Y(l === "no-ai" ? "Needs an AI fill: start the Gleamshelf app and set up the redraw model (or install LaMa)." : "Removed the sticker you pointed at.");
		} catch (e) {
			Y(e instanceof Error ? e.message : "The sticker could not be removed.");
		} finally {
			Je(!1);
		}
	}, Vt = async (t, n) => {
		Lt(!1), Y(null), Je(!0);
		try {
			let r = tt();
			if (!r) return void Y("Needs an AI fill: start the Gleamshelf app and set up the redraw model (or install LaMa).");
			let i = q(), { w: a, h: o, pixels: s } = et(i), c = {
				x: t * a,
				y: n * o
			}, l = {
				x0: c.x - a * .3,
				y0: c.y - o * .08,
				x1: c.x + a * .3,
				y1: c.y + o * .08
			}, u = U.installed("text-detect")[0];
			if (u) {
				let e = await U.client.detectText(await rr(i), u.id), r = (e, r) => t >= e.x - r && t <= e.x + e.width + r && n >= e.y - r && n <= e.y + e.height + r, s = (e) => Math.hypot(t - (e.x + e.width / 2), n - (e.y + e.height / 2)), c = e.filter((e) => r(e, 0)).sort((e, t) => e.width * e.height - t.width * t.height)[0] ?? e.filter((e) => r(e, .015)).sort((e, t) => s(e) - s(t))[0], d = .012;
				c && (l = {
					x0: (c.x - d) * a,
					y0: (c.y - d) * o,
					x1: (c.x + c.width + d) * a,
					y1: (c.y + c.height + d) * o
				});
			}
			let d = vt({
				width: a,
				height: o,
				data: s.data
			}, l, c);
			if (!("mask" in d)) return void Y(d.problem === "too-much" ? "That colour covers too much of the area to be sure it is print, so nothing was taken off. Click a letter of the text itself, not the picture behind it." : "No printed text was found at that point. Click right on a letter (a second click takes off a second colour).");
			let f = e.document.recipe.words, p = {
				...f ?? we,
				lettering: !1,
				stickers: void 0,
				ai: void 0
			}, m = await jt(p, {
				otherText: !1,
				client: U.client,
				rebuild: r.task === "redraw",
				from: i,
				extra: d.mask
			});
			if (!m) return void Y("Nothing to take off there.");
			let h = !!e.document.recipe.upscale;
			f || e.setWords(!0, { lettering: !1 });
			let g = m.done ? m.picture : await nt(r, m);
			await Gt(r.id, m.region ? await it(g, m.region, i) : g, [], r.task !== "redraw"), Y(`Took off the printed text you pointed at${h ? " (the enlarging was reset: run Sharpen & enlarge again)" : ""}.`);
		} catch (e) {
			Y(e instanceof Error ? e.message : "The printed text could not be removed.");
		} finally {
			Je(!1);
		}
	}, [Ht, Y] = a(null), Ut = async () => {
		Y(null), Je(!0);
		try {
			let t = e.document.recipe.words ? e.document.recipe.words.lettering !== !1 : !1, { result: n, stickersFound: r, stickerNote: i } = await Pt({
				lettering: t,
				stickers: !0
			});
			Y(n === "no-ai" ? "Needs an AI fill: start the Gleamshelf app and set up the redraw model (or install LaMa)." : i ?? (r ? `Removed ${r} price sticker${r === 1 ? "" : "s"}.` : "No price sticker found. A sticker with no clear price on it can be painted out with the cut-out brush."));
		} catch (e) {
			Y(e instanceof Error ? e.message : "The price stickers could not be removed.");
		} finally {
			Je(!1);
		}
	}, Wt = (e) => {
		let t = Le(), n = t && oe(t, P.width, P.height);
		if (!n) return e;
		let r = e.filter((e) => e.y >= n.y + n.height * .65);
		if (!r.length) return e;
		let i = Math.max(n.y, Math.min(...r.map((e) => e.y)) - .004);
		return [...e.filter((e) => !r.includes(e)), {
			x: 0,
			y: i,
			width: 1,
			height: 1 - i
		}];
	}, Gt = async (t, n, r = [], i = !0) => {
		let a = await createImageBitmap(n), o = Array.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(6)), (e) => e.toString(16).padStart(2, "0")).join("");
		G(o, {
			bitmap: a,
			blob: n
		}), r.length && e.eraseBoxes(i ? Wt(r) : r), e.setWordsAi(t, o), Ke();
	}, Kt = (t) => {
		let n = Le(), r = n && oe(n, P.width, P.height);
		return r ? (e.begin("Studio photo"), e.set("recipe/ops/backdrop/mode", "color"), e.set("recipe/ops/backdrop/color", "#ffffff"), e.fitSquareToProduct(r, .07), t?.shadow !== !1 && !e.effects.some((e) => e.id === "drop-shadow") && e.addEffect("drop-shadow", {
			opacity: .22,
			blur: 16,
			offsetX: 0,
			offsetY: 20,
			color: "#000000"
		}), e.commit(), !0) : !1;
	}, [qt, Jt] = a(() => {
		try {
			let e = localStorage.getItem("gleamshelf:auto-mode");
			return e === "character" || e === "auto" ? e : "product";
		} catch {
			return "product";
		}
	}), Yt = (e) => {
		Jt(e);
		try {
			localStorage.setItem("gleamshelf:auto-mode", e);
		} catch {}
	}, [Xt, Zt] = a(null), [Qt, $t] = a(!1), en = (e, t) => {
		try {
			let n = localStorage.getItem(e);
			return n === null ? t : n === "on";
		} catch {
			return t;
		}
	}, [X, tn] = a(() => Object.fromEntries(Or.map((e) => [e.key, en(`gleamshelf:full-${e.key}`, !0)]))), nn = (e, t) => {
		tn((n) => ({
			...n,
			[e]: t
		}));
		try {
			localStorage.setItem(`gleamshelf:full-${e}`, t ? "on" : "off");
		} catch {}
	}, rn = i(!0);
	n(() => (rn.current = !0, () => {
		rn.current = !1;
	}), []);
	let an = i(!1);
	n(() => {
		g && !an.current && (an.current = !0, B("pipeline", g.mask, "product", !1), Kt({ shadow: g.shadow }));
	}, []);
	let sn = async () => {
		if (Qt || !h) return;
		e.commit(), A(null), $t(!0);
		let t = (e) => Zt(e.map((e) => ({
			label: e.name,
			state: e.state
		})));
		try {
			t([{
				name: "Sending the photo to the Gleamshelf app (it stays on this computer)",
				state: "running"
			}]);
			let e = X.find, n = e && X.colour, r = await U.client.startProcess(h, {
				mode: qt,
				find: e,
				listing: e && X.listing,
				colour: n,
				vivid: n && X.vivid ? 1.4 : 1,
				stickers: X.stickers,
				lettering: X.lettering,
				thinParts: X.thinParts,
				look: X.look,
				enlarge: X.enlarge
			}), i;
			for (;;) {
				if (await new Promise((e) => setTimeout(e, 1200)), !rn.current) return;
				if (i = await U.client.processStatus(r), t(i.steps.length ? i.steps : [{
					name: i.status === "queued" ? "Waiting for the app to finish another job" : "Starting",
					state: "running"
				}]), i.status === "done" || i.status === "failed") break;
			}
			if (i.status === "failed") throw Error(i.error ?? "The app could not finish.");
			await v(await U.client.processPicture(r, "cutout"), i.report?.modeUsed !== "character", i.report ?? null);
		} catch (e) {
			A(e instanceof Error ? `The whole chain did not work: ${e.message}` : "The whole chain did not work.");
		} finally {
			rn.current && $t(!1);
		}
	}, [cn, un] = a(() => {
		try {
			return localStorage.getItem("gleamshelf:auto-detail") === "on";
		} catch {
			return !1;
		}
	}), fn = (e) => {
		un(e);
		try {
			localStorage.setItem("gleamshelf:auto-detail", e ? "on" : "off");
		} catch {}
	}, pn = U.state === "ready" && !!U.installed("enhance")[0] && !!U.installed("redraw")[0], mn = async () => {
		if (Qt) return;
		if (U.canProcess && U.state === "ready" && h) return sn();
		e.commit(), A(null), $t(!0);
		let n = qt === "character", r = cn && pn && n, i = [
			n ? "Cut out the box and crop to it" : "Cut out the product",
			n ? "Repaint lettering, printed text and price stickers" : "Remove price stickers",
			...n ? ["Cut out the character"] : [],
			"Brighter and sharper",
			r ? "Sharpen with detail, then enlarge (about 2 minutes)" : "Sharpen and enlarge",
			n ? "Studio photo (white, square, no shadow)" : "Studio photo (white, square)"
		], a = i.map((e) => ({
			label: e,
			state: "todo"
		})), [o, s, ...c] = [
			0,
			1,
			...i.slice(2).map((e, t) => t + 2)
		], l = n ? c.shift() : -1, [u, d, f] = c, p = (e, t, n) => {
			a[e] = {
				...a[e],
				state: t,
				note: n
			}, Zt([...a]);
		}, m = async (e, t) => {
			p(e, "running");
			try {
				let n = await t();
				a[e].state === "running" && p(e, "done", n || void 0);
			} catch (t) {
				p(e, "skipped", t instanceof Error ? t.message : "This step did not work.");
			}
		}, g = (e, t) => p(e, "skipped", t), _ = U.state === "ready", v = _ ? U.installed("cutout")[0] : void 0, y = (e, t) => {
			throw p(e, "skipped", t), Error(t);
		};
		Zt([...a]);
		try {
			if (await m(o, async () => {
				let r = "";
				if (e.document.recipe.mask.length === 0) {
					if (Me) e.removeGreenBackdrop(), r = "green backdrop removed (free)";
					else if (v) B(v.id, await U.client.cutout(await rr(t), v.id), "product"), r = "AI cut-out";
					else return y(o, "No green backdrop, and the AI cut-out is not available: start the Gleamshelf app and install a cut-out model.");
				} else r = "already cut out";
				if (n) {
					if (!v) return y(o, "Finding the character needs the AI cut-out: start the Gleamshelf app.");
					let t = Le(), n = t && oe(t, P.width, P.height);
					if (n) {
						let t = .06, r = Math.max(0, n.x - n.width * t), i = Math.max(0, n.y - n.height * t);
						e.setCrop(Be(e.document, {
							x: r,
							y: i,
							width: Math.min(1, n.x + n.width * 1.06) - r,
							height: Math.min(1, n.y + n.height * 1.06) - i
						}));
					}
					r += ", cropped to the box";
				}
				return r;
			}), !Le()) {
				for (let e = 1; e < a.length; e++) g(e, "Needs a cut-out first.");
				return;
			}
			await m(s, async () => {
				let r;
				if (n && v) try {
					r = rt(e.document, le(await U.client.cutout(await ir(t, e.document), v.id)));
				} catch {}
				let { result: i, stickersFound: a, stickerNote: o, skipped: c = 0 } = await Pt({
					lettering: n,
					stickers: !0,
					body: r
				});
				return i === "no-ai" ? y(s, "Needs an AI fill: start the Gleamshelf app and set up the redraw model (or install LaMa).") : i === "nothing" ? o ?? (n ? "nothing to remove" : "no price sticker found") : `${n ? "lettering and printed text" : ""}${n && a ? " and " : ""}${a ? `${a} price sticker${a === 1 ? "" : "s"}` : ""} repainted${o ? ` (${o})` : ""}${c ? `; ${c} printed line${c === 1 ? "" : "s"} left, too tangled with the picture to take off safely (take them off with "Click printed text", or crop them out)` : ""}`;
			}), n && await m(l, async () => v ? (B(v.id, await U.client.cutout(await ir(q(), e.document), v.id, void 0, { thinParts: !0 }), "character"), "cut out of the repainted cover") : y(l, "Finding the character needs the AI cut-out: start the Gleamshelf app.")), await m(u, async () => {
				let t = e.document.recipe;
				return Ke(), t === e.document.recipe ? "already set" : void 0;
			}), await m(d, async () => {
				let e = _ ? U.installed("upscale")[0] : void 0;
				if (!e) return y(d, "Needs an enlarging model: start the Gleamshelf app and install one.");
				let t = await kt();
				if (r) try {
					t = await U.client.enhance(t, { strength: .25 });
				} catch (e) {
					A(e instanceof Error ? `The detail sharpening did not work, so the plain enlarge was used: ${e.message}` : "The detail sharpening did not work, so the plain enlarge was used.");
				}
				return await At(e.id, await U.client.upscale(t, e.id)), `${e.name}, saved 2 times larger`;
			}), await m(f, async () => {
				if (n && e.fadeBottom(.15), !Kt({ shadow: !n })) return y(f, "Nothing is cut out.");
			});
		} finally {
			$t(!1);
		}
	}, hn = () => {
		let t = Le(), n = t && oe(t, P.width, P.height);
		n && e.fitSquareToProduct(n);
	};
	n(() => {
		if (!D || ue.width <= 0) return;
		let e = window.devicePixelRatio || 1, t = requestAnimationFrame(() => D.draw(F, Math.round(je * e), Math.round(L * e)));
		return () => cancelAnimationFrame(t);
	}, [
		D,
		F,
		je,
		L,
		ue.width,
		j,
		K,
		O
	]);
	let gn = (t) => {
		let n = t.target;
		if (n.tagName === "SELECT" || n.tagName === "INPUT" && n.type !== "range") return;
		let r = t.type === "keydown", i = t.ctrlKey || t.metaKey, a = t.key.toLowerCase();
		r && i && a === "z" ? (t.preventDefault(), t.shiftKey ? e.redo() : e.undo()) : r && i && a === "y" ? (t.preventDefault(), e.redo()) : t.key === "\\" ? fe(r) : r && !i && a === "c" ? De() : r && t.key === "Escape" && (It || Ct) ? (Lt(!1), wt(null)) : r && (t.key === "Enter" || t.key === "Escape") && (pe || he) && (t.preventDefault(), me(!1), ge(!1));
	}, _n = async () => {
		if (D && !ve) {
			ye(!0), A(null);
			try {
				e.commit();
				let t = await D.export(Ee ?? e.document, w), n = e.document.recipe.upscale?.ref, r = n && dt.get(n) ? { [n]: dt.get(n).blob } : void 0, i = e.document.recipe.words?.ai?.ref, a = i && Ye.get(i) ? { [i]: Ye.get(i).blob } : void 0, o = Sr(e.document.recipe) === "image" && j, s = {};
				for (let t of e.document.recipe.mask) {
					let e = t.kind === "model" ? z.get(t.ref) : void 0;
					t.kind === "model" && e && (s[t.ref] = await tr(e));
				}
				let c = e.document.recipe.finish?.ref, l = c && Se.get(c) ? { [c]: Se.get(c).blob } : void 0;
				T({
					...t,
					finishes: l,
					recipe: e.document.recipe,
					source: e.document.source,
					backgroundPhoto: o ? j.blob : void 0,
					cutoutMasks: Object.keys(s).length ? s : void 0,
					repairs: a,
					enlargements: r
				});
			} catch (e) {
				A(e instanceof Error ? e.message : "The image could not be saved.");
			} finally {
				ye(!1);
			}
		}
	};
	return /* @__PURE__ */ l("div", {
		className: "atl-editor",
		ref: ie,
		tabIndex: -1,
		onKeyDown: gn,
		onKeyUp: gn,
		children: [
			/* @__PURE__ */ l("header", {
				className: "atl-toolbar",
				children: [
					ee && /* @__PURE__ */ c("button", {
						type: "button",
						className: "atl-button",
						onClick: ee,
						children: "Cancel"
					}),
					/* @__PURE__ */ c("span", { className: "atl-toolbar__divider" }),
					/* @__PURE__ */ c("button", {
						type: "button",
						className: "atl-button",
						disabled: !ne.canUndo,
						onClick: () => e.undo(),
						title: ne.undoLabel ? `Undo ${ne.undoLabel} (Ctrl+Z)` : "Undo",
						children: "Undo"
					}),
					/* @__PURE__ */ c("button", {
						type: "button",
						className: "atl-button",
						disabled: !ne.canRedo,
						onClick: () => e.redo(),
						title: ne.redoLabel ? `Redo ${ne.redoLabel} (Ctrl+Shift+Z)` : "Redo",
						children: "Redo"
					}),
					/* @__PURE__ */ c("button", {
						type: "button",
						className: "atl-button",
						onClick: () => e.reset(),
						children: "Reset"
					}),
					/* @__PURE__ */ c("button", {
						type: "button",
						className: `atl-button ${O ? "is-active" : ""}`,
						onPointerDown: () => fe(!0),
						onPointerUp: () => fe(!1),
						onPointerLeave: () => fe(!1),
						title: "Hold to see the original (or hold \\)",
						children: "Compare"
					}),
					/* @__PURE__ */ c("span", { className: "atl-toolbar__spacer" }),
					/* @__PURE__ */ l("span", {
						className: "atl-toolbar__meta",
						children: [
							Ae.width,
							"×",
							Ae.height
						]
					}),
					/* @__PURE__ */ c("button", {
						type: "button",
						className: "atl-button atl-button--primary",
						disabled: !D || ve,
						onClick: () => void _n(),
						children: ve ? "Saving…" : te
					})
				]
			}),
			/* @__PURE__ */ l("main", {
				className: "atl-stage",
				ref: ae,
				children: [
					/* @__PURE__ */ l("div", {
						className: "atl-stage__frame",
						children: [
							/* @__PURE__ */ c("canvas", {
								ref: se,
								className: "atl-stage__canvas",
								style: {
									width: je,
									height: L
								}
							}),
							pe && !O && /* @__PURE__ */ c(ln, {
								editor: e,
								doc: E,
								width: je,
								height: L
							}),
							Ct && !O && !M && /* @__PURE__ */ c(Hn, {
								width: je,
								height: L,
								onArea: (e) => void Ot(e)
							}),
							It && !O && /* @__PURE__ */ c(zn, {
								editor: e,
								width: je,
								height: L,
								onPick: (e, t) => void (Rt === "text" ? Vt(e, t) : Bt(e, t))
							}),
							he && !O && /* @__PURE__ */ c(dn, {
								editor: e,
								doc: E,
								settings: _e,
								width: je,
								height: L
							})
						]
					}),
					O && /* @__PURE__ */ c("span", {
						className: "atl-stage__badge",
						children: "Original"
					}),
					he && !O && /* @__PURE__ */ l("span", {
						className: "atl-stage__badge",
						children: [_e.tool === "tap" ? "Tap the background to remove it" : _e.tool === "erase" ? "Paint to erase" : "Paint to bring back", " · Enter when done"]
					}),
					pe && !O && /* @__PURE__ */ c("span", {
						className: "atl-stage__badge",
						children: "Cropping · Enter when done"
					}),
					Ct && !O && /* @__PURE__ */ c("span", {
						className: "atl-stage__badge",
						children: "Drag a rectangle around the area to redraw · Esc to cancel"
					}),
					It && !O && /* @__PURE__ */ c("span", {
						className: "atl-stage__badge",
						children: Rt === "text" ? "Click a letter of the printed text to remove · Esc to cancel" : "Click the sticker to remove · Esc to cancel"
					}),
					be && /* @__PURE__ */ c("p", {
						className: "atl-error atl-stage__error",
						children: be
					}),
					!be && Ve > 0 && /* @__PURE__ */ c("p", {
						className: "atl-error atl-stage__error",
						children: "This edit used an AI cut-out whose mask was not supplied, so it is not applied. Run the AI cut-out again."
					})
				]
			}),
			/* @__PURE__ */ c("aside", {
				className: "atl-sidebar",
				children: /* @__PURE__ */ c(xr, {
					editor: e,
					doc: E,
					cropping: pe,
					onToggleCrop: De,
					cutout: he,
					onToggleCutout: N,
					cutSettings: _e,
					onCutSettings: (e) => k((t) => ({
						...t,
						...e
					})),
					onFitProduct: hn,
					onStudio: Kt,
					onBackgroundPhoto: He,
					hasBackgroundPhoto: !!j,
					backgroundName: j?.name,
					hasCutout: R.length > 0,
					lettering: {
						busy: Qe || qe,
						filled: K?.filled ?? 0,
						aiReady: !!tt()
					},
					onRemoveLettering: () => void Ft(),
					stickers: {
						run: () => void Ut(),
						busy: qe,
						note: Ht,
						picking: It,
						setPicking: (e) => (zt("sticker"), Lt(e)),
						pickingText: It && Rt === "text",
						setPickingText: (e) => (zt("text"), Lt(e))
					},
					auto: {
						run: () => void mn(),
						busy: Qt,
						mode: qt,
						setMode: Yt,
						steps: Xt,
						appReady: U.state === "ready",
						greenBackdrop: Me,
						full: U.canProcess && U.state === "ready" ? {
							available: !!h,
							steps: Or.map((e) => ({
								...e,
								on: X[e.key],
								disabled: e.needs === "find" && !X.find || e.needs === "colour" && !(X.find && X.colour)
							})),
							setStep: nn,
							report: _,
							goBack: y
						} : void 0,
						detail: {
							available: pn && qt === "character",
							on: cn,
							set: fn
						}
					},
					aiEnlarge: /* @__PURE__ */ c(Rn, {
						app: U,
						sharpen: pn ? (e) => U.client.enhance(e, { strength: .25 }) : null,
						getPicture: kt,
						onEnlarged: (e, t) => void At(e, t),
						onRemove: () => e.clearUpscale(),
						applied: ht && _t ? { factor: ht.factor } : null
					}),
					aiFinish: /* @__PURE__ */ c(Vn, {
						app: U,
						applied: !!M,
						onRedrawArea: (e, t) => (J(null), wt({
							prompt: e,
							keepShape: t
						})),
						onCancelArea: () => wt(null),
						picking: !!Ct,
						onRemove: () => e.clearFinish(),
						note: xt,
						busyOutside: yt
					}),
					autoEnhance: Ue,
					onAutoEnhance: Ge,
					aiFill: /* @__PURE__ */ c(Bn, {
						app: U,
						buildInput: (t) => jt(e.document.recipe.words ?? H ?? we, t),
						onFilled: (e, t, n) => void Gt(e, t, n),
						applied: !!ut,
						busyOutside: qe
					}),
					aiCutout: /* @__PURE__ */ c(Ln, {
						app: U,
						getPhoto: (t) => t === "character" ? ir(q(), e.document) : rr(q()),
						onMask: B,
						greenBackdrop: Me
					})
				})
			})
		]
	});
}
//#endregion
//#region src/GleamEditorModal.tsx
function jr({ open: e, ...t }) {
	return n(() => {
		if (!e) return;
		let t = document.body.style.overflow;
		return document.body.style.overflow = "hidden", () => {
			document.body.style.overflow = t;
		};
	}, [e]), e ? u(/* @__PURE__ */ c("div", {
		className: "atl-modal",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Edit photo",
		children: /* @__PURE__ */ c(kr, { ...t })
	}), document.body) : null;
}
//#endregion
export { kr as GleamEditor, jr as GleamEditorModal, Qn as decodePhoto, er as fetchPhoto, Jn as gpuMaxTextureSize, $n as trimTransparent };

//# sourceMappingURL=index.js.map