import type { LocalHealth, LocalModelStatus } from './types';
/** What a background run of the whole listing chain reports (see the companion app's /process routes). */
export interface ProcessStatus {
    id: string;
    status: 'queued' | 'running' | 'done' | 'failed';
    steps: {
        name: string;
        state: 'running' | 'done';
    }[];
    report?: {
        notes: string[];
        flags: string[];
        modeUsed: string;
        view: string;
        identity: {
            printedTitle: string | null;
            character: string | null;
            franchise: string | null;
        } | null;
        listing: {
            title: string;
            description: string;
            category: string;
            series: string | null;
            highlights: string[];
            unsupported: string[];
            unverifiedNumbers: string[];
            sources: string[];
        } | null;
        /** The product lookup's outcome: whether it was on, whether a picture showing this cover was found, and what it was used for. */
        lookup: {
            state: 'off' | 'found' | 'no-match' | 'no-pictures';
            read: string | null;
            tried: number;
            matched: number;
            bestMatch: number;
            completedParts: number;
            colourFit: number | null;
            detail: string;
        };
    };
    error?: string;
}
export interface ProcessOptions {
    mode?: 'product' | 'character' | 'auto';
    /** Search the web for reference pictures of the product (free; the search words go to DuckDuckGo, the photo stays here). */
    find?: boolean;
    /** Write a title and description with the local model. */
    listing?: boolean;
    /** Colour strength after a reference colour match, 1 to 2 (1 = the product's published colours). */
    vivid?: number;
    enlarge?: boolean;
    /** Steps of the chain; each is on unless set to false. */
    stickers?: boolean;
    /** Repaint lettering and printed text (character covers). */
    lettering?: boolean;
    /** Complete thin or detached parts of the figure. */
    thinParts?: boolean;
    /** Match the colours to the product's published picture (needs `find`). */
    colour?: boolean;
    /** The brighter and sharper look. */
    look?: boolean;
}
export declare class LocalModelError extends Error {
    readonly status: number;
    constructor(status: number, message: string);
}
/** The address the companion app listens on by default. */
export declare const DEFAULT_LOCAL_URL = "http://127.0.0.1:47321";
/**
 * The commands that run the companion app, as a person types them in the repo's folder. One place, so the editor's help,
 * the app's own messages and the docs never disagree.
 */
export declare const LOCAL_COMMANDS: {
    readonly start: "npm run local:start";
    readonly token: "npm run local:token";
    readonly models: "npm run models";
    /** Sets up the redraw model: a Python environment and a 7 GB download, after asking. */
    readonly redrawSetup: "npm run redraw:setup";
    /** The recommended model when no id is given; any other model by its id. */
    readonly install: (id?: string) => string;
};
/** A box around some text, as fractions (0-1) of the picture that was sent. */
export interface TextBox {
    x: number;
    y: number;
    width: number;
    height: number;
}
/** A box around some text with what it says. */
export interface ReadTextBox extends TextBox {
    text: string;
    /** 0-1: how sure the reader is. */
    score: number;
}
export interface CutoutMask {
    /** One byte per pixel: 255 is product, 0 is background. */
    alpha: Uint8Array;
    width: number;
    height: number;
    /** The mask already has stray pieces dropped and its thin or detached parts of the figure added, so it must not be filtered by "keep the main piece" again. */
    partsKept?: boolean;
}
/**
 * Talks to the Gleamshelf companion app running on the user's own computer. The photo never leaves the machine,
 * and running a model there costs nothing. The app is protected by a pairing token the user copies from its window.
 */
export declare class LocalModelClient {
    private readonly options;
    private readonly base;
    private readonly doFetch;
    constructor(options?: {
        url?: string;
        token?: string;
        fetch?: typeof fetch;
    });
    private headers;
    /**
     * Tells "not running" apart from "running, but this browser will not let the page talk to it" (a browser that blocks
     * calls to http://127.0.0.1 from a page, such as Safari). A blocked call and a refused one both look like a network
     * error to the page, so a second, opaque request is tried: it can reach the app even where reading the answer is blocked.
     */
    probe(): Promise<'ok' | 'blocked' | 'offline'>;
    /** Whether the companion app is running here. Never throws: not running is a normal answer. */
    health(): Promise<LocalHealth | null>;
    /**
     * Repaints part of a picture. `picture` is a PNG whose transparent pixels are the ones to fill in (what is kept must be
     * opaque). Returns the finished picture as a PNG, the same size. The first call loads the model; large areas take a while.
     */
    inpaint(picture: Blob, modelId: string, signal?: AbortSignal): Promise<Blob>;
    /** Makes a picture 4 times larger and sharper. Returns a PNG. Large pictures take a while; send at most about 1024 pixels on the long side. */
    upscale(picture: Blob, modelId: string, signal?: AbortSignal): Promise<Blob>;
    /**
     * Redraws part of a picture with the local image model. The part to redraw is the PNG's transparent pixels and/or `box` (normalized
     * x, y, width, height); a rough sketch drawn into the opaque part of the box steers it, and a `strength` below 1 keeps that sketch's
     * shape. With `stacked`, `picture` is an opaque PNG twice as tall as the picture: the picture on top and the part to repaint below it in
     * white, so the pixels under the part to repaint are kept (a transparent PNG loses them). About a minute.
     */
    redraw(picture: Blob, options: {
        prompt: string;
        negative?: string;
        strength?: number;
        steps?: number;
        guidance?: number;
        candidates?: number;
        seed?: number;
        box?: [number, number, number, number];
        stacked?: boolean;
    }, signal?: AbortSignal): Promise<Blob>;
    /**
     * Sharpens a picture (1400 pixels or less) while keeping every shape and, by default, its colours. About a minute for 1024 pixels.
     * `strength` (0.1-0.6) is how far it may be redrawn; low keeps the finest detail exactly where it was.
     */
    enhance(picture: Blob, options?: {
        strength?: number;
        prompt?: string;
        seed?: number;
        keepColour?: boolean;
    }, signal?: AbortSignal): Promise<Blob>;
    /** Finds printed text in a photo and reads it. Needs both the text finder and the text reader installed. */
    readText(photo: Blob, signal?: AbortSignal): Promise<ReadTextBox[]>;
    /** Finds printed text in a photo and returns boxes around it. */
    detectText(photo: Blob, modelId: string, signal?: AbortSignal): Promise<TextBox[]>;
    /** Starts the whole listing chain on a photo in the app (the same chain as the batch command). Returns the job's id at once; follow it with `processStatus`. */
    startProcess(photo: Blob, options?: ProcessOptions, signal?: AbortSignal): Promise<string>;
    processStatus(id: string, signal?: AbortSignal): Promise<ProcessStatus>;
    /** The finished picture of a job: the figure or product alone on a transparent background (`cutout`), or the white square (`studio`). */
    processPicture(id: string, which?: 'cutout' | 'studio', signal?: AbortSignal): Promise<Blob>;
    models(): Promise<LocalModelStatus[]>;
    /** Runs a cut-out model on a photo and returns its mask. The first run of a model loads it, which can take a few seconds. */
    cutout(photo: Blob, modelId: string, signal?: AbortSignal, options?: {
        thinParts?: boolean;
    }): Promise<CutoutMask>;
}
