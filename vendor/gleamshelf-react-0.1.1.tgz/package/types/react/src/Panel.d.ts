import { type Editor, type PhotoDocument } from '../../core/src/index.js';
import { type ReactNode } from 'react';
import type { CutoutSettings } from './CutoutOverlay';
interface Props {
    editor: Editor;
    doc: PhotoDocument;
    cropping: boolean;
    onToggleCrop: () => void;
    cutout: boolean;
    onToggleCutout: () => void;
    cutSettings: CutoutSettings;
    onCutSettings: (change: Partial<CutoutSettings>) => void;
    /** Frames the cut-out product on a square canvas. Only offered once something is cut out. */
    onFitProduct: () => void;
    /** White background, centred on a square, soft shadow: a listing-ready picture in one click. */
    onStudio?: () => void;
    /** Called with a photo the user chose to put behind the product. */
    onBackgroundPhoto: (file: File) => void;
    /** Whether a background photo is loaded, so choosing "Photo" has something to show. */
    hasBackgroundPhoto: boolean;
    backgroundName?: string;
    /** The AI cut-out controls, shown under the cut-out tools. */
    aiCutout?: ReactNode;
    hasCutout?: boolean;
    /** Whether the lettering is being worked out right now, and how many pixels it painted over. */
    lettering?: {
        busy: boolean;
        filled: number;
        aiReady: boolean;
    };
    /** Turns the lettering removal on, and fills with AI straight away when a fill model is available. */
    onRemoveLettering?: () => void;
    /** Whether AI steps also make the picture brighter and sharper, and how to change that. */
    autoEnhance?: boolean;
    onAutoEnhance?: (on: boolean) => void;
    /** The AI fill controls, shown under the lettering settings. */
    aiFill?: ReactNode;
    /** The AI sharpen-and-enlarge controls, shown in the Look section. */
    aiEnlarge?: ReactNode;
    /** The AI redraw controls (complete the antenna, redraw an area), shown in their own section. */
    aiFinish?: ReactNode;
    /** The price sticker button. */
    stickers?: {
        run: () => void;
        busy: boolean;
        note: string | null;
        picking: boolean;
        setPicking: (on: boolean) => void;
        pickingText?: boolean;
        setPickingText?: (on: boolean) => void;
    };
    /** The one-button chain. */
    auto?: {
        run: () => void;
        busy: boolean;
        mode: 'product' | 'character' | 'auto';
        setMode: (mode: 'product' | 'character' | 'auto') => void;
        steps: {
            label: string;
            state: 'todo' | 'running' | 'done' | 'skipped';
            note?: string;
        }[] | null;
        /** The slow extra sharpening with the tile model: whether it is set up, and whether it is switched on. */
        detail?: {
            available: boolean;
            on: boolean;
            set: (on: boolean) => void;
        };
        appReady: boolean;
        greenBackdrop: boolean;
        /** The app can run the whole chain itself (the same as the batch command): its options, and what the last run reported. */
        full?: {
            available: boolean;
            /** Every step of the chain, in order, each switchable and on by default. */
            steps: {
                key: string;
                label: string;
                title: string;
                on: boolean;
                disabled: boolean;
            }[];
            setStep: (key: string, on: boolean) => void;
            report: {
                notes: string[];
                flags: string[];
                modeUsed: string;
                lookup?: {
                    state: 'off' | 'found' | 'no-match' | 'no-pictures';
                    read: string | null;
                    detail: string;
                };
                listing: {
                    title: string;
                    description: string;
                    category: string;
                    series: string | null;
                    highlights: string[];
                    unsupported: string[];
                    unverifiedNumbers: string[];
                    sources: string[];
                } | null;
            } | null;
            /** Set while the picture open is the chain's result: goes back to the photo as it was. */
            goBack?: () => void;
        };
    };
}
/** Controls generated from the op definitions, plus dedicated tools for orientation and crop. */
export declare function Panel(props: Props): import("react").JSX.Element;
export {};
