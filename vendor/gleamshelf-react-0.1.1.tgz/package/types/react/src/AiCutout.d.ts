import { type CutoutMask } from '@gleamshelf/models';
import { useLocalApp } from './useLocalApp';
/** What to cut out: the whole product, or only the character in the artwork on the cover (inside the crop). */
export type CutoutScope = 'product' | 'character';
interface Props {
    /** The photo to cut out, as a file the companion app can read (shrunk is fine: the model works at a fixed size). For `character`, only what is inside the crop. */
    getPhoto: (scope: CutoutScope) => Promise<Blob>;
    /** Called with the mask a model made. For `character` the mask covers the crop, not the whole photo. */
    onMask: (model: string, mask: CutoutMask, scope: CutoutScope) => void;
    /** The photo has a green backdrop all round, so the free green-backdrop button already does the job. */
    greenBackdrop?: boolean;
    /** The connection to the companion app, shared with the other AI controls. */
    app: ReturnType<typeof useLocalApp>;
}
/** Explains what is missing to use a local model, step by step, with the exact commands. Shared by the AI controls. */
export declare function LocalAppHelp({ app, what }: {
    app: ReturnType<typeof useLocalApp>;
    what: {
        intro: string;
        install: string;
    };
}): import("react").JSX.Element | null;
/**
 * Cut the product out with an AI model running on the user's own computer through the Gleamshelf companion app: free,
 * and the photo never leaves the machine. Walks the person through what is missing (app, token, model) with the exact
 * command to run and a link to read about each model first.
 */
export declare function AiCutout({ getPhoto, onMask, greenBackdrop, app }: Props): import("react").JSX.Element;
export {};
