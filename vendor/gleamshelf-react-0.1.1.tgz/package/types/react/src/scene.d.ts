export { GleamScene, type GleamSceneProps, type GleamSceneResult } from './GleamScene';
export type { SceneDocument } from '@gleamshelf/scene3d';
