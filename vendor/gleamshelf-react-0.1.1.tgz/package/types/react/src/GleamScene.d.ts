import { type SceneDocument } from '@gleamshelf/scene3d';
import './gleamshelf.css';
export interface GleamSceneResult {
    blob: Blob;
    width: number;
    height: number;
    /** Save this to reopen the same display later. */
    scene: SceneDocument;
}
export interface GleamSceneProps {
    /** The product image (ideally a cut-out with a transparent background): a File/Blob or a CORS-readable URL. */
    image: Blob | string;
    /** A scene from an earlier result, to reopen it. */
    scene?: unknown;
    /** Pixel size of the saved still. */
    exportSize?: {
        width: number;
        height: number;
    };
    onDone?: (result: GleamSceneResult) => void;
    onCancel?: () => void;
    doneLabel?: string;
}
/**
 * A 3D display for a product image: pick a display, lighting and placement, orbit around it, and save a still.
 * Fills its container.
 */
export declare function GleamScene({ image, scene, exportSize, onDone, onCancel, doneLabel }: GleamSceneProps): import("react").JSX.Element;
