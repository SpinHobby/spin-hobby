import { type PhotoDocument } from '../../core/src/index.js';
import { type ShaderDef } from '@gleamshelf/shaders';
export type ExportType = 'image/webp' | 'image/jpeg' | 'image/png';
export interface ExportOptions {
    /** Longest side of the result in pixels; the full cropped resolution when omitted. */
    maxSize?: number;
    type?: ExportType;
    /** 0–1, for WebP and JPEG. */
    quality?: number;
    /** Lowers the quality step by step until the file fits (WebP and JPEG only). */
    maxBytes?: number;
    /** Fill behind transparent areas when the format has no transparency (JPEG). */
    background?: string;
}
export interface ExportResult {
    blob: Blob;
    width: number;
    height: number;
    /** The format actually produced: browsers without a WebP encoder fall back to JPEG. */
    type: string;
}
/**
 * Draws photo documents with WebGL2. One renderer owns one canvas (the on-screen preview) and one source
 * image; exports render offscreen at the export size, so the preview and the file use the exact same shader.
 */
export declare class Renderer {
    private readonly canvas;
    readonly maxTextureSize: number;
    private readonly gl;
    private readonly program;
    private readonly vao;
    private readonly uniforms;
    private source;
    private mask;
    private maskTexel;
    private despill;
    private background;
    private backgroundSize;
    private readonly effectPrograms;
    private composite;
    private scratch;
    /** 1×1 opaque stand-in, so the mask slot is never empty when there's no cut-out. */
    private readonly noMask;
    constructor(canvas: HTMLCanvasElement);
    /**
     * Uploads the original photo. Its size must not exceed `maxTextureSize`; callers decode large photos
     * smaller first (createImageBitmap with resizeWidth/resizeHeight).
     */
    setSource(image: TexImageSource): void;
    /**
     * The cut-out mask (one alpha byte per pixel, rows top to bottom, covering the whole original), or null for
     * none. Computed by core's computeMask from the recipe; scaled up smoothly when drawn.
     */
    setMask(alpha: Uint8Array | null, width?: number, height?: number, options?: {
        despill?: boolean;
    }): void;
    /**
     * A photo to show behind the product when the document's backdrop is set to `image` (or null for none). It is drawn to
     * cover the whole finished image, like a CSS background-size: cover. Callers decode it smaller than `maxTextureSize` first.
     */
    setBackground(image: (TexImageSource & {
        width: number;
        height: number;
    }) | null): void;
    /** Draws the document onto the preview canvas at `width` × `height` device pixels. */
    draw(doc: PhotoDocument, width: number, height: number): void;
    /** Renders the finished image offscreen and encodes it. */
    export(doc: PhotoDocument, options?: ExportOptions): Promise<ExportResult>;
    dispose(): void;
    /**
     * Compiles an effect and returns why it failed, or null if it works. Lets an editor or a test check a shader file
     * without drawing anything. Effects that fail are skipped when drawing, never fatal.
     */
    compileEffect(def: ShaderDef): string | null;
    private effectProgram;
    private freeScratch;
    /** Two offscreen pictures of the given size to pass the result between effects. Reused until the size changes. */
    private scratchTargets;
    /** Runs one effect: reads `input`, writes `target` (a framebuffer, or null for the screen). */
    private runEffect;
    /** Puts the product over the backdrop, as the last step before image-wide effects. */
    private runComposite;
    private setBackdropUniforms;
    /**
     * Draws the document into `finalTarget` (null is the canvas). With no effects that is one pass. With effects the product
     * is drawn alone first, so a shadow can fall on the backdrop, then effects and the backdrop are applied in order.
     */
    private render;
    /** The photo itself with its adjustments and cut-out; the backdrop only when `withBackdrop` (otherwise transparent behind it). */
    private drawPhoto;
}
