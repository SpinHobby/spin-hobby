import type { Img, Quad } from './image';
/** How far each corner moves toward the centre, as a fraction: leaves the very edge of a face (and the backdrop beyond it) out. */
export declare function insetQuad(quad: Quad, k: number): Quad;
/**
 * The real width/height of a flat face, read from a photo of it: the mean of the top and bottom edges over the mean of the
 * side edges, measured in pixels (the photo's own width and height matter because the corners are fractions).
 */
export declare function quadAspect(quad: Quad, width: number, height: number): number;
/**
 * Cuts a four-cornered area out of a photo and flattens it into a straight rectangle (perspective correction and crop
 * in one step). Everything outside the corners, a hand, a table, a bottle, is gone.
 */
export declare function flattenQuad(src: Img, quad: Quad, outWidth: number, outHeight: number): Img;
