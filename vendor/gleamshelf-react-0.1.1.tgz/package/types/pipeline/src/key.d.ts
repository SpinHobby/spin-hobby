import type { Img } from './image';
/** The share of a photo's border that is green. A photo shot on a green backdrop has a green frame all the way round. */
export declare function greenBorderShare(img: Img): number;
/**
 * Makes a green backdrop transparent. The transparency is worked out in the editor's core (one copy of the rule, so the browser and the command line cut a backdrop out
 * identically); green spill on the product's edges is pulled back here. Free, instant, and it works on any computer.
 */
export declare function keyOutGreen(src: Img): Img;
export { dropWisps } from '../../core/src/index.js';
/** The picture cropped to its visible (non-transparent) part, with a little room around it. Null if nothing is visible. */
export declare function trimToContent(src: Img, padFraction?: number, threshold?: number): Img | null;
