import type { Img, Quad, Rect } from './image';
import type { EnhanceOptions } from './enhance';
import type { SquareOptions } from './compose';
export interface PolishOptions {
    /** Price stickers and shop labels to paint over, as fractions of the original photo. They are filled in from the box around them, first, before anything is cropped. */
    stickers?: Rect[];
    /** Keep only this part of the photo first (fractions of the photo). */
    crop?: Rect;
    /** The corners of a box face in the photo. The face is straightened and becomes the product. */
    face?: {
        quad: Quad; /** How far to pull the corners in so the box edge is not included (0.01 = 1%). */
        inset?: number; /** Longest side of the straightened face in pixels. */
        longSide?: number;
    };
    /** 'auto' removes the backdrop only if the photo has a green frame. 'green' always does. 'none' never does. */
    cutout?: 'auto' | 'green' | 'none';
    enhance?: EnhanceOptions;
    /** The final square. */
    square: SquareOptions;
}
export interface PolishResult {
    image: Img;
    /** What was actually done, in order, so a caller can show it or log it. */
    steps: string[];
}
/**
 * The whole photo-to-listing recipe in one call: crop, straighten a box face, remove a green backdrop, enhance, then place
 * the result on a square canvas. Every step is optional and free; nothing here calls an AI service.
 */
export declare function polishPhoto(src: Img, options: PolishOptions): PolishResult;
/** The same square at several sizes, e.g. a large one for the product page and a small one for lists. */
export declare function exportSizes(square: Img, sizes: number[]): Map<number, Img>;
