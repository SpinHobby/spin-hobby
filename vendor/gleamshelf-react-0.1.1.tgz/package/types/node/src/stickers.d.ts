import type { Rect } from '@gleamshelf/pipeline';
export declare const STICKER_MODEL = "claude-opus-5";
/** What one sticker search usually costs, in US dollars (measured at 0.016 on real box photos; rounded up). */
export declare const STICKER_SEARCH_ESTIMATE_USD = 0.02;
/** Boxes the AI named, clamped into the photo and limited to a few (a sticker is small). */
export declare function sanitizeStickers(raw: unknown): Rect[];
export interface StickerSearch {
    stickers: Rect[];
    inputTokens: number;
    outputTokens: number;
    costUsd: number;
}
/** The part of the Anthropic client this needs, so a test can stand in for it. */
export interface StickerClient {
    messages: {
        create(body: Record<string, unknown>): Promise<{
            content: Array<{
                type: string;
                text?: string;
            }>;
            usage: {
                input_tokens: number;
                output_tokens: number;
            };
        }>;
    };
}
/**
 * Asks Claude where a shop's price stickers and labels are on a photo. This is the one step here that costs money (about
 * two US cents a photo), so the caller has to opt in. The photo is shrunk first, which makes it cheaper and does not
 * change the answer: positions come back as fractions of the whole photo.
 */
export declare function findStickers(photo: Buffer, client?: StickerClient): Promise<StickerSearch>;
