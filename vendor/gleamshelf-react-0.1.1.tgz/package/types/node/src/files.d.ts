import type { Img } from '@gleamshelf/pipeline';
export type ImageFormat = 'jpeg' | 'png' | 'webp';
/**
 * Reads a JPEG, PNG, WebP, AVIF or HEIC (iPhone) photo into plain RGBA pixels, with the camera's rotation applied.
 * HEIC is recognised from the file's own bytes, not its name, and is decoded by @gleamshelf/heic: free, no system tools.
 */
export declare function decodeImage(input: Buffer): Promise<Img>;
export declare function readImage(path: string): Promise<Img>;
export interface EncodeOptions {
    format?: ImageFormat;
    /** 1-100, for JPEG and WebP. */
    quality?: number;
}
/** Encodes pixels to a file's bytes. JPEG has no transparency, so a picture with transparent areas should be PNG or WebP. */
export declare function encodeImage(img: Img, options?: EncodeOptions): Promise<Buffer>;
export declare function writeImage(path: string, img: Img, options?: EncodeOptions): Promise<void>;
/** True if any pixel is not fully opaque. Used to choose PNG over JPEG automatically. */
export declare function hasTransparency(img: Img): boolean;
