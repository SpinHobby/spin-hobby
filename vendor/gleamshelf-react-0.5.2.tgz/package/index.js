import { C as e, E as t, F as n, I as r, L as i, M as a, N as o, P as s, S as c, T as l, _ as u, a as d, b as f, d as p, f as m, g as h, i as g, j as _, m as v, n as y, o as b, p as x, r as S, v as ee, w as C, x as te, y as ne } from "./src-L5EyMOAw.js";
import { _ as re, d as ie, f as ae, g as w, h as oe, i as se, m as T, n as ce, o as E, p as le, s as ue, t as de } from "./Panel-RJVMb4C4.js";
import { a as fe, c as D, i as pe, n as me, o as he, r as ge, s as _e, t as ve } from "./images-CjCrqZ-i.js";
import { t as ye } from "./PhotoLab-BfLodg_q.js";
import { Suspense as be, lazy as xe, useCallback as O, useEffect as k, useLayoutEffect as Se, useMemo as Ce, useRef as A, useState as j, useSyncExternalStore as we } from "react";
import { Fragment as M, jsx as N, jsxs as P } from "react/jsx-runtime";
import { createPortal as Te } from "react-dom";
//#region ../core/src/recolour.ts
var F = (e) => [
	parseInt(e.slice(1, 3), 16) / 255,
	parseInt(e.slice(3, 5), 16) / 255,
	parseInt(e.slice(5, 7), 16) / 255
], Ee = (() => {
	let e = /* @__PURE__ */ new Uint32Array(256);
	for (let t = 0; t < 256; t++) {
		let n = t;
		for (let e = 0; e < 8; e++) n = n & 1 ? 3988292384 ^ n >>> 1 : n >>> 1;
		e[t] = n >>> 0;
	}
	return e;
})();
function De(e) {
	let t = 4294967295;
	for (let n = 0; n < e.length; n++) t = Ee[(t ^ e[n]) & 255] ^ t >>> 8;
	return (t ^ 4294967295) >>> 0;
}
function Oe(e) {
	let t = new TextEncoder(), n = [], r = [], i = 0, a = 23585;
	for (let o of e) {
		let e = t.encode(o.name), s = De(o.bytes), c = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(30));
		c.setUint32(0, 67324752, !0), c.setUint16(4, 20, !0), c.setUint16(6, 2048, !0), c.setUint16(8, 0, !0), c.setUint16(10, 0, !0), c.setUint16(12, a, !0), c.setUint32(14, s, !0), c.setUint32(18, o.bytes.length, !0), c.setUint32(22, o.bytes.length, !0), c.setUint16(26, e.length, !0), n.push(new Uint8Array(c.buffer), e, o.bytes);
		let l = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(46));
		l.setUint32(0, 33639248, !0), l.setUint16(4, 20, !0), l.setUint16(6, 20, !0), l.setUint16(8, 2048, !0), l.setUint16(10, 0, !0), l.setUint16(12, 0, !0), l.setUint16(14, a, !0), l.setUint32(16, s, !0), l.setUint32(20, o.bytes.length, !0), l.setUint32(24, o.bytes.length, !0), l.setUint16(28, e.length, !0), l.setUint32(42, i, !0), r.push(new Uint8Array(l.buffer), e), i += 30 + e.length + o.bytes.length;
	}
	let o = r.reduce((e, t) => e + t.length, 0), s = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(22));
	s.setUint32(0, 101010256, !0), s.setUint16(8, e.length, !0), s.setUint16(10, e.length, !0), s.setUint32(12, o, !0), s.setUint32(16, i, !0);
	let c = [
		...n,
		...r,
		new Uint8Array(s.buffer)
	], l = new Uint8Array(c.reduce((e, t) => e + t.length, 0)), u = 0;
	for (let e of c) l.set(e, u), u += e.length;
	return l;
}
//#endregion
//#region ../shaders/src/compose.ts
var ke = "#version 300 es\nprecision highp float;\nuniform sampler2D uInput;\nuniform vec2 uResolution;\nuniform float uTime;\nuniform bool uFlipY;\nuniform bool uInputFlipped;\nout vec4 outColor;\nvec4 sampleInput(vec2 uv) { return texture(uInput, uInputFlipped ? vec2(uv.x, 1.0 - uv.y) : uv); }\nvec2 perMille(float v) { return v * 0.001 * max(uResolution.x, uResolution.y) / uResolution; }\n", Ae = "\nvoid main() {\n  vec2 uv = gl_FragCoord.xy / uResolution;\n  if (uFlipY) uv.y = 1.0 - uv.y;\n  outColor = effect(uv, sampleInput(uv));\n}\n";
function je(e) {
	return ke + e.source + Ae;
}
//#endregion
//#region src/PhoneCapture.tsx
function Me({ client: e, onOpen: t, onClose: n }) {
	let [r, i] = j(null), [a, o] = j(null), [s, c] = j([]), l = A(/* @__PURE__ */ new Map()), u = A(!1);
	k(() => {
		let t = !1;
		return e.phoneStart().then((e) => !t && i({
			url: e.url,
			qr: `data:image/svg+xml;charset=utf-8,${encodeURIComponent(e.qrSvg)}`
		})).catch((e) => !t && o(e instanceof Error ? e.message : "Phone capture could not start.")), () => {
			t = !0;
		};
	}, [e]), k(() => {
		if (!r) return;
		let t = !1, n = async () => {
			try {
				let n = await e.phonePhotos();
				for (let t of n.slice(0, 12)) if (!l.current.has(t.id) && !/\.hei[cf]$/i.test(t.name)) {
					l.current.set(t.id, "");
					let n = await e.phonePhoto(t.id);
					l.current.set(t.id, URL.createObjectURL(n));
				}
				t || c(n.map((e) => ({
					...e,
					thumb: l.current.get(e.id) || void 0
				})));
			} catch {}
		};
		n();
		let i = setInterval(() => void n(), 1500);
		return () => {
			t = !0, clearInterval(i);
		};
	}, [e, r]), k(() => () => l.current.forEach((e) => e && URL.revokeObjectURL(e)), []), k(() => {
		let e = (e) => {
			e.key === "Escape" && (e.stopPropagation(), n());
		};
		return window.addEventListener("keydown", e, !0), () => window.removeEventListener("keydown", e, !0);
	}, [n]);
	let d = async (n) => {
		if (!u.current) {
			u.current = !0;
			try {
				t(await e.phonePhoto(n.id), n.name);
			} catch (e) {
				o(e instanceof Error ? e.message : "That photo could not be opened.");
			} finally {
				u.current = !1;
			}
		}
	};
	return /* @__PURE__ */ N("div", {
		className: "gs-guide",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Photos from your phone",
		onClick: n,
		children: /* @__PURE__ */ P("div", {
			className: "gs-guide__sheet gs-phone",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ P("header", {
				className: "gs-guide__head",
				children: [/* @__PURE__ */ N("h2", { children: "Photos from your phone" }), /* @__PURE__ */ N("button", {
					type: "button",
					className: "gs-icon-button",
					onClick: n,
					"aria-label": "Close",
					children: /* @__PURE__ */ N(de, { name: "close" })
				})]
			}), /* @__PURE__ */ P("div", {
				className: "gs-phone__body",
				children: [/* @__PURE__ */ P("div", {
					className: "gs-phone__qr",
					children: [
						r ? /* @__PURE__ */ N("img", {
							src: r.qr,
							alt: "QR code to scan with your phone",
							width: 220,
							height: 220
						}) : /* @__PURE__ */ N("div", {
							className: "gs-phone__wait",
							children: a ?? "Starting…"
						}),
						r && /* @__PURE__ */ N("code", {
							className: "gs-phone__url",
							children: r.url
						}),
						/* @__PURE__ */ N(ue, { id: "phone" }),
						/* @__PURE__ */ P("details", {
							className: "gs-phone__trouble",
							children: [/* @__PURE__ */ N("summary", { children: "Phone cannot open the page?" }), /* @__PURE__ */ P("ul", { children: [
								/* @__PURE__ */ N("li", { children: "The phone and this computer must be on the same Wi-Fi. Guest networks usually keep devices apart: use the main one." }),
								/* @__PURE__ */ N("li", { children: "On a Mac, if it asked whether to accept incoming connections for “node”, choose Allow (System Settings › Network › Firewall)." }),
								/* @__PURE__ */ N("li", { children: "Type the address above into the phone’s browser if the camera will not read the code." })
							] })]
						})
					]
				}), /* @__PURE__ */ P("div", {
					className: "gs-phone__list",
					children: [
						/* @__PURE__ */ P("h3", { children: ["Arrived ", s.length ? `(${s.length})` : ""] }),
						!s.length && /* @__PURE__ */ N("p", {
							className: "gs-hint",
							children: "Photos you take or pick on the phone appear here as they arrive."
						}),
						/* @__PURE__ */ N("ul", { children: s.map((e) => /* @__PURE__ */ N("li", { children: /* @__PURE__ */ P("button", {
							type: "button",
							onClick: () => void d(e),
							title: `Open ${e.name} here`,
							children: [e.thumb ? /* @__PURE__ */ N("img", {
								src: e.thumb,
								alt: ""
							}) : /* @__PURE__ */ N("span", {
								className: "gs-phone__name",
								children: e.name
							}), /* @__PURE__ */ N("span", {
								className: "gs-phone__when",
								children: new Date(e.at).toLocaleTimeString([], {
									hour: "2-digit",
									minute: "2-digit"
								})
							})]
						}) }, e.id)) }),
						a && r && /* @__PURE__ */ N("p", {
							className: "gs-hint",
							children: a
						})
					]
				})]
			})]
		})
	});
}
//#endregion
//#region ../pipeline/src/image.ts
var Ne = (e, t, n = [
	0,
	0,
	0,
	0
]) => {
	let r = new Uint8ClampedArray(e * t * 4);
	if (n.some((e) => e !== 0)) for (let e = 0; e < r.length; e += 4) r.set(n, e);
	return {
		width: e,
		height: t,
		data: r
	};
}, Pe = (e) => ({
	width: e.width,
	height: e.height,
	data: new Uint8ClampedArray(e.data)
});
//#endregion
//#region ../pipeline/src/flatten.ts
function Fe(e, t) {
	let n = e.reduce((e, t) => e + t.x, 0) / 4, r = e.reduce((e, t) => e + t.y, 0) / 4;
	return e.map((e) => ({
		x: e.x + (n - e.x) * t,
		y: e.y + (r - e.y) * t
	}));
}
function Ie(e, t, n) {
	let r = e.map((e) => ({
		x: e.x * t,
		y: e.y * n
	})), i = (e, t) => Math.hypot(e.x - t.x, e.y - t.y);
	return (i(r[0], r[1]) + i(r[3], r[2])) / 2 / ((i(r[0], r[3]) + i(r[1], r[2])) / 2);
}
function Le(e) {
	let [t, n, r, i] = e, a = n.x - r.x, o = i.x - r.x, s = t.x - n.x + r.x - i.x, c = n.y - r.y, l = i.y - r.y, u = t.y - n.y + r.y - i.y, d = 0, f = 0;
	if (Math.abs(s) > 1e-9 || Math.abs(u) > 1e-9) {
		let e = a * l - o * c;
		d = (s * l - o * u) / e, f = (a * u - s * c) / e;
	}
	return {
		a: n.x - t.x + d * n.x,
		b: i.x - t.x + f * i.x,
		c: t.x,
		d: n.y - t.y + d * n.y,
		e: i.y - t.y + f * i.y,
		f: t.y,
		g: d,
		h: f
	};
}
function I(e, t, n, r) {
	let i = Le(t.map((t) => ({
		x: t.x * e.width,
		y: t.y * e.height
	}))), a = Ne(n, r), { width: o, height: s, data: c } = e;
	for (let e = 0; e < r; e++) for (let t = 0; t < n; t++) {
		let l = (t + .5) / n, u = (e + .5) / r, d = i.g * l + i.h * u + 1, f = (i.a * l + i.b * u + i.c) / d - .5, p = (i.d * l + i.e * u + i.f) / d - .5, m = Math.max(0, Math.min(o - 2, Math.floor(f))), h = Math.max(0, Math.min(s - 2, Math.floor(p))), g = Math.max(0, Math.min(1, f - m)), _ = Math.max(0, Math.min(1, p - h)), v = (e * n + t) * 4;
		for (let e = 0; e < 4; e++) {
			let t = (t, n) => c[(n * o + t) * 4 + e];
			a.data[v + e] = (t(m, h) * (1 - g) + t(m + 1, h) * g) * (1 - _) + (t(m, h + 1) * (1 - g) + t(m + 1, h + 1) * g) * _;
		}
	}
	return a;
}
var Re = (e, t, n) => (t.x - e.x) * (n.y - e.y) - (t.y - e.y) * (n.x - e.x), L = (e) => {
	let t = 0;
	for (let n = 0; n < e.length; n++) {
		let r = e[n], i = e[(n + 1) % e.length];
		t += r.x * i.y - i.x * r.y;
	}
	return Math.abs(t) / 2;
};
function ze(e, t, n) {
	let r = [];
	for (let i = 0; i < n; i++) {
		let n = -1, a = -1;
		for (let r = 0; r < t; r++) e[i * t + r] >= 128 && (n < 0 && (n = r), a = r);
		n >= 0 && r.push({
			x: n,
			y: i
		}, {
			x: a + 1,
			y: i
		}, {
			x: n,
			y: i + 1
		}, {
			x: a + 1,
			y: i + 1
		});
	}
	if (r.length < 3) return r;
	r.sort((e, t) => e.x - t.x || e.y - t.y);
	let i = [];
	for (let e of r) {
		for (; i.length >= 2 && Re(i[i.length - 2], i[i.length - 1], e) <= 0;) i.pop();
		i.push(e);
	}
	let a = [];
	for (let e = r.length - 1; e >= 0; e--) {
		let t = r[e];
		for (; a.length >= 2 && Re(a[a.length - 2], a[a.length - 1], t) <= 0;) a.pop();
		a.push(t);
	}
	return [...i.slice(0, -1), ...a.slice(0, -1)];
}
function Be(e, t, n) {
	let r = ze(e, t, n);
	if (r.length < 4) return null;
	let i = r.length, a = (e) => r.reduce((t, n, i) => e(n) > e(r[t]) ? i : t, 0), o = [
		a((e) => -e.x - e.y),
		a((e) => e.x - e.y),
		a((e) => e.x + e.y),
		a((e) => -e.x + e.y)
	], s = (e) => L(e.map((e) => r[e]));
	for (let e = 0; e < 50; e++) {
		let e = !1;
		for (let t = 0; t < 4; t++) for (let n of [1, -1]) for (;;) {
			let r = [...o];
			if (r[t] = (o[t] + n + i) % i, r[t] === o[(t + 1) % 4] || r[t] === o[(t + 3) % 4] || s(r) <= s(o) + 1e-9) break;
			o[t] = r[t], e = !0;
		}
		if (!e) break;
	}
	let c = o.map((e) => r[e]), l = c.reduce((e, t) => e + t.x, 0) / 4, u = c.reduce((e, t) => e + t.y, 0) / 4;
	c.sort((e, t) => Math.atan2(e.y - u, e.x - l) - Math.atan2(t.y - u, t.x - l));
	let d = c.reduce((e, t, n) => t.x + t.y < c[e].x + c[e].y ? n : e, 0), f = [...c.slice(d), ...c.slice(0, d)], p = 0, m = 0, h = 0, g = (e, t) => {
		for (let n = 0; n < 4; n++) if (Re(f[n], f[(n + 1) % 4], {
			x: e,
			y: t
		}) < 0) return !1;
		return !0;
	}, _ = Math.max(1, Math.floor(Math.max(t, n) / 300));
	for (let r = 0; r < n; r += _) for (let n = 0; n < t; n += _) {
		let i = e[r * t + n] >= 128, a = g(n + .5, r + .5);
		i && p++, a && m++, i && a && h++;
	}
	let v = p ? h / p : 0, y = m ? h / m : 0;
	return {
		quad: f.map((e) => ({
			x: e.x / t,
			y: e.y / n
		})),
		covers: v,
		fills: y,
		flat: v > .97 && y > .95
	};
}
function Ve(e, t, n, r) {
	let i = Be(t, n, r);
	if (!i || !i.flat) return null;
	let a = Ie(i.quad, e.width, e.height), o = i.quad.map((t) => ({
		x: t.x * e.width,
		y: t.y * e.height
	})), s = (e, t) => Math.hypot(e.x - t.x, e.y - t.y), c = Math.max(s(o[0], o[1]), s(o[3], o[2]), s(o[0], o[3]), s(o[1], o[2])), l = Math.max(8, Math.round(a >= 1 ? c : c * a)), u = Math.max(8, Math.round(a >= 1 ? c / a : c)), d = I(e, Fe(i.quad, .004), l, u);
	for (let e = 3; e < d.data.length; e += 4) d.data[e] = 255;
	return {
		image: d,
		quad: i.quad
	};
}
//#endregion
//#region ../pipeline/src/inpaint.ts
function He(e, t, n, r = 0, i = r) {
	let a = new Uint8Array(e * t);
	for (let o of n) {
		let n = Math.max(0, Math.floor((o.x - r) * e)), s = Math.max(0, Math.floor((o.y - i) * t)), c = Math.min(e, Math.ceil((o.x + o.width + r) * e)), l = Math.min(t, Math.ceil((o.y + o.height + i) * t));
		for (let t = s; t < l; t++) for (let r = n; r < c; r++) a[t * e + r] = 1;
	}
	return a;
}
function Ue(e, t, n, r) {
	let i = new Uint8Array(e.length);
	for (let a = 0; a < n; a++) for (let o = 0; o < t; o++) if (e[a * t + o]) for (let e = -r; e <= r; e++) for (let s = -r; s <= r; s++) {
		let r = o + s, c = a + e;
		r >= 0 && c >= 0 && r < t && c < n && (i[c * t + r] = 1);
	}
	return i;
}
var We = (...e) => {
	let t = new Uint8Array(e[0].length);
	for (let n of e) for (let e = 0; e < t.length; e++) n[e] && (t[e] = 1);
	return t;
};
function Ge(e, t) {
	let { width: n, height: r, data: i } = e, a = null, o = 0, s = 0;
	for (let e of [
		8,
		4,
		2,
		1
	]) {
		let c = Math.max(2, Math.floor(n / e)), l = Math.max(2, Math.floor(r / e)), u = new Float32Array(c * l * 3), d = new Uint8Array(c * l);
		for (let e = 0; e < l; e++) for (let f = 0; f < c; f++) {
			let p = Math.floor(f * n / c), m = Math.floor(e * r / l), h = Math.max(p + 1, Math.floor((f + 1) * n / c)), g = Math.max(m + 1, Math.floor((e + 1) * r / l)), _ = 0, v = 0, y = 0, b = 0, x = 0;
			for (let e = m; e < g; e++) for (let r = p; r < h; r++) if (v++, !t[e * n + r]) {
				_++;
				let t = (e * n + r) * 4;
				y += i[t], b += i[t + 1], x += i[t + 2];
			}
			let S = e * c + f;
			if (_ === v) u[S * 3] = y / _, u[S * 3 + 1] = b / _, u[S * 3 + 2] = x / _;
			else if (d[S] = 1, a) {
				let t = (Math.min(s - 1, Math.floor(e * s / l)) * o + Math.min(o - 1, Math.floor(f * o / c))) * 3;
				u[S * 3] = a[t], u[S * 3 + 1] = a[t + 1], u[S * 3 + 2] = a[t + 2];
			} else _ ? (u[S * 3] = y / _, u[S * 3 + 1] = b / _, u[S * 3 + 2] = x / _) : u[S * 3] = u[S * 3 + 1] = u[S * 3 + 2] = 128;
		}
		let f = e === 1 ? 60 : 250;
		for (let e = 0; e < f; e++) for (let e = 0; e < l; e++) for (let t = 0; t < c; t++) {
			let n = e * c + t;
			if (!d[n]) continue;
			let r = t > 0 ? n - 1 : n, i = t < c - 1 ? n + 1 : n, a = e > 0 ? n - c : n, o = e < l - 1 ? n + c : n;
			for (let e = 0; e < 3; e++) u[n * 3 + e] = (u[r * 3 + e] + u[i * 3 + e] + u[a * 3 + e] + u[o * 3 + e]) / 4;
		}
		a = u, o = c, s = l;
	}
	let c = Pe(e);
	if (a) {
		for (let e = 0; e < n * r; e++) if (t[e]) for (let t = 0; t < 3; t++) c.data[e * 4 + t] = a[e * 3 + t] + e * (7 + 4 * t) % 5 - 2;
	}
	return c;
}
//#endregion
//#region ../pipeline/src/stickers.ts
var R = (e) => Math.min(1, Math.max(0, e));
function z(e, t) {
	let { width: n, height: r, data: i } = e, a = t.width * 1, o = t.height * 1, s = Math.max(0, Math.floor((t.x - a) * n)), c = Math.max(0, Math.floor((t.y - o) * r)), l = Math.min(n, Math.ceil((t.x + t.width + a) * n)), u = Math.min(r, Math.ceil((t.y + t.height + o) * r)), d = l - s, f = u - c;
	if (d < 4 || f < 4) return t;
	let p = (e, t) => {
		let r = (t * n + e) * 4, a = Math.min(i[r], i[r + 1], i[r + 2]);
		return a >= 150 && Math.max(i[r], i[r + 1], i[r + 2]) - a <= 26;
	}, m = (e, i) => e >= t.x * n && e < (t.x + t.width) * n && i >= t.y * r && i < (t.y + t.height) * r, h = new Uint8Array(d * f), g = null, _ = [];
	for (let e = 0; e < f; e++) for (let t = 0; t < d; t++) {
		if (h[e * d + t] || !p(s + t, c + e)) continue;
		let n = 0, r = t, i = t, a = e, o = e;
		for (h[e * d + t] = 1, _.push(e * d + t); _.length;) {
			let e = _.pop(), t = e % d, l = (e - t) / d;
			m(s + t, c + l) && n++, t < r && (r = t), t > i && (i = t), l < a && (a = l), l > o && (o = l);
			for (let [e, n] of [
				[1, 0],
				[-1, 0],
				[0, 1],
				[0, -1]
			]) {
				let r = t + e, i = l + n;
				r < 0 || i < 0 || r >= d || i >= f || h[i * d + r] || !p(s + r, c + i) || (h[i * d + r] = 1, _.push(i * d + r));
			}
		}
		(!g || n > g.overlap) && (g = {
			overlap: n,
			minX: r,
			maxX: i,
			minY: a,
			maxY: o
		});
	}
	let v = t.width * n * t.height * r;
	if (!g || g.overlap < v * .2 || g.minX === 0 || g.minY === 0 || g.maxX === d - 1 || g.maxY === f - 1 || g.maxX - g.minX + 1 > t.width * n * 2 || g.maxY - g.minY + 1 > t.height * r * 2.5) return t;
	let y = Math.max(3, (g.maxX - g.minX) * .02), b = Math.max(3, (g.maxY - g.minY) * .04), x = R((s + g.minX - y) / n), S = R((c + g.minY - b) / r);
	return {
		x,
		y: S,
		width: R((s + g.maxX + 1 + y) / n) - x,
		height: R((c + g.maxY + 1 + b) / r) - S
	};
}
//#endregion
//#region ../pipeline/src/words.ts
var Ke = {
	lightness: 225,
	maxWidth: 30,
	minLength: 35
};
function B(e, t) {
	let { width: n, height: r, data: i } = e, a = new Uint8Array(n * r);
	for (let e = 0; e < n * r; e++) {
		if (i[e * 4 + 3] < 128) continue;
		let n = i[e * 4], r = i[e * 4 + 1], o = i[e * 4 + 2], s = Math.min(n, r, o);
		s >= t && Math.max(n, r, o) - s <= 34 && (a[e] = 1);
	}
	return a;
}
function qe(e, t, n, r, i) {
	let a = (e, a) => {
		let o = new Uint8Array(e.length), s = a ? t : n, c = a ? n : t;
		for (let n = 0; n < c; n++) for (let c = 0; c < s; c++) {
			let l = +!i;
			for (let o = -r; o <= r; o++) {
				let r = c + o, u = r < 0 || r >= s ? 0 : e[a ? n * t + r : r * t + n];
				if (i ? u : !u) {
					l = +!!i;
					break;
				}
			}
			o[a ? n * t + c : c * t + n] = l;
		}
		return o;
	};
	return a(a(e, !0), !1);
}
function Je(e, t = Ke, n) {
	let { width: r, height: i } = e, a = Math.max(r, i), o = B(e, t.lightness), s = Math.max(1, Math.round(t.maxWidth / 1e3 * a * .5)), c = qe(qe(o, r, i, s, !1), r, i, s, !0), l = t.minLength / 1e3 * a, u = new Uint8Array(r * i), d = new Uint8Array(r * i), f = [], p = [];
	for (let e = 0; e < o.length; e++) {
		if (!o[e] || u[e] || n && !n[e]) continue;
		let t = [], a = r, s = 0, m = i, h = 0, g = 0;
		for (u[e] = 1, f.push(e); f.length;) {
			let e = f.pop();
			t.push(e), c[e] && g++;
			let i = e % r, l = (e - i) / r;
			i < a && (a = i), i > s && (s = i), l < m && (m = l), l > h && (h = l);
			for (let t of [
				e - 1,
				e + 1,
				e - r,
				e + r,
				e - r - 1,
				e - r + 1,
				e + r - 1,
				e + r + 1
			]) {
				if (t < 0 || t >= o.length || !o[t] || u[t] || n && !n[t]) continue;
				let e = t % r;
				Math.abs(e - i) > 1 || (u[t] = 1, f.push(t));
			}
		}
		let _ = Math.hypot(s - a, h - m);
		if (_ >= l && g / t.length < .5) for (let e of t) d[e] = 1;
		else _ >= l * .4 && p.push({
			members: t,
			thickShare: g / t.length
		});
	}
	let m = qe(d, r, i, Math.max(2, Math.round(a * .03)), !0);
	for (let e of p) if (e.thickShare < .85 && e.members.some((e) => m[e])) for (let t of e.members) d[t] = 1;
	let h = B(e, Math.max(150, t.lightness - 40)), g = d;
	for (let e = 0; e < 4; e++) {
		let e = new Uint8Array(g);
		for (let t = 0; t < e.length; t++) {
			if (e[t] || !h[t] || n && !n[t]) continue;
			let i = t % r;
			(i > 0 && g[t - 1] || i < r - 1 && g[t + 1] || t >= r && g[t - r] || t + r < e.length && g[t + r]) && (e[t] = 1);
		}
		g = e;
	}
	return Ue(g, r, i, Math.max(2, Math.round(a * .0045)));
}
function Ye(e, t = Ke, n, r, i = !0) {
	let a = i ? Je(e, t, n) : new Uint8Array(e.width * e.height);
	r && (a = a.map((e, t) => e || r[t] ? 1 : 0));
	let o = 0;
	for (let e of a) o += e;
	return {
		image: o ? Ge(e, a) : Pe(e),
		filled: o
	};
}
//#endregion
//#region ../pipeline/src/printed.ts
var Xe = (e) => {
	let t = [...e].sort((e, t) => e - t);
	return t[Math.floor(t.length / 2)] ?? 0;
};
function Ze(e, t, n = 40) {
	let { width: r, height: i, data: a } = e, o = new Uint8Array(r * i), s = Math.max(0, Math.floor(t.x * r)), c = Math.max(0, Math.floor(t.y * i)), l = Math.min(r, Math.ceil((t.x + t.width) * r)), u = Math.min(i, Math.ceil((t.y + t.height) * i));
	if (l - s < 2 || u - c < 2) return o;
	let d = Math.max(2, Math.round(Math.min(l - s, u - c) * .25)), f = [], p = [], m = [], h = (e, t) => {
		let n = (t * r + e) * 4;
		f.push(a[n]), p.push(a[n + 1]), m.push(a[n + 2]);
	};
	for (let e = Math.max(0, c - d); e < Math.min(i, u + d); e++) for (let t = Math.max(0, s - d); t < Math.min(r, l + d); t++) (t < s || t >= l || e < c || e >= u) && h(t, e);
	if (f.length < 8) {
		for (let e = s; e < l; e++) h(e, c), h(e, u - 1);
		for (let e = c; e < u; e++) h(s, e), h(l - 1, e);
	}
	let g = [
		Xe(f),
		Xe(p),
		Xe(m)
	];
	if ([
		f,
		p,
		m
	].reduce((e, t, n) => e + Xe(t.map((e) => Math.abs(e - g[n]))), 0) / 3 > 18) return Qe(e, s, c, l, u);
	for (let e of [n, n * 1.8]) {
		let t = 0;
		o.fill(0);
		for (let n = c; n < u; n++) for (let i = s; i < l; i++) {
			let s = (n * r + i) * 4;
			(Math.abs(a[s] - g[0]) + Math.abs(a[s + 1] - g[1]) + Math.abs(a[s + 2] - g[2])) / 3 > e && (o[n * r + i] = 1, t++);
		}
		if (t <= (l - s) * (u - c) * .6) return o;
	}
	return Qe(e, s, c, l, u);
}
function Qe(e, t, n, r, i, a = 70) {
	let { width: o, height: s, data: c } = e, l = r - t, u = i - n, d = new Uint8Array(o * s), f = new Float32Array(l * u);
	for (let e = 0; e < u; e++) for (let r = 0; r < l; r++) {
		let i = ((n + e) * o + t + r) * 4;
		f[e * l + r] = .299 * c[i] + .587 * c[i + 1] + .114 * c[i + 2];
	}
	let p = Math.max(2, Math.round(u * .09)), m = (e, t) => {
		let n = (e, n) => {
			let r = new Float32Array(e.length), i = n ? l : u, a = n ? u : l;
			for (let o = 0; o < a; o++) for (let a = 0; a < i; a++) {
				let s = t ? -Infinity : Infinity;
				for (let r = Math.max(0, a - p); r <= Math.min(i - 1, a + p); r++) {
					let i = e[n ? o * l + r : r * l + o];
					(t ? i > s : i < s) && (s = i);
				}
				r[n ? o * l + a : a * l + o] = s;
			}
			return r;
		};
		return n(n(e, !0), !1);
	}, h = m(m(f, !0), !1), g = m(m(f, !1), !0), _ = 0, v = new Uint8Array(l * u);
	for (let e = 0; e < f.length; e++) (h[e] - f[e] > a || f[e] - g[e] > a) && (v[e] = 1, _++);
	if (_ > l * u * .4) return d;
	for (let e = 0; e < u; e++) for (let r = 0; r < l; r++) v[e * l + r] && (d[(n + e) * o + t + r] = 1);
	return d;
}
function $e(e, t, n, r = 48) {
	let { width: i, height: a, data: o } = e, s = (e, t) => {
		let n = (Math.min(a - 1, Math.max(0, t)) * i + Math.min(i - 1, Math.max(0, e))) * 4;
		return [
			o[n],
			o[n + 1],
			o[n + 2]
		];
	}, c = (e, t) => (Math.abs(e[0] - t[0]) + Math.abs(e[1] - t[1]) + Math.abs(e[2] - t[2])) / 3, l = Math.round(n.x), u = Math.round(n.y), d = Math.min(44, Math.max(14, Math.round((t.y1 - t.y0) * .2))), f = [], p = [], m = [];
	for (let e = -d - 2; e <= d + 2; e++) for (let t = -d - 2; t <= d + 2; t++) {
		if (Math.max(Math.abs(t), Math.abs(e)) < d) continue;
		let [n, r, i] = s(l + t, u + e);
		f.push(n), p.push(r), m.push(i);
	}
	let h = (e) => [...e].sort((e, t) => e - t)[Math.floor(e.length / 2)], g = [
		h(f),
		h(p),
		h(m)
	], _ = Math.min(22, Math.max(8, Math.round(d * .5))), v = null, y = 0;
	for (let e = 0; e <= _ && !v; e++) {
		for (let t = -e; t <= e; t++) for (let n = -e; n <= e; n++) {
			if (Math.max(Math.abs(n), Math.abs(t)) !== e) continue;
			let r = s(l + n, u + t), i = c(r, g);
			i >= 60 && i > y && (y = i, v = r);
		}
		if (v) for (let t = -(e + 2); t <= e + 2; t++) for (let n = -(e + 2); n <= e + 2; n++) {
			let e = s(l + n, u + t), r = c(e, g);
			r > y && (y = r, v = e);
		}
	}
	if (!v) return { problem: "no-print" };
	let b = new Uint8Array(i * a), x = 0, S = Math.max(0, Math.round(t.x0)), ee = Math.max(0, Math.round(t.y0)), C = Math.min(i, Math.round(t.x1)), te = Math.min(a, Math.round(t.y1));
	for (let e = ee; e < te; e++) for (let t = S; t < C; t++) {
		let n = (e * i + t) * 4;
		(Math.abs(o[n] - v[0]) + Math.abs(o[n + 1] - v[1]) + Math.abs(o[n + 2] - v[2])) / 3 < r && (b[e * i + t] = 1, x++);
	}
	return x < 12 ? { problem: "no-print" } : x > (C - S) * (te - ee) * .45 ? { problem: "too-much" } : {
		mask: b,
		color: v
	};
}
//#endregion
//#region ../pipeline/src/reconstruct.ts
function et(e, t, n) {
	let r = (e) => {
		let t = e / 255;
		return t <= .04045 ? t / 12.92 : ((t + .055) / 1.055) ** 2.4;
	}, i = r(e), a = r(t), o = r(n), s = (e) => e > .008856 ? Math.cbrt(e) : 7.787 * e + 16 / 116, c = s((.4124 * i + .3576 * a + .1805 * o) / .95047), l = s(.2126 * i + .7152 * a + .0722 * o), u = s((.0193 * i + .1192 * a + .9505 * o) / 1.08883);
	return [
		116 * l - 16,
		500 * (c - l),
		200 * (l - u)
	];
}
function tt(e, t) {
	let n = /* @__PURE__ */ new Float64Array(128);
	for (let r of e) n[Math.min(127, Math.floor(r / t * 128))]++;
	let r = e.length, i = 0;
	for (let e = 0; e < 128; e++) i += e * n[e];
	let a = 0, o = 0, s = 0, c = 0;
	for (let e = 0; e < 128; e++) {
		if (a += n[e], !a) continue;
		let t = r - a;
		if (!t) break;
		o += e * n[e];
		let l = a * t * (o / a - (i - o) / t) ** 2;
		l > s && (s = l, c = e);
	}
	return (c + 1) / 128 * t;
}
function nt(e, t, n, r) {
	let i = new Uint8Array(t * n), a = new Uint8Array(t * n), o = [];
	for (let s = 0; s < t * n; s++) {
		if (!e[s] || a[s]) continue;
		let c = [];
		for (a[s] = 1, o.push(s); o.length;) {
			let r = o.pop();
			c.push(r);
			let i = r % t;
			for (let s of [
				i > 0 ? r - 1 : -1,
				i < t - 1 ? r + 1 : -1,
				r - t,
				r + t
			]) s < 0 || s >= t * n || !e[s] || a[s] || (a[s] = 1, o.push(s));
		}
		if (c.length >= r) for (let e of c) i[e] = 1;
	}
	return i;
}
function rt(e, t, n, r = {}) {
	let { width: i, height: a } = e, { grow: o = 2, minPiece: s = 14, floor: c = 8 } = r, l = new Float32Array(i * a), u = [];
	for (let r = 0; r < i * a; r++) {
		if (!n[r]) continue;
		let i = et(e.data[r * 4], e.data[r * 4 + 1], e.data[r * 4 + 2]), a = et(t.data[r * 4], t.data[r * 4 + 1], t.data[r * 4 + 2]);
		l[r] = Math.hypot(i[0] - a[0], i[1] - a[1], i[2] - a[2]), u.push(l[r]);
	}
	if (!u.length) return new Uint8Array(i * a);
	let d = new Float32Array(i * a);
	for (let e = 0; e < a; e++) for (let t = 0; t < i; t++) {
		let n = 0, r = 0;
		for (let o = -1; o <= 1; o++) for (let s = -1; s <= 1; s++) {
			let c = t + s, u = e + o;
			if (c < 0 || u < 0 || c >= i || u >= a) continue;
			let d = (2 - Math.abs(s)) * (2 - Math.abs(o));
			n += l[u * i + c] * d, r += d;
		}
		d[e * i + t] = n / r;
	}
	l.set(d);
	let f = [];
	for (let e = 0; e < i * a; e++) n[e] && f.push(l[e]);
	let p = f.reduce((e, t) => Math.max(e, t), 0), m = Math.max(c, tt(f, Math.max(p, 1)) * .6), h = new Uint8Array(i * a);
	for (let e = 0; e < i * a; e++) n[e] && l[e] > m && (h[e] = 1);
	h = nt(h, i, a, s);
	let g = Ue(h, i, a, o);
	for (let e = 0; e < g.length; e++) n[e] || (g[e] = 0);
	return g;
}
//#endregion
//#region ../render2d/src/shaders.ts
var V = "#version 300 es\nvoid main() {\n  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));\n  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);\n}", it = "#version 300 es\nprecision highp float;\n\nuniform sampler2D uSource;\nuniform sampler2D uMask;   // cut-out alpha, same coordinates as the source\nuniform bool uHasMask;\nuniform vec2 uMaskTexel;   // size of one mask pixel in source coordinates\nuniform bool uDespill;     // pull green spill off the product's cut edge\nuniform sampler2D uBackground;\nuniform int uBgMode;       // 0 transparent, 1 colour, 2 photo\nuniform vec3 uBgColor;\nuniform vec4 uBgTransform; // output uv -> photo uv: scale.xy, offset.xy (\"cover\")\nuniform mat3 uOutputToSource;\nuniform vec2 uOutputSize;\nuniform bool uFlipY;\n\nuniform float uExposure;   // stops\nuniform float uContrast;   // -1..1\nuniform float uHighlights; // -1..1\nuniform float uShadows;    // -1..1\nuniform vec3 uWhiteBalance; // per-channel gains, luminance-neutral\nuniform float uVibrance;   // -1..1\nuniform float uSaturation; // -1..1\nuniform float uVignette;   // -1..1\nuniform bool uRecolour;    // off by default: it changes the product's own colour (core/recolour.ts is the reference)\nuniform vec3 uRecolourFrom;\nuniform vec3 uRecolourTo;\nuniform float uRecolourRange; // degrees of hue\n\nout vec4 outColor;\n\nvec3 toLinear(vec3 c) {\n  return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), step(0.04045, c));\n}\n\nvec3 toDisplay(vec3 c) {\n  c = max(c, 0.0);\n  return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c));\n}\n\nfloat luma(vec3 c) {\n  return dot(c, vec3(0.2126, 0.7152, 0.0722));\n}\n\n// hue in degrees, saturation, value\nvec3 rgbToHsv(vec3 c) {\n  float mx = max(c.r, max(c.g, c.b));\n  float mn = min(c.r, min(c.g, c.b));\n  float d = mx - mn;\n  float h = 0.0;\n  if (d > 0.0) {\n    if (mx == c.r) h = mod((c.g - c.b) / d, 6.0);\n    else if (mx == c.g) h = (c.b - c.r) / d + 2.0;\n    else h = (c.r - c.g) / d + 4.0;\n    h *= 60.0;\n  }\n  return vec3(h, mx > 0.0 ? d / mx : 0.0, mx);\n}\n\nvec3 hsvToRgb(vec3 hsv) {\n  vec3 k = mod(vec3(5.0, 3.0, 1.0) + mod(hsv.x, 360.0) / 60.0, 6.0);\n  return hsv.z - hsv.z * hsv.y * clamp(min(k, 4.0 - k), 0.0, 1.0);\n}\n\nvec3 recolour(vec3 c) {\n  vec3 p = rgbToHsv(c);\n  vec3 f = rgbToHsv(uRecolourFrom);\n  vec3 t = rgbToHsv(uRecolourTo);\n  float d = abs(mod(p.x - f.x + 540.0, 360.0) - 180.0);\n  float w = smoothstep(0.06, 0.18, p.y) * (1.0 - smoothstep(uRecolourRange * 0.6, uRecolourRange, d));\n  vec3 changed = hsvToRgb(vec3(p.x + (t.x - f.x), min(1.0, p.y * t.y / max(f.y, 0.05)), min(1.0, p.z * t.z / max(f.z, 0.05))));\n  return mix(c, changed, w);\n}\n\nvoid main() {\n  vec2 uv = gl_FragCoord.xy / uOutputSize;\n  if (uFlipY) uv.y = 1.0 - uv.y;\n\n  // The product, if this output pixel falls inside the photo (a square canvas can reach past its edges).\n  vec4 product = vec4(0.0);\n  vec2 src = (uOutputToSource * vec3(uv, 1.0)).xy;\n  if (!(any(lessThan(src, vec2(0.0))) || any(greaterThan(src, vec2(1.0))))) {\n    vec4 texel = texture(uSource, src);\n    float maskAlpha = uHasMask ? texture(uMask, src).r : 1.0;\n\n    if (uDespill && uHasMask) {\n      // Only where the cut edge is close: elsewhere a green pixel is the product's own colour.\n      vec2 d = uMaskTexel * 3.0;\n      float nearest = min(min(texture(uMask, src + vec2(d.x, 0.0)).r, texture(uMask, src - vec2(d.x, 0.0)).r),\n                          min(texture(uMask, src + vec2(0.0, d.y)).r, texture(uMask, src - vec2(0.0, d.y)).r));\n      float dom = texel.g - max(texel.r, texel.b);\n      if (nearest < 0.99 && dom > 0.0) texel.g = max(texel.r, texel.b) + dom * 0.15;\n    }\n\n    if (uRecolour) texel.rgb = recolour(texel.rgb);\n\n    vec3 linear = toLinear(texel.rgb) * exp2(uExposure) * uWhiteBalance;\n    vec3 c = toDisplay(linear);\n\n    float y = luma(c);\n    c *= 1.0 + uShadows * 0.6 * (1.0 - smoothstep(0.0, 0.55, y));\n    c *= 1.0 + uHighlights * 0.5 * smoothstep(0.45, 1.0, y);\n    c = (c - 0.5) * (1.0 + uContrast * 0.8) + 0.5;\n\n    y = luma(c);\n    float chroma = max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b));\n    c = mix(vec3(y), c, 1.0 + uVibrance * (1.0 - clamp(chroma, 0.0, 1.0)));\n    c = mix(vec3(y), c, 1.0 + uSaturation);\n\n    float edge = smoothstep(0.35, 1.0, length(uv - 0.5) * 1.41421);\n    c *= 1.0 + uVignette * edge;\n\n    product = vec4(clamp(c, 0.0, 1.0), texel.a * maskAlpha);\n  }\n\n  // Put the product over whatever is behind it.\n  vec3 behind = vec3(0.0);\n  float behindAlpha = 0.0;\n  if (uBgMode == 1) {\n    behind = uBgColor;\n    behindAlpha = 1.0;\n  } else if (uBgMode == 2) {\n    behind = texture(uBackground, uv * uBgTransform.xy + uBgTransform.zw).rgb;\n    behindAlpha = 1.0;\n  }\n  float a = product.a + behindAlpha * (1.0 - product.a);\n  vec3 rgb = a > 0.0 ? (product.rgb * product.a + behind * behindAlpha * (1.0 - product.a)) / a : vec3(0.0);\n  outColor = vec4(rgb, a);\n}", at = [
	"uSource",
	"uMask",
	"uHasMask",
	"uMaskTexel",
	"uDespill",
	"uBackground",
	"uBgMode",
	"uBgColor",
	"uBgTransform",
	"uOutputToSource",
	"uOutputSize",
	"uFlipY",
	"uExposure",
	"uContrast",
	"uHighlights",
	"uShadows",
	"uWhiteBalance",
	"uVibrance",
	"uSaturation",
	"uVignette",
	"uRecolour",
	"uRecolourFrom",
	"uRecolourTo",
	"uRecolourRange"
], ot = "#version 300 es\nprecision highp float;\nuniform sampler2D uProduct;\nuniform sampler2D uBackground;\nuniform vec2 uResolution;\nuniform bool uFlipY;\nuniform int uBgMode;\nuniform vec3 uBgColor;\nuniform vec4 uBgTransform;\nout vec4 outColor;\nvoid main() {\n  vec2 uv = gl_FragCoord.xy / uResolution;\n  if (uFlipY) uv.y = 1.0 - uv.y;\n  vec4 product = texture(uProduct, uv);\n  vec3 behind = vec3(0.0);\n  float behindAlpha = 0.0;\n  if (uBgMode == 1) { behind = uBgColor; behindAlpha = 1.0; }\n  else if (uBgMode == 2) { behind = texture(uBackground, uv * uBgTransform.xy + uBgTransform.zw).rgb; behindAlpha = 1.0; }\n  float a = product.a + behindAlpha * (1.0 - product.a);\n  vec3 rgb = a > 0.0 ? (product.rgb * product.a + behind * behindAlpha * (1.0 - product.a)) / a : vec3(0.0);\n  outColor = vec4(rgb, a);\n}";
function st(e, t, n) {
	let r = e.createShader(t);
	if (e.shaderSource(r, n), e.compileShader(r), !e.getShaderParameter(r, e.COMPILE_STATUS)) {
		let t = e.getShaderInfoLog(r);
		throw e.deleteShader(r), Error(`Shader failed to compile: ${t}`);
	}
	return r;
}
function ct(e, t) {
	let n = e / 100, r = t / 100, i = [
		1 + .25 * n,
		1 - .2 * r,
		1 - .25 * n
	], a = .2126 * i[0] + .7152 * i[1] + .0722 * i[2];
	return i.map((e) => e / a);
}
function lt(e, t, n) {
	return new Promise((r, i) => e.toBlob((e) => e ? r(e) : i(/* @__PURE__ */ Error("This browser could not encode the image.")), t, n));
}
var ut = class {
	canvas;
	maxTextureSize;
	gl;
	program;
	vao;
	uniforms;
	source = null;
	mask = null;
	maskTexel = [0, 0];
	despill = !1;
	background = null;
	backgroundSize = [1, 1];
	effectPrograms = /* @__PURE__ */ new Map();
	composite = null;
	scratch = null;
	noMask;
	constructor(e) {
		this.canvas = e;
		let t = e.getContext("webgl2", {
			alpha: !0,
			premultipliedAlpha: !1,
			antialias: !1
		});
		if (!t) throw Error("This browser does not support WebGL2, which the editor needs.");
		this.gl = t, this.maxTextureSize = t.getParameter(t.MAX_TEXTURE_SIZE);
		let n = t.createProgram();
		if (t.attachShader(n, st(t, t.VERTEX_SHADER, V)), t.attachShader(n, st(t, t.FRAGMENT_SHADER, it)), t.linkProgram(n), !t.getProgramParameter(n, t.LINK_STATUS)) throw Error(`Shader failed to link: ${t.getProgramInfoLog(n)}`);
		this.program = n, this.vao = t.createVertexArray(), this.noMask = t.createTexture(), t.bindTexture(t.TEXTURE_2D, this.noMask), t.texImage2D(t.TEXTURE_2D, 0, t.R8, 1, 1, 0, t.RED, t.UNSIGNED_BYTE, new Uint8Array([255])), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MIN_FILTER, t.NEAREST), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MAG_FILTER, t.NEAREST), this.uniforms = Object.fromEntries(at.map((e) => [e, t.getUniformLocation(n, e)]));
	}
	setSource(e) {
		let t = this.gl;
		this.source && t.deleteTexture(this.source), this.source = t.createTexture(), t.bindTexture(t.TEXTURE_2D, this.source), t.pixelStorei(t.UNPACK_FLIP_Y_WEBGL, !1), t.pixelStorei(t.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !1), t.texImage2D(t.TEXTURE_2D, 0, t.RGBA8, t.RGBA, t.UNSIGNED_BYTE, e), t.generateMipmap(t.TEXTURE_2D), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MIN_FILTER, t.LINEAR_MIPMAP_LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MAG_FILTER, t.LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_S, t.CLAMP_TO_EDGE), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_T, t.CLAMP_TO_EDGE);
	}
	setMask(e, t = 0, n = 0, r = {}) {
		let i = this.gl;
		this.mask && i.deleteTexture(this.mask), this.mask = null, this.despill = !1, e && (this.despill = r.despill === !0, this.maskTexel = [1 / t, 1 / n], this.mask = i.createTexture(), i.bindTexture(i.TEXTURE_2D, this.mask), i.pixelStorei(i.UNPACK_ALIGNMENT, 1), i.texImage2D(i.TEXTURE_2D, 0, i.R8, t, n, 0, i.RED, i.UNSIGNED_BYTE, e), i.pixelStorei(i.UNPACK_ALIGNMENT, 4), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_MIN_FILTER, i.LINEAR), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_MAG_FILTER, i.LINEAR), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_WRAP_S, i.CLAMP_TO_EDGE), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_WRAP_T, i.CLAMP_TO_EDGE));
	}
	setBackground(e) {
		let t = this.gl;
		this.background && t.deleteTexture(this.background), this.background = null, e && (this.backgroundSize = [e.width, e.height], this.background = t.createTexture(), t.bindTexture(t.TEXTURE_2D, this.background), t.pixelStorei(t.UNPACK_FLIP_Y_WEBGL, !1), t.pixelStorei(t.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !1), t.texImage2D(t.TEXTURE_2D, 0, t.RGBA8, t.RGBA, t.UNSIGNED_BYTE, e), t.generateMipmap(t.TEXTURE_2D), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MIN_FILTER, t.LINEAR_MIPMAP_LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MAG_FILTER, t.LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_S, t.CLAMP_TO_EDGE), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_T, t.CLAMP_TO_EDGE));
	}
	draw(e, t, n) {
		this.canvas.width !== t && (this.canvas.width = t), this.canvas.height !== n && (this.canvas.height = n), this.render(e, t, n, !0, null);
	}
	async export(e, t = {}) {
		let n = this.gl, r = Math.min(this.maxTextureSize, n.getParameter(n.MAX_RENDERBUFFER_SIZE)), { width: i, height: a } = u(e, Math.min(t.maxSize ?? Infinity, r));
		if (t.size) {
			let e = Math.min(t.size, r) / Math.max(i, a);
			i = Math.max(1, Math.round(i * e)), a = Math.max(1, Math.round(a * e));
		}
		let o = n.createTexture();
		n.bindTexture(n.TEXTURE_2D, o), n.texStorage2D(n.TEXTURE_2D, 1, n.RGBA8, i, a);
		let s = n.createFramebuffer();
		n.bindFramebuffer(n.FRAMEBUFFER, s), n.framebufferTexture2D(n.FRAMEBUFFER, n.COLOR_ATTACHMENT0, n.TEXTURE_2D, o, 0);
		let c = new Uint8ClampedArray(i * a * 4);
		try {
			this.render(e, i, a, !1, s), n.readPixels(0, 0, i, a, n.RGBA, n.UNSIGNED_BYTE, c);
		} finally {
			n.bindFramebuffer(n.FRAMEBUFFER, null), n.deleteFramebuffer(s), n.deleteTexture(o);
		}
		let l = t.type ?? "image/webp", d = document.createElement("canvas");
		d.width = i, d.height = a, d.getContext("2d").putImageData(new ImageData(c, i, a), 0, 0);
		let f = async (e, n) => {
			if (e !== "image/jpeg") return lt(d, e, n);
			let r = document.createElement("canvas");
			r.width = i, r.height = a;
			let o = r.getContext("2d");
			return o.fillStyle = t.background ?? "#ffffff", o.fillRect(0, 0, i, a), o.drawImage(d, 0, 0), lt(r, e, n);
		}, p = t.quality ?? .88, m = await f(l, p), h = m.type === l ? l : l === "image/webp" ? "image/jpeg" : m.type;
		if (h !== m.type && (m = await f(h, p)), t.maxBytes && h !== "image/png") for (; m.size > t.maxBytes && p > .4;) p -= .08, m = await f(h, p);
		return {
			blob: m,
			width: i,
			height: a,
			type: m.type
		};
	}
	dispose() {
		let e = this.gl;
		this.source && e.deleteTexture(this.source), this.mask && e.deleteTexture(this.mask), this.background && e.deleteTexture(this.background), e.deleteTexture(this.noMask), this.freeScratch();
		for (let t of this.effectPrograms.values()) typeof t != "string" && e.deleteProgram(t.program);
		this.effectPrograms.clear(), this.composite && e.deleteProgram(this.composite.program), e.deleteProgram(this.program), e.deleteVertexArray(this.vao), this.source = null;
	}
	compileEffect(e) {
		let t = this.effectProgram(e);
		return typeof t == "string" ? t : null;
	}
	effectProgram(e) {
		let t = `${e.id}:${e.source.length}:${e.source.slice(-40)}`, n = this.effectPrograms.get(t);
		if (n) return n;
		let r = this.gl, i;
		try {
			let t = r.createProgram();
			if (r.attachShader(t, st(r, r.VERTEX_SHADER, T)), r.attachShader(t, st(r, r.FRAGMENT_SHADER, je(e))), r.linkProgram(t), !r.getProgramParameter(t, r.LINK_STATUS)) throw Error(`Shader failed to link: ${r.getProgramInfoLog(t)}`);
			i = {
				program: t,
				inputs: {
					uInput: r.getUniformLocation(t, "uInput"),
					uResolution: r.getUniformLocation(t, "uResolution"),
					uTime: r.getUniformLocation(t, "uTime"),
					uFlipY: r.getUniformLocation(t, "uFlipY"),
					uInputFlipped: r.getUniformLocation(t, "uInputFlipped")
				},
				params: new Map(e.params.map((e) => [e.uniform, r.getUniformLocation(t, e.uniform)]))
			};
		} catch (t) {
			i = `${e.id}: ${t instanceof Error ? t.message : String(t)}`, console.warn(`The "${e.name}" effect was skipped. ${i}`);
		}
		return this.effectPrograms.set(t, i), i;
	}
	freeScratch() {
		if (this.scratch) {
			for (let e of this.scratch.targets) this.gl.deleteFramebuffer(e.framebuffer), this.gl.deleteTexture(e.texture);
			this.scratch = null;
		}
	}
	scratchTargets(e, t) {
		let n = this.gl;
		if (this.scratch && this.scratch.width === e && this.scratch.height === t) return this.scratch.targets;
		this.freeScratch();
		let r = () => {
			let r = n.createTexture();
			n.bindTexture(n.TEXTURE_2D, r), n.texStorage2D(n.TEXTURE_2D, 1, n.RGBA8, e, t), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MIN_FILTER, n.LINEAR), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MAG_FILTER, n.LINEAR), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_S, n.CLAMP_TO_EDGE), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_T, n.CLAMP_TO_EDGE);
			let i = n.createFramebuffer();
			return n.bindFramebuffer(n.FRAMEBUFFER, i), n.framebufferTexture2D(n.FRAMEBUFFER, n.COLOR_ATTACHMENT0, n.TEXTURE_2D, r, 0), {
				texture: r,
				framebuffer: i
			};
		}, i = [r(), r()];
		return this.scratch = {
			width: e,
			height: t,
			targets: i
		}, i;
	}
	runEffect(e, t, n, r, i, a, o, s) {
		let c = this.gl;
		c.bindFramebuffer(c.FRAMEBUFFER, i), c.viewport(0, 0, a, o), c.useProgram(e.program), c.bindVertexArray(this.vao), c.activeTexture(c.TEXTURE0), c.bindTexture(c.TEXTURE_2D, r), c.uniform1i(e.inputs.uInput, 0), c.uniform2f(e.inputs.uResolution, a, o), c.uniform1f(e.inputs.uTime, 0), c.uniform1i(e.inputs.uFlipY, +!!s), c.uniform1i(e.inputs.uInputFlipped, 0);
		for (let r of t.params) {
			let t = e.params.get(r.uniform);
			if (!t) continue;
			let i = re(r, n[r.key]);
			Array.isArray(i) ? c.uniform3f(t, i[0], i[1], i[2]) : r.glslType === "float" ? c.uniform1f(t, i) : c.uniform1i(t, i);
		}
		c.drawArrays(c.TRIANGLES, 0, 3);
	}
	runComposite(e, t, n, r, i, a) {
		let o = this.gl;
		if (!this.composite) {
			let e = o.createProgram();
			if (o.attachShader(e, st(o, o.VERTEX_SHADER, V)), o.attachShader(e, st(o, o.FRAGMENT_SHADER, ot)), o.linkProgram(e), !o.getProgramParameter(e, o.LINK_STATUS)) throw Error(`Shader failed to link: ${o.getProgramInfoLog(e)}`);
			let t = [
				"uProduct",
				"uBackground",
				"uResolution",
				"uFlipY",
				"uBgMode",
				"uBgColor",
				"uBgTransform"
			];
			this.composite = {
				program: e,
				uniforms: Object.fromEntries(t.map((t) => [t, o.getUniformLocation(e, t)]))
			};
		}
		let s = this.composite.uniforms;
		o.bindFramebuffer(o.FRAMEBUFFER, n), o.viewport(0, 0, r, i), o.useProgram(this.composite.program), o.bindVertexArray(this.vao), o.activeTexture(o.TEXTURE0), o.bindTexture(o.TEXTURE_2D, t), o.uniform1i(s.uProduct, 0);
		let c = l(e.recipe, "backdrop", "mode") === "image" && this.background;
		o.activeTexture(o.TEXTURE1), o.bindTexture(o.TEXTURE_2D, c ? this.background : this.noMask), o.uniform1i(s.uBackground, 1), o.uniform2f(s.uResolution, r, i), o.uniform1i(s.uFlipY, +!!a), this.setBackdropUniforms(e, r, i, s.uBgMode, s.uBgColor, s.uBgTransform), o.activeTexture(o.TEXTURE0), o.drawArrays(o.TRIANGLES, 0, 3);
	}
	setBackdropUniforms(e, t, n, r, i, a) {
		let o = this.gl, s = e.recipe, c = l(s, "backdrop", "mode"), u = c === "image" && this.background;
		o.uniform1i(r, u ? 2 : +(c === "color"));
		let d = l(s, "backdrop", "color") || "#ffffff";
		o.uniform3f(i, parseInt(d.slice(1, 3), 16) / 255, parseInt(d.slice(3, 5), 16) / 255, parseInt(d.slice(5, 7), 16) / 255);
		let f = t / n, p = this.backgroundSize[0] / this.backgroundSize[1], m = p > f ? f / p : 1, h = p > f ? 1 : p / f;
		o.uniform4f(a, m, h, (1 - m) / 2, (1 - h) / 2);
	}
	render(e, t, n, r, i) {
		let a = e.recipe.effects.map((e) => ({
			step: e,
			def: oe(e.id)
		})).filter((e) => !!e.def).map((e) => ({
			...e,
			program: this.effectProgram(e.def)
		})).filter((e) => typeof e.program != "string");
		if (!a.length) {
			this.gl.bindFramebuffer(this.gl.FRAMEBUFFER, i), this.drawPhoto(e, t, n, r, !0);
			return;
		}
		let [o, s] = this.scratchTargets(t, n);
		this.gl.bindFramebuffer(this.gl.FRAMEBUFFER, o.framebuffer), this.drawPhoto(e, t, n, !1, !1);
		let c = o, l = s, u = () => {
			[c, l] = [l, c];
		}, d = a.filter((e) => e.def.scope === "product"), f = a.filter((e) => e.def.scope !== "product");
		for (let e of d) this.runEffect(e.program, e.def, w(e.def, e.step.params), c.texture, l.framebuffer, t, n, !1), u();
		this.runComposite(e, c.texture, f.length ? l.framebuffer : i, t, n, !f.length && r), f.length && (u(), f.forEach((e, a) => {
			let o = a === f.length - 1;
			this.runEffect(e.program, e.def, w(e.def, e.step.params), c.texture, o ? i : l.framebuffer, t, n, o ? r : !1), u();
		}));
	}
	drawPhoto(e, n, r, i, a) {
		let o = this.gl, s = this.uniforms, c = e.recipe, u = ee(e);
		if (o.viewport(0, 0, n, r), o.clearColor(0, 0, 0, 0), o.clear(o.COLOR_BUFFER_BIT), !this.source) return;
		o.useProgram(this.program), o.bindVertexArray(this.vao), o.activeTexture(o.TEXTURE0), o.bindTexture(o.TEXTURE_2D, this.source), o.uniform1i(s.uSource, 0), o.activeTexture(o.TEXTURE1), o.bindTexture(o.TEXTURE_2D, this.mask ?? this.noMask), o.uniform1i(s.uMask, 1), o.uniform1i(s.uHasMask, +!!this.mask), o.uniform2f(s.uMaskTexel, this.maskTexel[0], this.maskTexel[1]), o.uniform1i(s.uDespill, +!!this.despill);
		let d = a && l(c, "backdrop", "mode") === "image" && this.background;
		o.activeTexture(o.TEXTURE2), o.bindTexture(o.TEXTURE_2D, d ? this.background : this.noMask), o.uniform1i(s.uBackground, 2), a ? this.setBackdropUniforms(e, n, r, s.uBgMode, s.uBgColor, s.uBgTransform) : o.uniform1i(s.uBgMode, 0), o.activeTexture(o.TEXTURE0), o.uniformMatrix3fv(s.uOutputToSource, !1, [
			u.a,
			u.b,
			0,
			u.c,
			u.d,
			0,
			u.e,
			u.f,
			1
		]), o.uniform2f(s.uOutputSize, n, r), o.uniform1i(s.uFlipY, +!!i), o.uniform1f(s.uExposure, t(c, "light", "exposure")), o.uniform1f(s.uContrast, t(c, "light", "contrast") / 100), o.uniform1f(s.uHighlights, t(c, "light", "highlights") / 100), o.uniform1f(s.uShadows, t(c, "light", "shadows") / 100), o.uniform3fv(s.uWhiteBalance, ct(t(c, "color", "temperature"), t(c, "color", "tint"))), o.uniform1f(s.uVibrance, t(c, "color", "vibrance") / 100), o.uniform1f(s.uSaturation, t(c, "color", "saturation") / 100), o.uniform1f(s.uVignette, t(c, "effects", "vignette") / 100), o.uniform1i(s.uRecolour, +!!C(c, "recolour", "on")), o.uniform3fv(s.uRecolourFrom, F(l(c, "recolour", "from") || "#d23c3c")), o.uniform3fv(s.uRecolourTo, F(l(c, "recolour", "to") || "#3c64d2")), o.uniform1f(s.uRecolourRange, t(c, "recolour", "range") || 30), o.drawArrays(o.TRIANGLES, 0, 3);
	}
}, dt = [
	"nw",
	"n",
	"ne",
	"e",
	"se",
	"s",
	"sw",
	"w"
], ft = (e) => `${e * 100}%`;
function pt({ editor: e, doc: t, width: n, height: r }) {
	let i = A(null), a = m(t), o = (t) => (n) => {
		n.preventDefault(), n.stopPropagation(), n.currentTarget.setPointerCapture(n.pointerId), i.current = {
			handle: t,
			start: m(e.document),
			x: n.clientX,
			y: n.clientY
		}, e.begin(t === "move" ? "Move crop" : "Resize crop");
	}, s = (t) => {
		let a = i.current;
		if (!a) return;
		let o = e.document;
		e.setCrop(x(a.start, a.handle, (t.clientX - a.x) / n, (t.clientY - a.y) / r, v(o), h(o)));
	}, c = () => {
		i.current && (i.current = null, e.commit());
	};
	return /* @__PURE__ */ N("div", {
		className: "gs-crop",
		style: {
			width: n,
			height: r
		},
		onPointerMove: s,
		onPointerUp: c,
		onPointerCancel: c,
		children: /* @__PURE__ */ P("div", {
			className: "gs-crop__box",
			style: {
				left: ft(a.x),
				top: ft(a.y),
				width: ft(a.width),
				height: ft(a.height)
			},
			onPointerDown: o("move"),
			children: [/* @__PURE__ */ N("div", { className: "gs-crop__thirds" }), dt.map((e) => /* @__PURE__ */ N("div", {
				className: `gs-crop__handle gs-crop__handle--${e}`,
				onPointerDown: o(e)
			}, e))]
		})
	});
}
//#endregion
//#region src/CutoutOverlay.tsx
var mt = .002;
function ht({ editor: e, doc: t, settings: n, width: r, height: i }) {
	let a = A(null), [o, s] = j(null), c = (t) => {
		let n = t.currentTarget.getBoundingClientRect(), [r, i] = p(ee(e.document), (t.clientX - n.left) / n.width, (t.clientY - n.top) / n.height);
		return [Math.min(1, Math.max(0, r)), Math.min(1, Math.max(0, i))];
	}, l = (e) => ({
		kind: "brush",
		mode: n.tool === "erase" ? "remove" : "keep",
		radius: n.brush,
		points: e
	}), d = (t) => {
		t.preventDefault();
		let [r, i] = c(t);
		n.tool === "tap" ? e.addMaskOp({
			kind: "fill",
			mode: "remove",
			x: r,
			y: i,
			tolerance: n.tolerance
		}) : (t.currentTarget.setPointerCapture(t.pointerId), a.current = [r, i], e.begin(n.tool === "erase" ? "Erase" : "Restore"), e.addMaskOp(l(a.current)));
	}, f = (t) => {
		let n = t.currentTarget.getBoundingClientRect();
		s({
			x: t.clientX - n.left,
			y: t.clientY - n.top
		});
		let r = a.current;
		if (!r) return;
		let [i, o] = c(t);
		Math.hypot(i - r[r.length - 2], o - r[r.length - 1]) < mt || (r.push(i, o), e.updateLastMaskOp(l([...r])));
	}, m = () => {
		a.current && (a.current = null, e.commit());
	}, h = u(t), g = n.brush * Math.max(t.source.width, t.source.height) * (r / h.width);
	return /* @__PURE__ */ N("div", {
		className: `gs-cutout gs-cutout--${n.tool}`,
		style: {
			width: r,
			height: i
		},
		onPointerDown: d,
		onPointerMove: f,
		onPointerUp: m,
		onPointerCancel: m,
		onPointerLeave: () => s(null),
		children: o && n.tool !== "tap" && /* @__PURE__ */ N("div", {
			className: "gs-cutout__brush",
			style: {
				left: o.x - g,
				top: o.y - g,
				width: g * 2,
				height: g * 2
			}
		})
	});
}
var gt = {
	id: "birefnet-general-fp16",
	name: "BiRefNet (whole box, larger)",
	task: "cutout",
	summary: "Cuts a whole box or product out of any background. Four times the size of the compact model, and it was never fooled by artwork on a cover (the compact one took a girl on the cover for the object on one box in ten).",
	recommended: !1,
	license: {
		name: "MIT",
		commercialUse: "allowed",
		url: "https://huggingface.co/ZhengPeng7/BiRefNet"
	},
	sizeMb: 489.7,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/ZhengPeng7/BiRefNet",
		download: "https://huggingface.co/onnx-community/BiRefNet-ONNX/resolve/main/onnx/model_fp16.onnx"
	},
	file: {
		name: "birefnet-general-fp16.onnx",
		bytes: 489666272
	},
	input: {
		size: 1024,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "logits-mask"
}, _t = {
	id: "birefnet-lite-fp16",
	name: "BiRefNet lite (compact)",
	task: "cutout",
	summary: "Separates the product from any background, with clean edges. The compact version: half the download, nearly the same quality.",
	recommended: !0,
	license: {
		name: "MIT",
		commercialUse: "allowed",
		url: "https://huggingface.co/ZhengPeng7/BiRefNet_lite"
	},
	sizeMb: 114.5,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/ZhengPeng7/BiRefNet_lite",
		download: "https://huggingface.co/onnx-community/BiRefNet_lite-ONNX/resolve/main/onnx/model_fp16.onnx"
	},
	file: {
		name: "birefnet-lite-fp16.onnx",
		bytes: 114538221
	},
	input: {
		size: 1024,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "logits-mask"
}, vt = {
	id: "birefnet-lite",
	name: "BiRefNet lite (full precision)",
	task: "cutout",
	summary: "The same cut-out model at full precision. A bigger download for slightly finer edges.",
	recommended: !1,
	license: {
		name: "MIT",
		commercialUse: "allowed",
		url: "https://huggingface.co/ZhengPeng7/BiRefNet_lite"
	},
	sizeMb: 224,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/ZhengPeng7/BiRefNet_lite",
		download: "https://huggingface.co/onnx-community/BiRefNet_lite-ONNX/resolve/main/onnx/model.onnx"
	},
	file: {
		name: "birefnet-lite.onnx",
		bytes: 224005088
	},
	input: {
		size: 1024,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "logits-mask"
}, yt = {
	id: "lama-fp32",
	name: "LaMa fill (removes marks and lettering)",
	task: "inpaint",
	summary: "Paints over what you mask (printed words, stickers, marks) with realistic detail from around it. Much cleaner than the free fill on hair and fabric. Takes a few seconds per patch on a laptop.",
	recommended: !0,
	license: {
		name: "Apache-2.0",
		commercialUse: "allowed",
		url: "https://huggingface.co/Carve/LaMa-ONNX"
	},
	sizeMb: 208,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/Carve/LaMa-ONNX",
		download: "https://huggingface.co/Carve/LaMa-ONNX/resolve/main/lama_fp32.onnx"
	},
	file: {
		name: "lama-fp32.onnx",
		bytes: 208044816
	},
	input: {
		size: 512,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image"
}, bt = {
	id: "ppocr-det-v4",
	name: "Text finder (PaddleOCR v4, compact)",
	task: "text-detect",
	summary: "Finds where printed text is on a picture (any colour, many languages including Japanese), so it can be filled in. Tiny and quick.",
	recommended: !0,
	license: {
		name: "Apache-2.0",
		commercialUse: "allowed",
		url: "https://huggingface.co/SWHL/RapidOCR"
	},
	sizeMb: 4.7,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/SWHL/RapidOCR",
		download: "https://huggingface.co/SWHL/RapidOCR/resolve/main/PP-OCRv4/ch_PP-OCRv4_det_infer.onnx"
	},
	file: {
		name: "ppocr-det-v4.onnx",
		bytes: 4745517
	},
	input: {
		size: 960,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "probability-map"
}, xt = {
	id: "ppocr-rec-v4",
	name: "Text reader (PaddleOCR v4, compact)",
	task: "text-read",
	summary: "Reads what printed text says (numbers, prices, English, Chinese, Japanese kana), so a shop's price sticker can be told apart from the box's own printing. Used together with the text finder.",
	recommended: !0,
	license: {
		name: "Apache-2.0",
		commercialUse: "allowed",
		url: "https://huggingface.co/SWHL/RapidOCR"
	},
	sizeMb: 10.9,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/SWHL/RapidOCR",
		download: "https://huggingface.co/SWHL/RapidOCR/resolve/main/PP-OCRv4/ch_PP-OCRv4_rec_infer.onnx"
	},
	file: {
		name: "ppocr-rec-v4.onnx",
		bytes: 10857958
	},
	input: {
		size: 48,
		mean: [
			.5,
			.5,
			.5
		],
		std: [
			.5,
			.5,
			.5
		]
	},
	output: "probability-map"
}, St = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realesr-general-x4",
	name: "Sharpen & enlarge (fast, small)",
	recommended: !1,
	summary: "Makes a picture 4 times larger and clearly sharper, adding believable fine detail. The small, quick one (about a quarter of a second for a face-sized area). Best first choice for photos of figures and boxes. In the benchmark it over-sharpened (1.13 times the original's edge detail) and lost some structure, so the x4plus model is the default.",
	sizeMb: 4.95,
	license: {
		name: "BSD-3-Clause (Real-ESRGAN)",
		commercialUse: "check",
		url: "https://github.com/xinntao/Real-ESRGAN/blob/master/LICENSE"
	},
	links: {
		modelCard: "https://huggingface.co/baker76/upscale-models",
		download: "https://huggingface.co/baker76/upscale-models/resolve/main/RealESR_General_x4.onnx"
	},
	file: {
		name: "realesr-general-x4.onnx",
		bytes: 4954907
	}
}, Ct = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realesrgan-anime-x4",
	name: "Sharpen & enlarge (illustrations)",
	recommended: !1,
	summary: "Tuned for drawn art: very clean lines and flat colour, but it smooths skin and plastic texture, so it suits flat box illustrations more than photos of figures.",
	sizeMb: 18.7,
	license: {
		name: "BSD-3-Clause (Real-ESRGAN)",
		commercialUse: "check",
		url: "https://github.com/xinntao/Real-ESRGAN/blob/master/LICENSE"
	},
	links: {
		modelCard: "https://huggingface.co/baker76/upscale-models",
		download: "https://huggingface.co/baker76/upscale-models/resolve/main/RealESRGAN_anime_x4.onnx"
	},
	file: {
		name: "realesrgan-anime-x4.onnx",
		bytes: 18688425
	}
}, wt = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realesrgan-x4plus",
	name: "Sharpen & enlarge (best photo quality)",
	recommended: !1,
	summary: "Sharpens and enlarges 4x with the larger photo model. On a benchmark (half-size, compressed crops restored and compared with the originals) it was the most faithful and best balanced of the Real-ESRGAN models: highest SSIM and sharpness closest to the original. Slower (a few seconds for a face-sized area).",
	sizeMb: 69.9,
	license: {
		name: "BSD-3-Clause (Real-ESRGAN)",
		commercialUse: "check",
		url: "https://github.com/xinntao/Real-ESRGAN/blob/master/LICENSE"
	},
	links: {
		modelCard: "https://huggingface.co/baker76/upscale-models",
		download: "https://huggingface.co/baker76/upscale-models/resolve/main/RealESRGAN_x4plus.onnx"
	},
	file: {
		name: "realesrgan-x4plus.onnx",
		bytes: 69879921
	}
}, H = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realplksr-x4",
	name: "Photo restore 4x (RealPLKSR, small and fast)",
	recommended: !0,
	summary: "A small 4x restoration model from darktable (MIT), trained for photographs. Best of every enlarging method on ten real product photos (bench/enlarge): sharper and truer than Real-ESRGAN, and it keeps printed text readable.",
	sizeMb: 29.7,
	license: {
		name: "MIT (darktable RealPLKSR)",
		commercialUse: "yes",
		url: "https://huggingface.co/darktable-org/upscale-realplksr-onnx"
	},
	links: {
		modelCard: "https://huggingface.co/darktable-org/upscale-realplksr-onnx",
		download: "https://huggingface.co/darktable-org/upscale-realplksr-onnx/resolve/main/onnx/model_x4.onnx"
	},
	file: {
		name: "realplksr-x4.onnx",
		bytes: 29711010
	}
}, U = {
	id: "sdxl-inpaint",
	name: "Redraw (Stable Diffusion XL inpainting)",
	task: "redraw",
	summary: "Redraws part of a picture with a believable continuation: a missing antenna, an edge that was cut off. Runs on this computer's GPU (about 30 seconds). It invents what it draws, so use it where the picture really is missing a part.",
	recommended: !0,
	license: {
		name: "OpenRAIL++-M (commercial use of the pictures is allowed; see the licence for its use restrictions)",
		commercialUse: "check",
		url: "https://huggingface.co/diffusers/stable-diffusion-xl-1.0-inpainting-0.1"
	},
	sizeMb: 6940,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/diffusers/stable-diffusion-xl-1.0-inpainting-0.1",
		download: "https://huggingface.co/diffusers/stable-diffusion-xl-1.0-inpainting-0.1"
	},
	file: {
		name: "sdxl-inpaint/unet/diffusion_pytorch_model.fp16.safetensors",
		bytes: 5135178560
	},
	input: {
		size: 1024,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image"
}, Tt = {
	id: "sdxl-tile",
	name: "Sharpen with detail (SDXL tile ControlNet)",
	task: "enhance",
	summary: "Makes a picture crisper and cleaner while every shape stays where it was: hair strands, fabric folds, edges. The original colours are kept. Runs on this computer's GPU (about half a minute to a minute for a 1024 pixel picture once the models are loaded). Works together with the redraw model.",
	recommended: !0,
	license: {
		name: "Apache-2.0 (used with SDXL, OpenRAIL++-M)",
		commercialUse: "allowed",
		url: "https://huggingface.co/xinsir/controlnet-tile-sdxl-1.0"
	},
	sizeMb: 2502,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/xinsir/controlnet-tile-sdxl-1.0",
		download: "https://huggingface.co/xinsir/controlnet-tile-sdxl-1.0"
	},
	file: {
		name: "sdxl-tile/diffusion_pytorch_model.safetensors",
		bytes: 2502139104
	},
	input: {
		size: 1024,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image"
}, Et = (e) => {
	let t = e;
	return !!t && typeof t.id == "string" && /^[a-z0-9][a-z0-9-]*$/.test(t.id) && typeof t.name == "string" && (t.task === "cutout" || t.task === "inpaint" || t.task === "text-detect" || t.task === "text-read" || t.task === "upscale" || t.task === "redraw" || t.task === "enhance") && typeof t.file?.name == "string" && typeof t.links?.download == "string" && typeof t.input?.size == "number";
};
function Dt(e) {
	return [...e].filter(Et).sort((e, t) => Number(t.recommended) - Number(e.recommended) || e.name.localeCompare(t.name));
}
function Ot(e) {
	return {
		MODELS: e,
		findModel: (t) => e.find((e) => e.id === t),
		modelsFor: (t) => e.filter((e) => e.task === t)
	};
}
var { MODELS: kt, findModel: At, modelsFor: jt } = Ot(Dt(Object.values(/* @__PURE__ */ Object.assign({
	"../registry/birefnet-general-fp16.json": gt,
	"../registry/birefnet-lite-fp16.json": _t,
	"../registry/birefnet-lite.json": vt,
	"../registry/lama-fp32.json": yt,
	"../registry/ppocr-det-v4.json": bt,
	"../registry/ppocr-rec-v4.json": xt,
	"../registry/realesr-general-x4.json": St,
	"../registry/realesrgan-anime-x4.json": Ct,
	"../registry/realesrgan-x4plus.json": wt,
	"../registry/realplksr-x4.json": H,
	"../registry/sdxl-inpaint.json": U,
	"../registry/sdxl-tile.json": Tt
})))), Mt = {
	strength: .5,
	control: .6,
	guidance: 6,
	keepColour: !1,
	seed: 7,
	prompt: "professional studio product photograph of a collectible, clean even soft lighting, glossy finish, crisp detail, true to the original colours, e-commerce pack shot",
	negativePrompt: "blurry, low quality, noise, artifacts, deformed, extra parts, changed design, text, watermark, logo"
}, W = class extends Error {
	status;
	constructor(e, t) {
		super(t), this.status = e;
	}
}, Nt = "http://127.0.0.1:47321", G = {
	start: "npm run local:start",
	token: "npm run local:token",
	models: "npm run models",
	redrawSetup: "npm run redraw:setup",
	install: (e) => e && e !== "birefnet-lite-fp16" ? `npm run models:install -- ${e}` : "npm run models:install"
}, Pt = class {
	options;
	base;
	doFetch;
	constructor(e = {}) {
		this.options = e, this.base = (e.url ?? "http://127.0.0.1:47321").replace(/\/$/, "");
		let t = e.fetch;
		this.doFetch = (e, n) => (t ?? fetch)(e, n);
	}
	headers(e = {}) {
		return this.options.token ? {
			Authorization: `Bearer ${this.options.token}`,
			...e
		} : e;
	}
	async probe() {
		if (await this.health()) return "ok";
		try {
			return await this.doFetch(`${this.base}/health`, {
				mode: "no-cors",
				signal: AbortSignal.timeout(2500)
			}), "blocked";
		} catch {
			return "offline";
		}
	}
	async health() {
		try {
			let e = await this.doFetch(`${this.base}/health`, { signal: AbortSignal.timeout(2500) });
			if (!e.ok) return null;
			let t = await e.json();
			return t.app === "gleamshelf-local" ? t : null;
		} catch {
			return null;
		}
	}
	async inpaint(e, t, n) {
		let r = await this.doFetch(`${this.base}/inpaint?model=${encodeURIComponent(t)}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "image/png" }),
			body: e,
			signal: n
		});
		if (!r.ok) throw new W(r.status, await K(r));
		return new Blob([await r.arrayBuffer()], { type: "image/png" });
	}
	async upscale(e, t, n) {
		let r = await this.doFetch(`${this.base}/upscale?model=${encodeURIComponent(t)}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!r.ok) throw new W(r.status, await K(r));
		return new Blob([await r.arrayBuffer()], { type: "image/png" });
	}
	async redraw(e, t, n) {
		let r = new URLSearchParams({ prompt: t.prompt });
		t.stacked && r.set("stacked", "true"), t.box && r.set("box", t.box.join(",")), t.negative && r.set("negative", t.negative);
		for (let e of [
			"strength",
			"steps",
			"guidance",
			"candidates",
			"seed"
		]) t[e] !== void 0 && r.set(e, String(t[e]));
		let i = await this.doFetch(`${this.base}/redraw?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "image/png" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new W(i.status, await K(i));
		return new Blob([await i.arrayBuffer()], { type: "image/png" });
	}
	async enhance(e, t = {}, n) {
		let r = new URLSearchParams();
		t.prompt && r.set("prompt", t.prompt), t.negativePrompt && r.set("negativePrompt", t.negativePrompt);
		for (let e of [
			"strength",
			"seed",
			"control",
			"guidance"
		]) t[e] !== void 0 && r.set(e, String(t[e]));
		t.keepColour === !1 && r.set("keepColour", "false");
		let i = await this.doFetch(`${this.base}/enhance?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "image/png" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new W(i.status, await K(i));
		return new Blob([await i.arrayBuffer()], { type: "image/png" });
	}
	gloss(e, t) {
		return this.enhance(e, Mt, t);
	}
	async readText(e, t) {
		let n = await this.doFetch(`${this.base}/read-text`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: t
		});
		if (!n.ok) throw new W(n.status, await K(n));
		return (await n.json()).boxes;
	}
	async detectText(e, t, n) {
		let r = await this.doFetch(`${this.base}/detect-text?model=${encodeURIComponent(t)}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!r.ok) throw new W(r.status, await K(r));
		return (await r.json()).boxes;
	}
	async startProcess(e, t = {}, n) {
		let r = new URLSearchParams();
		t.mode && r.set("mode", t.mode), t.vivid !== void 0 && r.set("vivid", String(t.vivid));
		for (let e of [
			"find",
			"listing",
			"enlarge",
			"stickers",
			"lettering",
			"thinParts",
			"colour",
			"look",
			"gloss",
			"review"
		]) t[e] !== void 0 && r.set(e, t[e] ? "1" : "0");
		let i = await this.doFetch(`${this.base}/process?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new W(i.status, await K(i));
		return (await i.json()).id;
	}
	async processStatus(e, t) {
		let n = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}`, {
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new W(n.status, await K(n));
		return await n.json();
	}
	async foundPicture(e, t, n) {
		let r = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/found/${t}.jpg`, {
			headers: this.headers(),
			signal: n
		});
		if (!r.ok) throw new W(r.status, await K(r));
		return new Blob([await r.arrayBuffer()], { type: "image/jpeg" });
	}
	async chooseReferences(e, t, n) {
		let r = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/choose`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify({ use: t }),
			signal: n
		});
		if (!r.ok) throw new W(r.status, await K(r));
	}
	async cancelProcess(e, t) {
		let n = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/cancel`, {
			method: "POST",
			headers: this.headers(),
			signal: t
		});
		if (!n.ok && n.status !== 404) throw new W(n.status, await K(n));
	}
	async processPicture(e, t = "cutout", n) {
		let r = t === "cutout" ? "cutout.png" : t === "changes" ? "changes.png" : "studio.jpg", i = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/${r}`, {
			headers: this.headers(),
			signal: n
		});
		if (!i.ok) throw new W(i.status, await K(i));
		return new Blob([await i.arrayBuffer()], { type: t === "studio" ? "image/jpeg" : "image/png" });
	}
	async recentRuns(e) {
		let t = await this.doFetch(`${this.base}/process/recent`, {
			headers: this.headers(),
			signal: e
		});
		if (!t.ok) throw new W(t.status, await K(t));
		return (await t.json()).runs;
	}
	async phoneStart(e) {
		let t = await this.doFetch(`${this.base}/phone/start`, {
			method: "POST",
			headers: this.headers(),
			signal: e
		});
		if (!t.ok) throw new W(t.status, await K(t));
		return await t.json();
	}
	async phonePhotos(e) {
		let t = await this.doFetch(`${this.base}/phone/photos`, {
			headers: this.headers(),
			signal: e
		});
		if (!t.ok) throw new W(t.status, await K(t));
		return (await t.json()).photos;
	}
	async phonePhoto(e, t) {
		let n = await this.doFetch(`${this.base}/phone/photos/${encodeURIComponent(e)}`, {
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new W(n.status, await K(n));
		return new Blob([await n.arrayBuffer()], { type: n.headers.get("Content-Type") ?? "image/jpeg" });
	}
	async models() {
		let e = await this.doFetch(`${this.base}/models`, { headers: this.headers() });
		if (!e.ok) throw new W(e.status, await K(e));
		return (await e.json()).models;
	}
	async cutout(e, t, n, r = {}) {
		let i = await this.doFetch(`${this.base}/cutout?model=${encodeURIComponent(t)}${r.thinParts ? "&refine=thin" : ""}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new W(i.status, await K(i));
		let a = Number(i.headers.get("X-Mask-Width")), o = Number(i.headers.get("X-Mask-Height")), s = new Uint8Array(await i.arrayBuffer());
		if (!(a > 0 && o > 0) || s.length !== a * o) throw new W(502, "The companion app sent a mask in a format this editor does not understand.");
		return {
			alpha: s,
			width: a,
			height: o,
			...i.headers.get("X-Mask-Parts") === "kept" ? { partsKept: !0 } : {}
		};
	}
};
async function K(e) {
	let t = await e.json().catch(() => null);
	return e.status === 401 ? "The companion app did not accept the pairing token. Copy it again from the app and paste it in." : t?.error ?? `The companion app answered ${e.status}.`;
}
//#endregion
//#region src/useLocalApp.ts
var Ft = "gleamshelf:local-app";
function It() {
	try {
		let e = /(?:^#|&)pair=([A-Za-z0-9_-]{16,128})/.exec(window.location.hash);
		return e ? (window.history.replaceState(null, "", window.location.pathname + window.location.search), e[1]) : null;
	} catch {
		return null;
	}
}
function Lt() {
	let e = It();
	if (e) {
		let t = Nt;
		try {
			let e = JSON.parse(localStorage.getItem(Ft) ?? "{}");
			typeof e.url == "string" && (t = e.url);
		} catch {}
		return Rt({
			url: t,
			token: e
		}), {
			url: t,
			token: e
		};
	}
	try {
		let e = JSON.parse(localStorage.getItem(Ft) ?? "{}");
		return {
			url: typeof e.url == "string" ? e.url : Nt,
			token: typeof e.token == "string" ? e.token : ""
		};
	} catch {
		return {
			url: Nt,
			token: ""
		};
	}
}
function Rt(e) {
	try {
		localStorage.setItem(Ft, JSON.stringify(e));
	} catch {}
}
function zt(e) {
	let [t, n] = j(() => ({
		...Lt(),
		...e?.url ? { url: e.url } : {},
		...e?.token ? { token: e.token } : {}
	})), [r, i] = j("checking"), [a, o] = j(null), [s, c] = j(null), [l, u] = j([]), d = Ce(() => new Pt({
		url: t.url,
		token: t.token
	}), [t]), f = O(async () => {
		c(null);
		let e = await d.probe();
		if (e === "ok" && u((await d.health())?.features ?? []), e !== "ok") i(e === "blocked" ? "blocked" : "offline"), o(null);
		else if (!t.token) i("needs-token"), o(null);
		else try {
			o(await d.models()), i("ready");
		} catch (e) {
			o(null), c(e instanceof Error ? e.message : "The companion app did not answer."), e instanceof W && e.status === 401 ? (n((e) => ({
				...e,
				token: ""
			})), i("needs-token")) : i("offline");
		}
	}, [d, t.token]);
	return k(() => {
		f();
	}, [f]), k(() => {
		if (r !== "offline" && r !== "blocked") return;
		let e = setInterval(() => void f(), 3e3);
		return () => clearInterval(e);
	}, [r, f]), {
		state: r,
		saved: t,
		client: d,
		models: a,
		installed: (e) => a?.filter((t) => t.task === e && t.installed) ?? [],
		problem: s,
		setProblem: c,
		check: f,
		connect: (e) => {
			let r = {
				...t,
				token: e.trim()
			};
			Rt(r), n(r);
		},
		canProcess: l.includes("process"),
		canPhone: l.includes("phone")
	};
}
//#endregion
//#region src/AiCutout.tsx
function Bt({ app: e, what: t }) {
	let [n, r] = j("");
	return e.state === "checking" ? /* @__PURE__ */ N("p", {
		className: "gs-hint",
		children: "Looking for the Gleamshelf app on this computer…"
	}) : e.state === "blocked" ? /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ P("p", {
		className: "gs-error",
		children: [
			"The Gleamshelf app is running at ",
			e.saved.url,
			", but this browser will not let the page talk to it. Safari does this. Open the editor in Chrome or Edge, or serve it from ",
			/* @__PURE__ */ N("code", { children: "http://localhost" }),
			"."
		]
	}), /* @__PURE__ */ N("button", {
		type: "button",
		className: "gs-button",
		onClick: () => void e.check(),
		children: "Check again"
	})] }) : e.state === "offline" ? /* @__PURE__ */ P(M, { children: [
		/* @__PURE__ */ P("p", {
			className: "gs-hint",
			children: [
				t.intro,
				" It needs the small Gleamshelf app running on this computer (your photos never leave it). Nothing answered at",
				" ",
				/* @__PURE__ */ N("code", { children: e.saved.url }),
				". This page keeps looking, so it will notice as soon as the app starts."
			]
		}),
		/* @__PURE__ */ P("ol", {
			className: "gs-steps",
			children: [/* @__PURE__ */ P("li", { children: [
				"Open a terminal in the Gleamshelf folder and run ",
				/* @__PURE__ */ N("code", { children: G.start }),
				". ",
				/* @__PURE__ */ N("strong", { children: "Leave it running" }),
				" while you edit."
			] }), /* @__PURE__ */ P("li", { children: [
				"Once, if you have not yet: ",
				/* @__PURE__ */ N("code", { children: t.install }),
				" (it says \"Already installed\" when the model is there; that is fine, the app still has to be started)."
			] })]
		}),
		/* @__PURE__ */ N("button", {
			type: "button",
			className: "gs-button",
			onClick: () => void e.check(),
			children: "Check now"
		})
	] }) : e.state === "needs-token" ? /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ P("p", {
		className: "gs-hint",
		children: [
			"The app is running. Paste its pairing token to connect. The token is a 32-character code. It is printed when you start the app, and again by ",
			/* @__PURE__ */ N("code", { children: G.token }),
			" (it is the last line of the output)."
		]
	}), /* @__PURE__ */ P("div", {
		className: "gs-crop-tools",
		children: [/* @__PURE__ */ N("input", {
			type: "password",
			className: "gs-input",
			"aria-label": "Pairing token",
			placeholder: "Pairing token",
			value: n,
			onChange: (e) => r(e.target.value)
		}), /* @__PURE__ */ N("button", {
			type: "button",
			className: "gs-button",
			disabled: !n.trim(),
			onClick: () => {
				e.connect(n), r("");
			},
			children: "Connect"
		})]
	})] }) : null;
}
function Vt({ getPhoto: e, onMask: t, greenBackdrop: n, app: r }) {
	let [i, a] = j(""), [o, s] = j(!1), [c, l] = j("product"), u = jt("cutout"), d = r.installed("cutout"), f = i && d.some((e) => e.id === i) ? i : d[0]?.id ?? "", p = At(f), m = async () => {
		s(!0), r.setProblem(null);
		try {
			t(f, await r.client.cutout(await e(c), f, void 0, { thinParts: c === "character" }), c);
		} catch (e) {
			r.setProblem(e instanceof Error ? e.message : "The cut-out did not work.");
		} finally {
			s(!1);
		}
	};
	return /* @__PURE__ */ P("div", {
		className: "gs-ai",
		children: [
			/* @__PURE__ */ P("div", {
				className: "gs-ai__title",
				children: [/* @__PURE__ */ N("strong", { children: "AI cut-out" }), /* @__PURE__ */ N("span", {
					className: "gs-badge gs-badge--free",
					title: "The model runs on your computer. Nothing is sent anywhere and nothing is charged.",
					children: "free · on your computer"
				})]
			}),
			/* @__PURE__ */ N(ue, { id: "aiCutout" }),
			/* @__PURE__ */ N(Bt, {
				app: r,
				what: {
					intro: "Works for any background, not just green.",
					install: G.install(u.find((e) => e.recommended)?.id)
				}
			}),
			r.state === "ready" && /* @__PURE__ */ P(M, { children: [d.length === 0 ? /* @__PURE__ */ P("p", {
				className: "gs-hint",
				children: [
					"No cut-out model is installed yet. Run ",
					/* @__PURE__ */ N("code", { children: G.install(u.find((e) => e.recommended)?.id) }),
					", then",
					" ",
					/* @__PURE__ */ N("button", {
						type: "button",
						className: "gs-link",
						onClick: () => void r.check(),
						children: "check again"
					}),
					"."
				]
			}) : /* @__PURE__ */ P(M, { children: [
				/* @__PURE__ */ P("label", {
					className: "gs-control",
					children: [/* @__PURE__ */ N("span", {
						className: "gs-control__row",
						children: /* @__PURE__ */ N("span", { children: "Model" })
					}), /* @__PURE__ */ N("select", {
						value: f,
						onChange: (e) => a(e.target.value),
						children: d.map((e) => /* @__PURE__ */ N("option", {
							value: e.id,
							children: e.name
						}, e.id))
					})]
				}),
				/* @__PURE__ */ P("div", {
					className: "gs-segmented",
					role: "group",
					"aria-label": "What to cut out",
					children: [/* @__PURE__ */ N("button", {
						type: "button",
						className: `gs-button ${c === "product" ? "is-active" : ""}`,
						"aria-pressed": c === "product",
						onClick: () => l("product"),
						title: "The whole box or product, without its background",
						children: "Whole product"
					}), /* @__PURE__ */ N("button", {
						type: "button",
						className: `gs-button ${c === "character" ? "is-active" : ""}`,
						"aria-pressed": c === "character",
						onClick: () => l("character"),
						title: "Only the character in the artwork on a box cover",
						children: "Character on cover"
					})]
				}),
				c === "product" && n && /* @__PURE__ */ P("p", {
					className: "gs-hint",
					children: [
						/* @__PURE__ */ N("strong", { children: "This photo has a green backdrop." }),
						" The free ",
						/* @__PURE__ */ N("em", { children: "Remove green backdrop" }),
						" button above does the same job instantly, so AI is not needed here. AI is for photos on any other background, or for picking out the character on a box cover."
					]
				}),
				c === "character" && /* @__PURE__ */ P("p", {
					className: "gs-hint",
					children: [
						"Use ",
						/* @__PURE__ */ N("strong", { children: "Crop" }),
						" first to frame just the artwork (leave out the logos, price tags and title text), then cut out. The character is found inside the crop. Printed words that cross the character stay with it; remove them with",
						" ",
						/* @__PURE__ */ N("strong", { children: "Printed lettering" }),
						" in the Clean up tab."
					]
				}),
				p && /* @__PURE__ */ P("p", {
					className: "gs-hint",
					children: [
						p.summary,
						" ",
						/* @__PURE__ */ N("a", {
							href: p.links.modelCard,
							target: "_blank",
							rel: "noreferrer",
							children: "About this model"
						}),
						" ",
						"· ",
						p.license.name,
						" licence, commercial use ",
						p.license.commercialUse
					]
				}),
				/* @__PURE__ */ N("button", {
					type: "button",
					className: "gs-button gs-button--primary",
					disabled: o || !f,
					onClick: () => void m(),
					children: o ? c === "character" ? "Working… also looking for thin parts, about 30 seconds" : "Working… the first run loads the model" : c === "character" ? "Cut out the character" : "Cut out with AI"
				})
			] }), u.some((e) => !r.models?.find((t) => t.id === e.id)?.installed) && /* @__PURE__ */ P("details", {
				className: "gs-hint",
				children: [/* @__PURE__ */ N("summary", { children: "More models" }), /* @__PURE__ */ N("ul", {
					className: "gs-models",
					children: u.filter((e) => !r.models?.find((t) => t.id === e.id)?.installed).map((e) => /* @__PURE__ */ P("li", { children: [
						/* @__PURE__ */ N("strong", { children: e.name }),
						" · ",
						e.sizeMb,
						" MB · ",
						e.license.name,
						/* @__PURE__ */ N("br", {}),
						e.summary,
						" ",
						/* @__PURE__ */ N("a", {
							href: e.links.modelCard,
							target: "_blank",
							rel: "noreferrer",
							children: "Read about it"
						}),
						/* @__PURE__ */ N("br", {}),
						/* @__PURE__ */ N("code", { children: G.install(e.id) })
					] }, e.id))
				})]
			})] }),
			r.problem && /* @__PURE__ */ N("p", {
				className: "gs-error",
				children: r.problem
			})
		]
	});
}
//#endregion
//#region src/AiEnlarge.tsx
function Ht({ getPicture: e, onEnlarged: t, onRemove: n, applied: r, app: i, sharpen: a }) {
	let [o, s] = j(!1), [c, l] = j(!1), [u, d] = j(""), f = jt("upscale"), p = i.installed("upscale"), m = u && p.some((e) => e.id === u) ? u : p[0]?.id ?? "", h = At(m), g = f.find((e) => e.recommended), _ = async () => {
		s(!0), i.setProblem(null);
		try {
			let n = await e();
			c && a && (n = await a(n)), t(m, await i.client.upscale(n, m));
		} catch (e) {
			i.setProblem(e instanceof Error ? e.message : "The enlarging did not work.");
		} finally {
			s(!1);
		}
	};
	return /* @__PURE__ */ P("div", {
		className: "gs-ai",
		children: [
			/* @__PURE__ */ P("div", {
				className: "gs-ai__title",
				children: [/* @__PURE__ */ N("strong", { children: "Sharpen & enlarge" }), /* @__PURE__ */ N("span", {
					className: "gs-badge gs-badge--free",
					title: "The model runs on your computer. Nothing is sent anywhere and nothing is charged.",
					children: "free · on your computer"
				})]
			}),
			/* @__PURE__ */ N(ue, { id: "enlarge" }),
			/* @__PURE__ */ N(Bt, {
				app: i,
				what: {
					intro: "Rebuilds fine detail so the picture is clearly sharper and can be saved larger.",
					install: G.install(g?.id)
				}
			}),
			i.state === "ready" && (p.length === 0 ? /* @__PURE__ */ P("p", {
				className: "gs-hint",
				children: [
					"No enlarging model is installed yet. Run ",
					/* @__PURE__ */ N("code", { children: G.install(g?.id) }),
					" (",
					g?.sizeMb,
					" MB), then",
					" ",
					/* @__PURE__ */ N("button", {
						type: "button",
						className: "gs-link",
						onClick: () => void i.check(),
						children: "check again"
					}),
					"."
				]
			}) : /* @__PURE__ */ P(M, { children: [
				/* @__PURE__ */ P("label", {
					className: "gs-control",
					children: [/* @__PURE__ */ N("span", {
						className: "gs-control__row",
						children: /* @__PURE__ */ N("span", { children: "Model" })
					}), /* @__PURE__ */ N("select", {
						value: m,
						onChange: (e) => d(e.target.value),
						children: p.map((e) => /* @__PURE__ */ N("option", {
							value: e.id,
							children: e.name
						}, e.id))
					})]
				}),
				h && /* @__PURE__ */ P("p", {
					className: "gs-hint",
					children: [
						h.summary,
						" ",
						/* @__PURE__ */ N("a", {
							href: h.links.modelCard,
							target: "_blank",
							rel: "noreferrer",
							children: "About this model"
						}),
						" ",
						"· ",
						h.license.name,
						"; check it allows your use. It adds believable detail that was not in the photo."
					]
				}),
				a && /* @__PURE__ */ P("label", {
					className: "gs-control gs-control--inline",
					title: "Re-draws the picture slightly with Stable Diffusion, pinned to the original shapes, so hair, fabric and edges come back crisper. Colours are kept. Free, on your computer.",
					children: [/* @__PURE__ */ N("input", {
						type: "checkbox",
						checked: c,
						onChange: (e) => l(e.target.checked)
					}), "Add detail first (slower, about a minute). Not for a box with small print: it redraws small text as gibberish."]
				}),
				/* @__PURE__ */ P("div", {
					className: "gs-crop-tools",
					children: [/* @__PURE__ */ N("button", {
						type: "button",
						className: "gs-button gs-button--primary",
						disabled: o || !m,
						onClick: () => void _(),
						children: o ? c && a ? "Sharpening… about a minute" : "Enlarging… a few seconds" : r ? "Enlarge again" : "Sharpen & enlarge"
					}), r && /* @__PURE__ */ N("button", {
						type: "button",
						className: "gs-button",
						onClick: n,
						children: "Remove"
					})]
				}),
				r && /* @__PURE__ */ P("p", {
					className: "gs-hint",
					children: [
						"Applied: the saved picture is ",
						r.factor,
						" times larger than the original photo. Do the lettering first: changing it later removes this."
					]
				})
			] })),
			i.problem && /* @__PURE__ */ N("p", {
				className: "gs-error",
				children: i.problem
			})
		]
	});
}
//#endregion
//#region src/PickOverlay.tsx
function Ut({ editor: e, width: t, height: n, onPick: r }) {
	return /* @__PURE__ */ N("div", {
		className: "gs-pick",
		style: {
			width: t,
			height: n
		},
		onPointerDown: (t) => {
			t.preventDefault();
			let n = t.currentTarget.getBoundingClientRect(), [i, a] = p(ee(e.document), (t.clientX - n.left) / n.width, (t.clientY - n.top) / n.height);
			r(Math.min(1, Math.max(0, i)), Math.min(1, Math.max(0, a)));
		}
	});
}
//#endregion
//#region src/AiFill.tsx
function Wt({ buildInput: e, onFilled: t, applied: n, app: r, busyOutside: i }) {
	let [a, o] = j(!1), s = a || !!i, [c, l] = j(!0), u = jt("inpaint"), d = jt("text-detect"), f = r.installed("inpaint")[0], p = r.installed("text-detect")[0], m = At(f?.id ?? u[0]?.id ?? ""), h = u.find((e) => e.recommended), g = async () => {
		if (f) {
			o(!0), r.setProblem(null);
			try {
				let n = await e({
					otherText: c && !!p,
					textModel: p?.id,
					client: r.client
				});
				n ? t(f.id, await r.client.inpaint(n.picture, f.id), n.cutAway) : r.setProblem("Nothing to fill: no lettering or printed text was found. Try a lower \"How white\" above.");
			} catch (e) {
				r.setProblem(e instanceof Error ? e.message : "The fill did not work.");
			} finally {
				o(!1);
			}
		}
	};
	return /* @__PURE__ */ P("div", {
		className: "gs-ai",
		children: [
			/* @__PURE__ */ P("div", {
				className: "gs-ai__title",
				children: [/* @__PURE__ */ N("strong", { children: "AI fill" }), /* @__PURE__ */ N("span", {
					className: "gs-badge gs-badge--free",
					title: "The model runs on your computer. Nothing is sent anywhere and nothing is charged.",
					children: "free · on your computer"
				})]
			}),
			/* @__PURE__ */ N(ue, { id: "aiFill" }),
			/* @__PURE__ */ N(Bt, {
				app: r,
				what: {
					intro: "A cleaner fill than the free one: it repaints hair, fabric and skin where the words were.",
					install: G.install(h?.id)
				}
			}),
			r.state === "ready" && /* @__PURE__ */ N(M, { children: f ? /* @__PURE__ */ P(M, { children: [
				/* @__PURE__ */ P("p", {
					className: "gs-hint",
					children: [
						m?.summary,
						" ",
						/* @__PURE__ */ N("a", {
							href: m?.links.modelCard,
							target: "_blank",
							rel: "noreferrer",
							children: "About this model"
						}),
						" ",
						"· ",
						m?.license.name,
						" licence. It invents the part hidden under the words, so look closely at the result."
					]
				}),
				/* @__PURE__ */ P("label", {
					className: "gs-control gs-control--inline",
					title: p ? "Finds other printed text (any colour) and fills it in too" : `Needs the text finder: ${G.install(d[0]?.id)}`,
					children: [
						/* @__PURE__ */ N("input", {
							type: "checkbox",
							checked: c && !!p,
							disabled: !p,
							onChange: (e) => l(e.target.checked)
						}),
						"Also fill other printed text",
						p ? "" : " (needs the text finder)"
					]
				}),
				!p && d[0] && /* @__PURE__ */ P("p", {
					className: "gs-hint",
					children: [
						"Text finder: ",
						d[0].name,
						", ",
						d[0].sizeMb,
						" MB, ",
						d[0].license.name,
						".",
						" ",
						/* @__PURE__ */ N("code", { children: G.install(d[0].id) })
					]
				}),
				/* @__PURE__ */ N("button", {
					type: "button",
					className: "gs-button gs-button--primary",
					disabled: s,
					onClick: () => void g(),
					children: s ? "Filling… a few seconds" : n ? "Fill again with AI" : "Fill with AI"
				})
			] }) : /* @__PURE__ */ P("p", {
				className: "gs-hint",
				children: [
					"No fill model is installed yet (",
					m ? `${m.name}, ${m.sizeMb} MB, ${m.license.name}` : "LaMa",
					"). Run",
					" ",
					/* @__PURE__ */ N("code", { children: G.install(h?.id) }),
					", then",
					" ",
					/* @__PURE__ */ N("button", {
						type: "button",
						className: "gs-link",
						onClick: () => void r.check(),
						children: "check again"
					}),
					"."
				]
			}) }),
			r.problem && /* @__PURE__ */ N("p", {
				className: "gs-error",
				children: r.problem
			})
		]
	});
}
//#endregion
//#region src/AiFinish.tsx
function Gt({ app: e, applied: t, onRedrawArea: n, onCancelArea: r, picking: i, onRemove: a, note: o, busyOutside: s }) {
	let [c, l] = j(!1), u = c || s, [d, f] = j(""), [p, m] = j(!0), h = e.state === "ready" && e.installed("redraw").length > 0;
	return /* @__PURE__ */ P("div", {
		className: "gs-ai",
		children: [
			/* @__PURE__ */ P("div", {
				className: "gs-ai__title",
				children: [/* @__PURE__ */ N("strong", { children: "Finishing touches (AI redraw)" }), /* @__PURE__ */ N("span", {
					className: "gs-badge gs-badge--free",
					title: "The model runs on your computer. Nothing is sent anywhere and nothing is charged.",
					children: "free · on your computer · about 30 s"
				})]
			}),
			/* @__PURE__ */ N(ue, { id: "finish" }),
			/* @__PURE__ */ N(Bt, {
				app: e,
				what: {
					intro: "Redraws an area you choose, for a part the photo cuts off or something the fill missed. Nothing is invented elsewhere.",
					install: G.redrawSetup
				}
			}),
			e.state === "ready" && !h && /* @__PURE__ */ P("p", {
				className: "gs-hint",
				children: [
					"The redraw model is not set up yet. Run ",
					/* @__PURE__ */ N("code", { children: G.redrawSetup }),
					" once (about 7 GB; it asks first), then",
					" ",
					/* @__PURE__ */ N("button", {
						type: "button",
						className: "gs-link",
						onClick: () => void e.check(),
						children: "check again"
					}),
					"."
				]
			}),
			h && /* @__PURE__ */ P(M, { children: [
				/* @__PURE__ */ P("label", {
					className: "gs-control",
					children: [/* @__PURE__ */ N("span", {
						className: "gs-control__row",
						children: /* @__PURE__ */ N("span", { children: "Redraw an area as…" })
					}), /* @__PURE__ */ N("input", {
						className: "gs-input",
						value: d,
						maxLength: 400,
						placeholder: "e.g. smooth blue plastic hair",
						onChange: (e) => f(e.target.value)
					})]
				}),
				/* @__PURE__ */ P("label", {
					className: "gs-control gs-control--inline",
					children: [/* @__PURE__ */ N("input", {
						type: "checkbox",
						checked: p,
						onChange: (e) => m(e.target.checked)
					}), "Keep what is there as a guide (less change)"]
				}),
				/* @__PURE__ */ P("div", {
					className: "gs-crop-tools",
					children: [/* @__PURE__ */ N("button", {
						type: "button",
						className: "gs-button",
						disabled: u || t || !d.trim(),
						onClick: () => i ? r() : n(d.trim(), p),
						children: i ? "Cancel" : "Choose the area…"
					}), t && /* @__PURE__ */ N("button", {
						type: "button",
						className: "gs-button",
						disabled: u,
						onClick: a,
						children: "Remove"
					})]
				}),
				t && /* @__PURE__ */ N("p", {
					className: "gs-hint",
					children: "Applied. This is the last step: changing anything else in the editor takes it off (Undo brings it back)."
				}),
				/* @__PURE__ */ N("p", {
					className: "gs-hint",
					children: "The model draws new pixels, so it can differ from the real item. Check the result before listing, and do not use it where a buyer needs to see the actual condition."
				})
			] }),
			o && /* @__PURE__ */ N("p", {
				className: "gs-hint",
				children: o
			}),
			e.problem && /* @__PURE__ */ N("p", {
				className: "gs-error",
				children: e.problem
			})
		]
	});
}
//#endregion
//#region src/AreaOverlay.tsx
function Kt({ width: e, height: t, onArea: n }) {
	let r = A(null), [i, a] = j(null), o = (e) => {
		let t = e.currentTarget.getBoundingClientRect();
		return {
			x: Math.min(1, Math.max(0, (e.clientX - t.left) / t.width)),
			y: Math.min(1, Math.max(0, (e.clientY - t.top) / t.height))
		};
	}, s = (e, t) => ({
		x: Math.min(e.x, t.x),
		y: Math.min(e.y, t.y),
		width: Math.abs(e.x - t.x),
		height: Math.abs(e.y - t.y)
	});
	return /* @__PURE__ */ N("div", {
		className: "gs-pick",
		style: {
			width: e,
			height: t
		},
		onPointerDown: (e) => {
			e.preventDefault(), e.currentTarget.setPointerCapture(e.pointerId), r.current = o(e), a(null);
		},
		onPointerMove: (e) => r.current && a(s(r.current, o(e))),
		onPointerUp: (e) => {
			if (!r.current) return;
			let t = s(r.current, o(e));
			r.current = null, a(null), t.width > .02 && t.height > .02 && n([
				t.x,
				t.y,
				t.width,
				t.height
			]);
		},
		children: i && /* @__PURE__ */ N("div", {
			className: "gs-area",
			style: {
				left: `${i.x * 100}%`,
				top: `${i.y * 100}%`,
				width: `${i.width * 100}%`,
				height: `${i.height * 100}%`
			}
		})
	});
}
//#endregion
//#region ../canvas/src/document.ts
var qt = [
	{
		id: "normal",
		label: "Normal"
	},
	{
		id: "multiply",
		label: "Multiply (darker)"
	},
	{
		id: "darken",
		label: "Keep darker"
	},
	{
		id: "color-burn",
		label: "Burn"
	},
	{
		id: "screen",
		label: "Screen (lighter)"
	},
	{
		id: "lighten",
		label: "Keep lighter"
	},
	{
		id: "color-dodge",
		label: "Dodge"
	},
	{
		id: "overlay",
		label: "Overlay"
	},
	{
		id: "soft-light",
		label: "Soft light"
	},
	{
		id: "hard-light",
		label: "Hard light"
	},
	{
		id: "difference",
		label: "Difference"
	},
	{
		id: "exclusion",
		label: "Exclusion"
	},
	{
		id: "hue",
		label: "Hue only"
	},
	{
		id: "saturation",
		label: "Saturation only"
	},
	{
		id: "color",
		label: "Colour only"
	},
	{
		id: "luminosity",
		label: "Brightness only"
	}
], Jt = {
	x: 0,
	y: 0,
	scaleX: 1,
	scaleY: 1,
	rotation: 0
}, Yt = 0, Xt = (e) => `${e}-${Date.now().toString(36)}-${(Yt++).toString(36)}`, Zt = (e, t) => ({
	width: e,
	height: t,
	data: new Uint8ClampedArray(e * t * 4)
}), Qt = (e) => ({
	width: e.width,
	height: e.height,
	data: new Uint8ClampedArray(e.data)
}), $t = class {
	map = /* @__PURE__ */ new Map();
	get(e) {
		return this.map.get(e);
	}
	add(e, t = "px") {
		let n = Xt(t);
		return this.map.set(n, e), n;
	}
	set(e, t) {
		this.map.set(e, t);
	}
	get size() {
		return this.map.size;
	}
	keepOnly(e) {
		let t = /* @__PURE__ */ new Set();
		for (let n of e) for (let e of en(n)) t.add(e);
		for (let e of [...this.map.keys()]) t.has(e) || this.map.delete(e);
	}
};
function en(e) {
	let t = [];
	for (let n of e.layers) n.kind === "raster" && t.push(n.pixels), n.mask && t.push(n.mask);
	return t;
}
function tn(e, t, n = "#ffffff") {
	if (!(e >= 1 && t >= 1 && e <= 16384 && t <= 16384)) throw Error("A canvas must be 1 to 16384 pixels on each side.");
	return {
		width: Math.round(e),
		height: Math.round(t),
		background: n,
		layers: []
	};
}
var nn = (e, t) => ({
	id: Xt(t),
	name: e,
	visible: !0,
	locked: !1,
	opacity: 1,
	blend: "normal",
	transform: { ...Jt }
}), rn = (e, t, n = {}) => ({
	...nn(e, "raster"),
	kind: "raster",
	pixels: t,
	transform: {
		...Jt,
		...n
	}
}), an = (e, t, n = {}, r = {}) => ({
	...nn(e, "shape"),
	kind: "shape",
	shape: t,
	fill: "#e46a9b",
	stroke: null,
	strokeWidth: 4,
	...n,
	transform: {
		...Jt,
		...r
	}
}), on = (e, t = {}, n = {}) => ({
	...nn(e.split("\n")[0].slice(0, 24) || "Text", "text"),
	kind: "text",
	text: e,
	font: "system-ui, sans-serif",
	size: 64,
	weight: 700,
	italic: !1,
	color: "#1a1a1a",
	align: "left",
	lineHeight: 1.2,
	box: {
		width: 0,
		height: 0
	},
	...t,
	transform: {
		...Jt,
		...n
	}
}), sn = (e, t) => e.layers.find((e) => e.id === t);
function cn(e, t, n) {
	let r = [...e.layers], i = n ? r.findIndex((e) => e.id === n) : -1;
	return r.splice(i >= 0 ? i + 1 : r.length, 0, t), {
		...e,
		layers: r
	};
}
function q(e, t, n) {
	return {
		...e,
		layers: e.layers.map((e) => e.id === t ? {
			...e,
			...n
		} : e)
	};
}
var ln = (e, t) => ({
	...e,
	layers: e.layers.filter((e) => e.id !== t)
});
function un(e, t, n) {
	let r = [...e.layers], i = r.findIndex((e) => e.id === t);
	if (i < 0) return e;
	let a = Math.max(0, Math.min(r.length - 1, n === Infinity ? r.length - 1 : n === -Infinity ? 0 : i + n));
	if (a === i) return e;
	let [o] = r.splice(i, 1);
	return r.splice(a, 0, o), {
		...e,
		layers: r
	};
}
function dn(e, t, n) {
	let r = sn(e, n);
	if (!r) return {
		doc: e,
		id: n
	};
	let i = {
		...r,
		id: Xt(r.kind),
		name: `${r.name} copy`
	};
	return i.kind === "raster" && (i.pixels = t.add(Qt(t.get(i.pixels)))), i.mask &&= t.add(Qt(t.get(i.mask)), "mask"), {
		doc: cn(e, i, n),
		id: i.id
	};
}
//#endregion
//#region ../canvas/src/geometry.ts
function fn(e) {
	let t = Math.cos(e.rotation), n = Math.sin(e.rotation);
	return {
		a: t * e.scaleX,
		b: n * e.scaleX,
		c: -n * e.scaleY,
		d: t * e.scaleY,
		e: e.x,
		f: e.y
	};
}
function pn(e) {
	let t = e.a * e.d - e.b * e.c;
	return t ? {
		a: e.d / t,
		b: -e.b / t,
		c: -e.c / t,
		d: e.a / t,
		e: (e.c * e.f - e.d * e.e) / t,
		f: (e.b * e.e - e.a * e.f) / t
	} : {
		a: 1,
		b: 0,
		c: 0,
		d: 1,
		e: -e.e,
		f: -e.f
	};
}
var mn = (e, t) => ({
	x: e.a * t.x + e.c * t.y + e.e,
	y: e.b * t.x + e.d * t.y + e.f
}), hn = (e, t) => mn(pn(fn(e.transform)), t);
function gn(e, t) {
	switch (e.kind) {
		case "raster": {
			let n = t?.get(e.pixels);
			return {
				x: 0,
				y: 0,
				width: n?.width ?? 0,
				height: n?.height ?? 0
			};
		}
		case "text": return {
			x: e.align === "center" ? -e.box.width / 2 : e.align === "right" ? -e.box.width : 0,
			y: 0,
			...e.box
		};
		case "shape": {
			let t = e.shape, n = e.stroke ? e.strokeWidth / 2 : 0, r;
			return r = t.type === "rect" || t.type === "ellipse" ? {
				x: 0,
				y: 0,
				width: t.width,
				height: t.height
			} : t.type === "line" ? {
				x: Math.min(0, t.x2),
				y: Math.min(0, t.y2),
				width: Math.abs(t.x2),
				height: Math.abs(t.y2)
			} : yn(t.path), {
				x: r.x - n,
				y: r.y - n,
				width: r.width + n * 2,
				height: r.height + n * 2
			};
		}
	}
}
function _n(e, t) {
	let n = gn(e, t), r = fn(e.transform);
	return [
		{
			x: n.x,
			y: n.y
		},
		{
			x: n.x + n.width,
			y: n.y
		},
		{
			x: n.x + n.width,
			y: n.y + n.height
		},
		{
			x: n.x,
			y: n.y + n.height
		}
	].map((e) => mn(r, e));
}
function vn(e, t, n) {
	for (let r = e.layers.length - 1; r >= 0; r--) {
		let i = e.layers[r];
		if (!i.visible || i.locked) continue;
		let a = hn(i, n), o = gn(i, t);
		if (!(a.x < o.x || a.y < o.y || a.x >= o.x + o.width || a.y >= o.y + o.height)) {
			if (i.kind === "raster") {
				let e = t.get(i.pixels);
				if (e.data[(Math.floor(a.y) * e.width + Math.floor(a.x)) * 4 + 3] < 10) continue;
			}
			return i;
		}
	}
}
function yn(e) {
	if (!e.points.length) return {
		x: 0,
		y: 0,
		width: 0,
		height: 0
	};
	let t = [], n = [];
	for (let r of e.points) t.push(r.x, r.x + (r.in?.x ?? 0), r.x + (r.out?.x ?? 0)), n.push(r.y, r.y + (r.in?.y ?? 0), r.y + (r.out?.y ?? 0));
	let r = Math.min(...t), i = Math.min(...n);
	return {
		x: r,
		y: i,
		width: Math.max(...t) - r,
		height: Math.max(...n) - i
	};
}
var J = (e) => Math.round(e * 100) / 100;
function bn(e) {
	let t = e.points;
	if (!t.length) return "";
	let n = [`M${J(t[0].x)} ${J(t[0].y)}`], r = (e, t) => {
		if (!e.out && !t.in) return `L${J(t.x)} ${J(t.y)}`;
		let n = {
			x: e.x + (e.out?.x ?? 0),
			y: e.y + (e.out?.y ?? 0)
		}, r = {
			x: t.x + (t.in?.x ?? 0),
			y: t.y + (t.in?.y ?? 0)
		};
		return `C${J(n.x)} ${J(n.y)} ${J(r.x)} ${J(r.y)} ${J(t.x)} ${J(t.y)}`;
	};
	for (let e = 1; e < t.length; e++) n.push(r(t[e - 1], t[e]));
	if (e.closed && t.length > 2) {
		let e = t[t.length - 1], i = t[0];
		(e.out || i.in) && n.push(r(e, i)), n.push("Z");
	}
	return n.join(" ");
}
function xn(e) {
	switch (e.type) {
		case "rect": {
			let { width: t, height: n } = e, r = Math.max(0, Math.min(e.radius, t / 2, n / 2));
			return r ? `M${J(r)} 0 H${J(t - r)} A${J(r)} ${J(r)} 0 0 1 ${J(t)} ${J(r)} V${J(n - r)} A${J(r)} ${J(r)} 0 0 1 ${J(t - r)} ${J(n)} H${J(r)} A${J(r)} ${J(r)} 0 0 1 0 ${J(n - r)} V${J(r)} A${J(r)} ${J(r)} 0 0 1 ${J(r)} 0 Z` : `M0 0 H${J(t)} V${J(n)} H0 Z`;
		}
		case "ellipse": {
			let t = e.width / 2, n = e.height / 2;
			return `M0 ${J(n)} A${J(t)} ${J(n)} 0 1 0 ${J(e.width)} ${J(n)} A${J(t)} ${J(n)} 0 1 0 0 ${J(n)} Z`;
		}
		case "line": return `M0 0 L${J(e.x2)} ${J(e.y2)}`;
		case "path": return bn(e.path);
	}
}
var Sn = (e, t = Math.PI / 12) => Math.round(e / t) * t, Cn = class {
	store;
	limit;
	past = [];
	future = [];
	current;
	constructor(e, t, n = 60) {
		this.store = t, this.limit = n, this.current = {
			doc: e,
			label: "Opened"
		};
	}
	get doc() {
		return this.current.doc;
	}
	get canUndo() {
		return this.past.length > 0;
	}
	get canRedo() {
		return this.future.length > 0;
	}
	list() {
		return {
			steps: [
				...this.past,
				this.current,
				...[...this.future].reverse()
			],
			at: this.past.length
		};
	}
	push(e, t) {
		e !== this.current.doc && (this.past.push(this.current), this.current = {
			doc: e,
			label: t
		}, this.future = [], this.past.length > this.limit && this.past.shift(), this.store.keepOnly([this.current.doc, ...this.past.map((e) => e.doc)]));
	}
	replace(e) {
		this.current = {
			...this.current,
			doc: e
		};
	}
	undo() {
		let e = this.past.pop();
		return e && (this.future.push(this.current), this.current = e), this.current.doc;
	}
	redo() {
		let e = this.future.pop();
		return e && (this.past.push(this.current), this.current = e), this.current.doc;
	}
	goTo(e) {
		for (; this.past.length > e && this.canUndo;) this.undo();
		for (; this.past.length < e && this.canRedo;) this.redo();
		return this.current.doc;
	}
}, wn = (e, t) => ({
	width: e,
	height: t,
	mask: new Uint8Array(e * t)
});
function Tn(e, t) {
	let n = wn(e, t);
	return n.mask.fill(255), n;
}
function En(e, t, n) {
	let r = wn(e, t), i = Math.max(0, Math.round(Math.min(n.x, n.x + n.width))), a = Math.min(e, Math.round(Math.max(n.x, n.x + n.width))), o = Math.max(0, Math.round(Math.min(n.y, n.y + n.height))), s = Math.min(t, Math.round(Math.max(n.y, n.y + n.height)));
	for (let t = o; t < s; t++) r.mask.fill(255, t * e + i, t * e + a);
	return r;
}
function Dn(e, t, n) {
	let r = wn(e, t), i = n.x + n.width / 2, a = n.y + n.height / 2, o = Math.abs(n.width / 2), s = Math.abs(n.height / 2);
	if (o < .5 || s < .5) return r;
	let c = Math.max(0, Math.floor(a - s)), l = Math.min(t, Math.ceil(a + s)), u = Math.max(0, Math.floor(i - o)), d = Math.min(e, Math.ceil(i + o));
	for (let t = c; t < l; t++) for (let n = u; n < d; n++) {
		let c = (n + .5 - i) / o, l = (t + .5 - a) / s, u = (1 - Math.sqrt(c * c + l * l)) * Math.min(o, s);
		u > 0 && (r.mask[t * e + n] = Math.round(255 * Math.min(1, u + .5)));
	}
	return r;
}
function On(e, t, n) {
	let r = wn(e, t);
	if (n.length < 3) return r;
	let i = n.map((e) => e.y), a = Math.max(0, Math.floor(Math.min(...i))), o = Math.min(t, Math.ceil(Math.max(...i))), s = [];
	for (let t = a; t < o; t++) {
		let i = t + .5;
		s.length = 0;
		for (let e = 0; e < n.length; e++) {
			let t = n[e], r = n[(e + 1) % n.length];
			t.y <= i != r.y <= i && s.push(t.x + (i - t.y) / (r.y - t.y) * (r.x - t.x));
		}
		s.sort((e, t) => e - t);
		for (let n = 0; n + 1 < s.length; n += 2) {
			let i = Math.max(0, Math.round(s[n])), a = Math.min(e, Math.round(s[n + 1]));
			a > i && r.mask.fill(255, t * e + i, t * e + a);
		}
	}
	return r;
}
function kn(e, t, n) {
	if (!e || n === "replace") return t;
	let r = wn(t.width, t.height);
	for (let i = 0; i < r.mask.length; i++) {
		let a = e.mask[i], o = t.mask[i];
		r.mask[i] = n === "add" ? Math.max(a, o) : n === "subtract" ? Math.max(0, a - o) : Math.min(a, o);
	}
	return r;
}
function An(e) {
	let t = wn(e.width, e.height);
	for (let n = 0; n < t.mask.length; n++) t.mask[n] = 255 - e.mask[n];
	return t;
}
function jn(e) {
	let t = e.width, n = e.height, r = -1, i = -1;
	for (let a = 0; a < e.height; a++) for (let o = 0; o < e.width; o++) e.mask[a * e.width + o] > 0 && (o < t && (t = o), o > r && (r = o), a < n && (n = a), a > i && (i = a));
	return r < 0 ? null : {
		x: t,
		y: n,
		width: r - t + 1,
		height: i - n + 1
	};
}
function Mn(e, t) {
	let n = Math.round(t);
	if (n < 1) return e;
	let r = Float32Array.from(e.mask), i = new Float32Array(r.length), { width: a, height: o } = e;
	for (let e = 0; e < 3; e++) {
		for (let e = 0; e < o; e++) {
			let t = 0;
			for (let i = -n; i <= n; i++) t += r[e * a + Math.min(a - 1, Math.max(0, i))];
			for (let o = 0; o < a; o++) i[e * a + o] = t / (2 * n + 1), t += r[e * a + Math.min(a - 1, o + n + 1)] - r[e * a + Math.max(0, o - n)];
		}
		[r, i] = [i, r];
		for (let e = 0; e < a; e++) {
			let t = 0;
			for (let i = -n; i <= n; i++) t += r[Math.min(o - 1, Math.max(0, i)) * a + e];
			for (let s = 0; s < o; s++) i[s * a + e] = t / (2 * n + 1), t += r[Math.min(o - 1, s + n + 1) * a + e] - r[Math.max(0, s - n) * a + e];
		}
		[r, i] = [i, r];
	}
	let s = wn(a, o);
	for (let e = 0; e < s.mask.length; e++) s.mask[e] = Math.round(r[e]);
	return s;
}
function Nn(e, t, n, r = !0) {
	let { width: i, height: a, data: o } = e, s = wn(i, a), c = Math.floor(t.x), l = Math.floor(t.y);
	if (c < 0 || l < 0 || c >= i || l >= a) return s;
	let u = (l * i + c) * 4, d = [
		o[u],
		o[u + 1],
		o[u + 2],
		o[u + 3]
	], f = (e) => {
		let t = e * 4;
		return Math.max(Math.abs(o[t] - d[0]), Math.abs(o[t + 1] - d[1]), Math.abs(o[t + 2] - d[2]), Math.abs(o[t + 3] - d[3])) <= n;
	};
	if (!r) {
		for (let e = 0; e < i * a; e++) f(e) && (s.mask[e] = 255);
		return s;
	}
	let p = [l * i + c];
	for (s.mask[l * i + c] = 255; p.length;) {
		let e = p.pop(), t = e % i, n = (e - t) / i;
		for (let r of [
			t > 0 ? e - 1 : -1,
			t < i - 1 ? e + 1 : -1,
			n > 0 ? e - i : -1,
			n < a - 1 ? e + i : -1
		]) r >= 0 && !s.mask[r] && f(r) && (s.mask[r] = 255, p.push(r));
	}
	return s;
}
function Pn(e) {
	let { width: t, height: n, mask: r } = e, i = new Uint8Array(t * n);
	for (let e = 0; e < n; e++) for (let a = 0; a < t; a++) {
		let o = e * t + a;
		r[o] < 128 || (a === 0 || e === 0 || a === t - 1 || e === n - 1 || r[o - 1] < 128 || r[o + 1] < 128 || r[o - t] < 128 || r[o + t] < 128) && (i[o] = 1);
	}
	return i;
}
//#endregion
//#region ../canvas/src/paint.ts
var Fn = (e) => [
	parseInt(e.slice(1, 3), 16),
	parseInt(e.slice(3, 5), 16),
	parseInt(e.slice(5, 7), 16)
], In = ([e, t, n]) => `#${[
	e,
	t,
	n
].map((e) => Math.round(Math.min(255, Math.max(0, e))).toString(16).padStart(2, "0")).join("")}`;
function Ln(e, t, n, r) {
	let i = Math.max(.5, n.size / 2), a = Math.max(0, Math.floor(t.x - i)), o = Math.min(e.width, Math.ceil(t.x + i)), s = Math.max(0, Math.floor(t.y - i)), c = Math.min(e.height, Math.ceil(t.y + i));
	if (o <= a || c <= s) return null;
	let l = i * Math.min(.999, Math.max(0, n.hardness)), u = e.data;
	for (let d = s; d < c; d++) for (let s = a; s < o; s++) {
		let a = Math.hypot(s + .5 - t.x, d + .5 - t.y);
		if (a >= i) continue;
		let o = a <= l ? 1 : 1 - (a - l) / (i - l);
		if (o = o * o * (3 - 2 * o) * n.flow, r && (o *= r(s, d)), o <= 0) continue;
		let c = (d * e.width + s) * 4, f = u[c + 3] / 255;
		if (n.mode === "erase" || n.mode === "hide") u[c + 3] = f * (1 - o) * 255;
		else if (n.mode === "reveal") u[c + 3] = (f + (1 - f) * o) * 255;
		else {
			let e = o + f * (1 - o);
			for (let t = 0; t < 3; t++) u[c + t] = (n.color[t] * o + u[c + t] * f * (1 - o)) / e;
			u[c + 3] = e * 255;
		}
	}
	return {
		x: a,
		y: s,
		width: o - a,
		height: c - s
	};
}
var Rn = () => ({
	last: null,
	carry: 0
}), zn = (e, t) => {
	if (!e) return t;
	if (!t) return e;
	let n = Math.min(e.x, t.x), r = Math.min(e.y, t.y);
	return {
		x: n,
		y: r,
		width: Math.max(e.x + e.width, t.x + t.width) - n,
		height: Math.max(e.y + e.height, t.y + t.height) - r
	};
};
function Bn(e, t, n, r) {
	if (!e.last) return e.last = t, e.carry = 0, r(t);
	let i = e.last, a = Math.hypot(t.x - i.x, t.y - i.y), o = null, s = n - e.carry;
	for (; s <= a;) o = zn(o, r({
		x: i.x + (t.x - i.x) * s / a,
		y: i.y + (t.y - i.y) * s / a
	})), s += n;
	return e.carry = a - (s - n), e.last = t, o;
}
var Vn = (e) => Math.max(1, e * .12);
function Hn(e, t, n, r, i) {
	return Bn(t, n, Vn(r.size), (t) => Ln(e, t, r, i));
}
function Un(e, t, n, r, i = !0, a) {
	let { width: o, height: s, data: c } = e, l = Math.floor(t.x), u = Math.floor(t.y);
	if (l < 0 || u < 0 || l >= o || u >= s) return null;
	let d = (u * o + l) * 4, f = [
		c[d],
		c[d + 1],
		c[d + 2],
		c[d + 3]
	], p = (e) => {
		let t = e * 4;
		return Math.max(Math.abs(c[t] - f[0]), Math.abs(c[t + 1] - f[1]), Math.abs(c[t + 2] - f[2]), Math.abs(c[t + 3] - f[3])) <= r;
	}, m = new Uint8Array(o * s);
	if (i) {
		let e = [u * o + l];
		for (m[u * o + l] = 1; e.length;) {
			let t = e.pop(), n = t % o, r = (t - n) / o;
			for (let i of [
				n > 0 ? t - 1 : -1,
				n < o - 1 ? t + 1 : -1,
				r > 0 ? t - o : -1,
				r < s - 1 ? t + o : -1
			]) i >= 0 && !m[i] && p(i) && (m[i] = 1, e.push(i));
		}
	} else for (let e = 0; e < o * s; e++) p(e) && (m[e] = 1);
	let h = o, g = s, _ = -1, v = -1;
	for (let e = 0; e < o * s; e++) {
		if (!m[e]) continue;
		let t = e % o, r = (e - t) / o, i = a ? a(t, r) : 1;
		i <= 0 || (Wn(c, e * 4, n, i), t < h && (h = t), t > _ && (_ = t), r < g && (g = r), r > v && (v = r));
	}
	return _ < 0 ? null : {
		x: h,
		y: g,
		width: _ - h + 1,
		height: v - g + 1
	};
}
function Wn(e, t, n, r) {
	let i = e[t + 3] / 255, a = r + i * (1 - r);
	for (let o = 0; o < 3; o++) e[t + o] = (n[o] * r + e[t + o] * i * (1 - r)) / a;
	e[t + 3] = a * 255;
}
function Gn(e, t, n) {
	for (let r = 0; r < e.height; r++) for (let i = 0; i < e.width; i++) {
		let a = n ? n(i, r) : 1;
		a > 0 && Wn(e.data, (r * e.width + i) * 4, t, a);
	}
}
function Kn(e, t) {
	for (let n = 0; n < e.height; n++) for (let r = 0; r < e.width; r++) {
		let i = t ? t(r, n) : 1, a = (n * e.width + r) * 4 + 3;
		i > 0 && (e.data[a] = e.data[a] * (1 - i));
	}
}
function qn(e, t) {
	let n = {
		width: e.width,
		height: e.height,
		data: new Uint8ClampedArray(e.data)
	};
	if (t) for (let r = 0; r < e.height; r++) for (let i = 0; i < e.width; i++) {
		let a = (r * e.width + i) * 4 + 3;
		n.data[a] = n.data[a] * t(i, r);
	}
	return n;
}
function Jn(e, t, n, r, i, a) {
	let o = n.x - t.x, s = n.y - t.y, c = o * o + s * s || 1;
	for (let n = 0; n < e.height; n++) for (let l = 0; l < e.width; l++) {
		let u = a ? a(l, n) : 1;
		if (u <= 0) continue;
		let d = Math.min(1, Math.max(0, ((l + .5 - t.x) * o + (n + .5 - t.y) * s) / c));
		Wn(e.data, (n * e.width + l) * 4, [
			r[0] + (i[0] - r[0]) * d,
			r[1] + (i[1] - r[1]) * d,
			r[2] + (i[2] - r[2]) * d
		], u);
	}
}
function Yn(e, t) {
	let n = Math.floor(t.x), r = Math.floor(t.y);
	if (n < 0 || r < 0 || n >= e.width || r >= e.height) return null;
	let i = (r * e.width + n) * 4;
	return [
		e.data[i],
		e.data[i + 1],
		e.data[i + 2]
	];
}
function Xn(e, t, n, r, i, a) {
	let o = Math.max(.5, i.size / 2), s = Math.max(0, Math.floor(n.x - o)), c = Math.min(e.width, Math.ceil(n.x + o)), l = Math.max(0, Math.floor(n.y - o)), u = Math.min(e.height, Math.ceil(n.y + o));
	if (c <= s || u <= l) return null;
	let d = o * Math.min(.999, Math.max(0, i.hardness));
	for (let f = l; f < u; f++) for (let l = s; l < c; l++) {
		let s = Math.floor(l + r.x), c = Math.floor(f + r.y);
		if (s < 0 || c < 0 || s >= t.width || c >= t.height) continue;
		let u = Math.hypot(l + .5 - n.x, f + .5 - n.y);
		if (u >= o) continue;
		let p = u <= d ? 1 : 1 - (u - d) / (o - d);
		p = p * p * (3 - 2 * p) * i.flow * (a ? a(l, f) : 1);
		let m = (c * t.width + s) * 4, h = t.data[m + 3] / 255 * p;
		h <= 0 || Wn(e.data, (f * e.width + l) * 4, [
			t.data[m],
			t.data[m + 1],
			t.data[m + 2]
		], h);
	}
	return {
		x: s,
		y: l,
		width: c - s,
		height: u - l
	};
}
//#endregion
//#region ../canvas/src/adjust.ts
function Zn(e, t, n) {
	let r = {
		width: e.width,
		height: e.height,
		data: new Uint8ClampedArray(e.data)
	}, i = r.data;
	for (let r = 0; r < e.height; r++) for (let a = 0; a < e.width; a++) {
		let o = (r * e.width + a) * 4;
		if (!i[o + 3]) continue;
		let s = t ? t(a, r) : 1;
		if (s <= 0) continue;
		let [c, l, u] = n(i[o], i[o + 1], i[o + 2]);
		i[o] = i[o] + (c - i[o]) * s, i[o + 1] = i[o + 1] + (l - i[o + 1]) * s, i[o + 2] = i[o + 2] + (u - i[o + 2]) * s;
	}
	return r;
}
var Qn = (e, t) => Zn(e, t, (e, t, n) => [
	255 - e,
	255 - t,
	255 - n
]), $n = (e, t) => Zn(e, t, (e, t, n) => {
	let r = .2126 * e + .7152 * t + .0722 * n;
	return [
		r,
		r,
		r
	];
});
function er(e, t, n, r) {
	let i = Math.tan((Math.max(-99, Math.min(99, n)) / 100 + 1) * Math.PI / 4), a = t * 1.28;
	return Zn(e, r, (e, t, n) => [
		e,
		t,
		n
	].map((e) => (e + a - 128) * i + 128));
}
function tr(e, t, n, r, i) {
	return Zn(e, i, (e, i, a) => {
		let [o, s, c] = dr(e, i, a);
		return o = (o + t + 360) % 360, s = Math.min(1, Math.max(0, s * (1 + n / 100))), c = r >= 0 ? c + (1 - c) * (r / 100) : c * (1 + r / 100), fr(o, s, c);
	});
}
var nr = (e, t, n) => Zn(e, n, (e, n, r) => [
	t[e],
	t[n],
	t[r]
]);
function rr(e, t, n, r, i, a, o) {
	let s = Math.min(t, n - 1), c = Math.max(n, s + 1), l = /* @__PURE__ */ new Uint8ClampedArray(256);
	for (let e = 0; e < 256; e++) {
		let t = Math.min(1, Math.max(0, (e - s) / (c - s)));
		l[e] = i + (a - i) * t ** (1 / Math.max(.01, r));
	}
	return nr(e, l, o);
}
function ir(e, t, n, r, i) {
	let a = [
		0,
		64,
		128,
		192,
		255
	], o = [
		0,
		64 + t * .64,
		128 + n * .64,
		192 + r * .64,
		255
	].map((e) => Math.min(255, Math.max(0, e)));
	for (let e = 1; e < o.length; e++) o[e] = Math.max(o[e], o[e - 1]);
	let s = a.length, c = a.slice(1).map((e, t) => e - a[t]), l = o.slice(1).map((e, t) => (e - o[t]) / c[t]), u = a.map((e, t) => t === 0 ? l[0] : t === s - 1 ? l[s - 2] : l[t - 1] * l[t] <= 0 ? 0 : (l[t - 1] + l[t]) / 2);
	for (let e = 0; e < s - 1; e++) {
		if (l[e] === 0) {
			u[e] = u[e + 1] = 0;
			continue;
		}
		let t = u[e] / l[e], n = u[e + 1] / l[e], r = Math.hypot(t, n);
		r > 3 && (u[e] = 3 * t * l[e] / r, u[e + 1] = 3 * n * l[e] / r);
	}
	let d = /* @__PURE__ */ new Uint8ClampedArray(256);
	for (let e = 0; e < 256; e++) {
		let t = 0;
		for (; t < s - 2 && e > a[t + 1];) t++;
		let n = (e - a[t]) / c[t], r = 2 * n ** 3 - 3 * n ** 2 + 1, i = n ** 3 - 2 * n ** 2 + n, l = -2 * n ** 3 + 3 * n ** 2, f = n ** 3 - n ** 2;
		d[e] = r * o[t] + i * c[t] * u[t] + l * o[t + 1] + f * c[t] * u[t + 1];
	}
	return nr(e, d, i);
}
function ar(e, t, n) {
	let r = t / 100;
	return Zn(e, n, (e, t, n) => {
		let i = Math.max(e, t, n), a = (e + t + n) / 3, o = i ? (i - Math.min(e, t, n)) / i : 0, s = 1 + r * (1 - o) * 1.5;
		return [
			a + (e - a) * s,
			a + (t - a) * s,
			a + (n - a) * s
		];
	});
}
function or(e, t, n, r) {
	let i = t * .3, a = n * .3;
	return Zn(e, r, (e, t, n) => [
		e + i + a * .5,
		t - a,
		n - i + a * .5
	]);
}
function sr(e, t, n) {
	let r = Math.max(2, Math.round(t)), i = /* @__PURE__ */ new Uint8ClampedArray(256);
	for (let e = 0; e < 256; e++) i[e] = Math.round(e / 255 * (r - 1)) / (r - 1) * 255;
	return nr(e, i, n);
}
function cr(e, t, n) {
	return Zn(e, n, (e, n, r) => {
		let i = .2126 * e + .7152 * n + .0722 * r >= t ? 255 : 0;
		return [
			i,
			i,
			i
		];
	});
}
function lr(e, t, n) {
	let r = Math.round(t);
	if (r < 1) return {
		...e,
		data: new Uint8ClampedArray(e.data)
	};
	let { width: i, height: a } = e, o = new Float32Array(i * a * 4);
	for (let t = 0; t < i * a; t++) {
		let n = e.data[t * 4 + 3] / 255;
		o[t * 4] = e.data[t * 4] * n, o[t * 4 + 1] = e.data[t * 4 + 1] * n, o[t * 4 + 2] = e.data[t * 4 + 2] * n, o[t * 4 + 3] = e.data[t * 4 + 3];
	}
	let s = new Float32Array(o.length), c = 2 * r + 1;
	for (let e = 0; e < 3; e++) {
		for (let e = 0; e < a; e++) for (let t = 0; t < 4; t++) {
			let n = 0;
			for (let a = -r; a <= r; a++) n += o[(e * i + Math.min(i - 1, Math.max(0, a))) * 4 + t];
			for (let a = 0; a < i; a++) s[(e * i + a) * 4 + t] = n / c, n += o[(e * i + Math.min(i - 1, a + r + 1)) * 4 + t] - o[(e * i + Math.max(0, a - r)) * 4 + t];
		}
		[o, s] = [s, o];
		for (let e = 0; e < i; e++) for (let t = 0; t < 4; t++) {
			let n = 0;
			for (let s = -r; s <= r; s++) n += o[(Math.min(a - 1, Math.max(0, s)) * i + e) * 4 + t];
			for (let l = 0; l < a; l++) s[(l * i + e) * 4 + t] = n / c, n += o[(Math.min(a - 1, l + r + 1) * i + e) * 4 + t] - o[(Math.max(0, l - r) * i + e) * 4 + t];
		}
		[o, s] = [s, o];
	}
	let l = {
		width: i,
		height: a,
		data: new Uint8ClampedArray(e.data)
	};
	for (let t = 0; t < a; t++) for (let r = 0; r < i; r++) {
		let a = n ? n(r, t) : 1;
		if (a <= 0) continue;
		let s = (t * i + r) * 4, c = o[s + 3], u = c > 0 ? 255 / c : 0;
		for (let t = 0; t < 3; t++) l.data[s + t] = e.data[s + t] + (o[s + t] * u - e.data[s + t]) * a;
		l.data[s + 3] = e.data[s + 3] + (c - e.data[s + 3]) * a;
	}
	return l;
}
function ur(e, t, n = 1, r) {
	let i = lr(e, n), a = {
		width: e.width,
		height: e.height,
		data: new Uint8ClampedArray(e.data)
	};
	for (let n = 0; n < e.height; n++) for (let o = 0; o < e.width; o++) {
		let s = r ? r(o, n) : 1;
		if (s <= 0) continue;
		let c = (n * e.width + o) * 4;
		for (let n = 0; n < 3; n++) a.data[c + n] = e.data[c + n] + (e.data[c + n] - i.data[c + n]) * t * s;
	}
	return a;
}
function dr(e, t, n) {
	e /= 255, t /= 255, n /= 255;
	let r = Math.max(e, t, n), i = Math.min(e, t, n), a = (r + i) / 2;
	if (r === i) return [
		0,
		0,
		a
	];
	let o = r - i, s = a > .5 ? o / (2 - r - i) : o / (r + i);
	return [
		r === e ? ((t - n) / o + (t < n ? 6 : 0)) * 60 : r === t ? ((n - e) / o + 2) * 60 : ((e - t) / o + 4) * 60,
		s,
		a
	];
}
function fr(e, t, n) {
	let r = (1 - Math.abs(2 * n - 1)) * t, i = e / 60, a = r * (1 - Math.abs(i % 2 - 1)), [o, s, c] = i < 1 ? [
		r,
		a,
		0
	] : i < 2 ? [
		a,
		r,
		0
	] : i < 3 ? [
		0,
		r,
		a
	] : i < 4 ? [
		0,
		a,
		r
	] : i < 5 ? [
		a,
		0,
		r
	] : [
		r,
		0,
		a
	], l = n - r / 2;
	return [
		(o + l) * 255,
		(s + l) * 255,
		(c + l) * 255
	];
}
//#endregion
//#region ../canvas/src/render.ts
var pr = (e) => `${e.italic ? "italic " : ""}${e.weight} ${e.size}px ${e.font}`;
function mr(e, t) {
	e.font = pr(t);
	let n = t.text.split("\n");
	return {
		width: Math.ceil(Math.max(1, ...n.map((t) => e.measureText(t).width))),
		height: Math.ceil(n.length * t.size * t.lineHeight)
	};
}
function hr(e, t, n) {
	if (t.kind === "raster") {
		let r = n.image(t.pixels);
		r && e.drawImage(r, 0, 0);
		return;
	}
	if (t.kind === "text") {
		e.font = pr(t), e.fillStyle = t.color, e.textAlign = t.align, e.textBaseline = "top";
		let n = t.size * t.lineHeight, r = (n - t.size) / 2;
		t.text.split("\n").forEach((t, i) => e.fillText(t, 0, i * n + r));
		return;
	}
	let r = n.path(xn(t.shape));
	t.fill && t.shape.type !== "line" && (e.fillStyle = t.fill, e.fill(r, "evenodd")), t.stroke && t.strokeWidth > 0 && (e.strokeStyle = t.stroke, e.lineWidth = t.strokeWidth, e.lineJoin = "round", e.lineCap = "round", e.stroke(r));
}
var gr = (e, t) => {
	let n = fn(t.transform);
	e.transform(n.a, n.b, n.c, n.d, n.e, n.f);
}, _r = (e) => !!(e && (e.shadow || e.glow || e.stroke)), vr = (e, t) => {
	let n = parseInt(e.slice(1), 16);
	return `rgba(${n >> 16 & 255}, ${n >> 8 & 255}, ${n & 255}, ${Math.max(0, Math.min(1, t))})`;
};
function yr(e, t, n, r, i) {
	let a = (e, n) => {
		let a = i.surface(r.width, r.height, 2);
		return a.ctx.drawImage(t, 0, 0), a.ctx.globalCompositeOperation = "source-in", a.ctx.fillStyle = vr(e, n), a.ctx.fillRect(0, 0, r.width, r.height), a.ctx.globalCompositeOperation = "source-over", a.canvas;
	}, o = (t, n, r, i) => {
		e.save(), n > 0 && (e.filter = `blur(${n / 2}px)`), e.drawImage(t, r, i), e.restore();
	};
	if (n.shadow && n.shadow.opacity > 0) {
		let e = n.shadow.angle * Math.PI / 180;
		o(a(n.shadow.color, n.shadow.opacity), n.shadow.blur, -Math.cos(e) * n.shadow.distance, Math.sin(e) * n.shadow.distance);
	}
	if (n.glow && n.glow.opacity > 0 && n.glow.size > 0) {
		let e = a(n.glow.color, n.glow.opacity);
		for (let t = 0; t < 2; t++) o(e, n.glow.size, 0, 0);
	}
	if (n.stroke && n.stroke.width > 0) {
		let t = a(n.stroke.color, 1), r = n.stroke.width;
		for (let n = Math.min(1, r); n <= r; n += Math.max(1, r / 4)) {
			let r = Math.max(8, Math.ceil(n * 3));
			for (let i = 0; i < r; i++) e.drawImage(t, Math.cos(i / r * 2 * Math.PI) * n, Math.sin(i / r * 2 * Math.PI) * n);
		}
	}
}
function br(e, t, n, r) {
	let i = n.mask && !n.maskOff ? r.image(n.mask) : void 0, a = _r(n.style) ? n.style : void 0;
	if (e.save(), e.globalAlpha = n.opacity, e.globalCompositeOperation = n.blend === "normal" ? "source-over" : n.blend, !i && !a) gr(e, n), hr(e, n, r);
	else {
		let o = r.surface(t.width, t.height, 0);
		if (o.ctx.save(), gr(o.ctx, n), hr(o.ctx, n, r), o.ctx.restore(), i && (o.ctx.globalCompositeOperation = "destination-in", o.ctx.drawImage(i, 0, 0), o.ctx.globalCompositeOperation = "source-over"), !a) e.drawImage(o.canvas, 0, 0);
		else {
			let n = r.surface(t.width, t.height, 1);
			yr(n.ctx, o.canvas, a, t, r), n.ctx.drawImage(o.canvas, 0, 0), e.drawImage(n.canvas, 0, 0);
		}
	}
	e.restore();
}
function xr(e, t, n, r = {}) {
	r.background !== !1 && t.background && (e.save(), e.fillStyle = t.background, e.fillRect(0, 0, t.width, t.height), e.restore());
	for (let i of t.layers) i.visible && !r.hide?.has(i.id) && br(e, t, i, n);
}
//#endregion
//#region ../canvas/src/files.ts
var Sr = (e) => e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"), Cr = (e) => String(Math.round(e * 1e3) / 1e3);
function wr(e, t) {
	let n = [], r = [];
	e.background && r.push(`<rect width="${e.width}" height="${e.height}" fill="${e.background}"/>`);
	for (let i of e.layers) {
		if (!i.visible) continue;
		let a = fn(i.transform), o = [
			`transform="matrix(${[
				a.a,
				a.b,
				a.c,
				a.d,
				a.e,
				a.f
			].map(Cr).join(" ")})"`,
			i.opacity < 1 ? `opacity="${Cr(i.opacity)}"` : "",
			i.blend === "normal" ? "" : `style="mix-blend-mode:${i.blend}"`
		], s = "";
		if (i.mask && !i.maskOff) {
			let r = `m-${n.length}`;
			n.push(`<mask id="${r}" maskUnits="userSpaceOnUse" x="0" y="0" width="${e.width}" height="${e.height}" style="mask-type:alpha"><image href="${t(i.mask)}" width="${e.width}" height="${e.height}"/></mask>`), s = ` mask="url(#${r})"`;
		}
		let c = "";
		if (i.style && (i.style.shadow || i.style.glow || i.style.stroke)) {
			let e = `f-${n.length}`;
			n.push(Tr(e, i.style)), c = ` filter="url(#${e})"`;
		}
		r.push(`<g${s}${c}><g ${o.filter(Boolean).join(" ")}>${Er(i, t)}</g></g>`);
	}
	return `<svg xmlns="http://www.w3.org/2000/svg" width="${e.width}" height="${e.height}" viewBox="0 0 ${e.width} ${e.height}">${n.length ? `<defs>${n.join("")}</defs>` : ""}${r.join("")}</svg>`;
}
function Tr(e, t) {
	let n = [], r = [];
	if (t.shadow && t.shadow.opacity > 0) {
		let e = t.shadow.angle * Math.PI / 180;
		n.push(`<feGaussianBlur in="SourceAlpha" stdDeviation="${Cr(t.shadow.blur / 2)}" result="sb"/><feOffset in="sb" dx="${Cr(-Math.cos(e) * t.shadow.distance)}" dy="${Cr(Math.sin(e) * t.shadow.distance)}" result="so"/><feFlood flood-color="${t.shadow.color}" flood-opacity="${Cr(t.shadow.opacity)}"/><feComposite in2="so" operator="in" result="shadow"/>`), r.push("shadow");
	}
	return t.glow && t.glow.opacity > 0 && (n.push(`<feGaussianBlur in="SourceAlpha" stdDeviation="${Cr(t.glow.size / 2)}" result="gb"/><feFlood flood-color="${t.glow.color}" flood-opacity="${Cr(Math.min(1, t.glow.opacity * 1.6))}"/><feComposite in2="gb" operator="in" result="glow"/>`), r.push("glow")), t.stroke && t.stroke.width > 0 && (n.push(`<feMorphology in="SourceAlpha" operator="dilate" radius="${Cr(t.stroke.width)}" result="sd"/><feFlood flood-color="${t.stroke.color}"/><feComposite in2="sd" operator="in" result="stroke"/>`), r.push("stroke")), `<filter id="${e}" x="-50%" y="-50%" width="200%" height="200%" color-interpolation-filters="sRGB">${n.join("")}<feMerge>${r.map((e) => `<feMergeNode in="${e}"/>`).join("")}<feMergeNode in="SourceGraphic"/></feMerge></filter>`;
}
function Er(e, t) {
	if (e.kind === "raster") return `<image href="${t(e.pixels)}"/>`;
	if (e.kind === "text") {
		let t = e.align === "center" ? "middle" : e.align === "right" ? "end" : "start", n = e.size * e.lineHeight, r = Sr(pr(e));
		return e.text.split("\n").map((i, a) => `<text x="0" y="${Cr(a * n + (n - e.size) / 2 + e.size * .8)}" style="font:${r}" fill="${e.color}" text-anchor="${t}" xml:space="preserve">${Sr(i)}</text>`).join("");
	}
	let n = e.fill && e.shape.type !== "line" ? e.fill : "none", r = e.stroke && e.strokeWidth > 0 ? ` stroke="${e.stroke}" stroke-width="${Cr(e.strokeWidth)}" stroke-linejoin="round" stroke-linecap="round"` : "";
	return `<path d="${xn(e.shape)}" fill="${n}" fill-rule="evenodd"${r}/>`;
}
function Dr(e, t) {
	let n = {};
	for (let r of en(e)) n[r] = t(r);
	return {
		format: "gleamshelf-canvas",
		version: 1,
		doc: e,
		pixels: n
	};
}
async function Or(e, t) {
	let n = e;
	if (!n || n.format !== "gleamshelf-canvas" || n.version !== 1 || !n.doc || !Array.isArray(n.doc.layers)) throw Error("That is not a Gleamshelf design file.");
	let r = new $t();
	for (let e of en(n.doc)) {
		let i = n.pixels?.[e];
		if (typeof i != "string") throw Error("The design file is missing one of its pictures.");
		r.set(e, await t(i));
	}
	return {
		doc: n.doc,
		store: r
	};
}
//#endregion
//#region ../canvas/src/commands.ts
var kr = class {
	backend;
	history;
	store;
	selection = null;
	selectedId = null;
	colours = {
		main: "#1a1a1a",
		second: "#ffffff"
	};
	clipboard = null;
	dry = !1;
	preview = null;
	constructor(e, t, n = new $t()) {
		this.backend = e, this.store = n, this.history = new Cn(t, n), this.selectedId = t.layers[t.layers.length - 1]?.id ?? null;
	}
	get doc() {
		return this.preview ?? this.history.doc;
	}
	get selected() {
		return this.selectedId ? sn(this.doc, this.selectedId) : void 0;
	}
	commit(e, t) {
		this.dry ? this.preview = e : this.history.push(e, t);
	}
	replace(e, t = new $t()) {
		this.store = t, this.history = new Cn(e, t), this.selection = null, this.selectedId = e.layers[e.layers.length - 1]?.id ?? null, this.clipboard = null, this.preview = null;
	}
	host() {
		return {
			image: (e) => {
				let t = this.store.get(e);
				return t ? this.backend.image(e, t) : void 0;
			},
			surface: (e, t) => {
				let n = this.backend.surface(e, t);
				return {
					ctx: n.ctx,
					canvas: n.canvas
				};
			},
			path: (e) => this.backend.path(e)
		};
	}
	flatten(e = this.doc, t = !0) {
		let n = this.backend.surface(e.width, e.height);
		return xr(n.ctx, e, this.host(), { background: t }), n.read();
	}
}, Y = class extends Error {};
function Ar(e) {
	if (typeof e != "string") {
		if (e && typeof e == "object") return e;
		throw new Y("The 3D design is missing.");
	}
	try {
		let t = JSON.parse(e);
		if (!t || typeof t != "object" || !Array.isArray(t.shapes)) throw new Y("That is not a 3D design (it has no shapes).");
		return t;
	} catch (e) {
		throw e instanceof Y ? e : new Y("The 3D design is not valid JSON.");
	}
}
var X = {
	name: "layer",
	type: "string",
	label: "Layer",
	description: "The layer, by id or name (the picked layer when left out).",
	optional: !0
}, jr = {
	name: "mode",
	type: "enum",
	label: "Combine",
	options: [
		"replace",
		"add",
		"subtract",
		"intersect"
	],
	default: "replace",
	description: "How the new selection combines with the current one."
};
function Z(e, t) {
	let n = e.doc;
	if (t) {
		let e = sn(n, t) ?? [...n.layers].reverse().find((e) => e.name === t);
		if (!e) throw new Y(`There is no layer called "${t}".`);
		return e;
	}
	let r = e.selected;
	if (!r) throw new Y("Pick a layer first.");
	return r;
}
var Mr = (e) => {
	if (e.locked) throw new Y(`"${e.name}" is locked.`);
	return e;
}, Nr = (e) => {
	if (e.kind !== "raster") throw new Y(`"${e.name}" is a ${e.kind} layer. Rasterize it first to change its pixels.`);
	return Mr(e);
};
function Pr(e, t) {
	let n = e.selection;
	if (!n) return;
	let { width: r, height: i, mask: a } = n;
	if (!t) return (e, t) => e >= 0 && t >= 0 && e < r && t < i ? a[t * r + e] / 255 : 0;
	let o = fn(t.transform);
	return (e, t) => {
		let n = mn(o, {
			x: e + .5,
			y: t + .5
		}), s = Math.floor(n.x), c = Math.floor(n.y);
		return s >= 0 && c >= 0 && s < r && c < i ? a[c * r + s] / 255 : 0;
	};
}
function Fr(e, t) {
	let n = t ? Z(e, t) : e.selected;
	if (n?.kind === "raster") return {
		doc: e.doc,
		layer: Nr(n)
	};
	let r = rn("Paint", e.store.add(Zt(e.doc.width, e.doc.height)));
	return e.selectedId = r.id, {
		doc: cn(e.doc, r, n?.id),
		layer: r
	};
}
function Ir(e, t, n) {
	let r = Qt(e.store.get(n.pixels)), i = e.store.add(r);
	return {
		doc: q(t, n.id, { pixels: i }),
		working: r,
		layer: {
			...n,
			pixels: i
		}
	};
}
var Lr = (e, t) => (e.selection = jn(t) ? t : null, { message: e.selection ? void 0 : "Nothing is selected." });
function Rr(e, t) {
	let n = e.backend.surface(e.doc.width, e.doc.height);
	return br(n.ctx, e.doc, {
		...t,
		opacity: 1,
		blend: "normal",
		mask: void 0
	}, e.host()), n.read();
}
var zr = (e, t) => mr(e.backend.surface(1, 1).ctx, {
	...t,
	text: t.text || " "
}), Br = (e, t, n) => {
	let r = mn(fn(e), n), i = mn(fn({
		...t,
		x: 0,
		y: 0
	}), n);
	return {
		...t,
		x: r.x - i.x,
		y: r.y - i.y
	};
}, Vr = (e) => e.map((e) => Array.isArray(e) ? {
	x: Number(e[0]),
	y: Number(e[1])
} : {
	x: Number(e.x),
	y: Number(e.y)
});
function Hr(e) {
	let t = e.doc, n = e.selection ? jn(e.selection) : null;
	return {
		width: t.width,
		height: t.height,
		background: t.background,
		picked: e.selectedId,
		selection: n,
		colours: e.colours,
		canUndo: e.history.canUndo,
		canRedo: e.history.canRedo,
		layers: [...t.layers].reverse().map((t) => {
			let n = gn(t, e.store), r = {
				id: t.id,
				name: t.name,
				kind: t.kind,
				visible: t.visible,
				locked: t.locked,
				opacity: t.opacity,
				blend: t.blend,
				x: Math.round(t.transform.x * 10) / 10,
				y: Math.round(t.transform.y * 10) / 10,
				width: Math.round(n.width * Math.abs(t.transform.scaleX)),
				height: Math.round(n.height * Math.abs(t.transform.scaleY)),
				rotation: Math.round(t.transform.rotation * 180 / Math.PI * 10) / 10,
				mask: t.mask ? t.maskOff ? "off" : "on" : null
			};
			return t.kind === "text" ? {
				...r,
				text: t.text,
				font: t.font,
				size: t.size,
				color: t.color
			} : t.kind === "shape" ? {
				...r,
				shape: t.shape.type,
				fill: t.fill,
				stroke: t.stroke,
				strokeWidth: t.strokeWidth
			} : r;
		})
	};
}
var Q = (e, t, n, r, i, a = {}) => ({
	name: t,
	label: e,
	type: "number",
	min: n,
	max: r,
	default: i,
	...a
}), $ = (e, t, n, r = {}) => ({
	name: t,
	label: e,
	type: "color",
	default: n,
	...r
}), Ur = (e) => e.colours.main, Wr = [
	{
		id: "undo",
		label: "Undo",
		menu: "Edit",
		keys: "Ctrl Z",
		description: "Undo the last change.",
		blocked: (e) => e.history.canUndo ? null : "Nothing to undo.",
		run: (e) => void e.history.undo()
	},
	{
		id: "redo",
		label: "Redo",
		menu: "Edit",
		keys: "Ctrl Shift Z",
		description: "Redo what was undone.",
		blocked: (e) => e.history.canRedo ? null : "Nothing to redo.",
		run: (e) => void e.history.redo()
	},
	{
		id: "new_canvas",
		label: "New canvas…",
		menu: "File",
		description: "Start a new, empty design (replaces the open one).",
		params: [
			Q("Width", "width", 1, 16384, 2e3, {
				type: "integer",
				unit: "px"
			}),
			Q("Height", "height", 1, 16384, 2e3, {
				type: "integer",
				unit: "px"
			}),
			$("Canvas colour", "background", "#ffffff", {
				nullable: !0,
				description: "null for transparent."
			})
		],
		run: (e, t) => e.replace(tn(t.width, t.height, t.background))
	},
	{
		id: "save_design",
		label: "Save design (.gleam)",
		menu: "File",
		keys: "Ctrl S",
		description: "The design as a .gleam file (one JSON file with its pictures), to open and keep editing later.",
		run: async (e) => {
			let t = Dr(e.doc, () => "");
			for (let n of Object.keys(t.pixels)) t.pixels[n] = await qr(e, n);
			return { file: {
				name: "design.gleam",
				type: "application/json",
				data: new TextEncoder().encode(JSON.stringify(t))
			} };
		}
	},
	{
		id: "export",
		label: "Export…",
		menu: "File",
		description: "The finished picture as PNG or JPEG, or as SVG with shapes and text kept as vectors.",
		params: [{
			name: "format",
			type: "enum",
			label: "Format",
			options: [
				"png",
				"jpeg",
				"svg"
			],
			default: "png"
		}, Q("Quality (JPEG)", "quality", .1, 1, .92, { step: .01 })],
		run: async (e, t) => {
			if (t.format === "svg") {
				let t = /* @__PURE__ */ new Map();
				for (let n of e.doc.layers) n.kind === "raster" && t.set(n.pixels, await qr(e, n.pixels)), n.mask && t.set(n.mask, await qr(e, n.mask));
				return { file: {
					name: "design.svg",
					type: "image/svg+xml",
					data: new TextEncoder().encode(wr(e.doc, (e) => t.get(e)))
				} };
			}
			let n = t.format === "jpeg" && !e.doc.background ? {
				...e.doc,
				background: "#ffffff"
			} : e.doc, r = await e.backend.encode(e.flatten(n), t.format, t.quality);
			return { file: {
				name: `design.${t.format === "jpeg" ? "jpg" : "png"}`,
				type: `image/${t.format}`,
				data: r
			} };
		}
	},
	{
		id: "place_image",
		label: "Place a picture…",
		menu: "File",
		description: "Put a picture on a new layer, fitted inside the canvas and centred unless x and y are given.",
		params: [
			{
				name: "image",
				type: "image",
				label: "Picture",
				description: "The picture (a file path from the command line or MCP)."
			},
			{
				name: "name",
				type: "string",
				label: "Layer name",
				default: "Picture"
			},
			Q("X", "x", -1e5, 1e5, void 0, { optional: !0 }),
			Q("Y", "y", -1e5, 1e5, void 0, { optional: !0 }),
			Q("Scale", "scale", .001, 100, void 0, {
				optional: !0,
				description: "Size as a fraction (1 = the picture’s own pixels); fits the canvas when left out."
			})
		],
		run: (e, t) => {
			let n = t.image, r = e.doc, i = t.scale ?? Math.min(1, r.width / n.width, r.height / n.height), a = rn(t.name, e.store.add(n), {
				x: t.x ?? (r.width - n.width * i) / 2,
				y: t.y ?? (r.height - n.height * i) / 2,
				scaleX: i,
				scaleY: i
			});
			return e.commit(cn(r, a, e.selectedId ?? void 0), "Place picture"), e.selectedId = a.id, { data: { id: a.id } };
		}
	},
	{
		id: "place_model",
		label: "Place a 3D picture",
		description: "Put a picture drawn in 3D mode on a new layer, with the 3D design it came from (JSON), so the layer can be opened in 3D mode and drawn again.",
		params: [
			{
				name: "image",
				type: "image",
				label: "Picture",
				description: "The picture 3D mode drew (a file path from the command line or MCP)."
			},
			{
				name: "model",
				type: "string",
				label: "3D design",
				description: "The 3D design as JSON."
			},
			{
				name: "name",
				type: "string",
				label: "Layer name",
				default: "3D object"
			}
		],
		run: (e, t) => {
			let n = Ar(t.model), r = t.image, i = e.doc, a = Math.min(1, i.width / r.width, i.height / r.height), o = {
				...rn(t.name, e.store.add(r), {
					x: (i.width - r.width * a) / 2,
					y: (i.height - r.height * a) / 2,
					scaleX: a,
					scaleY: a
				}),
				model3d: n
			};
			return e.commit(cn(i, o, e.selectedId ?? void 0), "Place 3D object"), e.selectedId = o.id, { data: { id: o.id } };
		}
	},
	{
		id: "redraw_model",
		label: "Redraw a 3D layer",
		description: "Give a 3D layer its new picture and design after a change in 3D mode. The layer keeps its place, size on the canvas, mask and settings.",
		params: [
			X,
			{
				name: "image",
				type: "image",
				label: "Picture",
				description: "The new picture from 3D mode."
			},
			{
				name: "model",
				type: "string",
				label: "3D design",
				description: "The changed 3D design as JSON."
			}
		],
		run: (e, t) => {
			let n = Z(e, t.layer);
			if (n.kind !== "raster" || n.model3d === void 0) throw new Y(`"${n.name}" is not a 3D layer.`);
			let r = Ar(t.model), i = t.image, a = e.store.get(n.pixels), o = a ? a.width * n.transform.scaleX / i.width : 1;
			e.commit(q(e.doc, n.id, {
				pixels: e.store.add(i),
				model3d: r,
				transform: {
					...n.transform,
					scaleX: o,
					scaleY: o * (n.transform.scaleY / n.transform.scaleX)
				}
			}), "Redraw 3D object");
		}
	},
	{
		id: "describe",
		label: "Describe the design",
		description: "The canvas size, selection, colours and every layer (top first) with its id, kind, position and settings.",
		run: (e) => ({ data: Hr(e) })
	},
	{
		id: "add_layer",
		label: "New picture layer",
		menu: "Layer",
		keys: "Ctrl Shift N",
		description: "An empty picture layer the size of the canvas, above the picked layer.",
		params: [{
			name: "name",
			type: "string",
			label: "Name",
			default: "Layer"
		}],
		run: (e, t) => {
			let n = rn(t.name, e.store.add(Zt(e.doc.width, e.doc.height)));
			return e.commit(cn(e.doc, n, e.selectedId ?? void 0), "New layer"), e.selectedId = n.id, { data: { id: n.id } };
		}
	},
	{
		id: "add_text",
		label: "Add text",
		description: "A text layer. x and y are its top-left corner (or its centre or right edge, by alignment).",
		params: [
			{
				name: "text",
				type: "string",
				label: "Text"
			},
			Q("X", "x", -1e5, 1e5, 0),
			Q("Y", "y", -1e5, 1e5, 0),
			Q("Size", "size", 1, 2e3, 72, { unit: "px" }),
			{
				name: "font",
				type: "string",
				label: "Font",
				default: "system-ui, sans-serif",
				description: "A CSS font family list."
			},
			Q("Weight", "weight", 100, 900, 700, { type: "integer" }),
			$("Colour", "color", Ur),
			{
				name: "align",
				type: "enum",
				label: "Align",
				options: [
					"left",
					"center",
					"right"
				],
				default: "left"
			},
			{
				name: "italic",
				type: "boolean",
				label: "Italic",
				default: !1
			}
		],
		run: (e, t) => {
			let n = on(t.text, {
				size: t.size,
				font: t.font,
				weight: t.weight,
				color: t.color,
				align: t.align,
				italic: t.italic
			}, {
				x: t.x,
				y: t.y
			}), r = {
				...n,
				box: zr(e, n)
			};
			return e.commit(cn(e.doc, r, e.selectedId ?? void 0), "Add text"), e.selectedId = r.id, { data: { id: r.id } };
		}
	},
	{
		id: "add_shape",
		label: "Add shape",
		description: "A rectangle, ellipse or line layer that stays an editable shape. For a line, width and height are how far it runs.",
		params: [
			{
				name: "shape",
				type: "enum",
				label: "Shape",
				options: [
					"rect",
					"ellipse",
					"line"
				],
				default: "rect"
			},
			Q("X", "x", -1e5, 1e5, 0),
			Q("Y", "y", -1e5, 1e5, 0),
			Q("Width", "width", -1e5, 1e5, 400),
			Q("Height", "height", -1e5, 1e5, 300),
			Q("Corner radius", "radius", 0, 1e5, 0),
			$("Fill", "fill", Ur, { nullable: !0 }),
			$("Outline", "stroke", null, { nullable: !0 }),
			Q("Outline width", "strokeWidth", 0, 1e3, 4)
		],
		run: (e, t) => {
			let n = t.shape === "line" ? {
				type: "line",
				x2: t.width,
				y2: t.height
			} : t.shape === "ellipse" ? {
				type: "ellipse",
				width: Math.abs(t.width),
				height: Math.abs(t.height)
			} : {
				type: "rect",
				width: Math.abs(t.width),
				height: Math.abs(t.height),
				radius: t.radius
			}, r = t.shape === "line" ? {
				fill: null,
				stroke: t.stroke ?? t.fill ?? e.colours.main,
				strokeWidth: t.strokeWidth || 4
			} : {
				fill: t.fill,
				stroke: t.stroke,
				strokeWidth: t.strokeWidth
			}, i = t.shape === "rect" ? "Rectangle" : t.shape === "ellipse" ? "Ellipse" : "Line", a = an(i, n, r, {
				x: t.x,
				y: t.y
			});
			return e.commit(cn(e.doc, a, e.selectedId ?? void 0), `Draw ${i.toLowerCase()}`), e.selectedId = a.id, { data: { id: a.id } };
		}
	},
	{
		id: "add_path",
		label: "Add path",
		description: "A path through points ([[x, y], ...] in canvas pixels), straight between them, open or closed.",
		params: [
			{
				name: "points",
				type: "points",
				label: "Points"
			},
			{
				name: "closed",
				type: "boolean",
				label: "Closed",
				default: !0
			},
			$("Fill", "fill", Ur, { nullable: !0 }),
			$("Outline", "stroke", null, { nullable: !0 }),
			Q("Outline width", "strokeWidth", 0, 1e3, 4)
		],
		run: (e, t) => {
			let n = Vr(t.points);
			if (n.length < 2) throw new Y("A path needs at least two points.");
			let r = an("Path", {
				type: "path",
				path: {
					points: n,
					closed: t.closed
				}
			}, t.closed ? {
				fill: t.fill,
				stroke: t.stroke,
				strokeWidth: t.strokeWidth
			} : {
				fill: null,
				stroke: t.stroke ?? t.fill ?? e.colours.main,
				strokeWidth: t.strokeWidth || 4
			});
			return e.commit(cn(e.doc, r, e.selectedId ?? void 0), "Draw path"), e.selectedId = r.id, { data: { id: r.id } };
		}
	},
	{
		id: "pick_layer",
		label: "Pick a layer",
		description: "Make a layer the one later commands act on.",
		params: [{
			...X,
			optional: !1
		}],
		run: (e, t) => {
			e.selectedId = Z(e, t.layer).id;
		}
	},
	{
		id: "drop_shadow",
		label: "Drop shadow…",
		menu: "Layer",
		description: "A soft shadow under the layer, cast away from a light at the given angle; it follows the layer as it changes. Opacity 0 removes it.",
		preview: !0,
		params: [
			Q("Opacity", "opacity", 0, 100, (e) => Math.round((e.selected?.style?.shadow?.opacity ?? .5) * 100), {
				type: "integer",
				unit: "%"
			}),
			Q("Angle", "angle", -180, 180, (e) => e.selected?.style?.shadow?.angle ?? 120, {
				type: "integer",
				unit: "°"
			}),
			Q("Distance", "distance", 0, 500, (e) => e.selected?.style?.shadow?.distance ?? 12, {
				type: "integer",
				unit: "px"
			}),
			Q("Softness", "blur", 0, 250, (e) => e.selected?.style?.shadow?.blur ?? 18, {
				type: "integer",
				unit: "px"
			}),
			$("Colour", "color", (e) => e.selected?.style?.shadow?.color ?? "#000000"),
			X
		],
		blocked: (e) => e.selected ? null : "Pick a layer.",
		run: (e, t) => {
			let n = Z(e, t.layer), r = t.opacity > 0 ? {
				color: t.color,
				opacity: t.opacity / 100,
				angle: t.angle,
				distance: t.distance,
				blur: t.blur
			} : void 0;
			e.commit(q(e.doc, n.id, { style: {
				...n.style,
				shadow: r
			} }), r ? "Drop shadow" : "Remove drop shadow");
		}
	},
	{
		id: "outer_glow",
		label: "Outer glow…",
		menu: "Layer",
		description: "A soft halo all round the layer, in the main colour unless one is given. Opacity 0 removes it.",
		preview: !0,
		params: [
			Q("Opacity", "opacity", 0, 100, (e) => Math.round((e.selected?.style?.glow?.opacity ?? .75) * 100), {
				type: "integer",
				unit: "%"
			}),
			Q("Size", "size", 1, 250, (e) => e.selected?.style?.glow?.size ?? 24, {
				type: "integer",
				unit: "px"
			}),
			$("Colour", "color", (e) => e.selected?.style?.glow?.color ?? e.colours.main),
			X
		],
		blocked: (e) => e.selected ? null : "Pick a layer.",
		run: (e, t) => {
			let n = Z(e, t.layer), r = t.opacity > 0 ? {
				color: t.color,
				opacity: t.opacity / 100,
				size: t.size
			} : void 0;
			e.commit(q(e.doc, n.id, { style: {
				...n.style,
				glow: r
			} }), r ? "Outer glow" : "Remove outer glow");
		}
	},
	{
		id: "stroke_outline",
		label: "Stroke…",
		menu: "Layer",
		description: "A line round the outside of the layer’s shape (its see-through edge), in the main colour unless one is given. Width 0 removes it.",
		preview: !0,
		params: [
			Q("Width", "width", 0, 100, (e) => e.selected?.style?.stroke?.width ?? 6, {
				type: "integer",
				unit: "px"
			}),
			$("Colour", "color", (e) => e.selected?.style?.stroke?.color ?? e.colours.main),
			X
		],
		blocked: (e) => e.selected ? null : "Pick a layer.",
		run: (e, t) => {
			let n = Z(e, t.layer), r = t.width > 0 ? {
				color: t.color,
				width: t.width
			} : void 0;
			e.commit(q(e.doc, n.id, { style: {
				...n.style,
				stroke: r
			} }), r ? "Stroke" : "Remove stroke");
		}
	},
	{
		id: "clear_style",
		label: "Clear layer style",
		menu: "Layer",
		description: "Take the drop shadow, glow and stroke off the layer.",
		blocked: (e) => e.selected?.style ? null : "The picked layer has no style.",
		params: [X],
		run: (e, t) => {
			let n = Z(e, t.layer);
			e.commit(q(e.doc, n.id, { style: void 0 }), "Clear layer style");
		}
	},
	{
		id: "set_layer",
		label: "Change a layer",
		description: "Change any of a layer’s settings: name, visible, locked, opacity (0-1), blend, x, y, scaleX, scaleY, rotation (degrees); fill, stroke, strokeWidth, radius (shapes); text, size, font, weight, color, align, italic (text).",
		params: [
			X,
			{
				name: "name",
				type: "string",
				label: "Name",
				optional: !0
			},
			{
				name: "visible",
				type: "boolean",
				label: "Visible",
				optional: !0
			},
			{
				name: "locked",
				type: "boolean",
				label: "Locked",
				optional: !0
			},
			Q("Opacity", "opacity", 0, 1, void 0, {
				optional: !0,
				step: .01
			}),
			{
				name: "blend",
				type: "enum",
				label: "Blend",
				options: qt.map((e) => e.id),
				optional: !0
			},
			Q("X", "x", -1e5, 1e5, void 0, { optional: !0 }),
			Q("Y", "y", -1e5, 1e5, void 0, { optional: !0 }),
			Q("Scale across", "scaleX", -100, 100, void 0, { optional: !0 }),
			Q("Scale down", "scaleY", -100, 100, void 0, { optional: !0 }),
			Q("Turn", "rotation", -3600, 3600, void 0, {
				optional: !0,
				unit: "°"
			}),
			$("Fill", "fill", void 0, {
				optional: !0,
				nullable: !0
			}),
			$("Outline", "stroke", void 0, {
				optional: !0,
				nullable: !0
			}),
			Q("Outline width", "strokeWidth", 0, 1e3, void 0, { optional: !0 }),
			Q("Corner radius", "radius", 0, 1e5, void 0, { optional: !0 }),
			{
				name: "text",
				type: "string",
				label: "Text",
				optional: !0
			},
			Q("Size", "size", 1, 2e3, void 0, { optional: !0 }),
			{
				name: "font",
				type: "string",
				label: "Font",
				optional: !0
			},
			Q("Weight", "weight", 100, 900, void 0, {
				optional: !0,
				type: "integer"
			}),
			$("Text colour", "color", void 0, { optional: !0 }),
			{
				name: "align",
				type: "enum",
				label: "Align",
				options: [
					"left",
					"center",
					"right"
				],
				optional: !0
			},
			{
				name: "italic",
				type: "boolean",
				label: "Italic",
				optional: !0
			}
		],
		run: (e, t) => {
			let n = Z(e, t.layer);
			if (n.locked && t.locked !== !1) throw new Y(`"${n.name}" is locked.`);
			let r = {};
			for (let e of [
				"name",
				"visible",
				"locked",
				"opacity",
				"blend"
			]) t[e] !== void 0 && (r[e] = t[e]);
			let i = { ...n.transform };
			if (t.x !== void 0 && (i.x = t.x), t.y !== void 0 && (i.y = t.y), t.scaleX !== void 0 && (i.scaleX = t.scaleX || .001), t.scaleY !== void 0 && (i.scaleY = t.scaleY || .001), t.rotation !== void 0 && (i.rotation = t.rotation * Math.PI / 180), r.transform = i, n.kind === "shape") {
				for (let e of [
					"fill",
					"stroke",
					"strokeWidth"
				]) t[e] !== void 0 && (r[e] = t[e]);
				t.radius !== void 0 && n.shape.type === "rect" && (r.shape = {
					...n.shape,
					radius: t.radius
				});
			}
			if (n.kind === "text") {
				for (let e of [
					"text",
					"size",
					"font",
					"weight",
					"color",
					"align",
					"italic"
				]) t[e] !== void 0 && (r[e] = t[e]);
				r.box = zr(e, {
					...n,
					...r
				});
			}
			e.commit(q(e.doc, n.id, r), "Change layer");
		}
	},
	{
		id: "duplicate_layer",
		label: "Duplicate layer",
		menu: "Layer",
		keys: "Ctrl J",
		description: "A copy of the layer just above it.",
		params: [X],
		blocked: (e) => e.selected ? null : "Pick a layer first.",
		run: (e, t) => {
			let n = dn(e.doc, e.store, Z(e, t.layer).id);
			return e.commit(n.doc, "Duplicate"), e.selectedId = n.id, { data: { id: n.id } };
		}
	},
	{
		id: "delete_layer",
		label: "Delete layer",
		menu: "Layer",
		description: "Remove the layer.",
		params: [X],
		blocked: (e) => e.selected ? null : "Pick a layer first.",
		run: (e, t) => {
			let n = Z(e, t.layer), r = e.doc.layers.indexOf(n), i = ln(e.doc, n.id);
			e.commit(i, "Delete layer"), e.selectedId === n.id && (e.selectedId = i.layers[Math.max(0, r - 1)]?.id ?? null);
		}
	},
	{
		id: "arrange_layer",
		label: "Arrange layer",
		description: "Move the layer in the stack: front, forward, backward or back.",
		params: [X, {
			name: "to",
			type: "enum",
			label: "To",
			options: [
				"front",
				"forward",
				"backward",
				"back"
			],
			default: "forward"
		}],
		run: (e, t) => {
			let n = {
				front: Infinity,
				forward: 1,
				backward: -1,
				back: -Infinity
			}[t.to];
			e.commit(un(e.doc, Z(e, t.layer).id, n), "Arrange");
		}
	},
	...[
		[
			"front",
			"Bring to front",
			"Ctrl Shift ]"
		],
		[
			"forward",
			"Bring forward",
			"Ctrl ]"
		],
		[
			"backward",
			"Send backward",
			"Ctrl ["
		],
		[
			"back",
			"Send to back",
			"Ctrl Shift ["
		]
	].map(([e, t, n]) => ({
		id: `arrange_${e}`,
		label: t,
		menu: "Layer",
		keys: n,
		description: `${t} (the picked layer).`,
		blocked: (e) => e.selected ? null : "Pick a layer first.",
		run: (n) => void n.commit(un(n.doc, n.selectedId, {
			front: Infinity,
			forward: 1,
			backward: -1,
			back: -Infinity
		}[e]), t)
	})),
	{
		id: "merge_down",
		label: "Merge down",
		menu: "Layer",
		keys: "Ctrl E",
		description: "Combine the layer with the one under it into one picture layer.",
		params: [X],
		blocked: (e) => e.selected && e.doc.layers.indexOf(e.selected) > 0 ? null : "Pick a layer that has one under it.",
		run: (e, t) => {
			let n = Z(e, t.layer), r = e.doc.layers.indexOf(n);
			if (r < 1) throw new Y("There is no layer under it to merge with.");
			let i = e.doc.layers[r - 1], a = e.backend.surface(e.doc.width, e.doc.height);
			br(a.ctx, e.doc, i, e.host()), br(a.ctx, e.doc, n, e.host());
			let o = rn(i.name, e.store.add(a.read())), s = ln(e.doc, n.id);
			e.commit({
				...s,
				layers: s.layers.map((e) => e.id === i.id ? o : e)
			}, "Merge down"), e.selectedId = o.id;
		}
	},
	{
		id: "flatten",
		label: "Flatten into one layer",
		menu: "Layer",
		description: "Every layer drawn into one picture layer (the canvas colour stays separate).",
		blocked: (e) => e.doc.layers.length > 1 ? null : "There is only one layer.",
		run: (e) => {
			let t = rn("Flattened", e.store.add(e.flatten(e.doc, !1)));
			e.commit({
				...e.doc,
				layers: [t]
			}, "Flatten"), e.selectedId = t.id;
		}
	},
	{
		id: "rasterize",
		label: "Rasterize (turn into pixels)",
		menu: "Layer",
		description: "Turn a shape or text layer into a picture layer, to paint on it.",
		params: [X],
		blocked: (e) => e.selected && e.selected.kind !== "raster" ? null : "Pick a shape or text layer.",
		run: (e, t) => {
			let n = Z(e, t.layer);
			if (n.kind === "raster") return { message: "It is already a picture layer." };
			let r = {
				...rn(n.name, e.store.add(Rr(e, n))),
				opacity: n.opacity,
				blend: n.blend,
				mask: n.mask,
				visible: n.visible
			};
			e.commit({
				...e.doc,
				layers: e.doc.layers.map((e) => e.id === n.id ? r : e)
			}, "Rasterize"), e.selectedId = r.id;
		}
	},
	{
		id: "flip_layer",
		label: "Flip layer",
		description: "Mirror the layer left to right (across) or upside down (down), about its centre.",
		params: [X, {
			name: "axis",
			type: "enum",
			label: "Axis",
			options: ["across", "down"],
			default: "across"
		}],
		run: (e, t) => {
			let n = Mr(Z(e, t.layer)), r = gn(n, e.store), i = n.transform, a = t.axis === "across" ? {
				...i,
				scaleX: -i.scaleX
			} : {
				...i,
				scaleY: -i.scaleY
			};
			e.commit(q(e.doc, n.id, { transform: Br(i, a, {
				x: r.x + r.width / 2,
				y: r.y + r.height / 2
			}) }), "Flip");
		}
	},
	...[["across", "Flip layer left to right"], ["down", "Flip layer upside down"]].map(([e, t]) => ({
		id: `flip_${e}`,
		label: t,
		menu: "Layer",
		description: `${t} (the picked layer).`,
		blocked: (e) => e.selected ? null : "Pick a layer first.",
		run: (t) => Yr(t, "flip_layer", { axis: e })
	})),
	{
		id: "add_mask",
		label: "Add mask",
		menu: "Layer",
		description: "A mask on the layer: it shows what is selected (or everything when nothing is). Paint on it to hide and show parts.",
		params: [X],
		blocked: (e) => e.selected && !e.selected.mask ? null : e.selected ? "It already has a mask." : "Pick a layer first.",
		run: (e, t) => {
			let n = Z(e, t.layer);
			if (n.mask) throw new Y(`"${n.name}" already has a mask.`);
			let r = Zt(e.doc.width, e.doc.height);
			for (let t = 0; t < e.doc.width * e.doc.height; t++) r.data[t * 4 + 3] = e.selection ? e.selection.mask[t] : 255;
			e.commit(q(e.doc, n.id, {
				mask: e.store.add(r, "mask"),
				maskOff: !1
			}), "Add mask");
		}
	},
	{
		id: "toggle_mask",
		label: "Switch mask off/on",
		menu: "Layer",
		description: "See the layer without its mask, or with it again.",
		params: [X],
		blocked: (e) => e.selected?.mask ? null : "The layer has no mask.",
		run: (e, t) => {
			let n = Z(e, t.layer);
			if (!n.mask) throw new Y(`"${n.name}" has no mask.`);
			e.commit(q(e.doc, n.id, { maskOff: !n.maskOff }), "Switch mask");
		}
	},
	{
		id: "apply_mask",
		label: "Apply mask to pixels",
		menu: "Layer",
		description: "Make what the mask hides transparent for good, and remove the mask.",
		params: [X],
		blocked: (e) => e.selected?.kind === "raster" && e.selected.mask ? null : "Pick a picture layer with a mask.",
		run: (e, t) => {
			let n = Nr(Z(e, t.layer));
			if (!n.mask) throw new Y(`"${n.name}" has no mask.`);
			let r = e.backend.surface(e.doc.width, e.doc.height);
			br(r.ctx, e.doc, {
				...n,
				opacity: 1,
				blend: "normal"
			}, e.host());
			let i = {
				...n,
				pixels: e.store.add(r.read()),
				mask: void 0,
				transform: {
					x: 0,
					y: 0,
					scaleX: 1,
					scaleY: 1,
					rotation: 0
				}
			};
			e.commit({
				...e.doc,
				layers: e.doc.layers.map((e) => e.id === n.id ? i : e)
			}, "Apply mask");
		}
	},
	{
		id: "delete_mask",
		label: "Delete mask",
		menu: "Layer",
		description: "Remove the layer’s mask (the layer shows fully again).",
		params: [X],
		blocked: (e) => e.selected?.mask ? null : "The layer has no mask.",
		run: (e, t) => void e.commit(q(e.doc, Z(e, t.layer).id, { mask: void 0 }), "Delete mask")
	},
	{
		id: "select_all",
		label: "Select all",
		menu: "Select",
		keys: "Ctrl A",
		description: "Select the whole canvas.",
		run: (e) => void (e.selection = Tn(e.doc.width, e.doc.height))
	},
	{
		id: "deselect",
		label: "Deselect",
		menu: "Select",
		keys: "Ctrl D",
		description: "Select nothing.",
		run: (e) => void (e.selection = null)
	},
	{
		id: "invert_selection",
		label: "Invert selection",
		menu: "Select",
		keys: "Ctrl Shift I",
		description: "Select what is not selected.",
		run: (e) => Lr(e, An(e.selection ?? {
			width: e.doc.width,
			height: e.doc.height,
			mask: new Uint8Array(e.doc.width * e.doc.height)
		}))
	},
	{
		id: "select_rect",
		label: "Select a box",
		description: "Select a rectangle of the canvas.",
		params: [
			Q("X", "x", -1e5, 1e5, 0),
			Q("Y", "y", -1e5, 1e5, 0),
			Q("Width", "width", 0, 1e5, 100),
			Q("Height", "height", 0, 1e5, 100),
			jr
		],
		run: (e, t) => Lr(e, kn(e.selection, En(e.doc.width, e.doc.height, t), t.mode))
	},
	{
		id: "select_ellipse",
		label: "Select an oval",
		description: "Select the oval inside a box.",
		params: [
			Q("X", "x", -1e5, 1e5, 0),
			Q("Y", "y", -1e5, 1e5, 0),
			Q("Width", "width", 0, 1e5, 100),
			Q("Height", "height", 0, 1e5, 100),
			jr
		],
		run: (e, t) => Lr(e, kn(e.selection, Dn(e.doc.width, e.doc.height, t), t.mode))
	},
	{
		id: "select_polygon",
		label: "Select an outline",
		description: "Select inside an outline through points ([[x, y], ...]).",
		params: [{
			name: "points",
			type: "points",
			label: "Points"
		}, jr],
		run: (e, t) => Lr(e, kn(e.selection, On(e.doc.width, e.doc.height, Vr(t.points)), t.mode))
	},
	{
		id: "magic_wand",
		label: "Select by colour",
		description: "Select the colour at a point, as the canvas looks: the touching patch, or every pixel of that colour.",
		params: [
			Q("X", "x", 0, 1e5, 0),
			Q("Y", "y", 0, 1e5, 0),
			Q("Tolerance", "tolerance", 0, 255, 32, { type: "integer" }),
			{
				name: "contiguous",
				type: "boolean",
				label: "Only touching pixels",
				default: !0
			},
			jr
		],
		run: (e, t) => Lr(e, kn(e.selection, Nn(e.flatten(), t, t.tolerance, t.contiguous), t.mode))
	},
	{
		id: "feather_selection",
		label: "Soften selection edge…",
		menu: "Select",
		description: "Blur the selection’s edge so edits fade out.",
		params: [Q("Softness", "radius", 1, 200, 8, {
			unit: "px",
			type: "integer"
		})],
		blocked: (e) => e.selection ? null : "Nothing is selected.",
		run: (e, t) => void (e.selection = Mn(e.selection, t.radius))
	},
	{
		id: "select_layer_pixels",
		label: "Select the layer’s pixels",
		menu: "Select",
		description: "Select what the layer covers (its non-transparent pixels).",
		params: [X],
		blocked: (e) => e.selected ? null : "Pick a layer first.",
		run: (e, t) => {
			let n = Rr(e, Z(e, t.layer)), r = new Uint8Array(e.doc.width * e.doc.height);
			for (let e = 0; e < r.length; e++) r[e] = n.data[e * 4 + 3];
			return Lr(e, {
				width: e.doc.width,
				height: e.doc.height,
				mask: r
			});
		}
	},
	{
		id: "fill",
		label: "Fill with main colour",
		menu: "Edit",
		keys: "Alt Delete",
		description: "Fill the selection (or the whole layer) of a picture layer with a colour.",
		params: [$("Colour", "color", Ur), X],
		run: (e, t) => {
			let n = Fr(e, t.layer), r = Ir(e, n.doc, n.layer);
			Gn(r.working, Fn(t.color), Pr(e, r.layer)), e.commit(r.doc, "Fill");
		}
	},
	{
		id: "clear",
		label: "Clear selected pixels",
		menu: "Edit",
		keys: "Delete",
		description: "Make the selected pixels of a picture layer transparent.",
		params: [X],
		blocked: (e) => e.selection ? e.selected?.kind === "raster" ? null : "Pick a picture layer." : "Select something first.",
		run: (e, t) => {
			if (!e.selection) throw new Y("Select something first.");
			let n = Nr(Z(e, t.layer)), r = Ir(e, e.doc, n);
			Kn(r.working, Pr(e, r.layer)), e.commit(r.doc, "Clear");
		}
	},
	{
		id: "copy",
		label: "Copy",
		menu: "Edit",
		keys: "Ctrl C",
		description: "Copy the selected pixels of a picture layer (Paste puts them on a new layer).",
		params: [X],
		blocked: (e) => e.selected?.kind === "raster" ? null : "Pick a picture layer.",
		run: (e, t) => {
			let n = Nr(Z(e, t.layer));
			return e.clipboard = {
				pixels: qn(e.store.get(n.pixels), Pr(e, n)),
				transform: n.transform
			}, { message: "Copied. Paste puts it on a new layer." };
		}
	},
	{
		id: "cut",
		label: "Cut",
		menu: "Edit",
		keys: "Ctrl X",
		description: "Copy the selected pixels and clear them.",
		params: [X],
		blocked: (e) => e.selected?.kind === "raster" ? null : "Pick a picture layer.",
		run: (e, t) => {
			let n = Nr(Z(e, t.layer)), r = Pr(e, n);
			e.clipboard = {
				pixels: qn(e.store.get(n.pixels), r),
				transform: n.transform
			};
			let i = Ir(e, e.doc, n);
			return Kn(i.working, r), e.commit(i.doc, "Cut"), { message: "Cut. Paste puts it on a new layer." };
		}
	},
	{
		id: "paste",
		label: "Paste as new layer",
		menu: "Edit",
		keys: "Ctrl V",
		description: "What was copied, on a new layer where it came from.",
		blocked: (e) => e.clipboard ? null : "Nothing has been copied.",
		run: (e) => {
			if (!e.clipboard) throw new Y("Nothing has been copied.");
			let t = rn("Pasted", e.store.add(Qt(e.clipboard.pixels)), e.clipboard.transform);
			e.commit(cn(e.doc, t, e.selectedId ?? void 0), "Paste"), e.selectedId = t.id;
		}
	},
	{
		id: "brush_stroke",
		label: "Paint a stroke",
		description: "Paint (or erase) along points ([[x, y], ...] in canvas pixels) on a picture layer, inside the selection.",
		params: [
			{
				name: "points",
				type: "points",
				label: "Points"
			},
			Q("Size", "size", 1, 2e3, 24, { unit: "px" }),
			Q("Hardness", "hardness", 0, 1, .6, { step: .01 }),
			Q("Flow", "flow", .01, 1, 1, { step: .01 }),
			$("Colour", "color", Ur),
			{
				name: "erase",
				type: "boolean",
				label: "Erase",
				default: !1
			},
			X
		],
		run: (e, t) => {
			let n = Fr(e, t.layer), r = Ir(e, n.doc, n.layer), i = Pr(e, r.layer), a = Rn(), o = (e) => {
				let t = fn(r.layer.transform), n = t.a * t.d - t.b * t.c || 1, i = e.x - t.e, a = e.y - t.f;
				return {
					x: (t.d * i - t.c * a) / n,
					y: (-t.b * i + t.a * a) / n
				};
			};
			for (let e of Vr(t.points)) Hn(r.working, a, o(e), {
				size: t.size,
				hardness: t.hardness,
				flow: t.flow,
				color: Fn(t.color),
				mode: t.erase ? "erase" : "paint"
			}, i);
			e.commit(r.doc, t.erase ? "Erase" : "Brush");
		}
	},
	{
		id: "flood_fill",
		label: "Fill a patch",
		description: "Fill the patch of similar colour around a point of a picture layer (paint bucket).",
		params: [
			Q("X", "x", -1e5, 1e5, 0),
			Q("Y", "y", -1e5, 1e5, 0),
			$("Colour", "color", Ur),
			Q("Tolerance", "tolerance", 0, 255, 32, { type: "integer" }),
			{
				name: "contiguous",
				type: "boolean",
				label: "Only touching pixels",
				default: !0
			},
			X
		],
		run: (e, t) => {
			let n = Fr(e, t.layer), r = Ir(e, n.doc, n.layer), i = fn(r.layer.transform), a = i.a * i.d - i.b * i.c || 1, o = t.x - i.e, s = t.y - i.f;
			Un(r.working, {
				x: (i.d * o - i.c * s) / a,
				y: (-i.b * o + i.a * s) / a
			}, Fn(t.color), t.tolerance, t.contiguous, Pr(e, r.layer)), e.commit(r.doc, "Fill");
		}
	},
	{
		id: "gradient",
		label: "Gradient",
		description: "A straight gradient on a picture layer from one point and colour to another, inside the selection.",
		params: [
			Q("From X", "x1", -1e5, 1e5, 0),
			Q("From Y", "y1", -1e5, 1e5, 0),
			Q("To X", "x2", -1e5, 1e5, (e) => e.doc.width),
			Q("To Y", "y2", -1e5, 1e5, 0),
			$("From colour", "from", Ur),
			$("To colour", "to", (e) => e.colours.second),
			X
		],
		run: (e, t) => {
			let n = Fr(e, t.layer), r = Ir(e, n.doc, n.layer), i = fn(r.layer.transform), a = i.a * i.d - i.b * i.c || 1, o = (e, t) => ({
				x: (i.d * (e - i.e) - i.c * (t - i.f)) / a,
				y: (-i.b * (e - i.e) + i.a * (t - i.f)) / a
			});
			Jn(r.working, o(t.x1, t.y1), o(t.x2, t.y2), Fn(t.from), Fn(t.to), Pr(e, r.layer)), e.commit(r.doc, "Gradient");
		}
	},
	...[
		[
			"brightness_contrast",
			"Brightness and contrast…",
			[Q("Brightness", "brightness", -100, 100, 0, { type: "integer" }), Q("Contrast", "contrast", -100, 100, 0, { type: "integer" })],
			(e, t, n) => er(e, t.brightness, t.contrast, n)
		],
		[
			"hue_saturation",
			"Hue and saturation…",
			[
				Q("Hue", "hue", -180, 180, 0, {
					type: "integer",
					unit: "°"
				}),
				Q("Saturation", "saturation", -100, 100, 0, { type: "integer" }),
				Q("Lightness", "lightness", -100, 100, 0, { type: "integer" })
			],
			(e, t, n) => tr(e, t.hue, t.saturation, t.lightness, n)
		],
		[
			"blur",
			"Blur…",
			[Q("Radius", "radius", 1, 100, 4, {
				type: "integer",
				unit: "px"
			})],
			(e, t, n) => lr(e, t.radius, n)
		],
		[
			"sharpen",
			"Sharpen…",
			[Q("Amount", "amount", 0, 3, .8, { step: .05 }), Q("Radius", "radius", 1, 8, 1, {
				type: "integer",
				unit: "px"
			})],
			(e, t, n) => ur(e, t.amount, t.radius, n)
		],
		[
			"levels",
			"Levels…",
			[
				Q("Input black", "inBlack", 0, 254, 0, { type: "integer" }),
				Q("Input white", "inWhite", 1, 255, 255, { type: "integer" }),
				Q("Midtones", "gamma", .1, 4, 1, { step: .01 }),
				Q("Output black", "outBlack", 0, 255, 0, { type: "integer" }),
				Q("Output white", "outWhite", 0, 255, 255, { type: "integer" })
			],
			(e, t, n) => rr(e, t.inBlack, t.inWhite, t.gamma, t.outBlack, t.outWhite, n)
		],
		[
			"curves",
			"Curves…",
			[
				Q("Shadows", "shadows", -100, 100, 0, { type: "integer" }),
				Q("Midtones", "midtones", -100, 100, 0, { type: "integer" }),
				Q("Highlights", "highlights", -100, 100, 0, { type: "integer" })
			],
			(e, t, n) => ir(e, t.shadows, t.midtones, t.highlights, n)
		],
		[
			"vibrance",
			"Vibrance…",
			[Q("Vibrance", "vibrance", -100, 100, 0, { type: "integer" })],
			(e, t, n) => ar(e, t.vibrance, n)
		],
		[
			"colour_balance",
			"Colour balance…",
			[Q("Warmth", "warmth", -100, 100, 0, { type: "integer" }), Q("Tint", "tint", -100, 100, 0, { type: "integer" })],
			(e, t, n) => or(e, t.warmth, t.tint, n)
		],
		[
			"posterize",
			"Posterize…",
			[Q("Levels", "steps", 2, 32, 6, { type: "integer" })],
			(e, t, n) => sr(e, t.steps, n)
		],
		[
			"threshold",
			"Threshold…",
			[Q("Level", "level", 0, 255, 128, { type: "integer" })],
			(e, t, n) => cr(e, t.level, n)
		],
		[
			"black_and_white",
			"Black and white",
			[],
			(e, t, n) => $n(e, n)
		],
		[
			"invert_colours",
			"Invert colours",
			[],
			(e, t, n) => Qn(e, n)
		]
	].map(([e, t, n, r]) => ({
		id: e,
		label: t,
		menu: "Adjust",
		keys: e === "invert_colours" ? "Ctrl I" : void 0,
		description: `${t.replace("…", "")} on a picture layer, inside the selection.`,
		params: [...n, X],
		preview: n.length > 0,
		blocked: (e) => e.selected?.kind === "raster" ? null : "Pick a picture layer.",
		run: (e, n) => {
			let i = Nr(Z(e, n.layer));
			e.commit(q(e.doc, i.id, { pixels: e.store.add(r(e.store.get(i.pixels), n, Pr(e, i))) }), t.replace("…", ""));
		}
	})),
	{
		id: "canvas_size",
		label: "Canvas size…",
		menu: "Canvas",
		description: "Make the canvas a new size; layers stay centred.",
		params: [Q("Width", "width", 1, 16384, (e) => e.doc.width, {
			type: "integer",
			unit: "px"
		}), Q("Height", "height", 1, 16384, (e) => e.doc.height, {
			type: "integer",
			unit: "px"
		})],
		run: (e, t) => {
			let n = (t.width - e.doc.width) / 2, r = (t.height - e.doc.height) / 2;
			e.commit({
				...e.doc,
				width: t.width,
				height: t.height,
				layers: e.doc.layers.map((e) => ({
					...e,
					mask: void 0,
					transform: {
						...e.transform,
						x: e.transform.x + n,
						y: e.transform.y + r
					}
				}))
			}, "Canvas size"), e.selection = null;
		}
	},
	{
		id: "crop",
		label: "Crop canvas",
		description: "Keep only a box of the canvas.",
		params: [
			Q("X", "x", -1e5, 1e5, 0, { type: "integer" }),
			Q("Y", "y", -1e5, 1e5, 0, { type: "integer" }),
			Q("Width", "width", 1, 16384, 100, { type: "integer" }),
			Q("Height", "height", 1, 16384, 100, { type: "integer" })
		],
		run: (e, t) => {
			let n = {
				x: t.x,
				y: t.y,
				width: t.width,
				height: t.height
			}, r = e.doc.layers.map((t) => {
				let r = t.mask;
				if (r) {
					let t = e.store.get(r), i = Zt(n.width, n.height);
					for (let e = 0; e < n.height; e++) for (let r = 0; r < n.width; r++) {
						let a = r + n.x, o = e + n.y;
						i.data[(e * n.width + r) * 4 + 3] = a >= 0 && o >= 0 && a < t.width && o < t.height ? t.data[(o * t.width + a) * 4 + 3] : 0;
					}
					r = e.store.add(i, "mask");
				}
				return {
					...t,
					mask: r,
					transform: {
						...t.transform,
						x: t.transform.x - n.x,
						y: t.transform.y - n.y
					}
				};
			});
			e.commit({
				...e.doc,
				width: n.width,
				height: n.height,
				layers: r
			}, "Crop"), e.selection = null;
		}
	},
	{
		id: "canvas_colour",
		label: "Canvas colour",
		description: "The colour under every layer, or null for transparent.",
		params: [$("Colour", "color", "#ffffff", { nullable: !0 })],
		run: (e, t) => void e.commit({
			...e.doc,
			background: t.color
		}, "Canvas colour")
	},
	{
		id: "set_colours",
		label: "Set colours",
		description: "The main and second colours used by painting, shapes and text when no colour is given.",
		params: [$("Main colour", "main", void 0, { optional: !0 }), $("Second colour", "second", void 0, { optional: !0 })],
		run: (e, t) => {
			t.main && (e.colours = {
				...e.colours,
				main: t.main
			}), t.second && (e.colours = {
				...e.colours,
				second: t.second
			});
		}
	}
], Gr = new Map(Wr.map((e) => [e.id, e])), Kr = (e) => Gr.get(e);
async function qr(e, t) {
	let n = await e.backend.encode(e.store.get(t), "png"), r = "";
	for (let e = 0; e < n.length; e += 32768) r += String.fromCharCode(...n.subarray(e, e + 32768));
	return `data:image/png;base64,${btoa(r)}`;
}
async function Jr(e, t, n = {}) {
	let r = {}, i = new Set((t.params ?? []).map((e) => e.name));
	for (let e of Object.keys(n)) if (!i.has(e)) throw new Y(`"${t.id}" has no setting called "${e}".`);
	for (let i of t.params ?? []) {
		let a = n[i.name];
		if (a === void 0 && (a = typeof i.default == "function" ? i.default(e) : i.default), a === void 0) {
			if (i.optional) continue;
			throw new Y(`"${t.id}" needs ${i.label.toLowerCase()} (${i.name}).`);
		}
		switch (i.type) {
			case "number":
			case "integer": {
				let e = typeof a == "string" ? Number(a) : a;
				if (typeof e != "number" || !Number.isFinite(e)) throw new Y(`${i.name} must be a number.`);
				let t = Math.min(i.max ?? Infinity, Math.max(i.min ?? -Infinity, e));
				i.type === "integer" && (t = Math.round(t)), a = t;
				break;
			}
			case "boolean":
				if ((a === "true" || a === "false") && (a = a === "true"), typeof a != "boolean") throw new Y(`${i.name} must be true or false.`);
				break;
			case "string":
				a = String(a);
				break;
			case "enum":
				if (!i.options.includes(String(a))) throw new Y(`${i.name} must be one of: ${i.options.join(", ")}.`);
				break;
			case "color":
				if (a === null || a === "null" || a === "none") {
					if (!i.nullable) throw new Y(`${i.name} needs a colour.`);
					a = null;
				} else if (typeof a != "string" || !/^#[0-9a-f]{6}$/i.test(a)) throw new Y(`${i.name} must be a colour like #ff8800.`);
				else a = a.toLowerCase();
				break;
			case "points": {
				let e = typeof a == "string" ? JSON.parse(a) : a;
				if (!Array.isArray(e) || !e.length) throw new Y(`${i.name} must be a list of points like [[10, 20], [30, 40]].`);
				a = e;
				break;
			}
			case "image": if (a instanceof Uint8Array && (a = await e.backend.decode(a)), !a || typeof a != "object" || !("data" in a)) throw new Y(`${i.name} must be a picture.`);
		}
		r[i.name] = a;
	}
	return r;
}
async function Yr(e, t, n = {}) {
	let r = Kr(t);
	if (!r) throw new Y(`There is no command "${t}". The command "describe" lists the design; the list of commands says what each does.`);
	let i = r.params?.some((e) => e.name === "layer") && n.layer ? null : r.blocked?.(e) ?? null;
	if (i) throw new Y(i);
	return r.run(e, await Jr(e, r, n));
}
//#endregion
//#region src/edit/icons.tsx
var Xr = {
	move: /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N("path", { d: "M12 3v18M3 12h18" }), /* @__PURE__ */ N("path", { d: "M12 3l-3 3M12 3l3 3M12 21l-3-3M12 21l3-3M3 12l3-3M3 12l3 3M21 12l-3-3M21 12l-3 3" })] }),
	box: /* @__PURE__ */ N("rect", {
		x: "4",
		y: "5",
		width: "16",
		height: "14",
		rx: "1",
		strokeDasharray: "3 2.5"
	}),
	oval: /* @__PURE__ */ N("ellipse", {
		cx: "12",
		cy: "12",
		rx: "8.5",
		ry: "7",
		strokeDasharray: "3 2.5"
	}),
	lasso: /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N("path", {
		d: "M7 16c-3-2-3.5-6 0-8.5S17 5 19 8s0 7-5 7.5c-2.5.3-5 0-7 .5",
		strokeDasharray: "3 2.5"
	}), /* @__PURE__ */ N("path", { d: "M7 16c-1 1.5 0 3.5 2 3" })] }),
	wand: /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N("path", { d: "M5 19L15 9" }), /* @__PURE__ */ N("path", { d: "M16 3v3M19.5 4.5l-2 2M21 8h-3M17 11.5l-1.5-1.5" })] }),
	brush: /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N("path", { d: "M14 4l6 6-8 8-6-6z" }), /* @__PURE__ */ N("path", { d: "M6 12c-2 1-2.5 4-3 8 4-.5 7-1 8-3" })] }),
	eraser: /* @__PURE__ */ P(M, { children: [
		/* @__PURE__ */ N("path", { d: "M8 20h12" }),
		/* @__PURE__ */ N("path", { d: "M4 15l9-9 6 6-8 8H8z" }),
		/* @__PURE__ */ N("path", { d: "M9 10l6 6" })
	] }),
	clone: /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N("rect", {
		x: "4",
		y: "4",
		width: "10",
		height: "10",
		rx: "1"
	}), /* @__PURE__ */ N("rect", {
		x: "10",
		y: "10",
		width: "10",
		height: "10",
		rx: "1",
		strokeDasharray: "3 2"
	})] }),
	bucket: /* @__PURE__ */ P(M, { children: [
		/* @__PURE__ */ N("path", { d: "M5 11l6-6 8 8-6 6z" }),
		/* @__PURE__ */ N("path", { d: "M5 11h14" }),
		/* @__PURE__ */ N("path", { d: "M20 16c0 1.5.8 2.5 0 3.5s-2-.5-1.5-1.5z" })
	] }),
	gradient: /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N("rect", {
		x: "3",
		y: "5",
		width: "18",
		height: "14",
		rx: "2"
	}), /* @__PURE__ */ N("path", {
		d: "M7 5v14M11 5v14M15 5v14",
		opacity: ".5"
	})] }),
	dropper: /* @__PURE__ */ P(M, { children: [
		/* @__PURE__ */ N("path", { d: "M14 6l4 4" }),
		/* @__PURE__ */ N("path", { d: "M16 4a2.1 2.1 0 013 3l-2 2-3-3z" }),
		/* @__PURE__ */ N("path", { d: "M15 9l-8 8-3 1 1-3 8-8" })
	] }),
	rect: /* @__PURE__ */ N("rect", {
		x: "4",
		y: "5",
		width: "16",
		height: "14",
		rx: "2"
	}),
	ellipse: /* @__PURE__ */ N("ellipse", {
		cx: "12",
		cy: "12",
		rx: "8.5",
		ry: "7"
	}),
	line: /* @__PURE__ */ N("path", { d: "M5 19L19 5" }),
	pen: /* @__PURE__ */ P(M, { children: [
		/* @__PURE__ */ N("path", { d: "M12 3l5 9-5 9-5-9z" }),
		/* @__PURE__ */ N("circle", {
			cx: "12",
			cy: "12",
			r: "1.5"
		}),
		/* @__PURE__ */ N("path", { d: "M12 21v-7.5" })
	] }),
	text: /* @__PURE__ */ N(M, { children: /* @__PURE__ */ N("path", { d: "M5 6V4h14v2M12 4v16M9 20h6" }) }),
	crop: /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N("path", { d: "M7 3v14h14" }), /* @__PURE__ */ N("path", { d: "M3 7h14v14" })] }),
	hand: /* @__PURE__ */ N("path", { d: "M8 13V6.5a1.5 1.5 0 013 0V12m0-6.5a1.5 1.5 0 013 0V12m0-5a1.5 1.5 0 013 0v7c0 4-2.5 7-6 7s-5-2-7-5l-1.5-2.5a1.5 1.5 0 012.5-1.5L8 14" }),
	zoom: /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N("circle", {
		cx: "10.5",
		cy: "10.5",
		r: "6.5"
	}), /* @__PURE__ */ N("path", { d: "M15.5 15.5L20 20M8 10.5h5M10.5 8v5" })] }),
	eye: /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N("path", { d: "M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z" }), /* @__PURE__ */ N("circle", {
		cx: "12",
		cy: "12",
		r: "3"
	})] }),
	eyeOff: /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N("path", {
		d: "M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z",
		opacity: ".35"
	}), /* @__PURE__ */ N("path", { d: "M4 20L20 4" })] }),
	lock: /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N("rect", {
		x: "5",
		y: "11",
		width: "14",
		height: "9",
		rx: "2"
	}), /* @__PURE__ */ N("path", { d: "M8 11V8a4 4 0 018 0v3" })] }),
	unlock: /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N("rect", {
		x: "5",
		y: "11",
		width: "14",
		height: "9",
		rx: "2"
	}), /* @__PURE__ */ N("path", { d: "M8 11V8a4 4 0 017.5-2" })] }),
	plus: /* @__PURE__ */ N("path", { d: "M12 5v14M5 12h14" }),
	copy: /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N("rect", {
		x: "8",
		y: "8",
		width: "12",
		height: "12",
		rx: "2"
	}), /* @__PURE__ */ N("path", { d: "M16 8V5a1 1 0 00-1-1H5a1 1 0 00-1 1v10a1 1 0 001 1h3" })] }),
	trash: /* @__PURE__ */ N(M, { children: /* @__PURE__ */ N("path", { d: "M4 7h16M10 7V4h4v3M6 7l1 13h10l1-13" }) }),
	up: /* @__PURE__ */ N("path", { d: "M12 19V5M6 11l6-6 6 6" }),
	down: /* @__PURE__ */ N("path", { d: "M12 5v14M6 13l6 6 6-6" }),
	merge: /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N("path", { d: "M7 4v5a5 5 0 005 5 5 5 0 005-5V4" }), /* @__PURE__ */ N("path", { d: "M12 14v6M9 17l3 3 3-3" })] }),
	mask: /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N("rect", {
		x: "3",
		y: "5",
		width: "18",
		height: "14",
		rx: "2"
	}), /* @__PURE__ */ N("circle", {
		cx: "12",
		cy: "12",
		r: "4",
		fill: "currentColor",
		stroke: "none"
	})] }),
	undo: /* @__PURE__ */ N("path", {
		d: "M9 7L4 12l5 5M4 12h10a6 6 0 010 12",
		transform: "translate(0 -3)"
	}),
	redo: /* @__PURE__ */ N("path", {
		d: "M15 7l5 5-5 5M20 12H10a6 6 0 000 12",
		transform: "translate(0 -3)"
	}),
	swap: /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N("path", { d: "M7 4L4 7l3 3M4 7h11a4 4 0 014 4" }), /* @__PURE__ */ N("path", { d: "M17 20l3-3-3-3M20 17H9a4 4 0 01-4-4" })] }),
	search: /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N("circle", {
		cx: "11",
		cy: "11",
		r: "6"
	}), /* @__PURE__ */ N("path", { d: "M16 16l4 4" })] })
};
function Zr({ name: e, size: t = 18, title: n }) {
	return /* @__PURE__ */ P("svg", {
		width: t,
		height: t,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: 1.7,
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": !n || void 0,
		role: n ? "img" : void 0,
		children: [n && /* @__PURE__ */ N("title", { children: n }), Xr[e]]
	});
}
//#endregion
//#region src/edit/EditMode.tsx
var Qr = xe(() => import("./ModelMode-J3uEt9XB.js").then((e) => ({ default: e.ModelMode })));
function $r(e) {
	let t = document.createElement("canvas");
	t.width = e.width, t.height = e.height;
	let n = t.getContext("2d", { willReadFrequently: !0 });
	n.drawImage(e, 0, 0);
	let r = n.getImageData(0, 0, t.width, t.height);
	return {
		width: r.width,
		height: r.height,
		data: r.data
	};
}
function ei(e, t, n, r = 640) {
	let i = document.createElement("canvas");
	i.width = e.width, i.height = e.height;
	let a = i.getContext("2d", { willReadFrequently: !0 });
	br(a, e, {
		...t,
		opacity: 1,
		blend: "normal",
		visible: !0,
		style: void 0
	}, n);
	let o = a.getImageData(0, 0, e.width, e.height).data, [s, c, l, u] = [
		e.width,
		e.height,
		-1,
		-1
	];
	for (let t = 0; t < e.height; t++) for (let n = 0; n < e.width; n++) o[(t * e.width + n) * 4 + 3] >= 128 && ([s, c, l, u] = [
		Math.min(s, n),
		Math.min(c, t),
		Math.max(l, n),
		Math.max(u, t)
	]);
	if (l < 0) return null;
	let d = Math.min(1, r / Math.max(l - s + 1, u - c + 1)), [f, p] = [Math.round((l - s + 1) * d) + 8, Math.round((u - c + 1) * d) + 8], m = document.createElement("canvas");
	m.width = f, m.height = p;
	let h = m.getContext("2d", { willReadFrequently: !0 });
	return h.drawImage(i, s, c, l - s + 1, u - c + 1, 4, 4, f - 8, p - 8), {
		rgba: h.getImageData(0, 0, f, p).data,
		width: f,
		height: p
	};
}
function ti(e) {
	let t = document.createElement("canvas");
	return t.width = e.width, t.height = e.height, t.getContext("2d").putImageData(new ImageData(e.data, e.width, e.height), 0, 0), t;
}
var ni = (e, t = "image/png", n) => new Promise((r, i) => e.toBlob((e) => e ? r(e) : i(/* @__PURE__ */ Error("The picture could not be made.")), t, n));
function ri(e, t) {
	let n = URL.createObjectURL(e), r = document.createElement("a");
	r.href = n, r.download = t, r.click(), setTimeout(() => URL.revokeObjectURL(n), 1e3);
}
function ii(e) {
	return new Promise((t) => {
		let n = document.createElement("input");
		n.type = "file", n.accept = e, n.onchange = () => t(n.files?.[0] ?? null), n.click();
	});
}
async function ai(e) {
	let t = new Image();
	return t.src = e, await t.decode(), $r(t);
}
var oi = null, si = (e) => mr(oi ??= document.createElement("canvas").getContext("2d"), e), ci = [
	"system-ui, sans-serif",
	"Georgia, serif",
	"\"Trebuchet MS\", sans-serif",
	"Impact, sans-serif",
	"\"Courier New\", monospace",
	"\"Brush Script MT\", cursive"
], li = [
	"File",
	"Edit",
	"Select",
	"Layer",
	"Adjust",
	"Canvas",
	"View"
], ui = (e) => `Command ${e} in packages/canvas/src/commands.ts; headless: npm run design, or the MCP tool design_run with command "${e}" (docs/MCP.md).`, di = new $t();
function fi(e) {
	return {
		surface: (e, t) => {
			let n = document.createElement("canvas");
			n.width = e, n.height = t;
			let r = n.getContext("2d", { willReadFrequently: !0 });
			return {
				ctx: r,
				canvas: n,
				read: () => ({
					width: e,
					height: t,
					data: r.getImageData(0, 0, e, t).data
				})
			};
		},
		image(t, n) {
			let r = e.get(t);
			return r || (r = ti(n), e.set(t, r)), r;
		},
		path: (e) => new Path2D(e),
		async encode(e, t, n) {
			let r = await ni(ti(e), `image/${t}`, n);
			return new Uint8Array(await r.arrayBuffer());
		},
		async decode(e) {
			let t = await createImageBitmap(new Blob([e])), n = $r(t);
			return t.close(), n;
		}
	};
}
var pi = (e, t, n = !1) => {
	let r = t.x - e.x, i = t.y - e.y;
	if (n) {
		let e = Math.max(Math.abs(r), Math.abs(i));
		r = Math.sign(r || 1) * e, i = Math.sign(i || 1) * e;
	}
	return {
		x: Math.min(e.x, e.x + r),
		y: Math.min(e.y, e.y + i),
		width: Math.abs(r),
		height: Math.abs(i)
	};
}, mi = (e) => e.shiftKey && e.altKey ? "intersect" : e.shiftKey ? "add" : e.altKey ? "subtract" : "replace";
function hi({ open: e, title: t = "Design", onDone: n, doneLabel: r = "Done", onClose: i }) {
	let a = A(null), [o, s] = j(null), [c, l] = j(null), [u, d] = j(null), [f, p] = j("move"), [m, h] = j({
		main: "#1a1a1a",
		second: "#ffffff"
	}), [g, _] = j({
		size: 24,
		hardness: .6,
		flow: 1
	}), [v, y] = j({
		tolerance: 32,
		contiguous: !0
	}), [b, x] = j({
		fill: "#e46a9b",
		stroke: null,
		strokeWidth: 4,
		radius: 0
	}), [S, ee] = j({
		font: ci[0],
		size: 72,
		weight: 700
	}), [C, te] = j(null), [ne, re] = j(!1), [w, oe] = j({
		zoom: 1,
		x: 0,
		y: 0
	}), [T, ce] = j(null), [E, ue] = j(null), [de, fe] = j(null), [D, pe] = j(null), [me, he] = j(null), [ge, _e] = j(null), [ve, ye] = j(null), [xe, O] = j(null), [we, Te] = j(null), [F, Ee] = j("layers"), [De, Oe] = j(null), [ke, Ae] = j(null), [je, Me] = j(null), [Ne, Pe] = j(!1), Fe = A(null), Ie = A(null), Le = A(null), I = A(null), Re = A(!1), L = A(null), ze = A(null), Be = A(/* @__PURE__ */ new Map()), Ve = A([]), [He, Ue] = j({
		width: 0,
		height: 0
	}), We = Ce(() => fi(Be.current), []), Ge = () => a.current, R = a.current?.store ?? di, z = o && u ? sn(o, u) : void 0;
	k(() => {
		let t = !1;
		return (async () => {
			try {
				let n, r = new $t();
				if (e.kind === "project") {
					let t = await Or(e.file, ai);
					r = t.store, n = t.doc;
				} else if (n = tn(e.width, e.height, e.background === void 0 ? "#ffffff" : e.background), e.kind === "pictures") for (let t of e.layers) n = cn(n, rn(t.name, r.add($r(t.picture)), {
					x: t.x ?? 0,
					y: t.y ?? 0
				}));
				if (t) return;
				a.current = new kr(We, n, r), s(n), d(n.layers[n.layers.length - 1]?.id ?? null);
			} catch (e) {
				t || l(e instanceof Error ? e.message : "This could not be opened.");
			}
		})(), () => {
			t = !0;
		};
	}, []);
	let Ke = () => {
		for (let e of [...Be.current.keys()]) Ge().store.get(e) || Be.current.delete(e);
	}, B = (e, t) => {
		Ge().commit(e, t), s(e), Ke();
	}, qe = () => {
		Ge().history.canUndo && s(Ge().history.undo());
	}, Je = () => {
		Ge().history.canRedo && s(Ge().history.redo());
	}, Ye = () => s(Ge().history.doc), Xe = (e) => {
		let t = Be.current.get(e);
		if (!t) {
			let n = Ge().store.get(e);
			if (!n) return;
			t = ti(n), Be.current.set(e, t);
		}
		return t;
	}, Ze = {
		image: Xe,
		surface(e, t, n = 0) {
			let r = Ve.current[n] ??= document.createElement("canvas");
			(r.width !== e || r.height !== t) && (r.width = e, r.height = t);
			let i = r.getContext("2d");
			return i.setTransform(1, 0, 0, 1, 0, 0), i.globalCompositeOperation = "source-over", i.clearRect(0, 0, e, t), {
				ctx: i,
				canvas: r
			};
		},
		path: (e) => new Path2D(e)
	}, Qe = (e, t = !0) => {
		let n = document.createElement("canvas");
		return n.width = e.width, n.height = e.height, xr(n.getContext("2d"), e, Ze, { background: t }), n;
	}, $e = (e) => {
		let t = Qe(e), n = t.getContext("2d", { willReadFrequently: !0 }).getImageData(0, 0, t.width, t.height);
		return {
			width: n.width,
			height: n.height,
			data: n.data
		};
	}, et = (e) => {
		if (!C) return;
		let { width: t, height: n, mask: r } = C;
		if (!e) return (e, i) => e >= 0 && i >= 0 && e < t && i < n ? r[i * t + e] / 255 : 0;
		let i = fn(e.transform);
		return (e, a) => {
			let o = mn(i, {
				x: e + .5,
				y: a + .5
			}), s = Math.floor(o.x), c = Math.floor(o.y);
			return s >= 0 && c >= 0 && s < t && c < n ? r[c * t + s] / 255 : 0;
		};
	}, tt = (e = o) => {
		if (!e || !He.width) return;
		let t = Math.min(1, (He.width - 64) / e.width, (He.height - 150) / e.height);
		oe({
			zoom: t,
			x: (He.width - e.width * t) / 2,
			y: (He.height - 90 - e.height * t) / 2 + 10
		});
	}, nt = (e, t = {
		x: He.width / 2,
		y: He.height / 2
	}) => oe((n) => {
		let r = Math.min(32, Math.max(.05, n.zoom * e));
		return {
			zoom: r,
			x: t.x - (t.x - n.x) * r / n.zoom,
			y: t.y - (t.y - n.y) * r / n.zoom
		};
	});
	Se(() => {
		let e = Fe.current;
		if (!e) return;
		let t = new ResizeObserver(() => Ue({
			width: e.clientWidth,
			height: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, [o === null]);
	let rt = A(!1);
	k(() => {
		o && He.width && !rt.current && (rt.current = !0, tt(o));
	}, [o, He.width]);
	let V = (e) => {
		let t = Ie.current.getBoundingClientRect();
		return {
			x: (e.clientX - t.left - w.x) / w.zoom,
			y: (e.clientY - t.top - w.y) / w.zoom
		};
	}, it = Ce(() => {
		if (!C) return null;
		let e = Pn(C), t = document.createElement("canvas");
		t.width = C.width, t.height = C.height;
		let n = t.getContext("2d"), r = n.createImageData(t.width, t.height);
		for (let n = 0; n < e.length; n++) {
			if (!e[n]) continue;
			let i = n % t.width, a = i + (n - i) / t.width >> 2 & 1 ? 255 : 0;
			r.data.set([
				a,
				a,
				a,
				255
			], n * 4);
		}
		return n.putImageData(r, 0, 0), t;
	}, [C]), at = Ce(() => {
		let e = document.createElement("canvas");
		e.width = e.height = 16;
		let t = e.getContext("2d");
		return t.fillStyle = "#ffffff", t.fillRect(0, 0, 16, 16), t.fillStyle = "#e4e4ea", t.fillRect(0, 0, 8, 8), t.fillRect(8, 8, 8, 8), e;
	}, []), ot = () => T?.kind === "line" && f === "line" ? an("", {
		type: "line",
		x2: T.to.x - T.from.x,
		y2: T.to.y - T.from.y
	}, {
		fill: null,
		stroke: b.stroke ?? m.main,
		strokeWidth: b.strokeWidth
	}, {
		x: T.from.x,
		y: T.from.y
	}) : T?.kind === "rect" && (f === "rect" || f === "ellipse") ? an("", f === "rect" ? {
		type: "rect",
		width: T.rect.width,
		height: T.rect.height,
		radius: b.radius
	} : {
		type: "ellipse",
		width: T.rect.width,
		height: T.rect.height
	}, b, {
		x: T.rect.x,
		y: T.rect.y
	}) : E && E.length ? an("", {
		type: "path",
		path: {
			points: E,
			closed: !1
		}
	}, {
		fill: null,
		stroke: b.stroke ?? m.main,
		strokeWidth: Math.max(1, b.strokeWidth)
	}) : null, st = () => {
		let e = Ie.current;
		if (!e || !o) return;
		let t = window.devicePixelRatio || 1, n = Math.round(He.width * t), r = Math.round(He.height * t);
		(e.width !== n || e.height !== r) && (e.width = n, e.height = r);
		let i = e.getContext("2d");
		i.setTransform(1, 0, 0, 1, 0, 0), i.clearRect(0, 0, n, r);
		let a = w.zoom;
		i.setTransform(t * a, 0, 0, t * a, t * w.x, t * w.y), i.save(), i.shadowColor = "rgba(0,0,0,0.5)", i.shadowBlur = 30 * t;
		let s = i.createPattern(at, "repeat");
		s.setTransform(new DOMMatrix().scale(1 / a)), i.fillStyle = s, i.fillRect(0, 0, o.width, o.height), i.restore(), i.save(), i.beginPath(), i.rect(0, 0, o.width, o.height), i.clip(), i.imageSmoothingEnabled = a < 2;
		let c = ot();
		xr(i, c ? {
			...o,
			layers: [...o.layers, c]
		} : o, Ze, { hide: D ? /* @__PURE__ */ new Set([D.id]) : void 0 }), i.restore();
		let l = 1 / a;
		if (it && (i.imageSmoothingEnabled = !1, i.drawImage(it, 0, 0)), i.lineWidth = l * 1.5, f === "move" && z && z.visible && !D) {
			let e = _n(z, R);
			if (i.strokeStyle = "#7cc4ff", i.beginPath(), e.forEach((e, t) => t ? i.lineTo(e.x, e.y) : i.moveTo(e.x, e.y)), i.closePath(), i.stroke(), !z.locked) {
				i.fillStyle = "#ffffff";
				for (let t of e) i.fillRect(t.x - 4 * l, t.y - 4 * l, 8 * l, 8 * l), i.strokeRect(t.x - 4 * l, t.y - 4 * l, 8 * l, 8 * l);
				let t = dt(z);
				i.beginPath(), i.moveTo((e[0].x + e[1].x) / 2, (e[0].y + e[1].y) / 2), i.lineTo(t.x, t.y), i.stroke(), i.beginPath(), i.arc(t.x, t.y, 5 * l, 0, Math.PI * 2), i.fill(), i.stroke();
			}
		}
		if (i.setLineDash([5 * l, 4 * l]), i.strokeStyle = "#ffffff", T?.kind === "rect" && (f === "box" || f === "oval")) {
			let e = T.rect;
			i.beginPath(), T.oval ? i.ellipse(e.x + e.width / 2, e.y + e.height / 2, e.width / 2, e.height / 2, 0, 0, Math.PI * 2) : i.rect(e.x, e.y, e.width, e.height), i.stroke();
		}
		if (T?.kind === "lasso" && (i.beginPath(), T.points.forEach((e, t) => t ? i.lineTo(e.x, e.y) : i.moveTo(e.x, e.y)), i.stroke()), T?.kind === "line" && f === "gradient") {
			i.setLineDash([]), i.strokeStyle = "#ffffff", i.beginPath(), i.moveTo(T.from.x, T.from.y), i.lineTo(T.to.x, T.to.y), i.stroke();
			for (let [e, t] of [[T.from, m.main], [T.to, m.second]]) i.fillStyle = t, i.beginPath(), i.arc(e.x, e.y, 6 * l, 0, Math.PI * 2), i.fill(), i.stroke();
		}
		let u = T?.kind === "crop" ? T.rect : de;
		if (u && f === "crop") {
			i.setLineDash([]), i.fillStyle = "rgba(10,10,14,0.6)", i.beginPath(), i.rect(-1e5, -1e5, 2e5, 2e5), i.rect(u.x, u.y, u.width, u.height), i.fill("evenodd"), i.strokeStyle = "#ffffff", i.strokeRect(u.x, u.y, u.width, u.height), i.strokeStyle = "rgba(255,255,255,0.35)";
			for (let e of [1 / 3, 2 / 3]) i.beginPath(), i.moveTo(u.x + u.width * e, u.y), i.lineTo(u.x + u.width * e, u.y + u.height), i.moveTo(u.x, u.y + u.height * e), i.lineTo(u.x + u.width, u.y + u.height * e), i.stroke();
		}
		if (i.setLineDash([]), E?.length && (i.strokeStyle = "#7cc4ff", i.fillStyle = "#ffffff", E.forEach((e, t) => {
			for (let t of [e.in, e.out]) t && (i.beginPath(), i.moveTo(e.x, e.y), i.lineTo(e.x + t.x, e.y + t.y), i.stroke(), i.beginPath(), i.arc(e.x + t.x, e.y + t.y, 3 * l, 0, Math.PI * 2), i.fill());
			i.fillStyle = t === 0 ? "#7cc4ff" : "#ffffff", i.fillRect(e.x - 3.5 * l, e.y - 3.5 * l, 7 * l, 7 * l), i.strokeRect(e.x - 3.5 * l, e.y - 3.5 * l, 7 * l, 7 * l), i.fillStyle = "#ffffff";
		})), De && (f === "brush" || f === "eraser" || f === "clone") && (i.strokeStyle = "rgba(255,255,255,0.9)", i.beginPath(), i.arc(De.x, De.y, g.size / 2, 0, Math.PI * 2), i.stroke(), i.strokeStyle = "rgba(0,0,0,0.6)", i.beginPath(), i.arc(De.x, De.y, g.size / 2 + l, 0, Math.PI * 2), i.stroke()), f === "clone" && L.current) {
			let e = L.current;
			i.strokeStyle = "#7cc4ff", i.beginPath(), i.moveTo(e.x - 8 * l, e.y), i.lineTo(e.x + 8 * l, e.y), i.moveTo(e.x, e.y - 8 * l), i.lineTo(e.x, e.y + 8 * l), i.stroke();
		}
	}, ct = A(st);
	ct.current = st;
	let lt = A(0), ut = () => {
		lt.current ||= requestAnimationFrame(() => {
			lt.current = 0, ct.current();
		});
	};
	k(ut);
	function dt(e) {
		let t = _n(e, R), n = {
			x: (t[0].x + t[1].x) / 2,
			y: (t[0].y + t[1].y) / 2
		}, r = {
			x: (t[0].x + t[2].x) / 2,
			y: (t[0].y + t[2].y) / 2
		}, i = n.x - r.x, a = n.y - r.y, o = Math.hypot(i, a) || 1;
		return {
			x: n.x + i / o * (26 / w.zoom),
			y: n.y + a / o * (26 / w.zoom)
		};
	}
	let ft = (e, t) => {
		let n = 9 / w.zoom, r = dt(e);
		if (Math.hypot(t.x - r.x, t.y - r.y) < n) return "rotate";
		let i = _n(e, R);
		for (let e = 0; e < 4; e++) if (Math.hypot(t.x - i[e].x, t.y - i[e].y) < n) return e;
		return null;
	}, pt = (e, t, n) => {
		let r = mn(fn(e), n), i = mn(fn({
			...t,
			x: 0,
			y: 0
		}), n);
		return {
			...t,
			x: r.x - i.x,
			y: r.y - i.y
		};
	}, mt = (e) => {
		let t = u ? sn(e, u) : void 0;
		if (t?.locked) return Ae("That layer is locked. Unlock it in the layers list to paint on it."), null;
		if (t && ne && t.mask) return {
			doc: e,
			layer: t,
			field: "mask"
		};
		if (t?.kind === "raster") return {
			doc: e,
			layer: t,
			field: "pixels"
		};
		let n = rn("Paint", R.add(Zt(e.width, e.height)));
		return d(n.id), {
			doc: cn(e, n, t?.id),
			layer: n,
			field: "pixels"
		};
	}, ht = (e, t, n) => {
		let r = n === "mask" ? t.mask : t.pixels, i = Qt(R.get(r)), a = R.add(i, n === "mask" ? "mask" : "px");
		return {
			next: q(e, t.id, { [n]: a }),
			working: i,
			id: a
		};
	}, gt = (e, t, n) => {
		if (!n) return;
		let r = Xe(e);
		r && (r.getContext("2d").putImageData(new ImageData(t.data, t.width, t.height), 0, 0, n.x, n.y, n.width, n.height), ut());
	}, _t = (e) => {
		if (!o || D) return;
		e.preventDefault(), (!Le.current?.contains(document.activeElement) || document.activeElement === document.body) && Le.current?.focus({ preventScroll: !0 }), e.target.setPointerCapture(e.pointerId), _e(null), Ae(null);
		let t = V(e);
		if (Re.current || f === "hand" || e.button === 1) I.current = {
			kind: "pan",
			start: {
				x: e.clientX,
				y: e.clientY
			},
			view0: w
		};
		else switch (f) {
			case "move": {
				if (z && !z.locked && z.visible) {
					let e = ft(z, t);
					if (e === "rotate") return void (I.current = {
						kind: "rotate",
						start: t,
						doc0: o,
						layer0: z
					});
					if (e !== null) return void (I.current = {
						kind: "scale",
						corner: e,
						doc0: o,
						layer0: z
					});
				}
				let e = vn(o, R, t) ?? (z && !z.locked && vt(z, t) ? z : void 0);
				e && (d(e.id), I.current = {
					kind: "move",
					start: t,
					doc0: o,
					layer0: e
				});
				return;
			}
			case "box":
			case "oval":
				I.current = {
					kind: "marquee",
					start: t,
					how: mi(e),
					oval: f === "oval"
				};
				return;
			case "lasso":
				I.current = {
					kind: "lasso",
					points: [t],
					how: mi(e)
				};
				return;
			case "wand": {
				let n = Nn($e(o), t, v.tolerance, v.contiguous), r = kn(C, n, mi(e));
				te(jn(r) ? r : null);
				return;
			}
			case "dropper": {
				let n = Yn($e(o), t);
				n && h((t) => e.altKey ? {
					...t,
					second: In(n)
				} : {
					...t,
					main: In(n)
				});
				return;
			}
			case "brush":
			case "eraser":
			case "clone": {
				if (f === "clone" && e.altKey) {
					L.current = t, ut();
					return;
				}
				if (f === "clone" && !L.current) {
					Ae("Alt-click where to copy from first.");
					return;
				}
				let n = mt(o);
				if (!n) return;
				let { next: r, working: i, id: a } = ht(n.doc, n.layer, n.field), c = sn(r, n.layer.id), l = n.field === "mask" ? t : hn(c, t), u = {
					kind: "paint",
					layerId: c.id,
					field: n.field,
					working: i,
					id: a,
					stroke: Rn(),
					clip: et(n.field === "mask" ? null : c)
				};
				if (f === "clone") {
					let e = n.field === "mask" ? L.current : hn(c, L.current);
					u.clone = {
						snapshot: Qt(i),
						offset: {
							x: e.x - l.x,
							y: e.y - l.y
						}
					};
				}
				I.current = u, s(r), yt(u, l);
				return;
			}
			case "bucket":
			case "gradient": {
				if (f === "gradient") return void (I.current = {
					kind: "gradient",
					start: t
				});
				let e = mt(o);
				if (!e) return;
				let { next: n, working: r, id: i } = ht(e.doc, e.layer, e.field), a = sn(n, e.layer.id);
				Un(r, e.field === "mask" ? t : hn(a, t), Fn(m.main), v.tolerance, v.contiguous, et(e.field === "mask" ? null : a)) && (Xe(i), gt(i, r, {
					x: 0,
					y: 0,
					width: r.width,
					height: r.height
				}), B(n, "Fill"));
				return;
			}
			case "rect":
			case "ellipse":
			case "line":
				I.current = {
					kind: "shape",
					start: t,
					type: f
				};
				return;
			case "pen": {
				let e = E ?? [];
				if (e.length > 2 && Math.hypot(t.x - e[0].x, t.y - e[0].y) < 8 / w.zoom) {
					Ct(!0);
					return;
				}
				let n = [...e, {
					x: t.x,
					y: t.y
				}];
				ue(n), I.current = {
					kind: "pen",
					index: n.length - 1
				};
				return;
			}
			case "text": {
				let e = [...o.layers].reverse().find((e) => e.kind === "text" && e.visible && !e.locked && vt(e, t));
				if (e) {
					d(e.id), pe({
						id: e.id,
						fresh: !1
					});
					return;
				}
				let n = on("", {
					font: S.font,
					size: S.size,
					weight: S.weight,
					color: m.main
				}, {
					x: t.x,
					y: t.y - S.size * .6
				}), r = {
					...n,
					box: si({
						...n,
						text: " "
					})
				};
				s(cn(o, r, u ?? void 0)), d(n.id), pe({
					id: n.id,
					fresh: !0
				});
				return;
			}
			case "crop":
				fe(null), I.current = {
					kind: "crop",
					start: t
				};
				return;
			case "zoom":
				nt(e.altKey ? 1 / 1.6 : 1.6, {
					x: t.x * w.zoom + w.x,
					y: t.y * w.zoom + w.y
				});
				return;
		}
	}, vt = (e, t) => {
		let n = hn(e, t), r = gn(e, R);
		return n.x >= r.x && n.y >= r.y && n.x <= r.x + r.width && n.y <= r.y + r.height;
	}, yt = (e, t) => {
		let n;
		if (e.clone) {
			let { snapshot: r, offset: i } = e.clone;
			n = Bn(e.stroke, t, Vn(g.size), (t) => Xn(e.working, r, t, i, g, e.clip));
		} else {
			let r = e.field === "mask" ? f === "eraser" ? "hide" : "reveal" : f === "eraser" ? "erase" : "paint";
			n = Hn(e.working, e.stroke, t, {
				...g,
				color: Fn(m.main),
				mode: r
			}, e.clip);
		}
		gt(e.id, e.working, n);
	}, bt = (e) => {
		if (!o) return;
		let t = V(e);
		(f === "brush" || f === "eraser" || f === "clone") && Oe(t);
		let n = I.current;
		if (!n) E?.length && f === "pen" && ut();
		else switch (n.kind) {
			case "pan":
				oe({
					...n.view0,
					x: n.view0.x + e.clientX - n.start.x,
					y: n.view0.y + e.clientY - n.start.y
				});
				return;
			case "move": {
				let r = t.x - n.start.x, i = t.y - n.start.y;
				e.shiftKey && (Math.abs(r) > Math.abs(i) ? i = 0 : r = 0);
				let a = n.layer0.transform;
				s(q(n.doc0, n.layer0.id, { transform: {
					...a,
					x: a.x + r,
					y: a.y + i
				} }));
				return;
			}
			case "scale": {
				let r = gn(n.layer0, R), i = [
					{
						x: r.x,
						y: r.y
					},
					{
						x: r.x + r.width,
						y: r.y
					},
					{
						x: r.x + r.width,
						y: r.y + r.height
					},
					{
						x: r.x,
						y: r.y + r.height
					}
				], a = i[n.corner], o = i[(n.corner + 2) % 4], c = n.layer0.transform, l = mn(pn(fn(c)), t), u = (l.x - o.x) / (a.x - o.x || 1), d = (l.y - o.y) / (a.y - o.y || 1);
				if (e.shiftKey || n.layer0.kind === "text") {
					let e = Math.max(Math.abs(u), Math.abs(d));
					u = Math.sign(u || 1) * e, d = Math.sign(d || 1) * e;
				}
				let f = pt(c, {
					...c,
					scaleX: c.scaleX * (Math.abs(u) < .01 ? .01 : u),
					scaleY: c.scaleY * (Math.abs(d) < .01 ? .01 : d)
				}, o);
				s(q(n.doc0, n.layer0.id, { transform: f }));
				return;
			}
			case "rotate": {
				let r = gn(n.layer0, R), i = {
					x: r.x + r.width / 2,
					y: r.y + r.height / 2
				}, a = n.layer0.transform, o = mn(fn(a), i), c = a.rotation + Math.atan2(t.y - o.y, t.x - o.x) - Math.atan2(n.start.y - o.y, n.start.x - o.x);
				e.shiftKey && (c = Sn(c)), s(q(n.doc0, n.layer0.id, { transform: pt(a, {
					...a,
					rotation: c
				}, i) }));
				return;
			}
			case "marquee":
				ce({
					kind: "rect",
					rect: pi(n.start, t, e.shiftKey && n.how === "replace"),
					oval: n.oval
				});
				return;
			case "lasso":
				n.points.push(t), ce({
					kind: "lasso",
					points: [...n.points]
				});
				return;
			case "paint": {
				let e = sn(o, n.layerId);
				yt(n, n.field === "mask" ? t : hn(e, t));
				return;
			}
			case "gradient":
				ce({
					kind: "line",
					from: n.start,
					to: t
				});
				return;
			case "shape":
				if (n.type === "line") {
					let r = t;
					if (e.shiftKey) {
						let e = Sn(Math.atan2(t.y - n.start.y, t.x - n.start.x), Math.PI / 4), i = Math.hypot(t.x - n.start.x, t.y - n.start.y);
						r = {
							x: n.start.x + Math.cos(e) * i,
							y: n.start.y + Math.sin(e) * i
						};
					}
					ce({
						kind: "line",
						from: n.start,
						to: r
					});
				} else ce({
					kind: "rect",
					rect: pi(n.start, t, e.shiftKey),
					oval: n.type === "ellipse"
				});
				return;
			case "pen": {
				if (!E) return;
				let e = E[n.index], r = {
					x: t.x - e.x,
					y: t.y - e.y
				};
				if (Math.hypot(r.x, r.y) < 3 / w.zoom) return;
				let i = [...E];
				i[n.index] = {
					...e,
					out: r,
					in: {
						x: -r.x,
						y: -r.y
					}
				}, ue(i);
				return;
			}
			case "crop":
				ce({
					kind: "crop",
					rect: pi(n.start, t, e.shiftKey)
				});
				return;
		}
	}, xt = (e) => {
		let t = I.current;
		if (I.current = null, !t || !o) return;
		let n = V(e);
		switch (t.kind) {
			case "move":
			case "scale":
			case "rotate":
				o !== t.doc0 && B(o, t.kind === "move" ? "Move" : t.kind === "scale" ? "Resize" : "Turn");
				return;
			case "marquee": {
				let r = pi(t.start, n, e.shiftKey && t.how === "replace");
				if (ce(null), r.width < 2 && r.height < 2) {
					t.how === "replace" && te(null);
					return;
				}
				let i = kn(C, (t.oval ? Dn : En)(o.width, o.height, r), t.how);
				te(jn(i) ? i : null);
				return;
			}
			case "lasso": {
				if (ce(null), t.points.length < 3) return;
				let e = kn(C, On(o.width, o.height, t.points), t.how);
				te(jn(e) ? e : null);
				return;
			}
			case "paint":
				B(o, f === "eraser" ? "Erase" : f === "clone" ? "Clone" : t.field === "mask" ? "Paint mask" : "Brush");
				return;
			case "gradient": {
				if (ce(null), Math.hypot(n.x - t.start.x, n.y - t.start.y) < 2) return;
				let e = mt(o);
				if (!e) return;
				let { next: r, working: i, id: a } = ht(e.doc, e.layer, e.field), s = sn(r, e.layer.id), c = (t) => e.field === "mask" ? t : hn(s, t);
				Jn(i, c(t.start), c(n), Fn(m.main), Fn(m.second), et(e.field === "mask" ? null : s)), Xe(a), gt(a, i, {
					x: 0,
					y: 0,
					width: i.width,
					height: i.height
				}), B(r, "Gradient");
				return;
			}
			case "shape": {
				let e = T;
				ce(null);
				let n = ot();
				if (!n || !e || !(e.kind === "line" ? Math.hypot(e.to.x - e.from.x, e.to.y - e.from.y) > 2 : e.kind === "rect" && e.rect.width > 2 && e.rect.height > 2)) return;
				let r = {
					...n,
					name: t.type === "rect" ? "Rectangle" : t.type === "ellipse" ? "Ellipse" : "Line"
				};
				B(cn(o, r, u ?? void 0), `Draw ${r.name.toLowerCase()}`), d(r.id);
				return;
			}
			case "crop": {
				let r = pi(t.start, n, e.shiftKey);
				ce(null), fe(r.width > 4 && r.height > 4 ? r : null);
				return;
			}
			default: return;
		}
	}, St = (e) => {
		if (!o) return;
		let t = Ie.current.getBoundingClientRect();
		e.ctrlKey || e.metaKey ? nt(Math.exp(-e.deltaY * .01), {
			x: e.clientX - t.left,
			y: e.clientY - t.top
		}) : oe((t) => ({
			...t,
			x: t.x - e.deltaX,
			y: t.y - e.deltaY
		}));
	};
	k(() => {
		let e = Ie.current;
		if (!e) return;
		let t = (e) => e.preventDefault();
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, [o === null]);
	let Ct = (e) => {
		if (!o || !E || E.length < 2) {
			ue(null);
			return;
		}
		let t = an("Path", {
			type: "path",
			path: {
				points: E,
				closed: e
			}
		}, e ? {
			fill: b.fill,
			stroke: b.stroke,
			strokeWidth: b.strokeWidth
		} : {
			fill: null,
			stroke: b.stroke ?? m.main,
			strokeWidth: Math.max(1, b.strokeWidth)
		});
		B(cn(o, t, u ?? void 0), "Draw path"), d(t.id), ue(null);
	}, wt = async () => {
		if (!o || !de) return;
		let e = de;
		fe(null), await kt("crop", {
			x: e.x,
			y: e.y,
			width: e.width,
			height: e.height
		});
	}, H = D && o ? sn(o, D.id) : void 0, U = (e) => {
		if (!o || !H) return;
		let t = {
			...H,
			...e
		};
		s(q(o, H.id, {
			...e,
			box: si({
				...t,
				text: t.text || " "
			}),
			name: t.text.split("\n")[0].slice(0, 24) || "Text"
		}));
	}, Tt = () => {
		if (!o || !D) return;
		let e = sn(o, D.id);
		if (pe(null), Le.current?.focus({ preventScroll: !0 }), e) {
			if (e.text.trim()) B(o, D.fresh ? "Add text" : "Edit text");
			else {
				let t = ln(o, e.id);
				D.fresh ? s(Ge().history.doc) : B(t, "Delete text");
			}
		}
	}, Et = async () => {
		if (!o || !z) return;
		let e = ei(o, z, Ze), { modelFromPicture: t } = await import("./core-CfU3dd1Z.js").then((e) => e.t), n = e && t(e.rgba, e.width, e.height, {
			name: z.name,
			viewAspect: .75
		});
		n ? ye({ design: n }) : Ae("This layer has nothing solid to push out.");
	}, Dt = () => {
		let e = Ge();
		return e.selection = C, e.selectedId = u, e.colours = m, e.clipboard = ze.current, e;
	}, Ot = (e) => {
		s(e.doc), te(e.selection), d(e.selectedId), h(e.colours), ze.current = e.clipboard, Ke();
	}, kt = async (e, n = {}) => {
		let r = Dt();
		Pe(!0);
		try {
			let i = await Yr(r, e, n);
			Ot(r), Me(null), i?.file && ri(new Blob([i.file.data], { type: i.file.type }), i.file.name.replace(/^design/, t)), Ae(i?.message ?? null), (e === "new_canvas" || e === "crop" || e === "canvas_size") && setTimeout(() => tt(r.doc));
		} catch (e) {
			Ot(r), Me(e instanceof Error ? e.message : String(e));
		} finally {
			Pe(!1);
		}
	}, At = (e) => {
		let t = Dt(), n = e.blocked?.(t);
		if (n) return Ae(n);
		let r = (e.params ?? []).filter((e) => e.type === "number" || e.type === "integer");
		if (!r.length) return void kt(e.id);
		let i = r.map((e) => ({
			key: e.name,
			label: e.label,
			min: e.min ?? 0,
			max: e.max ?? 100,
			step: e.step ?? (e.type === "integer" ? 1 : .01),
			unit: e.unit,
			value: Number(typeof e.default == "function" ? e.default(t) : e.default ?? e.min ?? 0)
		})), a = 0;
		he({
			title: e.label.replace("…", ""),
			fields: i,
			preview: e.preview ? (t) => {
				clearTimeout(a), a = window.setTimeout(async () => {
					let n = Dt();
					n.dry = !0;
					try {
						await Yr(n, e.id, t), s(n.doc);
					} catch {} finally {
						n.dry = !1, n.preview = null;
					}
				}, 120);
			} : void 0,
			apply: (t) => {
				clearTimeout(a), kt(e.id, t);
			}
		});
	}, jt = async (e, t) => {
		try {
			let n = await createImageBitmap(e), r = $r(n);
			n.close(), await kt("place_image", {
				image: r,
				name: t
			}), p("move");
		} catch {
			Me("That file is not a picture this browser can open.");
		}
	};
	async function Mt() {
		let e = await ii(".gleam,application/json");
		if (e) try {
			let t = await Or(JSON.parse(await e.text()), ai);
			Be.current.clear(), Ge().replace(t.doc, t.store), Ot(Ge()), setTimeout(() => tt(t.doc));
		} catch (e) {
			Me(e instanceof Error ? e.message : "That file could not be opened.");
		}
	}
	let W = o ? [
		{
			id: "open",
			menu: "File",
			label: "Open design…",
			keys: "Ctrl O",
			help: "Opens a saved .gleam design, with all its layers.",
			dev: "fromProject in packages/canvas (the .gleam JSON), then session().replace. MCP: design_open.",
			run: () => void Mt()
		},
		{
			id: "place",
			menu: "File",
			label: "Place a picture…",
			help: "Adds a picture from your computer as a new layer.",
			dev: ui("place_image"),
			run: () => void ii("image/*").then((e) => e && jt(e, e.name.replace(/\.[^.]+$/, "")))
		},
		{
			id: "new-3d",
			menu: "File",
			label: "New 3D object…",
			help: "Builds a 3D object from shapes in 3D mode and places it on a new layer.",
			dev: "ModelMode (packages/react/src/model3d/ModelMode.tsx), then the place_model command with the picture and its design.",
			run: () => ye({})
		},
		...[
			"png",
			"jpeg",
			"svg"
		].map((e) => ({
			id: `export-${e}`,
			menu: "File",
			label: e === "svg" ? "Export SVG (shapes and text stay vectors)" : `Export ${e.toUpperCase()}`,
			help: e === "svg" ? "Saves an SVG file; shapes and text stay sharp at any size." : `Saves the picture as a ${e.toUpperCase()} file.`,
			dev: `${ui("export")} With format "${e}".`,
			run: () => void kt("export", { format: e })
		})),
		...Wr.filter((e) => e.menu && e.id !== "export" && e.id !== "place_image").map((e) => ({
			id: e.id,
			menu: e.menu,
			label: e.label,
			keys: e.keys,
			help: e.description,
			dev: ui(e.id),
			run: () => At(e),
			enabled: () => !e.blocked?.(Dt())
		})),
		{
			id: "edit-3d",
			menu: "Layer",
			label: "Edit 3D layer…",
			help: "Opens the picked 3D layer in 3D mode; when you finish, the layer is drawn again in place.",
			dev: "RasterLayer.model3d reopened in ModelMode; redraw_model gives the layer its new picture and keeps its size on the canvas.",
			enabled: () => z?.kind === "raster" && z.model3d !== void 0,
			run: () => z?.kind === "raster" && ye({
				layerId: z.id,
				design: z.model3d
			})
		},
		{
			id: "make-3d",
			menu: "Layer",
			label: "Make 3D (push out)…",
			help: "Pushes the picked layer’s shape (a logo, text, a cut-out) out into a solid in 3D mode; when you finish, it is placed as a new 3D layer.",
			dev: "layerPicture (the layer drawn alone) → modelFromPicture (scene3d: one extrude shape in its main colour) → ModelMode → place_model.",
			enabled: () => !!z && (z.kind !== "raster" || z.model3d === void 0),
			run: () => void Et()
		},
		{
			id: "mask-edit",
			menu: "Layer",
			label: "Paint on mask (on/off)",
			help: "While on, the brush and eraser paint the layer’s mask: brush shows the layer, eraser hides it.",
			dev: "maskEdit state in EditMode.tsx: strokes go to layer.mask instead of the layer pixels (packages/canvas/src/paint.ts).",
			enabled: () => !!z?.mask,
			run: () => re((e) => !e)
		},
		...[
			[
				"zoom-in",
				"Zoom in",
				"Ctrl +",
				"Shows the picture bigger.",
				() => nt(1.25)
			],
			[
				"zoom-out",
				"Zoom out",
				"Ctrl −",
				"Shows the picture smaller.",
				() => nt(.8)
			],
			[
				"fit",
				"Fit on screen",
				"Ctrl 0",
				"Shows the whole picture.",
				() => tt()
			],
			[
				"actual",
				"Actual pixels",
				"Ctrl 1",
				"Shows one picture pixel per screen pixel.",
				() => nt(1 / w.zoom)
			]
		].map(([e, t, n, r, i]) => ({
			id: e,
			menu: "View",
			label: t,
			keys: n,
			help: r,
			dev: "View only (view.zoom in EditMode.tsx); the document is not changed.",
			run: i
		}))
	] : [], Nt = () => void kt("delete_layer"), G = (e) => {
		let t = W.find((t) => t.id === e);
		t && (!t.enabled || t.enabled()) && t.run(), _e(null), Te(null);
	}, Pt = (e) => {
		e.stopPropagation();
		let t = e.target, n = t.tagName === "TEXTAREA" || t.tagName === "INPUT" && ![
			"range",
			"checkbox",
			"color"
		].includes(t.type) || t.tagName === "SELECT";
		if (e.type === "keyup") {
			e.key === " " && (Re.current = !1);
			return;
		}
		if (n) {
			e.key === "Escape" && t.blur();
			return;
		}
		let r = e.ctrlKey || e.metaKey, i = e.key.toLowerCase(), a = r ? e.shiftKey ? {
			z: "redo",
			i: "invert_selection",
			n: "add_layer",
			"]": "arrange_front",
			"[": "arrange_back",
			"}": "arrange_front",
			"{": "arrange_back"
		} : {
			z: "undo",
			y: "redo",
			x: "cut",
			c: "copy",
			v: "paste",
			a: "select_all",
			d: "deselect",
			j: "duplicate_layer",
			e: "merge_down",
			i: "invert_colours",
			s: "save_design",
			o: "open",
			"]": "arrange_forward",
			"[": "arrange_backward",
			0: "fit",
			1: "actual",
			"=": "zoom-in",
			"+": "zoom-in",
			"-": "zoom-out"
		} : {};
		if (r && i === "k") {
			e.preventDefault(), Te("");
			return;
		}
		if (r && a[i]) {
			e.preventDefault(), G(a[i]);
			return;
		}
		if (e.key === " ") {
			Re.current = !0, e.preventDefault();
			return;
		}
		if (e.key === "Escape") {
			we === null ? me ? (Ye(), he(null)) : E ? ue(null) : de ? fe(null) : C && te(null) : Te(null);
			return;
		}
		if (e.key === "Enter") {
			E ? Ct(!1) : de && wt();
			return;
		}
		if (e.key === "Delete" || e.key === "Backspace") {
			e.preventDefault(), e.altKey ? G("fill") : C && z?.kind === "raster" ? G("clear") : Nt();
			return;
		}
		if (e.key.startsWith("Arrow") && z && !z.locked && o) {
			e.preventDefault();
			let t = e.shiftKey ? 10 : 1, n = e.key === "ArrowLeft" ? -t : e.key === "ArrowRight" ? t : 0, r = e.key === "ArrowUp" ? -t : e.key === "ArrowDown" ? t : 0;
			B(q(o, z.id, { transform: {
				...z.transform,
				x: z.transform.x + n,
				y: z.transform.y + r
			} }), "Nudge");
			return;
		}
		if (e.key === "[" || e.key === "]") {
			_((t) => ({
				...t,
				size: Math.max(1, Math.min(1e3, Math.round(t.size * (e.key === "]" ? 1.2 : 1 / 1.2))))
			}));
			return;
		}
		if (i === "x") return void h((e) => ({
			main: e.second,
			second: e.main
		}));
		if (i === "d") return void h({
			main: "#1a1a1a",
			second: "#ffffff"
		});
		let s = ie.find((t) => t.key === i && !!t.shift === e.shiftKey) ?? ie.find((e) => e.key === i);
		s && K(s.id);
	}, K = (e) => {
		E && e !== "pen" && Ct(!1), e !== "crop" && fe(null), p(e), Ae(null);
	};
	k(() => {
		let e = (e) => {
			let t = [...e.clipboardData?.files ?? []].find((e) => e.type.startsWith("image/"));
			t && (e.preventDefault(), jt(t, "Pasted picture"));
		};
		return window.addEventListener("paste", e), () => window.removeEventListener("paste", e);
	}), k(() => {
		o && !me && we === null && !ge && !D && (!Le.current?.contains(document.activeElement) || document.activeElement === document.body) && Le.current?.focus({ preventScroll: !0 });
	}, [
		o === null,
		me,
		we,
		ge,
		D
	]);
	let Ft = async () => {
		if (o && n) {
			Pe(!0);
			try {
				n(await ni(Qe(o)));
			} finally {
				Pe(!1);
			}
		}
	};
	if (c) return /* @__PURE__ */ P("div", {
		className: "gs-edit gs-edit--message",
		children: [/* @__PURE__ */ N("p", { children: c }), /* @__PURE__ */ N("button", {
			type: "button",
			className: "gs-edit__btn",
			onClick: i,
			children: "Close"
		})]
	});
	if (!o) return /* @__PURE__ */ N("div", {
		className: "gs-edit gs-edit--message",
		children: "Opening…"
	});
	let It = le(f), Lt = Ge().history.list(), Rt = ne && !!z?.mask, zt = we === null ? [] : W.filter((e) => e.label.toLowerCase().includes(we.toLowerCase())).slice(0, 12), Bt = H && (() => {
		let e = H.transform, t = gn(H);
		return {
			left: w.x + (e.x + t.x * e.scaleX) * w.zoom,
			top: w.y + e.y * w.zoom,
			fontSize: H.size * w.zoom * e.scaleY,
			width: Math.max(80, (H.box.width + H.size) * w.zoom * e.scaleX),
			rotation: e.rotation
		};
	})();
	return /* @__PURE__ */ P("div", {
		className: "gs-edit",
		ref: Le,
		tabIndex: -1,
		onKeyDown: Pt,
		onKeyUp: Pt,
		children: [
			/* @__PURE__ */ P("header", {
				className: "gs-edit__top",
				children: [
					/* @__PURE__ */ N("button", {
						type: "button",
						className: "gs-edit__btn gs-edit__btn--ghost",
						onClick: i,
						title: "Leave Edit mode without keeping changes",
						children: "← Back"
					}),
					/* @__PURE__ */ N("strong", {
						className: "gs-edit__title",
						children: t
					}),
					/* @__PURE__ */ N("nav", {
						className: "gs-edit__menus",
						"aria-label": "Menus",
						children: li.map((e) => /* @__PURE__ */ P("div", {
							className: "gs-edit__menu",
							children: [/* @__PURE__ */ N("button", {
								type: "button",
								className: `gs-edit__menubtn ${ge === e ? "is-open" : ""}`,
								onClick: () => _e(ge === e ? null : e),
								onMouseEnter: () => ge && _e(e),
								children: e
							}), ge === e && /* @__PURE__ */ P("ul", {
								className: "gs-edit__dropdown",
								role: "menu",
								children: [W.filter((t) => t.menu === e).map((e) => /* @__PURE__ */ N("li", {
									onMouseEnter: () => O(e.id),
									children: /* @__PURE__ */ P("button", {
										type: "button",
										role: "menuitem",
										disabled: e.enabled ? !e.enabled() : !1,
										onClick: () => G(e.id),
										onFocus: () => O(e.id),
										children: [/* @__PURE__ */ N("span", { children: e.label }), e.keys && /* @__PURE__ */ N("kbd", { children: e.keys })]
									})
								}, e.id)), /* @__PURE__ */ N("li", {
									className: "gs-edit__menuhelp",
									role: "none",
									children: (() => {
										let t = W.find((t) => t.id === xe && t.menu === e);
										return t ? /* @__PURE__ */ P(M, { children: [t.help, /* @__PURE__ */ N(se, { text: t.dev })] }) : "Point at an item to see what it does.";
									})()
								})]
							})]
						}, e))
					}),
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-edit__search",
						onClick: () => Te(""),
						title: "Find any command (Ctrl K)",
						children: [
							/* @__PURE__ */ N(Zr, {
								name: "search",
								size: 15
							}),
							" Find a command ",
							/* @__PURE__ */ N("kbd", { children: "Ctrl K" })
						]
					}),
					/* @__PURE__ */ N("span", { className: "gs-edit__spacer" }),
					/* @__PURE__ */ N("button", {
						type: "button",
						className: "gs-edit__icon",
						onClick: qe,
						disabled: !Ge().history.canUndo,
						title: "Undo (Ctrl Z)",
						children: /* @__PURE__ */ N(Zr, { name: "undo" })
					}),
					/* @__PURE__ */ N("button", {
						type: "button",
						className: "gs-edit__icon",
						onClick: Je,
						disabled: !Ge().history.canRedo,
						title: "Redo (Ctrl Shift Z)",
						children: /* @__PURE__ */ N(Zr, { name: "redo" })
					}),
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-edit__zoom",
						onClick: () => tt(),
						title: "Fit on screen (Ctrl 0)",
						children: [Math.round(w.zoom * 100), "%"]
					}),
					n && /* @__PURE__ */ N("button", {
						type: "button",
						className: "gs-edit__btn gs-edit__btn--primary",
						onClick: () => void Ft(),
						disabled: Ne,
						children: r
					})
				]
			}),
			/* @__PURE__ */ P("div", {
				className: "gs-edit__body",
				children: [/* @__PURE__ */ P("div", {
					className: "gs-edit__stage",
					ref: Fe,
					children: [
						/* @__PURE__ */ N("canvas", {
							ref: Ie,
							className: `gs-edit__canvas gs-edit__canvas--${Re.current || f === "hand" ? "hand" : f}`,
							onPointerDown: _t,
							onPointerMove: bt,
							onPointerUp: xt,
							onPointerLeave: () => Oe(null),
							onWheel: St,
							onDoubleClick: () => f === "pen" && E && Ct(!1)
						}),
						H && Bt && /* @__PURE__ */ N("textarea", {
							className: "gs-edit__textedit",
							autoFocus: !0,
							value: H.text,
							placeholder: "Type here",
							onChange: (e) => U({ text: e.target.value }),
							onBlur: Tt,
							onKeyDown: (e) => {
								(e.key === "Escape" || e.key === "Enter" && (e.metaKey || e.ctrlKey)) && (e.preventDefault(), e.target.blur());
							},
							style: {
								left: Bt.left,
								top: Bt.top,
								width: Bt.width,
								font: pr({
									...H,
									size: Bt.fontSize
								}),
								lineHeight: H.lineHeight,
								color: H.color,
								textAlign: H.align,
								transform: `rotate(${Bt.rotation}rad)`,
								height: (H.text.split("\n").length * H.lineHeight + .4) * Bt.fontSize
							}
						}),
						je && /* @__PURE__ */ P("div", {
							className: "gs-edit__problem",
							role: "alert",
							children: [
								/* @__PURE__ */ N("strong", { children: "Could not do that." }),
								" ",
								/* @__PURE__ */ N("span", { children: je }),
								/* @__PURE__ */ N("button", {
									type: "button",
									"aria-label": "Dismiss",
									onClick: () => Me(null),
									children: "×"
								})
							]
						}),
						/* @__PURE__ */ P("div", {
							className: "gs-edit__options",
							role: "toolbar",
							"aria-label": `${It.label} options`,
							children: [
								/* @__PURE__ */ N("span", {
									className: "gs-edit__optname",
									children: Rt && (f === "brush" || f === "eraser") ? `${It.label} on mask` : It.label
								}),
								/* @__PURE__ */ N(vi, {
									tool: f,
									brush: g,
									setBrush: _,
									wand: v,
									setWand: y,
									shapeStyle: b,
									setShapeStyle: x,
									textStyle: S,
									setTextStyle: ee,
									pen: E,
									finishPen: Ct,
									cropRect: de,
									applyCrop: wt,
									cancelCrop: () => fe(null)
								}),
								/* @__PURE__ */ P("span", {
									className: "gs-edit__hint",
									children: [ke ?? It.hint, !ke && /* @__PURE__ */ N(se, { text: It.dev })]
								})
							]
						}),
						/* @__PURE__ */ P("div", {
							className: "gs-edit__dock",
							role: "toolbar",
							"aria-label": "Tools",
							children: [/* @__PURE__ */ P("div", {
								className: "gs-edit__colors",
								title: "Main and second colour (X swaps, D resets)",
								children: [
									/* @__PURE__ */ N("label", {
										className: "gs-edit__swatch gs-edit__swatch--main",
										style: { background: m.main },
										children: /* @__PURE__ */ N("input", {
											type: "color",
											"aria-label": "Main colour",
											value: m.main,
											onChange: (e) => h((t) => ({
												...t,
												main: e.target.value
											}))
										})
									}),
									/* @__PURE__ */ N("label", {
										className: "gs-edit__swatch gs-edit__swatch--second",
										style: { background: m.second },
										children: /* @__PURE__ */ N("input", {
											type: "color",
											"aria-label": "Second colour",
											value: m.second,
											onChange: (e) => h((t) => ({
												...t,
												second: e.target.value
											}))
										})
									}),
									/* @__PURE__ */ N("button", {
										type: "button",
										className: "gs-edit__swap",
										onClick: () => h((e) => ({
											main: e.second,
											second: e.main
										})),
										title: "Swap colours (X)",
										children: /* @__PURE__ */ N(Zr, {
											name: "swap",
											size: 13
										})
									})
								]
							}), ae.map((e) => /* @__PURE__ */ N("div", {
								className: "gs-edit__group",
								"aria-label": e.name,
								children: e.tools.map((e) => /* @__PURE__ */ N("button", {
									type: "button",
									className: `gs-edit__tool ${f === e.id ? "is-active" : ""}`,
									"aria-pressed": f === e.id,
									title: `${e.label} (${e.shift ? "Shift " : ""}${e.key.toUpperCase()})`,
									onClick: () => K(e.id),
									children: /* @__PURE__ */ N(Zr, { name: e.id })
								}, e.id))
							}, e.name))]
						})
					]
				}), /* @__PURE__ */ P("aside", {
					className: "gs-edit__side",
					children: [/* @__PURE__ */ P("div", {
						className: "gs-edit__tabs",
						role: "tablist",
						children: [/* @__PURE__ */ N("button", {
							type: "button",
							role: "tab",
							"aria-selected": F === "layers",
							className: F === "layers" ? "is-active" : "",
							onClick: () => Ee("layers"),
							children: "Layers"
						}), /* @__PURE__ */ N("button", {
							type: "button",
							role: "tab",
							"aria-selected": F === "history",
							className: F === "history" ? "is-active" : "",
							onClick: () => Ee("history"),
							children: "History"
						})]
					}), F === "layers" ? /* @__PURE__ */ P(M, { children: [
						/* @__PURE__ */ N(bi, {
							doc: o,
							host: Ze,
							selectedId: u,
							maskEdit: ne,
							onSelect: (e) => {
								d(e), re(!1);
							},
							onMaskSelect: (e) => {
								d(e), re(!0);
							},
							onChange: (e, t, n) => B(q(o, e, t), n),
							onReorder: (e, t) => {
								let n = o.layers.findIndex((t) => t.id === e);
								B(un(o, e, t - n), "Reorder");
							}
						}),
						/* @__PURE__ */ P("div", {
							className: "gs-edit__layerbar",
							children: [
								/* @__PURE__ */ N("button", {
									type: "button",
									className: "gs-edit__icon",
									title: "New picture layer",
									onClick: () => G("new-layer"),
									children: /* @__PURE__ */ N(Zr, { name: "plus" })
								}),
								/* @__PURE__ */ N("button", {
									type: "button",
									className: "gs-edit__icon",
									title: "Duplicate (Ctrl J)",
									disabled: !z,
									onClick: () => G("duplicate"),
									children: /* @__PURE__ */ N(Zr, { name: "copy" })
								}),
								/* @__PURE__ */ N("button", {
									type: "button",
									className: "gs-edit__icon",
									title: "Add mask",
									disabled: !z || !!z.mask,
									onClick: () => G("mask-add"),
									children: /* @__PURE__ */ N(Zr, { name: "mask" })
								}),
								/* @__PURE__ */ N("button", {
									type: "button",
									className: "gs-edit__icon",
									title: "Merge down (Ctrl E)",
									disabled: !z || o.layers.indexOf(z) === 0,
									onClick: () => G("merge"),
									children: /* @__PURE__ */ N(Zr, { name: "merge" })
								}),
								/* @__PURE__ */ N("button", {
									type: "button",
									className: "gs-edit__icon",
									title: "Delete layer",
									disabled: !z,
									onClick: Nt,
									children: /* @__PURE__ */ N(Zr, { name: "trash" })
								})
							]
						}),
						z && /* @__PURE__ */ N(Si, {
							layer: z,
							live: (e) => s(q(o, z.id, e)),
							commit: (e, t) => B(q(o, z.id, e), t),
							commitLive: (e) => B(o, e),
							measure: si
						}, z.id),
						/* @__PURE__ */ P("div", {
							className: "gs-edit__canvasprops",
							children: [
								/* @__PURE__ */ N("span", { children: "Canvas" }),
								/* @__PURE__ */ P("span", {
									className: "gs-edit__muted",
									children: [
										o.width,
										" × ",
										o.height
									]
								}),
								/* @__PURE__ */ P("label", {
									className: "gs-edit__inline",
									children: [/* @__PURE__ */ N("input", {
										type: "checkbox",
										checked: !o.background,
										onChange: (e) => B({
											...o,
											background: e.target.checked ? null : "#ffffff"
										}, "Canvas colour")
									}), "Transparent"]
								}),
								o.background && /* @__PURE__ */ N("input", {
									type: "color",
									"aria-label": "Canvas colour",
									value: o.background,
									onChange: (e) => B({
										...o,
										background: e.target.value
									}, "Canvas colour")
								})
							]
						})
					] }) : /* @__PURE__ */ N("ol", {
						className: "gs-edit__history",
						children: Lt.steps.map((e, t) => /* @__PURE__ */ N("li", { children: /* @__PURE__ */ N("button", {
							type: "button",
							className: t === Lt.at ? "is-active" : t > Lt.at ? "is-future" : "",
							onClick: () => s(Ge().history.goTo(t)),
							children: e.label
						}) }, t))
					})]
				})]
			}),
			ve && /* @__PURE__ */ N("div", {
				className: "gs-edit__model3d",
				children: /* @__PURE__ */ N(be, {
					fallback: /* @__PURE__ */ N("div", {
						className: "gs-edit--message",
						children: "Loading 3D mode…"
					}),
					children: /* @__PURE__ */ N(Qr, {
						open: ve.design,
						title: ve.layerId ? z?.name ?? "3D object" : "New 3D object",
						doneLabel: ve.layerId ? "Update the layer" : "Place in design",
						onClose: () => ye(null),
						onDone: (e, t) => {
							let n = ve.layerId;
							ye(null), (async () => {
								let r = await createImageBitmap(e), i = $r(r);
								r.close(), n ? await kt("redraw_model", {
									layer: n,
									image: i,
									model: JSON.stringify(t)
								}) : (await kt("place_model", {
									image: i,
									model: JSON.stringify(t),
									name: "3D object"
								}), p("move"));
							})();
						}
					})
				})
			}),
			me && /* @__PURE__ */ N(wi, {
				spec: me,
				onCancel: () => {
					Ye(), he(null);
				},
				onApply: (e) => {
					me.apply(e), he(null);
				}
			}),
			we !== null && /* @__PURE__ */ N("div", {
				className: "gs-edit__scrim",
				onPointerDown: () => Te(null),
				children: /* @__PURE__ */ P("div", {
					className: "gs-edit__palette",
					onPointerDown: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ N("input", {
						autoFocus: !0,
						placeholder: "What do you want to do?",
						value: we,
						onChange: (e) => Te(e.target.value),
						onKeyDown: (e) => {
							e.key === "Enter" && zt[0] && (e.preventDefault(), G(zt[0].id)), e.key === "Escape" && Te(null);
						}
					}), /* @__PURE__ */ P("ul", { children: [zt.map((e) => /* @__PURE__ */ N("li", { children: /* @__PURE__ */ P("button", {
						type: "button",
						disabled: e.enabled ? !e.enabled() : !1,
						onClick: () => G(e.id),
						children: [/* @__PURE__ */ P("span", {
							className: "gs-edit__palitem",
							children: [
								/* @__PURE__ */ P("span", { children: [
									/* @__PURE__ */ N("span", {
										className: "gs-edit__muted",
										children: e.menu
									}),
									" ",
									e.label
								] }),
								/* @__PURE__ */ N("span", {
									className: "gs-edit__palhelp",
									children: e.help
								}),
								/* @__PURE__ */ N(se, { text: e.dev })
							]
						}), e.keys && /* @__PURE__ */ N("kbd", { children: e.keys })]
					}) }, e.id)), !zt.length && /* @__PURE__ */ N("li", {
						className: "gs-edit__muted",
						children: "Nothing matches."
					})] })]
				})
			})
		]
	});
}
function gi({ label: e, value: t, min: n, max: r, step: i, unit: a, onChange: o }) {
	return /* @__PURE__ */ P("label", {
		className: "gs-edit__slider",
		children: [
			/* @__PURE__ */ N("span", { children: e }),
			/* @__PURE__ */ N("input", {
				type: "range",
				min: n,
				max: r,
				step: i,
				value: t,
				onChange: (e) => o(Number(e.target.value))
			}),
			/* @__PURE__ */ P("output", { children: [Math.round(t * 100) / 100, a] })
		]
	});
}
function _i({ label: e, value: t, onChange: n }) {
	return /* @__PURE__ */ P("span", {
		className: "gs-edit__colorpick",
		children: [
			/* @__PURE__ */ N("span", { children: e }),
			/* @__PURE__ */ N("input", {
				type: "checkbox",
				"aria-label": `${e} on`,
				checked: t !== null,
				onChange: (e) => n(e.target.checked ? "#1a1a1a" : null)
			}),
			t !== null && /* @__PURE__ */ N("input", {
				type: "color",
				"aria-label": e,
				value: t,
				onChange: (e) => n(e.target.value)
			})
		]
	});
}
function vi(e) {
	switch (e.tool) {
		case "brush":
		case "eraser":
		case "clone": return /* @__PURE__ */ P(M, { children: [
			/* @__PURE__ */ N(gi, {
				label: "Size",
				min: 1,
				max: 500,
				step: 1,
				unit: "px",
				value: e.brush.size,
				onChange: (t) => e.setBrush((e) => ({
					...e,
					size: t
				}))
			}),
			/* @__PURE__ */ N(gi, {
				label: "Hardness",
				min: 0,
				max: 1,
				step: .01,
				value: e.brush.hardness,
				onChange: (t) => e.setBrush((e) => ({
					...e,
					hardness: t
				}))
			}),
			/* @__PURE__ */ N(gi, {
				label: "Flow",
				min: .02,
				max: 1,
				step: .01,
				value: e.brush.flow,
				onChange: (t) => e.setBrush((e) => ({
					...e,
					flow: t
				}))
			})
		] });
		case "wand":
		case "bucket": return /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N(gi, {
			label: "Tolerance",
			min: 0,
			max: 255,
			step: 1,
			value: e.wand.tolerance,
			onChange: (t) => e.setWand((e) => ({
				...e,
				tolerance: t
			}))
		}), /* @__PURE__ */ P("label", {
			className: "gs-edit__inline",
			children: [/* @__PURE__ */ N("input", {
				type: "checkbox",
				checked: e.wand.contiguous,
				onChange: (t) => e.setWand((e) => ({
					...e,
					contiguous: t.target.checked
				}))
			}), "Only touching pixels"]
		})] });
		case "rect":
		case "ellipse":
		case "line":
		case "pen": return /* @__PURE__ */ P(M, { children: [
			e.tool !== "line" && /* @__PURE__ */ N(_i, {
				label: "Fill",
				value: e.shapeStyle.fill,
				onChange: (t) => e.setShapeStyle((e) => ({
					...e,
					fill: t
				}))
			}),
			/* @__PURE__ */ N(_i, {
				label: "Outline",
				value: e.shapeStyle.stroke,
				onChange: (t) => e.setShapeStyle((e) => ({
					...e,
					stroke: t
				}))
			}),
			/* @__PURE__ */ N(gi, {
				label: "Width",
				min: 0,
				max: 100,
				step: 1,
				unit: "px",
				value: e.shapeStyle.strokeWidth,
				onChange: (t) => e.setShapeStyle((e) => ({
					...e,
					strokeWidth: t
				}))
			}),
			e.tool === "rect" && /* @__PURE__ */ N(gi, {
				label: "Corners",
				min: 0,
				max: 300,
				step: 1,
				unit: "px",
				value: e.shapeStyle.radius,
				onChange: (t) => e.setShapeStyle((e) => ({
					...e,
					radius: t
				}))
			}),
			e.tool === "pen" && e.pen && e.pen.length > 1 && /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N("button", {
				type: "button",
				className: "gs-edit__btn",
				onClick: () => e.finishPen(!1),
				children: "Finish open"
			}), /* @__PURE__ */ N("button", {
				type: "button",
				className: "gs-edit__btn",
				onClick: () => e.finishPen(!0),
				children: "Close shape"
			})] })
		] });
		case "text": return /* @__PURE__ */ P(M, { children: [
			/* @__PURE__ */ N("select", {
				"aria-label": "Font",
				value: e.textStyle.font,
				onChange: (t) => e.setTextStyle((e) => ({
					...e,
					font: t.target.value
				})),
				children: ci.map((e) => /* @__PURE__ */ N("option", {
					value: e,
					children: e.split(",")[0].replace(/"/g, "")
				}, e))
			}),
			/* @__PURE__ */ N(gi, {
				label: "Size",
				min: 8,
				max: 400,
				step: 1,
				unit: "px",
				value: e.textStyle.size,
				onChange: (t) => e.setTextStyle((e) => ({
					...e,
					size: t
				}))
			}),
			/* @__PURE__ */ P("select", {
				"aria-label": "Weight",
				value: e.textStyle.weight,
				onChange: (t) => e.setTextStyle((e) => ({
					...e,
					weight: Number(t.target.value)
				})),
				children: [
					/* @__PURE__ */ N("option", {
						value: 400,
						children: "Regular"
					}),
					/* @__PURE__ */ N("option", {
						value: 700,
						children: "Bold"
					}),
					/* @__PURE__ */ N("option", {
						value: 900,
						children: "Heavy"
					})
				]
			})
		] });
		case "crop": return e.cropRect ? /* @__PURE__ */ P(M, { children: [
			/* @__PURE__ */ P("span", {
				className: "gs-edit__muted",
				children: [
					Math.round(e.cropRect.width),
					" × ",
					Math.round(e.cropRect.height)
				]
			}),
			/* @__PURE__ */ N("button", {
				type: "button",
				className: "gs-edit__btn gs-edit__btn--primary",
				onClick: e.applyCrop,
				children: "Crop"
			}),
			/* @__PURE__ */ N("button", {
				type: "button",
				className: "gs-edit__btn",
				onClick: e.cancelCrop,
				children: "Cancel"
			})
		] }) : null;
		default: return null;
	}
}
function yi({ doc: e, layer: t, host: n, mask: r }) {
	let i = A(null);
	return k(() => {
		let a = i.current;
		if (!a) return;
		let o = Math.min(44 / e.width, 44 / e.height);
		a.width = Math.max(1, Math.round(e.width * o)), a.height = Math.max(1, Math.round(e.height * o));
		let s = a.getContext("2d");
		if (s.clearRect(0, 0, a.width, a.height), s.save(), s.scale(o, o), r && t.mask) {
			s.fillStyle = "#000", s.fillRect(0, 0, e.width, e.height);
			let r = n.image(t.mask);
			if (r) {
				let t = n.surface(e.width, e.height);
				t.ctx.fillStyle = "#fff", t.ctx.fillRect(0, 0, e.width, e.height), t.ctx.globalCompositeOperation = "destination-in", t.ctx.drawImage(r, 0, 0), s.drawImage(t.canvas, 0, 0);
			}
		} else br(s, e, {
			...t,
			opacity: 1,
			blend: "normal",
			mask: void 0,
			maskOff: !0
		}, n);
		s.restore();
	}), /* @__PURE__ */ N("canvas", {
		ref: i,
		className: "gs-edit__thumb"
	});
}
function bi({ doc: e, host: t, selectedId: n, maskEdit: r, onSelect: i, onMaskSelect: a, onChange: o, onReorder: s }) {
	let [c, l] = j(null), [u, d] = j(null);
	return e.layers.length ? /* @__PURE__ */ N("ul", {
		className: "gs-edit__layers",
		children: [...e.layers].reverse().map((f) => {
			let p = e.layers.indexOf(f);
			return /* @__PURE__ */ P("li", {
				className: `gs-edit__layer ${f.id === n ? "is-active" : ""} ${f.visible ? "" : "is-hidden"} ${u === f.id ? "is-dragging" : ""}`,
				draggable: c !== f.id,
				onDragStart: (e) => {
					d(f.id), e.dataTransfer.effectAllowed = "move";
				},
				onDragEnd: () => d(null),
				onDragOver: (e) => e.preventDefault(),
				onDrop: (e) => {
					e.preventDefault(), u && u !== f.id && s(u, p), d(null);
				},
				onClick: () => i(f.id),
				children: [
					/* @__PURE__ */ N("button", {
						type: "button",
						className: "gs-edit__icon gs-edit__icon--sm",
						title: f.visible ? "Hide" : "Show",
						onClick: (e) => (e.stopPropagation(), o(f.id, { visible: !f.visible }, f.visible ? "Hide layer" : "Show layer")),
						children: /* @__PURE__ */ N(Zr, {
							name: f.visible ? "eye" : "eyeOff",
							size: 16
						})
					}),
					/* @__PURE__ */ N("span", {
						className: `gs-edit__thumbwrap ${f.id === n && !r ? "is-target" : ""}`,
						children: /* @__PURE__ */ N(yi, {
							doc: e,
							layer: f,
							host: t
						})
					}),
					f.mask && /* @__PURE__ */ N("span", {
						className: `gs-edit__thumbwrap ${f.id === n && r ? "is-target" : ""} ${f.maskOff ? "is-off" : ""}`,
						title: "Mask: click to paint on it",
						onClick: (e) => (e.stopPropagation(), a(f.id)),
						children: /* @__PURE__ */ N(yi, {
							doc: e,
							layer: f,
							host: t,
							mask: !0
						})
					}),
					c === f.id ? /* @__PURE__ */ N("input", {
						className: "gs-edit__rename",
						autoFocus: !0,
						defaultValue: f.name,
						onClick: (e) => e.stopPropagation(),
						onBlur: (e) => {
							l(null), e.target.value.trim() && e.target.value !== f.name && o(f.id, { name: e.target.value.trim() }, "Rename");
						},
						onKeyDown: (e) => {
							e.key === "Enter" && e.target.blur(), e.key === "Escape" && l(null);
						}
					}) : /* @__PURE__ */ P("span", {
						className: "gs-edit__layername",
						onDoubleClick: () => l(f.id),
						title: "Double-click to rename",
						children: [f.name, /* @__PURE__ */ N("small", { children: f.kind === "raster" ? "picture" : f.kind === "text" ? "text" : f.shape.type === "path" ? "path" : "shape" })]
					}),
					/* @__PURE__ */ N("button", {
						type: "button",
						className: `gs-edit__icon gs-edit__icon--sm ${f.locked ? "is-on" : ""}`,
						title: f.locked ? "Unlock" : "Lock",
						onClick: (e) => (e.stopPropagation(), o(f.id, { locked: !f.locked }, f.locked ? "Unlock" : "Lock")),
						children: /* @__PURE__ */ N(Zr, {
							name: f.locked ? "lock" : "unlock",
							size: 15
						})
					})
				]
			}, f.id);
		})
	}) : /* @__PURE__ */ N("p", {
		className: "gs-edit__empty",
		children: "No layers yet. Draw, type, paint, or place a picture."
	});
}
var xi = (e) => Math.round(e * 180 / Math.PI * 10) / 10;
function Si({ layer: e, live: t, commit: n, commitLive: r, measure: i }) {
	let a = e.transform, o = (e, t, r, i = "") => /* @__PURE__ */ P("label", {
		className: "gs-edit__num",
		children: [
			/* @__PURE__ */ N("span", { children: e }),
			/* @__PURE__ */ N("input", {
				type: "number",
				value: Math.round(t * 10) / 10,
				onChange: (t) => {
					let i = Number(t.target.value);
					Number.isFinite(i) && n(r(i), `Set ${e.toLowerCase()}`);
				}
			}),
			i && /* @__PURE__ */ N("em", { children: i })
		]
	}), s = (t, r) => {
		let a = {
			...e,
			...t
		};
		n({
			...t,
			box: i({
				...a,
				text: a.text || " "
			})
		}, r);
	};
	return /* @__PURE__ */ P("section", {
		className: "gs-edit__props",
		children: [
			/* @__PURE__ */ P("label", {
				className: "gs-edit__slider",
				children: [
					/* @__PURE__ */ N("span", { children: "Opacity" }),
					/* @__PURE__ */ N("input", {
						type: "range",
						min: 0,
						max: 1,
						step: .01,
						value: e.opacity,
						onChange: (e) => t({ opacity: Number(e.target.value) }),
						onPointerUp: () => r("Opacity"),
						onKeyUp: () => r("Opacity")
					}),
					/* @__PURE__ */ P("output", { children: [Math.round(e.opacity * 100), "%"] })
				]
			}),
			/* @__PURE__ */ P("label", {
				className: "gs-edit__field",
				children: [/* @__PURE__ */ N("span", { children: "Mix" }), /* @__PURE__ */ N("select", {
					value: e.blend,
					onChange: (e) => n({ blend: e.target.value }, "Blend mode"),
					children: qt.map((e) => /* @__PURE__ */ N("option", {
						value: e.id,
						children: e.label
					}, e.id))
				})]
			}),
			/* @__PURE__ */ P("div", {
				className: "gs-edit__grid",
				children: [
					o("X", a.x, (e) => ({ transform: {
						...a,
						x: e
					} })),
					o("Y", a.y, (e) => ({ transform: {
						...a,
						y: e
					} })),
					o("Width", a.scaleX * 100, (e) => ({ transform: {
						...a,
						scaleX: e / 100 || .01
					} }), "%"),
					o("Height", a.scaleY * 100, (e) => ({ transform: {
						...a,
						scaleY: e / 100 || .01
					} }), "%"),
					o("Turn", xi(a.rotation), (e) => ({ transform: {
						...a,
						rotation: e * Math.PI / 180
					} }), "°")
				]
			}),
			e.kind === "shape" && /* @__PURE__ */ N(Ci, {
				layer: e,
				commit: n
			}),
			e.kind === "text" && /* @__PURE__ */ P(M, { children: [/* @__PURE__ */ N("textarea", {
				className: "gs-edit__textprop",
				value: e.text,
				onChange: (e) => s({
					text: e.target.value,
					name: e.target.value.split("\n")[0].slice(0, 24) || "Text"
				}, "Edit text"),
				rows: 2
			}), /* @__PURE__ */ P("div", {
				className: "gs-edit__grid",
				children: [
					/* @__PURE__ */ P("label", {
						className: "gs-edit__field gs-edit__field--wide",
						children: [/* @__PURE__ */ N("span", { children: "Font" }), /* @__PURE__ */ N("select", {
							value: e.font,
							onChange: (e) => s({ font: e.target.value }, "Font"),
							children: ci.map((e) => /* @__PURE__ */ N("option", {
								value: e,
								children: e.split(",")[0].replace(/"/g, "")
							}, e))
						})]
					}),
					o("Size", e.size, (t) => ({
						size: Math.max(1, t),
						box: i({
							...e,
							size: Math.max(1, t)
						})
					}), "px"),
					/* @__PURE__ */ P("label", {
						className: "gs-edit__field",
						children: [/* @__PURE__ */ N("span", { children: "Weight" }), /* @__PURE__ */ P("select", {
							value: e.weight,
							onChange: (e) => s({ weight: Number(e.target.value) }, "Weight"),
							children: [
								/* @__PURE__ */ N("option", {
									value: 400,
									children: "Regular"
								}),
								/* @__PURE__ */ N("option", {
									value: 700,
									children: "Bold"
								}),
								/* @__PURE__ */ N("option", {
									value: 900,
									children: "Heavy"
								})
							]
						})]
					}),
					/* @__PURE__ */ P("label", {
						className: "gs-edit__field",
						children: [/* @__PURE__ */ N("span", { children: "Colour" }), /* @__PURE__ */ N("input", {
							type: "color",
							value: e.color,
							onChange: (e) => n({ color: e.target.value }, "Text colour")
						})]
					}),
					/* @__PURE__ */ P("label", {
						className: "gs-edit__field",
						children: [/* @__PURE__ */ N("span", { children: "Align" }), /* @__PURE__ */ P("select", {
							value: e.align,
							onChange: (e) => s({ align: e.target.value }, "Align"),
							children: [
								/* @__PURE__ */ N("option", {
									value: "left",
									children: "Left"
								}),
								/* @__PURE__ */ N("option", {
									value: "center",
									children: "Centre"
								}),
								/* @__PURE__ */ N("option", {
									value: "right",
									children: "Right"
								})
							]
						})]
					}),
					/* @__PURE__ */ P("label", {
						className: "gs-edit__inline",
						children: [/* @__PURE__ */ N("input", {
							type: "checkbox",
							checked: e.italic,
							onChange: (e) => s({ italic: e.target.checked }, "Italic")
						}), "Italic"]
					})
				]
			})] })
		]
	});
}
function Ci({ layer: e, commit: t }) {
	return /* @__PURE__ */ P("div", {
		className: "gs-edit__grid",
		children: [
			e.shape.type !== "line" && /* @__PURE__ */ N(_i, {
				label: "Fill",
				value: e.fill,
				onChange: (e) => t({ fill: e }, "Fill colour")
			}),
			/* @__PURE__ */ N(_i, {
				label: "Outline",
				value: e.stroke,
				onChange: (e) => t({ stroke: e }, "Outline colour")
			}),
			/* @__PURE__ */ P("label", {
				className: "gs-edit__num",
				children: [
					/* @__PURE__ */ N("span", { children: "Outline" }),
					/* @__PURE__ */ N("input", {
						type: "number",
						min: 0,
						value: e.strokeWidth,
						onChange: (e) => t({ strokeWidth: Math.max(0, Number(e.target.value) || 0) }, "Outline width")
					}),
					/* @__PURE__ */ N("em", { children: "px" })
				]
			}),
			e.shape.type === "rect" && /* @__PURE__ */ P("label", {
				className: "gs-edit__num",
				children: [
					/* @__PURE__ */ N("span", { children: "Corners" }),
					/* @__PURE__ */ N("input", {
						type: "number",
						min: 0,
						value: e.shape.radius,
						onChange: (n) => t({ shape: {
							...e.shape,
							radius: Math.max(0, Number(n.target.value) || 0)
						} }, "Corners")
					}),
					/* @__PURE__ */ N("em", { children: "px" })
				]
			})
		]
	});
}
function wi({ spec: e, onCancel: t, onApply: n }) {
	let [r, i] = j(() => Object.fromEntries(e.fields.map((e) => [e.key, e.value]))), a = (t, n) => {
		let a = {
			...r,
			[t]: n
		};
		i(a), e.preview?.(a);
	};
	return /* @__PURE__ */ N("div", {
		className: "gs-edit__scrim",
		children: /* @__PURE__ */ P("form", {
			className: "gs-edit__dialog",
			onSubmit: (e) => {
				e.preventDefault(), n(r);
			},
			children: [
				/* @__PURE__ */ N("h3", { children: e.title }),
				e.fields.map((e) => e.max - e.min > 1e3 ? /* @__PURE__ */ P("label", {
					className: "gs-edit__num gs-edit__num--wide",
					children: [
						/* @__PURE__ */ N("span", { children: e.label }),
						/* @__PURE__ */ N("input", {
							type: "number",
							min: e.min,
							max: e.max,
							step: e.step,
							value: r[e.key],
							onChange: (t) => a(e.key, Math.min(e.max, Math.max(e.min, Number(t.target.value) || e.min)))
						}),
						e.unit && /* @__PURE__ */ N("em", { children: e.unit })
					]
				}, e.key) : /* @__PURE__ */ N(gi, {
					label: e.label,
					min: e.min,
					max: e.max,
					step: e.step,
					unit: e.unit,
					value: r[e.key],
					onChange: (t) => a(e.key, t)
				}, e.key)),
				/* @__PURE__ */ P("div", {
					className: "gs-edit__dialogbar",
					children: [/* @__PURE__ */ N("button", {
						type: "button",
						className: "gs-edit__btn",
						onClick: t,
						children: "Cancel"
					}), /* @__PURE__ */ N("button", {
						type: "submit",
						className: "gs-edit__btn gs-edit__btn--primary",
						autoFocus: !0,
						children: "Apply"
					})]
				})
			]
		})
	});
}
//#endregion
//#region src/GleamEditor.tsx
var Ti = xe(() => import("./PhotoLab-BfLodg_q.js").then((e) => e.n).then((e) => ({ default: e.PhotoLab }))), Ei = (e) => e.ops.backdrop?.mode, Di = {
	maxSize: 2048,
	type: "image/webp",
	quality: .88
}, Oi = 32, ki = "the same photograph, the surface continued smoothly with the same material, colour and lighting as right around it, nothing new added, sharp focus", Ai = "text, letters, words, logo, writing, new objects, pom pom, ball, flower, jewelry, pattern, stain, blotch, blurry, smudge", ji = (e) => Array.from({ length: Math.floor((e?.length ?? 0) / 4) }, (t, n) => ({
	x: e[n * 4],
	y: e[n * 4 + 1],
	width: e[n * 4 + 2],
	height: e[n * 4 + 3]
})), Mi = [
	{
		key: "stickers",
		label: "Remove price stickers",
		title: "Reads the prices on the photo and paints the shop's price stickers out, so the photo stays right when the price changes."
	},
	{
		key: "lettering",
		label: "Repaint lettering and printed text",
		title: "For a character on a cover: paints the title and printed text out from the rest of the picture before the character is cut out. Does nothing for a whole box."
	},
	{
		key: "find",
		label: "Look the product up on the web (free; sends search words, not the photo)",
		title: "Reads the cover with a local model, searches the web (DuckDuckGo) with those words and uses the official pictures it finds. Free. The search words leave this computer; your photo never does."
	},
	{
		key: "thinParts",
		label: "Complete what the box hides, from official pictures",
		title: "Looks again along the character's outline for thin or detached parts (an antenna), and, when an official photo of this figure is found and lines up with the cover, finishes the parts the box's printing hides (a title band over the tail) from it, in this photo's colours. Those parts are flagged for you to check."
	},
	{
		key: "colour",
		label: "Match colours to the official picture",
		title: "Brings the box's colours to the product's own published picture. Needs the web lookup to find it.",
		needs: "find"
	},
	{
		key: "vivid",
		label: "Punchier colours",
		title: "After colours are matched to an official picture, make them 40% stronger: the punchy look of a ChatGPT redraw. Off keeps the published, softer colours.",
		needs: "colour"
	},
	{
		key: "look",
		label: "Brighten and sharpen",
		title: "The colour and sharpness look applied at the end."
	},
	{
		key: "gloss",
		label: "Studio gloss (changes the product; off unless ticked)",
		title: "Redraws the product as a glossy studio pack shot with Stable Diffusion, free, on this computer, about a minute. It changes the product itself: finish, small details and printed text may no longer match the real item, so the result is flagged for review. Needs npm run redraw:setup.",
		optIn: !0
	},
	{
		key: "enlarge",
		label: "Enlarge",
		title: "Makes the picture bigger with a local model. Printed text is enlarged the plain way, so the model cannot rewrite it; everything else gets its extra detail."
	},
	{
		key: "listing",
		label: "Write a title and description",
		title: "Writes a title and description with a local model, only from what was found. Needs the web lookup and the vision model (npm run vlm:setup).",
		needs: "find"
	}
];
function Ni({ source: e, name: t, recipe: n, background: r, masks: i, repairs: a, enlargements: o, finishes: s, localApp: l, exportOptions: u, onDone: d, onCancel: f, doneLabel: p = "Done" }) {
	let [m, h] = j(null), [g, _] = j(null), [v, y] = j(e), [x, S] = j(null), [ee, C] = j(null);
	k(() => {
		y(e), S(null), C(null);
	}, [e]);
	let te = A(n);
	return k(() => {
		let n = new AbortController(), r = null;
		return h(null), _(null), (async () => {
			try {
				let i = typeof v == "string" ? await ge(v, n.signal) : v;
				if (r = await me(i), n.signal.aborted) return;
				let a = t ?? (e instanceof File ? e.name : typeof e == "string" ? e.split("/").pop()?.split("?")[0] : void 0), o = c({
					width: r.width,
					height: r.height,
					name: a
				}, te.current);
				h({
					image: r,
					editor: new b(o),
					blob: i
				});
			} catch (e) {
				n.signal.aborted || _(e instanceof Error ? e.message : "This photo couldn't be opened.");
			}
		})(), () => {
			n.abort(), r?.close();
		};
	}, [v, t]), g ? /* @__PURE__ */ P("div", {
		className: "gs-editor gs-editor--message",
		children: [/* @__PURE__ */ N("p", {
			className: "gs-error",
			children: g
		}), f && /* @__PURE__ */ N("button", {
			type: "button",
			className: "gs-button",
			onClick: f,
			children: "Close"
		})]
	}) : m ? /* @__PURE__ */ N(Pi, {
		editor: m.editor,
		image: m.image,
		initialBackground: r,
		initialMasks: i,
		initialRepairs: a,
		initialEnlargements: o,
		initialFinishes: s,
		localApp: l,
		sourceBlob: x ? null : m.blob,
		startFrom: x,
		fullReport: ee,
		onOpenProcessed: async (e, t, n) => {
			let r = await createImageBitmap(e, { premultiplyAlpha: "none" }), i = document.createElement("canvas");
			i.width = r.width, i.height = r.height;
			let a = i.getContext("2d", { willReadFrequently: !0 });
			a.drawImage(r, 0, 0);
			let o = a.getImageData(0, 0, i.width, i.height).data, s = new Uint8Array(i.width * i.height);
			for (let e = 0; e < s.length; e++) s[e] = o[e * 4 + 3];
			a.globalCompositeOperation = "destination-over", a.fillStyle = "#ffffff", a.fillRect(0, 0, i.width, i.height);
			let c = await new Promise((e, t) => i.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png")), l = {
				alpha: s,
				width: i.width,
				height: i.height
			};
			r.close(), S({
				mask: l,
				shadow: t
			}), C(n), y(c);
		},
		onBackToOriginal: x ? () => (S(null), C(null), y(e)) : void 0,
		onEdited: (e) => {
			te.current = void 0, S(null), C(null), y(e);
		},
		exportOptions: {
			...Di,
			...u
		},
		onDone: d,
		onCancel: f,
		doneLabel: p
	}) : /* @__PURE__ */ N("div", {
		className: "gs-editor gs-editor--message",
		children: "Opening photo…"
	});
}
function Pi({ editor: t, image: c, initialBackground: p, initialMasks: m, initialRepairs: h, initialEnlargements: v, initialFinishes: b, localApp: x, sourceBlob: ee, startFrom: C, fullReport: re, onOpenProcessed: ie, onBackToOriginal: ae, onEdited: w, exportOptions: oe, onDone: se, onCancel: T, doneLabel: le }) {
	let ue = we(t.subscribe, t.getSnapshot), { doc: D } = ue, pe = A(null), ye = A(null), xe = A(null), [O, Se] = j(null), [M, Te] = j({
		width: 0,
		height: 0
	}), [F, Ee] = j(!1), [De, ke] = j(!1), [Ae, je] = j(!1), [Ne, Pe] = j(!1), [Fe, Ie] = j({
		tool: "tap",
		brush: .02,
		tolerance: 25
	}), [Le, I] = j(!1), [Re, L] = j(null), [ze, Be] = j(null), [R, Ke] = j(null), [B, qe] = j(() => /* @__PURE__ */ new Map()), Xe = D.recipe.finish, Qe = Xe ? B.get(Xe.ref)?.bitmap : void 0, et = Ce(() => Qe ? te({
		width: Qe.width,
		height: Qe.height
	}) : null, [Qe]), tt = () => {
		Ae || t.clearFinish(), Pe(!1), je((e) => !e);
	}, nt = () => {
		Ne || t.clearFinish(), je(!1), Pe((e) => !e);
	}, V = Ce(() => {
		let { width: e, height: t } = r(c.width, c.height), n = document.createElement("canvas");
		n.width = e, n.height = t;
		let i = n.getContext("2d", { willReadFrequently: !0 });
		return i.drawImage(c, 0, 0, e, t), {
			pixels: i.getImageData(0, 0, e, t).data,
			width: e,
			height: t
		};
	}, [c]);
	k(() => {
		try {
			let e = new ut(xe.current);
			return e.setSource(c), Se(e), () => e.dispose();
		} catch (e) {
			L(e instanceof Error ? e.message : "The preview could not start.");
		}
	}, [c]), k(() => {
		let e = new ResizeObserver(([e]) => {
			let { width: t, height: n } = e.contentRect;
			Te({
				width: t,
				height: n
			});
		});
		return e.observe(ye.current), pe.current?.focus({ preventScroll: !0 }), () => e.disconnect();
	}, []);
	let it = Ce(() => F ? te(D.source) : et ?? (Ae ? f(D) : D), [
		F,
		Ae,
		D,
		et
	]), at = u(it), ot = u(et ?? D, oe.maxSize), st = Math.min((M.width - Oi) / at.width, (M.height - Oi) / at.height, 1), ct = Math.max(1, Math.floor(at.width * st)), lt = Math.max(1, Math.floor(at.height * st)), dt = D.recipe.mask, ft = Ce(() => a(V.pixels, V.width, V.height) > .5, [V]), [mt, gt] = j(() => /* @__PURE__ */ new Map()), _t = A(/* @__PURE__ */ new Map()), vt = (e, t) => {
		_t.current.set(e, t), gt((n) => new Map(n).set(e, t));
	}, yt = () => {
		let e = t.document.recipe.mask;
		return e.length ? _(V.pixels, V.width, V.height, e, _t.current) : null;
	}, bt = Ce(() => dt.length ? _(V.pixels, V.width, V.height, dt, mt) : null, [
		dt,
		V,
		mt
	]), xt = i(dt, mt).length;
	k(() => {
		if (!m) return;
		let e = !1;
		return (async () => {
			for (let [t, n] of Object.entries(m)) try {
				let r = typeof n == "string" ? await ge(n) : n, i = await ve(r);
				e || vt(t, i);
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [m]);
	let St = (e, n, r, i = !0) => {
		let a = r === "character" ? d(t.document, n.partsKept ? n : s(n)) : n, o = Array.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(6)), (e) => e.toString(16).padStart(2, "0")).join("");
		vt(o, a), t.addModelCutout(e, o, { replace: r === "character" }), i && Ot();
	};
	k(() => {
		O && (F || !bt || Qe ? O.setMask(null) : O.setMask(bt, V.width, V.height, { despill: o(dt) }));
	}, [
		O,
		bt,
		dt,
		F,
		V,
		Qe
	]);
	let Ct = async (e, t) => {
		let n = await me(e, Math.min(4096, O?.maxTextureSize ?? 4096));
		Ke((r) => (r?.bitmap.close(), {
			bitmap: n,
			blob: e,
			name: t
		}));
	}, wt = (e) => {
		L(null), Ct(e, e.name).then(() => t.set("recipe/ops/backdrop/mode", "image", "Backdrop: Photo"), (e) => L(e instanceof Error ? e.message : "That background photo couldn't be opened."));
	};
	k(() => {
		if (!p) return;
		let e = !1;
		return (async () => {
			try {
				let t = typeof p == "string" ? await ge(p) : p;
				e || await Ct(t, t instanceof File ? t.name : void 0);
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [p, O]), k(() => {
		O?.setBackground(R?.bitmap ?? null);
	}, [O, R]), k(() => () => R?.bitmap.close(), [R]);
	let H = D.recipe.words, U = zt(x), [Tt, Et] = j(() => {
		try {
			return localStorage.getItem("gleamshelf:auto-enhance") !== "off";
		} catch {
			return !0;
		}
	}), Dt = (e) => {
		Et(e);
		try {
			localStorage.setItem("gleamshelf:auto-enhance", e ? "on" : "off");
		} catch {}
	}, Ot = () => {
		let e = t.document.recipe, n = e.ops.light?.exposure === 0 && e.ops.color?.vibrance === 0 && !e.effects.some((e) => e.id === "sharpen");
		Tt && n && t.applyLook("bright-sharp");
	}, [kt, At] = j(!1), [jt, Mt] = j(() => /* @__PURE__ */ new Map()), W = A(/* @__PURE__ */ new Map()), Nt = (e, t) => {
		W.current.set(e, t), Mt((n) => new Map(n).set(e, t));
	}, [G, Pt] = j(null), [K, Ft] = j(!1);
	k(() => {
		if (!h) return;
		let e = !1;
		return (async () => {
			for (let [t, n] of Object.entries(h)) try {
				let r = typeof n == "string" ? await ge(n) : n, i = await createImageBitmap(r);
				e || Nt(t, {
					bitmap: i,
					blob: r
				});
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [h]);
	let It = (e = c) => {
		let t = Math.min(1, 2048 / Math.max(e.width, e.height)), n = Math.max(1, Math.round(e.width * t)), r = Math.max(1, Math.round(e.height * t)), i = document.createElement("canvas");
		i.width = n, i.height = r;
		let a = i.getContext("2d", { willReadFrequently: !0 });
		a.drawImage(e, 0, 0, n, r);
		let o = a.getImageData(0, 0, n, r), s = yt(), l = new Uint8Array(n * r).fill(+!s);
		if (s) for (let e = 0; e < r; e++) {
			let t = Math.min(V.height - 1, Math.floor(e / r * V.height));
			for (let r = 0; r < n; r++) l[e * n + r] = +(s[t * V.width + Math.min(V.width - 1, Math.floor(r / n * V.width))] > 140);
		}
		return {
			w: n,
			h: r,
			pixels: o,
			inside: l
		};
	}, Lt = () => U.state === "ready" ? U.installed("inpaint")[0] ?? U.installed("redraw")[0] : void 0, Rt = (e, t) => e.task === "redraw" ? U.client.redraw(t.picture, {
		prompt: ki,
		negative: Ai,
		strength: .99,
		steps: 24,
		guidance: 5,
		candidates: 3,
		seed: 5,
		stacked: !!t.region
	}) : U.client.inpaint(t.picture, e.id), Bt = async (e, t, n = c) => {
		let r = document.createElement("canvas");
		r.width = t.fullWidth, r.height = t.fullHeight;
		let i = r.getContext("2d");
		i.drawImage(n, 0, 0, t.fullWidth, t.fullHeight);
		let a = await createImageBitmap(e);
		return i.drawImage(a, t.x, t.y), a.close(), new Promise((e, t) => r.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be saved.")), "image/png"));
	}, qt = () => {
		let e = t.document.recipe.words?.ai;
		return e && W.current.get(e.ref)?.bitmap || c;
	}, Jt = H?.ai ? jt.get(H.ai.ref)?.bitmap : void 0;
	k(() => {
		if (!H) {
			Pt((e) => e && (e.owned && e.bitmap.close(), null));
			return;
		}
		if (Jt) {
			Pt((e) => (e?.owned && e.bitmap.close(), {
				bitmap: Jt,
				filled: -1,
				owned: !1
			})), Ft(!1);
			return;
		}
		let e = !1;
		Ft(!0);
		let t = setTimeout(async () => {
			let { w: t, h: n, pixels: r, inside: i } = It(), a = ji(H.stickers), o = a.length ? He(t, n, a, .003) : void 0, { image: s, filled: c } = Ye({
				width: t,
				height: n,
				data: r.data
			}, H, i, o, H.lettering !== !1), l = await createImageBitmap(new ImageData(new Uint8ClampedArray(s.data), t, n));
			if (e) return l.close();
			Pt((e) => (e?.owned && e.bitmap.close(), {
				bitmap: l,
				filled: c,
				owned: !0
			})), Ft(!1);
		}, 60);
		return () => {
			e = !0, clearTimeout(t);
		};
	}, [
		H,
		bt,
		c,
		V,
		Jt
	]), k(() => () => void (G?.owned && G.bitmap.close()), [G]);
	let [Yt, Xt] = j(() => /* @__PURE__ */ new Map());
	k(() => {
		if (!v) return;
		let e = !1;
		return (async () => {
			for (let [t, n] of Object.entries(v)) try {
				let r = typeof n == "string" ? await ge(n) : n, i = await createImageBitmap(r);
				e || Xt((e) => new Map(e).set(t, {
					bitmap: i,
					blob: r
				}));
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [v]);
	let Zt = D.recipe.upscale, Qt = Zt ? Yt.get(Zt.ref)?.bitmap : void 0;
	k(() => {
		if (!O) return;
		let e = Qe ?? Qt ?? G?.bitmap ?? c;
		O.setSource(F ? c : e);
	}, [
		O,
		G,
		Qt,
		F,
		c,
		Qe
	]), k(() => {
		if (!b) return;
		let e = !1;
		return (async () => {
			for (let [t, n] of Object.entries(b)) try {
				let r = typeof n == "string" ? await ge(n) : n, i = await createImageBitmap(r);
				e || qe((e) => new Map(e).set(t, {
					bitmap: i,
					blob: r
				}));
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [b]);
	let [$t, en] = j(!1), [tn, nn] = j(null), [rn, an] = j(null), on = async () => {
		if (!O) throw Error("The preview is not ready yet.");
		return (await O.export(t.document, {
			type: "image/png",
			maxSize: 1024
		})).blob;
	}, sn = async (e, n) => {
		let r = U.state === "ready" ? U.installed("upscale")[0] : void 0, i = n;
		if (r) try {
			i = await U.client.upscale(n, r.id);
		} catch {}
		let a = await createImageBitmap(i), o = Math.min(2048, O?.maxTextureSize ?? 2048);
		if (Math.max(a.width, a.height) > o) {
			let e = o / Math.max(a.width, a.height), t = await createImageBitmap(a, {
				resizeWidth: Math.floor(a.width * e),
				resizeHeight: Math.floor(a.height * e),
				resizeQuality: "high"
			});
			a.close(), a = t;
			let n = document.createElement("canvas");
			n.width = a.width, n.height = a.height, n.getContext("2d").drawImage(a, 0, 0), i = await new Promise((e, t) => n.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be saved.")), "image/png"));
		}
		let s = Array.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(6)), (e) => e.toString(16).padStart(2, "0")).join("");
		qe((e) => new Map(e).set(s, {
			bitmap: a,
			blob: i
		})), t.setFinish(e, s);
	}, cn = () => {
		let e = U.state === "ready" ? U.installed("redraw")[0] : void 0;
		if (!e) throw Error("The redraw model is not ready: start the Gleamshelf app and set it up first.");
		return e;
	}, q = async (e) => {
		let n = rn;
		if (an(null), n) {
			en(!0), nn(null), L(null);
			try {
				let r = cn();
				t.commit();
				let i = await U.client.redraw(await on(), {
					prompt: n.prompt,
					strength: n.keepShape ? .6 : .99,
					steps: 25,
					box: e
				});
				await sn(r.id, i), nn("The area was redrawn. Compare it with the real item before listing.");
			} catch (e) {
				L(e instanceof Error ? `The redraw did not work: ${e.message}` : "The redraw did not work.");
			} finally {
				en(!1);
			}
		}
	}, ln = async () => {
		let e = t.document.recipe.words?.ai, n = e && W.current.get(e.ref)?.bitmap || G?.bitmap || c, r = Math.min(1, 1024 / Math.max(n.width, n.height)), i = document.createElement("canvas");
		return i.width = Math.max(1, Math.round(n.width * r)), i.height = Math.max(1, Math.round(n.height * r)), i.getContext("2d").drawImage(n, 0, 0, i.width, i.height), new Promise((e, t) => i.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png"));
	}, un = async (e, n) => {
		let r = await createImageBitmap(n), i = O?.maxTextureSize ?? 4096;
		if (Math.max(r.width, r.height) > i) {
			let e = i / Math.max(r.width, r.height), t = await createImageBitmap(r, {
				resizeWidth: Math.floor(r.width * e),
				resizeHeight: Math.floor(r.height * e),
				resizeQuality: "high"
			});
			r.close(), r = t;
		}
		let a = Array.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(6)), (e) => e.toString(16).padStart(2, "0")).join("");
		Xt((e) => new Map(e).set(a, {
			bitmap: r,
			blob: n
		})), t.setUpscale(e, a);
	}, dn = async (e, { otherText: t, textModel: r, client: i, rebuild: a = !1, from: o = c, smoothOnly: s = !1, body: l, extra: u }) => {
		let d = It(o), { w: f, h: p, pixels: m } = d, h = Math.max(f, p), g = a ? Ue(d.inside, f, p, Math.max(4, Math.round(h * .06))) : d.inside, _ = e.lettering === !1 ? new Uint8Array(f * p) : Je({
			width: f,
			height: p,
			data: m.data
		}, e, g), v = ji(e.stickers);
		v.length && (_ = We(_, He(f, p, v, .003)));
		let y = [], b = new Uint8Array(f * p), x = new Uint8Array(f * p), S = 0;
		if (t && r) {
			let e = await i.detectText(await _e(o), r), t = new Uint8Array(f * p);
			for (let n of e) {
				if (n.width * n.height > (a ? .2 : .05)) continue;
				let e = Math.max(0, Math.floor(n.x * f)), r = Math.min(f, Math.ceil((n.x + n.width) * f)), i = Math.max(0, Math.floor(n.y * p)), o = Math.min(p, Math.ceil((n.y + n.height) * p)), s = 0, c = 0;
				for (let t = i; t < o; t++) for (let n = e; n < r; n++) s++, g[t * f + n] || c++;
				if (s) {
					if (a && l) {
						let t = 0, n = 0;
						for (let a = i; a < o; a += 2) for (let i = e; i < r; i += 2) {
							let e = Math.min(l.width - 1, Math.floor(i / f * l.width)), r = Math.min(l.height - 1, Math.floor(a / p * l.height));
							n++, l.alpha[r * l.width + e] > 140 && t++;
						}
						if (n && t / n < .35) {
							let t = Math.max(2, Math.round(h * .004));
							y.push({
								x: Math.max(0, (e - t) / f),
								y: Math.max(0, (i - t) / p),
								width: Math.min(1, (r - e + 2 * t) / f),
								height: Math.min(1, (o - i + 2 * t) / p)
							});
							continue;
						}
					}
					if (c / s >= .2 && !a) {
						let t = Math.max(2, Math.round(h * .004));
						y.push({
							x: Math.max(0, (e - t) / f),
							y: Math.max(0, (i - t) / p),
							width: Math.min(1, (r - e + 2 * t) / f),
							height: Math.min(1, (o - i + 2 * t) / p)
						});
					} else if (a) {
						let e = Ze({
							width: f,
							height: p,
							data: m.data
						}, n), r = 0;
						for (let t = 0; t < e.length; t++) r += +!!e[t];
						if (r === 0 && n.width * n.height > .004 && S++, r > n.width * f * n.height * p * .4) {
							S++;
							continue;
						}
						let i = n.height < .02 ? x : t;
						for (let t = 0; t < e.length; t++) e[t] && (i[t] = 1);
					} else for (let n = i; n < o; n++) for (let i = e; i < r; i++) g[n * f + i] && (t[n * f + i] = 1);
				}
			}
			a ? b = t : _ = We(_, t);
		}
		if (s) {
			for (let e = 0; e < _.length; e++) (_[e] || b[e]) && (x[e] = 1);
			_ = new Uint8Array(f * p), b = new Uint8Array(f * p);
		}
		if (u) {
			if (a) for (let e = 0; e < u.length; e++) b[e] ||= u[e];
			else _ = We(_, u);
		}
		let ee = x.some(Boolean), C = S;
		if (!_.some(Boolean) && !b.some(Boolean) && !ee && y.length === 0) return null;
		_ = Ue(_, f, p, Math.max(2, Math.round(h * (a ? .0015 : .005)))), b.some(Boolean) && (_ = We(_, Ue(b, f, p, Math.max(3, Math.round(h * .006)))));
		let te = ee ? We(_, Ue(x, f, p, Math.max(3, Math.round(h * .009)))) : _;
		if (a) {
			let e = (() => {
				let e = yt();
				return e ? n(e, V.width, V.height) : null;
			})(), t = .05, r = e ? Math.max(0, Math.floor((e.x - t) * f)) : 0, i = e ? Math.max(0, Math.floor((e.y - t) * p)) : 0, a = e ? Math.min(f, Math.ceil((e.x + e.width + t) * f)) : f, o = e ? Math.min(p, Math.ceil((e.y + e.height + t) * p)) : p, s = a - r, c = o - i, l = Ge({
				width: f,
				height: p,
				data: m.data
			}, te).data, u = new Uint8ClampedArray(s * c * 2 * 4);
			for (let e = 0; e < c; e++) for (let t = 0; t < s; t++) {
				let n = ((i + e) * f + r + t) * 4, a = (e * s + t) * 4;
				u[a] = l[n], u[a + 1] = l[n + 1], u[a + 2] = l[n + 2], u[a + 3] = 255;
				let o = ((c + e) * s + t) * 4, d = _[(i + e) * f + r + t] ? 255 : 0;
				u[o] = u[o + 1] = u[o + 2] = d, u[o + 3] = 255;
			}
			let d = 0;
			for (let e = 0; e < te.length; e++) d += +!!te[e];
			if (!_.some(Boolean)) {
				let e = document.createElement("canvas");
				return e.width = s, e.height = c, e.getContext("2d").putImageData(new ImageData(u.slice(0, s * c * 4), s, c), 0, 0), {
					picture: await new Promise((t, n) => e.toBlob((e) => e ? t(e) : n(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png")),
					cutAway: y,
					region: {
						x: r,
						y: i,
						width: s,
						height: c,
						fullWidth: f,
						fullHeight: p
					},
					share: d / te.length,
					skipped: C,
					done: !0
				};
			}
			let h = document.createElement("canvas");
			return h.width = s, h.height = c * 2, h.getContext("2d").putImageData(new ImageData(u, s, c * 2), 0, 0), {
				picture: await new Promise((e, t) => h.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png")),
				cutAway: y,
				region: {
					x: r,
					y: i,
					width: s,
					height: c,
					fullWidth: f,
					fullHeight: p
				},
				share: d / te.length,
				skipped: C
			};
		}
		let ne = new Uint8ClampedArray(m.data);
		for (let e = 0; e < f * p; e++) ne[e * 4 + 3] = _[e] ? 0 : 255;
		let re = document.createElement("canvas");
		return re.width = f, re.height = p, re.getContext("2d").putImageData(new ImageData(ne, f, p), 0, 0), {
			picture: await new Promise((e, t) => re.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png")),
			cutAway: y,
			share: 0
		};
	}, fn = async () => {
		let e = U.installed("text-detect")[0], t = U.installed("text-read")[0];
		if (!e || !t) throw Error("Reading prices needs the text finder and the text reader: install both with the commands in the AI panel.");
		let n = await U.client.readText(await _e(c)), r = /[$＄¥￥]\s*\d|\d\s*[$＄]|\d+\s*円/, { w: i, h: a, pixels: o } = It(), s = {
			width: i,
			height: a,
			data: o.data
		}, l = [];
		for (let e of n) {
			if (!r.test(e.text) || e.score < .5) continue;
			let t = {
				x: Math.max(0, e.x - e.width * .6),
				y: Math.max(0, e.y - e.height * 1),
				width: Math.min(1, e.width * 2.6),
				height: Math.min(1, e.height * 3.2)
			}, n = z(s, t);
			(n.width * n.height > .06 || n.x === t.x && n.y === t.y && n.width === t.width) && (n = {
				x: Math.max(0, e.x - e.width * .25),
				y: Math.max(0, e.y - e.height * .5),
				width: Math.min(1, e.width * 1.5),
				height: Math.min(1, e.height * 2)
			}), l.length < 28 && l.push(n.x, n.y, Math.min(n.width, 1 - n.x), Math.min(n.height, 1 - n.y));
		}
		return l;
	}, pn = async (t, { lettering: n, stickerBoxes: r, body: i }) => {
		let a = qt(), { w: o, h: s, pixels: c, inside: l } = It(a), u = Math.max(o, s), d = c.data, f = (e) => {
			let t = document.createElement("canvas");
			return t.width = o, t.height = s, t.getContext("2d").putImageData(new ImageData(new Uint8ClampedArray(e), o, s), 0, 0), new Promise((e, n) => t.toBlob((t) => t ? e(t) : n(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png"));
		}, p = async (e) => {
			let n = new Uint8ClampedArray(d);
			for (let t = 0; t < o * s; t++) e[t] && (n[t * 4 + 3] = 0);
			let r = await createImageBitmap(await U.client.inpaint(await f(n), t.id)), i = document.createElement("canvas");
			i.width = o, i.height = s;
			let a = i.getContext("2d", { willReadFrequently: !0 });
			a.drawImage(r, 0, 0, o, s), r.close();
			let c = a.getImageData(0, 0, o, s).data, l = new Uint8ClampedArray(d);
			for (let t = 0; t < o * s; t++) if (e[t]) for (let e = 0; e < 3; e++) l[t * 4 + e] = c[t * 4 + e];
			return l;
		}, m = () => new Uint8Array(o * s), h = m();
		if (n) {
			let t = Ue(l, o, s, Math.max(4, Math.round(u * .06)));
			h = Ue(Je({
				width: o,
				height: s,
				data: d
			}, { ...e }, t), o, s, Math.max(1, Math.round(u * .001)));
		}
		let g = r.length ? He(o, s, ji(r), .003) : m(), _ = [], v = 0, y = m(), b = U.installed("text-detect")[0];
		if (n && b) {
			let e = m();
			for (let t of await U.client.detectText(await _e(a), b.id)) {
				if (t.width * t.height > .05) {
					v++;
					continue;
				}
				let n = Math.max(0, Math.floor(t.x * o)), r = Math.min(o, Math.ceil((t.x + t.width) * o)), a = Math.max(0, Math.floor(t.y * s)), c = Math.min(s, Math.ceil((t.y + t.height) * s));
				if (i) {
					let e = 0, t = 0;
					for (let l = a; l < c; l += 2) for (let a = n; a < r; a += 2) {
						let n = Math.min(i.width - 1, Math.floor(a / o * i.width)), r = Math.min(i.height - 1, Math.floor(l / s * i.height));
						t++, i.alpha[r * i.width + n] > 140 && e++;
					}
					if (t && e / t < .35) {
						let e = Math.max(2, Math.round(u * .004));
						_.push({
							x: Math.max(0, (n - e) / o),
							y: Math.max(0, (a - e) / s),
							width: Math.min(1, (r - n + 2 * e) / o),
							height: Math.min(1, (c - a + 2 * e) / s)
						});
						continue;
					}
				}
				let l = Math.max(4, Math.round(u * .005));
				for (let t = Math.max(0, a - l); t < Math.min(s, c + l); t++) for (let i = Math.max(0, n - l); i < Math.min(o, r + l); i++) e[t * o + i] = 1;
			}
			e.some(Boolean) && (y = rt({
				width: o,
				height: s,
				data: d
			}, {
				width: o,
				height: s,
				data: await p(e)
			}, e));
		}
		let x = We(We(h, g), y);
		return x.some(Boolean) ? {
			picture: await f(await p(x)),
			cutAway: _,
			skipped: v
		} : {
			picture: null,
			cutAway: _,
			skipped: v
		};
	}, mn = async ({ lettering: n, stickers: r, add: i = [], body: a }) => {
		let o = Lt();
		if (!o) return {
			result: "no-ai",
			stickersFound: 0
		};
		let s = U.installed("text-detect")[0], c = [...t.document.recipe.words?.stickers ?? []], l;
		if (r) {
			c = [];
			try {
				c = await fn();
			} catch (e) {
				l = e instanceof Error ? e.message : "Price stickers could not be searched for.";
			}
		}
		if (c = [...c, ...i].slice(0, 28), o.task === "inpaint") {
			let e = await pn(o, {
				lettering: n,
				stickerBoxes: c,
				body: a
			});
			return e.picture ? (t.setWords(!0, {
				lettering: n,
				stickers: c
			}), await Tn(o.id, e.picture, e.cutAway, !1), {
				result: "filled",
				stickersFound: c.length / 4,
				stickerNote: l,
				skipped: e.skipped
			}) : {
				result: "nothing",
				stickersFound: 0,
				stickerNote: l,
				skipped: e.skipped
			};
		}
		let u = {
			...e,
			...n ? {} : { lettering: !1 },
			...c.length ? { stickers: c } : {}
		}, d = await dn(u, {
			otherText: n && !!s,
			textModel: s?.id,
			client: U.client,
			rebuild: o.task === "redraw",
			body: a
		});
		if (!d) return {
			result: "nothing",
			stickersFound: 0,
			stickerNote: l
		};
		let f = d.skipped ?? 0;
		t.setWords(!0, {
			lettering: n,
			stickers: c
		});
		let p = d.done ? d.picture : await Rt(o, d);
		if (await Tn(o.id, d.region ? await Bt(p, d.region) : p, d.cutAway, o.task !== "redraw"), o.task === "redraw" && n) try {
			let t = await dn({ ...e }, {
				otherText: !!s,
				textModel: s?.id,
				client: U.client,
				rebuild: !0,
				from: qt(),
				smoothOnly: !0
			});
			if (t?.region && t.share > 0 && t.share < d.share * .5) {
				let e = qt(), n = t.done ? t.picture : await Rt(o, t);
				await Tn(o.id, await Bt(n, t.region, e), []);
			}
		} catch {}
		return {
			result: "filled",
			stickersFound: c.length / 4,
			stickerNote: l,
			skipped: f
		};
	}, hn = async () => {
		if (!Lt()) return void t.setWords(!0);
		At(!0);
		try {
			(await mn({
				lettering: !0,
				stickers: !!U.installed("text-read")[0]
			})).result === "nothing" && t.setWords(!0);
		} catch (e) {
			L(e instanceof Error ? `The AI fill did not work: ${e.message}` : "The AI fill did not work.");
		} finally {
			At(!1);
		}
	}, [gn, _n] = j(!1), [vn, yn] = j("sticker"), J = async (e, n) => {
		_n(!1), Sn(null), At(!0);
		try {
			let { w: r, h: i, pixels: a } = It(), o = {
				x: Math.max(0, e - .06),
				y: Math.max(0, n - .035),
				width: .12,
				height: .07
			}, s = z({
				width: r,
				height: i,
				data: a.data
			}, o);
			s.width * s.height > .05 && (s = {
				x: Math.max(0, e - .03),
				y: Math.max(0, n - .02),
				width: .06,
				height: .04
			});
			let c = t.document.recipe.words ? t.document.recipe.words.lettering !== !1 : !1, { result: l } = await mn({
				lettering: c,
				stickers: !1,
				add: [
					s.x,
					s.y,
					Math.min(s.width, 1 - s.x),
					Math.min(s.height, 1 - s.y)
				]
			});
			Sn(l === "no-ai" ? "Needs an AI fill: start the Gleamshelf app and set up the redraw model (or install LaMa)." : "Removed the sticker you pointed at.");
		} catch (e) {
			Sn(e instanceof Error ? e.message : "The sticker could not be removed.");
		} finally {
			At(!1);
		}
	}, bn = async (n, r) => {
		_n(!1), Sn(null), At(!0);
		try {
			let i = Lt();
			if (!i) return void Sn("Needs an AI fill: start the Gleamshelf app and set up the redraw model (or install LaMa).");
			let a = qt(), { w: o, h: s, pixels: c } = It(a), l = {
				x: n * o,
				y: r * s
			}, u = {
				x0: l.x - o * .3,
				y0: l.y - s * .08,
				x1: l.x + o * .3,
				y1: l.y + s * .08
			}, d = U.installed("text-detect")[0];
			if (d) {
				let e = await U.client.detectText(await _e(a), d.id), t = (e, t) => n >= e.x - t && n <= e.x + e.width + t && r >= e.y - t && r <= e.y + e.height + t, i = (e) => Math.hypot(n - (e.x + e.width / 2), r - (e.y + e.height / 2)), c = e.filter((e) => t(e, 0)).sort((e, t) => e.width * e.height - t.width * t.height)[0] ?? e.filter((e) => t(e, .015)).sort((e, t) => i(e) - i(t))[0], l = .012;
				c && (u = {
					x0: (c.x - l) * o,
					y0: (c.y - l) * s,
					x1: (c.x + c.width + l) * o,
					y1: (c.y + c.height + l) * s
				});
			}
			let f = $e({
				width: o,
				height: s,
				data: c.data
			}, u, l);
			if (!("mask" in f)) return void Sn(f.problem === "too-much" ? "That colour covers too much of the area to be sure it is print, so nothing was taken off. Click a letter of the text itself, not the picture behind it." : "No printed text was found at that point. Click right on a letter (a second click takes off a second colour).");
			let p = t.document.recipe.words, m = {
				...p ?? e,
				lettering: !1,
				stickers: void 0,
				ai: void 0
			}, h = await dn(m, {
				otherText: !1,
				client: U.client,
				rebuild: i.task === "redraw",
				from: a,
				extra: f.mask
			});
			if (!h) return void Sn("Nothing to take off there.");
			let g = !!t.document.recipe.upscale;
			p || t.setWords(!0, { lettering: !1 });
			let _ = h.done ? h.picture : await Rt(i, h);
			await Tn(i.id, h.region ? await Bt(_, h.region, a) : _, [], i.task !== "redraw"), Sn(`Took off the printed text you pointed at${g ? " (the enlarging was reset: run Sharpen & enlarge again)" : ""}.`);
		} catch (e) {
			Sn(e instanceof Error ? e.message : "The printed text could not be removed.");
		} finally {
			At(!1);
		}
	}, [xn, Sn] = j(null), Cn = async () => {
		Sn(null), At(!0);
		try {
			let e = t.document.recipe.words ? t.document.recipe.words.lettering !== !1 : !1, { result: n, stickersFound: r, stickerNote: i } = await mn({
				lettering: e,
				stickers: !0
			});
			Sn(n === "no-ai" ? "Needs an AI fill: start the Gleamshelf app and set up the redraw model (or install LaMa)." : i ?? (r ? `Removed ${r} price sticker${r === 1 ? "" : "s"}.` : "No price sticker found. A sticker with no clear price on it can be painted out with the cut-out brush."));
		} catch (e) {
			Sn(e instanceof Error ? e.message : "The price stickers could not be removed.");
		} finally {
			At(!1);
		}
	}, wn = (e) => {
		let t = yt(), r = t && n(t, V.width, V.height);
		if (!r) return e;
		let i = e.filter((e) => e.y >= r.y + r.height * .65);
		if (!i.length) return e;
		let a = Math.max(r.y, Math.min(...i.map((e) => e.y)) - .004);
		return [...e.filter((e) => !i.includes(e)), {
			x: 0,
			y: a,
			width: 1,
			height: 1 - a
		}];
	}, Tn = async (e, n, r = [], i = !0) => {
		let a = await createImageBitmap(n), o = Array.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(6)), (e) => e.toString(16).padStart(2, "0")).join("");
		Nt(o, {
			bitmap: a,
			blob: n
		}), r.length && t.eraseBoxes(i ? wn(r) : r), t.setWordsAi(e, o), Ot();
	}, En = (e) => {
		let r = yt(), i = r && n(r, V.width, V.height);
		return i ? (t.begin("Studio photo"), t.set("recipe/ops/backdrop/mode", "color"), t.set("recipe/ops/backdrop/color", "#ffffff"), t.fitSquareToProduct(i, .07), e?.shadow !== !1 && !t.effects.some((e) => e.id === "drop-shadow") && t.addEffect("drop-shadow", {
			opacity: .22,
			blur: 16,
			offsetX: 0,
			offsetY: 20,
			color: "#000000"
		}), t.commit(), !0) : !1;
	}, [Dn, On] = j(!1), [kn, An] = j(null), jn = async () => {
		let e = yt();
		if (!e) return An("Cut the product out first.");
		On(!0), An(null);
		try {
			let t = document.createElement("canvas");
			t.width = c.width, t.height = c.height;
			let n = t.getContext("2d", { willReadFrequently: !0 });
			n.drawImage(c, 0, 0);
			let r = n.getImageData(0, 0, c.width, c.height), i = Ve({
				width: r.width,
				height: r.height,
				data: r.data
			}, e, V.width, V.height);
			if (!i) {
				An("This is not a flat four-cornered product (a card, a box front, a print), so it was left as it is.");
				return;
			}
			let a = document.createElement("canvas");
			a.width = i.image.width, a.height = i.image.height, a.getContext("2d").putImageData(new ImageData(new Uint8ClampedArray(i.image.data), i.image.width, i.image.height), 0, 0), await ie(await new Promise((e, t) => a.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("Could not save it.")), "image/png")), !0, null);
		} catch (e) {
			An(e instanceof Error ? e.message : "It could not be straightened.");
		} finally {
			On(!1);
		}
	}, [Mn, Nn] = j(!1), [Pn, Fn] = j(null), In = async (e) => {
		if (!O || Mn) return;
		let r = yt(), i = r && n(r, V.width, V.height);
		if (!i) return Fn("Cut the product out first.");
		Nn(!0), Fn(null);
		try {
			t.commit();
			let n = t.document, r = n.source.name || "photo", a = [], o = Infinity;
			for (let t of e) {
				let e = y(t);
				if (!e) continue;
				let s = S(n, i, e), c = u(s);
				o = Math.min(o, Math.max(c.width, c.height));
				let l = await O.export(s, {
					size: e.size,
					type: e.type,
					maxBytes: e.maxBytes,
					background: "#ffffff"
				});
				a.push({
					name: g(r, e),
					bytes: new Uint8Array(await l.blob.arrayBuffer())
				});
			}
			let s = new Blob([Oe(a)], { type: "application/zip" }), c = URL.createObjectURL(s), l = document.createElement("a");
			l.href = c, l.download = `${r.replace(/\.[^.]+$/, "") || "photo"}-listing-set.zip`, l.click(), setTimeout(() => URL.revokeObjectURL(c), 1e4), Fn(`Saved ${a.length} picture${a.length === 1 ? "" : "s"}: ${a.map((e) => e.name.replace(/^.*-/, "")).join(", ")}.` + (o < 1e3 ? ` The photo has about ${Math.round(o)} px across the product, so the larger sizes are stretched: use Sharpen and enlarge (Adjust) first for crisp zoom.` : "") + (t.finish ? " The finishing touches are not in the set: they were drawn for this framing only." : ""));
		} catch (e) {
			Fn(e instanceof Error ? e.message : "The listing set could not be made.");
		} finally {
			Nn(!1);
		}
	}, Ln = async (e, t) => {
		let n = await U.client.processPicture(e, "cutout"), r = t?.quality && t.quality.fidelity.original < 1 ? await U.client.processPicture(e, "changes").then((e) => URL.createObjectURL(e), () => void 0) : void 0;
		await ie(n, t?.modeUsed !== "character", t ? {
			...t,
			changesUrl: r
		} : null);
	}, [Rn, zn] = j([]), Bn = A(/* @__PURE__ */ new Map()), Vn = async () => {
		try {
			let e = await U.client.recentRuns();
			for (let t of e.slice(0, 8)) if (!Bn.current.has(t.id)) {
				let e = await U.client.processPicture(t.id, "studio").catch(() => null);
				e && Bn.current.set(t.id, URL.createObjectURL(e));
			}
			or.current && zn(e.map((e) => ({
				...e,
				thumb: Bn.current.get(e.id)
			})));
		} catch {}
	};
	k(() => {
		U.state === "ready" && U.canProcess && Vn();
	}, [U.state, U.canProcess]);
	let Hn = async (e) => {
		try {
			let t = await U.client.processStatus(e);
			await Ln(e, t.report);
		} catch (e) {
			L(e instanceof Error ? e.message : "That result could not be opened.");
		}
	}, [Un, Wn] = j(() => {
		try {
			let e = localStorage.getItem("gleamshelf:auto-mode");
			return e === "character" || e === "auto" ? e : "product";
		} catch {
			return "product";
		}
	}), Gn = (e) => {
		Wn(e);
		try {
			localStorage.setItem("gleamshelf:auto-mode", e);
		} catch {}
	}, [Kn, qn] = j(null), [Jn, Yn] = j(null), [Xn, Zn] = j(!1), [Qn, $n] = j(null), er = () => $n((e) => {
		if (e) for (let t of Object.values(e.thumbs)) URL.revokeObjectURL(t);
		return null;
	});
	k(() => () => er(), []);
	let tr = async (e) => {
		if (Qn && !Qn.sent) {
			$n({
				...Qn,
				sent: !0
			});
			try {
				await U.client.chooseReferences(Qn.job, e), $n((t) => t && {
					...t,
					ticked: e ?? t.online.photos.filter((e) => e.linesUp).map((e) => e.index)
				});
			} catch (e) {
				$n((e) => e && {
					...e,
					sent: !1
				}), L(e instanceof Error ? e.message : "The app did not take the choice.");
			}
		}
	}, nr = (e, t) => {
		try {
			let n = localStorage.getItem(e);
			return n === null ? t : n === "on";
		} catch {
			return t;
		}
	}, [rr, ir] = j(() => Object.fromEntries(Mi.map((e) => [e.key, !e.optIn && nr(`gleamshelf:full-${e.key}`, !0)]))), ar = (e, t) => {
		if (ir((n) => ({
			...n,
			[e]: t
		})), !Mi.find((t) => t.key === e)?.optIn) try {
			localStorage.setItem(`gleamshelf:full-${e}`, t ? "on" : "off");
		} catch {}
	}, or = A(!0);
	k(() => (or.current = !0, () => {
		or.current = !1;
	}), []);
	let sr = A(!1);
	k(() => {
		C && !sr.current && (sr.current = !0, St("pipeline", C.mask, "product", !1), En({ shadow: C.shadow }));
	}, []);
	let cr = async () => {
		if (Xn || !ee) return;
		t.commit(), L(null), Zn(!0), er();
		let e = (e) => qn(e.map((e) => ({
			label: e.name,
			state: e.state,
			startedAt: e.startedAt,
			seconds: e.seconds
		}))), n = null, r = !1, i = () => {
			r = !0, n && U.client.cancelProcess(n).catch(() => {});
		};
		try {
			e([{
				name: "Sending the photo to the Gleamshelf app (it stays on this computer)",
				state: "running"
			}]);
			let t = rr.find, a = t && rr.colour, o = await U.client.startProcess(ee, {
				mode: Un,
				find: t,
				listing: t && rr.listing,
				colour: a,
				vivid: a && rr.vivid ? 1.4 : 1,
				stickers: rr.stickers,
				lettering: rr.lettering,
				thinParts: rr.thinParts,
				look: rr.look,
				enlarge: rr.enlarge,
				gloss: rr.gloss,
				review: t
			});
			n = o;
			let s, c = 0, l = !1;
			for (Yn({
				health: null,
				receivedAt: Date.now(),
				queued: !0,
				unanswered: 0,
				stop: i
			});;) {
				if (await new Promise((e) => setTimeout(e, 1e3)), !or.current) return;
				if (r) throw Error("Stopped.");
				try {
					s = await U.client.processStatus(o), c = 0;
				} catch (e) {
					if (c++, Yn((e) => e && {
						...e,
						unanswered: c
					}), c >= 15) throw Error(`the Gleamshelf app stopped answering (${e instanceof Error ? e.message : "no answer"}). Is it still running? Start it again with: npm run local:start`);
					continue;
				}
				if (Yn({
					health: s.health ?? null,
					receivedAt: Date.now(),
					queued: s.status === "queued",
					unanswered: 0,
					stop: i
				}), e(s.steps.length ? s.steps : [{
					name: s.status === "queued" ? "Waiting for the app to finish another job" : "Starting",
					state: "running"
				}]), s.found && s.status === "waiting") {
					let e = s.found;
					if ($n((t) => t && t.job === o ? t : {
						job: o,
						online: e,
						thumbs: {},
						ticked: e.photos.filter((e) => e.linesUp).map((e) => e.index),
						sent: !1
					}), !l) {
						l = !0;
						for (let t of e.photos.slice(0, 24)) U.client.foundPicture(o, t.index).then((e) => {
							let n = URL.createObjectURL(e);
							if (!or.current) return URL.revokeObjectURL(n);
							$n((e) => e && e.job === o ? {
								...e,
								thumbs: {
									...e.thumbs,
									[t.index]: n
								}
							} : (URL.revokeObjectURL(n), e));
						}).catch(() => {});
					}
				}
				if (s.status === "done" || s.status === "failed") break;
			}
			if (s.status === "failed") throw Error(s.error === "Stopped." ? "Stopped." : s.error ?? "The app could not finish.");
			await Ln(o, s.report), Vn();
		} catch (e) {
			let t = e instanceof Error && e.message === "Stopped.";
			qn((e) => e?.map((e) => e.state === "running" ? {
				...e,
				state: "skipped",
				note: t ? "stopped" : "did not finish"
			} : e) ?? null), Be(t ? {
				kind: "stopped",
				message: "Stopped. Nothing was changed."
			} : {
				kind: "failed",
				message: e instanceof Error ? e.message : "The app could not finish."
			});
		} finally {
			or.current && (Zn(!1), Yn(null));
		}
	}, [lr, ur] = j(() => {
		try {
			return localStorage.getItem("gleamshelf:auto-detail") === "on";
		} catch {
			return !1;
		}
	}), dr = (e) => {
		ur(e);
		try {
			localStorage.setItem("gleamshelf:auto-detail", e ? "on" : "off");
		} catch {}
	}, [fr, pr] = j(!1), mr = U.state === "ready" && !!U.installed("enhance")[0] && !!U.installed("redraw")[0], hr = async () => {
		if (Xn) return;
		if (U.canProcess && U.state === "ready" && ee) return cr();
		t.commit(), L(null), Zn(!0);
		let e = Un === "character", r = lr && mr && e, i = fr && mr, a = [
			e ? "Cut out the box and crop to it" : "Cut out the product",
			e ? "Repaint lettering, printed text and price stickers" : "Remove price stickers",
			...e ? ["Cut out the character"] : [],
			"Brighter and sharper",
			i ? "Studio gloss (changes the product), then enlarge (about 2 minutes)" : r ? "Sharpen with detail, then enlarge (about 2 minutes)" : "Sharpen and enlarge",
			e ? "Studio photo (white, square, no shadow)" : "Studio photo (white, square)"
		], o = a.map((e) => ({
			label: e,
			state: "todo"
		})), [l, u, ...f] = [
			0,
			1,
			...a.slice(2).map((e, t) => t + 2)
		], p = e ? f.shift() : -1, [m, h, g] = f, _ = (e, t, n) => {
			o[e] = {
				...o[e],
				state: t,
				note: n
			}, qn([...o]);
		}, v = async (e, t) => {
			_(e, "running");
			try {
				let n = await t();
				o[e].state === "running" && _(e, "done", n || void 0);
			} catch (t) {
				_(e, "skipped", t instanceof Error ? t.message : "This step did not work.");
			}
		}, y = (e, t) => _(e, "skipped", t), b = U.state === "ready", x = b ? U.installed("cutout")[0] : void 0, S = (e, t) => {
			throw _(e, "skipped", t), Error(t);
		};
		qn([...o]);
		try {
			if (await v(l, async () => {
				let r = "";
				if (t.document.recipe.mask.length === 0) {
					if (ft) t.removeGreenBackdrop(), r = "green backdrop removed (free)";
					else if (x) St(x.id, await U.client.cutout(await _e(c), x.id), "product"), r = "AI cut-out";
					else return S(l, "No green backdrop, and the AI cut-out is not available: start the Gleamshelf app and install a cut-out model.");
				} else r = "already cut out";
				if (e) {
					if (!x) return S(l, "Finding the character needs the AI cut-out: start the Gleamshelf app.");
					let e = yt(), i = e && n(e, V.width, V.height);
					if (i) {
						let e = .06, n = Math.max(0, i.x - i.width * e), r = Math.max(0, i.y - i.height * e);
						t.setCrop(ne(t.document, {
							x: n,
							y: r,
							width: Math.min(1, i.x + i.width * 1.06) - n,
							height: Math.min(1, i.y + i.height * 1.06) - r
						}));
					}
					r += ", cropped to the box";
				}
				return r;
			}), !yt()) {
				for (let e = 1; e < o.length; e++) y(e, "Needs a cut-out first.");
				return;
			}
			await v(u, async () => {
				let n;
				if (e && x) try {
					n = d(t.document, s(await U.client.cutout(await he(c, t.document), x.id)));
				} catch {}
				let { result: r, stickersFound: i, stickerNote: a, skipped: o = 0 } = await mn({
					lettering: e,
					stickers: !0,
					body: n
				});
				return r === "no-ai" ? S(u, "Needs an AI fill: start the Gleamshelf app and set up the redraw model (or install LaMa).") : r === "nothing" ? a ?? (e ? "nothing to remove" : "no price sticker found") : `${e ? "lettering and printed text" : ""}${e && i ? " and " : ""}${i ? `${i} price sticker${i === 1 ? "" : "s"}` : ""} repainted${a ? ` (${a})` : ""}${o ? `; ${o} printed line${o === 1 ? "" : "s"} left, too tangled with the picture to take off safely (take them off with "Click printed text", or crop them out)` : ""}`;
			}), e && await v(p, async () => x ? (St(x.id, await U.client.cutout(await he(qt(), t.document), x.id, void 0, { thinParts: !0 }), "character"), "cut out of the repainted cover") : S(p, "Finding the character needs the AI cut-out: start the Gleamshelf app.")), await v(m, async () => {
				let e = t.document.recipe;
				return Ot(), e === t.document.recipe ? "already set" : void 0;
			}), await v(h, async () => {
				let e = b ? U.installed("upscale")[0] : void 0;
				if (!e) return S(h, "Needs an enlarging model: start the Gleamshelf app and install one.");
				let t = await ln(), n = !1;
				if (i) try {
					t = await U.client.gloss(t), n = !0;
				} catch (e) {
					L(e instanceof Error ? `Studio gloss did not work, so the product was left as photographed: ${e.message}` : "Studio gloss did not work, so the product was left as photographed.");
				}
				else if (r) try {
					t = await U.client.enhance(t, { strength: .25 });
				} catch (e) {
					L(e instanceof Error ? `The detail sharpening did not work, so the plain enlarge was used: ${e.message}` : "The detail sharpening did not work, so the plain enlarge was used.");
				}
				return await un(e.id, await U.client.upscale(t, e.id)), n ? `glossed by AI, so compare it with the real item before listing; ${e.name}, saved 2 times larger` : `${e.name}, saved 2 times larger`;
			}), await v(g, async () => {
				if (e && t.fadeBottom(.15), !En({ shadow: !e })) return S(g, "Nothing is cut out.");
			});
		} finally {
			Zn(!1);
		}
	}, gr = () => {
		let e = yt(), r = e && n(e, V.width, V.height);
		r && t.fitSquareToProduct(r);
	};
	k(() => {
		if (!O || M.width <= 0) return;
		let e = window.devicePixelRatio || 1, t = requestAnimationFrame(() => O.draw(it, Math.round(ct * e), Math.round(lt * e)));
		return () => cancelAnimationFrame(t);
	}, [
		O,
		it,
		ct,
		lt,
		M.width,
		R,
		G,
		F
	]);
	let _r = (e) => {
		let n = e.target;
		if (n.tagName === "SELECT" || n.tagName === "INPUT" && n.type !== "range") return;
		let r = e.type === "keydown", i = e.ctrlKey || e.metaKey, a = e.key.toLowerCase();
		r && i && a === "z" ? (e.preventDefault(), e.shiftKey ? t.redo() : t.undo()) : r && i && a === "y" ? (e.preventDefault(), t.redo()) : e.key === "\\" ? Ee(r) : r && !i && a === "c" ? tt() : r && !i && a === "e" && !vr ? br() : r && !i && a === "l" && !xr ? Tr() : r && !i && e.key === "?" ? ke(!0) : r && e.key === "Escape" && (gn || rn) ? (_n(!1), an(null)) : r && (e.key === "Enter" || e.key === "Escape") && (Ae || Ne) && (e.preventDefault(), je(!1), Pe(!1));
	}, [vr, yr] = j(null), br = async () => {
		if (O && !Le) {
			I(!0), L(null);
			try {
				t.commit();
				let e = et ?? t.document, n = Ei(e.recipe), r = e.recipe.ops, i = n === "image" ? e : {
					...e,
					recipe: {
						...e.recipe,
						ops: {
							...r,
							backdrop: {
								...r.backdrop,
								mode: "transparent"
							}
						}
					}
				}, { blob: a } = await O.export(i, { type: "image/png" }), o = await createImageBitmap(a, { premultiplyAlpha: "none" });
				yr({
					kind: "pictures",
					width: o.width,
					height: o.height,
					background: n === "color" ? l(e.recipe, "backdrop", "color") || "#ffffff" : n === "image" ? "#ffffff" : null,
					layers: [{
						name: e.recipe.mask.length ? "Product" : "Photo",
						picture: o
					}]
				});
			} catch (e) {
				L(e instanceof Error ? e.message : "Edit mode could not open this picture.");
			} finally {
				I(!1);
			}
		}
	}, [xr, Sr] = j(null), [Cr, wr] = j(!1), Tr = async () => {
		if (O && !Le) {
			I(!0), L(null);
			try {
				t.commit();
				let { blob: e } = await O.export(et ?? t.document, { type: "image/png" });
				Sr(e);
			} catch (e) {
				L(e instanceof Error ? e.message : "Photo lab could not open this picture.");
			} finally {
				I(!1);
			}
		}
	}, Er = () => {
		Sr(null), pe.current?.focus();
	}, Dr = () => {
		if (vr?.kind === "pictures") for (let e of vr.layers) e.picture.close?.();
		yr(null), pe.current?.focus();
	}, Or = async () => {
		if (O && !Le) {
			I(!0), L(null);
			try {
				t.commit();
				let e = await O.export(et ?? t.document, oe), n = t.document.recipe.upscale?.ref, r = n && Yt.get(n) ? { [n]: Yt.get(n).blob } : void 0, i = t.document.recipe.words?.ai?.ref, a = i && jt.get(i) ? { [i]: jt.get(i).blob } : void 0, o = Ei(t.document.recipe) === "image" && R, s = {};
				for (let e of t.document.recipe.mask) {
					let t = e.kind === "model" ? mt.get(e.ref) : void 0;
					e.kind === "model" && t && (s[e.ref] = await fe(t));
				}
				let c = t.document.recipe.finish?.ref, l = c && B.get(c) ? { [c]: B.get(c).blob } : void 0;
				se({
					...e,
					finishes: l,
					recipe: t.document.recipe,
					source: t.document.source,
					backgroundPhoto: o ? R.blob : void 0,
					cutoutMasks: Object.keys(s).length ? s : void 0,
					repairs: a,
					enlargements: r
				});
			} catch (e) {
				L(e instanceof Error ? e.message : "The image could not be saved.");
			} finally {
				I(!1);
			}
		}
	};
	return /* @__PURE__ */ P("div", {
		className: "gs-editor",
		ref: pe,
		tabIndex: -1,
		onKeyDown: _r,
		onKeyUp: _r,
		children: [
			/* @__PURE__ */ P("header", {
				className: "gs-toolbar",
				children: [
					/* @__PURE__ */ P("div", {
						className: "gs-toolbar__group",
						children: [T && /* @__PURE__ */ P("button", {
							type: "button",
							className: "gs-button gs-button--ghost",
							onClick: T,
							title: "Close without saving",
							children: [/* @__PURE__ */ N(de, { name: "close" }), " Cancel"]
						}), /* @__PURE__ */ P("span", {
							className: "gs-brand",
							"aria-hidden": "true",
							children: [/* @__PURE__ */ N("span", { className: "gs-brand__mark" }), "Gleamshelf"]
						})]
					}),
					/* @__PURE__ */ P("div", {
						className: "gs-toolbar__group gs-toolbar__group--center",
						children: [
							/* @__PURE__ */ N("button", {
								type: "button",
								className: "gs-icon-button",
								disabled: !ue.canUndo,
								onClick: () => t.undo(),
								title: ue.undoLabel ? `Undo ${ue.undoLabel} (Ctrl+Z)` : "Undo",
								"aria-label": "Undo",
								children: /* @__PURE__ */ N(de, { name: "undo" })
							}),
							/* @__PURE__ */ N("button", {
								type: "button",
								className: "gs-icon-button",
								disabled: !ue.canRedo,
								onClick: () => t.redo(),
								title: ue.redoLabel ? `Redo ${ue.redoLabel} (Ctrl+Shift+Z)` : "Redo",
								"aria-label": "Redo",
								children: /* @__PURE__ */ N(de, { name: "redo" })
							}),
							/* @__PURE__ */ N("span", { className: "gs-toolbar__divider" }),
							/* @__PURE__ */ P("button", {
								type: "button",
								className: `gs-button gs-button--ghost ${F ? "is-active" : ""}`,
								onPointerDown: () => Ee(!0),
								onPointerUp: () => Ee(!1),
								onPointerLeave: () => Ee(!1),
								title: "Hold to see the original (or hold \\)",
								children: [/* @__PURE__ */ N(de, { name: "compare" }), " Compare"]
							}),
							/* @__PURE__ */ P("button", {
								type: "button",
								className: "gs-button gs-button--ghost",
								onClick: () => t.reset(),
								title: "Back to the photo as it was",
								children: [/* @__PURE__ */ N(de, { name: "reset" }), " Reset"]
							})
						]
					}),
					/* @__PURE__ */ P("div", {
						className: "gs-toolbar__group gs-toolbar__group--end",
						children: [
							/* @__PURE__ */ P("span", {
								className: "gs-toolbar__meta",
								children: [
									ot.width,
									" × ",
									ot.height
								]
							}),
							U.state === "ready" && U.canPhone && /* @__PURE__ */ P("button", {
								type: "button",
								className: "gs-button gs-button--ghost",
								onClick: () => wr(!0),
								title: "Take photos on a phone and edit them here",
								children: [/* @__PURE__ */ N(de, { name: "spark" }), " From phone"]
							}),
							/* @__PURE__ */ P("button", {
								type: "button",
								className: "gs-button gs-button--ghost",
								onClick: () => ke(!0),
								title: "How to use every feature (?)",
								children: [/* @__PURE__ */ N(de, { name: "help" }), " Guide"]
							}),
							/* @__PURE__ */ P("button", {
								type: "button",
								className: "gs-button gs-button--edit",
								disabled: !O || Le,
								onClick: () => void br(),
								title: "Layers, brushes, selections, shapes and text on this picture (E)",
								children: [/* @__PURE__ */ N(de, { name: "layers" }), " Edit mode"]
							}),
							/* @__PURE__ */ P("button", {
								type: "button",
								className: "gs-button gs-button--edit",
								disabled: !O || Le,
								onClick: () => void Tr(),
								title: "Develop, looks, retouching and every filter, by hand (L)",
								children: [/* @__PURE__ */ N(de, { name: "sliders" }), " Photo lab"]
							}),
							/* @__PURE__ */ N("button", {
								type: "button",
								className: "gs-button gs-button--primary",
								disabled: !O || Le,
								onClick: () => void Or(),
								children: Le ? "Saving…" : le
							})
						]
					})
				]
			}),
			/* @__PURE__ */ P("main", {
				className: "gs-stage",
				ref: ye,
				children: [
					/* @__PURE__ */ P("div", {
						className: "gs-stage__frame",
						children: [
							/* @__PURE__ */ N("canvas", {
								ref: xe,
								className: "gs-stage__canvas",
								style: {
									width: ct,
									height: lt
								}
							}),
							Ae && !F && /* @__PURE__ */ N(pt, {
								editor: t,
								doc: D,
								width: ct,
								height: lt
							}),
							rn && !F && !Qe && /* @__PURE__ */ N(Kt, {
								width: ct,
								height: lt,
								onArea: (e) => void q(e)
							}),
							gn && !F && /* @__PURE__ */ N(Ut, {
								editor: t,
								width: ct,
								height: lt,
								onPick: (e, t) => void (vn === "text" ? bn(e, t) : J(e, t))
							}),
							Ne && !F && /* @__PURE__ */ N(ht, {
								editor: t,
								doc: D,
								settings: Fe,
								width: ct,
								height: lt
							})
						]
					}),
					F && /* @__PURE__ */ N("span", {
						className: "gs-stage__badge",
						children: "Original"
					}),
					Ne && !F && /* @__PURE__ */ P("span", {
						className: "gs-stage__badge",
						children: [
							Fe.tool === "tap" ? "Tap the background to remove it" : Fe.tool === "erase" ? "Paint to erase" : "Paint to bring back",
							" ",
							"· Enter when done"
						]
					}),
					Ae && !F && /* @__PURE__ */ N("span", {
						className: "gs-stage__badge",
						children: "Cropping · Enter when done"
					}),
					rn && !F && /* @__PURE__ */ N("span", {
						className: "gs-stage__badge",
						children: "Drag a rectangle around the area to redraw · Esc to cancel"
					}),
					gn && !F && /* @__PURE__ */ N("span", {
						className: "gs-stage__badge",
						children: vn === "text" ? "Click a letter of the printed text to remove · Esc to cancel" : "Click the sticker to remove · Esc to cancel"
					}),
					Re && /* @__PURE__ */ P("div", {
						className: "gs-alert",
						role: "alert",
						children: [
							/* @__PURE__ */ N("span", {
								className: "gs-alert__icon",
								"aria-hidden": "true",
								children: "!"
							}),
							/* @__PURE__ */ N("p", { children: Re }),
							/* @__PURE__ */ N("button", {
								type: "button",
								className: "gs-alert__close",
								"aria-label": "Dismiss",
								onClick: () => L(null),
								children: "×"
							})
						]
					}),
					!Re && xt > 0 && /* @__PURE__ */ N("p", {
						className: "gs-error gs-stage__error",
						children: "This edit used an AI cut-out whose mask was not supplied, so it is not applied. Run the AI cut-out again."
					})
				]
			}),
			/* @__PURE__ */ N("aside", {
				className: "gs-sidebar",
				children: /* @__PURE__ */ N(ce, {
					editor: t,
					doc: D,
					onOpenGuide: () => ke(!0),
					cropping: Ae,
					onToggleCrop: tt,
					cutout: Ne,
					onToggleCutout: nt,
					cutSettings: Fe,
					onCutSettings: (e) => Ie((t) => ({
						...t,
						...e
					})),
					onFitProduct: gr,
					onStudio: En,
					listingSet: {
						run: (e) => void In(e),
						busy: Mn,
						note: Pn
					},
					flatten: {
						run: () => void jn(),
						busy: Dn,
						note: kn
					},
					onBackgroundPhoto: wt,
					hasBackgroundPhoto: !!R,
					backgroundName: R?.name,
					hasCutout: dt.length > 0,
					lettering: {
						busy: K || kt,
						filled: G?.filled ?? 0,
						aiReady: !!Lt()
					},
					onRemoveLettering: () => void hn(),
					stickers: {
						run: () => void Cn(),
						busy: kt,
						note: xn,
						picking: gn,
						setPicking: (e) => (yn("sticker"), _n(e)),
						pickingText: gn && vn === "text",
						setPickingText: (e) => (yn("text"), _n(e))
					},
					auto: {
						run: () => {
							Be(null), hr();
						},
						end: ze,
						dismissEnd: () => Be(null),
						busy: Xn,
						mode: Un,
						setMode: Gn,
						steps: Kn,
						watch: Jn,
						appReady: U.state === "ready",
						greenBackdrop: ft,
						full: U.canProcess && U.state === "ready" ? {
							available: !!ee,
							steps: Mi.map((e) => ({
								...e,
								on: rr[e.key],
								disabled: e.needs === "find" && !rr.find || e.needs === "colour" && !(rr.find && rr.colour)
							})),
							setStep: ar,
							report: re,
							recent: {
								runs: Rn,
								open: (e) => void Hn(e)
							},
							found: Qn && {
								identity: Qn.online.identity,
								photos: Qn.online.photos.map((e) => ({
									...e,
									thumb: Qn.thumbs[e.index]
								})),
								ticked: Qn.ticked,
								waiting: !Qn.sent,
								toggle: (e) => $n((t) => t && !t.sent ? {
									...t,
									ticked: t.ticked.includes(e) ? t.ticked.filter((t) => t !== e) : [...t.ticked, e]
								} : t),
								use: () => void tr(Qn.ticked),
								skip: () => void tr([])
							},
							goBack: ae
						} : void 0,
						detail: {
							available: mr && Un === "character",
							on: lr,
							set: dr
						},
						gloss: {
							available: mr,
							on: fr,
							set: pr
						}
					},
					aiEnlarge: /* @__PURE__ */ N(Ht, {
						app: U,
						sharpen: mr ? (e) => U.client.enhance(e, { strength: .25 }) : null,
						getPicture: ln,
						onEnlarged: (e, t) => void un(e, t),
						onRemove: () => t.clearUpscale(),
						applied: Zt && Qt ? { factor: Zt.factor } : null
					}),
					aiFinish: /* @__PURE__ */ N(Gt, {
						app: U,
						applied: !!Qe,
						onRedrawArea: (e, t) => (nn(null), an({
							prompt: e,
							keepShape: t
						})),
						onCancelArea: () => an(null),
						picking: !!rn,
						onRemove: () => t.clearFinish(),
						note: tn,
						busyOutside: $t
					}),
					autoEnhance: Tt,
					onAutoEnhance: Dt,
					aiFill: /* @__PURE__ */ N(Wt, {
						app: U,
						buildInput: (n) => dn(t.document.recipe.words ?? H ?? e, n),
						onFilled: (e, t, n) => void Tn(e, t, n),
						applied: !!Jt,
						busyOutside: kt
					}),
					aiCutout: /* @__PURE__ */ N(Vt, {
						app: U,
						getPhoto: (e) => e === "character" ? he(qt(), t.document) : _e(qt()),
						onMask: St,
						greenBackdrop: ft
					})
				})
			}),
			vr && /* @__PURE__ */ N("div", {
				className: "gs-edit-overlay",
				children: /* @__PURE__ */ N(hi, {
					open: vr,
					title: t.document.source.name?.replace(/\.[^.]+$/, "") || "Design",
					doneLabel: "Use this picture",
					onClose: Dr,
					onDone: (e) => {
						Dr(), w(e);
					}
				})
			}),
			xr && /* @__PURE__ */ N("div", {
				className: "gs-edit-overlay",
				children: /* @__PURE__ */ N(be, {
					fallback: null,
					children: /* @__PURE__ */ N(Ti, {
						picture: xr,
						title: t.document.source.name?.replace(/\.[^.]+$/, "") || "Photo",
						doneLabel: "Use this picture",
						onClose: Er,
						onDone: (e) => {
							Er(), w(e);
						}
					})
				})
			}),
			Cr && /* @__PURE__ */ N(Me, {
				client: U.client,
				onClose: () => wr(!1),
				onOpen: (e) => {
					wr(!1), w(e);
				}
			}),
			De && /* @__PURE__ */ N(E, { onClose: () => ke(!1) })
		]
	});
}
//#endregion
//#region src/GleamEditorModal.tsx
function Fi({ open: e, ...t }) {
	return k(() => {
		if (!e) return;
		let t = document.body.style.overflow;
		return document.body.style.overflow = "hidden", () => {
			document.body.style.overflow = t;
		};
	}, [e]), e ? Te(/* @__PURE__ */ N("div", {
		className: "gs-modal",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Edit photo",
		children: /* @__PURE__ */ N(Ni, { ...t })
	}), document.body) : null;
}
//#endregion
export { hi as EditMode, Ni as GleamEditor, Fi as GleamEditorModal, ye as PhotoLab, me as decodePhoto, ge as fetchPhoto, pe as gpuMaxTextureSize, D as trimTransparent };

//# sourceMappingURL=index.js.map