import { n as e } from "./rolldown-runtime-DArdT4gl.js";
import { C as t, D as n, c as r, m as i, p as a } from "./GleamEditor-DZHrmEmu.js";
/* empty css                 */
import { useEffect as o, useState as s } from "react";
import { Fragment as c, jsx as l, jsxs as u } from "react/jsx-runtime";
//#region src/market/SellMore.tsx
function d() {
	let [e, t] = s(!1), [n, r] = s(null);
	return {
		busy: e,
		error: n,
		run: async (e) => {
			t(!0), r(null);
			try {
				return await e();
			} catch (e) {
				return r(e instanceof Error ? e.message : "Something went wrong."), null;
			} finally {
				t(!1);
			}
		}
	};
}
function f({ label: e, onText: t, hint: n }) {
	return /* @__PURE__ */ u("label", {
		className: "gs-m3d__field",
		children: [/* @__PURE__ */ l("span", { children: e }), /* @__PURE__ */ l("input", {
			type: "file",
			accept: ".csv,.tsv,.txt,text/csv,text/tab-separated-values,text/plain",
			title: n,
			onChange: (e) => {
				let n = e.target.files?.[0];
				if (!n) return t(null);
				n.text().then((e) => t({
					name: n.name,
					text: e
				}));
			}
		})]
	});
}
function p(e, t, n = "application/json") {
	let r = document.createElement("a");
	r.href = URL.createObjectURL(new Blob([t], { type: n })), r.download = e, r.click(), setTimeout(() => URL.revokeObjectURL(r.href), 1e3);
}
function m({ title: e, children: t, onSave: n }) {
	return /* @__PURE__ */ u("section", {
		className: "gs-mk__section",
		children: [/* @__PURE__ */ u("div", {
			className: "gs-mk__copyhead",
			children: [/* @__PURE__ */ l("h4", { children: e }), n && /* @__PURE__ */ l("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: n,
				children: "Save for the site"
			})]
		}), t]
	});
}
var h = (e) => e.toLocaleString("en-US", {
	minimumFractionDigits: 2,
	maximumFractionDigits: 2
});
function g({ app: e }) {
	let [t, n] = s(null), [r, i] = s(null), [a, o] = s(null), { busy: g, error: _, run: v } = d(), y = a ? [...new Set(a.sellers.map((e) => e.category))] : [];
	return /* @__PURE__ */ u(c, { children: [
		/* @__PURE__ */ l(f, {
			label: "Orders file",
			onText: n,
			hint: "An orders export: Shopify, Amazon order report, or any CSV with an order number and a product per line"
		}),
		/* @__PURE__ */ l(f, {
			label: "Stock file (optional)",
			onText: i,
			hint: "A products or inventory export with stock, price, cost and when it was listed"
		}),
		/* @__PURE__ */ l("div", {
			className: "gs-m3d__actions",
			children: /* @__PURE__ */ l("button", {
				type: "button",
				className: "gs-m3d__btn gs-m3d__btn--primary",
				disabled: !t || g,
				onClick: () => void v(() => e.client.market("insights", {
					orders: t.text,
					stock: r?.text
				})).then((e) => e && o(e)),
				children: g ? "Reading the orders…" : "Find what sells"
			})
		}),
		_ && /* @__PURE__ */ l("p", {
			className: "gs-mk__error",
			children: _
		}),
		a && /* @__PURE__ */ u(c, { children: [
			/* @__PURE__ */ u("p", {
				className: "gs-m3d__meta",
				children: [
					a.file.orders,
					" orders, ",
					a.file.lines,
					" lines",
					a.stockFile ? `; ${a.stockFile.items} products in stock` : "",
					"."
				]
			}),
			/* @__PURE__ */ l(m, {
				title: "Frequently bought together",
				onSave: a.together.length ? () => p("bought-together.json", JSON.stringify(a.together, null, 2)) : void 0,
				children: a.together.length ? /* @__PURE__ */ l("ul", {
					className: "gs-mk__list",
					children: a.together.slice(0, 20).map((e) => /* @__PURE__ */ u("li", { children: [
						/* @__PURE__ */ l("strong", { children: e.title }),
						" with",
						" ",
						e.with.map((e) => `${e.title} (${e.together} orders, ${Math.round(e.share * 100)}%)`).join(", ")
					] }, e.key))
				}) : /* @__PURE__ */ l("p", {
					className: "gs-m3d__meta",
					children: "No pairs yet: a pair needs to be in 2 or more orders, more often than chance."
				})
			}),
			/* @__PURE__ */ u(m, {
				title: "Best sellers, last 30 days",
				onSave: a.sellers.length ? () => p("best-sellers.json", JSON.stringify(a.sellers, null, 2)) : void 0,
				children: [y.map((e) => /* @__PURE__ */ u("div", { children: [/* @__PURE__ */ l("p", {
					className: "gs-mk__sub",
					children: e
				}), /* @__PURE__ */ l("ol", {
					className: "gs-mk__list",
					children: a.sellers.filter((t) => t.category === e).slice(0, 5).map((e) => /* @__PURE__ */ u("li", { children: [
						e.title,
						" · ",
						e.units,
						" sold",
						e.trending ? " · selling fast" : ""
					] }, e.key))
				})] }, e)), !y.length && /* @__PURE__ */ l("p", {
					className: "gs-m3d__meta",
					children: "No sales in the last 30 days."
				})]
			}),
			/* @__PURE__ */ l(m, {
				title: "Badges",
				onSave: a.badges.length ? () => p("badges.json", JSON.stringify(a.badges, null, 2)) : void 0,
				children: a.badges.length ? /* @__PURE__ */ l("ul", {
					className: "gs-mk__badges",
					children: a.badges.map((e) => /* @__PURE__ */ u("li", { children: [
						/* @__PURE__ */ l("span", {
							className: `gs-mk__badge is-${e.kind}`,
							children: e.text
						}),
						" ",
						e.title
					] }, `${e.key}${e.kind}`))
				}) : /* @__PURE__ */ l("p", {
					className: "gs-m3d__meta",
					children: "No badges yet: each one has to be true from the files."
				})
			}),
			a.stockFile && /* @__PURE__ */ l(m, {
				title: "Reorder",
				onSave: a.reorders.length ? () => p("reorders.json", JSON.stringify(a.reorders, null, 2)) : void 0,
				children: a.reorders.length ? /* @__PURE__ */ l("div", {
					className: "gs-mk__scroll",
					children: /* @__PURE__ */ u("table", {
						className: "gs-mk__table",
						children: [/* @__PURE__ */ l("thead", { children: /* @__PURE__ */ u("tr", { children: [
							/* @__PURE__ */ l("th", { children: "Product" }),
							/* @__PURE__ */ l("th", { children: "Stock" }),
							/* @__PURE__ */ l("th", { children: "Runs out in" }),
							/* @__PURE__ */ l("th", { children: "Order by" }),
							/* @__PURE__ */ l("th", { children: "Order" }),
							/* @__PURE__ */ l("th", { children: "Why" })
						] }) }), /* @__PURE__ */ l("tbody", { children: a.reorders.map((e) => /* @__PURE__ */ u("tr", { children: [
							/* @__PURE__ */ l("td", { children: e.title }),
							/* @__PURE__ */ l("td", { children: e.stock }),
							/* @__PURE__ */ u("td", { children: [e.daysLeft, " days"] }),
							/* @__PURE__ */ l("td", { children: e.orderBy }),
							/* @__PURE__ */ l("td", { children: e.quantity }),
							/* @__PURE__ */ l("td", { children: e.why })
						] }, e.key)) })]
					})
				}) : /* @__PURE__ */ l("p", {
					className: "gs-m3d__meta",
					children: "Nothing runs out in the next 7 weeks at the pace it sells."
				})
			}),
			a.stockFile && /* @__PURE__ */ l(m, {
				title: "Deals for slow stock",
				onSave: a.deals.length ? () => p("deals.json", JSON.stringify(a.deals, null, 2)) : void 0,
				children: a.deals.length ? /* @__PURE__ */ l("div", {
					className: "gs-mk__scroll",
					children: /* @__PURE__ */ u("table", {
						className: "gs-mk__table",
						children: [/* @__PURE__ */ l("thead", { children: /* @__PURE__ */ u("tr", { children: [
							/* @__PURE__ */ l("th", { children: "Product" }),
							/* @__PURE__ */ l("th", { children: "Stock" }),
							/* @__PURE__ */ l("th", { children: "Price" }),
							/* @__PURE__ */ l("th", { children: "Deal" }),
							/* @__PURE__ */ l("th", { children: "Why" })
						] }) }), /* @__PURE__ */ l("tbody", { children: a.deals.map((e) => /* @__PURE__ */ u("tr", { children: [
							/* @__PURE__ */ l("td", { children: e.title }),
							/* @__PURE__ */ l("td", { children: e.stock }),
							/* @__PURE__ */ l("td", { children: h(e.price) }),
							/* @__PURE__ */ l("td", { children: e.dealPrice === null ? "No room above cost" : `${h(e.dealPrice)} (${e.off}% off)` }),
							/* @__PURE__ */ l("td", { children: e.why })
						] }, e.key)) })]
					})
				}) : /* @__PURE__ */ l("p", {
					className: "gs-m3d__meta",
					children: "Nothing is sitting: every product listed 60 days or more sells within 3 months of stock."
				})
			})
		] })
	] });
}
function _({ app: e, title: t }) {
	let [n, r] = s(null), [i, a] = s(""), [o, h] = s(null), { busy: g, error: _, run: v } = d(), y = (r) => void v(() => e.client.market("reviews", {
		csv: n.text,
		product: i || void 0,
		title: t,
		summary: r
	})).then((e) => e && h(e));
	return /* @__PURE__ */ u(c, { children: [
		/* @__PURE__ */ l(f, {
			label: "Reviews file",
			onText: r,
			hint: "An export from your review app, Amazon, Etsy or a sheet: rating and review text"
		}),
		o && o.products.length > 1 && /* @__PURE__ */ u("label", {
			className: "gs-m3d__field",
			children: [/* @__PURE__ */ l("span", { children: "Product" }), /* @__PURE__ */ u("select", {
				value: i,
				onChange: (e) => a(e.target.value),
				children: [/* @__PURE__ */ l("option", {
					value: "",
					children: "All reviews"
				}), o.products.map((e) => /* @__PURE__ */ l("option", { children: e }, e))]
			})]
		}),
		/* @__PURE__ */ u("div", {
			className: "gs-m3d__actions",
			children: [/* @__PURE__ */ l("button", {
				type: "button",
				className: "gs-m3d__btn",
				disabled: !n || g,
				onClick: () => y(!1),
				children: "Count the stars"
			}), /* @__PURE__ */ l("button", {
				type: "button",
				className: "gs-m3d__btn gs-m3d__btn--primary",
				disabled: !n || g,
				onClick: () => y(!0),
				children: g ? "Reading on this computer…" : "Sum them up"
			})]
		}),
		_ && /* @__PURE__ */ l("p", {
			className: "gs-mk__error",
			children: _
		}),
		o && /* @__PURE__ */ u(c, { children: [
			/* @__PURE__ */ u("p", {
				className: "gs-mk__stars",
				children: [
					/* @__PURE__ */ l("strong", { children: o.average.toFixed(1) }),
					" out of 5 · ",
					o.count,
					" reviews"
				]
			}),
			/* @__PURE__ */ l("div", {
				className: "gs-mk__bars",
				children: [
					5,
					4,
					3,
					2,
					1
				].map((e) => {
					let t = o.stars[e - 1] ?? 0;
					return /* @__PURE__ */ u("div", {
						className: "gs-mk__bar",
						children: [
							/* @__PURE__ */ u("span", { children: [e, " star"] }),
							/* @__PURE__ */ l("span", {
								className: "gs-mk__barline",
								children: /* @__PURE__ */ l("span", { style: { width: `${o.count ? t / o.count * 100 : 0}%` } })
							}),
							/* @__PURE__ */ u("span", { children: [o.count ? Math.round(t / o.count * 100) : 0, "%"] })
						]
					}, e);
				})
			}),
			o.summary && /* @__PURE__ */ u(m, {
				title: "Customers say",
				onSave: () => p("customers-say.json", JSON.stringify({
					average: o.average,
					count: o.count,
					stars: o.stars,
					summary: o.summary,
					themes: o.themes
				}, null, 2)),
				children: [
					/* @__PURE__ */ l("p", { children: o.summary }),
					/* @__PURE__ */ l("ul", {
						className: "gs-mk__list",
						children: o.themes?.map((e) => /* @__PURE__ */ u("li", { children: [
							/* @__PURE__ */ l("span", {
								className: `gs-mk__badge is-${e.tone}`,
								children: e.name
							}),
							" ",
							e.says,
							e.mentions ? ` (about ${e.mentions} reviews)` : "",
							e.quotes.map((e) => /* @__PURE__ */ l("q", {
								className: "gs-mk__quote",
								children: e
							}, e))
						] }, e.name))
					}),
					/* @__PURE__ */ u("p", {
						className: "gs-m3d__meta",
						children: [
							"Written by the model on this computer from these reviews only.",
							o.dropped ? ` ${o.dropped} quotes that were in no review were left out.` : "",
							" Read it before it goes on the site."
						]
					})
				]
			})
		] })
	] });
}
function v({ app: e }) {
	let [t, n] = s(""), [r, i] = s(null), { busy: a, error: o, run: f } = d(), h = t.split("\n").map((e) => e.trim()).filter(Boolean);
	return /* @__PURE__ */ u(c, { children: [
		/* @__PURE__ */ u("label", {
			className: "gs-m3d__field gs-m3d__field--top",
			children: [/* @__PURE__ */ l("span", { children: "Product titles" }), /* @__PURE__ */ l("textarea", {
				rows: 6,
				value: t,
				onChange: (e) => n(e.target.value),
				placeholder: "One a line (paste the title column of a products export)"
			})]
		}),
		/* @__PURE__ */ l("div", {
			className: "gs-m3d__actions",
			children: /* @__PURE__ */ l("button", {
				type: "button",
				className: "gs-m3d__btn gs-m3d__btn--primary",
				disabled: !h.length || a,
				onClick: () => void f(() => e.client.market("synonyms", { titles: h })).then((e) => e && i(e)),
				children: "Find the names"
			})
		}),
		o && /* @__PURE__ */ l("p", {
			className: "gs-mk__error",
			children: o
		}),
		r && /* @__PURE__ */ u(m, {
			title: `${r.groups.length} series, every name`,
			onSave: r.groups.length ? () => p("search-synonyms.txt", r.shopify, "text/plain") : void 0,
			children: [r.groups.length ? /* @__PURE__ */ l("ul", {
				className: "gs-mk__list",
				children: r.groups.map((e) => /* @__PURE__ */ u("li", { children: [
					e.words.join(", "),
					" ",
					/* @__PURE__ */ u("span", {
						className: "gs-m3d__meta",
						children: [
							"(",
							e.products,
							" product",
							e.products === 1 ? "" : "s",
							")"
						]
					})
				] }, e.series))
			}) : /* @__PURE__ */ l("p", {
				className: "gs-m3d__meta",
				children: "None of these titles names a series in the list."
			}), /* @__PURE__ */ l("p", {
				className: "gs-m3d__meta",
				children: "The saved file is one group a line, as Shopify Search & Discovery’s synonyms take them."
			})]
		})
	] });
}
//#endregion
//#region src/market/ImportPlan.tsx
var y = {
	airing: "Airing",
	upcoming: "Upcoming",
	recent: "Figure wave",
	none: "Your seller"
};
function b({ label: e, onText: t, hint: n }) {
	return /* @__PURE__ */ u("label", {
		className: "gs-m3d__field",
		children: [/* @__PURE__ */ l("span", { children: e }), /* @__PURE__ */ l("input", {
			type: "file",
			accept: ".csv,.tsv,.txt,text/csv,text/plain",
			title: n,
			onChange: (e) => {
				let n = e.target.files?.[0];
				if (!n) return t(null);
				n.text().then(t);
			}
		})]
	});
}
function x({ factors: e }) {
	return /* @__PURE__ */ l("ul", {
		className: "gs-mk__factors",
		children: e.map((e) => /* @__PURE__ */ u("li", { children: [
			/* @__PURE__ */ u("span", {
				className: `gs-mk__pts ${e.points < 0 ? "is-minus" : ""}`,
				children: [e.points > 0 ? "+" : "", e.points]
			}),
			" ",
			/* @__PURE__ */ l("strong", { children: e.name }),
			": ",
			e.why
		] }, e.name))
	});
}
function S({ app: e }) {
	let [t, n] = s(null), [r, i] = s(null), [a, o] = s(null), [d, f] = s(""), [p, m] = s(!0), [h, g] = s(!0), [_, v] = s(!1), [S, C] = s(!0), [w, T] = s(!1), [E, D] = s(null), [O, k] = s(null), [A, j] = s(null), M = async () => {
		T(!0), D(null);
		try {
			k(await e.client.market("plan", {
				orders: t,
				stock: r,
				supplier: a,
				trends: p,
				ebay: h,
				brief: _,
				announced: S,
				shippingYen: Number(d) > 0 ? Number(d) : void 0
			}));
		} catch (e) {
			D(e instanceof Error ? e.message : "Something went wrong.");
		} finally {
			T(!1);
		}
	};
	return /* @__PURE__ */ u(c, { children: [
		/* @__PURE__ */ l(b, {
			label: "Orders file",
			onText: n,
			hint: "Your orders export (Shopify, Amazon, any CSV with an order and a product per line)"
		}),
		/* @__PURE__ */ l(b, {
			label: "Stock file",
			onText: i,
			hint: "Optional: your products export with stock, so what you already hold counts against buying more"
		}),
		/* @__PURE__ */ l(b, {
			label: "Supplier list",
			onText: o,
			hint: "Optional: a wholesaler's or shop's list with title, price (yen) and release date; a Canadian price column if you know it"
		}),
		/* @__PURE__ */ u("label", {
			className: "gs-m3d__field",
			children: [/* @__PURE__ */ l("span", { children: "Shipping per item (¥)" }), /* @__PURE__ */ l("input", {
				inputMode: "decimal",
				placeholder: "What your forwarder charges, for the margin",
				value: d,
				onChange: (e) => f(e.target.value)
			})]
		}),
		/* @__PURE__ */ u("label", {
			className: "gs-control gs-control--inline",
			children: [/* @__PURE__ */ l("input", {
				type: "checkbox",
				checked: p,
				onChange: (e) => m(e.target.checked)
			}), "Anime trends from AniList (free, public)"]
		}),
		/* @__PURE__ */ u("label", {
			className: "gs-control gs-control--inline",
			children: [/* @__PURE__ */ l("input", {
				type: "checkbox",
				checked: h,
				onChange: (e) => g(e.target.checked)
			}), "Canadian prices from eBay.ca for the best 10 of the supplier list (your eBay keys)"]
		}),
		/* @__PURE__ */ u("label", {
			className: "gs-control gs-control--inline",
			children: [/* @__PURE__ */ l("input", {
				type: "checkbox",
				checked: S,
				onChange: (e) => C(e.target.checked)
			}), "Figures the makers have announced, from their official sites (free web search; about a minute)"]
		}),
		/* @__PURE__ */ u("label", {
			className: "gs-control gs-control--inline",
			children: [/* @__PURE__ */ l("input", {
				type: "checkbox",
				checked: _,
				onChange: (e) => v(e.target.checked)
			}), "Write a buying brief with the AI on this computer (free; slower)"]
		}),
		/* @__PURE__ */ l("div", {
			className: "gs-m3d__actions",
			children: /* @__PURE__ */ l("button", {
				type: "button",
				className: "gs-m3d__btn gs-m3d__btn--primary",
				disabled: w || !t && !p,
				onClick: () => void M(),
				children: w ? "Weighing everything…" : "Suggest what to import"
			})
		}),
		E && /* @__PURE__ */ l("p", {
			className: "gs-mk__error",
			children: E
		}),
		O && /* @__PURE__ */ u(c, { children: [
			O.trendsError && /* @__PURE__ */ u("p", {
				className: "gs-mk__error",
				children: ["Anime trends: ", O.trendsError]
			}),
			O.notes.map((e) => /* @__PURE__ */ l("p", {
				className: "gs-mk__error",
				children: e
			}, e)),
			O.brief && /* @__PURE__ */ u("section", {
				className: "gs-mk__section",
				children: [
					/* @__PURE__ */ l("h4", { children: "Buying brief" }),
					O.brief.text && /* @__PURE__ */ l("p", {
						className: "gs-mk__brief",
						children: O.brief.text
					}),
					O.brief.flags.length > 0 && /* @__PURE__ */ l("ul", {
						className: "gs-mk__notes",
						children: O.brief.flags.map((e) => /* @__PURE__ */ l("li", { children: e }, e))
					}),
					/* @__PURE__ */ l("p", {
						className: "gs-m3d__meta",
						children: "Written by the model on this computer from the scores below only. Check it against them."
					})
				]
			}),
			O.products.length > 0 && /* @__PURE__ */ u("section", {
				className: "gs-mk__section",
				children: [
					/* @__PURE__ */ l("h4", { children: "What to buy, best first" }),
					/* @__PURE__ */ l("div", {
						className: "gs-mk__scroll",
						children: /* @__PURE__ */ u("table", {
							className: "gs-mk__table",
							children: [/* @__PURE__ */ l("thead", { children: /* @__PURE__ */ u("tr", { children: [
								/* @__PURE__ */ l("th", { children: "Product" }),
								/* @__PURE__ */ l("th", { children: "Verdict" }),
								/* @__PURE__ */ l("th", { children: "Score" }),
								/* @__PURE__ */ l("th", { children: "Landed" }),
								/* @__PURE__ */ l("th", { children: "Sells for" }),
								/* @__PURE__ */ l("th", { children: "Margin" })
							] }) }), /* @__PURE__ */ l("tbody", { children: O.products.slice(0, 40).map((e) => /* @__PURE__ */ u("tr", {
								className: e.verdict === "import" ? "is-good" : "",
								onClick: () => j(A === e.title ? null : e.title),
								children: [
									/* @__PURE__ */ u("td", { children: [
										e.url ? /* @__PURE__ */ l("a", {
											href: e.url,
											target: "_blank",
											rel: "noreferrer",
											onClick: (e) => e.stopPropagation(),
											children: e.title
										}) : e.title,
										e.source === "maker" && /* @__PURE__ */ u("span", {
											className: "gs-m3d__meta",
											children: [
												" ",
												"· announced by ",
												e.maker,
												e.release ? `, out ${e.release}` : ""
											]
										}),
										A === e.title && /* @__PURE__ */ l(x, { factors: e.factors })
									] }),
									/* @__PURE__ */ l("td", { children: /* @__PURE__ */ l("span", {
										className: `gs-mk__badge is-${e.verdict === "import" ? "positive" : e.verdict === "skip" ? "negative" : "mixed"}`,
										children: e.verdict === "import" ? "Import" : e.verdict === "consider" ? "Consider" : "Skip"
									}) }),
									/* @__PURE__ */ l("td", { children: e.score }),
									/* @__PURE__ */ l("td", { children: e.landed === null ? "—" : `CA$${e.landed}` }),
									/* @__PURE__ */ l("td", { children: e.caPrice === null ? "—" : `CA$${e.caPrice}` }),
									/* @__PURE__ */ l("td", { children: e.margin === null ? "—" : `${Math.round(e.margin * 100)}%` })
								]
							}, e.title)) })]
						})
					}),
					/* @__PURE__ */ l("p", {
						className: "gs-m3d__meta",
						children: "Click a product for the reasons behind its score."
					})
				]
			}),
			/* @__PURE__ */ u("section", {
				className: "gs-mk__section",
				children: [/* @__PURE__ */ l("h4", { children: "Series to stock up on" }), /* @__PURE__ */ l("ol", {
					className: "gs-mk__picks",
					children: O.series.slice(0, 15).map((e) => /* @__PURE__ */ u("li", { children: [
						/* @__PURE__ */ u("div", {
							className: "gs-mk__copyhead",
							children: [/* @__PURE__ */ u("span", { children: [
								/* @__PURE__ */ l("strong", { children: e.series }),
								" ",
								/* @__PURE__ */ l("span", {
									className: "gs-mk__badge",
									children: y[e.heat] ?? e.heat
								}),
								e.start && e.heat === "upcoming" ? ` starts ${e.start}` : ""
							] }), /* @__PURE__ */ l("span", {
								className: "gs-mk__pts",
								children: e.score
							})]
						}),
						/* @__PURE__ */ u("p", {
							className: "gs-m3d__meta",
							children: ["Buy: ", e.buy.join(", ") || "what sells for you"]
						}),
						/* @__PURE__ */ l(x, { factors: e.factors })
					] }, e.series))
				})]
			}),
			O.announced.length > 0 && /* @__PURE__ */ u("section", {
				className: "gs-mk__section",
				children: [
					/* @__PURE__ */ l("h4", { children: "Announced by the makers" }),
					/* @__PURE__ */ l("div", {
						className: "gs-mk__scroll",
						children: /* @__PURE__ */ u("table", {
							className: "gs-mk__table",
							children: [/* @__PURE__ */ l("thead", { children: /* @__PURE__ */ u("tr", { children: [
								/* @__PURE__ */ l("th", { children: "Out" }),
								/* @__PURE__ */ l("th", { children: "Series" }),
								/* @__PURE__ */ l("th", { children: "Product" }),
								/* @__PURE__ */ l("th", { children: "Maker" })
							] }) }), /* @__PURE__ */ l("tbody", { children: O.announced.map((e) => /* @__PURE__ */ u("tr", { children: [
								/* @__PURE__ */ l("td", { children: e.when }),
								/* @__PURE__ */ l("td", { children: e.series }),
								/* @__PURE__ */ u("td", { children: [/* @__PURE__ */ l("a", {
									href: e.url,
									target: "_blank",
									rel: "noreferrer",
									children: e.name
								}), e.kind === "goods" ? /* @__PURE__ */ l("span", {
									className: "gs-m3d__meta",
									children: " · goods, not weighed"
								}) : null] }),
								/* @__PURE__ */ l("td", { children: e.maker })
							] }, e.url + e.name)) })]
						})
					}),
					/* @__PURE__ */ l("p", {
						className: "gs-m3d__meta",
						children: "From the makers’ own sites. Prizes have no shop price: add your supplier’s for the margin."
					})
				]
			}),
			O.trends && /* @__PURE__ */ u("section", {
				className: "gs-mk__section",
				children: [/* @__PURE__ */ l("h4", { children: "Anime now and next (AniList)" }), /* @__PURE__ */ l("div", {
					className: "gs-mk__trends",
					children: [
						["Trending now", O.trends.airing.map((e) => ({
							...e,
							when: ""
						}))],
						["Finished lately, figures coming", O.trends.recent.map((e) => ({
							...e,
							when: e.end ? `ended ${e.end}` : ""
						}))],
						["Most anticipated", O.trends.upcoming.map((e) => ({
							...e,
							when: e.start ? `starts ${e.start}` : ""
						}))]
					].map(([e, t]) => /* @__PURE__ */ u("div", { children: [/* @__PURE__ */ l("p", {
						className: "gs-mk__sub",
						children: e
					}), /* @__PURE__ */ l("ol", {
						className: "gs-mk__list",
						children: t.slice(0, 8).map((e) => /* @__PURE__ */ u("li", { children: [
							/* @__PURE__ */ l("a", {
								href: e.url,
								target: "_blank",
								rel: "noreferrer",
								children: e.name
							}),
							" ",
							/* @__PURE__ */ l("span", {
								className: "gs-m3d__meta",
								children: e.when
							})
						] }, e.url))
					})] }, e))
				})]
			})
		] })
	] });
}
//#endregion
//#region src/market/MarketMode.tsx
var C = /* @__PURE__ */ e({ MarketMode: () => H });
function w({ onUse: e, patch: t, label: n = "Use" }) {
	let [r, i] = s(!1);
	return /* @__PURE__ */ l("button", {
		type: "button",
		className: "gs-m3d__btn",
		onClick: () => {
			e(t), i(!0), setTimeout(() => i(!1), 1500);
		},
		children: r ? "Added" : n
	});
}
var T = [
	{
		id: "plan",
		name: "What to import",
		help: "marketPlan"
	},
	{
		id: "comps",
		name: "Sold comps",
		help: "marketComps"
	},
	{
		id: "regions",
		name: "Prices by country",
		help: "marketRegions"
	},
	{
		id: "landed",
		name: "Landed cost",
		help: "marketLanded"
	},
	{
		id: "localise",
		name: "Translate listing",
		help: "marketLocalise"
	},
	{
		id: "bootleg",
		name: "Bootleg check",
		help: "marketBootleg"
	},
	{
		id: "sell",
		name: "Sell more",
		help: "marketSellMore"
	},
	{
		id: "reviews",
		name: "Customers say",
		help: "marketReviews"
	},
	{
		id: "synonyms",
		name: "Search synonyms",
		help: "marketSynonyms"
	}
], E = (e, t) => {
	let n = t === "JPY" || t === "KRW" || t === "IDR", r = {
		CAD: "CA$",
		USD: "US$",
		JPY: "¥",
		EUR: "€",
		GBP: "£",
		AUD: "A$",
		SGD: "S$"
	}, i = Math.abs(e).toLocaleString("en-US", {
		minimumFractionDigits: n ? 0 : 2,
		maximumFractionDigits: n ? 0 : 2
	});
	return `${e < 0 ? "−" : ""}${r[t] ? `${r[t]}${i}` : `${i} ${t}`}`;
}, D = [
	"USD",
	"CAD",
	"JPY",
	"GBP",
	"EUR",
	"AUD",
	"SGD"
];
function O() {
	let [e, t] = s(!1), [n, r] = s(null);
	return {
		busy: e,
		error: n,
		run: async (e) => {
			t(!0), r(null);
			try {
				return await e();
			} catch (e) {
				return r(e instanceof Error ? e.message : "Something went wrong."), null;
			} finally {
				t(!1);
			}
		}
	};
}
function k({ label: e, children: t }) {
	return /* @__PURE__ */ u("label", {
		className: "gs-m3d__field",
		children: [/* @__PURE__ */ l("span", { children: e }), t]
	});
}
function A({ items: e }) {
	let t = e.filter(Boolean);
	return t.length ? /* @__PURE__ */ l("ul", {
		className: "gs-mk__notes",
		children: t.map((e) => /* @__PURE__ */ l("li", { children: e }, e))
	}) : null;
}
var j = {
	sealed: "Sealed / new",
	opened: "Opened, complete",
	"box-damaged": "Box damaged",
	loose: "Loose (no box)",
	unknown: "Condition not given"
};
function M({ app: e, product: t, title: n, code: r, onUse: i }) {
	let [a, o] = s(null), [d, f] = s("USD"), [p, m] = s(!1), [h, g] = s("US"), [_, v] = s(null), { busy: y, error: b, run: x } = O();
	return /* @__PURE__ */ u(c, { children: [
		/* @__PURE__ */ l(k, {
			label: "Sales file",
			children: /* @__PURE__ */ l("input", {
				type: "file",
				accept: ".csv,text/csv,text/tab-separated-values",
				onChange: (e) => void e.target.files?.[0]?.text().then((t) => o({
					name: e.target.files[0].name,
					text: t
				}))
			})
		}),
		/* @__PURE__ */ l(k, {
			label: "Its prices in",
			children: /* @__PURE__ */ l("select", {
				value: d,
				onChange: (e) => f(e.target.value),
				children: D.map((e) => /* @__PURE__ */ l("option", { children: e }, e))
			})
		}),
		/* @__PURE__ */ u("label", {
			className: "gs-control gs-control--inline",
			children: [
				/* @__PURE__ */ l("input", {
					type: "checkbox",
					checked: p,
					onChange: (e) => m(e.target.checked)
				}),
				"Also eBay’s sold prices (last 90 days; needs eBay’s approval of your keys) on",
				/* @__PURE__ */ l("select", {
					value: h,
					onChange: (e) => g(e.target.value),
					disabled: !p,
					children: [
						"US",
						"CA",
						"GB",
						"AU",
						"DE",
						"SG",
						"HK"
					].map((e) => /* @__PURE__ */ l("option", { children: e }, e))
				})
			]
		}),
		/* @__PURE__ */ l("div", {
			className: "gs-m3d__actions",
			children: /* @__PURE__ */ l("button", {
				type: "button",
				className: "gs-m3d__btn gs-m3d__btn--primary",
				disabled: !a && !p || !n || y,
				onClick: () => void x(() => e.client.market("comps", {
					csv: a?.text,
					currency: d,
					ebaySold: p,
					ebayMarket: h,
					title: n,
					code: r || void 0,
					identity: t?.identity,
					home: "CAD"
				})).then((e) => e && v(e)),
				children: y ? "Reading the sales…" : "Find this product’s sales"
			})
		}),
		b && /* @__PURE__ */ l("p", {
			className: "gs-mk__error",
			children: b
		}),
		_ && /* @__PURE__ */ u(c, { children: [
			/* @__PURE__ */ u("p", {
				className: "gs-m3d__meta",
				children: [
					_.sales.length,
					" of ",
					_.file.rows,
					" sales are this product (matched by",
					" ",
					_.matchedBy === "code" ? "barcode" : _.matchedBy === "both" ? "barcode and title" : "title",
					").",
					_.file.notSold ? ` ${_.file.notSold} cancelled, refunded or pending orders left out.` : "",
					_.ebay && !_.ebay.error ? ` ${_.ebay.count} sold listings from eBay.` : ""
				]
			}),
			_.ebay?.error && /* @__PURE__ */ l("p", {
				className: "gs-mk__error",
				children: _.ebay.error
			}),
			/* @__PURE__ */ l("div", {
				className: "gs-mk__scroll",
				children: /* @__PURE__ */ u("table", {
					className: "gs-mk__table",
					children: [/* @__PURE__ */ l("thead", { children: /* @__PURE__ */ u("tr", { children: [
						/* @__PURE__ */ l("th", { children: "Condition" }),
						/* @__PURE__ */ l("th", { children: "Sales" }),
						/* @__PURE__ */ l("th", { children: "Range" }),
						/* @__PURE__ */ l("th", { children: "Median" }),
						/* @__PURE__ */ l("th", { children: "Days to sell" }),
						/* @__PURE__ */ l("th", { children: "Last 30 days" }),
						/* @__PURE__ */ l("th", { children: "List at" })
					] }) }), /* @__PURE__ */ l("tbody", { children: _.grades.map((e) => {
						let t = _.suggestions[e.grade];
						return /* @__PURE__ */ u("tr", { children: [
							/* @__PURE__ */ l("td", { children: j[e.grade] ?? e.grade }),
							/* @__PURE__ */ l("td", { children: e.count }),
							/* @__PURE__ */ u("td", { children: [
								E(e.low, _.currency),
								" – ",
								E(e.high, _.currency)
							] }),
							/* @__PURE__ */ l("td", { children: /* @__PURE__ */ l("strong", { children: E(e.median, _.currency) }) }),
							/* @__PURE__ */ l("td", { children: e.daysToSell ?? "—" }),
							/* @__PURE__ */ l("td", { children: e.trend === null ? "—" : `${e.trend >= 1 ? "+" : ""}${Math.round((e.trend - 1) * 100)}%` }),
							/* @__PURE__ */ u("td", {
								title: t?.why,
								children: [t ? `${E(t.price, _.currency)}${t.from === "rule" ? " *" : ""}` : "—", t && i && /* @__PURE__ */ u(c, { children: [" ", /* @__PURE__ */ l(w, {
									onUse: i,
									patch: { price: {
										amount: t.price,
										currency: _.currency,
										grade: e.grade,
										why: t.why
									} }
								})] })]
							})
						] }, e.grade);
					}) })]
				})
			}),
			/* @__PURE__ */ l(A, { items: [
				Object.values(_.suggestions).some((e) => e?.from === "rule") ? "* A rule of thumb from the sealed price: too few sales of that condition." : null,
				_.note,
				_.rateIsEstimate ? "Exchange rates are rough estimates (offline)." : null
			] })
		] })
	] });
}
function N({ app: e, product: t, title: n }) {
	let [r, i] = s({ JP: "" }), [a, o] = s("ebay"), [d, f] = s(null), [p, m] = s(null), { busy: h, error: g, run: _ } = O(), v = Object.fromEntries(Object.entries(r).flatMap(([e, t]) => Number(t) > 0 ? [[e, Number(t)]] : []));
	return /* @__PURE__ */ u(c, { children: [
		/* @__PURE__ */ l(k, {
			label: "Ship from Japan (¥)",
			children: /* @__PURE__ */ l("input", {
				inputMode: "decimal",
				placeholder: "What you pay a forwarder per item",
				value: r.JP,
				onChange: (e) => i({
					...r,
					JP: e.target.value
				})
			})
		}),
		/* @__PURE__ */ l(k, {
			label: "Sell on",
			children: /* @__PURE__ */ u("select", {
				value: a,
				onChange: (e) => o(e.target.value),
				children: [
					/* @__PURE__ */ l("option", {
						value: "ebay",
						children: "eBay"
					}),
					/* @__PURE__ */ l("option", {
						value: "shopify",
						children: "Your shop (Shopify)"
					}),
					/* @__PURE__ */ l("option", {
						value: "instore",
						children: "In store"
					}),
					/* @__PURE__ */ l("option", {
						value: "amazon",
						children: "Amazon"
					})
				]
			})
		}),
		/* @__PURE__ */ l("div", {
			className: "gs-m3d__actions",
			children: /* @__PURE__ */ l("button", {
				type: "button",
				className: "gs-m3d__btn gs-m3d__btn--primary",
				disabled: !n || h,
				onClick: () => void _(() => e.client.market("regions", {
					title: n,
					identity: t?.identity,
					home: "CA",
					marketplace: a,
					shipping: v
				})).then((e) => e && f(e)),
				children: h ? "Looking in each country…" : "Compare countries"
			})
		}),
		g && /* @__PURE__ */ l("p", {
			className: "gs-mk__error",
			children: g
		}),
		d && /* @__PURE__ */ u(c, { children: [
			/* @__PURE__ */ l("div", {
				className: "gs-mk__scroll",
				children: /* @__PURE__ */ u("table", {
					className: "gs-mk__table",
					children: [/* @__PURE__ */ l("thead", { children: /* @__PURE__ */ u("tr", { children: [
						/* @__PURE__ */ l("th", { children: "Country" }),
						/* @__PURE__ */ l("th", { children: "Listings" }),
						/* @__PURE__ */ l("th", { children: "Median there" }),
						/* @__PURE__ */ u("th", { children: ["In ", d.home] }),
						/* @__PURE__ */ l("th", {})
					] }) }), /* @__PURE__ */ l("tbody", { children: d.regions.map((e) => /* @__PURE__ */ u("tr", { children: [
						/* @__PURE__ */ l("td", { children: e.name }),
						/* @__PURE__ */ l("td", { children: e.count }),
						/* @__PURE__ */ l("td", { children: E(e.median, e.currency) }),
						/* @__PURE__ */ l("td", { children: /* @__PURE__ */ l("strong", { children: E(e.medianHome, d.home) }) }),
						/* @__PURE__ */ l("td", { children: /* @__PURE__ */ l("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: () => m(p === e.region ? null : e.region),
							children: p === e.region ? "Hide" : "Listings"
						}) })
					] }, e.region)) })]
				})
			}),
			d.regions.filter((e) => e.region === p).map((e) => /* @__PURE__ */ l("ul", {
				className: "gs-mk__list",
				children: e.listings.map((t) => /* @__PURE__ */ u("li", { children: [
					/* @__PURE__ */ l("a", {
						href: t.url,
						target: "_blank",
						rel: "noreferrer",
						children: t.title
					}),
					" ",
					/* @__PURE__ */ u("span", {
						className: "gs-m3d__meta",
						children: [
							t.site,
							" · ",
							E(t.price, e.currency)
						]
					})
				] }, t.url))
			}, e.region)),
			d.opportunities.length > 0 && /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("h4", { children: "Buy there, sell here" }), /* @__PURE__ */ l("div", {
				className: "gs-mk__scroll",
				children: /* @__PURE__ */ u("table", {
					className: "gs-mk__table",
					children: [/* @__PURE__ */ l("thead", { children: /* @__PURE__ */ u("tr", { children: [
						/* @__PURE__ */ l("th", { children: "Buy in" }),
						/* @__PURE__ */ l("th", { children: "Landed" }),
						/* @__PURE__ */ l("th", { children: "You keep" }),
						/* @__PURE__ */ l("th", { children: "Profit" }),
						/* @__PURE__ */ l("th", { children: "Margin" })
					] }) }), /* @__PURE__ */ l("tbody", { children: d.opportunities.map((e) => /* @__PURE__ */ u("tr", {
						className: e.alert ? "is-good" : "",
						children: [
							/* @__PURE__ */ l("td", { children: d.regions.find((t) => t.region === e.buy)?.name ?? e.buy }),
							/* @__PURE__ */ l("td", { children: E(e.landed, d.home) }),
							/* @__PURE__ */ l("td", { children: E(e.net, d.home) }),
							/* @__PURE__ */ l("td", { children: E(e.profit, d.home) }),
							/* @__PURE__ */ u("td", { children: [/* @__PURE__ */ u("strong", { children: [Math.round(e.margin * 100), "%"] }), e.alert && " · worth a look"] })
						]
					}, e.buy)) })]
				})
			})] }),
			/* @__PURE__ */ l(A, { items: [
				"Asking prices of new items, not sold prices. A margin is only worth a look with 3 or more listings on both sides and your real shipping cost.",
				...d.missing.map((e) => `${e.region}: ${e.why}`),
				d.rateIsEstimate ? "Exchange rates are rough estimates (offline)." : null
			] })
		] })
	] });
}
function P({ app: e }) {
	let [t, n] = s(null), [r, i] = s({
		price: "",
		currency: "JPY",
		from: "JP",
		to: "CA",
		shipping: "",
		serviceFee: "",
		sellPrice: "",
		marketplace: "ebay",
		shippingCost: "",
		fulfilmentFee: ""
	}), [a, d] = s(!1), [f, p] = s(null), { busy: m, error: h, run: g } = O();
	o(() => {
		e.client.marketRules().then(n).catch(() => n(null));
	}, [e.client]);
	let _ = (e) => (t) => i({
		...r,
		[e]: t.target.value
	}), v = (e) => Number(e) > 0 ? Number(e) : void 0, y = t?.rules.destinations[r.to];
	return /* @__PURE__ */ u(c, { children: [
		/* @__PURE__ */ u("div", {
			className: "gs-mk__two",
			children: [
				/* @__PURE__ */ l(k, {
					label: "Price",
					children: /* @__PURE__ */ l("input", {
						inputMode: "decimal",
						value: r.price,
						onChange: _("price")
					})
				}),
				/* @__PURE__ */ l(k, {
					label: "In",
					children: /* @__PURE__ */ l("select", {
						value: r.currency,
						onChange: _("currency"),
						children: D.map((e) => /* @__PURE__ */ l("option", { children: e }, e))
					})
				}),
				/* @__PURE__ */ l(k, {
					label: "Bought in",
					children: /* @__PURE__ */ u("select", {
						value: r.from,
						onChange: _("from"),
						children: [(t?.regions ?? [{
							id: "JP",
							name: "Japan"
						}]).map((e) => /* @__PURE__ */ l("option", {
							value: e.id,
							children: e.name
						}, e.id)), /* @__PURE__ */ l("option", {
							value: "CN",
							children: "China"
						})]
					})
				}),
				/* @__PURE__ */ l(k, {
					label: "Lands in",
					children: /* @__PURE__ */ l("select", {
						value: r.to,
						onChange: _("to"),
						children: Object.entries(t?.rules.destinations ?? { CA: { name: "Canada" } }).map(([e, t]) => /* @__PURE__ */ l("option", {
							value: e,
							children: t.name
						}, e))
					})
				}),
				/* @__PURE__ */ l(k, {
					label: "Shipping",
					children: /* @__PURE__ */ l("input", {
						inputMode: "decimal",
						placeholder: `International, in ${r.currency}`,
						value: r.shipping,
						onChange: _("shipping")
					})
				}),
				/* @__PURE__ */ l(k, {
					label: "Proxy fee",
					children: /* @__PURE__ */ l("input", {
						inputMode: "decimal",
						placeholder: `In ${r.currency}`,
						value: r.serviceFee,
						onChange: _("serviceFee")
					})
				}),
				/* @__PURE__ */ l(k, {
					label: "Sell for",
					children: /* @__PURE__ */ l("input", {
						inputMode: "decimal",
						placeholder: y ? `In ${y.currency}` : "",
						value: r.sellPrice,
						onChange: _("sellPrice")
					})
				}),
				/* @__PURE__ */ l(k, {
					label: "Sell on",
					children: /* @__PURE__ */ l("select", {
						value: r.marketplace,
						onChange: _("marketplace"),
						children: Object.entries(t?.rules.marketplaces ?? { ebay: { name: "eBay" } }).map(([e, t]) => /* @__PURE__ */ l("option", {
							value: e,
							children: t.name
						}, e))
					})
				}),
				/* @__PURE__ */ l(k, {
					label: "Your shipping",
					children: /* @__PURE__ */ l("input", {
						inputMode: "decimal",
						placeholder: "To the buyer, if you pay it",
						value: r.shippingCost,
						onChange: _("shippingCost")
					})
				}),
				r.marketplace === "amazon" && /* @__PURE__ */ l(k, {
					label: "FBA fee",
					children: /* @__PURE__ */ l("input", {
						inputMode: "decimal",
						placeholder: "Per item, from Amazon’s revenue calculator",
						value: r.fulfilmentFee,
						onChange: _("fulfilmentFee")
					})
				})
			]
		}),
		r.marketplace === "amazon" && /* @__PURE__ */ u("label", {
			className: "gs-control gs-control--inline",
			children: [/* @__PURE__ */ l("input", {
				type: "checkbox",
				checked: a,
				onChange: (e) => d(e.target.checked)
			}), "Individual plan (a fee per item instead of the monthly Professional plan)"]
		}),
		/* @__PURE__ */ l("div", {
			className: "gs-m3d__actions",
			children: /* @__PURE__ */ l("button", {
				type: "button",
				className: "gs-m3d__btn gs-m3d__btn--primary",
				disabled: !v(r.price) || m,
				onClick: () => void g(() => e.client.market("landed", {
					price: v(r.price),
					currency: r.currency,
					from: r.from,
					to: r.to,
					shipping: r.shipping === "" ? void 0 : Number(r.shipping),
					serviceFee: v(r.serviceFee),
					sellPrice: v(r.sellPrice),
					marketplace: r.marketplace,
					shippingCost: v(r.shippingCost),
					...r.marketplace === "amazon" ? {
						fulfilmentFee: v(r.fulfilmentFee),
						noPlan: a
					} : {}
				})).then((e) => e && p(e)),
				children: "Work it out"
			})
		}),
		h && /* @__PURE__ */ l("p", {
			className: "gs-mk__error",
			children: h
		}),
		f && /* @__PURE__ */ u("div", {
			className: "gs-mk__sums",
			children: [
				/* @__PURE__ */ l(F, {
					title: "Landed cost",
					lines: f.landed.lines,
					total: f.landed.total,
					currency: f.landed.currency
				}),
				f.sale && /* @__PURE__ */ l(F, {
					title: "After selling",
					lines: f.sale.lines,
					total: f.sale.net,
					currency: f.sale.currency,
					totalLabel: "You keep"
				}),
				f.profit !== void 0 && /* @__PURE__ */ u("p", {
					className: `gs-mk__profit ${f.profit >= 0 ? "is-good" : "is-bad"}`,
					children: [
						f.profit >= 0 ? "Profit" : "Loss",
						" ",
						E(Math.abs(f.profit), f.landed.currency),
						" · margin",
						" ",
						Math.round((f.margin ?? 0) * 100),
						"%"
					]
				}),
				/* @__PURE__ */ l(A, { items: f.landed.notes })
			]
		})
	] });
}
function F({ title: e, lines: t, total: n, currency: r, totalLabel: i = "Total" }) {
	return /* @__PURE__ */ l("div", {
		className: "gs-mk__scroll",
		children: /* @__PURE__ */ u("table", {
			className: "gs-mk__table gs-mk__lines",
			children: [/* @__PURE__ */ l("caption", { children: e }), /* @__PURE__ */ u("tbody", { children: [t.map((e) => /* @__PURE__ */ u("tr", { children: [/* @__PURE__ */ l("td", { children: e.label }), /* @__PURE__ */ l("td", { children: E(e.amount, r) })] }, e.label)), /* @__PURE__ */ u("tr", {
				className: "is-total",
				children: [/* @__PURE__ */ l("td", { children: i }), /* @__PURE__ */ l("td", { children: E(n, r) })]
			})] })]
		})
	});
}
var I = [
	["ja", "Japanese"],
	["en", "English"],
	["zh", "Chinese (simplified)"],
	["zh-Hant", "Chinese (traditional)"],
	["ko", "Korean"],
	["th", "Thai"],
	["id", "Indonesian"],
	["vi", "Vietnamese"],
	["tl", "Filipino"],
	["fr", "French"],
	["de", "German"],
	["es", "Spanish"]
];
function L({ app: e, product: t, title: n, onUse: r }) {
	let [i, a] = s(t?.listing?.description ?? ""), [o, d] = s("ja"), [f, p] = s("mercari"), [m, h] = s("sealed"), [g, _] = s(null), { busy: v, error: y, run: b } = O();
	return /* @__PURE__ */ u(c, { children: [
		/* @__PURE__ */ u("label", {
			className: "gs-m3d__field gs-m3d__field--top",
			children: [/* @__PURE__ */ l("span", { children: "Description" }), /* @__PURE__ */ l("textarea", {
				rows: 5,
				value: i,
				onChange: (e) => a(e.target.value)
			})]
		}),
		/* @__PURE__ */ u("div", {
			className: "gs-mk__two",
			children: [
				/* @__PURE__ */ l(k, {
					label: "Into",
					children: /* @__PURE__ */ l("select", {
						value: o,
						onChange: (e) => d(e.target.value),
						children: I.map(([e, t]) => /* @__PURE__ */ l("option", {
							value: e,
							children: t
						}, e))
					})
				}),
				/* @__PURE__ */ l(k, {
					label: "For",
					children: /* @__PURE__ */ u("select", {
						value: f,
						onChange: (e) => p(e.target.value),
						children: [
							/* @__PURE__ */ l("option", {
								value: "mercari",
								children: "Mercari (40)"
							}),
							/* @__PURE__ */ l("option", {
								value: "ebay",
								children: "eBay (80)"
							}),
							/* @__PURE__ */ l("option", {
								value: "shopee",
								children: "Shopee (120)"
							}),
							/* @__PURE__ */ l("option", {
								value: "amazon",
								children: "Amazon (title, bullets, search terms)"
							}),
							/* @__PURE__ */ l("option", {
								value: "lazada",
								children: "Lazada"
							}),
							/* @__PURE__ */ l("option", {
								value: "shopify",
								children: "Your shop"
							})
						]
					})
				}),
				/* @__PURE__ */ l(k, {
					label: "Condition",
					children: /* @__PURE__ */ l("select", {
						value: m,
						onChange: (e) => h(e.target.value),
						children: Object.entries(j).filter(([e]) => e !== "unknown").map(([e, t]) => /* @__PURE__ */ l("option", {
							value: e,
							children: t
						}, e))
					})
				})
			]
		}),
		/* @__PURE__ */ l("div", {
			className: "gs-m3d__actions",
			children: /* @__PURE__ */ l("button", {
				type: "button",
				className: "gs-m3d__btn gs-m3d__btn--primary",
				disabled: !n || v,
				onClick: () => void b(() => e.client.market("localise", {
					listing: {
						title: n,
						description: i
					},
					to: o,
					marketplace: f,
					grade: m,
					identity: t?.identity
				})).then((e) => e && _(e)),
				children: v ? "Translating on this computer…" : "Translate"
			})
		}),
		y && /* @__PURE__ */ l("p", {
			className: "gs-mk__error",
			children: y
		}),
		g && /* @__PURE__ */ u("div", {
			className: "gs-mk__out",
			children: [
				r && /* @__PURE__ */ l("div", {
					className: "gs-m3d__actions",
					children: /* @__PURE__ */ l(w, {
						onUse: r,
						label: "Use in the listing",
						patch: {
							title: g.title,
							description: g.description,
							bullets: g.bullets,
							searchTerms: g.searchTerms,
							language: o,
							marketplace: f
						}
					})
				}),
				/* @__PURE__ */ l(R, {
					label: "Title",
					text: g.title
				}),
				g.bullets && /* @__PURE__ */ l(R, {
					label: "Bullet points",
					text: g.bullets.map((e) => `• ${e}`).join("\n")
				}),
				/* @__PURE__ */ l(R, {
					label: "Description",
					text: g.description
				}),
				g.searchTerms && /* @__PURE__ */ l(R, {
					label: "Search terms",
					text: g.searchTerms
				}),
				g.rules.length > 0 && /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("h4", { children: "Against Amazon’s rules" }), /* @__PURE__ */ l(A, { items: g.rules })] }),
				/* @__PURE__ */ l(A, { items: [
					g.shortened ? "The title was cut to the marketplace’s length: check it still reads well." : null,
					g.names.length ? `Names used: ${g.names.join(", ")}.` : null,
					...g.flags,
					"Read it over before posting: the translation is the local model’s."
				] })
			]
		})
	] });
}
function R({ label: e, text: t }) {
	let [n, r] = s(!1);
	return /* @__PURE__ */ u("div", {
		className: "gs-mk__copy",
		children: [/* @__PURE__ */ u("div", {
			className: "gs-mk__copyhead",
			children: [/* @__PURE__ */ l("h4", { children: e }), /* @__PURE__ */ l("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => void navigator.clipboard.writeText(t).then(() => {
					r(!0), setTimeout(() => r(!1), 1500);
				}),
				children: n ? "Copied" : "Copy"
			})]
		}), /* @__PURE__ */ l("p", { children: t })]
	});
}
var z = {
	matches: "Nothing stood out",
	check: "Some points to check",
	differs: "Differs from the official photo",
	"cannot-compare": "Could not compare"
};
function B({ label: e, value: t, onChange: n }) {
	let [r, i] = s(null);
	return o(() => {
		if (!t) return i(null);
		let e = URL.createObjectURL(t);
		return i(e), () => URL.revokeObjectURL(e);
	}, [t]), /* @__PURE__ */ u("label", {
		className: "gs-mk__pic",
		children: [
			/* @__PURE__ */ l("span", { children: e }),
			r ? /* @__PURE__ */ l("img", {
				src: r,
				alt: e
			}) : /* @__PURE__ */ l("span", {
				className: "gs-mk__picempty",
				children: "Choose a photo"
			}),
			/* @__PURE__ */ l("input", {
				type: "file",
				accept: "image/*",
				onChange: (e) => n(e.target.files?.[0] ?? null)
			})
		]
	});
}
function V({ app: e, photo: t }) {
	let [n, r] = s(t ?? null), [i, a] = s(null), [o, d] = s(!0), [f, p] = s(null), { busy: m, error: h, run: g } = O();
	return /* @__PURE__ */ u(c, { children: [
		/* @__PURE__ */ u("div", {
			className: "gs-mk__pics",
			children: [/* @__PURE__ */ l(B, {
				label: "Photo to check",
				value: n,
				onChange: r
			}), /* @__PURE__ */ l(B, {
				label: "Maker’s official photo",
				value: i,
				onChange: a
			})]
		}),
		/* @__PURE__ */ u("label", {
			className: "gs-control gs-control--inline",
			children: [/* @__PURE__ */ l("input", {
				type: "checkbox",
				checked: o,
				onChange: (e) => d(e.target.checked)
			}), "Also ask the vision model on this computer (slower)"]
		}),
		/* @__PURE__ */ l("div", {
			className: "gs-m3d__actions",
			children: /* @__PURE__ */ l("button", {
				type: "button",
				className: "gs-m3d__btn gs-m3d__btn--primary",
				disabled: !n || !i || m,
				onClick: () => void g(() => e.client.bootlegCheck(n, i, { model: o })).then((e) => e && p(e)),
				children: m ? "Comparing…" : "Compare"
			})
		}),
		h && /* @__PURE__ */ l("p", {
			className: "gs-mk__error",
			children: h
		}),
		f && /* @__PURE__ */ u(c, { children: [
			/* @__PURE__ */ l("p", {
				className: `gs-mk__verdict is-${f.verdict}`,
				children: z[f.verdict]
			}),
			f.map && /* @__PURE__ */ l("img", {
				className: "gs-mk__map",
				src: f.map,
				alt: "The photo with the squares that differ outlined"
			}),
			/* @__PURE__ */ l(A, { items: f.points })
		] })
	] });
}
function H({ onClose: e, title: o = "Market", product: c, photo: d, onUse: f }) {
	let p = t(), [m, h] = s("plan"), [y, b] = s(c?.title ?? c?.listing?.title ?? ""), [x, C] = s(c?.code ?? ""), w = T.find((e) => e.id === m), E = p.state === "ready" && p.canMarket;
	return /* @__PURE__ */ u("div", {
		className: "gs-m3d gs-mk",
		children: [/* @__PURE__ */ u("header", {
			className: "gs-m3d__top",
			children: [
				/* @__PURE__ */ l("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: e,
					children: "← Back"
				}),
				/* @__PURE__ */ l("strong", {
					className: "gs-m3d__title",
					children: o
				}),
				/* @__PURE__ */ l("span", { className: "gs-m3d__spacer" }),
				/* @__PURE__ */ l(a, {})
			]
		}), /* @__PURE__ */ u("div", {
			className: "gs-mk__body",
			children: [/* @__PURE__ */ l("aside", {
				className: "gs-m3d__left",
				"aria-label": "Market tools",
				children: /* @__PURE__ */ u("div", {
					className: "gs-m3d__panel",
					children: [
						/* @__PURE__ */ u("section", { children: [
							/* @__PURE__ */ l("h4", { children: "Product" }),
							/* @__PURE__ */ u("label", {
								className: "gs-mk__stack",
								children: [/* @__PURE__ */ l("span", { children: "Title" }), /* @__PURE__ */ l("input", {
									value: y,
									onChange: (e) => b(e.target.value),
									placeholder: "Rem Relax time Figure (Re:Zero)"
								})]
							}),
							/* @__PURE__ */ u("label", {
								className: "gs-mk__stack",
								children: [/* @__PURE__ */ l("span", { children: "Barcode (JAN / UPC)" }), /* @__PURE__ */ l("input", {
									value: x,
									inputMode: "numeric",
									onChange: (e) => C(e.target.value),
									placeholder: "Optional"
								})]
							})
						] }),
						/* @__PURE__ */ u("section", { children: [/* @__PURE__ */ l("h4", { children: "Tools" }), /* @__PURE__ */ l("nav", {
							className: "gs-mk__tabs",
							children: T.map((e) => /* @__PURE__ */ l("button", {
								type: "button",
								className: `gs-m3d__btn ${e.id === m ? "is-on" : ""}`,
								"aria-pressed": e.id === m,
								onClick: () => h(e.id),
								children: e.name
							}, e.id))
						})] }),
						/* @__PURE__ */ l(i, { id: "market" })
					]
				})
			}), /* @__PURE__ */ u("main", {
				className: "gs-mk__main",
				children: [
					/* @__PURE__ */ l("h3", { children: w.name }),
					/* @__PURE__ */ l(i, { id: w.help }),
					E ? m === "comps" ? /* @__PURE__ */ l(M, {
						app: p,
						product: c,
						title: y,
						code: x,
						onUse: f
					}) : m === "regions" ? /* @__PURE__ */ l(N, {
						app: p,
						product: c,
						title: y
					}) : m === "landed" ? /* @__PURE__ */ l(P, { app: p }) : m === "localise" ? /* @__PURE__ */ l(L, {
						app: p,
						product: c,
						title: y,
						onUse: f
					}) : m === "plan" ? /* @__PURE__ */ l(S, { app: p }) : m === "sell" ? /* @__PURE__ */ l(g, { app: p }) : m === "reviews" ? /* @__PURE__ */ l(_, {
						app: p,
						title: y
					}) : m === "synonyms" ? /* @__PURE__ */ l(v, { app: p }) : /* @__PURE__ */ l(V, {
						app: p,
						photo: d
					}) : p.state === "ready" ? /* @__PURE__ */ u("p", {
						className: "gs-mk__error",
						children: [
							"The Gleamshelf app on this computer is older than these tools: update it and start it again (",
							n.start,
							")."
						]
					}) : /* @__PURE__ */ l(r, {
						app: p,
						what: {
							intro: "These tools run on this computer, for free.",
							install: n.start
						}
					})
				]
			})]
		})]
	});
}
//#endregion
export { C as n, H as t };

//# sourceMappingURL=MarketMode-C0s06jkE.js.map