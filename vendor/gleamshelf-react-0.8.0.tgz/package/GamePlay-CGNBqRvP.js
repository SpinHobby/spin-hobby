import { m as e } from "./GleamEditor-DZHrmEmu.js";
import { f as t } from "./src-Bvmr4r-R.js";
import { En as n, Tn as r } from "./document-CNMOilB9.js";
import { at as i, ct as a, ft as o, it as s, lt as c, mt as l, n as u, ot as d, pt as f, st as p, ut as m } from "./core-D8A0dBq3.js";
import { useEffect as h, useMemo as g, useRef as _, useState as v } from "react";
import { jsx as y, jsxs as b } from "react/jsx-runtime";
//#region src/model3d/StorySections.tsx
var x = (e) => Math.round(e * 100) / 100, S = (e, t) => {
	for (let n = t.length + 1;; n++) if (!t.some((t) => t.id === `${e}${n}`)) return `${e}${n}`;
}, C = 360, w = (e) => `${(Math.max(0, Math.min(1, (e - C) / 960)) * 100).toFixed(2)}%`;
function T({ label: e, value: t, onChange: n }) {
	let [r, o] = v(null);
	return /* @__PURE__ */ y("input", {
		"aria-label": e,
		className: "gs-m3d__time",
		value: r ?? i(t),
		onChange: (e) => o(e.target.value),
		onBlur: () => {
			let e = r === null ? null : a(r);
			e !== null && n(e), o(null);
		}
	});
}
function E({ game: t, put: n, shapes: r, spots: a }) {
	let [o, c] = v(null), l = t.actors ?? [], u = t.clock ?? s, d = (e) => r.find((t) => t.id === e.shape)?.label ?? e.character, f = (e, r, i) => n({
		...t,
		actors: l.map((t) => t.shape === e ? {
			...t,
			routine: r.length ? r : void 0
		} : t)
	}, i);
	return /* @__PURE__ */ b("section", { children: [
		/* @__PURE__ */ y("h4", { children: "Routines" }),
		/* @__PURE__ */ y(e, { id: "m3dRoutine" }),
		/* @__PURE__ */ b("div", {
			className: "gs-m3d__game-ruletools",
			children: [/* @__PURE__ */ b("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ y("span", { children: "Day starts" }), /* @__PURE__ */ y(T, {
					label: "When the level's day starts",
					value: u.start,
					onChange: (e) => n({
						...t,
						clock: {
							...u,
							start: e
						}
					}, "Day starts")
				})]
			}), /* @__PURE__ */ b("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ y("span", { children: "A minute is" }), /* @__PURE__ */ y("input", {
					type: "number",
					"aria-label": "Seconds a game minute takes",
					min: .05,
					max: 60,
					step: .05,
					value: x(1 / u.minutesPerSecond),
					onChange: (e) => {
						let r = Number(e.target.value);
						r > 0 && n({
							...t,
							clock: {
								...u,
								minutesPerSecond: 1 / r
							}
						}, "Clock speed");
					}
				})]
			})]
		}),
		!l.length && /* @__PURE__ */ y("p", {
			className: "gs-m3d__note",
			children: "Place a character in this level first."
		}),
		/* @__PURE__ */ y("ul", {
			className: "gs-m3d__routines",
			children: l.map((e) => /* @__PURE__ */ b("li", { children: [
				/* @__PURE__ */ y("button", {
					type: "button",
					className: "gs-m3d__routine-name",
					"aria-expanded": o === e.shape,
					onClick: () => c(o === e.shape ? null : e.shape),
					children: d(e)
				}),
				/* @__PURE__ */ y("div", {
					className: "gs-m3d__routine-bar",
					role: "img",
					"aria-label": `${d(e)}'s day`,
					children: (e.routine ?? []).map((e, t) => /* @__PURE__ */ y("i", {
						style: {
							left: w(e.from),
							right: `calc(100% - ${w(e.to)})`
						},
						title: `${i(e.from)}-${i(e.to)} ${a.find((t) => t.id === e.spot)?.label ?? ""}`
					}, t))
				}),
				o === e.shape && /* @__PURE__ */ b("div", {
					className: "gs-m3d__routine-blocks",
					children: [(e.routine ?? []).map((t, n) => {
						let r = (t) => f(e.shape, e.routine.map((e, r) => r === n ? {
							...e,
							...t
						} : e), "Change routine");
						return /* @__PURE__ */ b("div", {
							className: "gs-m3d__routine-block",
							children: [
								/* @__PURE__ */ y(T, {
									label: "From",
									value: t.from,
									onChange: (e) => r({ from: e })
								}),
								/* @__PURE__ */ y(T, {
									label: "To",
									value: t.to,
									onChange: (e) => r({ to: e })
								}),
								/* @__PURE__ */ b("select", {
									"aria-label": "Goes to",
									value: t.spot,
									onChange: (e) => r({ spot: e.target.value }),
									children: [!a.some((e) => e.id === t.spot) && /* @__PURE__ */ y("option", {
										value: t.spot,
										children: "(no longer here)"
									}), a.map((e) => /* @__PURE__ */ y("option", {
										value: e.id,
										children: e.label
									}, e.id))]
								}),
								/* @__PURE__ */ y("button", {
									type: "button",
									"aria-label": "Remove this block",
									onClick: () => f(e.shape, e.routine.filter((e, t) => t !== n), "Remove from routine"),
									children: "✕"
								})
							]
						}, n);
					}), /* @__PURE__ */ y("button", {
						type: "button",
						disabled: !a.length,
						onClick: () => {
							let t = e.routine?.[e.routine.length - 1]?.to ?? u.start;
							f(e.shape, [...e.routine ?? [], {
								from: t,
								to: Math.min(1440, t + 60),
								spot: a[0].id
							}], "Add to routine");
						},
						children: "+ Block"
					})]
				})
			] }, e.shape))
		})
	] });
}
function D({ game: n, put: r, doc: i, editor: a }) {
	let o = n.shots ?? [], s = () => {
		let { position: e, target: n } = t(i.camera);
		return {
			position: e.toArray().map(x),
			target: n.toArray().map(x)
		};
	}, c = (e, t) => {
		let n = [
			e[0] - t[0],
			e[1] - t[1],
			e[2] - t[2]
		], r = Math.max(.01, Math.hypot(...n));
		a.setCamera({
			target: t,
			distance: r,
			yaw: Math.atan2(n[0], n[2]) * 180 / Math.PI,
			pitch: Math.asin(n[1] / r) * 180 / Math.PI
		});
	};
	return /* @__PURE__ */ b("section", { children: [
		/* @__PURE__ */ y("h4", { children: "Camera shots" }),
		/* @__PURE__ */ y(e, { id: "m3dShots" }),
		/* @__PURE__ */ y("ul", {
			className: "gs-m3d__game-entries",
			children: o.map((e) => /* @__PURE__ */ b("li", { children: [
				/* @__PURE__ */ y("input", {
					"aria-label": "Shot's name",
					value: e.name,
					onChange: (t) => r({
						...n,
						shots: o.map((n) => n.id === e.id ? {
							...n,
							name: t.target.value
						} : n)
					}, "Name a shot")
				}),
				/* @__PURE__ */ y("button", {
					type: "button",
					onClick: () => c(e.position, e.target),
					children: "Look"
				}),
				/* @__PURE__ */ y("button", {
					type: "button",
					title: "Move this shot to the view as it is now",
					onClick: () => r({
						...n,
						shots: o.map((t) => t.id === e.id ? {
							...t,
							...s()
						} : t)
					}, "Change a shot"),
					children: "Update"
				}),
				/* @__PURE__ */ y("button", {
					type: "button",
					"aria-label": `Remove ${e.name}`,
					onClick: () => r({
						...n,
						shots: o.filter((t) => t.id !== e.id)
					}, "Remove a shot"),
					children: "✕"
				})
			] }, e.id))
		}),
		/* @__PURE__ */ y("button", {
			type: "button",
			onClick: () => r({
				...n,
				shots: [...o, {
					id: S("shot", o),
					name: `Shot ${o.length + 1}`,
					...s()
				}]
			}, "Save a shot"),
			children: "+ Save this view as a shot"
		})
	] });
}
var O = (e) => e.split("\n").map((e) => e.trim()).filter(Boolean);
function k({ game: t, put: i, shapes: a }) {
	let [o, s] = v(null), c = t.quests ?? [], l = (e, n) => i({
		...t,
		quests: c.map((t) => t.id === e.id ? e : t)
	}, n);
	return /* @__PURE__ */ b("section", { children: [
		/* @__PURE__ */ y("h4", { children: "Quests" }),
		/* @__PURE__ */ y(e, { id: "m3dQuests" }),
		/* @__PURE__ */ y("ul", {
			className: "gs-m3d__quests",
			children: c.map((e) => /* @__PURE__ */ b("li", { children: [/* @__PURE__ */ b("div", {
				className: "gs-m3d__quest-head",
				children: [
					/* @__PURE__ */ y("input", {
						"aria-label": "Quest's title",
						value: e.title,
						onChange: (t) => l({
							...e,
							title: t.target.value
						}, "Name a quest")
					}),
					/* @__PURE__ */ b("button", {
						type: "button",
						"aria-expanded": o === e.id,
						onClick: () => s(o === e.id ? null : e.id),
						children: [e.steps.length, " steps"]
					}),
					/* @__PURE__ */ y("button", {
						type: "button",
						"aria-label": `Remove ${e.title}`,
						onClick: () => i({
							...t,
							quests: c.filter((t) => t.id !== e.id)
						}, "Remove a quest"),
						children: "✕"
					})
				]
			}), o === e.id && /* @__PURE__ */ b("ol", {
				className: "gs-m3d__quest-steps",
				children: [e.steps.map((t, i) => {
					let o = (t) => l({
						...e,
						steps: e.steps.map((e, n) => n === i ? {
							...e,
							...t
						} : e)
					}, "Change a quest");
					return /* @__PURE__ */ b("li", { children: [
						/* @__PURE__ */ b("div", {
							className: "gs-m3d__game-ruletools",
							children: [
								/* @__PURE__ */ y("select", {
									"aria-label": "What to do",
									value: t.kind,
									onChange: (e) => o({ kind: e.target.value }),
									children: r.map((e) => /* @__PURE__ */ y("option", {
										value: e,
										children: n[e]
									}, e))
								}),
								/* @__PURE__ */ b("select", {
									"aria-label": "Which shape",
									value: t.shape,
									onChange: (e) => o({ shape: e.target.value }),
									children: [!a.some((e) => e.id === t.shape) && /* @__PURE__ */ y("option", {
										value: t.shape,
										children: "(no longer here)"
									}), a.map((e) => /* @__PURE__ */ y("option", {
										value: e.id,
										children: e.label
									}, e.id))]
								}),
								/* @__PURE__ */ y("button", {
									type: "button",
									"aria-label": "Remove this step",
									onClick: () => l({
										...e,
										steps: e.steps.filter((e, t) => t !== i)
									}, "Remove a step"),
									children: "✕"
								})
							]
						}),
						/* @__PURE__ */ y("input", {
							"aria-label": "Hint: what the player is told to do",
							placeholder: "Hint: what the player is told to do",
							value: t.hint,
							onChange: (e) => o({ hint: e.target.value })
						}),
						/* @__PURE__ */ y("textarea", {
							"aria-label": "What's said, one line each",
							rows: 3,
							placeholder: "What is said, one line each\nMio: Hello.",
							value: t.lines.join("\n"),
							onChange: (e) => o({ lines: e.target.value.split("\n") }),
							onBlur: (e) => o({ lines: O(e.target.value) })
						}),
						/* @__PURE__ */ y("textarea", {
							"aria-label": "The same lines in Japanese",
							rows: 2,
							placeholder: "日本語 (optional), one line each",
							value: (t.ja ?? []).join("\n"),
							onChange: (e) => o({ ja: e.target.value ? e.target.value.split("\n") : void 0 }),
							onBlur: (e) => o({ ja: O(e.target.value).length ? O(e.target.value) : void 0 })
						}),
						/* @__PURE__ */ y("input", {
							"aria-label": "An item it gives",
							placeholder: "An item it gives (optional)",
							value: t.gives ?? "",
							onChange: (e) => o({ gives: e.target.value || void 0 })
						})
					] }, i);
				}), /* @__PURE__ */ y("button", {
					type: "button",
					disabled: !a.length,
					onClick: () => l({
						...e,
						steps: [...e.steps, {
							kind: "talk",
							shape: a[0].id,
							hint: "",
							lines: []
						}]
					}, "Add a step"),
					children: "+ Step"
				})]
			})] }, e.id))
		}),
		/* @__PURE__ */ y("button", {
			type: "button",
			onClick: () => {
				let e = S("q", c);
				i({
					...t,
					quests: [...c, {
						id: e,
						title: `Quest ${c.length + 1}`,
						steps: []
					}]
				}, "Add a quest"), s(e);
			},
			children: "+ Quest"
		})
	] });
}
function A({ doc: e, game: t }) {
	let n = g(() => [...m(e.shapes, t), ...c(e.shapes, t)], [e.shapes, t]);
	return n.length ? /* @__PURE__ */ b("section", { children: [/* @__PURE__ */ y("h4", { children: "To look at" }), /* @__PURE__ */ y("ul", {
		className: "gs-m3d__findings",
		children: n.map((e, t) => /* @__PURE__ */ y("li", { children: e.message }, t))
	})] }) : null;
}
function j(e, t = 0) {
	let n = o(e), r = document.createElement("canvas");
	return r.width = 512, r.height = 256, r.getContext("2d").putImageData(new ImageData(new Uint8ClampedArray(f(n, 512, 256, t)), 512, 256), 0, 0), r.toDataURL("image/jpeg", .85);
}
function M({ game: t, put: n, doc: r, editor: a }) {
	let c = t.clock ?? s, [u, d] = v(Math.max(480, Math.min(1080, c.start))), f = o(u);
	return /* @__PURE__ */ b("section", { children: [
		/* @__PURE__ */ y("h4", { children: "Time of day" }),
		/* @__PURE__ */ y(e, { id: "m3dDaylight" }),
		/* @__PURE__ */ b("label", {
			className: "gs-m3d__check",
			children: [/* @__PURE__ */ y("input", {
				type: "checkbox",
				checked: !!c.daylight,
				onChange: (e) => n({
					...t,
					clock: {
						...c,
						daylight: e.target.checked || void 0
					}
				}, "Daylight follows the clock")
			}), "The sun and sky follow the clock while playing"]
		}),
		/* @__PURE__ */ b("label", {
			className: "gs-m3d__field",
			children: [/* @__PURE__ */ y("span", { children: i(u) }), /* @__PURE__ */ y("input", {
				type: "range",
				"aria-label": "Time of day",
				min: 480,
				max: 1080,
				step: 10,
				value: u,
				onChange: (e) => d(Number(e.target.value))
			})]
		}),
		/* @__PURE__ */ b("p", {
			className: "gs-m3d__note",
			children: [
				"Sun ",
				Math.round(f.elevation),
				"° up, ",
				/* @__PURE__ */ y("span", {
					style: { color: f.sunColor },
					children: "■"
				}),
				" sky ",
				/* @__PURE__ */ y("span", {
					style: { color: f.skyHigh },
					children: "■"
				}),
				/* @__PURE__ */ y("span", {
					style: { color: f.skyLow },
					children: "■"
				})
			]
		}),
		/* @__PURE__ */ b("button", {
			type: "button",
			onClick: () => {
				let e = l(r, u);
				a.replaceDesign({
					...e,
					background: {
						...e.background,
						picture: j(u)
					}
				}, `Light for ${i(u)}`);
			},
			children: ["Light the level for ", i(u)]
		})
	] });
}
function N({ game: t, put: n, editor: r }) {
	let i = t.shots ?? [], a = t.films ?? [], [o, s] = v(null), c = _(0);
	h(() => () => cancelAnimationFrame(c.current), []);
	let l = (e, r) => n({
		...t,
		films: a.map((t) => t.id === e.id ? e : t)
	}, r), u = (e) => {
		cancelAnimationFrame(c.current);
		let t = performance.now(), n = () => {
			let a = (performance.now() - t) / 1e3, o = d(e, i, a);
			if (o) {
				let e = [
					o.position[0] - o.target[0],
					o.position[1] - o.target[1],
					o.position[2] - o.target[2]
				], t = Math.max(.01, Math.hypot(...e));
				r.setCamera({
					target: o.target,
					distance: t,
					yaw: Math.atan2(e[0], e[2]) * 180 / Math.PI,
					pitch: Math.asin(e[1] / t) * 180 / Math.PI
				});
			}
			o && a < p(e) && (c.current = requestAnimationFrame(n));
		};
		c.current = requestAnimationFrame(n);
	};
	return i.length ? /* @__PURE__ */ b("section", { children: [
		/* @__PURE__ */ y("h4", { children: "Films" }),
		/* @__PURE__ */ y(e, { id: "m3dFilms" }),
		/* @__PURE__ */ y("ul", {
			className: "gs-m3d__game-entries",
			children: a.map((e) => /* @__PURE__ */ b("li", { children: [
				/* @__PURE__ */ y("input", {
					"aria-label": "Film's name",
					value: e.name,
					onChange: (t) => l({
						...e,
						name: t.target.value
					}, "Name a film")
				}),
				/* @__PURE__ */ b("button", {
					type: "button",
					"aria-expanded": o === e.id,
					onClick: () => s(o === e.id ? null : e.id),
					children: [
						e.steps.length,
						" shots, ",
						x(p(e)),
						" s"
					]
				}),
				/* @__PURE__ */ y("button", {
					type: "button",
					onClick: () => u(e),
					children: "Preview"
				}),
				/* @__PURE__ */ y("button", {
					type: "button",
					"aria-label": `Remove ${e.name}`,
					onClick: () => n({
						...t,
						films: a.filter((t) => t.id !== e.id)
					}, "Remove a film"),
					children: "✕"
				}),
				o === e.id && /* @__PURE__ */ b("div", {
					className: "gs-m3d__routine-blocks",
					children: [e.steps.map((t, n) => {
						let r = (t) => l({
							...e,
							steps: e.steps.map((e, r) => r === n ? {
								...e,
								...t
							} : e)
						}, "Change a film");
						return /* @__PURE__ */ b("div", {
							className: "gs-m3d__film-step",
							children: [
								/* @__PURE__ */ y("select", {
									"aria-label": "Shot",
									value: t.shot,
									onChange: (e) => r({ shot: e.target.value }),
									children: i.map((e) => /* @__PURE__ */ y("option", {
										value: e.id,
										children: e.name
									}, e.id))
								}),
								/* @__PURE__ */ y("input", {
									type: "number",
									"aria-label": "Seconds",
									min: 0,
									max: 60,
									step: .1,
									value: t.seconds,
									onChange: (e) => r({ seconds: Math.max(0, Math.min(60, Number(e.target.value) || 0)) })
								}),
								/* @__PURE__ */ b("label", {
									className: "gs-m3d__check",
									children: [/* @__PURE__ */ y("input", {
										type: "checkbox",
										checked: !!t.cut,
										onChange: (e) => r({ cut: e.target.checked || void 0 })
									}), "Cut"]
								}),
								/* @__PURE__ */ y("button", {
									type: "button",
									"aria-label": "Remove this shot from the film",
									onClick: () => e.steps.length > 1 && l({
										...e,
										steps: e.steps.filter((e, t) => t !== n)
									}, "Change a film"),
									children: "✕"
								})
							]
						}, n);
					}), /* @__PURE__ */ y("button", {
						type: "button",
						onClick: () => l({
							...e,
							steps: [...e.steps, {
								shot: i.at(-1).id,
								seconds: 2
							}]
						}, "Change a film"),
						children: "+ Shot"
					})]
				})
			] }, e.id))
		}),
		/* @__PURE__ */ y("button", {
			type: "button",
			onClick: () => {
				let e = {
					id: S("film", a),
					name: `Film ${a.length + 1}`,
					steps: i.slice(0, 3).map((e, t) => ({
						shot: e.id,
						seconds: t ? 2.5 : 0
					}))
				};
				n({
					...t,
					films: [...a, e]
				}, "Make a film"), s(e.id);
			},
			children: "+ Film from the shots"
		})
	] }) : null;
}
//#endregion
//#region src/model3d/GamePlay.tsx
function P({ editor: t, viewport: n, onStop: r, project: o }) {
	let s = _(null), c = _(null), [d, f] = v(null), [p, m] = v(!1), [g, x] = v(!1), S = _(!1);
	S.current = g;
	let [C, w] = v(0), [T, E] = v(0), D = _(0);
	D.current = T;
	let O = _(void 0), k = _(null), [A, M] = v(null), [N, P] = v(!1), [F, I] = v("12:00"), [L, R] = v(null), z = _(o);
	z.current = o, h(() => {
		let e = new u(t.document, O.current), r = -1, i = "";
		O.current = void 0, c.current = e, e.start(), E(0);
		let a = /* @__PURE__ */ new Set(), o = s.current;
		n.setOrbit(!1);
		let d = (t) => {
			if (t.target instanceof Element && t.target.closest("input, textarea, select")) return;
			let n = t.key.toLowerCase();
			a.add(n);
			let r = e.view();
			if (n === "p" && x((e) => !e), n === " " && !r.line && !r.choices && e.jump()) t.preventDefault(), t.stopPropagation();
			else {
				if (r.choices) {
					let t = r.choices.length;
					(n === "w" || n === "arrowup") && E((e) => (e + t - 1) % t), (n === "s" || n === "arrowdown") && E((e) => (e + 1) % t);
					let i = Number(n);
					i >= 1 && i <= t ? e.choose(i - 1) : (n === "e" || n === " " || n === "enter") && e.choose(D.current);
				} else (n === "e" || n === " " || n === "enter") && (r.line ? e.next() : e.use());
				[
					"w",
					"a",
					"s",
					"d",
					" ",
					"arrowup",
					"arrowdown",
					"arrowleft",
					"arrowright"
				].includes(n) && t.preventDefault(), t.stopPropagation();
			}
		}, p = (e) => a.delete(e.key.toLowerCase()), h = (t) => {
			document.pointerLockElement === o && e.turn(-t.movementX * .15, -t.movementY * .15);
		}, g = !1, _ = () => {
			let e = document.pointerLockElement === o;
			m(e), g && !e && x(!0), e && x(!1), g = e;
		};
		window.addEventListener("keydown", d, !0), window.addEventListener("keyup", p, !0), window.addEventListener("mousemove", h), document.addEventListener("pointerlockchange", _);
		let v = t.subscribe(() => e.setDocument(t.document)), y = /* @__PURE__ */ new Set(), b = 0, C = performance.now(), T = "", A = !1, N = (o) => {
			let s = Math.min(.05, (o - C) / 1e3);
			C = o;
			let c = (a.has("w") || a.has("arrowup") ? 1 : 0) - (a.has("s") || a.has("arrowdown") ? 1 : 0), u = (a.has("d") || a.has("arrowright") ? 1 : 0) - (a.has("a") || a.has("arrowleft") ? 1 : 0), d = navigator.getGamepads?.().find((e) => e?.connected);
			if (d) {
				let t = (e) => Math.abs(e ?? 0) > .18 ? e ?? 0 : 0;
				c -= t(d.axes[1]), u += t(d.axes[0]), e.turn(-t(d.axes[2]) * 150 * s, -t(d.axes[3]) * 110 * s);
				let n = (e) => !!d.buttons[e]?.pressed, r = (e, t) => {
					n(e) && !y.has(e) && t(), n(e) ? y.add(e) : y.delete(e);
				};
				r(9, () => x((e) => !e)), r(0, () => {
					let t = e.view();
					t.choices ? e.choose(D.current) : t.line ? e.next() : e.jump() || e.use();
				}), r(2, () => {
					!e.view().line && !e.view().choices && e.use();
				});
			}
			if (S.current) {
				b = requestAnimationFrame(N);
				return;
			}
			e.walk(c, u, s), e.tick(s);
			for (let t of e.takeSounds()) {
				let e = z.current?.project.sounds[t.sound]?.data;
				t.music ? (k.current?.pause(), k.current = e ? Object.assign(new Audio(e), {
					loop: !0,
					volume: t.volume
				}) : null, k.current?.play().catch(() => {})) : e && Object.assign(new Audio(e), { volume: t.volume }).play().catch(() => {});
			}
			for (let t of e.takeAchievements()) {
				let e = z.current?.project.achievements?.find((e) => e.id === t);
				M(`Achievement: ${e?.title ?? t}`), setTimeout(() => M(null), 4e3);
			}
			let p = e.view().level, m = z.current;
			p && m && m.project.levels.some((e) => e.id === p) && !A && (A = !0, setTimeout(() => {
				O.current = e.carry(), m.open("level", p), w((e) => e + 1);
			}, 600));
			let h = t.document.clip ?? 4, g = e.frame(e.time / h % 1);
			if (t.document.game?.clock?.daylight) {
				let t = Math.floor(e.minute / 10);
				t !== r && (r = t, i = j(e.minute, e.time * .01)), g = l(g, e.minute), g = {
					...g,
					background: {
						...g.background,
						picture: i
					}
				};
			}
			n.showFrame(g);
			let _ = e.view(), v = JSON.stringify(_);
			v !== T && (T = v, f(_)), b = requestAnimationFrame(N);
		};
		return b = requestAnimationFrame(N), () => {
			cancelAnimationFrame(b), window.removeEventListener("keydown", d, !0), window.removeEventListener("keyup", p, !0), window.removeEventListener("mousemove", h), document.removeEventListener("pointerlockchange", _), v(), document.pointerLockElement === o && document.exitPointerLock(), n.showFrame(null), n.setOrbit(!0);
		};
	}, [
		t,
		n,
		C
	]), h(() => () => k.current?.pause(), []);
	let B = c.current, V = () => {
		document.pointerLockElement === s.current ? d?.line ? B?.next() : d?.choices || B?.use() : s.current?.requestPointerLock();
	}, H = d?.line ? d.line.indexOf(": ") : -1, U = d?.line && H > 0 && H < 24 && !d.line.startsWith("(") ? d.line.slice(0, H) : null, W = d?.line ? U ? d.line.slice(H + 2) : d.line : null, G = d?.ended !== null && d?.ended !== void 0 ? d.ended : null;
	return /* @__PURE__ */ b("div", {
		ref: s,
		className: `gs-m3d__game ${p ? "is-locked" : ""}`,
		style: { "--tension": String(d?.tension ?? 0) },
		onClick: V,
		children: [
			/* @__PURE__ */ y("div", { className: "gs-m3d__game-vignette" }),
			!N && !d?.line && !d?.choices && !d?.shot && G === null && !d?.level && /* @__PURE__ */ y("div", { className: "gs-m3d__game-cross" }),
			d?.title && !N && /* @__PURE__ */ y("div", {
				className: "gs-m3d__game-title",
				children: d.title
			}),
			A && /* @__PURE__ */ y("div", {
				className: "gs-m3d__game-earned",
				role: "status",
				children: A
			}),
			!N && (d?.clock || !!d?.objectives.length) && /* @__PURE__ */ b("div", {
				className: "gs-m3d__game-objectives",
				children: [d.clock && /* @__PURE__ */ y("strong", { children: d.clock }), d.objectives.slice(0, 3).map((e) => /* @__PURE__ */ y("span", { children: e.hint || e.quest }, e.quest))]
			}),
			!N && !!d?.items.length && /* @__PURE__ */ y("div", {
				className: "gs-m3d__game-items",
				children: d.items.join(" · ")
			}),
			!N && !!d?.numbers.length && /* @__PURE__ */ y("div", {
				className: "gs-m3d__game-numbers",
				children: d.numbers.map(([e, t]) => /* @__PURE__ */ y("span", { children: `${e}: ${t}` }, e))
			}),
			!N && d?.prompt && !d.line && !d.choices && /* @__PURE__ */ b("div", {
				className: "gs-m3d__game-prompt",
				children: ["E · ", d.prompt]
			}),
			W && /* @__PURE__ */ b("div", {
				className: "gs-m3d__game-box",
				children: [U && /* @__PURE__ */ y("strong", { children: U }), /* @__PURE__ */ y("p", { children: W })]
			}),
			d?.choices && /* @__PURE__ */ y("div", {
				className: "gs-m3d__game-box gs-m3d__game-choices",
				onClick: (e) => e.stopPropagation(),
				children: d.choices.map((e, t) => /* @__PURE__ */ b("button", {
					type: "button",
					className: t === T ? "is-on" : "",
					onClick: () => B?.choose(t),
					children: [
						t + 1,
						" · ",
						e
					]
				}, e))
			}),
			(G !== null || d?.level) && /* @__PURE__ */ b("div", {
				className: "gs-m3d__game-end",
				onClick: (e) => e.stopPropagation(),
				children: [/* @__PURE__ */ y("p", { children: G === null ? o?.project.levels.some((e) => e.id === d.level) ? `On to “${o.project.levels.find((e) => e.id === d.level).name}”…` : `On to the level “${d.level}”: put this design in a game project (the Game tab) to go on to it.` : G || "The end." }), /* @__PURE__ */ b("div", { children: [/* @__PURE__ */ y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => {
						o && o.open("level", o.project.start), w((e) => e + 1);
					},
					children: "Play again"
				}), /* @__PURE__ */ y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: r,
					children: "Stop"
				})] })]
			}),
			g && G === null && !d?.level && /* @__PURE__ */ b("div", {
				className: "gs-m3d__game-end",
				onClick: (e) => e.stopPropagation(),
				children: [
					/* @__PURE__ */ y("p", { children: "Paused" }),
					/* @__PURE__ */ b("div", { children: [
						/* @__PURE__ */ y("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: () => {
								x(!1), s.current?.requestPointerLock();
							},
							children: "Go on"
						}),
						/* @__PURE__ */ y("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: () => {
								x(!1), w((e) => e + 1);
							},
							children: "Start this level again"
						}),
						/* @__PURE__ */ y("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: r,
							children: "Stop"
						})
					] }),
					/* @__PURE__ */ b("div", {
						className: "gs-m3d__game-test",
						children: [
							/* @__PURE__ */ y("strong", { children: "Test" }),
							/* @__PURE__ */ b("label", { children: [/* @__PURE__ */ y("span", { children: "Jump to" }), /* @__PURE__ */ y("input", {
								"aria-label": "Time to jump to",
								value: F,
								size: 5,
								onChange: (e) => I(e.target.value)
							})] }),
							/* @__PURE__ */ y("button", {
								type: "button",
								className: "gs-m3d__btn",
								disabled: a(F) === null,
								onClick: () => {
									let e = a(F);
									e !== null && B && (B.jumpTo(e), R(`Now ${i(e)}: everyone on a routine is where they'd be.`));
								},
								children: "Jump"
							}),
							/* @__PURE__ */ b("label", {
								className: "gs-m3d__check",
								children: [/* @__PURE__ */ y("input", {
									type: "checkbox",
									checked: N,
									onChange: (e) => P(e.target.checked)
								}), "Hide the screen's words (for screenshots)"]
							}),
							/* @__PURE__ */ y("button", {
								type: "button",
								className: "gs-m3d__btn",
								onClick: () => {
									if (!B) return;
									let e = JSON.stringify(B.snapshot(), null, 1);
									navigator.clipboard?.writeText(e).then(() => R("Copied who is where, as JSON: paste it into a bug report."), () => R(e));
								},
								children: "Copy who is where"
							}),
							L && /* @__PURE__ */ y("p", {
								className: "gs-m3d__note",
								children: L
							}),
							/* @__PURE__ */ y(e, { id: "m3dTestPlay" })
						]
					})
				]
			}),
			!p && !g && G === null && !d?.level && /* @__PURE__ */ b("div", {
				className: "gs-m3d__game-hint",
				children: [t.document.game?.player.jump ? "Click to play: WASD walk, the mouse looks, Space jumps, E uses and goes on, 1-4 answer, P or Esc pauses." : "Click to play: WASD walk, the mouse looks, E uses and goes on, 1-4 answer, P or Esc pauses.", /* @__PURE__ */ y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: (e) => {
						e.stopPropagation(), r();
					},
					children: "Stop"
				})]
			})
		]
	});
}
//#endregion
export { E as a, k as i, M as n, D as o, N as r, A as s, P as t };

//# sourceMappingURL=GamePlay-CGNBqRvP.js.map