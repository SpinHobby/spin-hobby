import { A as e, M as t, d as n, k as r, v as i, y as a } from "./GleamEditor-DZHrmEmu.js";
import { a as o, c as s, i as c, l, n as u, r as d } from "./src-BRmeDFgO.js";
import { n as f, t as p } from "./places-CIrqIjZW.js";
import { _ as m, g as h, h as g, m as _, u as v, v as y } from "./src-Bvmr4r-R.js";
import { Dt as b } from "./document-CNMOilB9.js";
import { in as x } from "./core-D8A0dBq3.js";
import { r as S, t as C } from "./ModelMode-DTKUpjLQ.js";
import { a as w, i as T, n as E, o as D, r as O } from "./ar-BtCMfvRn.js";
import { useEffect as k, useMemo as A, useRef as j, useState as M, useSyncExternalStore as N } from "react";
import { jsx as P, jsxs as F } from "react/jsx-runtime";
//#region src/GleamScene.tsx
var I = [
	{
		prefix: "stage/",
		title: "Display"
	},
	{
		prefix: "light/",
		title: "Lighting"
	},
	{
		prefix: "item/",
		title: "Product"
	},
	{
		prefix: "motion/",
		title: "Motion"
	}
], L = {
	studio: "Studio backdrop",
	pedestal: "Pedestal",
	shelf: "Shelf",
	table: "Con booth table",
	soft: "Soft",
	bright: "Bright",
	dramatic: "Dramatic",
	still: "Still",
	sway: "Gentle sway"
}, R = (e, t) => t.split("/").reduce((e, t) => e?.[t], e);
function z({ editor: e, path: t, spec: r, value: i }) {
	switch (r.kind) {
		case "number": return /* @__PURE__ */ F("label", {
			className: "gs-control",
			children: [/* @__PURE__ */ F("span", {
				className: "gs-control__row",
				children: [/* @__PURE__ */ P("span", { children: r.label }), /* @__PURE__ */ F("output", {
					className: i === r.default ? "" : "is-changed",
					children: [Number(i).toFixed(r.step < 1 ? 2 : 0), r.unit ?? ""]
				})]
			}), /* @__PURE__ */ P("input", {
				type: "range",
				style: n(Number(i), r.min, r.max),
				min: r.min,
				max: r.max,
				step: r.step,
				value: Number(i),
				onPointerDown: () => e.begin(r.label),
				onPointerUp: () => e.commit(),
				onLostPointerCapture: () => e.commit(),
				onChange: (n) => e.set(t, Number(n.target.value)),
				onDoubleClick: () => e.set(t, r.default, `Reset ${r.label}`)
			})]
		});
		case "boolean": return /* @__PURE__ */ F("label", {
			className: "gs-control gs-control--inline",
			children: [/* @__PURE__ */ P("input", {
				type: "checkbox",
				checked: i === !0,
				onChange: (n) => e.set(t, n.target.checked)
			}), r.label]
		});
		case "choice": return /* @__PURE__ */ F("label", {
			className: "gs-control",
			children: [/* @__PURE__ */ P("span", { children: r.label }), /* @__PURE__ */ P("select", {
				value: String(i),
				onChange: (n) => e.set(t, n.target.value),
				children: r.options.map((e) => /* @__PURE__ */ P("option", {
					value: e,
					children: L[e] ?? e
				}, e))
			})]
		});
		case "color": return /* @__PURE__ */ F("label", {
			className: "gs-control gs-control--inline gs-control--color",
			children: [/* @__PURE__ */ P("input", {
				type: "color",
				value: String(i),
				onPointerDown: () => e.begin(r.label),
				onBlur: () => e.commit(),
				onChange: (n) => e.set(t, n.target.value)
			}), r.label]
		});
	}
}
function B({ editor: e, doc: t }) {
	let n = t.vertex, r = n ? d(n.id) : void 0, a = r && n ? l(r, n.params) : {};
	return /* @__PURE__ */ F("section", { children: [
		/* @__PURE__ */ P("h2", { children: "Surface" }),
		/* @__PURE__ */ F("select", {
			"aria-label": "Surface shader",
			value: r?.id ?? "",
			onChange: (t) => {
				let n = d(t.target.value);
				e.setVertex(n ? {
					id: n.id,
					params: s(n)
				} : null, n ? `Surface: ${n.name}` : "Surface: none"), t.currentTarget.blur();
			},
			children: [/* @__PURE__ */ P("option", {
				value: "",
				children: "None (flat)"
			}), c().map((e) => /* @__PURE__ */ P("option", {
				value: e.id,
				title: e.description,
				children: e.name
			}, e.id))]
		}),
		r && /* @__PURE__ */ P("p", {
			className: "gs-hint",
			children: r.description
		}),
		r?.params.map((t) => /* @__PURE__ */ P(i, {
			spec: t.spec,
			value: a[t.key] ?? t.spec.default,
			onChange: (n) => e.setVertexParam(t.key, n, `${r.name}: ${t.spec.label}`),
			onBegin: () => e.begin(`${r.name}: ${t.spec.label}`),
			onCommit: () => e.commit()
		}, t.key))
	] });
}
function V({ image: n, scene: i, exportSize: a = {
	width: 1600,
	height: 1600
}, onDone: o, onCancel: s, doneLabel: c = "Save image" }) {
	let [l, u] = M(null), [d, f] = M(null), p = j(i);
	return k(() => {
		let i = new AbortController(), a = null;
		return u(null), f(null), (async () => {
			try {
				let o = typeof n == "string" ? await e(n, i.signal) : n, s = await r(o);
				if (a = await t(s), a !== s && s.close(), i.signal.aborted) return;
				let c = a.width / a.height, l = p.current ? y(c, p.current) : m(c);
				u({
					bitmap: a,
					editor: new g(l)
				});
			} catch (e) {
				i.signal.aborted || f(e instanceof Error ? e.message : "This image couldn't be opened.");
			}
		})(), () => {
			i.abort(), a?.close();
		};
	}, [n]), d ? /* @__PURE__ */ P("div", {
		className: "gs-editor gs-editor--message",
		children: /* @__PURE__ */ P("p", {
			className: "gs-error",
			children: d
		})
	}) : l ? /* @__PURE__ */ P(H, {
		...l,
		exportSize: a,
		onDone: o,
		onCancel: s,
		doneLabel: c
	}) : /* @__PURE__ */ P("div", {
		className: "gs-editor gs-editor--message",
		children: "Setting up the scene…"
	});
}
function H({ bitmap: e, editor: t, exportSize: n, onDone: r, onCancel: i, doneLabel: c }) {
	let l = N(t.subscribe, t.getSnapshot), d = j(null), f = j(null), [p, m] = M(null), [g, v] = M(!1), [y, b] = M(null);
	k(() => {
		try {
			let t = new _(d.current);
			return t.setImage(e), m(t), () => t.dispose();
		} catch (e) {
			b(e instanceof Error ? e.message : "The 3D view could not start.");
		}
	}, [e]), k(() => {
		p?.update(l.doc);
	}, [p, l.doc]), k(() => {
		if (!p) return;
		let e = new ResizeObserver(([e]) => p.resize(e.contentRect.width, e.contentRect.height));
		return e.observe(f.current), () => e.disconnect();
	}, [p]);
	let x = (e) => {
		e.target.tagName !== "SELECT" && (e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z" && (e.preventDefault(), e.shiftKey ? t.redo() : t.undo());
	}, S = async () => {
		if (p && !g) {
			v(!0), b(null);
			try {
				t.commit();
				let e = await p.exportImage({
					...n,
					type: "image/png"
				});
				r?.({
					blob: e,
					...n,
					scene: t.document
				});
			} catch (e) {
				b(e instanceof Error ? e.message : "The image could not be saved.");
			} finally {
				v(!1);
			}
		}
	};
	return /* @__PURE__ */ F("div", {
		className: "gs-editor",
		tabIndex: -1,
		onKeyDown: x,
		children: [
			/* @__PURE__ */ F("header", {
				className: "gs-toolbar",
				children: [
					i && /* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-button",
						onClick: i,
						children: "Close"
					}),
					/* @__PURE__ */ P("span", { className: "gs-toolbar__divider" }),
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-button",
						disabled: !l.canUndo,
						onClick: () => t.undo(),
						children: "Undo"
					}),
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-button",
						disabled: !l.canRedo,
						onClick: () => t.redo(),
						children: "Redo"
					}),
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-button",
						onClick: () => t.reset(),
						children: "Reset"
					}),
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-button",
						onClick: () => p?.resetView(),
						title: "Back to the starting camera view",
						children: "Recenter"
					}),
					/* @__PURE__ */ P("span", { className: "gs-toolbar__spacer" }),
					/* @__PURE__ */ P("span", {
						className: "gs-toolbar__meta",
						children: "Drag to orbit · scroll to zoom"
					}),
					r && /* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-button gs-button--primary",
						disabled: !p || g,
						onClick: () => void S(),
						children: g ? "Saving…" : c
					})
				]
			}),
			/* @__PURE__ */ F("main", {
				className: "gs-stage gs-stage--scene",
				ref: f,
				children: [/* @__PURE__ */ P("canvas", {
					ref: d,
					className: "gs-scene__canvas"
				}), y && /* @__PURE__ */ P("p", {
					className: "gs-error gs-stage__error",
					children: y
				})]
			}),
			/* @__PURE__ */ P("aside", {
				className: "gs-sidebar",
				children: /* @__PURE__ */ F("div", {
					className: "gs-panel",
					children: [
						I.map((e) => /* @__PURE__ */ F("section", { children: [/* @__PURE__ */ P("h2", { children: e.title }), Object.entries(h).filter(([t]) => t.startsWith(e.prefix)).map(([e, n]) => /* @__PURE__ */ P(z, {
							editor: t,
							path: e,
							spec: n,
							value: R(l.doc, e)
						}, e))] }, e.prefix)),
						/* @__PURE__ */ P(B, {
							editor: t,
							doc: l.doc
						}),
						/* @__PURE__ */ P(a, {
							title: "Effects",
							empty: "Add a look to the whole scene: glow, grain, sharpen and more.",
							steps: l.doc.effects,
							catalog: o(["image"]),
							known: u,
							onAdd: (e) => t.addEffect(e.id, s(e), `Add ${e.name}`),
							onRemove: (e) => t.removeEffect(e),
							onMove: (e, n) => t.moveEffect(e, n),
							onParam: (e, n, r, i) => t.setEffectParam(e, n, r, i),
							onBegin: (e) => t.begin(e),
							onCommit: () => t.commit()
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/model3d/ModelPlayer.tsx
function U({ design: e, actions: t, labels: n = {
	play: "Play",
	pause: "Pause"
} }) {
	let r = j(null), i = j(null), a = A(() => new x(e), [e]), [o, s] = M(!0), [c, l] = M(null), u = S(r, i, a, o), d = j(u);
	d.current = u;
	let f = j(o);
	return f.current = o, k(() => {
		if (r.current) try {
			let e = new v(r.current, a, { onPick: (e) => void (f.current && d.current.click(e)) });
			return e.setGrid(0), i.current = e, () => {
				e.dispose(), i.current = null;
			};
		} catch (e) {
			l(e instanceof Error ? `3D drawing could not start: ${e.message}` : "3D drawing could not start on this computer.");
		}
	}, [a]), k(() => {
		let e = i.current;
		if (!o || !e) return;
		let t = a.document.clip ?? 4, n = performance.now(), r = 0, s = (i) => {
			e.showFrame(b(a.document, ((i - n) / 1e3 / t % 1 + 1) % 1, d.current.at(i))), r = requestAnimationFrame(s);
		};
		return r = requestAnimationFrame(s), () => {
			cancelAnimationFrame(r), e.showFrame(null);
		};
	}, [o, a]), /* @__PURE__ */ F("div", {
		className: "gs-player",
		children: [
			/* @__PURE__ */ P("div", {
				className: "gs-player__stage",
				ref: r
			}),
			c && /* @__PURE__ */ P("p", {
				className: "gs-player__problem",
				children: c
			}),
			/* @__PURE__ */ F("div", {
				className: "gs-player__bar",
				children: [/* @__PURE__ */ P("button", {
					type: "button",
					className: "gs-player__btn",
					onClick: () => s((e) => !e),
					children: o ? n.pause : n.play
				}), t]
			})
		]
	});
}
//#endregion
export { V as GleamScene, p as MODEL_PLACES, C as ModelMode, U as ModelPlayer, E as canPlaceInRoom, O as canQuickLook, T as designUsdz, f as modelPlace, w as placeInRoom, D as quickLook };

//# sourceMappingURL=scene.js.map