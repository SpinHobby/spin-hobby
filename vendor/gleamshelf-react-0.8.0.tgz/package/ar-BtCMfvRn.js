import { n as e } from "./rolldown-runtime-DArdT4gl.js";
import "./src-Bvmr4r-R.js";
import { Et as t, Jn as n, M as r, Tt as i, Vn as a, Vt as o, h as s, q as c, qt as l } from "./three.core-BCwsimN9.js";
import { h as u } from "./output-BrHndJJc.js";
import { m as d, o as f } from "./mesh-DZeCIO4D.js";
import { l as p } from "./meshtrace-CDhGnliO.js";
import { t as m } from "./GLTFLoader-C265XJ9t.js";
import { a as h, n as g } from "./fflate.module-CAsKaJ_w.js";
//#region ../../node_modules/three/examples/jsm/exporters/USDZExporter.js
var _ = class {
	constructor(e, t = "", n = [], r = []) {
		this.name = e, this.type = t, this.metadata = n, this.properties = r, this.children = [];
	}
	addMetadata(e, t) {
		this.metadata.push({
			key: e,
			value: t
		});
	}
	addProperty(e, t = []) {
		this.properties.push({
			property: e,
			metadata: t
		});
	}
	addChild(e) {
		this.children.push(e);
	}
	toString(e = 0) {
		let t = "	".repeat(e), n = this.metadata.map((e) => {
			let n = e.key, r = e.value;
			if (Array.isArray(r)) {
				let e = [];
				return e.push(`${n} = {`), r.forEach((n) => {
					e.push(`${t}\t\t${n}`);
				}), e.push(`${t}\t}`), e.join("\n");
			}
			return `${n} = ${r}`;
		}), r = n.length ? ` (\n${n.map((e) => `${t}\t${e}`).join("\n")}\n${t})` : "", i = this.properties.map((e) => {
			let n = e.property.replace(/\n/g, "\n" + t + "	"), r = e.metadata.length ? ` (\n${e.metadata.map((e) => `${t}\t\t${e}`).join("\n")}\n${t}\t)` : "";
			return `${t}\t${n}${r}`;
		}), a = this.children.map((t) => t.toString(e + 1)), o = [];
		if (i.length > 0 && o.push(...i), a.length > 0) {
			i.length > 0 && o.push("");
			for (let e = 0; e < a.length; e++) o.push(a[e]), e < a.length - 1 && o.push("");
		}
		let s = o.join("\n");
		return `${t}def ${this.type ? this.type + " " : ""}"${this.name}"${r}\n${t}{\n${s}\n${t}}`;
	}
}, v = class {
	constructor() {
		this.textureUtils = null;
	}
	setTextureUtils(e) {
		this.textureUtils = e;
	}
	parse(e, t, n, r) {
		this.parseAsync(e, r).then(t).catch(n);
	}
	async parseAsync(e, t = {}) {
		t = Object.assign({
			ar: {
				anchoring: { type: "plane" },
				planeAnchoring: { alignment: "horizontal" }
			},
			includeAnchoringProperties: !0,
			onlyVisible: !0,
			quickLookCompatible: !1,
			maxTextureSize: 1024,
			animations: [],
			animationFrameRate: 60
		}, t);
		let n = /* @__PURE__ */ new Set(), r = {}, i = "model.usda";
		r[i] = null;
		let a = C(e, t.animations);
		t.animationTracks = a;
		let o = new _("Root", "Xform"), s = new _("Scenes", "Scope");
		s.addMetadata("kind", "\"sceneLibrary\""), o.addChild(s);
		let c = "Scene", l = new _(c, "Xform");
		l.addMetadata("customData", ["bool preliminary_collidesWithEnvironment = 0", `string sceneName = "${c}"`]), l.addMetadata("sceneName", `"${c}"`), t.includeAnchoringProperties && (l.addProperty(`token preliminary:anchoring:type = "${t.ar.anchoring.type}"`), l.addProperty(`token preliminary:planeAnchoring:alignment = "${t.ar.planeAnchoring.alignment}"`)), s.addChild(l);
		let u, d = {}, f = {};
		e.isScene ? D(e, l, d, n, r, t) : O(e, l, d, n, r, t);
		let p = B(d, f, t.quickLookCompatible);
		u = S(a.size > 0 ? {
			fps: t.animationFrameRate,
			endTimeCode: w(t.animations) * t.animationFrameRate
		} : null) + "\n" + o.toString() + "\n\n" + p.toString(), r[i] = g(u), u = null;
		for (let e in f) {
			let n = f[e];
			if (n.isCompressedTexture === !0) {
				if (this.textureUtils === null) throw Error("THREE.USDZExporter: setTextureUtils() must be called to process compressed textures.");
				n = await this.textureUtils.decompress(n);
			}
			let i = ee(n.image, n.flipY, t.maxTextureSize), a = n.userData.mimeType === "image/jpeg" ? "image/jpeg" : "image/png", o = await new Promise((e) => i.toBlob(e, a));
			r[`textures/Texture_${e}.${b(n)}`] = new Uint8Array(await o.arrayBuffer());
		}
		let m = 0;
		for (let e in r) {
			let t = r[e], n = 34 + e.length;
			m += n;
			let i = m & 63;
			if (i !== 4) {
				let n = 64 - i;
				r[e] = [t, { extra: { 12345: new Uint8Array(n) } }];
			}
			m = t.length;
		}
		return h(r, {
			level: 0,
			mtime: /* @__PURE__ */ new Date()
		});
	}
};
function y(e, t) {
	let n = e.name;
	return n = n.replace(/[^A-Za-z0-9_]/g, ""), /^[0-9]/.test(n) && (n = "_" + n), n === "" && (n = e.isCamera ? "Camera" : "Object"), t.has(n) && (n = n + "_" + e.id), t.add(n), n;
}
function b(e) {
	return e.userData.mimeType === "image/jpeg" ? "jpg" : "png";
}
function ee(e, t, n) {
	if (typeof HTMLImageElement < "u" && e instanceof HTMLImageElement || typeof HTMLCanvasElement < "u" && e instanceof HTMLCanvasElement || typeof OffscreenCanvas < "u" && e instanceof OffscreenCanvas || typeof ImageBitmap < "u" && e instanceof ImageBitmap) {
		let r = n / Math.max(e.width, e.height), i = document.createElement("canvas");
		i.width = e.width * Math.min(1, r), i.height = e.height * Math.min(1, r);
		let a = i.getContext("2d");
		return t === !0 && (a.translate(0, i.height), a.scale(1, -1)), a.drawImage(e, 0, 0, i.width, i.height), i;
	}
	throw Error("THREE.USDZExporter: No valid image data found. Unable to process texture.");
}
var x = 7;
function S(e = null) {
	return `#usda 1.0
(
	customLayerData = {
		string creator = "Three.js USDZExporter"
	}
	defaultPrim = "Root"
	metersPerUnit = 1
	upAxis = "Y"${e ? `
	startTimeCode = 0
	endTimeCode = ${e.endTimeCode}
	timeCodesPerSecond = ${e.fps}
	framesPerSecond = ${e.fps}` : ""}
)
`;
}
function C(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let r = 0; r < t.length; r++) {
		let i = t[r];
		for (let t = 0; t < i.tracks.length; t++) {
			let r = i.tracks[t], a = l.parseTrackName(r.name), o = l.findNode(e, a.nodeName);
			if (o == null) continue;
			let s = a.propertyName;
			if (s !== "position" && s !== "quaternion" && s !== "scale") continue;
			let c = n.get(o);
			c === void 0 && (c = {}, n.set(o, c)), c[s] = r;
		}
	}
	return n;
}
function w(e) {
	let t = 0;
	for (let n = 0; n < e.length; n++) e[n].duration > t && (t = e[n].duration);
	return t;
}
function T(e, t, n, r) {
	let i = n.times, a = n.values, o = [];
	for (let e = 0; e < i.length; e++) {
		let t = e * 3;
		o.push(`${(i[e] * r).toPrecision(x)}: (${a[t].toPrecision(x)}, ${a[t + 1].toPrecision(x)}, ${a[t + 2].toPrecision(x)})`);
	}
	return `${t} ${e}.timeSamples = {\n\t${o.join(",\n	")},\n}`;
}
function E(e, t) {
	let n = e.times, r = e.values, i = [];
	for (let e = 0; e < n.length; e++) {
		let a = e * 4;
		i.push(`${(n[e] * t).toPrecision(x)}: (${r[a + 3].toPrecision(x)}, ${r[a].toPrecision(x)}, ${r[a + 1].toPrecision(x)}, ${r[a + 2].toPrecision(x)})`);
	}
	return `quatf xformOp:orient.timeSamples = {\n\t${i.join(",\n	")},\n}`;
}
function D(e, t, n, r, i, a) {
	for (let o = 0, s = e.children.length; o < s; o++) O(e.children[o], t, n, r, i, a);
}
function O(e, t, n, r, i, a) {
	if (e.visible === !1 && a.onlyVisible === !0) return;
	let o;
	if (e.isMesh) {
		let t = e.geometry, s = Array.isArray(e.material), c = s ? e.material : [e.material];
		for (let e = 0; e < c.length; e++) {
			let t = c[e];
			t.isMeshStandardMaterial || console.warn("THREE.USDZExporter: Use MeshStandardMaterial for best results."), t.uuid in n || (n[t.uuid] = t);
		}
		let l = c.map((e) => n[e.uuid]);
		if (s === !1) {
			let e = `geometries/Geometry_${t.id}.usda`;
			if (!(e in i)) {
				let n = P(t);
				i[e] = g(S() + "\n" + n.toString());
			}
		}
		o = j(e, t, l, r, a);
	} else o = e.isCamera ? G(e, r, a) : A(e, r, a);
	t.addChild(o), D(e, o, n, r, i, a);
}
function k(e, t, n) {
	let r = n.animationTracks.get(t), i = t.pivot !== null;
	if (!i && r === void 0) {
		let n = M(t.matrix);
		e.addProperty(`matrix4d xformOp:transform = ${n}`), e.addProperty("uniform token[] xformOpOrder = [\"xformOp:transform\"]");
		return;
	}
	let a = n.animationFrameRate, o = t.position, s = t.quaternion, c = t.scale;
	if (r !== void 0 && r.position !== void 0 ? e.addProperty(T("xformOp:translate", "float3", r.position, a)) : e.addProperty(`float3 xformOp:translate = (${o.x.toPrecision(x)}, ${o.y.toPrecision(x)}, ${o.z.toPrecision(x)})`), i) {
		let n = t.pivot;
		e.addProperty(`float3 xformOp:translate:pivot = (${n.x.toPrecision(x)}, ${n.y.toPrecision(x)}, ${n.z.toPrecision(x)})`);
	}
	r !== void 0 && r.quaternion !== void 0 ? e.addProperty(E(r.quaternion, a)) : e.addProperty(`quatf xformOp:orient = (${s.w.toPrecision(x)}, ${s.x.toPrecision(x)}, ${s.y.toPrecision(x)}, ${s.z.toPrecision(x)})`), r !== void 0 && r.scale !== void 0 ? e.addProperty(T("xformOp:scale", "float3", r.scale, a)) : e.addProperty(`float3 xformOp:scale = (${c.x.toPrecision(x)}, ${c.y.toPrecision(x)}, ${c.z.toPrecision(x)})`), i ? e.addProperty("uniform token[] xformOpOrder = [\"xformOp:translate\", \"xformOp:translate:pivot\", \"xformOp:orient\", \"xformOp:scale\", \"!invert!xformOp:translate:pivot\"]") : e.addProperty("uniform token[] xformOpOrder = [\"xformOp:translate\", \"xformOp:orient\", \"xformOp:scale\"]");
}
function A(e, t, n) {
	let r = y(e, t);
	e.matrix.determinant() < 0 && console.warn("THREE.USDZExporter: USDZ does not support negative scales", e);
	let i = new _(r, "Xform");
	return k(i, e, n), i;
}
function j(e, t, n, r, i) {
	let a = A(e, r, i);
	return n.length === 1 ? (a.addMetadata("prepend references", `@./geometries/Geometry_${t.id}.usda@</Geometry>`), a.addMetadata("prepend apiSchemas", "[\"MaterialBindingAPI\"]"), a.addProperty(`rel material:binding = </Materials/Material_${n[0].id}>`)) : a.addChild(F(t, n)), a;
}
function M(e) {
	let t = e.elements;
	return `( ${N(t, 0)}, ${N(t, 4)}, ${N(t, 8)}, ${N(t, 12)} )`;
}
function N(e, t) {
	return `(${e[t + 0]}, ${e[t + 1]}, ${e[t + 2]}, ${e[t + 3]})`;
}
function P(e) {
	let t = new _("Geometry"), n = F(e);
	return t.addChild(n), t;
}
function F(e, t = null) {
	let n = e.attributes, r = n.position.count, i = new _("Geometry", "Mesh");
	i.addProperty(`int[] faceVertexCounts = [${I(e)}]`), i.addProperty(`int[] faceVertexIndices = [${L(e)}]`), i.addProperty(`normal3f[] normals = [${R(n.normal, r)}]`, ["interpolation = \"vertex\""]), i.addProperty(`point3f[] points = [${R(n.position, r)}]`);
	for (let e = 0; e < 4; e++) {
		let t = e > 0 ? e : "", r = n["uv" + t];
		r !== void 0 && i.addProperty(`texCoord2f[] primvars:st${t} = [${z(r)}]`, ["interpolation = \"vertex\""]);
	}
	let a = n.color;
	if (a !== void 0 && i.addProperty(`color3f[] primvars:displayColor = [${R(a, r)}]`, ["interpolation = \"vertex\""]), i.addProperty("uniform token subdivisionScheme = \"none\""), t !== null) {
		let r = e.groups, a = (e.index === null ? n.position.count : e.index.count) / 3;
		for (let e = 0; e < r.length; e++) {
			let n = r[e], o = t[n.materialIndex];
			if (o === void 0) continue;
			let s = Math.floor(n.start / 3), c = Math.min(s + Math.floor(n.count / 3), a), l = [];
			for (let e = s; e < c; e++) l.push(e);
			let u = new _(`subset_${e}`, "GeomSubset");
			u.addMetadata("prepend apiSchemas", "[\"MaterialBindingAPI\"]"), u.addProperty("uniform token elementType = \"face\""), u.addProperty("uniform token familyName = \"materialBind\""), u.addProperty(`int[] indices = [${l.join(", ")}]`), u.addProperty(`rel material:binding = </Materials/Material_${o.id}>`), i.addChild(u);
		}
	}
	return i;
}
function I(e) {
	let t = e.index === null ? e.attributes.position.count : e.index.count;
	return Array(t / 3).fill(3).join(", ");
}
function L(e) {
	let t = e.index, n = [];
	if (t !== null) for (let e = 0; e < t.count; e++) n.push(t.getX(e));
	else {
		let t = e.attributes.position.count;
		for (let e = 0; e < t; e++) n.push(e);
	}
	return n.join(", ");
}
function R(e, t) {
	if (e === void 0) return console.warn("USDZExporter: Normals missing."), Array(t).fill("(0, 0, 0)").join(", ");
	let n = [];
	for (let t = 0; t < e.count; t++) {
		let r = e.getX(t), i = e.getY(t), a = e.getZ(t);
		n.push(`(${r.toPrecision(x)}, ${i.toPrecision(x)}, ${a.toPrecision(x)})`);
	}
	return n.join(", ");
}
function z(e) {
	let t = [];
	for (let n = 0; n < e.count; n++) {
		let r = e.getX(n), i = e.getY(n);
		t.push(`(${r.toPrecision(x)}, ${1 - i.toPrecision(x)})`);
	}
	return t.join(", ");
}
function B(e, t, n = !1) {
	let r = new _("Materials");
	for (let i in e) {
		let a = e[i];
		r.addChild(V(a, t, n));
	}
	return r;
}
function V(e, t, n = !1) {
	let r = new _(`Material_${e.id}`, "Material");
	function i(r, i, a) {
		let o = r.source.id + "_" + r.flipY;
		t[o] = r;
		let s = r.channel > 0 ? "st" + r.channel : "st", c = {
			1e3: "repeat",
			1001: "clamp",
			1002: "mirror"
		}, l = r.repeat.clone(), u = r.offset.clone(), d = r.rotation, f = Math.sin(d), p = Math.cos(d);
		u.y = 1 - u.y - l.y, n ? (u.x /= l.x, u.y /= l.y, u.x += f / l.x, u.y += p - 1) : (u.x += f * l.x, u.y += (1 - p) * l.y);
		let m = new _(`PrimvarReader_${i}`, "Shader");
		m.addProperty("uniform token info:id = \"UsdPrimvarReader_float2\""), m.addProperty("float2 inputs:fallback = (0.0, 0.0)"), m.addProperty(`string inputs:varname = "${s}"`), m.addProperty("float2 outputs:result");
		let h = new _(`Transform2d_${i}`, "Shader");
		h.addProperty("uniform token info:id = \"UsdTransform2d\""), h.addProperty(`float2 inputs:in.connect = </Materials/Material_${e.id}/PrimvarReader_${i}.outputs:result>`), h.addProperty(`float inputs:rotation = ${(180 / Math.PI * d).toFixed(x)}`), h.addProperty(`float2 inputs:scale = ${W(l)}`), h.addProperty(`float2 inputs:translation = ${W(u)}`), h.addProperty("float2 outputs:result");
		let g = new _(`Texture_${r.id}_${i}`, "Shader");
		if (g.addProperty("uniform token info:id = \"UsdUVTexture\""), g.addProperty(`asset inputs:file = @textures/Texture_${o}.${b(r)}@`), g.addProperty(`float2 inputs:st.connect = </Materials/Material_${e.id}/Transform2d_${i}.outputs:result>`), a !== void 0) {
			let t = i === "diffuse" ? e.opacity : 1;
			g.addProperty(`float4 inputs:scale = ${U(a, t)}`);
		}
		if (i === "normal") {
			let t = e.normalScale.x;
			g.addProperty(`float4 inputs:scale = (${2 * t}, ${2 * t}, 2, 1)`), g.addProperty(`float4 inputs:bias = (${-t}, ${-t}, -1, 0)`);
		}
		return g.addProperty(`token inputs:sourceColorSpace = "${r.colorSpace === "" ? "raw" : "sRGB"}"`), g.addProperty(`token inputs:wrapS = "${c[r.wrapS]}"`), g.addProperty(`token inputs:wrapT = "${c[r.wrapT]}"`), g.addProperty("float outputs:r"), g.addProperty("float outputs:g"), g.addProperty("float outputs:b"), g.addProperty("float3 outputs:rgb"), (e.transparent || e.alphaTest > 0) && g.addProperty("float outputs:a"), [
			m,
			h,
			g
		];
	}
	e.side === 2 && console.warn("THREE.USDZExporter: USDZ does not support double sided materials", e);
	let a = new _("PreviewSurface", "Shader");
	if (a.addProperty("uniform token info:id = \"UsdPreviewSurface\""), e.map === null ? a.addProperty(`color3f inputs:diffuseColor = ${H(e.color)}`) : (a.addProperty(`color3f inputs:diffuseColor.connect = </Materials/Material_${e.id}/Texture_${e.map.id}_diffuse.outputs:rgb>`), e.transparent ? a.addProperty(`float inputs:opacity.connect = </Materials/Material_${e.id}/Texture_${e.map.id}_diffuse.outputs:a>`) : e.alphaTest > 0 && (a.addProperty(`float inputs:opacity.connect = </Materials/Material_${e.id}/Texture_${e.map.id}_diffuse.outputs:a>`), a.addProperty(`float inputs:opacityThreshold = ${e.alphaTest}`)), i(e.map, "diffuse", e.color).forEach((e) => r.addChild(e))), e.emissive) {
		let t = e.emissiveIntensity ?? 1;
		if (e.emissiveMap) {
			a.addProperty(`color3f inputs:emissiveColor.connect = </Materials/Material_${e.id}/Texture_${e.emissiveMap.id}_emissive.outputs:rgb>`);
			let n = new s(e.emissive.r * t, e.emissive.g * t, e.emissive.b * t);
			i(e.emissiveMap, "emissive", n).forEach((e) => r.addChild(e));
		} else e.emissive.getHex() > 0 && a.addProperty(`color3f inputs:emissiveColor = ${H(e.emissive)}`);
	}
	if (e.normalMap && (a.addProperty(`normal3f inputs:normal.connect = </Materials/Material_${e.id}/Texture_${e.normalMap.id}_normal.outputs:rgb>`), i(e.normalMap, "normal").forEach((e) => r.addChild(e))), e.aoMap) {
		a.addProperty(`float inputs:occlusion.connect = </Materials/Material_${e.id}/Texture_${e.aoMap.id}_occlusion.outputs:r>`);
		let t = e.aoMapIntensity ?? 1, n = new s(t, t, t);
		i(e.aoMap, "occlusion", n).forEach((e) => r.addChild(e));
	}
	if (e.roughnessMap) {
		a.addProperty(`float inputs:roughness.connect = </Materials/Material_${e.id}/Texture_${e.roughnessMap.id}_roughness.outputs:g>`);
		let t = new s(e.roughness, e.roughness, e.roughness);
		i(e.roughnessMap, "roughness", t).forEach((e) => r.addChild(e));
	} else a.addProperty(`float inputs:roughness = ${e.roughness ?? 1}`);
	if (e.metalnessMap) {
		a.addProperty(`float inputs:metallic.connect = </Materials/Material_${e.id}/Texture_${e.metalnessMap.id}_metallic.outputs:b>`);
		let t = new s(e.metalness, e.metalness, e.metalness);
		i(e.metalnessMap, "metallic", t).forEach((e) => r.addChild(e));
	} else a.addProperty(`float inputs:metallic = ${e.metalness ?? 0}`);
	if (e.alphaMap ? (a.addProperty(`float inputs:opacity.connect = </Materials/Material_${e.id}/Texture_${e.alphaMap.id}_opacity.outputs:r>`), a.addProperty("float inputs:opacityThreshold = 0.0001"), i(e.alphaMap, "opacity").forEach((e) => r.addChild(e))) : a.addProperty(`float inputs:opacity = ${e.opacity}`), e.isMeshPhysicalMaterial) {
		if (e.clearcoatMap !== null) {
			a.addProperty(`float inputs:clearcoat.connect = </Materials/Material_${e.id}/Texture_${e.clearcoatMap.id}_clearcoat.outputs:r>`);
			let t = new s(e.clearcoat, e.clearcoat, e.clearcoat);
			i(e.clearcoatMap, "clearcoat", t).forEach((e) => r.addChild(e));
		} else a.addProperty(`float inputs:clearcoat = ${e.clearcoat}`);
		if (e.clearcoatRoughnessMap !== null) {
			a.addProperty(`float inputs:clearcoatRoughness.connect = </Materials/Material_${e.id}/Texture_${e.clearcoatRoughnessMap.id}_clearcoatRoughness.outputs:g>`);
			let t = new s(e.clearcoatRoughness, e.clearcoatRoughness, e.clearcoatRoughness);
			i(e.clearcoatRoughnessMap, "clearcoatRoughness", t).forEach((e) => r.addChild(e));
		} else a.addProperty(`float inputs:clearcoatRoughness = ${e.clearcoatRoughness}`);
		a.addProperty(`float inputs:ior = ${e.ior}`);
	}
	return a.addProperty("int inputs:useSpecularWorkflow = 0"), a.addProperty("token outputs:surface"), r.addChild(a), r.addProperty(`token outputs:surface.connect = </Materials/Material_${e.id}/PreviewSurface.outputs:surface>`), r;
}
function H(e) {
	return `(${e.r}, ${e.g}, ${e.b})`;
}
function U(e, t = 1) {
	return `(${e.r}, ${e.g}, ${e.b}, ${t})`;
}
function W(e) {
	return `(${e.x}, ${e.y})`;
}
function G(e, t, n) {
	let r = y(e, t);
	e.matrix.determinant() < 0 && console.warn("THREE.USDZExporter: USDZ does not support negative scales", e);
	let i = new _(r, "Camera");
	k(i, e, n);
	let a = e.isOrthographicCamera ? "orthographic" : "perspective";
	i.addProperty(`token projection = "${a}"`);
	let o = `(${e.near.toPrecision(x)}, ${e.far.toPrecision(x)})`;
	i.addProperty(`float2 clippingRange = ${o}`);
	let s;
	s = e.isOrthographicCamera ? ((Math.abs(e.left) + Math.abs(e.right)) * 10).toPrecision(x) : e.getFilmWidth().toPrecision(x), i.addProperty(`float horizontalAperture = ${s}`);
	let c;
	if (c = e.isOrthographicCamera ? ((Math.abs(e.top) + Math.abs(e.bottom)) * 10).toPrecision(x) : e.getFilmHeight().toPrecision(x), i.addProperty(`float verticalAperture = ${c}`), e.isPerspectiveCamera) {
		let t = e.getFocalLength().toPrecision(x);
		i.addProperty(`float focalLength = ${t}`);
		let n = e.focus.toPrecision(x);
		i.addProperty(`float focusDistance = ${n}`);
	}
	return i;
}
//#endregion
//#region src/model3d/ar.ts
var K = /* @__PURE__ */ e({
	canPlaceInRoom: () => Z,
	canQuickLook: () => X,
	designUsdz: () => Y,
	placeInRoom: () => $,
	quickLook: () => Q
});
function q(e) {
	let t = [], n = [...e.materials], r = /* @__PURE__ */ new Map();
	for (let i of e.parts) {
		if (!i.colors) {
			t.push(i);
			continue;
		}
		let a = /* @__PURE__ */ new Map();
		for (let t = 0; t < i.indices.length; t += 3) {
			let o = [
				0,
				1,
				2
			].map((e) => (i.colors[i.indices[t] * 3 + e] + i.colors[i.indices[t + 1] * 3 + e] + i.colors[i.indices[t + 2] * 3 + e]) / 3).map((e) => Math.round(Math.min(1, Math.max(0, e)) ** (1 / 2.2) * 7)).join(","), s = r.get(o);
			if (s === void 0) {
				s = n.length;
				let t = e.materials[i.material];
				n.push({
					...t,
					color: o.split(",").map((e) => (Number(e) / 7) ** 2.2),
					texture: -1
				}), r.set(o, s);
			}
			let c = a.get(s);
			c || a.set(s, c = []), c.push(i.indices[t], i.indices[t + 1], i.indices[t + 2]);
		}
		for (let [e, n] of a) t.push({
			...i,
			colors: null,
			indices: new Uint32Array(n),
			material: e
		});
	}
	return f(t, n, e.textures);
}
async function J(e, t) {
	let n = q(await p(e, { cells: 120 }));
	if (!n.triangles) throw Error("There is nothing to show: the design has no visible shapes.");
	let r = t / 1e3 / Math.max(n.max[1] - n.min[1], 1e-6), i = [
		(n.min[0] + n.max[0]) / 2,
		n.min[1],
		(n.min[2] + n.max[2]) / 2
	], a = n.parts.map((e) => {
		let t = new Float32Array(e.positions.length);
		for (let n = 0; n < t.length; n += 3) for (let a = 0; a < 3; a++) t[n + a] = (e.positions[n + a] - i[a]) * r;
		return {
			...e,
			positions: t
		};
	}), o = d(f(a, n.materials, n.textures));
	return (await new m().parseAsync(o.buffer.slice(o.byteOffset, o.byteOffset + o.byteLength), "")).scene;
}
async function Y(e, t) {
	let n = await J(e, t);
	return new v().parseAsync(n, { quickLookCompatible: !0 });
}
var X = () => document.createElement("a").relList.supports("ar");
async function Z() {
	let e = navigator.xr;
	return !!e && await e.isSessionSupported("immersive-ar").catch(() => !1);
}
async function Q(e, t) {
	let n = await Y(e, t), r = document.createElement("a");
	r.rel = "ar", r.href = URL.createObjectURL(new Blob([n], { type: "model/vnd.usdz+zip" })), r.appendChild(document.createElement("img")), document.body.appendChild(r), r.click(), setTimeout(() => (URL.revokeObjectURL(r.href), r.remove()), 6e4);
}
async function $(e, s, l) {
	let d = navigator.xr, f = await J(e, s), p = new u({
		antialias: !0,
		alpha: !0
	});
	p.setPixelRatio(window.devicePixelRatio), p.setSize(window.innerWidth, window.innerHeight), p.xr.enabled = !0;
	let m = new n();
	m.add(new c(16777215, 7829367, 2.5));
	let h = new r(16777215, 1.5);
	h.position.set(1, 3, 2), m.add(h);
	let g = new o(70, window.innerWidth / window.innerHeight, .01, 40), _ = new i(new a(.08, .1, 32).rotateX(-Math.PI / 2), new t());
	_.matrixAutoUpdate = !1, _.visible = !1, m.add(_), f.visible = !1, m.add(f);
	let v = await d.requestSession("immersive-ar", {
		requiredFeatures: ["hit-test"],
		optionalFeatures: ["dom-overlay"],
		domOverlay: { root: l }
	});
	p.xr.setReferenceSpaceType("local"), await p.xr.setSession(v);
	let y = await v.requestReferenceSpace("viewer"), b = await v.requestHitTestSource({ space: y });
	return v.addEventListener("select", () => {
		_.visible && (f.position.setFromMatrixPosition(_.matrix), f.visible = !0);
	}), p.setAnimationLoop((e, t) => {
		let n = p.xr.getReferenceSpace(), r = t && b && n ? t.getHitTestResults(b)[0] : void 0, i = r && n ? r.getPose(n) : void 0;
		_.visible = !!i, i && _.matrix.fromArray(i.transform.matrix), p.render(m, g);
	}), v.addEventListener("end", () => p.setAnimationLoop(null)), () => {
		p.setAnimationLoop(null), v.end().catch(() => void 0), p.dispose();
	};
}
//#endregion
export { $ as a, Y as i, Z as n, Q as o, X as r, K as t };

//# sourceMappingURL=ar-BtCMfvRn.js.map