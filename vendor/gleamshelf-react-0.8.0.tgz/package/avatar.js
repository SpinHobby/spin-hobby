export { t as AvatarMode } from "./AvatarMode-CJmXA-Gz.js";
