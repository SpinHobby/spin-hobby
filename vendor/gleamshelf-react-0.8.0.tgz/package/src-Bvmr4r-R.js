import { F as e, I as t, N as n, P as r, c as i, d as a, j as o, l as s, s as c, u as l } from "./src-Dp2bJp0u.js";
import { l as u, n as d, o as f, r as p, s as m, t as h, u as g } from "./src-BRmeDFgO.js";
import { $n as _, B as v, Bt as y, C as b, Cr as x, Ct as S, D as C, Dt as w, Er as T, Et as E, F as ee, Fn as te, G as ne, Gt as D, Ht as re, In as ie, Jn as O, Jt as k, K as ae, Kn as oe, Kt as se, Ln as ce, M as le, Mt as ue, Or as de, P as fe, Pn as pe, Pt as me, Rt as he, S as A, Sr as j, St as M, T as N, Tt as P, Ut as F, V as ge, Vt as _e, W as ve, Yn as I, _ as ye, ar as be, bt as xe, c as Se, cr as Ce, ct as L, d as we, dt as Te, ft as Ee, g as De, h as Oe, j as ke, l as R, lr as Ae, lt as je, nr as Me, or as Ne, p as Pe, pr as Fe, q as Ie, rr as Le, tn as Re, u as ze, w as Be, wr as z, wt as B, yt as Ve, z as He, zn as Ue, zt as We } from "./three.core-BCwsimN9.js";
import { a as Ge, d as Ke, h as qe, i as Je, l as Ye, n as Xe, o as Ze, r as Qe, t as $e, u as et } from "./output-BrHndJJc.js";
import { c as tt } from "./mesh-DZeCIO4D.js";
import { $ as nt, Br as rt, Ct as it, Dt as at, F as ot, Gr as st, H as ct, Jr as lt, P as ut, Q as dt, Ur as ft, V as pt, Wr as mt, Y as ht, Yr as gt, gt as _t, ht as vt, j as yt, kr as bt, lt as xt, mt as St, oi as Ct, rt as wt, st as Tt, ut as Et, z as Dt } from "./document-CNMOilB9.js";
import { $t as Ot, Jt as kt, Kt as At, Qt as jt, Xt as Mt, Yt as Nt, en as Pt, g as Ft, h as It, i as Lt, m as Rt, qt as zt, v as Bt } from "./core-D8A0dBq3.js";
import { r as Vt } from "./meshtrace-CDhGnliO.js";
import { a as Ht, n as Ut } from "./meshFromThree-C49cjhgD.js";
var Wt = {
	"stage/template": {
		kind: "choice",
		label: "Display",
		options: [
			"studio",
			"pedestal",
			"shelf",
			"table"
		],
		default: "studio"
	},
	"stage/color": {
		kind: "color",
		label: "Backdrop",
		default: "#e9e4ef"
	},
	"stage/accent": {
		kind: "color",
		label: "Surface",
		default: "#c9b8d8"
	},
	"light/preset": {
		kind: "choice",
		label: "Lighting",
		options: [
			"soft",
			"bright",
			"dramatic"
		],
		default: "soft"
	},
	"light/angle": {
		kind: "number",
		label: "Light direction",
		min: -180,
		max: 180,
		step: 1,
		default: -55,
		unit: "°"
	},
	"item/scale": {
		kind: "number",
		label: "Size",
		min: .4,
		max: 1.6,
		step: .01,
		default: 1,
		unit: "×"
	},
	"item/turn": {
		kind: "number",
		label: "Turn",
		min: -60,
		max: 60,
		step: 1,
		default: 0,
		unit: "°"
	},
	"item/offset": {
		kind: "number",
		label: "Position",
		min: -1,
		max: 1,
		step: .01,
		default: 0
	},
	"item/base": {
		kind: "boolean",
		label: "Stand base",
		default: !0
	},
	"motion/mode": {
		kind: "choice",
		label: "Motion",
		options: ["still", "sway"],
		default: "still"
	}
};
function Gt(e) {
	let t = a(e).join("/");
	return Object.hasOwn(Wt, t) ? Wt[t] : void 0;
}
function Kt(e) {
	let t = {
		schema: "gleamshelf/scene",
		version: 1,
		stage: {},
		light: {},
		item: { aspect: e },
		motion: {},
		effects: [],
		vertex: null
	};
	for (let [e, n] of Object.entries(Wt)) t = l(t, e, n.default);
	return t;
}
function qt(e) {
	if (!(e > 0)) throw Error("A scene item needs a positive aspect ratio.");
	return Kt(e);
}
function Jt(t, r) {
	let i = qt(t);
	for (let [e, t] of Object.entries(Wt)) {
		let n = o(t, s(r, e));
		n !== void 0 && (i = l(i, e, n));
	}
	return i = l(i, "effects", e(s(r, "effects"))), i = l(i, "vertex", n([s(r, "vertex")])?.[0] ?? null), i;
}
//#endregion
//#region ../scene3d/src/sceneEditor.ts
var Yt = i(Gt), Xt = (e, t) => {
	let r = a(e).join("/");
	if (r === "effects") {
		let e = n(t);
		return e ? {
			value: e,
			label: "Effects"
		} : "invalid-value";
	}
	if (r === "vertex") {
		if (t === null) return {
			value: null,
			label: "Surface shader"
		};
		let e = n([t])?.[0];
		return e ? {
			value: e,
			label: "Surface shader"
		} : "invalid-value";
	}
	return Yt(e, t);
}, Zt = class extends c {
	constructor(e) {
		super(e, Xt);
	}
	get effects() {
		return this.doc.effects;
	}
	addEffect(e, t, n = "Add effect") {
		this.apply(n, [["effects", [...this.effects, {
			id: e,
			params: t
		}]]]);
	}
	removeEffect(e, t = "Remove effect") {
		this.apply(t, [["effects", this.effects.filter((t, n) => n !== e)]]);
	}
	moveEffect(e, t) {
		this.apply("Reorder effects", [["effects", r(this.effects, e, t)]]);
	}
	setEffectParam(e, n, r, i = "Adjust effect") {
		this.effects[e] && this.apply(i, [["effects", t(this.effects, e, n, r)]]);
	}
	setVertex(e, t = "Surface shader") {
		this.apply(t, [["vertex", e]]);
	}
	setVertexParam(e, t, n = "Adjust surface shader") {
		let r = this.doc.vertex;
		r && this.apply(n, [["vertex", {
			...r,
			params: {
				...r.params,
				[e]: t
			}
		}]]);
	}
	reset() {
		this.apply("Reset scene", [
			...Object.entries(Wt).map(([e, t]) => [e, t.default]),
			["effects", []],
			["vertex", null]
		]);
	}
}, Qt = (e, t = .85) => new ue({
	color: e,
	roughness: t,
	metalness: 0
});
function $t(e, t, n, r) {
	let i = [], a = -(t - r);
	i.push([0, t * .5], [0, a]);
	for (let e = 1; e <= 16; e++) {
		let t = e / 16 * (Math.PI / 2);
		i.push([r - Math.cos(t) * r, a - Math.sin(t) * r]);
	}
	i.push([n, a - r]);
	let o = [], s = [];
	for (let [t, n] of i) o.push(-e / 2, t, n, e / 2, t, n);
	for (let e = 0; e < i.length - 1; e++) {
		let t = e * 2;
		s.push(t, t + 1, t + 2, t + 1, t + 3, t + 2);
	}
	let c = new we();
	return c.setAttribute("position", new He(o, 3)), c.setIndex(s), c.computeVertexNormals(), c;
}
function V(e, t, { cast: n = !0 } = {}) {
	let r = new P(e, t);
	return r.receiveShadow = !0, r.castShadow = n, r;
}
function en(e, t) {
	e.add(V($t(14, 6, 6, 1.6), Qt(t), { cast: !1 }));
}
function tn(e, t, n) {
	let r = V(new F(14, 10), Qt(t), { cast: !1 });
	r.rotation.x = -Math.PI / 2;
	let i = V(new F(14, 8), Qt(t), { cast: !1 });
	i.position.set(0, 4, n), e.add(r, i);
}
function nn(e, t, n) {
	let r = new ne(), i = 0;
	switch (e) {
		case "studio":
			en(r, t);
			break;
		case "pedestal": {
			en(r, t);
			let e = .45, a = V(new A(.62, .66, e, 64), Qt(n, .6));
			a.position.y = e / 2, r.add(a), i = e;
			break;
		}
		case "shelf": {
			tn(r, t, -.75);
			let e = Qt(n, .7), a = (t) => {
				let n = V(new R(3.4, .07, .95), e);
				n.position.set(0, t, -.27), r.add(n);
			}, o = (t) => {
				let n = V(new R(.07, 2.6, .95), e);
				n.position.set(t, 1.3, -.27), r.add(n);
			};
			a(.05), a(.8), a(2.55), o(-1.7), o(1.7), i = .835;
			break;
		}
		case "table": {
			tn(r, t, -2.2);
			let e = .76, a = V(new R(3.6, .05, 1.5), Qt(n, .95));
			a.position.set(0, .735, 0);
			let o = V(new R(3.6, e, .02), Qt(n, .95));
			o.position.set(0, e / 2, .75), r.add(a, o), i = e;
			break;
		}
	}
	return {
		group: r,
		standY: i,
		dispose() {
			r.traverse((e) => {
				e instanceof P && (e.geometry.dispose(), e.material.dispose());
			});
		}
	};
}
//#endregion
//#region ../../node_modules/three/examples/jsm/controls/OrbitControls.js
var rn = { type: "change" }, an = { type: "start" }, on = { type: "end" }, sn = new te(), cn = new re(), ln = Math.cos(70 * M.DEG2RAD), H = new x(), U = 2 * Math.PI, W = {
	NONE: -1,
	ROTATE: 0,
	DOLLY: 1,
	PAN: 2,
	TOUCH_ROTATE: 3,
	TOUCH_PAN: 4,
	TOUCH_DOLLY_PAN: 5,
	TOUCH_DOLLY_ROTATE: 6
}, un = 1e-6, dn = class extends ye {
	constructor(e, t = null) {
		super(e, t), this.state = W.NONE, this.target = new x(), this.cursor = new x(), this.minDistance = 0, this.maxDistance = Infinity, this.minZoom = 0, this.maxZoom = Infinity, this.minTargetRadius = 0, this.maxTargetRadius = Infinity, this.minPolarAngle = 0, this.maxPolarAngle = Math.PI, this.minAzimuthAngle = -Infinity, this.maxAzimuthAngle = Infinity, this.enableDamping = !1, this.dampingFactor = .05, this.enableZoom = !0, this.zoomSpeed = 1, this.enableRotate = !0, this.rotateSpeed = 1, this.keyRotateSpeed = 1, this.enablePan = !0, this.panSpeed = 1, this.screenSpacePanning = !0, this.keyPanSpeed = 7, this.zoomToCursor = !1, this.autoRotate = !1, this.autoRotateSpeed = 2, this.keys = {
			LEFT: "ArrowLeft",
			UP: "ArrowUp",
			RIGHT: "ArrowRight",
			BOTTOM: "ArrowDown"
		}, this.mouseButtons = {
			LEFT: xe.ROTATE,
			MIDDLE: xe.DOLLY,
			RIGHT: xe.PAN
		}, this.touches = {
			ONE: be.ROTATE,
			TWO: be.DOLLY_PAN
		}, this.target0 = this.target.clone(), this.position0 = this.object.position.clone(), this.zoom0 = this.object.zoom, this._cursorStyle = "auto", this._domElementKeyEvents = null, this._lastPosition = new x(), this._lastQuaternion = new k(), this._lastTargetPosition = new x(), this._quat = new k().setFromUnitVectors(e.up, new x(0, 1, 0)), this._quatInverse = this._quat.clone().invert(), this._spherical = new Le(), this._sphericalDelta = new Le(), this._scale = 1, this._panOffset = new x(), this._rotateStart = new j(), this._rotateEnd = new j(), this._rotateDelta = new j(), this._panStart = new j(), this._panEnd = new j(), this._panDelta = new j(), this._dollyStart = new j(), this._dollyEnd = new j(), this._dollyDelta = new j(), this._dollyDirection = new x(), this._mouse = new j(), this._performCursorZoom = !1, this._pointers = [], this._pointerPositions = {}, this._controlActive = !1, this._onPointerMove = pn.bind(this), this._onPointerDown = fn.bind(this), this._onPointerUp = mn.bind(this), this._onContextMenu = xn.bind(this), this._onMouseWheel = _n.bind(this), this._onKeyDown = vn.bind(this), this._onTouchStart = yn.bind(this), this._onTouchMove = bn.bind(this), this._onMouseDown = hn.bind(this), this._onMouseMove = gn.bind(this), this._interceptControlDown = Sn.bind(this), this._interceptControlUp = Cn.bind(this), this.domElement !== null && this.connect(this.domElement), this.update();
	}
	set cursorStyle(e) {
		this._cursorStyle = e, e === "grab" ? this.domElement.style.cursor = "grab" : this.domElement.style.cursor = "auto";
	}
	get cursorStyle() {
		return this._cursorStyle;
	}
	connect(e) {
		super.connect(e), this.domElement.addEventListener("pointerdown", this._onPointerDown), this.domElement.addEventListener("pointercancel", this._onPointerUp), this.domElement.addEventListener("contextmenu", this._onContextMenu), this.domElement.addEventListener("wheel", this._onMouseWheel, { passive: !1 }), this.domElement.getRootNode().addEventListener("keydown", this._interceptControlDown, {
			passive: !0,
			capture: !0
		}), this.domElement.style.touchAction = "none";
	}
	disconnect() {
		this.state = W.NONE, this.domElement.removeEventListener("pointerdown", this._onPointerDown), this.domElement.ownerDocument.removeEventListener("pointermove", this._onPointerMove), this.domElement.ownerDocument.removeEventListener("pointerup", this._onPointerUp), this.domElement.removeEventListener("pointercancel", this._onPointerUp), this.domElement.removeEventListener("wheel", this._onMouseWheel), this.domElement.removeEventListener("contextmenu", this._onContextMenu), this.stopListenToKeyEvents();
		let e = this.domElement.getRootNode();
		e.removeEventListener("keydown", this._interceptControlDown, { capture: !0 }), e.removeEventListener("keyup", this._interceptControlUp, { capture: !0 }), this._controlActive = !1, this._pointers.length = 0, this._pointerPositions = {}, this.domElement.style.touchAction = "", this.domElement.style.cursor = "auto";
	}
	dispose() {
		this.disconnect();
	}
	getPolarAngle() {
		return this._spherical.phi;
	}
	getAzimuthalAngle() {
		return this._spherical.theta;
	}
	getDistance() {
		return this.object.position.distanceTo(this.target);
	}
	listenToKeyEvents(e) {
		e.addEventListener("keydown", this._onKeyDown), this._domElementKeyEvents = e;
	}
	stopListenToKeyEvents() {
		this._domElementKeyEvents !== null && (this._domElementKeyEvents.removeEventListener("keydown", this._onKeyDown), this._domElementKeyEvents = null);
	}
	saveState() {
		this.target0.copy(this.target), this.position0.copy(this.object.position), this.zoom0 = this.object.zoom;
	}
	reset() {
		this.target.copy(this.target0), this.object.position.copy(this.position0), this.object.zoom = this.zoom0, this.object.updateProjectionMatrix(), this.dispatchEvent(rn), this.update(), this.state = W.NONE;
	}
	pan(e, t) {
		this._pan(e, t), this.update();
	}
	dollyIn(e) {
		this._dollyIn(e), this.update();
	}
	dollyOut(e) {
		this._dollyOut(e), this.update();
	}
	rotateLeft(e) {
		this._rotateLeft(e), this.update();
	}
	rotateUp(e) {
		this._rotateUp(e), this.update();
	}
	update(e = null) {
		let t = this.object.position;
		H.copy(t).sub(this.target), H.applyQuaternion(this._quat), this._spherical.setFromVector3(H), this.autoRotate && this.state === W.NONE && this._rotateLeft(this._getAutoRotationAngle(e)), this.enableDamping ? (this._spherical.theta += this._sphericalDelta.theta * this.dampingFactor, this._spherical.phi += this._sphericalDelta.phi * this.dampingFactor) : (this._spherical.theta += this._sphericalDelta.theta, this._spherical.phi += this._sphericalDelta.phi);
		let n = this.minAzimuthAngle, r = this.maxAzimuthAngle;
		isFinite(n) && isFinite(r) && (n < -Math.PI ? n += U : n > Math.PI && (n -= U), r < -Math.PI ? r += U : r > Math.PI && (r -= U), n <= r ? this._spherical.theta = Math.max(n, Math.min(r, this._spherical.theta)) : this._spherical.theta = this._spherical.theta > (n + r) / 2 ? Math.max(n, this._spherical.theta) : Math.min(r, this._spherical.theta)), this._spherical.phi = Math.max(this.minPolarAngle, Math.min(this.maxPolarAngle, this._spherical.phi)), this._spherical.makeSafe(), this.enableDamping === !0 ? this.target.addScaledVector(this._panOffset, this.dampingFactor) : this.target.add(this._panOffset), this.target.sub(this.cursor), this.target.clampLength(this.minTargetRadius, this.maxTargetRadius), this.target.add(this.cursor);
		let i = !1;
		if (this.zoomToCursor && this._performCursorZoom || this.object.isOrthographicCamera) this._spherical.radius = this._clampDistance(this._spherical.radius);
		else {
			let e = this._spherical.radius;
			this._spherical.radius = this._clampDistance(this._spherical.radius * this._scale), i = e != this._spherical.radius;
		}
		if (H.setFromSpherical(this._spherical), H.applyQuaternion(this._quatInverse), t.copy(this.target).add(H), this.object.lookAt(this.target), this.enableDamping === !0 ? (this._sphericalDelta.theta *= 1 - this.dampingFactor, this._sphericalDelta.phi *= 1 - this.dampingFactor, this._panOffset.multiplyScalar(1 - this.dampingFactor)) : (this._sphericalDelta.set(0, 0, 0), this._panOffset.set(0, 0, 0)), this.zoomToCursor && this._performCursorZoom) {
			let e = null;
			if (this.object.isPerspectiveCamera) {
				let t = H.length();
				e = this._clampDistance(t * this._scale);
				let n = t - e;
				this.object.position.addScaledVector(this._dollyDirection, n), this.object.updateMatrixWorld(), i = !!n;
			} else if (this.object.isOrthographicCamera) {
				let t = new x(this._mouse.x, this._mouse.y, 0);
				t.unproject(this.object);
				let n = this.object.zoom;
				this.object.zoom = Math.max(this.minZoom, Math.min(this.maxZoom, this.object.zoom / this._scale)), this.object.updateProjectionMatrix(), i = n !== this.object.zoom;
				let r = new x(this._mouse.x, this._mouse.y, 0);
				r.unproject(this.object), this.object.position.sub(r).add(t), this.object.updateMatrixWorld(), e = H.length();
			} else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."), this.zoomToCursor = !1;
			e !== null && (this.screenSpacePanning ? this.target.set(0, 0, -1).transformDirection(this.object.matrix).multiplyScalar(e).add(this.object.position) : (sn.origin.copy(this.object.position), sn.direction.set(0, 0, -1).transformDirection(this.object.matrix), Math.abs(this.object.up.dot(sn.direction)) < ln ? this.object.lookAt(this.target) : (cn.setFromNormalAndCoplanarPoint(this.object.up, this.target), sn.intersectPlane(cn, this.target))));
		} else if (this.object.isOrthographicCamera) {
			let e = this.object.zoom;
			this.object.zoom = Math.max(this.minZoom, Math.min(this.maxZoom, this.object.zoom / this._scale)), e !== this.object.zoom && (this.object.updateProjectionMatrix(), i = !0);
		}
		return this._scale = 1, this._performCursorZoom = !1, i || this._lastPosition.distanceToSquared(this.object.position) > un || 8 * (1 - this._lastQuaternion.dot(this.object.quaternion)) > un || this._lastTargetPosition.distanceToSquared(this.target) > un ? (this.dispatchEvent(rn), this._lastPosition.copy(this.object.position), this._lastQuaternion.copy(this.object.quaternion), this._lastTargetPosition.copy(this.target), !0) : !1;
	}
	_getAutoRotationAngle(e) {
		return e === null ? U / 60 / 60 * this.autoRotateSpeed : U / 60 * this.autoRotateSpeed * e;
	}
	_getZoomScale(e) {
		let t = Math.abs(e * .01);
		return .95 ** (this.zoomSpeed * t);
	}
	_rotateLeft(e) {
		this._sphericalDelta.theta -= e;
	}
	_rotateUp(e) {
		this._sphericalDelta.phi -= e;
	}
	_panLeft(e, t) {
		H.setFromMatrixColumn(t, 0), H.multiplyScalar(-e), this._panOffset.add(H);
	}
	_panUp(e, t) {
		this.screenSpacePanning === !0 ? H.setFromMatrixColumn(t, 1) : (H.setFromMatrixColumn(t, 0), H.crossVectors(this.object.up, H)), H.multiplyScalar(e), this._panOffset.add(H);
	}
	_pan(e, t) {
		let n = this.domElement;
		if (this.object.isPerspectiveCamera) {
			let r = this.object.position;
			H.copy(r).sub(this.target);
			let i = H.length();
			i *= Math.tan(this.object.fov / 2 * Math.PI / 180), this._panLeft(2 * e * i / n.clientHeight, this.object.matrix), this._panUp(2 * t * i / n.clientHeight, this.object.matrix);
		} else this.object.isOrthographicCamera ? (this._panLeft(e * (this.object.right - this.object.left) / this.object.zoom / n.clientWidth, this.object.matrix), this._panUp(t * (this.object.top - this.object.bottom) / this.object.zoom / n.clientHeight, this.object.matrix)) : (console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."), this.enablePan = !1);
	}
	_dollyOut(e) {
		this.object.isPerspectiveCamera || this.object.isOrthographicCamera ? this._scale /= e : (console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."), this.enableZoom = !1);
	}
	_dollyIn(e) {
		this.object.isPerspectiveCamera || this.object.isOrthographicCamera ? this._scale *= e : (console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."), this.enableZoom = !1);
	}
	_updateZoomParameters(e, t) {
		if (!this.zoomToCursor) return;
		this._performCursorZoom = !0;
		let n = this.domElement.getBoundingClientRect(), r = e - n.left, i = t - n.top, a = n.width, o = n.height;
		this._mouse.x = r / a * 2 - 1, this._mouse.y = -(i / o) * 2 + 1, this._dollyDirection.set(this._mouse.x, this._mouse.y, 1).unproject(this.object).sub(this.object.position).normalize();
	}
	_clampDistance(e) {
		return Math.max(this.minDistance, Math.min(this.maxDistance, e));
	}
	_handleMouseDownRotate(e) {
		this._rotateStart.set(e.clientX, e.clientY);
	}
	_handleMouseDownDolly(e) {
		this._updateZoomParameters(e.clientX, e.clientX), this._dollyStart.set(e.clientX, e.clientY);
	}
	_handleMouseDownPan(e) {
		this._panStart.set(e.clientX, e.clientY);
	}
	_handleMouseMoveRotate(e) {
		this._rotateEnd.set(e.clientX, e.clientY), this._rotateDelta.subVectors(this._rotateEnd, this._rotateStart).multiplyScalar(this.rotateSpeed);
		let t = this.domElement;
		this._rotateLeft(U * this._rotateDelta.x / t.clientHeight), this._rotateUp(U * this._rotateDelta.y / t.clientHeight), this._rotateStart.copy(this._rotateEnd), this.update();
	}
	_handleMouseMoveDolly(e) {
		this._dollyEnd.set(e.clientX, e.clientY), this._dollyDelta.subVectors(this._dollyEnd, this._dollyStart), this._dollyDelta.y > 0 ? this._dollyOut(this._getZoomScale(this._dollyDelta.y)) : this._dollyDelta.y < 0 && this._dollyIn(this._getZoomScale(this._dollyDelta.y)), this._dollyStart.copy(this._dollyEnd), this.update();
	}
	_handleMouseMovePan(e) {
		this._panEnd.set(e.clientX, e.clientY), this._panDelta.subVectors(this._panEnd, this._panStart).multiplyScalar(this.panSpeed), this._pan(this._panDelta.x, this._panDelta.y), this._panStart.copy(this._panEnd), this.update();
	}
	_handleMouseWheel(e) {
		this._updateZoomParameters(e.clientX, e.clientY), e.deltaY < 0 ? this._dollyIn(this._getZoomScale(e.deltaY)) : e.deltaY > 0 && this._dollyOut(this._getZoomScale(e.deltaY)), this.update();
	}
	_handleKeyDown(e) {
		let t = !1;
		switch (e.code) {
			case this.keys.UP:
				e.ctrlKey || e.metaKey || e.shiftKey ? this.enableRotate && this._rotateUp(U * this.keyRotateSpeed / this.domElement.clientHeight) : this.enablePan && this._pan(0, this.keyPanSpeed), t = !0;
				break;
			case this.keys.BOTTOM:
				e.ctrlKey || e.metaKey || e.shiftKey ? this.enableRotate && this._rotateUp(-U * this.keyRotateSpeed / this.domElement.clientHeight) : this.enablePan && this._pan(0, -this.keyPanSpeed), t = !0;
				break;
			case this.keys.LEFT:
				e.ctrlKey || e.metaKey || e.shiftKey ? this.enableRotate && this._rotateLeft(U * this.keyRotateSpeed / this.domElement.clientHeight) : this.enablePan && this._pan(this.keyPanSpeed, 0), t = !0;
				break;
			case this.keys.RIGHT: e.ctrlKey || e.metaKey || e.shiftKey ? this.enableRotate && this._rotateLeft(-U * this.keyRotateSpeed / this.domElement.clientHeight) : this.enablePan && this._pan(-this.keyPanSpeed, 0), t = !0;
		}
		t && (e.preventDefault(), this.update());
	}
	_handleTouchStartRotate(e) {
		if (this._pointers.length === 1) this._rotateStart.set(e.pageX, e.pageY);
		else {
			let t = this._getSecondPointerPosition(e), n = .5 * (e.pageX + t.x), r = .5 * (e.pageY + t.y);
			this._rotateStart.set(n, r);
		}
	}
	_handleTouchStartPan(e) {
		if (this._pointers.length === 1) this._panStart.set(e.pageX, e.pageY);
		else {
			let t = this._getSecondPointerPosition(e), n = .5 * (e.pageX + t.x), r = .5 * (e.pageY + t.y);
			this._panStart.set(n, r);
		}
	}
	_handleTouchStartDolly(e) {
		let t = this._getSecondPointerPosition(e), n = e.pageX - t.x, r = e.pageY - t.y, i = Math.sqrt(n * n + r * r);
		this._dollyStart.set(0, i);
	}
	_handleTouchStartDollyPan(e) {
		this.enableZoom && this._handleTouchStartDolly(e), this.enablePan && this._handleTouchStartPan(e);
	}
	_handleTouchStartDollyRotate(e) {
		this.enableZoom && this._handleTouchStartDolly(e), this.enableRotate && this._handleTouchStartRotate(e);
	}
	_handleTouchMoveRotate(e) {
		if (this._pointers.length == 1) this._rotateEnd.set(e.pageX, e.pageY);
		else {
			let t = this._getSecondPointerPosition(e), n = .5 * (e.pageX + t.x), r = .5 * (e.pageY + t.y);
			this._rotateEnd.set(n, r);
		}
		this._rotateDelta.subVectors(this._rotateEnd, this._rotateStart).multiplyScalar(this.rotateSpeed);
		let t = this.domElement;
		this._rotateLeft(U * this._rotateDelta.x / t.clientHeight), this._rotateUp(U * this._rotateDelta.y / t.clientHeight), this._rotateStart.copy(this._rotateEnd);
	}
	_handleTouchMovePan(e) {
		if (this._pointers.length === 1) this._panEnd.set(e.pageX, e.pageY);
		else {
			let t = this._getSecondPointerPosition(e), n = .5 * (e.pageX + t.x), r = .5 * (e.pageY + t.y);
			this._panEnd.set(n, r);
		}
		this._panDelta.subVectors(this._panEnd, this._panStart).multiplyScalar(this.panSpeed), this._pan(this._panDelta.x, this._panDelta.y), this._panStart.copy(this._panEnd);
	}
	_handleTouchMoveDolly(e) {
		let t = this._getSecondPointerPosition(e), n = e.pageX - t.x, r = e.pageY - t.y, i = Math.sqrt(n * n + r * r);
		this._dollyEnd.set(0, i), this._dollyDelta.set(0, (this._dollyEnd.y / this._dollyStart.y) ** +this.zoomSpeed), this._dollyOut(this._dollyDelta.y), this._dollyStart.copy(this._dollyEnd);
		let a = (e.pageX + t.x) * .5, o = (e.pageY + t.y) * .5;
		this._updateZoomParameters(a, o);
	}
	_handleTouchMoveDollyPan(e) {
		this.enableZoom && this._handleTouchMoveDolly(e), this.enablePan && this._handleTouchMovePan(e);
	}
	_handleTouchMoveDollyRotate(e) {
		this.enableZoom && this._handleTouchMoveDolly(e), this.enableRotate && this._handleTouchMoveRotate(e);
	}
	_addPointer(e) {
		this._pointers.push(e.pointerId);
	}
	_removePointer(e) {
		delete this._pointerPositions[e.pointerId];
		for (let t = 0; t < this._pointers.length; t++) if (this._pointers[t] == e.pointerId) {
			this._pointers.splice(t, 1);
			return;
		}
	}
	_isTrackingPointer(e) {
		for (let t = 0; t < this._pointers.length; t++) if (this._pointers[t] == e.pointerId) return !0;
		return !1;
	}
	_trackPointer(e) {
		let t = this._pointerPositions[e.pointerId];
		t === void 0 && (t = new j(), this._pointerPositions[e.pointerId] = t), t.set(e.pageX, e.pageY);
	}
	_getSecondPointerPosition(e) {
		let t = e.pointerId === this._pointers[0] ? this._pointers[1] : this._pointers[0];
		return this._pointerPositions[t];
	}
	_customWheelEvent(e) {
		let t = e.deltaMode, n = {
			clientX: e.clientX,
			clientY: e.clientY,
			deltaY: e.deltaY
		};
		switch (t) {
			case 1:
				n.deltaY *= 16;
				break;
			case 2: n.deltaY *= 100;
		}
		return e.ctrlKey && !this._controlActive && (n.deltaY *= 10), n;
	}
};
function fn(e) {
	this.enabled !== !1 && (this._pointers.length === 0 && (this.domElement.setPointerCapture(e.pointerId), this.domElement.ownerDocument.addEventListener("pointermove", this._onPointerMove), this.domElement.ownerDocument.addEventListener("pointerup", this._onPointerUp)), !this._isTrackingPointer(e) && (this._addPointer(e), e.pointerType === "touch" ? this._onTouchStart(e) : this._onMouseDown(e), this._cursorStyle === "grab" && (this.domElement.style.cursor = "grabbing")));
}
function pn(e) {
	this.enabled !== !1 && (e.pointerType === "touch" ? this._onTouchMove(e) : this._onMouseMove(e));
}
function mn(e) {
	switch (this._removePointer(e), this._pointers.length) {
		case 0:
			this.domElement.releasePointerCapture(e.pointerId), this.domElement.ownerDocument.removeEventListener("pointermove", this._onPointerMove), this.domElement.ownerDocument.removeEventListener("pointerup", this._onPointerUp), this.dispatchEvent(on), this.state = W.NONE, this._cursorStyle === "grab" && (this.domElement.style.cursor = "grab");
			break;
		case 1:
			let t = this._pointers[0], n = this._pointerPositions[t];
			this._onTouchStart({
				pointerId: t,
				pageX: n.x,
				pageY: n.y
			});
	}
}
function hn(e) {
	let t;
	switch (e.button) {
		case 0:
			t = this.mouseButtons.LEFT;
			break;
		case 1:
			t = this.mouseButtons.MIDDLE;
			break;
		case 2:
			t = this.mouseButtons.RIGHT;
			break;
		default: t = -1;
	}
	switch (t) {
		case xe.DOLLY:
			if (this.enableZoom === !1) return;
			this._handleMouseDownDolly(e), this.state = W.DOLLY;
			break;
		case xe.ROTATE:
			if (e.ctrlKey || e.metaKey || e.shiftKey) {
				if (this.enablePan === !1) return;
				this._handleMouseDownPan(e), this.state = W.PAN;
			} else {
				if (this.enableRotate === !1) return;
				this._handleMouseDownRotate(e), this.state = W.ROTATE;
			}
			break;
		case xe.PAN:
			if (e.ctrlKey || e.metaKey || e.shiftKey) {
				if (this.enableRotate === !1) return;
				this._handleMouseDownRotate(e), this.state = W.ROTATE;
			} else {
				if (this.enablePan === !1) return;
				this._handleMouseDownPan(e), this.state = W.PAN;
			}
			break;
		default: this.state = W.NONE;
	}
	this.state !== W.NONE && this.dispatchEvent(an);
}
function gn(e) {
	switch (this.state) {
		case W.ROTATE:
			if (this.enableRotate === !1) return;
			this._handleMouseMoveRotate(e);
			break;
		case W.DOLLY:
			if (this.enableZoom === !1) return;
			this._handleMouseMoveDolly(e);
			break;
		case W.PAN:
			if (this.enablePan === !1) return;
			this._handleMouseMovePan(e);
	}
}
function _n(e) {
	this.enabled !== !1 && this.enableZoom !== !1 && this.state === W.NONE && (e.preventDefault(), this.dispatchEvent(an), this._handleMouseWheel(this._customWheelEvent(e)), this.dispatchEvent(on));
}
function vn(e) {
	this.enabled !== !1 && this._handleKeyDown(e);
}
function yn(e) {
	switch (this._trackPointer(e), this._pointers.length) {
		case 1:
			switch (this.touches.ONE) {
				case be.ROTATE:
					if (this.enableRotate === !1) return;
					this._handleTouchStartRotate(e), this.state = W.TOUCH_ROTATE;
					break;
				case be.PAN:
					if (this.enablePan === !1) return;
					this._handleTouchStartPan(e), this.state = W.TOUCH_PAN;
					break;
				default: this.state = W.NONE;
			}
			break;
		case 2:
			switch (this.touches.TWO) {
				case be.DOLLY_PAN:
					if (this.enableZoom === !1 && this.enablePan === !1) return;
					this._handleTouchStartDollyPan(e), this.state = W.TOUCH_DOLLY_PAN;
					break;
				case be.DOLLY_ROTATE:
					if (this.enableZoom === !1 && this.enableRotate === !1) return;
					this._handleTouchStartDollyRotate(e), this.state = W.TOUCH_DOLLY_ROTATE;
					break;
				default: this.state = W.NONE;
			}
			break;
		default: this.state = W.NONE;
	}
	this.state !== W.NONE && this.dispatchEvent(an);
}
function bn(e) {
	switch (this._trackPointer(e), this.state) {
		case W.TOUCH_ROTATE:
			if (this.enableRotate === !1) return;
			this._handleTouchMoveRotate(e), this.update();
			break;
		case W.TOUCH_PAN:
			if (this.enablePan === !1) return;
			this._handleTouchMovePan(e), this.update();
			break;
		case W.TOUCH_DOLLY_PAN:
			if (this.enableZoom === !1 && this.enablePan === !1) return;
			this._handleTouchMoveDollyPan(e), this.update();
			break;
		case W.TOUCH_DOLLY_ROTATE:
			if (this.enableZoom === !1 && this.enableRotate === !1) return;
			this._handleTouchMoveDollyRotate(e), this.update();
			break;
		default: this.state = W.NONE;
	}
}
function xn(e) {
	this.enabled !== !1 && e.preventDefault();
}
function Sn(e) {
	e.key === "Control" && (this._controlActive = !0, this.domElement.getRootNode().addEventListener("keyup", this._interceptControlUp, {
		passive: !0,
		capture: !0
	}));
}
function Cn(e) {
	e.key === "Control" && (this._controlActive = !1, this.domElement.getRootNode().removeEventListener("keyup", this._interceptControlUp, {
		passive: !0,
		capture: !0
	}));
}
//#endregion
//#region ../../node_modules/three/examples/jsm/shaders/CopyShader.js
var wn = {
	name: "CopyShader",
	uniforms: {
		tDiffuse: { value: null },
		opacity: { value: 1 }
	},
	vertexShader: "\n\n		varying vec2 vUv;\n\n		void main() {\n\n			vUv = uv;\n			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );\n\n		}",
	fragmentShader: "\n\n		uniform float opacity;\n\n		uniform sampler2D tDiffuse;\n\n		varying vec2 vUv;\n\n		void main() {\n\n			vec4 texel = texture2D( tDiffuse, vUv );\n			gl_FragColor = opacity * texel;\n\n\n		}"
}, Tn = class {
	constructor() {
		this.isPass = !0, this.enabled = !0, this.needsSwap = !0, this.clear = !1, this.renderToScreen = !1;
	}
	setSize() {}
	render() {
		console.error("THREE.Pass: .render() must be implemented in derived pass.");
	}
	dispose() {}
}, En = new y(-1, 1, 1, -1, 0, 1), Dn = new class extends we {
	constructor() {
		super(), this.setAttribute("position", new He([
			-1,
			3,
			0,
			-1,
			-1,
			0,
			3,
			-1,
			0
		], 3)), this.setAttribute("uv", new He([
			0,
			2,
			0,
			0,
			2,
			0
		], 2));
	}
}(), On = class {
	constructor(e) {
		this._mesh = new P(Dn, e);
	}
	dispose() {
		this._mesh.geometry.dispose();
	}
	render(e) {
		e.render(this._mesh, En);
	}
	get material() {
		return this._mesh.material;
	}
	set material(e) {
		this._mesh.material = e;
	}
}, kn = class extends Tn {
	constructor(e, t = "tDiffuse") {
		super(), this.textureID = t, this.uniforms = null, this.material = null, e instanceof I ? (this.uniforms = e.uniforms, this.material = e) : e && (this.uniforms = Fe.clone(e.uniforms), this.material = new I({
			name: e.name === void 0 ? "unspecified" : e.name,
			defines: Object.assign({}, e.defines),
			uniforms: this.uniforms,
			vertexShader: e.vertexShader,
			fragmentShader: e.fragmentShader
		})), this._fsQuad = new On(this.material);
	}
	render(e, t, n) {
		this.uniforms[this.textureID] && (this.uniforms[this.textureID].value = n.texture), this._fsQuad.material = this.material, this.renderToScreen ? (e.setRenderTarget(null), this._fsQuad.render(e)) : (e.setRenderTarget(t), this.clear && e.clear(e.autoClearColor, e.autoClearDepth, e.autoClearStencil), this._fsQuad.render(e));
	}
	dispose() {
		this.material.dispose(), this._fsQuad.dispose();
	}
}, An = class extends Tn {
	constructor(e, t) {
		super(), this.scene = e, this.camera = t, this.clear = !0, this.needsSwap = !1, this.inverse = !1;
	}
	render(e, t, n) {
		let r = e.getContext(), i = e.state;
		i.buffers.color.setMask(!1), i.buffers.depth.setMask(!1), i.buffers.color.setLocked(!0), i.buffers.depth.setLocked(!0);
		let a, o;
		this.inverse ? (a = 0, o = 1) : (a = 1, o = 0), i.buffers.stencil.setTest(!0), i.buffers.stencil.setOp(r.REPLACE, r.REPLACE, r.REPLACE), i.buffers.stencil.setFunc(r.ALWAYS, a, 4294967295), i.buffers.stencil.setClear(o), i.buffers.stencil.setLocked(!0), e.setRenderTarget(n), this.clear && e.clear(), e.render(this.scene, this.camera), e.setRenderTarget(t), this.clear && e.clear(), e.render(this.scene, this.camera), i.buffers.color.setLocked(!1), i.buffers.depth.setLocked(!1), i.buffers.color.setMask(!0), i.buffers.depth.setMask(!0), i.buffers.stencil.setLocked(!1), i.buffers.stencil.setFunc(r.EQUAL, 1, 4294967295), i.buffers.stencil.setOp(r.KEEP, r.KEEP, r.KEEP), i.buffers.stencil.setLocked(!0);
	}
}, jn = class extends Tn {
	constructor() {
		super(), this.needsSwap = !1;
	}
	render(e) {
		e.state.buffers.stencil.setLocked(!1), e.state.buffers.stencil.setTest(!1);
	}
}, Mn = class {
	constructor(e, t) {
		if (this.renderer = e, this._pixelRatio = e.getPixelRatio(), t === void 0) {
			let n = e.getSize(new j());
			this._width = n.width, this._height = n.height, t = new de(this._width * this._pixelRatio, this._height * this._pixelRatio, { type: ae }), t.texture.name = "EffectComposer.rt1";
		} else this._width = t.width, this._height = t.height;
		this.renderTarget1 = t, this.renderTarget2 = t.clone(), this.renderTarget2.texture.name = "EffectComposer.rt2", this.writeBuffer = this.renderTarget1, this.readBuffer = this.renderTarget2, this.renderToScreen = !0, this.passes = [], this.copyPass = new kn(wn), this.copyPass.material.blending = 0, this.timer = new Ce();
	}
	swapBuffers() {
		let e = this.readBuffer;
		this.readBuffer = this.writeBuffer, this.writeBuffer = e;
	}
	addPass(e) {
		this.passes.push(e), e.setSize(this._width * this._pixelRatio, this._height * this._pixelRatio);
	}
	insertPass(e, t) {
		this.passes.splice(t, 0, e), e.setSize(this._width * this._pixelRatio, this._height * this._pixelRatio);
	}
	removePass(e) {
		let t = this.passes.indexOf(e);
		t !== -1 && this.passes.splice(t, 1);
	}
	isLastEnabledPass(e) {
		for (let t = e + 1; t < this.passes.length; t++) if (this.passes[t].enabled) return !1;
		return !0;
	}
	render(e) {
		this.timer.update(), e === void 0 && (e = this.timer.getDelta());
		let t = this.renderer.getRenderTarget(), n = !1;
		for (let t = 0, r = this.passes.length; t < r; t++) {
			let r = this.passes[t];
			if (r.enabled !== !1) {
				if (r.renderToScreen = this.renderToScreen && this.isLastEnabledPass(t), r.render(this.renderer, this.writeBuffer, this.readBuffer, e, n), r.needsSwap) {
					if (n) {
						let t = this.renderer.getContext(), n = this.renderer.state.buffers.stencil;
						n.setFunc(t.NOTEQUAL, 1, 4294967295), this.copyPass.render(this.renderer, this.writeBuffer, this.readBuffer, e), n.setFunc(t.EQUAL, 1, 4294967295);
					}
					this.swapBuffers();
				}
				An !== void 0 && (r instanceof An ? n = !0 : r instanceof jn && (n = !1));
			}
		}
		this.renderer.setRenderTarget(t);
	}
	reset(e) {
		if (e === void 0) {
			let t = this.renderer.getSize(new j());
			this._pixelRatio = this.renderer.getPixelRatio(), this._width = t.width, this._height = t.height, e = this.renderTarget1.clone(), e.setSize(this._width * this._pixelRatio, this._height * this._pixelRatio);
		}
		this.renderTarget1.dispose(), this.renderTarget2.dispose(), this.renderTarget1 = e, this.renderTarget2 = e.clone(), this.writeBuffer = this.renderTarget1, this.readBuffer = this.renderTarget2;
	}
	setSize(e, t) {
		this._width = e, this._height = t;
		let n = this._width * this._pixelRatio, r = this._height * this._pixelRatio;
		this.renderTarget1.setSize(n, r), this.renderTarget2.setSize(n, r);
		for (let e = 0; e < this.passes.length; e++) this.passes[e].setSize(n, r);
	}
	setPixelRatio(e) {
		this._pixelRatio = e, this.setSize(this._width, this._height);
	}
	dispose() {
		this.renderTarget1.dispose(), this.renderTarget2.dispose(), this.copyPass.dispose();
	}
}, Nn = {
	name: "OutputShader",
	uniforms: {
		tDiffuse: { value: null },
		toneMappingExposure: { value: 1 }
	},
	vertexShader: "\n		precision highp float;\n\n		uniform mat4 modelViewMatrix;\n		uniform mat4 projectionMatrix;\n\n		attribute vec3 position;\n		attribute vec2 uv;\n\n		varying vec2 vUv;\n\n		void main() {\n\n			vUv = uv;\n			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );\n\n		}",
	fragmentShader: "\n\n		precision highp float;\n\n		uniform sampler2D tDiffuse;\n\n		#include <tonemapping_pars_fragment>\n		#include <colorspace_pars_fragment>\n\n		varying vec2 vUv;\n\n		void main() {\n\n			gl_FragColor = texture2D( tDiffuse, vUv );\n\n			// tone mapping\n\n			#ifdef LINEAR_TONE_MAPPING\n\n				gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );\n\n			#elif defined( REINHARD_TONE_MAPPING )\n\n				gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );\n\n			#elif defined( CINEON_TONE_MAPPING )\n\n				gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );\n\n			#elif defined( ACES_FILMIC_TONE_MAPPING )\n\n				gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );\n\n			#elif defined( AGX_TONE_MAPPING )\n\n				gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );\n\n			#elif defined( NEUTRAL_TONE_MAPPING )\n\n				gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );\n\n			#elif defined( CUSTOM_TONE_MAPPING )\n\n				gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );\n\n			#endif\n\n			// color space\n\n			#ifdef SRGB_TRANSFER\n\n				gl_FragColor = sRGBTransferOETF( gl_FragColor );\n\n			#endif\n\n		}"
}, Pn = class extends Tn {
	constructor() {
		super(), this.isOutputPass = !0, this.uniforms = Fe.clone(Nn.uniforms), this.material = new pe({
			name: Nn.name,
			uniforms: this.uniforms,
			vertexShader: Nn.vertexShader,
			fragmentShader: Nn.fragmentShader
		}), this._fsQuad = new On(this.material), this._outputColorSpace = null, this._toneMapping = null;
	}
	render(e, t, n) {
		this.uniforms.tDiffuse.value = n.texture, this.uniforms.toneMappingExposure.value = e.toneMappingExposure, (this._outputColorSpace !== e.outputColorSpace || this._toneMapping !== e.toneMapping) && (this._outputColorSpace = e.outputColorSpace, this._toneMapping = e.toneMapping, this.material.defines = {}, De.getTransfer(this._outputColorSpace) === "srgb" && (this.material.defines.SRGB_TRANSFER = ""), this._toneMapping === 1 ? this.material.defines.LINEAR_TONE_MAPPING = "" : this._toneMapping === 2 ? this.material.defines.REINHARD_TONE_MAPPING = "" : this._toneMapping === 3 ? this.material.defines.CINEON_TONE_MAPPING = "" : this._toneMapping === 4 ? this.material.defines.ACES_FILMIC_TONE_MAPPING = "" : this._toneMapping === 6 ? this.material.defines.AGX_TONE_MAPPING = "" : this._toneMapping === 7 ? this.material.defines.NEUTRAL_TONE_MAPPING = "" : this._toneMapping === 5 && (this.material.defines.CUSTOM_TONE_MAPPING = ""), this.material.needsUpdate = !0), this.renderToScreen === !0 ? (e.setRenderTarget(null), this._fsQuad.render(e)) : (e.setRenderTarget(t), this.clear && e.clear(e.autoClearColor, e.autoClearDepth, e.autoClearStencil), this._fsQuad.render(e));
	}
	dispose() {
		this.material.dispose(), this._fsQuad.dispose();
	}
}, Fn = class extends Tn {
	constructor(e, t, n = null, r = null, i = null) {
		super(), this.scene = e, this.camera = t, this.overrideMaterial = n, this.clearColor = r, this.clearAlpha = i, this.clear = !0, this.clearDepth = !1, this.needsSwap = !1, this.isRenderPass = !0, this._oldClearColor = new Oe();
	}
	render(e, t, n) {
		let r = e.autoClear;
		e.autoClear = !1;
		let i, a;
		this.overrideMaterial !== null && (a = this.scene.overrideMaterial, this.scene.overrideMaterial = this.overrideMaterial), this.clearColor !== null && (e.getClearColor(this._oldClearColor), e.setClearColor(this.clearColor, e.getClearAlpha())), this.clearAlpha !== null && (i = e.getClearAlpha(), e.setClearAlpha(this.clearAlpha)), this.clearDepth == 1 && e.clearDepth(), e.setRenderTarget(this.renderToScreen ? null : n), this.clear === !0 && e.clear(e.autoClearColor, e.autoClearDepth, e.autoClearStencil), e.render(this.scene, this.camera), this.clearColor !== null && e.setClearColor(this._oldClearColor), this.clearAlpha !== null && e.setClearAlpha(i), this.overrideMaterial !== null && (this.scene.overrideMaterial = a), e.autoClear = r;
	}
}, In = {
	soft: {
		ambient: 2.2,
		key: 1.4,
		warmth: "#ffffff",
		softness: 8,
		contact: .55
	},
	bright: {
		ambient: 3,
		key: 1.1,
		warmth: "#ffffff",
		softness: 5,
		contact: .4
	},
	dramatic: {
		ambient: .7,
		key: 3,
		warmth: "#ffe2c4",
		softness: 2,
		contact: .7
	}
};
function Ln() {
	let e = document.createElement("canvas");
	e.width = e.height = 128;
	let t = e.getContext("2d"), n = t.createRadialGradient(64, 64, 0, 64, 64, 64);
	n.addColorStop(0, "rgba(0,0,0,0.85)"), n.addColorStop(.45, "rgba(0,0,0,0.35)"), n.addColorStop(1, "rgba(0,0,0,0)"), t.fillStyle = n, t.fillRect(0, 0, 128, 128);
	let r = new Pe(e);
	return r.colorSpace = oe, r;
}
function Rn(e, t, n, r) {
	let i = t.params.find((e) => e.key === n), a = g(i, r);
	if (Array.isArray(a)) {
		let t = e.value ?? new x();
		t.set(a[0], a[1], a[2]), e.value = t;
	} else e.value = i.glslType === "bool" ? a === 1 : a;
}
function zn(e) {
	return Object.fromEntries(e.params.map((e) => [e.uniform, { value: e.glslType === "vec3" ? new x() : 0 }]));
}
var Bn = 22, Vn = 6, Hn = .035, Un = 32, Wn = class {
	canvas;
	renderer;
	scene = new O();
	camera = new _e(32, 1, .05, 100);
	controls;
	ambient = new Ie("#ffffff", "#888888", 2);
	key = new le("#ffffff", 1.4);
	item = new ne();
	front;
	back;
	base;
	contact;
	stage = null;
	stageKey = "";
	doc = null;
	texture = null;
	dirty = !0;
	framed = !1;
	startedAt = performance.now();
	vertexId = "";
	vertexDef = null;
	vertexUniforms = { uTime: { value: 0 } };
	composer = null;
	effectKey = "";
	effectPasses = [];
	animated = !1;
	constructor(e) {
		this.canvas = e, this.renderer = new qe({
			canvas: e,
			antialias: !0
		}), this.renderer.outputColorSpace = oe, this.renderer.toneMapping = 7, this.renderer.shadowMap.enabled = !0, this.renderer.shadowMap.type = 1, this.key.castShadow = !0, this.key.shadow.mapSize.set(2048, 2048), this.key.shadow.bias = -5e-4, this.key.shadow.normalBias = .02;
		let t = this.key.shadow.camera;
		t.left = -3, t.right = 3, t.top = 4, t.bottom = -2, t.near = .5, t.far = 20, this.scene.add(this.ambient, this.key, this.key.target, this.item);
		let n = new E({
			alphaTest: .5,
			toneMapped: !1,
			side: 0
		});
		this.front = new P(new F(1, 1, Un, Un), n), this.front.castShadow = !0;
		let r = new E({
			alphaTest: .5,
			color: "#3b3b44",
			side: 0
		});
		this.back = new P(new F(1, 1, Un, Un), r), this.back.rotation.y = Math.PI, this.base = new P(new R(1, Hn, .22), new ue({
			color: "#1d1d24",
			roughness: .35
		})), this.base.castShadow = !0, this.base.receiveShadow = !0, this.contact = new P(new F(1, 1), new E({
			map: Ln(),
			transparent: !0,
			depthWrite: !1,
			toneMapped: !1
		})), this.contact.rotation.x = -Math.PI / 2, this.contact.position.y = .002, this.contact.renderOrder = -1, this.item.add(this.front, this.back, this.base, this.contact), this.controls = new dn(this.camera, e), this.controls.enableDamping = !0, this.controls.enablePan = !1, this.controls.minDistance = 1.2, this.controls.maxDistance = 9, this.controls.maxPolarAngle = Math.PI / 2 - .04, this.controls.addEventListener("change", () => this.dirty = !0), this.renderer.setAnimationLoop(() => this.tick());
	}
	setImage(e) {
		this.texture?.dispose();
		let t = new Ne(e);
		t.colorSpace = oe, t.flipY = !1, t.repeat.set(1, -1), t.offset.set(0, 1), t.anisotropy = this.renderer.capabilities.getMaxAnisotropy(), t.needsUpdate = !0, this.texture = t, this.front.material.map = t, this.back.material.map = t, this.front.material.needsUpdate = !0, this.back.material.needsUpdate = !0, this.dirty = !0;
	}
	update(e) {
		let t = this.doc;
		this.doc = e;
		let n = `${e.stage.template}|${e.stage.color}|${e.stage.accent}`;
		n !== this.stageKey && (this.stage?.dispose(), this.stage && this.scene.remove(this.stage.group), this.stage = nn(e.stage.template, e.stage.color, e.stage.accent), this.scene.add(this.stage.group), this.scene.background = new Oe(e.stage.color), this.stageKey = n);
		let r = In[e.light.preset];
		this.ambient.intensity = r.ambient, this.ambient.groundColor.set(e.stage.accent), this.key.intensity = r.key, this.key.color.set(r.warmth), this.key.shadow.radius = r.softness;
		let i = M.degToRad(e.light.angle);
		this.key.position.set(Math.sin(i) * 4.5, 3.5, Math.cos(i) * 4.5);
		let a = e.item.scale, o = a * e.item.aspect, s = e.item.base ? Hn : 0;
		for (let e of [this.front, this.back]) e.position.y = s + a / 2;
		this.front.scale.set(o, a, 1), this.back.scale.set(-o, a, 1), this.base.visible = e.item.base, this.base.scale.set(o * .75, 1, Math.max(.5, a * .5)), this.base.position.y = Hn / 2, this.contact.scale.set(o * 1.15, Math.max(.35, o * .45), 1), this.contact.material.opacity = r.contact, this.item.position.set(e.item.offset * 1.2, this.stage.standY, 0), this.key.target.position.copy(this.item.position), this.applyShaders(e), (!this.framed || t?.stage.template !== e.stage.template) && this.resetView(), this.dirty = !0;
	}
	resetView() {
		if (!this.doc || !this.stage) return;
		let e = this.doc.item.scale, t = new x(this.item.position.x, this.stage.standY + e * .5, 0), n = M.degToRad(this.camera.fov), r = e * .85 / Math.tan(n / 2) + .4, i = M.degToRad(18), a = M.degToRad(10);
		this.camera.position.set(t.x + Math.sin(i) * Math.cos(a) * r, t.y + Math.sin(a) * r, t.z + Math.cos(i) * Math.cos(a) * r), this.controls.target.copy(t), this.controls.update(), this.framed = !0, this.dirty = !0;
	}
	resize(e, t) {
		this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2)), this.renderer.setSize(e, t, !1), this.syncComposerSize(), this.camera.aspect = e / Math.max(1, t), this.camera.updateProjectionMatrix(), this.dirty = !0;
	}
	async exportImage({ width: e, height: t, type: n = "image/png", quality: r = .92 }) {
		let i = this.renderer.getPixelRatio(), a = this.renderer.getSize(new j());
		this.renderer.setPixelRatio(1), this.renderer.setSize(e, t, !1), this.syncComposerSize(), this.camera.aspect = e / t, this.camera.updateProjectionMatrix(), this.renderFrame();
		let o = new Promise((e, t) => this.canvas.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("This browser could not encode the image.")), n, r));
		return this.renderer.setPixelRatio(i), this.renderer.setSize(a.x, a.y, !1), this.syncComposerSize(), this.camera.aspect = a.x / Math.max(1, a.y), this.camera.updateProjectionMatrix(), this.dirty = !0, o;
	}
	dispose() {
		this.renderer.setAnimationLoop(null), this.composer?.dispose();
		for (let { pass: e } of this.effectPasses) e.dispose();
		this.controls.dispose(), this.stage?.dispose(), this.texture?.dispose(), this.contact.material.map?.dispose();
		for (let e of [
			this.front,
			this.back,
			this.base,
			this.contact
		]) e.geometry.dispose(), e.material.dispose();
		this.renderer.dispose();
	}
	tick() {
		let e = this.controls.update(), t = this.doc?.motion.mode === "sway" || this.animated;
		this.vertexUniforms.uTime.value = (performance.now() - this.startedAt) / 1e3;
		for (let { uniforms: e } of this.effectPasses) e.uTime.value = (performance.now() - this.startedAt) / 1e3;
		let n = M.degToRad(this.doc?.item.turn ?? 0);
		if (this.doc?.motion.mode === "sway") {
			let e = (performance.now() - this.startedAt) / 1e3;
			this.item.rotation.y = n + M.degToRad(Bn) * Math.sin(e / Vn * Math.PI * 2);
		} else this.item.rotation.y !== n && (this.item.rotation.y = n, this.dirty = !0);
		(this.dirty || e || t) && (this.dirty = !1, this.renderFrame());
	}
	renderFrame() {
		if (!this.composer) return this.renderer.render(this.scene, this.camera);
		let e = this.renderer.getDrawingBufferSize(new j());
		for (let { uniforms: t } of this.effectPasses) t.uResolution.value.copy(e);
		this.composer.render();
	}
	syncComposerSize() {
		if (!this.composer) return;
		let e = this.renderer.getSize(new j());
		this.composer.setPixelRatio(this.renderer.getPixelRatio()), this.composer.setSize(e.x, e.y);
	}
	applyShaders(e) {
		this.applyVertex(e.vertex), this.applyEffects(e.effects), this.animated = !!this.vertexDef?.animated || this.effectPasses.some((e) => e.def.animated);
	}
	applyVertex(e) {
		let t = e && p(e.id) || null, n = t?.id ?? "";
		if (n !== this.vertexId) {
			this.vertexId = n, this.vertexDef = t, this.vertexUniforms = {
				uTime: this.vertexUniforms.uTime ?? { value: 0 },
				...t ? zn(t) : {}
			};
			for (let e of [this.front, this.back]) {
				let r = e.material;
				r.onBeforeCompile = (e) => {
					if (!t) return;
					Object.assign(e.uniforms, this.vertexUniforms);
					let { declarations: n, call: r } = f(t);
					e.vertexShader = e.vertexShader.replace("#include <common>", `#include <common>\n${n}`).replace("#include <begin_vertex>", r);
				}, r.customProgramCacheKey = () => `gleam-vertex:${n}`, r.needsUpdate = !0;
			}
		}
		if (t && e) for (let [n, r] of Object.entries(u(t, e.params))) Rn(this.vertexUniforms[t.params.find((e) => e.key === n).uniform], t, n, r);
	}
	applyEffects(e) {
		let t = e.map((e) => ({
			step: e,
			def: d(e.id)
		})).filter((e) => !!e.def && e.def.scope === "image"), n = t.map((e) => e.def.id).join(",");
		if (n !== this.effectKey) {
			this.effectKey = n, this.composer?.dispose();
			for (let { pass: e } of this.effectPasses) e.dispose();
			if (this.effectPasses = [], this.composer = null, t.length) {
				let e = new de(1, 1, {
					type: ae,
					samples: 4
				}), n = new Mn(this.renderer, e);
				n.addPass(new Fn(this.scene, this.camera)), n.addPass(new Pn());
				for (let { def: e } of t) {
					let t = {
						uInput: { value: null },
						uResolution: { value: new j(1, 1) },
						uTime: { value: 0 },
						uFlipY: { value: !0 },
						uInputFlipped: { value: !0 },
						...zn(e)
					}, r = (e) => e.replace(/^#version 300 es\n/, ""), i = new kn(new pe({
						glslVersion: ve,
						vertexShader: r(h),
						fragmentShader: r(m(e)),
						uniforms: t,
						depthTest: !1,
						depthWrite: !1
					}), "uInput");
					n.addPass(i), this.effectPasses.push({
						def: e,
						pass: i,
						uniforms: t
					});
				}
				this.composer = n, this.syncComposerSize();
			}
		}
		t.forEach(({ def: e, step: t }, n) => {
			let r = this.effectPasses[n].uniforms;
			for (let [n, i] of Object.entries(u(e, t.params))) Rn(r[e.params.find((e) => e.key === n).uniform], e, n, i);
		}), this.dirty = !0;
	}
}, Gn = new ie(), G = new x(), K = new x(), q = new k(), Kn = {
	X: new x(1, 0, 0),
	Y: new x(0, 1, 0),
	Z: new x(0, 0, 1)
}, qn = { type: "change" }, Jn = {
	type: "mouseDown",
	mode: null
}, Yn = {
	type: "mouseUp",
	mode: null
}, Xn = { type: "objectChange" }, Zn = class extends ye {
	constructor(e, t = null) {
		super(void 0, t);
		let n = new gr(this);
		this._root = n;
		let r = new _r();
		this._gizmo = r, n.add(r);
		let i = new vr();
		this._plane = i, n.add(i);
		let a = this;
		function o(e, t) {
			let n = t;
			Object.defineProperty(a, e, {
				get: function() {
					return n === void 0 ? t : n;
				},
				set: function(t) {
					n !== t && (n = t, i[e] = t, r[e] = t, a.dispatchEvent({
						type: e + "-changed",
						value: t
					}), a.dispatchEvent(qn));
				}
			}), a[e] = t, i[e] = t, r[e] = t;
		}
		o("camera", e), o("object", void 0), o("enabled", !0), o("axis", null), o("mode", "translate"), o("translationSnap", null), o("rotationSnap", null), o("scaleSnap", null), o("space", "world"), o("size", 1), this.viewport = null, o("dragging", !1), o("showX", !0), o("showY", !0), o("showZ", !0), o("showXY", !0), o("showYZ", !0), o("showXZ", !0), o("showXYZE", !0), o("showE", !0), o("minX", -Infinity), o("maxX", Infinity), o("minY", -Infinity), o("maxY", Infinity), o("minZ", -Infinity), o("maxZ", Infinity);
		let s = new x(), c = new x(), l = new k(), u = new k(), d = new x(), f = new k(), p = new x(), m = new x(), h = new x(), g = new x();
		o("worldPosition", s), o("worldPositionStart", c), o("worldQuaternion", l), o("worldQuaternionStart", u), o("cameraPosition", d), o("cameraQuaternion", f), o("pointStart", p), o("pointEnd", m), o("rotationAxis", h), o("rotationAngle", 0), o("eye", g), this._offset = new x(), this._startNorm = new x(), this._endNorm = new x(), this._cameraScale = new x(), this._parentPosition = new x(), this._parentQuaternion = new k(), this._parentQuaternionInv = new k(), this._parentScale = new x(), this._worldScaleStart = new x(), this._worldQuaternionInv = new k(), this._worldScale = new x(), this._positionStart = new x(), this._quaternionStart = new k(), this._scaleStart = new x(), this._getPointer = Qn.bind(this), this._onPointerDown = er.bind(this), this._onPointerHover = $n.bind(this), this._onPointerMove = tr.bind(this), this._onPointerUp = nr.bind(this), t !== null && this.connect(t);
	}
	connect(e) {
		super.connect(e), this.domElement.addEventListener("pointerdown", this._onPointerDown), this.domElement.addEventListener("pointermove", this._onPointerHover), this.domElement.addEventListener("pointerup", this._onPointerUp), this.domElement.style.touchAction = "none";
	}
	disconnect() {
		this.domElement.removeEventListener("pointerdown", this._onPointerDown), this.domElement.removeEventListener("pointermove", this._onPointerHover), this.domElement.removeEventListener("pointermove", this._onPointerMove), this.domElement.removeEventListener("pointerup", this._onPointerUp), this.domElement.style.touchAction = "";
	}
	getHelper() {
		return this._root;
	}
	pointerHover(e) {
		if (this.object === void 0 || this.dragging === !0) return;
		e !== null && Gn.setFromCamera(e, this.camera);
		let t = rr(this._gizmo.picker[this.mode], Gn);
		this.axis = t ? t.object.name : null;
	}
	pointerDown(e) {
		if (!(this.object === void 0 || this.dragging === !0 || e != null && e.button !== 0) && this.axis !== null) {
			e !== null && Gn.setFromCamera(e, this.camera);
			let t = rr(this._plane, Gn, !0);
			t && (this.object.updateMatrixWorld(), this.object.parent.updateMatrixWorld(), this._positionStart.copy(this.object.position), this._quaternionStart.copy(this.object.quaternion), this._scaleStart.copy(this.object.scale), this.object.matrixWorld.decompose(this.worldPositionStart, this.worldQuaternionStart, this._worldScaleStart), this.pointStart.copy(t.point).sub(this.worldPositionStart)), this.dragging = !0, Jn.mode = this.mode, this.dispatchEvent(Jn);
		}
	}
	pointerMove(e) {
		let t = this.axis, n = this.mode, r = this.object, i = this.space;
		if (n === "scale" ? i = "local" : (t === "E" || t === "XYZE" || t === "XYZ") && (i = "world"), r === void 0 || t === null || this.dragging === !1 || e !== null && e.button !== -1) return;
		e !== null && Gn.setFromCamera(e, this.camera);
		let a = rr(this._plane, Gn, !0);
		if (a) {
			if (this.pointEnd.copy(a.point).sub(this.worldPositionStart), n === "translate") this._offset.copy(this.pointEnd).sub(this.pointStart), i === "local" && t !== "XYZ" && this._offset.applyQuaternion(this._worldQuaternionInv), t.indexOf("X") === -1 && (this._offset.x = 0), t.indexOf("Y") === -1 && (this._offset.y = 0), t.indexOf("Z") === -1 && (this._offset.z = 0), i === "local" && t !== "XYZ" ? this._offset.applyQuaternion(this._quaternionStart).divide(this._parentScale) : this._offset.applyQuaternion(this._parentQuaternionInv).divide(this._parentScale), r.position.copy(this._offset).add(this._positionStart), this.translationSnap && (i === "local" && (r.position.applyQuaternion(q.copy(this._quaternionStart).invert()), t.search("X") !== -1 && (r.position.x = Math.round(r.position.x / this.translationSnap) * this.translationSnap), t.search("Y") !== -1 && (r.position.y = Math.round(r.position.y / this.translationSnap) * this.translationSnap), t.search("Z") !== -1 && (r.position.z = Math.round(r.position.z / this.translationSnap) * this.translationSnap), r.position.applyQuaternion(this._quaternionStart)), i === "world" && (r.getWorldPosition(G), t.search("X") !== -1 && (G.x = Math.round(G.x / this.translationSnap) * this.translationSnap), t.search("Y") !== -1 && (G.y = Math.round(G.y / this.translationSnap) * this.translationSnap), t.search("Z") !== -1 && (G.z = Math.round(G.z / this.translationSnap) * this.translationSnap), r.position.copy(r.parent.worldToLocal(G)))), r.position.x = Math.max(this.minX, Math.min(this.maxX, r.position.x)), r.position.y = Math.max(this.minY, Math.min(this.maxY, r.position.y)), r.position.z = Math.max(this.minZ, Math.min(this.maxZ, r.position.z));
			else if (n === "scale") {
				if (t.search("XYZ") !== -1) {
					let e = this.pointEnd.length() / this.pointStart.length();
					this.pointEnd.dot(this.pointStart) < 0 && (e *= -1), K.set(e, e, e);
				} else G.copy(this.pointStart), K.copy(this.pointEnd), G.applyQuaternion(this._worldQuaternionInv), K.applyQuaternion(this._worldQuaternionInv), K.divide(G), t.search("X") === -1 && (K.x = 1), t.search("Y") === -1 && (K.y = 1), t.search("Z") === -1 && (K.z = 1);
				r.scale.copy(this._scaleStart).multiply(K), this.scaleSnap && (t.search("X") !== -1 && (r.scale.x = Math.round(r.scale.x / this.scaleSnap) * this.scaleSnap || this.scaleSnap), t.search("Y") !== -1 && (r.scale.y = Math.round(r.scale.y / this.scaleSnap) * this.scaleSnap || this.scaleSnap), t.search("Z") !== -1 && (r.scale.z = Math.round(r.scale.z / this.scaleSnap) * this.scaleSnap || this.scaleSnap));
			} else if (n === "rotate") {
				this._offset.copy(this.pointEnd).sub(this.pointStart);
				let e = 20 / this.worldPosition.distanceTo(G.setFromMatrixPosition(this.camera.matrixWorld)), n = !1;
				t === "XYZE" ? (this.rotationAxis.copy(this._offset).cross(this.eye).normalize(), this.rotationAngle = this._offset.dot(G.copy(this.rotationAxis).cross(this.eye)) * e) : (t === "X" || t === "Y" || t === "Z") && (this.rotationAxis.copy(Kn[t]), G.copy(Kn[t]), i === "local" && G.applyQuaternion(this.worldQuaternion), G.cross(this.eye), G.length() === 0 ? n = !0 : this.rotationAngle = this._offset.dot(G.normalize()) * e), (t === "E" || n) && (this.rotationAxis.copy(this.eye), this.rotationAngle = this.pointEnd.angleTo(this.pointStart), this._startNorm.copy(this.pointStart).normalize(), this._endNorm.copy(this.pointEnd).normalize(), this.rotationAngle *= this._endNorm.cross(this._startNorm).dot(this.eye) < 0 ? 1 : -1), this.rotationSnap && (this.rotationAngle = Math.round(this.rotationAngle / this.rotationSnap) * this.rotationSnap), i === "local" && t !== "E" && t !== "XYZE" ? (r.quaternion.copy(this._quaternionStart), r.quaternion.multiply(q.setFromAxisAngle(this.rotationAxis, this.rotationAngle)).normalize()) : (this.rotationAxis.applyQuaternion(this._parentQuaternionInv), r.quaternion.copy(q.setFromAxisAngle(this.rotationAxis, this.rotationAngle)), r.quaternion.multiply(this._quaternionStart).normalize());
			}
			this.dispatchEvent(qn), this.dispatchEvent(Xn);
		}
	}
	pointerUp(e) {
		(e === null || e.button === 0) && (this.dragging && this.axis !== null && (Yn.mode = this.mode, this.dispatchEvent(Yn)), this.dragging = !1, this.axis = null);
	}
	dispose() {
		this.disconnect(), this._root.dispose();
	}
	attach(e) {
		return this.object = e, this._root.visible = !0, this;
	}
	detach() {
		return this.object = void 0, this.axis = null, this._root.visible = !1, this;
	}
	reset() {
		this.enabled && this.dragging && (this.object.position.copy(this._positionStart), this.object.quaternion.copy(this._quaternionStart), this.object.scale.copy(this._scaleStart), this.dispatchEvent(qn), this.dispatchEvent(Xn), this.pointStart.copy(this.pointEnd));
	}
	getRaycaster() {
		return Gn;
	}
	getMode() {
		return this.mode;
	}
	setMode(e) {
		this.mode = e;
	}
	setTranslationSnap(e) {
		this.translationSnap = e;
	}
	setRotationSnap(e) {
		this.rotationSnap = e;
	}
	setScaleSnap(e) {
		this.scaleSnap = e;
	}
	setSize(e) {
		this.size = e;
	}
	setSpace(e) {
		this.space = e;
	}
	setColors(e, t, n, r) {
		let i = this._gizmo.materialLib;
		i.xAxis.color.set(e), i.yAxis.color.set(t), i.zAxis.color.set(n), i.active.color.set(r), i.xAxisTransparent.color.set(e), i.yAxisTransparent.color.set(t), i.zAxisTransparent.color.set(n), i.activeTransparent.color.set(r), i.xAxis._color && i.xAxis._color.set(e), i.yAxis._color && i.yAxis._color.set(t), i.zAxis._color && i.zAxis._color.set(n), i.active._color && i.active._color.set(r), i.xAxisTransparent._color && i.xAxisTransparent._color.set(e), i.yAxisTransparent._color && i.yAxisTransparent._color.set(t), i.zAxisTransparent._color && i.zAxisTransparent._color.set(n), i.activeTransparent._color && i.activeTransparent._color.set(r);
	}
};
function Qn(e) {
	if (this.domElement.ownerDocument.pointerLockElement) return {
		x: 0,
		y: 0,
		button: e.button
	};
	{
		let t = this.domElement.getBoundingClientRect(), n = this.viewport, r, i, a, o;
		return n === null ? (r = 0, i = 0, a = t.width, o = t.height) : (r = n.x, i = t.height - n.y - n.w, a = n.z, o = n.w), {
			x: (e.clientX - t.left - r) / a * 2 - 1,
			y: -(e.clientY - t.top - i) / o * 2 + 1,
			button: e.button
		};
	}
}
function $n(e) {
	if (this.enabled) switch (e.pointerType) {
		case "mouse":
		case "pen": this.pointerHover(this._getPointer(e));
	}
}
function er(e) {
	this.enabled && (document.pointerLockElement || this.domElement.setPointerCapture(e.pointerId), this.domElement.addEventListener("pointermove", this._onPointerMove), this.pointerHover(this._getPointer(e)), this.pointerDown(this._getPointer(e)));
}
function tr(e) {
	this.enabled && this.pointerMove(this._getPointer(e));
}
function nr(e) {
	this.enabled && (this.domElement.releasePointerCapture(e.pointerId), this.domElement.removeEventListener("pointermove", this._onPointerMove), this.pointerUp(this._getPointer(e)));
}
function rr(e, t, n) {
	let r = t.intersectObject(e, !0);
	for (let e = 0; e < r.length; e++) if (r[e].object.visible || n) return r[e];
	return !1;
}
var ir = new ee(), J = new x(0, 1, 0), ar = new x(0, 0, 0), or = new B(), sr = new k(), cr = new k(), Y = new x(), lr = new B(), ur = new x(1, 0, 0), dr = new x(0, 1, 0), fr = new x(0, 0, 1), pr = new x(), mr = new x(), hr = new x(), gr = class extends he {
	constructor(e) {
		super(), this.isTransformControlsRoot = !0, this.controls = e, this.visible = !1;
	}
	updateMatrixWorld(e) {
		let t = this.controls;
		t.object !== void 0 && (t.object.updateMatrixWorld(), t.object.parent === null ? console.error("TransformControls: The attached 3D object must be a part of the scene graph.") : t.object.parent.matrixWorld.decompose(t._parentPosition, t._parentQuaternion, t._parentScale), t.object.matrixWorld.decompose(t.worldPosition, t.worldQuaternion, t._worldScale), t._parentQuaternionInv.copy(t._parentQuaternion).invert(), t._worldQuaternionInv.copy(t.worldQuaternion).invert()), t.camera.updateMatrixWorld(), t.camera.matrixWorld.decompose(t.cameraPosition, t.cameraQuaternion, t._cameraScale), t.camera.isOrthographicCamera ? t.camera.getWorldDirection(t.eye).negate() : t.eye.copy(t.cameraPosition).sub(t.worldPosition).normalize(), this.parent && (lr.copy(this.parent.matrixWorld).invert(), lr.decompose(this.position, this.quaternion, this.scale)), super.updateMatrixWorld(e);
	}
	dispose() {
		this.traverse(function(e) {
			e.geometry && e.geometry.dispose(), e.material && e.material.dispose();
		});
	}
}, _r = class extends he {
	constructor() {
		super(), this.isTransformControlsGizmo = !0, this.type = "TransformControlsGizmo";
		let e = new E({
			depthTest: !1,
			depthWrite: !1,
			fog: !1,
			toneMapped: !1,
			transparent: !0
		}), t = new je({
			depthTest: !1,
			depthWrite: !1,
			fog: !1,
			toneMapped: !1,
			transparent: !0
		}), n = e.clone();
		n.opacity = .15;
		let r = t.clone();
		r.opacity = .5;
		let i = e.clone();
		i.color.setHex(16711680);
		let a = e.clone();
		a.color.setHex(65280);
		let o = e.clone();
		o.color.setHex(255);
		let s = e.clone();
		s.color.setHex(16711680), s.opacity = .5;
		let c = e.clone();
		c.color.setHex(65280), c.opacity = .5;
		let l = e.clone();
		l.color.setHex(255), l.opacity = .5;
		let u = e.clone();
		u.opacity = .25;
		let d = e.clone();
		d.color.setHex(16776960), d.opacity = .25;
		let f = e.clone();
		f.color.setHex(16776960);
		let p = e.clone();
		p.color.setHex(7895160), this.materialLib = {
			xAxis: i,
			yAxis: a,
			zAxis: o,
			active: f,
			xAxisTransparent: s,
			yAxisTransparent: c,
			zAxisTransparent: l,
			activeTransparent: d
		};
		let m = new A(0, .04, .1, 12);
		m.translate(0, .05, 0);
		let h = new R(.08, .08, .08);
		h.translate(0, .04, 0);
		let g = new we();
		g.setAttribute("position", new He([
			0,
			0,
			0,
			1,
			0,
			0
		], 3));
		let _ = new A(.0075, .0075, .5, 3);
		_.translate(0, .25, 0);
		function v(e, t) {
			let n = new Ae(e, .0075, 3, 64, t * Math.PI * 2);
			return n.rotateY(Math.PI / 2), n.rotateX(Math.PI / 2), n;
		}
		function y() {
			let e = new we();
			return e.setAttribute("position", new He([
				0,
				0,
				0,
				1,
				1,
				1
			], 3)), e;
		}
		let b = {
			X: [
				[
					new P(m, i),
					[
						.5,
						0,
						0
					],
					[
						0,
						0,
						-Math.PI / 2
					]
				],
				[
					new P(m, i),
					[
						-.5,
						0,
						0
					],
					[
						0,
						0,
						Math.PI / 2
					]
				],
				[
					new P(_, i),
					[
						0,
						0,
						0
					],
					[
						0,
						0,
						-Math.PI / 2
					]
				]
			],
			Y: [
				[new P(m, a), [
					0,
					.5,
					0
				]],
				[
					new P(m, a),
					[
						0,
						-.5,
						0
					],
					[
						Math.PI,
						0,
						0
					]
				],
				[new P(_, a)]
			],
			Z: [
				[
					new P(m, o),
					[
						0,
						0,
						.5
					],
					[
						Math.PI / 2,
						0,
						0
					]
				],
				[
					new P(m, o),
					[
						0,
						0,
						-.5
					],
					[
						-Math.PI / 2,
						0,
						0
					]
				],
				[
					new P(_, o),
					null,
					[
						Math.PI / 2,
						0,
						0
					]
				]
			],
			XYZ: [[new P(new We(.1, 0), u), [
				0,
				0,
				0
			]]],
			XY: [[new P(new R(.15, .15, .01), l), [
				.15,
				.15,
				0
			]]],
			YZ: [[
				new P(new R(.15, .15, .01), s),
				[
					0,
					.15,
					.15
				],
				[
					0,
					Math.PI / 2,
					0
				]
			]],
			XZ: [[
				new P(new R(.15, .15, .01), c),
				[
					.15,
					0,
					.15
				],
				[
					-Math.PI / 2,
					0,
					0
				]
			]]
		}, x = {
			X: [[
				new P(new A(.2, 0, .6, 4), n),
				[
					.3,
					0,
					0
				],
				[
					0,
					0,
					-Math.PI / 2
				]
			], [
				new P(new A(.2, 0, .6, 4), n),
				[
					-.3,
					0,
					0
				],
				[
					0,
					0,
					Math.PI / 2
				]
			]],
			Y: [[new P(new A(.2, 0, .6, 4), n), [
				0,
				.3,
				0
			]], [
				new P(new A(.2, 0, .6, 4), n),
				[
					0,
					-.3,
					0
				],
				[
					0,
					0,
					Math.PI
				]
			]],
			Z: [[
				new P(new A(.2, 0, .6, 4), n),
				[
					0,
					0,
					.3
				],
				[
					Math.PI / 2,
					0,
					0
				]
			], [
				new P(new A(.2, 0, .6, 4), n),
				[
					0,
					0,
					-.3
				],
				[
					-Math.PI / 2,
					0,
					0
				]
			]],
			XYZ: [[new P(new We(.2, 0), n)]],
			XY: [[new P(new R(.2, .2, .01), n), [
				.15,
				.15,
				0
			]]],
			YZ: [[
				new P(new R(.2, .2, .01), n),
				[
					0,
					.15,
					.15
				],
				[
					0,
					Math.PI / 2,
					0
				]
			]],
			XZ: [[
				new P(new R(.2, .2, .01), n),
				[
					.15,
					0,
					.15
				],
				[
					-Math.PI / 2,
					0,
					0
				]
			]]
		}, S = {
			START: [[
				new P(new We(.01, 2), r),
				null,
				null,
				null,
				"helper"
			]],
			END: [[
				new P(new We(.01, 2), r),
				null,
				null,
				null,
				"helper"
			]],
			DELTA: [[
				new L(y(), r),
				null,
				null,
				null,
				"helper"
			]],
			X: [[
				new L(g, r),
				[
					-1e3,
					0,
					0
				],
				null,
				[
					1e6,
					1,
					1
				],
				"helper"
			]],
			Y: [[
				new L(g, r),
				[
					0,
					-1e3,
					0
				],
				[
					0,
					0,
					Math.PI / 2
				],
				[
					1e6,
					1,
					1
				],
				"helper"
			]],
			Z: [[
				new L(g, r),
				[
					0,
					0,
					-1e3
				],
				[
					0,
					-Math.PI / 2,
					0
				],
				[
					1e6,
					1,
					1
				],
				"helper"
			]]
		}, C = {
			XYZE: [[
				new P(v(.5, 1), p),
				null,
				[
					0,
					Math.PI / 2,
					0
				]
			]],
			X: [[new P(v(.5, .5), i)]],
			Y: [[
				new P(v(.5, .5), a),
				null,
				[
					0,
					0,
					-Math.PI / 2
				]
			]],
			Z: [[
				new P(v(.5, .5), o),
				null,
				[
					0,
					Math.PI / 2,
					0
				]
			]],
			E: [[
				new P(v(.75, 1), d),
				null,
				[
					0,
					Math.PI / 2,
					0
				]
			]]
		}, w = { AXIS: [[
			new L(g, r),
			[
				-1e3,
				0,
				0
			],
			null,
			[
				1e6,
				1,
				1
			],
			"helper"
		]] }, T = {
			XYZE: [[new P(new Me(.25, 10, 8), n)]],
			X: [[
				new P(new Ae(.5, .1, 4, 24), n),
				[
					0,
					0,
					0
				],
				[
					0,
					-Math.PI / 2,
					-Math.PI / 2
				]
			]],
			Y: [[
				new P(new Ae(.5, .1, 4, 24), n),
				[
					0,
					0,
					0
				],
				[
					Math.PI / 2,
					0,
					0
				]
			]],
			Z: [[
				new P(new Ae(.5, .1, 4, 24), n),
				[
					0,
					0,
					0
				],
				[
					0,
					0,
					-Math.PI / 2
				]
			]],
			E: [[new P(new Ae(.75, .1, 2, 24), n)]]
		}, ee = {
			X: [
				[
					new P(h, i),
					[
						.5,
						0,
						0
					],
					[
						0,
						0,
						-Math.PI / 2
					]
				],
				[
					new P(_, i),
					[
						0,
						0,
						0
					],
					[
						0,
						0,
						-Math.PI / 2
					]
				],
				[
					new P(h, i),
					[
						-.5,
						0,
						0
					],
					[
						0,
						0,
						Math.PI / 2
					]
				]
			],
			Y: [
				[new P(h, a), [
					0,
					.5,
					0
				]],
				[new P(_, a)],
				[
					new P(h, a),
					[
						0,
						-.5,
						0
					],
					[
						0,
						0,
						Math.PI
					]
				]
			],
			Z: [
				[
					new P(h, o),
					[
						0,
						0,
						.5
					],
					[
						Math.PI / 2,
						0,
						0
					]
				],
				[
					new P(_, o),
					[
						0,
						0,
						0
					],
					[
						Math.PI / 2,
						0,
						0
					]
				],
				[
					new P(h, o),
					[
						0,
						0,
						-.5
					],
					[
						-Math.PI / 2,
						0,
						0
					]
				]
			],
			XY: [[new P(new R(.15, .15, .01), l), [
				.15,
				.15,
				0
			]]],
			YZ: [[
				new P(new R(.15, .15, .01), s),
				[
					0,
					.15,
					.15
				],
				[
					0,
					Math.PI / 2,
					0
				]
			]],
			XZ: [[
				new P(new R(.15, .15, .01), c),
				[
					.15,
					0,
					.15
				],
				[
					-Math.PI / 2,
					0,
					0
				]
			]],
			XYZ: [[new P(new R(.1, .1, .1), u)]]
		}, te = {
			X: [[
				new P(new A(.2, 0, .6, 4), n),
				[
					.3,
					0,
					0
				],
				[
					0,
					0,
					-Math.PI / 2
				]
			], [
				new P(new A(.2, 0, .6, 4), n),
				[
					-.3,
					0,
					0
				],
				[
					0,
					0,
					Math.PI / 2
				]
			]],
			Y: [[new P(new A(.2, 0, .6, 4), n), [
				0,
				.3,
				0
			]], [
				new P(new A(.2, 0, .6, 4), n),
				[
					0,
					-.3,
					0
				],
				[
					0,
					0,
					Math.PI
				]
			]],
			Z: [[
				new P(new A(.2, 0, .6, 4), n),
				[
					0,
					0,
					.3
				],
				[
					Math.PI / 2,
					0,
					0
				]
			], [
				new P(new A(.2, 0, .6, 4), n),
				[
					0,
					0,
					-.3
				],
				[
					-Math.PI / 2,
					0,
					0
				]
			]],
			XY: [[new P(new R(.2, .2, .01), n), [
				.15,
				.15,
				0
			]]],
			YZ: [[
				new P(new R(.2, .2, .01), n),
				[
					0,
					.15,
					.15
				],
				[
					0,
					Math.PI / 2,
					0
				]
			]],
			XZ: [[
				new P(new R(.2, .2, .01), n),
				[
					.15,
					0,
					.15
				],
				[
					-Math.PI / 2,
					0,
					0
				]
			]],
			XYZ: [[new P(new R(.2, .2, .2), n), [
				0,
				0,
				0
			]]]
		}, ne = {
			X: [[
				new L(g, r),
				[
					-1e3,
					0,
					0
				],
				null,
				[
					1e6,
					1,
					1
				],
				"helper"
			]],
			Y: [[
				new L(g, r),
				[
					0,
					-1e3,
					0
				],
				[
					0,
					0,
					Math.PI / 2
				],
				[
					1e6,
					1,
					1
				],
				"helper"
			]],
			Z: [[
				new L(g, r),
				[
					0,
					0,
					-1e3
				],
				[
					0,
					-Math.PI / 2,
					0
				],
				[
					1e6,
					1,
					1
				],
				"helper"
			]]
		};
		function D(e) {
			let t = new he();
			for (let n in e) for (let r = e[n].length; r--;) {
				let i = e[n][r][0].clone(), a = e[n][r][1], o = e[n][r][2], s = e[n][r][3], c = e[n][r][4];
				i.name = n, i.tag = c, a && i.position.set(a[0], a[1], a[2]), o && i.rotation.set(o[0], o[1], o[2]), s && i.scale.set(s[0], s[1], s[2]), i.updateMatrix();
				let l = i.geometry.clone();
				l.applyMatrix4(i.matrix), i.geometry = l, i.renderOrder = Infinity, i.position.set(0, 0, 0), i.rotation.set(0, 0, 0), i.scale.set(1, 1, 1), t.add(i);
			}
			return t;
		}
		this.gizmo = {}, this.picker = {}, this.helper = {}, this.add(this.gizmo.translate = D(b)), this.add(this.gizmo.rotate = D(C)), this.add(this.gizmo.scale = D(ee)), this.add(this.picker.translate = D(x)), this.add(this.picker.rotate = D(T)), this.add(this.picker.scale = D(te)), this.add(this.helper.translate = D(S)), this.add(this.helper.rotate = D(w)), this.add(this.helper.scale = D(ne)), this.picker.translate.visible = !1, this.picker.rotate.visible = !1, this.picker.scale.visible = !1;
	}
	updateMatrixWorld(e) {
		let t = (this.mode === "scale" ? "local" : this.space) === "local" ? this.worldQuaternion : cr;
		this.gizmo.translate.visible = this.mode === "translate", this.gizmo.rotate.visible = this.mode === "rotate", this.gizmo.scale.visible = this.mode === "scale", this.helper.translate.visible = this.mode === "translate", this.helper.rotate.visible = this.mode === "rotate", this.helper.scale.visible = this.mode === "scale";
		let n = [];
		n = n.concat(this.picker[this.mode].children), n = n.concat(this.gizmo[this.mode].children), n = n.concat(this.helper[this.mode].children);
		for (let e = 0; e < n.length; e++) {
			let r = n[e];
			r.visible = !0, r.rotation.set(0, 0, 0), r.position.copy(this.worldPosition);
			let i;
			if (i = this.camera.isOrthographicCamera ? (this.camera.top - this.camera.bottom) / this.camera.zoom : this.worldPosition.distanceTo(this.cameraPosition) * Math.min(1.9 * Math.tan(Math.PI * this.camera.fov / 360) / this.camera.zoom, 7), r.scale.set(1, 1, 1).multiplyScalar(i * this.size / 4), r.tag === "helper") r.visible = !1, r.name === "AXIS" ? (r.visible = !!this.axis, this.axis === "X" && (q.setFromEuler(ir.set(0, 0, 0)), r.quaternion.copy(t).multiply(q), Math.abs(J.copy(ur).applyQuaternion(t).dot(this.eye)) > .9 && (r.visible = !1)), this.axis === "Y" && (q.setFromEuler(ir.set(0, 0, Math.PI / 2)), r.quaternion.copy(t).multiply(q), Math.abs(J.copy(dr).applyQuaternion(t).dot(this.eye)) > .9 && (r.visible = !1)), this.axis === "Z" && (q.setFromEuler(ir.set(0, Math.PI / 2, 0)), r.quaternion.copy(t).multiply(q), Math.abs(J.copy(fr).applyQuaternion(t).dot(this.eye)) > .9 && (r.visible = !1)), this.axis === "XYZE" && (q.setFromEuler(ir.set(0, Math.PI / 2, 0)), J.copy(this.rotationAxis), r.quaternion.setFromRotationMatrix(or.lookAt(ar, J, dr)), r.quaternion.multiply(q), r.visible = this.dragging), this.axis === "E" && (r.visible = !1)) : r.name === "START" ? (r.position.copy(this.worldPositionStart), r.visible = this.dragging) : r.name === "END" ? (r.position.copy(this.worldPosition), r.visible = this.dragging) : r.name === "DELTA" ? (r.position.copy(this.worldPositionStart), r.quaternion.copy(this.worldQuaternionStart), G.set(1e-10, 1e-10, 1e-10).add(this.worldPositionStart).sub(this.worldPosition).multiplyScalar(-1), G.applyQuaternion(this.worldQuaternionStart.clone().invert()), r.scale.copy(G), r.visible = this.dragging) : (r.quaternion.copy(t), this.dragging ? r.position.copy(this.worldPositionStart) : r.position.copy(this.worldPosition), this.axis && (r.visible = this.axis.search(r.name) !== -1));
			else {
				if (r.quaternion.copy(t), this.mode === "translate" || this.mode === "scale") {
					let e = .99, n = .2;
					r.name === "X" && Math.abs(J.copy(ur).applyQuaternion(t).dot(this.eye)) > e && (r.scale.set(1e-10, 1e-10, 1e-10), r.visible = !1), r.name === "Y" && Math.abs(J.copy(dr).applyQuaternion(t).dot(this.eye)) > e && (r.scale.set(1e-10, 1e-10, 1e-10), r.visible = !1), r.name === "Z" && Math.abs(J.copy(fr).applyQuaternion(t).dot(this.eye)) > e && (r.scale.set(1e-10, 1e-10, 1e-10), r.visible = !1), r.name === "XY" && Math.abs(J.copy(fr).applyQuaternion(t).dot(this.eye)) < n && (r.scale.set(1e-10, 1e-10, 1e-10), r.visible = !1), r.name === "YZ" && Math.abs(J.copy(ur).applyQuaternion(t).dot(this.eye)) < n && (r.scale.set(1e-10, 1e-10, 1e-10), r.visible = !1), r.name === "XZ" && Math.abs(J.copy(dr).applyQuaternion(t).dot(this.eye)) < n && (r.scale.set(1e-10, 1e-10, 1e-10), r.visible = !1);
				} else this.mode === "rotate" && (sr.copy(t), J.copy(this.eye).applyQuaternion(q.copy(t).invert()), r.name.search("E") !== -1 && r.quaternion.setFromRotationMatrix(or.lookAt(this.eye, ar, dr)), r.name === "X" && (q.setFromAxisAngle(ur, Math.atan2(-J.y, J.z)), q.multiplyQuaternions(sr, q), r.quaternion.copy(q)), r.name === "Y" && (q.setFromAxisAngle(dr, Math.atan2(J.x, J.z)), q.multiplyQuaternions(sr, q), r.quaternion.copy(q)), r.name === "Z" && (q.setFromAxisAngle(fr, Math.atan2(J.y, J.x)), q.multiplyQuaternions(sr, q), r.quaternion.copy(q)));
				r.visible = r.visible && (r.name.indexOf("X") === -1 || this.showX), r.visible = r.visible && (r.name.indexOf("Y") === -1 || this.showY), r.visible = r.visible && (r.name.indexOf("Z") === -1 || this.showZ), r.visible = r.visible && (r.name.indexOf("E") === -1 || this.showX && this.showY && this.showZ), r.visible = r.visible && (r.name.indexOf("XY") === -1 || this.showXY), r.visible = r.visible && (r.name.indexOf("YZ") === -1 || this.showYZ), r.visible = r.visible && (r.name.indexOf("XZ") === -1 || this.showXZ), r.visible = r.visible && (r.name !== "E" || this.showE), r.visible = r.visible && (r.name !== "XYZE" || this.showXYZE), r.material._color = r.material._color || r.material.color.clone(), r.material._opacity = r.material._opacity || r.material.opacity, r.material.color.copy(r.material._color), r.material.opacity = r.material._opacity, this.enabled && this.axis && (r.name === this.axis || this.axis.split("").some(function(e) {
					return r.name === e;
				})) && (r.material.color.copy(this.materialLib.active.color), r.material.opacity = 1);
			}
		}
		super.updateMatrixWorld(e);
	}
}, vr = class extends P {
	constructor() {
		super(new F(1e5, 1e5, 2, 2), new E({
			visible: !1,
			wireframe: !0,
			side: 2,
			transparent: !0,
			opacity: .1,
			toneMapped: !1
		})), this.isTransformControlsPlane = !0, this.type = "TransformControlsPlane";
	}
	updateMatrixWorld(e) {
		let t = this.space;
		switch (this.position.copy(this.worldPosition), this.mode === "scale" && (t = "local"), pr.copy(ur).applyQuaternion(t === "local" ? this.worldQuaternion : cr), mr.copy(dr).applyQuaternion(t === "local" ? this.worldQuaternion : cr), hr.copy(fr).applyQuaternion(t === "local" ? this.worldQuaternion : cr), J.copy(mr), this.mode) {
			case "translate":
			case "scale":
				switch (this.axis) {
					case "X":
						J.copy(this.eye).cross(pr), Y.copy(pr).cross(J);
						break;
					case "Y":
						J.copy(this.eye).cross(mr), Y.copy(mr).cross(J);
						break;
					case "Z":
						J.copy(this.eye).cross(hr), Y.copy(hr).cross(J);
						break;
					case "XY":
						Y.copy(hr);
						break;
					case "YZ":
						Y.copy(pr);
						break;
					case "XZ":
						J.copy(hr), Y.copy(mr);
						break;
					case "XYZ":
					case "E": Y.set(0, 0, 0);
				}
				break;
			default: Y.set(0, 0, 0);
		}
		Y.length() === 0 ? this.quaternion.copy(this.cameraQuaternion) : (lr.lookAt(G.set(0, 0, 0), Y, J), this.quaternion.setFromRotationMatrix(lr)), super.updateMatrixWorld(e);
	}
}, yr = "\nout vec2 vUv;\nvoid main() {\n  vUv = uv;\n  gl_Position = vec4(position.xy, 0.0, 1.0);\n}\n", br = "\nprecision highp float;\nprecision highp int;\nprecision highp sampler2DArray;\nout vec4 fragColor;\n\nuniform int uCount;\n// Windows' shader compiler (Direct3D, through the browser) unrolls loops of a fixed length and pastes every function into each place it is called,\n// so the distance field must be called from as few places as possible, each inside a loop it cannot unroll: a loop from ZERO (always 0, but\n// known only while drawing) stays a loop. Without this the shader took minutes to compile there.\n#define ZERO min(uCount, 0)\nuniform sampler2DArray uFields; // outline distance fields, one layer each (signed distance in texels)\n// The shapes' values, a row each in a data texture (ShapeTable in renderer.ts, written by fillUniforms), as game engines keep what a shader\n// reads about many objects in a buffer rather than in uniforms (which some graphics cards have few of). One texel each, by SLOT there:\nuniform highp sampler2D uShapes;\nvec4 shp(int i, int k) { return texelFetch(uShapes, ivec2(k, i), 0); }\nint kindOf(int i) { return int(shp(i, 0).x + 0.5); }   // 0-6 solids, 7 an outline pushed out, 8 an outline spun round, 20 a group starts, 21 it ends\nvec4 fOf(int i) { return shp(i, 1); }                  // x field layer, y the field's half size, z one texel, in the shape's units; w its form's wall (hollow)\nmat3 rotOf(int i) { return mat3(shp(i, 2).xyz, shp(i, 3).xyz, shp(i, 4).xyz); } // world to local\nvec4 posOf(int i) { return shp(i, 5); }                // xyz the middle, w how much it glows (the glow finish)\nvec4 halfOf(int i) { return shp(i, 6); }               // xyz half its size, w how much of it is glass (the glass finish)\nvec4 pOf(int i) { return shp(i, 7); }                  // x rounding radius, y torus thickness (a revolve: its sweep in radians), z blend radius, w combine (0 add, 1 subtract, 2 intersect)\nvec4 repAOf(int i) { return shp(i, 8); }               // x 0 no copies, 1 a grid, 2 round the middle; grid: yzw the counts; round: y count, z axis (0 x, 1 y, 2 z), w step (radians)\nvec4 repBOf(int i) { return shp(i, 9); }               // grid: xyz spacing; round: x the shape's own angle, y where angles start, z 1 for a whole ring; w mirror (1 x, 2 z)\nvec4 colOf(int i) { return shp(i, 10); }               // rgb linear colour, w its form's taper\nvec4 matOf(int i) { return shp(i, 11); }               // x shininess, y metal, z its form's twist, w its bend (radians)\nvec4 extraOf(int i) { return shp(i, 12); }             // x its bumps' height, y how many across a unit\n\nuniform int uLabelCount;      // labels (labels.ts), up to 4\nuniform int uLabelShape[4];   // the shape each is on\nuniform vec4 uLabelA[4];      // x side (0 front, 1 back, 2 top, 3 around), y width, z height, w the shape's half width (round its girth)\nuniform vec4 uLabelB[4];      // xy its middle on the face\nuniform sampler2DArray uLabels; // their pictures, one layer each (sRGB, straight alpha)\nuniform vec2 uRes;\nuniform vec2 uTileOffset;     // the part of the picture this draw covers (a tile of a big export, or all of it)\nuniform vec2 uTileSize;\nuniform vec3 uCamPos;\nuniform mat3 uCamRot;          // camera to world: columns right, up, back\nuniform float uTanHalf;\nuniform int uOrtho;\nuniform float uOrthoHalf;\n\nuniform vec3 uLightDir;\nuniform vec3 uLightCol;\nuniform float uIntensity;\nuniform float uAmbient;\nuniform int uShadows;\nuniform int uMoreLights;       // lights besides the key light (0-2)\nuniform vec4 uMoreDir[2];      // xyz towards the light, w its brightness\nuniform vec4 uMoreCol[2];      // rgb its linear colour, w 1 when it casts shadows\n\nuniform int uLook;             // 0 soft, 1 toon, 2 flat, 3 clay\nuniform float uOutline;        // pixels\nuniform vec3 uOutlineCol;\nuniform float uBands;\nuniform int uTransparent;\nuniform vec3 uBg;\nuniform int uGround;\nuniform float uGroundShadow;\nuniform int uSamples;          // 1 or 2 (2x2 samples per pixel)\nuniform float uGrid;           // the editing grid's cell on the ground (scene units), 0 for none (pictures and video never have one)\nuniform mat4 uViewProj;        // world to clip: the depth written, so imported models and shapes hide each other\nuniform sampler2D uMeshShadow; // imported models' depth seen from the light, for the shadows they cast\nuniform mat4 uLightViewProj;\nuniform int uMeshShadowOn;\nuniform float uShadowBias;\n\n// The baked field and the tile lists are for the shapes' own marches; the models' pass (NO_FIELD, MESH_FRAGMENT) goes without them, as its\n// textures and these would come to more than the 16 every graphics card has (WebGL 2's least).\n#ifndef NO_FIELD\n// The whole field baked into a 3D picture (DistanceVolume in renderer.ts), as game engines keep a global distance field of the scene: in the\n// box from uVolMin, uVolSize across, each texel the field's value at its middle. A ray far from everything reads one texel instead of\n// measuring every shape. uVolSafe is what the reading may be over the true distance between texels (the texel's half diagonal), taken off.\nuniform highp sampler3D uVol;\nuniform vec3 uVolMin;\nuniform vec3 uVolSize;\nuniform float uVolSafe;\nuniform int uVolOn;            // 1 while the picture matches the shapes drawn\n\n// Which shapes each tile of the picture (uTilePx square) can see at all (TileLists in renderer.ts): a tile's start and count in uTiles, the\n// shapes' indices in uTileList (4096 a row). The camera's march measures only its tile's list, as game engines light a tile by its own\n// list of lights (Forward+): a shape whose sphere no ray of the tile passes near is left out, as the sphere test would have left it out\nuniform highp sampler2D uTiles;\nuniform highp sampler2D uTileList;\nuniform int uTilesOn;\nuniform float uTilePx;\n#endif\nint gListStart = 0;\nint gListCount = -1;           // the tile's list while the camera's march runs; -1: every shape\n\nfloat len2(vec2 v) { return length(v); }\n\n// a revolve kept to a slice sweep radians wide, from +x towards +z. Kept in step with sweepCut in sdf.ts\nfloat sweepCut(float d, float x, float z, float sweep) {\n  if (sweep >= 6.283) return d;\n  float start = -z;\n  float end = -sin(sweep) * x + cos(sweep) * z;\n  return max(d, sweep <= 3.14159265 ? max(start, end) : min(start, end));\n}\n\nfloat shapeDist(int i, vec3 p) {\n  vec3 hs = halfOf(i).xyz;\n  float r = pOf(i).x;\n  int k = kindOf(i);\n  if (k == 0) { // box\n    vec3 q = abs(p) - hs + r;\n    return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0) - r;\n  }\n  if (k == 1) { // sphere, an ellipsoid\n    float k0 = length(p / hs);\n    float k1 = length(p / (hs * hs));\n    return k1 > 0.0 ? k0 * (k0 - 1.0) / k1 : -min(hs.x, min(hs.y, hs.z));\n  }\n  if (k == 2) { // cylinder\n    float ra = min(hs.x, hs.z);\n    float rr = min(r, min(ra, hs.y));\n    vec2 d = vec2(len2(vec2(p.x * ra / hs.x, p.z * ra / hs.z)) - ra + rr, abs(p.y) - hs.y + rr);\n    return min(max(d.x, d.y), 0.0) + length(max(d, 0.0)) - rr;\n  }\n  if (k == 3) { // cone, base down\n    float ra = min(hs.x, hs.z);\n    vec2 q = vec2(len2(vec2(p.x * ra / hs.x, p.z * ra / hs.z)), p.y);\n    float h = hs.y;\n    vec2 k1 = vec2(0.0, h);\n    vec2 k2 = vec2(-ra, 2.0 * h);\n    vec2 ca = vec2(q.x - min(q.x, q.y < 0.0 ? ra : 0.0), abs(q.y) - h);\n    vec2 cb = q - k1 + k2 * clamp(dot(k1 - q, k2) / dot(k2, k2), 0.0, 1.0);\n    float s = (cb.x < 0.0 && ca.y < 0.0) ? -1.0 : 1.0;\n    return s * sqrt(min(dot(ca, ca), dot(cb, cb))) - r * 0.5;\n  }\n  if (k == 4) { // torus\n    float tube = min(pOf(i).y * hs.x, hs.y);\n    float ring = max(hs.x - tube, 0.001);\n    return len2(vec2(len2(vec2(p.x, p.z * hs.x / hs.z)) - ring, p.y)) - tube;\n  }\n  if (k == 5) { // capsule\n    float ra = min(hs.x, hs.z);\n    float h = max(hs.y - ra, 0.0);\n    float cy = p.y - clamp(p.y, -h, h);\n    return length(vec3(p.x * ra / hs.x, cy, p.z * ra / hs.z)) - ra;\n  }\n  if (k == 7) { // an outline pushed out along z, rounded\n    vec4 f = fOf(i);\n    vec2 uv = vec2(p.x + f.y, f.y - p.y) / (2.0 * f.y);\n    // textureLod, not texture: the field has one level, and texture's screen-space gradients inside the ray march's loops make Windows' shader\n    // compiler (Direct3D, through the browser) unroll every loop round it, which took the shader minutes to compile\n    float inner = textureLod(uFields, vec3(clamp(uv, 0.0, 1.0), f.x), 0.0).r * f.z;\n    float d2 = inner + length(max(abs(p.xy) - f.y * 0.98, 0.0));\n    float rr = min(r, hs.z * 0.95);\n    vec2 w = vec2(d2 + rr, abs(p.z) - hs.z + rr);\n    return min(max(w.x, w.y), 0.0) + length(max(w, 0.0)) - rr;\n  }\n  if (k == 8) { // an outline spun round the upright axis: its silhouette's 2D distance in the cut through the axis\n    vec4 f = fOf(i);\n    float ra = min(hs.x, hs.z);\n    vec2 q = vec2(len2(vec2(p.x * ra / hs.x, p.z * ra / hs.z)), p.y);\n    vec2 uv = vec2(q.x + f.y, f.y - q.y) / (2.0 * f.y);\n    float d2 = textureLod(uFields, vec3(clamp(uv, 0.0, 1.0), f.x), 0.0).r * f.z + length(max(abs(q) - f.y * 0.98, 0.0));\n    return sweepCut(d2, p.x, p.z, pOf(i).y);\n  }\n  // pyramid, base down\n  float b = min(hs.x, hs.z);\n  float hgt = 2.0 * hs.y / (2.0 * b);\n  vec3 pp = vec3(abs(p.x * b / hs.x), p.y + hs.y, abs(p.z * b / hs.z)) / (2.0 * b);\n  if (pp.z > pp.x) pp.xz = pp.zx;\n  pp.xz -= 0.5;\n  float m2 = hgt * hgt + 0.25;\n  vec3 q = vec3(pp.z, hgt * pp.y - 0.5 * pp.x, hgt * pp.x + 0.5 * pp.y);\n  float s = max(-q.x, 0.0);\n  float t = clamp((q.y - 0.5 * pp.z) / (m2 + 0.25), 0.0, 1.0);\n  float a = m2 * (q.x + s) * (q.x + s) + q.y * q.y;\n  float bb = m2 * (q.x + 0.5 * t) * (q.x + 0.5 * t) + (q.y - m2 * t) * (q.y - m2 * t);\n  float d2 = min(q.y, -q.x * m2 - q.y * 0.5) > 0.0 ? 0.0 : min(a, bb);\n  return 2.0 * b * sqrt((d2 + q.z * q.z) / m2) * sign(max(q.z, -pp.y)) - r * 0.5;\n}\n\n// a shape's distance with its form, in its own frame: tapered, twisted and bent before measuring, slowed by how much that stretches space, then\n// hollowed. One call of shapeDist (see copyDist). Kept line for line with formedDistance in sdf.ts\n// a whole-number corner's random value (-1 to 1), uint arithmetic as hashCorner in sdf.ts\nfloat hashCorner(ivec3 c) {\n  uint h = (uint(c.x) * 73856093u) ^ (uint(c.y) * 19349663u) ^ (uint(c.z) * 83492791u);\n  h = (h ^ (h >> 13u)) * 1274126177u;\n  h = h ^ (h >> 16u);\n  return float(h & 0xffffffu) / 16777215.0 * 2.0 - 1.0;\n}\n// smooth value noise (-1 to 1), as valueNoise in sdf.ts\nfloat valueNoise(vec3 p) {\n  vec3 i = floor(p), f = p - i;\n  vec3 u = f * f * (3.0 - 2.0 * f);\n  ivec3 c = ivec3(i);\n  return mix(\n    mix(mix(hashCorner(c), hashCorner(c + ivec3(1, 0, 0)), u.x), mix(hashCorner(c + ivec3(0, 1, 0)), hashCorner(c + ivec3(1, 1, 0)), u.x), u.y),\n    mix(mix(hashCorner(c + ivec3(0, 0, 1)), hashCorner(c + ivec3(1, 0, 1)), u.x), mix(hashCorner(c + ivec3(0, 1, 1)), hashCorner(c + ivec3(1, 1, 1)), u.x), u.y),\n    u.z);\n}\n\nfloat formedDist(int i, vec3 p) {\n  vec3 p0 = p;\n  float shell = fOf(i).w, twist = matOf(i).z, bend = matOf(i).w, taper = colOf(i).w;\n  vec3 h = halfOf(i).xyz;\n  if (taper != 0.0) {\n    float sc = max(0.05, 1.0 + taper * clamp(p.y / h.y, -1.0, 1.0));\n    p.xz /= sc;\n  }\n  if (twist != 0.0) {\n    float a = twist * p.y / (2.0 * h.y);\n    float c = cos(a), s = sin(a);\n    p.xz = vec2(c * p.x - s * p.z, s * p.x + c * p.z);\n  }\n  if (bend != 0.0) {\n    float a = bend * p.x / (2.0 * h.x);\n    float c = cos(a), s = sin(a);\n    p.xy = vec2(c * p.x - s * p.y, s * p.x + c * p.y);\n  }\n  float reach = length(h);\n  float slow = 1.0 + abs(twist) * reach / (2.0 * h.y) + abs(bend) * reach / (2.0 * h.x) + abs(taper) * 2.0;\n  float bumps = extraOf(i).x, scale = extraOf(i).y;\n  float d = shapeDist(i, p) / (slow + bumps * scale * 1.5);\n  if (bumps > 0.0) d += bumps * valueNoise(p0 * scale);\n  if (shell > 0.0) d = abs(d + shell * 0.5) - shell * 0.5;\n  return d;\n}\n\n// the surface's colour with any label on it: the point taken into each labelled shape's frame, on its box and facing the label's way, then\n// found on the label. Kept line for line with labelUv in labels.ts\nvec3 labelled(vec3 p, vec3 n, vec3 col) {\n  for (int k = ZERO; k < uLabelCount; k++) {\n    int i = uLabelShape[k];\n    vec3 loc = rotOf(i) * (p - posOf(i).xyz);\n    vec3 nl = rotOf(i) * n;\n    if (any(greaterThan(abs(loc), halfOf(i).xyz + 0.02))) continue;\n    vec4 a = uLabelA[k];\n    int side = int(a.x + 0.5);\n    vec2 f;\n    if (side == 0) { if (nl.z < 0.2) continue; f = loc.xy; }\n    else if (side == 1) { if (nl.z > -0.2) continue; f = vec2(-loc.x, loc.y); }\n    else if (side == 2) { if (nl.y < 0.2) continue; f = vec2(loc.x, -loc.z); }\n    else { if (abs(nl.y) > 0.7) continue; f = vec2(atan(loc.x, loc.z) * a.w, loc.y); }\n    vec2 uv = (f - uLabelB[k].xy) / a.yz + 0.5;\n    if (any(lessThan(uv, vec2(0.0))) || any(greaterThan(uv, vec2(1.0)))) continue;\n    vec4 t = textureLod(uLabels, vec3(uv.x, 1.0 - uv.y, float(k)), 0.0);\n    col = mix(col, pow(t.rgb, vec3(2.2)), t.a);\n  }\n  return col;\n}\n\n// a point turned by -a round an axis through the scene's middle. Kept in step with turned in sdf.ts\nvec3 turnedP(vec3 p, int axis, float a) {\n  float c = cos(a), s = sin(a);\n  if (axis == 0) return vec3(p.x, p.y * c + p.z * s, -p.y * s + p.z * c);\n  if (axis == 1) return vec3(p.x * c + p.z * s, p.y, -p.x * s + p.z * c);\n  return vec3(p.x * c + p.y * s, -p.x * s + p.y * c, p.z);\n}\n\n// A shape's distance at a world point with its twin and copies: mirrored to its own side, then each copy that can be nearest (the nearest round\n// copy and the next; or the nearest grid copy and the next along each axis, where copies overlap) measured in the shape's frame. Kept in step with\n// copiesDistance in sdf.ts.\n// One loop with a bound known only while drawing, around the one call of shapeDist: Windows' shader compiler (through Direct3D) unrolls loops of\n// a fixed length and pastes shapeDist into every place it is called, which made the shader take minutes to compile.\nfloat copyDist(int i, vec3 p) {\n  vec4 a = repAOf(i);\n  vec4 b = repBOf(i);\n  int mode = int(a.x + 0.5);\n  int mirror = int(b.w + 0.5);\n  vec3 q = p;\n  vec3 mid = posOf(i).xyz;\n  mat3 rot = rotOf(i);\n  if ((mirror & 1) != 0) q.x = (mid.x < 0.0 ? -1.0 : 1.0) * abs(q.x);\n  if ((mirror & 2) != 0) q.z = (mid.z < 0.0 ? -1.0 : 1.0) * abs(q.z);\n  // round copies: which two to measure\n  int axis = int(a.z + 0.5);\n  float k = 0.0, k2 = 0.0;\n  if (mode == 2) {\n    vec2 w = axis == 0 ? q.yz : axis == 1 ? q.xz : q.xy;\n    float rel = b.y + mod(atan(w.y, w.x) - b.x - b.y, 6.28318531);\n    bool full = b.z > 0.5;\n    k = floor(rel / a.w + 0.5);\n    if (!full) k = clamp(k, 0.0, a.y - 1.0);\n    k2 = k + (rel > k * a.w ? 1.0 : -1.0);\n    if (!full) k2 = clamp(k2, 0.0, a.y - 1.0);\n  }\n  int tries = mode == 1 ? 8 : mode == 2 && k2 != k ? 2 : 1;\n  float d = 1e9;\n  for (int t = 0; t < tries; t++) {\n    vec3 w = mode == 2 ? turnedP(q, axis, (t == 0 ? k : k2) * a.w) : q;\n    vec3 loc = rot * (w - mid);\n    if (mode == 1) {\n      // grid: the nearest cell, or the next one along each axis whose bit of t is set (skipped where there is no next one)\n      vec3 sp = b.xyz;\n      vec3 last = a.yzw - 1.0;\n      vec3 c = clamp(floor(loc / sp + 0.5), vec3(0.0), last);\n      vec3 c2 = clamp(c + mix(vec3(-1.0), vec3(1.0), vec3(greaterThan(loc, c * sp))), vec3(0.0), last);\n      vec3 pick = vec3(float(t & 1), float((t >> 1) & 1), float((t >> 2) & 1));\n      if (dot(pick, vec3(equal(c, c2))) > 0.5) continue;\n      loc -= mix(c, c2, pick) * sp;\n    }\n    d = min(d, formedDist(i, loc));\n  }\n  return d;\n}\n\n// joins a shape (di, its colour and finish) onto what came before, added, cut or intersected, softly over k. Kept in step with join in sdf.ts\nvoid join(inout float d, inout vec3 col, inout vec4 mat, float di, vec3 ci, vec4 mi, float k, int op) {\n  float h;\n  if (op == 0) {\n    if (k > 1e-4) { h = clamp(0.5 + 0.5 * (d - di) / k, 0.0, 1.0); d = mix(d, di, h) - k * h * (1.0 - h); }\n    else { h = di < d ? 1.0 : 0.0; d = min(d, di); }\n  } else if (op == 1) {\n    float cut = -di;\n    if (k > 1e-4) { h = clamp(0.5 + 0.5 * (cut - d) / k, 0.0, 1.0); d = mix(d, cut, h) + k * h * (1.0 - h); }\n    else { h = cut > d ? 1.0 : 0.0; d = max(d, cut); }\n  } else {\n    if (k > 1e-4) { h = clamp(0.5 + 0.5 * (di - d) / k, 0.0, 1.0); d = mix(d, di, h) + k * h * (1.0 - h); }\n    else { h = di > d ? 1.0 : 0.0; d = max(d, di); }\n  }\n  col = mix(col, ci, h);\n  mat = mix(mat, mi, h);\n}\n\n// What a far-off shape or group is allowed to be, by what the caller needs of the field. The camera's march needs only a safe step: with\n// gSkip at 0 or more, a shape or group whose sphere is further off than its join plus gSkip has its sphere's distance stand in for it (a\n// lower bound, never through it). Everything that reads the field's value (normals, occlusion, shadows' softness, the path tracer) leaves\n// gSkip below 0: then a shape or group is skipped only when its sphere is further off than its join past what is already nearer, which\n// leaves the field exactly as it was.\nfloat gSkip = -1.0;\n\n// the design: shapes joined in order; a group joins its own shapes first, then joins what came before as one. Kept in step with sampleScene in sdf.ts\nfloat map(vec3 p, out vec3 col, out vec4 mat) {\n  float d = 1e9;\n  col = vec3(0.8);\n  mat = vec4(32.0, 0.0, 0.0, 0.0);\n  // a safe step wanted and the baked field at hand: from further off than gSkip, its reading (a lower bound, like a sphere's distance)\n  // stands for every shape at once; outside its box, the box's distance does (every shape is inside). Nearer, the shapes themselves\n#ifndef NO_FIELD\n  if (uVolOn == 1 && gSkip >= 0.0) {\n    vec3 q = (p - uVolMin) / uVolSize;\n    vec3 out3 = max(max(-q, q - 1.0), 0.0) * uVolSize;\n    float outside = length(out3);\n    // textureLod: no gradients, so the march's loops stay loops on Windows (see shapeDist)\n    float v = outside > 0.0 ? outside : textureLod(uVol, q, 0.0).r - uVolSafe;\n    if (v > gSkip) return v;\n  }\n#endif\n  float gd = 1e9;\n  vec3 gcol = vec3(0.8);\n  vec4 gmat = vec4(32.0, 0.0, 0.0, 0.0);\n  int skipTo = -1;  // a group being skipped: its shapes up to its end\n  // bounded by the shapes there are (known only while drawing), so the compiler keeps it a loop rather than pasting the body 48 times\n  int total = gListCount >= 0 ? gListCount : uCount;\n  for (int n = 0; n < total; n++) {\n    int i = n;\n#ifndef NO_FIELD\n    if (gListCount >= 0) {\n      int at = gListStart + n;\n      i = int(texelFetch(uTileList, ivec2(at & 4095, at >> 12), 0).x + 0.5);\n    }\n#endif\n    if (i <= skipTo) continue;\n    int k = kindOf(i);\n    vec4 P = pOf(i), pos = posOf(i);\n    int op = int(P.w + 0.5);\n    float blend = P.z;\n    // how far off a sphere must be for what is inside it to be left out (see gSkip): a cut from further off than its join changes nothing\n    // either; an intersection is never left out (it keeps what is inside it, so leaving it out would keep everything)\n    float beyond = blend + (gSkip < 0.0 ? d : gSkip);\n    if (k == 20) {\n      // a group nowhere near: its sphere (all its shapes, copies, joins and forms inside it) stands for it, and its shapes are skipped\n      int end = int(P.x + 0.5);\n      float far = length(p - pos.xyz) - pos.w;\n      if (pos.w > 0.0 && end > i && op != 2 && far > beyond) {\n        if (gSkip >= 0.0 && op == 0) d = min(d, far);\n        skipTo = end;\n        continue;\n      }\n      gd = d; gcol = col; gmat = mat;\n      d = 1e9; col = vec3(0.8); mat = vec4(32.0, 0.0, 0.0, 0.0);\n      continue;\n    }\n    if (k == 21) {\n      float di = d; vec3 ci = col; vec4 mi = mat;\n      d = gd; col = gcol; mat = gmat;\n      join(d, col, mat, di, ci, mi, P.z, op);\n      continue;\n    }\n    // a shape nowhere near, by its own sphere (its copies, join and form inside it): the same\n    float bound = extraOf(i).z;\n    float near = length(p - pos.xyz) - bound;\n    if (bound > 0.0 && op != 2 && near > beyond) {\n      if (gSkip >= 0.0 && op == 0) d = min(d, near);\n      continue;\n    }\n    float di = copyDist(i, p);\n    join(d, col, mat, di, colOf(i).rgb, vec4(matOf(i).xy, pos.w, halfOf(i).w), blend, op);\n  }\n  return d;\n}\n\nfloat mapD(vec3 p) { vec3 c; vec4 m; return map(p, c, m); }\n\n// the field's slope from four taps at the corners of a tetrahedron (+--, --+, -+-, +++), in a loop so the field is pasted in once (see ZERO)\nvec3 normalAt(vec3 p, float t) {\n  float e = 0.0005 * max(1.0, t);\n  vec3 n = vec3(0.0);\n  for (int j = ZERO; j < 4; j++) {\n    vec3 k = 2.0 * vec3(float(((j + 3) >> 1) & 1), float((j >> 1) & 1), float(j & 1)) - 1.0;\n    n += k * mapD(p + k * e);\n  }\n  return normalize(n);\n}\n\n// imported models in the way of the light, from their depth map (a little soft: nine taps)\nfloat meshShadow(vec3 p) {\n  if (uMeshShadowOn == 0) return 1.0;\n  vec4 c = uLightViewProj * vec4(p, 1.0);\n  vec3 q = c.xyz / c.w * 0.5 + 0.5;\n  if (q.x < 0.0 || q.y < 0.0 || q.x > 1.0 || q.y > 1.0) return 1.0;\n  // beyond the far side of the light's box still takes the shadow of what is in it\n  float z = min(q.z, 1.0) - uShadowBias;\n  vec2 texel = 1.5 / vec2(textureSize(uMeshShadow, 0));\n  float lit = 0.0;\n  for (int x = -1; x <= 1; x++)\n    // textureLod: no gradients, so the loops round this (the 2x2 samples a pixel) stay loops on Windows too (see shapeDist)\n    for (int y = -1; y <= 1; y++) lit += step(z, textureLod(uMeshShadow, q.xy + vec2(float(x), float(y)) * texel, 0.0).r);\n  return lit / 9.0;\n}\n\nfloat ambientOcclusion(vec3 p, vec3 n) {\n  float occ = 0.0;\n  float sca = 1.0;\n  for (int i = ZERO; i < 5; i++) {\n    float h = 0.02 + 0.12 * float(i);\n    occ += (h - mapD(p + n * h)) * sca;\n    sca *= 0.75;\n  }\n  return clamp(1.0 - 1.6 * occ, 0.0, 1.0);\n}\n\n// light j: 0 the key light, then the extra ones. Kept in step with the lights in cpu.ts\nvec3 lightDir(int j) { return j == 0 ? normalize(uLightDir) : uMoreDir[max(j - 1, 0)].xyz; }\nfloat lightPower(int j) { return j == 0 ? uIntensity : uMoreDir[max(j - 1, 0)].w; }\nvec3 lightColour(int j) { return j == 0 ? uLightCol : uMoreCol[max(j - 1, 0)].rgb; }\n\n// light j's share of what lightsAt found\nfloat litBy(vec3 lit, int j) { return j == 0 ? lit.x : j == 1 ? lit.y : lit.z; }\n\n// The light reaching a point from each light (x the key light, y and z the extra ones): 0 where the surface faces away, less in shadow (soft\n// shadows marched towards the light). Every light's march runs in this one loop, light after light, rather than a loop inside a loop over the\n// lights: the field is pasted in once and the loops nest no deeper than one march (see ZERO). A floor point (floor true) always faces the\n// lights and is offset straight up. Kept in step with lightsAt and softShadow in cpu.ts.\nvec3 lightsAt(vec3 p, vec3 n, bool floor) {\n  vec3 lit = vec3(0.0);\n  vec3 ro = p + (floor ? vec3(0.0, 0.002, 0.0) : n * 0.003);\n  int j = 0;          // the light being marched\n  int steps = 0;      // its steps so far (64 at most)\n  bool marching = false;\n  float res = 1.0, t = 0.02;\n  for (int i = ZERO; i < 3 * 64 + 3; i++) {\n    if (j > uMoreLights) break;\n    vec3 l = lightDir(j);\n    vec3 mine = vec3(equal(ivec3(j), ivec3(0, 1, 2)));\n    if (!marching) {\n      // the next light: facing away it gives none, without shadows all of it; otherwise its march starts\n      bool faces = floor || dot(n, l) > 0.0;\n      bool casts = j == 0 ? uShadows == 1 : uMoreCol[max(j - 1, 0)].w > 0.5;\n      if (!faces || !casts) {\n        lit += faces ? mine : vec3(0.0);\n        j++;\n        continue;\n      }\n      marching = true;\n      res = 1.0;\n      t = 0.02;\n      steps = 0;\n    }\n    // a sphere may stand in for what is further off than a tenth of the way along: its distance is then over t / 10, so the shadow's\n    // softness (10 h / t, at most 1) is the same as with the shapes themselves\n    gSkip = 0.1 * t;\n    float h = mapD(ro + l * t);\n    gSkip = -1.0;\n    res = min(res, 10.0 * h / t);\n    t += clamp(h, 0.02, 0.4);\n    steps++;\n    if (res < 0.002 || t > 30.0 || steps == 64) {\n      lit += clamp(res, 0.0, 1.0) * mine;\n      marching = false;\n      j++;\n    }\n  }\n  // imported models' depth map is seen from the key light only\n  lit.x *= meshShadow(floor ? p : p + n * 0.01);\n  return lit;\n}\n\n// occ: a model's own ambient occlusion (1 for none); like the field's, it darkens only the light that is not direct. lit: lightsAt\nvec3 shade(vec3 p, vec3 n, vec3 rd, vec3 albedo, vec2 mat, float occ, vec3 lit) {\n  if (uLook == 3) albedo = vec3(0.86, 0.84, 0.82);\n  vec3 l = normalize(uLightDir);\n  float diff = max(dot(n, l), 0.0);\n  float ao = ambientOcclusion(p, n) * occ;\n  float sky = 0.5 + 0.5 * n.y;\n  if (uLook == 2) return albedo * (0.82 + 0.18 * diff);\n  if (uLook == 1) {\n    // each light in steps; the key light's colour shows in its highlight and rim only, as it always has\n    float rim = pow(1.0 - max(dot(n, -rd), 0.0), 3.0) * 0.25;\n    vec3 c = albedo * uAmbient * 0.9 * occ;\n    for (int j = ZERO; j <= uMoreLights; j++) {\n      vec3 lj = lightDir(j);\n      float d = max(dot(n, lj), 0.0);\n      float stepped = floor(d * litBy(lit, j) * uBands + 0.5) / uBands;\n      float spec = pow(max(dot(n, normalize(lj - rd)), 0.0), mat.x) * d * litBy(lit, j);\n      vec3 col = lightColour(j);\n      c += albedo * (j == 0 ? vec3(1.0) : col) * lightPower(j) * 0.75 * stepped + col * step(0.92, spec) * 0.35;\n      if (j == 0) c += col * rim * stepped;\n    }\n    return c;\n  }\n  // soft: each light with the finish's highlight in it; from the key light also a cool fill from the other side so the shadow side keeps its\n  // form, sky from above and a rim\n  vec3 specCol = mix(vec3(1.0), albedo, mat.y);\n  vec3 base = albedo * (1.0 - 0.6 * mat.y);\n  vec3 fillDir = normalize(vec3(-l.x, 0.3, -l.z));\n  float fill = max(dot(n, fillDir), 0.0);\n  float rim = pow(1.0 - max(dot(n, -rd), 0.0), 4.0);\n  vec3 c = vec3(0.0);\n  for (int j = ZERO; j <= uMoreLights; j++) {\n    vec3 lj = lightDir(j);\n    float d = max(dot(n, lj), 0.0);\n    // a rough surface spreads its highlight so wide that little reaches any one place: full from satin up, a fifth on cloth\n    float spec = pow(max(dot(n, normalize(lj - rd)), 0.0), mat.x) * d * litBy(lit, j) * clamp((mat.x + 8.0) / 68.0, 0.2, 1.0);\n    vec3 col = lightColour(j) * lightPower(j);\n    c += base * col * d * litBy(lit, j) + specCol * col * spec * mix(0.35, 1.6, mat.y) * (mat.x > 60.0 ? 1.0 : 0.6);\n  }\n  c += base * vec3(0.72, 0.82, 1.0) * uAmbient * (0.25 + 0.75 * fill) * ao;\n  c += base * uAmbient * 0.45 * sky * ao;\n  c += uLightCol * rim * 0.22 * uIntensity * ao * sky;\n  // a warm bounce from below\n  c += base * vec3(1.0, 0.9, 0.8) * 0.05 * max(-n.y, 0.0);\n  return c;\n}\n\n// a shape's surface with its whole material (x shininess, y metal, z glow, w glass). Glass in this quick drawing is a tinted, darker body with the\n// sky reflected and a bright edge (the photo-real render bends light through it); a glowing surface lights itself. Kept in step with cpu.ts\nvec3 shadeAs(vec3 p, vec3 n, vec3 rd, vec3 albedo, vec4 mat, float occ, vec3 lit) {\n  // velvet (shininess under 6) has no highlight of its own, only its sheen below\n  vec3 c = shade(p, n, rd, albedo * (1.0 - 0.75 * mat.w), vec2(mat.x < 6.0 ? 8.0 : mat.x, mat.y), occ, lit);\n  if (uLook == 0) {\n    // velvet: a soft sheen towards the edges; a clear coat (shininess over 300): the sky reflected on top, more at grazing angles\n    float velvet = clamp((6.0 - mat.x) / 2.0, 0.0, 1.0), coat = clamp((mat.x - 300.0) / 100.0, 0.0, 1.0);\n    float edge = 1.0 - max(dot(n, -rd), 0.0);\n    if (velvet > 0.0) c += velvet * albedo * edge * edge * 0.9 * (uAmbient + 0.5);\n    if (coat > 0.0) {\n      vec3 sky = mix(vec3(0.3, 0.3, 0.32), vec3(0.95, 0.97, 1.0), 0.5 + 0.5 * reflect(rd, n).y);\n      c += coat * sky * (0.04 + 0.5 * pow(edge, 5.0));\n    }\n  }\n  if (mat.w > 0.0 && uLook == 0) {\n    float fres = pow(1.0 - max(dot(n, -rd), 0.0), 3.0);\n    vec3 sky = mix(vec3(0.55, 0.6, 0.68), vec3(0.95, 0.97, 1.0), 0.5 + 0.5 * reflect(rd, n).y);\n    c += mat.w * (sky * (0.08 + 0.7 * fres) + albedo * 0.1);\n  }\n  if (mat.z > 0.0 && uLook != 3) c = mix(c, albedo * 1.35, mat.z);\n  return c;\n}\n\n// the ray through a point of the picture\nvoid rayFor(vec2 frag, out vec3 ro, out vec3 rd) {\n  vec2 ndc = (frag / uRes) * 2.0 - 1.0;\n  float aspect = uRes.x / uRes.y;\n  if (uOrtho == 1) {\n    ro = uCamPos + uCamRot * vec3(ndc.x * uOrthoHalf * aspect, ndc.y * uOrthoHalf, 0.0);\n    rd = normalize(uCamRot * vec3(0.0, 0.0, -1.0));\n  } else {\n    ro = uCamPos;\n    rd = normalize(uCamRot * vec3(ndc.x * uTanHalf * aspect, ndc.y * uTanHalf, -1.0));\n  }\n}\n\n// where a ray meets the ground plane (x, z), or far away when it never does\nvec2 onGround(vec3 ro, vec3 rd) {\n  return rd.y < -1e-5 && ro.y > 0.0 || rd.y > 1e-5 && ro.y < 0.0 ? (ro + rd * (-ro.y / rd.y)).xz : vec2(1e6);\n}\n\n// lines at whole numbers of c, about one pixel wide (fw: how far c moves across a pixel)\nfloat gridLines(vec2 c, vec2 fw) {\n  vec2 d = abs(fract(c - 0.5) - 0.5) / max(fw, vec2(1e-6));\n  return 1.0 - min(min(d.x, d.y), 1.0);\n}\n\n// The editing grid on the ground: a thin line every cell, a stronger one every fifth, the x axis red and the z axis blue. Lines fade where the\n// cells get too small to tell apart, so far away there is no shimmer. Straight colour and alpha.\nvec4 gridAt(vec2 frag, vec3 ro, vec3 rd) {\n  vec2 g = onGround(ro, rd);\n  if (uGrid <= 0.0 || g.x > 1e5) return vec4(0.0);\n  // how far the ground point moves across one pixel, from the rays through the neighbouring pixels\n  vec3 ro1, rd1, ro2, rd2;\n  rayFor(frag + vec2(1.0, 0.0), ro1, rd1);\n  rayFor(frag + vec2(0.0, 1.0), ro2, rd2);\n  vec2 fw = min(abs(onGround(ro1, rd1) - g) + abs(onGround(ro2, rd2) - g), vec2(1e3));\n  float big = uGrid * 5.0;\n  float minor = gridLines(g / uGrid, fw / uGrid) * (1.0 - smoothstep(0.12, 0.3, max(fw.x, fw.y) / uGrid));\n  float major = gridLines(g / big, fw / big) * (1.0 - smoothstep(0.12, 0.3, max(fw.x, fw.y) / big));\n  vec2 axis = (1.0 - min(abs(g) / max(fw * 1.9, vec2(1e-6)), 1.0)) * (1.0 - smoothstep(0.5, 2.0, fw.yx / uGrid));\n  vec3 ink = uTransparent == 0 && dot(uBg, vec3(0.299, 0.587, 0.114)) > 0.5 ? vec3(0.12, 0.1, 0.18) : vec3(0.82, 0.8, 0.9);\n  vec4 c = vec4(ink, max(minor * 0.22, major * 0.42));\n  // the x axis runs where z = 0, the z axis where x = 0\n  if (axis.y > 0.0) c = mix(c, vec4(1.0, 0.36, 0.4, 0.95), axis.y);\n  if (axis.x > 0.0) c = mix(c, vec4(0.38, 0.6, 1.0, 0.95), axis.x);\n  return c;\n}\n\n// b drawn over a (straight colours)\nvec4 over(vec4 a, vec4 b) {\n  float alpha = b.a + a.a * (1.0 - b.a);\n  return alpha > 0.0 ? vec4((b.rgb * b.a + a.rgb * a.a * (1.0 - b.a)) / alpha, alpha) : vec4(0.0);\n}\n\n", xr = br + "\nin vec2 vUv;\n// the depth of what this pixel shows (1 for nothing)\nfloat gDepth;\nfloat depthOf(vec3 p) {\n  vec4 c = uViewProj * vec4(p, 1.0);\n  return clamp(c.z / c.w * 0.5 + 0.5, 0.0, 1.0);\n}\n\nvec4 render(vec2 frag) {\n  vec3 ro, rd;\n  rayFor(frag, ro, rd);\n  // a pixel's width in scene units at distance t: the outline is measured in pixels\n  float pixel = uOrtho == 1 ? 2.0 * uOrthoHalf / uRes.y : 2.0 * uTanHalf / uRes.y;\n  float outlinePx = uOutline * uRes.y / 1000.0;\n\n  float tGround = (uGround == 1 && rd.y < -1e-4) ? -ro.y / rd.y : 1e9;\n  float t = uOrtho == 1 ? 0.0 : 0.01;\n  float closest = 1e9;\n  bool hit = false;\n  vec3 col; vec4 mat;\n  if (uTilesOn == 1) {\n    ivec2 tile = clamp(ivec2(frag / uTilePx), ivec2(0), textureSize(uTiles, 0) - 1);\n    vec4 head = texelFetch(uTiles, tile, 0);\n    gListStart = int(head.x + 0.5);\n    gListCount = int(head.y + 0.5);\n  }\n  for (int i = ZERO; i < 200; i++) {\n    vec3 p = ro + rd * t;\n    float w = uOrtho == 1 ? pixel : pixel * max(t, 0.01);\n    // a sphere may stand in for what is further off than the outline's width: the outline is drawn from the nearest pass, and must not\n    // be drawn round a sphere\n    gSkip = outlinePx * w + 0.05;\n    float d = map(p, col, mat);\n    closest = min(closest, d / w);\n    if (d < 0.0004 * max(1.0, t)) { hit = true; break; }\n    t += d * 0.92;\n    if (t > 120.0 || t > tGround + 0.5) break;\n  }\n  gSkip = -1.0;\n  gListCount = -1;\n  bool surface = hit && t < tGround + 1e-3;\n  if (!surface && outlinePx > 0.0 && closest < outlinePx) return vec4(uOutlineCol, smoothstep(outlinePx, outlinePx * 0.6, closest));\n  // the surface's normal and the light reaching it, or the floor's; one call of each for both (see ZERO)\n  vec3 p = ro + rd * (surface ? t : tGround);\n  vec3 n = surface ? normalAt(p, t) : vec3(0.0, 1.0, 0.0);\n  vec3 lit = surface || tGround < 1e8 ? lightsAt(p, n, !surface) : vec3(0.0);\n  if (surface) {\n    vec3 c = shadeAs(p, n, rd, labelled(p, n, col), mat, 1.0, lit);\n    gDepth = depthOf(p);\n    // an inked edge where the surface turns away from the eye\n    if (outlinePx > 0.0) {\n      float facing = abs(dot(n, rd));\n      float edge = smoothstep(0.12 + 0.02 * outlinePx, 0.02, facing);\n      c = mix(c, uOutlineCol, edge);\n    }\n    return vec4(c, 1.0);\n  }\n  vec4 bg = uTransparent == 1 ? vec4(0.0) : vec4(uBg, 1.0);\n  if (tGround < 1e8) {\n    // the floor hides what is under it\n    gDepth = depthOf(p);\n    // the share of the light that is blocked, each light counted by its brightness\n    float reach = 0.0, all = 0.0;\n    for (int j = ZERO; j <= uMoreLights; j++) {\n      float w = max(lightPower(j), 1e-4);\n      reach += w * litBy(lit, j);\n      all += w;\n    }\n    float sh = 1.0 - reach / all;\n    // fades out away from the middle, so the floor has no edge\n    float fade = exp(-0.08 * length(p.xz));\n    float a = sh * uGroundShadow * fade;\n    bg = uTransparent == 1 ? vec4(0.0, 0.0, 0.0, a) : vec4(bg.rgb * (1.0 - a), 1.0);\n  }\n  return over(bg, gridAt(frag, ro, rd));\n}\n\nvoid main() {\n  vec2 frag = uTileOffset + vUv * uTileSize;\n  vec4 acc = vec4(0.0);\n  float depth = 1.0;\n  // one call of render for one sample or 2x2 (see ZERO)\n  int samples = uSamples > 1 ? 4 : 1;\n  for (int s = ZERO; s < samples; s++) {\n    gDepth = 1.0;\n    vec2 at = samples > 1 ? (vec2(float(s & 1), float(s >> 1)) - 0.5) * 0.5 : vec2(0.0);\n    vec4 c = render(frag + at);\n    acc += vec4(c.rgb * c.a, c.a);\n    depth = min(depth, gDepth);\n  }\n  acc /= float(samples);\n  gl_FragDepth = depth;\n  // to sRGB, alpha not premultiplied\n  vec3 rgb = acc.a > 0.0 ? acc.rgb / acc.a : vec3(0.0);\n  fragColor = vec4(pow(max(rgb, 0.0), vec3(1.0 / 2.2)), acc.a);\n}\n", Sr = br + "\nin vec2 vUv;\nuniform float uVolSlice;\nvoid main() {\n  vec3 p = uVolMin + vec3(vUv, uVolSlice) * uVolSize;\n  gSkip = -1.0;\n  fragColor = vec4(mapD(p), 0.0, 0.0, 1.0);\n}\n", Cr = "\nin vec3 aColor;\nuniform mat3 uNormalWorld;\nout vec3 vWorld;\nout vec3 vNormal;\nout vec2 vMeshUv;\nout vec3 vColor;\nvoid main() {\n  vec4 w = modelMatrix * vec4(position, 1.0);\n  vWorld = w.xyz;\n  vNormal = uNormalWorld * normal;\n  vMeshUv = uv;\n  vColor = aColor;\n  gl_Position = projectionMatrix * viewMatrix * w;\n}\n", wr = ("#define NO_FIELD\n" + br + "\nin vec3 vWorld;\nin vec3 vNormal;\nin vec2 vMeshUv;\nin vec3 vColor;\nuniform vec3 uAlbedo;     // linear\nuniform sampler2D uMap;   // sRGB\nuniform int uHasMap;\nuniform vec2 uFinish;     // shininess, metal (the shape's finish, or the model's when it has no roughness)\nuniform int uCutout;\nuniform int uUnlit;          // 1: the colours as they are, no light (a photo card)\nuniform sampler2D uNormalMap;\nuniform int uHasNormal;\nuniform float uNormalScale;\nuniform sampler2D uRoughMap; // glTF: roughness in green, metalness in blue\nuniform int uPbr;            // 1: the finish from the model's roughness and metalness (uRoughMetal, scaled by uRoughMap)\nuniform int uHasRough;\nuniform vec2 uRoughMetal;\nuniform sampler2D uAoMap;     // red: ambient occlusion\nuniform int uHasAo;\nuniform float uAoStrength;\nuniform vec3 uEmissive;       // linear, strength included\nuniform sampler2D uEmissiveMap; // sRGB\nuniform int uHasEmissive;\nuniform float uClearcoat;      // 0 for none\nuniform float uCoatRough;\nuniform sampler2D uCoatMap;    // red: amount\nuniform int uHasCoatMap;\nuniform sampler2D uCoatRoughMap; // green: roughness\nuniform int uHasCoatRoughMap;\nuniform sampler2D uCoatNormalMap;\nuniform int uHasCoatNormal;\nuniform float uCoatNormalScale;\nuniform vec3 uSheen;           // linear colour, black for none\nuniform float uSheenRough;\nuniform sampler2D uSheenMap;   // sRGB colour\nuniform int uHasSheenMap;\nuniform sampler2D uSheenRoughMap; // alpha: roughness\nuniform int uHasSheenRoughMap;\nuniform float uTransmission;   // 0 for none\nuniform sampler2D uTransmissionMap; // red: amount\nuniform int uHasTransmissionMap;\nuniform float uIor;\nuniform sampler2D uBackdrop;   // what was drawn behind (sRGB, straight alpha), for light passing through\nuniform int uHasBackdrop;\n\n// a soft studio around the design, for what a glossy layer reflects: a dark floor, a bright sky, and a long softbox above the horizon (the\n// band a varnished or glass surface shows). Kept in step with studio in cpu.ts\nvec3 studio(vec3 dir) {\n  float box = smoothstep(0.22, 0.32, dir.y) * (1.0 - smoothstep(0.5, 0.62, dir.y));\n  return (mix(vec3(0.3, 0.28, 0.27), vec3(0.85, 0.9, 1.0), smoothstep(-0.25, 0.6, dir.y)) + 1.6 * box) * (0.5 + uAmbient) * uLightCol;\n}\nfloat fresnel(float cosTheta, float f0) {\n  return f0 + (1.0 - f0) * pow(1.0 - cosTheta, 5.0);\n}\n\n// a normal map's normal, in a tangent frame made from how the position and texture coordinates change across the pixel (no stored tangents).\n// glTF's normal maps have +Y up the picture, which is against v here (v runs down the picture)\nvec3 mappedNormal(sampler2D map, float strength, vec3 n, vec2 uv, vec3 dp1, vec3 dp2, vec2 duv1, vec2 duv2) {\n  vec3 dp2perp = cross(dp2, n), dp1perp = cross(n, dp1);\n  vec3 t = dp2perp * duv1.x + dp1perp * duv2.x;\n  vec3 b = dp2perp * duv1.y + dp1perp * duv2.y;\n  float scale = max(dot(t, t), dot(b, b));\n  if (scale < 1e-20) return n;\n  // a back face's frame was made with the turned-round normal: turned back\n  float k = (gl_FrontFacing ? 1.0 : -1.0) * inversesqrt(scale);\n  vec3 m = texture(map, uv).xyz * 2.0 - 1.0;\n  m.xy *= strength;\n  return normalize(mat3(t * k, -b * k, n) * m);\n}\n\nvoid main() {\n  // the material's own look and toon steps, or the design's\n  gLook = uMatLook >= 0 ? uMatLook : uLook;\n  gBands = uMatBands > 0.0 ? uMatBands : uBands;\n  // the changes across the pixel, taken before anything can discard it\n  vec3 dp1 = dFdx(vWorld), dp2 = dFdy(vWorld);\n  vec2 duv1 = dFdx(vMeshUv), duv2 = dFdy(vMeshUv);\n  vec4 tex = uHasMap == 1 ? texture(uMap, vMeshUv) : vec4(1.0);\n  if (uCutout == 1 && tex.a < 0.5) discard;\n  if (uUnlit == 1) {\n    fragColor = vec4(uAlbedo * tex.rgb * vColor, 1.0);\n    return;\n  }\n  vec3 n = normalize(vNormal);\n  if (!gl_FrontFacing) n = -n;\n  // the surface's own shape, before the normal map (a clear coat lies over it)\n  vec3 shapeN = n;\n  if (uHasNormal == 1) n = mappedNormal(uNormalMap, uNormalScale, n, vMeshUv, dp1, dp2, duv1, duv2);\n  vec2 finish = uFinish;\n  if (uPbr == 1) {\n    vec2 rm = uRoughMetal;\n    if (uHasRough == 1) rm *= texture(uRoughMap, vMeshUv).gb;\n    finish = vec2(6.0 + (1.0 - rm.x) * (1.0 - rm.x) * 134.0, rm.y);\n  }\n  vec3 rd = uOrtho == 1 ? normalize(uCamRot * vec3(0.0, 0.0, -1.0)) : normalize(vWorld - uCamPos);\n  vec3 albedo = uAlbedo * pow(tex.rgb, vec3(2.2)) * vColor;\n  float occ = uHasAo == 1 ? 1.0 + uAoStrength * (texture(uAoMap, vMeshUv).r - 1.0) : 1.0;\n  vec3 l = normalize(uLightDir);\n  // the light reaching the surface, traced once from its own shape for the shading and the layers below (see ZERO)\n  vec3 lit = lightsAt(vWorld, shapeN, false);\n  vec3 c = shade(vWorld, n, rd, albedo, finish, occ, lit);\n  float vis = lit.x;\n  vec3 v = -rd;\n  float alpha = 1.0;\n  // the layers a physical material adds (clay shows the form only; toon and flat stay drawn)\n  bool layered = uLook == 0 && (uClearcoat > 0.0 || max(uSheen.r, max(uSheen.g, uSheen.b)) > 0.0 || uTransmission > 0.0);\n  if (!layered) vis = 1.0;\n  // light passing through, like glass: what was drawn behind, bent a little and tinted by the surface's colour\n  float trans = uLook != 3 ? uTransmission * (uHasTransmissionMap == 1 ? texture(uTransmissionMap, vMeshUv).r : 1.0) : 0.0;\n  if (trans > 0.0 && uHasBackdrop == 1) {\n    float f0 = pow((uIor - 1.0) / (uIor + 1.0), 2.0);\n    float f = fresnel(max(dot(n, v), 0.0), f0);\n    vec3 nv = normalize(mat3(viewMatrix) * n);\n    vec2 size = vec2(textureSize(uBackdrop, 0));\n    vec2 uv = gl_FragCoord.xy / size - nv.xy * (1.0 - 1.0 / uIor) * 0.08;\n    vec4 behind = texture(uBackdrop, clamp(uv, vec2(0.0), vec2(1.0)));\n    vec3 through = pow(behind.rgb, vec3(2.2)) * albedo;\n    float k = trans * (1.0 - f);\n    vec3 h = normalize(l + v);\n    float glint = pow(max(dot(n, h), 0.0), max(finish.x, 60.0)) * max(dot(n, l), 0.0) * vis * uIntensity;\n    c = mix(c, through, k) + studio(reflect(rd, n)) * f * trans + uLightCol * glint;\n    alpha = mix(1.0, behind.a, k);\n    alpha = clamp(alpha + glint + f * trans, 0.0, 1.0);\n  }\n  // a velvet glow at grazing angles\n  if (uLook == 0 && max(uSheen.r, max(uSheen.g, uSheen.b)) > 0.0) {\n    vec3 sheen = uSheen * (uHasSheenMap == 1 ? pow(texture(uSheenMap, vMeshUv).rgb, vec3(2.2)) : vec3(1.0));\n    float rough = uSheenRough * (uHasSheenRoughMap == 1 ? texture(uSheenRoughMap, vMeshUv).a : 1.0);\n    float rim = pow(1.0 - max(dot(n, v), 0.0), mix(5.0, 1.5, rough));\n    c += sheen * rim * (uLightCol * uIntensity * max(dot(n, l), 0.0) * vis * 0.8 + uAmbient * 0.6 * occ);\n  }\n  // a clear varnish on top: a sharp highlight and the studio reflected, more at grazing angles, the surface below a little dimmer\n  if (uLook == 0 && uClearcoat > 0.0) {\n    float coat = uClearcoat * (uHasCoatMap == 1 ? texture(uCoatMap, vMeshUv).r : 1.0);\n    float rough = uCoatRough * (uHasCoatRoughMap == 1 ? texture(uCoatRoughMap, vMeshUv).g : 1.0);\n    vec3 nc = uHasCoatNormal == 1 ? mappedNormal(uCoatNormalMap, uCoatNormalScale, shapeN, vMeshUv, dp1, dp2, duv1, duv2) : shapeN;\n    float f = fresnel(max(dot(nc, v), 0.0), 0.04);\n    vec3 h = normalize(l + v);\n    float shine = 8.0 + (1.0 - rough) * (1.0 - rough) * 600.0;\n    float spec = pow(max(dot(nc, h), 0.0), shine) * max(dot(nc, l), 0.0) * vis * uIntensity * (1.0 + shine / 120.0);\n    vec3 reflected = studio(reflect(rd, nc)) * mix(1.0, 0.35, rough);\n    c = c * (1.0 - coat * f) + coat * (uLightCol * spec + reflected * f);\n  }\n  // the light it gives off, on top (clay shows the form only)\n  if (uLook != 3) c += uEmissive * (uHasEmissive == 1 ? pow(texture(uEmissiveMap, vMeshUv).rgb, vec3(2.2)) : vec3(1.0));\n  if (uOutline > 0.0) {\n    float outlinePx = uOutline * uRes.y / 1000.0;\n    float edge = smoothstep(0.12 + 0.02 * outlinePx, 0.02, abs(dot(n, rd)));\n    c = mix(c, uOutlineCol, edge);\n    alpha = mix(alpha, 1.0, edge);\n  }\n  fragColor = vec4(pow(max(c, 0.0), vec3(1.0 / 2.2)), alpha);\n}\n").replace(/\buLook\b/g, "gLook").replace(/\buBands\b/g, "gBands").replace("uniform int gLook;", "uniform int uLook;\nuniform int uMatLook;\nint gLook;").replace("uniform float gBands;", "uniform float uBands;\nuniform float uMatBands;\nfloat gBands;").replace("gLook = uMatLook >= 0 ? uMatLook : gLook;", "gLook = uMatLook >= 0 ? uMatLook : uLook;").replace("gBands = uMatBands > 0.0 ? uMatBands : gBands;", "gBands = uMatBands > 0.0 ? uMatBands : uBands;"), Tr = "\nin vec3 aHull;\nuniform mat3 uNormalWorld;\nuniform float uOutline;\nuniform vec2 uRes;\nvoid main() {\n  vec4 clip = projectionMatrix * viewMatrix * modelMatrix * vec4(position, 1.0);\n  vec4 nclip = projectionMatrix * viewMatrix * vec4(normalize(uNormalWorld * aHull), 0.0);\n  vec2 dir = nclip.xy;\n  float l = length(dir);\n  dir = l > 1e-6 ? dir / l : vec2(0.0);\n  clip.xy += dir * (uOutline * uRes.y / 1000.0) * 2.0 / uRes * clip.w;\n  gl_Position = clip;\n}\n", Er = "\nprecision highp float;\nuniform vec3 uOutlineCol;\nout vec4 fragColor;\nvoid main() {\n  fragColor = vec4(pow(uOutlineCol, vec3(1.0 / 2.2)), 1.0);\n}\n", Dr = `
precision highp float;
#define TAPS 64
#define SPREAD ${Nt.toFixed(2)}
in vec2 vUv;
out vec4 fragColor;
uniform sampler2D uColor;      // the drawing: sRGB, alpha not premultiplied
uniform sampler2D uDepth;      // its depth, 0-1
uniform vec2 uSize;            // pixels
uniform float uNear;
uniform float uFar;
uniform int uOrthoDepth;       // 1 when the drawing camera is orthographic (depth is then linear)
uniform float uFocusAt;        // the distance in focus
uniform float uRadius;         // the blur of the far distance, pixels

float viewZ(vec2 uv) {
  float d = textureLod(uDepth, uv, 0.0).r;
  return uOrthoDepth == 1 ? uNear + d * (uFar - uNear) : uNear * uFar / (uFar - d * (uFar - uNear));
}
float circleOf(float z) { return uRadius * min(1.0, SPREAD * abs(z - uFocusAt) / max(z, 1e-4)); }
// linear colour premultiplied by alpha, so blurred edges fade out rather than darken
vec4 linearAt(vec2 uv) {
  vec4 c = textureLod(uColor, uv, 0.0);
  return vec4(pow(c.rgb, vec3(2.2)) * c.a, c.a);
}

void main() {
  vec2 px = 1.0 / uSize;
  float zc = viewZ(vUv);
  float cc = circleOf(zc);
  vec2 here = floor(vUv * uSize) + 0.5;
  vec4 sum = linearAt(vUv);
  float count = 1.0;
  for (int t = 0; t < TAPS; t++) {
    float r = sqrt((float(t) + 0.5) / float(TAPS)) * uRadius;
    float a = float(t) * 2.39996323;
    // whole pixels, as the CPU reads them
    vec2 uv = clamp((here + floor(vec2(cos(a), sin(a)) * r + 0.5)) * px, 0.5 * px, 1.0 - 0.5 * px);
    float z = viewZ(uv);
    float reach = z > zc ? min(circleOf(z), cc * 2.0) : circleOf(z);
    // its colour where its blur reaches here, the average so far where not
    sum += mix(sum / count, linearAt(uv), smoothstep(r - 0.5, r + 0.5, reach));
    count += 1.0;
  }
  vec4 c = sum / count;
  fragColor = c.a > 0.0 ? vec4(pow(max(c.rgb / c.a, 0.0), vec3(1.0 / 2.2)), c.a) : vec4(0.0);
}
`, Or = "\nin vec2 vUv;\nuniform sampler2D uAccum;   // the average so far (linear)\nuniform int uFrame;         // passes so far\nuniform vec3 uStudio;       // the background and floor colour (linear)\n// imported models (meshtrace.ts): their hierarchy's nodes (2 texels each) and triangles (12 each), materials and their pictures\nuniform highp sampler2D uBvh;\nuniform highp sampler2D uTris;\nuniform int uMeshTris;      // triangles (0: none)\n// materials, 4 texels each (meshtrace.ts TRACE_MAT_TEXELS): 0 rgb colour (linear), w its picture's layer (-1 none); 1 x metal, y roughness,\n// z glass, w its normal map's layer (-1 none); 2 rgb the light it gives off, w its normal map's strength; 3 x its own look (TRACE_LOOK: -1 the\n// design's, 0 physical, 1 toon, 2 flat, 3 clay, 4 unlit), y its toon steps (0: the design's), z its glow picture's layer (-1 none)\nuniform highp sampler2D uTMats;\n// the look and toon steps of the model surface meshSurface last read\nint gMeshLook;\nfloat gMeshBands;\nuniform highp sampler2DArray uTPics;\n// lights besides the key light, as placed (see ExtraLight3D): where, which way they face, and their kind\nuniform vec4 uLightPos[2];   // xyz where a point, spot or panel is\nuniform vec4 uLightAim[2];   // xyz the way a spot or panel faces, w the cosine of half a spot's cone\nuniform vec4 uLightKind[2];  // x 0 sun, 1 point, 2 spot, 3 area; y how far from the camera's target; z a panel's radius\n// a picture all round (equirectangular): x strength, y turn (radians), z 1 when it shows behind the design\nuniform highp sampler2D uEnv;\nuniform int uHasEnv;\nuniform vec4 uEnvSet;\n// the lens: how wide its opening (0: all sharp) and how far it is focused\nuniform float uAperture;\nuniform float uFocusDist;\n// 1: a see-through background stays clear in the picture (alpha), the floor catching only the shadow\nuniform int uKeepClear;\n\nuint seed;\nfloat rnd() {\n  seed = seed * 747796405u + 2891336453u;\n  uint w = ((seed >> ((seed >> 28u) + 4u)) ^ seed) * 277803737u;\n  return float((w >> 22u) ^ w) / 4294967295.0;\n}\n// a direction round n, more of them near n (as light falls on a matte surface)\nvec3 cosineDir(vec3 n) {\n  float a = 6.2831853 * rnd(), v = rnd(), r = sqrt(v);\n  vec3 t = normalize(abs(n.y) < 0.99 ? cross(n, vec3(0.0, 1.0, 0.0)) : cross(n, vec3(1.0, 0.0, 0.0)));\n  vec3 b = cross(n, t);\n  return normalize(t * cos(a) * r + b * sin(a) * r + n * sqrt(1.0 - v));\n}\n// the environment picture in a direction (linear)\nvec3 envAt(vec3 d) {\n  float u = atan(d.x, -d.z) / 6.2831853 + 0.5 + uEnvSet.y / 6.2831853;\n  float v = acos(clamp(d.y, -1.0, 1.0)) / 3.14159265;\n  return pow(textureLod(uEnv, vec2(fract(u), v), 0.0).rgb, vec3(2.2)) * uEnvSet.x;\n}\n// the light all round: the environment picture, or a soft studio, brighter above, with a long softbox band (what glossy things reflect)\nvec3 sky(vec3 d) {\n  if (uHasEnv == 1) return envAt(d);\n  float box = smoothstep(0.22, 0.32, d.y) * (1.0 - smoothstep(0.5, 0.62, d.y));\n  return (mix(vec3(0.32, 0.31, 0.3), vec3(0.95, 0.97, 1.0), smoothstep(-0.3, 0.7, d.y)) + 1.4 * box) * (0.35 + uAmbient) * uLightCol;\n}\nvec4 bvhAt(int i) { int w = textureSize(uBvh, 0).x; return texelFetch(uBvh, ivec2(i % w, i / w), 0); }\nvec4 matAt(int m, int k) { int i = m * 4 + k; int w = textureSize(uTMats, 0).x; return texelFetch(uTMats, ivec2(i % w, i / w), 0); }\nvec4 triAt(int t, int k) { int i = t * 12 + k; int w = textureSize(uTris, 0).x; return texelFetch(uTris, ivec2(i % w, i / w), 0); }\n\n// the nearest imported-model triangle along a ray before tMax: its distance (1e30 for none), index and barycentric (u, v). Walks the hierarchy\n// with a small stack, nearest boxes first not needed: a box farther than the best hit is skipped. Kept in step with traceMeshCpu\nfloat meshHit(vec3 ro, vec3 rd, float tMax, out int tri, out vec2 bc) {\n  tri = -1;\n  bc = vec2(0.0);\n  if (uMeshTris == 0) return 1e30;\n  vec3 inv = 1.0 / rd;\n  int stack[48];\n  int sp = 0;\n  stack[sp++] = 0;\n  float best = tMax;\n  for (int guard = ZERO; guard < 8192 && sp > 0; guard++) {\n    int ni = stack[--sp];\n    vec4 a = bvhAt(ni * 2), b = bvhAt(ni * 2 + 1);\n    vec3 t0 = (a.xyz - ro) * inv, t1 = (b.xyz - ro) * inv;\n    vec3 near3 = min(t0, t1), far3 = max(t0, t1);\n    float tn = max(max(near3.x, near3.y), max(near3.z, 0.0)), tf = min(min(far3.x, far3.y), min(far3.z, best));\n    if (tn > tf) continue;\n    int count = int(b.w + 0.5), first = int(a.w + 0.5);\n    if (count == 0) {\n      if (sp < 46) { stack[sp++] = first; stack[sp++] = first + 1; }\n      continue;\n    }\n    for (int k = 0; k < count; k++) {\n      int t = first + k;\n      vec3 p0 = triAt(t, 0).xyz;\n      vec3 e1 = triAt(t, 1).xyz - p0, e2 = triAt(t, 2).xyz - p0;\n      vec3 h = cross(rd, e2);\n      float det = dot(e1, h);\n      if (abs(det) < 1e-12) continue;\n      float f = 1.0 / det;\n      vec3 s = ro - p0;\n      float u = f * dot(s, h);\n      if (u < 0.0 || u > 1.0) continue;\n      vec3 q = cross(s, e1);\n      float v = f * dot(rd, q);\n      if (v < 0.0 || u + v > 1.0) continue;\n      float tt = f * dot(e2, q);\n      if (tt > 1e-4 && tt < best) { best = tt; tri = t; bc = vec2(u, v); }\n    }\n  }\n  return tri >= 0 ? best : 1e30;\n}\n\n// an imported model's surface where a ray met it: the normal facing the ray, colour (material, picture, the points' colours), finish as\n// the shapes' (shininess, metal, glow, glass), the light it gives off, and whether the ray met it from behind (inside glass)\nvoid meshSurface(int t, vec2 bc, vec3 rd, out vec3 n, out vec3 col, out vec4 mat, out vec3 glow, out bool back) {\n  float w0 = 1.0 - bc.x - bc.y;\n  vec4 t3 = triAt(t, 3), t4 = triAt(t, 4), t5 = triAt(t, 5), t6 = triAt(t, 6);\n  vec3 p0 = triAt(t, 0).xyz;\n  vec3 gn = normalize(cross(triAt(t, 1).xyz - p0, triAt(t, 2).xyz - p0));\n  back = dot(gn, rd) > 0.0;\n  if (back) gn = -gn;\n  vec2 uv = vec2(t3.w, t4.w) * w0 + vec2(t5.w, t6.x) * bc.x + t6.yz * bc.y;\n  vec3 vc = triAt(t, 7).rgb * w0 + triAt(t, 8).rgb * bc.x + triAt(t, 9).rgb * bc.y;\n  int m = int(triAt(t, 0).w + 0.5);\n  vec4 A = matAt(m, 0), B = matAt(m, 1), C = matAt(m, 2), D = matAt(m, 3);\n  n = normalize(t3.xyz * w0 + t4.xyz * bc.x + t5.xyz * bc.y);\n  // a normal map: its colour turned into a normal along the triangle's u and v (+Y up the picture, as mappedNormal)\n  vec3 tu = triAt(t, 10).xyz, tv = triAt(t, 11).xyz;\n  if (B.w >= 0.0 && dot(tu, tu) > 1e-20 && dot(tv, tv) > 1e-20) {\n    vec3 mm = textureLod(uTPics, vec3(fract(uv), B.w), 0.0).xyz * 2.0 - 1.0;\n    mm.xy *= C.w;\n    vec3 tx = normalize(tu - n * dot(n, tu)), ty = normalize(-tv - n * dot(n, -tv));\n    n = normalize(mat3(tx, ty, n) * mm);\n  }\n  if (dot(n, gn) < 0.0) n = -n;\n  col = A.rgb * vc;\n  if (A.w >= 0.0) col *= pow(textureLod(uTPics, vec3(fract(uv), A.w), 0.0).rgb, vec3(2.2));\n  float smooth1 = 1.0 - B.y;\n  glow = C.rgb;\n  if (D.z >= 0.0) glow *= pow(textureLod(uTPics, vec3(fract(uv), D.z), 0.0).rgb, vec3(2.2));\n  mat = vec4(6.0 + smooth1 * smooth1 * 134.0, B.x, 0.0, B.z);\n  // -1: no look of its own (the design's)\n  gMeshLook = int(floor(D.x + 0.5));\n  gMeshBands = D.y > 0.0 ? D.y : uBands;\n}\n// whether an imported model is between a point and a light\nfloat meshVisible(vec3 p, vec3 l) {\n  int tr;\n  vec2 b2;\n  return meshHit(p, l, 1e9, tr, b2) < 1e29 ? 0.0 : 1.0;\n}\n\n// the first surface along a ray (-1 for none); inside glass the field is turned inside out\nfloat traceRay(vec3 ro, vec3 rd, bool inside, float maxT, out vec3 col, out vec4 mat) {\n  float t = 0.002;\n  for (int i = ZERO; i < 256; i++) {\n    float d = map(ro + rd * t, col, mat);\n    if (inside) d = -d;\n    if (d < 0.0004 * max(1.0, t)) return t;\n    t += max(d * 0.9, 0.0005);\n    if (t > maxT) break;\n  }\n  return -1.0;\n}\n\n// how much of light j reaches a point (its brightness, falloff, cone and shadow) and the way to it. The sun-like ones come from lightsAt\n// (shadows of the shapes; imported models' are added after); a point, spot or panel is placed, falls off with distance (as bright as set at\n// the camera's target), and its shadow is marched to it (to a random point on a panel, so its shadows are soft)\nfloat lightReach(int j, vec3 p, vec3 n, vec3 lit, out vec3 l) {\n  vec4 kind = j == 0 ? vec4(0.0) : uLightKind[max(j - 1, 0)];\n  if (kind.x < 0.5) {\n    l = lightDir(j);\n    return litBy(lit, j) * lightPower(j);\n  }\n  vec3 pos = uLightPos[j - 1].xyz;\n  vec4 aim = uLightAim[j - 1];\n  if (kind.x > 2.5) {\n    vec3 t = normalize(abs(aim.y) < 0.99 ? cross(aim.xyz, vec3(0.0, 1.0, 0.0)) : cross(aim.xyz, vec3(1.0, 0.0, 0.0)));\n    vec3 bb = cross(aim.xyz, t);\n    float r = kind.z * sqrt(rnd()), a = 6.2831853 * rnd();\n    pos += (t * cos(a) + bb * sin(a)) * r;\n  }\n  vec3 L = pos - p;\n  float dist = length(L);\n  l = L / dist;\n  if (dot(n, l) <= 0.0) return 0.0;\n  float k = lightPower(j) * kind.y * kind.y / max(dist * dist, 1e-4);\n  float facing = dot(-l, aim.xyz);\n  if (kind.x > 1.5 && kind.x < 2.5) k *= smoothstep(aim.w, mix(aim.w, 1.0, 0.3), facing);\n  if (kind.x > 2.5) k *= max(facing, 0.0);\n  if (k <= 0.0) return 0.0;\n  if (uMoreCol[j - 1].w > 0.5) {\n    vec3 c2; vec4 m2;\n    if (traceRay(p + n * 0.003, l, false, dist, c2, m2) > 0.0) return 0.0;\n  }\n  int tr;\n  vec2 b2;\n  if (meshHit(p + n * 0.003, l, dist, tr, b2) < 1e29) return 0.0;\n  return k;\n}\n\n", kr = br + Or + "\n// a surface painted rather than lit for real (look 1 toon, 2 flat), as shade draws it: toon in steps of how much of each light reaches\n// (the key light white, the others in their colour) over a little ambient; flat nearly even, a touch lighter facing the key light\nvec3 drawnLight(int look, vec3 p, vec3 n, vec3 lit, vec3 col, float bands) {\n  if (look == 2) {\n    vec3 lk;\n    lightReach(0, p, n, lit, lk);\n    return col * (0.82 + 0.18 * max(dot(n, lk), 0.0));\n  }\n  vec3 drawn = col * uAmbient * 0.9;\n  for (int j = ZERO; j <= uMoreLights; j++) {\n    vec3 lj;\n    float pw = max(lightPower(j), 1e-4);\n    float k = lightReach(j, p, n, lit, lj) / pw;\n    float stepped = floor(max(dot(n, lj), 0.0) * min(k, 1.0) * bands + 0.5) / bands;\n    drawn += col * (j == 0 ? vec3(1.0) : lightColour(j)) * pw * 0.75 * stepped;\n  }\n  return drawn;\n}\n\nvoid main() {\n  vec2 frag = vUv * uRes;\n  seed = (uint(frag.x) * 1973u + uint(frag.y) * 9277u + uint(uFrame) * 26699u) | 1u;\n  vec3 ro, rd;\n  rayFor(frag + vec2(rnd(), rnd()) - 0.5, ro, rd);\n  // a real lens: the ray starts somewhere on its opening and goes through the point in focus\n  if (uAperture > 0.0) {\n    vec3 fwd = -uCamRot[2];\n    vec3 focus = ro + rd * (uFocusDist / max(dot(rd, fwd), 1e-3));\n    float r = uAperture * sqrt(rnd()), a = 6.2831853 * rnd();\n    ro += (uCamRot[0] * cos(a) + uCamRot[1] * sin(a)) * r;\n    rd = normalize(focus - ro);\n  }\n  vec3 radiance = vec3(0.0), through = vec3(1.0);\n  float alpha = 1.0;\n  bool inside = false;\n  for (int b = ZERO; b < 6; b++) {\n    vec3 col; vec4 mat;\n    float tGround = uGround == 1 && rd.y < -1e-4 && !inside ? -ro.y / rd.y : 1e9;\n    float t = traceRay(ro, rd, inside, 80.0, col, mat);\n    // an imported model in front of the shapes and the floor wins\n    int tri;\n    vec2 bc;\n    float tMesh = meshHit(ro, rd, min(t > 0.0 ? t : 1e9, tGround), tri, bc);\n    bool onMesh = tMesh < 1e29;\n    bool surf = onMesh || (t > 0.0 && t < tGround);\n    if (!surf && tGround > 1e8) {\n      // a clear background: the first ray that meets nothing leaves the pixel empty; bounced rays still see the studio's light\n      if (uKeepClear == 1 && b == 0) { alpha = 0.0; break; }\n      radiance += through * (b == 0 ? (uHasEnv == 1 && uEnvSet.z > 0.5 ? envAt(rd) : uStudio) : sky(rd));\n      break;\n    }\n    vec3 p = ro + rd * (onMesh ? tMesh : surf ? t : tGround);\n    vec3 n = vec3(0.0, 1.0, 0.0);\n    vec3 glowMesh = vec3(0.0);\n    bool backMesh = false;\n    if (onMesh) meshSurface(tri, bc, rd, n, col, mat, glowMesh, backMesh);\n    else if (surf) n = normalAt(p, t);\n    vec3 lit = lightsAt(p, n, !surf);\n    // imported models' shadows, from every sun-like light (the placed ones test their own)\n    if (uMeshTris > 0) {\n      vec3 vis = vec3(1.0);\n      for (int j = ZERO; j <= uMoreLights; j++)\n        if (litBy(lit, j) > 0.0 && (j == 0 || uLightKind[max(j - 1, 0)].x < 0.5)) {\n          float v = meshVisible(p + n * 0.003, lightDir(j));\n          if (j == 0) vis.x = v; else if (j == 1) vis.y = v; else vis.z = v;\n        }\n      lit *= vis;\n    }\n    if (!surf) {\n      // the studio floor: the background's colour where light reaches it, darker in shadows and under things nearby\n      float reach = 0.0, all = 0.0;\n      for (int j = ZERO; j <= uMoreLights; j++) {\n        vec3 lj;\n        float k = lightReach(j, p, n, lit, lj);\n        reach += min(k, lightPower(j));\n        all += max(lightPower(j), 1e-4);\n      }\n      vec3 c2; vec4 m2;\n      vec3 up = cosineDir(n);\n      float near = traceRay(p + vec3(0.0, 0.002, 0.0), up, false, 80.0, c2, m2);\n      int tr2;\n      vec2 b3;\n      float nearMesh = meshHit(p + vec3(0.0, 0.002, 0.0), up, 1.5, tr2, b3);\n      if (nearMesh < 1e29) near = near > 0.0 ? min(near, nearMesh) : nearMesh;\n      float occluded = near > 0.0 && near < 1.5 ? 1.0 - near / 1.5 : 0.0;\n      float floorLight = (1.0 - (1.0 - reach / all) * uGroundShadow) * (1.0 - 0.6 * occluded);\n      // a clear background: the floor catches only the shadow, as a darkness over whatever the picture is put on\n      if (uKeepClear == 1 && b == 0) { alpha = 1.0 - floorLight; break; }\n      radiance += through * uStudio * floorLight;\n      break;\n    }\n    // a model material's own look: unlit as its colours are; toon and flat painted with the light that reaches them (shadows included) and\n    // nothing traced on from them, so they stay drawn among real light; clay matte grey\n    // the look here: a model material's own, else the design's (toon and flat painted, clay grey); 4 is a material drawn unlit\n    int look = onMesh && gMeshLook >= 0 ? gMeshLook : uLook >= 1 && uLook <= 3 ? uLook : 0;\n    if (look == 4) {\n      radiance += through * col;\n      break;\n    }\n    if (look == 3) {\n      col = vec3(0.86, 0.84, 0.82);\n      // a material's own clay is matte; the design's keeps each surface's finish, as the quick drawing does\n      if (onMesh && gMeshLook == 3) mat = vec4(8.0, 0.0, 0.0, 0.0);\n      glowMesh = vec3(0.0);\n    } else if (!onMesh) col = labelled(p, n, col);\n    if (look == 1 || look == 2) {\n      // toon and flat are painted with the light that reaches them (shadows included) and nothing is traced on from them, so they stay\n      // drawn among real light; glass is a tinted, darker body, as the quick drawing's\n      vec3 base = col * (1.0 - 0.75 * (onMesh ? 0.0 : mat.w));\n      radiance += through * (drawnLight(look, p, n, lit, base, onMesh ? gMeshBands : uBands) + (onMesh ? glowMesh : col * mat.z * 2.2));\n      break;\n    }\n    if (mat.z > 0.0) radiance += through * col * mat.z * 2.2;\n    radiance += through * glowMesh;\n    if (mat.w > 0.5) {\n      // glass: reflected or let through, by Fresnel; it tints the light that passes. An imported model's normal already faces the ray, and\n      // whether it is entering comes from which side was met\n      bool within = onMesh ? backMesh : inside;\n      vec3 nn = onMesh ? n : inside ? -n : n;\n      float cosi = clamp(dot(-rd, nn), 0.0, 1.0);\n      float f = 0.04 + 0.96 * pow(1.0 - cosi, 5.0);\n      vec3 refr = refract(rd, nn, within ? 1.5 : 1.0 / 1.5);\n      if (dot(refr, refr) < 1e-6 || rnd() < f) {\n        rd = reflect(rd, nn);\n        ro = p + nn * 0.002;\n      } else {\n        rd = refr;\n        ro = p - nn * 0.002;\n        if (!onMesh) inside = !inside;\n        through *= mix(vec3(1.0), col, 0.35);\n      }\n      continue;\n    }\n    // each light's direct light, with its soft shadow; then the next bounce: a reflection (metal, glossy) or light scattered off a matte surface\n    float metal = mat.y;\n    float rough = clamp(1.0 - sqrt(mat.x / 220.0), 0.04, 1.0);\n    vec3 specCol = mix(vec3(1.0), col, metal);\n    float velvet = clamp((6.0 - mat.x) / 2.0, 0.0, 1.0);\n    float edge = 1.0 - max(dot(n, -rd), 0.0);\n    for (int j = ZERO; j <= uMoreLights; j++) {\n      vec3 lj;\n      float k = lightReach(j, p, n, lit, lj);\n      if (k <= 0.0) continue;\n      float d = max(dot(n, lj), 0.0);\n      float spec = (1.0 - velvet) * pow(max(dot(n, normalize(lj - rd)), 0.0), mat.x) * (mat.x + 8.0) / 64.0;\n      radiance += through * lightColour(j) * k * (d * (col * (1.0 - metal) + specCol * spec * mix(0.15, 1.0, metal)) + velvet * col * edge * edge * 0.6);\n    }\n    float fres = pow(1.0 - max(dot(n, -rd), 0.0), 5.0);\n    float pSpec = mix((0.04 + 0.6 * fres) * (mat.x > 60.0 ? 1.0 : 0.4), 1.0, metal);\n    if (rnd() < pSpec) {\n      rd = normalize(mix(reflect(rd, n), cosineDir(n), rough * rough));\n      through *= specCol;\n    } else {\n      rd = cosineDir(n);\n      through *= col * (1.0 - metal) * 0.85;\n    }\n    ro = p + n * 0.003;\n    if (b > 1) {\n      float q = clamp(max(through.r, max(through.g, through.b)), 0.05, 1.0);\n      if (rnd() > q) break;\n      through /= q;\n    }\n  }\n  // one very bright path (a firefly) would take hundreds of passes to fade back out of the average: capped instead\n  radiance = min(radiance, vec3(12.0));\n  vec4 prev = texture(uAccum, vUv);\n  float share = 1.0 / float(uFrame + 1);\n  fragColor = vec4(mix(prev.rgb, radiance, share), mix(prev.a, alpha, share));\n}\n", Ar = br + Or + "\nvoid main() {\n  vec2 frag = vUv * uRes;\n  seed = 1u;\n  vec3 ro, rd;\n  rayFor(frag, ro, rd);\n  vec3 col; vec4 mat;\n  float tGround = uGround == 1 && rd.y < -1e-4 ? -ro.y / rd.y : 1e9;\n  float t = traceRay(ro, rd, false, 80.0, col, mat);\n  int tri;\n  vec2 bc;\n  float tMesh = meshHit(ro, rd, min(t > 0.0 ? t : 1e9, tGround), tri, bc);\n  vec3 n = vec3(0.0);\n  float depth = 1e4;\n  if (tMesh < 1e29) {\n    vec3 glow; bool back;\n    meshSurface(tri, bc, rd, n, col, mat, glow, back);\n    depth = tMesh;\n  } else if (t > 0.0 && t < tGround) {\n    n = normalAt(ro + rd * t, t);\n    depth = t;\n  } else if (tGround < 1e8) {\n    n = vec3(0.0, 1.0, 0.0);\n    depth = tGround;\n  }\n  fragColor = vec4(n, depth);\n}\n", jr = "\nprecision highp float;\nin vec2 vUv;\nuniform sampler2D uColor;\nuniform sampler2D uGuide;\nuniform float uStep;\nout vec4 fragColor;\nvoid main() {\n  vec2 px = 1.0 / vec2(textureSize(uColor, 0));\n  vec4 g0 = texture(uGuide, vUv);\n  vec4 c0 = texture(uColor, vUv);\n  float l0 = dot(c0.rgb, vec3(0.2126, 0.7152, 0.0722));\n  float k[3] = float[3](0.375, 0.25, 0.0625);\n  vec4 sum = vec4(0.0);\n  float wsum = 0.0;\n  for (int y = -2; y <= 2; y++)\n    for (int x = -2; x <= 2; x++) {\n      vec2 uv = vUv + vec2(float(x), float(y)) * uStep * px;\n      vec4 c = texture(uColor, uv);\n      vec4 g = texture(uGuide, uv);\n      float w = k[abs(x)] * k[abs(y)];\n      w *= exp(-max(0.0, 1.0 - dot(g.xyz, g0.xyz)) * 32.0);\n      w *= exp(-abs(g.w - g0.w) / (0.02 * g0.w + 1e-3));\n      float l = dot(c.rgb, vec3(0.2126, 0.7152, 0.0722));\n      w *= exp(-abs(l - l0) / (0.35 * max(l0, l) + 0.05));\n      sum += c * w;\n      wsum += w;\n    }\n  // the clear parts' alpha is smoothed with the same weights, so the shadow's grain goes the same way the colours' does\n  fragColor = sum / max(wsum, 1e-6);\n}\n", Mr = "\nprecision highp float;\nin vec2 vUv;\nuniform sampler2D uAccum;\nout vec4 fragColor;\nvoid main() {\n  vec4 a = texture(uAccum, vUv);\n  vec3 c = a.a > 0.001 ? a.rgb / a.a : vec3(0.0);\n  c = c / (1.0 + max(c - 1.0, 0.0) * 0.5);\n  fragColor = vec4(pow(max(c, 0.0), vec3(1.0 / 2.2)), a.a);\n}\n", Nr = {
	box: 0,
	sphere: 1,
	cylinder: 2,
	cone: 3,
	torus: 4,
	capsule: 5,
	pyramid: 6,
	extrude: 7,
	text: 7,
	revolve: 8
}, Pr = {
	matte: [8, 0],
	satin: [32, 0],
	glossy: [140, 0],
	metal: [64, 1],
	glass: [220, 0],
	glow: [8, 0],
	velvet: [4, 0],
	coat: [400, 0]
}, Fr = {
	soft: 0,
	toon: 1,
	flat: 2,
	clay: 3,
	pixel: 1
}, Ir = {
	add: 0,
	subtract: 1,
	intersect: 2
}, Lr = (e) => new x(...ut(e));
function Rr(e) {
	let t = M.degToRad(e.yaw), n = M.degToRad(e.pitch), r = new x(...e.target), i = new x(Math.sin(t) * Math.cos(n), Math.sin(n), Math.cos(t) * Math.cos(n)).multiplyScalar(e.distance);
	return {
		position: r.clone().add(i),
		target: r
	};
}
var X = 512, zr = class {
	texture;
	held = [];
	constructor() {
		this.texture = new Be(new Uint8Array(X * X * 4 * 4), X, X, 4), this.texture.minFilter = this.texture.magFilter = Ee, this.texture.needsUpdate = !0;
	}
	put(e, t) {
		let n = xt(t);
		if (!n) return 1;
		if (this.held[e] !== t) {
			let r = this.texture.image.data, i = e * X * X * 4;
			for (let e = 0; e < X; e++) for (let t = 0; t < X; t++) {
				let a = Math.min(n.width - 1, Math.floor(t / X * n.width)), o = Math.min(n.height - 1, Math.floor(e / X * n.height));
				r.set(n.data.subarray((o * n.width + a) * 4, (o * n.width + a) * 4 + 4), i + (e * X + t) * 4);
			}
			this.held[e] = t, this.texture.needsUpdate = !0;
		}
		return n.width / n.height;
	}
	dispose() {
		this.texture.dispose();
	}
}, Br = /* @__PURE__ */ new WeakMap(), Vr = class {
	texture;
	grids = [];
	constructor() {
		let e = (/* @__PURE__ */ new Uint16Array(1048576)).fill(C.toHalfFloat(24));
		this.texture = new Be(e, 256, 256, 16), this.texture.format = ce, this.texture.type = ae, this.texture.minFilter = this.texture.magFilter = Ee, this.texture.unpackAlignment = 1, this.texture.needsUpdate = !0;
	}
	put(e, t) {
		let n = Ct(yt(t), ...Dt(t));
		if (this.grids[e] !== n.grid) {
			this.grids[e] = n.grid;
			let t = this.texture.image.data, r = e * 256 * 256;
			for (let e = 0; e < n.grid.length; e++) t[r + e] = C.toHalfFloat(n.grid[e]);
			this.texture.addLayerUpdate(e), this.texture.needsUpdate = !0;
		}
		return {
			half: n.half,
			texel: n.texel
		};
	}
	dispose() {
		this.texture.dispose();
	}
}, Z = new N(new Uint8Array([
	255,
	255,
	255,
	255
]), 1, 1);
Z.needsUpdate = !0;
var Hr = new N(/* @__PURE__ */ new Float32Array(4), 1, 1, Re, v);
Hr.needsUpdate = !0;
var Ur = new b(/* @__PURE__ */ new Uint16Array(1), 1, 1, 1);
Ur.format = ce, Ur.type = ae, Ur.needsUpdate = !0;
function Wr(e, t, n = 1) {
	let { position: r, target: i } = Rr(e.camera), a = Math.tan(M.degToRad(e.camera.fov / 2)) * n, o;
	if (e.camera.projection === "orthographic") {
		let n = e.camera.distance * a;
		o = new y(-n * t, n * t, n, -n, .05, 500);
	} else o = new _e(M.radToDeg(2 * Math.atan(a)), t, .05, 500);
	return o.position.copy(r), o.up.set(0, 1, 0), o.lookAt(i), o.updateMatrixWorld(), o.updateProjectionMatrix(), o.layers.enable(2), o;
}
var Q = {
	kind: 0,
	f: 1,
	rot: 2,
	pos: 5,
	half: 6,
	p: 7,
	repA: 8,
	repB: 9,
	col: 10,
	mat: 11,
	extra: 12
}, Gr = 13, Kr = class extends N {
	data = /* @__PURE__ */ new Float32Array(13312);
	constructor() {
		super(null, Gr, 256, Re, v), this.image.data = this.data, this.minFilter = this.magFilter = me, this.generateMipmaps = !1, this.needsUpdate = !0;
	}
	put(e, t, n, r = 0, i = 0, a = 0) {
		let o = (e * Gr + t) * 4;
		this.data[o] = n, this.data[o + 1] = r, this.data[o + 2] = i, this.data[o + 3] = a;
	}
	at(e, t, n) {
		return this.data[(e * Gr + t) * 4 + n];
	}
	turn(e, t) {
		this.put(e, Q.rot, t[0], t[1], t[2]), this.put(e, Q.rot + 1, t[3], t[4], t[5]), this.put(e, Q.rot + 2, t[6], t[7], t[8]);
	}
};
function qr(e) {
	return {
		uCount: { value: 0 },
		uFields: { value: e.texture },
		uShapes: { value: new Kr() },
		uRes: { value: new j(1, 1) },
		uTileOffset: { value: new j(0, 0) },
		uTileSize: { value: new j(1, 1) },
		uCamPos: { value: new x() },
		uCamRot: { value: new S() },
		uTanHalf: { value: .3 },
		uOrtho: { value: 0 },
		uOrthoHalf: { value: 1 },
		uLightDir: { value: new x(.5, .8, .5) },
		uLightCol: { value: new x(1, 1, 1) },
		uIntensity: { value: 1.4 },
		uAmbient: { value: .35 },
		uShadows: { value: 1 },
		uMoreLights: { value: 0 },
		uMoreDir: { value: [new z(), new z()] },
		uMoreCol: { value: [new z(), new z()] },
		uLook: { value: 0 },
		uOutline: { value: 0 },
		uOutlineCol: { value: new x() },
		uBands: { value: 3 },
		uTransparent: { value: 1 },
		uBg: { value: new x(1, 1, 1) },
		uGround: { value: 1 },
		uGroundShadow: { value: .35 },
		uSamples: { value: 1 },
		uGrid: { value: 0 },
		uViewProj: { value: new B() },
		uMeshShadow: { value: Z },
		uLightViewProj: { value: new B() },
		uMeshShadowOn: { value: 0 },
		uShadowBias: { value: .0015 },
		uLabelCount: { value: 0 },
		uLabelShape: { value: [
			0,
			0,
			0,
			0
		] },
		uLabelA: { value: Array.from({ length: 4 }, () => new z()) },
		uLabelB: { value: Array.from({ length: 4 }, () => new z()) },
		uLabels: { value: Jr(e).texture },
		uVol: { value: Ur },
		uVolMin: { value: new x() },
		uVolSize: { value: new x(1, 1, 1) },
		uVolSafe: { value: 0 },
		uVolOn: { value: 0 },
		uTiles: { value: Hr },
		uTileList: { value: Hr },
		uTilesOn: { value: 0 },
		uTilePx: { value: 32 }
	};
}
function Jr(e) {
	let t = Br.get(e);
	return t || Br.set(e, t = new zr()), t;
}
function Yr(e) {
	return Math.hypot(...e.size) / 2 * 1.05 + e.blend * .6 + (e.form?.noise ?? 0) + Math.max(0, ...ft(e).map((t) => Math.hypot(t[0] - e.position[0], t[1] - e.position[1], t[2] - e.position[2])));
}
function Xr(e) {
	let t = [
		Infinity,
		Infinity,
		Infinity
	], n = [
		-Infinity,
		-Infinity,
		-Infinity
	];
	for (let r of e) {
		if (r.op !== "shape" || r.shape.kind === "mesh" || r.shape.kind === "group") continue;
		let e = r.shape, i = Math.hypot(...e.size) / 2 * 1.05 + e.blend * .6 + (e.form?.noise ?? 0);
		for (let r of ft(e)) for (let e = 0; e < 3; e++) t[e] = Math.min(t[e], r[e] - i), n[e] = Math.max(n[e], r[e] + i);
	}
	if (t[0] === Infinity) return null;
	let r = t.map((e, t) => (e + n[t]) / 2);
	return [
		r[0],
		r[1],
		r[2],
		Math.hypot(n[0] - t[0], n[1] - t[1], n[2] - t[2]) / 2
	];
}
function Zr(e, t, n, r, i, a = 1) {
	let o = ct(n).slice(0, 256);
	e.uCount.value = o.length;
	let s = e.uShapes.value, c = Jr(t), l = 0;
	o.forEach((t, n) => {
		if (t.op !== "shape" || !t.shape.label || t.shape.kind === "mesh" || l >= 4) return;
		let r = t.shape.label, [i, a, o, s] = Et(t.shape, r, c.put(l, r.picture));
		e.uLabelShape.value[l] = n, e.uLabelA.value[l].set(Tt[r.side], i, a, t.shape.size[0] / 2), e.uLabelB.value[l].set(o, s, 0, 0), l++;
	}), e.uLabelCount.value = l;
	let u = 0;
	o.forEach((e, n) => {
		if (e.op !== "shape") {
			s.put(n, Q.kind, e.op === "begin" ? 20 : 21);
			let t = e.op === "begin" ? o.findIndex((e, t) => t > n && e.op === "end") : -1, r = t > n ? Xr(o.slice(n + 1, t)) : null;
			s.put(n, Q.p, t > n ? t : 0, 0, e.group.blend * .6, Ir[e.group.combine]), e.op === "begin" && s.put(n, Q.pos, r?.[0] ?? 0, r?.[1] ?? 0, r?.[2] ?? 0, r?.[3] ?? -1), s.put(n, Q.repA, 0, 1, 1, 1), s.put(n, Q.repB, 1, 1, 1, 0);
			return;
		}
		let r = e.shape;
		if (r.kind === "group" || r.kind === "mesh") return;
		s.put(n, Q.kind, Nr[r.kind]);
		let [i, a, c, l] = st(r);
		if (r.outline && u < 16) {
			let e = t.put(u, r);
			s.put(n, Q.f, u++, e.half, e.texel, i);
		} else s.put(n, Q.f, 0, 0, 0, i);
		let d = mt(r);
		s.put(n, Q.repA, ...d.a), s.put(n, Q.repB, ...d.b), s.turn(n, gt(r.rotation));
		let [f, p] = rt[r.finish];
		s.put(n, Q.pos, ...r.position, f), s.put(n, Q.half, r.size[0] / 2, r.size[1] / 2, r.size[2] / 2, p);
		let m = r.kind === "revolve" ? (r.revolve?.sweep ?? 360) * Math.PI / 180 : r.thickness;
		s.put(n, Q.p, r.round * Math.min(...r.size), m, r.blend * .6, Ir[r.combine]);
		let h = Lr(r.color);
		s.put(n, Q.col, h.x, h.y, h.z, l), s.put(n, Q.mat, ...Pr[r.finish], a, c), s.put(n, Q.extra, r.form?.noise ?? 0, r.form?.noiseScale ?? 8, Yr(r), 0);
	}), s.needsUpdate = !0, e.uRes.value.set(r, i), e.uTileOffset.value.set(0, 0), e.uTileSize.value.set(r, i);
	let { position: d, target: f } = Rr(n.camera), p = new B().lookAt(d, f, new x(0, 1, 0));
	e.uCamPos.value.copy(d), e.uCamRot.value.setFromMatrix4(p);
	let m = Math.tan(M.degToRad(n.camera.fov / 2)) * a;
	e.uTanHalf.value = m, e.uOrtho.value = +(n.camera.projection === "orthographic"), e.uOrthoHalf.value = n.camera.distance * m;
	let [h, ...g] = At(n);
	e.uLightDir.value.set(...h.dir), e.uLightCol.value.copy(Lr(h.color)), e.uIntensity.value = h.intensity, e.uAmbient.value = n.light.ambient, e.uShadows.value = +!!h.shadows, e.uMoreLights.value = g.length, g.forEach((t, n) => {
		e.uMoreDir.value[n].set(...t.dir, t.intensity);
		let r = Lr(t.color);
		e.uMoreCol.value[n].set(r.x, r.y, r.z, +!!t.shadows);
	}), e.uLook.value = Fr[n.style.look], e.uOutline.value = n.style.outline, e.uOutlineCol.value.copy(Lr(n.style.outlineColor)), e.uBands.value = n.style.bands, e.uTransparent.value = +!!n.background.transparent, e.uBg.value.copy(Lr(n.background.color)), e.uGround.value = +!!n.ground.on, e.uGroundShadow.value = n.ground.shadow;
	let _ = Wr(n, r / i, a);
	return e.uViewProj.value.multiplyMatrices(_.projectionMatrix, _.matrixWorldInverse), _;
}
function Qr(e) {
	return new I({
		glslVersion: ve,
		vertexShader: yr,
		fragmentShader: xr,
		uniforms: e,
		depthTest: !0,
		depthFunc: 1,
		depthWrite: !0,
		blending: 0
	});
}
var $r = class {
	target = null;
	material = new I({
		glslVersion: ve,
		vertexShader: yr,
		fragmentShader: Dr,
		uniforms: {
			uColor: { value: null },
			uDepth: { value: null },
			uSize: { value: new j(1, 1) },
			uNear: { value: kt },
			uFar: { value: 500 },
			uOrthoDepth: { value: 0 },
			uFocusAt: { value: 1 },
			uRadius: { value: 0 }
		},
		depthTest: !1,
		depthWrite: !1,
		blending: 0
	});
	scene = new O();
	camera = new y(-1, 1, 1, -1, 0, 1);
	constructor() {
		this.scene.add(new P(new F(2, 2), this.material));
	}
	begin(e, t, n, r) {
		let i = Mt(t, r);
		if (!i) return !1;
		(!this.target || this.target.width !== n || this.target.height !== r) && (this.target?.dispose(), this.target = new de(n, r, { depthTexture: new ke(n, r) }));
		let a = this.material.uniforms;
		return a.uColor.value = this.target.texture, a.uDepth.value = this.target.depthTexture, a.uSize.value.set(n, r), a.uOrthoDepth.value = +(t.camera.projection === "orthographic"), a.uFocusAt.value = i.at, a.uRadius.value = i.radius, e.setRenderTarget(this.target), e.clear(), !0;
	}
	finish(e, t, n) {
		e.setRenderTarget(null), e.setScissorTest(!1), e.setViewport(0, 0, t, n), e.render(this.scene, this.camera);
	}
	dispose() {
		this.target?.dispose(), this.material.dispose();
	}
}, ei = class e {
	uniforms;
	static PX = 32;
	static ROW = 4096;
	static ROWS = 64;
	header = null;
	headerData = /* @__PURE__ */ new Float32Array();
	tilesX = 0;
	tilesY = 0;
	list;
	listData = new Float32Array(e.ROW * e.ROWS);
	counts = /* @__PURE__ */ new Int32Array();
	starts = /* @__PURE__ */ new Int32Array();
	entries = 0;
	constructor(t) {
		this.uniforms = t, this.list = new N(this.listData, e.ROW, e.ROWS, ce, v), this.list.minFilter = this.list.magFilter = me, this.list.generateMipmaps = !1;
	}
	static wanted() {
		try {
			return localStorage.getItem("gleamshelf:3d-tiles") !== "off";
		} catch {
			return !0;
		}
	}
	update(t, n) {
		let r = this.uniforms, i = r.uCount.value;
		if (this.entries = 0, !e.wanted() || !i) {
			r.uTilesOn.value = 0;
			return;
		}
		let a = e.PX, o = Math.max(1, Math.ceil(t / a)), s = Math.max(1, Math.ceil(n / a));
		(!this.header || o !== this.tilesX || s !== this.tilesY) && (this.header?.dispose(), this.headerData = new Float32Array(o * s * 4), this.header = new N(this.headerData, o, s, Re, v), this.header.minFilter = this.header.magFilter = me, this.header.generateMipmaps = !1, this.tilesX = o, this.tilesY = s, this.counts = new Int32Array(o * s), this.starts = new Int32Array(o * s));
		let c = r.uShapes.value, l = r.uViewProj.value, u = r.uCamRot.value.elements, d = [
			new x(u[0], u[1], u[2]),
			new x(u[3], u[4], u[5]),
			new x(u[6], u[7], u[8])
		], f = r.uOutline.value * n / 1e3 + 2, p = new Int32Array(i * 4).fill(-1), m = new z(), h = new x(), g = (e) => p.set([
			0,
			0,
			o - 1,
			s - 1
		], e * 4);
		for (let e = 0; e < i; e++) {
			let r = c.at(e, Q.kind, 0);
			if (r === 21) {
				p[e * 4] < 0 && p[e * 4 + 2] < 0 && g(e);
				continue;
			}
			let u = c.at(e, Q.p, 3), _ = r === 20 ? Math.round(c.at(e, Q.p, 0)) : -1, v = (r === 20 ? c.at(e, Q.pos, 3) : c.at(e, Q.extra, 2)) + c.at(e, Q.p, 2) + .05, y = Infinity, b = Infinity, x = -Infinity, S = -Infinity, C = u === 2 || v <= .05;
			for (let r = 0; r < 8 && !C; r++) {
				h.set(c.at(e, Q.pos, 0), c.at(e, Q.pos, 1), c.at(e, Q.pos, 2)), h.addScaledVector(d[0], r & 1 ? v : -v), h.addScaledVector(d[1], r & 2 ? v : -v), h.addScaledVector(d[2], r & 4 ? v : -v), m.set(h.x, h.y, h.z, 1).applyMatrix4(l), m.w < 1e-4 && (C = !0);
				let i = m.x / m.w * .5 + .5, a = m.y / m.w * .5 + .5;
				y = Math.min(y, i * t), x = Math.max(x, i * t), b = Math.min(b, a * n), S = Math.max(S, a * n);
			}
			if (C) g(e);
			else {
				let t = Math.max(0, Math.floor((y - f) / a)), n = Math.min(o - 1, Math.floor((x + f) / a)), r = Math.max(0, Math.floor((b - f) / a)), i = Math.min(s - 1, Math.floor((S + f) / a));
				p.set([
					t,
					r,
					n,
					i
				], e * 4);
			}
			_ > e && _ < i && p.set(p.subarray(e * 4, e * 4 + 4), _ * 4);
		}
		let _ = this.counts.fill(0), y = 0;
		for (let e = 0; e < i; e++) {
			let [t, n, r, i] = [
				p[e * 4],
				p[e * 4 + 1],
				p[e * 4 + 2],
				p[e * 4 + 3]
			];
			for (let e = n; e <= i; e++) for (let n = t; n <= r; n++) _[e * o + n]++;
			r >= t && i >= n && (y += (r - t + 1) * (i - n + 1));
		}
		if (y > e.ROW * e.ROWS) {
			r.uTilesOn.value = 0;
			return;
		}
		let b = this.starts, S = 0;
		for (let e = 0; e < _.length; e++) b[e] = S, this.headerData[e * 4] = S, this.headerData[e * 4 + 1] = _[e], S += _[e];
		for (let e = 0; e < i; e++) {
			let [t, n, r, i] = [
				p[e * 4],
				p[e * 4 + 1],
				p[e * 4 + 2],
				p[e * 4 + 3]
			];
			for (let a = n; a <= i; a++) for (let n = t; n <= r; n++) this.listData[b[a * o + n]++] = e;
		}
		this.entries = y, this.header.needsUpdate = !0, this.list.needsUpdate = !0, r.uTiles.value = this.header, r.uTileList.value = this.list, r.uTilePx.value = a, r.uTilesOn.value = 1;
	}
	dispose() {
		this.header?.dispose(), this.list.dispose();
	}
}, ti = class e {
	uniforms;
	static RES = 64;
	static QUICK = 32;
	static wanted() {
		try {
			return localStorage.getItem("gleamshelf:3d-field") !== "off";
		} catch {
			return !0;
		}
	}
	target = null;
	scene = new O();
	camera = new y(-1, 1, 1, -1, 0, 1);
	material;
	bakedShapes = null;
	bakedQuick = !1;
	dims = null;
	constructor(e) {
		this.uniforms = e, this.material = new I({
			glslVersion: ve,
			vertexShader: yr,
			fragmentShader: Sr,
			uniforms: {
				...e,
				uVol: { value: Ur },
				uVolOn: { value: 0 },
				uVolSlice: { value: 0 }
			},
			depthTest: !1,
			depthWrite: !1,
			blending: 0
		}), this.scene.add(new P(new F(2, 2), this.material));
	}
	update(t, n, r) {
		if (!e.wanted()) {
			this.uniforms.uVolOn.value = 0, this.bakedShapes = null;
			return;
		}
		if (this.bakedShapes === n.shapes && (this.bakedQuick === r || !this.bakedQuick)) return;
		this.bakedShapes = n.shapes, this.bakedQuick = r;
		let i = this.uniforms, a = [
			Infinity,
			Infinity,
			Infinity
		], o = [
			-Infinity,
			-Infinity,
			-Infinity
		], s = i.uShapes.value;
		for (let e = 0; e < i.uCount.value; e++) {
			let t = s.at(e, Q.extra, 2);
			if (!(s.at(e, Q.kind, 0) >= 20 || t <= 0)) for (let [n, r] of [
				s.at(e, Q.pos, 0),
				s.at(e, Q.pos, 1),
				s.at(e, Q.pos, 2)
			].entries()) a[n] = Math.min(a[n], r - t), o[n] = Math.max(o[n], r + t);
		}
		if (a[0] === Infinity) {
			i.uVolOn.value = 0, this.dims = null;
			return;
		}
		let c = r ? e.QUICK : e.RES, l = Math.max(o[0] - a[0], o[1] - a[1], o[2] - a[2], .001) / c, u = [
			0,
			1,
			2
		].map((e) => Math.min(128, Math.max(2, Math.ceil((o[e] - a[e] + 3 * l) / l)))), d = [
			0,
			1,
			2
		].map((e) => (a[e] + o[e]) / 2 - u[e] * l / 2);
		(!this.target || this.dims?.some((e, t) => e !== u[t])) && (this.target?.dispose(), this.target = new T(u[0], u[1], u[2], {
			format: ce,
			type: ae,
			minFilter: Ee,
			magFilter: Ee,
			depthBuffer: !1,
			stencilBuffer: !1,
			generateMipmaps: !1
		})), this.dims = u, i.uVolMin.value.set(d[0], d[1], d[2]), i.uVolSize.value.set(u[0] * l, u[1] * l, u[2] * l);
		let f = t.getRenderTarget(), p = t.getScissorTest(), m = t.autoClear;
		t.setScissorTest(!1), t.autoClear = !1;
		let h = this.material.uniforms.uVolSlice;
		for (let e = 0; e < u[2]; e++) h.value = (e + .5) / u[2], t.setRenderTarget(this.target, e), t.render(this.scene, this.camera);
		t.setRenderTarget(f), t.setScissorTest(p), t.autoClear = m, i.uVol.value = this.target.texture, i.uVolSafe.value = .87 * l, i.uVolOn.value = 1;
	}
	dispose() {
		this.target?.dispose(), this.material.dispose();
	}
};
function ni(e, t) {
	let n = /* @__PURE__ */ new Map(), r = (t) => `${Math.round(e[t * 3] * 1e4)},${Math.round(e[t * 3 + 1] * 1e4)},${Math.round(e[t * 3 + 2] * 1e4)}`, i = e.length / 3;
	for (let e = 0; e < i; e++) {
		let i = r(e), a = n.get(i) ?? [
			0,
			0,
			0
		];
		a[0] += t[e * 3], a[1] += t[e * 3 + 1], a[2] += t[e * 3 + 2], n.set(i, a);
	}
	let a = new Float32Array(e.length);
	for (let e = 0; e < i; e++) {
		let t = n.get(r(e)), i = Math.hypot(...t) || 1;
		a.set([
			t[0] / i,
			t[1] / i,
			t[2] / i
		], e * 3);
	}
	return a;
}
var ri = class e {
	uniforms;
	onReady;
	upload;
	scene = new O();
	glass = new O();
	backdrop = null;
	built = /* @__PURE__ */ new Map();
	morphed = /* @__PURE__ */ new Map();
	ownPoints = /* @__PURE__ */ new Map();
	materials = /* @__PURE__ */ new Map();
	shadowTarget;
	depthMaterial = new w({ side: 2 });
	holedDepths = /* @__PURE__ */ new Map();
	holedDepth(e) {
		let t = this.holedDepths.get(e);
		return t || (t = new w({
			side: 2,
			map: e,
			alphaTest: .5
		}), this.holedDepths.set(e, t)), t;
	}
	lightCamera = new y(-1, 1, 1, -1, .01, 10);
	count = 0;
	textureBytes = 0;
	static TEXTURE_BUDGET = 32e7;
	static bytesOf = (e, t) => e * t * 4 * 1.34;
	capFor(t, n) {
		let r = 2048, i = Math.max(t, n), a = (r) => i <= r ? e.bytesOf(t, n) : e.bytesOf(t * r / i, n * r / i);
		for (; r > 256 && this.textureBytes + a(r) > e.TEXTURE_BUDGET;) r /= 2;
		return r;
	}
	constructor(e, t = () => {}, n) {
		this.uniforms = e, this.onReady = t, this.upload = n, this.shadowTarget = new de(2048, 2048, { depthTexture: new ke(2048, 2048) }), this.lightCamera.layers.set(1);
	}
	build(t, n) {
		let r = this.built.get(t);
		if (r && r.data === n) return r.ready;
		let i = tt(t, n), a = [], o = [], s = /* @__PURE__ */ new Map();
		i.parts.forEach((e, t) => {
			let n = `${e.material}:${+!!e.uvs}`, r = s.get(n);
			r === void 0 && (s.set(n, r = a.length), a.push({
				material: e.material,
				uvs: !!e.uvs,
				parts: [],
				vertices: 0
			}));
			let i = a[r];
			o.push({
				batch: r,
				offset: i.vertices
			}), i.parts.push(t), i.vertices += e.positions.length / 3;
		});
		let c = a.map((e) => {
			let t = new Float32Array(e.vertices * 3), n = new Float32Array(e.vertices * 3), r = new Float32Array(e.vertices * 3), a = new Float32Array(e.vertices * 3).fill(1), s = e.uvs ? new Float32Array(e.vertices * 2) : null, c = new Uint32Array(e.parts.reduce((e, t) => e + i.parts[t].indices.length, 0)), l = 0;
			for (let u of e.parts) {
				let e = i.parts[u], d = o[u].offset;
				t.set(e.positions, d * 3), n.set(e.normals, d * 3), r.set(ni(e.positions, e.normals), d * 3), s && e.uvs && s.set(e.uvs, d * 2), e.colors && a.set(e.colors, d * 3);
				for (let t = 0; t < e.indices.length; t++) c[l + t] = e.indices[t] + d;
				l += e.indices.length;
			}
			let u = new we();
			return u.setAttribute("position", new ze(t, 3)), u.setAttribute("normal", new ze(n, 3)), s && u.setAttribute("uv", new ze(s, 2)), u.setAttribute("aColor", new ze(a, 3)), u.setIndex(new ze(c, 1)), u.setAttribute("aHull", new ze(r, 3)), u.computeBoundingBox(), u.computeBoundingSphere(), u;
		}), l = {
			data: n,
			ready: Promise.resolve(null)
		};
		return l.ready = Promise.all(i.textures.map(async (t) => {
			try {
				let n = {
					premultiplyAlpha: "none",
					colorSpaceConversion: "none"
				}, r = await createImageBitmap(new Blob([t.bytes], { type: t.mime }), n), i = this.capFor(r.width, r.height), a = Math.max(r.width, r.height);
				if (a > i) {
					let e = await createImageBitmap(r, {
						...n,
						resizeWidth: Math.max(1, Math.round(r.width * i / a)),
						resizeHeight: Math.max(1, Math.round(r.height * i / a)),
						resizeQuality: "high"
					});
					r.close(), r = e;
				}
				this.textureBytes += e.bytesOf(r.width, r.height);
				let o = new Ne(r);
				return o.flipY = !1, o.wrapS = o.wrapT = Ue, o.colorSpace = "", o.anisotropy = 4, o.needsUpdate = !0, o;
			} catch {
				return null;
			}
		})).then(async (e) => {
			if (this.upload) for (let t of e) t && await this.upload(t);
			return l.value = {
				asset: i,
				batches: a,
				geometries: c,
				place: o,
				textures: e
			}, this.onReady(), l.value;
		}), this.built.set(t, l), l.ready;
	}
	async ready(e) {
		await Promise.all(ot(e).map(({ shape: e, asset: t }) => this.build(e.asset, t.data)));
	}
	sync(e) {
		this.scene.clear(), this.glass.clear(), this.count = 0;
		let t = /* @__PURE__ */ new Set(), n = ot(e), r = /* @__PURE__ */ new Map();
		for (let { shape: e } of n) r.set(e.asset, (r.get(e.asset) ?? 0) + 1);
		let i = /* @__PURE__ */ new Set();
		for (let { shape: a, path: o, asset: s } of n) {
			this.build(a.asset, s.data);
			let n = this.built.get(a.asset)?.value;
			if (!n) continue;
			let { asset: c } = n, l = (a.morph && a.morph.amount > 0 ? `${a.morph.asset}|${Math.round(a.morph.amount * 200)}` : "") + (bt(a.rig) ? `|${JSON.stringify(a.rig.pose)}|${a.rig.root ?? ""}` : "") + (a.face ? `|${JSON.stringify(a.face)}` : ""), u = (r.get(a.asset) ?? 1) > 1, d = n.geometries;
			if (u) {
				i.add(a.id);
				let t = this.ownPoints.get(a.id);
				if ((!t || t.asset !== a.asset) && (t?.geometries.forEach((e) => e.dispose()), t = {
					asset: a.asset,
					key: "",
					geometries: n.geometries.map((e) => e.clone())
				}, this.ownPoints.set(a.id, t)), d = t.geometries, t.key !== l) {
					(it(e, a) ?? c).parts.forEach((e, t) => {
						let r = n.place[t], i = r && d[r.batch];
						i && (i.attributes.position.array.set(e.positions, r.offset * 3), i.attributes.normal.array.set(e.normals, r.offset * 3), i.attributes.position.needsUpdate = !0, i.attributes.normal.needsUpdate = !0);
					});
					for (let e of d) e.computeBoundingSphere();
					t.key = l;
				}
			} else if ((this.morphed.get(a.asset) ?? "") !== l) {
				(it(e, a) ?? c).parts.forEach((e, t) => {
					let r = n.place[t], i = r && n.geometries[r.batch];
					i && (i.attributes.position.array.set(e.positions, r.offset * 3), i.attributes.normal.array.set(e.normals, r.offset * 3), i.attributes.position.needsUpdate = !0, i.attributes.normal.needsUpdate = !0);
				});
				for (let e of n.geometries) e.computeBoundingSphere();
				this.morphed.set(a.asset, l);
			}
			let f = c.max.map((e, t) => Math.max(e - c.min[t], 1e-9)), p = c.min.map((e, t) => (e + c.max[t]) / 2), m = new B().compose(new x(...a.position), new k().setFromEuler(ii(a.rotation)), new x(...a.size.map((e, t) => e / f[t]))).multiply(new B().makeTranslation(-p[0], -p[1], -p[2])), h = new S().getNormalMatrix(m), g = a.ownColors !== !1;
			n.batches.forEach((r, i) => {
				let s = `${a.id}:${i}`;
				t.add(s);
				let l = this.materialPreview.get(a.asset)?.get(r.material) ?? c.materials[r.material], u = g && l.texture >= 0 ? n.textures[l.texture] : null, f = this.materials.get(s);
				if (!f) {
					let e = new I({
						glslVersion: ve,
						vertexShader: Cr,
						fragmentShader: wr,
						uniforms: {
							...this.uniforms,
							uNormalWorld: { value: new S() },
							uAlbedo: { value: new x() },
							uMap: { value: Z },
							uHasMap: { value: 0 },
							uFinish: { value: new j() },
							uCutout: { value: 0 },
							uUnlit: { value: 0 },
							uNormalMap: { value: Z },
							uHasNormal: { value: 0 },
							uNormalScale: { value: 1 },
							uRoughMap: { value: Z },
							uPbr: { value: 0 },
							uHasRough: { value: 0 },
							uRoughMetal: { value: new j(.6, 0) },
							uAoMap: { value: Z },
							uHasAo: { value: 0 },
							uAoStrength: { value: 1 },
							uEmissive: { value: new x() },
							uEmissiveMap: { value: Z },
							uHasEmissive: { value: 0 },
							uClearcoat: { value: 0 },
							uCoatRough: { value: 0 },
							uCoatMap: { value: Z },
							uHasCoatMap: { value: 0 },
							uCoatRoughMap: { value: Z },
							uHasCoatRoughMap: { value: 0 },
							uCoatNormalMap: { value: Z },
							uHasCoatNormal: { value: 0 },
							uCoatNormalScale: { value: 1 },
							uSheen: { value: new x() },
							uSheenRough: { value: 0 },
							uSheenMap: { value: Z },
							uHasSheenMap: { value: 0 },
							uSheenRoughMap: { value: Z },
							uHasSheenRoughMap: { value: 0 },
							uTransmission: { value: 0 },
							uTransmissionMap: { value: Z },
							uHasTransmissionMap: { value: 0 },
							uIor: { value: 1.5 },
							uBackdrop: { value: Z },
							uHasBackdrop: { value: 0 },
							uMatLook: { value: -1 },
							uMatBands: { value: 0 }
						},
						side: 2
					});
					f = {
						mesh: e,
						hull: new I({
							glslVersion: ve,
							vertexShader: Tr,
							fragmentShader: Er,
							uniforms: {
								uNormalWorld: e.uniforms.uNormalWorld,
								uOutline: this.uniforms.uOutline,
								uRes: this.uniforms.uRes,
								uOutlineCol: this.uniforms.uOutlineCol
							},
							side: 1
						})
					}, this.materials.set(s, f);
				}
				let p = f.mesh.uniforms, _ = g && l.unlit ? 0 : 2;
				f.mesh.side !== _ && (f.mesh.side = _, f.mesh.needsUpdate = !0), p.uNormalWorld.value.copy(h), p.uAlbedo.value.copy(g ? new x(...l.color) : Lr(a.color)), p.uMap.value = u ?? Z, p.uHasMap.value = u && r.uvs ? 1 : 0, p.uFinish.value.set(...g ? [6 + (1 - l.roughness) ** 2 * 134, l.metalness] : Pr[a.finish]), p.uCutout.value = g && l.cutout ? 1 : 0, p.uUnlit.value = g && l.unlit ? 1 : 0;
				let v = l.normalTexture >= 0 && r.uvs ? n.textures[l.normalTexture] : null;
				p.uNormalMap.value = v ?? Z, p.uHasNormal.value = +!!v, p.uNormalScale.value = l.normalScale;
				let y = g && l.roughnessTexture >= 0 && r.uvs ? n.textures[l.roughnessTexture] : null;
				p.uRoughMap.value = y ?? Z, p.uHasRough.value = +!!y, p.uPbr.value = +!!g, p.uRoughMetal.value.set(l.roughness, l.metalness);
				let b = l.occlusionTexture >= 0 && r.uvs ? n.textures[l.occlusionTexture] : null;
				p.uAoMap.value = b ?? Z, p.uHasAo.value = +!!b, p.uAoStrength.value = l.occlusionStrength, p.uEmissive.value.set(...g ? l.emissive : [
					0,
					0,
					0
				]);
				let C = g && l.emissiveTexture >= 0 && r.uvs ? n.textures[l.emissiveTexture] : null;
				p.uEmissiveMap.value = C ?? Z, p.uHasEmissive.value = +!!C;
				let w = (e) => g && e >= 0 && r.uvs ? n.textures[e] ?? null : null, T = (e, t, n) => {
					p[e].value = n ?? Z, p[t].value = +!!n;
				};
				p.uClearcoat.value = g ? l.clearcoat : 0, p.uCoatRough.value = l.clearcoatRoughness, T("uCoatMap", "uHasCoatMap", w(l.clearcoatTexture)), T("uCoatRoughMap", "uHasCoatRoughMap", w(l.clearcoatRoughnessTexture)), T("uCoatNormalMap", "uHasCoatNormal", w(l.clearcoatNormalTexture)), p.uCoatNormalScale.value = l.clearcoatNormalScale, p.uSheen.value.set(...g ? l.sheenColor : [
					0,
					0,
					0
				]), p.uSheenRough.value = l.sheenRoughness, T("uSheenMap", "uHasSheenMap", w(l.sheenColorTexture)), T("uSheenRoughMap", "uHasSheenRoughMap", w(l.sheenRoughnessTexture));
				let E = g ? l.transmission : 0;
				p.uTransmission.value = E, T("uTransmissionMap", "uHasTransmissionMap", w(l.transmissionTexture)), p.uIor.value = l.ior, p.uMatLook.value = g && l.look ? Fr[l.look] : -1, p.uMatBands.value = g && l.bands ? l.bands : 0;
				let ee = d[i], te = new P(ee, f.mesh);
				if (te.matrixAutoUpdate = !1, te.matrix.copy(m), te.userData.ref = o, E <= .5 && te.layers.enable(1), (E > 0 ? this.glass : this.scene).add(te), e.style.outline > 0) {
					let e = new P(ee, f.hull);
					e.matrixAutoUpdate = !1, e.matrix.copy(m), e.layers.set(2), this.scene.add(e);
				}
			}), this.count++;
		}
		for (let [e, t] of this.ownPoints) i.has(e) || (t.geometries.forEach((e) => e.dispose()), this.ownPoints.delete(e));
		for (let [e, n] of this.materials) t.has(e) || (n.mesh.dispose(), n.hull.dispose(), this.materials.delete(e));
	}
	draw(e, t, n, r) {
		if (this.count && (e.render(this.scene, t), this.glass.children.length)) {
			(!this.backdrop || this.backdrop.image.width !== n || this.backdrop.image.height !== r) && (this.backdrop?.dispose(), this.backdrop = new ge(n, r)), e.copyFramebufferToTexture(this.backdrop);
			for (let e of this.glass.children) {
				let t = e.material.uniforms;
				t.uBackdrop.value = this.backdrop, t.uHasBackdrop.value = 1;
			}
			e.render(this.glass, t);
		}
	}
	pickables() {
		return [...this.scene.children, ...this.glass.children].filter((e) => e.userData.ref);
	}
	preview(e, t) {
		let n = this.built.get(e)?.value;
		if (n) {
			t.forEach((e, t) => {
				let r = n.place[t], i = r && n.geometries[r.batch];
				i && (i.attributes.position.array.set(e.positions, r.offset * 3), i.attributes.normal.array.set(e.normals, r.offset * 3), i.attributes.position.needsUpdate = !0, i.attributes.normal.needsUpdate = !0, e.colors && i.attributes.aColor && (i.attributes.aColor.array.set(e.colors, r.offset * 3), i.attributes.aColor.needsUpdate = !0));
			});
			for (let e of n.geometries) e.computeBoundingSphere();
			this.morphed.set(e, "preview");
		}
	}
	materialPreview = /* @__PURE__ */ new Map();
	previewPicture(e, t, n) {
		let r = this.built.get(e)?.value?.textures[t];
		if (!r) return !1;
		let i = r.image;
		return (i?.width !== n.width || i?.height !== n.height) && r.dispose(), r.image = n, r.needsUpdate = !0, !0;
	}
	renderShadow(e, t) {
		let n = this.uniforms;
		if (!this.count || !t.light.shadows) {
			n.uMeshShadowOn.value = 0, n.uMeshShadow.value = Z;
			return;
		}
		this.scene.updateMatrixWorld(), this.glass.updateMatrixWorld();
		let r = new Se();
		for (let e of this.pickables()) r.expandByObject(e);
		let i = r.getCenter(new x()), a = Math.max(r.getSize(new x()).length() / 2, .01), o = M.degToRad(t.light.azimuth), s = M.degToRad(t.light.elevation), c = new x(Math.sin(o) * Math.cos(s), Math.sin(s), Math.cos(o) * Math.cos(s)).normalize(), l = this.lightCamera;
		l.position.copy(i).addScaledVector(c, a * 2), l.up.set(0, Math.abs(c.y) > .99 ? 0 : 1, +(Math.abs(c.y) > .99)), l.lookAt(i), Object.assign(l, {
			left: -a,
			right: a,
			top: a,
			bottom: -a,
			near: .01,
			far: a * 4
		}), l.updateProjectionMatrix(), l.updateMatrixWorld();
		let u = e.getRenderTarget();
		e.setRenderTarget(this.shadowTarget), e.setScissorTest(!1), e.clear();
		let d = [];
		this.scene.traverse((e) => {
			let t = e, n = t.material?.uniforms;
			t.isMesh && n?.uCutout && n.uCutout.value === 1 && n.uHasMap?.value === 1 && (d.push({
				object: t,
				material: t.material
			}), t.material = this.holedDepth(n.uMap.value));
		}), this.scene.overrideMaterial = null, this.glass.overrideMaterial = this.depthMaterial;
		let f = /* @__PURE__ */ new Map();
		this.scene.traverse((e) => {
			let t = e;
			t.isMesh && !d.some((e) => e.object === t) && (f.set(t, t.material), t.material = this.depthMaterial);
		}), e.render(this.scene, l), e.autoClear = !1, e.render(this.glass, l);
		for (let e of d) e.object.material = e.material;
		for (let [e, t] of f) e.material = t;
		this.glass.overrideMaterial = null, e.setRenderTarget(u), n.uLightViewProj.value.multiplyMatrices(l.projectionMatrix, l.matrixWorldInverse), n.uMeshShadow.value = this.shadowTarget.depthTexture, n.uMeshShadowOn.value = 1, n.uShadowBias.value = Math.max(8e-4, .01 / (a * 4));
	}
	dispose() {
		for (let e of this.ownPoints.values()) e.geometries.forEach((e) => e.dispose());
		for (let e of this.built.values()) e.ready.then((e) => (e.geometries.forEach((e) => e.dispose()), e.textures.forEach((e) => e?.dispose())));
		for (let e of this.materials.values()) e.mesh.dispose(), e.hull.dispose();
		this.shadowTarget.dispose(), this.backdrop?.dispose(), this.depthMaterial.dispose();
		for (let e of this.holedDepths.values()) e.dispose();
	}
}, ii = (e) => new ee(...e.map((e) => M.degToRad(e)), "XYZ");
function ai(e) {
	let t = new Se();
	for (let n of e.children ?? []) {
		if (n.hidden) continue;
		let e = new B().compose(new x(...n.position), new k().setFromEuler(ii(n.rotation)), new x(...n.size));
		t.union(new Se(new x(-.5, -.5, -.5), new x(.5, .5, .5)).applyMatrix4(e));
	}
	return t.isEmpty() ? {
		centre: new x(),
		size: new x(1, 1, 1)
	} : {
		centre: t.getCenter(new x()),
		size: t.getSize(new x())
	};
}
var $ = (e, t = 1e3) => Math.round(e * t) / t, oi = (e) => [
	e.x,
	e.y,
	e.z
].map((e) => $(M.radToDeg(e), 100)), si = class e {
	container;
	editor;
	hooks;
	effectLayer = document.createElement("canvas");
	unlabel;
	canvas;
	renderer;
	atlas = new Vr();
	uniforms = qr(this.atlas);
	meshes;
	focus = new $r();
	volume = new ti(this.uniforms);
	tiles = new ei(this.uniforms);
	quadScene = new O();
	quadCamera = new y(-1, 1, 1, -1, 0, 1);
	overlay = new O();
	perspective = new _e(35, 1, .05, 500);
	ortho = new y(-1, 1, 1, -1, .05, 500);
	orbit;
	gizmo;
	proxy = new he();
	outline;
	selected = null;
	several = [];
	playing = null;
	doc;
	width = 1;
	height = 1;
	frame = 0;
	applying = !1;
	resize;
	gizmoStart = null;
	down = null;
	unsubscribe;
	grid = 0;
	snap = !1;
	uploads = [];
	uploading = !1;
	disposed = !1;
	flyPush = null;
	flying = !1;
	flyVelocity = new x();
	flyTarget = new x();
	flyFrame = 0;
	flyAt = 0;
	upload = (e) => new Promise((t) => {
		if (this.uploads.push({
			texture: e,
			done: t
		}), this.uploading) return;
		this.uploading = !0;
		let n = () => {
			let e = this.uploads.shift();
			if (!e || this.disposed) return void (this.uploading = !1);
			this.renderer.initTexture(e.texture), e.done(), requestAnimationFrame(n);
		};
		requestAnimationFrame(n);
	});
	constructor(e, t, n = {}) {
		this.container = e, this.editor = t, this.hooks = n, this.doc = t.document, this.renderer = new qe({
			antialias: !0,
			alpha: !0,
			premultipliedAlpha: !1,
			preserveDrawingBuffer: !0
		}), this.meshes = new ri(this.uniforms, () => {
			this.meshes.sync(this.doc), this.request();
		}, this.upload), this.unlabel = St(() => this.request()), this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5)), this.renderer.setClearColor(0, 0), this.renderer.autoClear = !1, this.canvas = this.renderer.domElement, this.canvas.style.display = "block", this.canvas.style.width = "100%", this.canvas.style.height = "100%", e.appendChild(this.canvas), Object.assign(this.effectLayer.style, {
			position: "absolute",
			inset: "0",
			width: "100%",
			height: "100%",
			pointerEvents: "none"
		}), e.appendChild(this.effectLayer), this.quadScene.add(new P(new F(2, 2), Qr(this.uniforms))), this.orbit = this.makeOrbit(this.activeCamera()), this.gizmo = new Zn(this.activeCamera(), this.canvas), this.gizmo.setSize(.85), this.gizmo.addEventListener("dragging-changed", (e) => {
			this.orbit.enabled = !e.value;
		}), this.gizmo.addEventListener("mouseDown", () => this.gizmoBegin()), this.gizmo.addEventListener("objectChange", () => this.gizmoChange()), this.gizmo.addEventListener("mouseUp", () => this.gizmoEnd()), this.overlay.add(this.proxy), this.overlay.add(this.gizmo.getHelper()), this.outline = new Te(new fe(new R(1, 1, 1)), new je({
			color: new Oe(getComputedStyle(e).getPropertyValue("--gs-focus").trim() || "#b38bff"),
			transparent: !0,
			opacity: .9,
			depthTest: !1
		})), this.outline.renderOrder = 10, this.proxy.add(this.outline), this.proxy.visible = !1, this.canvas.addEventListener("pointerdown", this.onPointerDown), this.canvas.addEventListener("pointerup", this.onPointerUp), this.resize = new ResizeObserver(() => this.fit()), this.resize.observe(e), this.unsubscribe = t.subscribe(() => this.setDocument(t.document)), this.fit(), this.setDocument(this.doc);
	}
	activeCamera() {
		return this.doc.camera.projection === "orthographic" ? this.ortho : this.perspective;
	}
	makeOrbit(e) {
		let t = new dn(e, this.canvas);
		return t.enableDamping = !1, t.zoomToCursor = !0, t.addEventListener("start", () => this.editor.begin("Turn the view")), t.addEventListener("change", () => this.orbitChange()), t.addEventListener("end", () => this.editor.commit()), t;
	}
	setDocument(e) {
		let t = e.camera.projection !== this.doc.camera.projection;
		if (this.doc = e, t) {
			let e = this.orbit.target.clone();
			this.orbit.dispose(), this.orbit = this.makeOrbit(this.activeCamera()), this.orbit.target.copy(e), this.gizmo.camera = this.activeCamera();
		}
		this.fitted !== `${e.style.look}:${e.style.pixel}` && this.fit(), this.showScene(e.background.picture), this.applyCamera(), this.meshes.sync(this.playing ?? e), this.placeProxy(), this.request();
	}
	showFrame(e) {
		this.playing = e, this.meshes.sync(e ?? this.doc), e ? (this.proxy.visible = !1, this.gizmo.detach()) : this.placeProxy();
		let t = this.effectLayer.getContext("2d"), n = this.canvas.getBoundingClientRect(), r = Math.min(window.devicePixelRatio || 1, 2);
		(this.effectLayer.width !== Math.round(n.width * r) || this.effectLayer.height !== Math.round(n.height * r)) && (this.effectLayer.width = Math.round(n.width * r), this.effectLayer.height = Math.round(n.height * r)), t.clearRect(0, 0, this.effectLayer.width, this.effectLayer.height), e?.effects?.length && gi(t, e, this.effectLayer.width, this.effectLayer.height), this.request();
	}
	select(e) {
		this.several = [], this.selected = e, this.placeProxy(), this.request();
	}
	selectSeveral(e) {
		if (e.length < 2) return this.select(e.length ? [e[0]] : null);
		this.several = [...e], this.selected = null, this.placeProxy(), this.request();
	}
	items() {
		let e = this.several.length ? this.several : this.selected?.length === 1 ? [this.selected[0]] : [];
		if (!this.several.length && this.selected?.length === 2) {
			let e = pt(this.doc, this.selected);
			return e ? [{
				ref: this.selected,
				shape: e
			}] : [];
		}
		return e.flatMap((e) => {
			let t = this.doc.shapes[e];
			return t ? t.kind === "group" ? (t.children ?? []).map((t, n) => ({
				ref: [e, n],
				shape: t
			})) : [{
				ref: [e],
				shape: t
			}] : [];
		});
	}
	setGizmo(e) {
		this.gizmo.setMode(e), this.request();
	}
	setGrid(e, t = !1) {
		this.grid = Math.max(0, e), this.snap = t, this.gizmo.setRotationSnap(t ? M.degToRad(15) : null), this.request();
	}
	placeProxy() {
		if (this.gizmoStart || this.playing) return;
		let e = this.several.length ? this.several.map((e) => this.doc.shapes[e]) : [pt(this.doc, this.selected)], t = this.selected?.length === 2 && this.doc.shapes[this.selected[0]]?.hidden, n = e.filter((e) => !!e && !e.hidden);
		if (!n.length || t) {
			this.proxy.visible = !1, this.gizmo.detach();
			return;
		}
		this.proxy.visible = !0, this.proxy.scale.set(1, 1, 1);
		let r = n[0];
		if (n.length > 1 || r.kind === "group") {
			let e = ai({
				...r,
				children: n.flatMap((e) => e.kind === "group" ? e.children ?? [] : [e])
			});
			this.proxy.position.copy(e.centre), this.proxy.rotation.set(0, 0, 0), this.outline.scale.copy(e.size);
		} else this.proxy.position.set(...r.position), this.proxy.rotation.copy(ii(r.rotation)), this.outline.scale.set(...r.size);
		n.some((e) => e.locked) || this.selected?.length === 2 && this.doc.shapes[this.selected[0]]?.locked ? this.gizmo.detach() : this.gizmo.object !== this.proxy && this.gizmo.attach(this.proxy);
	}
	gizmoBegin() {
		let e = this.items();
		if (!e.length) return;
		let t = this.several.length ? void 0 : pt(this.doc, this.selected);
		this.gizmoStart = {
			items: e.map((e) => ({
				ref: e.ref,
				shape: { ...e.shape }
			})),
			single: !!t && t.kind !== "group",
			pivot: this.proxy.position.clone(),
			size: [
				this.outline.scale.x,
				this.outline.scale.y,
				this.outline.scale.z
			]
		}, this.editor.begin(this.gizmo.mode === "translate" ? "Move" : this.gizmo.mode === "rotate" ? "Turn" : "Resize");
	}
	gizmoChange() {
		let e = this.gizmoStart;
		if (!e) return;
		let t = this.proxy;
		if (this.snap && this.grid > 0 && this.gizmo.mode === "translate") {
			let n = this.grid, r = t.position.clone().sub(e.pivot);
			t.position.copy(e.pivot).add(new x(...r.toArray().map((e) => Math.round(e / n) * n)));
		}
		if (e.single) {
			let n = e.items[0], r = n.shape.size.map((e, n) => Math.max(.02, e * Math.abs(t.scale.getComponent(n))));
			this.outline.scale.set(...r), this.editor.updateShapeAt(n.ref, {
				position: [
					t.position.x,
					t.position.y,
					t.position.z
				],
				rotation: oi(t.rotation),
				size: r
			});
			return;
		}
		let n = (Math.abs(t.scale.x) + Math.abs(t.scale.y) + Math.abs(t.scale.z)) / 3, r = new k().setFromEuler(t.rotation), i = t.position.clone().sub(e.pivot);
		this.outline.scale.set(e.size[0] * n, e.size[1] * n, e.size[2] * n);
		let a = e.items.map(({ shape: t }) => {
			let a = new x(...t.position).sub(e.pivot).multiplyScalar(n).applyQuaternion(r), o = r.clone().multiply(new k().setFromEuler(ii(t.rotation)));
			return {
				...t,
				position: e.pivot.clone().add(i).add(a).toArray().map((e) => $(e)),
				rotation: oi(new ee().setFromQuaternion(o, "XYZ")),
				size: t.size.map((e) => Math.max(.02, $(e * n)))
			};
		});
		this.editor.updateShapesAt(e.items.map((e, t) => {
			let n = a[t];
			return [e.ref, {
				position: n.position,
				rotation: n.rotation,
				size: n.size
			}];
		}), "Move");
	}
	gizmoEnd() {
		this.gizmoStart = null, this.editor.commit(), this.placeProxy();
	}
	applyCamera() {
		let { position: e, target: t } = Rr(this.doc.camera), n = this.width / this.height;
		this.applying = !0;
		for (let n of [this.perspective, this.ortho]) n.position.copy(e), n.up.set(0, 1, 0), n.lookAt(t);
		this.perspective.fov = this.doc.camera.fov, this.perspective.aspect = n, this.perspective.updateProjectionMatrix();
		let r = this.doc.camera.distance * Math.tan(M.degToRad(this.doc.camera.fov / 2));
		Object.assign(this.ortho, {
			left: -r * n,
			right: r * n,
			top: r,
			bottom: -r,
			zoom: 1
		}), this.ortho.updateProjectionMatrix(), this.orbit.target.copy(t), this.orbit.update(), this.applying = !1;
	}
	orbitChange() {
		if (this.applying) return;
		let e = this.activeCamera(), t = this.orbit.target, n = e.position.clone().sub(t), r = n.length();
		e instanceof y && e.zoom !== 1 && (r /= e.zoom, e.zoom = 1), this.editor.setCamera({
			yaw: $(M.radToDeg(Math.atan2(n.x, n.z)), 100),
			pitch: $(M.radToDeg(Math.asin(M.clamp(n.y / n.length(), -1, 1))), 100),
			distance: $(r),
			target: [
				t.x,
				t.y,
				t.z
			].map((e) => $(e))
		});
	}
	onPointerDown = (e) => {
		this.down = {
			x: e.clientX,
			y: e.clientY
		};
	};
	onPointerUp = (e) => {
		let t = this.down;
		this.down = null, !(!t || Math.hypot(e.clientX - t.x, e.clientY - t.y) > 4 || this.gizmo.dragging) && (this.playing || !this.gizmo.axis) && this.hooks.onPick?.(this.shapeAt(e.clientX, e.clientY), { extend: e.shiftKey || e.metaKey || e.ctrlKey });
	};
	modelHitAt(e, t) {
		let { ray: n } = this.rayFor(e, t);
		this.meshes.scene.updateMatrixWorld();
		let r = n.intersectObjects(this.meshes.pickables(), !1)[0];
		if (!r) return null;
		let i = r.face ? r.face.normal.clone().transformDirection(r.object.matrixWorld) : new x(0, 1, 0);
		return {
			ref: r.object.userData.ref,
			point: [
				r.point.x,
				r.point.y,
				r.point.z
			],
			normal: [
				i.x,
				i.y,
				i.z
			]
		};
	}
	rayAt(e, t) {
		let { ray: n } = this.rayFor(e, t), r = n.ray.origin, i = n.ray.direction;
		return {
			origin: [
				r.x,
				r.y,
				r.z
			],
			dir: [
				i.x,
				i.y,
				i.z
			]
		};
	}
	rayFor(e, t) {
		let n = this.canvas.getBoundingClientRect(), r = new j((e - n.left) / n.width * 2 - 1, -((t - n.top) / n.height) * 2 + 1), i = new ie();
		return i.setFromCamera(r, this.activeCamera()), { ray: i };
	}
	setOrbit(e) {
		this.orbit.enabled = e;
	}
	fly(e, { now: t = !1 } = {}) {
		t && !e ? (this.flyPush = null, this.flying && (cancelAnimationFrame(this.flyFrame), this.flying = !1, this.editor.commit())) : (this.flyPush = e && (e.forward || e.across || e.up) ? e : null, this.flyPush && !this.flying && (this.flying = !0, this.flyAt = performance.now(), this.flyVelocity.set(0, 0, 0), this.flyTarget.set(...this.doc.camera.target), this.editor.begin("Move the view"), this.flyFrame = requestAnimationFrame(this.flyStep)));
	}
	flyStep = (e) => {
		let t = Math.min(.05, (e - this.flyAt) / 1e3);
		this.flyAt = e;
		let n = this.flyPush, r = new x();
		if (n) {
			let e = M.degToRad(this.doc.camera.yaw);
			r.set(-Math.sin(e) * n.forward + Math.cos(e) * n.across, n.up, -Math.cos(e) * n.forward - Math.sin(e) * n.across).normalize().multiplyScalar(Math.max(.5, this.doc.camera.distance) * (n.fast ? 3 : 1));
		}
		this.flyVelocity.lerp(r, 1 - Math.exp(-t * 12)), !n && this.flyVelocity.lengthSq() < 1e-4 ? (this.flying = !1, this.editor.commit()) : (this.flyTarget.addScaledVector(this.flyVelocity, t), this.editor.setCamera({ target: [
			this.flyTarget.x,
			this.flyTarget.y,
			this.flyTarget.z
		].map((e) => $(e)) }), this.flyFrame = requestAnimationFrame(this.flyStep));
	};
	setMarks(e, t) {
		let n = this.marks.get(e);
		if (n && (this.overlay.remove(n), n.traverse((e) => {
			let t = e;
			t.geometry?.dispose(), t.material?.dispose();
		}), this.marks.delete(e)), t && (t.points.length || t.lines.length || t.strong?.length)) {
			let n = new Oe(getComputedStyle(this.container).getPropertyValue("--gs-focus").trim() || "#b38bff"), r = new ne(), i = (e, t) => {
				let i = new we().setAttribute("position", new He(e.flat(), 3)), a = new D(i, new se({
					color: n,
					size: t,
					sizeAttenuation: !1,
					depthTest: !1
				}));
				a.renderOrder = 11, r.add(a);
			};
			if (t.points.length && i(t.points, 7), t.strong?.length && i(t.strong, 12), t.lines.length) {
				let e = new we().setAttribute("position", new He(t.lines.flat(2), 3)), i = new Te(e, new je({
					color: n,
					depthTest: !1
				}));
				i.renderOrder = 11, r.add(i);
			}
			this.overlay.add(r), this.marks.set(e, r);
		}
		this.request();
	}
	marks = /* @__PURE__ */ new Map();
	previewModel(e, t) {
		this.meshes.preview(e, t), this.request();
	}
	previewMaterial(e, t, n) {
		let r = this.meshes.materialPreview.get(e) ?? /* @__PURE__ */ new Map();
		n ? r.set(t, n) : r.delete(t), r.size ? this.meshes.materialPreview.set(e, r) : this.meshes.materialPreview.delete(e), this.meshes.sync(this.playing ?? this.doc), this.request();
	}
	previewPicture(e, t, n) {
		let r = this.meshes.previewPicture(e, t, n);
		return this.request(), r;
	}
	shapeAt(e, t) {
		let n = this.playing ?? this.doc, r = this.canvas.getBoundingClientRect(), i = new j((e - r.left) / r.width * 2 - 1, -((t - r.top) / r.height) * 2 + 1), a = new ie();
		a.setFromCamera(i, this.playing ? Wr(n, r.width / Math.max(1, r.height)) : this.activeCamera());
		let o = a.ray.origin, s = a.ray.direction, c = n.shapes.some((e) => e.locked) ? { shapes: n.shapes.map((e) => e.locked ? {
			...e,
			hidden: !0
		} : e) } : n, l = lt(c, [
			o.x,
			o.y,
			o.z
		], [
			s.x,
			s.y,
			s.z
		]);
		this.meshes.scene.updateMatrixWorld();
		let u = a.intersectObjects(this.meshes.pickables(), !1).find((e) => !n.shapes[e.object.userData.ref[0]]?.locked);
		return u && u.distance < (l?.t ?? Infinity) ? u.object.userData.ref : l?.shape ?? null;
	}
	fit() {
		let e = Math.max(1, this.container.clientWidth), t = Math.max(1, this.container.clientHeight);
		this.width = e, this.height = t;
		let n = this.doc.style.look === "pixel";
		this.renderer.setPixelRatio(n ? 1 : this.pixelRatio());
		let [r, i] = n ? jt(this.doc, e, t) : [e, t];
		this.renderer.setSize(r, i, !1), this.canvas.style.imageRendering = n ? "pixelated" : "", this.fitted = `${this.doc.style.look}:${this.doc.style.pixel}`, this.applyCamera(), this.request();
	}
	fitted = "";
	showScene(e) {
		this.container.dataset.scene !== e && (this.container.dataset.scene = e, Object.assign(this.container.style, e ? {
			backgroundImage: `url("${e}")`,
			backgroundSize: "cover",
			backgroundPosition: "center"
		} : {
			backgroundImage: "",
			backgroundSize: "",
			backgroundPosition: ""
		}));
	}
	quality = 0;
	moving = !1;
	lastDraw = 0;
	lastAsk = 0;
	asking = !1;
	gaps = [];
	since = 0;
	sharpen = 0;
	drawn = [];
	gpuName = null;
	static MOVING_PIXELS = 2e6;
	static FLOOR = .25;
	static STILL_MS = 300;
	static SPEED_KEY = "gleamshelf:3d-speed";
	rate = e.savedRate();
	static savedRate() {
		try {
			let t = Number(localStorage.getItem(e.SPEED_KEY));
			return Number.isFinite(t) && t > 0 ? t : 0;
		} catch {
			return 0;
		}
	}
	static full = () => Math.min(window.devicePixelRatio || 1, 1.5);
	pixelRatio() {
		let t = e.full();
		if (this.moving) return t * this.quality;
		let n = this.width * this.height * t * t, r = this.rate ? Math.sqrt(e.STILL_MS * this.rate / n) : 1;
		return t * Math.min(1, Math.max(e.FLOOR, r));
	}
	startQuality() {
		let t = e.full(), n = this.width * this.height * t * t;
		return Math.min(1, Math.max(e.FLOOR, Math.sqrt((this.rate ? 16.7 * this.rate : e.MOVING_PIXELS) / n)));
	}
	setQuality(t) {
		let n = Math.min(1, Math.max(e.FLOOR, Math.round(t * 20) / 20));
		n !== this.quality && (this.quality = n, this.moving && this.doc.style.look !== "pixel" && this.renderer.setPixelRatio(this.pixelRatio()));
	}
	paced() {
		if (this.doc.style.look === "pixel") return;
		let t = performance.now(), n = t - this.lastDraw;
		if (this.lastDraw = t, n < 70 || this.asking) {
			if (!this.moving) this.moving = !0, this.gaps = [], this.since = 0, this.quality = this.startQuality(), this.renderer.setPixelRatio(this.pixelRatio());
			else {
				let e = this.renderer.getDrawingBufferSize(new j()), t = e.x * e.y / Math.max(1, n);
				if (n < 100 && (this.rate = this.rate ? this.rate * .8 + t * .2 : t), this.gaps.push(n), this.gaps.length > 7 && this.gaps.shift(), this.since++, this.gaps.length >= 5) {
					let e = [...this.gaps].sort((e, t) => e - t)[this.gaps.length >> 1];
					e > 21 && this.since >= 3 ? (this.since = 0, this.setQuality(this.quality * Math.sqrt(16.7 / e))) : e < 18.5 && this.since >= 8 && (this.since = 0, this.setQuality(this.quality + .05));
				}
			}
		}
		clearTimeout(this.sharpen), this.sharpen = window.setTimeout(() => {
			if (this.moving) {
				this.moving = !1;
				try {
					this.rate && localStorage.setItem(e.SPEED_KEY, String(Math.round(this.rate)));
				} catch {}
				this.renderer.setPixelRatio(this.pixelRatio()), this.request();
			}
		}, 160);
	}
	request() {
		let e = performance.now();
		this.asking = e - this.lastAsk < 120, this.lastAsk = e, !this.frame && (this.frame = requestAnimationFrame(() => {
			this.frame = 0, this.draw();
		}));
	}
	cpu = [];
	draw() {
		let e = performance.now();
		for (this.drawn.push(e); this.drawn.length && this.drawn[0] < e - 1e3;) this.drawn.shift();
		this.renderer.info.autoReset = !1, this.renderer.info.reset(), this.paced();
		let t = this.renderer.getDrawingBufferSize(new j()), n = Ot(this.playing ?? this.doc, t.y), r = Zr(this.uniforms, this.atlas, n, t.x, t.y);
		this.volume.update(this.renderer, n, this.gizmoStart !== null || this.playing !== null), this.tiles.update(t.x, t.y), this.uniforms.uGrid.value = this.doc.style.look === "pixel" ? 0 : this.grid, this.meshes.renderShadow(this.renderer, n);
		let i = this.renderer.getSize(new j());
		this.renderer.setViewport(0, 0, i.x, i.y), this.renderer.clear();
		let a = this.focus.begin(this.renderer, n, t.x, t.y);
		this.renderer.render(this.quadScene, this.quadCamera), this.meshes.draw(this.renderer, r, t.x, t.y), a && this.focus.finish(this.renderer, i.x, i.y), this.renderer.clearDepth(), this.renderer.render(this.overlay, this.activeCamera()), this.cpu.push(performance.now() - e), this.cpu.length > 20 && this.cpu.shift();
	}
	stats() {
		let t = performance.now(), n = this.drawn.filter((e) => e > t - 1e3), r = n.length > 1 && t - n[n.length - 1] < 250, i = n.slice(1).map((e, t) => e - n[t]).sort((e, t) => e - t), a = this.renderer.getDrawingBufferSize(new j()), o = e.full();
		if (this.gpuName === null) {
			let e = this.renderer.getContext(), t = e.getExtension("WEBGL_debug_renderer_info"), n = t ? String(e.getParameter(t.UNMASKED_RENDERER_WEBGL)) : "", r = n.match(/^ANGLE \((?:[^,]*), ([^,]*?)(?: \(0x[0-9A-Fa-f]+\))?(?: Direct3D.*| vs_.*)?(?:,.*)?\)$/)?.[1] ?? n;
			this.gpuName = r.replace(/^ANGLE \w+ Renderer: /, "").trim();
		}
		return {
			fps: r ? n.length : 0,
			frameMs: r && i.length ? i[i.length >> 1] : 0,
			moving: this.moving,
			width: a.x,
			height: a.y,
			share: Math.min(1, a.x * a.y / Math.max(1, this.width * this.height * o * o)),
			rate: Math.round(this.rate),
			shapes: this.uniforms.uCount.value,
			models: this.meshes.count,
			triangles: this.renderer.info.render.triangles,
			calls: this.renderer.info.render.calls,
			gpu: this.gpuName,
			field: this.uniforms.uVolOn.value ? this.volume.dims : null,
			cpuMs: this.cpu.length ? [...this.cpu].sort((e, t) => e - t)[this.cpu.length >> 1] : 0,
			tileEntries: this.tiles.entries,
			textureMB: Math.round(this.meshes.textureBytes / 1e6),
			textureBudgetMB: Math.round(ri.TEXTURE_BUDGET / 1e6)
		};
	}
	dispose() {
		cancelAnimationFrame(this.frame), cancelAnimationFrame(this.flyFrame), clearTimeout(this.sharpen), this.disposed = !0;
		for (let e of this.uploads.splice(0)) e.done();
		this.unsubscribe(), this.unlabel(), this.resize.disconnect(), this.canvas.removeEventListener("pointerdown", this.onPointerDown), this.canvas.removeEventListener("pointerup", this.onPointerUp), this.gizmo.dispose(), this.orbit.dispose(), this.meshes.dispose(), this.focus.dispose(), this.volume.dispose(), this.tiles.dispose(), this.atlas.dispose(), this.renderer.dispose(), this.canvas.remove();
	}
}, ci = class {
	canvas;
	output = document.createElement("canvas");
	backdrop = null;
	renderer;
	atlas = new Vr();
	uniforms = qr(this.atlas);
	meshes = new ri(this.uniforms);
	focus = new $r();
	volume = new ti(this.uniforms);
	tiles = new ei(this.uniforms);
	scene = new O();
	camera = new y(-1, 1, 1, -1, 0, 1);
	constructor() {
		this.canvas = document.createElement("canvas"), this.renderer = new qe({
			canvas: this.canvas,
			antialias: !0,
			alpha: !0,
			premultipliedAlpha: !1,
			preserveDrawingBuffer: !0
		}), this.renderer.setPixelRatio(1), this.renderer.setClearColor(0, 0), this.renderer.autoClear = !1, this.scene.add(new P(new F(2, 2), Qr(this.uniforms)));
	}
	async paint(e, t, n, r = {}) {
		if (!Pt(e)) return this.draw(e, t, n, r);
		let i = e.style.look === "pixel", [a, o] = jt(e, t, n), s = await this.draw(Ot(e, o), a, o, i ? {
			...r,
			samples: 1
		} : r), c = this.output;
		c.width = t, c.height = n;
		let l = c.getContext("2d");
		l.clearRect(0, 0, t, n);
		let u = await this.scenePicture(e.background.picture);
		if (u) {
			let e = Math.max(t / u.width, n / u.height);
			l.imageSmoothingEnabled = !0, l.drawImage(u, (t - u.width * e) / 2, (n - u.height * e) / 2, u.width * e, u.height * e);
		} else e.background.transparent || (l.fillStyle = e.background.color, l.fillRect(0, 0, t, n));
		return l.imageSmoothingEnabled = !i, l.drawImage(s, 0, 0, t, n), c;
	}
	surfaceFor(e) {
		return Pt(e) ? this.output : this.canvas;
	}
	async scenePicture(e) {
		return e ? (this.backdrop?.url !== e && (this.backdrop?.picture.close(), this.backdrop = {
			url: e,
			picture: await createImageBitmap(await (await fetch(e)).blob())
		}), this.backdrop.picture) : null;
	}
	async draw(e, t, n, r) {
		let { samples: i = 2, frame: a = 1, tile: o = 384 } = r;
		await Promise.all([this.meshes.ready(e), vt(e)]), this.meshes.sync(e), this.renderer.setSize(t, n, !1);
		let s = Zr(this.uniforms, this.atlas, e, t, n, a);
		this.volume.update(this.renderer, e, !1), this.tiles.update(t, n), this.meshes.renderShadow(this.renderer, e), this.renderer.setScissorTest(!1), this.renderer.setViewport(0, 0, t, n), this.renderer.clear();
		let c = this.focus.begin(this.renderer, e, t, n);
		this.uniforms.uSamples.value = i, this.renderer.setScissorTest(!0);
		for (let e = 0; e < n; e += o) for (let r = 0; r < t; r += o) {
			let i = Math.min(o, t - r), a = Math.min(o, n - e);
			this.renderer.setViewport(r, e, i, a), this.renderer.setScissor(r, e, i, a), this.uniforms.uTileOffset.value.set(r, e), this.uniforms.uTileSize.value.set(i, a), this.renderer.render(this.scene, this.camera), t * n > 7e5 && await new Promise((e) => setTimeout(e, 0));
		}
		return this.renderer.setScissorTest(!1), this.meshes.count && (this.renderer.setViewport(0, 0, t, n), this.meshes.draw(this.renderer, s, t, n)), c && this.focus.finish(this.renderer, t, n), this.canvas;
	}
	dispose() {
		this.backdrop?.picture.close(), this.meshes.dispose(), this.focus.dispose(), this.volume.dispose(), this.tiles.dispose(), this.atlas.dispose(), this.renderer.dispose();
	}
};
async function li(e, t, n, r = "image/png", i = 1) {
	let a = new ci();
	try {
		let o = await a.paint(e, t, n, { frame: i });
		return await new Promise((e, t) => o.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be made.")), r, .92));
	} finally {
		a.dispose();
	}
}
var ui = class e {
	width;
	height;
	canvas;
	renderer;
	atlas = new Vr();
	uniforms = qr(this.atlas);
	targets;
	guide;
	cleaned;
	trace;
	show;
	guidePass;
	denoisePass;
	camera = new y(-1, 1, 1, -1, 0, 1);
	stopped = !1;
	meshTextures;
	envTexture;
	frames = 0;
	denoise = !0;
	static async create(t, n, r, i = _t, a = !1) {
		await vt(t, i);
		let o = t.environment && i ? await di(t.environment.picture, i) : null;
		return new e(t, n, r, await Vt(t, i), o, a);
	}
	constructor(e, t, n, r = null, i = null, a = !1) {
		this.width = t, this.height = n, this.canvas = document.createElement("canvas"), this.renderer = new qe({
			canvas: this.canvas,
			preserveDrawingBuffer: !0,
			alpha: !0,
			premultipliedAlpha: !1
		}), this.renderer.setPixelRatio(1), this.renderer.setSize(t, n, !1);
		let o = () => new de(t, n, {
			type: v,
			depthBuffer: !1,
			minFilter: me,
			magFilter: me
		});
		this.targets = [o(), o()], this.guide = o(), this.cleaned = [o(), o()], Zr(this.uniforms, this.atlas, e, t, n);
		let s = new Oe(e.background.transparent ? "#f4f4f2" : e.background.color);
		this.meshTextures = hi(r), this.envTexture = i ? new N(new Uint8Array(i.data), i.width, i.height, Re) : new N(new Uint8Array([
			255,
			255,
			255,
			255
		]), 1, 1, Re), this.envTexture.minFilter = this.envTexture.magFilter = Ee, this.envTexture.wrapS = Ue, this.envTexture.needsUpdate = !0;
		let c = {
			...this.meshTextures.uniforms,
			...fi(e),
			uEnv: { value: this.envTexture },
			uHasEnv: { value: +!!i },
			uEnvSet: { value: new z(e.environment?.strength ?? 1, (e.environment?.turn ?? 0) * Math.PI / 180, +!!e.environment?.show, 0) },
			...pi(e),
			uAccum: { value: this.targets[0].texture },
			uFrame: { value: 0 },
			uStudio: { value: new x(s.r ** 2.2, s.g ** 2.2, s.b ** 2.2) },
			uKeepClear: { value: a && e.background.transparent ? 1 : 0 }
		}, l = new F(2, 2), u = (e, t) => new P(l, new I({
			glslVersion: ve,
			vertexShader: yr,
			fragmentShader: e,
			uniforms: t,
			depthTest: !1,
			depthWrite: !1
		}));
		this.trace = u(kr, {
			...this.uniforms,
			...c
		}), this.guidePass = u(Ar, {
			...this.uniforms,
			...c
		}), this.denoisePass = u(jr, {
			uColor: { value: null },
			uGuide: { value: this.guide.texture },
			uStep: { value: 1 }
		}), this.show = u(Mr, { uAccum: { value: this.targets[0].texture } }), this.renderer.setRenderTarget(this.guide), this.renderer.render(this.guidePass, this.camera), this.renderer.setRenderTarget(null);
	}
	present(e) {
		let t = e.texture;
		if (this.denoise) {
			let e = this.denoisePass.material.uniforms;
			[
				1,
				2,
				4,
				8
			].forEach((n, r) => {
				let i = this.cleaned[r % 2];
				e.uColor.value = t, e.uStep.value = n, this.renderer.setRenderTarget(i), this.renderer.render(this.denoisePass, this.camera), t = i.texture;
			});
		}
		this.show.material.uniforms.uAccum.value = t, this.renderer.setRenderTarget(null), this.renderer.render(this.show, this.camera);
	}
	async run(e, t) {
		this.stopped = !1;
		let n = this.trace.material.uniforms;
		for (; this.frames < e && !this.stopped;) {
			let [r, i] = this.frames % 2 ? [this.targets[1], this.targets[0]] : [this.targets[0], this.targets[1]];
			n.uAccum.value = r.texture, n.uFrame.value = this.frames, this.renderer.setRenderTarget(i), this.renderer.render(this.trace, this.camera), this.frames++, (this.frames % 4 == 0 || this.frames === e) && (this.present(i), t?.(this.frames / e), await new Promise((e) => setTimeout(e, 0)));
		}
	}
	redraw() {
		this.frames && this.present(this.frames % 2 ? this.targets[1] : this.targets[0]);
	}
	stop() {
		this.stopped = !0;
	}
	dispose() {
		this.stop();
		for (let e of [
			...this.targets,
			this.guide,
			...this.cleaned
		]) e.dispose();
		for (let e of this.meshTextures.textures) e.dispose();
		this.envTexture.dispose();
		for (let e of [
			this.trace,
			this.show,
			this.guidePass,
			this.denoisePass
		]) e.material.dispose();
		this.trace.geometry.dispose(), this.atlas.dispose(), this.renderer.dispose();
	}
};
async function di(e, t) {
	let n = /^data:(image\/[a-z]+);base64,(.*)$/.exec(e);
	if (!n) return null;
	let r = atob(n[2]);
	return t(Uint8Array.from(r, (e) => e.charCodeAt(0)), n[1]).catch(() => null);
}
function fi(e) {
	let t = new x(...e.camera.target), n = [new z(), new z()], r = [new z(0, -1, 0, .5), new z(0, -1, 0, .5)], i = [new z(), new z()];
	return (e.light.extra ?? []).slice(0, 2).forEach((e, a) => {
		if (!e.kind || e.kind === "sun") return;
		let o = new x(...zt(e.azimuth, e.elevation)), s = t.clone().addScaledVector(o, e.distance ?? 5), c = t.clone().sub(s).normalize();
		n[a].set(s.x, s.y, s.z, 0), r[a].set(c.x, c.y, c.z, Math.cos((e.cone ?? 50) * Math.PI / 360)), i[a].set(e.kind === "point" ? 1 : e.kind === "spot" ? 2 : 3, e.distance ?? 5, e.size ?? .8, 0);
	}), {
		uLightPos: { value: n },
		uLightAim: { value: r },
		uLightKind: { value: i }
	};
}
function pi(e) {
	let t = e.camera.focus, n = Math.max(.1, e.camera.distance + (t?.offset ?? 0));
	return {
		uAperture: { value: t ? t.blur * .06 * n : 0 },
		uFocusDist: { value: n }
	};
}
function mi(e) {
	let t = Math.max(1, e.length / 4), n = Math.min(2048, t), r = Math.ceil(t / n), i = new Float32Array(n * r * 4);
	i.set(e);
	let a = new N(i, n, r, Re, v);
	return a.minFilter = a.magFilter = me, a.needsUpdate = !0, a;
}
function hi(e) {
	let t = mi(e?.nodes ?? /* @__PURE__ */ new Float32Array(8)), n = mi(e?.tris ?? /* @__PURE__ */ new Float32Array(4)), r = Math.max(1, e?.pictures.length ?? 0), i = r <= 8 ? 1024 : r <= 64 ? 512 : 256, a = new Uint8Array(i * i * 4 * r);
	e?.pictures.forEach((e, t) => {
		for (let n = 0; n < i; n++) for (let r = 0; r < i; r++) {
			let o = Math.min(e.width - 1, Math.floor(r / i * e.width)), s = Math.min(e.height - 1, Math.floor(n / i * e.height));
			a.set(e.data.subarray((s * e.width + o) * 4, (s * e.width + o) * 4 + 4), ((t * i + n) * i + r) * 4);
		}
	});
	let o = new Be(a, i, i, r);
	o.minFilter = o.magFilter = Ee, o.needsUpdate = !0;
	let s = e?.materials.length ? e.materials : [void 0], c = new Float32Array(s.length * 4 * 4);
	s.forEach((e, t) => c.set([
		...e?.color ?? [
			1,
			1,
			1
		],
		e?.picture ?? -1,
		e?.metal ?? 0,
		e?.rough ?? .6,
		e?.glass ?? 0,
		e?.normalPicture ?? -1,
		...e?.glow ?? [
			0,
			0,
			0
		],
		e?.normalScale ?? 1,
		e?.look ?? -1,
		e?.bands ?? 0,
		e?.glowPicture ?? -1,
		0
	], t * 4 * 4));
	let l = mi(c);
	return {
		textures: [
			t,
			n,
			o,
			l
		],
		uniforms: {
			uBvh: { value: t },
			uTris: { value: n },
			uMeshTris: { value: e?.triCount ?? 0 },
			uTMats: { value: l },
			uTPics: { value: o }
		}
	};
}
function gi(e, t, n, r) {
	let i = wt(t);
	if (!i.length) return;
	let a = Wr(t, n / r);
	a.updateMatrixWorld();
	let o = a.position, s = Math.tan(M.degToRad(t.camera.fov / 2)), c = new x();
	for (let l of i) {
		if (c.set(...l.at).project(a), c.z > 1 || c.z < -1) continue;
		let i = (c.x * .5 + .5) * n, u = (-c.y * .5 + .5) * r, d = t.camera.projection === "orthographic" ? t.camera.distance : o.distanceTo(new x(...l.at)), f = l.size / (2 * s * Math.max(d, .01)) * r;
		if (e.save(), e.globalAlpha = l.alpha, e.translate(i, u), e.rotate(l.turn), l.look === "star") {
			let t = e.createRadialGradient(0, 0, 0, 0, 0, f * 1.4);
			t.addColorStop(0, l.color), t.addColorStop(1, "rgba(255,255,255,0)"), e.fillStyle = t, e.beginPath(), e.arc(0, 0, f * 1.4, 0, Math.PI * 2), e.fill(), e.fillStyle = l.color, e.beginPath();
			for (let t = 0; t < 8; t++) {
				let n = t % 2 ? f * .18 : f, r = t * Math.PI / 4;
				e.lineTo(Math.cos(r) * n, Math.sin(r) * n);
			}
			e.closePath(), e.fill();
		} else if (l.look === "puff" || l.look === "flame") {
			l.look === "flame" && (e.globalCompositeOperation = "lighter");
			let t = e.createRadialGradient(0, 0, 0, 0, 0, f);
			t.addColorStop(0, l.color), t.addColorStop(1, `${l.color}00`), e.fillStyle = t, e.beginPath(), e.arc(0, 0, f, 0, Math.PI * 2), e.fill();
		} else l.look === "drop" ? (e.fillStyle = l.color, e.beginPath(), e.arc(0, 0, f / 2, 0, Math.PI * 2), e.fill(), e.fillStyle = "rgba(255,255,255,0.7)", e.beginPath(), e.arc(-f * .15, -f * .15, f * .12, 0, Math.PI * 2), e.fill()) : (e.fillStyle = l.color, e.scale(1, Math.max(.15, Math.abs(Math.cos(l.turn * 1.7)))), e.fillRect(-f / 2, -f * .35, f, f * .7));
		e.restore();
	}
}
//#endregion
//#region ../scene3d/src/model/video.ts
var _i = {
	still: "Camera still",
	turntable: "Turntable",
	bounce: "Camera sway",
	light: "Light sweep"
};
function vi(e, t, n) {
	let r = at(e, n);
	return t === "still" ? r : t === "turntable" ? {
		...r,
		camera: {
			...r.camera,
			yaw: r.camera.yaw + 360 * n
		}
	} : t === "bounce" ? {
		...r,
		camera: {
			...r.camera,
			yaw: r.camera.yaw + 25 * Math.sin(2 * Math.PI * n)
		}
	} : {
		...r,
		light: {
			...r.light,
			azimuth: (r.light.azimuth + 360 * n + 180) % 360 - 180
		}
	};
}
async function yi(e, t) {
	let { kind: n, seconds: r = 4, fps: i = 30, size: a = 1080, aspect: o = 1, onProgress: s, music: c } = t, l = (e) => Math.max(2, Math.round(e / 2) * 2), [u, d] = o >= 1 ? [l(a), l(a / o)] : [l(a * o), l(a)], f = {
		...e,
		clip: r,
		background: {
			...e.background,
			transparent: !1
		}
	}, p = await Ke("avc", {
		width: u,
		height: d
	}), m = !p && await Ke("vp9", {
		width: u,
		height: d
	});
	if (!p && !m) throw Error("This browser cannot make video (it has no H.264 or VP9 encoder). Try Chrome, Edge or Safari.");
	let h = new ci();
	try {
		let e = new $e({
			format: p ? new Xe({ fastStart: "in-memory" }) : new Qe(),
			target: new Ze()
		}), t = !nt(f.compose), a = f.effects?.length || t ? Object.assign(document.createElement("canvas"), {
			width: u,
			height: d
		}) : null, o = new Ge(a ?? h.surfaceFor(f), {
			codec: p ? "avc" : "vp9",
			bitrate: Ye
		});
		e.addVideoTrack(o, { frameRate: i });
		let l = p ? "aac" : "opus", m = c && await et(l, {
			numberOfChannels: c.numberOfChannels,
			sampleRate: c.sampleRate
		}) ? new Je({
			codec: l,
			quality: Ye
		}) : null;
		m && e.addAudioTrack(m), await e.start();
		let g = Math.max(2, Math.round(Math.min(600, Math.max(1, r)) * i));
		for (let e = 0; e < g; e++) {
			let r = vi(f, n, e / g), c = await h.paint(r, u, d, { samples: 1 });
			if (a) {
				let n = a.getContext("2d");
				if (n.clearRect(0, 0, u, d), n.drawImage(c, 0, 0, u, d), gi(n, r, u, d), t) {
					let t = n.getImageData(0, 0, u, d);
					dt(t.data, u, d, f.compose, e + 1), n.putImageData(t, 0, 0);
				}
			}
			await o.add(e / i, 1 / i), s?.((e + 1) / g);
		}
		if (m && c) {
			let e = Math.min(c.length, Math.round(g / i * c.sampleRate)), t = new AudioBuffer({
				length: e,
				numberOfChannels: c.numberOfChannels,
				sampleRate: c.sampleRate
			});
			for (let n = 0; n < c.numberOfChannels; n++) t.copyToChannel(c.getChannelData(n).slice(0, e), n);
			await m.add(t);
		}
		await e.finalize();
		let _ = e.target.buffer, v = p ? "video/mp4" : "video/webm";
		return {
			blob: new Blob([_], { type: v }),
			type: v,
			extension: p ? "mp4" : "webm"
		};
	} finally {
		h.dispose();
	}
}
//#endregion
//#region ../scene3d/src/model/sequence.ts
function bi(e, t, n, r, i) {
	e.fillStyle = t.background, e.fillRect(0, 0, n, r);
	let a = t.text.split("\n"), o = Math.round(Math.min(r / (a.length + 2), n / Math.max(...a.map((e) => e.length), 1) * 1.6, r * .12));
	e.font = `600 ${o}px system-ui, sans-serif`, e.textAlign = "center", e.textBaseline = "middle", e.fillStyle = t.color, e.globalAlpha = Math.min(1, i * 4), a.forEach((t, i) => e.fillText(t, n / 2, r / 2 + (i - (a.length - 1) / 2) * o * 1.25)), e.globalAlpha = 1;
}
function xi(e, t, n, r, i) {
	let a = Math.max(n / t.width, r / t.height) * (1 + .06 * i);
	e.fillStyle = "#000000", e.fillRect(0, 0, n, r), e.drawImage(t, (n - t.width * a) / 2, (r - t.height * a) / 2, t.width * a, t.height * a);
}
async function Si(e, t, n = {}) {
	let { size: r = 1080, aspect: i = 16 / 9, fps: a = 30, music: o, onProgress: s } = n, c = (e) => Math.max(2, Math.round(e / 2) * 2), [l, u] = i >= 1 ? [c(r), c(r / i)] : [c(r * i), c(r)], d = {
		...e,
		background: {
			...e.background,
			transparent: !1
		}
	}, f = await Ke("avc", {
		width: l,
		height: u
	}), p = !f && await Ke("vp9", {
		width: l,
		height: u
	});
	if (!f && !p) throw Error("This browser cannot make video (it has no H.264 or VP9 encoder). Try Chrome, Edge or Safari.");
	let m = f ? "aac" : "opus", h = !!o && await et(m, {
		numberOfChannels: o.numberOfChannels,
		sampleRate: o.sampleRate
	}), g = await Promise.all(t.strips.map(async (e) => e.kind === "picture" ? createImageBitmap(await (await fetch(e.picture)).blob()) : null)), _ = new ci();
	try {
		let n = new $e({
			format: f ? new Xe({ fastStart: "in-memory" }) : new Qe(),
			target: new Ze()
		}), r = Object.assign(document.createElement("canvas"), {
			width: l,
			height: u
		}), i = r.getContext("2d", { willReadFrequently: !0 }), c = Object.assign(document.createElement("canvas"), {
			width: l,
			height: u
		}), p = new Ge(r, {
			codec: f ? "avc" : "vp9",
			bitrate: Ye
		});
		n.addVideoTrack(p, { frameRate: a });
		let v = h ? new Je({
			codec: m,
			quality: Ye
		}) : null;
		v && n.addAudioTrack(v), await n.start();
		let y = ht(t), b = t.strips.map((e) => Math.max(1, Math.round(e.seconds * a))), x = b.reduce((e, t) => e + t, 0), S = Math.round(t.fade * a), C = 0;
		for (let n = 0; n < t.strips.length; n++) {
			let o = t.strips[n];
			for (let t = 0; t < b[n]; t++) {
				let r = t / b[n];
				if (i.clearRect(0, 0, l, u), o.kind === "clip") {
					let e = vi(d, o.camera, o.from + (o.to - o.from) * r);
					i.drawImage(await _.paint(e, l, u, { samples: 1 }), 0, 0, l, u), gi(i, e, l, u);
				} else o.kind === "title" ? bi(i, o, l, u, r * o.seconds) : xi(i, g[n], l, u, r);
				if (!nt(e.compose)) {
					let t = i.getImageData(0, 0, l, u);
					dt(t.data, l, u, e.compose, C + 1), i.putImageData(t, 0, 0);
				}
				n > 0 && t < S && (i.globalAlpha = 1 - t / S, i.drawImage(c, 0, 0), i.globalAlpha = 1), await p.add(C / a, 1 / a), C++, s?.(C / x);
			}
			c.getContext("2d").drawImage(r, 0, 0);
		}
		if (v && o) {
			let e = Math.min(o.length, Math.round(y * o.sampleRate)), t = new AudioBuffer({
				length: e,
				numberOfChannels: o.numberOfChannels,
				sampleRate: o.sampleRate
			}), n = Math.max(0, e - o.sampleRate);
			for (let r = 0; r < o.numberOfChannels; r++) {
				let i = o.getChannelData(r).slice(0, e);
				for (let t = n; t < e; t++) i[t] *= (e - t) / (e - n);
				t.copyToChannel(i, r);
			}
			await v.add(t);
		}
		await n.finalize();
		let w = n.target.buffer, T = f ? "video/mp4" : "video/webm";
		return {
			blob: new Blob([w], { type: T }),
			type: T,
			extension: f ? "mp4" : "webm"
		};
	} finally {
		_.dispose(), g.forEach((e) => e?.close());
	}
}
//#endregion
//#region ../../node_modules/three/examples/jsm/libs/draco/gltf/draco_wasm_wrapper.js?url
var Ci = new URL("./assets/draco_wasm_wrapper.js", import.meta.url).href, wi = new URL("./assets/draco_decoder.wasm", import.meta.url).href, Ti = [
	"glb",
	"gltf",
	"fbx",
	"obj",
	"stl",
	"ply",
	"3mf",
	"pmx",
	"pmd"
], Ei = ".glb,.gltf,.fbx,.obj,.stl,.ply,.3mf,.pmx,.pmd,.bin,.mtl,.png,.jpg,.jpeg,.webp,.tga,.bmp,.spa,.sph", Di = (e) => e.toLowerCase().split(".").pop() ?? "", Oi = (e) => decodeURIComponent(e.split(/[?#]/)[0].split(/[\\/]/).pop() ?? "").toLowerCase();
function ki(e, t, n = 2048) {
	let r = e.image;
	if (!r || !r.width || !r.height || e.isCompressedTexture) return null;
	let i = Math.min(1, n / Math.max(r.width, r.height)), [a, o] = t ?? [Math.max(1, Math.round(r.width * i)), Math.max(1, Math.round(r.height * i))], s = new OffscreenCanvas(a, o).getContext("2d", { willReadFrequently: !0 });
	try {
		if (r.data) {
			let e = r.data, t = e.length / (r.width * r.height);
			if (t !== 3 && t !== 4) return null;
			let n = new Uint8ClampedArray(r.width * r.height * 4);
			for (let i = 0; i < r.width * r.height; i++) n[i * 4] = e[i * t], n[i * 4 + 1] = e[i * t + 1], n[i * 4 + 2] = e[i * t + 2], n[i * 4 + 3] = t === 4 ? e[i * t + 3] : 255;
			let i = new OffscreenCanvas(r.width, r.height);
			i.getContext("2d").putImageData(new ImageData(n, r.width, r.height), 0, 0), s.drawImage(i, 0, 0, a, o);
		} else s.drawImage(r, 0, 0, a, o);
	} catch {
		return null;
	}
	return s;
}
var Ai = async (e, t) => {
	let n = await e.convertToBlob({
		type: t,
		quality: .9
	});
	return {
		mime: n.type,
		bytes: new Uint8Array(await n.arrayBuffer())
	};
}, ji = async (e, t) => {
	let n = ki(e);
	if (!n) return null;
	let r = t === "data";
	if (!r) {
		let e = n.getImageData(0, 0, n.canvas.width, n.canvas.height).data;
		for (let t = 3; t < e.length; t += 4) if (e[t] < 250) {
			r = !0;
			break;
		}
	}
	return Ai(n.canvas, r ? "image/png" : "image/jpeg");
}, Mi = async (e, t) => {
	let n = ki(e ?? t);
	if (!n) return null;
	let r = [n.canvas.width, n.canvas.height], i = e ? ki(e, r)?.getImageData(0, 0, ...r).data : null, a = t ? ki(t, r)?.getImageData(0, 0, ...r).data : null, o = new ImageData(...r);
	for (let e = 0; e < o.data.length; e += 4) o.data[e] = 255, o.data[e + 1] = i ? i[e + 1] : 255, o.data[e + 2] = a ? a[e + 2] : 255, o.data[e + 3] = 255;
	let s = new OffscreenCanvas(...r);
	return s.getContext("2d").putImageData(o, 0, 0), Ai(s, "image/png");
};
function Ni(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(n.name.toLowerCase(), URL.createObjectURL(n));
	let n = new Ve(), r = 0, i = null;
	n.setURLModifier((e) => e.startsWith("blob:") || e.startsWith("data:") ? e : t.get(Oi(e)) ?? e), n.itemStart = ((e) => (t) => {
		r++, e(t);
	})(n.itemStart.bind(n));
	let a = (e) => (r = Math.max(0, r - 1), r || i?.(), e);
	return n.itemEnd = ((e) => (t) => e(a(t)))(n.itemEnd.bind(n)), n.itemError = ((e) => (t) => e(a(t)))(n.itemError.bind(n)), {
		manager: n,
		settled: () => new Promise((e) => {
			if (!r) return e();
			i = e, setTimeout(e, 2e4);
		}),
		dispose: () => t.forEach((e) => URL.revokeObjectURL(e))
	};
}
var Pi = "MikuMikuDance models and dances have their own authors' terms: check the readme before sharing or selling anything made with it.";
async function Fi(e, t, n) {
	let r = t.replace(/\\/g, "/").split("/").pop().toLowerCase(), i = e.find((e) => e.name.toLowerCase() === r);
	if (!i) return null;
	if (/\.tga$/i.test(r)) {
		let { TGALoader: e } = await import("./TGALoader-0G2gSx5H.js"), t = new e(n).parse(await i.arrayBuffer()), r = ki(new N(t.data, t.width, t.height));
		return r ? Ai(r.canvas, "image/png") : null;
	}
	try {
		let e = await createImageBitmap(i), t = new OffscreenCanvas(Math.min(2048, e.width), Math.min(2048, e.height));
		return t.getContext("2d").drawImage(e, 0, 0, t.width, t.height), e.close(), Ai(t, "image/png");
	} catch {
		return null;
	}
}
var Ii = ".glb,.gltf,.fbx,.bvh,.vmd,.bin";
async function Li(e) {
	let t = e.find((e) => [
		"glb",
		"gltf",
		"fbx",
		"bvh",
		"vmd"
	].includes(Di(e.name)));
	if (!t) throw Error("Pick an animation: .fbx, .glb, .gltf, .bvh or .vmd.");
	if (t.size > 2e8) throw Error("That file is over 200 MB; make it smaller first.");
	let n = Di(t.name), r = t.name.replace(/\.[^.]+$/, ""), { manager: i, settled: a, dispose: o } = Ni(e);
	try {
		let e = await t.arrayBuffer();
		if (n === "vmd") {
			let t = Ft(new Uint8Array(e)), n = Bt(t, r);
			if (!n && t.camera.length < 2) throw Error("There is no animation in that file.");
			return {
				bones: It,
				takes: n ? [n] : [],
				vmd: t
			};
		}
		let o, s, c;
		if (n === "bvh") {
			let { BVHLoader: t } = await import("./BVHLoader-DS0mprkY.js"), { skeleton: n, clip: r } = new t(i).parse(new TextDecoder().decode(e));
			o = new ne(), o.add(n.bones[0]), c = new _(n.bones[0]), s = [r];
		} else if (n === "fbx") {
			let { FBXLoader: t } = await import("./FBXLoader-CVEbOFst.js");
			o = new t(i).parse(e, ""), s = o.animations;
		} else {
			let { GLTFLoader: t } = await import("./GLTFLoader-C265XJ9t.js").then((e) => e.n), n = await new t(i).parseAsync(e, "");
			o = n.scene, s = n.animations;
		}
		if (await a(), !s.length) throw Error("There is no animation in that file.");
		let l = Lt(o, s, c);
		if (!l?.takes.length) throw Error("That file has no bones to take a motion from.");
		let u = (e) => !e || /^(mixamo\.com|take\s*\d*|armature\|?.*|animation)$/i.test(e);
		return {
			bones: l.bones,
			takes: l.takes.map((e, t) => u(e.name) ? {
				...e,
				name: l.takes.length > 1 ? `${r} ${t + 1}` : r
			} : e)
		};
	} catch (e) {
		let t = e instanceof Error ? e.message : String(e);
		throw Error(t.startsWith("There is") || t.startsWith("That ") ? t : `That animation could not be read: ${t}`);
	} finally {
		o();
	}
}
async function Ri(e) {
	let t = e.find((e) => Ti.includes(Di(e.name)));
	if (!t) throw Error(`Pick a 3D model: ${Ti.map((e) => `.${e}`).join(", ")}.`);
	if (t.size > 2e8) throw Error("That model is over 200 MB; make it smaller first.");
	let n = Di(t.name), { manager: r, settled: i, dispose: a } = Ni(e);
	try {
		let a, o = [], s = await t.arrayBuffer();
		if (n === "pmx" || n === "pmd") {
			let { asset: n, name: i, warnings: a } = await Rt(new Uint8Array(s), (t) => Fi(e, t, r));
			return {
				asset: Ht(n, i.trim() || t.name.replace(/\.[^.]+$/, "")),
				warnings: [...a, Pi]
			};
		}
		if (n === "glb" || n === "gltf") {
			let [{ GLTFLoader: e }, { DRACOLoader: t }, { MeshoptDecoder: n }] = await Promise.all([
				import("./GLTFLoader-C265XJ9t.js").then((e) => e.n),
				import("./DRACOLoader-BwZW6QkU.js"),
				import("./meshopt_decoder.module-B2eONCO9.js")
			]), i = new e(r), c = new t(r);
			c.setDecoderPath({
				js: Ci,
				wasm: wi
			}), i.setDRACOLoader(c), i.setMeshoptDecoder(n);
			try {
				let e = await i.parseAsync(s, "");
				a = e.scene, o = e.animations;
			} finally {
				c.dispose();
			}
		} else if (n === "fbx") {
			let { FBXLoader: e } = await import("./FBXLoader-CVEbOFst.js");
			a = new e(r).parse(s, ""), o = a.animations;
		} else if (n === "obj") {
			let [{ OBJLoader: t }, { MTLLoader: n }] = await Promise.all([import("./OBJLoader-DE4gLv6U.js"), import("./MTLLoader-DgnhkxGj.js")]), i = new t(r), o = e.find((e) => Di(e.name) === "mtl");
			if (o) {
				let e = new n(r).parse(await o.text(), "");
				e.preload(), i.setMaterials(e);
			}
			a = i.parse(new TextDecoder().decode(s));
		} else if (n === "stl") {
			let { STLLoader: e } = await import("./STLLoader-D0Aftpgw.js"), t = new e(r).parse(s);
			t.computeVertexNormals();
			let n = !!t.getAttribute("color");
			a = new P(t, new ue({
				color: 14210268,
				roughness: .55,
				vertexColors: n
			})), a.rotation.x = -Math.PI / 2;
		} else if (n === "ply") {
			let { PLYLoader: e } = await import("./PLYLoader-DHuVqliz.js"), t = new e(r).parse(s), n = !!t.getAttribute("color");
			a = new P(t, new ue({
				color: 14210268,
				roughness: .55,
				vertexColors: n
			}));
		} else {
			let { ThreeMFLoader: e } = await import("./3MFLoader-Br3zolgJ.js");
			a = new e(r).parse(s);
		}
		await i();
		let { asset: c, warnings: l } = await Ut(a, ji, Mi), u = c.skeleton && o.length ? Lt(a, o)?.takes ?? [] : [];
		return {
			asset: Ht(c, t.name.replace(/\.[^.]+$/, "")),
			warnings: l,
			...u.length ? { takes: u } : {}
		};
	} catch (e) {
		let t = e instanceof Error ? e.message : String(e);
		throw Error(t.startsWith("This model") || t.startsWith("There is") ? t : `That model could not be read: ${t}`);
	} finally {
		a();
	}
}
//#endregion
export { qt as _, Li as a, yi as c, ui as d, Rr as f, Wt as g, Zt as h, Ri as i, ci as l, Wn as m, Ei as n, Si as o, li as p, Ii as r, _i as s, Pi as t, si as u, Jt as v };

//# sourceMappingURL=src-Bvmr4r-R.js.map