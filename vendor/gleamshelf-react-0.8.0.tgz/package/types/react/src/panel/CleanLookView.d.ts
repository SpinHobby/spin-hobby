export type FigureMask = (picture: Blob) => Promise<{
    alpha: Uint8Array;
    width: number;
    height: number;
}>;
/**
 * The drawn clean photo with its backgrounds (a row of them, each shown with the figure on it, and the person's own photo) and its look
 * sliders (brightness, contrast, soft or hard light, matte or glossy, warmth, colour, backdrop): each redraws the picture through a shader in
 * the same frame, and the saved picture is the one shown. Double-click a slider to put it back.
 *
 * `from: 'maker'` is the maker's own photo of the figure (a window box's clean photo: real pixels, nothing redrawn): it goes onto the white
 * studio once the figure is found, since the maker's backdrop is theirs, and the words say so. Its photo is also checked for a logo laid over
 * it (findLogo), told through `onLogo`: where one touches the figure, it stays in the clean photo.
 */
export declare function CleanLookView({ picture, alt, figureMask, from, onLogo, }: {
    picture: Blob;
    alt: string;
    figureMask?: FigureMask;
    from?: 'drawn' | 'maker';
    onLogo?: (logo: {
        found: boolean;
        touching: boolean;
    } | null) => void;
}): import("react").JSX.Element;
