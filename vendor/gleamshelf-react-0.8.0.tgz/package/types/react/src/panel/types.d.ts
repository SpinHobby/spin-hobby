import { type Editor, type PhotoDocument } from '../../../core/src/index.js';
import { type ReactNode } from 'react';
import { type AutoWatch } from '../GleamEditor';
import { type CutoutSettings } from '../CutoutOverlay';
export interface PanelProps {
    /** Leaves out every control that needs the Gleamshelf app (One click, the AI slots, price stickers): GleamEditorProps.handToolsOnly. */
    handToolsOnly?: boolean;
    /** The app on this computer is reached: with handToolsOnly, everything is offered after all (a website visitor who runs the app). */
    appReady?: boolean;
    /** The free website's "cloud AI isn't available yet" for a tool by name (NoCloudAi), shown in place of One click and price stickers. */
    appNotice?: (feature: string) => ReactNode;
    editor: Editor;
    doc: PhotoDocument;
    cropping: boolean;
    onToggleCrop: () => void;
    cutout: boolean;
    onToggleCutout: () => void;
    cutSettings: CutoutSettings;
    onCutSettings: (change: Partial<CutoutSettings>) => void;
    /** Frames the cut-out product on a square canvas. Only offered once something is cut out. */
    onFitProduct: () => void;
    /** White background, centred on a square, soft shadow: a listing-ready picture in one click. */
    onStudio?: () => void;
    /** Straightens a card or box front photographed at an angle, from its cut-out's four corners. */
    flatten?: {
        run: () => void;
        busy: boolean;
        note: string | null;
    };
    /** Every marketplace's picture from this one cut-out, saved together as a zip. */
    listingSet?: {
        run: (presetIds: string[]) => void;
        busy: boolean;
        note: string | null;
    };
    /** Called with a photo the user chose to put behind the product. */
    onBackgroundPhoto: (file: File) => void;
    /** Whether a background photo is loaded, so choosing "Photo" has something to show. */
    hasBackgroundPhoto: boolean;
    backgroundName?: string;
    /** The AI cut-out controls, shown under the cut-out tools. */
    aiCutout?: ReactNode;
    hasCutout?: boolean;
    /** Whether the lettering is being worked out right now, and how many pixels it painted over. */
    lettering?: {
        busy: boolean;
        filled: number;
        aiReady: boolean;
    };
    /** Turns the lettering removal on, and fills with AI straight away when a fill model is available. */
    onRemoveLettering?: () => void;
    /** Whether AI steps also make the picture brighter and sharper, and how to change that. */
    autoEnhance?: boolean;
    onAutoEnhance?: (on: boolean) => void;
    /** The AI fill controls, shown under the lettering settings. */
    aiFill?: ReactNode;
    /** The AI sharpen-and-enlarge controls, shown in the Look section. */
    aiEnlarge?: ReactNode;
    /** The AI redraw controls (complete the antenna, redraw an area), shown in their own section. */
    aiFinish?: ReactNode;
    /** The price sticker button. */
    stickers?: {
        run: () => void;
        busy: boolean;
        note: string | null;
        picking: boolean;
        setPicking: (on: boolean) => void;
        pickingText?: boolean;
        setPickingText?: (on: boolean) => void;
    };
    /** Opens the guide to every feature. */
    onOpenGuide?: () => void;
    /** The one-button chain. */
    auto?: {
        run: () => void;
        busy: boolean;
        mode: 'product' | 'character' | 'auto';
        setMode: (mode: 'product' | 'character' | 'auto') => void;
        steps: {
            label: string;
            state: 'todo' | 'running' | 'done' | 'skipped';
            note?: string;
            startedAt?: number;
            seconds?: number;
        }[] | null;
        /** A run in the companion app: its signs of life, for the live indicator. */
        watch?: AutoWatch | null;
        /** How the last run ended when it did not finish (failed, or stopped by the person), and how to clear that. */
        end?: {
            kind: 'failed' | 'stopped';
            message: string;
        } | null;
        dismissEnd?: () => void;
        /** The slow extra sharpening with the tile model: whether it is set up, and whether it is switched on. */
        detail?: {
            available: boolean;
            on: boolean;
            set: (on: boolean) => void;
        };
        /** Studio gloss: the product redrawn by AI. Off unless ticked; it changes the product. */
        gloss?: {
            available: boolean;
            on: boolean;
            set: (on: boolean) => void;
        };
        appReady: boolean;
        greenBackdrop: boolean;
        /** The app can run the whole chain itself (the same as the batch command): its options, and what the last run reported. */
        full?: {
            available: boolean;
            /** Every step of the chain, in order, each switchable and on by default. */
            steps: {
                key: string;
                label: string;
                title: string;
                on: boolean;
                disabled: boolean;
            }[];
            setStep: (key: string, on: boolean) => void;
            /** One-click sets of the steps ("As photographed" keeps the product's own pixels). */
            presets?: {
                key: 'asPhotographed' | 'everything';
                label: string;
                title: string;
                active: boolean;
                apply: () => void;
            }[];
            report: {
                notes: string[];
                flags: string[];
                modeUsed: string;
                lookup?: {
                    state: 'off' | 'found' | 'no-match' | 'no-pictures';
                    read: string | null;
                    detail: string;
                };
                listing: {
                    title: string;
                    description: string;
                    category: string;
                    series: string | null;
                    highlights: string[];
                    unsupported: string[];
                    unverifiedNumbers: string[];
                    sources: string[];
                } | null;
                quality?: {
                    cutout: {
                        score: number;
                        reasons: string[];
                    };
                    fidelity: {
                        original: number;
                    };
                };
                health?: {
                    score: number;
                    level: 'good' | 'fair' | 'poor';
                    checks: {
                        id: string;
                        ok: boolean;
                        label: string;
                    }[];
                    fixes: string[];
                };
                changesUrl?: string;
                /** The product on a studio sweep, when the run made one. */
                promoUrl?: string;
                /** The app's id for this run: what is sent to the shop. */
                runId?: string;
            } | null;
            /** Set while the picture open is the chain's result: goes back to the photo as it was. */
            goBack?: () => void;
            /** Finished runs the app kept: each opens again instantly (no waiting, no internet). */
            recent?: {
                runs: {
                    id: string;
                    title: string;
                    finishedAt: number;
                    health: number | null;
                    thumb?: string;
                }[];
                open: (id: string) => void;
            };
            /** The connected shop: a finished run goes there as a draft (see ShopSend). Missing when the app cannot send to a shop. */
            shop?: ShopLinkProps;
            /** Opens 3D mode's ad maker with the run's cut-out, title and series. Missing when the run kept no cut-out. */
            makeAd?: () => Promise<void>;
            /** Opens 3D mode's From photos with the run's cut-out and what was read off the box (a 3D model of the figure). Missing without a cut-out. */
            make3d?: () => Promise<void>;
            /** Clean product photo for this run's photo (see CleanPhoto). Missing when the run's photo is not at hand (a run opened from before). */
            cleanPhoto?: CleanPhotoProps;
            /** What the run found online: shown before any of it is used, while the run waits for the person (see FoundPhotos). */
            found?: FoundPhotosProps | null;
        };
    };
}
export interface CleanPhotoProps {
    /** The redraw model is set up on this computer; when not, the card shows how to set it up (the maker's photo needs no model). */
    ready: boolean;
    /** The command that sets the model up. */
    setup: string;
    /**
     * Draws the clean photo from the run's photo; a different seed draws a different take. With `refs` (the maker's photos of the figure out
     * of its box, the first one full-body) the figure is drawn from those instead, for a window box whose plastic hides her legs and face.
     */
    make: (backdrop: CleanBackdrop, seed: number, refs: string[]) => Promise<Blob>;
    /** The run's pictures found online that show the figure out of its box: ticked to start with, the run's own `found-<n>` ids. */
    official: {
        ref: string;
        thumb?: string;
        title?: string;
        page?: string;
    }[];
    /** Keeps a maker's photo the person adds on this computer and answers its ref. */
    addReference: (picture: Blob) => Promise<string>;
    /** One of the maker's photos (a ref from `official` or addReference), full size: a window box's clean photo is it, cut out. */
    makerPhoto: (ref: string) => Promise<Blob>;
    /** The figure's mask in a drawn picture (the app's cut-out model), so the look sliders can light the figure and the backdrop apart. */
    figureMask?: (picture: Blob) => Promise<{
        alpha: Uint8Array;
        width: number;
        height: number;
    }>;
}
/** The app's own backdrops: the green cloth behind the shop's photos is only for keying, never kept. */
export type CleanBackdrop = 'artwork' | 'dark' | 'white';
export interface FoundPhotosProps {
    identity: {
        printedTitle: string | null;
        character: string | null;
        franchise: string | null;
        maker?: string | null;
        variant?: string | null;
    } | null;
    photos: {
        index: number;
        purpose: 'product' | 'unboxed';
        linesUp: boolean;
        shows?: 'box' | 'figure';
        inliers: number;
        page?: string;
        title?: string;
        thumb?: string;
    }[];
    ticked: number[];
    /** The run waits for the choice; false once it has gone. */
    waiting: boolean;
    toggle: (index: number) => void;
    use: () => void;
    skip: () => void;
}
export type ShopStatus = {
    connected: false;
} | {
    connected: true;
    url: string;
    label: string;
    answering: boolean;
};
export interface ShopLinkProps {
    status: () => Promise<ShopStatus>;
    connect: (address: string, code: string) => Promise<{
        url: string;
        label: string;
    }>;
    send: (id: string) => Promise<{
        sent: 'new' | 'replaced' | 'kept';
        status: string;
        shop: string;
    }>;
}
