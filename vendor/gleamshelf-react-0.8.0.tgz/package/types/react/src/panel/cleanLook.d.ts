/**
 * The look of a clean product photo, changed after it is drawn: one WebGL2 fragment shader over the drawn picture, so every slider answers
 * at once (a new take is minutes away; this is a frame). The picture is drawn with plain, even light (cleanphoto.py LIGHT) for these to start
 * from. Blurs come from the picture's mipmaps, so nothing is computed ahead but the mipmaps themselves.
 *
 * With the figure's mask (the app's cut-out model) "Light" and "Shine" act on the figure alone and "Backdrop" on the rest; without it they
 * act on the whole picture and "Backdrop" is not offered.
 *
 * The mask also lets the figure go on another background (BACKGROUNDS, or the person's own photo), like Photoroom. The shadow the model drew
 * under her goes with her: it is read off the drawn floor (how much darker it is beside her feet than further out) and laid on the new one.
 * Shadow controls are not here (issue #13, Shadow studio).
 */
export interface CleanLook {
    /** -100 darker to 100 brighter: ±1.5 stops. */
    brightness: number;
    /** -100 flatter to 100 punchier. */
    contrast: number;
    /** -100 soft (flat, wrapped) to 100 hard (deep shading): the figure's large-scale shading, its small detail kept. */
    light: number;
    /** -100 matte to 100 glossy: its highlights pulled down to the surface round them, or brightened with a little glow. */
    shine: number;
    /** -100 cool to 100 warm. */
    warmth: number;
    /** -100 muted to 100 vivid. */
    colour: number;
    /** -100 darker to 100 lighter: the backdrop alone (needs the figure's mask). */
    backdrop: number;
}
export declare const PLAIN_LOOK: CleanLook;
/** The sliders, in the order they are shown: which end is which, in words. */
export declare const LOOK_SLIDERS: {
    key: keyof CleanLook;
    label: string;
    low: string;
    high: string;
    needsMask?: boolean;
}[];
/** The shader's numbers for a look: each slider's -100..100 as the -1..1 the shader takes (brightness in stops). */
export declare function lookUniforms(look: CleanLook): {
    uExposure: number;
    uContrast: number;
    uLight: number;
    uShine: number;
    uWarmth: number;
    uColour: number;
    uBackdrop: number;
};
/** Whether a look changes anything (a plain one saves the drawn picture as it is). */
export declare const isPlainLook: (look: CleanLook) => boolean;
/**
 * Mip levels to blur at for a picture this size: "small" is about 1/48 of its longest side (a highlight's surroundings), "large" about 1/10
 * (the figure's broad shading), "top" the whole picture's average.
 */
export declare function blurLevels(width: number, height: number): {
    small: number;
    large: number;
    top: number;
};
export type BackgroundKind = 'drawn' | 'sweep' | 'gradient' | 'spot' | 'photo';
/**
 * A background the figure can go on. `colours` are the picture's own colours (not the editor's theme): a sweep's wall then floor, a
 * gradient's top then bottom, a spotlight's light then its dark.
 */
export interface Background {
    id: string;
    label: string;
    kind: BackgroundKind;
    colours?: [string, string];
}
export declare const BACKGROUNDS: Background[];
/** A colour as the shader takes it: red, green and blue from 0 to 1 (still sRGB). */
export declare function rgb(hex: string): [number, number, number];
/**
 * Where the figure stands, from its mask, as shares of the picture: her feet (the middle of her lowest tenth, and its bottom) and her size.
 * Null when the mask is empty.
 */
export declare function figureBounds(alpha: Uint8Array, width: number, height: number): {
    feet: [number, number];
    size: [number, number];
} | null;
/** How a photo of this shape covers a picture of that shape, centred: the scale and offset of the picture's place in the photo. */
export declare function coverTransform(photo: {
    width: number;
    height: number;
}, picture: {
    width: number;
    height: number;
}): [number, number, number, number];
/**
 * Whether a maker's photo carries a logo laid over it (the 一番くじ diamond on 1kuji's product photos), and whether it touches the figure.
 * Such a logo is a flat fill of one grey, semi-transparent: on the photo's plain light backdrop many pixels near the figure share one
 * exact grey, where a shadow fades through many. Where it touches her, it lies over her too, and stays in the clean photo.
 *
 * Measured on the window boxes' maker's photos (2026-11-18): the logo photos (IMG_9065 Rem B, IMG_9071 Murasame) put 2.3% and 3.6% of the
 * backdrop near her on one grey and 82 and 91 of those pixels against her; Yoshiko's (IMG_9094) logo, 1.2% beside her shoes, touched her
 * nowhere; the clean ones stayed at or under 0.09%. Dark, grey or textured backdrops (Godzilla's sky, Anya's marble) are not judged.
 *
 * `rgba` and `alpha` (the figure's mask) are the same size, best about 512 pixels across.
 */
export declare function findLogo(rgba: ArrayLike<number>, alpha: ArrayLike<number>, width: number, height: number): {
    found: boolean;
    touching: boolean;
} | null;
export declare const LOOK_FRAGMENT = "#version 300 es\nprecision highp float;\nin vec2 vUv;\nout vec4 outColor;\nuniform sampler2D uImage;\nuniform sampler2D uMask;\nuniform bool uHasMask;\nuniform float uLodSmall;\nuniform float uLodLarge;\nuniform float uLodTop;\nuniform float uExposure;\nuniform float uContrast;\nuniform float uLight;\nuniform float uShine;\nuniform float uWarmth;\nuniform float uColour;\nuniform float uBackdrop;\nuniform int uBgKind;\nuniform vec3 uBgTop;\nuniform vec3 uBgBottom;\nuniform vec2 uFeet;\nuniform vec2 uFigure;\nuniform float uAspect;\nuniform sampler2D uPhoto;\nuniform vec4 uPhotoXf;\nuniform float uCarryShadow;\n\nvec3 toLinear(vec3 c) { return pow(max(c, 0.0), vec3(2.2)); }\nvec3 toDisplay(vec3 c) { return pow(max(c, 0.0), vec3(1.0 / 2.2)); }\nfloat luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }\n// a blur from the mipmaps, two levels mixed so it has no blocky steps\nvec3 blurAt(float lod) {\n  return toLinear(mix(textureLod(uImage, vUv, lod).rgb, textureLod(uImage, vUv, lod + 1.0).rgb, 0.5));\n}\n\nfloat lumaAt(vec2 at, float lod) { return luma(toLinear(textureLod(uImage, at, lod).rgb)); }\n\n// the new background at this pixel\nvec3 background() {\n  vec3 a = toLinear(uBgTop);\n  vec3 b = toLinear(uBgBottom);\n  if (uBgKind == 1) {\n    // a sweep: the wall curving into the floor a little above her feet, a touch darker to the sides\n    float h = uFeet.y - 0.25 * uFigure.y;\n    vec3 col = mix(a, b, smoothstep(h - 0.18, h + 0.12, vUv.y));\n    float side = (vUv.x - 0.5) * 2.0;\n    return col * (1.0 - 0.07 * side * side);\n  }\n  if (uBgKind == 2) return mix(a, b, smoothstep(0.0, 1.0, vUv.y));\n  if (uBgKind == 3) {\n    // a spotlight on the wall behind her, falling off into the dark\n    vec2 d = (vUv - vec2(uFeet.x, uFeet.y - 0.55 * uFigure.y)) * vec2(uAspect, 1.0);\n    return mix(a, b, smoothstep(0.08, 0.8, length(d)));\n  }\n  if (uBgKind == 4) return toLinear(textureLod(uPhoto, vUv * uPhotoXf.xy + uPhotoXf.zw, 1.2).rgb);\n  return vec3(0.0);\n}\n\n// the shadow the model drew under her, as how much darker the floor is here than the floor well to either side at the same height\nfloat drawnShadow() {\n  vec2 rel = (vUv - uFeet) / vec2(max(uFigure.x, 0.05) * 0.8, max(uFigure.y, 0.05) * 0.12);\n  float near = 1.0 - smoothstep(0.55, 1.0, length(rel));\n  if (near <= 0.0) return 1.0;\n  float here = lumaAt(vUv, 1.0);\n  float dx = max(uFigure.x, 0.05) * 0.95;\n  // the darker side, so a bokeh light on one side is not taken for floor\n  float beside = min(lumaAt(vec2(vUv.x - dx, vUv.y), uLodSmall), lumaAt(vec2(vUv.x + dx, vUv.y), uLodSmall));\n  return mix(1.0, clamp(here / max(beside, 0.001), 0.25, 1.0), near);\n}\n\nvoid main() {\n  vec3 c = toLinear(texture(uImage, vUv).rgb);\n  float figure = uHasMask ? texture(uMask, vUv).r : 1.0;\n\n  // Light, soft to hard: the broad shading (the large blur against the whole picture's average) scaled in log, so detail stays as it is\n  float broad = luma(blurAt(uLodLarge)) + 0.002;\n  float whole = luma(toLinear(textureLod(uImage, vUv, uLodTop).rgb)) + 0.002;\n  float away = log(broad) - log(whole);\n  // softer light mostly opens the shadows (pulling the bright parts down as far greyed a white skirt)\n  if (uLight < 0.0) away = min(away, 0.0) + 0.3 * max(away, 0.0);\n  float shade = exp(away * uLight);\n  vec3 fig = c * shade;\n\n  // Shine, matte to glossy. A highlight is a spot much brighter than the surface round it (in proportion, so a white skirt is not one):\n  // glossy makes those spots brighter and the bright surface round them crisper, matte pulls them down to that surface\n  vec3 round3 = blurAt(uLodSmall) * shade;\n  float lum = luma(fig);\n  float around = luma(round3);\n  float highlight = smoothstep(0.12, 0.6, lum) * smoothstep(0.08, 0.5, (lum - around) / max(around, 0.03));\n  if (uShine > 0.0) {\n    float sheen = smoothstep(0.25, 0.7, lum);\n    fig = mix(fig, round3 + (fig - round3) * 1.8, sheen * uShine * 0.6);\n    fig *= 1.0 + highlight * uShine * 0.9;\n  } else {\n    fig = mix(fig, fig * clamp(around / max(lum, 0.001), 0.0, 1.0) * 1.06, highlight * -uShine);\n  }\n  // a soft shoulder, so brightened whites keep their folds instead of turning flat white\n  // (only as far as shine or light are moved: as drawn stays as drawn)\n  float pushed = clamp(max(uShine, 0.0) + abs(uLight), 0.0, 1.0);\n  fig = mix(fig, 0.8 + 0.2 * (1.0 - exp(-(fig - 0.8) / 0.2)), step(0.8, fig) * pushed);\n  bool swapped = uBgKind != 0 && uHasMask;\n  vec3 behind = swapped ? background() * (uCarryShadow > 0.5 ? drawnShadow() : 1.0) : c;\n  // on another background the mask's soft edge still holds the drawn backdrop's colour (a pale rim on a dark one): a tighter edge there\n  float keep = swapped ? smoothstep(0.3, 0.85, figure) : figure;\n  c = mix(behind, max(fig, 0.0), keep);\n\n  // Backdrop, darker to lighter: everything but the figure\n  c *= mix(exp2(uBackdrop * 1.3), 1.0, figure);\n\n  // the whole picture: brightness, warmth, colour\n  c *= exp2(uExposure);\n  c *= vec3(1.0 + 0.12 * uWarmth, 1.0 + 0.02 * uWarmth, 1.0 - 0.14 * uWarmth);\n  float l = luma(c);\n  c = max(mix(vec3(l), c, 1.0 + 0.8 * uColour), 0.0);\n\n  // contrast, on the displayed values: an S-curve up, towards the middle down\n  vec3 d = clamp(toDisplay(c), 0.0, 1.0);\n  d = uContrast >= 0.0 ? mix(d, d * d * (3.0 - 2.0 * d), uContrast) : mix(d, vec3(0.5), -0.45 * uContrast);\n  outColor = vec4(clamp(d, 0.0, 1.0), 1.0);\n}";
/** Draws a picture through the look shader onto a canvas the picture's size. Throws when the browser has no WebGL2. */
export declare class LookRenderer {
    readonly canvas: HTMLCanvasElement;
    private gl;
    private program;
    private image;
    private mask;
    private photo;
    /**
     * Whether the floor's darkening by her feet goes onto a new background (a drawn picture: the model's shadow). Not for the maker's photo:
     * there it is mostly the stand or base the cut-out left behind (Luffy's plank base came out as a grey smear, IMG_9103, 2026-11-18).
     */
    carryShadow: boolean;
    private photoXf;
    private bounds;
    private size;
    private where;
    constructor(canvas: HTMLCanvasElement, picture: TexImageSource & {
        width: number;
        height: number;
    });
    /** The figure's mask (255 is the figure), any size: stretched over the picture. */
    setMask(alpha: Uint8Array, width: number, height: number): void;
    /** Whether the figure was found, so it can go on another background. */
    get canSwap(): boolean;
    /** A photo of the person's own to put behind the figure (BACKGROUNDS' kind 'photo'), covering the picture, a little soft. */
    setPhoto(photo: TexImageSource & {
        width: number;
        height: number;
    }): void;
    render(look: CleanLook, background?: Background): void;
    /** The picture as drawn now, full size, as a PNG. */
    toBlob(): Promise<Blob>;
    dispose(): void;
}
