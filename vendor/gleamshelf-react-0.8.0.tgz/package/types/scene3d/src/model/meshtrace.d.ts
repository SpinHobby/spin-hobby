import { type ModelDocument, type Vec3 } from './document.js';
import type { DecodedPicture, DecodePicture } from './meshcpu.js';
/**
 * Imported models for the photo-real render (TRACE_FRAGMENT in glsl.ts): every triangle placed in the scene, in a bounding volume hierarchy
 * the shader walks to find the nearest triangle along a ray. Packed as float texels: a node is 2 (its box's low corner and its first child or
 * first triangle; its high corner and its triangle count, 0 for a node with children, which sit side by side), a triangle TRI_TEXELS
 * (corners and material, normals and texture coordinates, colours, and how its surface runs along the picture's u and v, for normal maps). Materials (at most MAX_TRACE_MATERIALS) are TRACE_MAT_TEXELS
 * texels each of a float texture; their pictures are layers of one texture (at most MAX_TRACE_PICTURES; the same picture in two models is
 * one layer). `traceMeshCpu` walks it the same way, for tests.
 */
export declare const TRI_TEXELS = 12;
export declare const MAX_TRACE_MATERIALS = 1024;
export declare const MAX_TRACE_PICTURES = 256;
export declare const TRACE_MAT_TEXELS = 4;
export interface TraceMaterial {
    /** Linear colour, multiplied by the picture and the points' colours. */
    color: Vec3;
    /** The colour picture's layer, or -1. */
    picture: number;
    metal: number;
    rough: number;
    /** How much light passes through (glass). */
    glass: number;
    /** Light it gives off (linear), and the picture scaling it (its layer, -1 none). */
    glow: Vec3;
    glowPicture?: number;
    /** Its normal map's layer (-1 none) and strength. */
    normalPicture: number;
    normalScale: number;
    /**
     * Its own look, as the shader's codes (TRACE_LOOK): toon and flat are painted with their steps of the light that reaches them, clay is
     * matte grey, unlit shows its colours as they are, physical is traced as light really goes; left out, the design's look.
     */
    look?: number;
    /** Toon: its steps of light (left out: the design's). */
    bands?: number;
}
/** The photo-real render's codes for a material's own look (0: physical; -1, the uniform's when left out: the design's). */
export declare const TRACE_LOOK: {
    readonly soft: 0;
    readonly toon: 1;
    readonly flat: 2;
    readonly clay: 3;
    readonly unlit: 4;
};
export interface TraceMesh {
    nodes: Float32Array;
    tris: Float32Array;
    nodeCount: number;
    triCount: number;
    materials: TraceMaterial[];
    pictures: DecodedPicture[];
}
/** The design's imported models ready for the photo-real render; null when it has none. */
export declare function buildTraceMesh(doc: Pick<ModelDocument, 'shapes' | 'assets'>, decode?: DecodePicture): Promise<TraceMesh | null>;
/** The nearest triangle along a ray before `tMax`, walking the hierarchy as the shader's meshHit does: distance, index, barycentric (u, v). */
export declare function traceMeshCpu(m: TraceMesh, ro: Vec3, rd: Vec3, tMax?: number): {
    t: number;
    tri: number;
    u: number;
    v: number;
} | null;
/**
 * How a triangle's surface runs along its picture: the change in position per unit of u and per unit of v (zero when its texture coordinates
 * are all one point). The shader turns a normal map's colour into a normal with them, as the quick drawing does (mappedNormal in glsl.ts).
 */
export declare function tangents(P: Vec3[], U: [number, number][]): [Vec3, Vec3];
