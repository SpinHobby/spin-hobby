import { n as e } from "./rolldown-runtime-DArdT4gl.js";
import { a as t, c as n, i as r, l as i, s as a, t as o, u as s } from "./Panel-CgSJeSmD.js";
import { useCallback as c, useEffect as l, useMemo as u, useRef as d, useState as f } from "react";
import { Fragment as ee, jsx as p, jsxs as m } from "react/jsx-runtime";
//#region ../craft/src/worker.ts?worker&inline
var h = "(function(){var e=class{__destroy_into_raw(){let e=this.__wbg_ptr;return this.__wbg_ptr=0,l.unregister(this),e}free(){let e=this.__destroy_into_raw();E.__wbg_developsource_free(e,0)}constructor(e,t,n){let r=v(n,E.__wbindgen_malloc),i=T,a=E.developsource_new(e,t,r,i);if(a[2])throw b(a[1]);return this.__wbg_ptr=a[0],l.register(this,this.__wbg_ptr,this),this}render(e,t,r,i){let a=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),o=T,s=E.developsource_render(this.__wbg_ptr,a,o,t,r,i);if(s[2])throw b(s[1]);return n.__wrap(s[0])}};Symbol.dispose&&(e.prototype[Symbol.dispose]=e.prototype.free);var t=class{__destroy_into_raw(){let e=this.__wbg_ptr;return this.__wbg_ptr=0,u.unregister(this),e}free(){let e=this.__destroy_into_raw();E.__wbg_photosession_free(e,0)}active_rgba(){let e=E.photosession_active_rgba(this.__wbg_ptr);if(e[2])throw b(e[1]);return n.__wrap(e[0])}commands(){let e,t;try{let i=E.photosession_commands(this.__wbg_ptr);var n=i[0],r=i[1];if(i[3])throw n=0,r=0,b(i[2]);return e=n,t=r,h(n,r)}finally{E.__wbindgen_free(e,t,1)}}composite(){let e=E.photosession_composite(this.__wbg_ptr);if(e[2])throw b(e[1]);return n.__wrap(e[0])}disabled_reason(e){let t=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),n=T,r=E.photosession_disabled_reason(this.__wbg_ptr,t,n),i;return r[0]!==0&&(i=h(r[0],r[1]),E.__wbindgen_free(r[0],r[1]*1,1)),i}execute(e,t){let n,r;try{let o=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),s=T,c=y(t,E.__wbindgen_malloc,E.__wbindgen_realloc),l=T,u=E.photosession_execute(this.__wbg_ptr,o,s,c,l);var i=u[0],a=u[1];if(u[3])throw i=0,a=0,b(u[2]);return n=i,r=a,h(i,a)}finally{E.__wbindgen_free(n,r,1)}}export(e,t){let n=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),r=T,i=y(t,E.__wbindgen_malloc,E.__wbindgen_realloc),a=T,o=E.photosession_export(this.__wbg_ptr,n,r,i,a);if(o[3])throw b(o[2]);var s=f(o[0],o[1]).slice();return E.__wbindgen_free(o[0],o[1]*1,1),s}height(){return E.photosession_height(this.__wbg_ptr)>>>0}constructor(){let e=E.photosession_new();return this.__wbg_ptr=e,u.register(this,this.__wbg_ptr,this),this}open(e,t){let n,r;try{let o=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),s=T,c=v(t,E.__wbindgen_malloc),l=T,u=E.photosession_open(this.__wbg_ptr,o,s,c,l);var i=u[0],a=u[1];if(u[3])throw i=0,a=0,b(u[2]);return n=i,r=a,h(i,a)}finally{E.__wbindgen_free(n,r,1)}}open_rgba(e,t,n,r){let i=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),a=T,o=v(r,E.__wbindgen_malloc),s=T,c=E.photosession_open_rgba(this.__wbg_ptr,i,a,t,n,o,s);if(c[1])throw b(c[0])}place_rgba(e,t,n,r,i,a){let o=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),s=T,c=v(a,E.__wbindgen_malloc),l=T,u=E.photosession_place_rgba(this.__wbg_ptr,o,s,t,n,r,i,c,l);if(u[1])throw b(u[0])}redo(){return E.photosession_redo(this.__wbg_ptr)!==0}replace_active_rgba(e,t,n,r){let i=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),a=T,o=v(r,E.__wbindgen_malloc),s=T,c=E.photosession_replace_active_rgba(this.__wbg_ptr,i,a,t,n,o,s);if(c[1])throw b(c[0])}revision(){let e=E.photosession_revision(this.__wbg_ptr);return BigInt.asUintN(64,e)}selection(){let e=E.photosession_selection(this.__wbg_ptr);return e===0?void 0:n.__wrap(e)}undo(){return E.photosession_undo(this.__wbg_ptr)!==0}width(){return E.photosession_width(this.__wbg_ptr)>>>0}};Symbol.dispose&&(t.prototype[Symbol.dispose]=t.prototype.free);var n=class e{static __wrap(t){let n=Object.create(e.prototype);return n.__wbg_ptr=t,d.register(n,n.__wbg_ptr,n),n}__destroy_into_raw(){let e=this.__wbg_ptr;return this.__wbg_ptr=0,d.unregister(this),e}free(){let e=this.__destroy_into_raw();E.__wbg_picture_free(e,0)}get height(){return E.picture_height(this.__wbg_ptr)>>>0}take(){let e=E.picture_take(this.__wbg_ptr);var t=f(e[0],e[1]).slice();return E.__wbindgen_free(e[0],e[1]*1,1),t}get width(){return E.picture_width(this.__wbg_ptr)>>>0}};Symbol.dispose&&(n.prototype[Symbol.dispose]=n.prototype.free);function r(e,t,n){let r,i;try{let s=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),c=T,l=y(t,E.__wbindgen_malloc,E.__wbindgen_realloc),u=T,d=E.develop_apply_preset(s,c,l,u,n);var a=d[0],o=d[1];if(d[3])throw a=0,o=0,b(d[2]);return r=a,i=o,h(a,o)}finally{E.__wbindgen_free(r,i,1)}}function i(){let e,t;try{let n=E.develop_controls();return e=n[0],t=n[1],h(n[0],n[1])}finally{E.__wbindgen_free(e,t,1)}}function a(){let e,t;try{let n=E.develop_defaults();return e=n[0],t=n[1],h(n[0],n[1])}finally{E.__wbindgen_free(e,t,1)}}function o(){let e,t;try{let n=E.develop_presets();return e=n[0],t=n[1],h(n[0],n[1])}finally{E.__wbindgen_free(e,t,1)}}function s(e,t,n){let r,i;try{let s=y(e,E.__wbindgen_malloc,E.__wbindgen_realloc),c=T,l=y(t,E.__wbindgen_malloc,E.__wbindgen_realloc),u=T,d=E.develop_set(s,c,l,u,n);var a=d[0],o=d[1];if(d[3])throw a=0,o=0,b(d[2]);return r=a,i=o,h(a,o)}finally{E.__wbindgen_free(r,i,1)}}function c(){return{__proto__:null,\"./gleamshelf_craft_bg.js\":{__proto__:null,__wbg___wbindgen_throw_41e9ee4f547fc59a:function(e,t){throw Error(h(e,t))},__wbg_error_757e9472f8410341:function(e,t){let n,r;try{n=e,r=t,console.error(h(e,t))}finally{E.__wbindgen_free(n,r,1)}},__wbg_new_227d7c05414eb861:function(){return/* @__PURE__ */ Error()},__wbg_stack_3b0d974bbf31e44f:function(e,t){let n=t.stack,r=y(n,E.__wbindgen_malloc,E.__wbindgen_realloc),i=T;m().setInt32(e+4,i,!0),m().setInt32(e+0,r,!0)},__wbindgen_generic_0000000000000001:function(e,t){return h(e,t)},__wbindgen_init_externref_table:function(){let e=E.__wbindgen_externrefs,t=e.grow(4);e.set(0,void 0),e.set(t+0,void 0),e.set(t+1,null),e.set(t+2,!0),e.set(t+3,!1)}}}}let l=typeof FinalizationRegistry>`u`?{register:()=>{},unregister:()=>{}}:new FinalizationRegistry(e=>E.__wbg_developsource_free(e,1)),u=typeof FinalizationRegistry>`u`?{register:()=>{},unregister:()=>{}}:new FinalizationRegistry(e=>E.__wbg_photosession_free(e,1)),d=typeof FinalizationRegistry>`u`?{register:()=>{},unregister:()=>{}}:new FinalizationRegistry(e=>E.__wbg_picture_free(e,1));function f(e,t){return e>>>=0,_().subarray(e/1,e/1+t)}let p=null;function m(){return(p===null||p.buffer.detached===!0||p.buffer.detached===void 0&&p.buffer!==E.memory.buffer)&&(p=new DataView(E.memory.buffer)),p}function h(e,t){return C(e>>>0,t)}let g=null;function _(){return(g===null||g.byteLength===0)&&(g=new Uint8Array(E.memory.buffer)),g}function v(e,t){let n=t(e.length*1,1)>>>0;return _().set(e,n/1),T=e.length,n}function y(e,t,n){if(n===void 0){let n=w.encode(e),r=t(n.length,1)>>>0;return _().subarray(r,r+n.length).set(n),T=n.length,r}let r=e.length,i=t(r,1)>>>0,a=_(),o=0;for(;o<r;o++){let t=e.charCodeAt(o);if(t>127)break;a[i+o]=t}if(o!==r){o!==0&&(e=e.slice(o)),i=n(i,r,r=o+e.length*3,1)>>>0;let t=_().subarray(i+o,i+r),a=w.encodeInto(e,t);o+=a.written,i=n(i,r,o,1)>>>0}return T=o,i}function b(e){let t=E.__wbindgen_externrefs.get(e);return E.__externref_table_dealloc(e),t}let x=new TextDecoder(`utf-8`,{ignoreBOM:!0,fatal:!0});x.decode();let S=0;function C(e,t){return S+=t,S>=2146435072&&(x=new TextDecoder(`utf-8`,{ignoreBOM:!0,fatal:!0}),x.decode(),S=t),x.decode(_().subarray(e,e+t))}let w=new TextEncoder;`encodeInto`in w||(w.encodeInto=function(e,t){let n=w.encode(e);return t.set(n),{read:e.length,written:n.length}});let T=0,E;function D(e,t){return E=e.exports,p=null,g=null,E.__wbindgen_start(),E}async function O(e,t){if(typeof Response==`function`&&e instanceof Response){if(!e.ok)throw Error(`failed to fetch Wasm: ${e.status} ${e.statusText} fetching '${e.url}'`);if(typeof WebAssembly.instantiateStreaming==`function`)try{return await WebAssembly.instantiateStreaming(e,t)}catch(t){if(n(e.type)&&e.headers.get(`Content-Type`)!==`application/wasm`)console.warn(\"`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\\n\",t);else throw t}let r=await e.arrayBuffer();return await WebAssembly.instantiate(r,t)}{let n=await WebAssembly.instantiate(e,t);return n instanceof WebAssembly.Instance?{instance:n,module:e}:n}function n(e){switch(e){case`basic`:case`cors`:case`default`:return!0}return!1}}async function k(e){if(E!==void 0)return E;if(e!==void 0&&(Object.getPrototypeOf(e)===Object.prototype?{module_or_path:e}=e:console.warn(`using deprecated parameters for the initialization function; pass a single object instead`)),e===void 0)throw Error(`Pass the WebAssembly URL to init().`);let t=c();(typeof e==`string`||typeof Request==`function`&&e instanceof Request||typeof URL==`function`&&e instanceof URL)&&(e=fetch(e));let{instance:n,module:r}=await O(await e,t);return D(n,r)}let A=null,j=null,M=null,N=()=>j??=new t,P=e=>{let t={width:e.width,height:e.height,rgba:e.take()};return e.free(),t},F=e=>e?JSON.parse(e):null;async function I(t){if(t.op===`init`)return A??=k({module_or_path:t.wasmUrl}),await A,null;if(!A)throw Error(`Photo lab has not started yet.`);switch(await A,t.op){case`open`:return F(N().open(t.name,t.bytes));case`openRgba`:return N().open_rgba(t.name,t.pic.width,t.pic.height,t.pic.rgba);case`execute`:return F(N().execute(t.id,JSON.stringify(t.params??{})));case`commands`:return F(N().commands());case`disabledReason`:return N().disabled_reason(t.id)??null;case`undo`:return N().undo();case`redo`:return N().redo();case`info`:{let e=N();return{revision:Number(e.revision()),width:e.width(),height:e.height()}}case`composite`:return P(N().composite());case`selection`:{let e=N().selection();return e?P(e):null}case`activeRgba`:return P(N().active_rgba());case`place`:return N().place_rgba(t.name,t.x,t.y,t.pic.width,t.pic.height,t.pic.rgba);case`replaceActive`:return N().replace_active_rgba(t.label,t.pic.width,t.pic.height,t.pic.rgba);case`export`:return N().export(t.ext,JSON.stringify(t.options??{}));case`developControls`:return F(i());case`developDefaults`:return F(a());case`developPresets`:return F(o());case`developApplyPreset`:return F(r(JSON.stringify(t.settings),JSON.stringify(t.preset),t.amount));case`developSet`:return F(s(JSON.stringify(t.settings),t.id,t.value));case`developSource`:return M?.free(),M=new e(t.pic.width,t.pic.height,t.pic.rgba),null;case`developRender`:if(!M)throw Error(`Nothing to develop yet.`);return P(M.render(JSON.stringify(t.settings),t.maxW,t.maxH,t.draft))}}let L=e=>e instanceof Uint8Array?[e.buffer]:e&&typeof e==`object`&&`rgba`in e&&e.rgba instanceof Uint8Array?[e.rgba.buffer]:[];self.onmessage=async e=>{let{seq:t,req:n}=e.data;try{let e=await I(n);self.postMessage({seq:t,ok:!0,result:e},L(e))}catch(e){self.postMessage({seq:t,ok:!1,error:typeof e==`string`?e:e instanceof Error?e.message:String(e)})}}})();\n//# sourceMappingURL=worker-C2mdyG4l.js.map", g = typeof self < "u" && self.Blob && new Blob(["(self.URL || self.webkitURL).revokeObjectURL(self.location.href);", h], { type: "text/javascript;charset=utf-8" });
function _(e) {
	let t;
	try {
		if (t = g && (self.URL || self.webkitURL).createObjectURL(g), !t) throw "";
		let n = new Worker(t, { name: e?.name });
		return n.addEventListener("error", () => {
			(self.URL || self.webkitURL).revokeObjectURL(t);
		}), n;
	} catch {
		return new Worker("data:text/javascript;charset=utf-8," + encodeURIComponent(h), { name: e?.name });
	}
}
new URL("./assets/gleamshelf_craft_bg.wasm", import.meta.url).href;
//#endregion
//#region ../craft/src/params.ts
function te(e) {
	let t = [], n = 0, r = !1, i = 0;
	for (let a = 0; a < e.length; a++) {
		let o = e[a];
		o === "\"" && e[a - 1] !== "\\" ? r = !r : !r && (o === "{" || o === "[" || o === "(") ? n++ : !r && (o === "}" || o === "]" || o === ")") ? n-- : !r && n === 0 && o === "," && (t.push(e.slice(i, a)), i = a + 1);
	}
	return t.push(e.slice(i)), t.map((e) => e.trim()).filter(Boolean);
}
function v(e) {
	let t = e.trimStart();
	if (!t.startsWith("{")) return null;
	let n = 0, r = !1;
	for (let e = 0; e < t.length; e++) {
		let i = t[e];
		if (i === "\"" && t[e - 1] !== "\\") r = !r;
		else if (!r && i === "{") n++;
		else if (!r && i === "}" && --n === 0) return {
			body: t.slice(1, e),
			rest: t.slice(e + 1).trim()
		};
	}
	return null;
}
var y = String.raw`-?\d+(?:\.\d+)?`, ne = new RegExp(String.raw`^(${y})\s*\.\.\s*(${y})(?:\s*=\s*(${y}))?(\?)?(?:\s.*)?$`), b = /^(u8|u16|u32|u64|i8|i16|i32|i64|usize|int|integer|px)\b/, x = /^(f32|f64|float|number|num)\b/;
function re(e, t, n) {
	let r = t.trim(), i = n, a = ne.exec(r);
	if (a) {
		let [, t, n, r, o] = a, s = Number(t), c = Number(n), l = !`${t}${n}${r ?? ""}`.includes(".");
		return {
			key: e,
			kind: "range",
			min: s,
			max: c,
			default: r === void 0 ? Math.min(c, Math.max(s, 0)) : Number(r),
			optional: i || !!o,
			integer: l
		};
	}
	r.endsWith("?") && (i = !0, r = r.slice(0, -1).trim());
	let o = /^bool(?:ean)?(?:\s*=\s*(true|false))?(\?)?$/.exec(r);
	if (o) return {
		key: e,
		kind: "bool",
		default: o[1] === "true",
		optional: i || !!o[2]
	};
	let s = /^"([^"]*\|[^"]*)"(?:\s*=\s*"([^"]*)")?(\?)?$/.exec(r);
	if (s) {
		let t = s[1].split("|").map((e) => e.trim()).filter(Boolean);
		return {
			key: e,
			kind: "choice",
			options: t,
			default: s[2] ?? t[0],
			optional: i || !!s[3]
		};
	}
	if (b.exec(r) && !r.includes("|") && !r.includes("[")) {
		let t = /=\s*(-?\d+)/.exec(r);
		return {
			key: e,
			kind: "number",
			default: t ? Number(t[1]) : null,
			optional: i || !t,
			integer: !0
		};
	}
	if (x.exec(r) && !r.includes("|") && !r.includes("[")) {
		let t = new RegExp(String.raw`=\s*(${y})`).exec(r);
		return {
			key: e,
			kind: "number",
			default: t ? Number(t[1]) : null,
			optional: i || !t,
			integer: !1
		};
	}
	let c = /^(str|string|text|name)\b(?:\s*=\s*"([^"]*)")?/.exec(r) ?? /^"([^"|]*)"$/.exec(r);
	if (c) {
		let t = c.length > 2 ? c[2] ?? null : null;
		return {
			key: e,
			kind: "text",
			default: t,
			optional: i || t === null,
			hint: r
		};
	}
	return /^("#rrggbb"|#rrggbb|color|colour)/i.test(r) ? {
		key: e,
		kind: "text",
		default: null,
		optional: !0,
		hint: "#rrggbb"
	} : {
		key: e,
		kind: "json",
		optional: !0,
		hint: r
	};
}
function S(e) {
	let t = v(e ?? "");
	if (!t) return {
		fields: [],
		notes: (e ?? "").trim()
	};
	let n = [];
	for (let e of te(t.body)) {
		let t = /^"([^"]+)"(\?)?\s*:\s*([\s\S]*)$/.exec(e);
		t && n.push(re(t[1], t[3], !!t[2]));
	}
	return {
		fields: n,
		notes: t.rest.replace(/^\(|\)$/g, "").trim()
	};
}
function C(e, t) {
	let n = {};
	for (let r of e.fields) {
		let e = t[r.key];
		if (e === void 0 || e === "" || e === null) {
			if (!r.optional && "default" in r) {
				let e = r.default;
				e != null && (n[r.key] = e);
			}
		} else if (r.kind === "json") try {
			n[r.key] = typeof e == "string" ? JSON.parse(e) : e;
		} catch {
			throw Error(`${r.key}: not valid JSON`);
		}
		else n[r.key] = e;
	}
	return n;
}
function ie(e) {
	let t = {};
	for (let n of e.fields) "default" in n && n.default !== null && !n.optional && (t[n.key] = n.default);
	return t;
}
//#endregion
//#region ../craft/src/index.ts
function ae(e = {}) {
	let t = new _({ name: "gleamshelf-craft" }), n = /* @__PURE__ */ new Map(), r = 0;
	t.onmessage = (e) => {
		let t = n.get(e.data.seq);
		t && (n.delete(e.data.seq), e.data.ok ? t.resolve(e.data.result) : t.reject(Error(e.data.error ?? "Photo lab failed.")));
	}, t.onerror = (e) => {
		let t = Error(e.message || "Photo lab could not start.");
		for (let e of n.values()) e.reject(t);
		n.clear();
	};
	let i = (e, i = []) => new Promise((a, o) => {
		let s = ++r;
		n.set(s, {
			resolve: a,
			reject: o
		}), t.postMessage({
			seq: s,
			req: e
		}, i);
	});
	i({
		op: "init",
		wasmUrl: new URL(e.wasmUrl ?? new URL("./assets/gleamshelf_craft_bg.wasm", import.meta.url).href, location.href).href
	}).catch(() => {});
	let a = (e) => {
		let t = e.rgba.slice();
		return [{
			width: e.width,
			height: e.height,
			rgba: t
		}, [t.buffer]];
	};
	return {
		openFile: (e, t) => i({
			op: "open",
			name: e,
			bytes: t.slice()
		}),
		openPicture: (e, t) => {
			let [n, r] = a(t);
			return i({
				op: "openRgba",
				name: e,
				pic: n
			}, r);
		},
		execute: (e, t) => i({
			op: "execute",
			id: e,
			params: t
		}),
		commands: () => i({ op: "commands" }),
		undo: () => i({ op: "undo" }),
		redo: () => i({ op: "redo" }),
		info: () => i({ op: "info" }),
		composite: () => i({ op: "composite" }),
		selection: () => i({ op: "selection" }),
		activePixels: () => i({ op: "activeRgba" }),
		place: (e, t, n, r) => {
			let [o, s] = a(r);
			return i({
				op: "place",
				name: e,
				x: t,
				y: n,
				pic: o
			}, s);
		},
		replaceActive: (e, t) => {
			let [n, r] = a(t);
			return i({
				op: "replaceActive",
				label: e,
				pic: n
			}, r);
		},
		export: (e, t) => i({
			op: "export",
			ext: e,
			options: t
		}),
		develop: {
			controls: () => i({ op: "developControls" }),
			defaults: () => i({ op: "developDefaults" }),
			presets: () => i({ op: "developPresets" }),
			applyPreset: (e, t, n) => i({
				op: "developApplyPreset",
				settings: e,
				preset: t,
				amount: n
			}),
			set: (e, t, n) => i({
				op: "developSet",
				settings: e,
				id: t,
				value: n
			}),
			source: (e) => {
				let [t, n] = a(e);
				return i({
					op: "developSource",
					pic: t
				}, n);
			},
			render: (e, t, n, r = !1) => i({
				op: "developRender",
				settings: e,
				maxW: t,
				maxH: n,
				draft: r
			})
		},
		close: () => {
			t.terminate();
			for (let e of n.values()) e.reject(/* @__PURE__ */ Error("Photo lab closed."));
			n.clear();
		}
	};
}
//#endregion
//#region src/photolab/gestures.ts
var oe = {
	size: 40,
	hardness: .7,
	opacity: 1,
	flow: 1,
	tolerance: 32,
	mode: "replace",
	paint: "#1a1a1a",
	second: "#ffffff",
	source: null
}, w = (e) => Math.round(e * 100) / 100, T = (e) => Math.max(1, Math.min(100, Math.round(e * 100)));
function se(e, t, n) {
	let r = e.command;
	if (!r) return { error: "This tool only moves the view." };
	if (t.kind === "box") {
		let i = Math.round(Math.min(t.x0, t.x1)), a = Math.round(Math.min(t.y0, t.y1)), o = Math.round(Math.abs(t.x1 - t.x0)), s = Math.round(Math.abs(t.y1 - t.y0));
		return o < 2 || s < 2 ? { error: "Drag a bigger box." } : e.id === "crop" ? {
			id: r,
			params: {
				x: i,
				y: a,
				width: o,
				height: s
			}
		} : e.id === "object" ? {
			id: r,
			params: {
				rect: [
					i,
					a,
					o,
					s
				],
				mode: n.mode
			}
		} : {
			id: r,
			params: {
				x: i,
				y: a,
				width: o,
				height: s,
				mode: n.mode,
				ellipse: e.id === "oval"
			}
		};
	}
	if (t.kind === "click") {
		let i = Math.round(t.x), a = Math.round(t.y);
		return e.id === "wand" ? {
			id: r,
			params: {
				x: i,
				y: a,
				tolerance: n.tolerance,
				mode: n.mode
			}
		} : e.id === "bucket" ? {
			id: r,
			params: {
				x: i,
				y: a,
				tolerance: n.tolerance,
				color: n.paint
			}
		} : e.id === "magicEraser" ? {
			id: r,
			params: {
				x: i,
				y: a,
				tolerance: n.tolerance
			}
		} : {
			id: r,
			params: {
				x: i,
				y: a
			}
		};
	}
	if (t.kind === "line") {
		let i = Math.round(t.x1 - t.x0), a = Math.round(t.y1 - t.y0);
		return e.id === "gradient" ? {
			id: r,
			params: {
				from: [w(t.x0), w(t.y0)],
				to: [w(t.x1), w(t.y1)],
				colors: [n.paint, n.second]
			}
		} : !i && !a ? { error: "Drag to where it should go." } : e.id === "patch" ? {
			id: r,
			params: {
				offset: [i, a],
				mode: "source"
			}
		} : {
			id: r,
			params: {
				offset: [i, a],
				mode: "move"
			}
		};
	}
	let i = t.points.map(([e, t]) => [w(e), w(t)]);
	if (!i.length) return { error: "Draw on the photo." };
	if (t.kind === "lasso") return i.length < 3 ? { error: "Draw all the way round." } : {
		id: r,
		params: {
			points: i,
			mode: n.mode
		}
	};
	switch (e.id) {
		case "quick": return {
			id: r,
			params: {
				points: i,
				size: Math.round(n.size),
				mode: n.mode === "subtract" ? "subtract" : "add"
			}
		};
		case "remove": return {
			id: r,
			params: {
				points: i,
				size: Math.round(n.size)
			}
		};
		case "brush":
		case "eraser": return {
			id: r,
			params: {
				points: i,
				size: n.size,
				hardness: n.hardness,
				opacity: n.opacity,
				flow: n.flow,
				...e.id === "eraser" ? { erase: !0 } : { color: n.paint }
			}
		};
		case "pencil": return {
			id: r,
			params: {
				points: i,
				size: n.size,
				opacity: n.opacity,
				color: n.paint
			}
		};
		case "mixer": return {
			id: r,
			params: {
				points: i,
				size: n.size,
				color: n.paint
			}
		};
		case "recolour": return {
			id: r,
			params: {
				points: i,
				size: n.size,
				tolerance: Math.min(100, n.tolerance),
				color: n.paint
			}
		};
		case "bgEraser": return {
			id: r,
			params: {
				points: i,
				size: n.size,
				hardness: n.hardness,
				tolerance: Math.min(100, n.tolerance)
			}
		};
		case "heal":
		case "clone": return n.source ? {
			id: r,
			params: {
				points: i,
				size: Math.round(n.size),
				hardness: T(n.hardness),
				opacity: T(n.opacity),
				flow: T(n.flow),
				source: n.source,
				aligned: !0
			}
		} : { error: "Alt-click where to copy from first." };
		default: return {
			id: r,
			params: {
				points: i,
				size: Math.round(n.size),
				hardness: T(n.hardness),
				opacity: T(n.opacity),
				flow: T(n.flow)
			}
		};
	}
}
function ce(e, t) {
	return t.shiftKey && t.altKey ? "intersect" : t.shiftKey ? "add" : t.altKey ? "subtract" : e;
}
//#endregion
//#region src/photolab/PhotoLab.tsx
var E = /* @__PURE__ */ e({ PhotoLab: () => A }), le = [
	{
		id: "develop",
		label: "Develop",
		glyph: "sliders"
	},
	{
		id: "looks",
		label: "Looks",
		glyph: "spark"
	},
	{
		id: "tools",
		label: "Tools",
		glyph: "brush"
	},
	{
		id: "everything",
		label: "Everything",
		glyph: "help"
	},
	{
		id: "layers",
		label: "Layers",
		glyph: "layers"
	},
	{
		id: "history",
		label: "History",
		glyph: "undo"
	}
], ue = /* @__PURE__ */ new Set([
	"File",
	"View",
	"Help",
	"Window"
]), de = /* @__PURE__ */ new Set([
	"Edit › Preferences",
	"Edit › Presets",
	"Edit › Purge",
	"Filter › Plug-ins",
	"Filter › Video"
]), fe = /(^|\.)(list|inspect|get|info|pixel|hitTest|caret|navigate|bounds|measure)$|^(tools|ui|prefs|command|document|actions|view|window|history|app|engine|paint|select\.(rect|lasso|quick|object|magicWand|magneticLasso))\b/, pe = /* @__PURE__ */ "Normal.Dissolve.Darken.Multiply.Color Burn.Linear Burn.Darker Color.Lighten.Screen.Color Dodge.Linear Dodge.Lighter Color.Overlay.Soft Light.Hard Light.Vivid Light.Linear Light.Pin Light.Hard Mix.Difference.Exclusion.Subtract.Divide.Hue.Saturation.Color.Luminosity".split("."), me = [
	{
		ext: "psd",
		label: "PSD (keeps layers)"
	},
	{
		ext: "png",
		label: "PNG"
	},
	{
		ext: "jpg",
		label: "JPEG"
	},
	{
		ext: "webp",
		label: "WebP"
	},
	{
		ext: "tif",
		label: "TIFF"
	}
], he = ".psd,.psb,.png,.jpg,.jpeg,.webp,.tif,.tiff,.bmp,.gif,.tga,.pcraft,.kra,.ora,.pdn", ge = 1600, _e = (e, t) => `${e} ${t}${e === 1 ? "" : "s"}`, ve = (e) => e.replace(/…$|\.\.\.$/, ""), ye = (e, t) => JSON.stringify(e) === JSON.stringify(t);
async function be(e) {
	let t = e instanceof Blob ? await createImageBitmap(e, { premultiplyAlpha: "none" }) : e, n = new OffscreenCanvas(t.width, t.height).getContext("2d");
	n.drawImage(t, 0, 0);
	let r = n.getImageData(0, 0, t.width, t.height).data;
	return {
		width: t.width,
		height: t.height,
		rgba: new Uint8Array(r.buffer, r.byteOffset, r.byteLength)
	};
}
var xe = (e) => createImageBitmap(new ImageData(new Uint8ClampedArray(e.rgba.buffer, e.rgba.byteOffset, e.rgba.byteLength), e.width, e.height), { premultiplyAlpha: "none" });
async function Se(e) {
	let { width: t, height: n } = e, r = (r, i) => r >= 0 && i >= 0 && r < t && i < n && e.rgba[(i * t + r) * 4 + 3] >= 128, i = Math.max(1, Math.round(Math.max(t, n) / 900)), a = new Uint8ClampedArray(t * n * 4);
	for (let o = 0; o < n; o++) for (let n = 0; n < t; n++) {
		let s = (o * t + n) * 4, c = e.rgba[s + 3];
		c && (c >= 128 && (!r(n - i, o) || !r(n + i, o) || !r(n, o - i) || !r(n, o + i)) ? a.set([
			255,
			255,
			255,
			255
		], s) : a.set([
			255,
			122,
			182,
			Math.round(c * .3)
		], s));
	}
	return createImageBitmap(new ImageData(a, t, n));
}
function Ce(e, t, n) {
	let r = structuredClone(e), i = t.split("."), a = r;
	for (let e = 0; e < i.length; e++) {
		let t = i[e], r = t in a ? t : t.replace(/[A-Z]/g, (e) => `_${e.toLowerCase()}`);
		if (!(r in a)) return null;
		if (e === i.length - 1) {
			if (typeof a[r] != "number") return null;
			a[r] = n;
		} else {
			let e = a[r];
			if (!e || typeof e != "object") return null;
			a = e;
		}
	}
	return r;
}
function we(e, t) {
	let n = e;
	for (let e of t.split(".")) {
		if (!n || typeof n != "object") return null;
		let t = n;
		n = e in t ? t[e] : t[e.replace(/[A-Z]/g, (e) => `_${e.toLowerCase()}`)];
	}
	return typeof n == "number" ? n : null;
}
var D = [
	"#e5484d",
	"#f08c2e",
	"#f5d90a",
	"#46a758",
	"#12a594",
	"#3e63dd",
	"#8e4ec6",
	"#d6409f"
];
function Te(e) {
	let t = e.track, n = D[t?.band ?? 0] ?? "#888";
	switch (t?.kind) {
		case "temp": return "linear-gradient(90deg, #3d7bff, #f2f2f2 50%, #ffbf3d)";
		case "tint": return "linear-gradient(90deg, #39c36a, #f2f2f2, #d94fd9)";
		case "rainbow": return "linear-gradient(90deg, red, yellow, lime, cyan, blue, magenta, red)";
		case "gradient": return `linear-gradient(90deg, ${t.from}, ${t.to})`;
		case "hue": return `linear-gradient(90deg, ${D[((t.band ?? 0) + 7) % 8]}, ${n}, ${D[((t.band ?? 0) + 1) % 8]})`;
		case "sat": return `linear-gradient(90deg, #7a7a7a, ${n})`;
		case "lum": return `linear-gradient(90deg, #1a1a1a, ${n}, #ffffff)`;
		default: return;
	}
}
var O = 7e3, k = 1e3;
function Ee(e, t) {
	if (e.id === "wb.temp" && e.min < O && O < e.max) {
		let n = Math.log(1 + (e.max - O) / k);
		return t > O ? .5 + .5 * Math.log(1 + (t - O) / k) / n : .5 * (t - e.min) / (O - e.min);
	}
	return (t - e.min) / (e.max - e.min || 1);
}
function De(e, t) {
	let n;
	if (e.id === "wb.temp" && e.min < O && O < e.max) {
		let r = Math.log(1 + (e.max - O) / k);
		n = t > .5 ? O + k * (Math.exp((2 * t - 1) * r) - 1) : e.min + 2 * t * (O - e.min);
	} else n = e.min + t * (e.max - e.min);
	return Math.min(e.max, Math.max(e.min, Math.round(n / e.step) * e.step));
}
function A({ picture: e, title: h = "Photo", doneLabel: g = "Done", onDone: _, onClose: te }) {
	let v = d(null), [y, ne] = f("starting"), [b, x] = f(null), [re, S] = f(null), [C, ie] = f("develop"), [w, T] = f({
		width: 0,
		height: 0
	}), [E, D] = f(0), [O, k] = f(null), [A, ke] = f(null), [j, Ae] = f(null), [je, M] = f(!1), [N, Me] = f([]), [Ne, Pe] = f(/* @__PURE__ */ new Map()), [Fe, Ie] = f([]), [Le, Re] = f([]), [P, ze] = f({
		zoom: 1,
		x: 0,
		y: 0
	}), [Be, Ve] = f("hand"), [F, I] = f(oe), [He, Ue] = f([]), [We, Ge] = f(null), [L, R] = f(null), [Ke, qe] = f([]), [z, Je] = f(null), [Ye, Xe] = f(null), [Ze, Qe] = f(!1), B = d(-1), $e = d(!1), et = d(0), V = d(null), H = d(null), U = d(null), [W, G] = f(null), [tt, nt] = f(!1), rt = d(null), K = n.find((e) => e.id === Be), q = !!L && !!We && !ye(L, We), it = (C === "develop" || C === "looks") && q && !!Ye, J = (e, t = !1) => S({
		text: e,
		bad: t
	}), Y = c(async () => {
		let e = v.current;
		if (!e) return;
		let [t, n, r, i, a] = await Promise.all([
			e.info(),
			e.composite(),
			e.selection(),
			e.execute("layer.list", { flat: !0 }),
			e.execute("document.inspect")
		]), o = /* @__PURE__ */ new Map(), s = (e = []) => {
			for (let t of e) o.set(t.id, {
				opacity: t.opacity ?? 1,
				blend: t.blend ?? "Normal"
			}), s(t.children);
		};
		s(a.layers), Pe(o), T({
			width: t.width,
			height: t.height
		}), D(t.revision), k(await xe(n)), Ae(r ? await Se(r) : null), Me(i.layers.map((e) => ({
			...e,
			depth: e.depth ?? 0
		}))), Ie(a.history ?? []);
	}, []), X = c((e, t) => {
		let n = V.current;
		if (!n || !e || !t) return;
		let r = n.getBoundingClientRect();
		if (r.width < 120 || r.height < 120) return;
		$e.current = !0;
		let i = Math.min(1, (r.width - 48) / e, (r.height - 48) / t);
		ze({
			zoom: i,
			x: (r.width - e * i) / 2,
			y: (r.height - t * i) / 2
		});
	}, []);
	l(() => {
		let t = !1, n = ae();
		return v.current = n, (async () => {
			try {
				let r = await be(e);
				ke(await xe(r)), await n.openPicture(h, r);
				let [i, a, o] = await Promise.all([
					n.develop.controls(),
					n.develop.defaults(),
					n.develop.presets()
				]);
				if (t) return;
				Ue(i), Ge(a), R(a), qe(o), await Y(), Re(await n.commands()), ne("ready"), X(r.width, r.height);
			} catch (e) {
				if (t) return;
				ne("failed"), J(e instanceof Error ? e.message : "Photo lab could not start.", !0);
			}
		})(), () => {
			t = !0, n.close(), v.current = null;
		};
	}, []);
	let Z = c(async (e, t, n) => {
		let r = v.current;
		if (!r) return null;
		x(n);
		try {
			let n = await r.execute(e, t);
			return await Y(), C === "everything" && Re(await r.commands()), S(null), n;
		} catch (e) {
			return J(e instanceof Error ? e.message : String(e), !0), null;
		} finally {
			x(null);
		}
	}, [Y, C]), at = async () => {
		let e = v.current;
		e && !b && await e.undo() && await Y();
	}, ot = async () => {
		let e = v.current;
		e && !b && await e.redo() && await Y();
	};
	l(() => {
		let e = v.current;
		if (!e || y !== "ready" || !L || !q || C !== "develop" && C !== "looks") return;
		let t = ++et.current, n = setTimeout(async () => {
			try {
				B.current !== E && (await e.develop.source(await e.activePixels()), B.current = E);
				let n = Math.min(1, ge / Math.max(w.width, w.height)), r = await e.develop.render(L, Math.round(w.width * n), Math.round(w.height * n), Ze);
				t === et.current && Xe(await xe(r));
			} catch (e) {
				t === et.current && J(e instanceof Error ? e.message : String(e), !0);
			}
		}, Ze ? 0 : 30);
		return () => clearTimeout(n);
	}, [
		L,
		q,
		C,
		E,
		w,
		Ze,
		y
	]);
	let st = async (e, t) => {
		if (!L) return;
		let n = Math.min(e.max, Math.max(e.min, t)), r = Ce(L, e.id, n);
		r ? R(r) : v.current && R(await v.current.develop.set(L, e.id, n)), Je(null);
	}, ct = async (e, t = 1) => {
		let n = v.current;
		if (!n || !L) return;
		let r = z ? z.base : L;
		R(await n.develop.applyPreset(r, e, t)), Je({
			preset: e,
			amount: t,
			base: r
		});
	}, lt = () => {
		R(We), Je(null), Xe(null);
	}, ut = async () => {
		let e = v.current;
		if (e && L && q) {
			x("Applying");
			try {
				B.current !== E && (await e.develop.source(await e.activePixels()), B.current = E);
				let t = await e.develop.render(L, w.width, w.height, !1);
				t.width === w.width && t.height === w.height ? await e.replaceActive(z ? `Look: ${z.preset.name}` : "Develop", t) : await e.place("Developed", Math.round((w.width - t.width) / 2), Math.round((w.height - t.height) / 2), t), lt(), await Y(), J(z ? `${z.preset.name} applied.` : "Develop applied.");
			} catch (e) {
				J(e instanceof Error ? e.message : String(e), !0);
			} finally {
				x(null);
			}
		}
	};
	l(() => {
		let e = H.current, t = V.current;
		if (!e || !t) return;
		let n = window.devicePixelRatio || 1, r = t.getBoundingClientRect();
		e.width = Math.round(r.width * n), e.height = Math.round(r.height * n);
		let i = e.getContext("2d");
		i.setTransform(n, 0, 0, n, 0, 0), i.clearRect(0, 0, r.width, r.height);
		let a = je ? A : it ? Ye : O;
		if (!a || !w.width) return;
		let o = w.width * P.zoom, s = w.height * P.zoom;
		i.save(), i.beginPath(), i.rect(P.x, P.y, o, s), i.clip();
		for (let e = 0; e < s; e += 10) for (let t = 0; t < o; t += 10) i.fillStyle = (t + e) / 10 % 2 ? "#22232b" : "#1b1c22", i.fillRect(P.x + t, P.y + e, 10, 10);
		if (i.imageSmoothingQuality = "high", i.imageSmoothingEnabled = P.zoom < 2, i.drawImage(a, P.x, P.y, o, s), j && !je && i.drawImage(j, P.x, P.y, o, s), i.restore(), W && W.points.length) {
			let e = W.points.map(([e, t]) => [P.x + e * P.zoom, P.y + t * P.zoom]);
			if (i.strokeStyle = "#ffffff", i.lineWidth = 1.5, i.setLineDash(W.tool.gesture === "stroke" ? [] : [6, 4]), i.beginPath(), W.tool.gesture === "box") {
				let [t, n] = [e[0], e[e.length - 1]];
				W.tool.id === "oval" ? i.ellipse((t[0] + n[0]) / 2, (t[1] + n[1]) / 2, Math.abs(n[0] - t[0]) / 2, Math.abs(n[1] - t[1]) / 2, 0, 0, Math.PI * 2) : i.rect(t[0], t[1], n[0] - t[0], n[1] - t[1]);
			} else W.tool.gesture === "line" ? (i.moveTo(e[0][0], e[0][1]), i.lineTo(e[e.length - 1][0], e[e.length - 1][1])) : (e.forEach(([e, t], n) => n ? i.lineTo(e, t) : i.moveTo(e, t)), W.tool.gesture === "lasso" && i.closePath(), W.tool.gesture === "stroke" && (i.globalAlpha = .35, i.lineWidth = Math.max(1, F.size * P.zoom), i.lineCap = "round", i.lineJoin = "round"));
			i.stroke(), i.globalAlpha = 1, i.setLineDash([]);
		}
		if (rt.current && K.options.includes("size")) {
			let [e, t] = rt.current;
			i.strokeStyle = "rgba(255,255,255,0.8)", i.lineWidth = 1, i.beginPath(), i.arc(P.x + e * P.zoom, P.y + t * P.zoom, Math.max(2, F.size / 2 * P.zoom), 0, Math.PI * 2), i.stroke();
		}
		if (K.source && F.source) {
			let [e, t] = F.source, n = P.x + e * P.zoom, r = P.y + t * P.zoom;
			i.strokeStyle = "#67e8f9", i.beginPath(), i.moveTo(n - 8, r), i.lineTo(n + 8, r), i.moveTo(n, r - 8), i.lineTo(n, r + 8), i.stroke();
		}
	});
	let [, dt] = f(0);
	l(() => {
		let e = V.current;
		if (!e) return;
		let t = new ResizeObserver(() => dt((e) => e + 1));
		return t.observe(e), () => t.disconnect();
	}, []), l(() => {
		!$e.current && w.width && X(w.width, w.height);
	});
	let ft = (e) => {
		let t = H.current.getBoundingClientRect();
		return [(e.clientX - t.left - P.x) / P.zoom, (e.clientY - t.top - P.y) / P.zoom];
	}, pt = (e) => {
		if (y !== "ready" || b) return;
		e.currentTarget.setPointerCapture(e.pointerId);
		let t = ft(e);
		K.gesture === "pan" || tt || e.button === 1 ? U.current = {
			tool: n[0],
			start: [e.clientX, e.clientY],
			points: [],
			pan: {
				x: P.x,
				y: P.y
			}
		} : K.source && e.altKey ? (I((e) => ({
			...e,
			source: [Math.round(t[0]), Math.round(t[1])]
		})), J("Copying from there. Now paint where it should go.")) : K.needsSelection && !j ? J("Select the thing first (Tools › Select).", !0) : it ? J("Apply or reset the develop first, so the tools work on what you see.", !0) : (U.current = {
			tool: K,
			start: t,
			points: [t]
		}, G({
			points: [t],
			tool: K
		}));
	}, mt = (e) => {
		let t = ft(e);
		rt.current = t;
		let n = U.current;
		n ? n.pan ? ze((t) => ({
			...t,
			x: n.pan.x + e.clientX - n.start[0],
			y: n.pan.y + e.clientY - n.start[1]
		})) : (n.tool.gesture === "box" || n.tool.gesture === "line" ? n.points = [n.start, t] : n.points.push(t), G({
			points: [...n.points],
			tool: n.tool
		})) : K.options.includes("size") && dt((e) => e + 1);
	}, ht = async (e) => {
		let t = U.current;
		if (U.current = null, G(null), !t || t.pan) return;
		let n = ft(e), r = {
			...F,
			mode: ce(F.mode, e)
		}, i;
		if (i = t.tool.gesture === "box" ? {
			kind: "box",
			x0: t.start[0],
			y0: t.start[1],
			x1: n[0],
			y1: n[1]
		} : t.tool.gesture === "line" ? {
			kind: "line",
			x0: t.start[0],
			y0: t.start[1],
			x1: n[0],
			y1: n[1]
		} : t.tool.gesture === "click" ? {
			kind: "click",
			x: n[0],
			y: n[1]
		} : {
			kind: t.tool.gesture === "lasso" ? "lasso" : "stroke",
			points: t.points
		}, t.tool.id === "dropper") {
			let e = await v.current?.execute("document.pixel", {
				x: Math.round(n[0]),
				y: Math.round(n[1])
			});
			if (e) {
				let t = `#${e.slice(0, 3).map((e) => Math.round(Math.min(1, Math.max(0, e)) * 255).toString(16).padStart(2, "0")).join("")}`;
				I((e) => ({
					...e,
					paint: t
				})), J(`Paint colour is now ${t}.`);
			}
			return;
		}
		let a = se(t.tool, i, r);
		"error" in a ? J(a.error, !0) : await Z(a.id, a.params, t.tool.label);
	}, gt = (e) => {
		let t = H.current.getBoundingClientRect(), n = e.clientX - t.left, r = e.clientY - t.top, i = Math.exp(-e.deltaY * .0015);
		ze((e) => {
			let t = Math.min(32, Math.max(.02, e.zoom * i));
			return {
				zoom: t,
				x: n - (n - e.x) * t / e.zoom,
				y: r - (r - e.y) * t / e.zoom
			};
		});
	};
	l(() => {
		let e = (e) => {
			if (e.target.closest("input, textarea, select")) return;
			let t = e.ctrlKey || e.metaKey;
			if (e.type === "keydown" && e.code === "Space" ? (nt(!0), e.preventDefault()) : e.type === "keyup" && e.code === "Space" && nt(!1), e.type !== "keydown") return;
			let n = e.key.toLowerCase();
			t && n === "z" ? (e.preventDefault(), e.shiftKey ? ot() : at()) : t && n === "y" ? (e.preventDefault(), ot()) : n === "[" ? I((e) => ({
				...e,
				size: Math.max(1, Math.round(e.size / 1.2))
			})) : n === "]" ? I((e) => ({
				...e,
				size: Math.min(2e3, Math.round(e.size * 1.2))
			})) : e.key === "\\" ? M(!0) : e.key === "Escape" && (U.current = null, G(null));
		}, t = (t) => {
			t.key === "\\" && M(!1), e(t);
		};
		return window.addEventListener("keydown", e), window.addEventListener("keyup", t), () => {
			window.removeEventListener("keydown", e), window.removeEventListener("keyup", t);
		};
	});
	let _t = d(null), vt = async (e) => {
		let t = v.current;
		if (t) {
			x("Opening");
			try {
				let { warnings: n } = await t.openFile(e.name, new Uint8Array(await e.arrayBuffer()));
				lt(), B.current = -1, await Y();
				let r = await t.info();
				X(r.width, r.height), Re(await t.commands()), J(n.length ? `Opened ${e.name}. ${n.slice(0, 2).join(" ")}` : `Opened ${e.name}.`);
			} catch (e) {
				J(e instanceof Error ? e.message : String(e), !0);
			} finally {
				x(null);
			}
		}
	}, yt = async (e) => {
		let t = v.current;
		if (t) {
			x("Saving");
			try {
				let n = await t.export(e, e === "jpg" || e === "webp" ? { quality: 92 } : void 0), r = {
					psd: "image/vnd.adobe.photoshop",
					png: "image/png",
					jpg: "image/jpeg",
					webp: "image/webp",
					tif: "image/tiff"
				}[e] ?? "application/octet-stream", i = URL.createObjectURL(new Blob([n], { type: r })), a = document.createElement("a");
				a.href = i, a.download = `${h}.${e}`, a.click(), setTimeout(() => URL.revokeObjectURL(i), 1e4);
			} catch (e) {
				J(e instanceof Error ? e.message : String(e), !0);
			} finally {
				x(null);
			}
		}
	}, bt = async () => {
		let e = v.current;
		if (e && (!q || confirm("The develop changes are not applied yet. Finish without them?"))) {
			x("Finishing");
			try {
				let t = await e.export("png");
				_(new Blob([t], { type: "image/png" }));
			} catch (e) {
				J(e instanceof Error ? e.message : String(e), !0), x(null);
			}
		}
	}, xt = u(() => {
		let e = /* @__PURE__ */ new Map();
		for (let t of He) {
			if (t.id.startsWith("hdr.")) continue;
			let n = e.get(t.sectionLabel) ?? [];
			n.push(t), e.set(t.sectionLabel, n);
		}
		return [...e.entries()];
	}, [He]), [St, Ct] = f(() => /* @__PURE__ */ new Set(["Light", "Color"])), wt = u(() => {
		let e = /* @__PURE__ */ new Map();
		for (let t of Ke) e.set(t.group, [...e.get(t.group) ?? [], t]);
		return [...e.entries()];
	}, [Ke]), Tt = q && /* @__PURE__ */ m("div", {
		className: "gs-lab__applybar",
		children: [
			/* @__PURE__ */ p("span", { children: z ? `Trying ${z.preset.name}` : "Previewing the develop" }),
			/* @__PURE__ */ p("button", {
				type: "button",
				className: "gs-lab__btn",
				onClick: lt,
				children: "Reset"
			}),
			/* @__PURE__ */ p("button", {
				type: "button",
				className: "gs-lab__btn gs-lab__btn--primary",
				disabled: !!b,
				onClick: () => void ut(),
				children: "Apply"
			})
		]
	}), Et = /* @__PURE__ */ m("div", {
		className: "gs-lab__panel-body",
		children: [
			/* @__PURE__ */ p(a, { id: "labDevelop" }),
			Tt,
			xt.map(([e, t]) => {
				let n = St.has(e);
				return /* @__PURE__ */ m("section", {
					className: "gs-lab__section",
					children: [/* @__PURE__ */ m("button", {
						type: "button",
						className: "gs-lab__section-head",
						"aria-expanded": n,
						onClick: () => Ct((t) => {
							let n = new Set(t);
							return n.has(e) ? n.delete(e) : n.add(e), n;
						}),
						children: [/* @__PURE__ */ p("span", { children: e }), /* @__PURE__ */ p("span", {
							className: "gs-lab__count",
							children: t.length
						})]
					}), n && t.map((e) => {
						let t = we(L, e.id) ?? e.default, n = Te(e);
						return /* @__PURE__ */ m("label", {
							className: "gs-lab__slider",
							children: [/* @__PURE__ */ m("span", {
								className: "gs-lab__slider-label",
								children: [e.label, /* @__PURE__ */ p("output", { children: t > 0 && e.min < 0 ? `+${t.toFixed(e.decimals)}` : t.toFixed(e.decimals) })]
							}), /* @__PURE__ */ p("input", {
								type: "range",
								min: 0,
								max: 1e3,
								step: 1,
								value: Math.round(Ee(e, t) * 1e3),
								style: n ? { background: n } : void 0,
								onPointerDown: () => Qe(!0),
								onPointerUp: () => Qe(!1),
								onDoubleClick: () => void st(e, e.default),
								onChange: (t) => void st(e, De(e, Number(t.target.value) / 1e3)),
								title: "Double-click to reset"
							})]
						}, e.id);
					})]
				}, e);
			})
		]
	}), Dt = /* @__PURE__ */ m("div", {
		className: "gs-lab__panel-body",
		children: [
			/* @__PURE__ */ p(a, { id: "labLooks" }),
			Tt,
			z && /* @__PURE__ */ m("label", {
				className: "gs-lab__slider",
				children: [/* @__PURE__ */ m("span", {
					className: "gs-lab__slider-label",
					children: ["Strength", /* @__PURE__ */ m("output", { children: [Math.round(z.amount * 100), "%"] })]
				}), /* @__PURE__ */ p("input", {
					type: "range",
					min: 0,
					max: 2,
					step: .05,
					value: z.amount,
					onChange: (e) => void ct(z.preset, Number(e.target.value))
				})]
			}),
			wt.map(([e, t]) => /* @__PURE__ */ m("section", {
				className: "gs-lab__section",
				children: [/* @__PURE__ */ p("h4", {
					className: "gs-lab__group",
					children: e
				}), /* @__PURE__ */ p("div", {
					className: "gs-lab__chips",
					children: t.map((e) => /* @__PURE__ */ p("button", {
						type: "button",
						className: `gs-lab__chip${z?.preset.id === e.id ? " is-on" : ""}`,
						onClick: () => void ct(e, z?.preset.id === e.id ? z.amount : 1),
						children: e.name
					}, e.id))
				})]
			}, e))
		]
	}), Ot = /* @__PURE__ */ m("div", {
		className: "gs-lab__panel-body",
		children: [/* @__PURE__ */ p(a, { id: "labTools" }), i.map((e) => /* @__PURE__ */ m("section", {
			className: "gs-lab__section",
			children: [
				/* @__PURE__ */ p("h4", {
					className: "gs-lab__group",
					children: e
				}),
				/* @__PURE__ */ p("div", {
					className: "gs-lab__tools",
					children: n.filter((t) => t.group === e).map((e) => /* @__PURE__ */ p("button", {
						type: "button",
						className: `gs-lab__tool${e.id === Be ? " is-on" : ""}`,
						onClick: () => Ve(e.id),
						title: e.hint,
						children: e.label
					}, e.id))
				}),
				e === "Select" && /* @__PURE__ */ m(ee, { children: [
					/* @__PURE__ */ m("div", {
						className: "gs-lab__chips",
						children: [
							/* @__PURE__ */ p("button", {
								type: "button",
								className: "gs-lab__chip",
								onClick: () => void Z("select.subject", {}, "Selecting the main thing"),
								children: "Main thing"
							}),
							/* @__PURE__ */ p("button", {
								type: "button",
								className: "gs-lab__chip",
								onClick: () => void Z("select.sky", {}, "Selecting the sky"),
								children: "Sky"
							}),
							/* @__PURE__ */ p("button", {
								type: "button",
								className: "gs-lab__chip",
								onClick: () => void Z("select.focusArea", {}, "Selecting what is sharp"),
								children: "In focus"
							}),
							/* @__PURE__ */ p("button", {
								type: "button",
								className: "gs-lab__chip",
								onClick: () => void Z("select.all", {}, "Selecting all"),
								children: "All"
							}),
							/* @__PURE__ */ p("button", {
								type: "button",
								className: "gs-lab__chip",
								disabled: !j,
								onClick: () => void Z("select.inverse", {}, "Inverting"),
								children: "Invert"
							}),
							/* @__PURE__ */ p("button", {
								type: "button",
								className: "gs-lab__chip",
								disabled: !j,
								onClick: () => void Z("select.deselect", {}, "Clearing"),
								children: "Clear"
							})
						]
					}),
					/* @__PURE__ */ m("div", {
						className: "gs-lab__chips",
						children: [
							/* @__PURE__ */ p("button", {
								type: "button",
								className: "gs-lab__chip",
								disabled: !j,
								onClick: () => void Z("select.refineEdge", {
									radius: 6,
									smartRadius: !0,
									smooth: 10,
									decontaminate: !0
								}, "Refining the edge"),
								children: "Refine edge"
							}),
							/* @__PURE__ */ p("button", {
								type: "button",
								className: "gs-lab__chip",
								disabled: !j,
								onClick: () => void Z("edit.contentAwareFill", {}, "Filling from around it"),
								children: "Fill from around"
							}),
							/* @__PURE__ */ p("button", {
								type: "button",
								className: "gs-lab__chip",
								disabled: !j,
								onClick: () => void Z("layer.new.layerViaCopy", {}, "Copying to a layer"),
								children: "Copy to new layer"
							})
						]
					}),
					/* @__PURE__ */ p(a, { id: "labSelect" })
				] })
			]
		}, e))]
	}), [Q, kt] = f(""), [At, jt] = f(null), Mt = u(() => {
		let e = Q.trim().toLowerCase(), t = /* @__PURE__ */ new Map();
		for (let n of Le) {
			let r = n.menu[0];
			if (r && ue.has(r) || !r && fe.test(n.id)) continue;
			let i = r ? n.menu.join(" › ") : "More";
			de.has(i) || (!e || [
				n.label,
				n.id,
				n.keywords ?? "",
				i
			].some((t) => t.toLowerCase().includes(e))) && t.set(i, [...t.get(i) ?? [], n]);
		}
		return [...t.entries()].sort(([e], [t]) => e === "More" ? 1 : t === "More" ? -1 : e.localeCompare(t));
	}, [Le, Q]), Nt = /* @__PURE__ */ m("div", {
		className: "gs-lab__panel-body",
		children: [
			/* @__PURE__ */ p(a, { id: "labEverything" }),
			/* @__PURE__ */ p("input", {
				className: "gs-lab__search",
				type: "search",
				placeholder: "Search: blur, levels, warp, sharpen…",
				value: Q,
				onChange: (e) => kt(e.target.value)
			}),
			/* @__PURE__ */ p("p", {
				className: "gs-lab__muted",
				children: _e(Mt.reduce((e, [, t]) => e + t.length, 0), "command")
			}),
			Mt.map(([e, t]) => /* @__PURE__ */ m("details", {
				className: "gs-lab__menu",
				open: !!Q.trim(),
				children: [/* @__PURE__ */ m("summary", { children: [
					e,
					" ",
					/* @__PURE__ */ p("span", {
						className: "gs-lab__count",
						children: t.length
					})
				] }), t.map((e) => /* @__PURE__ */ p(Oe, {
					command: e,
					open: At === e.id,
					busy: !!b,
					onOpen: () => jt(At === e.id ? null : e.id),
					onRun: (t) => void Z(e.id, t, ve(e.label))
				}, e.id))]
			}, e))
		]
	}), $ = N.find((e) => e.active), Pt = $ ? Ne.get($.id) : void 0, [Ft, It] = f(100);
	l(() => It(Math.round((Pt?.opacity ?? 1) * 100)), [Pt?.opacity, $?.id]);
	let Lt = {
		develop: Et,
		looks: Dt,
		tools: Ot,
		everything: Nt,
		layers: /* @__PURE__ */ m("div", {
			className: "gs-lab__panel-body",
			children: [
				/* @__PURE__ */ p(a, { id: "labLayers" }),
				/* @__PURE__ */ m("div", {
					className: "gs-lab__chips",
					children: [
						/* @__PURE__ */ p("button", {
							type: "button",
							className: "gs-lab__chip",
							onClick: () => void Z("layer.new.layer", {}, "New layer"),
							children: "New"
						}),
						/* @__PURE__ */ p("button", {
							type: "button",
							className: "gs-lab__chip",
							disabled: !$,
							onClick: () => void Z("layer.duplicate", {}, "Duplicate"),
							children: "Duplicate"
						}),
						/* @__PURE__ */ p("button", {
							type: "button",
							className: "gs-lab__chip",
							disabled: !$ || N.length < 2,
							onClick: () => void Z("layer.mergeDown", {}, "Merge down"),
							children: "Merge down"
						}),
						/* @__PURE__ */ p("button", {
							type: "button",
							className: "gs-lab__chip",
							disabled: N.length < 2,
							onClick: () => void Z("layer.flattenImage", {}, "Flatten"),
							children: "Flatten"
						}),
						/* @__PURE__ */ p("button", {
							type: "button",
							className: "gs-lab__chip",
							disabled: !$ || N.length < 2,
							onClick: () => void Z("layer.delete", {}, "Delete layer"),
							children: "Delete"
						})
					]
				}),
				$ && /* @__PURE__ */ m("div", {
					className: "gs-lab__layer-props",
					children: [/* @__PURE__ */ m("label", {
						className: "gs-lab__slider",
						children: [/* @__PURE__ */ m("span", {
							className: "gs-lab__slider-label",
							children: ["Opacity", /* @__PURE__ */ m("output", { children: [Ft, "%"] })]
						}), /* @__PURE__ */ p("input", {
							type: "range",
							min: 0,
							max: 100,
							value: Ft,
							onChange: (e) => It(Number(e.target.value)),
							onPointerUp: () => void Z("layer.setProps", {
								layer: $.id,
								opacity: Ft / 100
							}, "Opacity"),
							onKeyUp: () => void Z("layer.setProps", {
								layer: $.id,
								opacity: Ft / 100
							}, "Opacity")
						})]
					}), /* @__PURE__ */ m("label", {
						className: "gs-lab__field",
						children: ["Blend", /* @__PURE__ */ p("select", {
							value: Pt?.blend ?? "Normal",
							onChange: (e) => void Z("layer.setProps", {
								layer: $.id,
								blend: e.target.value
							}, "Blend"),
							children: pe.map((e) => /* @__PURE__ */ p("option", {
								value: e,
								children: e
							}, e))
						})]
					})]
				}),
				/* @__PURE__ */ p("ul", {
					className: "gs-lab__layers",
					children: N.map((e) => /* @__PURE__ */ m("li", {
						className: e.active ? "is-on" : void 0,
						style: { paddingLeft: 8 + e.depth * 14 },
						children: [/* @__PURE__ */ p("button", {
							type: "button",
							className: "gs-lab__eye",
							"aria-label": e.visible ? "Hide" : "Show",
							onClick: () => void Z("layer.setProps", {
								layer: e.id,
								visible: !e.visible
							}, e.visible ? "Hide" : "Show"),
							children: e.visible ? "●" : "○"
						}), /* @__PURE__ */ m("button", {
							type: "button",
							className: "gs-lab__layer-name",
							onClick: () => void Z("layer.select", { layer: e.id }, "Select layer"),
							children: [e.name, /* @__PURE__ */ m("span", {
								className: "gs-lab__muted",
								children: [" ", e.kind]
							})]
						})]
					}, e.id))
				})
			]
		}),
		history: /* @__PURE__ */ m("div", {
			className: "gs-lab__panel-body",
			children: [/* @__PURE__ */ p(a, { id: "labHistory" }), /* @__PURE__ */ p("ol", {
				className: "gs-lab__history",
				children: Fe.map((e, t) => /* @__PURE__ */ p("li", { children: /* @__PURE__ */ p("button", {
					type: "button",
					onClick: () => void Z("history.selectState", { state: t }, `Back to ${e}`),
					children: e
				}) }, `${t}-${e}`))
			})]
		})
	}[C], Rt = C === "tools" && /* @__PURE__ */ m("div", {
		className: "gs-lab__options",
		children: [
			/* @__PURE__ */ p("strong", { children: K.label }),
			K.options.includes("size") && /* @__PURE__ */ m("label", { children: [
				"Size",
				/* @__PURE__ */ p("input", {
					type: "range",
					min: 1,
					max: 500,
					value: F.size,
					onChange: (e) => I({
						...F,
						size: Number(e.target.value)
					})
				}),
				/* @__PURE__ */ m("output", { children: [F.size, "px"] })
			] }),
			K.options.includes("hardness") && /* @__PURE__ */ m("label", { children: ["Hardness", /* @__PURE__ */ p("input", {
				type: "range",
				min: 0,
				max: 1,
				step: .05,
				value: F.hardness,
				onChange: (e) => I({
					...F,
					hardness: Number(e.target.value)
				})
			})] }),
			K.options.includes("opacity") && /* @__PURE__ */ m("label", { children: ["Strength", /* @__PURE__ */ p("input", {
				type: "range",
				min: .05,
				max: 1,
				step: .05,
				value: F.opacity,
				onChange: (e) => I({
					...F,
					opacity: Number(e.target.value)
				})
			})] }),
			K.options.includes("flow") && /* @__PURE__ */ m("label", { children: ["Flow", /* @__PURE__ */ p("input", {
				type: "range",
				min: .05,
				max: 1,
				step: .05,
				value: F.flow,
				onChange: (e) => I({
					...F,
					flow: Number(e.target.value)
				})
			})] }),
			K.options.includes("tolerance") && /* @__PURE__ */ m("label", { children: [
				"Tolerance",
				/* @__PURE__ */ p("input", {
					type: "range",
					min: 0,
					max: 255,
					value: F.tolerance,
					onChange: (e) => I({
						...F,
						tolerance: Number(e.target.value)
					})
				}),
				/* @__PURE__ */ p("output", { children: F.tolerance })
			] }),
			K.options.includes("mode") && /* @__PURE__ */ m("label", { children: ["Selection", /* @__PURE__ */ p("select", {
				value: F.mode,
				onChange: (e) => I({
					...F,
					mode: e.target.value
				}),
				children: s.map((e) => /* @__PURE__ */ p("option", {
					value: e.id,
					children: e.label
				}, e.id))
			})] }),
			K.options.includes("colors") && /* @__PURE__ */ m(ee, { children: [/* @__PURE__ */ m("label", { children: ["Paint", /* @__PURE__ */ p("input", {
				type: "color",
				value: F.paint,
				onChange: (e) => I({
					...F,
					paint: e.target.value
				})
			})] }), /* @__PURE__ */ m("label", { children: ["Second", /* @__PURE__ */ p("input", {
				type: "color",
				value: F.second,
				onChange: (e) => I({
					...F,
					second: e.target.value
				})
			})] })] }),
			/* @__PURE__ */ m("span", {
				className: "gs-lab__hint",
				children: [K.hint, /* @__PURE__ */ p(r, { text: K.dev })]
			})
		]
	});
	return /* @__PURE__ */ m("div", {
		className: "gs-lab",
		tabIndex: -1,
		children: [/* @__PURE__ */ m("header", {
			className: "gs-lab__top",
			children: [
				/* @__PURE__ */ p("button", {
					type: "button",
					className: "gs-lab__btn",
					onClick: te,
					"aria-label": "Close Photo lab",
					children: /* @__PURE__ */ p(o, { name: "close" })
				}),
				/* @__PURE__ */ m("strong", {
					className: "gs-lab__title",
					children: ["Photo lab ", /* @__PURE__ */ p("span", {
						className: "gs-lab__muted",
						children: h
					})]
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					className: "gs-lab__btn",
					disabled: y !== "ready" || !!b,
					onClick: () => void at(),
					title: "Undo (Ctrl+Z)",
					children: /* @__PURE__ */ p(o, { name: "undo" })
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					className: "gs-lab__btn",
					disabled: y !== "ready" || !!b,
					onClick: () => void ot(),
					title: "Redo (Ctrl+Shift+Z)",
					children: /* @__PURE__ */ p(o, { name: "redo" })
				}),
				/* @__PURE__ */ m("button", {
					type: "button",
					className: "gs-lab__btn",
					disabled: !A,
					onPointerDown: () => M(!0),
					onPointerUp: () => M(!1),
					onPointerLeave: () => M(!1),
					title: "Hold to see the photo as it came in (\\)",
					children: [/* @__PURE__ */ p(o, { name: "compare" }), " Before"]
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					className: "gs-lab__btn",
					onClick: () => X(w.width, w.height),
					children: "Fit"
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					className: "gs-lab__btn",
					onClick: () => {
						let e = V.current.getBoundingClientRect();
						ze({
							zoom: 1,
							x: (e.width - w.width) / 2,
							y: (e.height - w.height) / 2
						});
					},
					children: "100%"
				}),
				/* @__PURE__ */ m("span", {
					className: "gs-lab__muted",
					children: [
						w.width,
						" × ",
						w.height,
						" · ",
						Math.round(P.zoom * 100),
						"%"
					]
				}),
				/* @__PURE__ */ p("span", { className: "gs-lab__spacer" }),
				/* @__PURE__ */ p("button", {
					type: "button",
					className: "gs-lab__btn",
					disabled: y !== "ready",
					onClick: () => _t.current?.click(),
					title: "Open a PSD or any photo",
					children: "Open file"
				}),
				/* @__PURE__ */ p("input", {
					ref: _t,
					type: "file",
					accept: he,
					hidden: !0,
					onChange: (e) => {
						let t = e.target.files?.[0];
						e.target.value = "", t && vt(t);
					}
				}),
				/* @__PURE__ */ m("select", {
					className: "gs-lab__btn",
					value: "",
					disabled: y !== "ready",
					onChange: (e) => e.target.value && void yt(e.target.value),
					"aria-label": "Save a copy",
					children: [/* @__PURE__ */ p("option", {
						value: "",
						children: "Save a copy…"
					}), me.map((e) => /* @__PURE__ */ p("option", {
						value: e.ext,
						children: e.label
					}, e.ext))]
				}),
				/* @__PURE__ */ p(t, {}),
				/* @__PURE__ */ p("button", {
					type: "button",
					className: "gs-lab__btn gs-lab__btn--primary",
					disabled: y !== "ready" || !!b,
					onClick: () => void bt(),
					children: g
				})
			]
		}), /* @__PURE__ */ m("div", {
			className: "gs-lab__main",
			children: [
				/* @__PURE__ */ p("nav", {
					className: "gs-lab__rail",
					"aria-label": "Photo lab panels",
					children: le.map((e) => /* @__PURE__ */ m("button", {
						type: "button",
						className: `gs-lab__rail-btn${C === e.id ? " is-on" : ""}`,
						onClick: () => ie(e.id),
						children: [/* @__PURE__ */ p(o, {
							name: e.glyph,
							size: 18
						}), /* @__PURE__ */ p("span", { children: e.label })]
					}, e.id))
				}),
				/* @__PURE__ */ p("aside", {
					className: "gs-lab__panel",
					children: y === "ready" ? Lt : /* @__PURE__ */ p("p", {
						className: "gs-lab__muted",
						children: y === "starting" ? "Starting Photo lab…" : "Photo lab could not start."
					})
				}),
				/* @__PURE__ */ m("div", {
					className: "gs-lab__stagewrap",
					children: [
						Rt,
						/* @__PURE__ */ m("div", {
							ref: V,
							className: `gs-lab__stage${tt || K.gesture === "pan" ? " is-pan" : ""}`,
							onDragOver: (e) => e.preventDefault(),
							onDrop: (e) => {
								e.preventDefault();
								let t = e.dataTransfer.files?.[0];
								t && vt(t);
							},
							children: [
								/* @__PURE__ */ p("canvas", {
									ref: H,
									onPointerDown: pt,
									onPointerMove: mt,
									onPointerUp: (e) => void ht(e),
									onPointerLeave: () => {
										rt.current = null, dt((e) => e + 1);
									},
									onWheel: gt
								}),
								it && /* @__PURE__ */ p("span", {
									className: "gs-lab__badge",
									children: "Preview: press Apply to keep it"
								}),
								je && /* @__PURE__ */ p("span", {
									className: "gs-lab__badge",
									children: "Before"
								}),
								(b || y === "starting") && /* @__PURE__ */ p("span", {
									className: "gs-lab__busy",
									children: b ?? "Starting the engines…"
								})
							]
						}),
						re && /* @__PURE__ */ m("div", {
							className: `gs-lab__message${re.bad ? " is-bad" : ""}`,
							role: "status",
							children: [re.text, /* @__PURE__ */ p("button", {
								type: "button",
								onClick: () => S(null),
								"aria-label": "Dismiss",
								children: "×"
							})]
						})
					]
				})
			]
		})]
	});
}
function Oe({ command: e, open: t, busy: n, onOpen: i, onRun: a }) {
	let o = u(() => S(e.params), [e.params]), [s, c] = f(() => ie(o)), [l, d] = f(null), ee = o.fields.filter((e) => e.kind !== "json"), h = o.fields.filter((e) => e.kind === "json"), g = !e.enabled, _ = () => {
		try {
			d(null), a(C(o, s));
		} catch (e) {
			d(e instanceof Error ? e.message : String(e));
		}
	};
	return /* @__PURE__ */ m("div", {
		className: `gs-lab__cmd${t ? " is-open" : ""}${g ? " is-off" : ""}`,
		children: [/* @__PURE__ */ m("button", {
			type: "button",
			className: "gs-lab__cmd-head",
			onClick: () => o.fields.length ? i() : !g && !n && _(),
			title: g ? e.disabledReason ?? "Not available right now" : e.id,
			children: [
				ve(e.label),
				e.shortcut && /* @__PURE__ */ p("kbd", { children: e.shortcut }),
				!o.fields.length && !g && /* @__PURE__ */ p("span", {
					className: "gs-lab__muted",
					children: " · runs now"
				})
			]
		}), t && /* @__PURE__ */ m("div", {
			className: "gs-lab__cmd-form",
			children: [
				g && /* @__PURE__ */ p("p", {
					className: "gs-lab__muted",
					children: e.disabledReason ?? "Not available right now."
				}),
				ee.map((e) => /* @__PURE__ */ p(j, {
					field: e,
					value: s[e.key],
					onChange: (t) => c({
						...s,
						[e.key]: t
					})
				}, e.key)),
				h.length > 0 && /* @__PURE__ */ m("details", { children: [/* @__PURE__ */ p("summary", { children: "More settings" }), h.map((e) => /* @__PURE__ */ p(j, {
					field: e,
					value: s[e.key],
					onChange: (t) => c({
						...s,
						[e.key]: t
					})
				}, e.key))] }),
				o.notes && /* @__PURE__ */ p("p", {
					className: "gs-lab__muted",
					children: o.notes
				}),
				/* @__PURE__ */ p(r, { text: `${e.id} ${e.params}` }),
				l && /* @__PURE__ */ p("p", {
					className: "gs-lab__error",
					children: l
				}),
				/* @__PURE__ */ m("div", {
					className: "gs-lab__chips",
					children: [/* @__PURE__ */ p("button", {
						type: "button",
						className: "gs-lab__btn",
						onClick: () => c(ie(o)),
						children: "Reset"
					}), /* @__PURE__ */ p("button", {
						type: "button",
						className: "gs-lab__btn gs-lab__btn--primary",
						disabled: g || n,
						onClick: _,
						children: "Apply"
					})]
				})
			]
		})]
	});
}
var ke = (e) => e.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/^./, (e) => e.toUpperCase());
function j({ field: e, value: t, onChange: n }) {
	let r = ke(e.key);
	switch (e.kind) {
		case "range": {
			let i = typeof t == "number" ? t : e.default, a = e.max - e.min, o = e.integer ? 1 : a > 100 ? .1 : a > 10 ? .05 : .01, s = e.min >= 0 && e.max >= 200 && e.max / Math.max(e.min, .1) >= 100, c = (t) => (s ? Math.cbrt((t - e.min) / a) : (t - e.min) / a) * 1e3, l = (t) => {
				let n = t / 1e3, r = e.min + (s ? n * n * n : n) * a;
				return e.integer ? Math.round(r) : Math.round(r / o) * o;
			};
			return /* @__PURE__ */ m("label", {
				className: "gs-lab__slider",
				children: [/* @__PURE__ */ m("span", {
					className: "gs-lab__slider-label",
					children: [r, /* @__PURE__ */ p("input", {
						className: "gs-lab__num",
						type: "number",
						min: e.min,
						max: e.max,
						step: o,
						value: i,
						onChange: (e) => n(e.target.value === "" ? void 0 : Number(e.target.value))
					})]
				}), /* @__PURE__ */ p("input", {
					type: "range",
					min: 0,
					max: 1e3,
					step: 1,
					value: Math.round(c(i)),
					onChange: (e) => n(l(Number(e.target.value)))
				})]
			});
		}
		case "bool": return /* @__PURE__ */ m("label", {
			className: "gs-lab__check",
			children: [/* @__PURE__ */ p("input", {
				type: "checkbox",
				checked: typeof t == "boolean" ? t : e.default,
				onChange: (e) => n(e.target.checked)
			}), r]
		});
		case "choice": return /* @__PURE__ */ m("label", {
			className: "gs-lab__field",
			children: [r, /* @__PURE__ */ p("select", {
				value: t ?? e.default,
				onChange: (e) => n(e.target.value),
				children: e.options.map((e) => /* @__PURE__ */ p("option", {
					value: e,
					children: ke(e)
				}, e))
			})]
		});
		case "number": return /* @__PURE__ */ m("label", {
			className: "gs-lab__field",
			children: [r, /* @__PURE__ */ p("input", {
				type: "number",
				step: e.integer ? 1 : "any",
				value: t == null ? "" : String(t),
				placeholder: e.optional ? "default" : void 0,
				onChange: (e) => n(e.target.value === "" ? void 0 : Number(e.target.value))
			})]
		});
		case "text": return /* @__PURE__ */ m("label", {
			className: "gs-lab__field",
			children: [r, /* @__PURE__ */ p("input", {
				type: "text",
				value: t ?? "",
				placeholder: e.optional ? "default" : e.hint,
				onChange: (e) => n(e.target.value)
			})]
		});
		case "json": return /* @__PURE__ */ m("label", {
			className: "gs-lab__field",
			children: [r, /* @__PURE__ */ p("input", {
				type: "text",
				value: t ?? "",
				placeholder: e.hint.slice(0, 60),
				onChange: (e) => n(e.target.value)
			})]
		});
	}
}
//#endregion
export { E as n, A as t };

//# sourceMappingURL=PhotoLab-DqJnYSem.js.map