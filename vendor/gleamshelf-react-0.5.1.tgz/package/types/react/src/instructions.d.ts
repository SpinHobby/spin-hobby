/**
 * One instruction per feature, twice: `user` for the person using the editor (what to do, in a sentence), `dev` for someone working on Gleamshelf (what runs,
 * where it lives, how to try it without the editor). The plain line is always on screen; the developer line shows when "Developer notes" is switched on.
 * Add an entry here with every new feature: instructions.test.ts checks each one has both, and that the plain line stays short.
 */
export interface HelpEntry {
    /** The section of the guide it is listed under. */
    group: HelpGroup;
    /** Its name in the guide. */
    name: string;
    user: string;
    dev: string;
}
export type HelpGroup = 'Top bar' | 'One click' | 'Cut out' | 'Clean up' | 'Adjust' | 'Edit mode' | 'Photo lab' | '3D mode';
export declare const HELP_GROUPS: readonly HelpGroup[];
export declare const HELP: {
    undo: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    compare: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    reset: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    editMode: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    photoLab: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    phone: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    done: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    guide: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    autoRun: {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    autoMode: {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    foundPhotos: {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    autoReport: {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    autoBack: {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.stickers': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.lettering': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.find': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.thinParts': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.colour': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.vivid': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.look': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.gloss': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.enlarge': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.listing': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    green: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    cutManual: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    'cut.tap': {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    'cut.erase': {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    'cut.restore': {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    fade: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    clearMask: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    aiCutout: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    studio: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    fidelityGuard: {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    flatten: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    listingHealth: {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    ground: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    listingSet: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    backdrop: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    square: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    stickers: {
        group: "Clean up";
        name: string;
        user: string;
        dev: string;
    };
    stickerClick: {
        group: "Clean up";
        name: string;
        user: string;
        dev: string;
    };
    textClick: {
        group: "Clean up";
        name: string;
        user: string;
        dev: string;
    };
    lettering: {
        group: "Clean up";
        name: string;
        user: string;
        dev: string;
    };
    letteringSliders: {
        group: "Clean up";
        name: string;
        user: string;
        dev: string;
    };
    aiFill: {
        group: "Clean up";
        name: string;
        user: string;
        dev: string;
    };
    finish: {
        group: "Clean up";
        name: string;
        user: string;
        dev: string;
    };
    rotate: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    crop: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    straighten: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    looks: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    autoLook: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    enlarge: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    light: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    color: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    recolour: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    effects: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    m3dAdd: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dOutlineShape: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dText: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dGroup: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dSvg: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dVideo: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dShapes: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dGizmo: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dView: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dImport: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dGrid: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dCombine: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dSize: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dMaterial: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dLook: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dOutline: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dLight: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dFloor: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dUse: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dMake: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dSave: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    labDevelop: {
        group: "Photo lab";
        name: string;
        user: string;
        dev: string;
    };
    labLooks: {
        group: "Photo lab";
        name: string;
        user: string;
        dev: string;
    };
    labTools: {
        group: "Photo lab";
        name: string;
        user: string;
        dev: string;
    };
    labSelect: {
        group: "Photo lab";
        name: string;
        user: string;
        dev: string;
    };
    labEverything: {
        group: "Photo lab";
        name: string;
        user: string;
        dev: string;
    };
    labLayers: {
        group: "Photo lab";
        name: string;
        user: string;
        dev: string;
    };
    labHistory: {
        group: "Photo lab";
        name: string;
        user: string;
        dev: string;
    };
    labFiles: {
        group: "Photo lab";
        name: string;
        user: string;
        dev: string;
    };
};
export type HelpId = keyof typeof HELP;
