import { type Recipe, type SourceInfo } from '../../core/src/index.js';
import type { ProcessHealth, ProcessStatus } from '../../models/src/index.js';
import { type ExportOptions, type ExportResult } from '../../render2d/src/index.js';
import './gleamshelf.css';
export interface GleamResult extends ExportResult {
    /** Save this next to the image; pass it back as `recipe` to continue editing from the original. */
    recipe: Recipe;
    source: SourceInfo;
    /** The background photo the recipe uses (when its backdrop is "image"), so the host can keep it with the edit. */
    backgroundPhoto?: Blob;
    /** The mask pictures of any AI cut-outs in the recipe, by the `ref` in the recipe. Keep them with the recipe. */
    cutoutMasks?: Record<string, Blob>;
    /** The pictures repainted by an AI fill, by the `ref` in the recipe's lettering step. Keep them with the recipe. */
    repairs?: Record<string, Blob>;
    /** The AI-enlarged picture, by the `ref` in the recipe's `upscale` step. Keep it with the recipe. */
    enlargements?: Record<string, Blob>;
    /** The AI-redrawn finishing picture, by the `ref` in the recipe's `finish` step. Keep it with the recipe. */
    finishes?: Record<string, Blob>;
}
export interface GleamEditorProps {
    /** The original photo: a File/Blob, or a URL whose server allows cross-origin reads (CORS). */
    source: Blob | string;
    /** File name, kept in the result. Taken from the File when not given. */
    name?: string;
    /** A recipe from an earlier result, to reopen that edit. */
    recipe?: unknown;
    /** A background photo to start with (for example the one saved with an earlier result), as a File/Blob or a CORS-readable URL. */
    background?: Blob | string;
    /** Mask pictures saved with an earlier result (`GleamResult.cutoutMasks`), by ref, so its AI cut-out reopens. */
    masks?: Record<string, Blob | string>;
    /** Pictures saved with an earlier result (`GleamResult.repairs`), by ref, so its AI-filled lettering reopens. */
    repairs?: Record<string, Blob | string>;
    /** Pictures saved with an earlier result (`GleamResult.enlargements`), by ref, so its AI enlarging reopens. */
    enlargements?: Record<string, Blob | string>;
    /** Pictures saved with an earlier result (`GleamResult.finishes`), by ref, so its AI finishing touches reopen. */
    finishes?: Record<string, Blob | string>;
    /** Where the companion app is, and its pairing token, if the host keeps them. Otherwise the editor remembers them itself. */
    localApp?: {
        url?: string;
        token?: string;
    };
    /** Size and format of the finished image; the host's own upload limits belong here. */
    exportOptions?: ExportOptions;
    onDone: (result: GleamResult) => void;
    onCancel?: () => void;
    doneLabel?: string;
}
/** What the companion app's whole-chain run reports, kept by the outer component because opening its result reloads the editor. */
/** What a run reported, and (in this browser) a picture of the parts no longer as photographed, when there are any. */
export type FullReport = NonNullable<ProcessStatus['report']> & {
    changesUrl?: string;
};
/** One step of the one-button chain, as shown to the person. */
export interface AutoStep {
    label: string;
    state: 'todo' | 'running' | 'done' | 'skipped';
    note?: string;
    /** For a run in the app: when the step began (the app's clock) and how long it took. */
    startedAt?: number;
    seconds?: number;
}
/** What the editor knows about a run in the companion app, for the live indicator (see RunHealth in Panel.tsx). */
export interface AutoWatch {
    health: ProcessHealth | null;
    /** When that report arrived (this browser's clock): elapsed times run on from it between reports. */
    receivedAt: number;
    queued: boolean;
    /** Status requests in a row that got no answer. */
    unanswered: number;
    stop: () => void;
}
export declare function GleamEditor({ source, name, recipe, background, masks, repairs, enlargements, finishes, localApp, exportOptions, onDone, onCancel, doneLabel, }: GleamEditorProps): import("react").JSX.Element;
