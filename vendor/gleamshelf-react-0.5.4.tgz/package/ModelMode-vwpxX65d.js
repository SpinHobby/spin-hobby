import { t as e } from "./rolldown-runtime-DArdT4gl.js";
import { c as t, l as n } from "./src-L5EyMOAw.js";
import { a as r, r as i, s as a } from "./Panel-Bat7k9QP.js";
import { c as o, l as s } from "./images-DAbNVxvX.js";
import { $ as c, $n as l, A as u, An as d, At as f, B as p, Bn as m, Bt as h, C as g, Cr as _, D as v, Dn as y, Dr as b, Dt as x, E as S, En as C, Er as w, Et as T, F as E, Ft as D, I as O, Jt as ee, Kn as k, L as A, Ln as te, M as ne, Mn as re, Mt as ie, Nt as ae, On as oe, Or as se, Ot as ce, P as le, Pt as ue, Qn as j, R as M, Rn as de, S as fe, Sr as pe, T as me, Tn as he, Tr as ge, Tt as _e, Ut as ve, Xn as ye, Yn as be, _ as xe, _r as Se, _t as N, ar as Ce, at as we, b as Te, br as Ee, bt as De, c as Oe, cr as ke, ct as Ae, d as je, dr as P, dt as Me, er as Ne, et as F, f as I, fr as L, ft as Pe, g as R, gr as Fe, gt as Ie, h as Le, hr as Re, ht as z, i as ze, it as B, j as V, jn as Be, jt as Ve, k as He, kn as Ue, l as We, lr as Ge, m as Ke, mt as qe, nr as Je, o as Ye, ot as Xe, p as Ze, pr as Qe, qn as $e, qt as et, rr as tt, rt as nt, s as rt, sr as it, st as at, tt as ot, ur as st, vr as ct, vt as lt, wn as ut, wr as dt, wt as ft, x as pt, xr as mt, y as ht, yr as gt, yt as _t, zn as vt } from "./three.core-Bn_95pMq.js";
import { A as yt, B as bt, C as xt, D as St, E as Ct, F as wt, H as Tt, I as Et, L as Dt, M as Ot, N as kt, O as At, P as jt, R as Mt, S as Nt, T as Pt, U as Ft, V as It, W as Lt, _ as Rt, a as zt, b as Bt, c as Vt, d as Ht, f as Ut, g as Wt, h as Gt, i as Kt, j as qt, k as Jt, l as Yt, m as Xt, n as Zt, o as Qt, p as $t, r as en, s as tn, u as nn, v as rn, w as an, x as on, y as sn, z as cn } from "./core-Ba-7Y5aI.js";
import { useEffect as ln, useRef as un, useState as H, useSyncExternalStore as dn } from "react";
import { Fragment as fn, jsx as U, jsxs as W } from "react/jsx-runtime";
//#region ../../node_modules/three/build/three.module.js
function pn() {
	let e = null, t = !1, n = null, r = null;
	function i(t, a) {
		r = e.requestAnimationFrame(i), n(t, a);
	}
	return {
		start: function() {
			t !== !0 && n !== null && e !== null && (r = e.requestAnimationFrame(i), t = !0);
		},
		stop: function() {
			e !== null && e.cancelAnimationFrame(r), t = !1;
		},
		setAnimationLoop: function(e) {
			n = e;
		},
		setContext: function(t) {
			e = t;
		}
	};
}
function mn(e) {
	let t = /* @__PURE__ */ new WeakMap();
	function n(t, n) {
		let r = t.array, i = t.usage, a = r.byteLength, o = e.createBuffer();
		e.bindBuffer(n, o), e.bufferData(n, r, i), t.onUploadCallback();
		let s;
		if (r instanceof Float32Array) s = e.FLOAT;
		else if (typeof Float16Array < "u" && r instanceof Float16Array) s = e.HALF_FLOAT;
		else if (r instanceof Uint16Array) s = t.isFloat16BufferAttribute ? e.HALF_FLOAT : e.UNSIGNED_SHORT;
		else if (r instanceof Int16Array) s = e.SHORT;
		else if (r instanceof Uint32Array) s = e.UNSIGNED_INT;
		else if (r instanceof Int32Array) s = e.INT;
		else if (r instanceof Int8Array) s = e.BYTE;
		else if (r instanceof Uint8Array) s = e.UNSIGNED_BYTE;
		else if (r instanceof Uint8ClampedArray) s = e.UNSIGNED_BYTE;
		else throw Error("THREE.WebGLAttributes: Unsupported buffer data format: " + r);
		return {
			buffer: o,
			type: s,
			bytesPerElement: r.BYTES_PER_ELEMENT,
			version: t.version,
			size: a
		};
	}
	function r(t, n, r) {
		let i = n.array, a = n.updateRanges;
		if (e.bindBuffer(r, t), a.length === 0) e.bufferSubData(r, 0, i);
		else {
			a.sort((e, t) => e.start - t.start);
			let t = 0;
			for (let e = 1; e < a.length; e++) {
				let n = a[t], r = a[e];
				r.start <= n.start + n.count + 1 ? n.count = Math.max(n.count, r.start + r.count - n.start) : (++t, a[t] = r);
			}
			a.length = t + 1;
			for (let t = 0, n = a.length; t < n; t++) {
				let n = a[t];
				e.bufferSubData(r, n.start * i.BYTES_PER_ELEMENT, i, n.start, n.count);
			}
			n.clearUpdateRanges();
		}
		n.onUploadCallback();
	}
	function i(e) {
		return e.isInterleavedBufferAttribute && (e = e.data), t.get(e);
	}
	function a(n) {
		n.isInterleavedBufferAttribute && (n = n.data);
		let r = t.get(n);
		r && (e.deleteBuffer(r.buffer), t.delete(n));
	}
	function o(e, i) {
		if (e.isInterleavedBufferAttribute && (e = e.data), e.isGLBufferAttribute) {
			let n = t.get(e);
			(!n || n.version < e.version) && t.set(e, {
				buffer: e.buffer,
				type: e.type,
				bytesPerElement: e.elementSize,
				version: e.version
			});
			return;
		}
		let a = t.get(e);
		if (a === void 0) t.set(e, n(e, i));
		else if (a.version < e.version) {
			if (a.size !== e.array.byteLength) throw Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");
			r(a.buffer, e, i), a.version = e.version;
		}
	}
	return {
		get: i,
		remove: a,
		update: o
	};
}
var G = {
	alphahash_fragment: "#ifdef USE_ALPHAHASH\n	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;\n#endif",
	alphahash_pars_fragment: "#ifdef USE_ALPHAHASH\n	const float ALPHA_HASH_SCALE = 0.05;\n	float hash2D( vec2 value ) {\n		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );\n	}\n	float hash3D( vec3 value ) {\n		return hash2D( vec2( hash2D( value.xy ), value.z ) );\n	}\n	float getAlphaHashThreshold( vec3 position ) {\n		float maxDeriv = max(\n			length( dFdx( position.xyz ) ),\n			length( dFdy( position.xyz ) )\n		);\n		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );\n		vec2 pixScales = vec2(\n			exp2( floor( log2( pixScale ) ) ),\n			exp2( ceil( log2( pixScale ) ) )\n		);\n		vec2 alpha = vec2(\n			hash3D( floor( pixScales.x * position.xyz ) ),\n			hash3D( floor( pixScales.y * position.xyz ) )\n		);\n		float lerpFactor = fract( log2( pixScale ) );\n		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;\n		float a = min( lerpFactor, 1.0 - lerpFactor );\n		vec3 cases = vec3(\n			x * x / ( 2.0 * a * ( 1.0 - a ) ),\n			( x - 0.5 * a ) / ( 1.0 - a ),\n			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )\n		);\n		float threshold = ( x < ( 1.0 - a ) )\n			? ( ( x < a ) ? cases.x : cases.y )\n			: cases.z;\n		return clamp( threshold , 1.0e-6, 1.0 );\n	}\n#endif",
	alphamap_fragment: "#ifdef USE_ALPHAMAP\n	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;\n#endif",
	alphamap_pars_fragment: "#ifdef USE_ALPHAMAP\n	uniform sampler2D alphaMap;\n#endif",
	alphatest_fragment: "#ifdef USE_ALPHATEST\n	#ifdef ALPHA_TO_COVERAGE\n	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );\n	if ( diffuseColor.a == 0.0 ) discard;\n	#else\n	if ( diffuseColor.a < alphaTest ) discard;\n	#endif\n#endif",
	alphatest_pars_fragment: "#ifdef USE_ALPHATEST\n	uniform float alphaTest;\n#endif",
	aomap_fragment: "#ifdef USE_AOMAP\n	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;\n	reflectedLight.indirectDiffuse *= ambientOcclusion;\n	#if defined( USE_CLEARCOAT ) \n		clearcoatSpecularIndirect *= ambientOcclusion;\n	#endif\n	#if defined( USE_SHEEN ) \n		sheenSpecularIndirect *= ambientOcclusion;\n	#endif\n	#if defined( USE_ENVMAP ) && defined( STANDARD )\n		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );\n		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );\n	#endif\n#endif",
	aomap_pars_fragment: "#ifdef USE_AOMAP\n	uniform sampler2D aoMap;\n	uniform float aoMapIntensity;\n#endif",
	batching_pars_vertex: "#ifdef USE_BATCHING\n	#if ! defined( GL_ANGLE_multi_draw )\n	#define gl_DrawID _gl_DrawID\n	uniform int _gl_DrawID;\n	#endif\n	uniform highp sampler2D batchingTexture;\n	uniform highp usampler2D batchingIdTexture;\n	mat4 getBatchingMatrix( const in float i ) {\n		int size = textureSize( batchingTexture, 0 ).x;\n		int j = int( i ) * 4;\n		int x = j % size;\n		int y = j / size;\n		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );\n		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );\n		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );\n		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );\n		return mat4( v1, v2, v3, v4 );\n	}\n	float getIndirectIndex( const in int i ) {\n		int size = textureSize( batchingIdTexture, 0 ).x;\n		int x = i % size;\n		int y = i / size;\n		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );\n	}\n#endif\n#ifdef USE_BATCHING_COLOR\n	uniform sampler2D batchingColorTexture;\n	vec4 getBatchingColor( const in float i ) {\n		int size = textureSize( batchingColorTexture, 0 ).x;\n		int j = int( i );\n		int x = j % size;\n		int y = j / size;\n		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );\n	}\n#endif",
	batching_vertex: "#ifdef USE_BATCHING\n	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );\n#endif",
	begin_vertex: "vec3 transformed = vec3( position );\n#ifdef USE_ALPHAHASH\n	vPosition = vec3( position );\n#endif",
	beginnormal_vertex: "vec3 objectNormal = vec3( normal );\n#ifdef USE_TANGENT\n	vec3 objectTangent = vec3( tangent.xyz );\n#endif",
	bsdfs: "float G_BlinnPhong_Implicit( ) {\n	return 0.25;\n}\nfloat D_BlinnPhong( const in float shininess, const in float dotNH ) {\n	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );\n}\nvec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {\n	vec3 halfDir = normalize( lightDir + viewDir );\n	float dotNH = saturate( dot( normal, halfDir ) );\n	float dotVH = saturate( dot( viewDir, halfDir ) );\n	vec3 F = F_Schlick( specularColor, 1.0, dotVH );\n	float G = G_BlinnPhong_Implicit( );\n	float D = D_BlinnPhong( shininess, dotNH );\n	return F * ( G * D );\n} // validated",
	iridescence_fragment: "#ifdef USE_IRIDESCENCE\n	const mat3 XYZ_TO_REC709 = mat3(\n		 3.2404542, -0.9692660,  0.0556434,\n		-1.5371385,  1.8760108, -0.2040259,\n		-0.4985314,  0.0415560,  1.0572252\n	);\n	vec3 Fresnel0ToIor( vec3 fresnel0 ) {\n		vec3 sqrtF0 = sqrt( fresnel0 );\n		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );\n	}\n	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {\n		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );\n	}\n	float IorToFresnel0( float transmittedIor, float incidentIor ) {\n		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));\n	}\n	vec3 evalSensitivity( float OPD, vec3 shift ) {\n		float phase = 2.0 * PI * OPD * 1.0e-9;\n		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );\n		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );\n		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );\n		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );\n		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );\n		xyz /= 1.0685e-7;\n		vec3 rgb = XYZ_TO_REC709 * xyz;\n		return rgb;\n	}\n	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {\n		vec3 I;\n		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );\n		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );\n		float cosTheta2Sq = 1.0 - sinTheta2Sq;\n		if ( cosTheta2Sq < 0.0 ) {\n			return vec3( 1.0 );\n		}\n		float cosTheta2 = sqrt( cosTheta2Sq );\n		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );\n		float R12 = F_Schlick( R0, 1.0, cosTheta1 );\n		float T121 = 1.0 - R12;\n		float phi12 = 0.0;\n		if ( iridescenceIOR < outsideIOR ) phi12 = PI;\n		float phi21 = PI - phi12;\n		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );\n		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );\n		vec3 phi23 = vec3( 0.0 );\n		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;\n		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;\n		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;\n		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;\n		vec3 phi = vec3( phi21 ) + phi23;\n		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );\n		vec3 r123 = sqrt( R123 );\n		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );\n		vec3 C0 = R12 + Rs;\n		I = C0;\n		vec3 Cm = Rs - T121;\n		for ( int m = 1; m <= 2; ++ m ) {\n			Cm *= r123;\n			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );\n			I += Cm * Sm;\n		}\n		return max( I, vec3( 0.0 ) );\n	}\n#endif",
	bumpmap_pars_fragment: "#ifdef USE_BUMPMAP\n	uniform sampler2D bumpMap;\n	uniform float bumpScale;\n	vec2 dHdxy_fwd() {\n		vec2 dSTdx = dFdx( vBumpMapUv );\n		vec2 dSTdy = dFdy( vBumpMapUv );\n		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;\n		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;\n		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;\n		return vec2( dBx, dBy );\n	}\n	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {\n		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );\n		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );\n		vec3 vN = surf_norm;\n		vec3 R1 = cross( vSigmaY, vN );\n		vec3 R2 = cross( vN, vSigmaX );\n		float fDet = dot( vSigmaX, R1 ) * faceDirection;\n		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );\n		return normalize( abs( fDet ) * surf_norm - vGrad );\n	}\n#endif",
	clipping_planes_fragment: "#if NUM_CLIPPING_PLANES > 0\n	vec4 plane;\n	#ifdef ALPHA_TO_COVERAGE\n		float distanceToPlane, distanceGradient;\n		float clipOpacity = 1.0;\n		#pragma unroll_loop_start\n		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {\n			plane = clippingPlanes[ i ];\n			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;\n			distanceGradient = fwidth( distanceToPlane ) / 2.0;\n			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );\n			if ( clipOpacity == 0.0 ) discard;\n		}\n		#pragma unroll_loop_end\n		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES\n			float unionClipOpacity = 1.0;\n			#pragma unroll_loop_start\n			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {\n				plane = clippingPlanes[ i ];\n				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;\n				distanceGradient = fwidth( distanceToPlane ) / 2.0;\n				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );\n			}\n			#pragma unroll_loop_end\n			clipOpacity *= 1.0 - unionClipOpacity;\n		#endif\n		diffuseColor.a *= clipOpacity;\n		if ( diffuseColor.a == 0.0 ) discard;\n	#else\n		#pragma unroll_loop_start\n		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {\n			plane = clippingPlanes[ i ];\n			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;\n		}\n		#pragma unroll_loop_end\n		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES\n			bool clipped = true;\n			#pragma unroll_loop_start\n			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {\n				plane = clippingPlanes[ i ];\n				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;\n			}\n			#pragma unroll_loop_end\n			if ( clipped ) discard;\n		#endif\n	#endif\n#endif",
	clipping_planes_pars_fragment: "#if NUM_CLIPPING_PLANES > 0\n	varying vec3 vClipPosition;\n	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];\n#endif",
	clipping_planes_pars_vertex: "#if NUM_CLIPPING_PLANES > 0\n	varying vec3 vClipPosition;\n#endif",
	clipping_planes_vertex: "#if NUM_CLIPPING_PLANES > 0\n	vClipPosition = - mvPosition.xyz;\n#endif",
	color_fragment: "#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )\n	diffuseColor *= vColor;\n#endif",
	color_pars_fragment: "#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )\n	varying vec4 vColor;\n#endif",
	color_pars_vertex: "#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )\n	varying vec4 vColor;\n#endif",
	color_vertex: "#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )\n	vColor = vec4( 1.0 );\n#endif\n#ifdef USE_COLOR_ALPHA\n	vColor *= color;\n#elif defined( USE_COLOR )\n	vColor.rgb *= color;\n#endif\n#ifdef USE_INSTANCING_COLOR\n	vColor.rgb *= instanceColor.rgb;\n#endif\n#ifdef USE_BATCHING_COLOR\n	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );\n#endif",
	common: "#define PI 3.141592653589793\n#define PI2 6.283185307179586\n#define PI_HALF 1.5707963267948966\n#define RECIPROCAL_PI 0.3183098861837907\n#define RECIPROCAL_PI2 0.15915494309189535\n#define EPSILON 1e-6\n#ifndef saturate\n#define saturate( a ) clamp( a, 0.0, 1.0 )\n#endif\n#define whiteComplement( a ) ( 1.0 - saturate( a ) )\nfloat pow2( const in float x ) { return x*x; }\nvec3 pow2( const in vec3 x ) { return x*x; }\nfloat pow3( const in float x ) { return x*x*x; }\nfloat pow4( const in float x ) { float x2 = x*x; return x2*x2; }\nfloat max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }\nfloat average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }\nhighp float rand( const in vec2 uv ) {\n	const highp float a = 12.9898, b = 78.233, c = 43758.5453;\n	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );\n	return fract( sin( sn ) * c );\n}\n#ifdef HIGH_PRECISION\n	float precisionSafeLength( vec3 v ) { return length( v ); }\n#else\n	float precisionSafeLength( vec3 v ) {\n		float maxComponent = max3( abs( v ) );\n		return length( v / maxComponent ) * maxComponent;\n	}\n#endif\nstruct IncidentLight {\n	vec3 color;\n	vec3 direction;\n	bool visible;\n};\nstruct ReflectedLight {\n	vec3 directDiffuse;\n	vec3 directSpecular;\n	vec3 indirectDiffuse;\n	vec3 indirectSpecular;\n};\n#ifdef USE_ALPHAHASH\n	varying vec3 vPosition;\n#endif\nvec3 transformDirection( in vec3 dir, in mat4 matrix ) {\n	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );\n}\n#define inverseTransformDirection transformDirectionByInverseViewMatrix\nvec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {\n	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );\n}\nvec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {\n	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );\n}\nbool isPerspectiveMatrix( mat4 m ) {\n	return m[ 2 ][ 3 ] == - 1.0;\n}\nvec2 equirectUv( in vec3 dir ) {\n	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;\n	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;\n	return vec2( u, v );\n}\nvec3 BRDF_Lambert( const in vec3 diffuseColor ) {\n	return RECIPROCAL_PI * diffuseColor;\n}\nvec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {\n	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );\n	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );\n}\nfloat F_Schlick( const in float f0, const in float f90, const in float dotVH ) {\n	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );\n	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );\n} // validated",
	cube_uv_reflection_fragment: "#ifdef ENVMAP_TYPE_CUBE_UV\n	#define cubeUV_minMipLevel 4.0\n	#define cubeUV_minTileSize 16.0\n	float getFace( vec3 direction ) {\n		vec3 absDirection = abs( direction );\n		float face = - 1.0;\n		if ( absDirection.x > absDirection.z ) {\n			if ( absDirection.x > absDirection.y )\n				face = direction.x > 0.0 ? 0.0 : 3.0;\n			else\n				face = direction.y > 0.0 ? 1.0 : 4.0;\n		} else {\n			if ( absDirection.z > absDirection.y )\n				face = direction.z > 0.0 ? 2.0 : 5.0;\n			else\n				face = direction.y > 0.0 ? 1.0 : 4.0;\n		}\n		return face;\n	}\n	vec2 getUV( vec3 direction, float face ) {\n		vec2 uv;\n		if ( face == 0.0 ) {\n			uv = vec2( direction.z, direction.y ) / abs( direction.x );\n		} else if ( face == 1.0 ) {\n			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );\n		} else if ( face == 2.0 ) {\n			uv = vec2( - direction.x, direction.y ) / abs( direction.z );\n		} else if ( face == 3.0 ) {\n			uv = vec2( - direction.z, direction.y ) / abs( direction.x );\n		} else if ( face == 4.0 ) {\n			uv = vec2( - direction.x, direction.z ) / abs( direction.y );\n		} else {\n			uv = vec2( direction.x, direction.y ) / abs( direction.z );\n		}\n		return 0.5 * ( uv + 1.0 );\n	}\n	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {\n		float face = getFace( direction );\n		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );\n		mipInt = max( mipInt, cubeUV_minMipLevel );\n		float faceSize = exp2( mipInt );\n		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;\n		if ( face > 2.0 ) {\n			uv.y += faceSize;\n			face -= 3.0;\n		}\n		uv.x += face * faceSize;\n		uv.x += filterInt * 3.0 * cubeUV_minTileSize;\n		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );\n		uv.x *= CUBEUV_TEXEL_WIDTH;\n		uv.y *= CUBEUV_TEXEL_HEIGHT;\n		#ifdef texture2DGradEXT\n			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;\n		#else\n			return texture2D( envMap, uv ).rgb;\n		#endif\n	}\n	#define cubeUV_r0 1.0\n	#define cubeUV_m0 - 2.0\n	#define cubeUV_r1 0.8\n	#define cubeUV_m1 - 1.0\n	#define cubeUV_r4 0.4\n	#define cubeUV_m4 2.0\n	#define cubeUV_r5 0.305\n	#define cubeUV_m5 3.0\n	#define cubeUV_r6 0.21\n	#define cubeUV_m6 4.0\n	float roughnessToMip( float roughness ) {\n		float mip = 0.0;\n		if ( roughness >= cubeUV_r1 ) {\n			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;\n		} else if ( roughness >= cubeUV_r4 ) {\n			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;\n		} else if ( roughness >= cubeUV_r5 ) {\n			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;\n		} else if ( roughness >= cubeUV_r6 ) {\n			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;\n		} else {\n			mip = - 2.0 * log2( 1.16 * roughness );		}\n		return mip;\n	}\n	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {\n		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );\n		float mipF = fract( mip );\n		float mipInt = floor( mip );\n		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );\n		if ( mipF == 0.0 ) {\n			return vec4( color0, 1.0 );\n		} else {\n			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );\n			return vec4( mix( color0, color1, mipF ), 1.0 );\n		}\n	}\n#endif",
	defaultnormal_vertex: "vec3 transformedNormal = objectNormal;\n#ifdef USE_TANGENT\n	vec3 transformedTangent = objectTangent;\n#endif\n#ifdef USE_BATCHING\n	mat3 bm = mat3( batchingMatrix );\n	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );\n	transformedNormal = bm * transformedNormal;\n	#ifdef USE_TANGENT\n		transformedTangent = bm * transformedTangent;\n	#endif\n#endif\n#ifdef USE_INSTANCING\n	mat3 im = mat3( instanceMatrix );\n	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );\n	transformedNormal = im * transformedNormal;\n	#ifdef USE_TANGENT\n		transformedTangent = im * transformedTangent;\n	#endif\n#endif\ntransformedNormal = normalMatrix * transformedNormal;\n#ifdef FLIP_SIDED\n	transformedNormal = - transformedNormal;\n#endif\n#ifdef USE_TANGENT\n	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;\n#endif",
	displacementmap_pars_vertex: "#ifdef USE_DISPLACEMENTMAP\n	uniform sampler2D displacementMap;\n	uniform float displacementScale;\n	uniform float displacementBias;\n#endif",
	displacementmap_vertex: "#ifdef USE_DISPLACEMENTMAP\n	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );\n#endif",
	emissivemap_fragment: "#ifdef USE_EMISSIVEMAP\n	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );\n	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE\n		emissiveColor = sRGBTransferEOTF( emissiveColor );\n	#endif\n	totalEmissiveRadiance *= emissiveColor.rgb;\n#endif",
	emissivemap_pars_fragment: "#ifdef USE_EMISSIVEMAP\n	uniform sampler2D emissiveMap;\n#endif",
	colorspace_fragment: "gl_FragColor = linearToOutputTexel( gl_FragColor );",
	colorspace_pars_fragment: "vec4 LinearTransferOETF( in vec4 value ) {\n	return value;\n}\nvec4 sRGBTransferEOTF( in vec4 value ) {\n	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );\n}\nvec4 sRGBTransferOETF( in vec4 value ) {\n	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );\n}",
	envmap_fragment: "#ifdef USE_ENVMAP\n	#ifdef ENV_WORLDPOS\n		vec3 cameraToFrag;\n		if ( isOrthographic ) {\n			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );\n		} else {\n			cameraToFrag = normalize( vWorldPosition - cameraPosition );\n		}\n		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );\n		#ifdef ENVMAP_MODE_REFLECTION\n			vec3 reflectVec = reflect( cameraToFrag, worldNormal );\n		#else\n			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );\n		#endif\n	#else\n		vec3 reflectVec = vReflect;\n	#endif\n	#ifdef ENVMAP_TYPE_CUBE\n		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );\n		#ifdef ENVMAP_BLENDING_MULTIPLY\n			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );\n		#elif defined( ENVMAP_BLENDING_MIX )\n			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );\n		#elif defined( ENVMAP_BLENDING_ADD )\n			outgoingLight += envColor.xyz * specularStrength * reflectivity;\n		#endif\n	#endif\n#endif",
	envmap_common_pars_fragment: "#ifdef USE_ENVMAP\n	uniform float envMapIntensity;\n	uniform mat3 envMapRotation;\n	#ifdef ENVMAP_TYPE_CUBE\n		uniform samplerCube envMap;\n	#else\n		uniform sampler2D envMap;\n	#endif\n#endif",
	envmap_pars_fragment: "#ifdef USE_ENVMAP\n	uniform float reflectivity;\n	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )\n		#define ENV_WORLDPOS\n	#endif\n	#ifdef ENV_WORLDPOS\n		varying vec3 vWorldPosition;\n		uniform float refractionRatio;\n	#else\n		varying vec3 vReflect;\n	#endif\n#endif",
	envmap_pars_vertex: "#ifdef USE_ENVMAP\n	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )\n		#define ENV_WORLDPOS\n	#endif\n	#ifdef ENV_WORLDPOS\n		\n		varying vec3 vWorldPosition;\n	#else\n		varying vec3 vReflect;\n		uniform float refractionRatio;\n	#endif\n#endif",
	envmap_physical_pars_fragment: "#ifdef USE_ENVMAP\n	vec3 getIBLIrradiance( const in vec3 normal ) {\n		#ifdef ENVMAP_TYPE_CUBE_UV\n			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );\n			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );\n			return PI * envMapColor.rgb * envMapIntensity;\n		#else\n			return vec3( 0.0 );\n		#endif\n	}\n	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {\n		#ifdef ENVMAP_TYPE_CUBE_UV\n			vec3 reflectVec = reflect( - viewDir, normal );\n			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );\n			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );\n			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );\n			return envMapColor.rgb * envMapIntensity;\n		#else\n			return vec3( 0.0 );\n		#endif\n	}\n	#ifdef USE_RETROREFLECTION\n		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {\n			#ifdef ENVMAP_TYPE_CUBE_UV\n				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );\n				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );\n				vec4 envMapColor = textureCubeUV( envMap, envMapRotation * retroVec, roughness );\n				return envMapColor.rgb * envMapIntensity;\n			#else\n				return vec3( 0.0 );\n			#endif\n		}\n	#endif\n	#ifdef USE_ANISOTROPY\n		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {\n			#ifdef ENVMAP_TYPE_CUBE_UV\n				vec3 bentNormal = cross( bitangent, viewDir );\n				bentNormal = normalize( cross( bentNormal, bitangent ) );\n				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );\n				return getIBLRadiance( viewDir, bentNormal, roughness );\n			#else\n				return vec3( 0.0 );\n			#endif\n		}\n		#ifdef USE_RETROREFLECTION\n			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {\n				#ifdef ENVMAP_TYPE_CUBE_UV\n					vec3 bentNormal = cross( bitangent, viewDir );\n					bentNormal = normalize( cross( bentNormal, bitangent ) );\n					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );\n					return getIBLRetroRadiance( viewDir, bentNormal, roughness );\n				#else\n					return vec3( 0.0 );\n				#endif\n			}\n		#endif\n	#endif\n#endif",
	envmap_vertex: "#ifdef USE_ENVMAP\n	#ifdef ENV_WORLDPOS\n		vWorldPosition = worldPosition.xyz;\n	#else\n		vec3 cameraToVertex;\n		if ( isOrthographic ) {\n			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );\n		} else {\n			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );\n		}\n		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );\n		#ifdef ENVMAP_MODE_REFLECTION\n			vReflect = reflect( cameraToVertex, worldNormal );\n		#else\n			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );\n		#endif\n	#endif\n#endif",
	fog_vertex: "#ifdef USE_FOG\n	vFogDepth = - mvPosition.z;\n#endif",
	fog_pars_vertex: "#ifdef USE_FOG\n	varying float vFogDepth;\n#endif",
	fog_fragment: "#ifdef USE_FOG\n	#ifdef FOG_EXP2\n		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );\n	#else\n		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );\n	#endif\n	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );\n#endif",
	fog_pars_fragment: "#ifdef USE_FOG\n	uniform vec3 fogColor;\n	varying float vFogDepth;\n	#ifdef FOG_EXP2\n		uniform float fogDensity;\n	#else\n		uniform float fogNear;\n		uniform float fogFar;\n	#endif\n#endif",
	gradientmap_pars_fragment: "#ifdef USE_GRADIENTMAP\n	uniform sampler2D gradientMap;\n#endif\nvec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {\n	float dotNL = dot( normal, lightDirection );\n	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );\n	#ifdef USE_GRADIENTMAP\n		return vec3( texture2D( gradientMap, coord ).r );\n	#else\n		vec2 fw = fwidth( coord ) * 0.5;\n		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );\n	#endif\n}",
	lightmap_pars_fragment: "#ifdef USE_LIGHTMAP\n	uniform sampler2D lightMap;\n	uniform float lightMapIntensity;\n#endif",
	lights_lambert_fragment: "LambertMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb;\nmaterial.specularStrength = specularStrength;",
	lights_lambert_pars_fragment: "varying vec3 vViewPosition;\nstruct LambertMaterial {\n	vec3 diffuseColor;\n	float specularStrength;\n};\nvoid RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {\n	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );\n	vec3 irradiance = dotNL * directLight.color;\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\nvoid RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {\n	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\n#define RE_Direct				RE_Direct_Lambert\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert",
	lights_pars_begin: "uniform bool receiveShadow;\nuniform vec3 ambientLightColor;\n#if defined( USE_LIGHT_PROBES )\n	uniform vec3 lightProbe[ 9 ];\n#endif\nvec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {\n	float x = normal.x, y = normal.y, z = normal.z;\n	vec3 result = shCoefficients[ 0 ] * 0.886227;\n	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;\n	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;\n	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;\n	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;\n	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;\n	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );\n	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;\n	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );\n	return result;\n}\nvec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {\n	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );\n	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );\n	return irradiance;\n}\nvec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {\n	vec3 irradiance = ambientLightColor;\n	return irradiance;\n}\nfloat getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {\n	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );\n	if ( cutoffDistance > 0.0 ) {\n		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );\n	}\n	return distanceFalloff;\n}\nfloat getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {\n	return smoothstep( coneCosine, penumbraCosine, angleCosine );\n}\n#if NUM_SUN_LIGHTS > 0\n	struct SunLight {\n		vec3 direction;\n		vec3 color;\n	};\n	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];\n	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {\n		light.color = sunLight.color;\n		light.direction = sunLight.direction;\n		light.visible = true;\n	}\n#endif\n#if NUM_DIR_LIGHTS > 0\n	struct DirectionalLight {\n		vec3 direction;\n		vec3 color;\n	};\n	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];\n	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {\n		light.color = directionalLight.color;\n		light.direction = directionalLight.direction;\n		light.visible = true;\n	}\n#endif\n#if NUM_POINT_LIGHTS > 0\n	struct PointLight {\n		vec3 position;\n		vec3 color;\n		float distance;\n		float decay;\n	};\n	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];\n	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {\n		vec3 lVector = pointLight.position - geometryPosition;\n		light.direction = normalize( lVector );\n		float lightDistance = length( lVector );\n		light.color = pointLight.color;\n		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );\n		light.visible = ( light.color != vec3( 0.0 ) );\n	}\n#endif\n#if NUM_SPOT_LIGHTS > 0\n	struct SpotLight {\n		vec3 position;\n		vec3 direction;\n		vec3 color;\n		float distance;\n		float decay;\n		float coneCos;\n		float penumbraCos;\n	};\n	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];\n	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {\n		vec3 lVector = spotLight.position - geometryPosition;\n		light.direction = normalize( lVector );\n		float angleCos = dot( light.direction, spotLight.direction );\n		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );\n		if ( spotAttenuation > 0.0 ) {\n			float lightDistance = length( lVector );\n			light.color = spotLight.color * spotAttenuation;\n			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );\n			light.visible = ( light.color != vec3( 0.0 ) );\n		} else {\n			light.color = vec3( 0.0 );\n			light.visible = false;\n		}\n	}\n#endif\n#if NUM_RECT_AREA_LIGHTS > 0\n	struct RectAreaLight {\n		vec3 color;\n		vec3 position;\n		vec3 halfWidth;\n		vec3 halfHeight;\n	};\n	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;\n	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];\n#endif\n#if NUM_HEMI_LIGHTS > 0\n	struct HemisphereLight {\n		vec3 direction;\n		vec3 skyColor;\n		vec3 groundColor;\n	};\n	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];\n	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {\n		float dotNL = dot( normal, hemiLight.direction );\n		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;\n		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );\n		return irradiance;\n	}\n#endif\n#include <lightprobes_pars_fragment>",
	lights_toon_fragment: "ToonMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb;",
	lights_toon_pars_fragment: "varying vec3 vViewPosition;\nstruct ToonMaterial {\n	vec3 diffuseColor;\n};\nvoid RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {\n	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\nvoid RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {\n	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\n#define RE_Direct				RE_Direct_Toon\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon",
	lights_phong_fragment: "BlinnPhongMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb;\nmaterial.specularColor = specular;\nmaterial.specularShininess = shininess;\nmaterial.specularStrength = specularStrength;",
	lights_phong_pars_fragment: "varying vec3 vViewPosition;\nstruct BlinnPhongMaterial {\n	vec3 diffuseColor;\n	vec3 specularColor;\n	float specularShininess;\n	float specularStrength;\n};\nvoid RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {\n	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );\n	vec3 irradiance = dotNL * directLight.color;\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;\n}\nvoid RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {\n	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\n#define RE_Direct				RE_Direct_BlinnPhong\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong",
	lights_physical_fragment: "PhysicalMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb;\nmaterial.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );\nmaterial.metalness = metalnessFactor;\nvec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );\nfloat geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );\nmaterial.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;\nmaterial.roughness = min( material.roughness, 1.0 );\n#ifdef IOR\n	material.ior = ior;\n	#ifdef USE_SPECULAR\n		float specularIntensityFactor = specularIntensity;\n		vec3 specularColorFactor = specularColor;\n		#ifdef USE_SPECULAR_COLORMAP\n			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;\n		#endif\n		#ifdef USE_SPECULAR_INTENSITYMAP\n			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;\n		#endif\n		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );\n	#else\n		float specularIntensityFactor = 1.0;\n		vec3 specularColorFactor = vec3( 1.0 );\n		material.specularF90 = 1.0;\n	#endif\n	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;\n	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );\n#else\n	material.specularColor = vec3( 0.04 );\n	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );\n	material.specularF90 = 1.0;\n#endif\n#ifdef USE_CLEARCOAT\n	material.clearcoat = clearcoat;\n	material.clearcoatRoughness = clearcoatRoughness;\n	material.clearcoatF0 = vec3( 0.04 );\n	material.clearcoatF90 = 1.0;\n	#ifdef USE_CLEARCOATMAP\n		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;\n	#endif\n	#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;\n	#endif\n	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );\n	material.clearcoatRoughness += geometryRoughness;\n	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );\n#endif\n#ifdef USE_DISPERSION\n	material.dispersion = dispersion;\n#endif\n#ifdef USE_RETROREFLECTION\n	material.retroreflectivity = retroreflectivity;\n#endif\n#ifdef USE_IRIDESCENCE\n	material.iridescence = iridescence;\n	material.iridescenceIOR = iridescenceIOR;\n	#ifdef USE_IRIDESCENCEMAP\n		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;\n	#endif\n	#ifdef USE_IRIDESCENCE_THICKNESSMAP\n		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;\n	#else\n		material.iridescenceThickness = iridescenceThicknessMaximum;\n	#endif\n#endif\n#ifdef USE_SHEEN\n	material.sheenColor = sheenColor;\n	#ifdef USE_SHEEN_COLORMAP\n		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;\n	#endif\n	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );\n	#ifdef USE_SHEEN_ROUGHNESSMAP\n		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;\n	#endif\n#endif\n#ifdef USE_ANISOTROPY\n	#ifdef USE_ANISOTROPYMAP\n		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );\n		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;\n		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;\n	#else\n		vec2 anisotropyV = anisotropyVector;\n	#endif\n	material.anisotropy = length( anisotropyV );\n	if( material.anisotropy == 0.0 ) {\n		anisotropyV = vec2( 1.0, 0.0 );\n	} else {\n		anisotropyV /= material.anisotropy;\n		material.anisotropy = saturate( material.anisotropy );\n	}\n	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );\n	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;\n	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;\n#endif",
	lights_physical_pars_fragment: "uniform sampler2D dfgLUT;\nstruct PhysicalMaterial {\n	vec3 diffuseColor;\n	vec3 diffuseContribution;\n	vec3 specularColor;\n	vec3 specularColorBlended;\n	float roughness;\n	float metalness;\n	float specularF90;\n	float dispersion;\n	vec2 dfg;\n	vec3 multiScatteringCompensation;\n	#ifdef USE_RETROREFLECTION\n		float retroreflectivity;\n	#endif\n	#ifdef USE_CLEARCOAT\n		float clearcoat;\n		float clearcoatRoughness;\n		vec3 clearcoatF0;\n		float clearcoatF90;\n	#endif\n	#ifdef USE_IRIDESCENCE\n		float iridescence;\n		float iridescenceIOR;\n		float iridescenceThickness;\n		vec3 iridescenceFresnel;\n		vec3 iridescenceF0Dielectric;\n		vec3 iridescenceF0Metallic;\n	#endif\n	#ifdef USE_SHEEN\n		vec3 sheenColor;\n		float sheenRoughness;\n	#endif\n	#ifdef IOR\n		float ior;\n	#endif\n	#ifdef USE_TRANSMISSION\n		float transmission;\n		float transmissionAlpha;\n		float thickness;\n		float attenuationDistance;\n		vec3 attenuationColor;\n	#endif\n	#ifdef USE_ANISOTROPY\n		float anisotropy;\n		float alphaT;\n		vec3 anisotropyT;\n		vec3 anisotropyB;\n	#endif\n};\nvec3 clearcoatSpecularDirect = vec3( 0.0 );\nvec3 clearcoatSpecularIndirect = vec3( 0.0 );\nvec3 sheenSpecularDirect = vec3( 0.0 );\nvec3 sheenSpecularIndirect = vec3(0.0 );\nvec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {\n    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );\n    float x2 = x * x;\n    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );\n    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );\n}\nfloat V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {\n	float a2 = pow2( alpha );\n	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );\n	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );\n	return 0.5 / max( gv + gl, EPSILON );\n}\nfloat D_GGX( const in float alpha, const in float dotNH ) {\n	float a2 = pow2( alpha );\n	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;\n	return RECIPROCAL_PI * a2 / pow2( denom );\n}\n#ifdef USE_ANISOTROPY\n	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {\n		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );\n		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );\n		return 0.5 / max( gv + gl, EPSILON );\n	}\n	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {\n		float a2 = alphaT * alphaB;\n		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );\n		highp float v2 = dot( v, v );\n		float w2 = a2 / v2;\n		return RECIPROCAL_PI * a2 * pow2 ( w2 );\n	}\n#endif\n#ifdef USE_CLEARCOAT\n	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {\n		vec3 f0 = material.clearcoatF0;\n		float f90 = material.clearcoatF90;\n		float roughness = material.clearcoatRoughness;\n		float alpha = pow2( roughness );\n		vec3 halfDir = normalize( lightDir + viewDir );\n		float dotNL = saturate( dot( normal, lightDir ) );\n		float dotNV = saturate( dot( normal, viewDir ) );\n		float dotNH = saturate( dot( normal, halfDir ) );\n		float dotVH = saturate( dot( viewDir, halfDir ) );\n		vec3 F = F_Schlick( f0, f90, dotVH );\n		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );\n		float D = D_GGX( alpha, dotNH );\n		return F * ( V * D );\n	}\n#endif\nvec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {\n	vec3 f0 = material.specularColorBlended;\n	float f90 = material.specularF90;\n	float roughness = material.roughness;\n	float alpha = pow2( roughness );\n	vec3 halfDir = normalize( lightDir + viewDir );\n	float dotNL = saturate( dot( normal, lightDir ) );\n	float dotNV = saturate( dot( normal, viewDir ) );\n	float dotNH = saturate( dot( normal, halfDir ) );\n	float dotVH = saturate( dot( viewDir, halfDir ) );\n	vec3 F = F_Schlick( f0, f90, dotVH );\n	#ifdef USE_IRIDESCENCE\n		F = mix( F, material.iridescenceFresnel, material.iridescence );\n	#endif\n	#ifdef USE_ANISOTROPY\n		float dotTL = dot( material.anisotropyT, lightDir );\n		float dotTV = dot( material.anisotropyT, viewDir );\n		float dotTH = dot( material.anisotropyT, halfDir );\n		float dotBL = dot( material.anisotropyB, lightDir );\n		float dotBV = dot( material.anisotropyB, viewDir );\n		float dotBH = dot( material.anisotropyB, halfDir );\n		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );\n		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );\n	#else\n		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );\n		float D = D_GGX( alpha, dotNH );\n	#endif\n	return F * ( V * D );\n}\nvec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {\n	const float LUT_SIZE = 64.0;\n	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;\n	const float LUT_BIAS = 0.5 / LUT_SIZE;\n	float dotNV = saturate( dot( N, V ) );\n	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );\n	uv = uv * LUT_SCALE + LUT_BIAS;\n	return uv;\n}\nfloat LTC_ClippedSphereFormFactor( const in vec3 f ) {\n	float l = length( f );\n	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );\n}\nvec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {\n	float x = dot( v1, v2 );\n	float y = abs( x );\n	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;\n	float b = 3.4175940 + ( 4.1616724 + y ) * y;\n	float v = a / b;\n	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;\n	return cross( v1, v2 ) * theta_sintheta;\n}\nvec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {\n	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];\n	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];\n	vec3 lightNormal = cross( v1, v2 );\n	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );\n	vec3 T1, T2;\n	T1 = normalize( V - N * dot( V, N ) );\n	T2 = - cross( N, T1 );\n	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );\n	vec3 coords[ 4 ];\n	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );\n	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );\n	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );\n	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );\n	coords[ 0 ] = normalize( coords[ 0 ] );\n	coords[ 1 ] = normalize( coords[ 1 ] );\n	coords[ 2 ] = normalize( coords[ 2 ] );\n	coords[ 3 ] = normalize( coords[ 3 ] );\n	vec3 vectorFormFactor = vec3( 0.0 );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );\n	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );\n	return vec3( result );\n}\n#if defined( USE_SHEEN )\nfloat D_Charlie( float roughness, float dotNH ) {\n	float alpha = pow2( roughness );\n	float invAlpha = 1.0 / alpha;\n	float cos2h = dotNH * dotNH;\n	float sin2h = max( 1.0 - cos2h, 0.0078125 );\n	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );\n}\nfloat V_Neubelt( float dotNV, float dotNL ) {\n	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );\n}\nvec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {\n	vec3 halfDir = normalize( lightDir + viewDir );\n	float dotNL = saturate( dot( normal, lightDir ) );\n	float dotNV = saturate( dot( normal, viewDir ) );\n	float dotNH = saturate( dot( normal, halfDir ) );\n	float D = D_Charlie( sheenRoughness, dotNH );\n	float V = V_Neubelt( dotNV, dotNL );\n	return sheenColor * ( D * V );\n}\n#endif\nfloat IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {\n	float dotNV = saturate( dot( normal, viewDir ) );\n	float r2 = roughness * roughness;\n	float rInv = 1.0 / ( roughness + 0.1 );\n	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;\n	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;\n	float DG = exp( a * dotNV + b );\n	return saturate( DG );\n}\nvec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {\n	float dotNV = saturate( dot( normal, viewDir ) );\n	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;\n	return specularColor * fab.x + specularF90 * fab.y;\n}\n#ifdef USE_IRIDESCENCE\nvoid computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {\n#else\nvoid computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {\n#endif\n	#ifdef USE_IRIDESCENCE\n		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );\n	#else\n		vec3 Fr = specularColor;\n	#endif\n	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;\n	float Ess = fab.x + fab.y;\n	float Ems = 1.0 - Ess;\n	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );\n	singleScatter += FssEss;\n	multiScatter += Fms * Ems;\n}\n#if NUM_RECT_AREA_LIGHTS > 0\n	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {\n		vec3 normal = geometryNormal;\n		vec3 viewDir = geometryViewDir;\n		vec3 position = geometryPosition;\n		vec3 lightPos = rectAreaLight.position;\n		vec3 halfWidth = rectAreaLight.halfWidth;\n		vec3 halfHeight = rectAreaLight.halfHeight;\n		vec3 lightColor = rectAreaLight.color;\n		float roughness = material.roughness;\n		vec3 rectCoords[ 4 ];\n		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;\n		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;\n		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;\n		vec2 uv = LTC_Uv( normal, viewDir, roughness );\n		vec4 t1 = texture2D( ltc_1, uv );\n		vec4 t2 = texture2D( ltc_2, uv );\n		mat3 mInv = mat3(\n			vec3( t1.x, 0, t1.y ),\n			vec3(    0, 1,    0 ),\n			vec3( t1.z, 0, t1.w )\n		);\n		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );\n		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );\n		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );\n		#ifdef USE_CLEARCOAT\n			vec3 Ncc = geometryClearcoatNormal;\n			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );\n			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );\n			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );\n			mat3 mInvClearcoat = mat3(\n				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),\n				vec3(             0, 1,             0 ),\n				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )\n			);\n			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;\n			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );\n		#endif\n	}\n#endif\nvoid RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {\n	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );\n	vec3 irradiance = dotNL * directLight.color;\n	#ifdef USE_CLEARCOAT\n		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );\n		vec3 ccIrradiance = dotNLcc * directLight.color;\n		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );\n	#endif\n	#ifdef USE_SHEEN\n \n 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );\n \n 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );\n 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );\n \n 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );\n \n 		irradiance *= sheenEnergyComp;\n \n 	#endif\n	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );\n	#ifdef USE_RETROREFLECTION\n		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );\n		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );\n		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );\n	#endif\n	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;\n	vec3 halfDir = normalize( directLight.direction + geometryViewDir );\n	float dotVH = saturate( dot( geometryViewDir, halfDir ) );\n	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );\n	#ifdef USE_RETROREFLECTION\n		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );\n		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );\n		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );\n		F = mix( F, retroF, saturate( material.retroreflectivity ) );\n	#endif\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - F );\n}\nvoid RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {\n	vec3 singleScattering = vec3( 0.0 );\n	vec3 multiScattering = vec3( 0.0 );\n	#ifdef USE_IRIDESCENCE\n		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );\n	#else\n		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );\n	#endif\n	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );\n	#ifdef USE_SHEEN\n		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );\n		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;\n		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;\n		diffuse *= sheenEnergyComp;\n	#endif\n	reflectedLight.indirectDiffuse += diffuse;\n}\nvoid RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {\n	#ifdef USE_CLEARCOAT\n		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );\n	#endif\n	#ifdef USE_SHEEN\n		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;\n 	#endif\n	vec3 singleScatteringDielectric = vec3( 0.0 );\n	vec3 multiScatteringDielectric = vec3( 0.0 );\n	vec3 singleScatteringMetallic = vec3( 0.0 );\n	vec3 multiScatteringMetallic = vec3( 0.0 );\n	#ifdef USE_IRIDESCENCE\n		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );\n		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );\n	#else\n		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );\n		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );\n	#endif\n	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );\n	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );\n	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;\n	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );\n	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;\n	vec3 indirectSpecular = radiance * singleScattering;\n	indirectSpecular += multiScattering * cosineWeightedIrradiance;\n	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;\n	#ifdef USE_SHEEN\n		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );\n		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;\n		indirectSpecular *= sheenEnergyComp;\n		indirectDiffuse *= sheenEnergyComp;\n	#endif\n	reflectedLight.indirectSpecular += indirectSpecular;\n	reflectedLight.indirectDiffuse += indirectDiffuse;\n}\n#define RE_Direct				RE_Direct_Physical\n#define RE_Direct_RectArea		RE_Direct_RectArea_Physical\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical\n#define RE_IndirectSpecular		RE_IndirectSpecular_Physical\nfloat computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {\n	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );\n}",
	lights_fragment_begin: "\nvec3 geometryPosition = - vViewPosition;\nvec3 geometryNormal = normal;\nvec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );\nvec3 geometryClearcoatNormal = vec3( 0.0 );\n#ifdef USE_CLEARCOAT\n	geometryClearcoatNormal = clearcoatNormal;\n#endif\n#ifdef USE_IRIDESCENCE\n	float dotNVi = saturate( dot( normal, geometryViewDir ) );\n	if ( material.iridescenceThickness == 0.0 ) {\n		material.iridescence = 0.0;\n	} else {\n		material.iridescence = saturate( material.iridescence );\n	}\n	if ( material.iridescence > 0.0 ) {\n		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );\n		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );\n		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );\n		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );\n		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );\n	}\n#endif\n#ifdef STANDARD\n	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );\n	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;\n	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )\n		float EssMs = material.dfg.x + material.dfg.y;\n		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );\n	#endif\n#endif\nIncidentLight directLight;\n#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )\n	PointLight pointLight;\n	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0\n	PointLightShadow pointLightShadow;\n	#endif\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {\n		pointLight = pointLights[ i ];\n		getPointLightInfo( pointLight, geometryPosition, directLight );\n		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )\n		pointLightShadow = pointLightShadows[ i ];\n		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;\n		#endif\n		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )\n	SpotLight spotLight;\n	vec4 spotColor;\n	vec3 spotLightCoord;\n	bool inSpotLightMap;\n	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0\n	SpotLightShadow spotLightShadow;\n	#endif\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {\n		spotLight = spotLights[ i ];\n		getSpotLightInfo( spotLight, geometryPosition, directLight );\n		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )\n		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX\n		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )\n		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS\n		#else\n		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )\n		#endif\n		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )\n			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;\n			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );\n			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );\n			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;\n		#endif\n		#undef SPOT_LIGHT_MAP_INDEX\n		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )\n		spotLightShadow = spotLightShadows[ i ];\n		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;\n		#endif\n		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )\n	SunLight sunLight;\n	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0\n	SunLightShadow sunLightShadow;\n	#endif\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {\n		sunLight = sunLights[ i ];\n		getSunLightInfo( sunLight, directLight );\n		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )\n		sunLightShadow = sunLightShadows[ i ];\n		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;\n		#endif\n		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )\n	DirectionalLight directionalLight;\n	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0\n	DirectionalLightShadow directionalLightShadow;\n	#endif\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {\n		directionalLight = directionalLights[ i ];\n		getDirectionalLightInfo( directionalLight, directLight );\n		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )\n		directionalLightShadow = directionalLightShadows[ i ];\n		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;\n		#endif\n		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )\n	RectAreaLight rectAreaLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {\n		rectAreaLight = rectAreaLights[ i ];\n		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if defined( RE_IndirectDiffuse )\n	vec3 iblIrradiance = vec3( 0.0 );\n	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );\n	#if defined( USE_LIGHT_PROBES )\n		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );\n	#endif\n	#if ( NUM_HEMI_LIGHTS > 0 )\n		#pragma unroll_loop_start\n		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {\n			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );\n		}\n		#pragma unroll_loop_end\n	#endif\n	#ifdef USE_LIGHT_PROBES_GRID\n		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;\n		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );\n		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );\n	#endif\n#endif\n#if defined( RE_IndirectSpecular )\n	vec3 radiance = vec3( 0.0 );\n	vec3 clearcoatRadiance = vec3( 0.0 );\n#endif",
	lights_fragment_maps: "#if defined( RE_IndirectDiffuse )\n	#ifdef USE_LIGHTMAP\n		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );\n		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;\n		irradiance += lightMapIrradiance;\n	#endif\n	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )\n		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )\n			iblIrradiance += getIBLIrradiance( geometryNormal );\n		#endif\n	#endif\n#endif\n#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )\n	#ifdef USE_ANISOTROPY\n		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );\n	#else\n		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );\n	#endif\n	#ifdef USE_RETROREFLECTION\n		#ifdef USE_ANISOTROPY\n			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );\n		#else\n			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );\n		#endif\n		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );\n	#endif\n	radiance += iblRadiance;\n	#ifdef USE_CLEARCOAT\n		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );\n	#endif\n#endif",
	lights_fragment_end: "#if defined( RE_IndirectDiffuse )\n	#if defined( LAMBERT ) || defined( PHONG )\n		irradiance += iblIrradiance;\n	#endif\n	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n#endif\n#if defined( RE_IndirectSpecular )\n	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n#endif",
	lightprobes_pars_fragment: "#ifdef USE_LIGHT_PROBES_GRID\nuniform highp sampler3D probesSH;\nuniform vec3 probesMin;\nuniform vec3 probesMax;\nuniform vec3 probesResolution;\nvec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {\n	vec3 res = probesResolution;\n	vec3 gridRange = probesMax - probesMin;\n	vec3 resMinusOne = res - 1.0;\n	vec3 probeSpacing = gridRange / resMinusOne;\n	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;\n	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );\n	uvw = uvw * resMinusOne / res + 0.5 / res;\n	float nz          = res.z;\n	float paddedSlices = nz + 2.0;\n	float atlasDepth  = 7.0 * paddedSlices;\n	float uvZBase     = uvw.z * nz + 1.0;\n	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );\n	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );\n	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );\n	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );\n	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );\n	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );\n	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );\n	vec3 c0 = s0.xyz;\n	vec3 c1 = vec3( s0.w, s1.xy );\n	vec3 c2 = vec3( s1.zw, s2.x );\n	vec3 c3 = s2.yzw;\n	vec3 c4 = s3.xyz;\n	vec3 c5 = vec3( s3.w, s4.xy );\n	vec3 c6 = vec3( s4.zw, s5.x );\n	vec3 c7 = s5.yzw;\n	vec3 c8 = s6.xyz;\n	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;\n	vec3 result = c0 * 0.886227;\n	result += c1 * 2.0 * 0.511664 * y;\n	result += c2 * 2.0 * 0.511664 * z;\n	result += c3 * 2.0 * 0.511664 * x;\n	result += c4 * 2.0 * 0.429043 * x * y;\n	result += c5 * 2.0 * 0.429043 * y * z;\n	result += c6 * ( 0.743125 * z * z - 0.247708 );\n	result += c7 * 2.0 * 0.429043 * x * z;\n	result += c8 * 0.429043 * ( x * x - y * y );\n	return max( result, vec3( 0.0 ) );\n}\n#endif",
	logdepthbuf_fragment: "#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )\n	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;\n#endif",
	logdepthbuf_pars_fragment: "#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )\n	uniform float logDepthBufFC;\n	varying float vFragDepth;\n	varying float vIsPerspective;\n#endif",
	logdepthbuf_pars_vertex: "#ifdef USE_LOGARITHMIC_DEPTH_BUFFER\n	varying float vFragDepth;\n	varying float vIsPerspective;\n#endif",
	logdepthbuf_vertex: "#ifdef USE_LOGARITHMIC_DEPTH_BUFFER\n	vFragDepth = 1.0 + gl_Position.w;\n	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );\n#endif",
	map_fragment: "#ifdef USE_MAP\n	vec4 sampledDiffuseColor = texture2D( map, vMapUv );\n	#ifdef DECODE_VIDEO_TEXTURE\n		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );\n	#endif\n	diffuseColor *= sampledDiffuseColor;\n#endif",
	map_pars_fragment: "#ifdef USE_MAP\n	uniform sampler2D map;\n#endif",
	map_particle_fragment: "#if defined( USE_MAP ) || defined( USE_ALPHAMAP )\n	#if defined( USE_POINTS_UV )\n		vec2 uv = vUv;\n	#else\n		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;\n	#endif\n#endif\n#ifdef USE_MAP\n	diffuseColor *= texture2D( map, uv );\n#endif\n#ifdef USE_ALPHAMAP\n	diffuseColor.a *= texture2D( alphaMap, uv ).g;\n#endif",
	map_particle_pars_fragment: "#if defined( USE_POINTS_UV )\n	varying vec2 vUv;\n#else\n	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )\n		uniform mat3 uvTransform;\n	#endif\n#endif\n#ifdef USE_MAP\n	uniform sampler2D map;\n#endif\n#ifdef USE_ALPHAMAP\n	uniform sampler2D alphaMap;\n#endif",
	metalnessmap_fragment: "float metalnessFactor = metalness;\n#ifdef USE_METALNESSMAP\n	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );\n	metalnessFactor *= texelMetalness.b;\n#endif",
	metalnessmap_pars_fragment: "#ifdef USE_METALNESSMAP\n	uniform sampler2D metalnessMap;\n#endif",
	morphinstance_vertex: "#ifdef USE_INSTANCING_MORPH\n	float morphTargetInfluences[ MORPHTARGETS_COUNT ];\n	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;\n	}\n#endif",
	morphcolor_vertex: "#if defined( USE_MORPHCOLORS )\n	vColor *= morphTargetBaseInfluence;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		#if defined( USE_COLOR_ALPHA )\n			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];\n		#elif defined( USE_COLOR )\n			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];\n		#endif\n	}\n#endif",
	morphnormal_vertex: "#ifdef USE_MORPHNORMALS\n	objectNormal *= morphTargetBaseInfluence;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];\n	}\n#endif",
	morphtarget_pars_vertex: "#ifdef USE_MORPHTARGETS\n	#ifndef USE_INSTANCING_MORPH\n		uniform float morphTargetBaseInfluence;\n		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];\n	#endif\n	uniform sampler2DArray morphTargetsTexture;\n	uniform ivec2 morphTargetsTextureSize;\n	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {\n		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;\n		int y = texelIndex / morphTargetsTextureSize.x;\n		int x = texelIndex - y * morphTargetsTextureSize.x;\n		ivec3 morphUV = ivec3( x, y, morphTargetIndex );\n		return texelFetch( morphTargetsTexture, morphUV, 0 );\n	}\n#endif",
	morphtarget_vertex: "#ifdef USE_MORPHTARGETS\n	transformed *= morphTargetBaseInfluence;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];\n	}\n#endif",
	normal_fragment_begin: "float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;\n#ifdef FLAT_SHADED\n	vec3 fdx = dFdx( vViewPosition );\n	vec3 fdy = dFdy( vViewPosition );\n	vec3 normal = normalize( cross( fdx, fdy ) );\n#else\n	vec3 normal = normalize( vNormal );\n	#ifdef DOUBLE_SIDED\n		normal *= faceDirection;\n	#endif\n#endif\n#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )\n	#ifdef USE_TANGENT\n		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );\n	#else\n		mat3 tbn = getTangentFrame( - vViewPosition, normal,\n		#if defined( USE_NORMALMAP )\n			vNormalMapUv\n		#elif defined( USE_CLEARCOAT_NORMALMAP )\n			vClearcoatNormalMapUv\n		#else\n			vUv\n		#endif\n		);\n	#endif\n	#ifdef DOUBLE_SIDED\n		tbn[0] *= faceDirection;\n		tbn[1] *= faceDirection;\n	#endif\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	#ifdef USE_TANGENT\n		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );\n	#else\n		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );\n	#endif\n	#ifdef DOUBLE_SIDED\n		tbn2[0] *= faceDirection;\n		tbn2[1] *= faceDirection;\n	#endif\n#endif\nvec3 nonPerturbedNormal = normal;",
	normal_fragment_maps: "#ifdef USE_NORMALMAP_OBJECTSPACE\n	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;\n	#ifdef FLIP_SIDED\n		normal = - normal;\n	#endif\n	#ifdef DOUBLE_SIDED\n		normal = normal * faceDirection;\n	#endif\n	normal = normalize( normalMatrix * normal );\n#elif defined( USE_NORMALMAP_TANGENTSPACE )\n	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;\n	#if defined( USE_PACKED_NORMALMAP )\n		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );\n	#endif\n	mapN.xy *= normalScale;\n	normal = normalize( tbn * mapN );\n#elif defined( USE_BUMPMAP )\n	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );\n#endif",
	normal_pars_fragment: "#ifndef FLAT_SHADED\n	varying vec3 vNormal;\n	#ifdef USE_TANGENT\n		varying vec3 vTangent;\n		varying vec3 vBitangent;\n	#endif\n#endif",
	normal_pars_vertex: "#ifndef FLAT_SHADED\n	varying vec3 vNormal;\n	#ifdef USE_TANGENT\n		varying vec3 vTangent;\n		varying vec3 vBitangent;\n	#endif\n#endif",
	normal_vertex: "#ifndef FLAT_SHADED\n	vNormal = normalize( transformedNormal );\n	#ifdef USE_TANGENT\n		vTangent = normalize( transformedTangent );\n		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );\n		#ifdef FLIP_SIDED\n			vBitangent = - vBitangent;\n		#endif\n	#endif\n#endif",
	normalmap_pars_fragment: "#ifdef USE_NORMALMAP\n	uniform sampler2D normalMap;\n	uniform vec2 normalScale;\n#endif\n#ifdef USE_NORMALMAP_OBJECTSPACE\n	uniform mat3 normalMatrix;\n#endif\n#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )\n	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {\n		vec3 q0 = dFdx( eye_pos.xyz );\n		vec3 q1 = dFdy( eye_pos.xyz );\n		vec2 st0 = dFdx( uv.st );\n		vec2 st1 = dFdy( uv.st );\n		vec3 N = surf_norm;\n		vec3 q1perp = cross( q1, N );\n		vec3 q0perp = cross( N, q0 );\n		vec3 T = q1perp * st0.x + q0perp * st1.x;\n		vec3 B = q1perp * st0.y + q0perp * st1.y;\n		float det = max( dot( T, T ), dot( B, B ) );\n		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );\n		return mat3( T * scale, B * scale, N );\n	}\n#endif",
	clearcoat_normal_fragment_begin: "#ifdef USE_CLEARCOAT\n	vec3 clearcoatNormal = nonPerturbedNormal;\n#endif",
	clearcoat_normal_fragment_maps: "#ifdef USE_CLEARCOAT_NORMALMAP\n	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;\n	clearcoatMapN.xy *= clearcoatNormalScale;\n	clearcoatNormal = normalize( tbn2 * clearcoatMapN );\n#endif",
	clearcoat_pars_fragment: "#ifdef USE_CLEARCOATMAP\n	uniform sampler2D clearcoatMap;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	uniform sampler2D clearcoatNormalMap;\n	uniform vec2 clearcoatNormalScale;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	uniform sampler2D clearcoatRoughnessMap;\n#endif",
	iridescence_pars_fragment: "#ifdef USE_IRIDESCENCEMAP\n	uniform sampler2D iridescenceMap;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	uniform sampler2D iridescenceThicknessMap;\n#endif",
	opaque_fragment: "#ifdef OPAQUE\ndiffuseColor.a = 1.0;\n#endif\n#ifdef USE_TRANSMISSION\ndiffuseColor.a *= material.transmissionAlpha;\n#endif\ngl_FragColor = vec4( outgoingLight, diffuseColor.a );",
	packing: "vec3 packNormalToRGB( const in vec3 normal ) {\n	return normalize( normal ) * 0.5 + 0.5;\n}\nvec3 unpackRGBToNormal( const in vec3 rgb ) {\n	return 2.0 * rgb.xyz - 1.0;\n}\nconst float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;\nconst float Inv255 = 1. / 255.;\nconst vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );\nconst vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );\nconst vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );\nconst vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );\nvec4 packDepthToRGBA( const in float v ) {\n	if( v <= 0.0 )\n		return vec4( 0., 0., 0., 0. );\n	if( v >= 1.0 )\n		return vec4( 1., 1., 1., 1. );\n	float vuf;\n	float af = modf( v * PackFactors.a, vuf );\n	float bf = modf( vuf * ShiftRight8, vuf );\n	float gf = modf( vuf * ShiftRight8, vuf );\n	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );\n}\nvec3 packDepthToRGB( const in float v ) {\n	if( v <= 0.0 )\n		return vec3( 0., 0., 0. );\n	if( v >= 1.0 )\n		return vec3( 1., 1., 1. );\n	float vuf;\n	float bf = modf( v * PackFactors.b, vuf );\n	float gf = modf( vuf * ShiftRight8, vuf );\n	return vec3( vuf * Inv255, gf * PackUpscale, bf );\n}\nvec2 packDepthToRG( const in float v ) {\n	if( v <= 0.0 )\n		return vec2( 0., 0. );\n	if( v >= 1.0 )\n		return vec2( 1., 1. );\n	float vuf;\n	float gf = modf( v * 256., vuf );\n	return vec2( vuf * Inv255, gf );\n}\nfloat unpackRGBAToDepth( const in vec4 v ) {\n	return dot( v, UnpackFactors4 );\n}\nfloat unpackRGBToDepth( const in vec3 v ) {\n	return dot( v, UnpackFactors3 );\n}\nfloat unpackRGToDepth( const in vec2 v ) {\n	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;\n}\nvec4 pack2HalfToRGBA( const in vec2 v ) {\n	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );\n	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );\n}\nvec2 unpackRGBATo2Half( const in vec4 v ) {\n	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );\n}\nfloat viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {\n	return ( viewZ + near ) / ( near - far );\n}\nfloat orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {\n	#ifdef USE_REVERSED_DEPTH_BUFFER\n	\n		return depth * ( far - near ) - far;\n	#else\n		return depth * ( near - far ) - near;\n	#endif\n}\nfloat viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {\n	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );\n}\nfloat perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {\n	\n	#ifdef USE_REVERSED_DEPTH_BUFFER\n		return ( near * far ) / ( ( near - far ) * depth - near );\n	#else\n		return ( near * far ) / ( ( far - near ) * depth - far );\n	#endif\n}",
	premultiplied_alpha_fragment: "#ifdef PREMULTIPLIED_ALPHA\n	gl_FragColor.rgb *= gl_FragColor.a;\n#endif",
	project_vertex: "vec4 mvPosition = vec4( transformed, 1.0 );\n#ifdef USE_BATCHING\n	mvPosition = batchingMatrix * mvPosition;\n#endif\n#ifdef USE_INSTANCING\n	mvPosition = instanceMatrix * mvPosition;\n#endif\nmvPosition = modelViewMatrix * mvPosition;\ngl_Position = projectionMatrix * mvPosition;",
	dithering_fragment: "#ifdef DITHERING\n	gl_FragColor.rgb = dithering( gl_FragColor.rgb );\n#endif",
	dithering_pars_fragment: "#ifdef DITHERING\n	vec3 dithering( vec3 color ) {\n		float grid_position = rand( gl_FragCoord.xy );\n		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );\n		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );\n		return color + dither_shift_RGB;\n	}\n#endif",
	roughnessmap_fragment: "float roughnessFactor = roughness;\n#ifdef USE_ROUGHNESSMAP\n	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );\n	roughnessFactor *= texelRoughness.g;\n#endif",
	roughnessmap_pars_fragment: "#ifdef USE_ROUGHNESSMAP\n	uniform sampler2D roughnessMap;\n#endif",
	shadowmap_pars_fragment: "#if NUM_SPOT_LIGHT_COORDS > 0\n	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];\n#endif\n#if NUM_SPOT_LIGHT_MAPS > 0\n	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];\n#endif\n#ifdef USE_SHADOWMAP\n	#if NUM_SUN_LIGHT_SHADOWS > 0\n		#define SUN_LIGHT_CASCADES 2\n		#if defined( SHADOWMAP_TYPE_PCF )\n			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];\n		#else\n			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];\n		#endif\n		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];\n		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];\n		varying vec4 vSunShadowWorldPosition;\n		varying vec3 vSunShadowWorldNormal;\n		struct SunLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n		#if defined( SHADOWMAP_TYPE_PCF )\n			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];\n		#else\n			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];\n		#endif\n		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];\n		struct DirectionalLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_SPOT_LIGHT_SHADOWS > 0\n		#if defined( SHADOWMAP_TYPE_PCF )\n			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];\n		#else\n			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];\n		#endif\n		struct SpotLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n		#if defined( SHADOWMAP_TYPE_PCF )\n			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];\n		#elif defined( SHADOWMAP_TYPE_BASIC )\n			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];\n		#endif\n		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];\n		struct PointLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n			float shadowCameraNear;\n			float shadowCameraFar;\n		};\n		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];\n	#endif\n	#if defined( SHADOWMAP_TYPE_PCF )\n		float interleavedGradientNoise( vec2 position ) {\n			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );\n		}\n		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {\n			const float goldenAngle = 2.399963229728653;\n			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );\n			float theta = float( sampleIndex ) * goldenAngle + phi;\n			return vec2( cos( theta ), sin( theta ) ) * r;\n		}\n	#endif\n	#if defined( SHADOWMAP_TYPE_PCF )\n		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {\n			float shadow = 1.0;\n			shadowCoord.xyz /= shadowCoord.w;\n			shadowCoord.z += shadowBias;\n			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;\n			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;\n			if ( frustumTest ) {\n				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;\n				float radius = shadowRadius * texelSize.x;\n				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;\n				shadow = (\n					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +\n					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +\n					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +\n					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +\n					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )\n				) * 0.2;\n			}\n			return mix( 1.0, shadow, shadowIntensity );\n		}\n	#elif defined( SHADOWMAP_TYPE_VSM )\n		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {\n			float shadow = 1.0;\n			shadowCoord.xyz /= shadowCoord.w;\n			#ifdef USE_REVERSED_DEPTH_BUFFER\n				shadowCoord.z -= shadowBias;\n			#else\n				shadowCoord.z += shadowBias;\n			#endif\n			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;\n			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;\n			if ( frustumTest ) {\n				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;\n				float mean = distribution.x;\n				float variance = distribution.y * distribution.y;\n				#ifdef USE_REVERSED_DEPTH_BUFFER\n					float hard_shadow = step( mean, shadowCoord.z );\n				#else\n					float hard_shadow = step( shadowCoord.z, mean );\n				#endif\n				\n				if ( hard_shadow == 1.0 ) {\n					shadow = 1.0;\n				} else {\n					variance = max( variance, 0.0000001 );\n					float d = shadowCoord.z - mean;\n					float p_max = variance / ( variance + d * d );\n					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );\n					shadow = max( hard_shadow, p_max );\n				}\n			}\n			return mix( 1.0, shadow, shadowIntensity );\n		}\n	#else\n		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {\n			float shadow = 1.0;\n			shadowCoord.xyz /= shadowCoord.w;\n			#ifdef USE_REVERSED_DEPTH_BUFFER\n				shadowCoord.z -= shadowBias;\n			#else\n				shadowCoord.z += shadowBias;\n			#endif\n			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;\n			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;\n			if ( frustumTest ) {\n				float depth = texture2D( shadowMap, shadowCoord.xy ).r;\n				#ifdef USE_REVERSED_DEPTH_BUFFER\n					shadow = step( depth, shadowCoord.z );\n				#else\n					shadow = step( shadowCoord.z, depth );\n				#endif\n			}\n			return mix( 1.0, shadow, shadowIntensity );\n		}\n	#endif\n	#if NUM_SUN_LIGHT_SHADOWS > 0\n		float getSunShadow(\n			#if defined( SHADOWMAP_TYPE_PCF )\n				sampler2DShadow shadowMap,\n			#else\n				sampler2D shadowMap,\n			#endif\n			SunLightShadow sunLightShadow,\n			int shadowIndex\n		) {\n			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );\n			float viewDepth = vSunShadowWorldPosition.w;\n			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;\n			float shadow = 1.0;\n			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {\n				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];\n				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {\n					float cascadeShadow = getShadow(\n						shadowMap,\n						sunLightShadow.shadowMapSize,\n						sunLightShadow.shadowIntensity,\n						sunLightShadow.shadowBias,\n						sunLightShadow.shadowRadius,\n						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition\n					);\n					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );\n				}\n			}\n			return shadow;\n		}\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n	#if defined( SHADOWMAP_TYPE_PCF )\n	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {\n		float shadow = 1.0;\n		vec3 lightToPosition = shadowCoord.xyz;\n		vec3 bd3D = normalize( lightToPosition );\n		vec3 absVec = abs( lightToPosition );\n		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );\n		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {\n			#ifdef USE_REVERSED_DEPTH_BUFFER\n				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );\n				dp -= shadowBias;\n			#else\n				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );\n				dp += shadowBias;\n			#endif\n			float texelSize = shadowRadius / shadowMapSize.x;\n			vec3 absDir = abs( bd3D );\n			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );\n			tangent = normalize( cross( bd3D, tangent ) );\n			vec3 bitangent = cross( bd3D, tangent );\n			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;\n			vec2 sample0 = vogelDiskSample( 0, 5, phi );\n			vec2 sample1 = vogelDiskSample( 1, 5, phi );\n			vec2 sample2 = vogelDiskSample( 2, 5, phi );\n			vec2 sample3 = vogelDiskSample( 3, 5, phi );\n			vec2 sample4 = vogelDiskSample( 4, 5, phi );\n			shadow = (\n				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +\n				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +\n				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +\n				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +\n				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )\n			) * 0.2;\n		}\n		return mix( 1.0, shadow, shadowIntensity );\n	}\n	#elif defined( SHADOWMAP_TYPE_BASIC )\n	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {\n		float shadow = 1.0;\n		vec3 lightToPosition = shadowCoord.xyz;\n		vec3 absVec = abs( lightToPosition );\n		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );\n		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {\n			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );\n			dp += shadowBias;\n			vec3 bd3D = normalize( lightToPosition );\n			float depth = textureCube( shadowMap, bd3D ).r;\n			#ifdef USE_REVERSED_DEPTH_BUFFER\n				depth = 1.0 - depth;\n			#endif\n			shadow = step( dp, depth );\n		}\n		return mix( 1.0, shadow, shadowIntensity );\n	}\n	#endif\n	#endif\n#endif",
	shadowmap_pars_vertex: "#if NUM_SPOT_LIGHT_COORDS > 0\n	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];\n	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];\n#endif\n#ifdef USE_SHADOWMAP\n	#if NUM_SUN_LIGHT_SHADOWS > 0\n		varying vec4 vSunShadowWorldPosition;\n		varying vec3 vSunShadowWorldNormal;\n	#endif\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];\n		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];\n		struct DirectionalLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_SPOT_LIGHT_SHADOWS > 0\n		struct SpotLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];\n		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];\n		struct PointLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n			float shadowCameraNear;\n			float shadowCameraFar;\n		};\n		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];\n	#endif\n#endif",
	shadowmap_vertex: "#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )\n	#ifdef HAS_NORMAL\n		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );\n	#else\n		vec3 shadowWorldNormal = vec3( 0.0 );\n	#endif\n	vec4 shadowWorldPosition;\n#endif\n#if defined( USE_SHADOWMAP )\n	#if NUM_SUN_LIGHT_SHADOWS > 0\n		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );\n		vSunShadowWorldNormal = shadowWorldNormal;\n	#endif\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n		#pragma unroll_loop_start\n		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {\n			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );\n			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;\n		}\n		#pragma unroll_loop_end\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n		#pragma unroll_loop_start\n		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {\n			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );\n			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;\n		}\n		#pragma unroll_loop_end\n	#endif\n#endif\n#if NUM_SPOT_LIGHT_COORDS > 0\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {\n		shadowWorldPosition = worldPosition;\n		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )\n			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;\n		#endif\n		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;\n	}\n	#pragma unroll_loop_end\n#endif",
	shadowmask_pars_fragment: "float getShadowMask() {\n	float shadow = 1.0;\n	#ifdef USE_SHADOWMAP\n	#if NUM_SUN_LIGHT_SHADOWS > 0\n	SunLightShadow sunLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {\n		sunLight = sunLightShadows[ i ];\n		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;\n	}\n	#pragma unroll_loop_end\n	#endif\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n	DirectionalLightShadow directionalLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {\n		directionalLight = directionalLightShadows[ i ];\n		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;\n	}\n	#pragma unroll_loop_end\n	#endif\n	#if NUM_SPOT_LIGHT_SHADOWS > 0\n	SpotLightShadow spotLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {\n		spotLight = spotLightShadows[ i ];\n		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;\n	}\n	#pragma unroll_loop_end\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )\n	PointLightShadow pointLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {\n		pointLight = pointLightShadows[ i ];\n		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;\n	}\n	#pragma unroll_loop_end\n	#endif\n	#endif\n	return shadow;\n}",
	skinbase_vertex: "#ifdef USE_SKINNING\n	mat4 boneMatX = getBoneMatrix( skinIndex.x );\n	mat4 boneMatY = getBoneMatrix( skinIndex.y );\n	mat4 boneMatZ = getBoneMatrix( skinIndex.z );\n	mat4 boneMatW = getBoneMatrix( skinIndex.w );\n#endif",
	skinning_pars_vertex: "#ifdef USE_SKINNING\n	uniform mat4 bindMatrix;\n	uniform mat4 bindMatrixInverse;\n	uniform highp sampler2D boneTexture;\n	mat4 getBoneMatrix( const in float i ) {\n		int size = textureSize( boneTexture, 0 ).x;\n		int j = int( i ) * 4;\n		int x = j % size;\n		int y = j / size;\n		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );\n		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );\n		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );\n		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );\n		return mat4( v1, v2, v3, v4 );\n	}\n#endif",
	skinning_vertex: "#ifdef USE_SKINNING\n	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );\n	vec4 skinned = vec4( 0.0 );\n	skinned += boneMatX * skinVertex * skinWeight.x;\n	skinned += boneMatY * skinVertex * skinWeight.y;\n	skinned += boneMatZ * skinVertex * skinWeight.z;\n	skinned += boneMatW * skinVertex * skinWeight.w;\n	transformed = ( bindMatrixInverse * skinned ).xyz;\n#endif",
	skinnormal_vertex: "#ifdef USE_SKINNING\n	mat4 skinMatrix = mat4( 0.0 );\n	skinMatrix += skinWeight.x * boneMatX;\n	skinMatrix += skinWeight.y * boneMatY;\n	skinMatrix += skinWeight.z * boneMatZ;\n	skinMatrix += skinWeight.w * boneMatW;\n	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;\n	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;\n	#ifdef USE_TANGENT\n		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;\n	#endif\n#endif",
	specularmap_fragment: "float specularStrength;\n#ifdef USE_SPECULARMAP\n	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );\n	specularStrength = texelSpecular.r;\n#else\n	specularStrength = 1.0;\n#endif",
	specularmap_pars_fragment: "#ifdef USE_SPECULARMAP\n	uniform sampler2D specularMap;\n#endif",
	tonemapping_fragment: "#if defined( TONE_MAPPING )\n	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );\n#endif",
	tonemapping_pars_fragment: "#ifndef saturate\n#define saturate( a ) clamp( a, 0.0, 1.0 )\n#endif\nuniform float toneMappingExposure;\nvec3 LinearToneMapping( vec3 color ) {\n	return saturate( toneMappingExposure * color );\n}\nvec3 ReinhardToneMapping( vec3 color ) {\n	color *= toneMappingExposure;\n	return saturate( color / ( vec3( 1.0 ) + color ) );\n}\nvec3 CineonToneMapping( vec3 color ) {\n	color *= toneMappingExposure;\n	color = max( vec3( 0.0 ), color - 0.004 );\n	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );\n}\nvec3 RRTAndODTFit( vec3 v ) {\n	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;\n	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;\n	return a / b;\n}\nvec3 ACESFilmicToneMapping( vec3 color ) {\n	const mat3 ACESInputMat = mat3(\n		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),\n		vec3( 0.04823, 0.01566, 0.83777 )\n	);\n	const mat3 ACESOutputMat = mat3(\n		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),\n		vec3( -0.07367, -0.00605,  1.07602 )\n	);\n	color *= toneMappingExposure / 0.6;\n	color = ACESInputMat * color;\n	color = RRTAndODTFit( color );\n	color = ACESOutputMat * color;\n	return saturate( color );\n}\nconst mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(\n	vec3( 1.6605, - 0.1246, - 0.0182 ),\n	vec3( - 0.5876, 1.1329, - 0.1006 ),\n	vec3( - 0.0728, - 0.0083, 1.1187 )\n);\nconst mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(\n	vec3( 0.6274, 0.0691, 0.0164 ),\n	vec3( 0.3293, 0.9195, 0.0880 ),\n	vec3( 0.0433, 0.0113, 0.8956 )\n);\nvec3 agxDefaultContrastApprox( vec3 x ) {\n	vec3 x2 = x * x;\n	vec3 x4 = x2 * x2;\n	return + 15.5 * x4 * x2\n		- 40.14 * x4 * x\n		+ 31.96 * x4\n		- 6.868 * x2 * x\n		+ 0.4298 * x2\n		+ 0.1191 * x\n		- 0.00232;\n}\nvec3 AgXToneMapping( vec3 color ) {\n	const mat3 AgXInsetMatrix = mat3(\n		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),\n		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),\n		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )\n	);\n	const mat3 AgXOutsetMatrix = mat3(\n		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),\n		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),\n		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )\n	);\n	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;\n	color *= toneMappingExposure;\n	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;\n	color = AgXInsetMatrix * color;\n	color = max( color, 1e-10 );	color = log2( color );\n	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );\n	color = clamp( color, 0.0, 1.0 );\n	color = agxDefaultContrastApprox( color );\n	color = AgXOutsetMatrix * color;\n	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );\n	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;\n	color = clamp( color, 0.0, 1.0 );\n	return color;\n}\nvec3 NeutralToneMapping( vec3 color ) {\n	const float StartCompression = 0.8 - 0.04;\n	const float Desaturation = 0.15;\n	color *= toneMappingExposure;\n	float x = min( color.r, min( color.g, color.b ) );\n	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;\n	color -= offset;\n	float peak = max( color.r, max( color.g, color.b ) );\n	if ( peak < StartCompression ) return color;\n	float d = 1. - StartCompression;\n	float newPeak = 1. - d * d / ( peak + d - StartCompression );\n	color *= newPeak / peak;\n	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );\n	return mix( color, vec3( newPeak ), g );\n}\nvec3 CustomToneMapping( vec3 color ) { return color; }",
	transmission_fragment: "#ifdef USE_TRANSMISSION\n	material.transmission = transmission;\n	material.transmissionAlpha = 1.0;\n	material.thickness = thickness;\n	material.attenuationDistance = attenuationDistance;\n	material.attenuationColor = attenuationColor;\n	#ifdef USE_TRANSMISSIONMAP\n		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;\n	#endif\n	#ifdef USE_THICKNESSMAP\n		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;\n	#endif\n	vec3 pos = vWorldPosition;\n	vec3 v = normalize( cameraPosition - pos );\n	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );\n	vec4 transmitted = getIBLVolumeRefraction(\n		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,\n		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,\n		material.attenuationColor, material.attenuationDistance );\n	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );\n	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );\n#endif",
	transmission_pars_fragment: "#ifdef USE_TRANSMISSION\n	uniform float transmission;\n	uniform float thickness;\n	uniform float attenuationDistance;\n	uniform vec3 attenuationColor;\n	#ifdef USE_TRANSMISSIONMAP\n		uniform sampler2D transmissionMap;\n	#endif\n	#ifdef USE_THICKNESSMAP\n		uniform sampler2D thicknessMap;\n	#endif\n	uniform vec2 transmissionSamplerSize;\n	uniform sampler2D transmissionSamplerMap;\n	uniform mat4 modelMatrix;\n	uniform mat4 projectionMatrix;\n	varying vec3 vWorldPosition;\n	float w0( float a ) {\n		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );\n	}\n	float w1( float a ) {\n		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );\n	}\n	float w2( float a ){\n		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );\n	}\n	float w3( float a ) {\n		return ( 1.0 / 6.0 ) * ( a * a * a );\n	}\n	float g0( float a ) {\n		return w0( a ) + w1( a );\n	}\n	float g1( float a ) {\n		return w2( a ) + w3( a );\n	}\n	float h0( float a ) {\n		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );\n	}\n	float h1( float a ) {\n		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );\n	}\n	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {\n		uv = uv * texelSize.zw + 0.5;\n		vec2 iuv = floor( uv );\n		vec2 fuv = fract( uv );\n		float g0x = g0( fuv.x );\n		float g1x = g1( fuv.x );\n		float h0x = h0( fuv.x );\n		float h1x = h1( fuv.x );\n		float h0y = h0( fuv.y );\n		float h1y = h1( fuv.y );\n		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;\n		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;\n		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;\n		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;\n		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +\n			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );\n	}\n	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {\n		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );\n		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );\n		vec2 fLodSizeInv = 1.0 / fLodSize;\n		vec2 cLodSizeInv = 1.0 / cLodSize;\n		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );\n		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );\n		return mix( fSample, cSample, fract( lod ) );\n	}\n	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {\n		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );\n		vec3 modelScale;\n		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );\n		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );\n		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );\n		return normalize( refractionVector ) * thickness * modelScale;\n	}\n	float applyIorToRoughness( const in float roughness, const in float ior ) {\n		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );\n	}\n	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {\n		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );\n		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );\n	}\n	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {\n		if ( isinf( attenuationDistance ) ) {\n			return vec3( 1.0 );\n		} else {\n			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;\n			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;\n		}\n	}\n	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,\n		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,\n		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,\n		const in vec3 attenuationColor, const in float attenuationDistance ) {\n		vec4 transmittedLight;\n		vec3 transmittance;\n		#ifdef USE_DISPERSION\n			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;\n			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );\n			for ( int i = 0; i < 3; i ++ ) {\n				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );\n				vec3 refractedRayExit = position + transmissionRay;\n				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );\n				vec2 refractionCoords = ndcPos.xy / ndcPos.w;\n				refractionCoords += 1.0;\n				refractionCoords /= 2.0;\n				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );\n				transmittedLight[ i ] = transmissionSample[ i ];\n				transmittedLight.a += transmissionSample.a;\n				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];\n			}\n			transmittedLight.a /= 3.0;\n		#else\n			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );\n			vec3 refractedRayExit = position + transmissionRay;\n			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );\n			vec2 refractionCoords = ndcPos.xy / ndcPos.w;\n			refractionCoords += 1.0;\n			refractionCoords /= 2.0;\n			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );\n			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );\n		#endif\n		vec3 attenuatedColor = transmittance * transmittedLight.rgb;\n		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );\n		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;\n		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );\n	}\n#endif",
	uv_pars_fragment: "#if defined( USE_UV ) || defined( USE_ANISOTROPY )\n	varying vec2 vUv;\n#endif\n#ifdef USE_MAP\n	varying vec2 vMapUv;\n#endif\n#ifdef USE_ALPHAMAP\n	varying vec2 vAlphaMapUv;\n#endif\n#ifdef USE_LIGHTMAP\n	varying vec2 vLightMapUv;\n#endif\n#ifdef USE_AOMAP\n	varying vec2 vAoMapUv;\n#endif\n#ifdef USE_BUMPMAP\n	varying vec2 vBumpMapUv;\n#endif\n#ifdef USE_NORMALMAP\n	varying vec2 vNormalMapUv;\n#endif\n#ifdef USE_EMISSIVEMAP\n	varying vec2 vEmissiveMapUv;\n#endif\n#ifdef USE_METALNESSMAP\n	varying vec2 vMetalnessMapUv;\n#endif\n#ifdef USE_ROUGHNESSMAP\n	varying vec2 vRoughnessMapUv;\n#endif\n#ifdef USE_ANISOTROPYMAP\n	varying vec2 vAnisotropyMapUv;\n#endif\n#ifdef USE_CLEARCOATMAP\n	varying vec2 vClearcoatMapUv;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	varying vec2 vClearcoatNormalMapUv;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	varying vec2 vClearcoatRoughnessMapUv;\n#endif\n#ifdef USE_IRIDESCENCEMAP\n	varying vec2 vIridescenceMapUv;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	varying vec2 vIridescenceThicknessMapUv;\n#endif\n#ifdef USE_SHEEN_COLORMAP\n	varying vec2 vSheenColorMapUv;\n#endif\n#ifdef USE_SHEEN_ROUGHNESSMAP\n	varying vec2 vSheenRoughnessMapUv;\n#endif\n#ifdef USE_SPECULARMAP\n	varying vec2 vSpecularMapUv;\n#endif\n#ifdef USE_SPECULAR_COLORMAP\n	varying vec2 vSpecularColorMapUv;\n#endif\n#ifdef USE_SPECULAR_INTENSITYMAP\n	varying vec2 vSpecularIntensityMapUv;\n#endif\n#ifdef USE_TRANSMISSIONMAP\n	uniform mat3 transmissionMapTransform;\n	varying vec2 vTransmissionMapUv;\n#endif\n#ifdef USE_THICKNESSMAP\n	uniform mat3 thicknessMapTransform;\n	varying vec2 vThicknessMapUv;\n#endif",
	uv_pars_vertex: "#if defined( USE_UV ) || defined( USE_ANISOTROPY )\n	varying vec2 vUv;\n#endif\n#ifdef USE_MAP\n	uniform mat3 mapTransform;\n	varying vec2 vMapUv;\n#endif\n#ifdef USE_ALPHAMAP\n	uniform mat3 alphaMapTransform;\n	varying vec2 vAlphaMapUv;\n#endif\n#ifdef USE_LIGHTMAP\n	uniform mat3 lightMapTransform;\n	varying vec2 vLightMapUv;\n#endif\n#ifdef USE_AOMAP\n	uniform mat3 aoMapTransform;\n	varying vec2 vAoMapUv;\n#endif\n#ifdef USE_BUMPMAP\n	uniform mat3 bumpMapTransform;\n	varying vec2 vBumpMapUv;\n#endif\n#ifdef USE_NORMALMAP\n	uniform mat3 normalMapTransform;\n	varying vec2 vNormalMapUv;\n#endif\n#ifdef USE_DISPLACEMENTMAP\n	uniform mat3 displacementMapTransform;\n	varying vec2 vDisplacementMapUv;\n#endif\n#ifdef USE_EMISSIVEMAP\n	uniform mat3 emissiveMapTransform;\n	varying vec2 vEmissiveMapUv;\n#endif\n#ifdef USE_METALNESSMAP\n	uniform mat3 metalnessMapTransform;\n	varying vec2 vMetalnessMapUv;\n#endif\n#ifdef USE_ROUGHNESSMAP\n	uniform mat3 roughnessMapTransform;\n	varying vec2 vRoughnessMapUv;\n#endif\n#ifdef USE_ANISOTROPYMAP\n	uniform mat3 anisotropyMapTransform;\n	varying vec2 vAnisotropyMapUv;\n#endif\n#ifdef USE_CLEARCOATMAP\n	uniform mat3 clearcoatMapTransform;\n	varying vec2 vClearcoatMapUv;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	uniform mat3 clearcoatNormalMapTransform;\n	varying vec2 vClearcoatNormalMapUv;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	uniform mat3 clearcoatRoughnessMapTransform;\n	varying vec2 vClearcoatRoughnessMapUv;\n#endif\n#ifdef USE_SHEEN_COLORMAP\n	uniform mat3 sheenColorMapTransform;\n	varying vec2 vSheenColorMapUv;\n#endif\n#ifdef USE_SHEEN_ROUGHNESSMAP\n	uniform mat3 sheenRoughnessMapTransform;\n	varying vec2 vSheenRoughnessMapUv;\n#endif\n#ifdef USE_IRIDESCENCEMAP\n	uniform mat3 iridescenceMapTransform;\n	varying vec2 vIridescenceMapUv;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	uniform mat3 iridescenceThicknessMapTransform;\n	varying vec2 vIridescenceThicknessMapUv;\n#endif\n#ifdef USE_SPECULARMAP\n	uniform mat3 specularMapTransform;\n	varying vec2 vSpecularMapUv;\n#endif\n#ifdef USE_SPECULAR_COLORMAP\n	uniform mat3 specularColorMapTransform;\n	varying vec2 vSpecularColorMapUv;\n#endif\n#ifdef USE_SPECULAR_INTENSITYMAP\n	uniform mat3 specularIntensityMapTransform;\n	varying vec2 vSpecularIntensityMapUv;\n#endif\n#ifdef USE_TRANSMISSIONMAP\n	uniform mat3 transmissionMapTransform;\n	varying vec2 vTransmissionMapUv;\n#endif\n#ifdef USE_THICKNESSMAP\n	uniform mat3 thicknessMapTransform;\n	varying vec2 vThicknessMapUv;\n#endif",
	uv_vertex: "#if defined( USE_UV ) || defined( USE_ANISOTROPY )\n	vUv = vec3( uv, 1 ).xy;\n#endif\n#ifdef USE_MAP\n	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_ALPHAMAP\n	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_LIGHTMAP\n	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_AOMAP\n	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_BUMPMAP\n	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_NORMALMAP\n	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_DISPLACEMENTMAP\n	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_EMISSIVEMAP\n	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_METALNESSMAP\n	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_ROUGHNESSMAP\n	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_ANISOTROPYMAP\n	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_CLEARCOATMAP\n	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_IRIDESCENCEMAP\n	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SHEEN_COLORMAP\n	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SHEEN_ROUGHNESSMAP\n	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SPECULARMAP\n	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SPECULAR_COLORMAP\n	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SPECULAR_INTENSITYMAP\n	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_TRANSMISSIONMAP\n	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_THICKNESSMAP\n	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;\n#endif",
	worldpos_vertex: "#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0\n	vec4 worldPosition = vec4( transformed, 1.0 );\n	#ifdef USE_BATCHING\n		worldPosition = batchingMatrix * worldPosition;\n	#endif\n	#ifdef USE_INSTANCING\n		worldPosition = instanceMatrix * worldPosition;\n	#endif\n	worldPosition = modelMatrix * worldPosition;\n#endif",
	background_vert: "varying vec2 vUv;\nuniform mat3 uvTransform;\nvoid main() {\n	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;\n	gl_Position = vec4( position.xy, 1.0, 1.0 );\n}",
	background_frag: "uniform sampler2D t2D;\nuniform float backgroundIntensity;\nvarying vec2 vUv;\nvoid main() {\n	vec4 texColor = texture2D( t2D, vUv );\n	#ifdef DECODE_VIDEO_TEXTURE\n		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );\n	#endif\n	texColor.rgb *= backgroundIntensity;\n	gl_FragColor = texColor;\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}",
	backgroundCube_vert: "varying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vWorldDirection = transformDirection( position, modelMatrix );\n	#include <begin_vertex>\n	#include <project_vertex>\n	gl_Position.z = gl_Position.w;\n}",
	backgroundCube_frag: "#ifdef ENVMAP_TYPE_CUBE\n	uniform samplerCube envMap;\n#elif defined( ENVMAP_TYPE_CUBE_UV )\n	uniform sampler2D envMap;\n#endif\nuniform float backgroundBlurriness;\nuniform float backgroundIntensity;\nuniform mat3 backgroundRotation;\nvarying vec3 vWorldDirection;\n#include <cube_uv_reflection_fragment>\nvoid main() {\n	#ifdef ENVMAP_TYPE_CUBE\n		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );\n	#elif defined( ENVMAP_TYPE_CUBE_UV )\n		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );\n	#else\n		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );\n	#endif\n	texColor.rgb *= backgroundIntensity;\n	gl_FragColor = texColor;\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}",
	cube_vert: "varying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vWorldDirection = transformDirection( position, modelMatrix );\n	#include <begin_vertex>\n	#include <project_vertex>\n	gl_Position.z = gl_Position.w;\n}",
	cube_frag: "uniform samplerCube tCube;\nuniform float tFlip;\nuniform float opacity;\nvarying vec3 vWorldDirection;\nvoid main() {\n	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );\n	gl_FragColor = texColor;\n	gl_FragColor.a *= opacity;\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}",
	depth_vert: "#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvarying vec2 vHighPrecisionZW;\nvoid main() {\n	#include <uv_vertex>\n	#include <batching_vertex>\n	#include <skinbase_vertex>\n	#include <morphinstance_vertex>\n	#ifdef USE_DISPLACEMENTMAP\n		#include <beginnormal_vertex>\n		#include <morphnormal_vertex>\n		#include <skinnormal_vertex>\n	#endif\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vHighPrecisionZW = gl_Position.zw;\n}",
	depth_frag: "#if DEPTH_PACKING == 3200\n	uniform float opacity;\n#endif\n#include <common>\n#include <packing>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvarying vec2 vHighPrecisionZW;\nvoid main() {\n	vec4 diffuseColor = vec4( 1.0 );\n	#include <clipping_planes_fragment>\n	#if DEPTH_PACKING == 3200\n		diffuseColor.a = opacity;\n	#endif\n	#include <map_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <logdepthbuf_fragment>\n	#ifdef USE_REVERSED_DEPTH_BUFFER\n		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];\n	#else\n		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;\n	#endif\n	#if DEPTH_PACKING == 3200\n		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );\n	#elif DEPTH_PACKING == 3201\n		gl_FragColor = packDepthToRGBA( fragCoordZ );\n	#elif DEPTH_PACKING == 3202\n		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );\n	#elif DEPTH_PACKING == 3203\n		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );\n	#endif\n}",
	distance_vert: "#define DISTANCE\nvarying vec3 vWorldPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <batching_vertex>\n	#include <skinbase_vertex>\n	#include <morphinstance_vertex>\n	#ifdef USE_DISPLACEMENTMAP\n		#include <beginnormal_vertex>\n		#include <morphnormal_vertex>\n		#include <skinnormal_vertex>\n	#endif\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <worldpos_vertex>\n	#include <clipping_planes_vertex>\n	vWorldPosition = worldPosition.xyz;\n}",
	distance_frag: "#define DISTANCE\nuniform vec3 referencePosition;\nuniform float nearDistance;\nuniform float farDistance;\nvarying vec3 vWorldPosition;\n#include <common>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( 1.0 );\n	#include <clipping_planes_fragment>\n	#include <map_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	float dist = length( vWorldPosition - referencePosition );\n	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );\n	dist = saturate( dist );\n	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );\n}",
	equirect_vert: "varying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vWorldDirection = transformDirection( position, modelMatrix );\n	#include <begin_vertex>\n	#include <project_vertex>\n}",
	equirect_frag: "uniform sampler2D tEquirect;\nvarying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vec3 direction = normalize( vWorldDirection );\n	vec2 sampleUV = equirectUv( direction );\n	gl_FragColor = texture2D( tEquirect, sampleUV );\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}",
	linedashed_vert: "uniform float scale;\nattribute float lineDistance;\nvarying float vLineDistance;\n#include <common>\n#include <uv_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	vLineDistance = scale * lineDistance;\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <fog_vertex>\n}",
	linedashed_frag: "uniform vec3 diffuse;\nuniform float opacity;\nuniform float dashSize;\nuniform float totalSize;\nvarying float vLineDistance;\n#include <common>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <fog_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	if ( mod( vLineDistance, totalSize ) > dashSize ) {\n		discard;\n	}\n	vec3 outgoingLight = vec3( 0.0 );\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	outgoingLight = diffuseColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n}",
	meshbasic_vert: "#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <envmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )\n		#include <beginnormal_vertex>\n		#include <morphnormal_vertex>\n		#include <skinbase_vertex>\n		#include <skinnormal_vertex>\n		#include <defaultnormal_vertex>\n	#endif\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <worldpos_vertex>\n	#include <envmap_vertex>\n	#include <fog_vertex>\n}",
	meshbasic_frag: "uniform vec3 diffuse;\nuniform float opacity;\n#ifndef FLAT_SHADED\n	varying vec3 vNormal;\n#endif\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_pars_fragment>\n#include <fog_pars_fragment>\n#include <specularmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <specularmap_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	#ifdef USE_LIGHTMAP\n		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );\n		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;\n	#else\n		reflectedLight.indirectDiffuse += vec3( 1.0 );\n	#endif\n	#include <aomap_fragment>\n	reflectedLight.indirectDiffuse *= diffuseColor.rgb;\n	vec3 outgoingLight = reflectedLight.indirectDiffuse;\n	#include <envmap_fragment>\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",
	meshlambert_vert: "#define LAMBERT\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <envmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <envmap_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}",
	meshlambert_frag: "#define LAMBERT\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform float opacity;\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <cube_uv_reflection_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_pars_fragment>\n#include <envmap_physical_pars_fragment>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_lambert_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <specularmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <specularmap_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_lambert_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;\n	#include <envmap_fragment>\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",
	meshmatcap_vert: "#define MATCAP\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <color_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <fog_vertex>\n	vViewPosition = - mvPosition.xyz;\n}",
	meshmatcap_frag: "#define MATCAP\nuniform vec3 diffuse;\nuniform float opacity;\nuniform sampler2D matcap;\nvarying vec3 vViewPosition;\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <fog_pars_fragment>\n#include <normal_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	vec3 viewDir = normalize( vViewPosition );\n	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );\n	vec3 y = cross( viewDir, x );\n	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;\n	#ifdef USE_MATCAP\n		vec4 matcapColor = texture2D( matcap, uv );\n	#else\n		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );\n	#endif\n	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",
	meshnormal_vert: "#define NORMAL\n#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )\n	varying vec3 vViewPosition;\n#endif\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphinstance_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )\n	vViewPosition = - mvPosition.xyz;\n#endif\n}",
	meshnormal_frag: "#define NORMAL\nuniform float opacity;\n#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )\n	varying vec3 vViewPosition;\n#endif\n#include <uv_pars_fragment>\n#include <normal_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );\n	#include <clipping_planes_fragment>\n	#include <logdepthbuf_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );\n	#ifdef OPAQUE\n		gl_FragColor.a = 1.0;\n	#endif\n}",
	meshphong_vert: "#define PHONG\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <envmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphinstance_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <envmap_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}",
	meshphong_frag: "#define PHONG\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform vec3 specular;\nuniform float shininess;\nuniform float opacity;\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <cube_uv_reflection_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_pars_fragment>\n#include <envmap_physical_pars_fragment>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_phong_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <specularmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <specularmap_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_phong_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;\n	#include <envmap_fragment>\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",
	meshphysical_vert: "#define STANDARD\nvarying vec3 vViewPosition;\n#ifdef USE_TRANSMISSION\n	varying vec3 vWorldPosition;\n#endif\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n#ifdef USE_TRANSMISSION\n	vWorldPosition = worldPosition.xyz;\n#endif\n}",
	meshphysical_frag: "#define STANDARD\n#ifdef PHYSICAL\n	#define IOR\n	#define USE_SPECULAR\n#endif\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform float roughness;\nuniform float metalness;\nuniform float opacity;\n#ifdef IOR\n	uniform float ior;\n#endif\n#ifdef USE_SPECULAR\n	uniform float specularIntensity;\n	uniform vec3 specularColor;\n	#ifdef USE_SPECULAR_COLORMAP\n		uniform sampler2D specularColorMap;\n	#endif\n	#ifdef USE_SPECULAR_INTENSITYMAP\n		uniform sampler2D specularIntensityMap;\n	#endif\n#endif\n#ifdef USE_CLEARCOAT\n	uniform float clearcoat;\n	uniform float clearcoatRoughness;\n#endif\n#ifdef USE_DISPERSION\n	uniform float dispersion;\n#endif\n#ifdef USE_RETROREFLECTION\n	uniform float retroreflectivity;\n#endif\n#ifdef USE_IRIDESCENCE\n	uniform float iridescence;\n	uniform float iridescenceIOR;\n	uniform float iridescenceThicknessMinimum;\n	uniform float iridescenceThicknessMaximum;\n#endif\n#ifdef USE_SHEEN\n	uniform vec3 sheenColor;\n	uniform float sheenRoughness;\n	#ifdef USE_SHEEN_COLORMAP\n		uniform sampler2D sheenColorMap;\n	#endif\n	#ifdef USE_SHEEN_ROUGHNESSMAP\n		uniform sampler2D sheenRoughnessMap;\n	#endif\n#endif\n#ifdef USE_ANISOTROPY\n	uniform vec2 anisotropyVector;\n	#ifdef USE_ANISOTROPYMAP\n		uniform sampler2D anisotropyMap;\n	#endif\n#endif\nvarying vec3 vViewPosition;\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <iridescence_fragment>\n#include <cube_uv_reflection_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_physical_pars_fragment>\n#include <fog_pars_fragment>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_physical_pars_fragment>\n#include <transmission_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <clearcoat_pars_fragment>\n#include <iridescence_pars_fragment>\n#include <roughnessmap_pars_fragment>\n#include <metalnessmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <roughnessmap_fragment>\n	#include <metalnessmap_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <clearcoat_normal_fragment_begin>\n	#include <clearcoat_normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_physical_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;\n	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;\n	#include <transmission_fragment>\n	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;\n	#ifdef USE_SHEEN\n \n		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;\n \n 	#endif\n	#ifdef USE_CLEARCOAT\n		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );\n		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );\n		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;\n	#endif\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",
	meshtoon_vert: "#define TOON\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}",
	meshtoon_frag: "#define TOON\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform float opacity;\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <gradientmap_pars_fragment>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_toon_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_toon_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",
	points_vert: "uniform float size;\nuniform float scale;\n#include <common>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\n#ifdef USE_POINTS_UV\n	varying vec2 vUv;\n	uniform mat3 uvTransform;\n#endif\nvoid main() {\n	#ifdef USE_POINTS_UV\n		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;\n	#endif\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <project_vertex>\n	gl_PointSize = size;\n	#ifdef USE_SIZEATTENUATION\n		bool isPerspective = isPerspectiveMatrix( projectionMatrix );\n		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );\n	#endif\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <worldpos_vertex>\n	#include <fog_vertex>\n}",
	points_frag: "uniform vec3 diffuse;\nuniform float opacity;\n#include <common>\n#include <color_pars_fragment>\n#include <map_particle_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <fog_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	vec3 outgoingLight = vec3( 0.0 );\n	#include <logdepthbuf_fragment>\n	#include <map_particle_fragment>\n	#include <color_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	outgoingLight = diffuseColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n}",
	shadow_vert: "#include <common>\n#include <batching_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <shadowmap_pars_vertex>\nvoid main() {\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphinstance_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <worldpos_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}",
	shadow_frag: "uniform vec3 color;\nuniform float opacity;\n#include <common>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <logdepthbuf_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <shadowmask_pars_fragment>\nvoid main() {\n	#include <logdepthbuf_fragment>\n	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n}",
	sprite_vert: "uniform float rotation;\nuniform vec2 center;\n#include <common>\n#include <uv_pars_vertex>\n#include <fog_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	vec4 mvPosition = modelViewMatrix[ 3 ];\n	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );\n	#ifndef USE_SIZEATTENUATION\n		bool isPerspective = isPerspectiveMatrix( projectionMatrix );\n		if ( isPerspective ) scale *= - mvPosition.z;\n	#endif\n	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;\n	vec2 rotatedPosition;\n	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;\n	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;\n	mvPosition.xy += rotatedPosition;\n	gl_Position = projectionMatrix * mvPosition;\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <fog_vertex>\n}",
	sprite_frag: "uniform vec3 diffuse;\nuniform float opacity;\n#include <common>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <fog_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	vec3 outgoingLight = vec3( 0.0 );\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	outgoingLight = diffuseColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n}"
}, K = {
	common: {
		diffuse: { value: /*@__PURE__*/ new I(16777215) },
		opacity: { value: 1 },
		map: { value: null },
		mapTransform: { value: /*@__PURE__*/ new z() },
		alphaMap: { value: null },
		alphaMapTransform: { value: /*@__PURE__*/ new z() },
		alphaTest: { value: 0 }
	},
	specularmap: {
		specularMap: { value: null },
		specularMapTransform: { value: /*@__PURE__*/ new z() }
	},
	envmap: {
		envMap: { value: null },
		envMapRotation: { value: /*@__PURE__*/ new z() },
		reflectivity: { value: 1 },
		ior: { value: 1.5 },
		refractionRatio: { value: .98 },
		dfgLUT: { value: null }
	},
	aomap: {
		aoMap: { value: null },
		aoMapIntensity: { value: 1 },
		aoMapTransform: { value: /*@__PURE__*/ new z() }
	},
	lightmap: {
		lightMap: { value: null },
		lightMapIntensity: { value: 1 },
		lightMapTransform: { value: /*@__PURE__*/ new z() }
	},
	bumpmap: {
		bumpMap: { value: null },
		bumpMapTransform: { value: /*@__PURE__*/ new z() },
		bumpScale: { value: 1 }
	},
	normalmap: {
		normalMap: { value: null },
		normalMapTransform: { value: /*@__PURE__*/ new z() },
		normalScale: { value: /*@__PURE__*/ new P(1, 1) }
	},
	displacementmap: {
		displacementMap: { value: null },
		displacementMapTransform: { value: /*@__PURE__*/ new z() },
		displacementScale: { value: 1 },
		displacementBias: { value: 0 }
	},
	emissivemap: {
		emissiveMap: { value: null },
		emissiveMapTransform: { value: /*@__PURE__*/ new z() }
	},
	metalnessmap: {
		metalnessMap: { value: null },
		metalnessMapTransform: { value: /*@__PURE__*/ new z() }
	},
	roughnessmap: {
		roughnessMap: { value: null },
		roughnessMapTransform: { value: /*@__PURE__*/ new z() }
	},
	gradientmap: { gradientMap: { value: null } },
	fog: {
		fogDensity: { value: 25e-5 },
		fogNear: { value: 1 },
		fogFar: { value: 2e3 },
		fogColor: { value: /*@__PURE__*/ new I(16777215) }
	},
	lights: {
		ambientLightColor: { value: [] },
		lightProbe: { value: [] },
		sunLights: {
			value: [],
			properties: {
				direction: {},
				color: {}
			}
		},
		sunLightShadows: {
			value: [],
			properties: {
				shadowIntensity: 1,
				shadowBias: {},
				shadowNormalBias: {},
				shadowRadius: {},
				shadowMapSize: {}
			}
		},
		sunShadowMatrix: { value: [] },
		sunShadowCascade: { value: [] },
		directionalLights: {
			value: [],
			properties: {
				direction: {},
				color: {}
			}
		},
		directionalLightShadows: {
			value: [],
			properties: {
				shadowIntensity: 1,
				shadowBias: {},
				shadowNormalBias: {},
				shadowRadius: {},
				shadowMapSize: {}
			}
		},
		directionalShadowMatrix: { value: [] },
		spotLights: {
			value: [],
			properties: {
				color: {},
				position: {},
				direction: {},
				distance: {},
				coneCos: {},
				penumbraCos: {},
				decay: {}
			}
		},
		spotLightShadows: {
			value: [],
			properties: {
				shadowIntensity: 1,
				shadowBias: {},
				shadowNormalBias: {},
				shadowRadius: {},
				shadowMapSize: {}
			}
		},
		spotLightMap: { value: [] },
		spotLightMatrix: { value: [] },
		pointLights: {
			value: [],
			properties: {
				color: {},
				position: {},
				decay: {},
				distance: {}
			}
		},
		pointLightShadows: {
			value: [],
			properties: {
				shadowIntensity: 1,
				shadowBias: {},
				shadowNormalBias: {},
				shadowRadius: {},
				shadowMapSize: {},
				shadowCameraNear: {},
				shadowCameraFar: {}
			}
		},
		pointShadowMatrix: { value: [] },
		hemisphereLights: {
			value: [],
			properties: {
				direction: {},
				skyColor: {},
				groundColor: {}
			}
		},
		rectAreaLights: {
			value: [],
			properties: {
				color: {},
				position: {},
				width: {},
				height: {}
			}
		},
		ltc_1: { value: null },
		ltc_2: { value: null },
		probesSH: { value: null },
		probesMin: { value: /*@__PURE__*/ new L() },
		probesMax: { value: /*@__PURE__*/ new L() },
		probesResolution: { value: /*@__PURE__*/ new L() }
	},
	points: {
		diffuse: { value: /*@__PURE__*/ new I(16777215) },
		opacity: { value: 1 },
		size: { value: 1 },
		scale: { value: 1 },
		map: { value: null },
		alphaMap: { value: null },
		alphaMapTransform: { value: /*@__PURE__*/ new z() },
		alphaTest: { value: 0 },
		uvTransform: { value: /*@__PURE__*/ new z() }
	},
	sprite: {
		diffuse: { value: /*@__PURE__*/ new I(16777215) },
		opacity: { value: 1 },
		center: { value: /*@__PURE__*/ new P(.5, .5) },
		rotation: { value: 0 },
		map: { value: null },
		mapTransform: { value: /*@__PURE__*/ new z() },
		alphaMap: { value: null },
		alphaMapTransform: { value: /*@__PURE__*/ new z() },
		alphaTest: { value: 0 }
	}
}, hn = {
	basic: {
		uniforms: /*@__PURE__*/ ge([
			K.common,
			K.specularmap,
			K.envmap,
			K.aomap,
			K.lightmap,
			K.fog
		]),
		vertexShader: G.meshbasic_vert,
		fragmentShader: G.meshbasic_frag
	},
	lambert: {
		uniforms: /*@__PURE__*/ ge([
			K.common,
			K.specularmap,
			K.envmap,
			K.aomap,
			K.lightmap,
			K.emissivemap,
			K.bumpmap,
			K.normalmap,
			K.displacementmap,
			K.fog,
			K.lights,
			{
				emissive: { value: /*@__PURE__*/ new I(0) },
				envMapIntensity: { value: 1 }
			}
		]),
		vertexShader: G.meshlambert_vert,
		fragmentShader: G.meshlambert_frag
	},
	phong: {
		uniforms: /*@__PURE__*/ ge([
			K.common,
			K.specularmap,
			K.envmap,
			K.aomap,
			K.lightmap,
			K.emissivemap,
			K.bumpmap,
			K.normalmap,
			K.displacementmap,
			K.fog,
			K.lights,
			{
				emissive: { value: /*@__PURE__*/ new I(0) },
				specular: { value: /*@__PURE__*/ new I(1118481) },
				shininess: { value: 30 },
				envMapIntensity: { value: 1 }
			}
		]),
		vertexShader: G.meshphong_vert,
		fragmentShader: G.meshphong_frag
	},
	standard: {
		uniforms: /*@__PURE__*/ ge([
			K.common,
			K.envmap,
			K.aomap,
			K.lightmap,
			K.emissivemap,
			K.bumpmap,
			K.normalmap,
			K.displacementmap,
			K.roughnessmap,
			K.metalnessmap,
			K.fog,
			K.lights,
			{
				emissive: { value: /*@__PURE__*/ new I(0) },
				roughness: { value: 1 },
				metalness: { value: 0 },
				envMapIntensity: { value: 1 }
			}
		]),
		vertexShader: G.meshphysical_vert,
		fragmentShader: G.meshphysical_frag
	},
	toon: {
		uniforms: /*@__PURE__*/ ge([
			K.common,
			K.aomap,
			K.lightmap,
			K.emissivemap,
			K.bumpmap,
			K.normalmap,
			K.displacementmap,
			K.gradientmap,
			K.fog,
			K.lights,
			{ emissive: { value: /*@__PURE__*/ new I(0) } }
		]),
		vertexShader: G.meshtoon_vert,
		fragmentShader: G.meshtoon_frag
	},
	matcap: {
		uniforms: /*@__PURE__*/ ge([
			K.common,
			K.bumpmap,
			K.normalmap,
			K.displacementmap,
			K.fog,
			{ matcap: { value: null } }
		]),
		vertexShader: G.meshmatcap_vert,
		fragmentShader: G.meshmatcap_frag
	},
	points: {
		uniforms: /*@__PURE__*/ ge([K.points, K.fog]),
		vertexShader: G.points_vert,
		fragmentShader: G.points_frag
	},
	dashed: {
		uniforms: /*@__PURE__*/ ge([
			K.common,
			K.fog,
			{
				scale: { value: 1 },
				dashSize: { value: 1 },
				totalSize: { value: 2 }
			}
		]),
		vertexShader: G.linedashed_vert,
		fragmentShader: G.linedashed_frag
	},
	depth: {
		uniforms: /*@__PURE__*/ ge([K.common, K.displacementmap]),
		vertexShader: G.depth_vert,
		fragmentShader: G.depth_frag
	},
	normal: {
		uniforms: /*@__PURE__*/ ge([
			K.common,
			K.bumpmap,
			K.normalmap,
			K.displacementmap,
			{ opacity: { value: 1 } }
		]),
		vertexShader: G.meshnormal_vert,
		fragmentShader: G.meshnormal_frag
	},
	sprite: {
		uniforms: /*@__PURE__*/ ge([K.sprite, K.fog]),
		vertexShader: G.sprite_vert,
		fragmentShader: G.sprite_frag
	},
	background: {
		uniforms: {
			uvTransform: { value: /*@__PURE__*/ new z() },
			t2D: { value: null },
			backgroundIntensity: { value: 1 }
		},
		vertexShader: G.background_vert,
		fragmentShader: G.background_frag
	},
	backgroundCube: {
		uniforms: {
			envMap: { value: null },
			backgroundBlurriness: { value: 0 },
			backgroundIntensity: { value: 1 },
			backgroundRotation: { value: /*@__PURE__*/ new z() }
		},
		vertexShader: G.backgroundCube_vert,
		fragmentShader: G.backgroundCube_frag
	},
	cube: {
		uniforms: {
			tCube: { value: null },
			tFlip: { value: -1 },
			opacity: { value: 1 }
		},
		vertexShader: G.cube_vert,
		fragmentShader: G.cube_frag
	},
	equirect: {
		uniforms: { tEquirect: { value: null } },
		vertexShader: G.equirect_vert,
		fragmentShader: G.equirect_frag
	},
	distance: {
		uniforms: /*@__PURE__*/ ge([
			K.common,
			K.displacementmap,
			{
				referencePosition: { value: /*@__PURE__*/ new L() },
				nearDistance: { value: 1 },
				farDistance: { value: 1e3 }
			}
		]),
		vertexShader: G.distance_vert,
		fragmentShader: G.distance_frag
	},
	shadow: {
		uniforms: /*@__PURE__*/ ge([
			K.lights,
			K.fog,
			{
				color: { value: /*@__PURE__*/ new I(0) },
				opacity: { value: 1 }
			}
		]),
		vertexShader: G.shadow_vert,
		fragmentShader: G.shadow_frag
	}
};
hn.physical = {
	uniforms: /*@__PURE__*/ ge([hn.standard.uniforms, {
		clearcoat: { value: 0 },
		clearcoatMap: { value: null },
		clearcoatMapTransform: { value: /*@__PURE__*/ new z() },
		clearcoatNormalMap: { value: null },
		clearcoatNormalMapTransform: { value: /*@__PURE__*/ new z() },
		clearcoatNormalScale: { value: /*@__PURE__*/ new P(1, 1) },
		clearcoatRoughness: { value: 0 },
		clearcoatRoughnessMap: { value: null },
		clearcoatRoughnessMapTransform: { value: /*@__PURE__*/ new z() },
		dispersion: { value: 0 },
		retroreflectivity: { value: 0 },
		iridescence: { value: 0 },
		iridescenceMap: { value: null },
		iridescenceMapTransform: { value: /*@__PURE__*/ new z() },
		iridescenceIOR: { value: 1.3 },
		iridescenceThicknessMinimum: { value: 100 },
		iridescenceThicknessMaximum: { value: 400 },
		iridescenceThicknessMap: { value: null },
		iridescenceThicknessMapTransform: { value: /*@__PURE__*/ new z() },
		sheen: { value: 0 },
		sheenColor: { value: /*@__PURE__*/ new I(0) },
		sheenColorMap: { value: null },
		sheenColorMapTransform: { value: /*@__PURE__*/ new z() },
		sheenRoughness: { value: 1 },
		sheenRoughnessMap: { value: null },
		sheenRoughnessMapTransform: { value: /*@__PURE__*/ new z() },
		transmission: { value: 0 },
		transmissionMap: { value: null },
		transmissionMapTransform: { value: /*@__PURE__*/ new z() },
		transmissionSamplerSize: { value: /*@__PURE__*/ new P() },
		transmissionSamplerMap: { value: null },
		thickness: { value: 0 },
		thicknessMap: { value: null },
		thicknessMapTransform: { value: /*@__PURE__*/ new z() },
		attenuationDistance: { value: 0 },
		attenuationColor: { value: /*@__PURE__*/ new I(0) },
		specularColor: { value: /*@__PURE__*/ new I(1, 1, 1) },
		specularColorMap: { value: null },
		specularColorMapTransform: { value: /*@__PURE__*/ new z() },
		specularIntensity: { value: 1 },
		specularIntensityMap: { value: null },
		specularIntensityMapTransform: { value: /*@__PURE__*/ new z() },
		anisotropyVector: { value: /*@__PURE__*/ new P() },
		anisotropyMap: { value: null },
		anisotropyMapTransform: { value: /*@__PURE__*/ new z() }
	}]),
	vertexShader: G.meshphysical_vert,
	fragmentShader: G.meshphysical_frag
};
var gn = {
	r: 0,
	b: 0,
	g: 0
}, _n = /*@__PURE__*/ new Ie(), vn = /*@__PURE__*/ new z();
vn.set(-1, 0, 0, 0, 1, 0, 0, 0, 1);
function yn(e, t, n, r, i, a) {
	let o = new I(0), s = i === !0 ? 0 : 1, c, l, u = null, d = 0, f = null;
	function p(e) {
		let n = e.isScene === !0 ? e.background : null;
		if (n && n.isTexture) {
			let r = e.backgroundBlurriness > 0;
			n = t.get(n, r);
		}
		return n;
	}
	function h(t) {
		let r = !1, i = p(t);
		i === null ? v(o, s) : i && i.isColor && (v(i, 1), r = !0);
		let c = e.xr.getEnvironmentBlendMode();
		c === "additive" ? n.buffers.color.setClear(0, 0, 0, 1, a) : c === "alpha-blend" && n.buffers.color.setClear(0, 0, 0, 0, a), (e.autoClear || r) && (n.buffers.depth.setTest(!0), n.buffers.depth.setMask(!0), n.buffers.color.setMask(!0), e.clear(e.autoClearColor, e.autoClearDepth, e.autoClearStencil));
	}
	function g(t, n) {
		let i = p(n);
		i && (i.isCubeTexture || i.mapping === 306) ? (l === void 0 && (l = new N(new rt(1, 1, 1), new m({
			name: "BackgroundCubeMaterial",
			uniforms: ct(hn.backgroundCube.uniforms),
			vertexShader: hn.backgroundCube.vertexShader,
			fragmentShader: hn.backgroundCube.fragmentShader,
			side: 1,
			depthTest: !1,
			depthWrite: !1,
			fog: !1,
			allowOverride: !1
		})), l.geometry.deleteAttribute("normal"), l.geometry.deleteAttribute("uv"), l.onBeforeRender = function(e, t, n) {
			this.matrixWorld.copyPosition(n.matrixWorld);
		}, Object.defineProperty(l.material, "envMap", { get: function() {
			return this.uniforms.envMap.value;
		} }), r.update(l)), l.material.uniforms.envMap.value = i, l.material.uniforms.backgroundBlurriness.value = n.backgroundBlurriness, l.material.uniforms.backgroundIntensity.value = n.backgroundIntensity, l.material.uniforms.backgroundRotation.value.setFromMatrix4(_n.makeRotationFromEuler(n.backgroundRotation)).transpose(), i.isCubeTexture && i.isRenderTargetTexture === !1 && l.material.uniforms.backgroundRotation.value.premultiply(vn), l.material.toneMapped = Ze.getTransfer(i.colorSpace) !== de, (u !== i || d !== i.version || f !== e.toneMapping) && (l.material.needsUpdate = !0, u = i, d = i.version, f = e.toneMapping), l.layers.enableAll(), t.unshift(l, l.geometry, l.material, 0, 0, null)) : i && i.isTexture && (c === void 0 && (c = new N(new D(2, 2), new m({
			name: "BackgroundMaterial",
			uniforms: ct(hn.background.uniforms),
			vertexShader: hn.background.vertexShader,
			fragmentShader: hn.background.fragmentShader,
			side: 0,
			depthTest: !1,
			depthWrite: !1,
			fog: !1,
			allowOverride: !1
		})), c.geometry.deleteAttribute("normal"), Object.defineProperty(c.material, "map", { get: function() {
			return this.uniforms.t2D.value;
		} }), r.update(c)), c.material.uniforms.t2D.value = i, c.material.uniforms.backgroundIntensity.value = n.backgroundIntensity, c.material.toneMapped = Ze.getTransfer(i.colorSpace) !== de, i.matrixAutoUpdate === !0 && i.updateMatrix(), c.material.uniforms.uvTransform.value.copy(i.matrix), (u !== i || d !== i.version || f !== e.toneMapping) && (c.material.needsUpdate = !0, u = i, d = i.version, f = e.toneMapping), c.layers.enableAll(), t.unshift(c, c.geometry, c.material, 0, 0, null));
	}
	function v(t, r) {
		t.getRGB(gn, _(e)), n.buffers.color.setClear(gn.r, gn.g, gn.b, r, a);
	}
	function y() {
		l !== void 0 && (l.geometry.dispose(), l.material.dispose(), l = void 0), c !== void 0 && (c.geometry.dispose(), c.material.dispose(), c = void 0);
	}
	return {
		getClearColor: function() {
			return o;
		},
		setClearColor: function(e, t = 1) {
			o.set(e), s = t, v(o, s);
		},
		getClearAlpha: function() {
			return s;
		},
		setClearAlpha: function(e) {
			s = e, v(o, s);
		},
		render: h,
		addToRenderList: g,
		dispose: y
	};
}
function bn(e, t) {
	let n = e.getParameter(e.MAX_VERTEX_ATTRIBS), r = {}, i = f(null), a = i, o = !1;
	function s(n, r, i, s, c) {
		let u = !1, f = d(n, s, i, r);
		a !== f && (a = f, l(a.object)), u = p(n, s, i, c), u && m(n, s, i, c), c !== null && t.update(c, e.ELEMENT_ARRAY_BUFFER), (u || o) && (o = !1, b(n, r, i, s), c !== null && e.bindBuffer(e.ELEMENT_ARRAY_BUFFER, t.get(c).buffer));
	}
	function c() {
		return e.createVertexArray();
	}
	function l(t) {
		return e.bindVertexArray(t);
	}
	function u(t) {
		return e.deleteVertexArray(t);
	}
	function d(e, t, n, i) {
		let a = i.wireframe === !0, o = r[t.id];
		o === void 0 && (o = {}, r[t.id] = o);
		let s = e.isInstancedMesh === !0 ? e.id : 0, l = o[s];
		l === void 0 && (l = {}, o[s] = l);
		let u = l[n.id];
		u === void 0 && (u = {}, l[n.id] = u);
		let d = u[a];
		return d === void 0 && (d = f(c()), u[a] = d), d;
	}
	function f(e) {
		let t = [], r = [], i = [];
		for (let e = 0; e < n; e++) t[e] = 0, r[e] = 0, i[e] = 0;
		return {
			geometry: null,
			program: null,
			wireframe: !1,
			newAttributes: t,
			enabledAttributes: r,
			attributeDivisors: i,
			object: e,
			attributes: {},
			index: null
		};
	}
	function p(e, t, n, r) {
		let i = a.attributes, o = t.attributes, s = 0, c = n.getAttributes();
		for (let t in c) if (c[t].location >= 0) {
			let n = i[t], r = o[t];
			if (r === void 0 && (t === "instanceMatrix" && e.instanceMatrix && (r = e.instanceMatrix), t === "instanceColor" && e.instanceColor && (r = e.instanceColor)), n === void 0 || n.attribute !== r || r && n.data !== r.data) return !0;
			s++;
		}
		return a.attributesNum !== s || a.index !== r;
	}
	function m(e, t, n, r) {
		let i = {}, o = t.attributes, s = 0, c = n.getAttributes();
		for (let t in c) if (c[t].location >= 0) {
			let n = o[t];
			n === void 0 && (t === "instanceMatrix" && e.instanceMatrix && (n = e.instanceMatrix), t === "instanceColor" && e.instanceColor && (n = e.instanceColor));
			let r = {};
			r.attribute = n, n && n.data && (r.data = n.data), i[t] = r, s++;
		}
		a.attributes = i, a.attributesNum = s, a.index = r;
	}
	function h() {
		let e = a.newAttributes;
		for (let t = 0, n = e.length; t < n; t++) e[t] = 0;
	}
	function g(e) {
		_(e, 0);
	}
	function _(t, n) {
		let r = a.newAttributes, i = a.enabledAttributes, o = a.attributeDivisors;
		r[t] = 1, i[t] === 0 && (e.enableVertexAttribArray(t), i[t] = 1), o[t] !== n && (e.vertexAttribDivisor(t, n), o[t] = n);
	}
	function v() {
		let t = a.newAttributes, n = a.enabledAttributes;
		for (let r = 0, i = n.length; r < i; r++) n[r] !== t[r] && (e.disableVertexAttribArray(r), n[r] = 0);
	}
	function y(t, n, r, i, a, o, s) {
		s === !0 ? e.vertexAttribIPointer(t, n, r, a, o) : e.vertexAttribPointer(t, n, r, i, a, o);
	}
	function b(n, r, i, a) {
		h();
		let o = a.attributes, s = i.getAttributes(), c = r.defaultAttributeValues;
		for (let r in s) {
			let i = s[r];
			if (i.location >= 0) {
				let s = o[r];
				if (s === void 0 && (r === "instanceMatrix" && n.instanceMatrix && (s = n.instanceMatrix), r === "instanceColor" && n.instanceColor && (s = n.instanceColor)), s !== void 0) {
					let r = s.normalized, o = s.itemSize, c = t.get(s);
					if (c === void 0) continue;
					let l = c.buffer, u = c.type, d = c.bytesPerElement, f = u === e.INT || u === e.UNSIGNED_INT || s.gpuType === 1013;
					if (s.isInterleavedBufferAttribute) {
						let t = s.data, c = t.stride, p = s.offset;
						if (t.isInstancedInterleavedBuffer) {
							for (let e = 0; e < i.locationSize; e++) _(i.location + e, t.meshPerAttribute);
							n.isInstancedMesh !== !0 && a._maxInstanceCount === void 0 && (a._maxInstanceCount = t.meshPerAttribute * t.count);
						} else for (let e = 0; e < i.locationSize; e++) g(i.location + e);
						e.bindBuffer(e.ARRAY_BUFFER, l);
						for (let e = 0; e < i.locationSize; e++) y(i.location + e, o / i.locationSize, u, r, c * d, (p + o / i.locationSize * e) * d, f);
					} else {
						if (s.isInstancedBufferAttribute) {
							for (let e = 0; e < i.locationSize; e++) _(i.location + e, s.meshPerAttribute);
							n.isInstancedMesh !== !0 && a._maxInstanceCount === void 0 && (a._maxInstanceCount = s.meshPerAttribute * s.count);
						} else for (let e = 0; e < i.locationSize; e++) g(i.location + e);
						e.bindBuffer(e.ARRAY_BUFFER, l);
						for (let e = 0; e < i.locationSize; e++) y(i.location + e, o / i.locationSize, u, r, o * d, o / i.locationSize * e * d, f);
					}
				} else if (c !== void 0) {
					let t = c[r];
					if (t !== void 0) switch (t.length) {
						case 2:
							e.vertexAttrib2fv(i.location, t);
							break;
						case 3:
							e.vertexAttrib3fv(i.location, t);
							break;
						case 4:
							e.vertexAttrib4fv(i.location, t);
							break;
						default: e.vertexAttrib1fv(i.location, t);
					}
				}
			}
		}
		v();
	}
	function x() {
		T();
		for (let e in r) {
			let t = r[e];
			for (let e in t) {
				let n = t[e];
				for (let e in n) {
					let t = n[e];
					for (let e in t) u(t[e].object), delete t[e];
					delete n[e];
				}
			}
			delete r[e];
		}
	}
	function S(e) {
		if (r[e.id] === void 0) return;
		let t = r[e.id];
		for (let e in t) {
			let n = t[e];
			for (let e in n) {
				let t = n[e];
				for (let e in t) u(t[e].object), delete t[e];
				delete n[e];
			}
		}
		delete r[e.id];
	}
	function C(e) {
		for (let t in r) {
			let n = r[t];
			for (let t in n) {
				let r = n[t];
				if (r[e.id] === void 0) continue;
				let i = r[e.id];
				for (let e in i) u(i[e].object), delete i[e];
				delete r[e.id];
			}
		}
	}
	function w(e) {
		for (let t in r) {
			let n = r[t], i = e.isInstancedMesh === !0 ? e.id : 0, a = n[i];
			if (a !== void 0) {
				for (let e in a) {
					let t = a[e];
					for (let e in t) u(t[e].object), delete t[e];
					delete a[e];
				}
				delete n[i], Object.keys(n).length === 0 && delete r[t];
			}
		}
	}
	function T() {
		E(), o = !0, a !== i && (a = i, l(a.object));
	}
	function E() {
		i.geometry = null, i.program = null, i.wireframe = !1;
	}
	return {
		setup: s,
		reset: T,
		resetDefaultState: E,
		dispose: x,
		releaseStatesOfGeometry: S,
		releaseStatesOfObject: w,
		releaseStatesOfProgram: C,
		initAttributes: h,
		enableAttribute: g,
		disableUnusedAttributes: v
	};
}
function xn(e, t, n) {
	let r;
	function i(e) {
		r = e;
	}
	function a(t, i) {
		e.drawArrays(r, t, i), n.update(i, r, 1);
	}
	function o(t, i, a) {
		a !== 0 && (e.drawArraysInstanced(r, t, i, a), n.update(i, r, a));
	}
	function s(e, i, a) {
		if (a === 0) return;
		t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(r, e, 0, i, 0, a);
		let o = 0;
		for (let e = 0; e < a; e++) o += i[e];
		n.update(o, r, 1);
	}
	this.setMode = i, this.render = a, this.renderInstances = o, this.renderMultiDraw = s;
}
function Sn(e, t, n, r) {
	let i;
	function a() {
		if (i !== void 0) return i;
		if (t.has("EXT_texture_filter_anisotropic") === !0) {
			let n = t.get("EXT_texture_filter_anisotropic");
			i = e.getParameter(n.MAX_TEXTURE_MAX_ANISOTROPY_EXT);
		} else i = 0;
		return i;
	}
	function o(t) {
		return t === 1023 || r.convert(t) === e.getParameter(e.IMPLEMENTATION_COLOR_READ_FORMAT);
	}
	function s(n) {
		let i = n === 1016 && (t.has("EXT_color_buffer_half_float") || t.has("EXT_color_buffer_float"));
		return !(n !== 1009 && n !== 1015 && !i && r.convert(n) !== e.getParameter(e.IMPLEMENTATION_COLOR_READ_TYPE));
	}
	function c(t) {
		if (t === "highp") {
			if (e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.HIGH_FLOAT).precision > 0 && e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.HIGH_FLOAT).precision > 0) return "highp";
			t = "mediump";
		}
		return t === "mediump" && e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.MEDIUM_FLOAT).precision > 0 && e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.MEDIUM_FLOAT).precision > 0 ? "mediump" : "lowp";
	}
	let l = n.precision === void 0 ? "highp" : n.precision, u = c(l);
	u !== l && (b("WebGLRenderer:", l, "not supported, using", u, "instead."), l = u);
	let d = n.logarithmicDepthBuffer === !0, f = n.reversedDepthBuffer === !0 && t.has("EXT_clip_control");
	n.reversedDepthBuffer === !0 && f === !1 && b("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");
	let p = e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS), m = e.getParameter(e.MAX_VERTEX_TEXTURE_IMAGE_UNITS), h = e.getParameter(e.MAX_TEXTURE_SIZE), g = e.getParameter(e.MAX_CUBE_MAP_TEXTURE_SIZE), _ = e.getParameter(e.MAX_VERTEX_ATTRIBS), v = e.getParameter(e.MAX_VERTEX_UNIFORM_VECTORS), y = e.getParameter(e.MAX_VARYING_VECTORS), x = e.getParameter(e.MAX_FRAGMENT_UNIFORM_VECTORS), S = e.getParameter(e.MAX_SAMPLES), C = e.getParameter(e.SAMPLES);
	return {
		isWebGL2: !0,
		getMaxAnisotropy: a,
		getMaxPrecision: c,
		textureFormatReadable: o,
		textureTypeReadable: s,
		precision: l,
		logarithmicDepthBuffer: d,
		reversedDepthBuffer: f,
		maxTextures: p,
		maxVertexTextures: m,
		maxTextureSize: h,
		maxCubemapSize: g,
		maxAttributes: _,
		maxVertexUniforms: v,
		maxVaryings: y,
		maxFragmentUniforms: x,
		maxSamples: S,
		samples: C
	};
}
function Cn(e) {
	let t = this, n = null, r = 0, i = !1, a = !1, o = new ue(), s = new z(), c = {
		value: null,
		needsUpdate: !1
	};
	this.uniform = c, this.numPlanes = 0, this.numIntersection = 0, this.init = function(e, t) {
		let n = e.length !== 0 || t || r !== 0 || i;
		return i = t, r = e.length, n;
	}, this.beginShadows = function() {
		a = !0, u(null);
	}, this.endShadows = function() {
		a = !1;
	}, this.setGlobalState = function(e, t) {
		n = u(e, t, 0);
	}, this.setState = function(t, o, s) {
		let d = t.clippingPlanes, f = t.clipIntersection, p = t.clipShadows, m = e.get(t);
		if (!i || d === null || d.length === 0 || a && !p) a ? u(null) : l();
		else {
			let e = a ? 0 : r, t = e * 4, i = m.clippingState || null;
			c.value = i, i = u(d, o, t, s);
			for (let e = 0; e !== t; ++e) i[e] = n[e];
			m.clippingState = i, this.numIntersection = f ? this.numPlanes : 0, this.numPlanes += e;
		}
	};
	function l() {
		c.value !== n && (c.value = n, c.needsUpdate = r > 0), t.numPlanes = r, t.numIntersection = 0;
	}
	function u(e, n, r, i) {
		let a = e === null ? 0 : e.length, l = null;
		if (a !== 0) {
			if (l = c.value, i !== !0 || l === null) {
				let t = r + a * 4, i = n.matrixWorldInverse;
				s.getNormalMatrix(i), (l === null || l.length < t) && (l = new Float32Array(t));
				for (let t = 0, n = r; t !== a; ++t, n += 4) o.copy(e[t]).applyMatrix4(i, s), o.normal.toArray(l, n), l[n + 3] = o.constant;
			}
			c.value = l, c.needsUpdate = !0;
		}
		return t.numPlanes = a, t.numIntersection = 0, l;
	}
}
var wn = 4, Tn = 6, En = 20, Dn = 256, On = /*@__PURE__*/ new ie(), kn = /*@__PURE__*/ new I(), An = null, jn = 0, Mn = 0, Nn = !1, Pn = /*@__PURE__*/ new L(), Fn = /*@__PURE__*/ new L(), In = class {
	constructor(e) {
		this._renderer = e, this._pingPongRenderTarget = null, this._lodMax = 0, this._cubeSize = 0, this._sizeLods = [], this._lodMeshes = [], this._backgroundBox = null, this._cubemapMaterial = null, this._equirectMaterial = null, this._blurMaterial = null, this._ggxMaterial = null;
	}
	fromScene(e, t = 0, n = .1, r = 100, i = {}) {
		let { size: a = 256, position: o = Pn } = i;
		An = this._renderer.getRenderTarget(), jn = this._renderer.getActiveCubeFace(), Mn = this._renderer.getActiveMipmapLevel(), Nn = this._renderer.xr.enabled, this._renderer.xr.enabled = !1, this._setSize(a);
		let s = this._allocateTargets();
		return s.depthBuffer = !0, this._sceneToCubeUV(e, n, r, s, o), t > 0 && this._blur(s, 0, 0, t), this._applyPMREM(s), this._cleanup(s), s;
	}
	fromEquirectangular(e, t = null) {
		return this._fromTexture(e, t);
	}
	fromCubemap(e, t = null) {
		return this._fromTexture(e, t);
	}
	compileCubemapShader() {
		this._cubemapMaterial === null && (this._cubemapMaterial = Un(), this._compileMaterial(this._cubemapMaterial));
	}
	compileEquirectangularShader() {
		this._equirectMaterial === null && (this._equirectMaterial = Hn(), this._compileMaterial(this._equirectMaterial));
	}
	dispose() {
		this._dispose(), this._cubemapMaterial !== null && this._cubemapMaterial.dispose(), this._equirectMaterial !== null && this._equirectMaterial.dispose(), this._backgroundBox !== null && (this._backgroundBox.geometry.dispose(), this._backgroundBox.material.dispose());
	}
	_setSize(e) {
		this._lodMax = Math.floor(Math.log2(e)), this._cubeSize = 2 ** this._lodMax;
	}
	_dispose() {
		this._blurMaterial !== null && this._blurMaterial.dispose(), this._ggxMaterial !== null && this._ggxMaterial.dispose(), this._pingPongRenderTarget !== null && this._pingPongRenderTarget.dispose();
		for (let e = 0; e < this._lodMeshes.length; e++) this._lodMeshes[e].geometry.dispose();
	}
	_cleanup(e) {
		this._renderer.setRenderTarget(An, jn, Mn), this._renderer.xr.enabled = Nn, e.scissorTest = !1, zn(e, 0, 0, e.width, e.height);
	}
	_fromTexture(e, t) {
		e.mapping === 301 || e.mapping === 302 ? this._setSize(e.image.length === 0 ? 16 : e.image[0].width || e.image[0].image.width) : this._setSize(e.image.width / 4), An = this._renderer.getRenderTarget(), jn = this._renderer.getActiveCubeFace(), Mn = this._renderer.getActiveMipmapLevel(), Nn = this._renderer.xr.enabled, this._renderer.xr.enabled = !1;
		let n = t || this._allocateTargets();
		return this._textureToCubeUV(e, n), this._applyPMREM(n), this._cleanup(n), n;
	}
	_allocateTargets() {
		let e = 3 * Math.max(this._cubeSize, 112), t = 4 * this._cubeSize, n = {
			magFilter: B,
			minFilter: B,
			generateMipmaps: !1,
			type: p,
			format: et,
			colorSpace: at,
			depthBuffer: !1
		}, r = Rn(e, t, n);
		if (this._pingPongRenderTarget === null || this._pingPongRenderTarget.width !== e || this._pingPongRenderTarget.height !== t) {
			this._pingPongRenderTarget !== null && this._dispose(), this._pingPongRenderTarget = Rn(e, t, n);
			let { _lodMax: r } = this;
			({lodMeshes: this._lodMeshes, sizeLods: this._sizeLods} = Ln(r)), this._blurMaterial = Vn(r, e, t), this._ggxMaterial = Bn(r, e, t);
		}
		return r;
	}
	_compileMaterial(e) {
		let t = new N(new We(), e);
		this._renderer.compile(t, On);
	}
	_sceneToCubeUV(e, t, n, r, i) {
		let a = new ae(90, 1, t, n), o = [
			1,
			-1,
			1,
			1,
			1,
			1
		], s = [
			1,
			1,
			1,
			-1,
			-1,
			-1
		], c = this._renderer, l = c.autoClear, u = c.toneMapping;
		c.getClearColor(kn), c.toneMapping = 0, c.autoClear = !1, c.state.buffers.depth.getReversed() && (c.setRenderTarget(r), c.clearDepth(), c.setRenderTarget(null)), this._backgroundBox === null && (this._backgroundBox = new N(new rt(), new lt({
			name: "PMREM.Background",
			side: 1,
			depthWrite: !1,
			depthTest: !1
		})));
		let d = this._backgroundBox, f = d.material, p = !1, m = e.background;
		m ? m.isColor && (f.color.copy(m), e.background = null, p = !0) : (f.color.copy(kn), p = !0);
		for (let t = 0; t < 6; t++) {
			let n = t % 3;
			n === 0 ? (a.up.set(0, o[t], 0), a.position.set(i.x, i.y, i.z), a.lookAt(i.x + s[t], i.y, i.z)) : n === 1 ? (a.up.set(0, 0, o[t]), a.position.set(i.x, i.y, i.z), a.lookAt(i.x, i.y + s[t], i.z)) : (a.up.set(0, o[t], 0), a.position.set(i.x, i.y, i.z), a.lookAt(i.x, i.y, i.z + s[t]));
			let l = this._cubeSize;
			zn(r, n * l, t > 2 ? l : 0, l, l), c.setRenderTarget(r), p && c.render(d, a), c.render(e, a);
		}
		c.toneMapping = u, c.autoClear = l, e.background = m;
	}
	_textureToCubeUV(e, t) {
		let n = this._renderer, r = e.mapping === 301 || e.mapping === 302;
		r ? (this._cubemapMaterial === null && (this._cubemapMaterial = Un()), this._cubemapMaterial.uniforms.flipEnvMap.value = e.isRenderTargetTexture === !1 ? -1 : 1) : this._equirectMaterial === null && (this._equirectMaterial = Hn());
		let i = r ? this._cubemapMaterial : this._equirectMaterial, a = this._lodMeshes[0];
		a.material = i;
		let o = i.uniforms;
		o.envMap.value = e;
		let s = this._cubeSize;
		zn(t, 0, 0, 3 * s, 2 * s), n.setRenderTarget(t), n.render(a, On);
	}
	_applyPMREM(e) {
		let t = this._renderer, n = t.autoClear;
		t.autoClear = !1;
		let r = this._lodMeshes.length;
		for (let t = 1; t < r; t++) this._applyGGXFilter(e, t - 1, t);
		t.autoClear = n;
	}
	_applyGGXFilter(e, t, n) {
		let r = this._renderer, i = this._pingPongRenderTarget, a = this._ggxMaterial, o = this._lodMeshes[n];
		o.material = a;
		let s = a.uniforms, c = n / (this._lodMeshes.length - 1), l = t / (this._lodMeshes.length - 1), u = Math.sqrt(c * c - l * l) * (c * 1.25), { _lodMax: d } = this, f = this._sizeLods[n], p = 3 * f * (n > d - wn ? n - d + wn : 0), m = 4 * (this._cubeSize - f);
		s.envMap.value = e.texture, s.roughness.value = u, s.mipInt.value = d - t, zn(i, p, m, 3 * f, 2 * f), r.setRenderTarget(i), r.render(o, On), s.envMap.value = i.texture, s.roughness.value = 0, s.mipInt.value = d - n, zn(e, p, m, 3 * f, 2 * f), r.setRenderTarget(e), r.render(o, On);
	}
	_blur(e, t, n, r) {
		let i = this._pingPongRenderTarget, a = Math.min(r, Math.PI) / Math.SQRT2;
		this._blurPass(e, i, t, n, a), this._blurPass(i, e, n, n, a);
	}
	_blurPass(e, t, n, r, i) {
		let a = this._renderer, o = this._blurMaterial, s = this._lodMeshes[r];
		s.material = o;
		let c = o.uniforms;
		c.envMap.value = e.texture, c.sigma.value = i, c.mipInt.value = this._lodMax - n;
		let l = this._sizeLods[r];
		zn(t, 3 * l * (r > this._lodMax - wn ? r - this._lodMax + wn : 0), 4 * (this._cubeSize - l), 3 * l, 2 * l), a.setRenderTarget(t), a.render(s, On);
	}
};
function Ln(e) {
	let t = [], n = [], r = e, i = e - wn + 1 + Tn;
	for (let e = 0; e < i; e++) {
		let e = 2 ** r;
		t.push(e);
		let i = 1 / (e - 2), a = -i, o = 1 + i, s = [
			a,
			a,
			o,
			a,
			o,
			o,
			a,
			a,
			o,
			o,
			a,
			o
		], c = /* @__PURE__ */ new Float32Array(108), l = /* @__PURE__ */ new Float32Array(108);
		for (let e = 0; e < 6; e++) {
			let t = e % 3 * 2 / 3 - 1, n = e > 2 ? 0 : -1, r = [
				t,
				n,
				0,
				t + 2 / 3,
				n,
				0,
				t + 2 / 3,
				n + 1,
				0,
				t,
				n,
				0,
				t + 2 / 3,
				n + 1,
				0,
				t,
				n + 1,
				0
			];
			c.set(r, 18 * e);
			for (let t = 0; t < 6; t++) {
				let n = s[t * 2] * 2 - 1, r = s[t * 2 + 1] * 2 - 1;
				e === 0 ? Fn.set(1, r, n) : e === 1 ? Fn.set(-n, 1, -r) : e === 2 ? Fn.set(-n, r, 1) : e === 3 ? Fn.set(-1, r, -n) : e === 4 ? Fn.set(-n, -1, r) : Fn.set(n, r, -1), Fn.toArray(l, (e * 6 + t) * 3);
			}
		}
		let u = new We();
		u.setAttribute("position", new Oe(c, 3)), u.setAttribute("outputDirection", new Oe(l, 3)), n.push(new N(u, null)), r > wn && r--;
	}
	return {
		lodMeshes: n,
		sizeLods: t
	};
}
function Rn(e, t, n) {
	let r = new Fe(e, t, n);
	return r.texture.mapping = 306, r.texture.name = "PMREM.cubeUv", r.scissorTest = !0, r;
}
function zn(e, t, n, r, i) {
	e.viewport.set(t, n, r, i), e.scissor.set(t, n, r, i);
}
function Bn(e, t, n) {
	return new m({
		name: "PMREMGGXConvolution",
		defines: {
			GGX_SAMPLES: Dn,
			CUBEUV_TEXEL_WIDTH: 1 / t,
			CUBEUV_TEXEL_HEIGHT: 1 / n,
			CUBEUV_MAX_MIP: `${e}.0`
		},
		uniforms: {
			envMap: { value: null },
			roughness: { value: 0 },
			mipInt: { value: 0 }
		},
		vertexShader: Wn(),
		fragmentShader: "\n\n			precision highp float;\n			precision highp int;\n\n			varying vec3 vOutputDirection;\n\n			uniform sampler2D envMap;\n			uniform float roughness;\n			uniform float mipInt;\n\n			#define ENVMAP_TYPE_CUBE_UV\n			#include <cube_uv_reflection_fragment>\n\n			#define PI 3.14159265359\n\n			// Van der Corput radical inverse\n			float radicalInverse_VdC(uint bits) {\n				bits = (bits << 16u) | (bits >> 16u);\n				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);\n				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);\n				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);\n				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);\n				return float(bits) * 2.3283064365386963e-10; // / 0x100000000\n			}\n\n			// Hammersley sequence\n			vec2 hammersley(uint i, uint N) {\n				return vec2(float(i) / float(N), radicalInverse_VdC(i));\n			}\n\n			// GGX VNDF importance sampling (Eric Heitz 2018)\n			// \"Sampling the GGX Distribution of Visible Normals\"\n			// https://jcgt.org/published/0007/04/01/\n			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {\n				float alpha = roughness * roughness;\n\n				// Section 4.1: Orthonormal basis\n				vec3 T1 = vec3(1.0, 0.0, 0.0);\n				vec3 T2 = cross(V, T1);\n\n				// Section 4.2: Parameterization of projected area\n				float r = sqrt(Xi.x);\n				float phi = 2.0 * PI * Xi.y;\n				float t1 = r * cos(phi);\n				float t2 = r * sin(phi);\n				float s = 0.5 * (1.0 + V.z);\n				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;\n\n				// Section 4.3: Reprojection onto hemisphere\n				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;\n\n				// Section 3.4: Transform back to ellipsoid configuration\n				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));\n			}\n\n			void main() {\n				vec3 N = normalize(vOutputDirection);\n				vec3 V = N; // Assume view direction equals normal for pre-filtering\n\n				vec3 prefilteredColor = vec3(0.0);\n				float totalWeight = 0.0;\n\n				// For very low roughness, just sample the environment directly\n				if (roughness < 0.001) {\n					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);\n					return;\n				}\n\n				// Tangent space basis for VNDF sampling\n				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);\n				vec3 tangent = normalize(cross(up, N));\n				vec3 bitangent = cross(N, tangent);\n\n				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {\n					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));\n\n					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)\n					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);\n\n					// Transform H back to world space\n					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);\n					vec3 L = normalize(2.0 * dot(V, H) * H - V);\n\n					float NdotL = max(dot(N, L), 0.0);\n\n					if(NdotL > 0.0) {\n						// Sample environment at fixed mip level\n						// VNDF importance sampling handles the distribution filtering\n						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);\n\n						// Weight by NdotL for the split-sum approximation\n						// VNDF PDF naturally accounts for the visible microfacet distribution\n						prefilteredColor += sampleColor * NdotL;\n						totalWeight += NdotL;\n					}\n				}\n\n				if (totalWeight > 0.0) {\n					prefilteredColor = prefilteredColor / totalWeight;\n				}\n\n				gl_FragColor = vec4(prefilteredColor, 1.0);\n			}\n		",
		blending: 0,
		depthTest: !1,
		depthWrite: !1
	});
}
function Vn(e, t, n) {
	return new m({
		name: "SphericalGaussianBlur",
		defines: {
			SAMPLES: En,
			CUBEUV_TEXEL_WIDTH: 1 / t,
			CUBEUV_TEXEL_HEIGHT: 1 / n,
			CUBEUV_MAX_MIP: `${e}.0`
		},
		uniforms: {
			envMap: { value: null },
			sigma: { value: 0 },
			mipInt: { value: 0 }
		},
		vertexShader: Wn(),
		fragmentShader: "\n\n			precision highp float;\n			precision highp int;\n\n			varying vec3 vOutputDirection;\n\n			uniform sampler2D envMap;\n			uniform float sigma;\n			uniform float mipInt;\n\n			#define ENVMAP_TYPE_CUBE_UV\n			#include <cube_uv_reflection_fragment>\n\n			#define PI 3.14159265359\n			#define GOLDEN_ANGLE 2.39996322973\n\n			void main() {\n\n				if ( sigma == 0.0 ) {\n\n					gl_FragColor = vec4( bilinearCubeUV( envMap, vOutputDirection, mipInt ), 1.0 );\n					return;\n\n				}\n\n				vec3 outputDirection = normalize( vOutputDirection );\n\n				vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );\n				vec3 tangent = normalize( cross( up, outputDirection ) );\n				vec3 bitangent = cross( outputDirection, tangent );\n\n				// Truncate the kernel at three standard deviations or at the antipode.\n				float thetaMax = min( 3.0 * sigma, PI );\n				float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );\n\n				vec3 accumColor = vec3( 0.0 );\n				float accumWeight = 0.0;\n\n				for ( int i = 0; i < SAMPLES; i ++ ) {\n\n					// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.\n					float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );\n					float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );\n					float phi = float( i ) * GOLDEN_ANGLE;\n\n					vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;\n					vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;\n\n					// Correct the planar sample density to solid angle.\n					float weight = sin( theta ) / theta;\n\n					accumColor += weight * bilinearCubeUV( envMap, sampleDirection, mipInt );\n					accumWeight += weight;\n\n				}\n\n				gl_FragColor = vec4( accumColor / accumWeight, 1.0 );\n\n			}\n		",
		blending: 0,
		depthTest: !1,
		depthWrite: !1
	});
}
function Hn() {
	return new m({
		name: "EquirectangularToCubeUV",
		uniforms: { envMap: { value: null } },
		vertexShader: Wn(),
		fragmentShader: "\n\n			precision mediump float;\n			precision mediump int;\n\n			varying vec3 vOutputDirection;\n\n			uniform sampler2D envMap;\n\n			#include <common>\n\n			void main() {\n\n				vec3 outputDirection = normalize( vOutputDirection );\n				vec2 uv = equirectUv( outputDirection );\n\n				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );\n\n			}\n		",
		blending: 0,
		depthTest: !1,
		depthWrite: !1
	});
}
function Un() {
	return new m({
		name: "CubemapToCubeUV",
		uniforms: {
			envMap: { value: null },
			flipEnvMap: { value: -1 }
		},
		vertexShader: Wn(),
		fragmentShader: "\n\n			precision mediump float;\n			precision mediump int;\n\n			uniform float flipEnvMap;\n\n			varying vec3 vOutputDirection;\n\n			uniform samplerCube envMap;\n\n			void main() {\n\n				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );\n\n			}\n		",
		blending: 0,
		depthTest: !1,
		depthWrite: !1
	});
}
function Wn() {
	return "\n\n		precision mediump float;\n		precision mediump int;\n\n		attribute vec3 outputDirection;\n\n		varying vec3 vOutputDirection;\n\n		void main() {\n\n			vOutputDirection = outputDirection;\n			gl_Position = vec4( position, 1.0 );\n\n		}\n	";
}
var Gn = class extends Fe {
	constructor(e = 1, t = {}) {
		super(e, e, t), this.isWebGLCubeRenderTarget = !0;
		let n = {
			width: e,
			height: e,
			depth: 1
		}, r = [
			n,
			n,
			n,
			n,
			n,
			n
		];
		this.texture = new xe(r), this._setTextureOptions(t), this.texture.isRenderTargetTexture = !0;
	}
	fromEquirectangularTexture(e, t) {
		this.texture.type = t.type, this.texture.colorSpace = t.colorSpace, this.texture.generateMipmaps = t.generateMipmaps, this.texture.minFilter = t.minFilter, this.texture.magFilter = t.magFilter;
		let n = {
			uniforms: { tEquirect: { value: null } },
			vertexShader: "\n\n				varying vec3 vWorldDirection;\n\n				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {\n\n					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );\n\n				}\n\n				void main() {\n\n					vWorldDirection = transformDirection( position, modelMatrix );\n\n					#include <begin_vertex>\n					#include <project_vertex>\n\n				}\n			",
			fragmentShader: "\n\n				uniform sampler2D tEquirect;\n\n				varying vec3 vWorldDirection;\n\n				#include <common>\n\n				void main() {\n\n					vec3 direction = normalize( vWorldDirection );\n\n					vec2 sampleUV = equirectUv( direction );\n\n					gl_FragColor = texture2D( tEquirect, sampleUV );\n\n				}\n			"
		}, r = new rt(5, 5, 5), i = new m({
			name: "CubemapFromEquirect",
			uniforms: ct(n.uniforms),
			vertexShader: n.vertexShader,
			fragmentShader: n.fragmentShader,
			side: 1,
			blending: 0
		});
		i.uniforms.tEquirect.value = t;
		let a = new N(r, i), o = t.minFilter;
		return t.minFilter === 1008 && (t.minFilter = B), new Le(1, 10, this).update(e, a), t.minFilter = o, a.geometry.dispose(), a.material.dispose(), this;
	}
	clear(e, t = !0, n = !0, r = !0) {
		let i = e.getRenderTarget();
		for (let i = 0; i < 6; i++) e.setRenderTarget(this, i), e.clear(t, n, r);
		e.setRenderTarget(i);
	}
};
function Kn(e) {
	let t = /* @__PURE__ */ new WeakMap(), n = /* @__PURE__ */ new WeakMap(), r = null;
	function i(e, t = !1) {
		return e == null ? null : t ? o(e) : a(e);
	}
	function a(n) {
		if (n && n.isTexture) {
			let r = n.mapping;
			if (r === 303 || r === 304) {
				if (t.has(n)) {
					let e = t.get(n).texture;
					return s(e, n.mapping);
				}
				{
					let r = n.image;
					if (r && r.height > 0) {
						let i = new Gn(r.height);
						return i.fromEquirectangularTexture(e, n), t.set(n, i), n.addEventListener("dispose", l), s(i.texture, n.mapping);
					}
					return null;
				}
			}
		}
		return n;
	}
	function o(t) {
		if (t && t.isTexture) {
			let i = t.mapping, a = i === 303 || i === 304, o = i === 301 || i === 302;
			if (a || o) {
				let i = n.get(t), s = i === void 0 ? 0 : i.texture.pmremVersion;
				if (t.isRenderTargetTexture && t.pmremVersion !== s) return r === null && (r = new In(e)), i = a ? r.fromEquirectangular(t, i) : r.fromCubemap(t, i), i.texture.pmremVersion = t.pmremVersion, n.set(t, i), i.texture;
				if (i !== void 0) return i.texture;
				{
					let s = t.image;
					return a && s && s.height > 0 || o && s && c(s) ? (r === null && (r = new In(e)), i = a ? r.fromEquirectangular(t) : r.fromCubemap(t), i.texture.pmremVersion = t.pmremVersion, n.set(t, i), t.addEventListener("dispose", u), i.texture) : null;
				}
			}
		}
		return t;
	}
	function s(e, t) {
		return t === 303 ? e.mapping = 301 : t === 304 && (e.mapping = 302), e;
	}
	function c(e) {
		let t = 0;
		for (let n = 0; n < 6; n++) e[n] !== void 0 && t++;
		return t === 6;
	}
	function l(e) {
		let n = e.target;
		n.removeEventListener("dispose", l);
		let r = t.get(n);
		r !== void 0 && (t.delete(n), r.dispose());
	}
	function u(e) {
		let t = e.target;
		t.removeEventListener("dispose", u);
		let r = n.get(t);
		r !== void 0 && (n.delete(t), r.dispose());
	}
	function d() {
		t = /* @__PURE__ */ new WeakMap(), n = /* @__PURE__ */ new WeakMap(), r !== null && (r.dispose(), r = null);
	}
	return {
		get: i,
		dispose: d
	};
}
function qn(e) {
	let t = {};
	function n(n) {
		if (t[n] !== void 0) return t[n];
		let r = e.getExtension(n);
		return t[n] = r, r;
	}
	return {
		has: function(e) {
			return n(e) !== null;
		},
		init: function() {
			n("EXT_color_buffer_float"), n("WEBGL_clip_cull_distance"), n("OES_texture_float_linear"), n("EXT_color_buffer_half_float"), n("WEBGL_multisampled_render_to_texture"), n("WEBGL_render_shared_exponent");
		},
		get: function(e) {
			let t = n(e);
			return t === null && se("WebGLRenderer: " + e + " extension not supported."), t;
		}
	};
}
function Jn(e, t, n, r) {
	let i = {}, a = /* @__PURE__ */ new WeakMap();
	function o(e) {
		let s = e.target;
		s.index !== null && t.remove(s.index);
		for (let e in s.attributes) t.remove(s.attributes[e]);
		s.removeEventListener("dispose", o), delete i[s.id];
		let c = a.get(s);
		c && (t.remove(c), a.delete(s)), r.releaseStatesOfGeometry(s), s.isInstancedBufferGeometry === !0 && delete s._maxInstanceCount, n.memory.geometries--;
	}
	function s(e, t) {
		return i[t.id] === !0 || (t.addEventListener("dispose", o), i[t.id] = !0, n.memory.geometries++), t;
	}
	function c(n) {
		let r = n.attributes;
		for (let n in r) t.update(r[n], e.ARRAY_BUFFER);
	}
	function u(e) {
		let n = [], r = e.index, i = e.attributes.position, o = 0;
		if (i === void 0) return;
		if (r !== null) {
			let e = r.array;
			o = r.version;
			for (let t = 0, r = e.length; t < r; t += 3) {
				let r = e[t + 0], i = e[t + 1], a = e[t + 2];
				n.push(r, i, i, a, a, r);
			}
		} else {
			let e = i.array;
			o = i.version;
			for (let t = 0, r = e.length / 3 - 1; t < r; t += 3) {
				let e = t + 0, r = t + 1, i = t + 2;
				n.push(e, r, r, i, i, e);
			}
		}
		let s = new (i.count >= 65535 ? Ne : l)(n, 1);
		s.version = o;
		let c = a.get(e);
		c && t.remove(c), a.set(e, s);
	}
	function d(e) {
		let t = a.get(e);
		if (t) {
			let n = e.index;
			n !== null && t.version < n.version && u(e);
		} else u(e);
		return a.get(e);
	}
	return {
		get: s,
		update: c,
		getWireframeAttribute: d
	};
}
function Yn(e, t, n) {
	let r;
	function i(e) {
		r = e;
	}
	let a, o;
	function s(e) {
		a = e.type, o = e.bytesPerElement;
	}
	function c(t, i) {
		e.drawElements(r, i, a, t * o), n.update(i, r, 1);
	}
	function l(t, i, s) {
		s !== 0 && (e.drawElementsInstanced(r, i, a, t * o, s), n.update(i, r, s));
	}
	function u(e, i, o) {
		if (o === 0) return;
		t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(r, i, 0, a, e, 0, o);
		let s = 0;
		for (let e = 0; e < o; e++) s += i[e];
		n.update(s, r, 1);
	}
	this.setMode = i, this.setIndex = s, this.render = c, this.renderInstances = l, this.renderMultiDraw = u;
}
function Xn(e) {
	let t = {
		geometries: 0,
		textures: 0
	}, n = {
		frame: 0,
		calls: 0,
		triangles: 0,
		points: 0,
		lines: 0
	};
	function r(t, r, i) {
		switch (n.calls++, r) {
			case e.TRIANGLES:
				n.triangles += t / 3 * i;
				break;
			case e.LINES:
				n.lines += t / 2 * i;
				break;
			case e.LINE_STRIP:
				n.lines += i * (t - 1);
				break;
			case e.LINE_LOOP:
				n.lines += i * t;
				break;
			case e.POINTS:
				n.points += i * t;
				break;
			default: mt("WebGLInfo: Unknown draw mode:", r);
		}
	}
	function i() {
		n.calls = 0, n.triangles = 0, n.points = 0, n.lines = 0;
	}
	return {
		memory: t,
		render: n,
		programs: null,
		autoReset: !0,
		reset: i,
		update: r
	};
}
function Zn(e, t, n) {
	let r = /* @__PURE__ */ new WeakMap(), i = new Qe();
	function a(a, o, s) {
		let c = a.morphTargetInfluences, l = o.morphAttributes.position || o.morphAttributes.normal || o.morphAttributes.color, u = l === void 0 ? 0 : l.length, d = r.get(o);
		if (d === void 0 || d.count !== u) {
			d !== void 0 && d.texture.dispose();
			let e = o.morphAttributes.position !== void 0, n = o.morphAttributes.normal !== void 0, a = o.morphAttributes.color !== void 0, s = o.morphAttributes.position || [], c = o.morphAttributes.normal || [], l = o.morphAttributes.color || [], f = 0;
			e === !0 && (f = 1), n === !0 && (f = 2), a === !0 && (f = 3);
			let p = o.attributes.position.count * f, m = 1;
			p > t.maxTextureSize && (m = Math.ceil(p / t.maxTextureSize), p = t.maxTextureSize);
			let h = new Float32Array(p * m * 4 * u), g = new pt(h, p, m, u);
			g.type = E, g.needsUpdate = !0;
			let _ = f * 4;
			for (let t = 0; t < u; t++) {
				let r = s[t], o = c[t], u = l[t], d = p * m * 4 * t;
				for (let t = 0; t < r.count; t++) {
					let s = t * _;
					e === !0 && (i.fromBufferAttribute(r, t), h[d + s + 0] = i.x, h[d + s + 1] = i.y, h[d + s + 2] = i.z, h[d + s + 3] = 0), n === !0 && (i.fromBufferAttribute(o, t), h[d + s + 4] = i.x, h[d + s + 5] = i.y, h[d + s + 6] = i.z, h[d + s + 7] = 0), a === !0 && (i.fromBufferAttribute(u, t), h[d + s + 8] = i.x, h[d + s + 9] = i.y, h[d + s + 10] = i.z, h[d + s + 11] = u.itemSize === 4 ? i.w : 1);
				}
			}
			d = {
				count: u,
				texture: g,
				size: new P(p, m)
			}, r.set(o, d);
			function v() {
				g.dispose(), r.delete(o), o.removeEventListener("dispose", v);
			}
			o.addEventListener("dispose", v);
		}
		if (a.isInstancedMesh === !0 && a.morphTexture !== null) s.getUniforms().setValue(e, "morphTexture", a.morphTexture, n);
		else {
			let t = 0;
			for (let e = 0; e < c.length; e++) t += c[e];
			let n = o.morphTargetsRelative ? 1 : 1 - t;
			s.getUniforms().setValue(e, "morphTargetBaseInfluence", n), s.getUniforms().setValue(e, "morphTargetInfluences", c);
		}
		s.getUniforms().setValue(e, "morphTargetsTexture", d.texture, n), s.getUniforms().setValue(e, "morphTargetsTextureSize", d.size);
	}
	return { update: a };
}
function Qn(e, t, n, r, i) {
	let a = /* @__PURE__ */ new WeakMap();
	function o(r) {
		let o = i.render.frame, s = r.geometry, l = t.get(r, s);
		if (a.get(l) !== o && (t.update(l), a.set(l, o)), r.isInstancedMesh && (r.hasEventListener("dispose", c) === !1 && r.addEventListener("dispose", c), a.get(r) !== o && (n.update(r.instanceMatrix, e.ARRAY_BUFFER), r.instanceColor !== null && n.update(r.instanceColor, e.ARRAY_BUFFER), a.set(r, o))), r.isSkinnedMesh) {
			let e = r.skeleton;
			a.get(e) !== o && (e.update(), a.set(e, o));
		}
		return l;
	}
	function s() {
		a = /* @__PURE__ */ new WeakMap();
	}
	function c(e) {
		let t = e.target;
		t.removeEventListener("dispose", c), r.releaseStatesOfObject(t), n.remove(t.instanceMatrix), t.instanceColor !== null && n.remove(t.instanceColor);
	}
	return {
		update: o,
		dispose: s
	};
}
var $n = {
	1: "LINEAR_TONE_MAPPING",
	2: "REINHARD_TONE_MAPPING",
	3: "CINEON_TONE_MAPPING",
	4: "ACES_FILMIC_TONE_MAPPING",
	6: "AGX_TONE_MAPPING",
	7: "NEUTRAL_TONE_MAPPING",
	5: "CUSTOM_TONE_MAPPING"
};
function er(e, t, n, r, i, a) {
	let o = new Fe(t, n, {
		type: e,
		depthBuffer: i,
		stencilBuffer: a,
		samples: r ? 4 : 0,
		storeMultisampledDepthBuffer: !1,
		storeMultisampledStencilBuffer: !1,
		resolveDepthBuffer: !1,
		resolveStencilBuffer: !1
	}), s = null, c = null, l = new We();
	l.setAttribute("position", new le([
		-1,
		3,
		0,
		-1,
		-1,
		0,
		3,
		-1,
		0
	], 3)), l.setAttribute("uv", new le([
		0,
		2,
		0,
		0,
		2,
		0
	], 2));
	let u = new C({
		uniforms: { tDiffuse: { value: null } },
		vertexShader: "\n			precision highp float;\n\n			uniform mat4 modelViewMatrix;\n			uniform mat4 projectionMatrix;\n\n			attribute vec3 position;\n			attribute vec2 uv;\n\n			varying vec2 vUv;\n\n			void main() {\n				vUv = uv;\n				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );\n			}",
		fragmentShader: "\n			precision highp float;\n\n			uniform sampler2D tDiffuse;\n\n			varying vec2 vUv;\n\n			#include <tonemapping_pars_fragment>\n			#include <colorspace_pars_fragment>\n\n			void main() {\n				gl_FragColor = texture2D( tDiffuse, vUv );\n\n				#ifdef LINEAR_TONE_MAPPING\n					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );\n				#elif defined( REINHARD_TONE_MAPPING )\n					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );\n				#elif defined( CINEON_TONE_MAPPING )\n					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );\n				#elif defined( ACES_FILMIC_TONE_MAPPING )\n					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );\n				#elif defined( AGX_TONE_MAPPING )\n					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );\n				#elif defined( NEUTRAL_TONE_MAPPING )\n					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );\n				#elif defined( CUSTOM_TONE_MAPPING )\n					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );\n				#endif\n\n				#ifdef SRGB_TRANSFER\n					gl_FragColor = sRGBTransferOETF( gl_FragColor );\n				#endif\n			}",
		depthTest: !1,
		depthWrite: !1
	}), d = new N(l, u), f = new ie(-1, 1, 1, -1, 0, 1), m = null, h = null, g = !1, _, v = null, y = [], b = !1;
	this.setSize = function(e, t) {
		o.setSize(e, t), s !== null && s.setSize(e, t), c !== null && c.setSize(e, t);
		for (let n = 0; n < y.length; n++) {
			let r = y[n];
			r.setSize && r.setSize(e, t);
		}
	}, this.setEffects = function(e) {
		y = e, b = y.length > 0 && y[0].isRenderPass === !0;
		let t = o.width, n = o.height;
		y.length > 0 && s === null && (s = new Fe(t, n, {
			type: p,
			depthBuffer: !1,
			stencilBuffer: !1
		}), c = new Fe(t, n, {
			type: p,
			depthBuffer: !1,
			stencilBuffer: !1
		}));
		for (let e = 0; e < y.length; e++) {
			let r = y[e];
			r.setSize && r.setSize(t, n);
		}
	}, this.begin = function(e, t) {
		if (g || e.toneMapping === 0 && y.length === 0) return !1;
		if (v = t, t !== null) {
			let e = t.width, n = t.height;
			(o.width !== e || o.height !== n) && this.setSize(e, n);
		}
		return b === !1 && e.setRenderTarget(o), _ = e.toneMapping, e.toneMapping = 0, !0;
	}, this.hasRenderPass = function() {
		return b;
	}, this.end = function(e, t) {
		e.toneMapping = _, g = !0;
		let n = o, r = s;
		for (let i = 0; i < y.length; i++) {
			let a = y[i];
			a.enabled !== !1 && (a.render(e, r, n, t), a.needsSwap !== !1 && (n = r, r = r === s ? c : s));
		}
		if (m !== e.outputColorSpace || h !== e.toneMapping) {
			m = e.outputColorSpace, h = e.toneMapping, u.defines = {}, Ze.getTransfer(m) === "srgb" && (u.defines.SRGB_TRANSFER = "");
			let t = $n[h];
			t && (u.defines[t] = ""), u.needsUpdate = !0;
		}
		u.uniforms.tDiffuse.value = n.texture, e.setRenderTarget(v), e.render(d, f), v = null, g = !1;
	}, this.isCompositing = function() {
		return g;
	}, this.dispose = function() {
		o.dispose(), s !== null && s.dispose(), c !== null && c.dispose(), l.dispose(), u.dispose();
	};
}
var tr = /*@__PURE__*/ new ye(), nr = /*@__PURE__*/ new v(1, 1), rr = /*@__PURE__*/ new pt(), ir = /*@__PURE__*/ new Te(), ar = /*@__PURE__*/ new xe(), or = [], sr = [], cr = /* @__PURE__ */ new Float32Array(16), lr = /* @__PURE__ */ new Float32Array(9), ur = /* @__PURE__ */ new Float32Array(4);
function dr(e, t, n) {
	let r = e[0];
	if (r <= 0 || r > 0) return e;
	let i = t * n, a = or[i];
	if (a === void 0 && (a = new Float32Array(i), or[i] = a), t !== 0) {
		r.toArray(a, 0);
		for (let r = 1, i = 0; r !== t; ++r) i += n, e[r].toArray(a, i);
	}
	return a;
}
function fr(e, t) {
	if (e.length !== t.length) return !1;
	for (let n = 0, r = e.length; n < r; n++) if (e[n] !== t[n]) return !1;
	return !0;
}
function pr(e, t) {
	for (let n = 0, r = t.length; n < r; n++) e[n] = t[n];
}
function mr(e, t) {
	let n = sr[t];
	n === void 0 && (n = new Int32Array(t), sr[t] = n);
	for (let r = 0; r !== t; ++r) n[r] = e.allocateTextureUnit();
	return n;
}
function hr(e, t) {
	let n = this.cache;
	n[0] !== t && (e.uniform1f(this.addr, t), n[0] = t);
}
function gr(e, t) {
	let n = this.cache;
	if (t.x !== void 0) (n[0] !== t.x || n[1] !== t.y) && (e.uniform2f(this.addr, t.x, t.y), n[0] = t.x, n[1] = t.y);
	else {
		if (fr(n, t)) return;
		e.uniform2fv(this.addr, t), pr(n, t);
	}
}
function _r(e, t) {
	let n = this.cache;
	if (t.x !== void 0) (n[0] !== t.x || n[1] !== t.y || n[2] !== t.z) && (e.uniform3f(this.addr, t.x, t.y, t.z), n[0] = t.x, n[1] = t.y, n[2] = t.z);
	else if (t.r !== void 0) (n[0] !== t.r || n[1] !== t.g || n[2] !== t.b) && (e.uniform3f(this.addr, t.r, t.g, t.b), n[0] = t.r, n[1] = t.g, n[2] = t.b);
	else {
		if (fr(n, t)) return;
		e.uniform3fv(this.addr, t), pr(n, t);
	}
}
function vr(e, t) {
	let n = this.cache;
	if (t.x !== void 0) (n[0] !== t.x || n[1] !== t.y || n[2] !== t.z || n[3] !== t.w) && (e.uniform4f(this.addr, t.x, t.y, t.z, t.w), n[0] = t.x, n[1] = t.y, n[2] = t.z, n[3] = t.w);
	else {
		if (fr(n, t)) return;
		e.uniform4fv(this.addr, t), pr(n, t);
	}
}
function yr(e, t) {
	let n = this.cache, r = t.elements;
	if (r === void 0) {
		if (fr(n, t)) return;
		e.uniformMatrix2fv(this.addr, !1, t), pr(n, t);
	} else {
		if (fr(n, r)) return;
		ur.set(r), e.uniformMatrix2fv(this.addr, !1, ur), pr(n, r);
	}
}
function br(e, t) {
	let n = this.cache, r = t.elements;
	if (r === void 0) {
		if (fr(n, t)) return;
		e.uniformMatrix3fv(this.addr, !1, t), pr(n, t);
	} else {
		if (fr(n, r)) return;
		lr.set(r), e.uniformMatrix3fv(this.addr, !1, lr), pr(n, r);
	}
}
function xr(e, t) {
	let n = this.cache, r = t.elements;
	if (r === void 0) {
		if (fr(n, t)) return;
		e.uniformMatrix4fv(this.addr, !1, t), pr(n, t);
	} else {
		if (fr(n, r)) return;
		cr.set(r), e.uniformMatrix4fv(this.addr, !1, cr), pr(n, r);
	}
}
function Sr(e, t) {
	let n = this.cache;
	n[0] !== t && (e.uniform1i(this.addr, t), n[0] = t);
}
function Cr(e, t) {
	let n = this.cache;
	if (t.x !== void 0) (n[0] !== t.x || n[1] !== t.y) && (e.uniform2i(this.addr, t.x, t.y), n[0] = t.x, n[1] = t.y);
	else {
		if (fr(n, t)) return;
		e.uniform2iv(this.addr, t), pr(n, t);
	}
}
function wr(e, t) {
	let n = this.cache;
	if (t.x !== void 0) (n[0] !== t.x || n[1] !== t.y || n[2] !== t.z) && (e.uniform3i(this.addr, t.x, t.y, t.z), n[0] = t.x, n[1] = t.y, n[2] = t.z);
	else {
		if (fr(n, t)) return;
		e.uniform3iv(this.addr, t), pr(n, t);
	}
}
function Tr(e, t) {
	let n = this.cache;
	if (t.x !== void 0) (n[0] !== t.x || n[1] !== t.y || n[2] !== t.z || n[3] !== t.w) && (e.uniform4i(this.addr, t.x, t.y, t.z, t.w), n[0] = t.x, n[1] = t.y, n[2] = t.z, n[3] = t.w);
	else {
		if (fr(n, t)) return;
		e.uniform4iv(this.addr, t), pr(n, t);
	}
}
function Er(e, t) {
	let n = this.cache;
	n[0] !== t && (e.uniform1ui(this.addr, t), n[0] = t);
}
function Dr(e, t) {
	let n = this.cache;
	if (t.x !== void 0) (n[0] !== t.x || n[1] !== t.y) && (e.uniform2ui(this.addr, t.x, t.y), n[0] = t.x, n[1] = t.y);
	else {
		if (fr(n, t)) return;
		e.uniform2uiv(this.addr, t), pr(n, t);
	}
}
function Or(e, t) {
	let n = this.cache;
	if (t.x !== void 0) (n[0] !== t.x || n[1] !== t.y || n[2] !== t.z) && (e.uniform3ui(this.addr, t.x, t.y, t.z), n[0] = t.x, n[1] = t.y, n[2] = t.z);
	else {
		if (fr(n, t)) return;
		e.uniform3uiv(this.addr, t), pr(n, t);
	}
}
function kr(e, t) {
	let n = this.cache;
	if (t.x !== void 0) (n[0] !== t.x || n[1] !== t.y || n[2] !== t.z || n[3] !== t.w) && (e.uniform4ui(this.addr, t.x, t.y, t.z, t.w), n[0] = t.x, n[1] = t.y, n[2] = t.z, n[3] = t.w);
	else {
		if (fr(n, t)) return;
		e.uniform4uiv(this.addr, t), pr(n, t);
	}
}
function Ar(e, t, n) {
	let r = this.cache, i = n.allocateTextureUnit();
	r[0] !== i && (e.uniform1i(this.addr, i), r[0] = i);
	let a;
	this.type === e.SAMPLER_2D_SHADOW ? (nr.compareFunction = n.isReversedDepthBuffer() ? 518 : 515, a = nr) : a = tr, n.setTexture2D(t || a, i);
}
function jr(e, t, n) {
	let r = this.cache, i = n.allocateTextureUnit();
	r[0] !== i && (e.uniform1i(this.addr, i), r[0] = i), n.setTexture3D(t || ir, i);
}
function Mr(e, t, n) {
	let r = this.cache, i = n.allocateTextureUnit();
	r[0] !== i && (e.uniform1i(this.addr, i), r[0] = i), n.setTextureCube(t || ar, i);
}
function Nr(e, t, n) {
	let r = this.cache, i = n.allocateTextureUnit();
	r[0] !== i && (e.uniform1i(this.addr, i), r[0] = i), n.setTexture2DArray(t || rr, i);
}
function Pr(e) {
	switch (e) {
		case 5126: return hr;
		case 35664: return gr;
		case 35665: return _r;
		case 35666: return vr;
		case 35674: return yr;
		case 35675: return br;
		case 35676: return xr;
		case 5124:
		case 35670: return Sr;
		case 35667:
		case 35671: return Cr;
		case 35668:
		case 35672: return wr;
		case 35669:
		case 35673: return Tr;
		case 5125: return Er;
		case 36294: return Dr;
		case 36295: return Or;
		case 36296: return kr;
		case 35678:
		case 36198:
		case 36298:
		case 36306:
		case 35682: return Ar;
		case 35679:
		case 36299:
		case 36307: return jr;
		case 35680:
		case 36300:
		case 36308:
		case 36293: return Mr;
		case 36289:
		case 36303:
		case 36311:
		case 36292: return Nr;
	}
}
function Fr(e, t) {
	e.uniform1fv(this.addr, t);
}
function Ir(e, t) {
	let n = dr(t, this.size, 2);
	e.uniform2fv(this.addr, n);
}
function Lr(e, t) {
	let n = dr(t, this.size, 3);
	e.uniform3fv(this.addr, n);
}
function Rr(e, t) {
	let n = dr(t, this.size, 4);
	e.uniform4fv(this.addr, n);
}
function zr(e, t) {
	let n = dr(t, this.size, 4);
	e.uniformMatrix2fv(this.addr, !1, n);
}
function Br(e, t) {
	let n = dr(t, this.size, 9);
	e.uniformMatrix3fv(this.addr, !1, n);
}
function Vr(e, t) {
	let n = dr(t, this.size, 16);
	e.uniformMatrix4fv(this.addr, !1, n);
}
function Hr(e, t) {
	e.uniform1iv(this.addr, t);
}
function Ur(e, t) {
	e.uniform2iv(this.addr, t);
}
function Wr(e, t) {
	e.uniform3iv(this.addr, t);
}
function Gr(e, t) {
	e.uniform4iv(this.addr, t);
}
function Kr(e, t) {
	e.uniform1uiv(this.addr, t);
}
function qr(e, t) {
	e.uniform2uiv(this.addr, t);
}
function Jr(e, t) {
	e.uniform3uiv(this.addr, t);
}
function Yr(e, t) {
	e.uniform4uiv(this.addr, t);
}
function Xr(e, t, n) {
	let r = this.cache, i = t.length, a = mr(n, i);
	fr(r, a) || (e.uniform1iv(this.addr, a), pr(r, a));
	let o;
	o = this.type === e.SAMPLER_2D_SHADOW ? nr : tr;
	for (let e = 0; e !== i; ++e) n.setTexture2D(t[e] || o, a[e]);
}
function Zr(e, t, n) {
	let r = this.cache, i = t.length, a = mr(n, i);
	fr(r, a) || (e.uniform1iv(this.addr, a), pr(r, a));
	for (let e = 0; e !== i; ++e) n.setTexture3D(t[e] || ir, a[e]);
}
function Qr(e, t, n) {
	let r = this.cache, i = t.length, a = mr(n, i);
	fr(r, a) || (e.uniform1iv(this.addr, a), pr(r, a));
	for (let e = 0; e !== i; ++e) n.setTextureCube(t[e] || ar, a[e]);
}
function $r(e, t, n) {
	let r = this.cache, i = t.length, a = mr(n, i);
	fr(r, a) || (e.uniform1iv(this.addr, a), pr(r, a));
	for (let e = 0; e !== i; ++e) n.setTexture2DArray(t[e] || rr, a[e]);
}
function ei(e) {
	switch (e) {
		case 5126: return Fr;
		case 35664: return Ir;
		case 35665: return Lr;
		case 35666: return Rr;
		case 35674: return zr;
		case 35675: return Br;
		case 35676: return Vr;
		case 5124:
		case 35670: return Hr;
		case 35667:
		case 35671: return Ur;
		case 35668:
		case 35672: return Wr;
		case 35669:
		case 35673: return Gr;
		case 5125: return Kr;
		case 36294: return qr;
		case 36295: return Jr;
		case 36296: return Yr;
		case 35678:
		case 36198:
		case 36298:
		case 36306:
		case 35682: return Xr;
		case 35679:
		case 36299:
		case 36307: return Zr;
		case 35680:
		case 36300:
		case 36308:
		case 36293: return Qr;
		case 36289:
		case 36303:
		case 36311:
		case 36292: return $r;
	}
}
var ti = class {
	constructor(e, t, n) {
		this.id = e, this.addr = n, this.cache = [], this.type = t.type, this.setValue = Pr(t.type);
	}
}, ni = class {
	constructor(e, t, n) {
		this.id = e, this.addr = n, this.cache = [], this.type = t.type, this.size = t.size, this.setValue = ei(t.type);
	}
}, ri = class {
	constructor(e) {
		this.id = e, this.seq = [], this.map = {};
	}
	setValue(e, t, n) {
		let r = this.seq;
		for (let i = 0, a = r.length; i !== a; ++i) {
			let a = r[i];
			a.setValue(e, t[a.id], n);
		}
	}
}, ii = /(\w+)(\])?(\[|\.)?/g;
function ai(e, t) {
	e.seq.push(t), e.map[t.id] = t;
}
function oi(e, t, n) {
	let r = e.name, i = r.length;
	for (ii.lastIndex = 0;;) {
		let a = ii.exec(r), o = ii.lastIndex, s = a[1], c = a[2] === "]", l = a[3];
		if (c && (s |= 0), l === void 0 || l === "[" && o + 2 === i) {
			ai(n, l === void 0 ? new ti(s, e, t) : new ni(s, e, t));
			break;
		}
		{
			let e = n.map[s];
			e === void 0 && (e = new ri(s), ai(n, e)), n = e;
		}
	}
}
var si = class {
	constructor(e, t) {
		this.seq = [], this.map = {};
		let n = e.getProgramParameter(t, e.ACTIVE_UNIFORMS);
		for (let r = 0; r < n; ++r) {
			let n = e.getActiveUniform(t, r);
			oi(n, e.getUniformLocation(t, n.name), this);
		}
		let r = [], i = [];
		for (let t of this.seq) t.type === e.SAMPLER_2D_SHADOW || t.type === e.SAMPLER_CUBE_SHADOW || t.type === e.SAMPLER_2D_ARRAY_SHADOW ? r.push(t) : i.push(t);
		r.length > 0 && (this.seq = r.concat(i));
	}
	setValue(e, t, n, r) {
		let i = this.map[t];
		i !== void 0 && i.setValue(e, n, r);
	}
	setOptional(e, t, n) {
		let r = t[n];
		r !== void 0 && this.setValue(e, n, r);
	}
	static upload(e, t, n, r) {
		for (let i = 0, a = t.length; i !== a; ++i) {
			let a = t[i], o = n[a.id];
			o.needsUpdate !== !1 && a.setValue(e, o.value, r);
		}
	}
	static seqWithValue(e, t) {
		let n = [];
		for (let r = 0, i = e.length; r !== i; ++r) {
			let i = e[r];
			i.id in t && n.push(i);
		}
		return n;
	}
};
function ci(e, t, n) {
	let r = e.createShader(t);
	return e.shaderSource(r, n), e.compileShader(r), r;
}
var li = 37297, ui = 0;
function di(e, t) {
	let n = e.split("\n"), r = [], i = Math.max(t - 6, 0), a = Math.min(t + 6, n.length);
	for (let e = i; e < a; e++) {
		let i = e + 1;
		r.push(`${i === t ? ">" : " "} ${i}: ${n[e]}`);
	}
	return r.join("\n");
}
var fi = /*@__PURE__*/ new z();
function pi(e) {
	Ze._getMatrix(fi, Ze.workingColorSpace, e);
	let t = `mat3( ${fi.elements.map((e) => e.toFixed(4))} )`;
	switch (Ze.getTransfer(e)) {
		case Ae: return [t, "LinearTransferOETF"];
		case de: return [t, "sRGBTransferOETF"];
		default: return b("WebGLProgram: Unsupported color space: ", e), [t, "LinearTransferOETF"];
	}
}
function mi(e, t, n) {
	let r = e.getShaderParameter(t, e.COMPILE_STATUS), i = (e.getShaderInfoLog(t) || "").trim();
	if (r && i === "") return "";
	let a = /ERROR: 0:(\d+)/.exec(i);
	if (a) {
		let r = parseInt(a[1]);
		return n.toUpperCase() + "\n\n" + i + "\n\n" + di(e.getShaderSource(t), r);
	}
	return i;
}
function hi(e, t) {
	let n = pi(t);
	return [
		`vec4 ${e}( vec4 value ) {`,
		`	return ${n[1]}( vec4( value.rgb * ${n[0]}, value.a ) );`,
		"}"
	].join("\n");
}
var gi = {
	1: "Linear",
	2: "Reinhard",
	3: "Cineon",
	4: "ACESFilmic",
	6: "AgX",
	7: "Neutral",
	5: "Custom"
};
function _i(e, t) {
	let n = gi[t];
	return n === void 0 ? (b("WebGLProgram: Unsupported toneMapping:", t), "vec3 " + e + "( vec3 color ) { return LinearToneMapping( color ); }") : "vec3 " + e + "( vec3 color ) { return " + n + "ToneMapping( color ); }";
}
var vi = /*@__PURE__*/ new L();
function yi() {
	return Ze.getLuminanceCoefficients(vi), [
		"float luminance( const in vec3 rgb ) {",
		`	const vec3 weights = vec3( ${vi.x.toFixed(4)}, ${vi.y.toFixed(4)}, ${vi.z.toFixed(4)} );`,
		"	return dot( weights, rgb );",
		"}"
	].join("\n");
}
function bi(e) {
	return [e.extensionClipCullDistance ? "#extension GL_ANGLE_clip_cull_distance : require" : "", e.extensionMultiDraw ? "#extension GL_ANGLE_multi_draw : require" : ""].filter(Ci).join("\n");
}
function xi(e) {
	let t = [];
	for (let n in e) {
		let r = e[n];
		r !== !1 && t.push("#define " + n + " " + r);
	}
	return t.join("\n");
}
function Si(e, t) {
	let n = {}, r = e.getProgramParameter(t, e.ACTIVE_ATTRIBUTES);
	for (let i = 0; i < r; i++) {
		let r = e.getActiveAttrib(t, i), a = r.name, o = 1;
		r.type === e.FLOAT_MAT2 && (o = 2), r.type === e.FLOAT_MAT3 && (o = 3), r.type === e.FLOAT_MAT4 && (o = 4), n[a] = {
			type: r.type,
			location: e.getAttribLocation(t, a),
			locationSize: o
		};
	}
	return n;
}
function Ci(e) {
	return e !== "";
}
function wi(e, t) {
	let n = t.numSpotLightShadows + t.numSpotLightMaps - t.numSpotLightShadowsWithMaps;
	return e.replace(/NUM_SUN_LIGHTS/g, t.numSunLights).replace(/NUM_DIR_LIGHTS/g, t.numDirLights).replace(/NUM_SPOT_LIGHTS/g, t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g, t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g, n).replace(/NUM_RECT_AREA_LIGHTS/g, t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g, t.numPointLights).replace(/NUM_HEMI_LIGHTS/g, t.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g, t.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g, t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g, t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g, t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g, t.numPointLightShadows);
}
function Ti(e, t) {
	return e.replace(/NUM_CLIPPING_PLANES/g, t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g, t.numClippingPlanes - t.numClipIntersection);
}
var Ei = /^[ \t]*#include +<([\w\d./]+)>/gm;
function Di(e) {
	return e.replace(Ei, ki);
}
var Oi = /* @__PURE__ */ new Map();
function ki(e, t) {
	let n = G[t];
	if (n === void 0) {
		let e = Oi.get(t);
		if (e !== void 0) n = G[e], b("WebGLRenderer: Shader chunk \"%s\" has been deprecated. Use \"%s\" instead.", t, e);
		else throw Error("THREE.WebGLProgram: Can not resolve #include <" + t + ">");
	}
	return Di(n);
}
var Ai = /#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;
function ji(e) {
	return e.replace(Ai, Mi);
}
function Mi(e, t, n, r) {
	let i = "";
	for (let e = parseInt(t); e < parseInt(n); e++) i += r.replace(/\[\s*i\s*\]/g, "[ " + e + " ]").replace(/UNROLLED_LOOP_INDEX/g, e);
	return i;
}
function Ni(e) {
	let t = `precision ${e.precision} float;
	precision ${e.precision} int;
	precision ${e.precision} sampler2D;
	precision ${e.precision} samplerCube;
	precision ${e.precision} sampler3D;
	precision ${e.precision} sampler2DArray;
	precision ${e.precision} sampler2DShadow;
	precision ${e.precision} samplerCubeShadow;
	precision ${e.precision} sampler2DArrayShadow;
	precision ${e.precision} isampler2D;
	precision ${e.precision} isampler3D;
	precision ${e.precision} isamplerCube;
	precision ${e.precision} isampler2DArray;
	precision ${e.precision} usampler2D;
	precision ${e.precision} usampler3D;
	precision ${e.precision} usamplerCube;
	precision ${e.precision} usampler2DArray;
	`;
	return e.precision === "highp" ? t += "\n#define HIGH_PRECISION" : e.precision === "mediump" ? t += "\n#define MEDIUM_PRECISION" : e.precision === "lowp" && (t += "\n#define LOW_PRECISION"), t;
}
var Pi = {
	1: "SHADOWMAP_TYPE_PCF",
	3: "SHADOWMAP_TYPE_VSM"
};
function Fi(e) {
	return Pi[e.shadowMapType] || "SHADOWMAP_TYPE_BASIC";
}
var Ii = {
	301: "ENVMAP_TYPE_CUBE",
	302: "ENVMAP_TYPE_CUBE",
	306: "ENVMAP_TYPE_CUBE_UV"
};
function Li(e) {
	return e.envMap === !1 ? "ENVMAP_TYPE_CUBE" : Ii[e.envMapMode] || "ENVMAP_TYPE_CUBE";
}
var Ri = { 302: "ENVMAP_MODE_REFRACTION" };
function zi(e) {
	return e.envMap === !1 ? "ENVMAP_MODE_REFLECTION" : Ri[e.envMapMode] || "ENVMAP_MODE_REFLECTION";
}
var Bi = {
	0: "ENVMAP_BLENDING_MULTIPLY",
	1: "ENVMAP_BLENDING_MIX",
	2: "ENVMAP_BLENDING_ADD"
};
function Vi(e) {
	return e.envMap === !1 ? "ENVMAP_BLENDING_NONE" : Bi[e.combine] || "ENVMAP_BLENDING_NONE";
}
function Hi(e) {
	let t = e.envMapCubeUVHeight;
	if (t === null) return null;
	let n = Math.log2(t) - 2, r = 1 / t;
	return {
		texelWidth: 1 / (3 * Math.max(2 ** n, 112)),
		texelHeight: r,
		maxMip: n
	};
}
function Ui(e, t, n, r) {
	let i = e.getContext(), a = n.defines, o = n.vertexShader, s = n.fragmentShader, c = Fi(n), l = Li(n), u = zi(n), d = Vi(n), f = Hi(n), p = bi(n), m = xi(a), h = i.createProgram(), g, _, v = n.glslVersion ? "#version " + n.glslVersion + "\n" : "";
	n.isRawShaderMaterial ? (g = [
		"#define SHADER_TYPE " + n.shaderType,
		"#define SHADER_NAME " + n.shaderName,
		m
	].filter(Ci).join("\n"), g.length > 0 && (g += "\n"), _ = [
		"#define SHADER_TYPE " + n.shaderType,
		"#define SHADER_NAME " + n.shaderName,
		m
	].filter(Ci).join("\n"), _.length > 0 && (_ += "\n")) : (g = [
		Ni(n),
		"#define SHADER_TYPE " + n.shaderType,
		"#define SHADER_NAME " + n.shaderName,
		m,
		n.extensionClipCullDistance ? "#define USE_CLIP_DISTANCE" : "",
		n.batching ? "#define USE_BATCHING" : "",
		n.batchingColor ? "#define USE_BATCHING_COLOR" : "",
		n.instancing ? "#define USE_INSTANCING" : "",
		n.instancingColor ? "#define USE_INSTANCING_COLOR" : "",
		n.instancingMorph ? "#define USE_INSTANCING_MORPH" : "",
		n.useFog && n.fog ? "#define USE_FOG" : "",
		n.useFog && n.fogExp2 ? "#define FOG_EXP2" : "",
		n.map ? "#define USE_MAP" : "",
		n.envMap ? "#define USE_ENVMAP" : "",
		n.envMap ? "#define " + u : "",
		n.lightMap ? "#define USE_LIGHTMAP" : "",
		n.aoMap ? "#define USE_AOMAP" : "",
		n.bumpMap ? "#define USE_BUMPMAP" : "",
		n.normalMap ? "#define USE_NORMALMAP" : "",
		n.normalMapObjectSpace ? "#define USE_NORMALMAP_OBJECTSPACE" : "",
		n.normalMapTangentSpace ? "#define USE_NORMALMAP_TANGENTSPACE" : "",
		n.displacementMap ? "#define USE_DISPLACEMENTMAP" : "",
		n.emissiveMap ? "#define USE_EMISSIVEMAP" : "",
		n.anisotropy ? "#define USE_ANISOTROPY" : "",
		n.anisotropyMap ? "#define USE_ANISOTROPYMAP" : "",
		n.clearcoatMap ? "#define USE_CLEARCOATMAP" : "",
		n.clearcoatRoughnessMap ? "#define USE_CLEARCOAT_ROUGHNESSMAP" : "",
		n.clearcoatNormalMap ? "#define USE_CLEARCOAT_NORMALMAP" : "",
		n.iridescenceMap ? "#define USE_IRIDESCENCEMAP" : "",
		n.iridescenceThicknessMap ? "#define USE_IRIDESCENCE_THICKNESSMAP" : "",
		n.specularMap ? "#define USE_SPECULARMAP" : "",
		n.specularColorMap ? "#define USE_SPECULAR_COLORMAP" : "",
		n.specularIntensityMap ? "#define USE_SPECULAR_INTENSITYMAP" : "",
		n.roughnessMap ? "#define USE_ROUGHNESSMAP" : "",
		n.metalnessMap ? "#define USE_METALNESSMAP" : "",
		n.alphaMap ? "#define USE_ALPHAMAP" : "",
		n.alphaHash ? "#define USE_ALPHAHASH" : "",
		n.transmission ? "#define USE_TRANSMISSION" : "",
		n.transmissionMap ? "#define USE_TRANSMISSIONMAP" : "",
		n.thicknessMap ? "#define USE_THICKNESSMAP" : "",
		n.sheenColorMap ? "#define USE_SHEEN_COLORMAP" : "",
		n.sheenRoughnessMap ? "#define USE_SHEEN_ROUGHNESSMAP" : "",
		n.mapUv ? "#define MAP_UV " + n.mapUv : "",
		n.alphaMapUv ? "#define ALPHAMAP_UV " + n.alphaMapUv : "",
		n.lightMapUv ? "#define LIGHTMAP_UV " + n.lightMapUv : "",
		n.aoMapUv ? "#define AOMAP_UV " + n.aoMapUv : "",
		n.emissiveMapUv ? "#define EMISSIVEMAP_UV " + n.emissiveMapUv : "",
		n.bumpMapUv ? "#define BUMPMAP_UV " + n.bumpMapUv : "",
		n.normalMapUv ? "#define NORMALMAP_UV " + n.normalMapUv : "",
		n.displacementMapUv ? "#define DISPLACEMENTMAP_UV " + n.displacementMapUv : "",
		n.metalnessMapUv ? "#define METALNESSMAP_UV " + n.metalnessMapUv : "",
		n.roughnessMapUv ? "#define ROUGHNESSMAP_UV " + n.roughnessMapUv : "",
		n.anisotropyMapUv ? "#define ANISOTROPYMAP_UV " + n.anisotropyMapUv : "",
		n.clearcoatMapUv ? "#define CLEARCOATMAP_UV " + n.clearcoatMapUv : "",
		n.clearcoatNormalMapUv ? "#define CLEARCOAT_NORMALMAP_UV " + n.clearcoatNormalMapUv : "",
		n.clearcoatRoughnessMapUv ? "#define CLEARCOAT_ROUGHNESSMAP_UV " + n.clearcoatRoughnessMapUv : "",
		n.iridescenceMapUv ? "#define IRIDESCENCEMAP_UV " + n.iridescenceMapUv : "",
		n.iridescenceThicknessMapUv ? "#define IRIDESCENCE_THICKNESSMAP_UV " + n.iridescenceThicknessMapUv : "",
		n.sheenColorMapUv ? "#define SHEEN_COLORMAP_UV " + n.sheenColorMapUv : "",
		n.sheenRoughnessMapUv ? "#define SHEEN_ROUGHNESSMAP_UV " + n.sheenRoughnessMapUv : "",
		n.specularMapUv ? "#define SPECULARMAP_UV " + n.specularMapUv : "",
		n.specularColorMapUv ? "#define SPECULAR_COLORMAP_UV " + n.specularColorMapUv : "",
		n.specularIntensityMapUv ? "#define SPECULAR_INTENSITYMAP_UV " + n.specularIntensityMapUv : "",
		n.transmissionMapUv ? "#define TRANSMISSIONMAP_UV " + n.transmissionMapUv : "",
		n.thicknessMapUv ? "#define THICKNESSMAP_UV " + n.thicknessMapUv : "",
		n.vertexTangents && n.flatShading === !1 ? "#define USE_TANGENT" : "",
		n.vertexNormals ? "#define HAS_NORMAL" : "",
		n.vertexColors ? "#define USE_COLOR" : "",
		n.vertexAlphas ? "#define USE_COLOR_ALPHA" : "",
		n.vertexUv1s ? "#define USE_UV1" : "",
		n.vertexUv2s ? "#define USE_UV2" : "",
		n.vertexUv3s ? "#define USE_UV3" : "",
		n.pointsUvs ? "#define USE_POINTS_UV" : "",
		n.flatShading ? "#define FLAT_SHADED" : "",
		n.skinning ? "#define USE_SKINNING" : "",
		n.morphTargets ? "#define USE_MORPHTARGETS" : "",
		n.morphNormals && n.flatShading === !1 ? "#define USE_MORPHNORMALS" : "",
		n.morphColors ? "#define USE_MORPHCOLORS" : "",
		n.morphTargetsCount > 0 ? "#define MORPHTARGETS_TEXTURE_STRIDE " + n.morphTextureStride : "",
		n.morphTargetsCount > 0 ? "#define MORPHTARGETS_COUNT " + n.morphTargetsCount : "",
		n.doubleSided ? "#define DOUBLE_SIDED" : "",
		n.flipSided ? "#define FLIP_SIDED" : "",
		n.shadowMapEnabled ? "#define USE_SHADOWMAP" : "",
		n.shadowMapEnabled ? "#define " + c : "",
		n.sizeAttenuation ? "#define USE_SIZEATTENUATION" : "",
		n.numLightProbes > 0 ? "#define USE_LIGHT_PROBES" : "",
		n.logarithmicDepthBuffer ? "#define USE_LOGARITHMIC_DEPTH_BUFFER" : "",
		n.reversedDepthBuffer ? "#define USE_REVERSED_DEPTH_BUFFER" : "",
		"uniform mat4 modelMatrix;",
		"uniform mat4 modelViewMatrix;",
		"uniform mat4 projectionMatrix;",
		"uniform mat4 viewMatrix;",
		"uniform mat3 normalMatrix;",
		"uniform vec3 cameraPosition;",
		"uniform bool isOrthographic;",
		"#ifdef USE_INSTANCING",
		"	attribute mat4 instanceMatrix;",
		"#endif",
		"#ifdef USE_INSTANCING_COLOR",
		"	attribute vec3 instanceColor;",
		"#endif",
		"#ifdef USE_INSTANCING_MORPH",
		"	uniform sampler2D morphTexture;",
		"#endif",
		"attribute vec3 position;",
		"attribute vec3 normal;",
		"attribute vec2 uv;",
		"#ifdef USE_UV1",
		"	attribute vec2 uv1;",
		"#endif",
		"#ifdef USE_UV2",
		"	attribute vec2 uv2;",
		"#endif",
		"#ifdef USE_UV3",
		"	attribute vec2 uv3;",
		"#endif",
		"#ifdef USE_TANGENT",
		"	attribute vec4 tangent;",
		"#endif",
		"#if defined( USE_COLOR_ALPHA )",
		"	attribute vec4 color;",
		"#elif defined( USE_COLOR )",
		"	attribute vec3 color;",
		"#endif",
		"#ifdef USE_SKINNING",
		"	attribute vec4 skinIndex;",
		"	attribute vec4 skinWeight;",
		"#endif",
		"\n"
	].filter(Ci).join("\n"), _ = [
		Ni(n),
		"#define SHADER_TYPE " + n.shaderType,
		"#define SHADER_NAME " + n.shaderName,
		m,
		n.useFog && n.fog ? "#define USE_FOG" : "",
		n.useFog && n.fogExp2 ? "#define FOG_EXP2" : "",
		n.alphaToCoverage ? "#define ALPHA_TO_COVERAGE" : "",
		n.map ? "#define USE_MAP" : "",
		n.matcap ? "#define USE_MATCAP" : "",
		n.envMap ? "#define USE_ENVMAP" : "",
		n.envMap ? "#define " + l : "",
		n.envMap ? "#define " + u : "",
		n.envMap ? "#define " + d : "",
		f ? "#define CUBEUV_TEXEL_WIDTH " + f.texelWidth : "",
		f ? "#define CUBEUV_TEXEL_HEIGHT " + f.texelHeight : "",
		f ? "#define CUBEUV_MAX_MIP " + f.maxMip + ".0" : "",
		n.lightMap ? "#define USE_LIGHTMAP" : "",
		n.aoMap ? "#define USE_AOMAP" : "",
		n.bumpMap ? "#define USE_BUMPMAP" : "",
		n.normalMap ? "#define USE_NORMALMAP" : "",
		n.normalMapObjectSpace ? "#define USE_NORMALMAP_OBJECTSPACE" : "",
		n.normalMapTangentSpace ? "#define USE_NORMALMAP_TANGENTSPACE" : "",
		n.packedNormalMap ? "#define USE_PACKED_NORMALMAP" : "",
		n.emissiveMap ? "#define USE_EMISSIVEMAP" : "",
		n.anisotropy ? "#define USE_ANISOTROPY" : "",
		n.anisotropyMap ? "#define USE_ANISOTROPYMAP" : "",
		n.clearcoat ? "#define USE_CLEARCOAT" : "",
		n.clearcoatMap ? "#define USE_CLEARCOATMAP" : "",
		n.clearcoatRoughnessMap ? "#define USE_CLEARCOAT_ROUGHNESSMAP" : "",
		n.clearcoatNormalMap ? "#define USE_CLEARCOAT_NORMALMAP" : "",
		n.dispersion ? "#define USE_DISPERSION" : "",
		n.retroreflection ? "#define USE_RETROREFLECTION" : "",
		n.iridescence ? "#define USE_IRIDESCENCE" : "",
		n.iridescenceMap ? "#define USE_IRIDESCENCEMAP" : "",
		n.iridescenceThicknessMap ? "#define USE_IRIDESCENCE_THICKNESSMAP" : "",
		n.specularMap ? "#define USE_SPECULARMAP" : "",
		n.specularColorMap ? "#define USE_SPECULAR_COLORMAP" : "",
		n.specularIntensityMap ? "#define USE_SPECULAR_INTENSITYMAP" : "",
		n.roughnessMap ? "#define USE_ROUGHNESSMAP" : "",
		n.metalnessMap ? "#define USE_METALNESSMAP" : "",
		n.alphaMap ? "#define USE_ALPHAMAP" : "",
		n.alphaTest ? "#define USE_ALPHATEST" : "",
		n.alphaHash ? "#define USE_ALPHAHASH" : "",
		n.sheen ? "#define USE_SHEEN" : "",
		n.sheenColorMap ? "#define USE_SHEEN_COLORMAP" : "",
		n.sheenRoughnessMap ? "#define USE_SHEEN_ROUGHNESSMAP" : "",
		n.transmission ? "#define USE_TRANSMISSION" : "",
		n.transmissionMap ? "#define USE_TRANSMISSIONMAP" : "",
		n.thicknessMap ? "#define USE_THICKNESSMAP" : "",
		n.vertexTangents && n.flatShading === !1 ? "#define USE_TANGENT" : "",
		n.vertexColors || n.instancingColor ? "#define USE_COLOR" : "",
		n.vertexAlphas || n.batchingColor ? "#define USE_COLOR_ALPHA" : "",
		n.vertexUv1s ? "#define USE_UV1" : "",
		n.vertexUv2s ? "#define USE_UV2" : "",
		n.vertexUv3s ? "#define USE_UV3" : "",
		n.pointsUvs ? "#define USE_POINTS_UV" : "",
		n.gradientMap ? "#define USE_GRADIENTMAP" : "",
		n.flatShading ? "#define FLAT_SHADED" : "",
		n.doubleSided ? "#define DOUBLE_SIDED" : "",
		n.flipSided ? "#define FLIP_SIDED" : "",
		n.shadowMapEnabled ? "#define USE_SHADOWMAP" : "",
		n.shadowMapEnabled ? "#define " + c : "",
		n.premultipliedAlpha ? "#define PREMULTIPLIED_ALPHA" : "",
		n.numLightProbes > 0 ? "#define USE_LIGHT_PROBES" : "",
		n.numLightProbeGrids > 0 ? "#define USE_LIGHT_PROBES_GRID" : "",
		n.decodeVideoTexture ? "#define DECODE_VIDEO_TEXTURE" : "",
		n.decodeVideoTextureEmissive ? "#define DECODE_VIDEO_TEXTURE_EMISSIVE" : "",
		n.logarithmicDepthBuffer ? "#define USE_LOGARITHMIC_DEPTH_BUFFER" : "",
		n.reversedDepthBuffer ? "#define USE_REVERSED_DEPTH_BUFFER" : "",
		"uniform mat4 viewMatrix;",
		"uniform vec3 cameraPosition;",
		"uniform bool isOrthographic;",
		n.toneMapping === 0 ? "" : "#define TONE_MAPPING",
		n.toneMapping === 0 ? "" : G.tonemapping_pars_fragment,
		n.toneMapping === 0 ? "" : _i("toneMapping", n.toneMapping),
		n.dithering ? "#define DITHERING" : "",
		n.opaque ? "#define OPAQUE" : "",
		G.colorspace_pars_fragment,
		hi("linearToOutputTexel", n.outputColorSpace),
		yi(),
		n.useDepthPacking ? "#define DEPTH_PACKING " + n.depthPacking : "",
		"\n"
	].filter(Ci).join("\n")), o = Di(o), o = wi(o, n), o = Ti(o, n), s = Di(s), s = wi(s, n), s = Ti(s, n), o = ji(o), s = ji(s), n.isRawShaderMaterial !== !0 && (v = "#version 300 es\n", g = [
		p,
		"#define attribute in",
		"#define varying out",
		"#define texture2D texture"
	].join("\n") + "\n" + g, _ = [
		"#define varying in",
		n.glslVersion === "300 es" ? "" : "layout(location = 0) out highp vec4 pc_fragColor;",
		n.glslVersion === "300 es" ? "" : "#define gl_FragColor pc_fragColor",
		"#define gl_FragDepthEXT gl_FragDepth",
		"#define texture2D texture",
		"#define textureCube texture",
		"#define texture2DProj textureProj",
		"#define texture2DLodEXT textureLod",
		"#define texture2DProjLodEXT textureProjLod",
		"#define textureCubeLodEXT textureLod",
		"#define texture2DGradEXT textureGrad",
		"#define texture2DProjGradEXT textureProjGrad",
		"#define textureCubeGradEXT textureGrad"
	].join("\n") + "\n" + _);
	let y = v + g + o, x = v + _ + s, S = ci(i, i.VERTEX_SHADER, y), C = ci(i, i.FRAGMENT_SHADER, x);
	i.attachShader(h, S), i.attachShader(h, C), n.index0AttributeName === void 0 ? n.hasPositionAttribute === !0 && i.bindAttribLocation(h, 0, "position") : i.bindAttribLocation(h, 0, n.index0AttributeName), i.linkProgram(h);
	function w(t) {
		if (e.debug.checkShaderErrors) {
			let n = i.getProgramInfoLog(h) || "", r = i.getShaderInfoLog(S) || "", a = i.getShaderInfoLog(C) || "", o = n.trim(), s = r.trim(), c = a.trim(), l = !0, u = !0;
			if (i.getProgramParameter(h, i.LINK_STATUS) === !1) {
				if (l = !1, typeof e.debug.onShaderError == "function") e.debug.onShaderError(i, h, S, C);
				else {
					let e = mi(i, S, "vertex"), n = mi(i, C, "fragment");
					mt("WebGLProgram: Shader Error " + i.getError() + " - VALIDATE_STATUS " + i.getProgramParameter(h, i.VALIDATE_STATUS) + "\n\nMaterial Name: " + t.name + "\nMaterial Type: " + t.type + "\n\nProgram Info Log: " + o + "\n" + e + "\n" + n);
				}
			} else o === "" ? (s === "" || c === "") && (u = !1) : b("WebGLProgram: Program Info Log:", o);
			u && (t.diagnostics = {
				runnable: l,
				programLog: o,
				vertexShader: {
					log: s,
					prefix: g
				},
				fragmentShader: {
					log: c,
					prefix: _
				}
			});
		}
		i.deleteShader(S), i.deleteShader(C), T = new si(i, h), E = Si(i, h);
	}
	let T;
	this.getUniforms = function() {
		return T === void 0 && w(this), T;
	};
	let E;
	this.getAttributes = function() {
		return E === void 0 && w(this), E;
	};
	let D = n.rendererExtensionParallelShaderCompile === !1;
	return this.isReady = function() {
		return D === !1 && (D = i.getProgramParameter(h, li)), D;
	}, this.destroy = function() {
		r.releaseStatesOfProgram(this), i.deleteProgram(h), this.program = void 0;
	}, this.type = n.shaderType, this.name = n.shaderName, this.id = ui++, this.cacheKey = t, this.usedTimes = 1, this.program = h, this.vertexShader = S, this.fragmentShader = C, this;
}
var Wi = 0, Gi = class {
	constructor() {
		this.shaderCache = /* @__PURE__ */ new Map(), this.materialCache = /* @__PURE__ */ new Map();
	}
	update(e, t, n) {
		let r = this._getShaderCacheForMaterial(e);
		return r.has(t) === !1 && (r.add(t), t.usedTimes++), r.has(n) === !1 && (r.add(n), n.usedTimes++), this;
	}
	remove(e) {
		let t = this.materialCache.get(e);
		for (let e of t) e.usedTimes--, e.usedTimes === 0 && this.shaderCache.delete(e.code);
		return this.materialCache.delete(e), this;
	}
	getVertexShaderStage(e) {
		return this._getShaderStage(e.vertexShader);
	}
	getFragmentShaderStage(e) {
		return this._getShaderStage(e.fragmentShader);
	}
	dispose() {
		this.shaderCache.clear(), this.materialCache.clear();
	}
	_getShaderCacheForMaterial(e) {
		let t = this.materialCache, n = t.get(e);
		return n === void 0 && (n = /* @__PURE__ */ new Set(), t.set(e, n)), n;
	}
	_getShaderStage(e) {
		let t = this.shaderCache, n = t.get(e);
		return n === void 0 && (n = new Ki(e), t.set(e, n)), n;
	}
}, Ki = class {
	constructor(e) {
		this.id = Wi++, this.code = e, this.usedTimes = 0;
	}
};
function qi(e) {
	return e === 1030 || e === 37490 || e === 36285;
}
function Ji(e, t, n, r, i, a) {
	let o = new c(), s = new Gi(), l = /* @__PURE__ */ new Set(), u = [], d = /* @__PURE__ */ new Map(), f = r.logarithmicDepthBuffer, p = r.precision, m = {
		MeshDepthMaterial: "depth",
		MeshDistanceMaterial: "distance",
		MeshNormalMaterial: "normal",
		MeshBasicMaterial: "basic",
		MeshLambertMaterial: "lambert",
		MeshPhongMaterial: "phong",
		MeshToonMaterial: "toon",
		MeshStandardMaterial: "physical",
		MeshPhysicalMaterial: "physical",
		MeshMatcapMaterial: "matcap",
		LineBasicMaterial: "basic",
		LineDashedMaterial: "dashed",
		PointsMaterial: "points",
		ShadowMaterial: "shadow",
		SpriteMaterial: "sprite"
	};
	function h(e) {
		return l.add(e), e === 0 ? "uv" : `uv${e}`;
	}
	function g(i, o, c, u, d, g) {
		let _ = u.fog, v = d.geometry, y = i.isMeshStandardMaterial || i.isMeshLambertMaterial || i.isMeshPhongMaterial ? u.environment : null, x = i.isMeshStandardMaterial || i.isMeshLambertMaterial && !i.envMap || i.isMeshPhongMaterial && !i.envMap, S = t.get(i.envMap || y, x), C = S && S.mapping === 306 ? S.image.height : null, w = m[i.type];
		i.precision !== null && (p = r.getMaxPrecision(i.precision), p !== i.precision && b("WebGLProgram.getParameters:", i.precision, "not supported, using", p, "instead."));
		let T = v.morphAttributes.position || v.morphAttributes.normal || v.morphAttributes.color, E = T === void 0 ? 0 : T.length, D = 0;
		v.morphAttributes.position !== void 0 && (D = 1), v.morphAttributes.normal !== void 0 && (D = 2), v.morphAttributes.color !== void 0 && (D = 3);
		let O, ee, k, A;
		if (w) {
			let e = hn[w];
			O = e.vertexShader, ee = e.fragmentShader;
		} else {
			O = i.vertexShader, ee = i.fragmentShader;
			let e = s.getVertexShaderStage(i), t = s.getFragmentShaderStage(i);
			s.update(i, e, t), k = e.id, A = t.id;
		}
		let te = e.getRenderTarget(), ne = e.state.buffers.depth.getReversed(), re = d.isInstancedMesh === !0, ie = d.isBatchedMesh === !0, ae = !!i.map, oe = !!i.matcap, se = !!S, ce = !!i.aoMap, le = !!i.lightMap, ue = !!i.bumpMap && i.wireframe === !1, j = !!i.normalMap, M = !!i.displacementMap, de = !!i.emissiveMap, fe = !!i.metalnessMap, pe = !!i.roughnessMap, me = i.anisotropy > 0, he = i.clearcoat > 0, ge = i.dispersion > 0, _e = i.retroreflectivity > 0, ve = i.iridescence > 0, ye = i.sheen > 0, be = i.transmission > 0, xe = me && !!i.anisotropyMap, Se = he && !!i.clearcoatMap, N = he && !!i.clearcoatNormalMap, Ce = he && !!i.clearcoatRoughnessMap, we = ve && !!i.iridescenceMap, Te = ve && !!i.iridescenceThicknessMap, Ee = ye && !!i.sheenColorMap, De = ye && !!i.sheenRoughnessMap, Oe = !!i.specularMap, ke = !!i.specularColorMap, Ae = !!i.specularIntensityMap, je = be && !!i.transmissionMap, P = be && !!i.thicknessMap, Me = !!i.gradientMap, Ne = !!i.alphaMap, F = i.alphaTest > 0, I = !!i.alphaHash, L = !!i.extensions, Pe = 0;
		i.toneMapped && (te === null || te.isXRRenderTarget === !0) && (Pe = e.toneMapping);
		let R = {
			shaderID: w,
			shaderType: i.type,
			shaderName: i.name,
			vertexShader: O,
			fragmentShader: ee,
			defines: i.defines,
			customVertexShaderID: k,
			customFragmentShaderID: A,
			isRawShaderMaterial: i.isRawShaderMaterial === !0,
			glslVersion: i.glslVersion,
			precision: p,
			batching: ie,
			batchingColor: ie && d._colorsTexture !== null,
			instancing: re,
			instancingColor: re && d.instanceColor !== null,
			instancingMorph: re && d.morphTexture !== null,
			outputColorSpace: te === null ? e.outputColorSpace : te.isXRRenderTarget === !0 ? te.texture.colorSpace : Ze.workingColorSpace,
			alphaToCoverage: !!i.alphaToCoverage,
			map: ae,
			matcap: oe,
			envMap: se,
			envMapMode: se && S.mapping,
			envMapCubeUVHeight: C,
			aoMap: ce,
			lightMap: le,
			bumpMap: ue,
			normalMap: j,
			displacementMap: M,
			emissiveMap: de,
			normalMapObjectSpace: j && i.normalMapType === 1,
			normalMapTangentSpace: j && i.normalMapType === 0,
			packedNormalMap: j && i.normalMapType === 0 && qi(i.normalMap.format),
			metalnessMap: fe,
			roughnessMap: pe,
			anisotropy: me,
			anisotropyMap: xe,
			clearcoat: he,
			clearcoatMap: Se,
			clearcoatNormalMap: N,
			clearcoatRoughnessMap: Ce,
			dispersion: ge,
			retroreflection: _e,
			iridescence: ve,
			iridescenceMap: we,
			iridescenceThicknessMap: Te,
			sheen: ye,
			sheenColorMap: Ee,
			sheenRoughnessMap: De,
			specularMap: Oe,
			specularColorMap: ke,
			specularIntensityMap: Ae,
			transmission: be,
			transmissionMap: je,
			thicknessMap: P,
			gradientMap: Me,
			opaque: i.transparent === !1 && i.blending === 1 && i.alphaToCoverage === !1,
			alphaMap: Ne,
			alphaTest: F,
			alphaHash: I,
			combine: i.combine,
			mapUv: ae && h(i.map.channel),
			aoMapUv: ce && h(i.aoMap.channel),
			lightMapUv: le && h(i.lightMap.channel),
			bumpMapUv: ue && h(i.bumpMap.channel),
			normalMapUv: j && h(i.normalMap.channel),
			displacementMapUv: M && h(i.displacementMap.channel),
			emissiveMapUv: de && h(i.emissiveMap.channel),
			metalnessMapUv: fe && h(i.metalnessMap.channel),
			roughnessMapUv: pe && h(i.roughnessMap.channel),
			anisotropyMapUv: xe && h(i.anisotropyMap.channel),
			clearcoatMapUv: Se && h(i.clearcoatMap.channel),
			clearcoatNormalMapUv: N && h(i.clearcoatNormalMap.channel),
			clearcoatRoughnessMapUv: Ce && h(i.clearcoatRoughnessMap.channel),
			iridescenceMapUv: we && h(i.iridescenceMap.channel),
			iridescenceThicknessMapUv: Te && h(i.iridescenceThicknessMap.channel),
			sheenColorMapUv: Ee && h(i.sheenColorMap.channel),
			sheenRoughnessMapUv: De && h(i.sheenRoughnessMap.channel),
			specularMapUv: Oe && h(i.specularMap.channel),
			specularColorMapUv: ke && h(i.specularColorMap.channel),
			specularIntensityMapUv: Ae && h(i.specularIntensityMap.channel),
			transmissionMapUv: je && h(i.transmissionMap.channel),
			thicknessMapUv: P && h(i.thicknessMap.channel),
			alphaMapUv: Ne && h(i.alphaMap.channel),
			vertexTangents: !!v.attributes.tangent && (j || me),
			vertexNormals: !!v.attributes.normal,
			vertexColors: i.vertexColors,
			vertexAlphas: i.vertexColors === !0 && !!v.attributes.color && v.attributes.color.itemSize === 4,
			pointsUvs: d.isPoints === !0 && !!v.attributes.uv && (ae || Ne),
			fog: !!_,
			useFog: i.fog === !0,
			fogExp2: !!_ && _.isFogExp2,
			flatShading: i.wireframe === !1 && (i.flatShading === !0 || v.attributes.normal === void 0 && j === !1 && (i.isMeshLambertMaterial || i.isMeshPhongMaterial || i.isMeshStandardMaterial || i.isMeshPhysicalMaterial)),
			sizeAttenuation: i.sizeAttenuation === !0,
			logarithmicDepthBuffer: f,
			reversedDepthBuffer: ne,
			skinning: d.isSkinnedMesh === !0,
			hasPositionAttribute: v.attributes.position !== void 0,
			morphTargets: v.morphAttributes.position !== void 0,
			morphNormals: v.morphAttributes.normal !== void 0,
			morphColors: v.morphAttributes.color !== void 0,
			morphTargetsCount: E,
			morphTextureStride: D,
			numSunLights: o.sun.length,
			numDirLights: o.directional.length,
			numPointLights: o.point.length,
			numSpotLights: o.spot.length,
			numSpotLightMaps: o.spotLightMap.length,
			numRectAreaLights: o.rectArea.length,
			numHemiLights: o.hemi.length,
			numSunLightShadows: o.sunShadowMap.length,
			numDirLightShadows: o.directionalShadowMap.length,
			numPointLightShadows: o.pointShadowMap.length,
			numSpotLightShadows: o.spotShadowMap.length,
			numSpotLightShadowsWithMaps: o.numSpotLightShadowsWithMaps,
			numLightProbes: o.numLightProbes,
			numLightProbeGrids: g.length,
			numClippingPlanes: a.numPlanes,
			numClipIntersection: a.numIntersection,
			dithering: i.dithering,
			shadowMapEnabled: e.shadowMap.enabled && c.length > 0,
			shadowMapType: e.shadowMap.type,
			toneMapping: Pe,
			decodeVideoTexture: ae && i.map.isVideoTexture === !0 && Ze.getTransfer(i.map.colorSpace) === "srgb",
			decodeVideoTextureEmissive: de && i.emissiveMap.isVideoTexture === !0 && Ze.getTransfer(i.emissiveMap.colorSpace) === "srgb",
			premultipliedAlpha: i.premultipliedAlpha,
			doubleSided: i.side === 2,
			flipSided: i.side === 1,
			useDepthPacking: i.depthPacking >= 0,
			depthPacking: i.depthPacking || 0,
			index0AttributeName: i.index0AttributeName,
			extensionClipCullDistance: L && i.extensions.clipCullDistance === !0 && n.has("WEBGL_clip_cull_distance"),
			extensionMultiDraw: (L && i.extensions.multiDraw === !0 || ie) && n.has("WEBGL_multi_draw"),
			rendererExtensionParallelShaderCompile: n.has("KHR_parallel_shader_compile"),
			customProgramCacheKey: i.customProgramCacheKey()
		};
		return R.vertexUv1s = l.has(1), R.vertexUv2s = l.has(2), R.vertexUv3s = l.has(3), l.clear(), R;
	}
	function _(t) {
		let n = [];
		if (t.shaderID ? n.push(t.shaderID) : (n.push(t.customVertexShaderID), n.push(t.customFragmentShaderID)), t.defines !== void 0) for (let e in t.defines) n.push(e), n.push(t.defines[e]);
		return t.isRawShaderMaterial === !1 && (v(n, t), y(n, t), n.push(e.outputColorSpace)), n.push(t.customProgramCacheKey), n.join();
	}
	function v(e, t) {
		e.push(t.precision), e.push(t.outputColorSpace), e.push(t.envMapMode), e.push(t.envMapCubeUVHeight), e.push(t.mapUv), e.push(t.alphaMapUv), e.push(t.lightMapUv), e.push(t.aoMapUv), e.push(t.bumpMapUv), e.push(t.normalMapUv), e.push(t.displacementMapUv), e.push(t.emissiveMapUv), e.push(t.metalnessMapUv), e.push(t.roughnessMapUv), e.push(t.anisotropyMapUv), e.push(t.clearcoatMapUv), e.push(t.clearcoatNormalMapUv), e.push(t.clearcoatRoughnessMapUv), e.push(t.iridescenceMapUv), e.push(t.iridescenceThicknessMapUv), e.push(t.sheenColorMapUv), e.push(t.sheenRoughnessMapUv), e.push(t.specularMapUv), e.push(t.specularColorMapUv), e.push(t.specularIntensityMapUv), e.push(t.transmissionMapUv), e.push(t.thicknessMapUv), e.push(t.combine), e.push(t.fogExp2), e.push(t.sizeAttenuation), e.push(t.morphTargetsCount), e.push(t.morphAttributeCount), e.push(t.numSunLights), e.push(t.numDirLights), e.push(t.numPointLights), e.push(t.numSpotLights), e.push(t.numSpotLightMaps), e.push(t.numHemiLights), e.push(t.numRectAreaLights), e.push(t.numSunLightShadows), e.push(t.numDirLightShadows), e.push(t.numPointLightShadows), e.push(t.numSpotLightShadows), e.push(t.numSpotLightShadowsWithMaps), e.push(t.numLightProbes), e.push(t.shadowMapType), e.push(t.toneMapping), e.push(t.numClippingPlanes), e.push(t.numClipIntersection), e.push(t.depthPacking);
	}
	function y(e, t) {
		o.disableAll(), t.instancing && o.enable(0), t.instancingColor && o.enable(1), t.instancingMorph && o.enable(2), t.matcap && o.enable(3), t.envMap && o.enable(4), t.normalMapObjectSpace && o.enable(5), t.normalMapTangentSpace && o.enable(6), t.clearcoat && o.enable(7), t.iridescence && o.enable(8), t.alphaTest && o.enable(9), t.vertexColors && o.enable(10), t.vertexAlphas && o.enable(11), t.vertexUv1s && o.enable(12), t.vertexUv2s && o.enable(13), t.vertexUv3s && o.enable(14), t.vertexTangents && o.enable(15), t.anisotropy && o.enable(16), t.alphaHash && o.enable(17), t.batching && o.enable(18), t.dispersion && o.enable(19), t.retroreflection && o.enable(24), t.batchingColor && o.enable(20), t.gradientMap && o.enable(21), t.packedNormalMap && o.enable(22), t.vertexNormals && o.enable(23), e.push(o.mask), o.disableAll(), t.fog && o.enable(0), t.useFog && o.enable(1), t.flatShading && o.enable(2), t.logarithmicDepthBuffer && o.enable(3), t.reversedDepthBuffer && o.enable(4), t.skinning && o.enable(5), t.morphTargets && o.enable(6), t.morphNormals && o.enable(7), t.morphColors && o.enable(8), t.premultipliedAlpha && o.enable(9), t.shadowMapEnabled && o.enable(10), t.doubleSided && o.enable(11), t.flipSided && o.enable(12), t.useDepthPacking && o.enable(13), t.dithering && o.enable(14), t.transmission && o.enable(15), t.sheen && o.enable(16), t.opaque && o.enable(17), t.pointsUvs && o.enable(18), t.decodeVideoTexture && o.enable(19), t.decodeVideoTextureEmissive && o.enable(20), t.alphaToCoverage && o.enable(21), t.numLightProbeGrids > 0 && o.enable(22), t.hasPositionAttribute && o.enable(23), e.push(o.mask);
	}
	function x(e) {
		let t = m[e.type], n;
		if (t) {
			let e = hn[t];
			n = Je.clone(e.uniforms);
		} else n = e.uniforms;
		return n;
	}
	function S(t, n) {
		let r = d.get(n);
		return r === void 0 ? (r = new Ui(e, n, t, i), u.push(r), d.set(n, r)) : ++r.usedTimes, r;
	}
	function C(e) {
		if (--e.usedTimes === 0) {
			let t = u.indexOf(e);
			u[t] = u[u.length - 1], u.pop(), d.delete(e.cacheKey), e.destroy();
		}
	}
	function w(e) {
		s.remove(e);
	}
	function T() {
		s.dispose();
	}
	return {
		getParameters: g,
		getProgramCacheKey: _,
		getUniforms: x,
		acquireProgram: S,
		releaseProgram: C,
		releaseShaderCache: w,
		programs: u,
		dispose: T
	};
}
function Yi() {
	let e = /* @__PURE__ */ new WeakMap();
	function t(t) {
		return e.has(t);
	}
	function n(t) {
		let n = e.get(t);
		return n === void 0 && (n = {}, e.set(t, n)), n;
	}
	function r(t) {
		e.delete(t);
	}
	function i(t, n, r) {
		e.get(t)[n] = r;
	}
	function a() {
		e = /* @__PURE__ */ new WeakMap();
	}
	return {
		has: t,
		get: n,
		remove: r,
		update: i,
		dispose: a
	};
}
function Xi(e, t) {
	return e.groupOrder === t.groupOrder ? e.renderOrder === t.renderOrder ? e.material.id === t.material.id ? e.materialVariant === t.materialVariant ? e.z === t.z ? e.id - t.id : e.z - t.z : e.materialVariant - t.materialVariant : e.material.id - t.material.id : e.renderOrder - t.renderOrder : e.groupOrder - t.groupOrder;
}
function Zi(e, t) {
	return e.groupOrder === t.groupOrder ? e.renderOrder === t.renderOrder ? e.z === t.z ? e.id - t.id : t.z - e.z : e.renderOrder - t.renderOrder : e.groupOrder - t.groupOrder;
}
function Qi() {
	let e = [], t = 0, n = [], r = [], i = [];
	function a() {
		t = 0, n.length = 0, r.length = 0, i.length = 0;
	}
	function o(e) {
		let t = 0;
		return e.isInstancedMesh && (t += 2), e.isSkinnedMesh && (t += 1), t;
	}
	function s(n, r, i, a, s, c) {
		let l = e[t];
		return l === void 0 ? (l = {
			id: n.id,
			object: n,
			geometry: r,
			material: i,
			materialVariant: o(n),
			groupOrder: a,
			renderOrder: n.renderOrder,
			z: s,
			group: c
		}, e[t] = l) : (l.id = n.id, l.object = n, l.geometry = r, l.material = i, l.materialVariant = o(n), l.groupOrder = a, l.renderOrder = n.renderOrder, l.z = s, l.group = c), t++, l;
	}
	function c(e, t, a, o, c, l, u) {
		u.reversedDepth === !0 && (c = -c);
		let d = s(e, t, a, o, c, l);
		a.transmission > 0 ? r.push(d) : a.transparent === !0 ? i.push(d) : n.push(d);
	}
	function l(e, t, a, o, c, l) {
		let u = s(e, t, a, o, c, l);
		a.transmission > 0 ? r.unshift(u) : a.transparent === !0 ? i.unshift(u) : n.unshift(u);
	}
	function u(e, t) {
		n.length > 1 && n.sort(e || Xi), r.length > 1 && r.sort(t || Zi), i.length > 1 && i.sort(t || Zi);
	}
	function d() {
		for (let n = t, r = e.length; n < r; n++) {
			let t = e[n];
			if (t.id === null) break;
			t.id = null, t.object = null, t.geometry = null, t.material = null, t.group = null;
		}
	}
	return {
		opaque: n,
		transmissive: r,
		transparent: i,
		init: a,
		push: c,
		unshift: l,
		finish: d,
		sort: u
	};
}
function $i() {
	let e = /* @__PURE__ */ new WeakMap();
	function t(t, n) {
		let r = e.get(t), i;
		return r === void 0 ? (i = new Qi(), e.set(t, [i])) : n >= r.length ? (i = new Qi(), r.push(i)) : i = r[n], i;
	}
	function n() {
		e = /* @__PURE__ */ new WeakMap();
	}
	return {
		get: t,
		dispose: n
	};
}
function ea() {
	let e = {};
	return { get: function(t) {
		if (e[t.id] !== void 0) return e[t.id];
		let n;
		switch (t.type) {
			case "SunLight":
			case "DirectionalLight":
				n = {
					direction: new L(),
					color: new I()
				};
				break;
			case "SpotLight":
				n = {
					position: new L(),
					direction: new L(),
					color: new I(),
					distance: 0,
					coneCos: 0,
					penumbraCos: 0,
					decay: 0
				};
				break;
			case "PointLight":
				n = {
					position: new L(),
					color: new I(),
					distance: 0,
					decay: 0
				};
				break;
			case "HemisphereLight":
				n = {
					direction: new L(),
					skyColor: new I(),
					groundColor: new I()
				};
				break;
			case "RectAreaLight": n = {
				color: new I(),
				position: new L(),
				halfWidth: new L(),
				halfHeight: new L()
			};
		}
		return e[t.id] = n, n;
	} };
}
function ta() {
	let e = {};
	return { get: function(t) {
		if (e[t.id] !== void 0) return e[t.id];
		let n;
		switch (t.type) {
			case "SunLight":
			case "DirectionalLight":
				n = {
					shadowIntensity: 1,
					shadowBias: 0,
					shadowNormalBias: 0,
					shadowRadius: 1,
					shadowMapSize: new P()
				};
				break;
			case "SpotLight":
				n = {
					shadowIntensity: 1,
					shadowBias: 0,
					shadowNormalBias: 0,
					shadowRadius: 1,
					shadowMapSize: new P()
				};
				break;
			case "PointLight": n = {
				shadowIntensity: 1,
				shadowBias: 0,
				shadowNormalBias: 0,
				shadowRadius: 1,
				shadowMapSize: new P(),
				shadowCameraNear: 1,
				shadowCameraFar: 1e3
			};
		}
		return e[t.id] = n, n;
	} };
}
var na = 0;
function ra(e, t) {
	return (t.castShadow ? 2 : 0) - (e.castShadow ? 2 : 0) + +!!t.map - !!e.map;
}
function ia(e) {
	let t = new ea(), n = ta(), r = {
		version: 0,
		hash: {
			sunLength: -1,
			directionalLength: -1,
			pointLength: -1,
			spotLength: -1,
			rectAreaLength: -1,
			hemiLength: -1,
			numSunShadows: -1,
			numDirectionalShadows: -1,
			numPointShadows: -1,
			numSpotShadows: -1,
			numSpotMaps: -1,
			numLightProbes: -1
		},
		ambient: [
			0,
			0,
			0
		],
		probe: [],
		sun: [],
		sunShadow: [],
		sunShadowMap: [],
		sunShadowMatrix: [],
		sunShadowCascade: [],
		directional: [],
		directionalShadow: [],
		directionalShadowMap: [],
		directionalShadowMatrix: [],
		spot: [],
		spotLightMap: [],
		spotShadow: [],
		spotShadowMap: [],
		spotLightMatrix: [],
		rectArea: [],
		rectAreaLTC1: null,
		rectAreaLTC2: null,
		point: [],
		pointShadow: [],
		pointShadowMap: [],
		pointShadowMatrix: [],
		hemi: [],
		numSpotLightShadowsWithMaps: 0,
		numLightProbes: 0
	};
	for (let e = 0; e < 9; e++) r.probe.push(new L());
	let i = new L(), a = new Ie(), o = new Ie();
	function s(i) {
		let a = 0, o = 0, s = 0;
		for (let e = 0; e < 9; e++) r.probe[e].set(0, 0, 0);
		let c = 0, l = 0, u = 0, d = 0, f = 0, p = 0, m = 0, h = 0, g = 0, _ = 0, v = 0, y = 0, b = 0, x = 0;
		i.sort(ra);
		for (let e = 0, S = i.length; e < S; e++) {
			let S = i[e], C = S.color, w = S.intensity, T = S.distance, E = null;
			if (S.shadow && S.shadow.map && (E = S.shadow.map.texture.format === 1030 ? S.shadow.map.texture : S.shadow.map.depthTexture || S.shadow.map.texture), S.isAmbientLight) a += C.r * w, o += C.g * w, s += C.b * w;
			else if (S.isLightProbe) {
				for (let e = 0; e < 9; e++) r.probe[e].addScaledVector(S.sh.coefficients[e], w);
				x++;
			} else if (S.isSunLight) {
				let e = t.get(S);
				if (e.color.copy(S.color).multiplyScalar(S.intensity), S.castShadow) {
					let e = S.shadow, t = n.get(S);
					t.shadowIntensity = e.intensity, t.shadowBias = e.bias, t.shadowNormalBias = e.normalBias, t.shadowRadius = e.radius, t.shadowMapSize.copy(e.mapSize).multiply(e.getFrameExtents()), r.sunShadow[l] = t, r.sunShadowMap[l] = E;
					let i = e.getViewportCount();
					for (let t = 0; t < i; t++) r.sunShadowMatrix[u + t] = e.getMatrix(t), r.sunShadowCascade[u + t] = e._cascadeData[t];
					u += i, l++;
				}
				r.sun[c] = e, c++;
			} else if (S.isDirectionalLight) {
				let e = t.get(S);
				if (e.color.copy(S.color).multiplyScalar(S.intensity), S.castShadow) {
					let e = S.shadow, t = n.get(S);
					t.shadowIntensity = e.intensity, t.shadowBias = e.bias, t.shadowNormalBias = e.normalBias, t.shadowRadius = e.radius, t.shadowMapSize = e.mapSize, r.directionalShadow[d] = t, r.directionalShadowMap[d] = E, r.directionalShadowMatrix[d] = S.shadow.matrix, g++;
				}
				r.directional[d] = e, d++;
			} else if (S.isSpotLight) {
				let e = t.get(S);
				e.position.setFromMatrixPosition(S.matrixWorld), e.color.copy(C).multiplyScalar(w), e.distance = T, e.coneCos = Math.cos(S.angle), e.penumbraCos = Math.cos(S.angle * (1 - S.penumbra)), e.decay = S.decay, r.spot[p] = e;
				let i = S.shadow;
				if (S.map && (r.spotLightMap[y] = S.map, y++, i.updateMatrices(S), S.castShadow && b++), r.spotLightMatrix[p] = i.matrix, S.castShadow) {
					let e = n.get(S);
					e.shadowIntensity = i.intensity, e.shadowBias = i.bias, e.shadowNormalBias = i.normalBias, e.shadowRadius = i.radius, e.shadowMapSize = i.mapSize, r.spotShadow[p] = e, r.spotShadowMap[p] = E, v++;
				}
				p++;
			} else if (S.isRectAreaLight) {
				let e = t.get(S);
				e.color.copy(C).multiplyScalar(w), e.halfWidth.set(S.width * .5, 0, 0), e.halfHeight.set(0, S.height * .5, 0), r.rectArea[m] = e, m++;
			} else if (S.isPointLight) {
				let e = t.get(S);
				if (e.color.copy(S.color).multiplyScalar(S.intensity), e.distance = S.distance, e.decay = S.decay, S.castShadow) {
					let e = S.shadow, t = n.get(S);
					t.shadowIntensity = e.intensity, t.shadowBias = e.bias, t.shadowNormalBias = e.normalBias, t.shadowRadius = e.radius, t.shadowMapSize = e.mapSize, t.shadowCameraNear = e.camera.near, t.shadowCameraFar = e.camera.far, r.pointShadow[f] = t, r.pointShadowMap[f] = E, r.pointShadowMatrix[f] = S.shadow.matrix, _++;
				}
				r.point[f] = e, f++;
			} else if (S.isHemisphereLight) {
				let e = t.get(S);
				e.skyColor.copy(S.color).multiplyScalar(w), e.groundColor.copy(S.groundColor).multiplyScalar(w), r.hemi[h] = e, h++;
			}
		}
		m > 0 && (e.has("OES_texture_float_linear") === !0 ? (r.rectAreaLTC1 = K.LTC_FLOAT_1, r.rectAreaLTC2 = K.LTC_FLOAT_2) : (r.rectAreaLTC1 = K.LTC_HALF_1, r.rectAreaLTC2 = K.LTC_HALF_2)), r.ambient[0] = a, r.ambient[1] = o, r.ambient[2] = s;
		let S = r.hash;
		(S.sunLength !== c || S.directionalLength !== d || S.pointLength !== f || S.spotLength !== p || S.rectAreaLength !== m || S.hemiLength !== h || S.numSunShadows !== l || S.numDirectionalShadows !== g || S.numPointShadows !== _ || S.numSpotShadows !== v || S.numSpotMaps !== y || S.numLightProbes !== x) && (r.sun.length = c, r.directional.length = d, r.spot.length = p, r.rectArea.length = m, r.point.length = f, r.hemi.length = h, r.sunShadow.length = l, r.sunShadowMap.length = l, r.sunShadowMatrix.length = u, r.sunShadowCascade.length = u, r.directionalShadow.length = g, r.directionalShadowMap.length = g, r.directionalShadowMatrix.length = g, r.pointShadow.length = _, r.pointShadowMap.length = _, r.pointShadowMatrix.length = _, r.spotShadow.length = v, r.spotShadowMap.length = v, r.spotLightMatrix.length = v + y - b, r.spotLightMap.length = y, r.numSpotLightShadowsWithMaps = b, r.numLightProbes = x, S.sunLength = c, S.directionalLength = d, S.pointLength = f, S.spotLength = p, S.rectAreaLength = m, S.hemiLength = h, S.numSunShadows = l, S.numDirectionalShadows = g, S.numPointShadows = _, S.numSpotShadows = v, S.numSpotMaps = y, S.numLightProbes = x, r.version = na++);
	}
	function c(e, t) {
		let n = 0, s = 0, c = 0, l = 0, u = 0, d = 0, f = t.matrixWorldInverse;
		for (let t = 0, p = e.length; t < p; t++) {
			let p = e[t];
			if (p.isSunLight) {
				let e = r.sun[n];
				e.direction.setFromMatrixPosition(p.matrixWorld), e.direction.transformDirection(f), n++;
			} else if (p.isDirectionalLight) {
				let e = r.directional[s];
				e.direction.setFromMatrixPosition(p.matrixWorld), i.setFromMatrixPosition(p.target.matrixWorld), e.direction.sub(i), e.direction.transformDirection(f), s++;
			} else if (p.isSpotLight) {
				let e = r.spot[l];
				e.position.setFromMatrixPosition(p.matrixWorld), e.position.applyMatrix4(f), e.direction.setFromMatrixPosition(p.matrixWorld), i.setFromMatrixPosition(p.target.matrixWorld), e.direction.sub(i), e.direction.transformDirection(f), l++;
			} else if (p.isRectAreaLight) {
				let e = r.rectArea[u];
				e.position.setFromMatrixPosition(p.matrixWorld), e.position.applyMatrix4(f), o.identity(), a.copy(p.matrixWorld), a.premultiply(f), o.extractRotation(a), e.halfWidth.set(p.width * .5, 0, 0), e.halfHeight.set(0, p.height * .5, 0), e.halfWidth.applyMatrix4(o), e.halfHeight.applyMatrix4(o), u++;
			} else if (p.isPointLight) {
				let e = r.point[c];
				e.position.setFromMatrixPosition(p.matrixWorld), e.position.applyMatrix4(f), c++;
			} else if (p.isHemisphereLight) {
				let e = r.hemi[d];
				e.direction.setFromMatrixPosition(p.matrixWorld), e.direction.transformDirection(f), d++;
			}
		}
	}
	return {
		setup: s,
		setupView: c,
		state: r
	};
}
function aa(e) {
	let t = new ia(e), n = [], r = [], i = [];
	function a(e) {
		d.camera = e, n.length = 0, r.length = 0, i.length = 0;
	}
	function o(e) {
		n.push(e);
	}
	function s(e) {
		r.push(e);
	}
	function c(e) {
		i.push(e);
	}
	function l() {
		t.setup(n);
	}
	function u(e) {
		t.setupView(n, e);
	}
	let d = {
		lightsArray: n,
		shadowsArray: r,
		lightProbeGridArray: i,
		camera: null,
		lights: t,
		transmissionRenderTarget: {},
		textureUnits: 0
	};
	return {
		init: a,
		state: d,
		setupLights: l,
		setupLightsView: u,
		pushLight: o,
		pushShadow: s,
		pushLightProbeGrid: c
	};
}
function oa(e) {
	let t = /* @__PURE__ */ new WeakMap();
	function n(n, r = 0) {
		let i = t.get(n), a;
		return i === void 0 ? (a = new aa(e), t.set(n, [a])) : r >= i.length ? (a = new aa(e), i.push(a)) : a = i[r], a;
	}
	function r() {
		t = /* @__PURE__ */ new WeakMap();
	}
	return {
		get: n,
		dispose: r
	};
}
var sa = "void main() {\n	gl_Position = vec4( position, 1.0 );\n}", ca = "uniform sampler2D shadow_pass;\nuniform vec2 resolution;\nuniform float radius;\nvoid main() {\n	const float samples = float( VSM_SAMPLES );\n	float mean = 0.0;\n	float squared_mean = 0.0;\n	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );\n	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;\n	for ( float i = 0.0; i < samples; i ++ ) {\n		float uvOffset = uvStart + i * uvStride;\n		#ifdef HORIZONTAL_PASS\n			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;\n			mean += distribution.x;\n			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;\n		#else\n			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;\n			mean += depth;\n			squared_mean += depth * depth;\n		#endif\n	}\n	mean = mean / samples;\n	squared_mean = squared_mean / samples;\n	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );\n	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );\n}", la = [
	/*@__PURE__*/ new L(1, 0, 0),
	/*@__PURE__*/ new L(-1, 0, 0),
	/*@__PURE__*/ new L(0, 1, 0),
	/*@__PURE__*/ new L(0, -1, 0),
	/*@__PURE__*/ new L(0, 0, 1),
	/*@__PURE__*/ new L(0, 0, -1)
], ua = [
	/*@__PURE__*/ new L(0, -1, 0),
	/*@__PURE__*/ new L(0, -1, 0),
	/*@__PURE__*/ new L(0, 0, 1),
	/*@__PURE__*/ new L(0, 0, -1),
	/*@__PURE__*/ new L(0, -1, 0),
	/*@__PURE__*/ new L(0, -1, 0)
], da = /*@__PURE__*/ new Ie(), fa = /*@__PURE__*/ new L(), pa = /*@__PURE__*/ new L();
function ma(e, t, n) {
	let r = new A(), i = new P(), a = new P(), o = new Qe(), s = new _t(), c = new De(), l = {}, u = n.maxTextureSize, d = {
		0: 1,
		1: 0,
		2: 2
	}, f = new m({
		defines: { VSM_SAMPLES: 8 },
		uniforms: {
			shadow_pass: { value: null },
			resolution: { value: new P() },
			radius: { value: 4 }
		},
		vertexShader: sa,
		fragmentShader: ca
	}), h = f.clone();
	h.defines.HORIZONTAL_PASS = 1;
	let g = new We();
	g.setAttribute("position", new Oe(new Float32Array([
		-1,
		-1,
		.5,
		3,
		-1,
		.5,
		-1,
		3,
		.5
	]), 3));
	let _ = new N(g, f), y = this;
	this.enabled = !1, this.autoUpdate = !0, this.needsUpdate = !1, this.type = 1;
	let x = this.type;
	this.render = function(t, n, s) {
		if (y.enabled === !1 || y.autoUpdate === !1 && y.needsUpdate === !1 || t.length === 0) return;
		this.type === 2 && (b("WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead."), this.type = 1);
		let c = e.getRenderTarget(), l = e.getActiveCubeFace(), d = e.getActiveMipmapLevel(), f = e.state;
		f.setBlending(0), f.buffers.depth.getReversed() === !0 ? f.buffers.color.setClear(0, 0, 0, 0) : f.buffers.color.setClear(1, 1, 1, 1), f.buffers.depth.setTest(!0), f.setScissorTest(!1);
		let m = x !== this.type;
		m && n.traverse(function(e) {
			e.material && (Array.isArray(e.material) ? e.material.forEach((e) => e.needsUpdate = !0) : e.material.needsUpdate = !0);
		});
		for (let c = 0, l = t.length; c < l; c++) {
			let l = t[c], d = l.shadow;
			if (d === void 0) {
				b("WebGLShadowMap:", l, "has no shadow.");
				continue;
			}
			if (d.autoUpdate === !1 && d.needsUpdate === !1) continue;
			i.copy(d.mapSize);
			let h = d.getFrameExtents();
			i.multiply(h), a.copy(d.mapSize), (i.x > u || i.y > u) && (i.x > u && (a.x = Math.floor(u / h.x), i.x = a.x * h.x, d.mapSize.x = a.x), i.y > u && (a.y = Math.floor(u / h.y), i.y = a.y * h.y, d.mapSize.y = a.y));
			let g = e.state.buffers.depth.getReversed();
			if (d.camera._reversedDepth = g, d.map === null || m === !0) {
				if (d.map !== null && (d.map.depthTexture !== null && (d.map.depthTexture.dispose(), d.map.depthTexture = null), d.map.dispose()), this.type === 3) {
					if (l.isPointLight) {
						b("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");
						continue;
					}
					d.map = new Fe(i.x, i.y, {
						format: ut,
						type: p,
						minFilter: B,
						magFilter: B,
						generateMipmaps: !1
					}), d.map.texture.name = l.name + ".shadowMap", d.map.depthTexture = new v(i.x, i.y, E), d.map.depthTexture.name = l.name + ".shadowMapDepth", d.map.depthTexture.format = me, d.map.depthTexture.compareFunction = null, d.map.depthTexture.minFilter = T, d.map.depthTexture.magFilter = T;
				} else l.isPointLight ? (d.map = new Gn(i.x), d.map.depthTexture = new R(i.x, it)) : (d.map = new Fe(i.x, i.y), d.map.depthTexture = new v(i.x, i.y, it)), d.map.depthTexture.name = l.name + ".shadowMap", d.map.depthTexture.format = me, this.type === 1 ? (d.map.depthTexture.compareFunction = g ? 518 : 515, d.map.depthTexture.minFilter = B, d.map.depthTexture.magFilter = B) : (d.map.depthTexture.compareFunction = null, d.map.depthTexture.minFilter = T, d.map.depthTexture.magFilter = T);
				d.camera.updateProjectionMatrix();
			}
			d.map.isWebGLCubeRenderTarget !== !0 && (d.map.width !== i.x || d.map.height !== i.y) && d.map.setSize(i.x, i.y);
			let _ = d.map.isWebGLCubeRenderTarget ? 6 : d.getViewportCount();
			l.isPointLight !== !0 && d.updateMatrices(l, s);
			for (let t = 0; t < _; t++) {
				let i = d.getCamera(t);
				if (l.isPointLight) {
					let e = d.camera, n = d.matrix, r = l.distance || e.far;
					r !== e.far && (e.far = r, e.updateProjectionMatrix()), fa.setFromMatrixPosition(l.matrixWorld), e.position.copy(fa), pa.copy(e.position), pa.add(la[t]), e.up.copy(ua[t]), e.lookAt(pa), e.updateMatrixWorld(), n.makeTranslation(-fa.x, -fa.y, -fa.z), da.multiplyMatrices(e.projectionMatrix, e.matrixWorldInverse), d._frustum.setFromProjectionMatrix(da, e.coordinateSystem, e.reversedDepth);
				}
				if (d.map.isWebGLCubeRenderTarget) e.setRenderTarget(d.map, t), e.clear();
				else {
					t === 0 && (e.setRenderTarget(d.map), e.clear());
					let n = d.getViewport(t);
					o.set(a.x * n.x, a.y * n.y, a.x * n.z, a.y * n.w), f.viewport(o);
				}
				r = d.getFrustum(t), w(n, s, i, l, this.type);
			}
			d.isPointLightShadow !== !0 && this.type === 3 && S(d, s), d.needsUpdate = !1;
		}
		x = this.type, y.needsUpdate = !1, e.setRenderTarget(c, l, d);
	};
	function S(n, r) {
		let a = t.update(_);
		f.defines.VSM_SAMPLES !== n.blurSamples && (f.defines.VSM_SAMPLES = n.blurSamples, h.defines.VSM_SAMPLES = n.blurSamples, f.needsUpdate = !0, h.needsUpdate = !0), n.mapPass === null ? n.mapPass = new Fe(i.x, i.y, {
			format: ut,
			type: p
		}) : (n.mapPass.width !== n.map.width || n.mapPass.height !== n.map.height) && n.mapPass.setSize(n.map.width, n.map.height), f.uniforms.shadow_pass.value = n.map.depthTexture, f.uniforms.resolution.value.set(n.map.width, n.map.height), f.uniforms.radius.value = n.radius, e.setRenderTarget(n.mapPass), e.clear(), e.renderBufferDirect(r, null, a, f, _, null), h.uniforms.shadow_pass.value = n.mapPass.texture, h.uniforms.resolution.value.set(n.map.width, n.map.height), h.uniforms.radius.value = n.radius, e.setRenderTarget(n.map), e.clear(), e.renderBufferDirect(r, null, a, h, _, null);
	}
	function C(t, n, r, i) {
		let a = null, o = r.isPointLight === !0 ? t.customDistanceMaterial : t.customDepthMaterial;
		if (o !== void 0) a = o;
		else if (a = r.isPointLight === !0 ? c : s, e.localClippingEnabled && n.clipShadows === !0 && Array.isArray(n.clippingPlanes) && n.clippingPlanes.length !== 0 || n.displacementMap && n.displacementScale !== 0 || n.alphaMap && n.alphaTest > 0 || n.map && n.alphaTest > 0 || n.alphaToCoverage === !0) {
			let e = a.uuid, t = n.uuid, r = l[e];
			r === void 0 && (r = {}, l[e] = r);
			let i = r[t];
			i === void 0 && (i = a.clone(), r[t] = i, n.addEventListener("dispose", D)), a = i;
		}
		if (a.visible = n.visible, a.wireframe = n.wireframe, i === 3 ? a.side = n.shadowSide === null ? n.side : n.shadowSide : a.side = n.shadowSide === null ? d[n.side] : n.shadowSide, a.alphaMap = n.alphaMap, a.alphaTest = n.alphaToCoverage === !0 ? .5 : n.alphaTest, a.map = n.map, a.clipShadows = n.clipShadows, a.clippingPlanes = n.clippingPlanes, a.clipIntersection = n.clipIntersection, a.displacementMap = n.displacementMap, a.displacementScale = n.displacementScale, a.displacementBias = n.displacementBias, a.wireframeLinewidth = n.wireframeLinewidth, a.linewidth = n.linewidth, r.isPointLight === !0 && a.isMeshDistanceMaterial === !0) {
			let t = e.properties.get(a);
			t.light = r;
		}
		return a;
	}
	function w(n, i, a, o, s) {
		if (n.visible === !1) return;
		if (n.layers.test(i.layers) && (n.isMesh || n.isLine || n.isPoints) && (n.castShadow || n.receiveShadow && s === 3) && (!n.frustumCulled || n.intersectsFrustum(r))) {
			n.modelViewMatrix.multiplyMatrices(a.matrixWorldInverse, n.matrixWorld);
			let r = t.update(n), c = n.material;
			if (Array.isArray(c)) {
				let t = r.groups;
				for (let l = 0, u = t.length; l < u; l++) {
					let u = t[l], d = c[u.materialIndex];
					if (d && d.visible) {
						let t = C(n, d, o, s);
						n.onBeforeShadow(e, n, i, a, r, t, u), e.renderBufferDirect(a, null, r, t, n, u), n.onAfterShadow(e, n, i, a, r, t, u);
					}
				}
			} else if (c.visible) {
				let t = C(n, c, o, s);
				n.onBeforeShadow(e, n, i, a, r, t, null), e.renderBufferDirect(a, null, r, t, n, null), n.onAfterShadow(e, n, i, a, r, t, null);
			}
		}
		let c = n.children;
		for (let e = 0, t = c.length; e < t; e++) w(c[e], i, a, o, s);
	}
	function D(e) {
		e.target.removeEventListener("dispose", D);
		for (let t in l) {
			let n = l[t], r = e.target.uuid;
			r in n && (n[r].dispose(), delete n[r]);
		}
	}
}
function ha(e, t) {
	function n() {
		let t = !1, n = new Qe(), r = null, i = new Qe(0, 0, 0, 0);
		return {
			setMask: function(n) {
				r !== n && !t && (e.colorMask(n, n, n, n), r = n);
			},
			setLocked: function(e) {
				t = e;
			},
			setClear: function(t, r, a, o, s) {
				s === !0 && (t *= o, r *= o, a *= o), n.set(t, r, a, o), i.equals(n) === !1 && (e.clearColor(t, r, a, o), i.copy(n));
			},
			reset: function() {
				t = !1, r = null, i.set(-1, 0, 0, 0);
			}
		};
	}
	function r() {
		let n = !1, r = !1, i = null, a = null, o = null;
		return {
			setReversed: function(e) {
				if (r !== e) {
					let n = t.get("EXT_clip_control");
					e ? n.clipControlEXT(n.LOWER_LEFT_EXT, n.ZERO_TO_ONE_EXT) : n.clipControlEXT(n.LOWER_LEFT_EXT, n.NEGATIVE_ONE_TO_ONE_EXT), r = e;
					let i = o;
					o = null, this.setClear(i);
				}
			},
			getReversed: function() {
				return r;
			},
			setTest: function(t) {
				t ? fe(e.DEPTH_TEST) : pe(e.DEPTH_TEST);
			},
			setMask: function(t) {
				i !== t && !n && (e.depthMask(t), i = t);
			},
			setFunc: function(t) {
				if (r && (t = re[t]), a !== t) {
					switch (t) {
						case 0:
							e.depthFunc(e.NEVER);
							break;
						case 1:
							e.depthFunc(e.ALWAYS);
							break;
						case 2:
							e.depthFunc(e.LESS);
							break;
						case 3:
							e.depthFunc(e.LEQUAL);
							break;
						case 4:
							e.depthFunc(e.EQUAL);
							break;
						case 5:
							e.depthFunc(e.GEQUAL);
							break;
						case 6:
							e.depthFunc(e.GREATER);
							break;
						case 7:
							e.depthFunc(e.NOTEQUAL);
							break;
						default: e.depthFunc(e.LEQUAL);
					}
					a = t;
				}
			},
			setLocked: function(e) {
				n = e;
			},
			setClear: function(t) {
				o !== t && (o = t, r && (t = 1 - t), e.clearDepth(t));
			},
			reset: function() {
				n = !1, i = null, a = null, o = null, r = !1;
			}
		};
	}
	function i() {
		let t = !1, n = null, r = null, i = null, a = null, o = null, s = null, c = null, l = null;
		return {
			setTest: function(n) {
				t || (n ? fe(e.STENCIL_TEST) : pe(e.STENCIL_TEST));
			},
			setMask: function(r) {
				n !== r && !t && (e.stencilMask(r), n = r);
			},
			setFunc: function(t, n, o) {
				(r !== t || i !== n || a !== o) && (e.stencilFunc(t, n, o), r = t, i = n, a = o);
			},
			setOp: function(t, n, r) {
				(o !== t || s !== n || c !== r) && (e.stencilOp(t, n, r), o = t, s = n, c = r);
			},
			setLocked: function(e) {
				t = e;
			},
			setClear: function(t) {
				l !== t && (e.clearStencil(t), l = t);
			},
			reset: function() {
				t = !1, n = null, r = null, i = null, a = null, o = null, s = null, c = null, l = null;
			}
		};
	}
	let a = new n(), o = new r(), s = new i(), c = /* @__PURE__ */ new WeakMap(), l = /* @__PURE__ */ new WeakMap(), u = {}, d = {}, f = {}, p = /* @__PURE__ */ new WeakMap(), m = [], h = null, g = !1, _ = null, v = null, y = null, b = null, x = null, S = null, C = null, w = new I(0, 0, 0), T = 0, E = !1, D = null, O = null, ee = null, k = null, A = null, te = e.getParameter(e.MAX_COMBINED_TEXTURE_IMAGE_UNITS), ne = !1, ie = 0, ae = e.getParameter(e.VERSION);
	ae.indexOf("WebGL") === -1 ? ae.indexOf("OpenGL ES") !== -1 && (ie = parseFloat(/^OpenGL ES (\d)/.exec(ae)[1]), ne = ie >= 2) : (ie = parseFloat(/^WebGL (\d)/.exec(ae)[1]), ne = ie >= 1);
	let oe = null, se = {}, ce = e.getParameter(e.SCISSOR_BOX), le = e.getParameter(e.VIEWPORT), ue = new Qe().fromArray(ce), j = new Qe().fromArray(le);
	function M(t, n, r, i) {
		let a = /* @__PURE__ */ new Uint8Array(4), o = e.createTexture();
		e.bindTexture(t, o), e.texParameteri(t, e.TEXTURE_MIN_FILTER, e.NEAREST), e.texParameteri(t, e.TEXTURE_MAG_FILTER, e.NEAREST);
		for (let o = 0; o < r; o++) t === e.TEXTURE_3D || t === e.TEXTURE_2D_ARRAY ? e.texImage3D(n, 0, e.RGBA, 1, 1, i, 0, e.RGBA, e.UNSIGNED_BYTE, a) : e.texImage2D(n + o, 0, e.RGBA, 1, 1, 0, e.RGBA, e.UNSIGNED_BYTE, a);
		return o;
	}
	let de = {};
	de[e.TEXTURE_2D] = M(e.TEXTURE_2D, e.TEXTURE_2D, 1), de[e.TEXTURE_CUBE_MAP] = M(e.TEXTURE_CUBE_MAP, e.TEXTURE_CUBE_MAP_POSITIVE_X, 6), de[e.TEXTURE_2D_ARRAY] = M(e.TEXTURE_2D_ARRAY, e.TEXTURE_2D_ARRAY, 1, 1), de[e.TEXTURE_3D] = M(e.TEXTURE_3D, e.TEXTURE_3D, 1, 1), a.setClear(0, 0, 0, 1), o.setClear(1), s.setClear(0), fe(e.DEPTH_TEST), o.setFunc(3), xe(!1), Se(1), fe(e.CULL_FACE), ye(0);
	function fe(t) {
		u[t] !== !0 && (e.enable(t), u[t] = !0);
	}
	function pe(t) {
		u[t] !== !1 && (e.disable(t), u[t] = !1);
	}
	function me(t, n) {
		return f[t] !== n && (e.bindFramebuffer(t, n), f[t] = n, t === e.DRAW_FRAMEBUFFER && (f[e.FRAMEBUFFER] = n), t === e.FRAMEBUFFER && (f[e.DRAW_FRAMEBUFFER] = n), !0);
	}
	function he(t, n) {
		let r = m, i = !1;
		if (t) {
			r = p.get(n), r === void 0 && (r = [], p.set(n, r));
			let a = t.textures;
			if (r.length !== a.length || r[0] !== e.COLOR_ATTACHMENT0) {
				for (let t = 0, n = a.length; t < n; t++) r[t] = e.COLOR_ATTACHMENT0 + t;
				r.length = a.length, i = !0;
			}
		} else r[0] !== e.BACK && (r[0] = e.BACK, i = !0);
		i && e.drawBuffers(r);
	}
	function ge(t) {
		return h !== t && (e.useProgram(t), h = t, !0);
	}
	let _e = {
		100: e.FUNC_ADD,
		101: e.FUNC_SUBTRACT,
		102: e.FUNC_REVERSE_SUBTRACT
	};
	_e[103] = e.MIN, _e[104] = e.MAX;
	let ve = {
		200: e.ZERO,
		201: e.ONE,
		202: e.SRC_COLOR,
		204: e.SRC_ALPHA,
		210: e.SRC_ALPHA_SATURATE,
		208: e.DST_COLOR,
		206: e.DST_ALPHA,
		203: e.ONE_MINUS_SRC_COLOR,
		205: e.ONE_MINUS_SRC_ALPHA,
		209: e.ONE_MINUS_DST_COLOR,
		207: e.ONE_MINUS_DST_ALPHA,
		211: e.CONSTANT_COLOR,
		212: e.ONE_MINUS_CONSTANT_COLOR,
		213: e.CONSTANT_ALPHA,
		214: e.ONE_MINUS_CONSTANT_ALPHA
	};
	function ye(t, n, r, i, a, o, s, c, l, u) {
		if (t === 0) g === !0 && (pe(e.BLEND), g = !1);
		else if (g === !1 && (fe(e.BLEND), g = !0), t !== 5) {
			if (t !== _ || u !== E) {
				if ((v !== 100 || x !== 100) && (e.blendEquation(e.FUNC_ADD), v = 100, x = 100), u) switch (t) {
					case 1:
						e.blendFuncSeparate(e.ONE, e.ONE_MINUS_SRC_ALPHA, e.ONE, e.ONE_MINUS_SRC_ALPHA);
						break;
					case 2:
						e.blendFunc(e.ONE, e.ONE);
						break;
					case 3:
						e.blendFuncSeparate(e.ZERO, e.ONE_MINUS_SRC_COLOR, e.ZERO, e.ONE);
						break;
					case 4:
						e.blendFuncSeparate(e.DST_COLOR, e.ONE_MINUS_SRC_ALPHA, e.ZERO, e.ONE);
						break;
					default: mt("WebGLState: Invalid blending: ", t);
				}
				else switch (t) {
					case 1:
						e.blendFuncSeparate(e.SRC_ALPHA, e.ONE_MINUS_SRC_ALPHA, e.ONE, e.ONE_MINUS_SRC_ALPHA);
						break;
					case 2:
						e.blendFuncSeparate(e.SRC_ALPHA, e.ONE, e.ONE, e.ONE);
						break;
					case 3:
						mt("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");
						break;
					case 4:
						mt("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");
						break;
					default: mt("WebGLState: Invalid blending: ", t);
				}
				y = null, b = null, S = null, C = null, w.set(0, 0, 0), T = 0, _ = t, E = u;
			}
		} else a ||= n, o ||= r, s ||= i, (n !== v || a !== x) && (e.blendEquationSeparate(_e[n], _e[a]), v = n, x = a), (r !== y || i !== b || o !== S || s !== C) && (e.blendFuncSeparate(ve[r], ve[i], ve[o], ve[s]), y = r, b = i, S = o, C = s), (c.equals(w) === !1 || l !== T) && (e.blendColor(c.r, c.g, c.b, l), w.copy(c), T = l), _ = t, E = !1;
	}
	function be(t, n) {
		t.side === 2 ? pe(e.CULL_FACE) : fe(e.CULL_FACE);
		let r = t.side === 1;
		n && (r = !r), xe(r), t.blending === 1 && t.transparent === !1 ? ye(0) : ye(t.blending, t.blendEquation, t.blendSrc, t.blendDst, t.blendEquationAlpha, t.blendSrcAlpha, t.blendDstAlpha, t.blendColor, t.blendAlpha, t.premultipliedAlpha), o.setFunc(t.depthFunc), o.setTest(t.depthTest), o.setMask(t.depthWrite), a.setMask(t.colorWrite);
		let i = t.stencilWrite;
		s.setTest(i), i && (s.setMask(t.stencilWriteMask), s.setFunc(t.stencilFunc, t.stencilRef, t.stencilFuncMask), s.setOp(t.stencilFail, t.stencilZFail, t.stencilZPass)), Ce(t.polygonOffset, t.polygonOffsetFactor, t.polygonOffsetUnits), t.alphaToCoverage === !0 ? fe(e.SAMPLE_ALPHA_TO_COVERAGE) : pe(e.SAMPLE_ALPHA_TO_COVERAGE);
	}
	function xe(t) {
		D !== t && (t ? e.frontFace(e.CW) : e.frontFace(e.CCW), D = t);
	}
	function Se(t) {
		t === 0 ? pe(e.CULL_FACE) : (fe(e.CULL_FACE), t !== O && (t === 1 ? e.cullFace(e.BACK) : t === 2 ? e.cullFace(e.FRONT) : e.cullFace(e.FRONT_AND_BACK))), O = t;
	}
	function N(t) {
		t !== ee && (ne && e.lineWidth(t), ee = t);
	}
	function Ce(t, n, r) {
		t ? (fe(e.POLYGON_OFFSET_FILL), (k !== n || A !== r) && (k = n, A = r, o.getReversed() && (n = -n), e.polygonOffset(n, r))) : pe(e.POLYGON_OFFSET_FILL);
	}
	function we(t) {
		t ? fe(e.SCISSOR_TEST) : pe(e.SCISSOR_TEST);
	}
	function Te(t) {
		t === void 0 && (t = e.TEXTURE0 + te - 1), oe !== t && (e.activeTexture(t), oe = t);
	}
	function Ee(t, n, r) {
		r === void 0 && (r = oe === null ? e.TEXTURE0 + te - 1 : oe);
		let i = se[r];
		i === void 0 && (i = {
			type: void 0,
			texture: void 0
		}, se[r] = i), (i.type !== t || i.texture !== n) && (oe !== r && (e.activeTexture(r), oe = r), e.bindTexture(t, n || de[t]), i.type = t, i.texture = n);
	}
	function De() {
		let t = se[oe];
		t !== void 0 && t.type !== void 0 && (e.bindTexture(t.type, null), t.type = void 0, t.texture = void 0);
	}
	function Oe() {
		try {
			e.compressedTexImage2D(...arguments);
		} catch (e) {
			mt("WebGLState:", e);
		}
	}
	function ke() {
		try {
			e.compressedTexImage3D(...arguments);
		} catch (e) {
			mt("WebGLState:", e);
		}
	}
	function Ae() {
		try {
			e.texSubImage2D(...arguments);
		} catch (e) {
			mt("WebGLState:", e);
		}
	}
	function je() {
		try {
			e.texSubImage3D(...arguments);
		} catch (e) {
			mt("WebGLState:", e);
		}
	}
	function P() {
		try {
			e.compressedTexSubImage2D(...arguments);
		} catch (e) {
			mt("WebGLState:", e);
		}
	}
	function Me() {
		try {
			e.compressedTexSubImage3D(...arguments);
		} catch (e) {
			mt("WebGLState:", e);
		}
	}
	function Ne() {
		try {
			e.texStorage2D(...arguments);
		} catch (e) {
			mt("WebGLState:", e);
		}
	}
	function F() {
		try {
			e.texStorage3D(...arguments);
		} catch (e) {
			mt("WebGLState:", e);
		}
	}
	function L() {
		try {
			e.texImage2D(...arguments);
		} catch (e) {
			mt("WebGLState:", e);
		}
	}
	function Pe() {
		try {
			e.texImage3D(...arguments);
		} catch (e) {
			mt("WebGLState:", e);
		}
	}
	function R(t) {
		return d[t] === void 0 ? e.getParameter(t) : d[t];
	}
	function Fe(t, n) {
		d[t] !== n && (e.pixelStorei(t, n), d[t] = n);
	}
	function Ie(t) {
		ue.equals(t) === !1 && (e.scissor(t.x, t.y, t.z, t.w), ue.copy(t));
	}
	function Le(t) {
		j.equals(t) === !1 && (e.viewport(t.x, t.y, t.z, t.w), j.copy(t));
	}
	function Re(t, n) {
		let r = l.get(n);
		r === void 0 && (r = /* @__PURE__ */ new WeakMap(), l.set(n, r));
		let i = r.get(t);
		i === void 0 && (i = e.getUniformBlockIndex(n, t.name), r.set(t, i));
	}
	function z(t, n) {
		let r = l.get(n).get(t);
		c.get(n) !== r && (e.uniformBlockBinding(n, r, t.__bindingPointIndex), c.set(n, r));
	}
	function ze() {
		e.disable(e.BLEND), e.disable(e.CULL_FACE), e.disable(e.DEPTH_TEST), e.disable(e.POLYGON_OFFSET_FILL), e.disable(e.SCISSOR_TEST), e.disable(e.STENCIL_TEST), e.disable(e.SAMPLE_ALPHA_TO_COVERAGE), e.blendEquation(e.FUNC_ADD), e.blendFunc(e.ONE, e.ZERO), e.blendFuncSeparate(e.ONE, e.ZERO, e.ONE, e.ZERO), e.blendColor(0, 0, 0, 0), e.colorMask(!0, !0, !0, !0), e.clearColor(0, 0, 0, 0), e.depthMask(!0), e.depthFunc(e.LESS), o.setReversed(!1), e.clearDepth(1), e.stencilMask(4294967295), e.stencilFunc(e.ALWAYS, 0, 4294967295), e.stencilOp(e.KEEP, e.KEEP, e.KEEP), e.clearStencil(0), e.cullFace(e.BACK), e.frontFace(e.CCW), e.polygonOffset(0, 0), e.activeTexture(e.TEXTURE0), e.bindFramebuffer(e.FRAMEBUFFER, null), e.bindFramebuffer(e.DRAW_FRAMEBUFFER, null), e.bindFramebuffer(e.READ_FRAMEBUFFER, null), e.useProgram(null), e.lineWidth(1), e.scissor(0, 0, e.canvas.width, e.canvas.height), e.viewport(0, 0, e.canvas.width, e.canvas.height), e.pixelStorei(e.PACK_ALIGNMENT, 4), e.pixelStorei(e.UNPACK_ALIGNMENT, 4), e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL, !1), e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !1), e.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL, e.BROWSER_DEFAULT_WEBGL), e.pixelStorei(e.PACK_ROW_LENGTH, 0), e.pixelStorei(e.PACK_SKIP_PIXELS, 0), e.pixelStorei(e.PACK_SKIP_ROWS, 0), e.pixelStorei(e.UNPACK_ROW_LENGTH, 0), e.pixelStorei(e.UNPACK_IMAGE_HEIGHT, 0), e.pixelStorei(e.UNPACK_SKIP_PIXELS, 0), e.pixelStorei(e.UNPACK_SKIP_ROWS, 0), e.pixelStorei(e.UNPACK_SKIP_IMAGES, 0), u = {}, d = {}, oe = null, se = {}, f = {}, p = /* @__PURE__ */ new WeakMap(), m = [], h = null, g = !1, _ = null, v = null, y = null, b = null, x = null, S = null, C = null, w = new I(0, 0, 0), T = 0, E = !1, D = null, O = null, ee = null, k = null, A = null, ue.set(0, 0, e.canvas.width, e.canvas.height), j.set(0, 0, e.canvas.width, e.canvas.height), a.reset(), o.reset(), s.reset();
	}
	return {
		buffers: {
			color: a,
			depth: o,
			stencil: s
		},
		enable: fe,
		disable: pe,
		bindFramebuffer: me,
		drawBuffers: he,
		useProgram: ge,
		setBlending: ye,
		setMaterial: be,
		setFlipSided: xe,
		setCullFace: Se,
		setLineWidth: N,
		setPolygonOffset: Ce,
		setScissorTest: we,
		activeTexture: Te,
		bindTexture: Ee,
		unbindTexture: De,
		compressedTexImage2D: Oe,
		compressedTexImage3D: ke,
		texImage2D: L,
		texImage3D: Pe,
		pixelStorei: Fe,
		getParameter: R,
		updateUBOMapping: Re,
		uniformBlockBinding: z,
		texStorage2D: Ne,
		texStorage3D: F,
		texSubImage2D: Ae,
		texSubImage3D: je,
		compressedTexSubImage2D: P,
		compressedTexSubImage3D: Me,
		scissor: Ie,
		viewport: Le,
		reset: ze
	};
}
function ga(e, t, n, r, i, a, o) {
	let s = t.has("WEBGL_multisampled_render_to_texture") ? t.get("WEBGL_multisampled_render_to_texture") : null, c = typeof navigator > "u" ? !1 : /OculusBrowser/g.test(navigator.userAgent), l = new P(), u = /* @__PURE__ */ new WeakMap(), d = /* @__PURE__ */ new Set(), f, p = /* @__PURE__ */ new WeakMap(), m = !1;
	try {
		m = typeof OffscreenCanvas < "u" && new OffscreenCanvas(1, 1).getContext("2d") !== null;
	} catch {}
	function h(e, t) {
		return m ? new OffscreenCanvas(e, t) : Ee("canvas");
	}
	function g(e, t, n) {
		let r = 1, i = R(e);
		if ((i.width > n || i.height > n) && (r = n / Math.max(i.width, i.height)), r < 1) {
			if (typeof HTMLImageElement < "u" && e instanceof HTMLImageElement || typeof HTMLCanvasElement < "u" && e instanceof HTMLCanvasElement || typeof ImageBitmap < "u" && e instanceof ImageBitmap || typeof VideoFrame < "u" && e instanceof VideoFrame) {
				let n = Math.floor(r * i.width), a = Math.floor(r * i.height);
				f === void 0 && (f = h(n, a));
				let o = t ? h(n, a) : f;
				return o.width = n, o.height = a, o.getContext("2d").drawImage(e, 0, 0, n, a), b("WebGLRenderer: Texture has been resized from (" + i.width + "x" + i.height + ") to (" + n + "x" + a + ")."), o;
			}
			return "data" in e && b("WebGLRenderer: Image in DataTexture is too big (" + i.width + "x" + i.height + ")."), e;
		}
		return e;
	}
	function _(e) {
		return e.generateMipmaps;
	}
	function v(t) {
		e.generateMipmap(t);
	}
	function y(t) {
		return t.isWebGLCubeRenderTarget ? e.TEXTURE_CUBE_MAP : t.isWebGL3DRenderTarget ? e.TEXTURE_3D : t.isWebGLArrayRenderTarget || t.isCompressedArrayTexture ? e.TEXTURE_2D_ARRAY : e.TEXTURE_2D;
	}
	function C(n, r, i, a, o, s = !1) {
		if (n !== null) {
			if (e[n] !== void 0) return e[n];
			b("WebGLRenderer: Attempt to use non-existing WebGL internal format '" + n + "'");
		}
		let c;
		a && (c = t.get("EXT_texture_norm16"), c || b("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));
		let l = r;
		if (r === e.RED && (i === e.FLOAT && (l = e.R32F), i === e.HALF_FLOAT && (l = e.R16F), i === e.UNSIGNED_BYTE && (l = e.R8), i === e.UNSIGNED_SHORT && c && (l = c.R16_EXT), i === e.SHORT && c && (l = c.R16_SNORM_EXT)), r === e.RED_INTEGER && (i === e.UNSIGNED_BYTE && (l = e.R8UI), i === e.UNSIGNED_SHORT && (l = e.R16UI), i === e.UNSIGNED_INT && (l = e.R32UI), i === e.BYTE && (l = e.R8I), i === e.SHORT && (l = e.R16I), i === e.INT && (l = e.R32I)), r === e.RG && (i === e.FLOAT && (l = e.RG32F), i === e.HALF_FLOAT && (l = e.RG16F), i === e.UNSIGNED_BYTE && (l = e.RG8), i === e.UNSIGNED_SHORT && c && (l = c.RG16_EXT), i === e.SHORT && c && (l = c.RG16_SNORM_EXT)), r === e.RG_INTEGER && (i === e.UNSIGNED_BYTE && (l = e.RG8UI), i === e.UNSIGNED_SHORT && (l = e.RG16UI), i === e.UNSIGNED_INT && (l = e.RG32UI), i === e.BYTE && (l = e.RG8I), i === e.SHORT && (l = e.RG16I), i === e.INT && (l = e.RG32I)), r === e.RGB_INTEGER && (i === e.UNSIGNED_BYTE && (l = e.RGB8UI), i === e.UNSIGNED_SHORT && (l = e.RGB16UI), i === e.UNSIGNED_INT && (l = e.RGB32UI), i === e.BYTE && (l = e.RGB8I), i === e.SHORT && (l = e.RGB16I), i === e.INT && (l = e.RGB32I)), r === e.RGBA_INTEGER && (i === e.UNSIGNED_BYTE && (l = e.RGBA8UI), i === e.UNSIGNED_SHORT && (l = e.RGBA16UI), i === e.UNSIGNED_INT && (l = e.RGBA32UI), i === e.BYTE && (l = e.RGBA8I), i === e.SHORT && (l = e.RGBA16I), i === e.INT && (l = e.RGBA32I)), r === e.RGB && (i === e.UNSIGNED_SHORT && c && (l = c.RGB16_EXT), i === e.SHORT && c && (l = c.RGB16_SNORM_EXT), i === e.UNSIGNED_INT_5_9_9_9_REV && (l = e.RGB9_E5), i === e.UNSIGNED_INT_10F_11F_11F_REV && (l = e.R11F_G11F_B10F)), r === e.RGBA) {
			let t = s ? Ae : Ze.getTransfer(o);
			i === e.FLOAT && (l = e.RGBA32F), i === e.HALF_FLOAT && (l = e.RGBA16F), i === e.UNSIGNED_BYTE && (l = t === "srgb" ? e.SRGB8_ALPHA8 : e.RGBA8), i === e.UNSIGNED_SHORT && c && (l = c.RGBA16_EXT), i === e.SHORT && c && (l = c.RGBA16_SNORM_EXT), i === e.UNSIGNED_SHORT_4_4_4_4 && (l = e.RGBA4), i === e.UNSIGNED_SHORT_5_5_5_1 && (l = e.RGB5_A1);
		}
		return (l === e.R16F || l === e.R32F || l === e.RG16F || l === e.RG32F || l === e.RGBA16F || l === e.RGBA32F) && t.get("EXT_color_buffer_float"), l;
	}
	function w(t, n) {
		let r;
		return t ? n === null || n === 1014 || n === 1020 ? r = e.DEPTH24_STENCIL8 : n === 1015 ? r = e.DEPTH32F_STENCIL8 : n === 1012 && (r = e.DEPTH24_STENCIL8, b("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")) : n === null || n === 1014 || n === 1020 ? r = e.DEPTH_COMPONENT24 : n === 1015 ? r = e.DEPTH_COMPONENT32F : n === 1012 && (r = e.DEPTH_COMPONENT16), r;
	}
	function E(e, t) {
		return _(e) === !0 || e.isFramebufferTexture && e.minFilter !== 1003 && e.minFilter !== 1006 ? Math.log2(Math.max(t.width, t.height)) + 1 : e.mipmaps !== void 0 && e.mipmaps.length > 0 ? e.mipmaps.length : e.isCompressedTexture && Array.isArray(e.image) ? t.mipmaps.length : 1;
	}
	function D(e) {
		let t = e.target;
		t.removeEventListener("dispose", D), ee(t), t.isVideoTexture && u.delete(t), t.isHTMLTexture && d.delete(t);
	}
	function O(e) {
		let t = e.target;
		t.removeEventListener("dispose", O), A(t);
	}
	function ee(e) {
		let t = r.get(e);
		if (t.__webglInit === void 0) return;
		let n = e.source, i = p.get(n);
		if (i) {
			let r = i[t.__cacheKey];
			r.usedTimes--, r.usedTimes === 0 && k(e), Object.keys(i).length === 0 && p.delete(n);
		}
		r.remove(e);
	}
	function k(t) {
		let n = r.get(t);
		e.deleteTexture(n.__webglTexture);
		let i = t.source, a = p.get(i);
		delete a[n.__cacheKey], o.memory.textures--;
	}
	function A(t) {
		let n = r.get(t);
		if (t.depthTexture && (t.depthTexture.dispose(), r.remove(t.depthTexture)), t.isWebGLCubeRenderTarget) for (let t = 0; t < 6; t++) {
			if (Array.isArray(n.__webglFramebuffer[t])) for (let r = 0; r < n.__webglFramebuffer[t].length; r++) e.deleteFramebuffer(n.__webglFramebuffer[t][r]);
			else e.deleteFramebuffer(n.__webglFramebuffer[t]);
			n.__webglDepthbuffer && e.deleteRenderbuffer(n.__webglDepthbuffer[t]);
		}
		else {
			if (Array.isArray(n.__webglFramebuffer)) for (let t = 0; t < n.__webglFramebuffer.length; t++) e.deleteFramebuffer(n.__webglFramebuffer[t]);
			else e.deleteFramebuffer(n.__webglFramebuffer);
			if (n.__webglDepthbuffer && e.deleteRenderbuffer(n.__webglDepthbuffer), n.__webglMultisampledFramebuffer && e.deleteFramebuffer(n.__webglMultisampledFramebuffer), n.__webglColorRenderbuffer) for (let t = 0; t < n.__webglColorRenderbuffer.length; t++) n.__webglColorRenderbuffer[t] && e.deleteRenderbuffer(n.__webglColorRenderbuffer[t]);
			n.__webglDepthRenderbuffer && e.deleteRenderbuffer(n.__webglDepthRenderbuffer);
		}
		let i = t.textures;
		for (let t = 0, n = i.length; t < n; t++) {
			let n = r.get(i[t]);
			n.__webglTexture && (e.deleteTexture(n.__webglTexture), o.memory.textures--), r.remove(i[t]);
		}
		r.remove(t);
	}
	let te = 0;
	function ne() {
		te = 0;
	}
	function re() {
		return te;
	}
	function ie(e) {
		te = e;
	}
	function ae() {
		let e = te;
		return e >= i.maxTextures && b("WebGLTextures: Trying to use " + (e + 1) + " texture units while this GPU supports only " + i.maxTextures), te += 1, e;
	}
	function oe(e) {
		let t = [];
		return t.push(e.wrapS), t.push(e.wrapT), t.push(e.wrapR || 0), t.push(e.magFilter), t.push(e.minFilter), t.push(e.anisotropy), t.push(e.internalFormat), t.push(e.format), t.push(e.type), t.push(e.generateMipmaps), t.push(e.premultiplyAlpha), t.push(e.flipY), t.push(e.unpackAlignment), t.push(e.colorSpace), t.join();
	}
	function se(t, i) {
		let a = r.get(t);
		if (t.isVideoTexture && L(t), t.isRenderTargetTexture === !1 && t.isExternalTexture !== !0 && t.version > 0 && a.__version !== t.version) {
			let e = t.image;
			if (e === null) b("WebGLRenderer: Texture marked for update but no image data found.");
			else if (e.complete === !1) b("WebGLRenderer: Texture marked for update but image is incomplete");
			else {
				ye(a, t, i);
				return;
			}
		} else t.isExternalTexture && (a.__webglTexture = t.sourceTexture ? t.sourceTexture : null);
		n.bindTexture(e.TEXTURE_2D, a.__webglTexture, e.TEXTURE0 + i);
	}
	function le(t, i) {
		let a = r.get(t);
		t.isRenderTargetTexture === !1 && t.version > 0 && a.__version !== t.version ? ye(a, t, i) : (t.isExternalTexture && (a.__webglTexture = t.sourceTexture ? t.sourceTexture : null), n.bindTexture(e.TEXTURE_2D_ARRAY, a.__webglTexture, e.TEXTURE0 + i));
	}
	function ue(t, i) {
		let a = r.get(t);
		t.isRenderTargetTexture === !1 && t.version > 0 && a.__version !== t.version ? ye(a, t, i) : n.bindTexture(e.TEXTURE_3D, a.__webglTexture, e.TEXTURE0 + i);
	}
	function j(t, i) {
		let a = r.get(t);
		t.isCubeDepthTexture !== !0 && t.version > 0 && a.__version !== t.version ? be(a, t, i) : n.bindTexture(e.TEXTURE_CUBE_MAP, a.__webglTexture, e.TEXTURE0 + i);
	}
	let M = {
		[Be]: e.REPEAT,
		[je]: e.CLAMP_TO_EDGE,
		[_e]: e.MIRRORED_REPEAT
	}, de = {
		[T]: e.NEAREST,
		[ce]: e.NEAREST_MIPMAP_NEAREST,
		[x]: e.NEAREST_MIPMAP_LINEAR,
		[B]: e.LINEAR,
		[Xe]: e.LINEAR_MIPMAP_NEAREST,
		[we]: e.LINEAR_MIPMAP_LINEAR
	}, fe = {
		512: e.NEVER,
		519: e.ALWAYS,
		513: e.LESS,
		515: e.LEQUAL,
		514: e.EQUAL,
		518: e.GEQUAL,
		516: e.GREATER,
		517: e.NOTEQUAL
	};
	function me(n, a) {
		if (a.type === 1015 && t.has("OES_texture_float_linear") === !1 && (a.magFilter === 1006 || a.magFilter === 1007 || a.magFilter === 1005 || a.magFilter === 1008 || a.minFilter === 1006 || a.minFilter === 1007 || a.minFilter === 1005 || a.minFilter === 1008) && b("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."), e.texParameteri(n, e.TEXTURE_WRAP_S, M[a.wrapS]), e.texParameteri(n, e.TEXTURE_WRAP_T, M[a.wrapT]), (n === e.TEXTURE_3D || n === e.TEXTURE_2D_ARRAY) && e.texParameteri(n, e.TEXTURE_WRAP_R, M[a.wrapR]), e.texParameteri(n, e.TEXTURE_MAG_FILTER, de[a.magFilter]), e.texParameteri(n, e.TEXTURE_MIN_FILTER, de[a.minFilter]), a.compareFunction && (e.texParameteri(n, e.TEXTURE_COMPARE_MODE, e.COMPARE_REF_TO_TEXTURE), e.texParameteri(n, e.TEXTURE_COMPARE_FUNC, fe[a.compareFunction])), t.has("EXT_texture_filter_anisotropic") === !0) {
			if (a.magFilter === 1003 || a.minFilter !== 1005 && a.minFilter !== 1008 || a.type === 1015 && t.has("OES_texture_float_linear") === !1) return;
			if (a.anisotropy > 1 || r.get(a).__currentAnisotropy) {
				let o = t.get("EXT_texture_filter_anisotropic");
				e.texParameterf(n, o.TEXTURE_MAX_ANISOTROPY_EXT, Math.min(a.anisotropy, i.getMaxAnisotropy())), r.get(a).__currentAnisotropy = a.anisotropy;
			}
		}
	}
	function he(t, n) {
		let r = !1;
		t.__webglInit === void 0 && (t.__webglInit = !0, n.addEventListener("dispose", D));
		let i = n.source, a = p.get(i);
		a === void 0 && (a = {}, p.set(i, a));
		let s = oe(n);
		if (s !== t.__cacheKey) {
			a[s] === void 0 && (a[s] = {
				texture: e.createTexture(),
				usedTimes: 0
			}, o.memory.textures++, r = !0), a[s].usedTimes++;
			let i = a[t.__cacheKey];
			i !== void 0 && (a[t.__cacheKey].usedTimes--, i.usedTimes === 0 && k(n)), t.__cacheKey = s, t.__webglTexture = a[s].texture;
		}
		return r;
	}
	function ge(e, t, n) {
		return Math.floor(Math.floor(e / n) / t);
	}
	function ve(t, r, i, a) {
		let o = t.updateRanges;
		if (o.length === 0) n.texSubImage2D(e.TEXTURE_2D, 0, 0, 0, r.width, r.height, i, a, r.data);
		else {
			o.sort((e, t) => e.start - t.start);
			let s = 0;
			for (let e = 1; e < o.length; e++) {
				let t = o[s], n = o[e], i = t.start + t.count, a = ge(n.start, r.width, 4), c = ge(t.start, r.width, 4);
				n.start <= i + 1 && a === c && ge(n.start + n.count - 1, r.width, 4) === a ? t.count = Math.max(t.count, n.start + n.count - t.start) : (++s, o[s] = n);
			}
			o.length = s + 1;
			let c = n.getParameter(e.UNPACK_ROW_LENGTH), l = n.getParameter(e.UNPACK_SKIP_PIXELS), u = n.getParameter(e.UNPACK_SKIP_ROWS);
			n.pixelStorei(e.UNPACK_ROW_LENGTH, r.width);
			for (let t = 0, s = o.length; t < s; t++) {
				let s = o[t], c = Math.floor(s.start / 4), l = Math.ceil(s.count / 4), u = c % r.width, d = Math.floor(c / r.width), f = l;
				n.pixelStorei(e.UNPACK_SKIP_PIXELS, u), n.pixelStorei(e.UNPACK_SKIP_ROWS, d), n.texSubImage2D(e.TEXTURE_2D, 0, u, d, f, 1, i, a, r.data);
			}
			t.clearUpdateRanges(), n.pixelStorei(e.UNPACK_ROW_LENGTH, c), n.pixelStorei(e.UNPACK_SKIP_PIXELS, l), n.pixelStorei(e.UNPACK_SKIP_ROWS, u);
		}
	}
	function ye(t, o, s) {
		let c = e.TEXTURE_2D;
		(o.isDataArrayTexture || o.isCompressedArrayTexture) && (c = e.TEXTURE_2D_ARRAY), o.isData3DTexture && (c = e.TEXTURE_3D);
		let l = he(t, o), u = o.source;
		n.bindTexture(c, t.__webglTexture, e.TEXTURE0 + s);
		let f = r.get(u);
		if (u.version !== f.__version || l === !0) {
			if (n.activeTexture(e.TEXTURE0 + s), !(typeof ImageBitmap < "u" && o.image instanceof ImageBitmap)) {
				let t = Ze.getPrimaries(Ze.workingColorSpace), r = o.colorSpace === "" ? null : Ze.getPrimaries(o.colorSpace), i = o.colorSpace === "" || t === r ? e.NONE : e.BROWSER_DEFAULT_WEBGL;
				n.pixelStorei(e.UNPACK_FLIP_Y_WEBGL, o.flipY), n.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL, o.premultiplyAlpha), n.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL, i);
			}
			n.pixelStorei(e.UNPACK_ALIGNMENT, o.unpackAlignment);
			let t = g(o.image, !1, i.maxTextureSize);
			t = Pe(o, t);
			let r = a.convert(o.format, o.colorSpace), p = a.convert(o.type), m = C(o.internalFormat, r, p, o.normalized, o.colorSpace, o.isVideoTexture);
			me(c, o);
			let h, y = o.mipmaps, x = o.isVideoTexture !== !0, T = f.__version === void 0 || l === !0, D = u.dataReady, O = E(o, t);
			if (o.isDepthTexture) m = w(o.format === S, o.type), T && (x ? n.texStorage2D(e.TEXTURE_2D, 1, m, t.width, t.height) : n.texImage2D(e.TEXTURE_2D, 0, m, t.width, t.height, 0, r, p, null));
			else if (o.isDataTexture) {
				if (y.length > 0) {
					x && T && n.texStorage2D(e.TEXTURE_2D, O, m, y[0].width, y[0].height);
					for (let t = 0, i = y.length; t < i; t++) h = y[t], x ? D && n.texSubImage2D(e.TEXTURE_2D, t, 0, 0, h.width, h.height, r, p, h.data) : n.texImage2D(e.TEXTURE_2D, t, m, h.width, h.height, 0, r, p, h.data);
					o.generateMipmaps = !1;
				} else x ? (T && n.texStorage2D(e.TEXTURE_2D, O, m, t.width, t.height), D && ve(o, t, r, p)) : n.texImage2D(e.TEXTURE_2D, 0, m, t.width, t.height, 0, r, p, t.data);
			} else if (o.isCompressedTexture) {
				if (o.isCompressedArrayTexture) {
					x && T && n.texStorage3D(e.TEXTURE_2D_ARRAY, O, m, y[0].width, y[0].height, t.depth);
					for (let i = 0, a = y.length; i < a; i++) if (h = y[i], o.format !== 1023) {
						if (r !== null) {
							if (x) {
								if (D) {
									if (o.layerUpdates.size > 0) {
										let t = pe(h.width, h.height, o.format, o.type);
										for (let a of o.layerUpdates) {
											let o = h.data.subarray(a * t / h.data.BYTES_PER_ELEMENT, (a + 1) * t / h.data.BYTES_PER_ELEMENT);
											n.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY, i, 0, 0, a, h.width, h.height, 1, r, o);
										}
									} else n.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY, i, 0, 0, 0, h.width, h.height, t.depth, r, h.data);
								}
							} else n.compressedTexImage3D(e.TEXTURE_2D_ARRAY, i, m, h.width, h.height, t.depth, 0, h.data, 0, 0);
						} else b("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");
					} else x ? D && n.texSubImage3D(e.TEXTURE_2D_ARRAY, i, 0, 0, 0, h.width, h.height, t.depth, r, p, h.data) : n.texImage3D(e.TEXTURE_2D_ARRAY, i, m, h.width, h.height, t.depth, 0, r, p, h.data);
					o.layerUpdates.size > 0 && o.clearLayerUpdates();
				} else {
					x && T && n.texStorage2D(e.TEXTURE_2D, O, m, y[0].width, y[0].height);
					for (let t = 0, i = y.length; t < i; t++) h = y[t], o.format === 1023 ? x ? D && n.texSubImage2D(e.TEXTURE_2D, t, 0, 0, h.width, h.height, r, p, h.data) : n.texImage2D(e.TEXTURE_2D, t, m, h.width, h.height, 0, r, p, h.data) : r === null ? b("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()") : x ? D && n.compressedTexSubImage2D(e.TEXTURE_2D, t, 0, 0, h.width, h.height, r, h.data) : n.compressedTexImage2D(e.TEXTURE_2D, t, m, h.width, h.height, 0, h.data);
				}
			} else if (o.isDataArrayTexture) {
				if (x) {
					if (T && n.texStorage3D(e.TEXTURE_2D_ARRAY, O, m, t.width, t.height, t.depth), D) {
						if (o.layerUpdates.size > 0) {
							let i = pe(t.width, t.height, o.format, o.type);
							for (let a of o.layerUpdates) {
								let o = t.data.subarray(a * i / t.data.BYTES_PER_ELEMENT, (a + 1) * i / t.data.BYTES_PER_ELEMENT);
								n.texSubImage3D(e.TEXTURE_2D_ARRAY, 0, 0, 0, a, t.width, t.height, 1, r, p, o);
							}
							o.clearLayerUpdates();
						} else n.texSubImage3D(e.TEXTURE_2D_ARRAY, 0, 0, 0, 0, t.width, t.height, t.depth, r, p, t.data);
					}
				} else n.texImage3D(e.TEXTURE_2D_ARRAY, 0, m, t.width, t.height, t.depth, 0, r, p, t.data);
			} else if (o.isData3DTexture) x ? (T && n.texStorage3D(e.TEXTURE_3D, O, m, t.width, t.height, t.depth), D && n.texSubImage3D(e.TEXTURE_3D, 0, 0, 0, 0, t.width, t.height, t.depth, r, p, t.data)) : n.texImage3D(e.TEXTURE_3D, 0, m, t.width, t.height, t.depth, 0, r, p, t.data);
			else if (o.isFramebufferTexture) {
				if (T) {
					if (x) n.texStorage2D(e.TEXTURE_2D, O, m, t.width, t.height);
					else {
						let i = t.width, a = t.height;
						for (let t = 0; t < O; t++) n.texImage2D(e.TEXTURE_2D, t, m, i, a, 0, r, p, null), i >>= 1, a >>= 1;
					}
				}
			} else if (o.isHTMLTexture) {
				if ("texElementImage2D" in e) {
					let n = e.canvas;
					if (n.hasAttribute("layoutsubtree") || n.setAttribute("layoutsubtree", "true"), t.parentNode !== n) {
						n.appendChild(t), d.add(o), n.onpaint = (e) => {
							let t = e.changedElements;
							for (let e of d) t.includes(e.image) && (e.needsUpdate = !0);
						}, n.requestPaint();
						return;
					}
					if (e.texElementImage2D.length === 3) e.texElementImage2D(e.TEXTURE_2D, e.RGBA8, t);
					else {
						let n = e.RGBA, r = e.RGBA, i = e.UNSIGNED_BYTE;
						e.texElementImage2D(e.TEXTURE_2D, 0, n, r, i, t);
					}
					e.texParameteri(e.TEXTURE_2D, e.TEXTURE_MIN_FILTER, e.LINEAR), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_WRAP_S, e.CLAMP_TO_EDGE), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_WRAP_T, e.CLAMP_TO_EDGE);
				}
			} else if (y.length > 0) {
				if (x && T) {
					let t = R(y[0]);
					n.texStorage2D(e.TEXTURE_2D, O, m, t.width, t.height);
				}
				for (let t = 0, i = y.length; t < i; t++) h = y[t], x ? D && n.texSubImage2D(e.TEXTURE_2D, t, 0, 0, r, p, h) : n.texImage2D(e.TEXTURE_2D, t, m, r, p, h);
				o.generateMipmaps = !1;
			} else if (x) {
				if (T) {
					let r = R(t);
					n.texStorage2D(e.TEXTURE_2D, O, m, r.width, r.height);
				}
				D && n.texSubImage2D(e.TEXTURE_2D, 0, 0, 0, r, p, t);
			} else n.texImage2D(e.TEXTURE_2D, 0, m, r, p, t);
			_(o) && v(c), f.__version = u.version, o.onUpdate && o.onUpdate(o);
		}
		t.__version = o.version;
	}
	function be(t, o, s) {
		if (o.image.length !== 6) return;
		let c = he(t, o), l = o.source;
		n.bindTexture(e.TEXTURE_CUBE_MAP, t.__webglTexture, e.TEXTURE0 + s);
		let u = r.get(l);
		if (l.version !== u.__version || c === !0) {
			n.activeTexture(e.TEXTURE0 + s);
			let t = Ze.getPrimaries(Ze.workingColorSpace), r = o.colorSpace === "" ? null : Ze.getPrimaries(o.colorSpace), d = o.colorSpace === "" || t === r ? e.NONE : e.BROWSER_DEFAULT_WEBGL;
			n.pixelStorei(e.UNPACK_FLIP_Y_WEBGL, o.flipY), n.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL, o.premultiplyAlpha), n.pixelStorei(e.UNPACK_ALIGNMENT, o.unpackAlignment), n.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL, d);
			let f = o.isCompressedTexture || o.image[0].isCompressedTexture, p = o.image[0] && o.image[0].isDataTexture, m = [];
			for (let e = 0; e < 6; e++) !f && !p ? m[e] = g(o.image[e], !0, i.maxCubemapSize) : m[e] = p ? o.image[e].image : o.image[e], m[e] = Pe(o, m[e]);
			let h = m[0], y = a.convert(o.format, o.colorSpace), x = a.convert(o.type), S = C(o.internalFormat, y, x, o.normalized, o.colorSpace), w = o.isVideoTexture !== !0, T = u.__version === void 0 || c === !0, D = l.dataReady, O = E(o, h);
			me(e.TEXTURE_CUBE_MAP, o);
			let ee;
			if (f) {
				w && T && n.texStorage2D(e.TEXTURE_CUBE_MAP, O, S, h.width, h.height);
				for (let t = 0; t < 6; t++) {
					ee = m[t].mipmaps;
					for (let r = 0; r < ee.length; r++) {
						let i = ee[r];
						o.format === 1023 ? w ? D && n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + t, r, 0, 0, i.width, i.height, y, x, i.data) : n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + t, r, S, i.width, i.height, 0, y, x, i.data) : y === null ? b("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()") : w ? D && n.compressedTexSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + t, r, 0, 0, i.width, i.height, y, i.data) : n.compressedTexImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + t, r, S, i.width, i.height, 0, i.data);
					}
				}
			} else {
				if (ee = o.mipmaps, w && T) {
					ee.length > 0 && O++;
					let t = R(m[0]);
					n.texStorage2D(e.TEXTURE_CUBE_MAP, O, S, t.width, t.height);
				}
				for (let t = 0; t < 6; t++) if (p) {
					w ? D && n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + t, 0, 0, 0, m[t].width, m[t].height, y, x, m[t].data) : n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + t, 0, S, m[t].width, m[t].height, 0, y, x, m[t].data);
					for (let r = 0; r < ee.length; r++) {
						let i = ee[r].image[t].image;
						w ? D && n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + t, r + 1, 0, 0, i.width, i.height, y, x, i.data) : n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + t, r + 1, S, i.width, i.height, 0, y, x, i.data);
					}
				} else {
					w ? D && n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + t, 0, 0, 0, y, x, m[t]) : n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + t, 0, S, y, x, m[t]);
					for (let r = 0; r < ee.length; r++) {
						let i = ee[r];
						w ? D && n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + t, r + 1, 0, 0, y, x, i.image[t]) : n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + t, r + 1, S, y, x, i.image[t]);
					}
				}
			}
			_(o) && v(e.TEXTURE_CUBE_MAP), u.__version = l.version, o.onUpdate && o.onUpdate(o);
		}
		t.__version = o.version;
	}
	function xe(t, i, o, c, l, u) {
		let d = a.convert(o.format, o.colorSpace), f = a.convert(o.type), p = C(o.internalFormat, d, f, o.normalized, o.colorSpace), m = r.get(i), h = r.get(o);
		if (h.__renderTarget = i, !m.__hasExternalTextures) {
			let t = Math.max(1, i.width >> u), r = Math.max(1, i.height >> u);
			l === e.TEXTURE_3D || l === e.TEXTURE_2D_ARRAY ? n.texImage3D(l, u, p, t, r, i.depth, 0, d, f, null) : n.texImage2D(l, u, p, t, r, 0, d, f, null);
		}
		n.bindFramebuffer(e.FRAMEBUFFER, t), I(i) ? s.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER, c, l, h.__webglTexture, 0, F(i)) : (l === e.TEXTURE_2D || l >= e.TEXTURE_CUBE_MAP_POSITIVE_X && l <= e.TEXTURE_CUBE_MAP_NEGATIVE_Z) && e.framebufferTexture2D(e.FRAMEBUFFER, c, l, h.__webglTexture, u), n.bindFramebuffer(e.FRAMEBUFFER, null);
	}
	function Se(t, n, r) {
		if (e.bindRenderbuffer(e.RENDERBUFFER, t), n.depthBuffer) {
			let i = n.depthTexture, a = i && i.isDepthTexture ? i.type : null, o = w(n.stencilBuffer, a), c = n.stencilBuffer ? e.DEPTH_STENCIL_ATTACHMENT : e.DEPTH_ATTACHMENT;
			I(n) ? s.renderbufferStorageMultisampleEXT(e.RENDERBUFFER, F(n), o, n.width, n.height) : r ? e.renderbufferStorageMultisample(e.RENDERBUFFER, F(n), o, n.width, n.height) : e.renderbufferStorage(e.RENDERBUFFER, o, n.width, n.height), e.framebufferRenderbuffer(e.FRAMEBUFFER, c, e.RENDERBUFFER, t);
		} else {
			let t = n.textures;
			for (let i = 0; i < t.length; i++) {
				let o = t[i], c = a.convert(o.format, o.colorSpace), l = a.convert(o.type), u = C(o.internalFormat, c, l, o.normalized, o.colorSpace);
				I(n) ? s.renderbufferStorageMultisampleEXT(e.RENDERBUFFER, F(n), u, n.width, n.height) : r ? e.renderbufferStorageMultisample(e.RENDERBUFFER, F(n), u, n.width, n.height) : e.renderbufferStorage(e.RENDERBUFFER, u, n.width, n.height);
			}
		}
		e.bindRenderbuffer(e.RENDERBUFFER, null);
	}
	function N(t, i, o) {
		let c = i.isWebGLCubeRenderTarget === !0;
		if (n.bindFramebuffer(e.FRAMEBUFFER, t), !(i.depthTexture && i.depthTexture.isDepthTexture)) throw Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");
		let l = r.get(i.depthTexture);
		if (l.__renderTarget = i, (!l.__webglTexture || i.depthTexture.image.width !== i.width || i.depthTexture.image.height !== i.height) && (i.depthTexture.image.width = i.width, i.depthTexture.image.height = i.height, i.depthTexture.needsUpdate = !0), c) {
			if (l.__webglInit === void 0 && (l.__webglInit = !0, i.depthTexture.addEventListener("dispose", D)), l.__webglTexture === void 0) {
				l.__webglTexture = e.createTexture(), n.bindTexture(e.TEXTURE_CUBE_MAP, l.__webglTexture), me(e.TEXTURE_CUBE_MAP, i.depthTexture);
				let t = a.convert(i.depthTexture.format), r = a.convert(i.depthTexture.type), o;
				i.depthTexture.format === 1026 ? o = e.DEPTH_COMPONENT24 : i.depthTexture.format === 1027 && (o = e.DEPTH24_STENCIL8);
				for (let n = 0; n < 6; n++) e.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + n, 0, o, i.width, i.height, 0, t, r, null);
			}
		} else se(i.depthTexture, 0);
		let u = l.__webglTexture, d = F(i), f = c ? e.TEXTURE_CUBE_MAP_POSITIVE_X + o : e.TEXTURE_2D, p = i.depthTexture.format === 1027 ? e.DEPTH_STENCIL_ATTACHMENT : e.DEPTH_ATTACHMENT;
		if (i.depthTexture.format === 1026) I(i) ? s.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER, p, f, u, 0, d) : e.framebufferTexture2D(e.FRAMEBUFFER, p, f, u, 0);
		else if (i.depthTexture.format === 1027) I(i) ? s.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER, p, f, u, 0, d) : e.framebufferTexture2D(e.FRAMEBUFFER, p, f, u, 0);
		else throw Error("THREE.WebGLTextures: Unknown depthTexture format.");
	}
	function Ce(t) {
		let i = r.get(t), a = t.isWebGLCubeRenderTarget === !0;
		if (i.__boundDepthTexture !== t.depthTexture) {
			let e = t.depthTexture;
			if (i.__depthDisposeCallback && i.__depthDisposeCallback(), e) {
				let t = () => {
					delete i.__boundDepthTexture, delete i.__depthDisposeCallback, e.removeEventListener("dispose", t);
				};
				e.addEventListener("dispose", t), i.__depthDisposeCallback = t;
			}
			i.__boundDepthTexture = e;
		}
		if (t.depthTexture && !i.__autoAllocateDepthBuffer) {
			if (a) for (let e = 0; e < 6; e++) N(i.__webglFramebuffer[e], t, e);
			else {
				let e = t.texture.mipmaps;
				e && e.length > 0 ? N(i.__webglFramebuffer[0], t, 0) : N(i.__webglFramebuffer, t, 0);
			}
		} else if (a) {
			i.__webglDepthbuffer = [];
			for (let r = 0; r < 6; r++) if (n.bindFramebuffer(e.FRAMEBUFFER, i.__webglFramebuffer[r]), i.__webglDepthbuffer[r] === void 0) i.__webglDepthbuffer[r] = e.createRenderbuffer(), Se(i.__webglDepthbuffer[r], t, !1);
			else {
				let n = t.stencilBuffer ? e.DEPTH_STENCIL_ATTACHMENT : e.DEPTH_ATTACHMENT, a = i.__webglDepthbuffer[r];
				e.bindRenderbuffer(e.RENDERBUFFER, a), e.framebufferRenderbuffer(e.FRAMEBUFFER, n, e.RENDERBUFFER, a);
			}
		} else {
			let r = t.texture.mipmaps;
			if (r && r.length > 0 ? n.bindFramebuffer(e.FRAMEBUFFER, i.__webglFramebuffer[0]) : n.bindFramebuffer(e.FRAMEBUFFER, i.__webglFramebuffer), i.__webglDepthbuffer === void 0) i.__webglDepthbuffer = e.createRenderbuffer(), Se(i.__webglDepthbuffer, t, !1);
			else {
				let n = t.stencilBuffer ? e.DEPTH_STENCIL_ATTACHMENT : e.DEPTH_ATTACHMENT, r = i.__webglDepthbuffer;
				e.bindRenderbuffer(e.RENDERBUFFER, r), e.framebufferRenderbuffer(e.FRAMEBUFFER, n, e.RENDERBUFFER, r);
			}
		}
		n.bindFramebuffer(e.FRAMEBUFFER, null);
	}
	function Te(t, n, i) {
		let a = r.get(t);
		n !== void 0 && xe(a.__webglFramebuffer, t, t.texture, e.COLOR_ATTACHMENT0, e.TEXTURE_2D, 0), i !== void 0 && Ce(t);
	}
	function De(t) {
		let i = t.texture, s = r.get(t), c = r.get(i);
		t.addEventListener("dispose", O);
		let l = t.textures, u = t.isWebGLCubeRenderTarget === !0, d = l.length > 1;
		if (d || (c.__webglTexture === void 0 && (c.__webglTexture = e.createTexture()), c.__version = i.version, o.memory.textures++), u) {
			s.__webglFramebuffer = [];
			for (let t = 0; t < 6; t++) if (i.mipmaps && i.mipmaps.length > 0) {
				s.__webglFramebuffer[t] = [];
				for (let n = 0; n < i.mipmaps.length; n++) s.__webglFramebuffer[t][n] = e.createFramebuffer();
			} else s.__webglFramebuffer[t] = e.createFramebuffer();
		} else {
			if (i.mipmaps && i.mipmaps.length > 0) {
				s.__webglFramebuffer = [];
				for (let t = 0; t < i.mipmaps.length; t++) s.__webglFramebuffer[t] = e.createFramebuffer();
			} else s.__webglFramebuffer = e.createFramebuffer();
			if (d) for (let t = 0, n = l.length; t < n; t++) {
				let n = r.get(l[t]);
				n.__webglTexture === void 0 && (n.__webglTexture = e.createTexture(), o.memory.textures++);
			}
			if (t.samples > 0 && I(t) === !1) {
				s.__webglMultisampledFramebuffer = e.createFramebuffer(), s.__webglColorRenderbuffer = [], n.bindFramebuffer(e.FRAMEBUFFER, s.__webglMultisampledFramebuffer);
				for (let n = 0; n < l.length; n++) {
					let r = l[n];
					s.__webglColorRenderbuffer[n] = e.createRenderbuffer(), e.bindRenderbuffer(e.RENDERBUFFER, s.__webglColorRenderbuffer[n]);
					let i = a.convert(r.format, r.colorSpace), o = a.convert(r.type), c = C(r.internalFormat, i, o, r.normalized, r.colorSpace, t.isXRRenderTarget === !0), u = F(t);
					e.renderbufferStorageMultisample(e.RENDERBUFFER, u, c, t.width, t.height), e.framebufferRenderbuffer(e.FRAMEBUFFER, e.COLOR_ATTACHMENT0 + n, e.RENDERBUFFER, s.__webglColorRenderbuffer[n]);
				}
				e.bindRenderbuffer(e.RENDERBUFFER, null), t.depthBuffer && (s.__webglDepthRenderbuffer = e.createRenderbuffer(), Se(s.__webglDepthRenderbuffer, t, !0)), n.bindFramebuffer(e.FRAMEBUFFER, null);
			}
		}
		if (u) {
			n.bindTexture(e.TEXTURE_CUBE_MAP, c.__webglTexture), me(e.TEXTURE_CUBE_MAP, i);
			for (let n = 0; n < 6; n++) if (i.mipmaps && i.mipmaps.length > 0) for (let r = 0; r < i.mipmaps.length; r++) xe(s.__webglFramebuffer[n][r], t, i, e.COLOR_ATTACHMENT0, e.TEXTURE_CUBE_MAP_POSITIVE_X + n, r);
			else xe(s.__webglFramebuffer[n], t, i, e.COLOR_ATTACHMENT0, e.TEXTURE_CUBE_MAP_POSITIVE_X + n, 0);
			_(i) && v(e.TEXTURE_CUBE_MAP), n.unbindTexture();
		} else if (d) {
			for (let i = 0, a = l.length; i < a; i++) {
				let a = l[i], o = r.get(a), c = e.TEXTURE_2D;
				(t.isWebGL3DRenderTarget || t.isWebGLArrayRenderTarget) && (c = t.isWebGL3DRenderTarget ? e.TEXTURE_3D : e.TEXTURE_2D_ARRAY), n.bindTexture(c, o.__webglTexture), me(c, a), xe(s.__webglFramebuffer, t, a, e.COLOR_ATTACHMENT0 + i, c, 0), _(a) && v(c);
			}
			n.unbindTexture();
		} else {
			let r = e.TEXTURE_2D;
			if ((t.isWebGL3DRenderTarget || t.isWebGLArrayRenderTarget) && (r = t.isWebGL3DRenderTarget ? e.TEXTURE_3D : e.TEXTURE_2D_ARRAY), n.bindTexture(r, c.__webglTexture), me(r, i), i.mipmaps && i.mipmaps.length > 0) for (let n = 0; n < i.mipmaps.length; n++) xe(s.__webglFramebuffer[n], t, i, e.COLOR_ATTACHMENT0, r, n);
			else xe(s.__webglFramebuffer, t, i, e.COLOR_ATTACHMENT0, r, 0);
			_(i) && v(r), n.unbindTexture();
		}
		t.depthBuffer && Ce(t);
	}
	function Oe(e) {
		let t = e.textures;
		for (let i = 0, a = t.length; i < a; i++) {
			let a = t[i];
			if (_(a)) {
				let t = y(e), i = r.get(a).__webglTexture;
				n.bindTexture(t, i), v(t), n.unbindTexture();
			}
		}
	}
	let ke = [], Me = [];
	function Ne(t) {
		if (t.samples > 0) {
			if (I(t) === !1) {
				let i = t.textures, a = t.width, o = t.height, s = e.COLOR_BUFFER_BIT, l = t.stencilBuffer ? e.DEPTH_STENCIL_ATTACHMENT : e.DEPTH_ATTACHMENT, u = r.get(t), d = i.length > 1;
				if (d) for (let t = 0; t < i.length; t++) n.bindFramebuffer(e.FRAMEBUFFER, u.__webglMultisampledFramebuffer), e.framebufferRenderbuffer(e.FRAMEBUFFER, e.COLOR_ATTACHMENT0 + t, e.RENDERBUFFER, null), n.bindFramebuffer(e.FRAMEBUFFER, u.__webglFramebuffer), e.framebufferTexture2D(e.DRAW_FRAMEBUFFER, e.COLOR_ATTACHMENT0 + t, e.TEXTURE_2D, null, 0);
				n.bindFramebuffer(e.READ_FRAMEBUFFER, u.__webglMultisampledFramebuffer);
				let f = t.texture.mipmaps;
				f && f.length > 0 ? n.bindFramebuffer(e.DRAW_FRAMEBUFFER, u.__webglFramebuffer[0]) : n.bindFramebuffer(e.DRAW_FRAMEBUFFER, u.__webglFramebuffer);
				for (let n = 0; n < i.length; n++) {
					if (t.resolveDepthBuffer && (t.depthBuffer && (s |= e.DEPTH_BUFFER_BIT), t.stencilBuffer && t.resolveStencilBuffer && (s |= e.STENCIL_BUFFER_BIT)), d) {
						e.framebufferRenderbuffer(e.READ_FRAMEBUFFER, e.COLOR_ATTACHMENT0, e.RENDERBUFFER, u.__webglColorRenderbuffer[n]);
						let t = r.get(i[n]).__webglTexture;
						e.framebufferTexture2D(e.DRAW_FRAMEBUFFER, e.COLOR_ATTACHMENT0, e.TEXTURE_2D, t, 0);
					}
					e.blitFramebuffer(0, 0, a, o, 0, 0, a, o, s, e.NEAREST), c === !0 && (ke.length = 0, Me.length = 0, ke.push(e.COLOR_ATTACHMENT0 + n), t.depthBuffer && t.storeMultisampledDepthBuffer === !1 && (ke.push(l), Me.push(l), e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER, Me)), e.invalidateFramebuffer(e.READ_FRAMEBUFFER, ke));
				}
				if (n.bindFramebuffer(e.READ_FRAMEBUFFER, null), n.bindFramebuffer(e.DRAW_FRAMEBUFFER, null), d) for (let t = 0; t < i.length; t++) {
					n.bindFramebuffer(e.FRAMEBUFFER, u.__webglMultisampledFramebuffer), e.framebufferRenderbuffer(e.FRAMEBUFFER, e.COLOR_ATTACHMENT0 + t, e.RENDERBUFFER, u.__webglColorRenderbuffer[t]);
					let a = r.get(i[t]).__webglTexture;
					n.bindFramebuffer(e.FRAMEBUFFER, u.__webglFramebuffer), e.framebufferTexture2D(e.DRAW_FRAMEBUFFER, e.COLOR_ATTACHMENT0 + t, e.TEXTURE_2D, a, 0);
				}
				n.bindFramebuffer(e.DRAW_FRAMEBUFFER, u.__webglMultisampledFramebuffer);
			} else if (t.depthBuffer && t.storeMultisampledDepthBuffer === !1 && c) {
				let n = t.stencilBuffer ? e.DEPTH_STENCIL_ATTACHMENT : e.DEPTH_ATTACHMENT;
				e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER, [n]);
			}
		}
	}
	function F(e) {
		return Math.min(i.maxSamples, e.samples);
	}
	function I(e) {
		let n = r.get(e);
		return e.samples > 0 && t.has("WEBGL_multisampled_render_to_texture") === !0 && n.__useRenderToTexture !== !1;
	}
	function L(e) {
		let t = o.render.frame;
		u.get(e) !== t && (u.set(e, t), e.update());
	}
	function Pe(e, t) {
		let n = e.colorSpace, r = e.format, i = e.type;
		return e.isCompressedTexture === !0 || e.isVideoTexture === !0 || n !== "srgb-linear" && n !== "" && (Ze.getTransfer(n) === "srgb" ? (r !== 1023 || i !== 1009) && b("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType.") : mt("WebGLTextures: Unsupported texture color space:", n)), t;
	}
	function R(e) {
		return typeof HTMLImageElement < "u" && e instanceof HTMLImageElement ? (l.width = e.naturalWidth || e.width, l.height = e.naturalHeight || e.height) : typeof VideoFrame < "u" && e instanceof VideoFrame ? (l.width = e.displayWidth, l.height = e.displayHeight) : (l.width = e.width, l.height = e.height), l;
	}
	this.allocateTextureUnit = ae, this.resetTextureUnits = ne, this.getTextureUnits = re, this.setTextureUnits = ie, this.setTexture2D = se, this.setTexture2DArray = le, this.setTexture3D = ue, this.setTextureCube = j, this.rebindTextures = Te, this.setupRenderTarget = De, this.updateRenderTargetMipmap = Oe, this.updateMultisampleRenderTarget = Ne, this.setupDepthRenderbuffer = Ce, this.setupFrameBufferTexture = xe, this.useMultisampledRTT = I, this.isReversedDepthBuffer = function() {
		return n.buffers.depth.getReversed();
	};
}
function _a(e, t) {
	function n(n, r = "") {
		let i, a = Ze.getTransfer(r);
		if (n === 1009) return e.UNSIGNED_BYTE;
		if (n === 1017) return e.UNSIGNED_SHORT_4_4_4_4;
		if (n === 1018) return e.UNSIGNED_SHORT_5_5_5_1;
		if (n === 35902) return e.UNSIGNED_INT_5_9_9_9_REV;
		if (n === 35899) return e.UNSIGNED_INT_10F_11F_11F_REV;
		if (n === 1010) return e.BYTE;
		if (n === 1011) return e.SHORT;
		if (n === 1012) return e.UNSIGNED_SHORT;
		if (n === 1013) return e.INT;
		if (n === 1014) return e.UNSIGNED_INT;
		if (n === 1015) return e.FLOAT;
		if (n === 1016) return e.HALF_FLOAT;
		if (n === 1021) return e.ALPHA;
		if (n === 1022) return e.RGB;
		if (n === 1023) return e.RGBA;
		if (n === 1026) return e.DEPTH_COMPONENT;
		if (n === 1027) return e.DEPTH_STENCIL;
		if (n === 1028) return e.RED;
		if (n === 1029) return e.RED_INTEGER;
		if (n === 1030) return e.RG;
		if (n === 1031) return e.RG_INTEGER;
		if (n === 1033) return e.RGBA_INTEGER;
		if (n === 33776 || n === 33777 || n === 33778 || n === 33779) {
			if (a === "srgb") {
				if (i = t.get("WEBGL_compressed_texture_s3tc_srgb"), i !== null) {
					if (n === 33776) return i.COMPRESSED_SRGB_S3TC_DXT1_EXT;
					if (n === 33777) return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;
					if (n === 33778) return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;
					if (n === 33779) return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT;
				} else return null;
			} else if (i = t.get("WEBGL_compressed_texture_s3tc"), i !== null) {
				if (n === 33776) return i.COMPRESSED_RGB_S3TC_DXT1_EXT;
				if (n === 33777) return i.COMPRESSED_RGBA_S3TC_DXT1_EXT;
				if (n === 33778) return i.COMPRESSED_RGBA_S3TC_DXT3_EXT;
				if (n === 33779) return i.COMPRESSED_RGBA_S3TC_DXT5_EXT;
			} else return null;
		}
		if (n === 35840 || n === 35841 || n === 35842 || n === 35843) {
			if (i = t.get("WEBGL_compressed_texture_pvrtc"), i !== null) {
				if (n === 35840) return i.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;
				if (n === 35841) return i.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;
				if (n === 35842) return i.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;
				if (n === 35843) return i.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG;
			} else return null;
		}
		if (n === 36196 || n === 37492 || n === 37496 || n === 37488 || n === 37489 || n === 37490 || n === 37491) {
			if (i = t.get("WEBGL_compressed_texture_etc"), i !== null) {
				if (n === 36196 || n === 37492) return a === "srgb" ? i.COMPRESSED_SRGB8_ETC2 : i.COMPRESSED_RGB8_ETC2;
				if (n === 37496) return a === "srgb" ? i.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC : i.COMPRESSED_RGBA8_ETC2_EAC;
				if (n === 37488) return i.COMPRESSED_R11_EAC;
				if (n === 37489) return i.COMPRESSED_SIGNED_R11_EAC;
				if (n === 37490) return i.COMPRESSED_RG11_EAC;
				if (n === 37491) return i.COMPRESSED_SIGNED_RG11_EAC;
			} else return null;
		}
		if (n === 37808 || n === 37809 || n === 37810 || n === 37811 || n === 37812 || n === 37813 || n === 37814 || n === 37815 || n === 37816 || n === 37817 || n === 37818 || n === 37819 || n === 37820 || n === 37821) {
			if (i = t.get("WEBGL_compressed_texture_astc"), i !== null) {
				if (n === 37808) return a === "srgb" ? i.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR : i.COMPRESSED_RGBA_ASTC_4x4_KHR;
				if (n === 37809) return a === "srgb" ? i.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR : i.COMPRESSED_RGBA_ASTC_5x4_KHR;
				if (n === 37810) return a === "srgb" ? i.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR : i.COMPRESSED_RGBA_ASTC_5x5_KHR;
				if (n === 37811) return a === "srgb" ? i.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR : i.COMPRESSED_RGBA_ASTC_6x5_KHR;
				if (n === 37812) return a === "srgb" ? i.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR : i.COMPRESSED_RGBA_ASTC_6x6_KHR;
				if (n === 37813) return a === "srgb" ? i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR : i.COMPRESSED_RGBA_ASTC_8x5_KHR;
				if (n === 37814) return a === "srgb" ? i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR : i.COMPRESSED_RGBA_ASTC_8x6_KHR;
				if (n === 37815) return a === "srgb" ? i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR : i.COMPRESSED_RGBA_ASTC_8x8_KHR;
				if (n === 37816) return a === "srgb" ? i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR : i.COMPRESSED_RGBA_ASTC_10x5_KHR;
				if (n === 37817) return a === "srgb" ? i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR : i.COMPRESSED_RGBA_ASTC_10x6_KHR;
				if (n === 37818) return a === "srgb" ? i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR : i.COMPRESSED_RGBA_ASTC_10x8_KHR;
				if (n === 37819) return a === "srgb" ? i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR : i.COMPRESSED_RGBA_ASTC_10x10_KHR;
				if (n === 37820) return a === "srgb" ? i.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR : i.COMPRESSED_RGBA_ASTC_12x10_KHR;
				if (n === 37821) return a === "srgb" ? i.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR : i.COMPRESSED_RGBA_ASTC_12x12_KHR;
			} else return null;
		}
		if (n === 36492 || n === 36494 || n === 36495) {
			if (i = t.get("EXT_texture_compression_bptc"), i !== null) {
				if (n === 36492) return a === "srgb" ? i.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT : i.COMPRESSED_RGBA_BPTC_UNORM_EXT;
				if (n === 36494) return i.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;
				if (n === 36495) return i.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT;
			} else return null;
		}
		if (n === 36283 || n === 36284 || n === 36285 || n === 36286) {
			if (i = t.get("EXT_texture_compression_rgtc"), i !== null) {
				if (n === 36283) return i.COMPRESSED_RED_RGTC1_EXT;
				if (n === 36284) return i.COMPRESSED_SIGNED_RED_RGTC1_EXT;
				if (n === 36285) return i.COMPRESSED_RED_GREEN_RGTC2_EXT;
				if (n === 36286) return i.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT;
			} else return null;
		}
		return n === 1020 ? e.UNSIGNED_INT_24_8 : e[n] === void 0 ? null : e[n];
	}
	return { convert: n };
}
var va = "\nvoid main() {\n\n	gl_Position = vec4( position, 1.0 );\n\n}", ya = "\nuniform sampler2DArray depthColor;\nuniform float depthWidth;\nuniform float depthHeight;\n\nvoid main() {\n\n	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );\n\n	if ( coord.x >= 1.0 ) {\n\n		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;\n\n	} else {\n\n		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;\n\n	}\n\n}", ba = class {
	constructor() {
		this.texture = null, this.mesh = null, this.depthNear = 0, this.depthFar = 0;
	}
	init(e, t) {
		if (this.texture === null) {
			let n = new ne(e.texture);
			(e.depthNear !== t.depthNear || e.depthFar !== t.depthFar) && (this.depthNear = e.depthNear, this.depthFar = e.depthFar), this.texture = n;
		}
	}
	getMesh(e) {
		if (this.texture !== null && this.mesh === null) {
			let t = e.cameras[0].viewport, n = new m({
				vertexShader: va,
				fragmentShader: ya,
				uniforms: {
					depthColor: { value: this.texture },
					depthWidth: { value: t.z },
					depthHeight: { value: t.w }
				}
			});
			this.mesh = new N(new D(20, 20), n);
		}
		return this.mesh;
	}
	reset() {
		this.texture = null, this.mesh = null;
	}
	getDepthTexture() {
		return this.texture;
	}
}, xa = class extends V {
	constructor(e, t) {
		super();
		let n = this, r = null, i = 1, a = null, o = "local-floor", s = 1, c = null, l = null, u = null, d = null, f = null, p = null, m = typeof XRWebGLBinding < "u", h = new ba(), g = {}, _ = t.getContextAttributes(), y = null, x = null, C = [], w = [], T = new P(), E = null, D = null, O = new ae();
		O.viewport = new Qe();
		let ee = new ae();
		ee.viewport = new Qe();
		let k = [O, ee], A = new ze(), te = null, re = null;
		this.cameraAutoUpdate = !0, this.enabled = !1, this.isPresenting = !1, this.getController = function(e) {
			let t = C[e];
			return t === void 0 && (t = new Se(), C[e] = t), t.getTargetRaySpace();
		}, this.getControllerGrip = function(e) {
			let t = C[e];
			return t === void 0 && (t = new Se(), C[e] = t), t.getGripSpace();
		}, this.getHand = function(e) {
			let t = C[e];
			return t === void 0 && (t = new Se(), C[e] = t), t.getHandSpace();
		};
		function ie(e) {
			let t = w.indexOf(e.inputSource);
			if (t === -1) return;
			let n = C[t];
			n !== void 0 && (n.update(e.inputSource, e.frame, c || a), n.dispatchEvent({
				type: e.type,
				data: e.inputSource
			}));
		}
		function oe() {
			r.removeEventListener("select", ie), r.removeEventListener("selectstart", ie), r.removeEventListener("selectend", ie), r.removeEventListener("squeeze", ie), r.removeEventListener("squeezestart", ie), r.removeEventListener("squeezeend", ie), r.removeEventListener("end", oe), r.removeEventListener("inputsourceschange", se);
			for (let e = 0; e < C.length; e++) {
				let t = w[e];
				t !== null && (w[e] = null, C[e].disconnect(t));
			}
			te = null, re = null, h.reset();
			for (let e in g) delete g[e];
			if (e.setRenderTarget(y), f = null, d = null, u = null, r = null, x = null, pe.stop(), n.isPresenting = !1, e.setPixelRatio(E), e.setSize(T.width, T.height, !1), D !== null) {
				let e = D.camera;
				e.fov = D.fov, e.zoom = D.zoom, e.updateProjectionMatrix(), D = null;
			}
			n.dispatchEvent({ type: "sessionend" });
		}
		this.setFramebufferScaleFactor = function(e) {
			i = e, n.isPresenting === !0 && b("WebXRManager: Cannot change framebuffer scale while presenting.");
		}, this.setReferenceSpaceType = function(e) {
			o = e, n.isPresenting === !0 && b("WebXRManager: Cannot change reference space type while presenting.");
		}, this.getReferenceSpace = function() {
			return c || a;
		}, this.setReferenceSpace = function(e) {
			c = e;
		}, this.getBaseLayer = function() {
			return d === null ? f : d;
		}, this.getBinding = function() {
			return u === null && m && (u = new XRWebGLBinding(r, t)), u;
		}, this.getFrame = function() {
			return p;
		}, this.getSession = function() {
			return r;
		}, this.setSession = async function(l) {
			if (r = l, r !== null) {
				if (y = e.getRenderTarget(), r.addEventListener("select", ie), r.addEventListener("selectstart", ie), r.addEventListener("selectend", ie), r.addEventListener("squeeze", ie), r.addEventListener("squeezestart", ie), r.addEventListener("squeezeend", ie), r.addEventListener("end", oe), r.addEventListener("inputsourceschange", se), _.xrCompatible !== !0 && await t.makeXRCompatible(), E = e.getPixelRatio(), e.getSize(T), m && "createProjectionLayer" in XRWebGLBinding.prototype) {
					let n = null, a = null, o = null;
					_.depth && (o = _.stencil ? t.DEPTH24_STENCIL8 : t.DEPTH_COMPONENT24, n = _.stencil ? S : me, a = _.stencil ? Ce : it);
					let s = {
						colorFormat: t.RGBA8,
						depthFormat: o,
						scaleFactor: i
					};
					u = this.getBinding(), d = u.createProjectionLayer(s), r.updateRenderState({ layers: [d] }), e.setPixelRatio(1), e.setSize(d.textureWidth, d.textureHeight, !1), x = new Fe(d.textureWidth, d.textureHeight, {
						format: et,
						type: tt,
						depthTexture: new v(d.textureWidth, d.textureHeight, a, void 0, void 0, void 0, void 0, void 0, void 0, n),
						stencilBuffer: _.stencil,
						colorSpace: e.outputColorSpace,
						samples: _.antialias ? 4 : 0,
						resolveDepthBuffer: d.ignoreDepthValues === !1,
						resolveStencilBuffer: d.ignoreDepthValues === !1,
						storeMultisampledDepthBuffer: d.ignoreDepthValues === !1,
						storeMultisampledStencilBuffer: d.ignoreDepthValues === !1
					});
				} else {
					let n = {
						antialias: _.antialias,
						alpha: !0,
						depth: _.depth,
						stencil: _.stencil,
						framebufferScaleFactor: i
					};
					f = new XRWebGLLayer(r, t, n), r.updateRenderState({ baseLayer: f }), e.setPixelRatio(1), e.setSize(f.framebufferWidth, f.framebufferHeight, !1), x = new Fe(f.framebufferWidth, f.framebufferHeight, {
						format: et,
						type: tt,
						colorSpace: e.outputColorSpace,
						stencilBuffer: _.stencil,
						resolveDepthBuffer: f.ignoreDepthValues === !1,
						resolveStencilBuffer: f.ignoreDepthValues === !1,
						storeMultisampledDepthBuffer: f.ignoreDepthValues === !1,
						storeMultisampledStencilBuffer: f.ignoreDepthValues === !1
					});
				}
				x.isXRRenderTarget = !0, this.setFoveation(s), c = null, a = await r.requestReferenceSpace(o), pe.setContext(r), pe.start(), n.isPresenting = !0, n.dispatchEvent({ type: "sessionstart" });
			}
		}, this.getEnvironmentBlendMode = function() {
			if (r !== null) return r.environmentBlendMode;
		}, this.getDepthTexture = function() {
			return h.getDepthTexture();
		};
		function se(e) {
			for (let t = 0; t < e.removed.length; t++) {
				let n = e.removed[t], r = w.indexOf(n);
				r >= 0 && (w[r] = null, C[r].disconnect(n));
			}
			for (let t = 0; t < e.added.length; t++) {
				let n = e.added[t], r = w.indexOf(n);
				if (r === -1) {
					for (let e = 0; e < C.length; e++) if (e >= w.length) {
						w.push(n), r = e;
						break;
					} else if (w[e] === null) {
						w[e] = n, r = e;
						break;
					}
					if (r === -1) break;
				}
				let i = C[r];
				i && i.connect(n);
			}
		}
		let ce = new L(), le = new L();
		function ue(e, t, n) {
			ce.setFromMatrixPosition(t.matrixWorld), le.setFromMatrixPosition(n.matrixWorld);
			let r = ce.distanceTo(le), i = t.projectionMatrix.elements, a = n.projectionMatrix.elements, o = i[14] / (i[10] - 1), s = i[14] / (i[10] + 1), c = (i[9] + 1) / i[5], l = (i[9] - 1) / i[5], u = (i[8] - 1) / i[0], d = (a[8] + 1) / a[0], f = o * u, p = o * d, m = r / (-u + d), h = m * -u;
			if (t.matrixWorld.decompose(e.position, e.quaternion, e.scale), e.translateX(h), e.translateZ(m), e.matrixWorld.compose(e.position, e.quaternion, e.scale), e.matrixWorldInverse.copy(e.matrixWorld).invert(), i[10] === -1) e.projectionMatrix.copy(t.projectionMatrix), e.projectionMatrixInverse.copy(t.projectionMatrixInverse);
			else {
				let t = o + m, n = s + m, i = f - h, a = p + (r - h), u = c * s / n * t, d = l * s / n * t;
				e.projectionMatrix.makePerspective(i, a, u, d, t, n), e.projectionMatrixInverse.copy(e.projectionMatrix).invert();
			}
		}
		function j(e, t) {
			t === null ? e.matrixWorld.copy(e.matrix) : e.matrixWorld.multiplyMatrices(t.matrixWorld, e.matrix), e.matrixWorldInverse.copy(e.matrixWorld).invert();
		}
		this.updateCamera = function(e) {
			if (r === null) return;
			let t = e.near, n = e.far;
			h.texture !== null && (h.depthNear > 0 && (t = h.depthNear), h.depthFar > 0 && (n = h.depthFar)), A.near = ee.near = O.near = t, A.far = ee.far = O.far = n, (te !== A.near || re !== A.far) && (r.updateRenderState({
				depthNear: A.near,
				depthFar: A.far
			}), te = A.near, re = A.far), A.layers.mask = e.layers.mask | 6, O.layers.mask = A.layers.mask & -5, ee.layers.mask = A.layers.mask & -3;
			let i = e.parent, a = A.cameras;
			j(A, i);
			for (let e = 0; e < a.length; e++) j(a[e], i);
			a.length === 2 ? ue(A, O, ee) : A.projectionMatrix.copy(O.projectionMatrix), D === null && e.isPerspectiveCamera && (D = {
				camera: e,
				fov: e.fov,
				zoom: e.zoom
			}), M(e, A, i);
		};
		function M(e, t, n) {
			n === null ? e.matrix.copy(t.matrixWorld) : (e.matrix.copy(n.matrixWorld), e.matrix.invert(), e.matrix.multiply(t.matrixWorld)), e.matrix.decompose(e.position, e.quaternion, e.scale), e.updateMatrixWorld(!0), e.projectionMatrix.copy(t.projectionMatrix), e.projectionMatrixInverse.copy(t.projectionMatrixInverse), e.isPerspectiveCamera && (e.fov = ve * 2 * Math.atan(1 / e.projectionMatrix.elements[5]), e.zoom = 1);
		}
		this.getCamera = function() {
			return A;
		}, this.getFoveation = function() {
			if (d !== null || f !== null) return s;
		}, this.setFoveation = function(e) {
			s = e, d !== null && (d.fixedFoveation = e), f !== null && f.fixedFoveation !== void 0 && (f.fixedFoveation = e);
		}, this.hasDepthSensing = function() {
			return h.texture !== null;
		}, this.getDepthSensingMesh = function() {
			return h.getMesh(A);
		}, this.getCameraTexture = function(e) {
			return g[e];
		};
		let de = null;
		function fe(t, i) {
			if (l = i.getViewerPose(c || a), p = i, l !== null) {
				let t = l.views;
				f !== null && (e.setRenderTargetFramebuffer(x, f.framebuffer), e.setRenderTarget(x));
				let i = !1;
				t.length !== A.cameras.length && (A.cameras.length = 0, i = !0);
				for (let n = 0; n < t.length; n++) {
					let r = t[n], a = null;
					if (f !== null) a = f.getViewport(r);
					else {
						let t = u.getViewSubImage(d, r);
						a = t.viewport, n === 0 && (e.setRenderTargetTextures(x, t.colorTexture, t.depthStencilTexture), e.setRenderTarget(x));
					}
					let o = k[n];
					o === void 0 && (o = new ae(), o.layers.enable(n), o.viewport = new Qe(), k[n] = o), o.matrix.fromArray(r.transform.matrix), o.matrix.decompose(o.position, o.quaternion, o.scale), o.projectionMatrix.fromArray(r.projectionMatrix), o.projectionMatrixInverse.copy(o.projectionMatrix).invert(), o.viewport.set(a.x, a.y, a.width, a.height), n === 0 && (A.matrix.copy(o.matrix), A.matrix.decompose(A.position, A.quaternion, A.scale)), i === !0 && A.cameras.push(o);
				}
				let a = r.enabledFeatures;
				if (a && a.includes("depth-sensing") && r.depthUsage == "gpu-optimized" && m) {
					u = n.getBinding();
					let e = u.getDepthInformation(t[0]);
					e && e.isValid && e.texture && h.init(e, r.renderState);
				}
				if (a && a.includes("camera-access") && m) {
					e.state.unbindTexture(), u = n.getBinding();
					for (let e = 0; e < t.length; e++) {
						let n = t[e].camera;
						if (n) {
							let e = g[n];
							e || (e = new ne(), g[n] = e);
							let t = u.getCameraImage(n);
							e.sourceTexture = t;
						}
					}
				}
			}
			for (let e = 0; e < C.length; e++) {
				let t = w[e], n = C[e];
				t !== null && n !== void 0 && n.update(t, i, c || a);
			}
			de && de(t, i), i.detectedPlanes && n.dispatchEvent({
				type: "planesdetected",
				data: i
			}), p = null;
		}
		let pe = new pn();
		pe.setAnimationLoop(fe), this.setAnimationLoop = function(e) {
			de = e;
		}, this.dispose = function() {};
	}
}, Sa = /*@__PURE__*/ new Ie(), Ca = /*@__PURE__*/ new z();
Ca.set(-1, 0, 0, 0, 1, 0, 0, 0, 1);
function wa(e, t) {
	function n(e, t) {
		e.matrixAutoUpdate === !0 && e.updateMatrix(), t.value.copy(e.matrix);
	}
	function r(t, n) {
		n.color.getRGB(t.fogColor.value, _(e)), n.isFog ? (t.fogNear.value = n.near, t.fogFar.value = n.far) : n.isFogExp2 && (t.fogDensity.value = n.density);
	}
	function i(e, t, n, r, i) {
		t.isNodeMaterial ? t.uniformsNeedUpdate = !1 : t.isMeshBasicMaterial ? a(e, t) : t.isMeshLambertMaterial ? (a(e, t), t.envMap && (e.envMapIntensity.value = t.envMapIntensity)) : t.isMeshToonMaterial ? (a(e, t), d(e, t)) : t.isMeshPhongMaterial ? (a(e, t), u(e, t), t.envMap && (e.envMapIntensity.value = t.envMapIntensity)) : t.isMeshStandardMaterial ? (a(e, t), f(e, t), t.isMeshPhysicalMaterial && p(e, t, i)) : t.isMeshMatcapMaterial ? (a(e, t), m(e, t)) : t.isMeshDepthMaterial ? a(e, t) : t.isMeshDistanceMaterial ? (a(e, t), h(e, t)) : t.isMeshNormalMaterial ? a(e, t) : t.isLineBasicMaterial ? (o(e, t), t.isLineDashedMaterial && s(e, t)) : t.isPointsMaterial ? c(e, t, n, r) : t.isSpriteMaterial ? l(e, t) : t.isShadowMaterial ? (e.color.value.copy(t.color), e.opacity.value = t.opacity) : t.isShaderMaterial && (t.uniformsNeedUpdate = !1);
	}
	function a(e, r) {
		e.opacity.value = r.opacity, r.color && e.diffuse.value.copy(r.color), r.emissive && e.emissive.value.copy(r.emissive).multiplyScalar(r.emissiveIntensity), r.map && (e.map.value = r.map, n(r.map, e.mapTransform)), r.alphaMap && (e.alphaMap.value = r.alphaMap, n(r.alphaMap, e.alphaMapTransform)), r.bumpMap && (e.bumpMap.value = r.bumpMap, n(r.bumpMap, e.bumpMapTransform), e.bumpScale.value = r.bumpScale, r.side === 1 && (e.bumpScale.value *= -1)), r.normalMap && (e.normalMap.value = r.normalMap, n(r.normalMap, e.normalMapTransform), e.normalScale.value.copy(r.normalScale), r.side === 1 && e.normalScale.value.negate()), r.displacementMap && (e.displacementMap.value = r.displacementMap, n(r.displacementMap, e.displacementMapTransform), e.displacementScale.value = r.displacementScale, e.displacementBias.value = r.displacementBias), r.emissiveMap && (e.emissiveMap.value = r.emissiveMap, n(r.emissiveMap, e.emissiveMapTransform)), r.specularMap && (e.specularMap.value = r.specularMap, n(r.specularMap, e.specularMapTransform)), r.alphaTest > 0 && (e.alphaTest.value = r.alphaTest);
		let i = t.get(r), a = i.envMap, o = i.envMapRotation;
		a && (e.envMap.value = a, e.envMapRotation.value.setFromMatrix4(Sa.makeRotationFromEuler(o)).transpose(), a.isCubeTexture && a.isRenderTargetTexture === !1 && e.envMapRotation.value.premultiply(Ca), e.reflectivity.value = r.reflectivity, e.ior.value = r.ior, e.refractionRatio.value = r.refractionRatio), r.lightMap && (e.lightMap.value = r.lightMap, e.lightMapIntensity.value = r.lightMapIntensity, n(r.lightMap, e.lightMapTransform)), r.aoMap && (e.aoMap.value = r.aoMap, e.aoMapIntensity.value = r.aoMapIntensity, n(r.aoMap, e.aoMapTransform));
	}
	function o(e, t) {
		e.diffuse.value.copy(t.color), e.opacity.value = t.opacity, t.map && (e.map.value = t.map, n(t.map, e.mapTransform));
	}
	function s(e, t) {
		e.dashSize.value = t.dashSize, e.totalSize.value = t.dashSize + t.gapSize, e.scale.value = t.scale;
	}
	function c(e, t, r, i) {
		e.diffuse.value.copy(t.color), e.opacity.value = t.opacity, e.size.value = t.size * r, e.scale.value = i * .5, t.map && (e.map.value = t.map, n(t.map, e.uvTransform)), t.alphaMap && (e.alphaMap.value = t.alphaMap, n(t.alphaMap, e.alphaMapTransform)), t.alphaTest > 0 && (e.alphaTest.value = t.alphaTest);
	}
	function l(e, t) {
		e.diffuse.value.copy(t.color), e.opacity.value = t.opacity, e.rotation.value = t.rotation, t.map && (e.map.value = t.map, n(t.map, e.mapTransform)), t.alphaMap && (e.alphaMap.value = t.alphaMap, n(t.alphaMap, e.alphaMapTransform)), t.alphaTest > 0 && (e.alphaTest.value = t.alphaTest);
	}
	function u(e, t) {
		e.specular.value.copy(t.specular), e.shininess.value = Math.max(t.shininess, 1e-4);
	}
	function d(e, t) {
		t.gradientMap && (e.gradientMap.value = t.gradientMap);
	}
	function f(e, t) {
		e.metalness.value = t.metalness, t.metalnessMap && (e.metalnessMap.value = t.metalnessMap, n(t.metalnessMap, e.metalnessMapTransform)), e.roughness.value = t.roughness, t.roughnessMap && (e.roughnessMap.value = t.roughnessMap, n(t.roughnessMap, e.roughnessMapTransform)), t.envMap && (e.envMapIntensity.value = t.envMapIntensity);
	}
	function p(e, t, r) {
		e.ior.value = t.ior, t.sheen > 0 && (e.sheenColor.value.copy(t.sheenColor).multiplyScalar(t.sheen), e.sheenRoughness.value = t.sheenRoughness, t.sheenColorMap && (e.sheenColorMap.value = t.sheenColorMap, n(t.sheenColorMap, e.sheenColorMapTransform)), t.sheenRoughnessMap && (e.sheenRoughnessMap.value = t.sheenRoughnessMap, n(t.sheenRoughnessMap, e.sheenRoughnessMapTransform))), t.clearcoat > 0 && (e.clearcoat.value = t.clearcoat, e.clearcoatRoughness.value = t.clearcoatRoughness, t.clearcoatMap && (e.clearcoatMap.value = t.clearcoatMap, n(t.clearcoatMap, e.clearcoatMapTransform)), t.clearcoatRoughnessMap && (e.clearcoatRoughnessMap.value = t.clearcoatRoughnessMap, n(t.clearcoatRoughnessMap, e.clearcoatRoughnessMapTransform)), t.clearcoatNormalMap && (e.clearcoatNormalMap.value = t.clearcoatNormalMap, n(t.clearcoatNormalMap, e.clearcoatNormalMapTransform), e.clearcoatNormalScale.value.copy(t.clearcoatNormalScale), t.side === 1 && e.clearcoatNormalScale.value.negate())), t.dispersion > 0 && (e.dispersion.value = t.dispersion), t.retroreflectivity > 0 && (e.retroreflectivity.value = t.retroreflectivity), t.iridescence > 0 && (e.iridescence.value = t.iridescence, e.iridescenceIOR.value = t.iridescenceIOR, e.iridescenceThicknessMinimum.value = t.iridescenceThicknessRange[0], e.iridescenceThicknessMaximum.value = t.iridescenceThicknessRange[1], t.iridescenceMap && (e.iridescenceMap.value = t.iridescenceMap, n(t.iridescenceMap, e.iridescenceMapTransform)), t.iridescenceThicknessMap && (e.iridescenceThicknessMap.value = t.iridescenceThicknessMap, n(t.iridescenceThicknessMap, e.iridescenceThicknessMapTransform))), t.transmission > 0 && (e.transmission.value = t.transmission, e.transmissionSamplerMap.value = r.texture, e.transmissionSamplerSize.value.set(r.width, r.height), t.transmissionMap && (e.transmissionMap.value = t.transmissionMap, n(t.transmissionMap, e.transmissionMapTransform)), e.thickness.value = t.thickness, t.thicknessMap && (e.thicknessMap.value = t.thicknessMap, n(t.thicknessMap, e.thicknessMapTransform)), e.attenuationDistance.value = t.attenuationDistance, e.attenuationColor.value.copy(t.attenuationColor)), t.anisotropy > 0 && (e.anisotropyVector.value.set(t.anisotropy * Math.cos(t.anisotropyRotation), t.anisotropy * Math.sin(t.anisotropyRotation)), t.anisotropyMap && (e.anisotropyMap.value = t.anisotropyMap, n(t.anisotropyMap, e.anisotropyMapTransform))), e.specularIntensity.value = t.specularIntensity, e.specularColor.value.copy(t.specularColor), t.specularColorMap && (e.specularColorMap.value = t.specularColorMap, n(t.specularColorMap, e.specularColorMapTransform)), t.specularIntensityMap && (e.specularIntensityMap.value = t.specularIntensityMap, n(t.specularIntensityMap, e.specularIntensityMapTransform));
	}
	function m(e, t) {
		t.matcap && (e.matcap.value = t.matcap);
	}
	function h(e, n) {
		let r = t.get(n).light;
		e.referencePosition.value.setFromMatrixPosition(r.matrixWorld), e.nearDistance.value = r.shadow.camera.near, e.farDistance.value = r.shadow.camera.far;
	}
	return {
		refreshFogUniforms: r,
		refreshMaterialUniforms: i
	};
}
function Ta(e, t, n, r) {
	let i = {}, a = {}, o = [], s = e.getParameter(e.MAX_UNIFORM_BUFFER_BINDINGS);
	function c(e, t) {
		let n = t.program;
		r.uniformBlockBinding(e, n);
	}
	function l(e, n) {
		let o = i[e.id];
		o === void 0 && (g(e), o = u(e), i[e.id] = o, e.addEventListener("dispose", v));
		let s = n.program;
		r.updateUBOMapping(e, s);
		let c = t.render.frame;
		a[e.id] !== c && (f(e), a[e.id] = c);
	}
	function u(t) {
		let n = d();
		t.__bindingPointIndex = n;
		let r = e.createBuffer(), i = t.__size, a = t.usage;
		return e.bindBuffer(e.UNIFORM_BUFFER, r), e.bufferData(e.UNIFORM_BUFFER, i, a), e.bindBuffer(e.UNIFORM_BUFFER, null), e.bindBufferBase(e.UNIFORM_BUFFER, n, r), r;
	}
	function d() {
		for (let e = 0; e < s; e++) if (o.indexOf(e) === -1) return o.push(e), e;
		return mt("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."), 0;
	}
	function f(t) {
		let n = i[t.id], r = t.uniforms, a = t.__cache;
		e.bindBuffer(e.UNIFORM_BUFFER, n);
		for (let e = 0, t = r.length; e < t; e++) {
			let t = r[e];
			if (Array.isArray(t)) for (let n = 0, r = t.length; n < r; n++) p(t[n], e, n, a);
			else p(t, e, 0, a);
		}
		e.bindBuffer(e.UNIFORM_BUFFER, null);
	}
	function p(t, n, r, i) {
		if (h(t, n, r, i) === !0) {
			let n = t.__offset, r = t.value;
			if (Array.isArray(r)) {
				let e = 0;
				for (let n = 0; n < r.length; n++) {
					let i = r[n], a = _(i);
					m(i, t.__data, e), typeof i != "number" && typeof i != "boolean" && !i.isMatrix3 && !ArrayBuffer.isView(i) && (e += a.storage / Float32Array.BYTES_PER_ELEMENT);
				}
			} else m(r, t.__data, 0);
			e.bufferSubData(e.UNIFORM_BUFFER, n, t.__data);
		}
	}
	function m(e, t, n) {
		typeof e == "number" || typeof e == "boolean" ? t[0] = e : e.isMatrix3 ? (t[0] = e.elements[0], t[1] = e.elements[1], t[2] = e.elements[2], t[3] = 0, t[4] = e.elements[3], t[5] = e.elements[4], t[6] = e.elements[5], t[7] = 0, t[8] = e.elements[6], t[9] = e.elements[7], t[10] = e.elements[8], t[11] = 0) : ArrayBuffer.isView(e) ? t.set(new e.constructor(e.buffer, e.byteOffset, t.length)) : e.toArray(t, n);
	}
	function h(e, t, n, r) {
		let i = e.value, a = t + "_" + n;
		if (r[a] === void 0) return r[a] = typeof i == "number" || typeof i == "boolean" ? i : ArrayBuffer.isView(i) ? i.slice() : i.clone(), !0;
		{
			let e = r[a];
			if (typeof i == "number" || typeof i == "boolean") {
				if (e !== i) return r[a] = i, !0;
			} else if (ArrayBuffer.isView(i)) return !0;
			else if (e.equals(i) === !1) return e.copy(i), !0;
		}
		return !1;
	}
	function g(e) {
		let t = e.uniforms, n = 0;
		for (let e = 0, r = t.length; e < r; e++) {
			let r = Array.isArray(t[e]) ? t[e] : [t[e]];
			for (let e = 0, t = r.length; e < t; e++) {
				let t = r[e], i = Array.isArray(t.value) ? t.value : [t.value];
				for (let e = 0, r = i.length; e < r; e++) {
					let r = i[e], a = _(r), o = n % 16, s = o % a.boundary, c = o + s;
					n += s, c !== 0 && 16 - c < a.storage && (n += 16 - c), t.__data = new Float32Array(a.storage / Float32Array.BYTES_PER_ELEMENT), t.__offset = n, n += a.storage;
				}
			}
		}
		let r = n % 16;
		return r > 0 && (n += 16 - r), e.__size = n, e.__cache = {}, this;
	}
	function _(e) {
		let t = {
			boundary: 0,
			storage: 0
		};
		return typeof e == "number" || typeof e == "boolean" ? (t.boundary = 4, t.storage = 4) : e.isVector2 ? (t.boundary = 8, t.storage = 8) : e.isVector3 || e.isColor ? (t.boundary = 16, t.storage = 12) : e.isVector4 ? (t.boundary = 16, t.storage = 16) : e.isMatrix3 ? (t.boundary = 48, t.storage = 48) : e.isMatrix4 ? (t.boundary = 64, t.storage = 64) : e.isTexture ? b("WebGLRenderer: Texture samplers can not be part of an uniforms group.") : ArrayBuffer.isView(e) ? (t.boundary = 16, t.storage = e.byteLength) : b("WebGLRenderer: Unsupported uniform value type.", e), t;
	}
	function v(t) {
		let n = t.target;
		n.removeEventListener("dispose", v);
		let r = o.indexOf(n.__bindingPointIndex);
		o.splice(r, 1), e.deleteBuffer(i[n.id]), delete i[n.id], delete a[n.id];
	}
	function y() {
		for (let t in i) e.deleteBuffer(i[t]);
		o = [], i = {}, a = {};
	}
	return {
		bind: c,
		update: l,
		dispose: y
	};
}
var Ea = new Uint16Array([
	12469,
	15057,
	12620,
	14925,
	13266,
	14620,
	13807,
	14376,
	14323,
	13990,
	14545,
	13625,
	14713,
	13328,
	14840,
	12882,
	14931,
	12528,
	14996,
	12233,
	15039,
	11829,
	15066,
	11525,
	15080,
	11295,
	15085,
	10976,
	15082,
	10705,
	15073,
	10495,
	13880,
	14564,
	13898,
	14542,
	13977,
	14430,
	14158,
	14124,
	14393,
	13732,
	14556,
	13410,
	14702,
	12996,
	14814,
	12596,
	14891,
	12291,
	14937,
	11834,
	14957,
	11489,
	14958,
	11194,
	14943,
	10803,
	14921,
	10506,
	14893,
	10278,
	14858,
	9960,
	14484,
	14039,
	14487,
	14025,
	14499,
	13941,
	14524,
	13740,
	14574,
	13468,
	14654,
	13106,
	14743,
	12678,
	14818,
	12344,
	14867,
	11893,
	14889,
	11509,
	14893,
	11180,
	14881,
	10751,
	14852,
	10428,
	14812,
	10128,
	14765,
	9754,
	14712,
	9466,
	14764,
	13480,
	14764,
	13475,
	14766,
	13440,
	14766,
	13347,
	14769,
	13070,
	14786,
	12713,
	14816,
	12387,
	14844,
	11957,
	14860,
	11549,
	14868,
	11215,
	14855,
	10751,
	14825,
	10403,
	14782,
	10044,
	14729,
	9651,
	14666,
	9352,
	14599,
	9029,
	14967,
	12835,
	14966,
	12831,
	14963,
	12804,
	14954,
	12723,
	14936,
	12564,
	14917,
	12347,
	14900,
	11958,
	14886,
	11569,
	14878,
	11247,
	14859,
	10765,
	14828,
	10401,
	14784,
	10011,
	14727,
	9600,
	14660,
	9289,
	14586,
	8893,
	14508,
	8533,
	15111,
	12234,
	15110,
	12234,
	15104,
	12216,
	15092,
	12156,
	15067,
	12010,
	15028,
	11776,
	14981,
	11500,
	14942,
	11205,
	14902,
	10752,
	14861,
	10393,
	14812,
	9991,
	14752,
	9570,
	14682,
	9252,
	14603,
	8808,
	14519,
	8445,
	14431,
	8145,
	15209,
	11449,
	15208,
	11451,
	15202,
	11451,
	15190,
	11438,
	15163,
	11384,
	15117,
	11274,
	15055,
	10979,
	14994,
	10648,
	14932,
	10343,
	14871,
	9936,
	14803,
	9532,
	14729,
	9218,
	14645,
	8742,
	14556,
	8381,
	14461,
	8020,
	14365,
	7603,
	15273,
	10603,
	15272,
	10607,
	15267,
	10619,
	15256,
	10631,
	15231,
	10614,
	15182,
	10535,
	15118,
	10389,
	15042,
	10167,
	14963,
	9787,
	14883,
	9447,
	14800,
	9115,
	14710,
	8665,
	14615,
	8318,
	14514,
	7911,
	14411,
	7507,
	14279,
	7198,
	15314,
	9675,
	15313,
	9683,
	15309,
	9712,
	15298,
	9759,
	15277,
	9797,
	15229,
	9773,
	15166,
	9668,
	15084,
	9487,
	14995,
	9274,
	14898,
	8910,
	14800,
	8539,
	14697,
	8234,
	14590,
	7790,
	14479,
	7409,
	14367,
	7067,
	14178,
	6621,
	15337,
	8619,
	15337,
	8631,
	15333,
	8677,
	15325,
	8769,
	15305,
	8871,
	15264,
	8940,
	15202,
	8909,
	15119,
	8775,
	15022,
	8565,
	14916,
	8328,
	14804,
	8009,
	14688,
	7614,
	14569,
	7287,
	14448,
	6888,
	14321,
	6483,
	14088,
	6171,
	15350,
	7402,
	15350,
	7419,
	15347,
	7480,
	15340,
	7613,
	15322,
	7804,
	15287,
	7973,
	15229,
	8057,
	15148,
	8012,
	15046,
	7846,
	14933,
	7611,
	14810,
	7357,
	14682,
	7069,
	14552,
	6656,
	14421,
	6316,
	14251,
	5948,
	14007,
	5528,
	15356,
	5942,
	15356,
	5977,
	15353,
	6119,
	15348,
	6294,
	15332,
	6551,
	15302,
	6824,
	15249,
	7044,
	15171,
	7122,
	15070,
	7050,
	14949,
	6861,
	14818,
	6611,
	14679,
	6349,
	14538,
	6067,
	14398,
	5651,
	14189,
	5311,
	13935,
	4958,
	15359,
	4123,
	15359,
	4153,
	15356,
	4296,
	15353,
	4646,
	15338,
	5160,
	15311,
	5508,
	15263,
	5829,
	15188,
	6042,
	15088,
	6094,
	14966,
	6001,
	14826,
	5796,
	14678,
	5543,
	14527,
	5287,
	14377,
	4985,
	14133,
	4586,
	13869,
	4257,
	15360,
	1563,
	15360,
	1642,
	15358,
	2076,
	15354,
	2636,
	15341,
	3350,
	15317,
	4019,
	15273,
	4429,
	15203,
	4732,
	15105,
	4911,
	14981,
	4932,
	14836,
	4818,
	14679,
	4621,
	14517,
	4386,
	14359,
	4156,
	14083,
	3795,
	13808,
	3437,
	15360,
	122,
	15360,
	137,
	15358,
	285,
	15355,
	636,
	15344,
	1274,
	15322,
	2177,
	15281,
	2765,
	15215,
	3223,
	15120,
	3451,
	14995,
	3569,
	14846,
	3567,
	14681,
	3466,
	14511,
	3305,
	14344,
	3121,
	14037,
	2800,
	13753,
	2467,
	15360,
	0,
	15360,
	1,
	15359,
	21,
	15355,
	89,
	15346,
	253,
	15325,
	479,
	15287,
	796,
	15225,
	1148,
	15133,
	1492,
	15008,
	1749,
	14856,
	1882,
	14685,
	1886,
	14506,
	1783,
	14324,
	1608,
	13996,
	1398,
	13702,
	1183
]), Da = null;
function Oa() {
	return Da === null && (Da = new fe(Ea, 16, 16, ut, p), Da.name = "DFG_LUT", Da.minFilter = B, Da.magFilter = B, Da.wrapS = je, Da.wrapT = je, Da.generateMipmaps = !1, Da.needsUpdate = !0), Da;
}
var ka = class {
	constructor(e = {}) {
		let { canvas: t = gt(), context: n = null, depth: r = !0, stencil: i = !1, alpha: a = !1, antialias: o = !1, premultipliedAlpha: s = !0, preserveDrawingBuffer: c = !1, powerPreference: l = "default", failIfMajorPerformanceCaveat: u = !1, reversedDepthBuffer: f = !1, outputBufferType: m = tt } = e;
		this.isWebGLRenderer = !0;
		let h;
		if (n !== null) {
			if (typeof WebGLRenderingContext < "u" && n instanceof WebGLRenderingContext) throw Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");
			h = n.getContextAttributes().alpha;
		} else h = a;
		let g = m, _ = /* @__PURE__ */ new Set([
			ee,
			he,
			d
		]), v = /* @__PURE__ */ new Set([
			tt,
			it,
			st,
			Ce,
			ke,
			Ge
		]), y = /* @__PURE__ */ new Uint32Array(4), x = /* @__PURE__ */ new Int32Array(4), S = new L(), C = null, T = null, E = [], D = [], O = null;
		this.domElement = t, this.debug = {
			checkShaderErrors: !0,
			diagnostics: { keywords: !1 },
			onShaderError: null
		}, this.autoClear = !0, this.autoClearColor = !0, this.autoClearDepth = !0, this.autoClearStencil = !0, this.sortObjects = !0, this.clippingPlanes = [], this.localClippingEnabled = !1, this.toneMapping = 0, this.toneMappingExposure = 1, this.transmissionResolutionScale = 1;
		let k = this, ne = !1, re = null, ie = null, ae = null, oe = null;
		this._outputColorSpace = te;
		let se = 0, ce = 0, le = null, ue = -1, j = null, M = new Qe(), de = new Qe(), fe = null, pe = new I(0), me = 0, ge = t.width, _e = t.height, ve = 1, ye = null, be = null, xe = new Qe(0, 0, ge, _e), Se = new Qe(0, 0, ge, _e), N = !1, Te = new A(), Ee = !1, De = !1, Oe = new Ie(), Ae = new L(), je = new Qe(), P = {
			background: null,
			fog: null,
			environment: null,
			overrideMaterial: null,
			isScene: !0
		}, Me = !1;
		function Ne() {
			return le === null ? ve : 1;
		}
		let F = n;
		function Pe(e, n) {
			return t.getContext(e, n);
		}
		let R, Le, z, ze, B, V, Be, Ve, He, Ue, We, Ke, qe, Je, Ye, Xe, $e, et, nt, rt, at, ot, ct;
		try {
			let e = {
				alpha: !0,
				depth: r,
				stencil: i,
				antialias: o,
				premultipliedAlpha: s,
				preserveDrawingBuffer: c,
				powerPreference: l,
				failIfMajorPerformanceCaveat: u
			};
			if ("setAttribute" in t && t.setAttribute("data-engine", "three.js r186"), t.addEventListener("webglcontextlost", ft, !1), t.addEventListener("webglcontextrestored", pt, !1), t.addEventListener("webglcontextcreationerror", ht, !1), F === null) {
				let t = "webgl2";
				if (F = Pe(t, e), F === null) throw Pe(t) ? Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes.") : Error("THREE.WebGLRenderer: Error creating WebGL context.");
			}
			lt();
		} catch (e) {
			throw t.removeEventListener("webglcontextlost", ft, !1), t.removeEventListener("webglcontextrestored", pt, !1), t.removeEventListener("webglcontextcreationerror", ht, !1), mt("WebGLRenderer: " + e.message), e;
		}
		function lt() {
			R = new qn(F), R.init(), at = new _a(F, R), Le = new Sn(F, R, e, at), z = new ha(F, R), Le.reversedDepthBuffer && f && z.buffers.depth.setReversed(!0), ie = F.createFramebuffer(), ae = F.createFramebuffer(), oe = F.createFramebuffer(), ze = new Xn(F), B = new Yi(), V = new ga(F, R, z, B, Le, at, ze), Be = new Kn(k), Ve = new mn(F), ot = new bn(F, Ve), He = new Jn(F, Ve, ze, ot), Ue = new Qn(F, He, Ve, ot, ze), et = new Zn(F, Le, V), Ye = new Cn(B), We = new Ji(k, Be, R, Le, ot, Ye), Ke = new wa(k, B), qe = new $i(), Je = new oa(R), $e = new yn(k, Be, z, Ue, h, s), Xe = new ma(k, Ue, Le), ct = new Ta(F, ze, Le, z), nt = new xn(F, R, ze), rt = new Yn(F, R, ze), ze.programs = We.programs, k.capabilities = Le, k.extensions = R, k.properties = B, k.renderLists = qe, k.shadowMap = Xe, k.state = z, k.info = ze;
		}
		g !== 1009 && (O = new er(g, t.width, t.height, o, r, i));
		let ut = new xa(k, F);
		this.xr = ut, this.getContext = function() {
			return F;
		}, this.getContextAttributes = function() {
			return F.getContextAttributes();
		}, this.forceContextLoss = function() {
			let e = R.get("WEBGL_lose_context");
			e && e.loseContext();
		}, this.forceContextRestore = function() {
			let e = R.get("WEBGL_lose_context");
			e && e.restoreContext();
		}, this.getPixelRatio = function() {
			return ve;
		}, this.setPixelRatio = function(e) {
			e !== void 0 && (ve = e, this.setSize(ge, _e, !1));
		}, this.getSize = function(e) {
			return e.set(ge, _e);
		}, this.setSize = function(e, n, r = !0) {
			ut.isPresenting ? b("WebGLRenderer: Can't change size while VR device is presenting.") : (ge = e, _e = n, t.width = Math.floor(e * ve), t.height = Math.floor(n * ve), r === !0 && (t.style.width = e + "px", t.style.height = n + "px"), O !== null && O.setSize(t.width, t.height), this.setViewport(0, 0, e, n));
		}, this.getDrawingBufferSize = function(e) {
			return e.set(ge * ve, _e * ve).floor();
		}, this.setDrawingBufferSize = function(e, n, r) {
			ge = e, _e = n, ve = r, t.width = Math.floor(e * r), t.height = Math.floor(n * r), this.setViewport(0, 0, e, n);
		}, this.setEffects = function(e) {
			if (g === 1009) mt("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");
			else {
				if (e) {
					for (let t = 0; t < e.length; t++) if (e[t].isOutputPass === !0) {
						b("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");
						break;
					}
				}
				O.setEffects(e || []);
			}
		}, this.getCurrentViewport = function(e) {
			return e.copy(M);
		}, this.getViewport = function(e) {
			return e.copy(xe);
		}, this.setViewport = function(e, t, n, r) {
			e.isVector4 ? xe.set(e.x, e.y, e.z, e.w) : xe.set(e, t, n, r), z.viewport(M.copy(xe).multiplyScalar(ve).round());
		}, this.getScissor = function(e) {
			return e.copy(Se);
		}, this.setScissor = function(e, t, n, r) {
			e.isVector4 ? Se.set(e.x, e.y, e.z, e.w) : Se.set(e, t, n, r), z.scissor(de.copy(Se).multiplyScalar(ve).round());
		}, this.getScissorTest = function() {
			return N;
		}, this.setScissorTest = function(e) {
			z.setScissorTest(N = e);
		}, this.setOpaqueSort = function(e) {
			ye = e;
		}, this.setTransparentSort = function(e) {
			be = e;
		}, this.getClearColor = function(e) {
			return e.copy($e.getClearColor());
		}, this.setClearColor = function() {
			$e.setClearColor(...arguments);
		}, this.getClearAlpha = function() {
			return $e.getClearAlpha();
		}, this.setClearAlpha = function() {
			$e.setClearAlpha(...arguments);
		}, this.clear = function(e = !0, t = !0, n = !0) {
			let r = 0;
			if (e) {
				let e = !1;
				if (le !== null) {
					let t = le.texture.format;
					e = _.has(t);
				}
				if (e) {
					let e = le.texture.type, t = v.has(e), n = $e.getClearColor(), r = $e.getClearAlpha(), i = n.r, a = n.g, o = n.b;
					t ? (y[0] = i, y[1] = a, y[2] = o, y[3] = r, F.clearBufferuiv(F.COLOR, 0, y)) : (x[0] = i, x[1] = a, x[2] = o, x[3] = r, F.clearBufferiv(F.COLOR, 0, x));
				} else r |= F.COLOR_BUFFER_BIT;
			}
			t && (r |= F.DEPTH_BUFFER_BIT, this.state.buffers.depth.setMask(!0)), n && (r |= F.STENCIL_BUFFER_BIT, this.state.buffers.stencil.setMask(4294967295)), r !== 0 && F.clear(r);
		}, this.clearColor = function() {
			this.clear(!0, !1, !1);
		}, this.clearDepth = function() {
			this.clear(!1, !0, !1);
		}, this.clearStencil = function() {
			this.clear(!1, !1, !0);
		}, this.setNodesHandler = function(e) {
			e.setRenderer(this), re = e;
		}, this.dispose = function() {
			t.removeEventListener("webglcontextlost", ft, !1), t.removeEventListener("webglcontextrestored", pt, !1), t.removeEventListener("webglcontextcreationerror", ht, !1), $e.dispose(), qe.dispose(), Je.dispose(), B.dispose(), Be.dispose(), Ue.dispose(), ot.dispose(), ct.dispose(), We.dispose(), ut.dispose(), ut.removeEventListener("sessionstart", Ct), ut.removeEventListener("sessionend", wt), Tt.stop();
		};
		function ft(e) {
			e.preventDefault(), dt("WebGLRenderer: Context Lost."), ne = !0;
		}
		function pt() {
			dt("WebGLRenderer: Context Restored."), ne = !1;
			let e = ze.autoReset, t = Xe.enabled, n = Xe.autoUpdate, r = Xe.needsUpdate, i = Xe.type;
			lt(), ze.autoReset = e, Xe.enabled = t, Xe.autoUpdate = n, Xe.needsUpdate = r, Xe.type = i;
		}
		function ht(e) {
			mt("WebGLRenderer: A WebGL context could not be created. Reason: ", e.statusMessage);
		}
		function _t(e) {
			let t = e.target;
			t.removeEventListener("dispose", _t), vt(t);
		}
		function vt(e) {
			yt(e), B.remove(e);
		}
		function yt(e) {
			let t = B.get(e).programs;
			t !== void 0 && (t.forEach(function(e) {
				We.releaseProgram(e);
			}), e.isShaderMaterial && We.releaseShaderCache(e));
		}
		this.renderBufferDirect = function(e, t, n, r, i, a) {
			t === null && (t = P);
			let o = i.isMesh && i.matrixWorld.determinantAffine() < 0, s = Ft(e, t, n, r, i);
			z.setMaterial(r, o);
			let c = n.index, l = 1;
			if (r.wireframe === !0) {
				if (c = He.getWireframeAttribute(n), c === void 0) return;
				l = 2;
			}
			let u = n.drawRange, d = n.attributes.position, f = u.start * l, p = (u.start + u.count) * l;
			a !== null && (f = Math.max(f, a.start * l), p = Math.min(p, (a.start + a.count) * l)), c === null ? d != null && (f = Math.max(f, 0), p = Math.min(p, d.count)) : (f = Math.max(f, 0), p = Math.min(p, c.count));
			let m = p - f;
			if (m < 0 || m === Infinity) return;
			ot.setup(i, r, s, n, c);
			let h, g = nt;
			if (c !== null && (h = Ve.get(c), g = rt, g.setIndex(h)), i.isMesh) r.wireframe === !0 ? (z.setLineWidth(r.wireframeLinewidth * Ne()), g.setMode(F.LINES)) : g.setMode(F.TRIANGLES);
			else if (i.isLine) {
				let e = r.linewidth;
				e === void 0 && (e = 1), z.setLineWidth(e * Ne()), i.isLineSegments ? g.setMode(F.LINES) : i.isLineLoop ? g.setMode(F.LINE_LOOP) : g.setMode(F.LINE_STRIP);
			} else i.isPoints ? g.setMode(F.POINTS) : i.isSprite && g.setMode(F.TRIANGLES);
			if (i.isBatchedMesh) {
				if (R.get("WEBGL_multi_draw")) g.renderMultiDraw(i._multiDrawStarts, i._multiDrawCounts, i._multiDrawCount);
				else {
					let e = i._multiDrawStarts, t = i._multiDrawCounts, n = i._multiDrawCount, a = c ? Ve.get(c).bytesPerElement : 1, o = B.get(r).currentProgram.getUniforms();
					for (let r = 0; r < n; r++) o.setValue(F, "_gl_DrawID", r), g.render(e[r] / a, t[r]);
				}
			} else if (i.isInstancedMesh) g.renderInstances(f, m, i.count);
			else if (n.isInstancedBufferGeometry) {
				let e = n._maxInstanceCount === void 0 ? Infinity : n._maxInstanceCount, t = Math.min(n.instanceCount, e);
				g.renderInstances(f, m, t);
			} else g.render(f, m);
		};
		function bt(e, t, n, r) {
			re !== null && e.isNodeMaterial && re.setObject(r, e), Ee === !0 && Ye.setState(e, n, !1), e.transparent === !0 && e.side === 2 && e.forceSinglePass === !1 ? (e.side = 1, e.needsUpdate = !0, jt(e, t, r), e.side = 0, e.needsUpdate = !0, jt(e, t, r), e.side = 2) : jt(e, t, r);
		}
		this.compile = function(e, t, n = null) {
			n === null && (n = e), re !== null && re.renderStart(e, t, n), T = Je.get(n), T.init(t), D.push(T), n.traverseVisible(function(e) {
				e.isLight && e.layers.test(t.layers) && (T.pushLight(e), e.castShadow && T.pushShadow(e));
			}), e !== n && e.traverseVisible(function(e) {
				e.isLight && e.layers.test(t.layers) && (T.pushLight(e), e.castShadow && T.pushShadow(e));
			}), T.setupLights(), re !== null && re.updateLights(T.state.lightsArray), De = this.localClippingEnabled, Ee = Ye.init(this.clippingPlanes, De), Ee === !0 && Ye.setGlobalState(this.clippingPlanes, t), re !== null && Xe.render(T.state.shadowsArray, n, t);
			let r = /* @__PURE__ */ new Set();
			return e.traverse(function(e) {
				if (!(e.isMesh || e.isPoints || e.isLine || e.isSprite)) return;
				let i = e.material;
				if (i) {
					if (Array.isArray(i)) for (let a = 0; a < i.length; a++) {
						let o = i[a];
						bt(o, n, t, e), r.add(o);
					}
					else bt(i, n, t, e), r.add(i);
				}
			}), T = D.pop(), re !== null && re.renderEnd(), r;
		}, this.compileAsync = function(e, t, n = null) {
			let r = this.compile(e, t, n);
			return new Promise((t) => {
				function n() {
					r.forEach(function(e) {
						let t = B.get(e).currentProgram;
						(t === void 0 || t.isReady()) && r.delete(e);
					}), r.size === 0 ? t(e) : setTimeout(n, 10);
				}
				R.get("KHR_parallel_shader_compile") === null ? setTimeout(n, 10) : n();
			});
		};
		let xt = null;
		function St(e) {
			xt && xt(e);
		}
		function Ct() {
			Tt.stop();
		}
		function wt() {
			Tt.start();
		}
		let Tt = new pn();
		Tt.setAnimationLoop(St), typeof self < "u" && Tt.setContext(self), this.setAnimationLoop = function(e) {
			xt = e, ut.setAnimationLoop(e), e === null ? Tt.stop() : Tt.start();
		}, ut.addEventListener("sessionstart", Ct), ut.addEventListener("sessionend", wt), this.render = function(e, t) {
			if (t !== void 0 && t.isCamera !== !0) {
				mt("WebGLRenderer.render: camera is not an instance of THREE.Camera.");
				return;
			}
			if (ne === !0) return;
			re !== null && re.renderStart(e, t);
			let n = ut.enabled === !0 && ut.isPresenting === !0, r = O !== null && (le === null || n) && O.begin(k, le);
			if (e.matrixWorldAutoUpdate === !0 && e.updateMatrixWorld(), t.parent === null && t.matrixWorldAutoUpdate === !0 && t.updateMatrixWorld(), ut.enabled === !0 && ut.isPresenting === !0 && (O === null || O.isCompositing() === !1) && (ut.cameraAutoUpdate === !0 && ut.updateCamera(t), t = ut.getCamera()), e.isScene === !0 && e.onBeforeRender(k, e, t, le), T = Je.get(e, D.length), T.init(t), T.state.textureUnits = V.getTextureUnits(), D.push(T), Oe.multiplyMatrices(t.projectionMatrix, t.matrixWorldInverse), Te.setFromProjectionMatrix(Oe, Re, t.reversedDepth), De = this.localClippingEnabled, Ee = Ye.init(this.clippingPlanes, De), C = qe.get(e, E.length), C.init(), E.push(C), ut.enabled === !0 && ut.isPresenting === !0) {
				let e = k.xr.getDepthSensingMesh();
				e !== null && Et(e, t, -Infinity, k.sortObjects);
			}
			Et(e, t, 0, k.sortObjects), C.finish(), re !== null && re.updateLights(T.state.lightsArray), k.sortObjects === !0 && C.sort(ye, be), Me = ut.enabled === !1 || ut.isPresenting === !1 || ut.hasDepthSensing() === !1, Me && $e.addToRenderList(C, e), this.info.render.frame++, this.info.autoReset === !0 && this.info.reset(), Ee === !0 && Ye.beginShadows();
			let i = T.state.shadowsArray;
			if (Xe.render(i, e, t), Ee === !0 && Ye.endShadows(), (r && O.hasRenderPass()) === !1) {
				let n = C.opaque, r = C.transmissive;
				if (T.setupLights(), t.isArrayCamera) {
					let i = t.cameras;
					if (r.length > 0) for (let t = 0, a = i.length; t < a; t++) {
						let a = i[t];
						Ot(n, r, e, a);
					}
					Me && $e.render(e);
					for (let t = 0, n = i.length; t < n; t++) {
						let n = i[t];
						Dt(C, e, n, n.viewport);
					}
				} else r.length > 0 && Ot(n, r, e, t), Me && $e.render(e), Dt(C, e, t);
			}
			le !== null && ce === 0 && (V.updateMultisampleRenderTarget(le), V.updateRenderTargetMipmap(le)), r && O.end(k), e.isScene === !0 && e.onAfterRender(k, e, t), ot.resetDefaultState(), ue = -1, j = null, D.pop(), D.length > 0 ? (T = D[D.length - 1], V.setTextureUnits(T.state.textureUnits), Ee === !0 && Ye.setGlobalState(k.clippingPlanes, T.state.camera)) : T = null, E.pop(), C = E.length > 0 ? E[E.length - 1] : null, re !== null && re.renderEnd();
		};
		function Et(e, t, n, r) {
			if (e.visible === !1) return;
			if (e.layers.test(t.layers)) {
				if (e.isGroup) n = e.renderOrder;
				else if (e.isLOD) e.autoUpdate === !0 && e.update(t);
				else if (e.isLightProbeGrid) T.pushLightProbeGrid(e);
				else if (e.isLight) T.pushLight(e), e.castShadow && T.pushShadow(e);
				else if (e.isSprite) {
					if (!e.frustumCulled || e.intersectsFrustum(Te)) {
						r && je.setFromMatrixPosition(e.matrixWorld).applyMatrix4(Oe);
						let i = Ue.update(e), a = e.material;
						a.visible && C.push(e, i, a, n, je.z, null, t);
					}
				} else if ((e.isMesh || e.isLine || e.isPoints) && (!e.frustumCulled || e.intersectsFrustum(Te))) {
					let i = Ue.update(e), a = e.material;
					if (r && (e.boundingSphere === void 0 ? (i.boundingSphere === null && i.computeBoundingSphere(), je.copy(i.boundingSphere.center)) : (e.boundingSphere === null && e.computeBoundingSphere(), je.copy(e.boundingSphere.center)), je.applyMatrix4(e.matrixWorld).applyMatrix4(Oe)), Array.isArray(a)) {
						let r = i.groups;
						for (let o = 0, s = r.length; o < s; o++) {
							let s = r[o], c = a[s.materialIndex];
							c && c.visible && C.push(e, i, c, n, je.z, s, t);
						}
					} else a.visible && C.push(e, i, a, n, je.z, null, t);
				}
			}
			let i = e.children;
			for (let e = 0, a = i.length; e < a; e++) Et(i[e], t, n, r);
		}
		function Dt(e, t, n, r) {
			let { opaque: i, transmissive: a, transparent: o } = e;
			T.setupLightsView(n), Ee === !0 && Ye.setGlobalState(k.clippingPlanes, n), r && z.viewport(M.copy(r)), i.length > 0 && kt(i, t, n), a.length > 0 && kt(a, t, n), o.length > 0 && kt(o, t, n), z.buffers.depth.setTest(!0), z.buffers.depth.setMask(!0), z.buffers.color.setMask(!0), z.setPolygonOffset(!1);
		}
		function Ot(e, t, n, r) {
			if ((n.isScene === !0 ? n.overrideMaterial : null) !== null) return;
			if (T.state.transmissionRenderTarget[r.id] === void 0) {
				let e = R.has("EXT_color_buffer_half_float") || R.has("EXT_color_buffer_float");
				T.state.transmissionRenderTarget[r.id] = new Fe(1, 1, {
					generateMipmaps: !0,
					type: e ? p : tt,
					minFilter: we,
					samples: Math.max(4, Le.samples),
					stencilBuffer: i,
					resolveDepthBuffer: !1,
					resolveStencilBuffer: !1,
					storeMultisampledDepthBuffer: !1,
					storeMultisampledStencilBuffer: !1,
					colorSpace: Ze.workingColorSpace
				});
			}
			let a = T.state.transmissionRenderTarget[r.id], o = r.viewport || M;
			a.setSize(o.z * k.transmissionResolutionScale, o.w * k.transmissionResolutionScale);
			let s = k.getRenderTarget(), c = k.getActiveCubeFace(), l = k.getActiveMipmapLevel();
			k.setRenderTarget(a), k.getClearColor(pe), me = k.getClearAlpha(), me < 1 && k.setClearColor(16777215, .5), k.clear(), Me && $e.render(n);
			let u = k.toneMapping;
			k.toneMapping = 0;
			let d = r.viewport;
			if (r.viewport !== void 0 && (r.viewport = void 0), T.setupLightsView(r), Ee === !0 && Ye.setGlobalState(k.clippingPlanes, r), kt(e, n, r), V.updateMultisampleRenderTarget(a), V.updateRenderTargetMipmap(a), R.has("WEBGL_multisampled_render_to_texture") === !1) {
				let e = !1;
				for (let i = 0, a = t.length; i < a; i++) {
					let { object: a, geometry: o, material: s, group: c } = t[i];
					if (s.side === 2 && a.layers.test(r.layers)) {
						let t = s.side;
						s.side = 1, s.needsUpdate = !0, At(a, n, r, o, s, c), s.side = t, s.needsUpdate = !0, e = !0;
					}
				}
				e === !0 && (V.updateMultisampleRenderTarget(a), V.updateRenderTargetMipmap(a));
			}
			k.setRenderTarget(s, c, l), k.setClearColor(pe, me), d !== void 0 && (r.viewport = d), k.toneMapping = u;
		}
		function kt(e, t, n) {
			let r = t.isScene === !0 ? t.overrideMaterial : null;
			for (let i = 0, a = e.length; i < a; i++) {
				let a = e[i], { object: o, geometry: s, group: c } = a, l = a.material;
				l.allowOverride === !0 && r !== null && (l = r), o.layers.test(n.layers) && At(o, t, n, s, l, c);
			}
		}
		function At(e, t, n, r, i, a) {
			re !== null && i.isNodeMaterial && re.setObject(e, i), e.onBeforeRender(k, t, n, r, i, a), e.modelViewMatrix.multiplyMatrices(n.matrixWorldInverse, e.matrixWorld), e.normalMatrix.getNormalMatrix(e.modelViewMatrix), i.onBeforeRender(k, t, n, r, e, a), i.transparent === !0 && i.side === 2 && i.forceSinglePass === !1 ? (i.side = 1, i.needsUpdate = !0, k.renderBufferDirect(n, t, r, i, e, a), i.side = 0, i.needsUpdate = !0, k.renderBufferDirect(n, t, r, i, e, a), i.side = 2) : k.renderBufferDirect(n, t, r, i, e, a), e.onAfterRender(k, t, n, r, i, a);
		}
		function jt(e, t, n) {
			t.isScene !== !0 && (t = P);
			let r = B.get(e), i = T.state.lights, a = T.state.shadowsArray, o = i.state.version, s = We.getParameters(e, i.state, a, t, n, T.state.lightProbeGridArray), c = We.getProgramCacheKey(s), l = r.programs;
			r.environment = e.isMeshStandardMaterial || e.isMeshLambertMaterial || e.isMeshPhongMaterial ? t.environment : null, r.fog = t.fog;
			let u = e.isMeshStandardMaterial || e.isMeshLambertMaterial && !e.envMap || e.isMeshPhongMaterial && !e.envMap;
			r.envMap = Be.get(e.envMap || r.environment, u), r.envMapRotation = r.environment !== null && e.envMap === null ? t.environmentRotation : e.envMapRotation, l === void 0 && (e.addEventListener("dispose", _t), l = /* @__PURE__ */ new Map(), r.programs = l);
			let d = l.get(c);
			if (d !== void 0) {
				if (r.currentProgram === d && r.lightsStateVersion === o) return Nt(e, s), d;
			} else s.uniforms = We.getUniforms(e), re !== null && e.isNodeMaterial && re.build(e, n, s), e.onBeforeCompile(s, k), d = We.acquireProgram(s, c), l.set(c, d), r.uniforms = s.uniforms;
			let f = r.uniforms;
			return (!e.isShaderMaterial && !e.isRawShaderMaterial || e.clipping === !0) && (f.clippingPlanes = Ye.uniform), Nt(e, s), r.needsLights = Lt(e), r.lightsStateVersion = o, r.needsLights && (f.ambientLightColor.value = i.state.ambient, f.lightProbe.value = i.state.probe, f.sunLights.value = i.state.sun, f.sunLightShadows.value = i.state.sunShadow, f.directionalLights.value = i.state.directional, f.directionalLightShadows.value = i.state.directionalShadow, f.spotLights.value = i.state.spot, f.spotLightShadows.value = i.state.spotShadow, f.rectAreaLights.value = i.state.rectArea, f.ltc_1.value = i.state.rectAreaLTC1, f.ltc_2.value = i.state.rectAreaLTC2, f.pointLights.value = i.state.point, f.pointLightShadows.value = i.state.pointShadow, f.hemisphereLights.value = i.state.hemi, f.sunShadowMatrix.value = i.state.sunShadowMatrix, f.sunShadowCascade.value = i.state.sunShadowCascade, f.directionalShadowMatrix.value = i.state.directionalShadowMatrix, f.spotLightMatrix.value = i.state.spotLightMatrix, f.spotLightMap.value = i.state.spotLightMap, f.pointShadowMatrix.value = i.state.pointShadowMatrix), r.lightProbeGrid = T.state.lightProbeGridArray.length > 0, r.currentProgram = d, r.uniformsList = null, d;
		}
		function Mt(e) {
			if (e.uniformsList === null) {
				let t = e.currentProgram.getUniforms();
				e.uniformsList = si.seqWithValue(t.seq, e.uniforms);
			}
			return e.uniformsList;
		}
		function Nt(e, t) {
			let n = B.get(e);
			n.outputColorSpace = t.outputColorSpace, n.batching = t.batching, n.batchingColor = t.batchingColor, n.instancing = t.instancing, n.instancingColor = t.instancingColor, n.instancingMorph = t.instancingMorph, n.skinning = t.skinning, n.morphTargets = t.morphTargets, n.morphNormals = t.morphNormals, n.morphColors = t.morphColors, n.morphTargetsCount = t.morphTargetsCount, n.numClippingPlanes = t.numClippingPlanes, n.numIntersection = t.numClipIntersection, n.vertexAlphas = t.vertexAlphas, n.vertexTangents = t.vertexTangents, n.toneMapping = t.toneMapping;
		}
		function Pt(e, t) {
			if (e.length === 0) return null;
			if (e.length === 1) return e[0].texture === null ? null : e[0];
			S.setFromMatrixPosition(t.matrixWorld);
			for (let t = 0, n = e.length; t < n; t++) {
				let n = e[t];
				if (n.texture !== null && n.boundingBox.containsPoint(S)) return n;
			}
			return null;
		}
		function Ft(e, t, n, r, i) {
			t.isScene !== !0 && (t = P), V.resetTextureUnits();
			let a = t.fog, o = r.isMeshStandardMaterial || r.isMeshLambertMaterial || r.isMeshPhongMaterial ? t.environment : null, s = le === null ? k.outputColorSpace : le.isXRRenderTarget === !0 ? le.texture.colorSpace : Ze.workingColorSpace, c = r.isMeshStandardMaterial || r.isMeshLambertMaterial && !r.envMap || r.isMeshPhongMaterial && !r.envMap, l = Be.get(r.envMap || o, c), u = r.vertexColors === !0 && !!n.attributes.color && n.attributes.color.itemSize === 4, d = !!n.attributes.tangent && (!!r.normalMap || r.anisotropy > 0), f = !!n.morphAttributes.position, p = !!n.morphAttributes.normal, m = !!n.morphAttributes.color, h = 0;
			r.toneMapped && (le === null || le.isXRRenderTarget === !0) && (h = k.toneMapping);
			let g = n.morphAttributes.position || n.morphAttributes.normal || n.morphAttributes.color, _ = g === void 0 ? 0 : g.length, v = B.get(r), y = T.state.lights;
			if (Ee === !0 && (De === !0 || e !== j)) {
				let t = e === j && r.id === ue;
				Ye.setState(r, e, t);
			}
			let b = !1;
			r.version === v.__version ? v.needsLights && v.lightsStateVersion !== y.state.version ? b = !0 : v.outputColorSpace === s ? i.isBatchedMesh && v.batching === !1 || !i.isBatchedMesh && v.batching === !0 || i.isBatchedMesh && v.batchingColor === !0 && i._colorsTexture === null || i.isBatchedMesh && v.batchingColor === !1 && i._colorsTexture !== null || i.isInstancedMesh && v.instancing === !1 || !i.isInstancedMesh && v.instancing === !0 || i.isSkinnedMesh && v.skinning === !1 || !i.isSkinnedMesh && v.skinning === !0 || i.isInstancedMesh && v.instancingColor === !0 && i.instanceColor === null || i.isInstancedMesh && v.instancingColor === !1 && i.instanceColor !== null || i.isInstancedMesh && v.instancingMorph === !0 && i.morphTexture === null || i.isInstancedMesh && v.instancingMorph === !1 && i.morphTexture !== null ? b = !0 : v.envMap === l ? r.fog === !0 && v.fog !== a || v.numClippingPlanes !== void 0 && (v.numClippingPlanes !== Ye.numPlanes || v.numIntersection !== Ye.numIntersection) ? b = !0 : v.vertexAlphas === u && v.vertexTangents === d && v.morphTargets === f && v.morphNormals === p && v.morphColors === m && v.toneMapping === h && v.morphTargetsCount === _ ? !!v.lightProbeGrid != T.state.lightProbeGridArray.length > 0 && (b = !0) : b = !0 : b = !0 : b = !0 : (b = !0, v.__version = r.version);
			let x = v.currentProgram;
			b === !0 && (x = jt(r, t, i), re && r.isNodeMaterial && re.onUpdateProgram(r, x, v));
			let S = !1, C = !1, w = !1, E = x.getUniforms(), D = v.uniforms;
			if (z.useProgram(x.program) && (S = !0, C = !0, w = !0), r.id !== ue && (ue = r.id, C = !0), v.needsLights) {
				let e = Pt(T.state.lightProbeGridArray, i);
				v.lightProbeGrid !== e && (v.lightProbeGrid = e, C = !0);
			}
			if (S || j !== e) {
				z.buffers.depth.getReversed() && e.reversedDepth !== !0 && (e._reversedDepth = !0, e.updateProjectionMatrix()), E.setValue(F, "projectionMatrix", e.projectionMatrix), E.setValue(F, "viewMatrix", e.matrixWorldInverse);
				let t = E.map.cameraPosition;
				t !== void 0 && t.setValue(F, Ae.setFromMatrixPosition(e.matrixWorld)), Le.logarithmicDepthBuffer && E.setValue(F, "logDepthBufFC", 2 / (Math.log(e.far + 1) / Math.LN2)), (r.isMeshPhongMaterial || r.isMeshToonMaterial || r.isMeshLambertMaterial || r.isMeshBasicMaterial || r.isMeshStandardMaterial || r.isShaderMaterial) && E.setValue(F, "isOrthographic", e.isOrthographicCamera === !0), j !== e && (j = e, C = !0, w = !0);
			}
			if (v.needsLights && (y.state.sunShadowMap.length > 0 && E.setValue(F, "sunShadowMap", y.state.sunShadowMap, V), y.state.directionalShadowMap.length > 0 && E.setValue(F, "directionalShadowMap", y.state.directionalShadowMap, V), y.state.spotShadowMap.length > 0 && E.setValue(F, "spotShadowMap", y.state.spotShadowMap, V), y.state.pointShadowMap.length > 0 && E.setValue(F, "pointShadowMap", y.state.pointShadowMap, V)), i.isSkinnedMesh) {
				E.setOptional(F, i, "bindMatrix"), E.setOptional(F, i, "bindMatrixInverse");
				let e = i.skeleton;
				e && (e.boneTexture === null && e.computeBoneTexture(), E.setValue(F, "boneTexture", e.boneTexture, V));
			}
			i.isBatchedMesh && (E.setOptional(F, i, "batchingTexture"), E.setValue(F, "batchingTexture", i._matricesTexture, V), E.setOptional(F, i, "batchingIdTexture"), E.setValue(F, "batchingIdTexture", i._indirectTexture, V), E.setOptional(F, i, "batchingColorTexture"), i._colorsTexture !== null && E.setValue(F, "batchingColorTexture", i._colorsTexture, V));
			let O = n.morphAttributes;
			if ((O.position !== void 0 || O.normal !== void 0 || O.color !== void 0) && et.update(i, n, x), (C || v.receiveShadow !== i.receiveShadow) && (v.receiveShadow = i.receiveShadow, E.setValue(F, "receiveShadow", i.receiveShadow)), (r.isMeshStandardMaterial || r.isMeshLambertMaterial || r.isMeshPhongMaterial) && r.envMap === null && t.environment !== null && (D.envMapIntensity.value = t.environmentIntensity), D.dfgLUT !== void 0 && (D.dfgLUT.value = Oa()), C) {
				if (E.setValue(F, "toneMappingExposure", k.toneMappingExposure), v.needsLights && It(D, w), a && r.fog === !0 && Ke.refreshFogUniforms(D, a), Ke.refreshMaterialUniforms(D, r, ve, _e, T.state.transmissionRenderTarget[e.id]), v.needsLights && v.lightProbeGrid) {
					let e = v.lightProbeGrid;
					D.probesSH.value = e.texture, D.probesMin.value.copy(e.boundingBox.min), D.probesMax.value.copy(e.boundingBox.max), D.probesResolution.value.copy(e.resolution);
				}
				si.upload(F, Mt(v), D, V);
			}
			if (r.isShaderMaterial && r.uniformsNeedUpdate === !0 && (si.upload(F, Mt(v), D, V), r.uniformsNeedUpdate = !1), r.isSpriteMaterial && E.setValue(F, "center", i.center), E.setValue(F, "modelViewMatrix", i.modelViewMatrix), E.setValue(F, "normalMatrix", i.normalMatrix), E.setValue(F, "modelMatrix", i.matrixWorld), r.uniformsGroups !== void 0) {
				let e = r.uniformsGroups;
				for (let t = 0, n = e.length; t < n; t++) {
					let n = e[t];
					ct.update(n, x), ct.bind(n, x);
				}
			}
			return x;
		}
		function It(e, t) {
			e.ambientLightColor.needsUpdate = t, e.lightProbe.needsUpdate = t, e.sunLights.needsUpdate = t, e.sunLightShadows.needsUpdate = t, e.directionalLights.needsUpdate = t, e.directionalLightShadows.needsUpdate = t, e.pointLights.needsUpdate = t, e.pointLightShadows.needsUpdate = t, e.spotLights.needsUpdate = t, e.spotLightShadows.needsUpdate = t, e.rectAreaLights.needsUpdate = t, e.hemisphereLights.needsUpdate = t;
		}
		function Lt(e) {
			return e.isMeshLambertMaterial || e.isMeshToonMaterial || e.isMeshPhongMaterial || e.isMeshStandardMaterial || e.isShadowMaterial || e.isShaderMaterial && e.lights === !0;
		}
		this.getActiveCubeFace = function() {
			return se;
		}, this.getActiveMipmapLevel = function() {
			return ce;
		}, this.getRenderTarget = function() {
			return le;
		}, this.setRenderTargetTextures = function(e, t, n) {
			let r = B.get(e);
			r.__autoAllocateDepthBuffer = e.resolveDepthBuffer === !1, r.__autoAllocateDepthBuffer === !1 && (r.__useRenderToTexture = !1), B.get(e.texture).__webglTexture = t, B.get(e.depthTexture).__webglTexture = r.__autoAllocateDepthBuffer ? void 0 : n, r.__hasExternalTextures = !0;
		}, this.setRenderTargetFramebuffer = function(e, t) {
			let n = B.get(e);
			n.__webglFramebuffer = t, n.__useDefaultFramebuffer = t === void 0;
		}, this.setRenderTarget = function(e, t = 0, n = 0) {
			le = e, se = t, ce = n;
			let r = null, i = !1, a = !1;
			if (e) {
				let o = B.get(e);
				if (o.__useDefaultFramebuffer !== void 0) {
					z.bindFramebuffer(F.FRAMEBUFFER, o.__webglFramebuffer), M.copy(e.viewport), de.copy(e.scissor), fe = e.scissorTest, z.viewport(M), z.scissor(de), z.setScissorTest(fe), ue = -1;
					return;
				}
				if (o.__webglFramebuffer === void 0) V.setupRenderTarget(e);
				else if (o.__hasExternalTextures) V.rebindTextures(e, B.get(e.texture).__webglTexture, B.get(e.depthTexture).__webglTexture);
				else if (e.depthBuffer) {
					let t = e.depthTexture;
					if (o.__boundDepthTexture !== t) {
						if (t !== null && B.has(t) && (e.width !== t.image.width || e.height !== t.image.height)) throw Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");
						V.setupDepthRenderbuffer(e);
					}
				}
				let s = e.texture;
				(s.isData3DTexture || s.isDataArrayTexture || s.isCompressedArrayTexture) && (a = !0);
				let c = B.get(e).__webglFramebuffer;
				e.isWebGLCubeRenderTarget ? (r = Array.isArray(c[t]) ? c[t][n] : c[t], i = !0) : r = e.samples > 0 && V.useMultisampledRTT(e) === !1 ? B.get(e).__webglMultisampledFramebuffer : Array.isArray(c) ? c[n] : c, M.copy(e.viewport), de.copy(e.scissor), fe = e.scissorTest;
			} else M.copy(xe).multiplyScalar(ve).floor(), de.copy(Se).multiplyScalar(ve).floor(), fe = N;
			if (n !== 0 && (r = ie), z.bindFramebuffer(F.FRAMEBUFFER, r) && z.drawBuffers(e, r), z.viewport(M), z.scissor(de), z.setScissorTest(fe), i) {
				let r = B.get(e.texture);
				F.framebufferTexture2D(F.FRAMEBUFFER, F.COLOR_ATTACHMENT0, F.TEXTURE_CUBE_MAP_POSITIVE_X + t, r.__webglTexture, n);
			} else if (a) {
				let r = t;
				for (let t = 0; t < e.textures.length; t++) {
					let i = B.get(e.textures[t]);
					F.framebufferTextureLayer(F.FRAMEBUFFER, F.COLOR_ATTACHMENT0 + t, i.__webglTexture, n, r);
				}
			} else if (e !== null && n !== 0) {
				let t = B.get(e.texture);
				F.framebufferTexture2D(F.FRAMEBUFFER, F.COLOR_ATTACHMENT0, F.TEXTURE_2D, t.__webglTexture, n);
			}
			ue = -1;
		};
		function Rt(e) {
			let t = B.get(e);
			return (t.__readFormat !== e.format || t.__readType !== e.type) && (t.__readFormat = e.format, t.__readType = e.type, t.__formatReadable = Le.textureFormatReadable(e.format), t.__typeReadable = Le.textureTypeReadable(e.type)), t;
		}
		this.readRenderTargetPixels = function(e, t, n, r, i, a, o, s = 0) {
			if (!(e && e.isWebGLRenderTarget)) {
				mt("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");
				return;
			}
			let c = B.get(e).__webglFramebuffer;
			if (e.isWebGLCubeRenderTarget && o !== void 0 && (c = c[o]), c) {
				z.bindFramebuffer(F.FRAMEBUFFER, c);
				try {
					let o = e.textures[s], c = o.format, l = o.type;
					e.textures.length > 1 && F.readBuffer(F.COLOR_ATTACHMENT0 + s);
					let u = Rt(o);
					if (u.__formatReadable === !1) {
						mt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");
						return;
					}
					if (u.__typeReadable === !1) {
						mt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");
						return;
					}
					t >= 0 && t <= e.width - r && n >= 0 && n <= e.height - i && F.readPixels(t, n, r, i, at.convert(c), at.convert(l), a);
				} finally {
					let e = le === null ? null : B.get(le).__webglFramebuffer;
					z.bindFramebuffer(F.FRAMEBUFFER, e);
				}
			}
		}, this.readRenderTargetPixelsAsync = async function(e, t, n, r, i, a, o, s = 0) {
			if (!(e && e.isWebGLRenderTarget)) throw Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");
			let c = B.get(e).__webglFramebuffer;
			if (e.isWebGLCubeRenderTarget && o !== void 0 && (c = c[o]), c) {
				if (t >= 0 && t <= e.width - r && n >= 0 && n <= e.height - i) {
					z.bindFramebuffer(F.FRAMEBUFFER, c);
					let o = e.textures[s], l = o.format, u = o.type;
					e.textures.length > 1 && F.readBuffer(F.COLOR_ATTACHMENT0 + s);
					let d = Rt(o);
					if (d.__formatReadable === !1) throw Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");
					if (d.__typeReadable === !1) throw Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");
					let f = F.createBuffer();
					F.bindBuffer(F.PIXEL_PACK_BUFFER, f), F.bufferData(F.PIXEL_PACK_BUFFER, a.byteLength, F.STREAM_READ), F.readPixels(t, n, r, i, at.convert(l), at.convert(u), 0), F.bindBuffer(F.PIXEL_PACK_BUFFER, null);
					let p = le === null ? null : B.get(le).__webglFramebuffer;
					z.bindFramebuffer(F.FRAMEBUFFER, p);
					let m = F.fenceSync(F.SYNC_GPU_COMMANDS_COMPLETE, 0);
					return F.flush(), await w(F, m, 4), F.bindBuffer(F.PIXEL_PACK_BUFFER, f), F.getBufferSubData(F.PIXEL_PACK_BUFFER, 0, a), F.bindBuffer(F.PIXEL_PACK_BUFFER, null), F.deleteBuffer(f), F.deleteSync(m), a;
				}
				throw Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.");
			}
		}, this.copyFramebufferToTexture = function(e, t = null, n = 0) {
			let r = 2 ** -n, i = Math.floor(e.image.width * r), a = Math.floor(e.image.height * r), o = t === null ? 0 : t.x, s = t === null ? 0 : t.y;
			V.setTexture2D(e, 0), F.copyTexSubImage2D(F.TEXTURE_2D, n, 0, 0, o, s, i, a), z.unbindTexture();
		}, this.copyTextureToTexture = function(e, t, n = null, r = null, i = 0, a = 0) {
			let o, s, c, l, u, d, f, p, m, h = e.isCompressedTexture ? e.mipmaps[a] : e.image;
			if (n !== null) o = n.max.x - n.min.x, s = n.max.y - n.min.y, c = n.isBox3 ? n.max.z - n.min.z : 1, l = n.min.x, u = n.min.y, d = n.isBox3 ? n.min.z : 0;
			else {
				let t = 2 ** -i;
				o = Math.floor(h.width * t), s = Math.floor(h.height * t), c = e.isDataArrayTexture ? h.depth : e.isData3DTexture ? Math.floor(h.depth * t) : 1, l = 0, u = 0, d = 0;
			}
			r === null ? (f = 0, p = 0, m = 0) : (f = r.x, p = r.y, m = r.z);
			let g = at.convert(t.format), _ = at.convert(t.type), v;
			t.isData3DTexture ? (V.setTexture3D(t, 0), v = F.TEXTURE_3D) : t.isDataArrayTexture || t.isCompressedArrayTexture ? (V.setTexture2DArray(t, 0), v = F.TEXTURE_2D_ARRAY) : (V.setTexture2D(t, 0), v = F.TEXTURE_2D), z.activeTexture(F.TEXTURE0), z.pixelStorei(F.UNPACK_FLIP_Y_WEBGL, t.flipY), z.pixelStorei(F.UNPACK_PREMULTIPLY_ALPHA_WEBGL, t.premultiplyAlpha), z.pixelStorei(F.UNPACK_ALIGNMENT, t.unpackAlignment);
			let y = z.getParameter(F.UNPACK_ROW_LENGTH), b = z.getParameter(F.UNPACK_IMAGE_HEIGHT), x = z.getParameter(F.UNPACK_SKIP_PIXELS), S = z.getParameter(F.UNPACK_SKIP_ROWS), C = z.getParameter(F.UNPACK_SKIP_IMAGES);
			z.pixelStorei(F.UNPACK_ROW_LENGTH, h.width), z.pixelStorei(F.UNPACK_IMAGE_HEIGHT, h.height), z.pixelStorei(F.UNPACK_SKIP_PIXELS, l), z.pixelStorei(F.UNPACK_SKIP_ROWS, u), z.pixelStorei(F.UNPACK_SKIP_IMAGES, d);
			let w = e.isDataArrayTexture || e.isData3DTexture, T = t.isDataArrayTexture || t.isData3DTexture;
			if (e.isDepthTexture) {
				let n = B.get(e), r = B.get(t), h = B.get(n.__renderTarget), g = B.get(r.__renderTarget);
				z.bindFramebuffer(F.READ_FRAMEBUFFER, h.__webglFramebuffer), z.bindFramebuffer(F.DRAW_FRAMEBUFFER, g.__webglFramebuffer);
				for (let n = 0; n < c; n++) w && (F.framebufferTextureLayer(F.READ_FRAMEBUFFER, F.COLOR_ATTACHMENT0, B.get(e).__webglTexture, i, d + n), F.framebufferTextureLayer(F.DRAW_FRAMEBUFFER, F.COLOR_ATTACHMENT0, B.get(t).__webglTexture, a, m + n)), F.blitFramebuffer(l, u, o, s, f, p, o, s, F.DEPTH_BUFFER_BIT, F.NEAREST);
				z.bindFramebuffer(F.READ_FRAMEBUFFER, null), z.bindFramebuffer(F.DRAW_FRAMEBUFFER, null);
			} else if (i !== 0 || e.isRenderTargetTexture || B.has(e)) {
				let n = B.get(e), r = B.get(t);
				z.bindFramebuffer(F.READ_FRAMEBUFFER, ae), z.bindFramebuffer(F.DRAW_FRAMEBUFFER, oe);
				for (let e = 0; e < c; e++) w ? F.framebufferTextureLayer(F.READ_FRAMEBUFFER, F.COLOR_ATTACHMENT0, n.__webglTexture, i, d + e) : F.framebufferTexture2D(F.READ_FRAMEBUFFER, F.COLOR_ATTACHMENT0, F.TEXTURE_2D, n.__webglTexture, i), T ? F.framebufferTextureLayer(F.DRAW_FRAMEBUFFER, F.COLOR_ATTACHMENT0, r.__webglTexture, a, m + e) : F.framebufferTexture2D(F.DRAW_FRAMEBUFFER, F.COLOR_ATTACHMENT0, F.TEXTURE_2D, r.__webglTexture, a), i === 0 ? T ? F.copyTexSubImage3D(v, a, f, p, m + e, l, u, o, s) : F.copyTexSubImage2D(v, a, f, p, l, u, o, s) : F.blitFramebuffer(l, u, o, s, f, p, o, s, F.COLOR_BUFFER_BIT, F.NEAREST);
				z.bindFramebuffer(F.READ_FRAMEBUFFER, null), z.bindFramebuffer(F.DRAW_FRAMEBUFFER, null);
			} else T ? e.isDataTexture || e.isData3DTexture ? F.texSubImage3D(v, a, f, p, m, o, s, c, g, _, h.data) : t.isCompressedArrayTexture ? F.compressedTexSubImage3D(v, a, f, p, m, o, s, c, g, h.data) : F.texSubImage3D(v, a, f, p, m, o, s, c, g, _, h) : e.isDataTexture ? F.texSubImage2D(F.TEXTURE_2D, a, f, p, o, s, g, _, h.data) : e.isCompressedTexture ? F.compressedTexSubImage2D(F.TEXTURE_2D, a, f, p, h.width, h.height, g, h.data) : F.texSubImage2D(F.TEXTURE_2D, a, f, p, o, s, g, _, h);
			z.pixelStorei(F.UNPACK_ROW_LENGTH, y), z.pixelStorei(F.UNPACK_IMAGE_HEIGHT, b), z.pixelStorei(F.UNPACK_SKIP_PIXELS, x), z.pixelStorei(F.UNPACK_SKIP_ROWS, S), z.pixelStorei(F.UNPACK_SKIP_IMAGES, C), a === 0 && t.generateMipmaps && F.generateMipmap(v), z.unbindTexture();
		}, this.initRenderTarget = function(e) {
			B.get(e).__webglFramebuffer === void 0 && V.setupRenderTarget(e);
		}, this.initTexture = function(e) {
			e.isCubeTexture ? V.setTextureCube(e, 0) : e.isData3DTexture ? V.setTexture3D(e, 0) : e.isDataArrayTexture || e.isCompressedArrayTexture ? V.setTexture2DArray(e, 0) : V.setTexture2D(e, 0), z.unbindTexture();
		}, this.resetState = function() {
			se = 0, ce = 0, le = null, z.reset(), ot.reset();
		}, typeof __THREE_DEVTOOLS__ < "u" && __THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe", { detail: this }));
	}
	get coordinateSystem() {
		return Re;
	}
	get outputColorSpace() {
		return this._outputColorSpace;
	}
	set outputColorSpace(e) {
		this._outputColorSpace = e;
		let t = this.getContext();
		t.drawingBufferColorSpace = Ze._getDrawingBufferColorSpace(e), t.unpackColorSpace = Ze._getUnpackColorSpace();
	}
}, Aa = {
	"stage/template": {
		kind: "choice",
		label: "Display",
		options: [
			"studio",
			"pedestal",
			"shelf",
			"table"
		],
		default: "studio"
	},
	"stage/color": {
		kind: "color",
		label: "Backdrop",
		default: "#e9e4ef"
	},
	"stage/accent": {
		kind: "color",
		label: "Surface",
		default: "#c9b8d8"
	},
	"light/preset": {
		kind: "choice",
		label: "Lighting",
		options: [
			"soft",
			"bright",
			"dramatic"
		],
		default: "soft"
	},
	"light/angle": {
		kind: "number",
		label: "Light direction",
		min: -180,
		max: 180,
		step: 1,
		default: -55,
		unit: "°"
	},
	"item/scale": {
		kind: "number",
		label: "Size",
		min: .4,
		max: 1.6,
		step: .01,
		default: 1,
		unit: "×"
	},
	"item/turn": {
		kind: "number",
		label: "Turn",
		min: -60,
		max: 60,
		step: 1,
		default: 0,
		unit: "°"
	},
	"item/offset": {
		kind: "number",
		label: "Position",
		min: -1,
		max: 1,
		step: .01,
		default: 0
	},
	"item/base": {
		kind: "boolean",
		label: "Stand base",
		default: !0
	},
	"motion/mode": {
		kind: "choice",
		label: "Motion",
		options: ["still", "sway"],
		default: "still"
	}
};
function ja(e) {
	let t = n(e).join("/");
	return Object.hasOwn(Aa, t) ? Aa[t] : void 0;
}
t(ja);
//#endregion
//#region ../../node_modules/three/examples/jsm/controls/OrbitControls.js
var Ma = { type: "change" }, Na = { type: "start" }, Pa = { type: "end" }, Fa = new y(), Ia = new ue(), La = Math.cos(70 * qe.DEG2RAD), Ra = new L(), za = 2 * Math.PI, Ba = {
	NONE: -1,
	ROTATE: 0,
	DOLLY: 1,
	PAN: 2,
	TOUCH_ROTATE: 3,
	TOUCH_PAN: 4,
	TOUCH_DOLLY_PAN: 5,
	TOUCH_DOLLY_ROTATE: 6
}, Va = 1e-6, Ha = class extends Ke {
	constructor(e, t = null) {
		super(e, t), this.state = Ba.NONE, this.target = new L(), this.cursor = new L(), this.minDistance = 0, this.maxDistance = Infinity, this.minZoom = 0, this.maxZoom = Infinity, this.minTargetRadius = 0, this.maxTargetRadius = Infinity, this.minPolarAngle = 0, this.maxPolarAngle = Math.PI, this.minAzimuthAngle = -Infinity, this.maxAzimuthAngle = Infinity, this.enableDamping = !1, this.dampingFactor = .05, this.enableZoom = !0, this.zoomSpeed = 1, this.enableRotate = !0, this.rotateSpeed = 1, this.keyRotateSpeed = 1, this.enablePan = !0, this.panSpeed = 1, this.screenSpacePanning = !0, this.keyPanSpeed = 7, this.zoomToCursor = !1, this.autoRotate = !1, this.autoRotateSpeed = 2, this.keys = {
			LEFT: "ArrowLeft",
			UP: "ArrowUp",
			RIGHT: "ArrowRight",
			BOTTOM: "ArrowDown"
		}, this.mouseButtons = {
			LEFT: Pe.ROTATE,
			MIDDLE: Pe.DOLLY,
			RIGHT: Pe.PAN
		}, this.touches = {
			ONE: be.ROTATE,
			TWO: be.DOLLY_PAN
		}, this.target0 = this.target.clone(), this.position0 = this.object.position.clone(), this.zoom0 = this.object.zoom, this._cursorStyle = "auto", this._domElementKeyEvents = null, this._lastPosition = new L(), this._lastQuaternion = new h(), this._lastTargetPosition = new L(), this._quat = new h().setFromUnitVectors(e.up, new L(0, 1, 0)), this._quatInverse = this._quat.clone().invert(), this._spherical = new $e(), this._sphericalDelta = new $e(), this._scale = 1, this._panOffset = new L(), this._rotateStart = new P(), this._rotateEnd = new P(), this._rotateDelta = new P(), this._panStart = new P(), this._panEnd = new P(), this._panDelta = new P(), this._dollyStart = new P(), this._dollyEnd = new P(), this._dollyDelta = new P(), this._dollyDirection = new L(), this._mouse = new P(), this._performCursorZoom = !1, this._pointers = [], this._pointerPositions = {}, this._controlActive = !1, this._onPointerMove = Wa.bind(this), this._onPointerDown = Ua.bind(this), this._onPointerUp = Ga.bind(this), this._onContextMenu = Qa.bind(this), this._onMouseWheel = Ja.bind(this), this._onKeyDown = Ya.bind(this), this._onTouchStart = Xa.bind(this), this._onTouchMove = Za.bind(this), this._onMouseDown = Ka.bind(this), this._onMouseMove = qa.bind(this), this._interceptControlDown = $a.bind(this), this._interceptControlUp = eo.bind(this), this.domElement !== null && this.connect(this.domElement), this.update();
	}
	set cursorStyle(e) {
		this._cursorStyle = e, e === "grab" ? this.domElement.style.cursor = "grab" : this.domElement.style.cursor = "auto";
	}
	get cursorStyle() {
		return this._cursorStyle;
	}
	connect(e) {
		super.connect(e), this.domElement.addEventListener("pointerdown", this._onPointerDown), this.domElement.addEventListener("pointercancel", this._onPointerUp), this.domElement.addEventListener("contextmenu", this._onContextMenu), this.domElement.addEventListener("wheel", this._onMouseWheel, { passive: !1 }), this.domElement.getRootNode().addEventListener("keydown", this._interceptControlDown, {
			passive: !0,
			capture: !0
		}), this.domElement.style.touchAction = "none";
	}
	disconnect() {
		this.state = Ba.NONE, this.domElement.removeEventListener("pointerdown", this._onPointerDown), this.domElement.ownerDocument.removeEventListener("pointermove", this._onPointerMove), this.domElement.ownerDocument.removeEventListener("pointerup", this._onPointerUp), this.domElement.removeEventListener("pointercancel", this._onPointerUp), this.domElement.removeEventListener("wheel", this._onMouseWheel), this.domElement.removeEventListener("contextmenu", this._onContextMenu), this.stopListenToKeyEvents();
		let e = this.domElement.getRootNode();
		e.removeEventListener("keydown", this._interceptControlDown, { capture: !0 }), e.removeEventListener("keyup", this._interceptControlUp, { capture: !0 }), this._controlActive = !1, this._pointers.length = 0, this._pointerPositions = {}, this.domElement.style.touchAction = "", this.domElement.style.cursor = "auto";
	}
	dispose() {
		this.disconnect();
	}
	getPolarAngle() {
		return this._spherical.phi;
	}
	getAzimuthalAngle() {
		return this._spherical.theta;
	}
	getDistance() {
		return this.object.position.distanceTo(this.target);
	}
	listenToKeyEvents(e) {
		e.addEventListener("keydown", this._onKeyDown), this._domElementKeyEvents = e;
	}
	stopListenToKeyEvents() {
		this._domElementKeyEvents !== null && (this._domElementKeyEvents.removeEventListener("keydown", this._onKeyDown), this._domElementKeyEvents = null);
	}
	saveState() {
		this.target0.copy(this.target), this.position0.copy(this.object.position), this.zoom0 = this.object.zoom;
	}
	reset() {
		this.target.copy(this.target0), this.object.position.copy(this.position0), this.object.zoom = this.zoom0, this.object.updateProjectionMatrix(), this.dispatchEvent(Ma), this.update(), this.state = Ba.NONE;
	}
	pan(e, t) {
		this._pan(e, t), this.update();
	}
	dollyIn(e) {
		this._dollyIn(e), this.update();
	}
	dollyOut(e) {
		this._dollyOut(e), this.update();
	}
	rotateLeft(e) {
		this._rotateLeft(e), this.update();
	}
	rotateUp(e) {
		this._rotateUp(e), this.update();
	}
	update(e = null) {
		let t = this.object.position;
		Ra.copy(t).sub(this.target), Ra.applyQuaternion(this._quat), this._spherical.setFromVector3(Ra), this.autoRotate && this.state === Ba.NONE && this._rotateLeft(this._getAutoRotationAngle(e)), this.enableDamping ? (this._spherical.theta += this._sphericalDelta.theta * this.dampingFactor, this._spherical.phi += this._sphericalDelta.phi * this.dampingFactor) : (this._spherical.theta += this._sphericalDelta.theta, this._spherical.phi += this._sphericalDelta.phi);
		let n = this.minAzimuthAngle, r = this.maxAzimuthAngle;
		isFinite(n) && isFinite(r) && (n < -Math.PI ? n += za : n > Math.PI && (n -= za), r < -Math.PI ? r += za : r > Math.PI && (r -= za), n <= r ? this._spherical.theta = Math.max(n, Math.min(r, this._spherical.theta)) : this._spherical.theta = this._spherical.theta > (n + r) / 2 ? Math.max(n, this._spherical.theta) : Math.min(r, this._spherical.theta)), this._spherical.phi = Math.max(this.minPolarAngle, Math.min(this.maxPolarAngle, this._spherical.phi)), this._spherical.makeSafe(), this.enableDamping === !0 ? this.target.addScaledVector(this._panOffset, this.dampingFactor) : this.target.add(this._panOffset), this.target.sub(this.cursor), this.target.clampLength(this.minTargetRadius, this.maxTargetRadius), this.target.add(this.cursor);
		let i = !1;
		if (this.zoomToCursor && this._performCursorZoom || this.object.isOrthographicCamera) this._spherical.radius = this._clampDistance(this._spherical.radius);
		else {
			let e = this._spherical.radius;
			this._spherical.radius = this._clampDistance(this._spherical.radius * this._scale), i = e != this._spherical.radius;
		}
		if (Ra.setFromSpherical(this._spherical), Ra.applyQuaternion(this._quatInverse), t.copy(this.target).add(Ra), this.object.lookAt(this.target), this.enableDamping === !0 ? (this._sphericalDelta.theta *= 1 - this.dampingFactor, this._sphericalDelta.phi *= 1 - this.dampingFactor, this._panOffset.multiplyScalar(1 - this.dampingFactor)) : (this._sphericalDelta.set(0, 0, 0), this._panOffset.set(0, 0, 0)), this.zoomToCursor && this._performCursorZoom) {
			let e = null;
			if (this.object.isPerspectiveCamera) {
				let t = Ra.length();
				e = this._clampDistance(t * this._scale);
				let n = t - e;
				this.object.position.addScaledVector(this._dollyDirection, n), this.object.updateMatrixWorld(), i = !!n;
			} else if (this.object.isOrthographicCamera) {
				let t = new L(this._mouse.x, this._mouse.y, 0);
				t.unproject(this.object);
				let n = this.object.zoom;
				this.object.zoom = Math.max(this.minZoom, Math.min(this.maxZoom, this.object.zoom / this._scale)), this.object.updateProjectionMatrix(), i = n !== this.object.zoom;
				let r = new L(this._mouse.x, this._mouse.y, 0);
				r.unproject(this.object), this.object.position.sub(r).add(t), this.object.updateMatrixWorld(), e = Ra.length();
			} else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."), this.zoomToCursor = !1;
			e !== null && (this.screenSpacePanning ? this.target.set(0, 0, -1).transformDirection(this.object.matrix).multiplyScalar(e).add(this.object.position) : (Fa.origin.copy(this.object.position), Fa.direction.set(0, 0, -1).transformDirection(this.object.matrix), Math.abs(this.object.up.dot(Fa.direction)) < La ? this.object.lookAt(this.target) : (Ia.setFromNormalAndCoplanarPoint(this.object.up, this.target), Fa.intersectPlane(Ia, this.target))));
		} else if (this.object.isOrthographicCamera) {
			let e = this.object.zoom;
			this.object.zoom = Math.max(this.minZoom, Math.min(this.maxZoom, this.object.zoom / this._scale)), e !== this.object.zoom && (this.object.updateProjectionMatrix(), i = !0);
		}
		return this._scale = 1, this._performCursorZoom = !1, i || this._lastPosition.distanceToSquared(this.object.position) > Va || 8 * (1 - this._lastQuaternion.dot(this.object.quaternion)) > Va || this._lastTargetPosition.distanceToSquared(this.target) > Va ? (this.dispatchEvent(Ma), this._lastPosition.copy(this.object.position), this._lastQuaternion.copy(this.object.quaternion), this._lastTargetPosition.copy(this.target), !0) : !1;
	}
	_getAutoRotationAngle(e) {
		return e === null ? za / 60 / 60 * this.autoRotateSpeed : za / 60 * this.autoRotateSpeed * e;
	}
	_getZoomScale(e) {
		let t = Math.abs(e * .01);
		return .95 ** (this.zoomSpeed * t);
	}
	_rotateLeft(e) {
		this._sphericalDelta.theta -= e;
	}
	_rotateUp(e) {
		this._sphericalDelta.phi -= e;
	}
	_panLeft(e, t) {
		Ra.setFromMatrixColumn(t, 0), Ra.multiplyScalar(-e), this._panOffset.add(Ra);
	}
	_panUp(e, t) {
		this.screenSpacePanning === !0 ? Ra.setFromMatrixColumn(t, 1) : (Ra.setFromMatrixColumn(t, 0), Ra.crossVectors(this.object.up, Ra)), Ra.multiplyScalar(e), this._panOffset.add(Ra);
	}
	_pan(e, t) {
		let n = this.domElement;
		if (this.object.isPerspectiveCamera) {
			let r = this.object.position;
			Ra.copy(r).sub(this.target);
			let i = Ra.length();
			i *= Math.tan(this.object.fov / 2 * Math.PI / 180), this._panLeft(2 * e * i / n.clientHeight, this.object.matrix), this._panUp(2 * t * i / n.clientHeight, this.object.matrix);
		} else this.object.isOrthographicCamera ? (this._panLeft(e * (this.object.right - this.object.left) / this.object.zoom / n.clientWidth, this.object.matrix), this._panUp(t * (this.object.top - this.object.bottom) / this.object.zoom / n.clientHeight, this.object.matrix)) : (console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."), this.enablePan = !1);
	}
	_dollyOut(e) {
		this.object.isPerspectiveCamera || this.object.isOrthographicCamera ? this._scale /= e : (console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."), this.enableZoom = !1);
	}
	_dollyIn(e) {
		this.object.isPerspectiveCamera || this.object.isOrthographicCamera ? this._scale *= e : (console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."), this.enableZoom = !1);
	}
	_updateZoomParameters(e, t) {
		if (!this.zoomToCursor) return;
		this._performCursorZoom = !0;
		let n = this.domElement.getBoundingClientRect(), r = e - n.left, i = t - n.top, a = n.width, o = n.height;
		this._mouse.x = r / a * 2 - 1, this._mouse.y = -(i / o) * 2 + 1, this._dollyDirection.set(this._mouse.x, this._mouse.y, 1).unproject(this.object).sub(this.object.position).normalize();
	}
	_clampDistance(e) {
		return Math.max(this.minDistance, Math.min(this.maxDistance, e));
	}
	_handleMouseDownRotate(e) {
		this._rotateStart.set(e.clientX, e.clientY);
	}
	_handleMouseDownDolly(e) {
		this._updateZoomParameters(e.clientX, e.clientX), this._dollyStart.set(e.clientX, e.clientY);
	}
	_handleMouseDownPan(e) {
		this._panStart.set(e.clientX, e.clientY);
	}
	_handleMouseMoveRotate(e) {
		this._rotateEnd.set(e.clientX, e.clientY), this._rotateDelta.subVectors(this._rotateEnd, this._rotateStart).multiplyScalar(this.rotateSpeed);
		let t = this.domElement;
		this._rotateLeft(za * this._rotateDelta.x / t.clientHeight), this._rotateUp(za * this._rotateDelta.y / t.clientHeight), this._rotateStart.copy(this._rotateEnd), this.update();
	}
	_handleMouseMoveDolly(e) {
		this._dollyEnd.set(e.clientX, e.clientY), this._dollyDelta.subVectors(this._dollyEnd, this._dollyStart), this._dollyDelta.y > 0 ? this._dollyOut(this._getZoomScale(this._dollyDelta.y)) : this._dollyDelta.y < 0 && this._dollyIn(this._getZoomScale(this._dollyDelta.y)), this._dollyStart.copy(this._dollyEnd), this.update();
	}
	_handleMouseMovePan(e) {
		this._panEnd.set(e.clientX, e.clientY), this._panDelta.subVectors(this._panEnd, this._panStart).multiplyScalar(this.panSpeed), this._pan(this._panDelta.x, this._panDelta.y), this._panStart.copy(this._panEnd), this.update();
	}
	_handleMouseWheel(e) {
		this._updateZoomParameters(e.clientX, e.clientY), e.deltaY < 0 ? this._dollyIn(this._getZoomScale(e.deltaY)) : e.deltaY > 0 && this._dollyOut(this._getZoomScale(e.deltaY)), this.update();
	}
	_handleKeyDown(e) {
		let t = !1;
		switch (e.code) {
			case this.keys.UP:
				e.ctrlKey || e.metaKey || e.shiftKey ? this.enableRotate && this._rotateUp(za * this.keyRotateSpeed / this.domElement.clientHeight) : this.enablePan && this._pan(0, this.keyPanSpeed), t = !0;
				break;
			case this.keys.BOTTOM:
				e.ctrlKey || e.metaKey || e.shiftKey ? this.enableRotate && this._rotateUp(-za * this.keyRotateSpeed / this.domElement.clientHeight) : this.enablePan && this._pan(0, -this.keyPanSpeed), t = !0;
				break;
			case this.keys.LEFT:
				e.ctrlKey || e.metaKey || e.shiftKey ? this.enableRotate && this._rotateLeft(za * this.keyRotateSpeed / this.domElement.clientHeight) : this.enablePan && this._pan(this.keyPanSpeed, 0), t = !0;
				break;
			case this.keys.RIGHT: e.ctrlKey || e.metaKey || e.shiftKey ? this.enableRotate && this._rotateLeft(-za * this.keyRotateSpeed / this.domElement.clientHeight) : this.enablePan && this._pan(-this.keyPanSpeed, 0), t = !0;
		}
		t && (e.preventDefault(), this.update());
	}
	_handleTouchStartRotate(e) {
		if (this._pointers.length === 1) this._rotateStart.set(e.pageX, e.pageY);
		else {
			let t = this._getSecondPointerPosition(e), n = .5 * (e.pageX + t.x), r = .5 * (e.pageY + t.y);
			this._rotateStart.set(n, r);
		}
	}
	_handleTouchStartPan(e) {
		if (this._pointers.length === 1) this._panStart.set(e.pageX, e.pageY);
		else {
			let t = this._getSecondPointerPosition(e), n = .5 * (e.pageX + t.x), r = .5 * (e.pageY + t.y);
			this._panStart.set(n, r);
		}
	}
	_handleTouchStartDolly(e) {
		let t = this._getSecondPointerPosition(e), n = e.pageX - t.x, r = e.pageY - t.y, i = Math.sqrt(n * n + r * r);
		this._dollyStart.set(0, i);
	}
	_handleTouchStartDollyPan(e) {
		this.enableZoom && this._handleTouchStartDolly(e), this.enablePan && this._handleTouchStartPan(e);
	}
	_handleTouchStartDollyRotate(e) {
		this.enableZoom && this._handleTouchStartDolly(e), this.enableRotate && this._handleTouchStartRotate(e);
	}
	_handleTouchMoveRotate(e) {
		if (this._pointers.length == 1) this._rotateEnd.set(e.pageX, e.pageY);
		else {
			let t = this._getSecondPointerPosition(e), n = .5 * (e.pageX + t.x), r = .5 * (e.pageY + t.y);
			this._rotateEnd.set(n, r);
		}
		this._rotateDelta.subVectors(this._rotateEnd, this._rotateStart).multiplyScalar(this.rotateSpeed);
		let t = this.domElement;
		this._rotateLeft(za * this._rotateDelta.x / t.clientHeight), this._rotateUp(za * this._rotateDelta.y / t.clientHeight), this._rotateStart.copy(this._rotateEnd);
	}
	_handleTouchMovePan(e) {
		if (this._pointers.length === 1) this._panEnd.set(e.pageX, e.pageY);
		else {
			let t = this._getSecondPointerPosition(e), n = .5 * (e.pageX + t.x), r = .5 * (e.pageY + t.y);
			this._panEnd.set(n, r);
		}
		this._panDelta.subVectors(this._panEnd, this._panStart).multiplyScalar(this.panSpeed), this._pan(this._panDelta.x, this._panDelta.y), this._panStart.copy(this._panEnd);
	}
	_handleTouchMoveDolly(e) {
		let t = this._getSecondPointerPosition(e), n = e.pageX - t.x, r = e.pageY - t.y, i = Math.sqrt(n * n + r * r);
		this._dollyEnd.set(0, i), this._dollyDelta.set(0, (this._dollyEnd.y / this._dollyStart.y) ** +this.zoomSpeed), this._dollyOut(this._dollyDelta.y), this._dollyStart.copy(this._dollyEnd);
		let a = (e.pageX + t.x) * .5, o = (e.pageY + t.y) * .5;
		this._updateZoomParameters(a, o);
	}
	_handleTouchMoveDollyPan(e) {
		this.enableZoom && this._handleTouchMoveDolly(e), this.enablePan && this._handleTouchMovePan(e);
	}
	_handleTouchMoveDollyRotate(e) {
		this.enableZoom && this._handleTouchMoveDolly(e), this.enableRotate && this._handleTouchMoveRotate(e);
	}
	_addPointer(e) {
		this._pointers.push(e.pointerId);
	}
	_removePointer(e) {
		delete this._pointerPositions[e.pointerId];
		for (let t = 0; t < this._pointers.length; t++) if (this._pointers[t] == e.pointerId) {
			this._pointers.splice(t, 1);
			return;
		}
	}
	_isTrackingPointer(e) {
		for (let t = 0; t < this._pointers.length; t++) if (this._pointers[t] == e.pointerId) return !0;
		return !1;
	}
	_trackPointer(e) {
		let t = this._pointerPositions[e.pointerId];
		t === void 0 && (t = new P(), this._pointerPositions[e.pointerId] = t), t.set(e.pageX, e.pageY);
	}
	_getSecondPointerPosition(e) {
		let t = e.pointerId === this._pointers[0] ? this._pointers[1] : this._pointers[0];
		return this._pointerPositions[t];
	}
	_customWheelEvent(e) {
		let t = e.deltaMode, n = {
			clientX: e.clientX,
			clientY: e.clientY,
			deltaY: e.deltaY
		};
		switch (t) {
			case 1:
				n.deltaY *= 16;
				break;
			case 2: n.deltaY *= 100;
		}
		return e.ctrlKey && !this._controlActive && (n.deltaY *= 10), n;
	}
};
function Ua(e) {
	this.enabled !== !1 && (this._pointers.length === 0 && (this.domElement.setPointerCapture(e.pointerId), this.domElement.ownerDocument.addEventListener("pointermove", this._onPointerMove), this.domElement.ownerDocument.addEventListener("pointerup", this._onPointerUp)), !this._isTrackingPointer(e) && (this._addPointer(e), e.pointerType === "touch" ? this._onTouchStart(e) : this._onMouseDown(e), this._cursorStyle === "grab" && (this.domElement.style.cursor = "grabbing")));
}
function Wa(e) {
	this.enabled !== !1 && (e.pointerType === "touch" ? this._onTouchMove(e) : this._onMouseMove(e));
}
function Ga(e) {
	switch (this._removePointer(e), this._pointers.length) {
		case 0:
			this.domElement.releasePointerCapture(e.pointerId), this.domElement.ownerDocument.removeEventListener("pointermove", this._onPointerMove), this.domElement.ownerDocument.removeEventListener("pointerup", this._onPointerUp), this.dispatchEvent(Pa), this.state = Ba.NONE, this._cursorStyle === "grab" && (this.domElement.style.cursor = "grab");
			break;
		case 1:
			let t = this._pointers[0], n = this._pointerPositions[t];
			this._onTouchStart({
				pointerId: t,
				pageX: n.x,
				pageY: n.y
			});
	}
}
function Ka(e) {
	let t;
	switch (e.button) {
		case 0:
			t = this.mouseButtons.LEFT;
			break;
		case 1:
			t = this.mouseButtons.MIDDLE;
			break;
		case 2:
			t = this.mouseButtons.RIGHT;
			break;
		default: t = -1;
	}
	switch (t) {
		case Pe.DOLLY:
			if (this.enableZoom === !1) return;
			this._handleMouseDownDolly(e), this.state = Ba.DOLLY;
			break;
		case Pe.ROTATE:
			if (e.ctrlKey || e.metaKey || e.shiftKey) {
				if (this.enablePan === !1) return;
				this._handleMouseDownPan(e), this.state = Ba.PAN;
			} else {
				if (this.enableRotate === !1) return;
				this._handleMouseDownRotate(e), this.state = Ba.ROTATE;
			}
			break;
		case Pe.PAN:
			if (e.ctrlKey || e.metaKey || e.shiftKey) {
				if (this.enableRotate === !1) return;
				this._handleMouseDownRotate(e), this.state = Ba.ROTATE;
			} else {
				if (this.enablePan === !1) return;
				this._handleMouseDownPan(e), this.state = Ba.PAN;
			}
			break;
		default: this.state = Ba.NONE;
	}
	this.state !== Ba.NONE && this.dispatchEvent(Na);
}
function qa(e) {
	switch (this.state) {
		case Ba.ROTATE:
			if (this.enableRotate === !1) return;
			this._handleMouseMoveRotate(e);
			break;
		case Ba.DOLLY:
			if (this.enableZoom === !1) return;
			this._handleMouseMoveDolly(e);
			break;
		case Ba.PAN:
			if (this.enablePan === !1) return;
			this._handleMouseMovePan(e);
	}
}
function Ja(e) {
	this.enabled !== !1 && this.enableZoom !== !1 && this.state === Ba.NONE && (e.preventDefault(), this.dispatchEvent(Na), this._handleMouseWheel(this._customWheelEvent(e)), this.dispatchEvent(Pa));
}
function Ya(e) {
	this.enabled !== !1 && this._handleKeyDown(e);
}
function Xa(e) {
	switch (this._trackPointer(e), this._pointers.length) {
		case 1:
			switch (this.touches.ONE) {
				case be.ROTATE:
					if (this.enableRotate === !1) return;
					this._handleTouchStartRotate(e), this.state = Ba.TOUCH_ROTATE;
					break;
				case be.PAN:
					if (this.enablePan === !1) return;
					this._handleTouchStartPan(e), this.state = Ba.TOUCH_PAN;
					break;
				default: this.state = Ba.NONE;
			}
			break;
		case 2:
			switch (this.touches.TWO) {
				case be.DOLLY_PAN:
					if (this.enableZoom === !1 && this.enablePan === !1) return;
					this._handleTouchStartDollyPan(e), this.state = Ba.TOUCH_DOLLY_PAN;
					break;
				case be.DOLLY_ROTATE:
					if (this.enableZoom === !1 && this.enableRotate === !1) return;
					this._handleTouchStartDollyRotate(e), this.state = Ba.TOUCH_DOLLY_ROTATE;
					break;
				default: this.state = Ba.NONE;
			}
			break;
		default: this.state = Ba.NONE;
	}
	this.state !== Ba.NONE && this.dispatchEvent(Na);
}
function Za(e) {
	switch (this._trackPointer(e), this.state) {
		case Ba.TOUCH_ROTATE:
			if (this.enableRotate === !1) return;
			this._handleTouchMoveRotate(e), this.update();
			break;
		case Ba.TOUCH_PAN:
			if (this.enablePan === !1) return;
			this._handleTouchMovePan(e), this.update();
			break;
		case Ba.TOUCH_DOLLY_PAN:
			if (this.enableZoom === !1 && this.enablePan === !1) return;
			this._handleTouchMoveDollyPan(e), this.update();
			break;
		case Ba.TOUCH_DOLLY_ROTATE:
			if (this.enableZoom === !1 && this.enableRotate === !1) return;
			this._handleTouchMoveDollyRotate(e), this.update();
			break;
		default: this.state = Ba.NONE;
	}
}
function Qa(e) {
	this.enabled !== !1 && e.preventDefault();
}
function $a(e) {
	e.key === "Control" && (this._controlActive = !0, this.domElement.getRootNode().addEventListener("keyup", this._interceptControlUp, {
		passive: !0,
		capture: !0
	}));
}
function eo(e) {
	e.key === "Control" && (this._controlActive = !1, this.domElement.getRootNode().removeEventListener("keyup", this._interceptControlUp, {
		passive: !0,
		capture: !0
	}));
}
//#endregion
//#region ../scene3d/src/model/meshFromThree.ts
var to = (e) => {
	let t = e;
	return t?.map ?? t?.normalMap ?? t?.roughnessMap ?? t?.metalnessMap ?? t?.aoMap ?? t?.emissiveMap ?? null;
}, no = 15e5;
async function ro(e, t, n) {
	e.updateMatrixWorld(!0);
	let r = [], i = [], a = [], o = /* @__PURE__ */ new Set(), s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map(), l = [], u = (e, n) => {
		let r = c.get(e);
		return r || (r = n().then((e) => e ? a.push(e) - 1 : (t && o.add("Some textures could not be read (compressed GPU textures); those parts do without them."), -1)), c.set(e, r)), r;
	}, d = (e, n) => u(`${e.uuid}:${n}`, () => t ? t(e, n) : Promise.resolve(null)), f = (e) => {
		if (!e) return i.push(Yt()) - 1;
		let t = s.get(e);
		if (t !== void 0) return t;
		let r = e, a = r.color ?? new I(1, 1, 1), c = (e) => e && e.channel !== 0 ? (o.add("Some maps use a second set of texture coordinates and were left out."), null) : e ?? null;
		for (let e of [
			"map",
			"normalMap",
			"roughnessMap",
			"metalnessMap",
			"aoMap",
			"emissiveMap",
			"clearcoatMap",
			"clearcoatRoughnessMap",
			"clearcoatNormalMap",
			"sheenColorMap",
			"sheenRoughnessMap",
			"transmissionMap"
		]) r[e] = c(r[e]);
		let f = (r.sheenColor ?? new I(0, 0, 0)).clone().multiplyScalar(r.sheen ?? 0), p = (r.emissive ?? new I(0, 0, 0)).clone().multiplyScalar(r.emissiveIntensity ?? 1), m = r.roughness ?? (r.shininess === void 0 ? .6 : 1 - Math.min(1, Math.sqrt(r.shininess / 100))), h = {
			color: [
				a.r,
				a.g,
				a.b
			],
			opacity: e.opacity ?? 1,
			metalness: r.metalness ?? 0,
			roughness: m,
			texture: -1,
			normalTexture: -1,
			normalScale: Math.abs(r.normalScale?.x ?? 1) || 1,
			roughnessTexture: -1,
			occlusionTexture: -1,
			occlusionStrength: r.aoMapIntensity ?? 1,
			emissive: [
				p.r,
				p.g,
				p.b
			],
			emissiveTexture: -1,
			clearcoat: r.clearcoat ?? 0,
			clearcoatTexture: -1,
			clearcoatRoughness: r.clearcoatRoughness ?? 0,
			clearcoatRoughnessTexture: -1,
			clearcoatNormalTexture: -1,
			clearcoatNormalScale: Math.abs(r.clearcoatNormalScale?.x ?? 1) || 1,
			sheenColor: [
				f.r,
				f.g,
				f.b
			],
			sheenColorTexture: -1,
			sheenRoughness: r.sheenRoughness ?? 0,
			sheenRoughnessTexture: -1,
			transmission: r.transmission ?? 0,
			transmissionTexture: -1,
			ior: Math.min(3, Math.max(1, r.ior ?? 1.5)),
			cutout: e.alphaTest > 0 || e.transparent,
			doubleSided: e.side === 2
		}, g = i.push(h) - 1;
		s.set(e, g), r.map && l.push(d(r.map, "color").then((e) => void (h.texture = e))), r.normalMap && l.push(d(r.normalMap, "data").then((e) => void (h.normalTexture = e))), r.aoMap && l.push(d(r.aoMap, "data").then((e) => void (h.occlusionTexture = e))), r.emissiveMap && l.push(d(r.emissiveMap, "color").then((e) => void (h.emissiveTexture = e)));
		let _ = [
			[
				r.clearcoatMap,
				"data",
				(e) => h.clearcoatTexture = e
			],
			[
				r.clearcoatRoughnessMap,
				"data",
				(e) => h.clearcoatRoughnessTexture = e
			],
			[
				r.clearcoatNormalMap,
				"data",
				(e) => h.clearcoatNormalTexture = e
			],
			[
				r.sheenColorMap,
				"color",
				(e) => h.sheenColorTexture = e
			],
			[
				r.sheenRoughnessMap,
				"data",
				(e) => h.sheenRoughnessTexture = e
			],
			[
				r.transmissionMap,
				"data",
				(e) => h.transmissionTexture = e
			]
		];
		for (let [e, t, n] of _) e && l.push(d(e, t).then(n));
		let v = r.roughnessMap ?? null, y = r.metalnessMap ?? null;
		if (v || y) {
			let e = v && v === y ? v : null;
			l.push((e ? d(e, "data") : u(`${v?.uuid}+${y?.uuid}`, () => n ? n(v, y) : Promise.resolve(null))).then((e) => void (h.roughnessTexture = e)));
		}
		return g;
	}, p = 0;
	if (e.traverse((e) => {
		let t = e;
		if (!t.isMesh || !t.visible) return;
		let n = t.geometry, i = n.getAttribute("position");
		if (!i) return;
		let a = n.getIndex(), s = n.getAttribute("normal"), c = n.getAttribute("uv"), l = n.getAttribute("color"), u = Array.isArray(t.material) ? t.material : [t.material], d = n.groups.length ? n.groups : [{
			start: 0,
			count: a ? a.count : i.count,
			materialIndex: 0
		}], m = t.isInstancedMesh ? t : null, h = [];
		if (m) for (let e = 0; e < m.count; e++) {
			let n = new Ie();
			m.getMatrixAt(e, n), h.push(t.matrixWorld.clone().multiply(n));
		}
		else h.push(t.matrixWorld);
		t.isSkinnedMesh && o.add("Rigged models come in their resting pose.");
		for (let e of h) {
			let t = new z().getNormalMatrix(e), n = e.determinant() < 0;
			for (let o of d) {
				let d = u[o.materialIndex ?? 0] ?? u[0], m = f(d), h = !!l && d?.vertexColors === !0, g = to(d);
				g && g.updateMatrix();
				let _ = Math.min(o.start + o.count, a ? a.count : i.count), v = /* @__PURE__ */ new Map(), y = [];
				for (let e = o.start; e + 2 < _; e += 3) {
					let t = [
						0,
						1,
						2
					].map((t) => a ? a.getX(e + t) : e + t);
					n && ([t[1], t[2]] = [t[2], t[1]]);
					for (let e of t) v.has(e) || v.set(e, v.size), y.push(v.get(e));
				}
				if (!y.length) continue;
				let b = v.size, x = new Float32Array(b * 3), S = s ? new Float32Array(b * 3) : null, C = c ? new Float32Array(b * 2) : null, w = h ? new Float32Array(b * 3) : null, T = new L(), E = new P();
				for (let [n, r] of v) T.fromBufferAttribute(i, n).applyMatrix4(e), x.set([
					T.x,
					T.y,
					T.z
				], r * 3), S && (T.fromBufferAttribute(s, n).applyMatrix3(t).normalize(), S.set([
					T.x,
					T.y,
					T.z
				], r * 3)), C && (E.set(c.getX(n), c.getY(n)), g && (E.applyMatrix3(g.matrix), g.flipY && (E.y = 1 - E.y)), C.set([E.x, E.y], r * 2)), w && w.set([
					l.getX(n),
					l.getY(n),
					l.getZ(n)
				], r * 3);
				let D = Uint32Array.from(y);
				if (p += D.length / 3, p > 15e5) throw Error(`This model has more than ${no.toLocaleString("en")} triangles; simplify it first (Blender's Decimate does it).`);
				let O = !!S;
				for (let e = 0; O && e < b; e++) Math.hypot(S[e * 3], S[e * 3 + 1], S[e * 3 + 2]) > 1e-4 || (O = !1);
				r.push({
					positions: x,
					normals: O ? S : Vt(x, D),
					uvs: C,
					colors: w,
					indices: D,
					material: m
				});
			}
		}
	}), await Promise.all(l), !r.length) throw Error("There is nothing to draw in that file (no triangles).");
	return {
		asset: nn(r, i, a),
		warnings: [...o]
	};
}
function io(e, t) {
	return {
		name: t.slice(0, 80) || "Model",
		data: Ut($t(e)),
		triangles: e.triangles,
		size: e.max.map((t, n) => t - e.min[n]),
		centre: e.min.map((t, n) => (t + e.max[n]) / 2)
	};
}
//#endregion
//#region ../scene3d/src/model/card.ts
function ao(e, t, n, r, i = "Product photo") {
	let a = Math.max(.01, n / Math.max(1, r)), [o, s] = [-a / 2, a / 2], c = (e, t, n) => ({
		positions: new Float32Array([
			o,
			0,
			e,
			s,
			0,
			e,
			s,
			1,
			e,
			o,
			1,
			e
		]),
		normals: new Float32Array([
			0,
			0,
			t,
			0,
			0,
			t,
			0,
			0,
			t,
			0,
			0,
			t
		]),
		uvs: new Float32Array(n ? [
			1,
			1,
			0,
			1,
			0,
			0,
			1,
			0
		] : [
			0,
			1,
			1,
			1,
			1,
			0,
			0,
			0
		]),
		colors: null,
		indices: new Uint32Array(t === 1 ? [
			0,
			1,
			2,
			0,
			2,
			3
		] : [
			0,
			2,
			1,
			0,
			3,
			2
		]),
		material: 0
	}), l = {
		...Yt(),
		color: [
			1,
			1,
			1
		],
		roughness: 1,
		texture: 0,
		cutout: !0,
		unlit: !0
	};
	return io(nn([c(0, 1, !1), c(-.002, -1, !0)], [l], [{
		mime: t,
		bytes: e
	}]), i);
}
//#endregion
//#region ../scene3d/node_modules/mediabunny/dist/modules/src/misc.js
function q(e) {
	if (!e) throw Error("Assertion failed.");
}
var oo = Math.PI / 180, so = 180 / Math.PI, co = (e) => {
	let t = (e % 360 + 360) % 360;
	if (t === 0 || t === 90 || t === 180 || t === 270) return t;
	throw Error(`Invalid rotation ${e}.`);
}, lo = [
	1,
	0,
	0,
	0,
	1,
	0,
	0,
	0,
	1
], uo = (e, t, n) => {
	let [r, i, , a, o] = e, s = Math.abs(r) * t + Math.abs(a) * n, c = Math.abs(i) * t + Math.abs(o) * n;
	return _o(_o(ho(-t / 2, -n / 2), e), ho(s / 2, c / 2));
}, fo = (e) => {
	let [t, n] = e;
	return co(Uo(Math.atan2(n, po(e) ? -t : t) * so, 90));
}, po = (e) => {
	let [t, n, , r, i] = e;
	return t * i - n * r < 0;
}, mo = (e) => {
	let t = e * oo, n = Math.round(Math.cos(t)), r = Math.round(Math.sin(t));
	return [
		n,
		r,
		0,
		-r,
		n,
		0,
		0,
		0,
		1
	];
}, ho = (e, t) => [
	1,
	0,
	0,
	0,
	1,
	0,
	e,
	t,
	1
], go = (e, t) => [
	e,
	0,
	0,
	0,
	t,
	0,
	0,
	0,
	1
], _o = (e, t) => {
	let n = Array(9);
	for (let r = 0; r < 3; r++) for (let i = 0; i < 3; i++) n[3 * r + i] = e[3 * r] * t[i] + e[3 * r + 1] * t[3 + i] + e[3 * r + 2] * t[6 + i];
	return n;
}, vo = (e, t, n, r) => ({
	rotation: co(e + (t ? -n : n)),
	flip: t !== r
}), yo = (e) => e && e[e.length - 1], bo = (e) => e >= 0 && e < 2 ** 32, xo = (e) => e >= -(2 ** 31) && e < 2 ** 31, J = (e) => {
	let t = 0;
	for (; e.readBits(1) === 0 && t < 32;) t++;
	if (t >= 32) throw Error("Invalid exponential-Golomb code.");
	return (1 << t) - 1 + e.readBits(t);
}, So = (e) => {
	let t = J(e);
	return t & 1 ? t + 1 >> 1 : -(t >> 1);
}, Co = (e, t, n, r) => {
	for (let i = t; i < n; i++) {
		let t = Math.floor(i / 8), a = e[t], o = 7 - (i & 7);
		a &= ~(1 << o), a |= (r & 1 << n - i - 1) >> n - i - 1 << o, e[t] = a;
	}
}, wo = (e) => e.constructor === Uint8Array ? e : ArrayBuffer.isView(e) ? new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : new Uint8Array(e), To = (e) => e.constructor === DataView ? e : ArrayBuffer.isView(e) ? new DataView(e.buffer, e.byteOffset, e.byteLength) : new DataView(e), Eo = globalThis.TextEncoder === void 0 ? class {
	constructor() {
		this.encoding = "utf-8";
	}
	encode(e = "") {
		let t = new Uint8Array(3 * e.length), n = 0;
		for (let r = 0; r < e.length; r++) {
			let i = e.charCodeAt(r);
			if (i < 128) t[n++] = i;
			else if (i < 2048) t[n++] = 192 | i >> 6, t[n++] = 128 | i & 63;
			else if (i < 55296 || i > 57343) t[n++] = 224 | i >> 12, t[n++] = 128 | i >> 6 & 63, t[n++] = 128 | i & 63;
			else {
				let a = r + 1 < e.length ? e.charCodeAt(r + 1) : 0;
				i < 56320 && a >= 56320 && a <= 57343 ? (i = 65536 + (i - 55296 << 10) + (a - 56320), r++, t[n++] = 240 | i >> 18, t[n++] = 128 | i >> 12 & 63, t[n++] = 128 | i >> 6 & 63, t[n++] = 128 | i & 63) : (t[n++] = 239, t[n++] = 191, t[n++] = 189);
			}
		}
		return t.slice(0, n);
	}
} : globalThis.TextEncoder;
globalThis.TextDecoder === void 0 || globalThis.TextDecoder;
var Do = /* #__PURE__ */ new Eo(), Oo = {
	bt709: 1,
	bt470bg: 5,
	smpte170m: 6,
	bt2020: 9,
	smpte432: 12
}, ko = {
	bt709: 1,
	smpte170m: 6,
	linear: 8,
	"iec61966-2-1": 13,
	pq: 16,
	hlg: 18
}, Ao = {
	rgb: 0,
	bt709: 1,
	bt470bg: 5,
	smpte170m: 6,
	"bt2020-ncl": 9
}, jo = (e) => !e || e.primaries == null && e.transfer == null && e.matrix == null && e.fullRange == null, Mo = (e) => e instanceof ArrayBuffer || typeof SharedArrayBuffer < "u" && e instanceof SharedArrayBuffer || ArrayBuffer.isView(e), No = class {
	constructor() {
		this.currentPromise = Promise.resolve(), this.pending = 0;
	}
	async acquire() {
		let e, t = new Promise((t) => {
			let n = !1;
			e = () => {
				n ||= (t(), this.pending--, !0);
			};
		}), n = this.currentPromise;
		return this.currentPromise = t, this.pending++, await n, e;
	}
}, Po = (e) => [...e].map((e) => e.toString(16).padStart(2, "0")).join(""), Fo = (e) => (e = e >> 1 & 1431655765 | (e & 1431655765) << 1, e = e >> 2 & 858993459 | (e & 858993459) << 2, e = e >> 4 & 252645135 | (e & 252645135) << 4, e = e >> 8 & 16711935 | (e & 16711935) << 8, e = e >> 16 & 65535 | (e & 65535) << 16, e >>> 0), Io = (e, t, n) => {
	let r = 0, i = e.length - 1, a = -1;
	for (; r <= i;) {
		let o = r + (i - r + 1) / 2 | 0;
		n(e[o]) <= t ? (a = o, r = o + 1) : i = o - 1;
	}
	return a;
}, Lo = () => {
	let e, t;
	return {
		promise: new Promise((n, r) => {
			e = n, t = r;
		}),
		resolve: e,
		reject: t
	};
}, Ro = (e) => {
	throw Error(`Unexpected value: ${e}`);
}, zo = (e, t, n) => {
	let r = e.getUint8(t), i = e.getUint8(t + 1), a = e.getUint8(t + 2);
	return n ? r | i << 8 | a << 16 : r << 16 | i << 8 | a;
}, Bo = (e, t, n, r) => {
	n >>>= 0, n &= 16777215, r ? (e.setUint8(t, n & 255), e.setUint8(t + 1, n >>> 8 & 255), e.setUint8(t + 2, n >>> 16 & 255)) : (e.setUint8(t, n >>> 16 & 255), e.setUint8(t + 1, n >>> 8 & 255), e.setUint8(t + 2, n & 255));
}, Vo = (e, t, n) => Math.max(t, Math.min(n, e)), Ho = (e, t, n) => e + (t - e) * n, Uo = (e, t) => Math.round(e / t) * t, Wo = (e, t) => Math.round(e * t) / t, Go = (e, t) => Math.floor(e * t) / t, Ko = (e) => {
	let t = 0;
	for (; e !== 0;) e &= e - 1, t++;
	return t;
}, qo = /^[a-z]{3}$/, Jo = (e) => qo.test(e), Yo = 1e6 * (1 + 2 ** -52), Xo = (e, t) => {
	let n = e < 0 ? -1 : 1;
	e = Math.abs(e);
	let r = 0, i = 1, a = 1, o = 0, s = e;
	for (;;) {
		let e = Math.floor(s), c = e * a + r, l = e * o + i;
		if (l > t) return {
			num: n * a,
			den: o
		};
		if (r = a, i = o, a = c, o = l, s = 1 / (s - e), !isFinite(s)) break;
	}
	return {
		num: n * a,
		den: o
	};
}, Zo = class {
	constructor() {
		this.currentPromise = Promise.resolve();
	}
	call(e) {
		return this.currentPromise = this.currentPromise.then(e);
	}
}, Qo = null, $o = () => Qo === null ? Qo = typeof navigator < "u" && navigator.userAgent?.includes("Firefox") : Qo, es = null, ts = () => es === null ? es = !(typeof navigator > "u" || !navigator.vendor?.includes("Google Inc") && !/Chrome/.test(navigator.userAgent)) : es, ns = (e) => globalThis.isSecureContext !== void 0 && !globalThis.isSecureContext ? `${e} is not available in this environment; this may be because this page is running in an insecure context. Try serving your page over HTTPS or use localhost.` : `${e} is not available in this environment.`, rs = (e) => e instanceof DOMException && e.name === "QuotaExceededError" && /reclaimed/i.test(e.message), is = (/* #__PURE__ */ (async () => {})()).constructor, as = (e) => e instanceof is || e instanceof Promise || typeof e?.then == "function", os = function* (e) {
	for (let t in e) {
		let n = e[t];
		n !== void 0 && (yield {
			key: t,
			value: n
		});
	}
}, ss = (e) => {
	switch (e.toLowerCase()) {
		case "image/jpeg":
		case "image/jpg": return ".jpg";
		case "image/png": return ".png";
		case "image/gif": return ".gif";
		case "image/webp": return ".webp";
		case "image/bmp": return ".bmp";
		case "image/svg+xml": return ".svg";
		case "image/tiff": return ".tiff";
		case "image/avif": return ".avif";
		case "image/x-icon":
		case "image/vnd.microsoft.icon": return ".ico";
		default: return null;
	}
}, cs = (e, t) => {
	if (e.length !== t.length) return !1;
	for (let n = 0; n < e.length; n++) if (e[n] !== t[n]) return !1;
	return !0;
}, ls = () => {
	Symbol.dispose ??= Symbol("Symbol.dispose");
}, us = (e) => typeof e == "number" && !Number.isNaN(e), ds = (e, t) => {
	let n = -1, r = Infinity;
	for (let i = 0; i < e.length; i++) {
		let a = t(e[i]);
		a < r && (r = a, n = i);
	}
	return n;
}, fs = (e) => {
	q(Number.isInteger(e.num)), q(Number.isInteger(e.den)), q(e.den !== 0);
	let t = Math.abs(e.num), n = Math.abs(e.den);
	for (; n !== 0;) {
		let e = t % n;
		t = n, n = e;
	}
	let r = t || 1;
	return {
		num: e.num / r,
		den: e.den / r
	};
}, ps = (e, t) => {
	if (typeof e != "object" || !e) throw TypeError(`${t} must be an object.`);
	if (!Number.isInteger(e.left) || e.left < 0) throw TypeError(`${t}.left must be a non-negative integer.`);
	if (!Number.isInteger(e.top) || e.top < 0) throw TypeError(`${t}.top must be a non-negative integer.`);
	if (!Number.isInteger(e.width) || e.width < 0) throw TypeError(`${t}.width must be a non-negative integer.`);
	if (!Number.isInteger(e.height) || e.height < 0) throw TypeError(`${t}.height must be a non-negative integer.`);
}, ms = (e) => new Promise((t) => setTimeout(t, e)), hs = (e) => Array.isArray(e) ? e : [e], gs = class {
	constructor() {
		this._listeners = /* @__PURE__ */ new Map();
	}
	on(e, t, n) {
		this._listeners.has(e) || this._listeners.set(e, /* @__PURE__ */ new Set());
		let r = {
			fn: t,
			once: n?.once ?? !1
		};
		return this._listeners.get(e).add(r), () => {
			this._listeners.get(e)?.delete(r);
		};
	}
	_emit(...e) {
		let [t, n] = e, r = this._listeners.get(t);
		if (r) for (let e of r) {
			try {
				e.fn(n);
			} catch (e) {
				console.error(e);
			}
			e.once && r.delete(e);
		}
	}
}, _s = (e) => typeof e == "object" && !!e && Object.getPrototypeOf(e) === Object.prototype && Object.values(e).every((e) => typeof e == "string"), vs;
(function(e) {
	e[e.Silent = 0] = "Silent", e[e.Errors = 1] = "Errors", e[e.Warnings = 2] = "Warnings", e[e.Info = 3] = "Info";
})(vs ||= {});
var ys = class e {
	constructor() {}
	static get level() {
		return e._level;
	}
	static set level(t) {
		if (t !== vs.Silent && t !== vs.Errors && t !== vs.Warnings && t !== vs.Info) throw TypeError("Invalid log level. Use one of the values of the LogLevel enum.");
		e._level = t;
	}
	static get _emitter() {
		return e._emitterInstance ??= new gs();
	}
	static on(t, n, r) {
		return e._emitter.on(t, n, r);
	}
	static _error(...t) {
		e._emitter._emit("error", t), e._level >= vs.Errors && console.error(...t);
	}
	static _warn(...t) {
		e._emitter._emit("warn", t), e._level >= vs.Warnings && console.warn(...t);
	}
	static _info(...t) {
		e._emitter._emit("info", t), e._level >= vs.Info && console.info(...t);
	}
};
ys._level = vs.Info, ys._emitterInstance = null;
//#endregion
//#region ../scene3d/node_modules/mediabunny/dist/modules/src/metadata.js
var bs = class {
	constructor(e, t) {
		if (this.data = e, this.mimeType = t, !(e instanceof Uint8Array)) throw TypeError("data must be a Uint8Array.");
		if (typeof t != "string") throw TypeError("mimeType must be a string.");
	}
}, xs = class {
	constructor(e, t, n, r) {
		if (this.data = e, this.mimeType = t, this.name = n, this.description = r, !(e instanceof Uint8Array)) throw TypeError("data must be a Uint8Array.");
		if (t !== void 0 && typeof t != "string") throw TypeError("mimeType, when provided, must be a string.");
		if (n !== void 0 && typeof n != "string") throw TypeError("name, when provided, must be a string.");
		if (r !== void 0 && typeof r != "string") throw TypeError("description, when provided, must be a string.");
	}
}, Ss = (e) => {
	if (!e || typeof e != "object") throw TypeError("tags must be an object.");
	if (e.title !== void 0 && typeof e.title != "string") throw TypeError("tags.title, when provided, must be a string.");
	if (e.description !== void 0 && typeof e.description != "string") throw TypeError("tags.description, when provided, must be a string.");
	if (e.artist !== void 0 && typeof e.artist != "string") throw TypeError("tags.artist, when provided, must be a string.");
	if (e.album !== void 0 && typeof e.album != "string") throw TypeError("tags.album, when provided, must be a string.");
	if (e.albumArtist !== void 0 && typeof e.albumArtist != "string") throw TypeError("tags.albumArtist, when provided, must be a string.");
	if (e.trackNumber !== void 0 && (!Number.isInteger(e.trackNumber) || e.trackNumber <= 0)) throw TypeError("tags.trackNumber, when provided, must be a positive integer.");
	if (e.tracksTotal !== void 0 && (!Number.isInteger(e.tracksTotal) || e.tracksTotal <= 0)) throw TypeError("tags.tracksTotal, when provided, must be a positive integer.");
	if (e.discNumber !== void 0 && (!Number.isInteger(e.discNumber) || e.discNumber <= 0)) throw TypeError("tags.discNumber, when provided, must be a positive integer.");
	if (e.discsTotal !== void 0 && (!Number.isInteger(e.discsTotal) || e.discsTotal <= 0)) throw TypeError("tags.discsTotal, when provided, must be a positive integer.");
	if (e.genre !== void 0 && typeof e.genre != "string") throw TypeError("tags.genre, when provided, must be a string.");
	if (e.date !== void 0 && (!(e.date instanceof Date) || Number.isNaN(e.date.getTime()))) throw TypeError("tags.date, when provided, must be a valid Date.");
	if (e.beatsPerMinute !== void 0 && (!Number.isInteger(e.beatsPerMinute) || e.beatsPerMinute <= 0)) throw TypeError("tags.beatsPerMinute, when provided, must be a positive integer.");
	if (e.lyrics !== void 0 && typeof e.lyrics != "string") throw TypeError("tags.lyrics, when provided, must be a string.");
	if (e.images !== void 0) {
		if (!Array.isArray(e.images)) throw TypeError("tags.images, when provided, must be an array.");
		for (let t of e.images) {
			if (!t || typeof t != "object") throw TypeError("Each image in tags.images must be an object.");
			if (!(t.data instanceof Uint8Array)) throw TypeError("Each image.data must be a Uint8Array.");
			if (typeof t.mimeType != "string") throw TypeError("Each image.mimeType must be a string.");
			if (![
				"coverFront",
				"coverBack",
				"unknown"
			].includes(t.kind)) throw TypeError("Each image.kind must be 'coverFront', 'coverBack', or 'unknown'.");
		}
	}
	if (e.comment !== void 0 && typeof e.comment != "string") throw TypeError("tags.comment, when provided, must be a string.");
	if (e.raw !== void 0) {
		if (!e.raw || typeof e.raw != "object") throw TypeError("tags.raw, when provided, must be an object.");
		for (let t of Object.values(e.raw)) if (t !== null && typeof t != "string" && !(Array.isArray(t) && t.every((e) => typeof e == "string")) && !(t instanceof Uint8Array) && !(t instanceof bs) && !(t instanceof xs) && !_s(t)) throw TypeError("Each value in tags.raw must be a string, string array, Uint8Array, RichImageData, AttachedFile, Record<string, string>, or null.");
	}
}, Cs = (e) => {
	if (!e || typeof e != "object") throw TypeError("disposition must be an object.");
	if (e.default !== void 0 && typeof e.default != "boolean") throw TypeError("disposition.default must be a boolean.");
	if (e.primary !== void 0 && typeof e.primary != "boolean") throw TypeError("disposition.primary must be a boolean.");
	if (e.forced !== void 0 && typeof e.forced != "boolean") throw TypeError("disposition.forced must be a boolean.");
	if (e.original !== void 0 && typeof e.original != "boolean") throw TypeError("disposition.original must be a boolean.");
	if (e.commentary !== void 0 && typeof e.commentary != "boolean") throw TypeError("disposition.commentary must be a boolean.");
	if (e.hearingImpaired !== void 0 && typeof e.hearingImpaired != "boolean") throw TypeError("disposition.hearingImpaired must be a boolean.");
	if (e.visuallyImpaired !== void 0 && typeof e.visuallyImpaired != "boolean") throw TypeError("disposition.visuallyImpaired must be a boolean.");
}, ws = class e {
	constructor(e) {
		this.bytes = e, this.pos = 0;
	}
	seekToByte(e) {
		this.pos = 8 * e;
	}
	readBit() {
		let e = Math.floor(this.pos / 8), t = this.bytes[e] ?? 0, n = 7 - (this.pos & 7), r = (t & 1 << n) >> n;
		return this.pos++, r;
	}
	readBits(e) {
		if (e === 1) return this.readBit();
		let t = 0;
		for (let n = 0; n < e; n++) t <<= 1, t |= this.readBit();
		return t;
	}
	writeBits(e, t) {
		let n = this.pos + e;
		for (let e = this.pos; e < n; e++) {
			let r = Math.floor(e / 8), i = this.bytes[r], a = 7 - (e & 7);
			i &= ~(1 << a), i |= (t & 1 << n - e - 1) >> n - e - 1 << a, this.bytes[r] = i;
		}
		this.pos = n;
	}
	copyBits(e, t) {
		let n = 0;
		for (; n < e - 7; n += 8) this.writeBits(8, t.readBits(8));
		let r = e - n;
		r > 0 && this.writeBits(r, t.readBits(r));
	}
	readAlignedByte() {
		if (this.pos % 8 != 0) throw Error("Bitstream is not byte-aligned.");
		let e = this.pos / 8, t = this.bytes[e] ?? 0;
		return this.pos += 8, t;
	}
	skipBits(e) {
		this.pos += e;
	}
	getBitsLeft() {
		return this.bytes.length * 8 - this.pos;
	}
	clone() {
		let t = new e(this.bytes);
		return t.pos = this.pos, t;
	}
}, Ts = [
	96e3,
	88200,
	64e3,
	48e3,
	44100,
	32e3,
	24e3,
	22050,
	16e3,
	12e3,
	11025,
	8e3,
	7350
], Es = [
	-1,
	1,
	2,
	3,
	4,
	5,
	6,
	8
], Ds = (e) => {
	let t = e.objectType === 5 || e.objectType === 29, n = e.objectType === 29, r = t ? e.outputSampleRate / 2 : e.outputSampleRate, i = n ? 1 : e.outputNumberOfChannels, a = Es.indexOf(i);
	if (a === -1) throw TypeError(`Unsupported number of channels: ${e.outputNumberOfChannels}`);
	let o = 16;
	e.objectType >= 32 && (o += 6), As(r) === 15 && (o += 24), t && (o += 9, As(e.outputSampleRate) === 15 && (o += 24));
	let s = Math.ceil(o / 8), c = new Uint8Array(s), l = new ws(c);
	return Os(l, e.objectType), ks(l, r), l.writeBits(4, a), t && (ks(l, e.outputSampleRate), Os(l, 2)), l.writeBits(3, 0), c;
}, Os = (e, t) => {
	t < 32 ? e.writeBits(5, t) : (e.writeBits(5, 31), e.writeBits(6, t - 32));
}, ks = (e, t) => {
	let n = As(t);
	e.writeBits(4, n), n === 15 && e.writeBits(24, t);
}, As = (e) => {
	let t = Ts.indexOf(e);
	return t === -1 ? 15 : t;
}, js = [
	48e3,
	44100,
	32e3
], Ms = [
	24e3,
	22050,
	16e3
], Ns = "Mediabunny v1.61.3", Ps;
(function(e) {
	e[e.NON_IDR_SLICE = 1] = "NON_IDR_SLICE", e[e.SLICE_DPA = 2] = "SLICE_DPA", e[e.SLICE_DPB = 3] = "SLICE_DPB", e[e.SLICE_DPC = 4] = "SLICE_DPC", e[e.IDR = 5] = "IDR", e[e.SEI = 6] = "SEI", e[e.SPS = 7] = "SPS", e[e.PPS = 8] = "PPS", e[e.AUD = 9] = "AUD", e[e.SPS_EXT = 13] = "SPS_EXT";
})(Ps ||= {});
var Fs;
(function(e) {
	e[e.RASL_N = 8] = "RASL_N", e[e.RASL_R = 9] = "RASL_R", e[e.BLA_W_LP = 16] = "BLA_W_LP", e[e.RSV_IRAP_VCL23 = 23] = "RSV_IRAP_VCL23", e[e.VPS_NUT = 32] = "VPS_NUT", e[e.SPS_NUT = 33] = "SPS_NUT", e[e.PPS_NUT = 34] = "PPS_NUT", e[e.AUD_NUT = 35] = "AUD_NUT", e[e.PREFIX_SEI_NUT = 39] = "PREFIX_SEI_NUT", e[e.SUFFIX_SEI_NUT = 40] = "SUFFIX_SEI_NUT";
})(Fs ||= {});
var Is = function* (e) {
	let t = 0, n = -1;
	for (; t < e.length - 2;) {
		let r = e.indexOf(0, t);
		if (r === -1 || r >= e.length - 2) break;
		t = r;
		let i = 0;
		t + 3 < e.length && e[t + 1] === 0 && e[t + 2] === 0 && e[t + 3] === 1 ? i = 4 : e[t + 1] === 0 && e[t + 2] === 1 && (i = 3), i === 0 ? t++ : (n !== -1 && t > n && (yield {
			offset: n,
			length: t - n
		}), n = t + i, t = n);
	}
	n !== -1 && n < e.length && (yield {
		offset: n,
		length: e.length - n
	});
}, Ls = function* (e, t) {
	let n = 0, r = new DataView(e.buffer, e.byteOffset, e.byteLength);
	for (; n + t <= e.length;) {
		let e;
		t === 1 ? e = r.getUint8(n) : t === 2 ? e = r.getUint16(n, !1) : t === 3 ? e = zo(r, n, !1) : (q(t === 4), e = r.getUint32(n, !1)), n += t, yield {
			offset: n,
			length: e
		}, n += e;
	}
}, Rs = (e, t) => t.description ? Ls(e, (wo(t.description)[4] & 3) + 1) : Is(e), zs = (e) => e & 31, Bs = (e) => {
	let t = [], n = e.length;
	for (let r = 0; r < n; r++) r + 2 < n && e[r] === 0 && e[r + 1] === 0 && e[r + 2] === 3 ? (t.push(0, 0), r += 2) : t.push(e[r]);
	return new Uint8Array(t);
};
new Uint8Array([
	0,
	0,
	0,
	1
]);
var Vs = (e, t) => {
	let n = e.reduce((e, n) => e + t + n.byteLength, 0), r = new Uint8Array(n), i = 0;
	for (let n of e) {
		let e = new DataView(r.buffer, r.byteOffset, r.byteLength);
		switch (t) {
			case 1:
				e.setUint8(i, n.byteLength);
				break;
			case 2:
				e.setUint16(i, n.byteLength, !1);
				break;
			case 3:
				Bo(e, i, n.byteLength, !1);
				break;
			case 4: e.setUint32(i, n.byteLength, !1);
		}
		i += t, r.set(n, i), i += n.byteLength;
	}
	return r;
}, Hs = (e) => {
	try {
		let t = [], n = [], r = [];
		for (let i of Is(e)) {
			let a = e.subarray(i.offset, i.offset + i.length), o = zs(a[0]);
			o === Ps.SPS ? t.push(a) : o === Ps.PPS ? n.push(a) : o === Ps.SPS_EXT && r.push(a);
		}
		if (t.length === 0 || n.length === 0) return null;
		let i = t[0], a = Gs(i);
		q(a !== null);
		let o = a.profileIdc === 100 || a.profileIdc === 110 || a.profileIdc === 122 || a.profileIdc === 144;
		return {
			configurationVersion: 1,
			avcProfileIndication: a.profileIdc,
			profileCompatibility: a.constraintFlags,
			avcLevelIndication: a.levelIdc,
			lengthSizeMinusOne: 3,
			sequenceParameterSets: t,
			pictureParameterSets: n,
			chromaFormat: o ? a.chromaFormatIdc : null,
			bitDepthLumaMinus8: o ? a.bitDepthLumaMinus8 : null,
			bitDepthChromaMinus8: o ? a.bitDepthChromaMinus8 : null,
			sequenceParameterSetExt: o ? r : null
		};
	} catch (e) {
		return ys._error("Error building AVC Decoder Configuration Record:", e), null;
	}
}, Us = (e) => {
	let t = [];
	t.push(e.configurationVersion), t.push(e.avcProfileIndication), t.push(e.profileCompatibility), t.push(e.avcLevelIndication), t.push(252 | e.lengthSizeMinusOne & 3), t.push(224 | e.sequenceParameterSets.length & 31);
	for (let n of e.sequenceParameterSets) {
		let e = n.byteLength;
		t.push(e >> 8), t.push(e & 255);
		for (let r = 0; r < e; r++) t.push(n[r]);
	}
	t.push(e.pictureParameterSets.length);
	for (let n of e.pictureParameterSets) {
		let e = n.byteLength;
		t.push(e >> 8), t.push(e & 255);
		for (let r = 0; r < e; r++) t.push(n[r]);
	}
	if ((e.avcProfileIndication === 100 || e.avcProfileIndication === 110 || e.avcProfileIndication === 122 || e.avcProfileIndication === 144) && e.chromaFormat !== null) {
		q(e.bitDepthLumaMinus8 !== null), q(e.bitDepthChromaMinus8 !== null), q(e.sequenceParameterSetExt !== null), t.push(252 | e.chromaFormat & 3), t.push(248 | e.bitDepthLumaMinus8 & 7), t.push(248 | e.bitDepthChromaMinus8 & 7), t.push(e.sequenceParameterSetExt.length);
		for (let n of e.sequenceParameterSetExt) {
			let e = n.byteLength;
			t.push(e >> 8), t.push(e & 255);
			for (let r = 0; r < e; r++) t.push(n[r]);
		}
	}
	return new Uint8Array(t);
}, Ws = {
	1: {
		num: 1,
		den: 1
	},
	2: {
		num: 12,
		den: 11
	},
	3: {
		num: 10,
		den: 11
	},
	4: {
		num: 16,
		den: 11
	},
	5: {
		num: 40,
		den: 33
	},
	6: {
		num: 24,
		den: 11
	},
	7: {
		num: 20,
		den: 11
	},
	8: {
		num: 32,
		den: 11
	},
	9: {
		num: 80,
		den: 33
	},
	10: {
		num: 18,
		den: 11
	},
	11: {
		num: 15,
		den: 11
	},
	12: {
		num: 64,
		den: 33
	},
	13: {
		num: 160,
		den: 99
	},
	14: {
		num: 4,
		den: 3
	},
	15: {
		num: 3,
		den: 2
	},
	16: {
		num: 2,
		den: 1
	}
}, Gs = (e) => {
	try {
		let t = Bs(e), n = new ws(t);
		if (n.skipBits(1), n.skipBits(2), n.readBits(5) !== 7) return null;
		let r = n.readAlignedByte(), i = n.readAlignedByte(), a = n.readAlignedByte();
		J(n);
		let o = 1, s = 0, c = 0, l = 0;
		if ((r === 100 || r === 110 || r === 122 || r === 244 || r === 44 || r === 83 || r === 86 || r === 118 || r === 128) && (o = J(n), o === 3 && (l = n.readBits(1)), s = J(n), c = J(n), n.skipBits(1), n.readBits(1))) {
			for (let e = 0; e < (o === 3 ? 12 : 8); e++) if (n.readBits(1)) {
				let t = e < 6 ? 16 : 64, r = 8, i = 8;
				for (let e = 0; e < t; e++) {
					if (i !== 0) {
						let e = So(n);
						i = (r + e + 256) % 256;
					}
					r = i === 0 ? r : i;
				}
			}
		}
		J(n);
		let u = J(n);
		if (u === 0) J(n);
		else if (u === 1) {
			n.skipBits(1), So(n), So(n);
			let e = J(n);
			for (let t = 0; t < e; t++) So(n);
		}
		J(n), n.skipBits(1);
		let d = J(n), f = J(n), p = 16 * (d + 1), m = 16 * (f + 1), h = p, g = m, _ = n.readBits(1);
		if (_ || n.skipBits(1), n.skipBits(1), n.readBits(1)) {
			let e = J(n), t = J(n), r = J(n), i = J(n), a, s;
			if ((l === 0 ? o : 0) === 0) a = 1, s = 2 - _;
			else {
				let e = o === 3 ? 1 : 2, t = o === 1 ? 2 : 1;
				a = e, s = t * (2 - _);
			}
			h -= a * (e + t), g -= s * (r + i);
		}
		let v = 2, y = 2, b = 2, x = 0, S = {
			num: 1,
			den: 1
		}, C = null, w = null, T = null, E = null, D = n.pos;
		if (n.readBits(1)) {
			if (n.readBits(1)) {
				let e = n.readBits(8);
				if (e === 255) S = {
					num: n.readBits(16),
					den: n.readBits(16)
				};
				else {
					let t = Ws[e];
					t && (S = t);
				}
			}
			n.readBits(1) && n.skipBits(1), n.readBits(1) && (n.skipBits(3), x = n.readBits(1), n.readBits(1) && (v = n.readBits(8), y = n.readBits(8), b = n.readBits(8))), n.readBits(1) && (J(n), J(n)), n.readBits(1) && (n.skipBits(32), n.skipBits(32), n.skipBits(1));
			let e = n.readBits(1);
			e && Ks(n);
			let t = n.readBits(1);
			t && Ks(n), (e || t) && n.skipBits(1), n.skipBits(1), T = n.pos, E = n.readBits(1), E && (n.skipBits(1), J(n), J(n), J(n), J(n), C = J(n), w = J(n));
		}
		if (C === null) {
			q(w === null);
			let e = i & 16;
			if ((r === 44 || r === 86 || r === 100 || r === 110 || r === 122 || r === 244) && e) C = 0, w = 0;
			else {
				let e = d + 1, t = f + 1, n = (2 - _) * t, r = Ic.find((e) => e.level >= a) ?? yo(Ic), i = Math.min(Math.floor(r.maxDpbMbs / (e * n)), 16);
				C = i, w = i;
			}
		}
		return q(w !== null), {
			emulationUnpreventedBytes: t,
			profileIdc: r,
			constraintFlags: i,
			levelIdc: a,
			frameMbsOnlyFlag: _,
			chromaFormatIdc: o,
			bitDepthLumaMinus8: s,
			bitDepthChromaMinus8: c,
			codedWidth: p,
			codedHeight: m,
			displayWidth: h,
			displayHeight: g,
			pixelAspectRatio: S,
			colourPrimaries: v,
			matrixCoefficients: b,
			transferCharacteristics: y,
			fullRangeFlag: x,
			numReorderFrames: C,
			maxDecFrameBuffering: w,
			vuiParametersFlagBitOffset: D,
			bitstreamRestrictionFlagBitOffset: T,
			bitstreamRestrictionFlag: E
		};
	} catch (e) {
		return ys._error("Error parsing AVC SPS:", e), null;
	}
}, Ks = (e) => {
	let t = J(e);
	e.skipBits(4), e.skipBits(4);
	for (let n = 0; n <= t; n++) J(e), J(e), e.skipBits(1);
	e.skipBits(5), e.skipBits(5), e.skipBits(5), e.skipBits(5);
}, qs = (e, t) => t.description ? Ls(e, (wo(t.description)[21] & 3) + 1) : Is(e), Js = (e) => e >> 1 & 63, Ys = (e) => {
	try {
		let t = new ws(Bs(e));
		t.skipBits(16), t.readBits(4);
		let n = t.readBits(3), r = t.readBits(1), { general_profile_space: i, general_tier_flag: a, general_profile_idc: o, general_profile_compatibility_flags: s, general_constraint_indicator_flags: c, general_level_idc: l } = Zs(t, n);
		J(t);
		let u = J(t), d = 0;
		u === 3 && (d = t.readBits(1));
		let f = J(t), p = J(t), m = f, h = p;
		if (t.readBits(1)) {
			let e = J(t), n = J(t), r = J(t), i = J(t), a = 1, o = 1, s = d === 0 ? u : 0;
			s === 1 ? (a = 2, o = 2) : s === 2 && (a = 2, o = 1), m -= (e + n) * a, h -= (r + i) * o;
		}
		let g = J(t), _ = J(t);
		J(t);
		let v = t.readBits(1) ? 0 : n, y = 0;
		for (let e = v; e <= n; e++) J(t), y = J(t), J(t);
		if (J(t), J(t), J(t), J(t), J(t), J(t), t.readBits(1) && t.readBits(1) && Qs(t), t.skipBits(1), t.skipBits(1), t.readBits(1) && (t.skipBits(4), t.skipBits(4), J(t), J(t), t.skipBits(1)), $s(t, J(t)), t.readBits(1)) {
			let e = J(t);
			for (let n = 0; n < e; n++) J(t), t.skipBits(1);
		}
		t.skipBits(1), t.skipBits(1);
		let b = 2, x = 2, S = 2, C = 0, w = 0, T = {
			num: 1,
			den: 1
		};
		if (t.readBits(1)) {
			let e = tc(t, n);
			T = e.pixelAspectRatio, b = e.colourPrimaries, x = e.transferCharacteristics, S = e.matrixCoefficients, C = e.fullRangeFlag, w = e.minSpatialSegmentationIdc;
		}
		return {
			displayWidth: m,
			displayHeight: h,
			pixelAspectRatio: T,
			colourPrimaries: b,
			transferCharacteristics: x,
			matrixCoefficients: S,
			fullRangeFlag: C,
			maxDecFrameBuffering: y + 1,
			spsMaxSubLayersMinus1: n,
			spsTemporalIdNestingFlag: r,
			generalProfileSpace: i,
			generalTierFlag: a,
			generalProfileIdc: o,
			generalProfileCompatibilityFlags: s,
			generalConstraintIndicatorFlags: c,
			generalLevelIdc: l,
			chromaFormatIdc: u,
			bitDepthLumaMinus8: g,
			bitDepthChromaMinus8: _,
			minSpatialSegmentationIdc: w
		};
	} catch (e) {
		return ys._error("Error parsing HEVC SPS:", e), null;
	}
}, Xs = (e) => {
	try {
		let t = [], n = [], r = [], i = [];
		for (let a of Is(e)) {
			let o = e.subarray(a.offset, a.offset + a.length), s = Js(o[0]);
			s === Fs.VPS_NUT ? t.push(o) : s === Fs.SPS_NUT ? n.push(o) : s === Fs.PPS_NUT ? r.push(o) : (s === Fs.PREFIX_SEI_NUT || s === Fs.SUFFIX_SEI_NUT) && i.push(o);
		}
		if (n.length === 0 || r.length === 0) return null;
		let a = Ys(n[0]);
		if (!a) return null;
		let o = 0;
		if (r.length > 0) {
			let e = r[0], t = new ws(Bs(e));
			t.skipBits(16), J(t), J(t), t.skipBits(1), t.skipBits(1), t.skipBits(3), t.skipBits(1), t.skipBits(1), J(t), J(t), So(t), t.skipBits(1), t.skipBits(1), t.readBits(1) && J(t), So(t), So(t), t.skipBits(1), t.skipBits(1), t.skipBits(1), t.skipBits(1);
			let n = t.readBits(1), i = t.readBits(1);
			o = !n && !i ? 0 : n && !i ? 2 : !n && i ? 3 : 0;
		}
		let s = [
			...t.length ? [{
				arrayCompleteness: 1,
				nalUnitType: Fs.VPS_NUT,
				nalUnits: t
			}] : [],
			...n.length ? [{
				arrayCompleteness: 1,
				nalUnitType: Fs.SPS_NUT,
				nalUnits: n
			}] : [],
			...r.length ? [{
				arrayCompleteness: 1,
				nalUnitType: Fs.PPS_NUT,
				nalUnits: r
			}] : [],
			...i.length ? [{
				arrayCompleteness: 1,
				nalUnitType: Js(i[0][0]),
				nalUnits: i
			}] : []
		];
		return {
			configurationVersion: 1,
			generalProfileSpace: a.generalProfileSpace,
			generalTierFlag: a.generalTierFlag,
			generalProfileIdc: a.generalProfileIdc,
			generalProfileCompatibilityFlags: a.generalProfileCompatibilityFlags,
			generalConstraintIndicatorFlags: a.generalConstraintIndicatorFlags,
			generalLevelIdc: a.generalLevelIdc,
			minSpatialSegmentationIdc: a.minSpatialSegmentationIdc,
			parallelismType: o,
			chromaFormatIdc: a.chromaFormatIdc,
			bitDepthLumaMinus8: a.bitDepthLumaMinus8,
			bitDepthChromaMinus8: a.bitDepthChromaMinus8,
			avgFrameRate: 0,
			constantFrameRate: 0,
			numTemporalLayers: a.spsMaxSubLayersMinus1 + 1,
			temporalIdNested: a.spsTemporalIdNestingFlag,
			lengthSizeMinusOne: 3,
			arrays: s
		};
	} catch (e) {
		return ys._error("Error building HEVC Decoder Configuration Record:", e), null;
	}
}, Zs = (e, t) => {
	let n = e.readBits(2), r = e.readBits(1), i = e.readBits(5), a = 0;
	for (let t = 0; t < 32; t++) a = a << 1 | e.readBits(1);
	let o = /* @__PURE__ */ new Uint8Array(6);
	for (let t = 0; t < 6; t++) o[t] = e.readBits(8);
	let s = e.readBits(8), c = [], l = [];
	for (let n = 0; n < t; n++) c.push(e.readBits(1)), l.push(e.readBits(1));
	if (t > 0) for (let n = t; n < 8; n++) e.skipBits(2);
	for (let n = 0; n < t; n++) c[n] && e.skipBits(88), l[n] && e.skipBits(8);
	return {
		general_profile_space: n,
		general_tier_flag: r,
		general_profile_idc: i,
		general_profile_compatibility_flags: a,
		general_constraint_indicator_flags: o,
		general_level_idc: s
	};
}, Qs = (e) => {
	for (let t = 0; t < 4; t++) for (let n = 0; n < (t === 3 ? 2 : 6); n++) if (!e.readBits(1)) J(e);
	else {
		let n = Math.min(64, 1 << 4 + (t << 1));
		t > 1 && So(e);
		for (let t = 0; t < n; t++) So(e);
	}
}, $s = (e, t) => {
	let n = [];
	for (let r = 0; r < t; r++) n[r] = ec(e, r, t, n);
}, ec = (e, t, n, r) => {
	let i = 0, a = 0, o = 0;
	if (t !== 0 && (a = e.readBits(1)), a) {
		o = t === n ? t - (J(e) + 1) : t - 1, e.readBits(1), J(e);
		let a = r[o] ?? 0;
		for (let t = 0; t <= a; t++) e.readBits(1) || e.readBits(1);
		i = r[o];
	} else {
		let t = J(e), n = J(e);
		for (let n = 0; n < t; n++) J(e), e.readBits(1);
		for (let t = 0; t < n; t++) J(e), e.readBits(1);
		i = t + n;
	}
	return i;
}, tc = (e, t) => {
	let n = 2, r = 2, i = 2, a = 0, o = 0, s = {
		num: 1,
		den: 1
	};
	if (e.readBits(1)) {
		let t = e.readBits(8);
		if (t === 255) s = {
			num: e.readBits(16),
			den: e.readBits(16)
		};
		else {
			let e = Ws[t];
			e && (s = e);
		}
	}
	return e.readBits(1) && e.readBits(1), e.readBits(1) && (e.readBits(3), a = e.readBits(1), e.readBits(1) && (n = e.readBits(8), r = e.readBits(8), i = e.readBits(8))), e.readBits(1) && (J(e), J(e)), e.readBits(1), e.readBits(1), e.readBits(1), e.readBits(1) && (J(e), J(e), J(e), J(e)), e.readBits(1) && (e.readBits(32), e.readBits(32), e.readBits(1) && J(e), e.readBits(1) && nc(e, !0, t)), e.readBits(1) && (e.readBits(1), e.readBits(1), e.readBits(1), o = J(e), J(e), J(e), J(e), J(e)), {
		pixelAspectRatio: s,
		colourPrimaries: n,
		transferCharacteristics: r,
		matrixCoefficients: i,
		fullRangeFlag: a,
		minSpatialSegmentationIdc: o
	};
}, nc = (e, t, n) => {
	let r = !1, i = !1, a = !1;
	t && (r = e.readBits(1) === 1, i = e.readBits(1) === 1, (r || i) && (a = e.readBits(1) === 1, a && (e.readBits(8), e.readBits(5), e.readBits(1), e.readBits(5)), e.readBits(4), e.readBits(4), a && e.readBits(4), e.readBits(5), e.readBits(5), e.readBits(5)));
	for (let t = 0; t <= n; t++) {
		let t = e.readBits(1) === 1, n = !0;
		t || (n = e.readBits(1) === 1);
		let o = !1;
		n ? J(e) : o = e.readBits(1) === 1;
		let s = 1;
		o || (s = J(e) + 1), r && rc(e, s, a), i && rc(e, s, a);
	}
}, rc = (e, t, n) => {
	for (let r = 0; r < t; r++) J(e), J(e), n && (J(e), J(e)), e.readBits(1);
}, ic = (e) => {
	let t = [];
	t.push(e.configurationVersion), t.push((e.generalProfileSpace & 3) << 6 | (e.generalTierFlag & 1) << 5 | e.generalProfileIdc & 31), t.push(e.generalProfileCompatibilityFlags >>> 24 & 255), t.push(e.generalProfileCompatibilityFlags >>> 16 & 255), t.push(e.generalProfileCompatibilityFlags >>> 8 & 255), t.push(e.generalProfileCompatibilityFlags & 255), t.push(...e.generalConstraintIndicatorFlags), t.push(e.generalLevelIdc & 255), t.push(240 | e.minSpatialSegmentationIdc >> 8 & 15), t.push(e.minSpatialSegmentationIdc & 255), t.push(252 | e.parallelismType & 3), t.push(252 | e.chromaFormatIdc & 3), t.push(248 | e.bitDepthLumaMinus8 & 7), t.push(248 | e.bitDepthChromaMinus8 & 7), t.push(e.avgFrameRate >> 8 & 255), t.push(e.avgFrameRate & 255), t.push((e.constantFrameRate & 3) << 6 | (e.numTemporalLayers & 7) << 3 | (e.temporalIdNested & 1) << 2 | e.lengthSizeMinusOne & 3), t.push(e.arrays.length & 255);
	for (let n of e.arrays) {
		t.push((n.arrayCompleteness & 1) << 7 | n.nalUnitType & 63), t.push(n.nalUnits.length >> 8 & 255), t.push(n.nalUnits.length & 255);
		for (let e of n.nalUnits) {
			t.push(e.length >> 8 & 255), t.push(e.length & 255);
			for (let n = 0; n < e.length; n++) t.push(e[n]);
		}
	}
	return new Uint8Array(t);
}, ac;
(function(e) {
	e[e.audAllowed = 0] = "audAllowed", e[e.beforeFirstVcl = 1] = "beforeFirstVcl", e[e.afterFirstVcl = 2] = "afterFirstVcl", e[e.eoBitstreamAllowed = 3] = "eoBitstreamAllowed", e[e.noMoreDataAllowed = 4] = "noMoreDataAllowed";
})(ac ||= {});
var oc = {
	1: {
		colourPrimaries: 5,
		transferCharacteristics: 6,
		matrixCoefficients: 5
	},
	2: {
		colourPrimaries: 1,
		transferCharacteristics: 1,
		matrixCoefficients: 1
	},
	3: {
		colourPrimaries: 6,
		transferCharacteristics: 6,
		matrixCoefficients: 6
	},
	4: {
		colourPrimaries: 7,
		transferCharacteristics: 7,
		matrixCoefficients: 7
	},
	5: {
		colourPrimaries: 9,
		transferCharacteristics: 14,
		matrixCoefficients: 9
	},
	7: {
		colourPrimaries: 1,
		transferCharacteristics: 13,
		matrixCoefficients: 0
	}
}, sc = (e) => {
	let t = new ws(e);
	if (t.readBits(2) !== 2) return null;
	let n = t.readBits(1), r = (t.readBits(1) << 1) + n;
	if (r === 3 && t.skipBits(1), t.readBits(1) === 1 || t.readBits(1) !== 0 || (t.skipBits(2), t.readBits(24) !== 4817730)) return null;
	let i = 8;
	r >= 2 && (i = t.readBits(1) ? 12 : 10);
	let a = t.readBits(3), o = 0, s = 0;
	if (a !== 7) {
		if (s = t.readBits(1), r === 1 || r === 3) {
			let e = t.readBits(1), n = t.readBits(1);
			o = !e && !n ? 3 : e && !n ? 2 : 1, t.skipBits(1);
		} else o = 1;
	} else o = 3, s = 1;
	let c = t.readBits(16), l = t.readBits(16), u = (c + 1) * (l + 1), d = yo(Rc).level;
	for (let e of Rc) if (u <= e.maxPictureSize) {
		d = e.level;
		break;
	}
	let f = oc[a], p = f?.colourPrimaries ?? 2, m = f?.transferCharacteristics ?? 2, h = f?.matrixCoefficients ?? 2;
	return {
		profile: r,
		level: d,
		bitDepth: i,
		chromaSubsampling: o,
		videoFullRangeFlag: s,
		colourPrimaries: p,
		transferCharacteristics: m,
		matrixCoefficients: h
	};
}, cc = function* (e) {
	let t = new ws(e), n = () => {
		let e = 0;
		for (let n = 0; n < 8; n++) {
			let r = t.readAlignedByte();
			if (e += (r & 127) * 2 ** (n * 7), !(r & 128)) break;
			if (n === 7 && r & 128) return null;
		}
		return e > 2 ** 32 - 1 ? null : e;
	};
	for (; t.getBitsLeft() >= 8;) {
		t.skipBits(1);
		let r = t.readBits(4), i = t.readBits(1), a = t.readBits(1);
		t.skipBits(1), i && t.skipBits(8);
		let o;
		if (a) {
			let e = n();
			if (e === null) return;
			o = e;
		} else o = Math.floor(t.getBitsLeft() / 8);
		q(t.pos % 8 == 0), yield {
			type: r,
			data: e.subarray(t.pos / 8, t.pos / 8 + o)
		}, t.skipBits(o * 8);
	}
}, lc = (e) => {
	for (let { type: t, data: n } of cc(e)) {
		if (t !== 1) continue;
		let e = new ws(n), r = e.readBits(3);
		e.readBits(1);
		let i = e.readBits(1), a = 0, o = 0, s = 0;
		if (i) a = e.readBits(5);
		else {
			let t = e.readBits(1), n = 0;
			if (t) {
				if (e.skipBits(32), e.skipBits(32), e.readBits(1)) {
					let t = 0;
					for (; t < 32 && !e.readBits(1);) t++;
					t < 32 && e.skipBits(t);
				}
				n = e.readBits(1), n && (s = e.readBits(5), e.skipBits(32), e.skipBits(5), e.skipBits(5));
			}
			let r = e.readBits(1), i = e.readBits(5);
			for (let t = 0; t <= i; t++) {
				e.skipBits(12);
				let i = e.readBits(5);
				if (t === 0 && (a = i), i > 7) {
					let n = e.readBits(1);
					t === 0 && (o = n);
				}
				if (n && e.readBits(1)) {
					let t = s + 1;
					e.skipBits(t), e.skipBits(t), e.skipBits(1);
				}
				r && e.readBits(1) && e.skipBits(4);
			}
		}
		let c = e.readBits(4), l = e.readBits(4), u = c + 1;
		e.skipBits(u);
		let d = l + 1;
		e.skipBits(d);
		let f = 0;
		if (f = i ? 0 : e.readBits(1), f && (e.skipBits(4), e.skipBits(3)), e.skipBits(1), e.skipBits(1), e.skipBits(1), !i) {
			e.skipBits(1), e.skipBits(1), e.skipBits(1), e.skipBits(1);
			let t = e.readBits(1);
			t && (e.skipBits(1), e.skipBits(1));
			let n = e.readBits(1), r = 0;
			r = n ? 2 : e.readBits(1), r > 0 && (e.readBits(1) || e.skipBits(1)), t && e.skipBits(3);
		}
		e.skipBits(1), e.skipBits(1), e.skipBits(1);
		let p = e.readBits(1), m = 8;
		r === 2 && p ? m = e.readBits(1) ? 12 : 10 : r <= 2 && (m = p ? 10 : 8);
		let h = 0;
		r !== 1 && (h = e.readBits(1));
		let g = 2, _ = 2, v = 2;
		e.readBits(1) && (g = e.readBits(8), _ = e.readBits(8), v = e.readBits(8));
		let y = 0, b = 1, x = 1, S = 0;
		return h ? y = e.readBits(1) : g === 1 && _ === 13 && v === 0 ? (y = 1, b = 0, x = 0) : (y = e.readBits(1), r === 0 ? (b = 1, x = 1) : r === 1 ? (b = 0, x = 0) : m === 12 ? (b = e.readBits(1), x = b ? e.readBits(1) : 0) : (b = 1, x = 0), b && x && (S = e.readBits(2))), {
			profile: r,
			level: a,
			tier: o,
			bitDepth: m,
			monochrome: h,
			chromaSubsamplingX: b,
			chromaSubsamplingY: x,
			chromaSamplePosition: S,
			videoFullRangeFlag: y,
			colourPrimaries: g,
			transferCharacteristics: _,
			matrixCoefficients: v
		};
	}
	return null;
}, uc = (e) => e.colourPrimaries !== 2 || e.transferCharacteristics !== 2 || e.matrixCoefficients !== 2, dc = (e) => {
	let t = To(e), n = t.getUint8(9), r = t.getUint16(10, !0), i = t.getUint32(12, !0), a = t.getInt16(16, !0), o = t.getUint8(18), s = null;
	return o && (s = e.subarray(19, 21 + n)), {
		outputChannelCount: n,
		preSkip: r,
		inputSampleRate: i,
		outputGain: a,
		channelMappingFamily: o,
		channelMappingTable: s
	};
}, fc = (e, t, n) => {
	switch (e) {
		case "avc":
			for (let e of Rs(n, t)) {
				let t = n[e.offset], r = zs(t);
				if (r >= Ps.NON_IDR_SLICE && r <= Ps.SLICE_DPC) return "delta";
				if (r === Ps.IDR) return "key";
				if (r === Ps.SEI && !ts()) {
					let t = Bs(n.subarray(e.offset, e.offset + e.length)), r = 1;
					do {
						let e = 0;
						for (;;) {
							let n = t[r++];
							if (n === void 0 || (e += n, n < 255)) break;
						}
						let n = 0;
						for (;;) {
							let e = t[r++];
							if (e === void 0 || (n += e, e < 255)) break;
						}
						if (e === 6) {
							let e = new ws(t);
							e.pos = 8 * r;
							let n = J(e), i = e.readBits(1);
							if (n === 0 && i === 1) return "key";
						}
						r += n;
					} while (r < t.length - 1);
				}
			}
			return "delta";
		case "hevc":
			for (let e of qs(n, t)) {
				let t = Js(n[e.offset]);
				if (t < Fs.BLA_W_LP) return "delta";
				if (t <= Fs.RSV_IRAP_VCL23) return "key";
			}
			return "delta";
		case "vp8": return n[0] & 1 ? "delta" : "key";
		case "vp9": {
			let e = new ws(n);
			if (e.readBits(2) !== 2) return null;
			let t = e.readBits(1);
			return (e.readBits(1) << 1) + t === 3 && e.skipBits(1), e.readBits(1) ? null : e.readBits(1) === 0 ? "key" : "delta";
		}
		case "av1": {
			let e = !1;
			for (let { type: t, data: r } of cc(n)) if (t === 1) {
				let t = new ws(r);
				t.skipBits(4), e = !!t.readBits(1);
			} else if (t === 3 || t === 6 || t === 7) {
				if (e) return "key";
				let t = new ws(r);
				return t.readBits(1) ? null : t.readBits(2) === 0 ? "key" : "delta";
			}
			return null;
		}
		case "prores": return "key";
		default: Ro(e), q(!1);
	}
}, pc;
(function(e) {
	e[e.STREAMINFO = 0] = "STREAMINFO", e[e.VORBIS_COMMENT = 4] = "VORBIS_COMMENT", e[e.PICTURE = 6] = "PICTURE";
})(pc ||= {});
var mc = (e) => {
	if (e.length < 7 || e[0] !== 11 || e[1] !== 119) return null;
	let t = new ws(e);
	t.skipBits(16), t.skipBits(16);
	let n = t.readBits(2);
	if (n === 3) return null;
	let r = t.readBits(6), i = t.readBits(5);
	if (i > 8) return null;
	let a = t.readBits(3), o = t.readBits(3);
	return o & 1 && o !== 1 && t.skipBits(2), o & 4 && t.skipBits(2), o === 2 && t.skipBits(2), {
		fscod: n,
		bsid: i,
		bsmod: a,
		acmod: o,
		lfeon: t.readBits(1),
		bitRateCode: Math.floor(r / 2)
	};
};
new Uint8Array([
	5,
	4,
	65,
	67,
	45,
	51
]), new Uint8Array([
	5,
	4,
	69,
	65,
	67,
	51
]);
var hc = [
	1,
	2,
	3,
	6
], gc = (e) => {
	if (e.length < 6 || e[0] !== 11 || e[1] !== 119) return null;
	let t = new ws(e);
	t.skipBits(16);
	let n = t.readBits(2);
	if (t.skipBits(3), n !== 0 && n !== 2) return null;
	let r = t.readBits(11), i = t.readBits(2), a = 0, o;
	i === 3 ? (a = t.readBits(2), o = 3) : o = t.readBits(2);
	let s = t.readBits(3), c = t.readBits(1), l = t.readBits(5);
	if (l < 11 || l > 16) return null;
	let u = hc[o], d;
	return d = i < 3 ? js[i] / 1e3 : Ms[a] / 1e3, {
		dataRate: Math.round((r + 1) * d / (u * 16)),
		substreams: [{
			fscod: i,
			fscod2: a,
			bsid: l,
			bsmod: 0,
			acmod: s,
			lfeon: c,
			numDepSub: 0,
			chanLoc: 0
		}]
	};
}, _c = 8, vc = [
	0,
	8e3,
	16e3,
	32e3,
	0,
	0,
	11025,
	22050,
	44100,
	0,
	0,
	12e3,
	24e3,
	48e3,
	96e3,
	192e3
], yc = [
	32e3,
	56e3,
	64e3,
	96e3,
	112e3,
	128e3,
	192e3,
	224e3,
	256e3,
	32e4,
	384e3,
	448e3,
	512e3,
	576e3,
	64e4,
	768e3,
	96e4,
	1024e3,
	1152e3,
	128e4,
	1344e3,
	1408e3,
	1411200,
	1472e3,
	1536e3,
	192e4,
	2048e3,
	3072e3,
	384e4,
	0,
	0,
	0
], bc = [
	16,
	16,
	20,
	20,
	0,
	24,
	24,
	0
], xc = [
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	6,
	6,
	6,
	7,
	8,
	8
], Sc = [
	1,
	2,
	2,
	2,
	2,
	3,
	18,
	19,
	6,
	7,
	518,
	323,
	83,
	519,
	582,
	535
], Cc = 8, wc = [
	32e3,
	44100,
	48e3,
	0
], Tc = [
	8e3,
	16e3,
	32e3,
	64e3,
	128e3,
	22050,
	44100,
	88200,
	176400,
	352800,
	12e3,
	24e3,
	48e3,
	96e3,
	192e3,
	384e3
], Ec = [
	512,
	1024,
	2048,
	4096
], Dc = (e) => {
	let t = Oc(e), n = To(e), r = t ? Math.ceil(t.frameSize / 4) * 4 : 0, i = null;
	for (; r + 4 <= e.length && n.getUint32(r) === 1683496997;) {
		let t = kc(e.subarray(r));
		if (!t) break;
		i ??= t, r += t.frameSize;
	}
	if (t) return {
		frameSize: i ? r : t.frameSize,
		sampleRate: t.sampleRate,
		numberOfChannels: t.numberOfChannels,
		sampleCount: t.sampleCount,
		channelLayout: t.channelLayout,
		pcmResolution: t.pcmResolution,
		bitRate: t.bitRate,
		core: t,
		hasExtensions: i !== null
	};
	if (!i?.asset) return null;
	let { asset: a } = i;
	return {
		frameSize: r,
		sampleRate: a.sampleRate,
		numberOfChannels: a.numberOfChannels,
		sampleCount: a.sampleCount,
		channelLayout: a.channelLayout,
		pcmResolution: a.pcmResolution,
		bitRate: 0,
		core: null,
		hasExtensions: !0
	};
}, Oc = (e) => {
	if (e.length < 18 || e[0] !== 127 || e[1] !== 254 || e[2] !== 128 || e[3] !== 1) return null;
	let t = new ws(e);
	if (t.skipBits(32), t.skipBits(1), t.readBits(5) !== 31) return null;
	let n = t.readBits(1), r = t.readBits(7) + 1;
	if (r % _c !== 0) return null;
	let i = t.readBits(14) + 1;
	if (i < 96) return null;
	let a = t.readBits(6);
	if (a >= xc.length) return null;
	let o = vc[t.readBits(4)];
	if (o === 0) return null;
	let s = yc[t.readBits(5)];
	if (t.readBits(1) !== 0) return null;
	t.skipBits(4), t.skipBits(5);
	let c = t.readBits(2);
	if (c === 3) return null;
	t.skipBits(1), n && t.skipBits(16), t.skipBits(7);
	let l = bc[t.readBits(3)];
	if (l === 0) return null;
	let u = c !== 0;
	return {
		frameSize: i,
		sampleRate: o,
		numberOfChannels: xc[a] + +!!u,
		sampleCount: r * 32,
		channelLayout: Sc[a] | (u ? Cc : 0),
		amode: a,
		lfePresent: u,
		bitRate: s,
		pcmResolution: l
	};
}, kc = (e) => {
	if (e.length < 10 || e[0] !== 100 || e[1] !== 88 || e[2] !== 32 || e[3] !== 37) return null;
	let t = new ws(e);
	t.skipBits(32), t.skipBits(8);
	let n = t.readBits(2), r = t.readBits(1), i = 8 + 4 * r, a = 16 + 4 * r;
	t.skipBits(i);
	let o = t.readBits(a) + 1, s = {
		frameSize: o,
		asset: null
	};
	if (!t.readBits(1)) return s;
	let c = wc[t.readBits(2)], l = 512 * (t.readBits(3) + 1);
	t.readBits(1) && t.skipBits(36);
	let u = t.readBits(3) + 1, d = t.readBits(3) + 1, f = [];
	for (let e = 0; e < u; e++) f.push(t.readBits(n + 1));
	for (let e of f) t.skipBits(8 * Ko(e));
	if (t.readBits(1)) {
		t.skipBits(2);
		let e = t.readBits(2) + 1 << 2, n = t.readBits(2) + 1;
		t.skipBits(n * e);
	}
	for (let e = 0; e < d; e++) t.skipBits(a);
	t.skipBits(9), t.skipBits(3), t.readBits(1) && t.skipBits(4), t.readBits(1) && t.skipBits(24), t.readBits(1) && t.skipBits(8 * (t.readBits(10) + 1));
	let p = t.readBits(5) + 1, m = Tc[t.readBits(4)], h = t.readBits(8) + 1, g = 0;
	if (t.readBits(1) && (h > 2 && t.skipBits(1), h > 6 && t.skipBits(1), t.readBits(1))) {
		let e = t.readBits(2) + 1 << 2;
		g = t.readBits(e);
	}
	return c === 0 || t.getBitsLeft() < 0 ? s : {
		frameSize: o,
		asset: {
			sampleRate: m,
			numberOfChannels: h,
			sampleCount: Math.round(l * m / c),
			channelLayout: g,
			pcmResolution: p
		}
	};
}, Ac = (e) => {
	let t = /* @__PURE__ */ new Uint8Array(20), n = To(t);
	n.setUint32(0, e.sampleRate), n.setUint32(4, e.bitRate), n.setUint32(8, e.bitRate), t[12] = e.pcmResolution;
	let r = e.core && !e.hasExtensions ? 1 : 0, i = new ws(t);
	return i.seekToByte(13), i.writeBits(2, Math.max(Ec.indexOf(e.sampleCount), 0)), i.writeBits(5, r), i.writeBits(1, +!!e.core?.lfePresent), i.writeBits(6, e.core?.amode ?? 0), i.writeBits(14, e.core ? e.core.frameSize - 1 : 0), i.writeBits(1, 0), i.writeBits(3, 0), i.writeBits(16, e.channelLayout), i.writeBits(1, 0), i.writeBits(1, 0), i.writeBits(1, 0), i.writeBits(5, 0), t;
}, jc = [
	"avc",
	"hevc",
	"vp9",
	"av1",
	"vp8",
	"prores"
], Mc = [
	"pcm-s16",
	"pcm-s16be",
	"pcm-s24",
	"pcm-s24be",
	"pcm-s32",
	"pcm-s32be",
	"pcm-f32",
	"pcm-f32be",
	"pcm-f64",
	"pcm-f64be",
	"pcm-u8",
	"pcm-s8",
	"ulaw",
	"alaw"
], Nc = [
	"aac",
	"opus",
	"mp3",
	"vorbis",
	"flac",
	"ac3",
	"eac3",
	"dts"
], Pc = [...Nc, ...Mc], Fc = ["webvtt"], Ic = [
	{
		maxMacroblocks: 99,
		maxBitrate: 64e3,
		maxDpbMbs: 396,
		level: 10
	},
	{
		maxMacroblocks: 396,
		maxBitrate: 192e3,
		maxDpbMbs: 900,
		level: 11
	},
	{
		maxMacroblocks: 396,
		maxBitrate: 384e3,
		maxDpbMbs: 2376,
		level: 12
	},
	{
		maxMacroblocks: 396,
		maxBitrate: 768e3,
		maxDpbMbs: 2376,
		level: 13
	},
	{
		maxMacroblocks: 396,
		maxBitrate: 2e6,
		maxDpbMbs: 2376,
		level: 20
	},
	{
		maxMacroblocks: 792,
		maxBitrate: 4e6,
		maxDpbMbs: 4752,
		level: 21
	},
	{
		maxMacroblocks: 1620,
		maxBitrate: 4e6,
		maxDpbMbs: 8100,
		level: 22
	},
	{
		maxMacroblocks: 1620,
		maxBitrate: 1e7,
		maxDpbMbs: 8100,
		level: 30
	},
	{
		maxMacroblocks: 3600,
		maxBitrate: 14e6,
		maxDpbMbs: 18e3,
		level: 31
	},
	{
		maxMacroblocks: 5120,
		maxBitrate: 2e7,
		maxDpbMbs: 20480,
		level: 32
	},
	{
		maxMacroblocks: 8192,
		maxBitrate: 2e7,
		maxDpbMbs: 32768,
		level: 40
	},
	{
		maxMacroblocks: 8192,
		maxBitrate: 5e7,
		maxDpbMbs: 32768,
		level: 41
	},
	{
		maxMacroblocks: 8704,
		maxBitrate: 5e7,
		maxDpbMbs: 34816,
		level: 42
	},
	{
		maxMacroblocks: 22080,
		maxBitrate: 135e6,
		maxDpbMbs: 110400,
		level: 50
	},
	{
		maxMacroblocks: 36864,
		maxBitrate: 24e7,
		maxDpbMbs: 184320,
		level: 51
	},
	{
		maxMacroblocks: 36864,
		maxBitrate: 24e7,
		maxDpbMbs: 184320,
		level: 52
	},
	{
		maxMacroblocks: 139264,
		maxBitrate: 24e7,
		maxDpbMbs: 696320,
		level: 60
	},
	{
		maxMacroblocks: 139264,
		maxBitrate: 48e7,
		maxDpbMbs: 696320,
		level: 61
	},
	{
		maxMacroblocks: 139264,
		maxBitrate: 8e8,
		maxDpbMbs: 696320,
		level: 62
	}
], Lc = [
	{
		maxPictureSize: 36864,
		maxBitrate: 128e3,
		tier: "L",
		level: 30
	},
	{
		maxPictureSize: 122880,
		maxBitrate: 15e5,
		tier: "L",
		level: 60
	},
	{
		maxPictureSize: 245760,
		maxBitrate: 3e6,
		tier: "L",
		level: 63
	},
	{
		maxPictureSize: 552960,
		maxBitrate: 6e6,
		tier: "L",
		level: 90
	},
	{
		maxPictureSize: 983040,
		maxBitrate: 1e7,
		tier: "L",
		level: 93
	},
	{
		maxPictureSize: 2228224,
		maxBitrate: 12e6,
		tier: "L",
		level: 120
	},
	{
		maxPictureSize: 2228224,
		maxBitrate: 3e7,
		tier: "H",
		level: 120
	},
	{
		maxPictureSize: 2228224,
		maxBitrate: 2e7,
		tier: "L",
		level: 123
	},
	{
		maxPictureSize: 2228224,
		maxBitrate: 5e7,
		tier: "H",
		level: 123
	},
	{
		maxPictureSize: 8912896,
		maxBitrate: 25e6,
		tier: "L",
		level: 150
	},
	{
		maxPictureSize: 8912896,
		maxBitrate: 1e8,
		tier: "H",
		level: 150
	},
	{
		maxPictureSize: 8912896,
		maxBitrate: 4e7,
		tier: "L",
		level: 153
	},
	{
		maxPictureSize: 8912896,
		maxBitrate: 16e7,
		tier: "H",
		level: 153
	},
	{
		maxPictureSize: 8912896,
		maxBitrate: 6e7,
		tier: "L",
		level: 156
	},
	{
		maxPictureSize: 8912896,
		maxBitrate: 24e7,
		tier: "H",
		level: 156
	},
	{
		maxPictureSize: 35651584,
		maxBitrate: 6e7,
		tier: "L",
		level: 180
	},
	{
		maxPictureSize: 35651584,
		maxBitrate: 24e7,
		tier: "H",
		level: 180
	},
	{
		maxPictureSize: 35651584,
		maxBitrate: 12e7,
		tier: "L",
		level: 183
	},
	{
		maxPictureSize: 35651584,
		maxBitrate: 48e7,
		tier: "H",
		level: 183
	},
	{
		maxPictureSize: 35651584,
		maxBitrate: 24e7,
		tier: "L",
		level: 186
	},
	{
		maxPictureSize: 35651584,
		maxBitrate: 8e8,
		tier: "H",
		level: 186
	}
], Rc = [
	{
		maxPictureSize: 36864,
		maxBitrate: 2e5,
		level: 10
	},
	{
		maxPictureSize: 73728,
		maxBitrate: 8e5,
		level: 11
	},
	{
		maxPictureSize: 122880,
		maxBitrate: 18e5,
		level: 20
	},
	{
		maxPictureSize: 245760,
		maxBitrate: 36e5,
		level: 21
	},
	{
		maxPictureSize: 552960,
		maxBitrate: 72e5,
		level: 30
	},
	{
		maxPictureSize: 983040,
		maxBitrate: 12e6,
		level: 31
	},
	{
		maxPictureSize: 2228224,
		maxBitrate: 18e6,
		level: 40
	},
	{
		maxPictureSize: 2228224,
		maxBitrate: 3e7,
		level: 41
	},
	{
		maxPictureSize: 8912896,
		maxBitrate: 6e7,
		level: 50
	},
	{
		maxPictureSize: 8912896,
		maxBitrate: 12e7,
		level: 51
	},
	{
		maxPictureSize: 8912896,
		maxBitrate: 18e7,
		level: 52
	},
	{
		maxPictureSize: 35651584,
		maxBitrate: 18e7,
		level: 60
	},
	{
		maxPictureSize: 35651584,
		maxBitrate: 24e7,
		level: 61
	},
	{
		maxPictureSize: 35651584,
		maxBitrate: 48e7,
		level: 62
	}
], zc = [
	{
		maxPictureSize: 147456,
		maxBitrate: 15e5,
		tier: "M",
		level: 0
	},
	{
		maxPictureSize: 278784,
		maxBitrate: 3e6,
		tier: "M",
		level: 1
	},
	{
		maxPictureSize: 665856,
		maxBitrate: 6e6,
		tier: "M",
		level: 4
	},
	{
		maxPictureSize: 1065024,
		maxBitrate: 1e7,
		tier: "M",
		level: 5
	},
	{
		maxPictureSize: 2359296,
		maxBitrate: 12e6,
		tier: "M",
		level: 8
	},
	{
		maxPictureSize: 2359296,
		maxBitrate: 3e7,
		tier: "H",
		level: 8
	},
	{
		maxPictureSize: 2359296,
		maxBitrate: 2e7,
		tier: "M",
		level: 9
	},
	{
		maxPictureSize: 2359296,
		maxBitrate: 5e7,
		tier: "H",
		level: 9
	},
	{
		maxPictureSize: 8912896,
		maxBitrate: 3e7,
		tier: "M",
		level: 12
	},
	{
		maxPictureSize: 8912896,
		maxBitrate: 1e8,
		tier: "H",
		level: 12
	},
	{
		maxPictureSize: 8912896,
		maxBitrate: 4e7,
		tier: "M",
		level: 13
	},
	{
		maxPictureSize: 8912896,
		maxBitrate: 16e7,
		tier: "H",
		level: 13
	},
	{
		maxPictureSize: 8912896,
		maxBitrate: 6e7,
		tier: "M",
		level: 14
	},
	{
		maxPictureSize: 8912896,
		maxBitrate: 24e7,
		tier: "H",
		level: 14
	},
	{
		maxPictureSize: 35651584,
		maxBitrate: 6e7,
		tier: "M",
		level: 15
	},
	{
		maxPictureSize: 35651584,
		maxBitrate: 24e7,
		tier: "H",
		level: 15
	},
	{
		maxPictureSize: 35651584,
		maxBitrate: 6e7,
		tier: "M",
		level: 16
	},
	{
		maxPictureSize: 35651584,
		maxBitrate: 24e7,
		tier: "H",
		level: 16
	},
	{
		maxPictureSize: 35651584,
		maxBitrate: 1e8,
		tier: "M",
		level: 17
	},
	{
		maxPictureSize: 35651584,
		maxBitrate: 48e7,
		tier: "H",
		level: 17
	},
	{
		maxPictureSize: 35651584,
		maxBitrate: 16e7,
		tier: "M",
		level: 18
	},
	{
		maxPictureSize: 35651584,
		maxBitrate: 8e8,
		tier: "H",
		level: 18
	},
	{
		maxPictureSize: 35651584,
		maxBitrate: 16e7,
		tier: "M",
		level: 19
	},
	{
		maxPictureSize: 35651584,
		maxBitrate: 8e8,
		tier: "H",
		level: 19
	}
], Bc = ".01.01.01.01.00", Vc = ".0.110.01.01.01.0", Hc = [
	"ap4x",
	"ap4h",
	"apch",
	"apcn",
	"apcs",
	"apco"
], Uc = [
	"dtsc",
	"dtsh",
	"dtsl",
	"dtse"
], Wc = [
	{
		fourCc: "apco",
		bitrate: 45e6,
		alpha: !1
	},
	{
		fourCc: "apcs",
		bitrate: 102e6,
		alpha: !1
	},
	{
		fourCc: "apcn",
		bitrate: 147e6,
		alpha: !1
	},
	{
		fourCc: "apch",
		bitrate: 22e7,
		alpha: !1
	},
	{
		fourCc: "ap4h",
		bitrate: 33e7,
		alpha: !0
	},
	{
		fourCc: "ap4x",
		bitrate: 5e8,
		alpha: !0
	}
], Gc = (e, t, n, r, i) => {
	if (e === "avc") {
		let e = Math.ceil(t / 16) * Math.ceil(n / 16), i = Ic.find((t) => e <= t.maxMacroblocks && r <= t.maxBitrate) ?? yo(Ic), a = i ? i.level : 0;
		return `avc1.${"64".padStart(2, "0")}00${a.toString(16).padStart(2, "0")}`;
	}
	if (e === "hevc") {
		let e = t * n, i = Lc.find((t) => e <= t.maxPictureSize && r <= t.maxBitrate) ?? yo(Lc);
		return `hev1.1.6.${i.tier}${i.level}.B0`;
	}
	if (e === "vp8") return "vp8";
	if (e === "vp9") {
		let e = t * n;
		return `vp09.00.${(Rc.find((t) => e <= t.maxPictureSize && r <= t.maxBitrate) ?? yo(Rc)).level.toString().padStart(2, "0")}.08`;
	}
	if (e === "av1") {
		let e = t * n, i = zc.find((t) => e <= t.maxPictureSize && r <= t.maxBitrate) ?? yo(zc);
		return `av01.0.${i.level.toString().padStart(2, "0")}${i.tier}.08`;
	}
	if (e === "prores") {
		let e = (t * n / 2073600) ** .95, a = Wc.filter((e) => e.alpha === i), o = a[0].fourCc, s = Infinity;
		for (let { fourCc: t, bitrate: n } of a) {
			let i = Math.abs(n * e - r);
			i < s && (s = i, o = t);
		}
		return o;
	}
	throw Ro(e), TypeError(`Unhandled codec '${String(e)}'.`);
}, Kc = (e) => {
	let t = e.split(".");
	return [
		1,
		1,
		Number(t[1]),
		2,
		1,
		Number(t[2]),
		3,
		1,
		Number(t[3]),
		4,
		1,
		t[4] ? Number(t[4]) : 1
	];
}, qc = (e) => {
	let t = e.split("."), n = Number(t[1]), r = t[2], i = Number(r.slice(0, -1)), a = (n << 5) + i, o = +(r.slice(-1) === "H"), s = Number(t[3]), c = s === 8 ? 0 : 1, l = +(s === 12), u = t[4] ? Number(t[4]) : 0, d = t[5] ? Number(t[5][0]) : 1, f = t[5] ? Number(t[5][1]) : 1, p = t[5] ? Number(t[5][2]) : 0;
	return [
		129,
		a,
		(o << 7) + (c << 6) + (l << 5) + (u << 4) + (d << 3) + (f << 2) + p,
		0
	];
}, Jc = (e) => {
	let { codec: t, codecDescription: n, colorSpace: r, avcCodecInfo: i, hevcCodecInfo: a, vp9CodecInfo: o, av1CodecInfo: s, proresFormat: c } = e;
	if (t === "avc") {
		if (q(e.avcType !== null), i) {
			let t = new Uint8Array([
				i.avcProfileIndication,
				i.profileCompatibility,
				i.avcLevelIndication
			]);
			return `avc${e.avcType}.${Po(t)}`;
		}
		if (!n || n.byteLength < 4) throw TypeError("AVC decoder description is not provided or is not at least 4 bytes long.");
		return `avc${e.avcType}.${Po(n.subarray(1, 4))}`;
	}
	if (t === "hevc") {
		let e, t, r, i, o, s;
		if (a) e = a.generalProfileSpace, t = a.generalProfileIdc, r = Fo(a.generalProfileCompatibilityFlags), i = a.generalTierFlag, o = a.generalLevelIdc, s = [...a.generalConstraintIndicatorFlags];
		else {
			if (!n || n.byteLength < 23) throw TypeError("HEVC decoder description is not provided or is not at least 23 bytes long.");
			let a = To(n), c = a.getUint8(1);
			e = c >> 6 & 3, t = c & 31, r = Fo(a.getUint32(2)), i = c >> 5 & 1, o = a.getUint8(12), s = [];
			for (let e = 0; e < 6; e++) s.push(a.getUint8(6 + e));
		}
		let c = "hev1.";
		for (c += [
			"",
			"A",
			"B",
			"C"
		][e] + t, c += ".", c += r.toString(16).toUpperCase(), c += ".", c += i === 0 ? "L" : "H", c += o; s.length > 0 && s[s.length - 1] === 0;) s.pop();
		return s.length > 0 && (c += ".", c += s.map((e) => e.toString(16).toUpperCase()).join(".")), c;
	}
	if (t === "vp8") return "vp8";
	if (t === "vp9") {
		if (!o) {
			let t = e.width * e.height, n = yo(Rc).level;
			for (let e of Rc) if (t <= e.maxPictureSize) {
				n = e.level;
				break;
			}
			return `vp09.00.${n.toString().padStart(2, "0")}.08`;
		}
		let t = o.profile.toString().padStart(2, "0"), n = o.level.toString().padStart(2, "0"), r = o.bitDepth.toString().padStart(2, "0"), i = o.chromaSubsampling.toString().padStart(2, "0"), a = o.colourPrimaries.toString().padStart(2, "0"), s = o.transferCharacteristics.toString().padStart(2, "0"), c = o.matrixCoefficients.toString().padStart(2, "0"), l = o.videoFullRangeFlag.toString().padStart(2, "0"), u = `vp09.${t}.${n}.${r}.${i}`;
		return u += `.${a}.${s}.${c}.${l}`, u.endsWith(Bc) && (u = u.slice(0, -15)), u;
	}
	if (t === "av1") {
		if (!s) {
			let t = e.width * e.height, n = yo(Rc).level;
			for (let e of Rc) if (t <= e.maxPictureSize) {
				n = e.level;
				break;
			}
			return `av01.0.${n.toString().padStart(2, "0")}M.08`;
		}
		let t = s.profile, n = s.level.toString().padStart(2, "0"), i = s.tier ? "H" : "M", a = s.bitDepth.toString().padStart(2, "0"), o = s.monochrome ? "1" : "0", c = 100 * s.chromaSubsamplingX + 10 * s.chromaSubsamplingY + 1 * (s.chromaSubsamplingX && s.chromaSubsamplingY ? s.chromaSamplePosition : 0), l, u, d, f;
		uc(s) ? (l = s.colourPrimaries, u = s.transferCharacteristics, d = s.matrixCoefficients, f = s.videoFullRangeFlag) : (l = r?.primaries ? Oo[r.primaries] : 1, u = r?.transfer ? ko[r.transfer] : 1, d = r?.matrix ? Ao[r.matrix] : 1, f = +!!r?.fullRange);
		let p = `av01.${t}.${n}${i}.${a}`;
		return p += `.${o}.${c.toString().padStart(3, "0")}`, p += `.${l.toString().padStart(2, "0")}`, p += `.${u.toString().padStart(2, "0")}`, p += `.${d.toString().padStart(2, "0")}`, p += `.${f}`, p.endsWith(Vc) && (p = p.slice(0, -17)), p;
	}
	if (t === "prores") return c ?? "apch";
	throw t !== null && Ro(t), TypeError(`Unhandled codec '${t}'.`);
}, Yc = 48e3, Xc = /^pcm-([usf])(\d+)(be)?$/, Zc = (e) => {
	if (q(Mc.includes(e)), e === "ulaw") return {
		dataType: "ulaw",
		sampleSize: 1,
		littleEndian: !0,
		silentValue: 255
	};
	if (e === "alaw") return {
		dataType: "alaw",
		sampleSize: 1,
		littleEndian: !0,
		silentValue: 213
	};
	let t = Xc.exec(e);
	q(t);
	let n;
	n = t[1] === "u" ? "unsigned" : t[1] === "s" ? "signed" : "float";
	let r = Number(t[2]) / 8, i = t[3] !== "be";
	return {
		dataType: n,
		sampleSize: r,
		littleEndian: i,
		silentValue: e === "pcm-u8" ? 128 : 0
	};
}, Qc = (e) => e.startsWith("avc1") || e.startsWith("avc3") ? "avc" : e.startsWith("hev1") || e.startsWith("hvc1") ? "hevc" : e === "vp8" ? "vp8" : e.startsWith("vp09") ? "vp9" : e.startsWith("av01") ? "av1" : Hc.includes(e) ? "prores" : e === "mp3" || e === "mp4a.69" || e === "mp4a.6B" || e === "mp4a.6b" || e === "mp4a.40.34" ? "mp3" : e.startsWith("mp4a.40.") || e === "mp4a.67" ? "aac" : e === "opus" || e === "Opus" ? "opus" : e === "vorbis" ? "vorbis" : e === "flac" ? "flac" : e === "ac-3" || e === "ac3" ? "ac3" : e === "ec-3" || e === "eac3" ? "eac3" : Uc.includes(e) ? "dts" : e === "ulaw" ? "ulaw" : e === "alaw" ? "alaw" : Xc.test(e) ? e : e === "webvtt" ? "webvtt" : null, $c = (e) => e === "avc" ? { avc: { format: "avc" } } : e === "hevc" ? { hevc: { format: "hevc" } } : {}, el = [
	"avc1",
	"avc3",
	"hev1",
	"hvc1",
	"vp8",
	"vp09",
	"av01",
	...Hc
], tl = /^(avc1|avc3)\.[0-9a-fA-F]{6}$/, nl = /^(hev1|hvc1)\.(?:[ABC]?\d+)\.[0-9a-fA-F]{1,8}\.[LH]\d+(?:\.[0-9a-fA-F]{1,2}){0,6}$/, rl = /^vp09(?:\.\d{2}){3}(?:(?:\.\d{2}){5})?$/, il = /^av01\.\d\.\d{2}[MH]\.\d{2}(?:\.\d\.\d{3}\.\d{2}\.\d{2}\.\d{2}\.\d)?$/, al = (e, t) => {
	if (!e) throw TypeError("Video chunk metadata must be provided.");
	if (typeof e != "object") throw TypeError("Video chunk metadata must be an object.");
	if (!e.decoderConfig) throw TypeError("Video chunk metadata must include a decoder configuration.");
	if (typeof e.decoderConfig != "object") throw TypeError("Video chunk metadata decoder configuration must be an object.");
	if (typeof e.decoderConfig.codec != "string") throw TypeError("Video chunk metadata decoder configuration must specify a codec string.");
	if (!el.some((t) => e.decoderConfig.codec.startsWith(t))) throw TypeError("Video chunk metadata decoder configuration codec string must be a valid video codec string as specified in the Mediabunny Codec Registry.");
	if (!Number.isInteger(e.decoderConfig.codedWidth) || e.decoderConfig.codedWidth <= 0) throw TypeError("Video chunk metadata decoder configuration must specify a valid codedWidth (positive integer).");
	if (!Number.isInteger(e.decoderConfig.codedHeight) || e.decoderConfig.codedHeight <= 0) throw TypeError("Video chunk metadata decoder configuration must specify a valid codedHeight (positive integer).");
	if (e.decoderConfig.displayAspectWidth !== void 0 && (!Number.isInteger(e.decoderConfig.displayAspectWidth) || e.decoderConfig.displayAspectWidth <= 0)) throw TypeError("Video chunk metadata decoder configuration displayAspectWidth, when defined, must be a positive integer.");
	if (e.decoderConfig.displayAspectHeight !== void 0 && (!Number.isInteger(e.decoderConfig.displayAspectHeight) || e.decoderConfig.displayAspectHeight <= 0)) throw TypeError("Video chunk metadata decoder configuration displayAspectHeight, when defined, must be a positive integer.");
	if (e.decoderConfig.displayAspectWidth !== void 0 != (e.decoderConfig.displayAspectHeight !== void 0)) throw TypeError("Video chunk metadata decoder configuration must specify both displayAspectWidth and displayAspectHeight, or neither.");
	if (e.decoderConfig.description !== void 0 && !Mo(e.decoderConfig.description)) throw TypeError("Video chunk metadata decoder configuration description, when defined, must be an ArrayBuffer or an ArrayBuffer view.");
	if (e.decoderConfig.colorSpace !== void 0) {
		let { colorSpace: t } = e.decoderConfig;
		if (typeof t != "object") throw TypeError("Video chunk metadata decoder configuration colorSpace, when provided, must be an object.");
		let n = Object.keys(Oo);
		if (t.primaries != null && !n.includes(t.primaries)) throw TypeError(`Video chunk metadata decoder configuration colorSpace primaries, when defined, must be one of ${n.join(", ")}.`);
		let r = Object.keys(ko);
		if (t.transfer != null && !r.includes(t.transfer)) throw TypeError(`Video chunk metadata decoder configuration colorSpace transfer, when defined, must be one of ${r.join(", ")}.`);
		let i = Object.keys(Ao);
		if (t.matrix != null && !i.includes(t.matrix)) throw TypeError(`Video chunk metadata decoder configuration colorSpace matrix, when defined, must be one of ${i.join(", ")}.`);
		if (t.fullRange != null && typeof t.fullRange != "boolean") throw TypeError("Video chunk metadata decoder configuration colorSpace fullRange, when defined, must be a boolean.");
	}
	if (e.decoderConfig.codec.startsWith("avc1") || e.decoderConfig.codec.startsWith("avc3")) {
		if (!tl.test(e.decoderConfig.codec)) throw TypeError("Video chunk metadata decoder configuration codec string for AVC must be a valid AVC codec string as specified in Section 3.4 of RFC 6381.");
	} else if (e.decoderConfig.codec.startsWith("hev1") || e.decoderConfig.codec.startsWith("hvc1")) {
		if (!nl.test(e.decoderConfig.codec)) throw TypeError("Video chunk metadata decoder configuration codec string for HEVC must be a valid HEVC codec string as specified in Section E.3 of ISO 14496-15.");
	} else if (e.decoderConfig.codec.startsWith("vp8")) {
		if (e.decoderConfig.codec !== "vp8") throw TypeError("Video chunk metadata decoder configuration codec string for VP8 must be \"vp8\".");
	} else if (e.decoderConfig.codec.startsWith("vp09")) {
		if (!rl.test(e.decoderConfig.codec)) throw TypeError("Video chunk metadata decoder configuration codec string for VP9 must be a valid VP9 codec string as specified in Section \"Codecs Parameter String\" of https://www.webmproject.org/vp9/mp4/.");
	} else if (e.decoderConfig.codec.startsWith("av01")) {
		if (!il.test(e.decoderConfig.codec)) throw TypeError("Video chunk metadata decoder configuration codec string for AV1 must be a valid AV1 codec string as specified in Section \"Codecs Parameter String\" of https://aomediacodec.github.io/av1-isobmff/.");
	} else if (Hc.some((t) => e.decoderConfig.codec.startsWith(t)) && !Hc.some((t) => e.decoderConfig.codec === t)) throw TypeError(`Video chunk metadata decoder configuration codec string for ProRes must be one of the valid ProRes four-character codes: ${Hc.join(", ")}.`);
	if (t !== null && Qc(e.decoderConfig.codec) !== t) throw TypeError(`Video chunk metadata decoder configuration codec string '${e.decoderConfig.codec}' does not fit to the track codec '${t}'.`);
}, ol = [
	"mp4a",
	"mp3",
	"opus",
	"vorbis",
	"flac",
	"ulaw",
	"alaw",
	"pcm",
	"ac-3",
	"ec-3",
	"dts"
], sl = (e, t) => {
	if (!e) throw TypeError("Audio chunk metadata must be provided.");
	if (typeof e != "object") throw TypeError("Audio chunk metadata must be an object.");
	if (!e.decoderConfig) throw TypeError("Audio chunk metadata must include a decoder configuration.");
	if (typeof e.decoderConfig != "object") throw TypeError("Audio chunk metadata decoder configuration must be an object.");
	if (typeof e.decoderConfig.codec != "string") throw TypeError("Audio chunk metadata decoder configuration must specify a codec string.");
	if (!ol.some((t) => e.decoderConfig.codec.startsWith(t))) throw TypeError("Audio chunk metadata decoder configuration codec string must be a valid audio codec string as specified in the Mediabunny Codec Registry.");
	if (!Number.isInteger(e.decoderConfig.sampleRate) || e.decoderConfig.sampleRate <= 0) throw TypeError("Audio chunk metadata decoder configuration must specify a valid sampleRate (positive integer).");
	if (!Number.isInteger(e.decoderConfig.numberOfChannels) || e.decoderConfig.numberOfChannels <= 0) throw TypeError("Audio chunk metadata decoder configuration must specify a valid numberOfChannels (positive integer).");
	if (e.decoderConfig.description !== void 0 && !Mo(e.decoderConfig.description)) throw TypeError("Audio chunk metadata decoder configuration description, when defined, must be an ArrayBuffer or an ArrayBuffer view.");
	if (e.decoderConfig.codec.startsWith("mp4a") && e.decoderConfig.codec !== "mp4a.69" && e.decoderConfig.codec !== "mp4a.6B" && e.decoderConfig.codec !== "mp4a.6b") {
		if (![
			"mp4a.40.2",
			"mp4a.40.02",
			"mp4a.40.5",
			"mp4a.40.05",
			"mp4a.40.29",
			"mp4a.67"
		].includes(e.decoderConfig.codec)) throw TypeError("Audio chunk metadata decoder configuration codec string for AAC must be a valid AAC codec string as specified in https://www.w3.org/TR/webcodecs-aac-codec-registration/.");
	} else if (e.decoderConfig.codec.startsWith("mp3") || e.decoderConfig.codec.startsWith("mp4a")) {
		if (e.decoderConfig.codec !== "mp3" && e.decoderConfig.codec !== "mp4a.69" && e.decoderConfig.codec !== "mp4a.6B" && e.decoderConfig.codec !== "mp4a.6b") throw TypeError("Audio chunk metadata decoder configuration codec string for MP3 must be \"mp3\", \"mp4a.69\" or \"mp4a.6B\".");
	} else if (e.decoderConfig.codec.startsWith("opus")) {
		if (e.decoderConfig.codec !== "opus") throw TypeError("Audio chunk metadata decoder configuration codec string for Opus must be \"opus\".");
		if (e.decoderConfig.description && e.decoderConfig.description.byteLength < 18) throw TypeError("Audio chunk metadata decoder configuration description, when specified, is expected to be an Identification Header as specified in Section 5.1 of RFC 7845.");
	} else if (e.decoderConfig.codec.startsWith("vorbis")) {
		if (e.decoderConfig.codec !== "vorbis") throw TypeError("Audio chunk metadata decoder configuration codec string for Vorbis must be \"vorbis\".");
		if (!e.decoderConfig.description) throw TypeError("Audio chunk metadata decoder configuration for Vorbis must include a description, which is expected to adhere to the format described in https://www.w3.org/TR/webcodecs-vorbis-codec-registration/.");
	} else if (e.decoderConfig.codec.startsWith("flac")) {
		if (e.decoderConfig.codec !== "flac") throw TypeError("Audio chunk metadata decoder configuration codec string for FLAC must be \"flac\".");
		if (!e.decoderConfig.description || e.decoderConfig.description.byteLength < 42) throw TypeError("Audio chunk metadata decoder configuration for FLAC must include a description, which is expected to adhere to the format described in https://www.w3.org/TR/webcodecs-flac-codec-registration/.");
	} else if (e.decoderConfig.codec.startsWith("ac-3") || e.decoderConfig.codec.startsWith("ac3")) {
		if (e.decoderConfig.codec !== "ac-3") throw TypeError("Audio chunk metadata decoder configuration codec string for AC-3 must be \"ac-3\".");
	} else if (e.decoderConfig.codec.startsWith("ec-3") || e.decoderConfig.codec.startsWith("eac3")) {
		if (e.decoderConfig.codec !== "ec-3") throw TypeError("Audio chunk metadata decoder configuration codec string for EC-3 must be \"ec-3\".");
	} else if (e.decoderConfig.codec.startsWith("dts")) {
		if (!Uc.includes(e.decoderConfig.codec)) throw TypeError(`Audio chunk metadata decoder configuration codec string for DTS must be one of the following four-character codes: ${Uc.join(", ")}.`);
	} else if ((e.decoderConfig.codec.startsWith("pcm") || e.decoderConfig.codec.startsWith("ulaw") || e.decoderConfig.codec.startsWith("alaw")) && !Mc.includes(e.decoderConfig.codec)) throw TypeError(`Audio chunk metadata decoder configuration codec string for PCM must be one of the supported PCM codecs (${Mc.join(", ")}).`);
	if (t !== null && Qc(e.decoderConfig.codec) !== t) throw TypeError(`Audio chunk metadata decoder configuration codec string '${e.decoderConfig.codec}' does not fit to the track codec '${t}'.`);
}, cl = (e) => {
	if (!e) throw TypeError("Subtitle metadata must be provided.");
	if (typeof e != "object") throw TypeError("Subtitle metadata must be an object.");
	if (!e.config) throw TypeError("Subtitle metadata must include a config object.");
	if (typeof e.config != "object") throw TypeError("Subtitle metadata config must be an object.");
	if (typeof e.config.description != "string") throw TypeError("Subtitle metadata config description must be a string.");
}, ll = /* #__PURE__ */ new Uint8Array(), ul = class e {
	constructor(e, t, n, r, i = -1, a, o) {
		if (this.data = e, this.type = t, this.timestamp = n, this.duration = r, this.sequenceNumber = i, e === ll && a === void 0) throw Error("Internal error: byteLength must be explicitly provided when constructing metadata-only packets.");
		if (a === void 0 && (a = e.byteLength), !(e instanceof Uint8Array)) throw TypeError("data must be a Uint8Array.");
		if (t !== "key" && t !== "delta") throw TypeError("type must be either \"key\" or \"delta\".");
		if (!Number.isFinite(n)) throw TypeError("timestamp must be a number.");
		if (!Number.isFinite(r) || r < 0) throw TypeError("duration must be a non-negative number.");
		if (!Number.isFinite(i)) throw TypeError("sequenceNumber must be a number.");
		if (!Number.isInteger(a) || a < 0) throw TypeError("byteLength must be a non-negative integer.");
		if (o !== void 0 && (typeof o != "object" || !o)) throw TypeError("sideData, when provided, must be an object.");
		if (o?.alpha !== void 0 && !(o.alpha instanceof Uint8Array)) throw TypeError("sideData.alpha, when provided, must be a Uint8Array.");
		if (o?.alphaByteLength !== void 0 && (!Number.isInteger(o.alphaByteLength) || o.alphaByteLength < 0)) throw TypeError("sideData.alphaByteLength, when provided, must be a non-negative integer.");
		this.byteLength = a, this.sideData = o ?? {}, this.sideData.alpha && this.sideData.alphaByteLength === void 0 && (this.sideData.alphaByteLength = this.sideData.alpha.byteLength);
	}
	get isMetadataOnly() {
		return this.data === ll;
	}
	get microsecondTimestamp() {
		return Math.trunc(Yo * this.timestamp);
	}
	get microsecondDuration() {
		return Math.trunc(Yo * this.duration);
	}
	toEncodedVideoChunk() {
		if (this.isMetadataOnly) throw TypeError("Metadata-only packets cannot be converted to a video chunk.");
		if (typeof EncodedVideoChunk > "u") throw Error("EncodedVideoChunk is not available in this environment.");
		return new EncodedVideoChunk({
			data: this.data,
			type: this.type,
			timestamp: this.microsecondTimestamp,
			duration: this.microsecondDuration
		});
	}
	alphaToEncodedVideoChunk(e = this.type) {
		if (!this.sideData.alpha) throw TypeError("This packet does not contain alpha side data.");
		if (this.isMetadataOnly) throw TypeError("Metadata-only packets cannot be converted to a video chunk.");
		if (typeof EncodedVideoChunk > "u") throw Error("EncodedVideoChunk is not available in this environment.");
		return new EncodedVideoChunk({
			data: this.sideData.alpha,
			type: e,
			timestamp: this.microsecondTimestamp,
			duration: this.microsecondDuration
		});
	}
	toEncodedAudioChunk() {
		if (this.isMetadataOnly) throw TypeError("Metadata-only packets cannot be converted to an audio chunk.");
		if (typeof EncodedAudioChunk > "u") throw Error("EncodedAudioChunk is not available in this environment.");
		return new EncodedAudioChunk({
			data: this.data,
			type: this.type,
			timestamp: this.microsecondTimestamp,
			duration: this.microsecondDuration
		});
	}
	static fromEncodedChunk(t, n) {
		if (!(t instanceof EncodedVideoChunk || t instanceof EncodedAudioChunk)) throw TypeError("chunk must be an EncodedVideoChunk or EncodedAudioChunk.");
		let r = new Uint8Array(t.byteLength);
		return t.copyTo(r), new e(r, t.type, t.timestamp / 1e6, (t.duration ?? 0) / 1e6, void 0, void 0, n);
	}
	clone(t) {
		if (t !== void 0 && (typeof t != "object" || !t)) throw TypeError("options, when provided, must be an object.");
		if (t?.data !== void 0 && !(t.data instanceof Uint8Array)) throw TypeError("options.data, when provided, must be a Uint8Array.");
		if (t?.type !== void 0 && t.type !== "key" && t.type !== "delta") throw TypeError("options.type, when provided, must be either \"key\" or \"delta\".");
		if (t?.timestamp !== void 0 && !Number.isFinite(t.timestamp)) throw TypeError("options.timestamp, when provided, must be a number.");
		if (t?.duration !== void 0 && !Number.isFinite(t.duration)) throw TypeError("options.duration, when provided, must be a number.");
		if (t?.sequenceNumber !== void 0 && !Number.isFinite(t.sequenceNumber)) throw TypeError("options.sequenceNumber, when provided, must be a number.");
		if (t?.sideData !== void 0 && (typeof t.sideData != "object" || t.sideData === null)) throw TypeError("options.sideData, when provided, must be an object.");
		return new e(t?.data ?? this.data, t?.type ?? this.type, t?.timestamp ?? this.timestamp, t?.duration ?? this.duration, t?.sequenceNumber ?? this.sequenceNumber, this.byteLength, t?.sideData ?? this.sideData);
	}
}, dl = (e) => {
	let t = (e.hasVideo ? "video/" : e.hasAudio ? "audio/" : "application/") + (e.isQuickTime ? "quicktime" : "mp4");
	if (e.codecStrings.length > 0) {
		let n = [...new Set(e.codecStrings)];
		t += `; codecs="${n.join(", ")}"`;
	}
	return t;
}, fl = class {
	constructor(e) {
		this.value = e;
	}
}, pl = class {
	constructor(e) {
		this.value = e;
	}
}, ml = class {
	constructor(e) {
		this.value = e;
	}
}, hl = class {
	constructor(e) {
		this.value = e;
	}
}, Y;
(function(e) {
	e[e.EBML = 440786851] = "EBML", e[e.EBMLVersion = 17030] = "EBMLVersion", e[e.EBMLReadVersion = 17143] = "EBMLReadVersion", e[e.EBMLMaxIDLength = 17138] = "EBMLMaxIDLength", e[e.EBMLMaxSizeLength = 17139] = "EBMLMaxSizeLength", e[e.DocType = 17026] = "DocType", e[e.DocTypeVersion = 17031] = "DocTypeVersion", e[e.DocTypeReadVersion = 17029] = "DocTypeReadVersion", e[e.Void = 236] = "Void", e[e.Segment = 408125543] = "Segment", e[e.SeekHead = 290298740] = "SeekHead", e[e.Seek = 19899] = "Seek", e[e.SeekID = 21419] = "SeekID", e[e.SeekPosition = 21420] = "SeekPosition", e[e.Duration = 17545] = "Duration", e[e.Info = 357149030] = "Info", e[e.TimestampScale = 2807729] = "TimestampScale", e[e.MuxingApp = 19840] = "MuxingApp", e[e.WritingApp = 22337] = "WritingApp", e[e.Tracks = 374648427] = "Tracks", e[e.TrackEntry = 174] = "TrackEntry", e[e.TrackNumber = 215] = "TrackNumber", e[e.TrackUID = 29637] = "TrackUID", e[e.TrackType = 131] = "TrackType", e[e.FlagEnabled = 185] = "FlagEnabled", e[e.FlagDefault = 136] = "FlagDefault", e[e.FlagForced = 21930] = "FlagForced", e[e.FlagOriginal = 21934] = "FlagOriginal", e[e.FlagHearingImpaired = 21931] = "FlagHearingImpaired", e[e.FlagVisualImpaired = 21932] = "FlagVisualImpaired", e[e.FlagCommentary = 21935] = "FlagCommentary", e[e.FlagLacing = 156] = "FlagLacing", e[e.Name = 21358] = "Name", e[e.Language = 2274716] = "Language", e[e.LanguageBCP47 = 2274717] = "LanguageBCP47", e[e.CodecID = 134] = "CodecID", e[e.CodecPrivate = 25506] = "CodecPrivate", e[e.CodecDelay = 22186] = "CodecDelay", e[e.SeekPreRoll = 22203] = "SeekPreRoll", e[e.DefaultDuration = 2352003] = "DefaultDuration", e[e.Video = 224] = "Video", e[e.PixelWidth = 176] = "PixelWidth", e[e.PixelHeight = 186] = "PixelHeight", e[e.DisplayWidth = 21680] = "DisplayWidth", e[e.DisplayHeight = 21690] = "DisplayHeight", e[e.DisplayUnit = 21682] = "DisplayUnit", e[e.AlphaMode = 21440] = "AlphaMode", e[e.Audio = 225] = "Audio", e[e.SamplingFrequency = 181] = "SamplingFrequency", e[e.Channels = 159] = "Channels", e[e.BitDepth = 25188] = "BitDepth", e[e.SimpleBlock = 163] = "SimpleBlock", e[e.BlockGroup = 160] = "BlockGroup", e[e.Block = 161] = "Block", e[e.BlockAdditions = 30113] = "BlockAdditions", e[e.BlockMore = 166] = "BlockMore", e[e.BlockAdditional = 165] = "BlockAdditional", e[e.BlockAddID = 238] = "BlockAddID", e[e.BlockDuration = 155] = "BlockDuration", e[e.ReferenceBlock = 251] = "ReferenceBlock", e[e.Cluster = 524531317] = "Cluster", e[e.Timestamp = 231] = "Timestamp", e[e.Cues = 475249515] = "Cues", e[e.CuePoint = 187] = "CuePoint", e[e.CueTime = 179] = "CueTime", e[e.CueTrackPositions = 183] = "CueTrackPositions", e[e.CueTrack = 247] = "CueTrack", e[e.CueClusterPosition = 241] = "CueClusterPosition", e[e.Colour = 21936] = "Colour", e[e.MatrixCoefficients = 21937] = "MatrixCoefficients", e[e.TransferCharacteristics = 21946] = "TransferCharacteristics", e[e.Primaries = 21947] = "Primaries", e[e.Range = 21945] = "Range", e[e.Projection = 30320] = "Projection", e[e.ProjectionType = 30321] = "ProjectionType", e[e.ProjectionPoseYaw = 30323] = "ProjectionPoseYaw", e[e.ProjectionPosePitch = 30324] = "ProjectionPosePitch", e[e.ProjectionPoseRoll = 30325] = "ProjectionPoseRoll", e[e.Attachments = 423732329] = "Attachments", e[e.AttachedFile = 24999] = "AttachedFile", e[e.FileDescription = 18046] = "FileDescription", e[e.FileName = 18030] = "FileName", e[e.FileMediaType = 18016] = "FileMediaType", e[e.FileData = 18012] = "FileData", e[e.FileUID = 18094] = "FileUID", e[e.Chapters = 272869232] = "Chapters", e[e.Tags = 307544935] = "Tags", e[e.Tag = 29555] = "Tag", e[e.Targets = 25536] = "Targets", e[e.TargetTypeValue = 26826] = "TargetTypeValue", e[e.TargetType = 25546] = "TargetType", e[e.TagTrackUID = 25541] = "TagTrackUID", e[e.TagEditionUID = 25545] = "TagEditionUID", e[e.TagChapterUID = 25540] = "TagChapterUID", e[e.TagAttachmentUID = 25542] = "TagAttachmentUID", e[e.SimpleTag = 26568] = "SimpleTag", e[e.TagName = 17827] = "TagName", e[e.TagLanguage = 17530] = "TagLanguage", e[e.TagString = 17543] = "TagString", e[e.TagBinary = 17541] = "TagBinary", e[e.ContentEncodings = 28032] = "ContentEncodings", e[e.ContentEncoding = 25152] = "ContentEncoding", e[e.ContentEncodingOrder = 20529] = "ContentEncodingOrder", e[e.ContentEncodingScope = 20530] = "ContentEncodingScope", e[e.ContentCompression = 20532] = "ContentCompression", e[e.ContentCompAlgo = 16980] = "ContentCompAlgo", e[e.ContentCompSettings = 16981] = "ContentCompSettings", e[e.ContentEncryption = 20533] = "ContentEncryption";
})(Y ||= {});
var gl = [Y.EBML, Y.Segment], _l = [
	Y.SeekHead,
	Y.Info,
	Y.Cluster,
	Y.Tracks,
	Y.Cues,
	Y.Attachments,
	Y.Chapters,
	Y.Tags
];
[...gl, ..._l];
var vl = (e) => e < 256 ? 1 : e < 65536 ? 2 : e < 1 << 24 ? 3 : e < 2 ** 32 ? 4 : e < 2 ** 40 ? 5 : 6, yl = (e) => e < 1n << 8n ? 1 : e < 1n << 16n ? 2 : e < 1n << 24n ? 3 : e < 1n << 32n ? 4 : e < 1n << 40n ? 5 : e < 1n << 48n ? 6 : e < 1n << 56n ? 7 : 8, bl = (e) => e >= -64 && e < 64 ? 1 : e >= -8192 && e < 8192 ? 2 : e >= -1048576 && e < 1 << 20 ? 3 : e >= -134217728 && e < 1 << 27 ? 4 : e >= -(2 ** 34) && e < 2 ** 34 ? 5 : 6, xl = (e) => {
	if (e < 127) return 1;
	if (e < 16383) return 2;
	if (e < (1 << 21) - 1) return 3;
	if (e < (1 << 28) - 1) return 4;
	if (e < 2 ** 35 - 1) return 5;
	if (e < 2 ** 42 - 1) return 6;
	throw Error("EBML varint size not supported " + e);
}, Sl = class {
	constructor(e) {
		this.writer = e, this.helper = /* @__PURE__ */ new Uint8Array(8), this.helperView = new DataView(this.helper.buffer), this.offsets = /* @__PURE__ */ new WeakMap(), this.dataOffsets = /* @__PURE__ */ new WeakMap();
	}
	writeByte(e) {
		this.helperView.setUint8(0, e), this.writer.write(this.helper.subarray(0, 1));
	}
	writeFloat32(e) {
		this.helperView.setFloat32(0, e, !1), this.writer.write(this.helper.subarray(0, 4));
	}
	writeFloat64(e) {
		this.helperView.setFloat64(0, e, !1), this.writer.write(this.helper);
	}
	writeUnsignedInt(e, t = vl(e)) {
		let n = 0;
		switch (t) {
			case 6: this.helperView.setUint8(n++, e / 2 ** 40 | 0);
			case 5: this.helperView.setUint8(n++, e / 2 ** 32 | 0);
			case 4: this.helperView.setUint8(n++, e >> 24);
			case 3: this.helperView.setUint8(n++, e >> 16);
			case 2: this.helperView.setUint8(n++, e >> 8);
			case 1:
				this.helperView.setUint8(n++, e);
				break;
			default: throw Error("Bad unsigned int size " + t);
		}
		this.writer.write(this.helper.subarray(0, n));
	}
	writeUnsignedBigInt(e, t = yl(e)) {
		let n = 0;
		for (let r = t - 1; r >= 0; r--) this.helperView.setUint8(n++, Number(e >> BigInt(r * 8) & 255n));
		this.writer.write(this.helper.subarray(0, n));
	}
	writeSignedInt(e, t = bl(e)) {
		e < 0 && (e += 2 ** (t * 8)), this.writeUnsignedInt(e, t);
	}
	writeVarInt(e, t = xl(e)) {
		let n = 0;
		switch (t) {
			case 1:
				this.helperView.setUint8(n++, 128 | e);
				break;
			case 2:
				this.helperView.setUint8(n++, 64 | e >> 8), this.helperView.setUint8(n++, e);
				break;
			case 3:
				this.helperView.setUint8(n++, 32 | e >> 16), this.helperView.setUint8(n++, e >> 8), this.helperView.setUint8(n++, e);
				break;
			case 4:
				this.helperView.setUint8(n++, 16 | e >> 24), this.helperView.setUint8(n++, e >> 16), this.helperView.setUint8(n++, e >> 8), this.helperView.setUint8(n++, e);
				break;
			case 5:
				this.helperView.setUint8(n++, 8 | e / 2 ** 32 & 7), this.helperView.setUint8(n++, e >> 24), this.helperView.setUint8(n++, e >> 16), this.helperView.setUint8(n++, e >> 8), this.helperView.setUint8(n++, e);
				break;
			case 6:
				this.helperView.setUint8(n++, 4 | e / 2 ** 40 & 3), this.helperView.setUint8(n++, e / 2 ** 32 | 0), this.helperView.setUint8(n++, e >> 24), this.helperView.setUint8(n++, e >> 16), this.helperView.setUint8(n++, e >> 8), this.helperView.setUint8(n++, e);
				break;
			default: throw Error("Bad EBML varint size " + t);
		}
		this.writer.write(this.helper.subarray(0, n));
	}
	writeAsciiString(e) {
		this.writer.write(new Uint8Array(e.split("").map((e) => e.charCodeAt(0))));
	}
	writeEBML(e) {
		if (e !== null) {
			if (e instanceof Uint8Array) this.writer.write(e);
			else if (Array.isArray(e)) for (let t of e) this.writeEBML(t);
			else if (this.offsets.set(e, this.writer.getPos()), this.writeUnsignedInt(e.id), Array.isArray(e.data)) {
				let t = this.writer.getPos(), n = e.size === -1 ? 1 : e.size ?? 4;
				e.size === -1 ? this.writeByte(255) : this.writer.seek(this.writer.getPos() + n);
				let r = this.writer.getPos();
				if (this.dataOffsets.set(e, r), this.writeEBML(e.data), e.size !== -1) {
					let e = this.writer.getPos() - r, i = this.writer.getPos();
					this.writer.seek(t), this.writeVarInt(e, n), this.writer.seek(i);
				}
			} else if (typeof e.data == "number") {
				let t = e.size ?? vl(e.data);
				this.writeVarInt(t), this.writeUnsignedInt(e.data, t);
			} else if (typeof e.data == "bigint") {
				let t = e.size ?? yl(e.data);
				this.writeVarInt(t), this.writeUnsignedBigInt(e.data, t);
			} else if (typeof e.data == "string") this.writeVarInt(e.data.length), this.writeAsciiString(e.data);
			else if (e.data instanceof Uint8Array) this.writeVarInt(e.data.byteLength, e.size), this.writer.write(e.data);
			else if (e.data instanceof fl) this.writeVarInt(4), this.writeFloat32(e.data.value);
			else if (e.data instanceof pl) this.writeVarInt(8), this.writeFloat64(e.data.value);
			else if (e.data instanceof ml) {
				let t = e.size ?? bl(e.data.value);
				this.writeVarInt(t), this.writeSignedInt(e.data.value, t);
			} else if (e.data instanceof hl) {
				let t = Do.encode(e.data.value);
				this.writeVarInt(t.length), this.writer.write(t);
			} else Ro(e.data);
		}
	}
}, Cl = {
	avc: "V_MPEG4/ISO/AVC",
	hevc: "V_MPEGH/ISO/HEVC",
	vp8: "V_VP8",
	vp9: "V_VP9",
	av1: "V_AV1",
	prores: "V_PRORES",
	aac: "A_AAC",
	mp3: "A_MPEG/L3",
	opus: "A_OPUS",
	vorbis: "A_VORBIS",
	flac: "A_FLAC",
	ac3: "A_AC3",
	eac3: "A_EAC3",
	dts: "A_DTS",
	"pcm-u8": "A_PCM/INT/LIT",
	"pcm-s16": "A_PCM/INT/LIT",
	"pcm-s16be": "A_PCM/INT/BIG",
	"pcm-s24": "A_PCM/INT/LIT",
	"pcm-s24be": "A_PCM/INT/BIG",
	"pcm-s32": "A_PCM/INT/LIT",
	"pcm-s32be": "A_PCM/INT/BIG",
	"pcm-f32": "A_PCM/FLOAT/IEEE",
	"pcm-f64": "A_PCM/FLOAT/IEEE",
	webvtt: "S_TEXT/WEBVTT"
}, wl = (e) => {
	let t = (e.hasVideo ? "video/" : e.hasAudio ? "audio/" : "application/") + (e.isWebM ? "webm" : "x-matroska");
	if (e.codecStrings.length > 0) {
		let n = [...new Set(e.codecStrings.filter(Boolean))];
		t += `; codecs="${n.join(", ")}"`;
	}
	return t;
}, Tl = (e) => {
	let t = e.filePos, n = new ws(mu(e, 9));
	if (n.readBits(12) !== 4095 || (n.skipBits(1), n.readBits(2) !== 0)) return null;
	let r = n.readBits(1), i = n.readBits(2) + 1, a = n.readBits(4);
	if (a === 15) return null;
	n.skipBits(1);
	let o = n.readBits(3);
	if (o === 0) throw Error("ADTS frames with channel configuration 0 are not supported.");
	n.skipBits(1), n.skipBits(1), n.skipBits(1), n.skipBits(1);
	let s = n.readBits(13);
	n.skipBits(11);
	let c = n.readBits(2) + 1;
	if (c !== 1) throw Error("ADTS frames with more than one AAC frame are not supported.");
	let l = null;
	return r === 1 ? e.filePos -= 2 : l = n.readBits(16), {
		objectType: i,
		samplingFrequencyIndex: a,
		channelConfiguration: o,
		frameLength: s,
		numberOfAacFrames: c,
		crcCheck: l,
		startPos: t
	};
}, El = /* @__PURE__ */ e(((e, t) => {
	t.exports = {};
})), Dl = function(e, t, n) {
	if (t != null) {
		if (typeof t != "object" && typeof t != "function") throw TypeError("Object expected.");
		var r, i;
		if (n) {
			if (!Symbol.asyncDispose) throw TypeError("Symbol.asyncDispose is not defined.");
			r = t[Symbol.asyncDispose];
		}
		if (r === void 0) {
			if (!Symbol.dispose) throw TypeError("Symbol.dispose is not defined.");
			r = t[Symbol.dispose], n && (i = r);
		}
		if (typeof r != "function") throw TypeError("Object not disposable.");
		i && (r = function() {
			try {
				i.call(this);
			} catch (e) {
				return Promise.reject(e);
			}
		}), e.stack.push({
			value: t,
			dispose: r,
			async: n
		});
	} else n && e.stack.push({ async: !0 });
	return t;
}, Ol = (function(e) {
	return function(t) {
		function n(n) {
			t.error = t.hasError ? new e(n, t.error, "An error was suppressed during disposal.") : n, t.hasError = !0;
		}
		var r, i = 0;
		function a() {
			for (; r = t.stack.pop();) try {
				if (!r.async && i === 1) return i = 0, t.stack.push(r), Promise.resolve().then(a);
				if (r.dispose) {
					var e = r.dispose.call(r.value);
					if (r.async) return i |= 2, Promise.resolve(e).then(a, function(e) {
						return n(e), a();
					});
				} else i |= 1;
			} catch (e) {
				n(e);
			}
			if (i === 1) return t.hasError ? Promise.reject(t.error) : Promise.resolve();
			if (t.hasError) throw t.error;
		}
		return a();
	};
})(typeof SuppressedError == "function" ? SuppressedError : function(e, t, n) {
	var r = Error(n);
	return r.name = "SuppressedError", r.error = e, r.suppressed = t, r;
});
ls();
var kl = -Infinity, Al = -Infinity, jl = null;
typeof FinalizationRegistry < "u" && (jl = new FinalizationRegistry((e) => {
	let t = performance.now();
	e.type === "video" ? (t - kl >= 1e3 && (ys._error("A VideoSample was garbage collected without first being closed. For proper resource management, make sure to call close() on all your VideoSamples as soon as you're done using them."), kl = t), typeof VideoFrame < "u" && e.data instanceof VideoFrame && e.data.close()) : (t - Al >= 1e3 && (ys._error("An AudioSample was garbage collected without first being closed. For proper resource management, make sure to call close() on all your AudioSamples as soon as you're done using them."), Al = t), typeof AudioData < "u" && e.data instanceof AudioData && e.data.close());
}));
var Ml = class {
	constructor() {
		this._referenceCount = 0, this._lastAllocationBuffer = null;
	}
}, Nl = [
	"I420",
	"I420P10",
	"I420P12",
	"I420A",
	"I420AP10",
	"I420AP12",
	"I422",
	"I422P10",
	"I422P12",
	"I422A",
	"I422AP10",
	"I422AP12",
	"I444",
	"I444P10",
	"I444P12",
	"I444A",
	"I444AP10",
	"I444AP12",
	"NV12",
	"RGBA",
	"RGBX",
	"BGRA",
	"BGRX"
], Pl = new Set(Nl), Fl = class e {
	get codedWidth() {
		return this.visibleRect.width;
	}
	get codedHeight() {
		return this.visibleRect.height;
	}
	get displayWidth() {
		return this.rotation % 180 == 0 ? this.squarePixelWidth : this.squarePixelHeight;
	}
	get displayHeight() {
		return this.rotation % 180 == 0 ? this.squarePixelHeight : this.squarePixelWidth;
	}
	get microsecondTimestamp() {
		return Math.trunc(Yo * this.timestamp);
	}
	get microsecondDuration() {
		return Math.trunc(Yo * this.duration);
	}
	get hasAlpha() {
		return this.format && this.format.includes("A");
	}
	constructor(t, n) {
		if (this._closed = !1, t instanceof ArrayBuffer || typeof SharedArrayBuffer < "u" && t instanceof SharedArrayBuffer || ArrayBuffer.isView(t)) {
			if (!n || typeof n != "object") throw TypeError("init must be an object.");
			if (n.format === void 0 || !Pl.has(n.format)) throw TypeError("init.format must be one of: " + Nl.join(", "));
			if (!Number.isInteger(n.codedWidth) || n.codedWidth <= 0) throw TypeError("init.codedWidth must be a positive integer.");
			if (!Number.isInteger(n.codedHeight) || n.codedHeight <= 0) throw TypeError("init.codedHeight must be a positive integer.");
			if (n.rotation !== void 0 && ![
				0,
				90,
				180,
				270
			].includes(n.rotation)) throw TypeError("init.rotation, when provided, must be 0, 90, 180, or 270.");
			if (n.flip !== void 0 && typeof n.flip != "boolean") throw TypeError("init.flip, when provided, must be a boolean.");
			if (!Number.isFinite(n.timestamp)) throw TypeError("init.timestamp must be a number.");
			if (n.duration !== void 0 && (!Number.isFinite(n.duration) || n.duration < 0)) throw TypeError("init.duration, when provided, must be a non-negative number.");
			if (n.layout !== void 0) {
				if (!Array.isArray(n.layout)) throw TypeError("init.layout, when provided, must be an array.");
				for (let e of n.layout) {
					if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("Each entry in init.layout must be an object.");
					if (!Number.isInteger(e.offset) || e.offset < 0) throw TypeError("plane.offset must be a non-negative integer.");
					if (!Number.isInteger(e.stride) || e.stride < 0) throw TypeError("plane.stride must be a non-negative integer.");
				}
			}
			if (n.visibleRect !== void 0 && ps(n.visibleRect, "init.visibleRect"), n.displayWidth !== void 0 && (!Number.isInteger(n.displayWidth) || n.displayWidth <= 0)) throw TypeError("init.displayWidth, when provided, must be a positive integer.");
			if (n.displayHeight !== void 0 && (!Number.isInteger(n.displayHeight) || n.displayHeight <= 0)) throw TypeError("init.displayHeight, when provided, must be a positive integer.");
			if (n.displayWidth !== void 0 != (n.displayHeight !== void 0)) throw TypeError("init.displayWidth and init.displayHeight must be either both provided or both omitted.");
			this.format = n.format, this.rotation = n.rotation ?? 0, this.flip = n.flip ?? !1, this.timestamp = n.timestamp, this.duration = n.duration ?? 0;
			let e = n.layout ?? Kl(n.format, n.codedWidth, n.codedHeight), r = n.colorSpace ?? null;
			r === null && (r = this.format === "RGBA" || this.format === "RGBX" || this.format === "BGRA" || this.format === "BGRX" ? {
				primaries: "bt709",
				transfer: "iec61966-2-1",
				matrix: "rgb",
				fullRange: !0
			} : {
				primaries: "bt709",
				transfer: "bt709",
				matrix: "bt709",
				fullRange: !1
			}), this.visibleRect = {
				left: n.visibleRect?.left ?? 0,
				top: n.visibleRect?.top ?? 0,
				width: n.visibleRect?.width ?? n.codedWidth,
				height: n.visibleRect?.height ?? n.codedHeight
			}, n.displayWidth === void 0 ? (this.squarePixelWidth = this.visibleRect.width, this.squarePixelHeight = this.visibleRect.height) : (this.squarePixelWidth = this.rotation % 180 == 0 ? n.displayWidth : n.displayHeight, this.squarePixelHeight = this.rotation % 180 == 0 ? n.displayHeight : n.displayWidth), this._data = n._doNotCopy ? wo(t) : wo(t).slice(), this._layout = e, this.colorSpace = new Vl(r);
		} else if (typeof VideoFrame < "u" && t instanceof VideoFrame) {
			if (n?.rotation !== void 0 && ![
				0,
				90,
				180,
				270
			].includes(n.rotation)) throw TypeError("init.rotation, when provided, must be 0, 90, 180, or 270.");
			if (n?.flip !== void 0 && typeof n.flip != "boolean") throw TypeError("init.flip, when provided, must be a boolean.");
			if (n?.timestamp !== void 0 && !Number.isFinite(n?.timestamp)) throw TypeError("init.timestamp, when provided, must be a number.");
			if (n?.duration !== void 0 && (!Number.isFinite(n.duration) || n.duration < 0)) throw TypeError("init.duration, when provided, must be a non-negative number.");
			n?.visibleRect !== void 0 && ps(n.visibleRect, "init.visibleRect"), this._data = t, this._layout = null, this.format = t.format, this.visibleRect = {
				left: t.visibleRect?.x ?? 0,
				top: t.visibleRect?.y ?? 0,
				width: t.visibleRect?.width ?? t.codedWidth,
				height: t.visibleRect?.height ?? t.codedHeight
			}, this.rotation = n?.rotation ?? 0, this.flip = n?.flip ?? !1, this.squarePixelWidth = t.displayWidth, this.squarePixelHeight = t.displayHeight, this.timestamp = n?.timestamp ?? t.timestamp / 1e6, this.duration = n?.duration ?? (t.duration ?? 0) / 1e6, this.colorSpace = new Vl(t.colorSpace);
		} else if (typeof HTMLImageElement < "u" && t instanceof HTMLImageElement || typeof SVGImageElement < "u" && t instanceof SVGImageElement || typeof ImageBitmap < "u" && t instanceof ImageBitmap || typeof HTMLVideoElement < "u" && t instanceof HTMLVideoElement || typeof HTMLCanvasElement < "u" && t instanceof HTMLCanvasElement || typeof OffscreenCanvas < "u" && t instanceof OffscreenCanvas) {
			if (!n || typeof n != "object") throw TypeError("init must be an object.");
			if (n.rotation !== void 0 && ![
				0,
				90,
				180,
				270
			].includes(n.rotation)) throw TypeError("init.rotation, when provided, must be 0, 90, 180, or 270.");
			if (n.flip !== void 0 && typeof n.flip != "boolean") throw TypeError("init.flip, when provided, must be a boolean.");
			if (!Number.isFinite(n.timestamp)) throw TypeError("init.timestamp must be a number.");
			if (n.duration !== void 0 && (!Number.isFinite(n.duration) || n.duration < 0)) throw TypeError("init.duration, when provided, must be a non-negative number.");
			if (n.visibleRect !== void 0 && ps(n.visibleRect, "init.visibleRect"), typeof VideoFrame < "u") return new e(new VideoFrame(t, {
				timestamp: Math.trunc(n.timestamp * Yo),
				duration: Math.trunc((n.duration ?? 0) * Yo) || void 0,
				visibleRect: n.visibleRect && {
					x: n.visibleRect.left,
					y: n.visibleRect.top,
					width: n.visibleRect.width,
					height: n.visibleRect.height
				}
			}), n);
			let r = 0, i = 0;
			if ("naturalWidth" in t ? (r = t.naturalWidth, i = t.naturalHeight) : "videoWidth" in t ? (r = t.videoWidth, i = t.videoHeight) : "width" in t && (r = Number(t.width), i = Number(t.height)), !r || !i) throw TypeError("Could not determine dimensions.");
			let a = n.visibleRect ?? {
				left: 0,
				top: 0,
				width: r,
				height: i
			}, o = new OffscreenCanvas(a.width, a.height), s = o.getContext("2d", {
				alpha: $o(),
				willReadFrequently: !0
			});
			if (!s) throw Error("OffscreenCanvas must have support for the '2d' context in order to create a VideoSample from this data.");
			s.drawImage(t, -a.left, -a.top), this._data = o, this._layout = null, this.format = "RGBX", this.visibleRect = {
				left: 0,
				top: 0,
				width: a.width,
				height: a.height
			}, this.squarePixelWidth = a.width, this.squarePixelHeight = a.height, this.rotation = n.rotation ?? 0, this.flip = n.flip ?? !1, this.timestamp = n.timestamp, this.duration = n.duration ?? 0, this.colorSpace = new Vl({
				matrix: "rgb",
				primaries: "bt709",
				transfer: "iec61966-2-1",
				fullRange: !0
			});
		} else if (t instanceof Ml) {
			if (!n || typeof n != "object") throw TypeError("init must be an object.");
			if (n.rotation !== void 0 && ![
				0,
				90,
				180,
				270
			].includes(n.rotation)) throw TypeError("init.rotation, when provided, must be 0, 90, 180, or 270.");
			if (n.flip !== void 0 && typeof n.flip != "boolean") throw TypeError("init.flip, when provided, must be a boolean.");
			if (!Number.isFinite(n.timestamp)) throw TypeError("init.timestamp must be a number.");
			if (n.duration !== void 0 && (!Number.isFinite(n.duration) || n.duration < 0)) throw TypeError("init.duration, when provided, must be a non-negative number.");
			if (this._data = t, t._referenceCount++, this.format = t.getFormat(), this.format !== null && !Nl.includes(this.format)) throw TypeError("getFormat() must return a VideoSamplePixelFormat or null.");
			if (this.visibleRect = {
				left: 0,
				top: 0,
				width: t.getCodedWidth(),
				height: t.getCodedHeight()
			}, !Number.isInteger(this.visibleRect.width) || this.visibleRect.width <= 0) throw TypeError("getCodedWidth() must return a positive integer.");
			if (!Number.isInteger(this.visibleRect.height) || this.visibleRect.height <= 0) throw TypeError("getCodedHeight() must return a positive integer.");
			if (this.squarePixelWidth = t.getSquarePixelWidth(), !Number.isInteger(this.squarePixelWidth) || this.squarePixelWidth <= 0) throw TypeError("getSquarePixelWidth() must return a positive integer.");
			if (this.squarePixelHeight = t.getSquarePixelHeight(), !Number.isInteger(this.squarePixelHeight) || this.squarePixelHeight <= 0) throw TypeError("getSquarePixelHeight() must return a positive integer.");
			this.rotation = n.rotation ?? 0, this.flip = n.flip ?? !1, this.timestamp = n.timestamp, this.duration = n.duration ?? 0, this.colorSpace = t.getColorSpace();
		} else throw TypeError("Invalid data type: Must be a BufferSource, CanvasImageSource, or VideoSampleResource.");
		this.encodeOptions = n?.encodeOptions ?? {}, this.pixelAspectRatio = fs({
			num: this.squarePixelWidth * this.codedHeight,
			den: this.squarePixelHeight * this.codedWidth
		}), jl?.register(this, {
			type: "video",
			data: this._data
		}, this);
	}
	clone() {
		if (this._closed) throw Error("VideoSample is closed.");
		return q(this._data !== null), this._data instanceof Ml ? new e(this._data, {
			timestamp: this.timestamp,
			duration: this.duration,
			rotation: this.rotation,
			flip: this.flip,
			encodeOptions: this.encodeOptions
		}) : Hl(this._data) ? new e(this._data.clone(), {
			timestamp: this.timestamp,
			duration: this.duration,
			rotation: this.rotation,
			flip: this.flip,
			encodeOptions: this.encodeOptions
		}) : this._data instanceof Uint8Array ? (q(this._layout), new e(this._data, {
			format: this.format,
			layout: this._layout,
			codedWidth: this.codedWidth,
			codedHeight: this.codedHeight,
			timestamp: this.timestamp,
			duration: this.duration,
			colorSpace: this.colorSpace,
			rotation: this.rotation,
			flip: this.flip,
			visibleRect: this.visibleRect,
			displayWidth: this.displayWidth,
			displayHeight: this.displayHeight,
			encodeOptions: this.encodeOptions,
			_doNotCopy: !0
		})) : new e(this._data, {
			format: this.format,
			codedWidth: this.codedWidth,
			codedHeight: this.codedHeight,
			timestamp: this.timestamp,
			duration: this.duration,
			colorSpace: this.colorSpace,
			rotation: this.rotation,
			flip: this.flip,
			visibleRect: this.visibleRect,
			displayWidth: this.displayWidth,
			displayHeight: this.displayHeight,
			encodeOptions: this.encodeOptions
		});
	}
	close() {
		this._closed ||= (jl?.unregister(this), this._data instanceof Ml ? (this._data._referenceCount--, this._data._referenceCount === 0 && this._data.close()) : Hl(this._data) ? this._data.close() : this._data = null, !0);
	}
	allocationSize(e = {}) {
		if (Gl(e), this._closed) throw Error("VideoSample is closed.");
		if ((e.format ?? this.format) == null) throw Error("Cannot get allocation size when format is null.");
		return Hl(this._data) ? this._data.allocationSize(e) : Jl(this, e).allocationSize;
	}
	async copyTo(t, n = {}) {
		if (!Mo(t)) throw TypeError("destination must be an ArrayBuffer or an ArrayBuffer view.");
		if (Gl(n), this._closed) throw Error("VideoSample is closed.");
		if ((n.format ?? this.format) == null) throw Error("Cannot copy video sample data when format is null.");
		if (q(this._data !== null), Hl(this._data)) return this._data.copyTo(t, n);
		if (n.format && ![
			"RGBA",
			"RGBX",
			"BGRA",
			"BGRX"
		].includes(this.format) && [
			"RGBA",
			"RGBX",
			"BGRA",
			"BGRX"
		].includes(n.format)) {
			if (this._data instanceof Ml) {
				let r = {
					stack: [],
					error: void 0,
					hasError: !1
				};
				try {
					let i = Dl(r, await this._data.toRgbSample({
						timestamp: this.timestamp,
						duration: this.duration,
						rotation: this.rotation,
						flip: this.flip
					}, n.colorSpace ?? "srgb"), !1);
					if (!(i instanceof e)) throw TypeError("toRgbSample() must return a VideoSample.");
					if (![
						"RGBA",
						"RGBX",
						"BGRA",
						"BGRX"
					].includes(i.format)) throw Error(`Sample returned by toRgbSample was expected to have an RGB format, got '${i.format}' instead.`);
					return await i.copyTo(t, n);
				} catch (e) {
					r.error = e, r.hasError = !0;
				} finally {
					Ol(r);
				}
			} else {
				if (typeof VideoFrame > "u") throw Error("For this sample, converting from a non-RGB to an RGB format requires VideoFrame to be defined.");
				let e = this.toVideoFrame(), r = await e.copyTo(t, n);
				return e.close(), r;
			}
		}
		let r = Jl(this, n);
		q(this.format);
		let i = wo(t);
		if (i.byteLength < r.allocationSize) throw TypeError(`Destination buffer too small. Required: ${r.allocationSize}, Available: ${i.byteLength}`);
		let a = ql(this.format), o;
		if (this._data instanceof Ml) {
			let e = this._data.getDataPlanes();
			if (as(e) && (e = await e), !Array.isArray(e) || e.some((e) => !(e.data instanceof Uint8Array) || !Number.isInteger(e.stride) || e.stride < 0)) throw TypeError("getDataPlanes() must return an array of objects with a Uint8Array \"data\" property and a non-negative integer \"stride\" property.");
			o = e;
		} else if (this._data instanceof Uint8Array) q(this._layout), q(this._layout.length === a.length), o = this._layout.map((e, t) => {
			let n = Math.ceil(this.codedHeight / a[t].heightDivisor);
			return {
				data: this._data.subarray(e.offset, e.offset + e.stride * n),
				stride: e.stride
			};
		});
		else {
			let e = this._data.getContext("2d");
			q(e), o = [{
				data: wo(e.getImageData(0, 0, this.codedWidth, this.codedHeight).data),
				stride: 4 * this.codedWidth
			}];
		}
		let s = [], c = a.length;
		for (let e = 0; e < c; e++) {
			let t = r.computedLayouts[e], n = o[e].stride, a = o[e].data, c = t.sourceTop * n;
			c += t.sourceLeftBytes;
			let l = t.destinationOffset, u = t.sourceWidthBytes, d = {
				offset: l,
				stride: t.destinationStride
			};
			for (let e = 0; e < t.sourceHeight; e++) {
				if (c + u > a.byteLength) throw Error("Source buffer OOB read.");
				if (l + u > i.byteLength) throw Error("Destination buffer OOB write.");
				let e = a.subarray(c, c + u);
				i.set(e, l), c += n, l += t.destinationStride;
			}
			s.push(d);
		}
		if (n.format !== void 0) {
			let e = this.format.startsWith("RGB") !== n.format.startsWith("RGB"), t = this.format.includes("X") && n.format.includes("A");
			if (e || t) for (let n = 0; n < r.allocationSize; n += 4) {
				if (e) {
					let e = i[n], t = i[n + 2];
					i[n] = t, i[n + 2] = e;
				}
				t && (i[n + 3] = 255);
			}
		}
		return s;
	}
	toVideoFrame() {
		if (this._closed) throw Error("VideoSample is closed.");
		if (q(this._data !== null), this._data instanceof Ml) {
			if (this.format === null) throw Error("Cannot convert a VideoSampleResource-backed VideoSample to VideoFrame if format is null.");
			let e = this._data.getDataPlanes();
			if (as(e)) throw Error("Cannot convert a VideoSampleResource-backed VideoSample to VideoFrame if getDataPlanes() returns a promise.");
			let t = e.reduce((e, t) => e + t.data.byteLength, 0), n = new Uint8Array(t), r = 0, i = [];
			for (let t of e) n.set(t.data, r), i.push(r), r += t.data.byteLength;
			return new VideoFrame(n, {
				format: this.format,
				layout: e.map((e, t) => ({
					offset: i[t],
					stride: e.stride
				})),
				codedWidth: this.codedWidth,
				codedHeight: this.codedHeight,
				timestamp: this.microsecondTimestamp,
				duration: this.microsecondDuration,
				colorSpace: this.colorSpace,
				visibleRect: this.visibleRect,
				displayWidth: this.squarePixelWidth,
				displayHeight: this.squarePixelHeight
			});
		}
		return Hl(this._data) ? new VideoFrame(this._data, {
			timestamp: this.microsecondTimestamp,
			duration: this.microsecondDuration || void 0
		}) : this._data instanceof Uint8Array ? (q(this._layout), new VideoFrame(this._data, {
			format: this.format,
			codedWidth: this.codedWidth,
			codedHeight: this.codedHeight,
			layout: this._layout,
			timestamp: this.microsecondTimestamp,
			duration: this.microsecondDuration || void 0,
			colorSpace: this.colorSpace,
			visibleRect: this.visibleRect,
			displayWidth: this.squarePixelWidth,
			displayHeight: this.squarePixelHeight
		})) : new VideoFrame(this._data, {
			timestamp: this.microsecondTimestamp,
			duration: this.microsecondDuration || void 0
		});
	}
	draw(e, t, n, r, i, a, o, s, c) {
		let l = 0, u = 0, d = this.displayWidth, f = this.displayHeight, p = 0, m = 0, h = this.displayWidth, g = this.displayHeight;
		if (a === void 0 ? (p = t, m = n, r !== void 0 && (h = r, g = i)) : (l = t, u = n, d = r, f = i, p = a, m = o, s === void 0 ? (h = d, g = f) : (h = s, g = c)), !(typeof CanvasRenderingContext2D < "u" && e instanceof CanvasRenderingContext2D || typeof OffscreenCanvasRenderingContext2D < "u" && e instanceof OffscreenCanvasRenderingContext2D)) throw TypeError("context must be a CanvasRenderingContext2D or OffscreenCanvasRenderingContext2D.");
		if (!Number.isFinite(l)) throw TypeError("sx must be a number.");
		if (!Number.isFinite(u)) throw TypeError("sy must be a number.");
		if (!Number.isFinite(d) || d < 0) throw TypeError("sWidth must be a non-negative number.");
		if (!Number.isFinite(f) || f < 0) throw TypeError("sHeight must be a non-negative number.");
		if (!Number.isFinite(p)) throw TypeError("dx must be a number.");
		if (!Number.isFinite(m)) throw TypeError("dy must be a number.");
		if (!Number.isFinite(h) || h < 0) throw TypeError("dWidth must be a non-negative number.");
		if (!Number.isFinite(g) || g < 0) throw TypeError("dHeight must be a non-negative number.");
		if (this._closed) throw Error("VideoSample is closed.");
		({sx: l, sy: u, sWidth: d, sHeight: f} = this._unmapSourceRegion(l, u, d, f, this.rotation, this.flip));
		let _ = this.toCanvasImageSource();
		e.save();
		let v = p + h / 2, y = m + g / 2;
		e.translate(v, y), this.flip && e.scale(-1, 1), e.rotate(this.rotation * Math.PI / 180);
		let b = this.rotation % 180 == 0 ? 1 : h / g;
		e.scale(1 / b, b), e.drawImage(_, l, u, d, f, -h / 2, -g / 2, h, g), e.restore();
	}
	drawWithFit(e, t) {
		if (!(typeof CanvasRenderingContext2D < "u" && e instanceof CanvasRenderingContext2D || typeof OffscreenCanvasRenderingContext2D < "u" && e instanceof OffscreenCanvasRenderingContext2D)) throw TypeError("context must be a CanvasRenderingContext2D or OffscreenCanvasRenderingContext2D.");
		if (!t || typeof t != "object") throw TypeError("options must be an object.");
		if (![
			"fill",
			"contain",
			"cover"
		].includes(t.fit)) throw TypeError("options.fit must be 'fill', 'contain', or 'cover'.");
		if (t.rotation !== void 0 && ![
			0,
			90,
			180,
			270
		].includes(t.rotation)) throw TypeError("options.rotation, when provided, must be 0, 90, 180, or 270.");
		if (t.flip !== void 0 && typeof t.flip != "boolean") throw TypeError("options.flip, when provided, must be a boolean.");
		t.crop !== void 0 && Wl(t.crop, "options.");
		let n = e.canvas.width, r = e.canvas.height, i = t.rotation ?? this.rotation, a = t.flip ?? this.flip, [o, s] = i % 180 == 0 ? [this.squarePixelWidth, this.squarePixelHeight] : [this.squarePixelHeight, this.squarePixelWidth], c = t.crop;
		c &&= Ul(c, o, s);
		let l, u, d, f, { sx: p, sy: m, sWidth: h, sHeight: g } = this._unmapSourceRegion(t.crop?.left ?? 0, t.crop?.top ?? 0, t.crop?.width ?? o, t.crop?.height ?? s, i, a);
		if (t.fit === "fill") l = 0, u = 0, d = n, f = r;
		else {
			let [e, i] = t.crop ? [t.crop.width, t.crop.height] : [o, s], a = t.fit === "contain" ? Math.min(n / e, r / i) : Math.max(n / e, r / i);
			d = e * a, f = i * a, l = (n - d) / 2, u = (r - f) / 2;
		}
		e.save();
		let _ = i % 180 == 0 ? 1 : d / f;
		e.translate(n / 2, r / 2), a && e.scale(-1, 1), e.rotate(i * Math.PI / 180), e.scale(1 / _, _), e.translate(-n / 2, -r / 2), e.drawImage(this.toCanvasImageSource(), p, m, h, g, l, u, d, f), e.restore();
	}
	_unmapSourceRegion(e, t, n, r, i, a) {
		return a && (e = (i % 180 == 0 ? this.squarePixelWidth : this.squarePixelHeight) - e - n), i === 90 ? [e, t, n, r] = [
			t,
			this.squarePixelHeight - e - n,
			r,
			n
		] : i === 180 ? [e, t] = [this.squarePixelWidth - e - n, this.squarePixelHeight - t - r] : i === 270 && ([e, t, n, r] = [
			this.squarePixelWidth - t - r,
			e,
			r,
			n
		]), {
			sx: e,
			sy: t,
			sWidth: n,
			sHeight: r
		};
	}
	_drawWithFitAndMipmapping(e, t, n) {
		let r = e.width, i = e.height, [a, o] = n.rotation % 180 == 0 ? [this.squarePixelWidth, this.squarePixelHeight] : [this.squarePixelHeight, this.squarePixelWidth], s = n.crop ? n.crop.width : a, c = n.crop ? n.crop.height : o, l = 0;
		2 * r < s && 2 * i < c && (l = Math.floor(Math.log2(Math.min(s / r, c / i))));
		let u = r * 2 ** l, d = i * 2 ** l, { canvas: f, context: p, isNew: m } = l > 0 ? Bl(u, d) : {
			canvas: e,
			context: t,
			isNew: n.targetIsFresh
		};
		p.imageSmoothingQuality = "high", n.fillBlack ? (p.fillStyle = "black", p.fillRect(0, 0, u, d)) : m || p.clearRect(0, 0, u, d), this.drawWithFit(p, {
			fit: n.fit,
			rotation: n.rotation,
			flip: n.flip,
			crop: n.crop
		}), p.globalCompositeOperation = "copy";
		for (let e = l; e > 1; e--) {
			let t = r * 2 ** e, n = i * 2 ** e;
			p.drawImage(f, 0, 0, t, n, 0, 0, t / 2, n / 2);
		}
		p.globalCompositeOperation = "source-over", l > 0 && (t.imageSmoothingQuality = "high", t.globalCompositeOperation = "copy", t.drawImage(f, 0, 0, 2 * r, 2 * i, 0, 0, r, i), t.globalCompositeOperation = "source-over");
	}
	toCanvasImageSource() {
		if (this._closed) throw Error("VideoSample is closed.");
		if (q(this._data !== null), this._data instanceof Ml || this._data instanceof Uint8Array) {
			let e = this.toVideoFrame();
			return queueMicrotask(() => e.close()), e;
		}
		return this._data;
	}
	async transform(t) {
		if (!t || typeof t != "object") throw TypeError("options must be an object.");
		if (t.width !== void 0 && (!Number.isInteger(t.width) || t.width <= 0)) throw TypeError("options.width, when provided, must be a positive integer.");
		if (t.height !== void 0 && (!Number.isInteger(t.height) || t.height <= 0)) throw TypeError("options.height, when provided, must be a positive integer.");
		if (t.roundDimensionsTo !== void 0 && (!Number.isInteger(t.roundDimensionsTo) || t.roundDimensionsTo <= 0)) throw TypeError("options.roundDimensionsTo, when provided, must be a positive integer.");
		if (t.fit !== void 0 && ![
			"fill",
			"contain",
			"cover"
		].includes(t.fit)) throw TypeError("options.fit, when provided, must be one of \"fill\", \"contain\", or \"cover\".");
		if (t.width !== void 0 && t.height !== void 0 && t.fit === void 0) throw TypeError("When both options.width and options.height are provided, options.fit must also be provided.");
		if (t.rotate !== void 0 && ![
			0,
			90,
			180,
			270
		].includes(t.rotate)) throw TypeError("options.rotate, when provided, must be 0, 90, 180 or 270.");
		if (t.flip !== void 0 && typeof t.flip != "boolean") throw TypeError("options.flip, when provided, must be a boolean.");
		if (t.crop !== void 0 && Wl(t.crop, "options."), t.alpha !== void 0 && !["keep", "discard"].includes(t.alpha)) throw TypeError("options.alpha, when provided, must be 'keep' or 'discard'.");
		let { rotation: n, flip: r } = vo(this.rotation, this.flip, t.rotate ?? 0, t.flip ?? !1), [i, a] = n % 180 == 0 ? [this.squarePixelWidth, this.squarePixelHeight] : [this.squarePixelHeight, this.squarePixelWidth], o = t.crop;
		o &&= Ul(o, i, a);
		let s = o ? o.width : i, c = o ? o.height : a, l = s / c, u, d;
		t.width !== void 0 && t.height === void 0 ? (u = t.width, d = u / l) : t.width === void 0 && t.height !== void 0 ? (d = t.height, u = d * l) : t.width !== void 0 && t.height !== void 0 ? (u = t.width, d = t.height) : (u = s, d = c), u = Uo(u, t.roundDimensionsTo ?? 1), d = Uo(d, t.roundDimensionsTo ?? 1);
		let f = {
			width: u,
			height: d,
			fit: t.fit ?? "fill",
			rotation: n,
			flip: r,
			crop: o ?? {
				left: 0,
				top: 0,
				width: i,
				height: a
			},
			alpha: t.alpha ?? "keep"
		};
		for (let e of Il) {
			let t = e(this, f);
			if (as(t) && (t = await t), t !== null) return t;
		}
		let { canvas: p, context: m, isNew: h } = Bl(f.width, f.height);
		return this._drawWithFitAndMipmapping(p, m, {
			fit: f.fit,
			rotation: f.rotation,
			flip: f.flip,
			crop: f.crop,
			targetIsFresh: h,
			fillBlack: f.alpha === "discard"
		}), new e(p, {
			timestamp: this.timestamp,
			duration: this.duration,
			rotation: 0,
			flip: !1
		});
	}
	setRotation(e) {
		if (![
			0,
			90,
			180,
			270
		].includes(e)) throw TypeError("newRotation must be 0, 90, 180, or 270.");
		this.rotation = e;
	}
	setFlip(e) {
		if (typeof e != "boolean") throw TypeError("newFlip must be a boolean.");
		this.flip = e;
	}
	setTimestamp(e) {
		if (!Number.isFinite(e)) throw TypeError("newTimestamp must be a number.");
		this.timestamp = e;
	}
	setDuration(e) {
		if (!Number.isFinite(e) || e < 0) throw TypeError("newDuration must be a non-negative number.");
		this.duration = e;
	}
	setEncodeOptions(e) {
		if (!e || typeof e != "object") throw TypeError("newEncodeOptions must be an object.");
		this.encodeOptions = e;
	}
	[Symbol.dispose]() {
		this.close();
	}
}, Il = [], Ll = 3, Rl = [], zl = 0, Bl = (e, t) => {
	for (let n of Rl) if (n.canvas.width === e && n.canvas.height === t) return n.age = zl++, {
		canvas: n.canvas,
		context: n.context,
		isNew: !1
	};
	let n;
	if (typeof OffscreenCanvas < "u") n = new OffscreenCanvas(e, t);
	else {
		if (typeof window > "u" || typeof document > "u") throw Error("Cannot transform VideoSamples in this environment. Either run in an environment with OffscreenCanvas or HTMLCanvasElement, or supply a custom VideoSample transformer using registerVideoSampleTransformer().");
		n = document.createElement("canvas"), n.width = e, n.height = t;
	}
	let r = n.getContext("2d", {
		alpha: !0,
		willReadFrequently: !1
	});
	if (!r) throw Error("The '2d' canvas context is required to transform VideoSamples. Register a custom transformer using registerVideoSampleTransformer to work around this limitation.");
	return Rl.length >= Ll && Rl.splice(ds(Rl, (e) => e.age), 1), Rl.push({
		canvas: n,
		context: r,
		age: zl++
	}), {
		canvas: n,
		context: r,
		isNew: !0
	};
}, Vl = class {
	constructor(e) {
		if (e !== void 0) {
			if (!e || typeof e != "object") throw TypeError("init.colorSpace, when provided, must be an object.");
			let t = Object.keys(Oo);
			if (e.primaries != null && !t.includes(e.primaries)) throw TypeError(`init.colorSpace.primaries, when provided, must be one of ${t.join(", ")}.`);
			let n = Object.keys(ko);
			if (e.transfer != null && !n.includes(e.transfer)) throw TypeError(`init.colorSpace.transfer, when provided, must be one of ${n.join(", ")}.`);
			let r = Object.keys(Ao);
			if (e.matrix != null && !r.includes(e.matrix)) throw TypeError(`init.colorSpace.matrix, when provided, must be one of ${r.join(", ")}.`);
			if (e.fullRange != null && typeof e.fullRange != "boolean") throw TypeError("init.colorSpace.fullRange, when provided, must be a boolean.");
		}
		this.primaries = e?.primaries ?? null, this.transfer = e?.transfer ?? null, this.matrix = e?.matrix ?? null, this.fullRange = e?.fullRange ?? null;
	}
	toJSON() {
		return {
			primaries: this.primaries,
			transfer: this.transfer,
			matrix: this.matrix,
			fullRange: this.fullRange
		};
	}
}, Hl = (e) => typeof VideoFrame < "u" && e instanceof VideoFrame, Ul = (e, t, n) => {
	let r = Math.min(e.left, t), i = Math.min(e.top, n), a = Math.min(e.width, t - r), o = Math.min(e.height, n - i);
	return q(a >= 0), q(o >= 0), {
		left: r,
		top: i,
		width: a,
		height: o
	};
}, Wl = (e, t) => {
	if (!e || typeof e != "object") throw TypeError(t + "crop, when provided, must be an object.");
	if (!Number.isInteger(e.left) || e.left < 0) throw TypeError(t + "crop.left must be a non-negative integer.");
	if (!Number.isInteger(e.top) || e.top < 0) throw TypeError(t + "crop.top must be a non-negative integer.");
	if (!Number.isInteger(e.width) || e.width < 0) throw TypeError(t + "crop.width must be a non-negative integer.");
	if (!Number.isInteger(e.height) || e.height < 0) throw TypeError(t + "crop.height must be a non-negative integer.");
}, Gl = (e) => {
	if (!e || typeof e != "object") throw TypeError("options must be an object.");
	if (e.colorSpace !== void 0 && !["display-p3", "srgb"].includes(e.colorSpace)) throw TypeError("options.colorSpace, when provided, must be 'display-p3' or 'srgb'.");
	if (e.format !== void 0 && typeof e.format != "string") throw TypeError("options.format, when provided, must be a string.");
	if (e.layout !== void 0) {
		if (!Array.isArray(e.layout)) throw TypeError("options.layout, when provided, must be an array.");
		for (let t of e.layout) {
			if (!t || typeof t != "object") throw TypeError("Each entry in options.layout must be an object.");
			if (!Number.isInteger(t.offset) || t.offset < 0) throw TypeError("plane.offset must be a non-negative integer.");
			if (!Number.isInteger(t.stride) || t.stride < 0) throw TypeError("plane.stride must be a non-negative integer.");
		}
	}
	if (e.rect !== void 0) {
		if (!e.rect || typeof e.rect != "object") throw TypeError("options.rect, when provided, must be an object.");
		if (e.rect.x !== void 0 && (!Number.isInteger(e.rect.x) || e.rect.x < 0)) throw TypeError("options.rect.x, when provided, must be a non-negative integer.");
		if (e.rect.y !== void 0 && (!Number.isInteger(e.rect.y) || e.rect.y < 0)) throw TypeError("options.rect.y, when provided, must be a non-negative integer.");
		if (e.rect.width !== void 0 && (!Number.isInteger(e.rect.width) || e.rect.width < 0)) throw TypeError("options.rect.width, when provided, must be a non-negative integer.");
		if (e.rect.height !== void 0 && (!Number.isInteger(e.rect.height) || e.rect.height < 0)) throw TypeError("options.rect.height, when provided, must be a non-negative integer.");
	}
}, Kl = (e, t, n) => {
	let r = ql(e), i = [], a = 0;
	for (let e of r) {
		let r = Math.ceil(t / e.widthDivisor), o = Math.ceil(n / e.heightDivisor), s = r * e.sampleBytes, c = s * o;
		i.push({
			offset: a,
			stride: s
		}), a += c;
	}
	return i;
}, ql = (e) => {
	let t = (e, t, n, r, i) => {
		let a = [
			{
				sampleBytes: e,
				widthDivisor: 1,
				heightDivisor: 1
			},
			{
				sampleBytes: t,
				widthDivisor: n,
				heightDivisor: r
			},
			{
				sampleBytes: t,
				widthDivisor: n,
				heightDivisor: r
			}
		];
		return i && a.push({
			sampleBytes: e,
			widthDivisor: 1,
			heightDivisor: 1
		}), a;
	};
	switch (e) {
		case "I420": return t(1, 1, 2, 2, !1);
		case "I420P10":
		case "I420P12": return t(2, 2, 2, 2, !1);
		case "I420A": return t(1, 1, 2, 2, !0);
		case "I420AP10":
		case "I420AP12": return t(2, 2, 2, 2, !0);
		case "I422": return t(1, 1, 2, 1, !1);
		case "I422P10":
		case "I422P12": return t(2, 2, 2, 1, !1);
		case "I422A": return t(1, 1, 2, 1, !0);
		case "I422AP10":
		case "I422AP12": return t(2, 2, 2, 1, !0);
		case "I444": return t(1, 1, 1, 1, !1);
		case "I444P10":
		case "I444P12": return t(2, 2, 1, 1, !1);
		case "I444A": return t(1, 1, 1, 1, !0);
		case "I444AP10":
		case "I444AP12": return t(2, 2, 1, 1, !0);
		case "NV12": return [{
			sampleBytes: 1,
			widthDivisor: 1,
			heightDivisor: 1
		}, {
			sampleBytes: 2,
			widthDivisor: 2,
			heightDivisor: 2
		}];
		case "RGBA":
		case "RGBX":
		case "BGRA":
		case "BGRX": return [{
			sampleBytes: 4,
			widthDivisor: 1,
			heightDivisor: 1
		}];
		default: Ro(e), q(!1);
	}
}, Jl = (e, t) => {
	let n = {
		left: 0,
		top: 0,
		width: e.codedWidth,
		height: e.codedHeight
	}, r = t.rect, i = Yl(n, r, e.codedWidth, e.codedHeight, e.format), a = t.layout, o;
	if (!t.format || t.format === e.format) o = e.format;
	else if ([
		"RGBA",
		"RGBX",
		"BGRA",
		"BGRX"
	].includes(t.format)) o = t.format;
	else throw Error("NotSupportedError: Invalid destination format.");
	return Zl(i, o, a);
}, Yl = (e, t, n, r, i) => {
	let a = { ...e };
	if (t !== void 0) {
		if (t.width === 0 || t.height === 0) throw TypeError("visibleRect dimensions cannot be zero.");
		if ((t.x || 0) + (t.width || 0) > n) throw TypeError("visibleRect exceeds codedWidth.");
		if ((t.y || 0) + (t.height || 0) > r) throw TypeError("visibleRect exceeds codedHeight.");
		a.x = t.x || 0, a.y = t.y || 0, a.width = t.width || 0, a.height = t.height || 0;
	}
	if (!Xl(i, a)) throw TypeError("visibleRect alignment is invalid for the format.");
	return a;
}, Xl = (e, t) => {
	if (e === null) return !0;
	let n = ql(e);
	for (let e = 0; e < n.length; e++) {
		let r = n[e], i = r.widthDivisor, a = r.heightDivisor;
		if ((t.x || 0) % i !== 0 || (t.y || 0) % a !== 0) return !1;
	}
	return !0;
}, Zl = (e, t, n) => {
	let r = ql(t), i = r.length;
	if (n !== void 0 && n.length !== i) throw TypeError(`Layout must have ${i} planes.`);
	let a = 0, o = [], s = [];
	for (let t = 0; t < i; t++) {
		let i = r[t], c = i.sampleBytes, l = i.widthDivisor, u = i.heightDivisor, d = {
			destinationOffset: 0,
			destinationStride: 0,
			sourceTop: 0,
			sourceHeight: 0,
			sourceLeftBytes: 0,
			sourceWidthBytes: 0
		};
		if (d.sourceTop = Math.ceil(Math.trunc(e.y || 0) / u), d.sourceHeight = Math.ceil(Math.trunc(e.height || 0) / u), d.sourceLeftBytes = Math.floor(Math.trunc(e.x || 0) / l) * c, d.sourceWidthBytes = Math.floor(Math.trunc(e.width || 0) / l) * c, n !== void 0) {
			let e = n[t];
			if (e.stride < d.sourceWidthBytes) throw TypeError(`Stride for plane ${t} is too small.`);
			d.destinationOffset = e.offset, d.destinationStride = e.stride;
		} else d.destinationOffset = a, d.destinationStride = d.sourceWidthBytes;
		let f = d.destinationStride * d.sourceHeight + d.destinationOffset;
		if (f > 4294967295) throw TypeError("Allocation size exceeds limit.");
		s.push(f), a = Math.max(a, f);
		for (let e = 0; e < t; e++) {
			let n = o[e];
			if (!(s[t] <= n.destinationOffset || s[e] <= d.destinationOffset)) throw TypeError("Planes overlap.");
		}
		o.push(d);
	}
	return {
		allocationSize: a,
		computedLayouts: o
	};
}, Ql = /* @__PURE__ */ new Map(), $l = (e) => {
	if (!e || typeof e != "object") throw TypeError("Encoding config must be an object.");
	if (!jc.includes(e.codec)) throw TypeError(`Invalid video codec '${e.codec}'. Must be one of: ${jc.join(", ")}.`);
	let t = e.bitrate;
	if (e.quality === void 0 && t === void 0) throw TypeError("config.quality must be provided.");
	if (e.quality !== void 0 && t !== void 0) throw TypeError("config.quality and config.bitrate cannot both be provided.");
	if (e.quality !== void 0 && !(e.quality instanceof nu)) throw TypeError("config.quality, when provided, must be a Quality.");
	if (t !== void 0 && !(t instanceof nu) && (!Number.isInteger(t) || t <= 0)) throw TypeError("config.bitrate, when provided, must be a positive integer or a quality.");
	if (e.keyFrameInterval !== void 0 && (!Number.isFinite(e.keyFrameInterval) || e.keyFrameInterval < 0)) throw TypeError("config.keyFrameInterval, when provided, must be a non-negative number.");
	if (e.sizeChangeBehavior !== void 0 && ![
		"deny",
		"passThrough",
		"fill",
		"contain",
		"cover"
	].includes(e.sizeChangeBehavior)) throw TypeError("config.sizeChangeBehavior, when provided, must be 'deny', 'passThrough', 'fill', 'contain' or 'cover'.");
	if (e.transform !== void 0) {
		if (typeof e.transform != "object" || !e.transform) throw TypeError("config.transform, when provided, must be an object.");
		if (e.transform.width !== void 0 && (!Number.isInteger(e.transform.width) || e.transform.width <= 0)) throw TypeError("config.transform.width, when provided, must be a positive integer.");
		if (e.transform.height !== void 0 && (!Number.isInteger(e.transform.height) || e.transform.height <= 0)) throw TypeError("config.transform.height, when provided, must be a positive integer.");
		if (e.transform.fit !== void 0 && ![
			"fill",
			"contain",
			"cover"
		].includes(e.transform.fit)) throw TypeError("config.transform.fit, when provided, must be one of \"fill\", \"contain\", or \"cover\".");
		if (e.transform.width !== void 0 && e.transform.height !== void 0 && e.transform.fit === void 0 && ![
			"fill",
			"contain",
			"cover"
		].includes(e.sizeChangeBehavior)) throw TypeError("When both config.transform.width and config.transform.height are provided, config.transform.fit must also be provided.");
		if (e.transform.fit !== void 0 && [
			"fill",
			"contain",
			"cover"
		].includes(e.sizeChangeBehavior) && e.transform.fit !== e.sizeChangeBehavior) throw TypeError("config.transform.fit, when provided, cannot differ from config.sizeChangeBehavior when config.sizeChangeBehavior is 'fill', 'contain' or 'cover', as sizeChangeBehavior already determines the fitting algorithm.");
		if (e.transform.rotate !== void 0 && ![
			0,
			90,
			180,
			270
		].includes(e.transform.rotate)) throw TypeError("config.transform.rotate, when provided, must be 0, 90, 180 or 270.");
		if (e.transform.flip !== void 0 && typeof e.transform.flip != "boolean") throw TypeError("config.transform.flip, when provided, must be a boolean.");
		if (e.transform.crop !== void 0 && Wl(e.transform.crop, "config.transform."), e.transform.process !== void 0 && typeof e.transform.process != "function") throw TypeError("config.transform.process, when provided, must be a function.");
		if (e.transform.frameRate !== void 0 && (!Number.isFinite(e.transform.frameRate) || e.transform.frameRate <= 0)) throw TypeError("config.transform.frameRate, when provided, must be a finite positive number.");
		if (e.transform.force !== void 0 && typeof e.transform.force != "boolean") throw TypeError("config.transform.force, when provided, must be a boolean.");
	}
	if (e.onEncodedPacket !== void 0 && typeof e.onEncodedPacket != "function") throw TypeError("config.onEncodedPacket, when provided, must be a function.");
	if (e.onEncoderConfig !== void 0 && typeof e.onEncoderConfig != "function") throw TypeError("config.onEncoderConfig, when provided, must be a function.");
	if (e.onEncodedSample !== void 0 && typeof e.onEncodedSample != "function") throw TypeError("config.onEncodedSample, when provided, must be a function.");
	eu(e.codec, e);
}, eu = (e, t) => {
	if (!t || typeof t != "object") throw TypeError("Encoding options must be an object.");
	if (t.alpha !== void 0 && !["discard", "keep"].includes(t.alpha)) throw TypeError("options.alpha, when provided, must be 'discard' or 'keep'.");
	let n = t.bitrateMode;
	if (n !== void 0 && !["constant", "variable"].includes(n)) throw TypeError("bitrateMode, when provided, must be 'constant' or 'variable'.");
	if (t.latencyMode !== void 0 && !["quality", "realtime"].includes(t.latencyMode)) throw TypeError("latencyMode, when provided, must be 'quality' or 'realtime'.");
	if (t.fullCodecString !== void 0 && typeof t.fullCodecString != "string") throw TypeError("fullCodecString, when provided, must be a string.");
	if (t.fullCodecString !== void 0 && Qc(t.fullCodecString) !== e) throw TypeError(`fullCodecString, when provided, must be a string that matches the specified codec (${e}).`);
	if (t.hardwareAcceleration !== void 0 && ![
		"no-preference",
		"prefer-hardware",
		"prefer-software"
	].includes(t.hardwareAcceleration)) throw TypeError("hardwareAcceleration, when provided, must be 'no-preference', 'prefer-hardware' or 'prefer-software'.");
	if (t.scalabilityMode !== void 0 && typeof t.scalabilityMode != "string") throw TypeError("scalabilityMode, when provided, must be a string.");
	if (t.contentHint !== void 0 && typeof t.contentHint != "string") throw TypeError("contentHint, when provided, must be a string.");
}, tu = (e) => {
	let t = e.bitrateMode, n = e.quality._toVideoRateControl(e.codec, e.width, e.height, t), r = (t, n, r) => ({
		codec: e.fullCodecString ?? Gc(e.codec, e.width, e.height, r, e.alpha === "keep"),
		width: e.width,
		height: e.height,
		displayWidth: e.squarePixelWidth,
		displayHeight: e.squarePixelHeight,
		bitrate: t,
		bitrateMode: n,
		alpha: e.alpha ?? "discard",
		framerate: e.framerate,
		latencyMode: e.latencyMode,
		hardwareAcceleration: e.hardwareAcceleration,
		scalabilityMode: e.scalabilityMode,
		contentHint: e.contentHint,
		...$c(e.codec)
	}), i = [];
	return n.quantizer !== null && i.push({
		config: r(void 0, "quantizer", n.bitrate),
		quantizer: n.quantizer
	}), n.bitrateMode !== "quantizer" && i.push({
		config: r(n.bitrate, n.bitrateMode, n.bitrate),
		quantizer: null
	}), q(i.length > 0), i;
}, nu = class {
	constructor(e) {
		if ((typeof e == "number" || typeof e == "string") && (e = { quality: e }), !e || typeof e != "object") throw TypeError("options must be an object.");
		if (e.bitrateMode !== void 0 && !["constant", "variable"].includes(e.bitrateMode)) throw TypeError("options.bitrateMode, when provided, must be 'constant' or 'variable'.");
		if ("quality" in e) {
			if (typeof e.quality == "string" ? !(e.quality in ru) : typeof e.quality != "number" || Number.isNaN(e.quality)) throw TypeError("options.quality must be a number, or one of 'very-low', 'low', 'medium', 'high' or 'very-high'.");
			if (e.preferBitrate !== void 0 && typeof e.preferBitrate != "boolean") throw TypeError("options.preferBitrate, when provided, must be a boolean.");
			if ("bitrate" in e || "quantizer" in e) throw TypeError("options.quality cannot be combined with options.bitrate or options.quantizer.");
			this._quality = typeof e.quality == "string" ? ru[e.quality] : e.quality, this._preferBitrate = e.preferBitrate ?? !1, this._bitrate = void 0, this._quantizer = void 0;
		} else {
			if (e.bitrate !== void 0 && (!Number.isInteger(e.bitrate) || e.bitrate <= 0)) throw TypeError("options.bitrate, when provided, must be a positive integer.");
			if (e.quantizer !== void 0 && (!Number.isInteger(e.quantizer) || e.quantizer < 0)) throw TypeError("options.quantizer, when provided, must be a non-negative integer.");
			if (e.bitrate === void 0 && e.quantizer === void 0) throw TypeError("At least one of options.bitrate or options.quantizer must be set.");
			if ("preferBitrate" in e) throw TypeError("options.preferBitrate can only be combined with options.quality.");
			this._quality = void 0, this._preferBitrate = !1, this._bitrate = e.bitrate, this._quantizer = e.quantizer;
		}
		this._bitrateMode = e.bitrateMode;
	}
	_toVideoRateControl(e, t, n, r) {
		let i = iu[e], a = null, o = this._bitrateMode ?? r ?? "variable";
		if (this._quantizer !== void 0) {
			if (!i) {
				if (this._bitrate === void 0) throw Error(`Codec '${e}' does not support quantizer-based encoding. Provide a bitrate in the Quality to define a fallback.`);
			} else if (this._quantizer < i.min || this._quantizer > i.max) {
				if (this._bitrate === void 0) throw Error(`Quantizer ${this._quantizer} is out of range for codec '${e}'; must be between ${i.min} and ${i.max}.`);
			} else a = this._quantizer, this._bitrate === void 0 && (o = "quantizer");
		} else this._bitrate === void 0 && i && !this._preferBitrate && (q(this._quality !== void 0), a = Vo(Math.round(Ho(i.worst, i.best, this._quality)), i.min, i.max));
		let s;
		if (this._bitrate !== void 0) s = this._bitrate;
		else {
			let r = this._quality;
			r === void 0 && (q(a !== null && i), r = Vo((a - i.worst) / (i.best - i.worst), 0, 1)), s = ou(e, t, n, au(r));
		}
		return {
			quantizer: a,
			bitrate: s,
			bitrateMode: o
		};
	}
	_toVideoBitrate(e, t, n) {
		return this._bitrate === void 0 ? (q(this._quality !== void 0), ou(e, t, n, au(this._quality))) : this._bitrate;
	}
	_toAudioBitrate(e) {
		if (Mc.includes(e) || e === "flac") return;
		if (this._bitrate !== void 0) return this._bitrate;
		if (this._quality === void 0) throw Error("This Quality defines neither a quality level nor a bitrate and therefore cannot be used for audio encoding.");
		let t = au(this._quality), n = {
			aac: 128e3,
			opus: 64e3,
			mp3: 16e4,
			vorbis: 64e3,
			ac3: 384e3,
			eac3: 192e3,
			dts: 768e3
		}[e];
		if (!n) throw Error(`Unhandled codec: ${e}`);
		let r = n * t;
		return e === "aac" ? r = [
			96e3,
			128e3,
			16e4,
			192e3
		].reduce((e, t) => Math.abs(t - r) < Math.abs(e - r) ? t : e) : e === "opus" || e === "vorbis" ? r = Math.max(6e3, r) : e === "mp3" && (r = [
			8e3,
			16e3,
			24e3,
			32e3,
			4e4,
			48e3,
			64e3,
			8e4,
			96e3,
			112e3,
			128e3,
			16e4,
			192e3,
			224e3,
			256e3,
			32e4
		].reduce((e, t) => Math.abs(t - r) < Math.abs(e - r) ? t : e)), Math.round(r / 1e3) * 1e3;
	}
}, ru = {
	"very-low": 0,
	low: .25,
	medium: .5,
	high: .75,
	"very-high": 1
}, iu = {
	avc: {
		min: 0,
		max: 51,
		worst: 41,
		best: 16
	},
	hevc: {
		min: 0,
		max: 51,
		worst: 41,
		best: 16
	},
	vp9: {
		min: 0,
		max: 63,
		worst: 52,
		best: 20
	},
	av1: {
		min: 0,
		max: 255,
		worst: 208,
		best: 80
	}
}, au = (e) => .3 * Math.exp(2.5538 * e), ou = (e, t, n, r) => {
	let i = t * n, a = 3e6, o = a * (i / 2073600) ** .95 * {
		avc: 1,
		hevc: .6,
		vp9: .6,
		av1: .4,
		vp8: 1.2,
		prores: 22e7 / a
	}[e] * r;
	return Math.ceil(o / 1e3) * 1e3;
}, su = (e, t) => {
	if (e === "avc") return { avc: { quantizer: t } };
	if (e === "hevc") return { hevc: { quantizer: t } };
	if (e === "vp9") return { vp9: { quantizer: t } };
	if (e === "av1") return { av1: { quantizer: t } };
	q(!1);
}, cu = /* #__PURE__ */ new nu("high"), lu = async (e, t = {}) => {
	let { width: n = 1280, height: r = 720, quality: i, bitrate: a, frameRate: o, ...s } = t;
	if (!jc.includes(e)) return !1;
	if (!Number.isInteger(n) || n <= 0) throw TypeError("width must be a positive integer.");
	if (!Number.isInteger(r) || r <= 0) throw TypeError("height must be a positive integer.");
	if (i !== void 0 && !(i instanceof nu)) throw TypeError("quality, when provided, must be a Quality.");
	if (i !== void 0 && a !== void 0) throw TypeError("quality and bitrate cannot both be provided.");
	if (a !== void 0 && !(a instanceof nu) && (!Number.isInteger(a) || a <= 0)) throw TypeError("bitrate must be a positive integer or a quality.");
	if (o !== void 0 && (!Number.isFinite(o) || o <= 0)) throw TypeError("frameRate, when provided, must be a finite positive number.");
	eu(e, s);
	let c = uu(i, a) ?? new nu("medium"), l;
	try {
		l = tu({
			codec: e,
			width: n,
			height: r,
			quality: c,
			framerate: o,
			...s,
			alpha: "discard"
		});
	} catch {
		return !1;
	}
	let u = JSON.stringify(l), d = Ql.get(u);
	if (d) return d;
	let f = (async () => {
		for (let { config: t } of l) if (du.some((n) => n.supports(e, t))) return !0;
		if (typeof VideoEncoder > "u" || (n % 2 == 1 || r % 2 == 1) && (e === "avc" || e === "hevc")) return !1;
		for (let { config: t, quantizer: i } of l) {
			try {
				if (!(await VideoEncoder.isConfigSupported(t)).supported) continue;
			} catch {
				continue;
			}
			if (!$o() || await new Promise(async (a) => {
				try {
					let o = new VideoEncoder({
						output: () => {},
						error: () => a(!1)
					});
					o.configure(t);
					let s = new Uint8Array(n * r * 4), c = new VideoFrame(s, {
						format: "RGBA",
						codedWidth: n,
						codedHeight: r,
						timestamp: 0
					});
					o.encode(c, i === null ? void 0 : su(e, i)), c.close(), await o.flush(), a(!0);
				} catch {
					a(!1);
				}
			})) return !0;
		}
		return !1;
	})();
	return Ql.set(u, f), f;
}, uu = (e, t) => {
	if (e !== void 0) return e;
	if (t !== void 0) return t instanceof nu ? t : new nu({ bitrate: t });
}, du = [], fu = class e {
	constructor(e, t, n, r, i) {
		this.bytes = e, this.view = t, this.offset = n, this.start = r, this.end = i, this.bufferPos = r - n;
	}
	static tempFromBytes(t) {
		return new e(t, To(t), 0, 0, t.length);
	}
	get length() {
		return this.end - this.start;
	}
	get filePos() {
		return this.offset + this.bufferPos;
	}
	set filePos(e) {
		this.bufferPos = e - this.offset;
	}
	get remainingLength() {
		return Math.max(this.end - this.filePos, 0);
	}
	skip(e) {
		this.bufferPos += e;
	}
	slice(t, n = this.end - t) {
		if (t < this.start || t + n > this.end) throw RangeError("Slicing outside of original slice.");
		return new e(this.bytes, this.view, this.offset, t, t + n);
	}
}, pu = (e, t) => {
	if (e.filePos < e.start || e.filePos + t > e.end) throw RangeError(`Tried reading [${e.filePos}, ${e.filePos + t}), but slice is [${e.start}, ${e.end}). This is likely an internal error, please report it alongside the file that caused it.`);
}, mu = (e, t) => {
	pu(e, t);
	let n = e.bytes.subarray(e.bufferPos, e.bufferPos + t);
	return e.bufferPos += t, n;
}, hu = class {
	constructor(e) {
		this.mutex = new No(), this.trackTimestampInfo = /* @__PURE__ */ new WeakMap(), this.output = e;
	}
	onTrackClose(e) {}
	validateTimestamp(e, t, n) {
		let r = this.trackTimestampInfo.get(e);
		if (r) {
			if (n && (r.maxTimestampBeforeLastKeyPacket = r.maxTimestamp), r.maxTimestampBeforeLastKeyPacket !== null && t < r.maxTimestampBeforeLastKeyPacket) throw Error(`Timestamps cannot be smaller than the largest timestamp of the previous GOP (a GOP begins with a key packet and ends right before the next key packet). Got ${t}s, but largest timestamp is ${r.maxTimestampBeforeLastKeyPacket}s.`);
			r.maxTimestamp = Math.max(r.maxTimestamp, t);
		} else {
			if (!n) throw Error("First packet must be a key packet.");
			r = {
				maxTimestamp: t,
				maxTimestampBeforeLastKeyPacket: null
			}, this.trackTimestampInfo.set(e, r);
		}
	}
}, gu = /<(?:(\d{2}):)?(\d{2}):(\d{2}).(\d{3})>/g, _u = /(?:(\d{2}):)?(\d{2}):(\d{2}).(\d{3})/, vu = (e) => {
	let t = _u.exec(e);
	if (!t) throw Error("Expected match.");
	return 36e5 * Number(t[1] || "0") + 6e4 * Number(t[2]) + 1e3 * Number(t[3]) + Number(t[4]);
}, yu = (e) => {
	let t = Math.floor(e / 36e5), n = Math.floor(e % 36e5 / 6e4), r = Math.floor(e % 6e4 / 1e3), i = e % 1e3;
	return t.toString().padStart(2, "0") + ":" + n.toString().padStart(2, "0") + ":" + r.toString().padStart(2, "0") + "." + i.toString().padStart(3, "0");
}, bu = class {
	constructor(e) {
		this.writer = e, this.helper = /* @__PURE__ */ new Uint8Array(8), this.helperView = new DataView(this.helper.buffer), this.offsets = /* @__PURE__ */ new WeakMap();
	}
	writeU32(e) {
		this.helperView.setUint32(0, e, !1), this.writer.write(this.helper.subarray(0, 4));
	}
	writeU64(e) {
		this.helperView.setUint32(0, Math.floor(e / 2 ** 32), !1), this.helperView.setUint32(4, e, !1), this.writer.write(this.helper.subarray(0, 8));
	}
	writeAscii(e) {
		for (let t = 0; t < e.length; t++) this.helperView.setUint8(t % 8, e.charCodeAt(t)), t % 8 == 7 && this.writer.write(this.helper);
		e.length % 8 != 0 && this.writer.write(this.helper.subarray(0, e.length % 8));
	}
	writeBox(e) {
		if (this.offsets.set(e, this.writer.getPos()), e.contents && !e.children) this.writeBoxHeader(e, e.size ?? e.contents.byteLength + 8), this.writer.write(e.contents);
		else {
			let t = this.writer.getPos();
			if (this.writeBoxHeader(e, 0), e.contents && this.writer.write(e.contents), e.children) for (let t of e.children) t && this.writeBox(t);
			let n = this.writer.getPos(), r = e.size ?? n - t;
			this.writer.seek(t), this.writeBoxHeader(e, r), this.writer.seek(n);
		}
	}
	writeBoxHeader(e, t) {
		this.writeU32(e.largeSize ? 1 : t), this.writeAscii(e.type), e.largeSize && this.writeU64(t);
	}
	measureBoxHeader(e) {
		return 8 + (e.largeSize ? 8 : 0);
	}
	patchBox(e) {
		let t = this.offsets.get(e);
		q(t !== void 0);
		let n = this.writer.getPos();
		this.writer.seek(t), this.writeBox(e), this.writer.seek(n);
	}
	measureBox(e) {
		if (e.contents && !e.children) return this.measureBoxHeader(e) + e.contents.byteLength;
		{
			let t = this.measureBoxHeader(e);
			if (e.contents && (t += e.contents.byteLength), e.children) for (let n of e.children) n && (t += this.measureBox(n));
			return t;
		}
	}
}, X = /* #__PURE__ */ new Uint8Array(8), xu = /* #__PURE__ */ new DataView(X.buffer), Su = (e) => [(e % 256 + 256) % 256], Z = (e) => (xu.setUint16(0, e, !1), [X[0], X[1]]), Cu = (e) => (xu.setInt16(0, e, !1), [X[0], X[1]]), wu = (e) => (xu.setUint32(0, e, !1), [
	X[1],
	X[2],
	X[3]
]), Q = (e) => (xu.setUint32(0, e, !1), [
	X[0],
	X[1],
	X[2],
	X[3]
]), Tu = (e) => (xu.setInt32(0, e, !1), [
	X[0],
	X[1],
	X[2],
	X[3]
]), Eu = (e) => (xu.setUint32(0, Math.floor(e / 2 ** 32), !1), xu.setUint32(4, e, !1), [
	X[0],
	X[1],
	X[2],
	X[3],
	X[4],
	X[5],
	X[6],
	X[7]
]), Du = (e) => (xu.setInt32(0, Math.floor(e / 2 ** 32), !1), xu.setUint32(4, e, !1), [
	X[0],
	X[1],
	X[2],
	X[3],
	X[4],
	X[5],
	X[6],
	X[7]
]), Ou = (e) => (xu.setInt16(0, 256 * e, !1), [X[0], X[1]]), ku = (e) => (xu.setInt32(0, 2 ** 16 * e, !1), [
	X[0],
	X[1],
	X[2],
	X[3]
]), Au = (e) => (xu.setInt32(0, 2 ** 30 * e, !1), [
	X[0],
	X[1],
	X[2],
	X[3]
]), ju = (e, t) => {
	let n = [], r = e;
	do {
		let e = r & 127;
		r >>= 7, n.length > 0 && (e |= 128), n.push(e), t !== void 0 && t--;
	} while (r > 0 || t);
	return n.reverse();
}, Mu = (e, t = !1) => {
	let n = Array(e.length).fill(null).map((t, n) => e.charCodeAt(n));
	return t && n.push(0), n;
}, Nu = (e) => [
	ku(e[0]),
	ku(e[1]),
	Au(e[2]),
	ku(e[3]),
	ku(e[4]),
	Au(e[5]),
	ku(e[6]),
	ku(e[7]),
	Au(e[8])
], $ = (e, t, n) => ({
	type: e,
	contents: t && new Uint8Array(t.flat(10)),
	children: n
}), Pu = (e, t, n, r, i) => $(e, [
	Su(t),
	wu(n),
	r ?? []
], i), Fu = (e) => e.isQuickTime ? $("ftyp", [
	Mu("qt  "),
	Q(512),
	Mu("qt  ")
]) : e.fragmented ? e.cmaf ? $("ftyp", [
	Mu("iso5"),
	Q(512),
	Mu("iso5"),
	Mu("iso6"),
	Mu("mp41"),
	Mu("cmfc"),
	Mu("dash")
]) : $("ftyp", [
	Mu("iso5"),
	Q(512),
	Mu("iso5"),
	Mu("iso6"),
	Mu("mp41")
]) : $("ftyp", [
	Mu("isom"),
	Q(512),
	Mu("isom"),
	e.holdsAvc ? Mu("avc1") : [],
	Mu("mp41")
]), Iu = () => $("styp", [
	Mu("iso5"),
	Q(0),
	Mu("iso5"),
	Mu("iso6"),
	Mu("mp41"),
	Mu("cmfc"),
	Mu("dash")
]), Lu = (e, t) => {
	let n = Math.max(0, e.minWrittenTimestamp), r = Math.max(0, e.maxWrittenEndTimestamp - n);
	return Number.isFinite(r) || (r = 0), Pu("sidx", 1, 0, [
		Q(1),
		Q(hf),
		Eu(vf(n, hf)),
		Eu(0),
		Z(0),
		Z(1),
		Q(t & 2147483647),
		Q(vf(r, hf)),
		Q(0)
	]);
}, Ru = (e) => ({
	type: "mdat",
	largeSize: e
}), zu = (e) => ({
	type: "free",
	size: e
}), Bu = (e) => $("moov", void 0, [
	Vu(e.creationTime, e.trackDatas),
	...e.trackDatas.map((t) => Hu(t, e.creationTime)),
	e.isFragmented ? jd(e.trackDatas) : null,
	Kd(e)
]), Vu = (e, t) => {
	let n = Math.max(0, ...t.map((e) => Math.max(0, vf(yf(e), hf) + vf(e.startTimestampOffset ?? 0, hf)))), r = Math.max(0, ...t.map((e) => e.track.id)) + 1, i = !bo(e) || !bo(n), a = i ? Eu : Q;
	return Pu("mvhd", +i, 0, [
		a(e),
		a(e),
		Q(hf),
		a(n),
		ku(1),
		Ou(1),
		Array(10).fill(0),
		Nu(lo),
		Array(24).fill(0),
		Q(r)
	]);
}, Hu = (e, t) => {
	let n = _f(e), r = e.startTimestampOffset !== null && e.startTimestampOffset !== 0;
	return $("trak", void 0, [
		Uu(e, t),
		r ? Wu(e) : null,
		Gu(e, t),
		n.name === void 0 ? null : $("udta", void 0, [$("name", [...Do.encode(n.name)])])
	]);
}, Uu = (e, t) => {
	let n = Math.max(0, vf(yf(e), hf) + vf(e.startTimestampOffset ?? 0, hf)), r = !bo(t) || !bo(n), i = r ? Eu : Q, a;
	if (e.type === "video" && e.track.metadata.transformationMatrix) a = e.track.metadata.transformationMatrix;
	else if (e.type === "video") {
		let { rotation: t, flip: n } = e.track.metadata;
		a = uo(_o(mo(t ?? 0), go(n ? -1 : 1, 1)), e.info.width, e.info.height);
	} else a = lo;
	let o = 2;
	e.track.metadata.disposition?.default !== !1 && (o |= 1);
	let s = e.type === "video" ? 0 : e.type === "audio" ? 1 : e.type === "subtitle" ? 2 : Ro(e);
	return Pu("tkhd", +r, o, [
		i(t),
		i(t),
		Q(e.track.id),
		Q(0),
		i(n),
		Array(8).fill(0),
		Z(0),
		Z(s),
		Ou(+(e.type === "audio")),
		Z(0),
		Nu(a),
		ku(e.type === "video" ? e.info.width : 0),
		ku(e.type === "video" ? e.info.height : 0)
	]);
}, Wu = (e) => {
	let t = e.startTimestampOffset;
	if (q(t !== null), t > 0) {
		let n = vf(t, hf), r = vf(yf(e), hf), i = !bo(n) || !bo(r), a = i ? Eu : Q, o = i ? Du : Tu;
		return $("edts", void 0, [Pu("elst", +!!i, 0, [
			Q(2),
			a(n),
			o(-1),
			ku(1),
			a(r),
			o(0),
			ku(1)
		])]);
	}
	{
		let n = vf(-t, e.timescale), r = Math.max(0, vf(yf(e), hf) + vf(t, hf)), i = !xo(n) || !bo(r), a = i ? Eu : Q, o = i ? Du : Tu;
		return $("edts", void 0, [Pu("elst", +!!i, 0, [
			Q(1),
			a(r),
			o(n),
			ku(1)
		])]);
	}
}, Gu = (e, t) => $("mdia", void 0, [
	Ku(e, t),
	Yu(!0, qu[e.type], Ju[e.type]),
	Xu(e)
]), Ku = (e, t) => {
	let n = vf(yf(e), e.timescale), r = !bo(t) || !bo(n), i = r ? Eu : Q;
	return Pu("mdhd", +r, 0, [
		i(t),
		i(t),
		Q(e.timescale),
		i(n),
		Z(sf(e.track.metadata.languageCode ?? "und")),
		Z(0)
	]);
}, qu = {
	video: "vide",
	audio: "soun",
	subtitle: "text"
}, Ju = {
	video: "MediabunnyVideoHandler",
	audio: "MediabunnySoundHandler",
	subtitle: "MediabunnyTextHandler"
}, Yu = (e, t, n, r = "\0\0\0\0") => Pu("hdlr", 0, 0, [
	e ? Mu("mhlr") : Q(0),
	Mu(t),
	Mu(r),
	Q(0),
	Q(0),
	Mu(n, !0)
]), Xu = (e) => $("minf", void 0, [
	Zu[e.type](),
	Qu(),
	td(e)
]), Zu = {
	video: () => Pu("vmhd", 0, 1, [
		Z(0),
		Z(0),
		Z(0),
		Z(0)
	]),
	audio: () => Pu("smhd", 0, 0, [Z(0), Z(0)]),
	subtitle: () => Pu("nmhd", 0, 0)
}, Qu = () => $("dinf", void 0, [$u()]), $u = () => Pu("dref", 0, 0, [Q(1)], [ed()]), ed = () => Pu("url ", 0, 1), td = (e) => {
	let t = e.compositionTimeOffsetTable.length > 1 || e.compositionTimeOffsetTable.some((e) => e.sampleCompositionTimeOffset !== 0);
	return $("stbl", void 0, [
		nd(e),
		wd(e),
		t ? kd(e) : null,
		t ? Ad(e) : null,
		Ed(e),
		Dd(e),
		Od(e),
		Td(e)
	]);
}, nd = (e) => {
	let t;
	if (e.type === "video") t = rd(ef(e.track.source._codec, e.info.decoderConfig.codec), e);
	else if (e.type === "audio") {
		let n = nf(e.track.source._codec, e.info.decoderConfig.codec, e.muxer.isQuickTime);
		q(n), t = dd(n, e);
	} else e.type === "subtitle" && (t = Sd(af[e.track.source._codec], e));
	return q(t), Pu("stsd", 0, 0, [Q(1)], [t]);
}, rd = (e, t) => $(e, [
	[
		,
		,
		,
		,
		,
		,
	].fill(0),
	Z(1),
	Z(0),
	Z(0),
	Array(12).fill(0),
	Z(t.info.width),
	Z(t.info.height),
	Q(4718592),
	Q(4718592),
	Q(0),
	Z(1),
	Su(Ns.length),
	Mu(Ns),
	Array(31 - Ns.length).fill(0),
	Z(t.info.hasAlphaChannel ? 32 : 24),
	Cu(65535)
], [
	tf[t.track.source._codec]?.(t) ?? null,
	ad(t),
	jo(t.info.decoderConfig.colorSpace) ? null : od(t),
	id(t)
]), id = (e) => e.avgBitrate === 0 && e.maxBitrate === 0 ? null : $("btrt", [
	Q(0),
	Q(e.maxBitrate),
	Q(e.avgBitrate)
]), ad = (e) => e.info.pixelAspectRatio.num === e.info.pixelAspectRatio.den ? null : $("pasp", [Q(e.info.pixelAspectRatio.num), Q(e.info.pixelAspectRatio.den)]), od = (e) => {
	let t = e.info.decoderConfig.colorSpace;
	return $("colr", [
		Mu(e.muxer.isQuickTime ? "nclc" : "nclx"),
		Z(t?.primaries == null ? 2 : Oo[t.primaries]),
		Z(t?.transfer == null ? 2 : ko[t.transfer]),
		Z(t?.matrix == null ? 2 : Ao[t.matrix]),
		e.muxer.isQuickTime ? [] : Su(!!t?.fullRange << 7)
	]);
}, sd = (e) => e.info.decoderConfig && $("avcC", [...wo(e.info.decoderConfig.description)]), cd = (e) => e.info.decoderConfig && $("hvcC", [...wo(e.info.decoderConfig.description)]), ld = (e) => {
	if (!e.info.decoderConfig) return null;
	let t = e.info.decoderConfig, n = t.codec.split("."), r = Number(n[1]), i = Number(n[2]), a = Number(n[3]), o = n[4] ? Number(n[4]) : 1, s = n[8] ? Number(n[8]) : Number(t.colorSpace?.fullRange ?? 0), c = (a << 4) + (o << 1) + s, l = n[5] ? Number(n[5]) : t.colorSpace?.primaries ? Oo[t.colorSpace.primaries] : 1, u = n[6] ? Number(n[6]) : t.colorSpace?.transfer ? ko[t.colorSpace.transfer] : 1, d = n[7] ? Number(n[7]) : t.colorSpace?.matrix ? Ao[t.colorSpace.matrix] : 1;
	return Pu("vpcC", 1, 0, [
		Su(r),
		Su(i),
		Su(c),
		Su(l),
		Su(u),
		Su(d),
		Z(0)
	]);
}, ud = (e) => $("av1C", qc(e.info.decoderConfig.codec)), dd = (e, t) => {
	let n = 0, r, i = 16, a = Mc.includes(t.track.source._codec);
	if (a) {
		let e = t.track.source._codec, { sampleSize: r } = Zc(e);
		i = 8 * r, i > 16 && (n = 1);
	}
	if (t.muxer.isQuickTime && (n = 1), n === 0) r = [
		[
			,
			,
			,
			,
			,
			,
		].fill(0),
		Z(1),
		Z(n),
		Z(0),
		Q(0),
		Z(t.info.numberOfChannels),
		Z(i),
		Z(0),
		Z(0),
		Z(t.info.sampleRate < 2 ** 16 ? t.info.sampleRate : 0),
		Z(0)
	];
	else {
		let e = a ? 0 : -2;
		r = [
			[
				,
				,
				,
				,
				,
				,
			].fill(0),
			Z(1),
			Z(n),
			Z(0),
			Q(0),
			Z(t.info.numberOfChannels),
			Z(Math.min(i, 16)),
			Cu(e),
			Z(0),
			Z(t.info.sampleRate < 2 ** 16 ? t.info.sampleRate : 0),
			Z(0),
			a ? [
				Q(1),
				Q(i / 8),
				Q(t.info.numberOfChannels * i / 8)
			] : [
				Q(0),
				Q(0),
				Q(0)
			],
			Q(2)
		];
	}
	return $(e, r, [rf(t.track.source._codec, t.muxer.isQuickTime)?.(t) ?? null, id(t)]);
}, fd = (e) => {
	let t;
	switch (e.track.source._codec) {
		case "aac":
			t = 64;
			break;
		case "mp3":
			t = 107;
			break;
		case "vorbis":
			t = 221;
			break;
		default: throw Error(`Unhandled audio codec: ${e.track.source._codec}`);
	}
	let n = [
		...Su(t),
		...Su(21),
		...wu(0),
		...Q(e.maxBitrate),
		...Q(e.avgBitrate)
	];
	if (e.info.decoderConfig.description) {
		let t = wo(e.info.decoderConfig.description);
		n = [
			...n,
			...Su(5),
			...ju(t.byteLength),
			...t
		];
	}
	return n = [
		...Z(1),
		...Su(0),
		...Su(4),
		...ju(n.length),
		...n,
		...Su(6),
		...Su(1),
		...Su(2)
	], n = [
		...Su(3),
		...ju(n.length),
		...n
	], Pu("esds", 0, 0, n);
}, pd = (e) => $("wave", void 0, [
	md(e),
	hd(e),
	$("\0\0\0\0")
]), md = (e) => $("frma", [Mu(nf(e.track.source._codec, e.info.decoderConfig.codec, e.muxer.isQuickTime))]), hd = (e) => {
	let { littleEndian: t } = Zc(e.track.source._codec);
	return $("enda", [Z(+t)]);
}, gd = (e) => {
	let t = e.info.numberOfChannels, n = 3840, r = e.info.sampleRate, i = 0, a = 0, o = /* @__PURE__ */ new Uint8Array(), s = e.info.decoderConfig?.description;
	if (s) {
		q(s.byteLength >= 18);
		let e = dc(wo(s));
		t = e.outputChannelCount, n = e.preSkip, r = e.inputSampleRate, i = e.outputGain, a = e.channelMappingFamily, e.channelMappingTable && (o = e.channelMappingTable);
	}
	return $("dOps", [
		Su(0),
		Su(t),
		Z(n),
		Q(r),
		Cu(i),
		Su(a),
		...o
	]);
}, _d = (e) => {
	let t = e.info.decoderConfig?.description;
	return q(t), Pu("dfLa", 0, 0, [...wo(t).subarray(4)]);
}, vd = (e) => {
	let { littleEndian: t, sampleSize: n } = Zc(e.track.source._codec);
	return Pu("pcmC", 0, 0, [Su(+t), Su(8 * n)]);
}, yd = (e) => {
	q(e.info.primingPacket);
	let t = mc(e.info.primingPacket.data);
	if (!t) throw Error("Couldn't extract AC-3 frame info from the audio packet. Ensure the packets contain valid AC-3 sync frames (as specified in ETSI TS 102 366).");
	let n = /* @__PURE__ */ new Uint8Array(3), r = new ws(n);
	return r.writeBits(2, t.fscod), r.writeBits(5, t.bsid), r.writeBits(3, t.bsmod), r.writeBits(3, t.acmod), r.writeBits(1, t.lfeon), r.writeBits(5, t.bitRateCode), r.writeBits(5, 0), $("dac3", [...n]);
}, bd = (e) => {
	q(e.info.primingPacket);
	let t = gc(e.info.primingPacket.data);
	if (!t) throw Error("Couldn't extract E-AC-3 frame info from the audio packet. Ensure the packets contain valid E-AC-3 sync frames (as specified in ETSI TS 102 366).");
	let n = 16;
	for (let e of t.substreams) n += 23, e.numDepSub > 0 ? n += 9 : n += 1;
	let r = Math.ceil(n / 8), i = new Uint8Array(r), a = new ws(i);
	a.writeBits(13, t.dataRate), a.writeBits(3, t.substreams.length - 1);
	for (let e of t.substreams) a.writeBits(2, e.fscod), a.writeBits(5, e.bsid), a.writeBits(1, 0), a.writeBits(1, 0), a.writeBits(3, e.bsmod), a.writeBits(3, e.acmod), a.writeBits(1, e.lfeon), a.writeBits(3, 0), a.writeBits(4, e.numDepSub), e.numDepSub > 0 ? a.writeBits(9, e.chanLoc) : a.writeBits(1, 0);
	return $("dec3", [...i]);
}, xd = (e) => {
	q(e.info.primingPacket);
	let t = Dc(e.info.primingPacket.data);
	if (!t) throw Error("Couldn't extract DTS frame info from the audio packet. Ensure the packets contain valid DTS frames as specified in ETSI TS 102 114.");
	return $("ddts", [...Ac(t)]);
}, Sd = (e, t) => $(e, [[
	,
	,
	,
	,
	,
	,
].fill(0), Z(1)], [of[t.track.source._codec](t), id(t)]), Cd = (e) => $("vttC", [...Do.encode(e.info.config.description)]), wd = (e) => Pu("stts", 0, 0, [Q(e.timeToSampleTable.length), e.timeToSampleTable.map((e) => [Q(e.sampleCount), Q(e.sampleDelta)])]), Td = (e) => {
	if (e.samples.every((e) => e.type === "key")) return null;
	let t = [...e.samples.entries()].filter(([, e]) => e.type === "key");
	return Pu("stss", 0, 0, [Q(t.length), t.map(([e]) => Q(e + 1))]);
}, Ed = (e) => Pu("stsc", 0, 0, [Q(e.compactlyCodedChunkTable.length), e.compactlyCodedChunkTable.map((e) => [
	Q(e.firstChunk),
	Q(e.samplesPerChunk),
	Q(1)
])]), Dd = (e) => {
	if (e.type === "audio" && e.info.requiresPcmTransformation) {
		let { sampleSize: t } = Zc(e.track.source._codec);
		return Pu("stsz", 0, 0, [Q(t * e.info.numberOfChannels), Q(e.samples.reduce((t, n) => t + vf(n.duration, e.timescale), 0))]);
	}
	return Pu("stsz", 0, 0, [
		Q(0),
		Q(e.samples.length),
		e.samples.map((e) => Q(e.size))
	]);
}, Od = (e) => e.finalizedChunks.length > 0 && yo(e.finalizedChunks).offset >= 2 ** 32 ? Pu("co64", 0, 0, [Q(e.finalizedChunks.length), e.finalizedChunks.map((e) => Eu(e.offset))]) : Pu("stco", 0, 0, [Q(e.finalizedChunks.length), e.finalizedChunks.map((e) => Q(e.offset))]), kd = (e) => Pu("ctts", 1, 0, [Q(e.compositionTimeOffsetTable.length), e.compositionTimeOffsetTable.map((e) => [Q(e.sampleCount), Tu(e.sampleCompositionTimeOffset)])]), Ad = (e) => {
	let t = Infinity, n = -Infinity, r = Infinity, i = -Infinity;
	q(e.compositionTimeOffsetTable.length > 0), q(e.samples.length > 0);
	for (let r = 0; r < e.compositionTimeOffsetTable.length; r++) {
		let i = e.compositionTimeOffsetTable[r];
		t = Math.min(t, i.sampleCompositionTimeOffset), n = Math.max(n, i.sampleCompositionTimeOffset);
	}
	for (let t = 0; t < e.samples.length; t++) {
		let n = e.samples[t];
		r = Math.min(r, vf(n.timestamp, e.timescale)), i = Math.max(i, vf(n.timestamp + n.duration, e.timescale));
	}
	let a = Math.max(-t, 0);
	return i >= 2 ** 31 ? null : Pu("cslg", 0, 0, [
		Tu(a),
		Tu(t),
		Tu(n),
		Tu(r),
		Tu(i)
	]);
}, jd = (e) => $("mvex", void 0, e.map(Md)), Md = (e) => Pu("trex", 0, 0, [
	Q(e.track.id),
	Q(1),
	Q(0),
	Q(0),
	Q(0)
]), Nd = (e, t) => $("moof", void 0, [Pd(e), ...t.map(Id)]), Pd = (e) => Pu("mfhd", 0, 0, [Q(e)]), Fd = (e) => {
	let t = 0, n = 0, r = e.type === "delta";
	return n |= +r, t |= r ? 1 : 2, t << 24 | n << 16;
}, Id = (e) => $("traf", void 0, [
	Ld(e),
	Rd(e),
	zd(e)
]), Ld = (e) => {
	q(e.currentChunk);
	let t = 0;
	t |= 8, t |= 16, t |= 32, t |= 131072;
	let n = e.currentChunk.samples[1] ?? e.currentChunk.samples[0], r = {
		duration: n.timescaleUnitsToNextSample,
		size: n.size,
		flags: Fd(n)
	};
	return Pu("tfhd", 0, t, [
		Q(e.track.id),
		Q(r.duration),
		Q(r.size),
		Q(r.flags)
	]);
}, Rd = (e) => (q(e.currentChunk), Pu("tfdt", 1, 0, [Eu(vf(e.currentChunk.startTimestamp, e.timescale))])), zd = (e) => {
	q(e.currentChunk);
	let t = e.currentChunk.samples.map((e) => e.timescaleUnitsToNextSample), n = e.currentChunk.samples.map((e) => e.size), r = e.currentChunk.samples.map(Fd), i = e.currentChunk.samples.map((t) => vf(t.timestamp - t.decodeTimestamp, e.timescale)), a = new Set(t), o = new Set(n), s = new Set(r), c = new Set(i), l = s.size === 2 && r[0] !== r[1], u = a.size > 1, d = o.size > 1, f = !l && s.size > 1, p = c.size > 1 || [...c].some((e) => e !== 0), m = 0;
	return m |= 1, m |= 4 * l, m |= 256 * u, m |= 512 * d, m |= 1024 * f, m |= 2048 * p, Pu("trun", 1, m, [
		Q(e.currentChunk.samples.length),
		Q(e.currentChunk.offset - e.currentChunk.moofOffset || 0),
		l ? Q(r[0]) : [],
		e.currentChunk.samples.map((e, a) => [
			u ? Q(t[a]) : [],
			d ? Q(n[a]) : [],
			f ? Q(r[a]) : [],
			p ? Tu(i[a]) : []
		])
	]);
}, Bd = (e) => $("mfra", void 0, [...e.map(Vd), Hd()]), Vd = (e) => Pu("tfra", 1, 0, [
	Q(e.track.id),
	Q(63),
	Q(e.finalizedChunks.length),
	e.finalizedChunks.map((t) => [
		Eu(vf(t.samples[0].timestamp, e.timescale)),
		Eu(t.moofOffset),
		Q(t.trafIndex + 1),
		Q(1),
		Q(1)
	])
]), Hd = () => Pu("mfro", 0, 0, [Q(0)]), Ud = () => $("vtte"), Wd = (e, t, n, r, i) => $("vttc", void 0, [
	i === null ? null : $("vsid", [Tu(i)]),
	n === null ? null : $("iden", [...Do.encode(n)]),
	t === null ? null : $("ctim", [...Do.encode(yu(t))]),
	r === null ? null : $("sttg", [...Do.encode(r)]),
	$("payl", [...Do.encode(e)])
]), Gd = (e) => $("vtta", [...Do.encode(e)]), Kd = (e) => {
	let t = [], n = e.format._options.metadataFormat ?? "auto", r = e.output._metadataTags;
	if (n === "mdir" || n === "auto" && !e.isQuickTime) {
		let e = Zd(r);
		e && t.push(e);
	} else if (n === "mdta") {
		let e = Qd(r);
		e && t.push(e);
	} else (n === "udta" || n === "auto" && e.isQuickTime) && qd(t, e.output._metadataTags);
	return t.length === 0 ? null : $("udta", void 0, t);
}, qd = (e, t) => {
	for (let { key: n, value: r } of os(t)) switch (n) {
		case "title":
			e.push(Jd("©nam", r));
			break;
		case "description":
			e.push(Jd("©des", r));
			break;
		case "artist":
			e.push(Jd("©ART", r));
			break;
		case "album":
			e.push(Jd("©alb", r));
			break;
		case "albumArtist":
			e.push(Jd("albr", r));
			break;
		case "genre":
			e.push(Jd("©gen", r));
			break;
		case "date":
			e.push(Jd("©day", r.toISOString().slice(0, 10)));
			break;
		case "comment":
			e.push(Jd("©cmt", r));
			break;
		case "lyrics":
			e.push(Jd("©lyr", r));
			break;
		case "raw": break;
		case "discNumber":
		case "discsTotal":
		case "trackNumber":
		case "tracksTotal":
		case "beatsPerMinute":
		case "images": break;
		default: Ro(n);
	}
	if (t.raw) for (let n in t.raw) {
		let r = t.raw[n];
		r == null || n.length !== 4 || e.some((e) => e.type === n) || (typeof r == "string" ? e.push(Jd(n, r)) : r instanceof Uint8Array && e.push($(n, Array.from(r))));
	}
}, Jd = (e, t) => {
	let n = Do.encode(t);
	return $(e, [
		Z(n.length),
		Z(sf("und")),
		Array.from(n)
	]);
}, Yd = {
	"image/jpeg": 13,
	"image/png": 14,
	"image/bmp": 27
}, Xd = (e, t) => {
	let n = [];
	for (let { key: r, value: i } of os(e)) switch (r) {
		case "title":
			n.push({
				key: t ? "title" : "©nam",
				value: $d(i)
			});
			break;
		case "description":
			n.push({
				key: t ? "description" : "©des",
				value: $d(i)
			});
			break;
		case "artist":
			n.push({
				key: t ? "artist" : "©ART",
				value: $d(i)
			});
			break;
		case "album":
			n.push({
				key: t ? "album" : "©alb",
				value: $d(i)
			});
			break;
		case "albumArtist":
			n.push({
				key: t ? "album_artist" : "aART",
				value: $d(i)
			});
			break;
		case "comment":
			n.push({
				key: t ? "comment" : "©cmt",
				value: $d(i)
			});
			break;
		case "genre":
			n.push({
				key: t ? "genre" : "©gen",
				value: $d(i)
			});
			break;
		case "beatsPerMinute":
			t || n.push({
				key: "tmpo",
				value: $("data", [
					Q(21),
					Q(0),
					Z(i)
				])
			});
			break;
		case "lyrics":
			n.push({
				key: t ? "lyrics" : "©lyr",
				value: $d(i)
			});
			break;
		case "date":
			n.push({
				key: t ? "date" : "©day",
				value: $d(i.toISOString().slice(0, 10))
			});
			break;
		case "images":
			for (let e of i) e.kind === "coverFront" && n.push({
				key: "covr",
				value: $("data", [
					Q(Yd[e.mimeType] ?? 0),
					Q(0),
					Array.from(e.data)
				])
			});
			break;
		case "trackNumber":
			if (t) {
				let t = e.tracksTotal === void 0 ? i.toString() : `${i}/${e.tracksTotal}`;
				n.push({
					key: "track",
					value: $d(t)
				});
			} else n.push({
				key: "trkn",
				value: $("data", [
					Q(0),
					Q(0),
					Z(0),
					Z(i),
					Z(e.tracksTotal ?? 0),
					Z(0)
				])
			});
			break;
		case "discNumber":
			t || n.push({
				key: "disc",
				value: $("data", [
					Q(0),
					Q(0),
					Z(0),
					Z(i),
					Z(e.discsTotal ?? 0),
					Z(0)
				])
			});
			break;
		case "tracksTotal":
		case "discsTotal": break;
		case "raw": break;
		default: Ro(r);
	}
	if (e.raw) for (let r in e.raw) {
		let i = e.raw[r];
		i == null || !t && r.length !== 4 || n.some((e) => e.key === r) || (typeof i == "string" ? n.push({
			key: r,
			value: $d(i)
		}) : i instanceof Uint8Array ? n.push({
			key: r,
			value: $("data", [
				Q(0),
				Q(0),
				Array.from(i)
			])
		}) : i instanceof bs && n.push({
			key: r,
			value: $("data", [
				Q(Yd[i.mimeType] ?? 0),
				Q(0),
				Array.from(i.data)
			])
		}));
	}
	return n;
}, Zd = (e) => {
	let t = Xd(e, !1);
	return t.length === 0 ? null : Pu("meta", 0, 0, void 0, [Yu(!1, "mdir", "", "appl"), $("ilst", void 0, t.map((e) => $(e.key, void 0, [e.value])))]);
}, Qd = (e) => {
	let t = Xd(e, !0);
	return t.length === 0 ? null : $("meta", void 0, [
		Yu(!1, "mdta", ""),
		Pu("keys", 0, 0, [Q(t.length)], t.map((e) => $("mdta", [...Do.encode(e.key)]))),
		$("ilst", void 0, t.map((e, t) => $(String.fromCharCode(...Q(t + 1)), void 0, [e.value])))
	]);
}, $d = (e) => $("data", [
	Q(1),
	Q(0),
	...Do.encode(e)
]), ef = (e, t) => {
	switch (e) {
		case "avc": return t.startsWith("avc3") ? "avc3" : "avc1";
		case "hevc": return "hvc1";
		case "vp8": return "vp08";
		case "vp9": return "vp09";
		case "av1": return "av01";
		case "prores": return t;
	}
}, tf = {
	avc: sd,
	hevc: cd,
	vp8: ld,
	vp9: ld,
	av1: ud,
	prores: null
}, nf = (e, t, n) => {
	switch (e) {
		case "aac": return "mp4a";
		case "mp3": return "mp4a";
		case "opus": return "Opus";
		case "vorbis": return "mp4a";
		case "flac": return "fLaC";
		case "ulaw": return "ulaw";
		case "alaw": return "alaw";
		case "pcm-u8": return "raw ";
		case "pcm-s8": return "sowt";
		case "ac3": return "ac-3";
		case "eac3": return "ec-3";
		case "dts": return t;
	}
	if (n) switch (e) {
		case "pcm-s16": return "sowt";
		case "pcm-s16be": return "twos";
		case "pcm-s24": return "in24";
		case "pcm-s24be": return "in24";
		case "pcm-s32": return "in32";
		case "pcm-s32be": return "in32";
		case "pcm-f32": return "fl32";
		case "pcm-f32be": return "fl32";
		case "pcm-f64": return "fl64";
		case "pcm-f64be": return "fl64";
	}
	else switch (e) {
		case "pcm-s16": return "ipcm";
		case "pcm-s16be": return "ipcm";
		case "pcm-s24": return "ipcm";
		case "pcm-s24be": return "ipcm";
		case "pcm-s32": return "ipcm";
		case "pcm-s32be": return "ipcm";
		case "pcm-f32": return "fpcm";
		case "pcm-f32be": return "fpcm";
		case "pcm-f64": return "fpcm";
		case "pcm-f64be": return "fpcm";
	}
}, rf = (e, t) => {
	switch (e) {
		case "aac": return fd;
		case "mp3": return fd;
		case "opus": return gd;
		case "vorbis": return fd;
		case "flac": return _d;
		case "ac3": return yd;
		case "eac3": return bd;
		case "dts": return xd;
	}
	if (t) switch (e) {
		case "pcm-s24": return pd;
		case "pcm-s24be": return pd;
		case "pcm-s32": return pd;
		case "pcm-s32be": return pd;
		case "pcm-f32": return pd;
		case "pcm-f32be": return pd;
		case "pcm-f64": return pd;
		case "pcm-f64be": return pd;
	}
	else switch (e) {
		case "pcm-s16": return vd;
		case "pcm-s16be": return vd;
		case "pcm-s24": return vd;
		case "pcm-s24be": return vd;
		case "pcm-s32": return vd;
		case "pcm-s32be": return vd;
		case "pcm-f32": return vd;
		case "pcm-f32be": return vd;
		case "pcm-f64": return vd;
		case "pcm-f64be": return vd;
	}
	return null;
}, af = { webvtt: "wvtt" }, of = { webvtt: Cd }, sf = (e) => {
	q(e.length === 3);
	let t = 0;
	for (let n = 0; n < 3; n++) t <<= 5, t += e.charCodeAt(n) - 96;
	return t;
}, cf = class {
	constructor(e, t) {
		if (this.finalized = !1, this.started = !1, this.pos = 0, this.trackedWrites = null, this.trackedStart = -1, this.trackedEnd = -1, e._writerAcquired) throw Error("Can't have multiple Writers for the same Target.");
		this.target = e, e._setMonotonicity(t), e._writerAcquired = !0;
	}
	start() {
		q(!this.started), this.target._start(), this.started = !0;
	}
	write(e) {
		q(this.started && !this.finalized), this.maybeTrackWrites(e), this.target._write(e, this.pos), this.pos += e.byteLength;
	}
	seek(e) {
		this.pos = e;
	}
	getPos() {
		return this.pos;
	}
	async flush() {
		return q(this.started && !this.finalized), this.target._flush();
	}
	async finalize() {
		q(this.started && !this.finalized), await this.target._finalize(), this.finalized = !0;
	}
	maybeTrackWrites(e) {
		if (!this.trackedWrites) return;
		let t = this.getPos();
		if (t < this.trackedStart) {
			if (t + e.byteLength <= this.trackedStart) return;
			e = e.subarray(this.trackedStart - t), t = 0;
		}
		let n = t + e.byteLength - this.trackedStart, r = this.trackedWrites.byteLength;
		for (; r < n;) r *= 2;
		if (r !== this.trackedWrites.byteLength) {
			let e = new Uint8Array(r);
			e.set(this.trackedWrites, 0), this.trackedWrites = e;
		}
		this.trackedWrites.set(e, t - this.trackedStart), this.trackedEnd = Math.max(this.trackedEnd, t + e.byteLength);
	}
	startTrackingWrites() {
		this.trackedWrites = /* @__PURE__ */ new Uint8Array(1024), this.trackedStart = this.getPos(), this.trackedEnd = this.trackedStart;
	}
	stopTrackingWrites() {
		if (!this.trackedWrites) throw Error("Internal error: Can't get tracked writes since nothing was tracked.");
		let e = {
			data: this.trackedWrites.subarray(0, this.trackedEnd - this.trackedStart),
			start: this.trackedStart,
			end: this.trackedEnd
		};
		return this.trackedWrites = null, e;
	}
};
El();
var lf = class extends gs {
	constructor() {
		super(...arguments), this._writerAcquired = !1, this._monotonicity = null, this.onwrite = null;
	}
	_setMonotonicity(e) {
		this._monotonicity !== !1 && (this._monotonicity = e);
	}
	_dispatchWrite(e, t) {
		this.onwrite?.(e, t), this._emit("write", {
			start: e,
			end: t
		});
	}
	slice(e) {
		if (!Number.isInteger(e) || e < 0) throw TypeError("offset must be a non-negative integer.");
		return new pf(this, e);
	}
}, uf = 2 ** 16, df = 2 ** 32, ff = class extends lf {
	constructor(e = {}) {
		if (super(), this.buffer = null, this._maxPos = 0, !e || typeof e != "object") throw TypeError("BufferTarget options, when provided, must be an object.");
		if (e.onFinalize !== void 0 && typeof e.onFinalize != "function") throw TypeError("options.onFinalize, when provided, must be a function.");
		if (this._options = e, this._supportsResize = "resize" in /* @__PURE__ */ new ArrayBuffer(0), this._supportsResize) try {
			this._buffer = new ArrayBuffer(uf, { maxByteLength: df });
		} catch {
			this._buffer = new ArrayBuffer(uf), this._supportsResize = !1;
		}
		else this._buffer = new ArrayBuffer(uf);
		this._bytes = new Uint8Array(this._buffer);
	}
	_ensureSize(e) {
		let t = this._buffer.byteLength;
		for (; t < e;) t *= 2;
		if (t !== this._buffer.byteLength) {
			if (t > df) throw Error(`ArrayBuffer exceeded maximum size of ${df} bytes. Please consider using another target.`);
			if (this._supportsResize) this._buffer.resize(t);
			else {
				let e = new ArrayBuffer(t), n = new Uint8Array(e);
				n.set(this._bytes, 0), this._buffer = e, this._bytes = n;
			}
		}
	}
	_start() {}
	_write(e, t) {
		this._ensureSize(t + e.byteLength), this._bytes.set(e, t), this._maxPos = Math.max(this._maxPos, t + e.byteLength), this._dispatchWrite(t, t + e.byteLength);
	}
	async _flush() {}
	async _finalize() {
		this.buffer = this._buffer.slice(0, this._maxPos), this._options.onFinalize && await this._options.onFinalize(this.buffer), this._emit("finalized");
	}
	async _close() {}
	_getSlice(e, t) {
		return this._bytes.slice(e, t);
	}
}, pf = class extends lf {
	constructor(e, t) {
		super(), this._baseTarget = e, this._offset = t;
	}
	_start() {}
	_write(e, t) {
		this._baseTarget._write(e, this._offset + t), this._dispatchWrite(t, t + e.byteLength);
	}
	_flush() {
		return this._baseTarget._flush();
	}
	async _finalize() {
		this._emit("finalized");
	}
	async _close() {}
	_setMonotonicity(e) {
		super._setMonotonicity(e), this._baseTarget._setMonotonicity(e);
	}
}, mf = class {
	constructor(e, t) {
		if (this.rootPath = e, this.getTarget = t, typeof e != "string") throw TypeError("rootPath must be a string.");
		if (typeof t != "function") throw TypeError("getTarget must be a function.");
	}
}, hf = 57600, gf = 2082844800, _f = (e) => {
	let t = {}, n = e.track;
	return n.metadata.name !== void 0 && (t.name = n.metadata.name), t;
}, vf = (e, t, n = !0) => {
	let r = e * t;
	return n ? Math.round(r) : r;
}, yf = (e) => {
	if (e.samples.length === 0) return 0;
	let t = Infinity, n = -Infinity;
	for (let r = 0; r < e.samples.length; r++) {
		let i = e.samples[r];
		i.timestamp < t && (t = i.timestamp), i.timestamp + i.duration > n && (n = i.timestamp + i.duration);
	}
	return t === Infinity ? 0 : n - t;
}, bf = class extends hu {
	constructor(e, t) {
		super(e), this.writer = null, this.boxWriter = null, this.initWriter = null, this.initBoxWriter = null, this.auxTarget = new ff(), this.auxWriter = new cf(this.auxTarget, !1), this.auxBoxWriter = new bu(this.auxWriter), this.mdat = null, this.ftypSize = null, this.trackDatas = [], this.allTracksKnown = Lo(), this.creationTime = Math.floor(Date.now() / 1e3) + gf, this.finalizedChunks = [], this.wroteFragmentedHeader = !1, this.nextFragmentNumber = 1, this.maxWrittenTimestamp = -Infinity, this.minWrittenTimestamp = Infinity, this.maxWrittenEndTimestamp = -Infinity, this.segmentHeaderSize = null, this.format = t, this.formatOptions = { ...t._options }, this.isQuickTime = t instanceof Uf, this.isCmaf = t instanceof Hf, this.minimumFragmentDuration = this.formatOptions.minimumFragmentDuration ?? (t instanceof Hf ? Infinity : 1), this.auxWriter.start();
	}
	async start() {
		let e = await this.mutex.acquire();
		if (this.isCmaf ? (this.fastStart = "fragmented", this.isFragmented = !0) : (this.writer = await this.output._getRootWriter((e) => this.formatOptions.fastStart === void 0 ? e instanceof ff : this.formatOptions.fastStart === "fragmented"), this.boxWriter = new bu(this.writer), this.fastStart = this.formatOptions.fastStart ?? (this.writer.target instanceof ff && "in-memory"), this.isFragmented = this.fastStart === "fragmented"), this.isCmaf) {
			if (!this.output._hasInitTarget()) throw Error("CMAF outputs require the initTarget field in OutputOptions to be set; the init segment will be written to it.");
			let e = new cf(await this.output._getInitTarget(), !0);
			e.start(), this.initWriter = e, this.initBoxWriter = new bu(e);
		}
		let t = this.output.tracks.some((e) => e.isVideoTrack() && e.source._codec === "avc");
		{
			let e = this.initBoxWriter ?? this.boxWriter;
			if (q(e), this.formatOptions.onFtyp && e.writer.startTrackingWrites(), e.writeBox(Fu({
				isQuickTime: this.isQuickTime,
				holdsAvc: t,
				fragmented: this.isFragmented,
				cmaf: this.isCmaf
			})), this.formatOptions.onFtyp) {
				let { data: t, start: n } = e.writer.stopTrackingWrites();
				this.formatOptions.onFtyp(t, n);
			}
			this.ftypSize = e.writer.getPos(), this.isCmaf && await this.initWriter.flush();
		}
		if (this.fastStart !== "in-memory") {
			if (this.fastStart === "reserve") {
				for (let e of this.output.tracks) if (e.metadata.maximumPacketCount === void 0) throw Error("All tracks must specify maximumPacketCount in their metadata when using fastStart: 'reserve'.");
			} else this.isFragmented || (q(this.writer), q(this.boxWriter), this.formatOptions.onMdat && this.writer.startTrackingWrites(), this.mdat = Ru(!0), this.boxWriter.writeBox(this.mdat));
		}
		await this.writer?.flush();
		for (let e of this.output.tracks) e.isVideoTrack() && e.metadata.decoderConfig ? this.getVideoTrackData(e, e.metadata.primingPacket ?? null, { decoderConfig: e.metadata.decoderConfig }) : e.isAudioTrack() && e.metadata.decoderConfig && this.getAudioTrackData(e, e.metadata.primingPacket ?? null, { decoderConfig: e.metadata.decoderConfig });
		e();
	}
	allTracksAreKnown() {
		for (let e of this.output.tracks) if (!e.source._closed && !this.trackDatas.some((t) => t.track === e)) return !1;
		return !0;
	}
	async getMimeType() {
		await this.allTracksKnown.promise;
		let e = this.trackDatas.map((e) => e.type === "video" || e.type === "audio" ? e.info.decoderConfig.codec : { webvtt: "wvtt" }[e.track.source._codec]);
		return dl({
			isQuickTime: this.isQuickTime,
			hasVideo: this.trackDatas.some((e) => e.type === "video"),
			hasAudio: this.trackDatas.some((e) => e.type === "audio"),
			codecStrings: e
		});
	}
	getVideoTrackData(e, t, n) {
		let r = this.trackDatas.find((t) => t.track === e);
		if (r) return r;
		al(n, e.source._codec), q(n), q(n.decoderConfig);
		let i = { ...n.decoderConfig };
		q(i.codedWidth !== void 0), q(i.codedHeight !== void 0);
		let a = !1;
		if (e.source._codec === "avc" && !i.description) {
			if (!t) throw Error("No AVC description provided; you must therefore provide a priming packet.");
			let e = Hs(t.data);
			if (!e) throw Error("Couldn't extract an AVCDecoderConfigurationRecord from the AVC packet. Make sure the packets are in Annex B format (as specified in ITU-T-REC-H.264) when not providing a description, or provide a description (must be an AVCDecoderConfigurationRecord as specified in ISO 14496-15) and ensure the packets are in AVCC format.");
			i.description = Us(e), a = !0;
		} else if (e.source._codec === "hevc" && !i.description) {
			if (!t) throw Error("No HEVC description provided; you must therefore provide a priming packet.");
			let e = Xs(t.data);
			if (!e) throw Error("Couldn't extract an HEVCDecoderConfigurationRecord from the HEVC packet. Make sure the packets are in Annex B format (as specified in ITU-T-REC-H.265) when not providing a description, or provide a description (must be an HEVCDecoderConfigurationRecord as specified in ISO 14496-15) and ensure the packets are in HEVC format.");
			i.description = ic(e), a = !0;
		}
		let o = Xo(1 / (e.metadata.frameRate ?? 57600), 1e6).den, s = i.displayAspectWidth, c = i.displayAspectHeight, l = s === void 0 || c === void 0 ? {
			num: 1,
			den: 1
		} : fs({
			num: s * i.codedHeight,
			den: c * i.codedWidth
		}), u = i.codec === "ap4h" || i.codec === "ap4x", d = {
			muxer: this,
			track: e,
			type: "video",
			info: {
				width: i.codedWidth,
				height: i.codedHeight,
				pixelAspectRatio: l,
				decoderConfig: i,
				requiresAnnexBTransformation: a,
				hasAlphaChannel: u
			},
			timescale: o,
			samples: [],
			sampleQueue: [],
			timestampProcessingQueue: [],
			timeToSampleTable: [],
			compositionTimeOffsetTable: [],
			lastTimescaleUnits: null,
			lastSample: null,
			startTimestampOffset: null,
			finalizedChunks: [],
			currentChunk: null,
			compactlyCodedChunkTable: [],
			closed: !1,
			avgBitrate: e.source._nominalBitrate ?? e.metadata.averageBitrate ?? 0,
			maxBitrate: e.source._nominalBitrate ?? e.metadata.bitrate ?? 0
		};
		return this.trackDatas.push(d), this.trackDatas.sort((e, t) => e.track.id - t.track.id), this.allTracksAreKnown() && this.allTracksKnown.resolve(), d;
	}
	getAudioTrackData(e, t, n) {
		let r = this.trackDatas.find((t) => t.track === e);
		if (r) return r;
		sl(n, e.source._codec), q(n), q(n.decoderConfig);
		let i = { ...n.decoderConfig }, a = !1;
		if (e.source._codec === "aac" && !i.description) {
			if (!t) throw Error("No AAC description provided; you must therefore provide a priming packet.");
			let e = Tl(fu.tempFromBytes(t.data));
			if (!e) throw Error("Couldn't parse ADTS header from the AAC packet. Make sure the packets are in ADTS format (as specified in ISO 13818-7) when not providing a description, or provide a description (must be an AudioSpecificConfig as specified in ISO 14496-3) and ensure the packets are raw AAC data.");
			let n = Ts[e.samplingFrequencyIndex], r = Es[e.channelConfiguration];
			if (n === void 0 || r === void 0) throw Error("Invalid ADTS frame header.");
			i.description = Ds({
				objectType: e.objectType,
				outputSampleRate: n,
				outputNumberOfChannels: r
			}), a = !0;
		}
		if (!t) {
			if (e.source._codec === "ac3" || e.source._codec === "eac3") throw Error("AC-3/E-AC-3 require a priming packet.");
			if (e.source._codec === "dts") throw Error("DTS requires a priming packet.");
		}
		let o = {
			muxer: this,
			track: e,
			type: "audio",
			info: {
				numberOfChannels: n.decoderConfig.numberOfChannels,
				sampleRate: n.decoderConfig.sampleRate,
				decoderConfig: i,
				requiresPcmTransformation: !this.isFragmented && Mc.includes(e.source._codec),
				expectedNextPcmPacketTimestamp: null,
				requiresAdtsStripping: a,
				primingPacket: t
			},
			timescale: i.sampleRate,
			samples: [],
			sampleQueue: [],
			timestampProcessingQueue: [],
			timeToSampleTable: [],
			compositionTimeOffsetTable: [],
			lastTimescaleUnits: null,
			lastSample: null,
			startTimestampOffset: null,
			finalizedChunks: [],
			currentChunk: null,
			compactlyCodedChunkTable: [],
			closed: !1,
			avgBitrate: e.source._nominalBitrate ?? e.metadata.averageBitrate ?? 0,
			maxBitrate: e.source._nominalBitrate ?? e.metadata.bitrate ?? 0
		};
		return this.trackDatas.push(o), this.trackDatas.sort((e, t) => e.track.id - t.track.id), this.allTracksAreKnown() && this.allTracksKnown.resolve(), o;
	}
	getSubtitleTrackData(e, t) {
		let n = this.trackDatas.find((t) => t.track === e);
		if (n) return n;
		cl(t), q(t), q(t.config);
		let r = {
			muxer: this,
			track: e,
			type: "subtitle",
			info: { config: t.config },
			timescale: 1e3,
			samples: [],
			sampleQueue: [],
			timestampProcessingQueue: [],
			timeToSampleTable: [],
			compositionTimeOffsetTable: [],
			lastTimescaleUnits: null,
			lastSample: null,
			startTimestampOffset: null,
			finalizedChunks: [],
			currentChunk: null,
			compactlyCodedChunkTable: [],
			closed: !1,
			avgBitrate: e.source._nominalBitrate ?? e.metadata.averageBitrate ?? 0,
			maxBitrate: e.source._nominalBitrate ?? e.metadata.bitrate ?? 0,
			lastCueEndTimestamp: null,
			cueQueue: [],
			nextSourceId: 0,
			cueToSourceId: /* @__PURE__ */ new WeakMap()
		};
		return this.trackDatas.push(r), this.trackDatas.sort((e, t) => e.track.id - t.track.id), this.allTracksAreKnown() && this.allTracksKnown.resolve(), r;
	}
	async addEncodedVideoPacket(e, t, n) {
		let r = await this.mutex.acquire();
		try {
			let r = this.getVideoTrackData(e, t, n), i = t.data;
			if (r.info.requiresAnnexBTransformation) {
				let e = [...Is(i)].map((e) => i.subarray(e.offset, e.offset + e.length));
				if (e.length === 0) throw Error("Failed to transform packet data. Make sure all packets are provided in Annex B format, as specified in ITU-T-REC-H.264 and ITU-T-REC-H.265.");
				i = Vs(e, 4);
			}
			this.validateTimestamp(r.track, t.timestamp, t.type === "key");
			let a = this.createSampleForTrack(r, i, t.timestamp, t.duration, t.type);
			await this.registerSample(r, a);
		} finally {
			r();
		}
	}
	async addEncodedAudioPacket(e, t, n) {
		let r = await this.mutex.acquire();
		try {
			let r = this.getAudioTrackData(e, t, n), i = t.data;
			if (r.info.requiresAdtsStripping) {
				let e = Tl(fu.tempFromBytes(i));
				if (!e) throw Error("Expected ADTS frame, didn't get one.");
				let t = e.crcCheck === null ? 7 : 9;
				i = i.subarray(t);
			}
			this.validateTimestamp(r.track, t.timestamp, t.type === "key");
			let a = t.timestamp, o = t.duration;
			if (r.info.requiresPcmTransformation) {
				let e = Zc(r.info.decoderConfig.codec).sampleSize * r.info.numberOfChannels;
				if (o = i.byteLength / e / r.info.sampleRate, r.info.expectedNextPcmPacketTimestamp !== null) {
					let e = a - r.info.expectedNextPcmPacketTimestamp;
					if (e < .01) a = r.info.expectedNextPcmPacketTimestamp;
					else {
						let t = await this.padWithSilence(r, r.info.expectedNextPcmPacketTimestamp, e);
						a = r.info.expectedNextPcmPacketTimestamp + t;
					}
				}
				r.info.expectedNextPcmPacketTimestamp = a + o;
			}
			let s = this.createSampleForTrack(r, i, a, o, t.type);
			await this.registerSample(r, s);
		} finally {
			r();
		}
	}
	async padWithSilence(e, t, n) {
		let r = vf(n, e.timescale);
		if (n = r / e.timescale, r > 0) {
			let { sampleSize: i, silentValue: a } = Zc(e.info.decoderConfig.codec), o = r * e.info.numberOfChannels, s = new Uint8Array(i * o).fill(a), c = this.createSampleForTrack(e, new Uint8Array(s.buffer), t, n, "key");
			await this.registerSample(e, c);
		}
		return n;
	}
	async addSubtitleCue(e, t, n) {
		let r = await this.mutex.acquire();
		try {
			let r = this.getSubtitleTrackData(e, n);
			this.validateTimestamp(r.track, t.timestamp, !0), e.source._codec === "webvtt" && (r.cueQueue.push(t), await this.processWebVTTCues(r, t.timestamp));
		} finally {
			r();
		}
	}
	async processWebVTTCues(e, t) {
		for (; e.cueQueue.length > 0;) {
			e.lastCueEndTimestamp ??= Math.min(0, e.cueQueue[0].timestamp);
			let n = /* @__PURE__ */ new Set([]);
			for (let r of e.cueQueue) q(r.timestamp <= t), q(e.lastCueEndTimestamp <= r.timestamp + r.duration), n.add(Math.max(r.timestamp, e.lastCueEndTimestamp)), n.add(r.timestamp + r.duration);
			let r = [...n].sort((e, t) => e - t), i = r[0], a = r[1] ?? i;
			if (t < a) break;
			if (e.lastCueEndTimestamp < i) {
				this.auxWriter.seek(0);
				let t = Ud();
				this.auxBoxWriter.writeBox(t);
				let n = this.auxTarget._getSlice(0, this.auxWriter.getPos()), r = this.createSampleForTrack(e, n, e.lastCueEndTimestamp, i - e.lastCueEndTimestamp, "key");
				await this.registerSample(e, r), e.lastCueEndTimestamp = i;
			}
			this.auxWriter.seek(0);
			for (let t = 0; t < e.cueQueue.length; t++) {
				let n = e.cueQueue[t];
				if (n.timestamp >= a) break;
				gu.lastIndex = 0;
				let r = gu.test(n.text), o = n.timestamp + n.duration, s = e.cueToSourceId.get(n);
				if (s === void 0 && a < o && (s = e.nextSourceId++, e.cueToSourceId.set(n, s)), n.notes) {
					let e = Gd(n.notes);
					this.auxBoxWriter.writeBox(e);
				}
				let c = Wd(n.text, r ? i : null, n.identifier ?? null, n.settings ?? null, s ?? null);
				this.auxBoxWriter.writeBox(c), o === a && e.cueQueue.splice(t--, 1);
			}
			let o = this.auxTarget._getSlice(0, this.auxWriter.getPos()), s = this.createSampleForTrack(e, o, i, a - i, "key");
			await this.registerSample(e, s), e.lastCueEndTimestamp = a;
		}
	}
	createSampleForTrack(e, t, n, r, i) {
		return {
			timestamp: n,
			decodeTimestamp: n,
			duration: r,
			data: t,
			size: t.byteLength,
			type: i,
			timescaleUnitsToNextSample: vf(r, e.timescale)
		};
	}
	processTimestamps(e, t) {
		if (e.timestampProcessingQueue.length === 0) return;
		if (e.type === "audio" && e.info.requiresPcmTransformation) {
			q(!this.isFragmented), e.startTimestampOffset ??= e.timestampProcessingQueue[0].timestamp;
			let t = 0;
			for (let n = 0; n < e.timestampProcessingQueue.length; n++) {
				let r = e.timestampProcessingQueue[n], i = vf(r.duration, e.timescale);
				t += i;
			}
			if (e.timeToSampleTable.length === 0) e.timeToSampleTable.push({
				sampleCount: t,
				sampleDelta: 1
			});
			else {
				let n = yo(e.timeToSampleTable);
				n.sampleCount += t;
			}
			e.timestampProcessingQueue.length = 0;
			return;
		}
		let n = e.timestampProcessingQueue.map((e) => e.timestamp).sort((e, t) => e - t);
		this.isFragmented ? e.startTimestampOffset ??= Math.min(n[0], 0) : e.startTimestampOffset ??= n[0];
		for (let t = 0; t < e.timestampProcessingQueue.length; t++) {
			let r = e.timestampProcessingQueue[t];
			r.decodeTimestamp = n[t];
			let i = vf(r.timestamp - r.decodeTimestamp, e.timescale), a = vf(r.duration, e.timescale);
			if (e.lastTimescaleUnits !== null) {
				q(e.lastSample);
				let t = vf(r.decodeTimestamp, e.timescale, !1), n = Math.round(t - e.lastTimescaleUnits);
				if (q(n >= 0), e.lastTimescaleUnits += n, e.lastSample.timescaleUnitsToNextSample = n, !this.isFragmented) {
					let t = yo(e.timeToSampleTable);
					if (q(t), t.sampleCount === 1) {
						t.sampleDelta = n;
						let r = e.timeToSampleTable[e.timeToSampleTable.length - 2];
						r && r.sampleDelta === n && (r.sampleCount++, e.timeToSampleTable.pop(), t = r);
					} else t.sampleDelta !== n && (t.sampleCount--, e.timeToSampleTable.push(t = {
						sampleCount: 1,
						sampleDelta: n
					}));
					t.sampleDelta === a ? t.sampleCount++ : e.timeToSampleTable.push({
						sampleCount: 1,
						sampleDelta: a
					});
					let r = yo(e.compositionTimeOffsetTable);
					q(r), r.sampleCompositionTimeOffset === i ? r.sampleCount++ : e.compositionTimeOffsetTable.push({
						sampleCount: 1,
						sampleCompositionTimeOffset: i
					});
				}
			} else e.lastTimescaleUnits = vf(r.decodeTimestamp, e.timescale, !1), this.isFragmented || (e.timeToSampleTable.push({
				sampleCount: 1,
				sampleDelta: a
			}), e.compositionTimeOffsetTable.push({
				sampleCount: 1,
				sampleCompositionTimeOffset: i
			}));
			e.lastSample = r;
		}
		if (e.timestampProcessingQueue.length = 0, q(e.lastSample), q(e.lastTimescaleUnits !== null), t !== void 0 && e.lastSample.timescaleUnitsToNextSample === 0) {
			q(t.type === "key");
			let n = vf(t.timestamp, e.timescale, !1), r = Math.round(n - e.lastTimescaleUnits);
			e.lastSample.timescaleUnitsToNextSample = r;
		}
	}
	async registerSample(e, t) {
		t.type === "key" && this.processTimestamps(e, t), e.timestampProcessingQueue.push(t), this.isFragmented ? (e.sampleQueue.push(t), await this.interleaveSamples()) : this.fastStart === "reserve" ? await this.registerSampleFastStartReserve(e, t) : await this.addSampleToTrack(e, t);
	}
	async addSampleToTrack(e, t) {
		if (!this.isFragmented && (e.samples.push(t), this.fastStart === "reserve")) {
			let t = e.track.metadata.maximumPacketCount;
			if (q(t !== void 0), e.samples.length > t) throw Error(`Track #${e.track.id} has already reached the maximum packet count (${t}). Either add less packets or increase the maximum packet count.`);
		}
		let n = !1;
		if (!e.currentChunk) n = !0;
		else {
			e.currentChunk.startTimestamp = Math.min(e.currentChunk.startTimestamp, t.timestamp);
			let r = t.timestamp - e.currentChunk.startTimestamp;
			if (this.isFragmented) {
				let i = this.trackDatas.every((n) => {
					if (e === n) return t.type === "key";
					let r = n.sampleQueue[0];
					return r ? r.type === "key" : n.closed;
				});
				r >= this.minimumFragmentDuration && i && t.timestamp > this.maxWrittenTimestamp && (n = !0, await this.finalizeFragment());
			} else n = r >= .5;
		}
		n && (e.currentChunk && await this.finalizeCurrentChunk(e), e.currentChunk = {
			startTimestamp: t.timestamp,
			samples: [],
			offset: null,
			moofOffset: null,
			trafIndex: null
		}), q(e.currentChunk), e.currentChunk.samples.push(t), this.isFragmented && (this.maxWrittenTimestamp = Math.max(this.maxWrittenTimestamp, t.timestamp), this.maxWrittenEndTimestamp = Math.max(this.maxWrittenEndTimestamp, t.timestamp + t.duration), this.minWrittenTimestamp = Math.min(this.minWrittenTimestamp, t.timestamp));
	}
	async finalizeCurrentChunk(e) {
		if (q(!this.isFragmented), q(this.writer), !e.currentChunk) return;
		e.finalizedChunks.push(e.currentChunk), this.finalizedChunks.push(e.currentChunk);
		let t = e.currentChunk.samples.length;
		if (e.type === "audio" && e.info.requiresPcmTransformation && (t = e.currentChunk.samples.reduce((t, n) => t + vf(n.duration, e.timescale), 0)), (e.compactlyCodedChunkTable.length === 0 || yo(e.compactlyCodedChunkTable).samplesPerChunk !== t) && e.compactlyCodedChunkTable.push({
			firstChunk: e.finalizedChunks.length,
			samplesPerChunk: t
		}), this.fastStart === "in-memory") e.currentChunk.offset = 0;
		else {
			e.currentChunk.offset = this.writer.getPos();
			for (let t of e.currentChunk.samples) q(t.data), this.writer.write(t.data), t.data = null;
			await this.writer.flush();
		}
	}
	async interleaveSamples(e = !1) {
		if (q(this.isFragmented), e || this.allTracksAreKnown()) outer: for (;;) {
			let t = null, n = Infinity;
			for (let r of this.trackDatas) {
				if (!e && r.sampleQueue.length === 0 && !r.closed) break outer;
				r.sampleQueue.length > 0 && r.sampleQueue[0].timestamp < n && (t = r, n = r.sampleQueue[0].timestamp);
			}
			if (!t) break;
			let r = t.sampleQueue.shift();
			await this.addSampleToTrack(t, r);
		}
	}
	async finalizeFragment(e = !this.isCmaf) {
		if (q(this.isFragmented), !this.wroteFragmentedHeader) {
			this.wroteFragmentedHeader = !0;
			let e = this.initBoxWriter ?? this.boxWriter;
			q(e), this.formatOptions.onMoov && e.writer.startTrackingWrites(), this.ensureOneEnabledTrack();
			let t = Bu(this);
			if (e.writeBox(t), this.formatOptions.onMoov) {
				let { data: t, start: n } = e.writer.stopTrackingWrites();
				this.formatOptions.onMoov(t, n);
			}
			if (this.isCmaf) {
				q(this.initWriter), await this.initWriter.flush(), await this.initWriter.finalize(), this.writer = await this.output._getRootWriter(!0), this.boxWriter = new bu(this.writer);
				let e = this.boxWriter.measureBox(Iu()), t = this.boxWriter.measureBox(Lu(this, 0));
				this.segmentHeaderSize = e + t, this.writer.seek(this.segmentHeaderSize);
			}
		}
		q(this.writer), q(this.boxWriter);
		let t = this.trackDatas.filter((e) => e.currentChunk);
		if (t.length === 0) {
			e && await this.writer.flush();
			return;
		}
		let n = this.nextFragmentNumber++, r = Nd(n, t), i = this.writer.getPos(), a = i + this.boxWriter.measureBox(r), o = a + 8, s = Infinity;
		for (let e = 0; e < t.length; e++) {
			let n = t[e];
			q(n.currentChunk), q(n.startTimestampOffset !== null), n.currentChunk.offset = o, n.currentChunk.moofOffset = i, n.currentChunk.trafIndex = e, n.currentChunk.startTimestamp -= n.startTimestampOffset;
			for (let e of n.currentChunk.samples) o += e.size, e.timestamp -= n.startTimestampOffset, e.decodeTimestamp -= n.startTimestampOffset;
			s = Math.min(s, n.currentChunk.startTimestamp);
		}
		let c = o - a, l = c >= 2 ** 32;
		if (l) for (let e of t) e.currentChunk.offset += 8;
		this.formatOptions.onMoof && this.writer.startTrackingWrites();
		let u = Nd(n, t);
		if (this.boxWriter.writeBox(u), this.formatOptions.onMoof) {
			let { data: e, start: t } = this.writer.stopTrackingWrites();
			this.formatOptions.onMoof(e, t, s);
		}
		q(this.writer.getPos() === a), this.formatOptions.onMdat && this.writer.startTrackingWrites();
		let d = Ru(l);
		d.size = c, this.boxWriter.writeBox(d), this.writer.seek(a + (l ? 16 : 8));
		for (let e of t) for (let t of e.currentChunk.samples) this.writer.write(t.data), t.data = null;
		if (this.formatOptions.onMdat) {
			let { data: e, start: t } = this.writer.stopTrackingWrites();
			this.formatOptions.onMdat(e, t);
		}
		for (let e of t) e.finalizedChunks.push(e.currentChunk), this.finalizedChunks.push(e.currentChunk), e.currentChunk = null;
		e && await this.writer.flush();
	}
	async registerSampleFastStartReserve(e, t) {
		this.allTracksAreKnown() ? (this.mdat || await this.createFastStartReserveMdat(), await this.addSampleToTrack(e, t)) : e.sampleQueue.push(t);
	}
	async createFastStartReserveMdat() {
		q(this.writer), q(this.boxWriter), this.ensureOneEnabledTrack();
		let e = Bu(this), t = this.boxWriter.measureBox(e) + this.computeSampleTableSizeUpperBound() + 4096;
		q(this.ftypSize !== null), this.writer.seek(this.ftypSize + t), this.formatOptions.onMdat && this.writer.startTrackingWrites(), this.mdat = Ru(!0), this.boxWriter.writeBox(this.mdat);
		for (let e of this.trackDatas) {
			for (let t of e.sampleQueue) await this.addSampleToTrack(e, t);
			e.sampleQueue.length = 0;
		}
	}
	computeSampleTableSizeUpperBound() {
		q(this.fastStart === "reserve");
		let e = 0;
		for (let t of this.trackDatas) {
			let n = t.track.metadata.maximumPacketCount;
			q(n !== void 0), e += 8 * Math.ceil(2 / 3 * n), e += 4 * n, e += 8 * Math.ceil(2 / 3 * n), e += 12 * Math.ceil(2 / 3 * n), e += 4 * n, e += 8 * n;
		}
		return e;
	}
	async onTrackClose(e) {
		let t = await this.mutex.acquire(), n = this.trackDatas.find((t) => t.track === e);
		n && (n.closed = !0, n.type === "subtitle" && e.source._codec === "webvtt" && await this.processWebVTTCues(n, Infinity), this.processTimestamps(n)), this.allTracksAreKnown() && this.allTracksKnown.resolve(), this.isFragmented && await this.interleaveSamples(), t();
	}
	ensureOneEnabledTrack() {
		for (let e of [
			"video",
			"audio",
			"subtitle"
		]) {
			let t = this.trackDatas.filter((t) => t.type === e);
			if (t.length !== 0 && !t.some((e) => e.track.metadata.disposition?.default !== !1)) {
				let e = t[0];
				e.track.metadata.disposition = {
					...e.track.metadata.disposition,
					default: !0
				};
			}
		}
	}
	async forceFragmentFinalization() {
		q(this.isFragmented);
		let e = await this.mutex.acquire();
		try {
			for (let e of this.trackDatas) e.type === "subtitle" && e.track.source._codec === "webvtt" && await this.processWebVTTCues(e, Infinity), this.processTimestamps(e);
			await this.interleaveSamples(!0), await this.finalizeFragment();
		} finally {
			e();
		}
	}
	async finalize() {
		let e = await this.mutex.acquire();
		this.allTracksKnown.resolve(), this.ensureOneEnabledTrack(), !this.mdat && this.fastStart === "reserve" && await this.createFastStartReserveMdat();
		for (let e of this.trackDatas) e.closed = !0, e.type === "subtitle" && e.track.source._codec === "webvtt" && await this.processWebVTTCues(e, Infinity), this.processTimestamps(e);
		if (this.isFragmented) await this.interleaveSamples(!0), await this.finalizeFragment(!1);
		else for (let e of this.trackDatas) {
			await this.finalizeCurrentChunk(e);
			let t = yf(e);
			if (t > 0) {
				let n = 0;
				for (let t of e.samples) n += t.size;
				e.avgBitrate = Math.round(8 * n / t);
			} else e.avgBitrate = 0;
			let n = 0, r = 0, i = 0;
			for (let t = 0; t < e.samples.length; t++) {
				let a = e.samples[t];
				for (r += a.size; a.decodeTimestamp - e.samples[n].decodeTimestamp >= 1;) r -= e.samples[n].size, n++;
				i = Math.max(i, r);
			}
			if (e.maxBitrate = 8 * i, e.startTimestampOffset !== null) for (let t = 0; t < e.samples.length; t++) {
				let n = e.samples[t];
				n.timestamp -= e.startTimestampOffset, n.decodeTimestamp -= e.startTimestampOffset;
			}
		}
		if (q(this.writer), q(this.boxWriter), this.fastStart === "in-memory") {
			this.mdat = Ru(!1);
			let e;
			for (let t = 0; t < 2; t++) {
				let t = Bu(this), n = this.boxWriter.measureBox(t);
				e = this.boxWriter.measureBox(this.mdat);
				let r = this.writer.getPos() + n + e;
				for (let t of this.finalizedChunks) {
					t.offset = r;
					for (let { data: n } of t.samples) q(n), r += n.byteLength, e += n.byteLength;
				}
				if (r < 2 ** 32) break;
				e >= 2 ** 32 && (this.mdat.largeSize = !0);
			}
			this.formatOptions.onMoov && this.writer.startTrackingWrites();
			let t = Bu(this);
			if (this.boxWriter.writeBox(t), this.formatOptions.onMoov) {
				let { data: e, start: t } = this.writer.stopTrackingWrites();
				this.formatOptions.onMoov(e, t);
			}
			this.formatOptions.onMdat && this.writer.startTrackingWrites(), this.mdat.size = e, this.boxWriter.writeBox(this.mdat);
			for (let e of this.finalizedChunks) for (let t of e.samples) q(t.data), this.writer.write(t.data), t.data = null;
			if (this.formatOptions.onMdat) {
				let { data: e, start: t } = this.writer.stopTrackingWrites();
				this.formatOptions.onMdat(e, t);
			}
		} else if (this.isFragmented) {
			if (this.isCmaf) {
				let e = this.segmentHeaderSize === null ? 0 : this.writer.getPos() - this.segmentHeaderSize;
				this.writer.seek(0), this.boxWriter.writeBox(Iu()), this.boxWriter.writeBox(Lu(this, e));
			} else {
				let e = this.writer.getPos(), t = Bd(this.trackDatas);
				this.boxWriter.writeBox(t);
				let n = this.writer.getPos() - e;
				this.writer.seek(this.writer.getPos() - 4), this.boxWriter.writeU32(n);
			}
		} else {
			q(this.mdat);
			let e = this.boxWriter.offsets.get(this.mdat);
			q(e !== void 0);
			let t = this.writer.getPos() - e;
			if (this.mdat.size = t, this.mdat.largeSize = t >= 2 ** 32, this.boxWriter.patchBox(this.mdat), this.formatOptions.onMdat) {
				let { data: e, start: t } = this.writer.stopTrackingWrites();
				this.formatOptions.onMdat(e, t);
			}
			let n = Bu(this);
			if (this.fastStart === "reserve") {
				q(this.ftypSize !== null), this.writer.seek(this.ftypSize), this.formatOptions.onMoov && this.writer.startTrackingWrites(), this.boxWriter.writeBox(n);
				let e = this.boxWriter.offsets.get(this.mdat) - this.writer.getPos();
				this.boxWriter.writeBox(zu(e));
			} else this.formatOptions.onMoov && this.writer.startTrackingWrites(), this.boxWriter.writeBox(n);
			if (this.formatOptions.onMoov) {
				let { data: e, start: t } = this.writer.stopTrackingWrites();
				this.formatOptions.onMoov(e, t);
			}
		}
		e();
	}
}, xf = -(2 ** 15), Sf = 2 ** 15 - 1, Cf = 6, wf = 5, Tf = {
	video: 1,
	audio: 2,
	subtitle: 17
}, Ef = class extends hu {
	constructor(e, t) {
		super(e), this.trackDatas = [], this.allTracksKnown = Lo(), this.segment = null, this.segmentInfo = null, this.seekHead = null, this.tracksElement = null, this.tagsElement = null, this.attachmentsElement = null, this.segmentDuration = null, this.cues = null, this.currentCluster = null, this.currentClusterStartMsTimestamp = null, this.currentClusterMaxMsTimestamp = null, this.trackDatasInCurrentCluster = /* @__PURE__ */ new Map(), this.startTimestamp = Infinity, this.endTimestamp = -Infinity, this.warnedAboutTooNegativeTimestamp = !1, this.format = t;
	}
	async start() {
		let e = await this.mutex.acquire();
		this.writer = await this.output._getRootWriter(!!this.format._options.appendOnly), this.ebmlWriter = new Sl(this.writer), this.writeEBMLHeader(), this.createSegmentInfo(), this.createCues(), await this.writer.flush();
		for (let e of this.output.tracks) e.isVideoTrack() && e.metadata.decoderConfig ? this.getVideoTrackData(e, e.metadata.primingPacket ?? null, { decoderConfig: e.metadata.decoderConfig }) : e.isAudioTrack() && e.metadata.decoderConfig && this.getAudioTrackData(e, e.metadata.primingPacket ?? null, { decoderConfig: e.metadata.decoderConfig });
		e();
	}
	writeEBMLHeader() {
		this.format._options.onEbmlHeader && this.writer.startTrackingWrites();
		let e = {
			id: Y.EBML,
			data: [
				{
					id: Y.EBMLVersion,
					data: 1
				},
				{
					id: Y.EBMLReadVersion,
					data: 1
				},
				{
					id: Y.EBMLMaxIDLength,
					data: 4
				},
				{
					id: Y.EBMLMaxSizeLength,
					data: 8
				},
				{
					id: Y.DocType,
					data: this.format instanceof Gf ? "webm" : "matroska"
				},
				{
					id: Y.DocTypeVersion,
					data: 4
				},
				{
					id: Y.DocTypeReadVersion,
					data: 2
				}
			]
		};
		if (this.ebmlWriter.writeEBML(e), this.format._options.onEbmlHeader) {
			let { data: e, start: t } = this.writer.stopTrackingWrites();
			this.format._options.onEbmlHeader(e, t);
		}
	}
	maybeCreateSeekHead(e) {
		if (this.format._options.appendOnly) return;
		let t = new Uint8Array([
			28,
			83,
			187,
			107
		]), n = new Uint8Array([
			21,
			73,
			169,
			102
		]), r = new Uint8Array([
			22,
			84,
			174,
			107
		]), i = new Uint8Array([
			25,
			65,
			164,
			105
		]), a = new Uint8Array([
			18,
			84,
			195,
			103
		]), o = {
			id: Y.SeekHead,
			data: [
				{
					id: Y.Seek,
					data: [{
						id: Y.SeekID,
						data: n
					}, {
						id: Y.SeekPosition,
						size: 5,
						data: e ? this.ebmlWriter.offsets.get(this.segmentInfo) - this.segmentDataOffset : 0
					}]
				},
				{
					id: Y.Seek,
					data: [{
						id: Y.SeekID,
						data: r
					}, {
						id: Y.SeekPosition,
						size: 5,
						data: e ? this.ebmlWriter.offsets.get(this.tracksElement) - this.segmentDataOffset : 0
					}]
				},
				this.attachmentsElement ? {
					id: Y.Seek,
					data: [{
						id: Y.SeekID,
						data: i
					}, {
						id: Y.SeekPosition,
						size: 5,
						data: e ? this.ebmlWriter.offsets.get(this.attachmentsElement) - this.segmentDataOffset : 0
					}]
				} : null,
				this.tagsElement ? {
					id: Y.Seek,
					data: [{
						id: Y.SeekID,
						data: a
					}, {
						id: Y.SeekPosition,
						size: 5,
						data: e ? this.ebmlWriter.offsets.get(this.tagsElement) - this.segmentDataOffset : 0
					}]
				} : null,
				{
					id: Y.Seek,
					data: [{
						id: Y.SeekID,
						data: t
					}, {
						id: Y.SeekPosition,
						size: 5,
						data: e ? this.ebmlWriter.offsets.get(this.cues) - this.segmentDataOffset : 0
					}]
				}
			]
		};
		this.seekHead = o;
	}
	createSegmentInfo() {
		let e = {
			id: Y.Duration,
			data: new pl(0)
		};
		this.segmentDuration = e;
		let t = {
			id: Y.Info,
			data: [
				{
					id: Y.TimestampScale,
					data: 1e6
				},
				{
					id: Y.MuxingApp,
					data: Ns
				},
				{
					id: Y.WritingApp,
					data: Ns
				},
				this.format._options.appendOnly ? null : e
			]
		};
		this.segmentInfo = t;
	}
	createTracks() {
		let e = {
			id: Y.Tracks,
			data: []
		};
		this.tracksElement = e;
		for (let t of this.trackDatas) {
			let n = Cl[t.track.source._codec];
			q(n), t.type === "audio" && t.track.source._codec === "dts" && (t.info.decoderConfig.codec === "dtse" ? n = "A_DTS/EXPRESS" : t.info.decoderConfig.codec === "dtsl" && (n = "A_DTS/LOSSLESS"));
			let r = 0;
			if (t.type === "audio" && t.track.source._codec === "opus") {
				r = 8e7;
				let e = t.info.decoderConfig.description;
				if (e) {
					let t = dc(wo(e));
					r = Math.round(1e9 * (t.preSkip / Yc));
				}
			}
			e.data.push({
				id: Y.TrackEntry,
				data: [
					{
						id: Y.TrackNumber,
						data: t.track.id
					},
					{
						id: Y.TrackUID,
						data: t.track.id
					},
					{
						id: Y.TrackType,
						data: Tf[t.type]
					},
					t.track.metadata.disposition?.default === !1 ? {
						id: Y.FlagDefault,
						data: 0
					} : null,
					t.track.metadata.disposition?.forced ? {
						id: Y.FlagForced,
						data: 1
					} : null,
					t.track.metadata.disposition?.hearingImpaired ? {
						id: Y.FlagHearingImpaired,
						data: 1
					} : null,
					t.track.metadata.disposition?.visuallyImpaired ? {
						id: Y.FlagVisualImpaired,
						data: 1
					} : null,
					t.track.metadata.disposition?.original ? {
						id: Y.FlagOriginal,
						data: 1
					} : null,
					t.track.metadata.disposition?.commentary ? {
						id: Y.FlagCommentary,
						data: 1
					} : null,
					{
						id: Y.FlagLacing,
						data: 0
					},
					{
						id: Y.Language,
						data: t.track.metadata.languageCode ?? "und"
					},
					{
						id: Y.CodecID,
						data: n
					},
					t.codecPrivate ? {
						id: Y.CodecPrivate,
						data: wo(t.codecPrivate)
					} : null,
					r > 0 ? {
						id: Y.SeekPreRoll,
						data: r
					} : null,
					t.track.metadata.name === void 0 ? null : {
						id: Y.Name,
						data: new hl(t.track.metadata.name)
					},
					t.type === "video" ? this.videoSpecificTrackInfo(t) : null,
					t.type === "audio" ? this.audioSpecificTrackInfo(t) : null,
					t.type === "subtitle" ? this.subtitleSpecificTrackInfo(t) : null
				]
			});
		}
	}
	videoSpecificTrackInfo(e) {
		let { frameRate: t, transformationMatrix: n } = e.track.metadata, r = [t ? {
			id: Y.DefaultDuration,
			data: 1e9 / t
		} : null], i, a, o;
		if (n) {
			i = fo(n);
			let e = _o(mo(-i), n);
			a = Math.sign(e[0]), o = Math.sign(e[4]), o === -1 && (o = 1, a = -a, i = co(i + 180));
		} else i = e.track.metadata.rotation ?? 0, a = e.track.metadata.flip ? -1 : 1, o = 1;
		let s = i ? co(a === -1 ? i : -i) : 0, c = Math.round(Math.acos(a) * so), l = Math.round(Math.acos(o) * so), u = !!e.info.aspectRatio && e.info.aspectRatio.num * e.info.height !== e.info.aspectRatio.den * e.info.width, d = e.info.decoderConfig.colorSpace, f = {
			id: Y.Video,
			data: [
				{
					id: Y.PixelWidth,
					data: e.info.width
				},
				{
					id: Y.PixelHeight,
					data: e.info.height
				},
				u ? {
					id: Y.DisplayWidth,
					data: e.info.aspectRatio.num
				} : null,
				u ? {
					id: Y.DisplayHeight,
					data: e.info.aspectRatio.den
				} : null,
				u ? {
					id: Y.DisplayUnit,
					data: 3
				} : null,
				e.info.alphaMode ? {
					id: Y.AlphaMode,
					data: 1
				} : null,
				jo(d) ? null : {
					id: Y.Colour,
					data: [
						{
							id: Y.MatrixCoefficients,
							data: d?.matrix == null ? 2 : Ao[d.matrix]
						},
						{
							id: Y.TransferCharacteristics,
							data: d?.transfer == null ? 2 : ko[d.transfer]
						},
						{
							id: Y.Primaries,
							data: d?.primaries == null ? 2 : Oo[d.primaries]
						},
						{
							id: Y.Range,
							data: d?.fullRange == null ? 0 : d.fullRange ? 2 : 1
						}
					]
				},
				s || c || l ? {
					id: Y.Projection,
					data: [
						{
							id: Y.ProjectionType,
							data: 0
						},
						c ? {
							id: Y.ProjectionPoseYaw,
							data: new fl(c)
						} : null,
						l ? {
							id: Y.ProjectionPosePitch,
							data: new fl(l)
						} : null,
						s ? {
							id: Y.ProjectionPoseRoll,
							data: new fl((s + 180) % 360 - 180)
						} : null
					]
				} : null
			]
		};
		return r.push(f), r;
	}
	audioSpecificTrackInfo(e) {
		let t = Mc.includes(e.track.source._codec) ? Zc(e.track.source._codec) : null;
		return [{
			id: Y.Audio,
			data: [
				{
					id: Y.SamplingFrequency,
					data: new fl(e.info.sampleRate)
				},
				{
					id: Y.Channels,
					data: e.info.numberOfChannels
				},
				t ? {
					id: Y.BitDepth,
					data: 8 * t.sampleSize
				} : null
			]
		}];
	}
	subtitleSpecificTrackInfo(e) {
		return [];
	}
	maybeCreateTags() {
		let e = [], t = (t, n) => {
			e.push({
				id: Y.SimpleTag,
				data: [{
					id: Y.TagName,
					data: new hl(t)
				}, typeof n == "string" ? {
					id: Y.TagString,
					data: new hl(n)
				} : {
					id: Y.TagBinary,
					data: n
				}]
			});
		}, n = this.output._metadataTags, r = /* @__PURE__ */ new Set();
		for (let { key: e, value: i } of os(n)) switch (e) {
			case "title":
				t("TITLE", i), r.add("TITLE");
				break;
			case "description":
				t("DESCRIPTION", i), r.add("DESCRIPTION");
				break;
			case "artist":
				t("ARTIST", i), r.add("ARTIST");
				break;
			case "album":
				t("ALBUM", i), r.add("ALBUM");
				break;
			case "albumArtist":
				t("ALBUM_ARTIST", i), r.add("ALBUM_ARTIST");
				break;
			case "genre":
				t("GENRE", i), r.add("GENRE");
				break;
			case "beatsPerMinute":
				t("BPM", i.toString()), r.add("BPM");
				break;
			case "comment":
				t("COMMENT", i), r.add("COMMENT");
				break;
			case "lyrics":
				t("LYRICS", i), r.add("LYRICS");
				break;
			case "date":
				t("DATE", i.toISOString().slice(0, 10)), r.add("DATE");
				break;
			case "trackNumber":
				t("PART_NUMBER", n.tracksTotal === void 0 ? i.toString() : `${i}/${n.tracksTotal}`), r.add("PART_NUMBER");
				break;
			case "discNumber":
				t("DISC", n.discsTotal === void 0 ? i.toString() : `${i}/${n.discsTotal}`), r.add("DISC");
				break;
			case "tracksTotal":
			case "discsTotal": break;
			case "images":
			case "raw": break;
			default: Ro(e);
		}
		if (n.raw) for (let e in n.raw) {
			let i = n.raw[e];
			i == null || r.has(e) || (typeof i == "string" || i instanceof Uint8Array) && t(e, i);
		}
		e.length !== 0 && (this.tagsElement = {
			id: Y.Tags,
			data: [{
				id: Y.Tag,
				data: [{
					id: Y.Targets,
					data: [{
						id: Y.TargetTypeValue,
						data: 50
					}, {
						id: Y.TargetType,
						data: "MOVIE"
					}]
				}, ...e]
			}]
		});
	}
	maybeCreateAttachments() {
		let e = this.output._metadataTags, t = [], n = /* @__PURE__ */ new Set(), r = e.images ?? [];
		for (let e of r) {
			let r = e.name;
			r === void 0 && (r = (e.kind === "coverFront" ? "cover" : e.kind === "coverBack" ? "back" : "image") + (ss(e.mimeType) ?? ""));
			let i;
			for (;;) {
				i = 0n;
				for (let e = 0; e < 8; e++) i <<= 8n, i |= BigInt(Math.floor(Math.random() * 256));
				if (i !== 0n && !n.has(i)) break;
			}
			n.add(i), t.push({
				id: Y.AttachedFile,
				data: [
					e.description === void 0 ? null : {
						id: Y.FileDescription,
						data: new hl(e.description)
					},
					{
						id: Y.FileName,
						data: new hl(r)
					},
					{
						id: Y.FileMediaType,
						data: e.mimeType
					},
					{
						id: Y.FileData,
						data: e.data
					},
					{
						id: Y.FileUID,
						data: i
					}
				]
			});
		}
		for (let [n, i] of Object.entries(e.raw ?? {})) i instanceof xs && /^\d+$/.test(n) && (r.find((e) => e.mimeType === i.mimeType && cs(e.data, i.data)) || t.push({
			id: Y.AttachedFile,
			data: [
				i.description === void 0 ? null : {
					id: Y.FileDescription,
					data: new hl(i.description)
				},
				{
					id: Y.FileName,
					data: new hl(i.name ?? "")
				},
				{
					id: Y.FileMediaType,
					data: i.mimeType ?? ""
				},
				{
					id: Y.FileData,
					data: i.data
				},
				{
					id: Y.FileUID,
					data: BigInt(n)
				}
			]
		}));
		t.length !== 0 && (this.attachmentsElement = {
			id: Y.Attachments,
			data: t
		});
	}
	createSegment() {
		this.createTracks(), this.maybeCreateTags(), this.maybeCreateAttachments(), this.maybeCreateSeekHead(!1);
		let e = {
			id: Y.Segment,
			size: this.format._options.appendOnly ? -1 : Cf,
			data: [
				this.seekHead,
				this.segmentInfo,
				this.tracksElement,
				this.attachmentsElement,
				this.tagsElement
			]
		};
		if (this.segment = e, this.format._options.onSegmentHeader && this.writer.startTrackingWrites(), this.ebmlWriter.writeEBML(e), this.format._options.onSegmentHeader) {
			let { data: e, start: t } = this.writer.stopTrackingWrites();
			this.format._options.onSegmentHeader(e, t);
		}
	}
	createCues() {
		this.cues = {
			id: Y.Cues,
			data: []
		};
	}
	get segmentDataOffset() {
		return q(this.segment), this.ebmlWriter.dataOffsets.get(this.segment);
	}
	allTracksAreKnown() {
		for (let e of this.output.tracks) if (!e.source._closed && !this.trackDatas.some((t) => t.track === e)) return !1;
		return !0;
	}
	async getMimeType() {
		await this.allTracksKnown.promise;
		let e = this.trackDatas.map((e) => e.type === "video" || e.type === "audio" ? e.info.decoderConfig.codec : { webvtt: "wvtt" }[e.track.source._codec]);
		return wl({
			isWebM: this.format instanceof Gf,
			hasVideo: this.trackDatas.some((e) => e.type === "video"),
			hasAudio: this.trackDatas.some((e) => e.type === "audio"),
			codecStrings: e
		});
	}
	getVideoTrackData(e, t, n) {
		let r = this.trackDatas.find((t) => t.track === e);
		if (r) return r;
		al(n, e.source._codec), q(n), q(n.decoderConfig), q(n.decoderConfig.codedWidth !== void 0), q(n.decoderConfig.codedHeight !== void 0);
		let i = n.decoderConfig.displayAspectWidth, a = n.decoderConfig.displayAspectHeight, o = i === void 0 || a === void 0 ? null : fs({
			num: i,
			den: a
		}), s = {
			track: e,
			type: "video",
			info: {
				width: n.decoderConfig.codedWidth,
				height: n.decoderConfig.codedHeight,
				aspectRatio: o,
				decoderConfig: n.decoderConfig,
				alphaMode: e.metadata.canBeTransparent || (t ? !!t.sideData.alpha : null)
			},
			chunkQueue: [],
			lastWrittenMsTimestamp: null,
			codecPrivate: n.decoderConfig.description ?? null,
			closed: !1
		};
		return e.source._codec === "vp9" ? s.codecPrivate = new Uint8Array(Kc(s.info.decoderConfig.codec)) : e.source._codec === "av1" ? s.codecPrivate = new Uint8Array(qc(s.info.decoderConfig.codec)) : e.source._codec === "prores" && (s.codecPrivate = Do.encode(n.decoderConfig.codec)), this.trackDatas.push(s), this.trackDatas.sort((e, t) => e.track.id - t.track.id), this.allTracksAreKnown() && this.allTracksKnown.resolve(), s;
	}
	getAudioTrackData(e, t, n) {
		let r = this.trackDatas.find((t) => t.track === e);
		if (r) return r;
		sl(n, e.source._codec), q(n), q(n.decoderConfig);
		let i = { ...n.decoderConfig }, a = !1;
		if (e.source._codec === "aac" && !i.description) {
			if (!t) throw Error("No AAC description provided; you must therefore provide a priming packet.");
			let e = Tl(fu.tempFromBytes(t.data));
			if (!e) throw Error("Couldn't parse ADTS header from the AAC packet. Make sure the packets are in ADTS format (as specified in ISO 13818-7) when not providing a description, or provide a description (must be an AudioSpecificConfig as specified in ISO 14496-3) and ensure the packets are raw AAC data.");
			let n = Ts[e.samplingFrequencyIndex], r = Es[e.channelConfiguration];
			if (n === void 0 || r === void 0) throw Error("Invalid ADTS frame header.");
			i.description = Ds({
				objectType: e.objectType,
				outputSampleRate: n,
				outputNumberOfChannels: r
			}), a = !0;
		}
		let o = {
			track: e,
			type: "audio",
			info: {
				numberOfChannels: n.decoderConfig.numberOfChannels,
				sampleRate: n.decoderConfig.sampleRate,
				decoderConfig: i,
				requiresAdtsStripping: a
			},
			chunkQueue: [],
			lastWrittenMsTimestamp: null,
			codecPrivate: i.description ?? null,
			closed: !1
		};
		return this.trackDatas.push(o), this.trackDatas.sort((e, t) => e.track.id - t.track.id), this.allTracksAreKnown() && this.allTracksKnown.resolve(), o;
	}
	getSubtitleTrackData(e, t) {
		let n = this.trackDatas.find((t) => t.track === e);
		if (n) return n;
		cl(t), q(t), q(t.config);
		let r = {
			track: e,
			type: "subtitle",
			info: { config: t.config },
			chunkQueue: [],
			lastWrittenMsTimestamp: null,
			codecPrivate: Do.encode(t.config.description),
			closed: !1
		};
		return this.trackDatas.push(r), this.trackDatas.sort((e, t) => e.track.id - t.track.id), this.allTracksAreKnown() && this.allTracksKnown.resolve(), r;
	}
	async addEncodedVideoPacket(e, t, n) {
		let r = await this.mutex.acquire();
		try {
			let r = this.getVideoTrackData(e, t, n);
			r.info.alphaMode ??= !!t.sideData.alpha;
			let i = t.data;
			if (e.source._codec === "prores") {
				if (i.byteLength < 8) throw Error("ProRes packet too small, expected at least 8 bytes.");
				i = i.subarray(8);
			}
			let a = t.type === "key";
			this.validateTimestamp(r.track, t.timestamp, a);
			let o = t.timestamp, s = t.duration;
			e.metadata.frameRate !== void 0 && (o = Wo(o, e.metadata.frameRate), s = Wo(s, e.metadata.frameRate));
			let c = r.info.alphaMode ? t.sideData.alpha ?? null : null, l = this.createInternalChunk(i, o, s, t.type, c);
			e.source._codec === "vp9" && this.fixVP9ColorSpace(r, l), r.chunkQueue.push(l), await this.interleaveChunks();
		} finally {
			r();
		}
	}
	async addEncodedAudioPacket(e, t, n) {
		let r = await this.mutex.acquire();
		try {
			let r = this.getAudioTrackData(e, t, n), i = t.data;
			if (r.info.requiresAdtsStripping) {
				let e = Tl(fu.tempFromBytes(i));
				if (!e) throw Error("Expected ADTS frame, didn't get one.");
				let t = e.crcCheck === null ? 7 : 9;
				i = i.subarray(t);
			}
			let a = t.type === "key";
			this.validateTimestamp(r.track, t.timestamp, a);
			let o = this.createInternalChunk(i, t.timestamp, t.duration, t.type);
			r.chunkQueue.push(o), await this.interleaveChunks();
		} finally {
			r();
		}
	}
	async addSubtitleCue(e, t, n) {
		let r = await this.mutex.acquire();
		try {
			let r = this.getSubtitleTrackData(e, n);
			this.validateTimestamp(r.track, t.timestamp, !0);
			let i = t.text, a = Math.round(t.timestamp * 1e3);
			gu.lastIndex = 0, i = i.replace(gu, (e) => `<${yu(vu(e.slice(1, -1)) - a)}>`);
			let o = Do.encode(i), s = `${t.settings ?? ""}\n${t.identifier ?? ""}\n${t.notes ?? ""}`, c = this.createInternalChunk(o, t.timestamp, t.duration, "key", s.trim() ? Do.encode(s) : null);
			r.chunkQueue.push(c), await this.interleaveChunks();
		} finally {
			r();
		}
	}
	async interleaveChunks(e = !1) {
		if (e || this.allTracksAreKnown()) {
			outer: for (;;) {
				let t = null, n = Infinity;
				for (let r of this.trackDatas) {
					if (!e && r.chunkQueue.length === 0 && !r.closed) break outer;
					r.chunkQueue.length > 0 && r.chunkQueue[0].timestamp < n && (t = r, n = r.chunkQueue[0].timestamp);
				}
				if (!t) break;
				let r = t.chunkQueue.shift();
				this.writeBlock(t, r);
			}
			e || await this.writer.flush();
		}
	}
	fixVP9ColorSpace(e, t) {
		if (t.type !== "key" || !e.info.decoderConfig.colorSpace || !e.info.decoderConfig.colorSpace.matrix) return;
		let n = new ws(t.data);
		n.skipBits(2);
		let r = n.readBits(1), i = (n.readBits(1) << 1) + r;
		if (i === 3 && n.skipBits(1), n.readBits(1) || n.readBits(1) !== 0 || (n.skipBits(2), n.readBits(24) !== 4817730)) return;
		i >= 2 && n.skipBits(1);
		let a = {
			rgb: 7,
			bt709: 2,
			bt470bg: 1,
			smpte170m: 3
		}[e.info.decoderConfig.colorSpace.matrix];
		Co(t.data, n.pos, n.pos + 3, a);
	}
	createInternalChunk(e, t, n, r, i = null) {
		return {
			data: e,
			type: r,
			timestamp: t,
			duration: n,
			additions: i
		};
	}
	writeBlock(e, t) {
		this.segment || this.createSegment();
		let n = Math.round(1e3 * t.timestamp), r = this.trackDatas.every((n) => {
			if (e === n) return t.type === "key";
			let r = n.chunkQueue[0];
			return r ? r.type === "key" : n.closed;
		}), i = !1;
		if (!this.currentCluster) i = !0;
		else {
			q(this.currentClusterStartMsTimestamp !== null), q(this.currentClusterMaxMsTimestamp !== null);
			let e = n - this.currentClusterStartMsTimestamp;
			i = r && n > this.currentClusterMaxMsTimestamp && e >= 1e3 * (this.format._options.minimumClusterDuration ?? 1) || e > Sf;
		}
		i && this.createNewCluster(n);
		let a = n - this.currentClusterStartMsTimestamp;
		if (a < xf) {
			if (!this.warnedAboutTooNegativeTimestamp) {
				let e = this.format instanceof Gf ? "WebM" : "Matroska";
				ys._warn(`Packets had to be discarded because their timestamp is too negative to represent in ${e}.`), this.warnedAboutTooNegativeTimestamp = !0;
			}
			return;
		}
		let o = /* @__PURE__ */ new Uint8Array(4), s = new DataView(o.buffer);
		s.setUint8(0, 128 | e.track.id), s.setInt16(1, a, !1);
		let c = Math.round(1e3 * t.duration);
		if (t.additions || e.type === "subtitle") {
			let r = {
				id: Y.BlockGroup,
				data: [
					{
						id: Y.Block,
						data: [o, t.data]
					},
					t.type === "delta" ? {
						id: Y.ReferenceBlock,
						data: new ml(e.lastWrittenMsTimestamp - n)
					} : null,
					t.additions ? {
						id: Y.BlockAdditions,
						data: [{
							id: Y.BlockMore,
							data: [{
								id: Y.BlockAddID,
								data: 1
							}, {
								id: Y.BlockAdditional,
								data: t.additions
							}]
						}]
					} : null,
					c > 0 ? {
						id: Y.BlockDuration,
						data: c
					} : null
				]
			};
			this.ebmlWriter.writeEBML(r);
		} else {
			s.setUint8(3, Number(t.type === "key") << 7);
			let e = {
				id: Y.SimpleBlock,
				data: [o, t.data]
			};
			this.ebmlWriter.writeEBML(e);
		}
		this.startTimestamp = Math.min(this.startTimestamp, n), this.endTimestamp = Math.max(this.endTimestamp, n + c), e.lastWrittenMsTimestamp = n, this.trackDatasInCurrentCluster.has(e) || this.trackDatasInCurrentCluster.set(e, { firstMsTimestamp: n }), this.currentClusterMaxMsTimestamp = Math.max(this.currentClusterMaxMsTimestamp, n);
	}
	createNewCluster(e) {
		e = Math.max(0, e), this.currentCluster && this.finalizeCurrentCluster(), this.format._options.onCluster && this.writer.startTrackingWrites(), this.currentCluster = {
			id: Y.Cluster,
			size: this.format._options.appendOnly ? -1 : wf,
			data: [{
				id: Y.Timestamp,
				data: e
			}]
		}, this.ebmlWriter.writeEBML(this.currentCluster), this.currentClusterStartMsTimestamp = e, this.currentClusterMaxMsTimestamp = e, this.trackDatasInCurrentCluster.clear();
	}
	finalizeCurrentCluster() {
		if (q(this.currentCluster), !this.format._options.appendOnly) {
			let e = this.writer.getPos() - this.ebmlWriter.dataOffsets.get(this.currentCluster), t = this.writer.getPos();
			this.writer.seek(this.ebmlWriter.offsets.get(this.currentCluster) + 4), this.ebmlWriter.writeVarInt(e, wf), this.writer.seek(t);
		}
		if (this.format._options.onCluster) {
			q(this.currentClusterStartMsTimestamp !== null);
			let { data: e, start: t } = this.writer.stopTrackingWrites();
			this.format._options.onCluster(e, t, this.currentClusterStartMsTimestamp / 1e3);
		}
		let e = this.ebmlWriter.offsets.get(this.currentCluster) - this.segmentDataOffset, t = /* @__PURE__ */ new Map();
		for (let [e, { firstMsTimestamp: n }] of this.trackDatasInCurrentCluster) t.has(n) || t.set(n, []), t.get(n).push(e);
		let n = [...t.entries()].sort((e, t) => e[0] - t[0]);
		for (let [t, r] of n) q(this.cues), this.cues.data.push({
			id: Y.CuePoint,
			data: [{
				id: Y.CueTime,
				data: Math.max(0, t)
			}, ...r.map((t) => ({
				id: Y.CueTrackPositions,
				data: [{
					id: Y.CueTrack,
					data: t.track.id
				}, {
					id: Y.CueClusterPosition,
					data: e
				}]
			}))]
		});
	}
	async onTrackClose(e) {
		let t = await this.mutex.acquire(), n = this.trackDatas.find((t) => t.track === e);
		n && (n.closed = !0), this.allTracksAreKnown() && this.allTracksKnown.resolve(), await this.interleaveChunks(), t();
	}
	async finalize() {
		let e = await this.mutex.acquire();
		this.allTracksKnown.resolve();
		for (let e of this.trackDatas) e.closed = !0;
		if (this.segment || this.createSegment(), await this.interleaveChunks(!0), this.currentCluster && this.finalizeCurrentCluster(), q(this.cues), this.ebmlWriter.writeEBML(this.cues), !this.format._options.appendOnly) {
			let e = this.writer.getPos() - this.segmentDataOffset;
			this.writer.seek(this.ebmlWriter.offsets.get(this.segment) + 4), this.ebmlWriter.writeVarInt(e, Cf);
			let t = this.startTimestamp === Infinity ? 0 : this.endTimestamp;
			this.segmentDuration.data = new pl(t), this.writer.seek(this.ebmlWriter.offsets.get(this.segmentDuration)), this.ebmlWriter.writeEBML(this.segmentDuration), q(this.seekHead), this.writer.seek(this.ebmlWriter.offsets.get(this.seekHead)), this.maybeCreateSeekHead(!0), this.ebmlWriter.writeEBML(this.seekHead);
		}
		e();
	}
}, Df = function(e, t, n) {
	if (t != null) {
		if (typeof t != "object" && typeof t != "function") throw TypeError("Object expected.");
		var r, i;
		if (n) {
			if (!Symbol.asyncDispose) throw TypeError("Symbol.asyncDispose is not defined.");
			r = t[Symbol.asyncDispose];
		}
		if (r === void 0) {
			if (!Symbol.dispose) throw TypeError("Symbol.dispose is not defined.");
			r = t[Symbol.dispose], n && (i = r);
		}
		if (typeof r != "function") throw TypeError("Object not disposable.");
		i && (r = function() {
			try {
				i.call(this);
			} catch (e) {
				return Promise.reject(e);
			}
		}), e.stack.push({
			value: t,
			dispose: r,
			async: n
		});
	} else n && e.stack.push({ async: !0 });
	return t;
}, Of = (function(e) {
	return function(t) {
		function n(n) {
			t.error = t.hasError ? new e(n, t.error, "An error was suppressed during disposal.") : n, t.hasError = !0;
		}
		var r, i = 0;
		function a() {
			for (; r = t.stack.pop();) try {
				if (!r.async && i === 1) return i = 0, t.stack.push(r), Promise.resolve().then(a);
				if (r.dispose) {
					var e = r.dispose.call(r.value);
					if (r.async) return i |= 2, Promise.resolve(e).then(a, function(e) {
						return n(e), a();
					});
				} else i |= 1;
			} catch (e) {
				n(e);
			}
			if (i === 1) return t.hasError ? Promise.reject(t.error) : Promise.resolve();
			if (t.hasError) throw t.error;
		}
		return a();
	};
})(typeof SuppressedError == "function" ? SuppressedError : function(e, t, n) {
	var r = Error(n);
	return r.name = "SuppressedError", r.error = e, r.suppressed = t, r;
}), kf = class {
	constructor() {
		this._connectedTrack = null, this._closingPromise = null, this._closed = !1, this._nominalBitrate = null;
	}
	_ensureValidAdd() {
		if (!this._connectedTrack) throw Error("Source is not connected to an output track.");
		if (this._connectedTrack.output.state === "canceled") throw Error("Output has been canceled.");
		if (this._connectedTrack.output.state === "finalizing" || this._connectedTrack.output.state === "finalized") throw Error("Output has been finalized.");
		if (this._connectedTrack.output.state === "pending") throw Error("Output has not started.");
		if (this._closed) throw Error("Source is closed.");
	}
	async _start() {}
	async _flushAndClose(e) {}
	close() {
		if (this._closingPromise) return;
		let e = this._connectedTrack;
		if (!e) throw Error("Cannot call close without connecting the source to an output track.");
		if (e.output.state === "pending") throw Error("Cannot call close before output has been started.");
		this._closingPromise = (async () => {
			await this._flushAndClose(!1), this._closed = !0, e.output.state !== "finalizing" && e.output.state !== "finalized" && e.output._muxer.onTrackClose(e);
		})();
	}
	async _flushOrWaitForOngoingClose(e) {
		return this._closingPromise ??= (async () => {
			await this._flushAndClose(e), this._closed = !0;
		})();
	}
}, Af = class extends kf {
	constructor(e) {
		if (super(), !jc.includes(e)) throw TypeError(`Invalid video codec '${e}'. Must be one of: ${jc.join(", ")}.`);
		this._codec = e;
	}
}, jf = (e, t) => {
	if (e.metadata.hasOnlyKeyPackets && t.type !== "key") throw Error("Cannot add non-key packets to a hasOnlyKeyPackets video track.");
}, Mf = class {
	setError(e) {
		this.errorSet ||= (this.error = e, !0);
	}
	constructor(e, t) {
		this.source = e, this.encodingConfig = t, this.ensureEncoderPromise = null, this.encoderInitialized = !1, this.encoder = null, this.encoderConfig = null, this.encodersReclaimed = !1, this.muxer = null, this.lastMultipleOfKeyFrameInterval = -1, this.emittedEncoderPackets = 0, this.codedWidth = null, this.codedHeight = null, this.outputWidth = null, this.outputHeight = null, this.frameRateLastSample = null, this.frameRateLastTimestamp = null, this.frameRateLastEndTimestamp = null, this.preciseTimings = [], this.customEncoder = null, this.customEncoderCallSerializer = new Zo(), this.customEncoderQueueSize = 0, this.defaultEncodeOptions = {}, this.alphaEncoder = null, this.splitter = null, this.splitterCreationFailed = !1, this.alphaFrameQueue = [], this.error = null, this.errorSet = !1, this.lastMuxerPromise = Promise.resolve(), this.closed = !1;
	}
	async add(e, t, n) {
		let r = e;
		try {
			this.checkForEncoderError(), this.source._ensureValidAdd();
			let i = this.encodingConfig, a = i.sizeChangeBehavior ?? "deny", o = !1;
			if (this.codedWidth !== null && this.codedHeight !== null) {
				if ((e.codedWidth !== this.codedWidth || e.codedHeight !== this.codedHeight) && (o = !0, a === "deny")) throw Error(`Video sample size must remain constant. Expected ${this.codedWidth}x${this.codedHeight}, got ${e.codedWidth}x${e.codedHeight}. To allow the sample size to change over time, set \`sizeChangeBehavior\` to a value other than 'deny' in the encoding options.`);
			} else this.codedWidth = e.codedWidth, this.codedHeight = e.codedHeight;
			if (i.transform?.width !== void 0 || i.transform?.height !== void 0 || i.transform?.rotate !== void 0 || i.transform?.flip !== void 0 || i.transform?.crop !== void 0 || i.transform?.force === !0 || o && a !== "passThrough") {
				let n = i.transform?.width, r = i.transform?.height, s = i.transform?.fit ?? "fill";
				o && a !== "passThrough" && (q(this.outputWidth), q(this.outputHeight), q(a !== "deny"), n = this.outputWidth, r = this.outputHeight, s = a);
				let c = await e.transform({
					width: n,
					height: r,
					roundDimensionsTo: 2,
					crop: i.transform?.crop,
					rotate: i.transform?.rotate,
					flip: i.transform?.flip,
					fit: s,
					alpha: i.alpha
				});
				(this.outputWidth === null || this.outputHeight === null) && (this.outputWidth = c.displayWidth, this.outputHeight = c.displayHeight), t && e.close(), e = c, t = !0;
			} else (this.outputWidth === null || this.outputHeight === null) && (this.outputWidth = e.codedWidth, this.outputHeight = e.codedHeight);
			let s = i.transform?.frameRate;
			if (s !== void 0) {
				let i = e.timestamp + e.duration, a = Go(e.timestamp, s);
				if (this.frameRateLastSample !== null) {
					if (a <= this.frameRateLastTimestamp) {
						this.frameRateLastSample.close(), this.frameRateLastSample = e.clone(), this.frameRateLastEndTimestamp = i;
						return;
					}
					await this.padFrameRate(a, n);
				}
				e === r && (e = e.clone(), t = !0), e.setTimestamp(a), e.setDuration(1 / s), this.frameRateLastSample?.close(), this.frameRateLastSample = e.clone(), this.frameRateLastTimestamp = a, this.frameRateLastEndTimestamp = i;
			}
			await this.processAndEncode(e, n);
		} finally {
			t && e.close();
		}
	}
	async processAndEncode(e, t) {
		let n = this.encodingConfig, r;
		if (n.transform?.process) {
			let t = n.transform.process(e);
			if (as(t) && (t = await t), t === null) return;
			Array.isArray(t) || (t = [t]);
			let i = [];
			try {
				for (let n of t) n instanceof Fl ? i.push(n) : typeof VideoFrame < "u" && n instanceof VideoFrame ? i.push(new Fl(n)) : i.push(new Fl(n, {
					timestamp: e.timestamp,
					duration: e.duration
				}));
			} catch (n) {
				for (let t of i) t !== e && t.close();
				for (let n of t) (n instanceof Fl && n !== e || typeof VideoFrame < "u" && n instanceof VideoFrame) && n.close();
				throw n;
			}
			r = i;
		} else r = [e];
		try {
			for (let e of r) {
				if (this.encoderInitialized || (this.ensureEncoderPromise || this.ensureEncoder(e), this.encoderInitialized || await this.ensureEncoderPromise), q(this.encoderInitialized), this.closed) break;
				this.encodersReclaimed && this.recreateWebCodecsEncoders();
				let n = this.encodingConfig.keyFrameInterval ?? 2, r = Math.floor(e.timestamp / n), i = {
					...this.defaultEncodeOptions,
					...e.encodeOptions,
					...t
				}, a = {
					...i,
					keyFrame: i.keyFrame === void 0 ? n === 0 || r !== this.lastMultipleOfKeyFrameInterval : i.keyFrame
				};
				if (this.lastMultipleOfKeyFrameInterval = r, this.encodingConfig.onEncodedSample?.(e), this.customEncoder) {
					this.customEncoderQueueSize++;
					let t = e.clone(), n = this.customEncoderCallSerializer.call(() => this.customEncoder.encode(t, a)).catch((e) => this.setError(e)).finally(() => {
						this.customEncoderQueueSize--, t.close();
					});
					this.customEncoderQueueSize >= 4 && await n;
				} else {
					q(this.encoder);
					let t = e.toVideoFrame(), n = Io(this.preciseTimings, t.timestamp, (e) => e.microsecondTimestamp), r = n === -1 ? null : this.preciseTimings[n];
					if (r && r.microsecondTimestamp === t.timestamp ? (r.timestamp !== e.timestamp && (r.timestampIsValid = !1), r.duration !== e.duration && (r.durationIsValid = !1)) : (this.preciseTimings.splice(n + 1, 0, {
						microsecondTimestamp: t.timestamp,
						timestamp: e.timestamp,
						duration: e.duration,
						timestampIsValid: !0,
						durationIsValid: !0
					}), this.preciseTimings.length > 128 && this.preciseTimings.shift()), !this.alphaEncoder) try {
						this.encoder.encode(t, a);
					} finally {
						t.close();
					}
					else if (t.format && !t.format.includes("A") || this.splitterCreationFailed) {
						this.alphaFrameQueue.push(null);
						try {
							this.encoder.encode(t, a);
						} finally {
							t.close();
						}
					} else {
						this.splitter ||= new Pf();
						let { colorFrame: e, alphaFrame: n } = await this.splitter.split(t);
						this.alphaFrameQueue.push(n);
						try {
							this.encoder.encode(e, a);
						} finally {
							e.close();
						}
					}
					this.encoder.encodeQueueSize >= 4 && await new Promise((e) => this.encoder.addEventListener("dequeue", e, { once: !0 }));
				}
				await this.lastMuxerPromise;
			}
		} finally {
			for (let t of r) t !== e && t.close();
		}
	}
	async padFrameRate(e, t) {
		let n = this.encodingConfig.transform.frameRate;
		q(this.frameRateLastSample);
		let r = Math.round((e - this.frameRateLastTimestamp) * n);
		for (let e = 1; e < r; e++) {
			let r = {
				stack: [],
				error: void 0,
				hasError: !1
			};
			try {
				let i = Df(r, this.frameRateLastSample.clone(), !1);
				i.setTimestamp(this.frameRateLastTimestamp + e / n), i.setDuration(1 / n), await this.processAndEncode(i, t);
			} catch (e) {
				r.error = e, r.hasError = !0;
			} finally {
				Of(r);
			}
		}
	}
	ensureEncoder(e) {
		this.ensureEncoderPromise = (async () => {
			let t = uu(this.encodingConfig.quality, this.encodingConfig.bitrate);
			q(t !== void 0);
			let n = tu({
				...this.encodingConfig,
				quality: t,
				width: e.codedWidth,
				height: e.codedHeight,
				squarePixelWidth: e.squarePixelWidth,
				squarePixelHeight: e.squarePixelHeight,
				framerate: this.source._connectedTrack?.metadata.frameRate
			}), r = null, i;
			for (let e of n) {
				let t = e.config;
				if (this.encodingConfig.onEncoderConfig?.(t), i = du.find((e) => e.supports(this.encodingConfig.codec, t)), i) {
					r = e;
					break;
				}
				if (typeof VideoEncoder < "u") {
					if (t.alpha = "discard", this.encodingConfig.alpha === "keep" && (t.latencyMode = "quality"), (t.width % 2 == 1 || t.height % 2 == 1) && (this.encodingConfig.codec === "avc" || this.encodingConfig.codec === "hevc")) throw Error(`The dimensions ${t.width}x${t.height} are not supported for codec '${this.encodingConfig.codec}'; both width and height must be even numbers. Make sure to round your dimensions to the nearest even number.`);
					try {
						if ((await VideoEncoder.isConfigSupported(t)).supported) {
							r = e;
							break;
						}
					} catch {}
				}
			}
			if (!r) {
				if (typeof VideoEncoder > "u") throw Error(ns("VideoEncoder"));
				let e = n[0].config, t = n.map(({ config: e, quantizer: t }) => t === null ? `${e.bitrate} bps` : `quantizer ${t}`);
				throw Error(`This specific encoder configuration (${e.codec}, ${t.join(" / ")}, ${e.width}x${e.height}, hardware acceleration: ${e.hardwareAcceleration ?? "no-preference"}) is not supported in this environment. Consider using another codec or changing your video parameters.`);
			}
			let a = r.config;
			r.quantizer === null ? this.source._nominalBitrate = a.bitrate ?? null : this.defaultEncodeOptions = su(this.encodingConfig.codec, r.quantizer), i ? (this.customEncoder = new i(), this.customEncoder.codec = this.encodingConfig.codec, this.customEncoder.config = a, this.customEncoder.onPacket = (e, t) => {
				if (!(e instanceof ul)) throw TypeError("The first argument passed to onPacket must be an EncodedPacket.");
				if (t !== void 0 && (!t || typeof t != "object")) throw TypeError("The second argument passed to onPacket must be an object or undefined.");
				jf(this.source._connectedTrack, e), this.encodingConfig.onEncodedPacket?.(e, t), this.lastMuxerPromise = this.muxer.addEncodedVideoPacket(this.source._connectedTrack, e, t).catch((e) => {
					this.setError(e);
				});
			}, this.customEncoder.onError = (e) => {
				this.setError(e);
			}, await this.customEncoder.init()) : (this.encoderConfig = a, this.createWebCodecsEncoders()), q(this.source._connectedTrack), this.muxer = this.source._connectedTrack.output._muxer, this.encoderInitialized = !0;
		})();
	}
	createWebCodecsEncoders() {
		let e = this.encoderConfig;
		q(e);
		let t = [], n = [], r = 0, i = 0, a = (e, t) => {
			rs(e) ? this.encodersReclaimed = !0 : (e.stack = t, this.setError(e));
		}, o = (/* @__PURE__ */ Error("Encoding error")).stack;
		if (this.encoder = new VideoEncoder({
			output: (e, a) => {
				if (!this.alphaEncoder) {
					this.addPacket(e, null, a);
					return;
				}
				let o = this.alphaFrameQueue.shift();
				q(o !== void 0), o ? (this.alphaEncoder.encode(o, {
					...this.defaultEncodeOptions,
					keyFrame: e.type === "key"
				}), i++, o.close(), t.push({
					chunk: e,
					meta: a
				})) : i === 0 ? this.addPacket(e, null, a) : (n.push(r + i), t.push({
					chunk: e,
					meta: a
				}));
			},
			error: (e) => a(e, o)
		}), this.encoder.configure(e), this.encodingConfig.alpha === "keep") {
			let o = (/* @__PURE__ */ Error("Encoding error")).stack;
			this.alphaEncoder = new VideoEncoder({
				output: (e, a) => {
					i--;
					let o = t.shift();
					for (q(o !== void 0), this.addPacket(o.chunk, e, o.meta), r++; n.length > 0 && n[0] === r;) {
						n.shift();
						let e = t.shift();
						q(e !== void 0), this.addPacket(e.chunk, null, e.meta);
					}
				},
				error: (e) => a(e, o)
			}), this.alphaEncoder.configure(e);
		}
	}
	addPacket(e, t, n) {
		let r = {};
		if (t) {
			let e = new Uint8Array(t.byteLength);
			t.copyTo(e), r.alpha = e;
		}
		let i = ul.fromEncodedChunk(e, r), a = this.encoderConfig;
		q(a), n?.decoderConfig && (n.decoderConfig.codec = Jc({
			width: a.width,
			height: a.height,
			codec: this.encodingConfig.codec,
			codecDescription: n.decoderConfig.description ? wo(n.decoderConfig.description) : null,
			colorSpace: n.decoderConfig.colorSpace ?? null,
			avcType: a.codec.includes("avc1.") ? 1 : a.codec.includes("avc3.") ? 3 : null,
			avcCodecInfo: this.encodingConfig.codec === "avc" && !n.decoderConfig.description ? Hs(i.data) : null,
			hevcCodecInfo: this.encodingConfig.codec === "hevc" && !n.decoderConfig.description ? Xs(i.data) : null,
			vp9CodecInfo: this.encodingConfig.codec === "vp9" ? sc(i.data) : null,
			av1CodecInfo: this.encodingConfig.codec === "av1" ? lc(i.data) : null,
			proresFormat: null
		}));
		let o = Io(this.preciseTimings, e.timestamp, (e) => e.microsecondTimestamp), s = o === -1 ? null : this.preciseTimings[o], c = null;
		this.emittedEncoderPackets === 0 && i.type === "delta" && n?.decoderConfig && (c = fc(this.encodingConfig.codec, n.decoderConfig, i.data)), (s && s.microsecondTimestamp === e.timestamp || c !== null) && (i = i.clone({
			timestamp: s?.timestampIsValid ? s.timestamp : void 0,
			duration: s?.durationIsValid ? s.duration : void 0,
			type: c ?? void 0
		})), jf(this.source._connectedTrack, i), this.encodingConfig.onEncodedPacket?.(i, n), this.lastMuxerPromise = this.muxer.addEncodedVideoPacket(this.source._connectedTrack, i, n).catch((e) => {
			this.setError(e);
		}), this.emittedEncoderPackets++;
	}
	recreateWebCodecsEncoders() {
		q(this.encoder), this.encoder.state !== "closed" && this.encoder.close(), this.alphaEncoder && this.alphaEncoder.state !== "closed" && this.alphaEncoder.close(), this.alphaFrameQueue.forEach((e) => e?.close()), this.alphaFrameQueue.length = 0, this.encodersReclaimed = !1, this.lastMultipleOfKeyFrameInterval = -1, this.createWebCodecsEncoders();
	}
	async flushAndClose(e) {
		try {
			if (!e && (this.checkForEncoderError(), this.frameRateLastSample)) {
				let e = this.encodingConfig.transform.frameRate, t = Go(this.frameRateLastEndTimestamp, e);
				await this.padFrameRate(t);
			}
			this.closed = !0, e || (this.customEncoder ? this.customEncoderCallSerializer.call(() => this.customEncoder.flush()) : this.encoder && !this.encodersReclaimed && (await this.encoder.flush(), await this.alphaEncoder?.flush(), await ms(25)));
		} finally {
			this.closed = !0, this.frameRateLastSample?.close(), this.frameRateLastSample = null, this.customEncoder ? await this.customEncoderCallSerializer.call(() => this.customEncoder.close()).catch((e) => this.setError(e)) : this.encoder && (this.encoder.state !== "closed" && this.encoder.close(), this.alphaEncoder && this.alphaEncoder.state !== "closed" && this.alphaEncoder.close(), this.alphaFrameQueue.forEach((e) => e?.close()), this.alphaFrameQueue.length = 0, this.splitter?.close());
		}
		e || this.checkForEncoderError();
	}
	getQueueSize() {
		return this.customEncoder ? this.customEncoderQueueSize : this.encoder?.encodeQueueSize ?? 0;
	}
	checkForEncoderError() {
		if (this.errorSet) throw this.error;
	}
}, Nf = null, Pf = class {
	constructor() {
		this.worker = null, this.pendingRequests = /* @__PURE__ */ new Map(), this.nextRequestId = 0;
	}
	split(e) {
		if (!this.worker) {
			if (!Nf) {
				let e = new Blob([`(${Ff.toString()})()`], { type: "application/javascript" });
				Nf = URL.createObjectURL(e);
			}
			this.worker = new Worker(Nf), this.worker.addEventListener("message", (e) => {
				let t = e.data, n = this.pendingRequests.get(t.id);
				n && (this.pendingRequests.delete(t.id), "error" in t ? n.reject(Error(t.error)) : n.resolve({
					colorFrame: t.colorFrame,
					alphaFrame: t.alphaFrame
				}));
			}), this.worker.addEventListener("error", (e) => {
				let t = Error(e.message || "Color/alpha splitter worker error.");
				for (let e of this.pendingRequests.values()) e.reject(t);
				this.pendingRequests.clear();
			});
		}
		let t = this.nextRequestId++, n = Lo();
		return this.pendingRequests.set(t, n), this.worker.postMessage({
			id: t,
			sourceFrame: e
		}, { transfer: [e] }), n.promise;
	}
	close() {
		this.worker?.terminate(), this.worker = null;
		let e = /* @__PURE__ */ Error("Color/alpha splitter closed.");
		for (let t of this.pendingRequests.values()) t.reject(e);
		this.pendingRequests.clear();
	}
}, Ff = () => {
	let e = null, t = Promise.resolve();
	self.addEventListener("message", (e) => {
		let { id: r, sourceFrame: i } = e.data;
		t = t.then(async () => {
			try {
				let { colorFrame: e, alphaFrame: t } = await n(i);
				self.postMessage({
					id: r,
					colorFrame: e,
					alphaFrame: t
				}, { transfer: [e, t] });
			} catch (e) {
				self.postMessage({
					id: r,
					error: e.message
				});
			} finally {
				i.close();
			}
		});
	});
	let n = async (t) => {
		let n = t.format;
		if (!n) throw Error("CPU color/alpha splitting requires a known VideoFrame format.");
		let a = t.allocationSize();
		if ((!e || e.byteLength !== a) && (e = new Uint8Array(a)), await t.copyTo(e), n === "RGBA" || n === "BGRA") return r(e, n, t);
		if (n === "I420A" || n === "I420AP10" || n === "I420AP12" || n === "I422A" || n === "I422AP10" || n === "I422AP12" || n === "I444A" || n === "I444AP10" || n === "I444AP12") return i(e, n, t);
		throw Error(`CPU color/alpha splitting does not support format '${n}'.`);
	}, r = (e, t, n) => {
		let r = n.visibleRect?.width ?? n.codedWidth, i = n.visibleRect?.height ?? n.codedHeight, a = r * i, o = a + Math.ceil(r / 2) * Math.ceil(i / 2) * 2, s = new Uint8Array(o);
		for (let t = 0, n = 3; t < a; t++, n += 4) s[t] = e[n];
		s.fill(128, a);
		let c = new VideoFrame(e, {
			format: t === "RGBA" ? "RGBX" : "BGRX",
			codedWidth: r,
			codedHeight: i,
			timestamp: n.timestamp,
			duration: n.duration ?? void 0
		}), l = {
			format: "I420",
			codedWidth: r,
			codedHeight: i,
			timestamp: n.timestamp,
			duration: n.duration ?? void 0,
			colorSpace: {
				fullRange: !0,
				matrix: "bt709",
				primaries: "bt709",
				transfer: "bt709"
			},
			transfer: [s.buffer]
		};
		return {
			colorFrame: c,
			alphaFrame: new VideoFrame(s, l)
		};
	}, i = (e, t, n) => {
		let r = n.visibleRect?.width ?? n.codedWidth, i = n.visibleRect?.height ?? n.codedHeight, a = t.includes("P10"), o = t.includes("P12"), s = a || o ? 2 : 1, c, l;
		t.startsWith("I420") ? (c = Math.ceil(r / 2), l = Math.ceil(i / 2)) : t.startsWith("I422") ? (c = Math.ceil(r / 2), l = i) : (c = r, l = i);
		let u = r * i, d = c * l, f = u * s, p = d * s, m = u * s, h = f + p * 2, g = t.replace("A", ""), _ = Math.ceil(r / 2) * Math.ceil(i / 2), v = m + _ * s * 2, y = new Uint8Array(v), b = h;
		y.set(e.subarray(b, b + m), 0);
		let x = m, S = a ? 512 : o ? 2048 : 128;
		s === 1 ? y.fill(S, x) : new Uint16Array(y.buffer, x, 2 * _).fill(S);
		let C = a ? "I420P10" : o ? "I420P12" : "I420", w = new VideoFrame(e.subarray(0, h), {
			format: g,
			codedWidth: r,
			codedHeight: i,
			timestamp: n.timestamp,
			duration: n.duration ?? void 0
		}), T = {
			format: C,
			codedWidth: r,
			codedHeight: i,
			timestamp: n.timestamp,
			duration: n.duration ?? void 0,
			colorSpace: {
				fullRange: !0,
				matrix: "bt709",
				primaries: "bt709",
				transfer: "bt709"
			},
			transfer: [y.buffer]
		};
		return {
			colorFrame: w,
			alphaFrame: new VideoFrame(y, T)
		};
	};
}, If = class extends Af {
	constructor(e, t) {
		if (!(typeof HTMLCanvasElement < "u" && e instanceof HTMLCanvasElement) && !(typeof OffscreenCanvas < "u" && e instanceof OffscreenCanvas)) throw TypeError("canvas must be an HTMLCanvasElement or OffscreenCanvas.");
		$l(t), super(t.codec), this._encoder = new Mf(this, t), this._canvas = e;
	}
	add(e, t = 0, n) {
		if (!Number.isFinite(e)) throw TypeError("timestamp must be a finite number.");
		if (!Number.isFinite(t) || t < 0) throw TypeError("duration must be a non-negative number.");
		let r = new Fl(this._canvas, {
			timestamp: e,
			duration: t
		});
		return this._encoder.add(r, !0, n);
	}
	_flushAndClose(e) {
		return this._encoder.flushAndClose(e);
	}
}, Lf = class extends kf {
	constructor(e) {
		if (super(), !Pc.includes(e)) throw TypeError(`Invalid audio codec '${e}'. Must be one of: ${Pc.join(", ")}.`);
		this._codec = e;
	}
}, Rf = class extends kf {
	constructor(e) {
		if (super(), !Fc.includes(e)) throw TypeError(`Invalid subtitle codec '${e}'. Must be one of: ${Fc.join(", ")}.`);
		this._codec = e;
	}
}, zf = class {
	get supportsVideoRotationMetadata() {
		return this.supportsVideoTransformationMetadata;
	}
	getSupportedVideoCodecs() {
		return this.getSupportedCodecs().filter((e) => jc.includes(e));
	}
	getSupportedAudioCodecs() {
		return this.getSupportedCodecs().filter((e) => Pc.includes(e));
	}
	getSupportedSubtitleCodecs() {
		return this.getSupportedCodecs().filter((e) => Fc.includes(e));
	}
	_codecUnsupportedHint(e) {
		return "";
	}
	_isFragmentedIsobmff() {
		return !1;
	}
}, Bf = class extends zf {
	constructor(e = {}) {
		if (!e || typeof e != "object") throw TypeError("options must be an object.");
		if (e.fastStart !== void 0 && ![
			!1,
			"in-memory",
			"reserve",
			"fragmented"
		].includes(e.fastStart)) throw TypeError("options.fastStart, when provided, must be false, 'in-memory', 'reserve', or 'fragmented'.");
		if (e.minimumFragmentDuration !== void 0 && (!us(e.minimumFragmentDuration) || e.minimumFragmentDuration < 0)) throw TypeError("options.minimumFragmentDuration, when provided, must be a non-negative number.");
		if (e.onFtyp !== void 0 && typeof e.onFtyp != "function") throw TypeError("options.onFtyp, when provided, must be a function.");
		if (e.onMoov !== void 0 && typeof e.onMoov != "function") throw TypeError("options.onMoov, when provided, must be a function.");
		if (e.onMdat !== void 0 && typeof e.onMdat != "function") throw TypeError("options.onMdat, when provided, must be a function.");
		if (e.onMoof !== void 0 && typeof e.onMoof != "function") throw TypeError("options.onMoof, when provided, must be a function.");
		if (e.metadataFormat !== void 0 && ![
			"mdir",
			"mdta",
			"udta",
			"auto"
		].includes(e.metadataFormat)) throw TypeError("options.metadataFormat, when provided, must be either 'auto', 'mdir', 'mdta', or 'udta'.");
		super(), this._options = e;
	}
	getSupportedTrackCounts() {
		let e = 2 ** 32 - 1;
		return {
			video: {
				min: 0,
				max: e
			},
			audio: {
				min: 0,
				max: e
			},
			subtitle: {
				min: 0,
				max: e
			},
			total: {
				min: 0,
				max: e
			}
		};
	}
	get supportsVideoTransformationMetadata() {
		return !0;
	}
	get supportsTimestampedMediaData() {
		return !0;
	}
	get negativeTimestampSupport() {
		return "full";
	}
	_createMuxer(e) {
		return new bf(e, this);
	}
	_isFragmentedIsobmff() {
		return this._options.fastStart === "fragmented";
	}
}, Vf = class extends Bf {
	constructor(e) {
		super(e);
	}
	get _name() {
		return "MP4";
	}
	get fileExtension() {
		return ".mp4";
	}
	get mimeType() {
		return "video/mp4";
	}
	getSupportedCodecs() {
		return [
			...jc,
			...Nc,
			"pcm-s16",
			"pcm-s16be",
			"pcm-s24",
			"pcm-s24be",
			"pcm-s32",
			"pcm-s32be",
			"pcm-f32",
			"pcm-f32be",
			"pcm-f64",
			"pcm-f64be",
			...Fc
		];
	}
	_codecUnsupportedHint(e) {
		return new Uf().getSupportedCodecs().includes(e) ? " Switching to MOV will grant support for this codec." : "";
	}
}, Hf = class extends Bf {
	constructor(e) {
		super(e);
	}
	get _name() {
		return "CMAF";
	}
	get fileExtension() {
		return ".m4s";
	}
	get mimeType() {
		return "video/mp4";
	}
	getSupportedCodecs() {
		return [
			...jc,
			...Nc,
			"pcm-s16",
			"pcm-s16be",
			"pcm-s24",
			"pcm-s24be",
			"pcm-s32",
			"pcm-s32be",
			"pcm-f32",
			"pcm-f32be",
			"pcm-f64",
			"pcm-f64be",
			...Fc
		];
	}
}, Uf = class extends Bf {
	constructor(e) {
		super(e);
	}
	get _name() {
		return "MOV";
	}
	get fileExtension() {
		return ".mov";
	}
	get mimeType() {
		return "video/quicktime";
	}
	getSupportedCodecs() {
		return [...jc, ...Pc];
	}
	_codecUnsupportedHint(e) {
		return new Vf().getSupportedCodecs().includes(e) ? " Switching to MP4 will grant support for this codec." : "";
	}
}, Wf = class extends zf {
	constructor(e = {}) {
		if (!e || typeof e != "object") throw TypeError("options must be an object.");
		if (e.appendOnly !== void 0 && typeof e.appendOnly != "boolean") throw TypeError("options.appendOnly, when provided, must be a boolean.");
		if (e.minimumClusterDuration !== void 0 && (!us(e.minimumClusterDuration) || e.minimumClusterDuration < 0)) throw TypeError("options.minimumClusterDuration, when provided, must be a non-negative number.");
		if (e.onEbmlHeader !== void 0 && typeof e.onEbmlHeader != "function") throw TypeError("options.onEbmlHeader, when provided, must be a function.");
		if (e.onSegmentHeader !== void 0 && typeof e.onSegmentHeader != "function") throw TypeError("options.onHeader, when provided, must be a function.");
		if (e.onCluster !== void 0 && typeof e.onCluster != "function") throw TypeError("options.onCluster, when provided, must be a function.");
		super(), this._options = e;
	}
	_createMuxer(e) {
		return new Ef(e, this);
	}
	get _name() {
		return "Matroska";
	}
	getSupportedTrackCounts() {
		return {
			video: {
				min: 0,
				max: 127
			},
			audio: {
				min: 0,
				max: 127
			},
			subtitle: {
				min: 0,
				max: 127
			},
			total: {
				min: 0,
				max: 127
			}
		};
	}
	get fileExtension() {
		return ".mkv";
	}
	get mimeType() {
		return "video/x-matroska";
	}
	getSupportedCodecs() {
		return [
			...jc,
			...Nc,
			...Mc.filter((e) => ![
				"pcm-s8",
				"pcm-f32be",
				"pcm-f64be",
				"ulaw",
				"alaw"
			].includes(e)),
			...Fc
		];
	}
	get supportsVideoTransformationMetadata() {
		return !1;
	}
	get supportsTimestampedMediaData() {
		return !0;
	}
	get negativeTimestampSupport() {
		return "prefer-non-negative";
	}
}, Gf = class extends Wf {
	constructor(e) {
		super(e);
	}
	getSupportedCodecs() {
		return [
			...jc.filter((e) => [
				"vp8",
				"vp9",
				"av1"
			].includes(e)),
			...Pc.filter((e) => ["opus", "vorbis"].includes(e)),
			...Fc
		];
	}
	get _name() {
		return "WebM";
	}
	get fileExtension() {
		return ".webm";
	}
	get mimeType() {
		return "video/webm";
	}
	_codecUnsupportedHint(e) {
		return new Wf().getSupportedCodecs().includes(e) ? " Switching to MKV will grant support for this codec." : "";
	}
}, Kf = [
	"video",
	"audio",
	"subtitle"
], qf = class e {
	constructor(e, t, n, r, i) {
		this.id = e, this.output = t, this.type = n, this.source = r, this.metadata = i;
	}
	isVideoTrack() {
		return this.type === "video";
	}
	isAudioTrack() {
		return this.type === "audio";
	}
	isSubtitleTrack() {
		return this.type === "subtitle";
	}
	canBePairedWith(t) {
		if (!(t instanceof e)) throw TypeError("other must be an OutputTrack.");
		if (this === t) return !1;
		let n = hs(this.metadata.group), r = hs(t.metadata.group);
		for (let e of n) if (this.type !== t.type && r.some((t) => e === t) || r.some((t) => e._pairedGroups.has(t))) return !0;
		return !1;
	}
}, Jf = class extends qf {
	constructor(e, t, n, r) {
		super(e, t, "video", n, r);
	}
}, Yf = class extends qf {
	constructor(e, t, n, r) {
		super(e, t, "audio", n, r);
	}
}, Xf = class extends qf {
	constructor(e, t, n, r) {
		super(e, t, "subtitle", n, r);
	}
}, Zf = class e {
	constructor() {
		this._pairedGroups = /* @__PURE__ */ new Set();
	}
	pairWith(t) {
		if (!(t instanceof e)) throw TypeError("other must be an OutputTrackGroup.");
		if (this === t) throw TypeError("Cannot pair a group with itself.");
		this._pairedGroups.add(t), t._pairedGroups.add(this);
	}
}, Qf = (e) => {
	if (!e || typeof e != "object") throw TypeError("metadata must be an object.");
	if (e.languageCode !== void 0 && !Jo(e.languageCode)) throw TypeError("metadata.languageCode, when provided, must be a three-letter, ISO 639-2/T language code.");
	if (e.name !== void 0 && typeof e.name != "string") throw TypeError("metadata.name, when provided, must be a string.");
	if (e.disposition !== void 0 && Cs(e.disposition), e.maximumPacketCount !== void 0 && (!Number.isInteger(e.maximumPacketCount) || e.maximumPacketCount < 0)) throw TypeError("metadata.maximumPacketCount, when provided, must be a non-negative integer.");
	if (e.bitrate !== void 0 && (!Number.isFinite(e.bitrate) || e.bitrate < 0)) throw TypeError("metadata.bitrate, when provided, must be a non-negative number.");
	if (e.averageBitrate !== void 0 && (!Number.isFinite(e.averageBitrate) || e.averageBitrate < 0)) throw TypeError("metadata.averageBitrate, when provided, must be a non-negative number.");
	if (e.group !== void 0 && !(e.group instanceof Zf) && (!Array.isArray(e.group) || e.group.some((e) => !(e instanceof Zf)))) throw TypeError("metadata.group, when provided, must be an OutputTrackGroup instance or an array of OutputTrackGroup instances.");
}, $f = class extends gs {
	get target() {
		let e = "Output.target cannot be used when using PathedTarget with an async callback. Use the 'target' event instead.";
		if (this._rootTargetPromise) throw TypeError(e);
		let t = this._getRootTarget();
		if (as(t)) throw TypeError(e);
		return t;
	}
	constructor(e) {
		if (super(), this.state = "pending", this.defaultTrackGroup = new Zf(), this.tracks = [], this._onFinalize = null, this._unfinalizedTargets = /* @__PURE__ */ new Set(), this._rootWriterPromise = null, this._startPromise = null, this._cancelPromise = null, this._finalizePromise = null, this._mutex = new No(), this._metadataTags = {}, this._rootTarget = null, this._rootTargetPromise = null, this._firstMediaStreamTimestamp = null, !e || typeof e != "object") throw TypeError("options must be an object.");
		if (!(e.format instanceof zf)) throw TypeError("options.format must be an OutputFormat.");
		if (!(e.target instanceof lf || e.target instanceof mf)) throw TypeError("options.target must be a Target or a PathedTarget.");
		if (e.target instanceof lf && this._rememberTarget(e.target), e.initTarget !== void 0 && !(e.initTarget instanceof lf) && typeof e.initTarget != "function") throw Error("options.initTarget, when provided, must be a Target or a function that returns or resolves to a Target.");
		if (e.onFinalize !== void 0 && typeof e.onFinalize != "function") throw TypeError("options.onFinalize, when provided, must be a function.");
		this.format = e.format, this._target = e.target, this._onFinalize = e.onFinalize ?? null, this._initTarget = e.initTarget ?? null, this._initTarget instanceof lf && this._rememberTarget(this._initTarget), this._muxer = e.format._createMuxer(this);
	}
	_getTargetValidated(e) {
		q(this._target instanceof mf);
		let t = this._target.getTarget(e), n = (e) => {
			if (!(e instanceof lf)) throw TypeError("getTarget must return a Target.");
			return e;
		};
		return as(t) ? t.then(n) : n(t);
	}
	async _getTarget(e) {
		q(this._target instanceof mf);
		let t = await this._getTargetValidated(e);
		return this._emit("target", {
			target: t,
			request: e,
			isRoot: e.isRoot
		}), this.state === "canceled" ? await t._close() : this._rememberTarget(t), t;
	}
	_rememberTarget(e) {
		this._unfinalizedTargets.add(e), e.on("finalized", () => this._unfinalizedTargets.delete(e), { once: !0 });
	}
	async _getInitTarget() {
		if (q(this._initTarget !== null), this._initTarget instanceof lf) return this._initTarget;
		let e = await this._initTarget();
		return this.state === "canceled" ? await e._close() : this._rememberTarget(e), e;
	}
	_hasInitTarget() {
		return this._initTarget !== null;
	}
	_getRootTarget() {
		if (this._rootTarget) return this._rootTarget;
		if (this._rootTargetPromise) return this._rootTargetPromise;
		if (this._target instanceof lf) return this._emit("target", {
			target: this._target,
			request: null,
			isRoot: !0
		}), this._rootTarget = this._target, this._target;
		let e = {
			path: this._target.rootPath,
			isRoot: !0,
			mimeType: this.format.mimeType
		}, t = this._getTargetValidated(e), n = (t) => (this.state === "canceled" ? t._close() : this._rememberTarget(t), this._emit("target", {
			target: t,
			request: e,
			isRoot: !0
		}), this._rootTarget = t, t);
		return as(t) ? this._rootTargetPromise = t.then(n) : n(t);
	}
	_getRootWriter(e) {
		return this._rootWriterPromise ??= (async () => {
			let t = await this._getRootTarget(), n = new cf(t, typeof e == "boolean" ? e : e(t));
			return n.start(), n;
		})();
	}
	addVideoTrack(e, t = {}) {
		if (!(e instanceof Af)) throw TypeError("source must be a VideoSource.");
		if (Qf(t), t.rotation !== void 0 && ![
			0,
			90,
			180,
			270
		].includes(t.rotation)) throw TypeError(`Invalid video rotation: ${t.rotation}. Has to be 0, 90, 180 or 270.`);
		if (t.flip !== void 0 && typeof t.flip != "boolean") throw TypeError("metadata.flip, when provided, must be a boolean.");
		if (t.transformationMatrix !== void 0 && (!Array.isArray(t.transformationMatrix) || t.transformationMatrix.length !== 9 || !t.transformationMatrix.every((e) => Number.isFinite(e)))) throw TypeError("metadata.transformationMatrix, when provided, must be an array of 9 finite numbers.");
		if (t.frameRate !== void 0 && (!Number.isFinite(t.frameRate) || t.frameRate <= 0)) throw TypeError(`Invalid video frame rate: ${t.frameRate}. Must be a positive number.`);
		if (t.hasOnlyKeyPackets !== void 0 && typeof t.hasOnlyKeyPackets != "boolean") throw TypeError("metadata.hasOnlyKeyPackets, when provided, must be a boolean.");
		if (t.canBeTransparent !== void 0 && typeof t.canBeTransparent != "boolean") throw TypeError("metadata.canBeTransparent, when provided, must be a boolean.");
		if (t.decoderConfig !== void 0 && al({ decoderConfig: t.decoderConfig }, e._codec), t.primingPacket !== void 0) {
			if (!(t.primingPacket instanceof ul)) throw TypeError("metadata.primingPacket, when provided, must be an EncodedPacket.");
			if (t.decoderConfig === void 0) throw TypeError("metadata.primingPacket can only be provided alongside metadata.decoderConfig.");
		}
		let n = { ...t };
		return n.group ??= this.defaultTrackGroup, this._addTrack(new Jf(this.tracks.length + 1, this, e, n));
	}
	addAudioTrack(e, t = {}) {
		if (!(e instanceof Lf)) throw TypeError("source must be an AudioSource.");
		if (Qf(t), t.decoderConfig !== void 0 && sl({ decoderConfig: t.decoderConfig }, e._codec), t.primingPacket !== void 0) {
			if (!(t.primingPacket instanceof ul)) throw TypeError("metadata.primingPacket, when provided, must be an EncodedPacket.");
			if (t.decoderConfig === void 0) throw TypeError("metadata.primingPacket can only be provided alongside metadata.decoderConfig.");
		}
		let n = { ...t };
		return n.group ??= this.defaultTrackGroup, this._addTrack(new Yf(this.tracks.length + 1, this, e, n));
	}
	addSubtitleTrack(e, t = {}) {
		if (!(e instanceof Rf)) throw TypeError("source must be a SubtitleSource.");
		Qf(t);
		let n = { ...t };
		return n.group ??= this.defaultTrackGroup, this._addTrack(new Xf(this.tracks.length + 1, this, e, n));
	}
	setMetadataTags(e) {
		if (Ss(e), this.state !== "pending") throw Error("Cannot set metadata tags after output has been started or canceled.");
		this._metadataTags = e;
	}
	_addTrack(e) {
		if (this.state !== "pending") throw Error("Cannot add track after output has been started or canceled.");
		if (e.source._connectedTrack) throw Error("Source is already used for a track.");
		let t = this.format.getSupportedTrackCounts(), n = this.tracks.reduce((t, n) => t + +(n.type === e.type), 0), r = t[e.type].max;
		if (n === r) throw Error(r === 0 ? `${this.format._name} does not support ${e.type} tracks.` : `${this.format._name} does not support more than ${r} ${e.type} track${r === 1 ? "" : "s"}.`);
		let i = t.total.max;
		if (this.tracks.length === i) throw Error(`${this.format._name} does not support more than ${i} tracks${i === 1 ? "" : "s"} in total.`);
		if (e.isVideoTrack()) {
			let t = this.format.getSupportedVideoCodecs();
			if (t.length === 0) throw Error(`${this.format._name} does not support video tracks.` + this.format._codecUnsupportedHint(e.source._codec));
			if (!t.includes(e.source._codec)) throw Error(`Codec '${e.source._codec}' cannot be contained within ${this.format._name}. Supported video codecs are: ${t.map((e) => `'${e}'`).join(", ")}.` + this.format._codecUnsupportedHint(e.source._codec));
		} else if (e.isAudioTrack()) {
			let t = this.format.getSupportedAudioCodecs();
			if (t.length === 0) throw Error(`${this.format._name} does not support audio tracks.` + this.format._codecUnsupportedHint(e.source._codec));
			if (!t.includes(e.source._codec)) throw Error(`Codec '${e.source._codec}' cannot be contained within ${this.format._name}. Supported audio codecs are: ${t.map((e) => `'${e}'`).join(", ")}.` + this.format._codecUnsupportedHint(e.source._codec));
		} else if (e.isSubtitleTrack()) {
			let t = this.format.getSupportedSubtitleCodecs();
			if (t.length === 0) throw Error(`${this.format._name} does not support subtitle tracks.` + this.format._codecUnsupportedHint(e.source._codec));
			if (!t.includes(e.source._codec)) throw Error(`Codec '${e.source._codec}' cannot be contained within ${this.format._name}. Supported subtitle codecs are: ${t.map((e) => `'${e}'`).join(", ")}.` + this.format._codecUnsupportedHint(e.source._codec));
		}
		return this.tracks.push(e), e.source._connectedTrack = e, e;
	}
	hasEnoughTracks() {
		let e = this.format.getSupportedTrackCounts();
		for (let t of Kf) if (this.tracks.reduce((e, n) => e + +(n.type === t), 0) < e[t].min) return !1;
		let t = e.total.min;
		return !(this.tracks.length < t);
	}
	async start() {
		let e = this.format.getSupportedTrackCounts();
		for (let t of Kf) {
			let n = this.tracks.reduce((e, n) => e + +(n.type === t), 0), r = e[t].min;
			if (n < r) throw Error(r === e[t].max ? `${this.format._name} requires exactly ${r} ${t} track${r === 1 ? "" : "s"}.` : `${this.format._name} requires at least ${r} ${t} track${r === 1 ? "" : "s"}.`);
		}
		let t = e.total.min;
		if (this.tracks.length < t) throw Error(t === e.total.max ? `${this.format._name} requires exactly ${t} track${t === 1 ? "" : "s"}.` : `${this.format._name} requires at least ${t} track${t === 1 ? "" : "s"}.`);
		if (this.state === "canceled") throw Error("Output has been canceled.");
		return this._startPromise ? (ys._warn("Output has already been started."), this._startPromise) : this._startPromise = (async () => {
			this.state = "started";
			let e = this._mutex.acquire();
			try {
				await this._muxer.start();
				let e = this.tracks.map((e) => e.source._start());
				await Promise.all(e);
			} finally {
				(await e)();
			}
		})();
	}
	getMimeType() {
		return this._muxer.getMimeType();
	}
	async cancel() {
		if (this.state === "canceled") return this._cancelPromise ?? void 0;
		if (this.state === "finalizing" || this.state === "finalized") this.state === "finalized" && ys._warn("Output has already been finalized.");
		else return this._cancelPromise = (async () => {
			this.state = "canceled";
			let e = await this._mutex.acquire();
			try {
				let e = this.tracks.map((e) => e.source._flushOrWaitForOngoingClose(!0));
				await Promise.all(e), await Promise.all([...this._unfinalizedTargets].map((e) => e._close())), this._unfinalizedTargets.clear();
			} finally {
				e();
			}
		})();
	}
	async finalize() {
		if (this.state === "pending") throw Error("Cannot finalize before starting.");
		if (this.state === "canceled") throw Error("Cannot finalize after canceling.");
		return this._finalizePromise ? (ys._warn("Output has already been finalized."), this._finalizePromise) : this._finalizePromise = (async () => {
			this.state = "finalizing";
			let e = await this._mutex.acquire();
			try {
				let e = this.tracks.map((e) => e.source._flushOrWaitForOngoingClose(!1));
				if (await Promise.all(e), await this._muxer.finalize(), this._rootWriterPromise) {
					let e = await this._rootWriterPromise;
					e.finalized || (await e.flush(), await e.finalize());
				}
				this._onFinalize && await this._onFinalize(), this.state = "finalized";
			} catch (e) {
				throw this.state = "canceled", e;
			} finally {
				await Promise.all([...this._unfinalizedTargets].map((e) => e._close().catch(() => {}))), this._unfinalizedTargets.clear(), e();
			}
		})();
	}
}, ep = new oe(), tp = new L(), np = new L(), rp = new h(), ip = {
	X: new L(1, 0, 0),
	Y: new L(0, 1, 0),
	Z: new L(0, 0, 1)
}, ap = { type: "change" }, op = {
	type: "mouseDown",
	mode: null
}, sp = {
	type: "mouseUp",
	mode: null
}, cp = { type: "objectChange" }, lp = class extends Ke {
	constructor(e, t = null) {
		super(void 0, t);
		let n = new Ap(this);
		this._root = n;
		let r = new jp();
		this._gizmo = r, n.add(r);
		let i = new Mp();
		this._plane = i, n.add(i);
		let a = this;
		function o(e, t) {
			let n = t;
			Object.defineProperty(a, e, {
				get: function() {
					return n === void 0 ? t : n;
				},
				set: function(t) {
					n !== t && (n = t, i[e] = t, r[e] = t, a.dispatchEvent({
						type: e + "-changed",
						value: t
					}), a.dispatchEvent(ap));
				}
			}), a[e] = t, i[e] = t, r[e] = t;
		}
		o("camera", e), o("object", void 0), o("enabled", !0), o("axis", null), o("mode", "translate"), o("translationSnap", null), o("rotationSnap", null), o("scaleSnap", null), o("space", "world"), o("size", 1), this.viewport = null, o("dragging", !1), o("showX", !0), o("showY", !0), o("showZ", !0), o("showXY", !0), o("showYZ", !0), o("showXZ", !0), o("showXYZE", !0), o("showE", !0), o("minX", -Infinity), o("maxX", Infinity), o("minY", -Infinity), o("maxY", Infinity), o("minZ", -Infinity), o("maxZ", Infinity);
		let s = new L(), c = new L(), l = new h(), u = new h(), d = new L(), f = new h(), p = new L(), m = new L(), g = new L(), _ = new L();
		o("worldPosition", s), o("worldPositionStart", c), o("worldQuaternion", l), o("worldQuaternionStart", u), o("cameraPosition", d), o("cameraQuaternion", f), o("pointStart", p), o("pointEnd", m), o("rotationAxis", g), o("rotationAngle", 0), o("eye", _), this._offset = new L(), this._startNorm = new L(), this._endNorm = new L(), this._cameraScale = new L(), this._parentPosition = new L(), this._parentQuaternion = new h(), this._parentQuaternionInv = new h(), this._parentScale = new L(), this._worldScaleStart = new L(), this._worldQuaternionInv = new h(), this._worldScale = new L(), this._positionStart = new L(), this._quaternionStart = new h(), this._scaleStart = new L(), this._getPointer = up.bind(this), this._onPointerDown = fp.bind(this), this._onPointerHover = dp.bind(this), this._onPointerMove = pp.bind(this), this._onPointerUp = mp.bind(this), t !== null && this.connect(t);
	}
	connect(e) {
		super.connect(e), this.domElement.addEventListener("pointerdown", this._onPointerDown), this.domElement.addEventListener("pointermove", this._onPointerHover), this.domElement.addEventListener("pointerup", this._onPointerUp), this.domElement.style.touchAction = "none";
	}
	disconnect() {
		this.domElement.removeEventListener("pointerdown", this._onPointerDown), this.domElement.removeEventListener("pointermove", this._onPointerHover), this.domElement.removeEventListener("pointermove", this._onPointerMove), this.domElement.removeEventListener("pointerup", this._onPointerUp), this.domElement.style.touchAction = "";
	}
	getHelper() {
		return this._root;
	}
	pointerHover(e) {
		if (this.object === void 0 || this.dragging === !0) return;
		e !== null && ep.setFromCamera(e, this.camera);
		let t = hp(this._gizmo.picker[this.mode], ep);
		this.axis = t ? t.object.name : null;
	}
	pointerDown(e) {
		if (!(this.object === void 0 || this.dragging === !0 || e != null && e.button !== 0) && this.axis !== null) {
			e !== null && ep.setFromCamera(e, this.camera);
			let t = hp(this._plane, ep, !0);
			t && (this.object.updateMatrixWorld(), this.object.parent.updateMatrixWorld(), this._positionStart.copy(this.object.position), this._quaternionStart.copy(this.object.quaternion), this._scaleStart.copy(this.object.scale), this.object.matrixWorld.decompose(this.worldPositionStart, this.worldQuaternionStart, this._worldScaleStart), this.pointStart.copy(t.point).sub(this.worldPositionStart)), this.dragging = !0, op.mode = this.mode, this.dispatchEvent(op);
		}
	}
	pointerMove(e) {
		let t = this.axis, n = this.mode, r = this.object, i = this.space;
		if (n === "scale" ? i = "local" : (t === "E" || t === "XYZE" || t === "XYZ") && (i = "world"), r === void 0 || t === null || this.dragging === !1 || e !== null && e.button !== -1) return;
		e !== null && ep.setFromCamera(e, this.camera);
		let a = hp(this._plane, ep, !0);
		if (a) {
			if (this.pointEnd.copy(a.point).sub(this.worldPositionStart), n === "translate") this._offset.copy(this.pointEnd).sub(this.pointStart), i === "local" && t !== "XYZ" && this._offset.applyQuaternion(this._worldQuaternionInv), t.indexOf("X") === -1 && (this._offset.x = 0), t.indexOf("Y") === -1 && (this._offset.y = 0), t.indexOf("Z") === -1 && (this._offset.z = 0), i === "local" && t !== "XYZ" ? this._offset.applyQuaternion(this._quaternionStart).divide(this._parentScale) : this._offset.applyQuaternion(this._parentQuaternionInv).divide(this._parentScale), r.position.copy(this._offset).add(this._positionStart), this.translationSnap && (i === "local" && (r.position.applyQuaternion(rp.copy(this._quaternionStart).invert()), t.search("X") !== -1 && (r.position.x = Math.round(r.position.x / this.translationSnap) * this.translationSnap), t.search("Y") !== -1 && (r.position.y = Math.round(r.position.y / this.translationSnap) * this.translationSnap), t.search("Z") !== -1 && (r.position.z = Math.round(r.position.z / this.translationSnap) * this.translationSnap), r.position.applyQuaternion(this._quaternionStart)), i === "world" && (r.getWorldPosition(tp), t.search("X") !== -1 && (tp.x = Math.round(tp.x / this.translationSnap) * this.translationSnap), t.search("Y") !== -1 && (tp.y = Math.round(tp.y / this.translationSnap) * this.translationSnap), t.search("Z") !== -1 && (tp.z = Math.round(tp.z / this.translationSnap) * this.translationSnap), r.position.copy(r.parent.worldToLocal(tp)))), r.position.x = Math.max(this.minX, Math.min(this.maxX, r.position.x)), r.position.y = Math.max(this.minY, Math.min(this.maxY, r.position.y)), r.position.z = Math.max(this.minZ, Math.min(this.maxZ, r.position.z));
			else if (n === "scale") {
				if (t.search("XYZ") !== -1) {
					let e = this.pointEnd.length() / this.pointStart.length();
					this.pointEnd.dot(this.pointStart) < 0 && (e *= -1), np.set(e, e, e);
				} else tp.copy(this.pointStart), np.copy(this.pointEnd), tp.applyQuaternion(this._worldQuaternionInv), np.applyQuaternion(this._worldQuaternionInv), np.divide(tp), t.search("X") === -1 && (np.x = 1), t.search("Y") === -1 && (np.y = 1), t.search("Z") === -1 && (np.z = 1);
				r.scale.copy(this._scaleStart).multiply(np), this.scaleSnap && (t.search("X") !== -1 && (r.scale.x = Math.round(r.scale.x / this.scaleSnap) * this.scaleSnap || this.scaleSnap), t.search("Y") !== -1 && (r.scale.y = Math.round(r.scale.y / this.scaleSnap) * this.scaleSnap || this.scaleSnap), t.search("Z") !== -1 && (r.scale.z = Math.round(r.scale.z / this.scaleSnap) * this.scaleSnap || this.scaleSnap));
			} else if (n === "rotate") {
				this._offset.copy(this.pointEnd).sub(this.pointStart);
				let e = 20 / this.worldPosition.distanceTo(tp.setFromMatrixPosition(this.camera.matrixWorld)), n = !1;
				t === "XYZE" ? (this.rotationAxis.copy(this._offset).cross(this.eye).normalize(), this.rotationAngle = this._offset.dot(tp.copy(this.rotationAxis).cross(this.eye)) * e) : (t === "X" || t === "Y" || t === "Z") && (this.rotationAxis.copy(ip[t]), tp.copy(ip[t]), i === "local" && tp.applyQuaternion(this.worldQuaternion), tp.cross(this.eye), tp.length() === 0 ? n = !0 : this.rotationAngle = this._offset.dot(tp.normalize()) * e), (t === "E" || n) && (this.rotationAxis.copy(this.eye), this.rotationAngle = this.pointEnd.angleTo(this.pointStart), this._startNorm.copy(this.pointStart).normalize(), this._endNorm.copy(this.pointEnd).normalize(), this.rotationAngle *= this._endNorm.cross(this._startNorm).dot(this.eye) < 0 ? 1 : -1), this.rotationSnap && (this.rotationAngle = Math.round(this.rotationAngle / this.rotationSnap) * this.rotationSnap), i === "local" && t !== "E" && t !== "XYZE" ? (r.quaternion.copy(this._quaternionStart), r.quaternion.multiply(rp.setFromAxisAngle(this.rotationAxis, this.rotationAngle)).normalize()) : (this.rotationAxis.applyQuaternion(this._parentQuaternionInv), r.quaternion.copy(rp.setFromAxisAngle(this.rotationAxis, this.rotationAngle)), r.quaternion.multiply(this._quaternionStart).normalize());
			}
			this.dispatchEvent(ap), this.dispatchEvent(cp);
		}
	}
	pointerUp(e) {
		(e === null || e.button === 0) && (this.dragging && this.axis !== null && (sp.mode = this.mode, this.dispatchEvent(sp)), this.dragging = !1, this.axis = null);
	}
	dispose() {
		this.disconnect(), this._root.dispose();
	}
	attach(e) {
		return this.object = e, this._root.visible = !0, this;
	}
	detach() {
		return this.object = void 0, this.axis = null, this._root.visible = !1, this;
	}
	reset() {
		this.enabled && this.dragging && (this.object.position.copy(this._positionStart), this.object.quaternion.copy(this._quaternionStart), this.object.scale.copy(this._scaleStart), this.dispatchEvent(ap), this.dispatchEvent(cp), this.pointStart.copy(this.pointEnd));
	}
	getRaycaster() {
		return ep;
	}
	getMode() {
		return this.mode;
	}
	setMode(e) {
		this.mode = e;
	}
	setTranslationSnap(e) {
		this.translationSnap = e;
	}
	setRotationSnap(e) {
		this.rotationSnap = e;
	}
	setScaleSnap(e) {
		this.scaleSnap = e;
	}
	setSize(e) {
		this.size = e;
	}
	setSpace(e) {
		this.space = e;
	}
	setColors(e, t, n, r) {
		let i = this._gizmo.materialLib;
		i.xAxis.color.set(e), i.yAxis.color.set(t), i.zAxis.color.set(n), i.active.color.set(r), i.xAxisTransparent.color.set(e), i.yAxisTransparent.color.set(t), i.zAxisTransparent.color.set(n), i.activeTransparent.color.set(r), i.xAxis._color && i.xAxis._color.set(e), i.yAxis._color && i.yAxis._color.set(t), i.zAxis._color && i.zAxis._color.set(n), i.active._color && i.active._color.set(r), i.xAxisTransparent._color && i.xAxisTransparent._color.set(e), i.yAxisTransparent._color && i.yAxisTransparent._color.set(t), i.zAxisTransparent._color && i.zAxisTransparent._color.set(n), i.activeTransparent._color && i.activeTransparent._color.set(r);
	}
};
function up(e) {
	if (this.domElement.ownerDocument.pointerLockElement) return {
		x: 0,
		y: 0,
		button: e.button
	};
	{
		let t = this.domElement.getBoundingClientRect(), n = this.viewport, r, i, a, o;
		return n === null ? (r = 0, i = 0, a = t.width, o = t.height) : (r = n.x, i = t.height - n.y - n.w, a = n.z, o = n.w), {
			x: (e.clientX - t.left - r) / a * 2 - 1,
			y: -(e.clientY - t.top - i) / o * 2 + 1,
			button: e.button
		};
	}
}
function dp(e) {
	if (this.enabled) switch (e.pointerType) {
		case "mouse":
		case "pen": this.pointerHover(this._getPointer(e));
	}
}
function fp(e) {
	this.enabled && (document.pointerLockElement || this.domElement.setPointerCapture(e.pointerId), this.domElement.addEventListener("pointermove", this._onPointerMove), this.pointerHover(this._getPointer(e)), this.pointerDown(this._getPointer(e)));
}
function pp(e) {
	this.enabled && this.pointerMove(this._getPointer(e));
}
function mp(e) {
	this.enabled && (this.domElement.releasePointerCapture(e.pointerId), this.domElement.removeEventListener("pointermove", this._onPointerMove), this.pointerUp(this._getPointer(e)));
}
function hp(e, t, n) {
	let r = t.intersectObject(e, !0);
	for (let e = 0; e < r.length; e++) if (r[e].object.visible || n) return r[e];
	return !1;
}
var gp = new u(), _p = new L(0, 1, 0), vp = new L(0, 0, 0), yp = new Ie(), bp = new h(), xp = new h(), Sp = new L(), Cp = new Ie(), wp = new L(1, 0, 0), Tp = new L(0, 1, 0), Ep = new L(0, 0, 1), Dp = new L(), Op = new L(), kp = new L(), Ap = class extends f {
	constructor(e) {
		super(), this.isTransformControlsRoot = !0, this.controls = e, this.visible = !1;
	}
	updateMatrixWorld(e) {
		let t = this.controls;
		t.object !== void 0 && (t.object.updateMatrixWorld(), t.object.parent === null ? console.error("TransformControls: The attached 3D object must be a part of the scene graph.") : t.object.parent.matrixWorld.decompose(t._parentPosition, t._parentQuaternion, t._parentScale), t.object.matrixWorld.decompose(t.worldPosition, t.worldQuaternion, t._worldScale), t._parentQuaternionInv.copy(t._parentQuaternion).invert(), t._worldQuaternionInv.copy(t.worldQuaternion).invert()), t.camera.updateMatrixWorld(), t.camera.matrixWorld.decompose(t.cameraPosition, t.cameraQuaternion, t._cameraScale), t.camera.isOrthographicCamera ? t.camera.getWorldDirection(t.eye).negate() : t.eye.copy(t.cameraPosition).sub(t.worldPosition).normalize(), this.parent && (Cp.copy(this.parent.matrixWorld).invert(), Cp.decompose(this.position, this.quaternion, this.scale)), super.updateMatrixWorld(e);
	}
	dispose() {
		this.traverse(function(e) {
			e.geometry && e.geometry.dispose(), e.material && e.material.dispose();
		});
	}
}, jp = class extends f {
	constructor() {
		super(), this.isTransformControlsGizmo = !0, this.type = "TransformControlsGizmo";
		let e = new lt({
			depthTest: !1,
			depthWrite: !1,
			fog: !1,
			toneMapped: !1,
			transparent: !0
		}), t = new ot({
			depthTest: !1,
			depthWrite: !1,
			fog: !1,
			toneMapped: !1,
			transparent: !0
		}), n = e.clone();
		n.opacity = .15;
		let r = t.clone();
		r.opacity = .5;
		let i = e.clone();
		i.color.setHex(16711680);
		let a = e.clone();
		a.color.setHex(65280);
		let o = e.clone();
		o.color.setHex(255);
		let s = e.clone();
		s.color.setHex(16711680), s.opacity = .5;
		let c = e.clone();
		c.color.setHex(65280), c.opacity = .5;
		let l = e.clone();
		l.color.setHex(255), l.opacity = .5;
		let u = e.clone();
		u.opacity = .25;
		let d = e.clone();
		d.color.setHex(16776960), d.opacity = .25;
		let p = e.clone();
		p.color.setHex(16776960);
		let m = e.clone();
		m.color.setHex(7895160), this.materialLib = {
			xAxis: i,
			yAxis: a,
			zAxis: o,
			active: p,
			xAxisTransparent: s,
			yAxisTransparent: c,
			zAxisTransparent: l,
			activeTransparent: d
		};
		let h = new ht(0, .04, .1, 12);
		h.translate(0, .05, 0);
		let g = new rt(.08, .08, .08);
		g.translate(0, .04, 0);
		let _ = new We();
		_.setAttribute("position", new le([
			0,
			0,
			0,
			1,
			0,
			0
		], 3));
		let v = new ht(.0075, .0075, .5, 3);
		v.translate(0, .25, 0);
		function y(e, t) {
			let n = new j(e, .0075, 3, 64, t * Math.PI * 2);
			return n.rotateY(Math.PI / 2), n.rotateX(Math.PI / 2), n;
		}
		function b() {
			let e = new We();
			return e.setAttribute("position", new le([
				0,
				0,
				0,
				1,
				1,
				1
			], 3)), e;
		}
		let x = {
			X: [
				[
					new N(h, i),
					[
						.5,
						0,
						0
					],
					[
						0,
						0,
						-Math.PI / 2
					]
				],
				[
					new N(h, i),
					[
						-.5,
						0,
						0
					],
					[
						0,
						0,
						Math.PI / 2
					]
				],
				[
					new N(v, i),
					[
						0,
						0,
						0
					],
					[
						0,
						0,
						-Math.PI / 2
					]
				]
			],
			Y: [
				[new N(h, a), [
					0,
					.5,
					0
				]],
				[
					new N(h, a),
					[
						0,
						-.5,
						0
					],
					[
						Math.PI,
						0,
						0
					]
				],
				[new N(v, a)]
			],
			Z: [
				[
					new N(h, o),
					[
						0,
						0,
						.5
					],
					[
						Math.PI / 2,
						0,
						0
					]
				],
				[
					new N(h, o),
					[
						0,
						0,
						-.5
					],
					[
						-Math.PI / 2,
						0,
						0
					]
				],
				[
					new N(v, o),
					null,
					[
						Math.PI / 2,
						0,
						0
					]
				]
			],
			XYZ: [[new N(new Ve(.1, 0), u), [
				0,
				0,
				0
			]]],
			XY: [[new N(new rt(.15, .15, .01), l), [
				.15,
				.15,
				0
			]]],
			YZ: [[
				new N(new rt(.15, .15, .01), s),
				[
					0,
					.15,
					.15
				],
				[
					0,
					Math.PI / 2,
					0
				]
			]],
			XZ: [[
				new N(new rt(.15, .15, .01), c),
				[
					.15,
					0,
					.15
				],
				[
					-Math.PI / 2,
					0,
					0
				]
			]]
		}, S = {
			X: [[
				new N(new ht(.2, 0, .6, 4), n),
				[
					.3,
					0,
					0
				],
				[
					0,
					0,
					-Math.PI / 2
				]
			], [
				new N(new ht(.2, 0, .6, 4), n),
				[
					-.3,
					0,
					0
				],
				[
					0,
					0,
					Math.PI / 2
				]
			]],
			Y: [[new N(new ht(.2, 0, .6, 4), n), [
				0,
				.3,
				0
			]], [
				new N(new ht(.2, 0, .6, 4), n),
				[
					0,
					-.3,
					0
				],
				[
					0,
					0,
					Math.PI
				]
			]],
			Z: [[
				new N(new ht(.2, 0, .6, 4), n),
				[
					0,
					0,
					.3
				],
				[
					Math.PI / 2,
					0,
					0
				]
			], [
				new N(new ht(.2, 0, .6, 4), n),
				[
					0,
					0,
					-.3
				],
				[
					-Math.PI / 2,
					0,
					0
				]
			]],
			XYZ: [[new N(new Ve(.2, 0), n)]],
			XY: [[new N(new rt(.2, .2, .01), n), [
				.15,
				.15,
				0
			]]],
			YZ: [[
				new N(new rt(.2, .2, .01), n),
				[
					0,
					.15,
					.15
				],
				[
					0,
					Math.PI / 2,
					0
				]
			]],
			XZ: [[
				new N(new rt(.2, .2, .01), n),
				[
					.15,
					0,
					.15
				],
				[
					-Math.PI / 2,
					0,
					0
				]
			]]
		}, C = {
			START: [[
				new N(new Ve(.01, 2), r),
				null,
				null,
				null,
				"helper"
			]],
			END: [[
				new N(new Ve(.01, 2), r),
				null,
				null,
				null,
				"helper"
			]],
			DELTA: [[
				new F(b(), r),
				null,
				null,
				null,
				"helper"
			]],
			X: [[
				new F(_, r),
				[
					-1e3,
					0,
					0
				],
				null,
				[
					1e6,
					1,
					1
				],
				"helper"
			]],
			Y: [[
				new F(_, r),
				[
					0,
					-1e3,
					0
				],
				[
					0,
					0,
					Math.PI / 2
				],
				[
					1e6,
					1,
					1
				],
				"helper"
			]],
			Z: [[
				new F(_, r),
				[
					0,
					0,
					-1e3
				],
				[
					0,
					-Math.PI / 2,
					0
				],
				[
					1e6,
					1,
					1
				],
				"helper"
			]]
		}, w = {
			XYZE: [[
				new N(y(.5, 1), m),
				null,
				[
					0,
					Math.PI / 2,
					0
				]
			]],
			X: [[new N(y(.5, .5), i)]],
			Y: [[
				new N(y(.5, .5), a),
				null,
				[
					0,
					0,
					-Math.PI / 2
				]
			]],
			Z: [[
				new N(y(.5, .5), o),
				null,
				[
					0,
					Math.PI / 2,
					0
				]
			]],
			E: [[
				new N(y(.75, 1), d),
				null,
				[
					0,
					Math.PI / 2,
					0
				]
			]]
		}, T = { AXIS: [[
			new F(_, r),
			[
				-1e3,
				0,
				0
			],
			null,
			[
				1e6,
				1,
				1
			],
			"helper"
		]] }, E = {
			XYZE: [[new N(new k(.25, 10, 8), n)]],
			X: [[
				new N(new j(.5, .1, 4, 24), n),
				[
					0,
					0,
					0
				],
				[
					0,
					-Math.PI / 2,
					-Math.PI / 2
				]
			]],
			Y: [[
				new N(new j(.5, .1, 4, 24), n),
				[
					0,
					0,
					0
				],
				[
					Math.PI / 2,
					0,
					0
				]
			]],
			Z: [[
				new N(new j(.5, .1, 4, 24), n),
				[
					0,
					0,
					0
				],
				[
					0,
					0,
					-Math.PI / 2
				]
			]],
			E: [[new N(new j(.75, .1, 2, 24), n)]]
		}, D = {
			X: [
				[
					new N(g, i),
					[
						.5,
						0,
						0
					],
					[
						0,
						0,
						-Math.PI / 2
					]
				],
				[
					new N(v, i),
					[
						0,
						0,
						0
					],
					[
						0,
						0,
						-Math.PI / 2
					]
				],
				[
					new N(g, i),
					[
						-.5,
						0,
						0
					],
					[
						0,
						0,
						Math.PI / 2
					]
				]
			],
			Y: [
				[new N(g, a), [
					0,
					.5,
					0
				]],
				[new N(v, a)],
				[
					new N(g, a),
					[
						0,
						-.5,
						0
					],
					[
						0,
						0,
						Math.PI
					]
				]
			],
			Z: [
				[
					new N(g, o),
					[
						0,
						0,
						.5
					],
					[
						Math.PI / 2,
						0,
						0
					]
				],
				[
					new N(v, o),
					[
						0,
						0,
						0
					],
					[
						Math.PI / 2,
						0,
						0
					]
				],
				[
					new N(g, o),
					[
						0,
						0,
						-.5
					],
					[
						-Math.PI / 2,
						0,
						0
					]
				]
			],
			XY: [[new N(new rt(.15, .15, .01), l), [
				.15,
				.15,
				0
			]]],
			YZ: [[
				new N(new rt(.15, .15, .01), s),
				[
					0,
					.15,
					.15
				],
				[
					0,
					Math.PI / 2,
					0
				]
			]],
			XZ: [[
				new N(new rt(.15, .15, .01), c),
				[
					.15,
					0,
					.15
				],
				[
					-Math.PI / 2,
					0,
					0
				]
			]],
			XYZ: [[new N(new rt(.1, .1, .1), u)]]
		}, O = {
			X: [[
				new N(new ht(.2, 0, .6, 4), n),
				[
					.3,
					0,
					0
				],
				[
					0,
					0,
					-Math.PI / 2
				]
			], [
				new N(new ht(.2, 0, .6, 4), n),
				[
					-.3,
					0,
					0
				],
				[
					0,
					0,
					Math.PI / 2
				]
			]],
			Y: [[new N(new ht(.2, 0, .6, 4), n), [
				0,
				.3,
				0
			]], [
				new N(new ht(.2, 0, .6, 4), n),
				[
					0,
					-.3,
					0
				],
				[
					0,
					0,
					Math.PI
				]
			]],
			Z: [[
				new N(new ht(.2, 0, .6, 4), n),
				[
					0,
					0,
					.3
				],
				[
					Math.PI / 2,
					0,
					0
				]
			], [
				new N(new ht(.2, 0, .6, 4), n),
				[
					0,
					0,
					-.3
				],
				[
					-Math.PI / 2,
					0,
					0
				]
			]],
			XY: [[new N(new rt(.2, .2, .01), n), [
				.15,
				.15,
				0
			]]],
			YZ: [[
				new N(new rt(.2, .2, .01), n),
				[
					0,
					.15,
					.15
				],
				[
					0,
					Math.PI / 2,
					0
				]
			]],
			XZ: [[
				new N(new rt(.2, .2, .01), n),
				[
					.15,
					0,
					.15
				],
				[
					-Math.PI / 2,
					0,
					0
				]
			]],
			XYZ: [[new N(new rt(.2, .2, .2), n), [
				0,
				0,
				0
			]]]
		}, ee = {
			X: [[
				new F(_, r),
				[
					-1e3,
					0,
					0
				],
				null,
				[
					1e6,
					1,
					1
				],
				"helper"
			]],
			Y: [[
				new F(_, r),
				[
					0,
					-1e3,
					0
				],
				[
					0,
					0,
					Math.PI / 2
				],
				[
					1e6,
					1,
					1
				],
				"helper"
			]],
			Z: [[
				new F(_, r),
				[
					0,
					0,
					-1e3
				],
				[
					0,
					-Math.PI / 2,
					0
				],
				[
					1e6,
					1,
					1
				],
				"helper"
			]]
		};
		function A(e) {
			let t = new f();
			for (let n in e) for (let r = e[n].length; r--;) {
				let i = e[n][r][0].clone(), a = e[n][r][1], o = e[n][r][2], s = e[n][r][3], c = e[n][r][4];
				i.name = n, i.tag = c, a && i.position.set(a[0], a[1], a[2]), o && i.rotation.set(o[0], o[1], o[2]), s && i.scale.set(s[0], s[1], s[2]), i.updateMatrix();
				let l = i.geometry.clone();
				l.applyMatrix4(i.matrix), i.geometry = l, i.renderOrder = Infinity, i.position.set(0, 0, 0), i.rotation.set(0, 0, 0), i.scale.set(1, 1, 1), t.add(i);
			}
			return t;
		}
		this.gizmo = {}, this.picker = {}, this.helper = {}, this.add(this.gizmo.translate = A(x)), this.add(this.gizmo.rotate = A(w)), this.add(this.gizmo.scale = A(D)), this.add(this.picker.translate = A(S)), this.add(this.picker.rotate = A(E)), this.add(this.picker.scale = A(O)), this.add(this.helper.translate = A(C)), this.add(this.helper.rotate = A(T)), this.add(this.helper.scale = A(ee)), this.picker.translate.visible = !1, this.picker.rotate.visible = !1, this.picker.scale.visible = !1;
	}
	updateMatrixWorld(e) {
		let t = (this.mode === "scale" ? "local" : this.space) === "local" ? this.worldQuaternion : xp;
		this.gizmo.translate.visible = this.mode === "translate", this.gizmo.rotate.visible = this.mode === "rotate", this.gizmo.scale.visible = this.mode === "scale", this.helper.translate.visible = this.mode === "translate", this.helper.rotate.visible = this.mode === "rotate", this.helper.scale.visible = this.mode === "scale";
		let n = [];
		n = n.concat(this.picker[this.mode].children), n = n.concat(this.gizmo[this.mode].children), n = n.concat(this.helper[this.mode].children);
		for (let e = 0; e < n.length; e++) {
			let r = n[e];
			r.visible = !0, r.rotation.set(0, 0, 0), r.position.copy(this.worldPosition);
			let i;
			if (i = this.camera.isOrthographicCamera ? (this.camera.top - this.camera.bottom) / this.camera.zoom : this.worldPosition.distanceTo(this.cameraPosition) * Math.min(1.9 * Math.tan(Math.PI * this.camera.fov / 360) / this.camera.zoom, 7), r.scale.set(1, 1, 1).multiplyScalar(i * this.size / 4), r.tag === "helper") r.visible = !1, r.name === "AXIS" ? (r.visible = !!this.axis, this.axis === "X" && (rp.setFromEuler(gp.set(0, 0, 0)), r.quaternion.copy(t).multiply(rp), Math.abs(_p.copy(wp).applyQuaternion(t).dot(this.eye)) > .9 && (r.visible = !1)), this.axis === "Y" && (rp.setFromEuler(gp.set(0, 0, Math.PI / 2)), r.quaternion.copy(t).multiply(rp), Math.abs(_p.copy(Tp).applyQuaternion(t).dot(this.eye)) > .9 && (r.visible = !1)), this.axis === "Z" && (rp.setFromEuler(gp.set(0, Math.PI / 2, 0)), r.quaternion.copy(t).multiply(rp), Math.abs(_p.copy(Ep).applyQuaternion(t).dot(this.eye)) > .9 && (r.visible = !1)), this.axis === "XYZE" && (rp.setFromEuler(gp.set(0, Math.PI / 2, 0)), _p.copy(this.rotationAxis), r.quaternion.setFromRotationMatrix(yp.lookAt(vp, _p, Tp)), r.quaternion.multiply(rp), r.visible = this.dragging), this.axis === "E" && (r.visible = !1)) : r.name === "START" ? (r.position.copy(this.worldPositionStart), r.visible = this.dragging) : r.name === "END" ? (r.position.copy(this.worldPosition), r.visible = this.dragging) : r.name === "DELTA" ? (r.position.copy(this.worldPositionStart), r.quaternion.copy(this.worldQuaternionStart), tp.set(1e-10, 1e-10, 1e-10).add(this.worldPositionStart).sub(this.worldPosition).multiplyScalar(-1), tp.applyQuaternion(this.worldQuaternionStart.clone().invert()), r.scale.copy(tp), r.visible = this.dragging) : (r.quaternion.copy(t), this.dragging ? r.position.copy(this.worldPositionStart) : r.position.copy(this.worldPosition), this.axis && (r.visible = this.axis.search(r.name) !== -1));
			else {
				if (r.quaternion.copy(t), this.mode === "translate" || this.mode === "scale") {
					let e = .99, n = .2;
					r.name === "X" && Math.abs(_p.copy(wp).applyQuaternion(t).dot(this.eye)) > e && (r.scale.set(1e-10, 1e-10, 1e-10), r.visible = !1), r.name === "Y" && Math.abs(_p.copy(Tp).applyQuaternion(t).dot(this.eye)) > e && (r.scale.set(1e-10, 1e-10, 1e-10), r.visible = !1), r.name === "Z" && Math.abs(_p.copy(Ep).applyQuaternion(t).dot(this.eye)) > e && (r.scale.set(1e-10, 1e-10, 1e-10), r.visible = !1), r.name === "XY" && Math.abs(_p.copy(Ep).applyQuaternion(t).dot(this.eye)) < n && (r.scale.set(1e-10, 1e-10, 1e-10), r.visible = !1), r.name === "YZ" && Math.abs(_p.copy(wp).applyQuaternion(t).dot(this.eye)) < n && (r.scale.set(1e-10, 1e-10, 1e-10), r.visible = !1), r.name === "XZ" && Math.abs(_p.copy(Tp).applyQuaternion(t).dot(this.eye)) < n && (r.scale.set(1e-10, 1e-10, 1e-10), r.visible = !1);
				} else this.mode === "rotate" && (bp.copy(t), _p.copy(this.eye).applyQuaternion(rp.copy(t).invert()), r.name.search("E") !== -1 && r.quaternion.setFromRotationMatrix(yp.lookAt(this.eye, vp, Tp)), r.name === "X" && (rp.setFromAxisAngle(wp, Math.atan2(-_p.y, _p.z)), rp.multiplyQuaternions(bp, rp), r.quaternion.copy(rp)), r.name === "Y" && (rp.setFromAxisAngle(Tp, Math.atan2(_p.x, _p.z)), rp.multiplyQuaternions(bp, rp), r.quaternion.copy(rp)), r.name === "Z" && (rp.setFromAxisAngle(Ep, Math.atan2(_p.y, _p.x)), rp.multiplyQuaternions(bp, rp), r.quaternion.copy(rp)));
				r.visible = r.visible && (r.name.indexOf("X") === -1 || this.showX), r.visible = r.visible && (r.name.indexOf("Y") === -1 || this.showY), r.visible = r.visible && (r.name.indexOf("Z") === -1 || this.showZ), r.visible = r.visible && (r.name.indexOf("E") === -1 || this.showX && this.showY && this.showZ), r.visible = r.visible && (r.name.indexOf("XY") === -1 || this.showXY), r.visible = r.visible && (r.name.indexOf("YZ") === -1 || this.showYZ), r.visible = r.visible && (r.name.indexOf("XZ") === -1 || this.showXZ), r.visible = r.visible && (r.name !== "E" || this.showE), r.visible = r.visible && (r.name !== "XYZE" || this.showXYZE), r.material._color = r.material._color || r.material.color.clone(), r.material._opacity = r.material._opacity || r.material.opacity, r.material.color.copy(r.material._color), r.material.opacity = r.material._opacity, this.enabled && this.axis && (r.name === this.axis || this.axis.split("").some(function(e) {
					return r.name === e;
				})) && (r.material.color.copy(this.materialLib.active.color), r.material.opacity = 1);
			}
		}
		super.updateMatrixWorld(e);
	}
}, Mp = class extends N {
	constructor() {
		super(new D(1e5, 1e5, 2, 2), new lt({
			visible: !1,
			wireframe: !0,
			side: 2,
			transparent: !0,
			opacity: .1,
			toneMapped: !1
		})), this.isTransformControlsPlane = !0, this.type = "TransformControlsPlane";
	}
	updateMatrixWorld(e) {
		let t = this.space;
		switch (this.position.copy(this.worldPosition), this.mode === "scale" && (t = "local"), Dp.copy(wp).applyQuaternion(t === "local" ? this.worldQuaternion : xp), Op.copy(Tp).applyQuaternion(t === "local" ? this.worldQuaternion : xp), kp.copy(Ep).applyQuaternion(t === "local" ? this.worldQuaternion : xp), _p.copy(Op), this.mode) {
			case "translate":
			case "scale":
				switch (this.axis) {
					case "X":
						_p.copy(this.eye).cross(Dp), Sp.copy(Dp).cross(_p);
						break;
					case "Y":
						_p.copy(this.eye).cross(Op), Sp.copy(Op).cross(_p);
						break;
					case "Z":
						_p.copy(this.eye).cross(kp), Sp.copy(kp).cross(_p);
						break;
					case "XY":
						Sp.copy(kp);
						break;
					case "YZ":
						Sp.copy(Dp);
						break;
					case "XZ":
						_p.copy(kp), Sp.copy(Op);
						break;
					case "XYZ":
					case "E": Sp.set(0, 0, 0);
				}
				break;
			default: Sp.set(0, 0, 0);
		}
		Sp.length() === 0 ? this.quaternion.copy(this.cameraQuaternion) : (Cp.lookAt(tp.set(0, 0, 0), Sp, _p), this.quaternion.setFromRotationMatrix(Cp)), super.updateMatrixWorld(e);
	}
}, Np = "\nout vec2 vUv;\nvoid main() {\n  vUv = uv;\n  gl_Position = vec4(position.xy, 0.0, 1.0);\n}\n", Pp = "\nprecision highp float;\nprecision highp int;\nprecision highp sampler2DArray;\n#define MAXS 48\nout vec4 fragColor;\n\nuniform int uCount;\nuniform int uKind[MAXS];      // 0-6 solids, 7 an outline pushed out, 20 a group starts, 21 it ends\nuniform sampler2DArray uFields; // outline distance fields, one layer each (signed distance in texels)\nuniform vec4 uF[MAXS];        // x field layer, y the field's half size, z one texel, in the shape's units\nuniform mat3 uRot[MAXS];      // world to local\nuniform vec3 uPos[MAXS];\nuniform vec3 uHalf[MAXS];\nuniform vec4 uP[MAXS];        // x rounding radius, y torus thickness, z blend radius, w combine (0 add, 1 subtract, 2 intersect)\nuniform vec3 uCol[MAXS];      // linear colour\nuniform vec2 uMat[MAXS];      // x shininess, y metal\n\nuniform vec2 uRes;\nuniform vec2 uTileOffset;     // the part of the picture this draw covers (a tile of a big export, or all of it)\nuniform vec2 uTileSize;\nuniform vec3 uCamPos;\nuniform mat3 uCamRot;          // camera to world: columns right, up, back\nuniform float uTanHalf;\nuniform int uOrtho;\nuniform float uOrthoHalf;\n\nuniform vec3 uLightDir;\nuniform vec3 uLightCol;\nuniform float uIntensity;\nuniform float uAmbient;\nuniform int uShadows;\n\nuniform int uLook;             // 0 soft, 1 toon, 2 flat, 3 clay\nuniform float uOutline;        // pixels\nuniform vec3 uOutlineCol;\nuniform float uBands;\nuniform int uTransparent;\nuniform vec3 uBg;\nuniform int uGround;\nuniform float uGroundShadow;\nuniform int uSamples;          // 1 or 2 (2x2 samples per pixel)\nuniform float uGrid;           // the editing grid's cell on the ground (scene units), 0 for none (pictures and video never have one)\nuniform mat4 uViewProj;        // world to clip: the depth written, so imported models and shapes hide each other\nuniform sampler2D uMeshShadow; // imported models' depth seen from the light, for the shadows they cast\nuniform mat4 uLightViewProj;\nuniform int uMeshShadowOn;\nuniform float uShadowBias;\n\nfloat len2(vec2 v) { return length(v); }\n\nfloat shapeDist(int i, vec3 p) {\n  vec3 hs = uHalf[i];\n  float r = uP[i].x;\n  int k = uKind[i];\n  if (k == 0) { // box\n    vec3 q = abs(p) - hs + r;\n    return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0) - r;\n  }\n  if (k == 1) { // sphere, an ellipsoid\n    float k0 = length(p / hs);\n    float k1 = length(p / (hs * hs));\n    return k1 > 0.0 ? k0 * (k0 - 1.0) / k1 : -min(hs.x, min(hs.y, hs.z));\n  }\n  if (k == 2) { // cylinder\n    float ra = min(hs.x, hs.z);\n    float rr = min(r, min(ra, hs.y));\n    vec2 d = vec2(len2(vec2(p.x * ra / hs.x, p.z * ra / hs.z)) - ra + rr, abs(p.y) - hs.y + rr);\n    return min(max(d.x, d.y), 0.0) + length(max(d, 0.0)) - rr;\n  }\n  if (k == 3) { // cone, base down\n    float ra = min(hs.x, hs.z);\n    vec2 q = vec2(len2(vec2(p.x * ra / hs.x, p.z * ra / hs.z)), p.y);\n    float h = hs.y;\n    vec2 k1 = vec2(0.0, h);\n    vec2 k2 = vec2(-ra, 2.0 * h);\n    vec2 ca = vec2(q.x - min(q.x, q.y < 0.0 ? ra : 0.0), abs(q.y) - h);\n    vec2 cb = q - k1 + k2 * clamp(dot(k1 - q, k2) / dot(k2, k2), 0.0, 1.0);\n    float s = (cb.x < 0.0 && ca.y < 0.0) ? -1.0 : 1.0;\n    return s * sqrt(min(dot(ca, ca), dot(cb, cb))) - r * 0.5;\n  }\n  if (k == 4) { // torus\n    float tube = min(uP[i].y * hs.x, hs.y);\n    float ring = max(hs.x - tube, 0.001);\n    return len2(vec2(len2(vec2(p.x, p.z * hs.x / hs.z)) - ring, p.y)) - tube;\n  }\n  if (k == 5) { // capsule\n    float ra = min(hs.x, hs.z);\n    float h = max(hs.y - ra, 0.0);\n    float cy = p.y - clamp(p.y, -h, h);\n    return length(vec3(p.x * ra / hs.x, cy, p.z * ra / hs.z)) - ra;\n  }\n  if (k == 7) { // an outline pushed out along z, rounded\n    vec4 f = uF[i];\n    vec2 uv = vec2(p.x + f.y, f.y - p.y) / (2.0 * f.y);\n    float inner = texture(uFields, vec3(clamp(uv, 0.0, 1.0), f.x)).r * f.z;\n    float d2 = inner + length(max(abs(p.xy) - f.y * 0.98, 0.0));\n    float rr = min(r, hs.z * 0.95);\n    vec2 w = vec2(d2 + rr, abs(p.z) - hs.z + rr);\n    return min(max(w.x, w.y), 0.0) + length(max(w, 0.0)) - rr;\n  }\n  // pyramid, base down\n  float b = min(hs.x, hs.z);\n  float hgt = 2.0 * hs.y / (2.0 * b);\n  vec3 pp = vec3(abs(p.x * b / hs.x), p.y + hs.y, abs(p.z * b / hs.z)) / (2.0 * b);\n  if (pp.z > pp.x) pp.xz = pp.zx;\n  pp.xz -= 0.5;\n  float m2 = hgt * hgt + 0.25;\n  vec3 q = vec3(pp.z, hgt * pp.y - 0.5 * pp.x, hgt * pp.x + 0.5 * pp.y);\n  float s = max(-q.x, 0.0);\n  float t = clamp((q.y - 0.5 * pp.z) / (m2 + 0.25), 0.0, 1.0);\n  float a = m2 * (q.x + s) * (q.x + s) + q.y * q.y;\n  float bb = m2 * (q.x + 0.5 * t) * (q.x + 0.5 * t) + (q.y - m2 * t) * (q.y - m2 * t);\n  float d2 = min(q.y, -q.x * m2 - q.y * 0.5) > 0.0 ? 0.0 : min(a, bb);\n  return 2.0 * b * sqrt((d2 + q.z * q.z) / m2) * sign(max(q.z, -pp.y)) - r * 0.5;\n}\n\n// joins a shape (di, its colour and finish) onto what came before, added, cut or intersected, softly over k. Kept in step with join in sdf.ts\nvoid join(inout float d, inout vec3 col, inout vec2 mat, float di, vec3 ci, vec2 mi, float k, int op) {\n  float h;\n  if (op == 0) {\n    if (k > 1e-4) { h = clamp(0.5 + 0.5 * (d - di) / k, 0.0, 1.0); d = mix(d, di, h) - k * h * (1.0 - h); }\n    else { h = di < d ? 1.0 : 0.0; d = min(d, di); }\n  } else if (op == 1) {\n    float cut = -di;\n    if (k > 1e-4) { h = clamp(0.5 - 0.5 * (cut - d) / k, 0.0, 1.0); d = mix(d, cut, h) + k * h * (1.0 - h); }\n    else { h = cut > d ? 1.0 : 0.0; d = max(d, cut); }\n  } else {\n    if (k > 1e-4) { h = clamp(0.5 - 0.5 * (di - d) / k, 0.0, 1.0); d = mix(d, di, h) + k * h * (1.0 - h); }\n    else { h = di > d ? 1.0 : 0.0; d = max(d, di); }\n  }\n  col = mix(col, ci, h);\n  mat = mix(mat, mi, h);\n}\n\n// the design: shapes joined in order; a group joins its own shapes first, then joins what came before as one. Kept in step with sampleScene in sdf.ts\nfloat map(vec3 p, out vec3 col, out vec2 mat) {\n  float d = 1e9;\n  col = vec3(0.8);\n  mat = vec2(32.0, 0.0);\n  float gd = 1e9;\n  vec3 gcol = vec3(0.8);\n  vec2 gmat = vec2(32.0, 0.0);\n  for (int i = 0; i < MAXS; i++) {\n    if (i >= uCount) break;\n    int k = uKind[i];\n    if (k == 20) {\n      gd = d; gcol = col; gmat = mat;\n      d = 1e9; col = vec3(0.8); mat = vec2(32.0, 0.0);\n      continue;\n    }\n    if (k == 21) {\n      float di = d; vec3 ci = col; vec2 mi = mat;\n      d = gd; col = gcol; mat = gmat;\n      join(d, col, mat, di, ci, mi, uP[i].z, int(uP[i].w + 0.5));\n      continue;\n    }\n    float di = shapeDist(i, uRot[i] * (p - uPos[i]));\n    join(d, col, mat, di, uCol[i], uMat[i], uP[i].z, int(uP[i].w + 0.5));\n  }\n  return d;\n}\n\nfloat mapD(vec3 p) { vec3 c; vec2 m; return map(p, c, m); }\n\nvec3 normalAt(vec3 p, float t) {\n  float e = 0.0005 * max(1.0, t);\n  vec2 k = vec2(1.0, -1.0);\n  return normalize(k.xyy * mapD(p + k.xyy * e) + k.yyx * mapD(p + k.yyx * e) + k.yxy * mapD(p + k.yxy * e) + k.xxx * mapD(p + k.xxx * e));\n}\n\n// imported models in the way of the light, from their depth map (a little soft: nine taps)\nfloat meshShadow(vec3 p) {\n  if (uMeshShadowOn == 0) return 1.0;\n  vec4 c = uLightViewProj * vec4(p, 1.0);\n  vec3 q = c.xyz / c.w * 0.5 + 0.5;\n  if (q.x < 0.0 || q.y < 0.0 || q.x > 1.0 || q.y > 1.0) return 1.0;\n  // beyond the far side of the light's box still takes the shadow of what is in it\n  float z = min(q.z, 1.0) - uShadowBias;\n  vec2 texel = 1.5 / vec2(textureSize(uMeshShadow, 0));\n  float lit = 0.0;\n  for (int x = -1; x <= 1; x++)\n    for (int y = -1; y <= 1; y++) lit += step(z, texture(uMeshShadow, q.xy + vec2(float(x), float(y)) * texel).r);\n  return lit / 9.0;\n}\n\nfloat softShadow(vec3 ro, vec3 rd) {\n  if (uShadows == 0) return 1.0;\n  float res = 1.0;\n  float t = 0.02;\n  for (int i = 0; i < 64; i++) {\n    float h = mapD(ro + rd * t);\n    res = min(res, 10.0 * h / t);\n    t += clamp(h, 0.02, 0.4);\n    if (res < 0.002 || t > 30.0) break;\n  }\n  return clamp(res, 0.0, 1.0);\n}\n\nfloat ambientOcclusion(vec3 p, vec3 n) {\n  float occ = 0.0;\n  float sca = 1.0;\n  for (int i = 0; i < 5; i++) {\n    float h = 0.02 + 0.12 * float(i);\n    occ += (h - mapD(p + n * h)) * sca;\n    sca *= 0.75;\n  }\n  return clamp(1.0 - 1.6 * occ, 0.0, 1.0);\n}\n\n// occ: a model's own ambient occlusion (1 for none); like the field's, it darkens only the light that is not direct\nvec3 shade(vec3 p, vec3 n, vec3 rd, vec3 albedo, vec2 mat, float occ) {\n  if (uLook == 3) albedo = vec3(0.86, 0.84, 0.82);\n  vec3 l = normalize(uLightDir);\n  float diff = max(dot(n, l), 0.0);\n  float sh = diff > 0.0 ? softShadow(p + n * 0.003, l) * meshShadow(p + n * 0.01) : 0.0;\n  float ao = ambientOcclusion(p, n) * occ;\n  vec3 h = normalize(l - rd);\n  float spec = pow(max(dot(n, h), 0.0), mat.x) * diff * sh;\n  float sky = 0.5 + 0.5 * n.y;\n  if (uLook == 2) return albedo * (0.82 + 0.18 * diff);\n  if (uLook == 1) {\n    float lit = diff * sh;\n    float stepped = floor(lit * uBands + 0.5) / uBands;\n    float rim = pow(1.0 - max(dot(n, -rd), 0.0), 3.0) * 0.25;\n    float highlight = step(0.92, spec / max(diff, 0.001) * diff) * 0.35;\n    return albedo * (uAmbient * 0.9 * occ + uIntensity * 0.75 * stepped) + uLightCol * (highlight + rim * stepped);\n  }\n  // soft: a key light, a cool fill from the other side so the shadow side keeps its form, sky from above, a rim, and the finish's highlight\n  vec3 specCol = mix(vec3(1.0), albedo, mat.y);\n  vec3 base = albedo * (1.0 - 0.6 * mat.y);\n  vec3 fillDir = normalize(vec3(-l.x, 0.3, -l.z));\n  float fill = max(dot(n, fillDir), 0.0);\n  float rim = pow(1.0 - max(dot(n, -rd), 0.0), 4.0);\n  vec3 c = base * uLightCol * diff * sh * uIntensity;\n  c += base * vec3(0.72, 0.82, 1.0) * uAmbient * (0.25 + 0.75 * fill) * ao;\n  c += base * uAmbient * 0.45 * sky * ao;\n  c += uLightCol * rim * 0.22 * uIntensity * ao * sky;\n  c += specCol * uLightCol * spec * uIntensity * mix(0.35, 1.6, mat.y) * (mat.x > 60.0 ? 1.0 : 0.6);\n  // a warm bounce from below\n  c += base * vec3(1.0, 0.9, 0.8) * 0.05 * max(-n.y, 0.0);\n  return c;\n}\n\n// the ray through a point of the picture\nvoid rayFor(vec2 frag, out vec3 ro, out vec3 rd) {\n  vec2 ndc = (frag / uRes) * 2.0 - 1.0;\n  float aspect = uRes.x / uRes.y;\n  if (uOrtho == 1) {\n    ro = uCamPos + uCamRot * vec3(ndc.x * uOrthoHalf * aspect, ndc.y * uOrthoHalf, 0.0);\n    rd = normalize(uCamRot * vec3(0.0, 0.0, -1.0));\n  } else {\n    ro = uCamPos;\n    rd = normalize(uCamRot * vec3(ndc.x * uTanHalf * aspect, ndc.y * uTanHalf, -1.0));\n  }\n}\n\n// where a ray meets the ground plane (x, z), or far away when it never does\nvec2 onGround(vec3 ro, vec3 rd) {\n  return rd.y < -1e-5 && ro.y > 0.0 || rd.y > 1e-5 && ro.y < 0.0 ? (ro + rd * (-ro.y / rd.y)).xz : vec2(1e6);\n}\n\n// lines at whole numbers of c, about one pixel wide (fw: how far c moves across a pixel)\nfloat gridLines(vec2 c, vec2 fw) {\n  vec2 d = abs(fract(c - 0.5) - 0.5) / max(fw, vec2(1e-6));\n  return 1.0 - min(min(d.x, d.y), 1.0);\n}\n\n// The editing grid on the ground: a thin line every cell, a stronger one every fifth, the x axis red and the z axis blue. Lines fade where the\n// cells get too small to tell apart, so far away there is no shimmer. Straight colour and alpha.\nvec4 gridAt(vec2 frag, vec3 ro, vec3 rd) {\n  vec2 g = onGround(ro, rd);\n  if (uGrid <= 0.0 || g.x > 1e5) return vec4(0.0);\n  // how far the ground point moves across one pixel, from the rays through the neighbouring pixels\n  vec3 ro1, rd1, ro2, rd2;\n  rayFor(frag + vec2(1.0, 0.0), ro1, rd1);\n  rayFor(frag + vec2(0.0, 1.0), ro2, rd2);\n  vec2 fw = min(abs(onGround(ro1, rd1) - g) + abs(onGround(ro2, rd2) - g), vec2(1e3));\n  float big = uGrid * 5.0;\n  float minor = gridLines(g / uGrid, fw / uGrid) * (1.0 - smoothstep(0.12, 0.3, max(fw.x, fw.y) / uGrid));\n  float major = gridLines(g / big, fw / big) * (1.0 - smoothstep(0.12, 0.3, max(fw.x, fw.y) / big));\n  vec2 axis = (1.0 - min(abs(g) / max(fw * 1.9, vec2(1e-6)), 1.0)) * (1.0 - smoothstep(0.5, 2.0, fw.yx / uGrid));\n  vec3 ink = uTransparent == 0 && dot(uBg, vec3(0.299, 0.587, 0.114)) > 0.5 ? vec3(0.12, 0.1, 0.18) : vec3(0.82, 0.8, 0.9);\n  vec4 c = vec4(ink, max(minor * 0.22, major * 0.42));\n  // the x axis runs where z = 0, the z axis where x = 0\n  if (axis.y > 0.0) c = mix(c, vec4(1.0, 0.36, 0.4, 0.95), axis.y);\n  if (axis.x > 0.0) c = mix(c, vec4(0.38, 0.6, 1.0, 0.95), axis.x);\n  return c;\n}\n\n// b drawn over a (straight colours)\nvec4 over(vec4 a, vec4 b) {\n  float alpha = b.a + a.a * (1.0 - b.a);\n  return alpha > 0.0 ? vec4((b.rgb * b.a + a.rgb * a.a * (1.0 - b.a)) / alpha, alpha) : vec4(0.0);\n}\n\n", Fp = Pp + "\nin vec2 vUv;\n// the depth of what this pixel shows (1 for nothing)\nfloat gDepth;\nfloat depthOf(vec3 p) {\n  vec4 c = uViewProj * vec4(p, 1.0);\n  return clamp(c.z / c.w * 0.5 + 0.5, 0.0, 1.0);\n}\n\nvec4 render(vec2 frag) {\n  vec3 ro, rd;\n  rayFor(frag, ro, rd);\n  // a pixel's width in scene units at distance t: the outline is measured in pixels\n  float pixel = uOrtho == 1 ? 2.0 * uOrthoHalf / uRes.y : 2.0 * uTanHalf / uRes.y;\n  float outlinePx = uOutline * uRes.y / 1000.0;\n\n  float tGround = (uGround == 1 && rd.y < -1e-4) ? -ro.y / rd.y : 1e9;\n  float t = uOrtho == 1 ? 0.0 : 0.01;\n  float closest = 1e9;\n  bool hit = false;\n  vec3 col; vec2 mat;\n  for (int i = 0; i < 200; i++) {\n    vec3 p = ro + rd * t;\n    float d = map(p, col, mat);\n    float w = uOrtho == 1 ? pixel : pixel * max(t, 0.01);\n    closest = min(closest, d / w);\n    if (d < 0.0004 * max(1.0, t)) { hit = true; break; }\n    t += d * 0.92;\n    if (t > 120.0 || t > tGround + 0.5) break;\n  }\n  if (hit && t < tGround + 1e-3) {\n    vec3 p = ro + rd * t;\n    vec3 n = normalAt(p, t);\n    vec3 c = shade(p, n, rd, col, mat, 1.0);\n    gDepth = depthOf(p);\n    // an inked edge where the surface turns away from the eye\n    if (outlinePx > 0.0) {\n      float facing = abs(dot(n, rd));\n      float edge = smoothstep(0.12 + 0.02 * outlinePx, 0.02, facing);\n      c = mix(c, uOutlineCol, edge);\n    }\n    return vec4(c, 1.0);\n  }\n  if (outlinePx > 0.0 && closest < outlinePx) return vec4(uOutlineCol, smoothstep(outlinePx, outlinePx * 0.6, closest));\n  vec4 bg = uTransparent == 1 ? vec4(0.0) : vec4(uBg, 1.0);\n  if (tGround < 1e8) {\n    vec3 g = ro + rd * tGround;\n    // the floor hides what is under it\n    gDepth = depthOf(g);\n    float sh = 1.0 - softShadow(g + vec3(0.0, 0.002, 0.0), normalize(uLightDir)) * meshShadow(g);\n    // fades out away from the middle, so the floor has no edge\n    float fade = exp(-0.08 * length(g.xz));\n    float a = sh * uGroundShadow * fade;\n    bg = uTransparent == 1 ? vec4(0.0, 0.0, 0.0, a) : vec4(bg.rgb * (1.0 - a), 1.0);\n  }\n  return over(bg, gridAt(frag, ro, rd));\n}\n\nvoid main() {\n  vec2 frag = uTileOffset + vUv * uTileSize;\n  vec4 acc = vec4(0.0);\n  float depth = 1.0;\n  if (uSamples > 1) {\n    for (int sy = 0; sy < 2; sy++)\n      for (int sx = 0; sx < 2; sx++) {\n        gDepth = 1.0;\n        vec4 c = render(frag + (vec2(float(sx), float(sy)) - 0.5) * 0.5);\n        acc += vec4(c.rgb * c.a, c.a);\n        depth = min(depth, gDepth);\n      }\n    acc /= 4.0;\n  } else {\n    gDepth = 1.0;\n    vec4 c = render(frag);\n    acc = vec4(c.rgb * c.a, c.a);\n    depth = gDepth;\n  }\n  gl_FragDepth = depth;\n  // to sRGB, alpha not premultiplied\n  vec3 rgb = acc.a > 0.0 ? acc.rgb / acc.a : vec3(0.0);\n  fragColor = vec4(pow(max(rgb, 0.0), vec3(1.0 / 2.2)), acc.a);\n}\n", Ip = "\nin vec3 aColor;\nuniform mat3 uNormalWorld;\nout vec3 vWorld;\nout vec3 vNormal;\nout vec2 vMeshUv;\nout vec3 vColor;\nvoid main() {\n  vec4 w = modelMatrix * vec4(position, 1.0);\n  vWorld = w.xyz;\n  vNormal = uNormalWorld * normal;\n  vMeshUv = uv;\n  vColor = aColor;\n  gl_Position = projectionMatrix * viewMatrix * w;\n}\n", Lp = Pp + "\nin vec3 vWorld;\nin vec3 vNormal;\nin vec2 vMeshUv;\nin vec3 vColor;\nuniform vec3 uAlbedo;     // linear\nuniform sampler2D uMap;   // sRGB\nuniform int uHasMap;\nuniform vec2 uFinish;     // shininess, metal (the shape's finish, or the model's when it has no roughness)\nuniform int uCutout;\nuniform int uUnlit;          // 1: the colours as they are, no light (a photo card)\nuniform sampler2D uNormalMap;\nuniform int uHasNormal;\nuniform float uNormalScale;\nuniform sampler2D uRoughMap; // glTF: roughness in green, metalness in blue\nuniform int uPbr;            // 1: the finish from the model's roughness and metalness (uRoughMetal, scaled by uRoughMap)\nuniform int uHasRough;\nuniform vec2 uRoughMetal;\nuniform sampler2D uAoMap;     // red: ambient occlusion\nuniform int uHasAo;\nuniform float uAoStrength;\nuniform vec3 uEmissive;       // linear, strength included\nuniform sampler2D uEmissiveMap; // sRGB\nuniform int uHasEmissive;\nuniform float uClearcoat;      // 0 for none\nuniform float uCoatRough;\nuniform sampler2D uCoatMap;    // red: amount\nuniform int uHasCoatMap;\nuniform sampler2D uCoatRoughMap; // green: roughness\nuniform int uHasCoatRoughMap;\nuniform sampler2D uCoatNormalMap;\nuniform int uHasCoatNormal;\nuniform float uCoatNormalScale;\nuniform vec3 uSheen;           // linear colour, black for none\nuniform float uSheenRough;\nuniform sampler2D uSheenMap;   // sRGB colour\nuniform int uHasSheenMap;\nuniform sampler2D uSheenRoughMap; // alpha: roughness\nuniform int uHasSheenRoughMap;\nuniform float uTransmission;   // 0 for none\nuniform sampler2D uTransmissionMap; // red: amount\nuniform int uHasTransmissionMap;\nuniform float uIor;\nuniform sampler2D uBackdrop;   // what was drawn behind (sRGB, straight alpha), for light passing through\nuniform int uHasBackdrop;\n\n// a soft studio around the design, for what a glossy layer reflects: a dark floor, a bright sky, and a long softbox above the horizon (the\n// band a varnished or glass surface shows). Kept in step with studio in cpu.ts\nvec3 studio(vec3 dir) {\n  float box = smoothstep(0.22, 0.32, dir.y) * (1.0 - smoothstep(0.5, 0.62, dir.y));\n  return (mix(vec3(0.3, 0.28, 0.27), vec3(0.85, 0.9, 1.0), smoothstep(-0.25, 0.6, dir.y)) + 1.6 * box) * (0.5 + uAmbient) * uLightCol;\n}\nfloat fresnel(float cosTheta, float f0) {\n  return f0 + (1.0 - f0) * pow(1.0 - cosTheta, 5.0);\n}\n\n// a normal map's normal, in a tangent frame made from how the position and texture coordinates change across the pixel (no stored tangents).\n// glTF's normal maps have +Y up the picture, which is against v here (v runs down the picture)\nvec3 mappedNormal(sampler2D map, float strength, vec3 n, vec2 uv, vec3 dp1, vec3 dp2, vec2 duv1, vec2 duv2) {\n  vec3 dp2perp = cross(dp2, n), dp1perp = cross(n, dp1);\n  vec3 t = dp2perp * duv1.x + dp1perp * duv2.x;\n  vec3 b = dp2perp * duv1.y + dp1perp * duv2.y;\n  float scale = max(dot(t, t), dot(b, b));\n  if (scale < 1e-20) return n;\n  // a back face's frame was made with the turned-round normal: turned back\n  float k = (gl_FrontFacing ? 1.0 : -1.0) * inversesqrt(scale);\n  vec3 m = texture(map, uv).xyz * 2.0 - 1.0;\n  m.xy *= strength;\n  return normalize(mat3(t * k, -b * k, n) * m);\n}\n\nvoid main() {\n  // the changes across the pixel, taken before anything can discard it\n  vec3 dp1 = dFdx(vWorld), dp2 = dFdy(vWorld);\n  vec2 duv1 = dFdx(vMeshUv), duv2 = dFdy(vMeshUv);\n  vec4 tex = uHasMap == 1 ? texture(uMap, vMeshUv) : vec4(1.0);\n  if (uCutout == 1 && tex.a < 0.5) discard;\n  if (uUnlit == 1) {\n    fragColor = vec4(uAlbedo * tex.rgb * vColor, 1.0);\n    return;\n  }\n  vec3 n = normalize(vNormal);\n  if (!gl_FrontFacing) n = -n;\n  // the surface's own shape, before the normal map (a clear coat lies over it)\n  vec3 shapeN = n;\n  if (uHasNormal == 1) n = mappedNormal(uNormalMap, uNormalScale, n, vMeshUv, dp1, dp2, duv1, duv2);\n  vec2 finish = uFinish;\n  if (uPbr == 1) {\n    vec2 rm = uRoughMetal;\n    if (uHasRough == 1) rm *= texture(uRoughMap, vMeshUv).gb;\n    finish = vec2(6.0 + (1.0 - rm.x) * (1.0 - rm.x) * 134.0, rm.y);\n  }\n  vec3 rd = uOrtho == 1 ? normalize(uCamRot * vec3(0.0, 0.0, -1.0)) : normalize(vWorld - uCamPos);\n  vec3 albedo = uAlbedo * pow(tex.rgb, vec3(2.2)) * vColor;\n  float occ = uHasAo == 1 ? 1.0 + uAoStrength * (texture(uAoMap, vMeshUv).r - 1.0) : 1.0;\n  vec3 c = shade(vWorld, n, rd, albedo, finish, occ);\n  vec3 l = normalize(uLightDir);\n  vec3 v = -rd;\n  float alpha = 1.0;\n  // the layers a physical material adds (clay shows the form only; toon and flat stay drawn)\n  bool layered = uLook == 0 && (uClearcoat > 0.0 || max(uSheen.r, max(uSheen.g, uSheen.b)) > 0.0 || uTransmission > 0.0);\n  float vis = layered ? softShadow(vWorld + shapeN * 0.003, l) * meshShadow(vWorld + shapeN * 0.01) : 1.0;\n  // light passing through, like glass: what was drawn behind, bent a little and tinted by the surface's colour\n  float trans = uLook != 3 ? uTransmission * (uHasTransmissionMap == 1 ? texture(uTransmissionMap, vMeshUv).r : 1.0) : 0.0;\n  if (trans > 0.0 && uHasBackdrop == 1) {\n    float f0 = pow((uIor - 1.0) / (uIor + 1.0), 2.0);\n    float f = fresnel(max(dot(n, v), 0.0), f0);\n    vec3 nv = normalize(mat3(viewMatrix) * n);\n    vec2 size = vec2(textureSize(uBackdrop, 0));\n    vec2 uv = gl_FragCoord.xy / size - nv.xy * (1.0 - 1.0 / uIor) * 0.08;\n    vec4 behind = texture(uBackdrop, clamp(uv, vec2(0.0), vec2(1.0)));\n    vec3 through = pow(behind.rgb, vec3(2.2)) * albedo;\n    float k = trans * (1.0 - f);\n    vec3 h = normalize(l + v);\n    float glint = pow(max(dot(n, h), 0.0), max(finish.x, 60.0)) * max(dot(n, l), 0.0) * vis * uIntensity;\n    c = mix(c, through, k) + studio(reflect(rd, n)) * f * trans + uLightCol * glint;\n    alpha = mix(1.0, behind.a, k);\n    alpha = clamp(alpha + glint + f * trans, 0.0, 1.0);\n  }\n  // a velvet glow at grazing angles\n  if (uLook == 0 && max(uSheen.r, max(uSheen.g, uSheen.b)) > 0.0) {\n    vec3 sheen = uSheen * (uHasSheenMap == 1 ? pow(texture(uSheenMap, vMeshUv).rgb, vec3(2.2)) : vec3(1.0));\n    float rough = uSheenRough * (uHasSheenRoughMap == 1 ? texture(uSheenRoughMap, vMeshUv).a : 1.0);\n    float rim = pow(1.0 - max(dot(n, v), 0.0), mix(5.0, 1.5, rough));\n    c += sheen * rim * (uLightCol * uIntensity * max(dot(n, l), 0.0) * vis * 0.8 + uAmbient * 0.6 * occ);\n  }\n  // a clear varnish on top: a sharp highlight and the studio reflected, more at grazing angles, the surface below a little dimmer\n  if (uLook == 0 && uClearcoat > 0.0) {\n    float coat = uClearcoat * (uHasCoatMap == 1 ? texture(uCoatMap, vMeshUv).r : 1.0);\n    float rough = uCoatRough * (uHasCoatRoughMap == 1 ? texture(uCoatRoughMap, vMeshUv).g : 1.0);\n    vec3 nc = uHasCoatNormal == 1 ? mappedNormal(uCoatNormalMap, uCoatNormalScale, shapeN, vMeshUv, dp1, dp2, duv1, duv2) : shapeN;\n    float f = fresnel(max(dot(nc, v), 0.0), 0.04);\n    vec3 h = normalize(l + v);\n    float shine = 8.0 + (1.0 - rough) * (1.0 - rough) * 600.0;\n    float spec = pow(max(dot(nc, h), 0.0), shine) * max(dot(nc, l), 0.0) * vis * uIntensity * (1.0 + shine / 120.0);\n    vec3 reflected = studio(reflect(rd, nc)) * mix(1.0, 0.35, rough);\n    c = c * (1.0 - coat * f) + coat * (uLightCol * spec + reflected * f);\n  }\n  // the light it gives off, on top (clay shows the form only)\n  if (uLook != 3) c += uEmissive * (uHasEmissive == 1 ? pow(texture(uEmissiveMap, vMeshUv).rgb, vec3(2.2)) : vec3(1.0));\n  if (uOutline > 0.0) {\n    float outlinePx = uOutline * uRes.y / 1000.0;\n    float edge = smoothstep(0.12 + 0.02 * outlinePx, 0.02, abs(dot(n, rd)));\n    c = mix(c, uOutlineCol, edge);\n    alpha = mix(alpha, 1.0, edge);\n  }\n  fragColor = vec4(pow(max(c, 0.0), vec3(1.0 / 2.2)), alpha);\n}\n", Rp = "\nin vec3 aHull;\nuniform mat3 uNormalWorld;\nuniform float uOutline;\nuniform vec2 uRes;\nvoid main() {\n  vec4 clip = projectionMatrix * viewMatrix * modelMatrix * vec4(position, 1.0);\n  vec4 nclip = projectionMatrix * viewMatrix * vec4(normalize(uNormalWorld * aHull), 0.0);\n  vec2 dir = nclip.xy;\n  float l = length(dir);\n  dir = l > 1e-6 ? dir / l : vec2(0.0);\n  clip.xy += dir * (uOutline * uRes.y / 1000.0) * 2.0 / uRes * clip.w;\n  gl_Position = clip;\n}\n", zp = "\nprecision highp float;\nuniform vec3 uOutlineCol;\nout vec4 fragColor;\nvoid main() {\n  fragColor = vec4(pow(uOutlineCol, vec3(1.0 / 2.2)), 1.0);\n}\n", Bp = {
	box: 0,
	sphere: 1,
	cylinder: 2,
	cone: 3,
	torus: 4,
	capsule: 5,
	pyramid: 6,
	extrude: 7,
	text: 7
}, Vp = {
	matte: [8, 0],
	satin: [32, 0],
	glossy: [140, 0],
	metal: [64, 1]
}, Hp = {
	soft: 0,
	toon: 1,
	flat: 2,
	clay: 3,
	pixel: 1
}, Up = {
	add: 0,
	subtract: 1,
	intersect: 2
}, Wp = (e) => {
	let t = new I(e);
	return new L(t.r ** 2.2, t.g ** 2.2, t.b ** 2.2);
};
function Gp(e) {
	let t = qe.degToRad(e.yaw), n = qe.degToRad(e.pitch), r = new L(...e.target), i = new L(Math.sin(t) * Math.cos(n), Math.sin(n), Math.cos(t) * Math.cos(n)).multiplyScalar(e.distance);
	return {
		position: r.clone().add(i),
		target: r
	};
}
var Kp = class {
	texture;
	grids = [];
	constructor() {
		let e = (/* @__PURE__ */ new Uint16Array(1048576)).fill(g.toHalfFloat(24));
		this.texture = new pt(e, 256, 256, 16), this.texture.format = Ue, this.texture.type = p, this.texture.minFilter = this.texture.magFilter = B, this.texture.unpackAlignment = 1, this.texture.needsUpdate = !0;
	}
	put(e, t) {
		let n = Lt(t.outline, t.size[0], t.size[1]);
		if (this.grids[e] !== n.grid) {
			this.grids[e] = n.grid;
			let t = this.texture.image.data, r = e * 256 * 256;
			for (let e = 0; e < n.grid.length; e++) t[r + e] = g.toHalfFloat(n.grid[e]);
			this.texture.addLayerUpdate(e), this.texture.needsUpdate = !0;
		}
		return {
			half: n.half,
			texel: n.texel
		};
	}
	dispose() {
		this.texture.dispose();
	}
}, qp = new fe(new Uint8Array([
	255,
	255,
	255,
	255
]), 1, 1);
qp.needsUpdate = !0;
function Jp(e, t, n = 1) {
	let { position: r, target: i } = Gp(e.camera), a = Math.tan(qe.degToRad(e.camera.fov / 2)) * n, o;
	if (e.camera.projection === "orthographic") {
		let n = e.camera.distance * a;
		o = new ie(-n * t, n * t, n, -n, .05, 500);
	} else o = new ae(qe.radToDeg(2 * Math.atan(a)), t, .05, 500);
	return o.position.copy(r), o.up.set(0, 1, 0), o.lookAt(i), o.updateMatrixWorld(), o.updateProjectionMatrix(), o.layers.enable(2), o;
}
function Yp(e) {
	return {
		uCount: { value: 0 },
		uKind: { value: Array(48).fill(0) },
		uFields: { value: e.texture },
		uF: { value: Array.from({ length: 48 }, () => new Qe()) },
		uRot: { value: Array.from({ length: 48 }, () => new z()) },
		uPos: { value: Array.from({ length: 48 }, () => new L()) },
		uHalf: { value: Array.from({ length: 48 }, () => new L(.5, .5, .5)) },
		uP: { value: Array.from({ length: 48 }, () => new Qe()) },
		uCol: { value: Array.from({ length: 48 }, () => new L(.8, .8, .8)) },
		uMat: { value: Array.from({ length: 48 }, () => new P(32, 0)) },
		uRes: { value: new P(1, 1) },
		uTileOffset: { value: new P(0, 0) },
		uTileSize: { value: new P(1, 1) },
		uCamPos: { value: new L() },
		uCamRot: { value: new z() },
		uTanHalf: { value: .3 },
		uOrtho: { value: 0 },
		uOrthoHalf: { value: 1 },
		uLightDir: { value: new L(.5, .8, .5) },
		uLightCol: { value: new L(1, 1, 1) },
		uIntensity: { value: 1.4 },
		uAmbient: { value: .35 },
		uShadows: { value: 1 },
		uLook: { value: 0 },
		uOutline: { value: 0 },
		uOutlineCol: { value: new L() },
		uBands: { value: 3 },
		uTransparent: { value: 1 },
		uBg: { value: new L(1, 1, 1) },
		uGround: { value: 1 },
		uGroundShadow: { value: .35 },
		uSamples: { value: 1 },
		uGrid: { value: 0 },
		uViewProj: { value: new Ie() },
		uMeshShadow: { value: qp },
		uLightViewProj: { value: new Ie() },
		uMeshShadowOn: { value: 0 },
		uShadowBias: { value: .0015 }
	};
}
function Xp(e, t, n, r, i, a = 1) {
	let o = Ot(n).slice(0, 48);
	e.uCount.value = o.length;
	let s = 0;
	o.forEach((n, r) => {
		if (n.op !== "shape") {
			e.uKind.value[r] = n.op === "begin" ? 20 : 21, e.uP.value[r].set(0, 0, n.group.blend * .6, Up[n.group.combine]);
			return;
		}
		let i = n.shape;
		if (i.kind === "group" || i.kind === "mesh") return;
		if (e.uKind.value[r] = Bp[i.kind], i.outline && s < 16) {
			let n = t.put(s, i);
			e.uF.value[r].set(s++, n.half, n.texel, 0);
		}
		let a = Tt(i.rotation);
		e.uRot.value[r].set(a[0], a[3], a[6], a[1], a[4], a[7], a[2], a[5], a[8]), e.uPos.value[r].set(...i.position), e.uHalf.value[r].set(i.size[0] / 2, i.size[1] / 2, i.size[2] / 2), e.uP.value[r].set(i.round * Math.min(...i.size), i.thickness, i.blend * .6, Up[i.combine]), e.uCol.value[r].copy(Wp(i.color)), e.uMat.value[r].set(...Vp[i.finish]);
	}), e.uRes.value.set(r, i), e.uTileOffset.value.set(0, 0), e.uTileSize.value.set(r, i);
	let { position: c, target: l } = Gp(n.camera), u = new Ie().lookAt(c, l, new L(0, 1, 0));
	e.uCamPos.value.copy(c), e.uCamRot.value.setFromMatrix4(u);
	let d = Math.tan(qe.degToRad(n.camera.fov / 2)) * a;
	e.uTanHalf.value = d, e.uOrtho.value = +(n.camera.projection === "orthographic"), e.uOrthoHalf.value = n.camera.distance * d;
	let f = qe.degToRad(n.light.azimuth), p = qe.degToRad(n.light.elevation);
	e.uLightDir.value.set(Math.sin(f) * Math.cos(p), Math.sin(p), Math.cos(f) * Math.cos(p)), e.uLightCol.value.copy(Wp(n.light.color)), e.uIntensity.value = n.light.intensity, e.uAmbient.value = n.light.ambient, e.uShadows.value = +!!n.light.shadows, e.uLook.value = Hp[n.style.look], e.uOutline.value = n.style.outline, e.uOutlineCol.value.copy(Wp(n.style.outlineColor)), e.uBands.value = n.style.bands, e.uTransparent.value = +!!n.background.transparent, e.uBg.value.copy(Wp(n.background.color)), e.uGround.value = +!!n.ground.on, e.uGroundShadow.value = n.ground.shadow;
	let m = Jp(n, r / i, a);
	return e.uViewProj.value.multiplyMatrices(m.projectionMatrix, m.matrixWorldInverse), m;
}
function Zp(e) {
	return new m({
		glslVersion: M,
		vertexShader: Np,
		fragmentShader: Fp,
		uniforms: e,
		depthTest: !0,
		depthFunc: 1,
		depthWrite: !0,
		blending: 0
	});
}
function Qp(e, t) {
	let n = /* @__PURE__ */ new Map(), r = (t) => `${Math.round(e[t * 3] * 1e4)},${Math.round(e[t * 3 + 1] * 1e4)},${Math.round(e[t * 3 + 2] * 1e4)}`, i = e.length / 3;
	for (let e = 0; e < i; e++) {
		let i = r(e), a = n.get(i) ?? [
			0,
			0,
			0
		];
		a[0] += t[e * 3], a[1] += t[e * 3 + 1], a[2] += t[e * 3 + 2], n.set(i, a);
	}
	let a = new Float32Array(e.length);
	for (let e = 0; e < i; e++) {
		let t = n.get(r(e)), i = Math.hypot(...t) || 1;
		a.set([
			t[0] / i,
			t[1] / i,
			t[2] / i
		], e * 3);
	}
	return a;
}
var $p = class {
	uniforms;
	onReady;
	scene = new vt();
	glass = new vt();
	backdrop = null;
	built = /* @__PURE__ */ new Map();
	materials = /* @__PURE__ */ new Map();
	shadowTarget;
	depthMaterial = new _t({ side: 2 });
	holedDepths = /* @__PURE__ */ new Map();
	holedDepth(e) {
		let t = this.holedDepths.get(e);
		return t || (t = new _t({
			side: 2,
			map: e,
			alphaTest: .5
		}), this.holedDepths.set(e, t)), t;
	}
	lightCamera = new ie(-1, 1, 1, -1, .01, 10);
	count = 0;
	constructor(e, t = () => {}) {
		this.uniforms = e, this.onReady = t, this.shadowTarget = new Fe(2048, 2048, { depthTexture: new v(2048, 2048) }), this.lightCamera.layers.set(1);
	}
	build(e, t) {
		let n = this.built.get(e);
		if (n && n.data === t) return n.ready;
		let r = Ht(e, t), i = r.parts.map((e) => {
			let t = new We();
			return t.setAttribute("position", new Oe(e.positions, 3)), t.setAttribute("normal", new Oe(e.normals, 3)), e.uvs && t.setAttribute("uv", new Oe(e.uvs, 2)), t.setAttribute("aColor", new Oe(e.colors ?? new Float32Array(e.positions.length).fill(1), 3)), t.setIndex(new Oe(e.indices, 1)), t.setAttribute("aHull", new Oe(Qp(e.positions, e.normals), 3)), t.computeBoundingBox(), t.computeBoundingSphere(), t;
		}), a = {
			data: t,
			ready: Promise.resolve(null)
		};
		return a.ready = Promise.all(r.textures.map(async (e) => {
			try {
				let t = await createImageBitmap(new Blob([e.bytes], { type: e.mime }), {
					premultiplyAlpha: "none",
					colorSpaceConversion: "none"
				}), n = new ye(t);
				return n.flipY = !1, n.wrapS = n.wrapT = Be, n.colorSpace = "", n.anisotropy = 4, n.needsUpdate = !0, n;
			} catch {
				return null;
			}
		})).then((e) => (a.value = {
			asset: r,
			geometries: i,
			textures: e
		}, this.onReady(), a.value)), this.built.set(e, a), a.ready;
	}
	async ready(e) {
		await Promise.all(At(e).map(({ shape: e, asset: t }) => this.build(e.asset, t.data)));
	}
	sync(e) {
		this.scene.clear(), this.glass.clear(), this.count = 0;
		let t = /* @__PURE__ */ new Set();
		for (let { shape: n, path: r, asset: i } of At(e)) {
			this.build(n.asset, i.data);
			let a = this.built.get(n.asset)?.value;
			if (!a) continue;
			let { asset: o } = a, s = o.max.map((e, t) => Math.max(e - o.min[t], 1e-9)), c = o.min.map((e, t) => (e + o.max[t]) / 2), l = new Ie().compose(new L(...n.position), new h().setFromEuler(em(n.rotation)), new L(...n.size.map((e, t) => e / s[t]))).multiply(new Ie().makeTranslation(-c[0], -c[1], -c[2])), u = new z().getNormalMatrix(l), d = n.ownColors !== !1;
			o.parts.forEach((i, s) => {
				let c = `${n.id}:${s}`;
				t.add(c);
				let f = o.materials[i.material], p = d && f.texture >= 0 ? a.textures[f.texture] : null, h = this.materials.get(c);
				if (!h) {
					let e = new m({
						glslVersion: M,
						vertexShader: Ip,
						fragmentShader: Lp,
						uniforms: {
							...this.uniforms,
							uNormalWorld: { value: new z() },
							uAlbedo: { value: new L() },
							uMap: { value: qp },
							uHasMap: { value: 0 },
							uFinish: { value: new P() },
							uCutout: { value: 0 },
							uUnlit: { value: 0 },
							uNormalMap: { value: qp },
							uHasNormal: { value: 0 },
							uNormalScale: { value: 1 },
							uRoughMap: { value: qp },
							uPbr: { value: 0 },
							uHasRough: { value: 0 },
							uRoughMetal: { value: new P(.6, 0) },
							uAoMap: { value: qp },
							uHasAo: { value: 0 },
							uAoStrength: { value: 1 },
							uEmissive: { value: new L() },
							uEmissiveMap: { value: qp },
							uHasEmissive: { value: 0 },
							uClearcoat: { value: 0 },
							uCoatRough: { value: 0 },
							uCoatMap: { value: qp },
							uHasCoatMap: { value: 0 },
							uCoatRoughMap: { value: qp },
							uHasCoatRoughMap: { value: 0 },
							uCoatNormalMap: { value: qp },
							uHasCoatNormal: { value: 0 },
							uCoatNormalScale: { value: 1 },
							uSheen: { value: new L() },
							uSheenRough: { value: 0 },
							uSheenMap: { value: qp },
							uHasSheenMap: { value: 0 },
							uSheenRoughMap: { value: qp },
							uHasSheenRoughMap: { value: 0 },
							uTransmission: { value: 0 },
							uTransmissionMap: { value: qp },
							uHasTransmissionMap: { value: 0 },
							uIor: { value: 1.5 },
							uBackdrop: { value: qp },
							uHasBackdrop: { value: 0 }
						},
						side: 2
					});
					h = {
						mesh: e,
						hull: new m({
							glslVersion: M,
							vertexShader: Rp,
							fragmentShader: zp,
							uniforms: {
								uNormalWorld: e.uniforms.uNormalWorld,
								uOutline: this.uniforms.uOutline,
								uRes: this.uniforms.uRes,
								uOutlineCol: this.uniforms.uOutlineCol
							},
							side: 1
						})
					}, this.materials.set(c, h);
				}
				let g = h.mesh.uniforms, _ = d && f.unlit ? 0 : 2;
				h.mesh.side !== _ && (h.mesh.side = _, h.mesh.needsUpdate = !0), g.uNormalWorld.value.copy(u), g.uAlbedo.value.copy(d ? new L(...f.color) : Wp(n.color)), g.uMap.value = p ?? qp, g.uHasMap.value = p && i.uvs ? 1 : 0, g.uFinish.value.set(...d ? [6 + (1 - f.roughness) ** 2 * 134, f.metalness] : Vp[n.finish]), g.uCutout.value = d && f.cutout ? 1 : 0, g.uUnlit.value = d && f.unlit ? 1 : 0;
				let v = f.normalTexture >= 0 && i.uvs ? a.textures[f.normalTexture] : null;
				g.uNormalMap.value = v ?? qp, g.uHasNormal.value = +!!v, g.uNormalScale.value = f.normalScale;
				let y = d && f.roughnessTexture >= 0 && i.uvs ? a.textures[f.roughnessTexture] : null;
				g.uRoughMap.value = y ?? qp, g.uHasRough.value = +!!y, g.uPbr.value = +!!d, g.uRoughMetal.value.set(f.roughness, f.metalness);
				let b = f.occlusionTexture >= 0 && i.uvs ? a.textures[f.occlusionTexture] : null;
				g.uAoMap.value = b ?? qp, g.uHasAo.value = +!!b, g.uAoStrength.value = f.occlusionStrength, g.uEmissive.value.set(...d ? f.emissive : [
					0,
					0,
					0
				]);
				let x = d && f.emissiveTexture >= 0 && i.uvs ? a.textures[f.emissiveTexture] : null;
				g.uEmissiveMap.value = x ?? qp, g.uHasEmissive.value = +!!x;
				let S = (e) => d && e >= 0 && i.uvs ? a.textures[e] ?? null : null, C = (e, t, n) => {
					g[e].value = n ?? qp, g[t].value = +!!n;
				};
				g.uClearcoat.value = d ? f.clearcoat : 0, g.uCoatRough.value = f.clearcoatRoughness, C("uCoatMap", "uHasCoatMap", S(f.clearcoatTexture)), C("uCoatRoughMap", "uHasCoatRoughMap", S(f.clearcoatRoughnessTexture)), C("uCoatNormalMap", "uHasCoatNormal", S(f.clearcoatNormalTexture)), g.uCoatNormalScale.value = f.clearcoatNormalScale, g.uSheen.value.set(...d ? f.sheenColor : [
					0,
					0,
					0
				]), g.uSheenRough.value = f.sheenRoughness, C("uSheenMap", "uHasSheenMap", S(f.sheenColorTexture)), C("uSheenRoughMap", "uHasSheenRoughMap", S(f.sheenRoughnessTexture));
				let w = d ? f.transmission : 0;
				g.uTransmission.value = w, C("uTransmissionMap", "uHasTransmissionMap", S(f.transmissionTexture)), g.uIor.value = f.ior;
				let T = a.geometries[s], E = new N(T, h.mesh);
				if (E.matrixAutoUpdate = !1, E.matrix.copy(l), E.userData.ref = r, w <= .5 && E.layers.enable(1), (w > 0 ? this.glass : this.scene).add(E), e.style.outline > 0) {
					let e = new N(T, h.hull);
					e.matrixAutoUpdate = !1, e.matrix.copy(l), e.layers.set(2), this.scene.add(e);
				}
			}), this.count++;
		}
		for (let [e, n] of this.materials) t.has(e) || (n.mesh.dispose(), n.hull.dispose(), this.materials.delete(e));
	}
	draw(e, t, n, r) {
		if (this.count && (e.render(this.scene, t), this.glass.children.length)) {
			(!this.backdrop || this.backdrop.image.width !== n || this.backdrop.image.height !== r) && (this.backdrop?.dispose(), this.backdrop = new O(n, r)), e.copyFramebufferToTexture(this.backdrop);
			for (let e of this.glass.children) {
				let t = e.material.uniforms;
				t.uBackdrop.value = this.backdrop, t.uHasBackdrop.value = 1;
			}
			e.render(this.glass, t);
		}
	}
	pickables() {
		return [...this.scene.children, ...this.glass.children].filter((e) => e.userData.ref);
	}
	renderShadow(e, t) {
		let n = this.uniforms;
		if (!this.count || !t.light.shadows) {
			n.uMeshShadowOn.value = 0, n.uMeshShadow.value = qp;
			return;
		}
		this.scene.updateMatrixWorld(), this.glass.updateMatrixWorld();
		let r = new Ye();
		for (let e of this.pickables()) r.expandByObject(e);
		let i = r.getCenter(new L()), a = Math.max(r.getSize(new L()).length() / 2, .01), o = qe.degToRad(t.light.azimuth), s = qe.degToRad(t.light.elevation), c = new L(Math.sin(o) * Math.cos(s), Math.sin(s), Math.cos(o) * Math.cos(s)).normalize(), l = this.lightCamera;
		l.position.copy(i).addScaledVector(c, a * 2), l.up.set(0, Math.abs(c.y) > .99 ? 0 : 1, +(Math.abs(c.y) > .99)), l.lookAt(i), Object.assign(l, {
			left: -a,
			right: a,
			top: a,
			bottom: -a,
			near: .01,
			far: a * 4
		}), l.updateProjectionMatrix(), l.updateMatrixWorld();
		let u = e.getRenderTarget();
		e.setRenderTarget(this.shadowTarget), e.setScissorTest(!1), e.clear();
		let d = [];
		this.scene.traverse((e) => {
			let t = e, n = t.material?.uniforms;
			t.isMesh && n?.uCutout && n.uCutout.value === 1 && n.uHasMap?.value === 1 && (d.push({
				object: t,
				material: t.material
			}), t.material = this.holedDepth(n.uMap.value));
		}), this.scene.overrideMaterial = null, this.glass.overrideMaterial = this.depthMaterial;
		let f = /* @__PURE__ */ new Map();
		this.scene.traverse((e) => {
			let t = e;
			t.isMesh && !d.some((e) => e.object === t) && (f.set(t, t.material), t.material = this.depthMaterial);
		}), e.render(this.scene, l), e.autoClear = !1, e.render(this.glass, l);
		for (let e of d) e.object.material = e.material;
		for (let [e, t] of f) e.material = t;
		this.glass.overrideMaterial = null, e.setRenderTarget(u), n.uLightViewProj.value.multiplyMatrices(l.projectionMatrix, l.matrixWorldInverse), n.uMeshShadow.value = this.shadowTarget.depthTexture, n.uMeshShadowOn.value = 1, n.uShadowBias.value = Math.max(8e-4, .01 / (a * 4));
	}
	dispose() {
		for (let e of this.built.values()) e.ready.then((e) => (e.geometries.forEach((e) => e.dispose()), e.textures.forEach((e) => e?.dispose())));
		for (let e of this.materials.values()) e.mesh.dispose(), e.hull.dispose();
		this.shadowTarget.dispose(), this.backdrop?.dispose(), this.depthMaterial.dispose();
		for (let e of this.holedDepths.values()) e.dispose();
	}
}, em = (e) => new u(...e.map((e) => qe.degToRad(e)), "XYZ");
function tm(e) {
	let t = new Ye();
	for (let n of e.children ?? []) {
		if (n.hidden) continue;
		let e = new Ie().compose(new L(...n.position), new h().setFromEuler(em(n.rotation)), new L(...n.size));
		t.union(new Ye(new L(-.5, -.5, -.5), new L(.5, .5, .5)).applyMatrix4(e));
	}
	return t.isEmpty() ? {
		centre: new L(),
		size: new L(1, 1, 1)
	} : {
		centre: t.getCenter(new L()),
		size: t.getSize(new L())
	};
}
var nm = (e, t = 1e3) => Math.round(e * t) / t, rm = (e) => [
	e.x,
	e.y,
	e.z
].map((e) => nm(qe.radToDeg(e), 100)), im = class {
	container;
	editor;
	hooks;
	canvas;
	renderer;
	atlas = new Kp();
	uniforms = Yp(this.atlas);
	meshes;
	quadScene = new vt();
	quadCamera = new ie(-1, 1, 1, -1, 0, 1);
	overlay = new vt();
	perspective = new ae(35, 1, .05, 500);
	ortho = new ie(-1, 1, 1, -1, .05, 500);
	orbit;
	gizmo;
	proxy = new f();
	outline;
	selected = null;
	several = [];
	playing = null;
	doc;
	width = 1;
	height = 1;
	frame = 0;
	applying = !1;
	resize;
	gizmoStart = null;
	down = null;
	unsubscribe;
	grid = 0;
	snap = !1;
	constructor(e, t, n = {}) {
		this.container = e, this.editor = t, this.hooks = n, this.doc = t.document, this.renderer = new ka({
			antialias: !0,
			alpha: !0,
			premultipliedAlpha: !1,
			preserveDrawingBuffer: !0
		}), this.meshes = new $p(this.uniforms, () => {
			this.meshes.sync(this.doc), this.request();
		}), this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5)), this.renderer.setClearColor(0, 0), this.renderer.autoClear = !1, this.canvas = this.renderer.domElement, this.canvas.style.display = "block", this.canvas.style.width = "100%", this.canvas.style.height = "100%", e.appendChild(this.canvas), this.quadScene.add(new N(new D(2, 2), Zp(this.uniforms))), this.orbit = this.makeOrbit(this.activeCamera()), this.gizmo = new lp(this.activeCamera(), this.canvas), this.gizmo.setSize(.85), this.gizmo.addEventListener("dragging-changed", (e) => {
			this.orbit.enabled = !e.value;
		}), this.gizmo.addEventListener("mouseDown", () => this.gizmoBegin()), this.gizmo.addEventListener("objectChange", () => this.gizmoChange()), this.gizmo.addEventListener("mouseUp", () => this.gizmoEnd()), this.overlay.add(this.proxy), this.overlay.add(this.gizmo.getHelper()), this.outline = new nt(new He(new rt(1, 1, 1)), new ot({
			color: new I(getComputedStyle(e).getPropertyValue("--gs-focus").trim() || "#b38bff"),
			transparent: !0,
			opacity: .9,
			depthTest: !1
		})), this.outline.renderOrder = 10, this.proxy.add(this.outline), this.proxy.visible = !1, this.canvas.addEventListener("pointerdown", this.onPointerDown), this.canvas.addEventListener("pointerup", this.onPointerUp), this.resize = new ResizeObserver(() => this.fit()), this.resize.observe(e), this.unsubscribe = t.subscribe(() => this.setDocument(t.document)), this.fit(), this.setDocument(this.doc);
	}
	activeCamera() {
		return this.doc.camera.projection === "orthographic" ? this.ortho : this.perspective;
	}
	makeOrbit(e) {
		let t = new Ha(e, this.canvas);
		return t.enableDamping = !1, t.zoomToCursor = !0, t.addEventListener("start", () => this.editor.begin("Turn the view")), t.addEventListener("change", () => this.orbitChange()), t.addEventListener("end", () => this.editor.commit()), t;
	}
	setDocument(e) {
		let t = e.camera.projection !== this.doc.camera.projection;
		if (this.doc = e, t) {
			let e = this.orbit.target.clone();
			this.orbit.dispose(), this.orbit = this.makeOrbit(this.activeCamera()), this.orbit.target.copy(e), this.gizmo.camera = this.activeCamera();
		}
		this.fitted !== `${e.style.look}:${e.style.pixel}` && this.fit(), this.showScene(e.background.picture), this.applyCamera(), this.meshes.sync(this.playing ?? e), this.placeProxy(), this.request();
	}
	showFrame(e) {
		this.playing = e, this.meshes.sync(e ?? this.doc), e ? (this.proxy.visible = !1, this.gizmo.detach()) : this.placeProxy(), this.request();
	}
	select(e) {
		this.several = [], this.selected = e, this.placeProxy(), this.request();
	}
	selectSeveral(e) {
		if (e.length < 2) return this.select(e.length ? [e[0]] : null);
		this.several = [...e], this.selected = null, this.placeProxy(), this.request();
	}
	items() {
		let e = this.several.length ? this.several : this.selected?.length === 1 ? [this.selected[0]] : [];
		if (!this.several.length && this.selected?.length === 2) {
			let e = qt(this.doc, this.selected);
			return e ? [{
				ref: this.selected,
				shape: e
			}] : [];
		}
		return e.flatMap((e) => {
			let t = this.doc.shapes[e];
			return t ? t.kind === "group" ? (t.children ?? []).map((t, n) => ({
				ref: [e, n],
				shape: t
			})) : [{
				ref: [e],
				shape: t
			}] : [];
		});
	}
	setGizmo(e) {
		this.gizmo.setMode(e), this.request();
	}
	setGrid(e, t = !1) {
		this.grid = Math.max(0, e), this.snap = t, this.gizmo.setRotationSnap(t ? qe.degToRad(15) : null), this.request();
	}
	placeProxy() {
		if (this.gizmoStart || this.playing) return;
		let e = this.several.length ? this.several.map((e) => this.doc.shapes[e]) : [qt(this.doc, this.selected)], t = this.selected?.length === 2 && this.doc.shapes[this.selected[0]]?.hidden, n = e.filter((e) => !!e && !e.hidden);
		if (!n.length || t) {
			this.proxy.visible = !1, this.gizmo.detach();
			return;
		}
		this.proxy.visible = !0, this.proxy.scale.set(1, 1, 1);
		let r = n[0];
		if (n.length > 1 || r.kind === "group") {
			let e = tm({
				...r,
				children: n.flatMap((e) => e.kind === "group" ? e.children ?? [] : [e])
			});
			this.proxy.position.copy(e.centre), this.proxy.rotation.set(0, 0, 0), this.outline.scale.copy(e.size);
		} else this.proxy.position.set(...r.position), this.proxy.rotation.copy(em(r.rotation)), this.outline.scale.set(...r.size);
		n.some((e) => e.locked) || this.selected?.length === 2 && this.doc.shapes[this.selected[0]]?.locked ? this.gizmo.detach() : this.gizmo.object !== this.proxy && this.gizmo.attach(this.proxy);
	}
	gizmoBegin() {
		let e = this.items();
		if (!e.length) return;
		let t = this.several.length ? void 0 : qt(this.doc, this.selected);
		this.gizmoStart = {
			items: e.map((e) => ({
				ref: e.ref,
				shape: { ...e.shape }
			})),
			single: !!t && t.kind !== "group",
			pivot: this.proxy.position.clone(),
			size: [
				this.outline.scale.x,
				this.outline.scale.y,
				this.outline.scale.z
			]
		}, this.editor.begin(this.gizmo.mode === "translate" ? "Move" : this.gizmo.mode === "rotate" ? "Turn" : "Resize");
	}
	gizmoChange() {
		let e = this.gizmoStart;
		if (!e) return;
		let t = this.proxy;
		if (this.snap && this.grid > 0 && this.gizmo.mode === "translate") {
			let n = this.grid, r = t.position.clone().sub(e.pivot);
			t.position.copy(e.pivot).add(new L(...r.toArray().map((e) => Math.round(e / n) * n)));
		}
		if (e.single) {
			let n = e.items[0], r = n.shape.size.map((e, n) => Math.max(.02, e * Math.abs(t.scale.getComponent(n))));
			this.outline.scale.set(...r), this.editor.updateShapeAt(n.ref, {
				position: [
					t.position.x,
					t.position.y,
					t.position.z
				],
				rotation: rm(t.rotation),
				size: r
			});
			return;
		}
		let n = (Math.abs(t.scale.x) + Math.abs(t.scale.y) + Math.abs(t.scale.z)) / 3, r = new h().setFromEuler(t.rotation), i = t.position.clone().sub(e.pivot);
		this.outline.scale.set(e.size[0] * n, e.size[1] * n, e.size[2] * n);
		let a = e.items.map(({ shape: t }) => {
			let a = new L(...t.position).sub(e.pivot).multiplyScalar(n).applyQuaternion(r), o = r.clone().multiply(new h().setFromEuler(em(t.rotation)));
			return {
				...t,
				position: e.pivot.clone().add(i).add(a).toArray().map((e) => nm(e)),
				rotation: rm(new u().setFromQuaternion(o, "XYZ")),
				size: t.size.map((e) => Math.max(.02, nm(e * n)))
			};
		});
		this.editor.updateShapesAt(e.items.map((e, t) => {
			let n = a[t];
			return [e.ref, {
				position: n.position,
				rotation: n.rotation,
				size: n.size
			}];
		}), "Move");
	}
	gizmoEnd() {
		this.gizmoStart = null, this.editor.commit(), this.placeProxy();
	}
	applyCamera() {
		let { position: e, target: t } = Gp(this.doc.camera), n = this.width / this.height;
		this.applying = !0;
		for (let n of [this.perspective, this.ortho]) n.position.copy(e), n.up.set(0, 1, 0), n.lookAt(t);
		this.perspective.fov = this.doc.camera.fov, this.perspective.aspect = n, this.perspective.updateProjectionMatrix();
		let r = this.doc.camera.distance * Math.tan(qe.degToRad(this.doc.camera.fov / 2));
		Object.assign(this.ortho, {
			left: -r * n,
			right: r * n,
			top: r,
			bottom: -r,
			zoom: 1
		}), this.ortho.updateProjectionMatrix(), this.orbit.target.copy(t), this.orbit.update(), this.applying = !1;
	}
	orbitChange() {
		if (this.applying) return;
		let e = this.activeCamera(), t = this.orbit.target, n = e.position.clone().sub(t), r = n.length();
		e instanceof ie && e.zoom !== 1 && (r /= e.zoom, e.zoom = 1), this.editor.setCamera({
			yaw: nm(qe.radToDeg(Math.atan2(n.x, n.z)), 100),
			pitch: nm(qe.radToDeg(Math.asin(qe.clamp(n.y / n.length(), -1, 1))), 100),
			distance: nm(r),
			target: [
				t.x,
				t.y,
				t.z
			].map((e) => nm(e))
		});
	}
	onPointerDown = (e) => {
		this.down = {
			x: e.clientX,
			y: e.clientY
		};
	};
	onPointerUp = (e) => {
		let t = this.down;
		if (this.down = null, !t || Math.hypot(e.clientX - t.x, e.clientY - t.y) > 4 || this.gizmo.dragging || this.gizmo.axis) return;
		let n = this.canvas.getBoundingClientRect(), r = new P((e.clientX - n.left) / n.width * 2 - 1, -((e.clientY - n.top) / n.height) * 2 + 1), i = new oe();
		i.setFromCamera(r, this.activeCamera());
		let a = i.ray.origin, o = i.ray.direction, s = this.doc.shapes.some((e) => e.locked) ? { shapes: this.doc.shapes.map((e) => e.locked ? {
			...e,
			hidden: !0
		} : e) } : this.doc, c = It(s, [
			a.x,
			a.y,
			a.z
		], [
			o.x,
			o.y,
			o.z
		]), l = { extend: e.shiftKey || e.metaKey || e.ctrlKey };
		this.meshes.scene.updateMatrixWorld();
		let u = i.intersectObjects(this.meshes.pickables(), !1).find((e) => !this.doc.shapes[e.object.userData.ref[0]]?.locked);
		if (u && u.distance < (c?.t ?? Infinity)) return this.hooks.onPick?.(u.object.userData.ref, l);
		this.hooks.onPick?.(c?.shape ?? null, l);
	};
	fit() {
		let e = Math.max(1, this.container.clientWidth), t = Math.max(1, this.container.clientHeight);
		this.width = e, this.height = t;
		let n = this.doc.style.look === "pixel";
		this.renderer.setPixelRatio(n ? 1 : Math.min(window.devicePixelRatio || 1, 1.5));
		let [r, i] = n ? Xt(this.doc, e, t) : [e, t];
		this.renderer.setSize(r, i, !1), this.canvas.style.imageRendering = n ? "pixelated" : "", this.fitted = `${this.doc.style.look}:${this.doc.style.pixel}`, this.applyCamera(), this.request();
	}
	fitted = "";
	showScene(e) {
		this.container.dataset.scene !== e && (this.container.dataset.scene = e, Object.assign(this.container.style, e ? {
			backgroundImage: `url("${e}")`,
			backgroundSize: "cover",
			backgroundPosition: "center"
		} : {
			backgroundImage: "",
			backgroundSize: "",
			backgroundPosition: ""
		}));
	}
	request() {
		this.frame ||= requestAnimationFrame(() => {
			this.frame = 0, this.draw();
		});
	}
	draw() {
		let e = this.renderer.getDrawingBufferSize(new P()), t = Gt(this.playing ?? this.doc, e.y), n = Xp(this.uniforms, this.atlas, t, e.x, e.y);
		this.uniforms.uGrid.value = this.doc.style.look === "pixel" ? 0 : this.grid, this.meshes.renderShadow(this.renderer, t);
		let r = this.renderer.getSize(new P());
		this.renderer.setViewport(0, 0, r.x, r.y), this.renderer.clear(), this.renderer.render(this.quadScene, this.quadCamera), this.meshes.draw(this.renderer, n, e.x, e.y), this.renderer.clearDepth(), this.renderer.render(this.overlay, this.activeCamera());
	}
	dispose() {
		cancelAnimationFrame(this.frame), this.unsubscribe(), this.resize.disconnect(), this.canvas.removeEventListener("pointerdown", this.onPointerDown), this.canvas.removeEventListener("pointerup", this.onPointerUp), this.gizmo.dispose(), this.orbit.dispose(), this.meshes.dispose(), this.atlas.dispose(), this.renderer.dispose(), this.canvas.remove();
	}
}, am = class {
	canvas;
	output = document.createElement("canvas");
	backdrop = null;
	renderer;
	atlas = new Kp();
	uniforms = Yp(this.atlas);
	meshes = new $p(this.uniforms);
	scene = new vt();
	camera = new ie(-1, 1, 1, -1, 0, 1);
	constructor() {
		this.canvas = document.createElement("canvas"), this.renderer = new ka({
			canvas: this.canvas,
			antialias: !0,
			alpha: !0,
			premultipliedAlpha: !1,
			preserveDrawingBuffer: !0
		}), this.renderer.setPixelRatio(1), this.renderer.setClearColor(0, 0), this.renderer.autoClear = !1, this.scene.add(new N(new D(2, 2), Zp(this.uniforms)));
	}
	async paint(e, t, n, r = {}) {
		if (!Wt(e)) return this.draw(e, t, n, r);
		let i = e.style.look === "pixel", [a, o] = Xt(e, t, n), s = await this.draw(Gt(e, o), a, o, i ? {
			...r,
			samples: 1
		} : r), c = this.output;
		c.width = t, c.height = n;
		let l = c.getContext("2d");
		l.clearRect(0, 0, t, n);
		let u = await this.scenePicture(e.background.picture);
		if (u) {
			let e = Math.max(t / u.width, n / u.height);
			l.imageSmoothingEnabled = !0, l.drawImage(u, (t - u.width * e) / 2, (n - u.height * e) / 2, u.width * e, u.height * e);
		} else e.background.transparent || (l.fillStyle = e.background.color, l.fillRect(0, 0, t, n));
		return l.imageSmoothingEnabled = !i, l.drawImage(s, 0, 0, t, n), c;
	}
	surfaceFor(e) {
		return Wt(e) ? this.output : this.canvas;
	}
	async scenePicture(e) {
		return e ? (this.backdrop?.url !== e && (this.backdrop?.picture.close(), this.backdrop = {
			url: e,
			picture: await createImageBitmap(await (await fetch(e)).blob())
		}), this.backdrop.picture) : null;
	}
	async draw(e, t, n, r) {
		let { samples: i = 2, frame: a = 1, tile: o = 384 } = r;
		await this.meshes.ready(e), this.meshes.sync(e), this.renderer.setSize(t, n, !1);
		let s = Xp(this.uniforms, this.atlas, e, t, n, a);
		this.meshes.renderShadow(this.renderer, e), this.renderer.setScissorTest(!1), this.renderer.setViewport(0, 0, t, n), this.renderer.clear(), this.uniforms.uSamples.value = i, this.renderer.setScissorTest(!0);
		for (let e = 0; e < n; e += o) for (let r = 0; r < t; r += o) {
			let i = Math.min(o, t - r), a = Math.min(o, n - e);
			this.renderer.setViewport(r, e, i, a), this.renderer.setScissor(r, e, i, a), this.uniforms.uTileOffset.value.set(r, e), this.uniforms.uTileSize.value.set(i, a), this.renderer.render(this.scene, this.camera), t * n > 7e5 && await new Promise((e) => setTimeout(e, 0));
		}
		return this.renderer.setScissorTest(!1), this.meshes.count && (this.renderer.setViewport(0, 0, t, n), this.meshes.draw(this.renderer, s, t, n)), this.canvas;
	}
	dispose() {
		this.backdrop?.picture.close(), this.meshes.dispose(), this.atlas.dispose(), this.renderer.dispose();
	}
};
async function om(e, t, n, r = "image/png", i = 1) {
	let a = new am();
	try {
		let o = await a.paint(e, t, n, { frame: i });
		return await new Promise((e, t) => o.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be made.")), r, .92));
	} finally {
		a.dispose();
	}
}
//#endregion
//#region ../scene3d/src/model/video.ts
var sm = {
	still: "Camera still",
	turntable: "Turntable",
	bounce: "Camera sway",
	light: "Light sweep"
};
function cm(e, t, n) {
	let r = Mt(e, n);
	return t === "still" ? r : t === "turntable" ? {
		...r,
		camera: {
			...r.camera,
			yaw: r.camera.yaw + 360 * n
		}
	} : t === "bounce" ? {
		...r,
		camera: {
			...r.camera,
			yaw: r.camera.yaw + 25 * Math.sin(2 * Math.PI * n)
		}
	} : {
		...r,
		light: {
			...r.light,
			azimuth: (r.light.azimuth + 360 * n + 180) % 360 - 180
		}
	};
}
async function lm(e, t) {
	let { kind: n, seconds: r = 4, fps: i = 30, size: a = 1080, aspect: o = 1, onProgress: s } = t, c = (e) => Math.max(2, Math.round(e / 2) * 2), [l, u] = o >= 1 ? [c(a), c(a / o)] : [c(a * o), c(a)], d = {
		...e,
		background: {
			...e.background,
			transparent: !1
		}
	}, f = await lu("avc", {
		width: l,
		height: u
	}), p = !f && await lu("vp9", {
		width: l,
		height: u
	});
	if (!f && !p) throw Error("This browser cannot make video (it has no H.264 or VP9 encoder). Try Chrome, Edge or Safari.");
	let m = new am();
	try {
		let e = new $f({
			format: f ? new Vf({ fastStart: "in-memory" }) : new Gf(),
			target: new ff()
		}), t = new If(m.surfaceFor(d), {
			codec: f ? "avc" : "vp9",
			bitrate: cu
		});
		e.addVideoTrack(t, { frameRate: i }), await e.start();
		let a = Math.max(2, Math.round(Math.min(20, Math.max(1, r)) * i));
		for (let e = 0; e < a; e++) await m.paint(cm(d, n, e / a), l, u, { samples: 1 }), await t.add(e / i, 1 / i), s?.((e + 1) / a);
		await e.finalize();
		let o = e.target.buffer, c = f ? "video/mp4" : "video/webm";
		return {
			blob: new Blob([o], { type: c }),
			type: c,
			extension: f ? "mp4" : "webm"
		};
	} finally {
		m.dispose();
	}
}
//#endregion
//#region ../../node_modules/three/examples/jsm/libs/draco/gltf/draco_wasm_wrapper.js?url
var um = "data:text/javascript;base64,dmFyICRqc2NvbXA9JGpzY29tcHx8e307JGpzY29tcC5zY29wZT17fTskanNjb21wLmFycmF5SXRlcmF0b3JJbXBsPWZ1bmN0aW9uKGgpe3ZhciBuPTA7cmV0dXJuIGZ1bmN0aW9uKCl7cmV0dXJuIG48aC5sZW5ndGg/e2RvbmU6ITEsdmFsdWU6aFtuKytdfTp7ZG9uZTohMH19fTskanNjb21wLmFycmF5SXRlcmF0b3I9ZnVuY3Rpb24oaCl7cmV0dXJue25leHQ6JGpzY29tcC5hcnJheUl0ZXJhdG9ySW1wbChoKX19OyRqc2NvbXAubWFrZUl0ZXJhdG9yPWZ1bmN0aW9uKGgpe3ZhciBuPSJ1bmRlZmluZWQiIT10eXBlb2YgU3ltYm9sJiZTeW1ib2wuaXRlcmF0b3ImJmhbU3ltYm9sLml0ZXJhdG9yXTtyZXR1cm4gbj9uLmNhbGwoaCk6JGpzY29tcC5hcnJheUl0ZXJhdG9yKGgpfTskanNjb21wLkFTU1VNRV9FUzU9ITE7JGpzY29tcC5BU1NVTUVfTk9fTkFUSVZFX01BUD0hMTskanNjb21wLkFTU1VNRV9OT19OQVRJVkVfU0VUPSExOyRqc2NvbXAuU0lNUExFX0ZST1VORF9QT0xZRklMTD0hMTsKJGpzY29tcC5JU09MQVRFX1BPTFlGSUxMUz0hMTskanNjb21wLkZPUkNFX1BPTFlGSUxMX1BST01JU0U9ITE7JGpzY29tcC5GT1JDRV9QT0xZRklMTF9QUk9NSVNFX1dIRU5fTk9fVU5IQU5ETEVEX1JFSkVDVElPTj0hMTskanNjb21wLmdldEdsb2JhbD1mdW5jdGlvbihoKXtoPVsib2JqZWN0Ij09dHlwZW9mIGdsb2JhbFRoaXMmJmdsb2JhbFRoaXMsaCwib2JqZWN0Ij09dHlwZW9mIHdpbmRvdyYmd2luZG93LCJvYmplY3QiPT10eXBlb2Ygc2VsZiYmc2VsZiwib2JqZWN0Ij09dHlwZW9mIGdsb2JhbCYmZ2xvYmFsXTtmb3IodmFyIG49MDtuPGgubGVuZ3RoOysrbil7dmFyIGs9aFtuXTtpZihrJiZrLk1hdGg9PU1hdGgpcmV0dXJuIGt9dGhyb3cgRXJyb3IoIkNhbm5vdCBmaW5kIGdsb2JhbCBvYmplY3QiKTt9OyRqc2NvbXAuZ2xvYmFsPSRqc2NvbXAuZ2V0R2xvYmFsKHRoaXMpOwokanNjb21wLmRlZmluZVByb3BlcnR5PSRqc2NvbXAuQVNTVU1FX0VTNXx8ImZ1bmN0aW9uIj09dHlwZW9mIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzP09iamVjdC5kZWZpbmVQcm9wZXJ0eTpmdW5jdGlvbihoLG4sayl7aWYoaD09QXJyYXkucHJvdG90eXBlfHxoPT1PYmplY3QucHJvdG90eXBlKXJldHVybiBoO2hbbl09ay52YWx1ZTtyZXR1cm4gaH07JGpzY29tcC5JU19TWU1CT0xfTkFUSVZFPSJmdW5jdGlvbiI9PT10eXBlb2YgU3ltYm9sJiYic3ltYm9sIj09PXR5cGVvZiBTeW1ib2woIngiKTskanNjb21wLlRSVVNUX0VTNl9QT0xZRklMTFM9ISRqc2NvbXAuSVNPTEFURV9QT0xZRklMTFN8fCRqc2NvbXAuSVNfU1lNQk9MX05BVElWRTskanNjb21wLnBvbHlmaWxscz17fTskanNjb21wLnByb3BlcnR5VG9Qb2x5ZmlsbFN5bWJvbD17fTskanNjb21wLlBPTFlGSUxMX1BSRUZJWD0iJGpzY3AkIjsKdmFyICRqc2NvbXAkbG9va3VwUG9seWZpbGxlZFZhbHVlPWZ1bmN0aW9uKGgsbil7dmFyIGs9JGpzY29tcC5wcm9wZXJ0eVRvUG9seWZpbGxTeW1ib2xbbl07aWYobnVsbD09aylyZXR1cm4gaFtuXTtrPWhba107cmV0dXJuIHZvaWQgMCE9PWs/azpoW25dfTskanNjb21wLnBvbHlmaWxsPWZ1bmN0aW9uKGgsbixrLHApe24mJigkanNjb21wLklTT0xBVEVfUE9MWUZJTExTPyRqc2NvbXAucG9seWZpbGxJc29sYXRlZChoLG4sayxwKTokanNjb21wLnBvbHlmaWxsVW5pc29sYXRlZChoLG4sayxwKSl9OwokanNjb21wLnBvbHlmaWxsVW5pc29sYXRlZD1mdW5jdGlvbihoLG4sayxwKXtrPSRqc2NvbXAuZ2xvYmFsO2g9aC5zcGxpdCgiLiIpO2ZvcihwPTA7cDxoLmxlbmd0aC0xO3ArKyl7dmFyIGw9aFtwXTtpZighKGwgaW4gaykpcmV0dXJuO2s9a1tsXX1oPWhbaC5sZW5ndGgtMV07cD1rW2hdO249bihwKTtuIT1wJiZudWxsIT1uJiYkanNjb21wLmRlZmluZVByb3BlcnR5KGssaCx7Y29uZmlndXJhYmxlOiEwLHdyaXRhYmxlOiEwLHZhbHVlOm59KX07CiRqc2NvbXAucG9seWZpbGxJc29sYXRlZD1mdW5jdGlvbihoLG4sayxwKXt2YXIgbD1oLnNwbGl0KCIuIik7aD0xPT09bC5sZW5ndGg7cD1sWzBdO3A9IWgmJnAgaW4gJGpzY29tcC5wb2x5ZmlsbHM/JGpzY29tcC5wb2x5ZmlsbHM6JGpzY29tcC5nbG9iYWw7Zm9yKHZhciB5PTA7eTxsLmxlbmd0aC0xO3krKyl7dmFyIGY9bFt5XTtpZighKGYgaW4gcCkpcmV0dXJuO3A9cFtmXX1sPWxbbC5sZW5ndGgtMV07az0kanNjb21wLklTX1NZTUJPTF9OQVRJVkUmJiJlczYiPT09az9wW2xdOm51bGw7bj1uKGspO251bGwhPW4mJihoPyRqc2NvbXAuZGVmaW5lUHJvcGVydHkoJGpzY29tcC5wb2x5ZmlsbHMsbCx7Y29uZmlndXJhYmxlOiEwLHdyaXRhYmxlOiEwLHZhbHVlOm59KTpuIT09ayYmKHZvaWQgMD09PSRqc2NvbXAucHJvcGVydHlUb1BvbHlmaWxsU3ltYm9sW2xdJiYoaz0xRTkqTWF0aC5yYW5kb20oKT4+PjAsJGpzY29tcC5wcm9wZXJ0eVRvUG9seWZpbGxTeW1ib2xbbF09JGpzY29tcC5JU19TWU1CT0xfTkFUSVZFPwokanNjb21wLmdsb2JhbC5TeW1ib2wobCk6JGpzY29tcC5QT0xZRklMTF9QUkVGSVgraysiJCIrbCksJGpzY29tcC5kZWZpbmVQcm9wZXJ0eShwLCRqc2NvbXAucHJvcGVydHlUb1BvbHlmaWxsU3ltYm9sW2xdLHtjb25maWd1cmFibGU6ITAsd3JpdGFibGU6ITAsdmFsdWU6bn0pKSl9OwokanNjb21wLnBvbHlmaWxsKCJQcm9taXNlIixmdW5jdGlvbihoKXtmdW5jdGlvbiBuKCl7dGhpcy5iYXRjaF89bnVsbH1mdW5jdGlvbiBrKGYpe3JldHVybiBmIGluc3RhbmNlb2YgbD9mOm5ldyBsKGZ1bmN0aW9uKHEsdSl7cShmKX0pfWlmKGgmJighKCRqc2NvbXAuRk9SQ0VfUE9MWUZJTExfUFJPTUlTRXx8JGpzY29tcC5GT1JDRV9QT0xZRklMTF9QUk9NSVNFX1dIRU5fTk9fVU5IQU5ETEVEX1JFSkVDVElPTiYmInVuZGVmaW5lZCI9PT10eXBlb2YgJGpzY29tcC5nbG9iYWwuUHJvbWlzZVJlamVjdGlvbkV2ZW50KXx8ISRqc2NvbXAuZ2xvYmFsLlByb21pc2V8fC0xPT09JGpzY29tcC5nbG9iYWwuUHJvbWlzZS50b1N0cmluZygpLmluZGV4T2YoIltuYXRpdmUgY29kZV0iKSkpcmV0dXJuIGg7bi5wcm90b3R5cGUuYXN5bmNFeGVjdXRlPWZ1bmN0aW9uKGYpe2lmKG51bGw9PXRoaXMuYmF0Y2hfKXt0aGlzLmJhdGNoXz1bXTt2YXIgcT10aGlzO3RoaXMuYXN5bmNFeGVjdXRlRnVuY3Rpb24oZnVuY3Rpb24oKXtxLmV4ZWN1dGVCYXRjaF8oKX0pfXRoaXMuYmF0Y2hfLnB1c2goZil9Owp2YXIgcD0kanNjb21wLmdsb2JhbC5zZXRUaW1lb3V0O24ucHJvdG90eXBlLmFzeW5jRXhlY3V0ZUZ1bmN0aW9uPWZ1bmN0aW9uKGYpe3AoZiwwKX07bi5wcm90b3R5cGUuZXhlY3V0ZUJhdGNoXz1mdW5jdGlvbigpe2Zvcig7dGhpcy5iYXRjaF8mJnRoaXMuYmF0Y2hfLmxlbmd0aDspe3ZhciBmPXRoaXMuYmF0Y2hfO3RoaXMuYmF0Y2hfPVtdO2Zvcih2YXIgcT0wO3E8Zi5sZW5ndGg7KytxKXt2YXIgdT1mW3FdO2ZbcV09bnVsbDt0cnl7dSgpfWNhdGNoKEEpe3RoaXMuYXN5bmNUaHJvd18oQSl9fX10aGlzLmJhdGNoXz1udWxsfTtuLnByb3RvdHlwZS5hc3luY1Rocm93Xz1mdW5jdGlvbihmKXt0aGlzLmFzeW5jRXhlY3V0ZUZ1bmN0aW9uKGZ1bmN0aW9uKCl7dGhyb3cgZjt9KX07dmFyIGw9ZnVuY3Rpb24oZil7dGhpcy5zdGF0ZV89MDt0aGlzLnJlc3VsdF89dm9pZCAwO3RoaXMub25TZXR0bGVkQ2FsbGJhY2tzXz1bXTt0aGlzLmlzUmVqZWN0aW9uSGFuZGxlZF89ITE7dmFyIHE9dGhpcy5jcmVhdGVSZXNvbHZlQW5kUmVqZWN0XygpOwp0cnl7ZihxLnJlc29sdmUscS5yZWplY3QpfWNhdGNoKHUpe3EucmVqZWN0KHUpfX07bC5wcm90b3R5cGUuY3JlYXRlUmVzb2x2ZUFuZFJlamVjdF89ZnVuY3Rpb24oKXtmdW5jdGlvbiBmKEEpe3JldHVybiBmdW5jdGlvbihGKXt1fHwodT0hMCxBLmNhbGwocSxGKSl9fXZhciBxPXRoaXMsdT0hMTtyZXR1cm57cmVzb2x2ZTpmKHRoaXMucmVzb2x2ZVRvXykscmVqZWN0OmYodGhpcy5yZWplY3RfKX19O2wucHJvdG90eXBlLnJlc29sdmVUb189ZnVuY3Rpb24oZil7aWYoZj09PXRoaXMpdGhpcy5yZWplY3RfKG5ldyBUeXBlRXJyb3IoIkEgUHJvbWlzZSBjYW5ub3QgcmVzb2x2ZSB0byBpdHNlbGYiKSk7ZWxzZSBpZihmIGluc3RhbmNlb2YgbCl0aGlzLnNldHRsZVNhbWVBc1Byb21pc2VfKGYpO2Vsc2V7YTpzd2l0Y2godHlwZW9mIGYpe2Nhc2UgIm9iamVjdCI6dmFyIHE9bnVsbCE9ZjticmVhayBhO2Nhc2UgImZ1bmN0aW9uIjpxPSEwO2JyZWFrIGE7ZGVmYXVsdDpxPSExfXE/dGhpcy5yZXNvbHZlVG9Ob25Qcm9taXNlT2JqXyhmKToKdGhpcy5mdWxmaWxsXyhmKX19O2wucHJvdG90eXBlLnJlc29sdmVUb05vblByb21pc2VPYmpfPWZ1bmN0aW9uKGYpe3ZhciBxPXZvaWQgMDt0cnl7cT1mLnRoZW59Y2F0Y2godSl7dGhpcy5yZWplY3RfKHUpO3JldHVybn0iZnVuY3Rpb24iPT10eXBlb2YgcT90aGlzLnNldHRsZVNhbWVBc1RoZW5hYmxlXyhxLGYpOnRoaXMuZnVsZmlsbF8oZil9O2wucHJvdG90eXBlLnJlamVjdF89ZnVuY3Rpb24oZil7dGhpcy5zZXR0bGVfKDIsZil9O2wucHJvdG90eXBlLmZ1bGZpbGxfPWZ1bmN0aW9uKGYpe3RoaXMuc2V0dGxlXygxLGYpfTtsLnByb3RvdHlwZS5zZXR0bGVfPWZ1bmN0aW9uKGYscSl7aWYoMCE9dGhpcy5zdGF0ZV8pdGhyb3cgRXJyb3IoIkNhbm5vdCBzZXR0bGUoIitmKyIsICIrcSsiKTogUHJvbWlzZSBhbHJlYWR5IHNldHRsZWQgaW4gc3RhdGUiK3RoaXMuc3RhdGVfKTt0aGlzLnN0YXRlXz1mO3RoaXMucmVzdWx0Xz1xOzI9PT10aGlzLnN0YXRlXyYmdGhpcy5zY2hlZHVsZVVuaGFuZGxlZFJlamVjdGlvbkNoZWNrXygpOwp0aGlzLmV4ZWN1dGVPblNldHRsZWRDYWxsYmFja3NfKCl9O2wucHJvdG90eXBlLnNjaGVkdWxlVW5oYW5kbGVkUmVqZWN0aW9uQ2hlY2tfPWZ1bmN0aW9uKCl7dmFyIGY9dGhpcztwKGZ1bmN0aW9uKCl7aWYoZi5ub3RpZnlVbmhhbmRsZWRSZWplY3Rpb25fKCkpe3ZhciBxPSRqc2NvbXAuZ2xvYmFsLmNvbnNvbGU7InVuZGVmaW5lZCIhPT10eXBlb2YgcSYmcS5lcnJvcihmLnJlc3VsdF8pfX0sMSl9O2wucHJvdG90eXBlLm5vdGlmeVVuaGFuZGxlZFJlamVjdGlvbl89ZnVuY3Rpb24oKXtpZih0aGlzLmlzUmVqZWN0aW9uSGFuZGxlZF8pcmV0dXJuITE7dmFyIGY9JGpzY29tcC5nbG9iYWwuQ3VzdG9tRXZlbnQscT0kanNjb21wLmdsb2JhbC5FdmVudCx1PSRqc2NvbXAuZ2xvYmFsLmRpc3BhdGNoRXZlbnQ7aWYoInVuZGVmaW5lZCI9PT10eXBlb2YgdSlyZXR1cm4hMDsiZnVuY3Rpb24iPT09dHlwZW9mIGY/Zj1uZXcgZigidW5oYW5kbGVkcmVqZWN0aW9uIix7Y2FuY2VsYWJsZTohMH0pOgoiZnVuY3Rpb24iPT09dHlwZW9mIHE/Zj1uZXcgcSgidW5oYW5kbGVkcmVqZWN0aW9uIix7Y2FuY2VsYWJsZTohMH0pOihmPSRqc2NvbXAuZ2xvYmFsLmRvY3VtZW50LmNyZWF0ZUV2ZW50KCJDdXN0b21FdmVudCIpLGYuaW5pdEN1c3RvbUV2ZW50KCJ1bmhhbmRsZWRyZWplY3Rpb24iLCExLCEwLGYpKTtmLnByb21pc2U9dGhpcztmLnJlYXNvbj10aGlzLnJlc3VsdF87cmV0dXJuIHUoZil9O2wucHJvdG90eXBlLmV4ZWN1dGVPblNldHRsZWRDYWxsYmFja3NfPWZ1bmN0aW9uKCl7aWYobnVsbCE9dGhpcy5vblNldHRsZWRDYWxsYmFja3NfKXtmb3IodmFyIGY9MDtmPHRoaXMub25TZXR0bGVkQ2FsbGJhY2tzXy5sZW5ndGg7KytmKXkuYXN5bmNFeGVjdXRlKHRoaXMub25TZXR0bGVkQ2FsbGJhY2tzX1tmXSk7dGhpcy5vblNldHRsZWRDYWxsYmFja3NfPW51bGx9fTt2YXIgeT1uZXcgbjtsLnByb3RvdHlwZS5zZXR0bGVTYW1lQXNQcm9taXNlXz1mdW5jdGlvbihmKXt2YXIgcT10aGlzLmNyZWF0ZVJlc29sdmVBbmRSZWplY3RfKCk7CmYuY2FsbFdoZW5TZXR0bGVkXyhxLnJlc29sdmUscS5yZWplY3QpfTtsLnByb3RvdHlwZS5zZXR0bGVTYW1lQXNUaGVuYWJsZV89ZnVuY3Rpb24oZixxKXt2YXIgdT10aGlzLmNyZWF0ZVJlc29sdmVBbmRSZWplY3RfKCk7dHJ5e2YuY2FsbChxLHUucmVzb2x2ZSx1LnJlamVjdCl9Y2F0Y2goQSl7dS5yZWplY3QoQSl9fTtsLnByb3RvdHlwZS50aGVuPWZ1bmN0aW9uKGYscSl7ZnVuY3Rpb24gdSh3LEIpe3JldHVybiJmdW5jdGlvbiI9PXR5cGVvZiB3P2Z1bmN0aW9uKFIpe3RyeXtBKHcoUikpfWNhdGNoKFope0YoWil9fTpCfXZhciBBLEYsdj1uZXcgbChmdW5jdGlvbih3LEIpe0E9dztGPUJ9KTt0aGlzLmNhbGxXaGVuU2V0dGxlZF8odShmLEEpLHUocSxGKSk7cmV0dXJuIHZ9O2wucHJvdG90eXBlLmNhdGNoPWZ1bmN0aW9uKGYpe3JldHVybiB0aGlzLnRoZW4odm9pZCAwLGYpfTtsLnByb3RvdHlwZS5jYWxsV2hlblNldHRsZWRfPWZ1bmN0aW9uKGYscSl7ZnVuY3Rpb24gdSgpe3N3aXRjaChBLnN0YXRlXyl7Y2FzZSAxOmYoQS5yZXN1bHRfKTsKYnJlYWs7Y2FzZSAyOnEoQS5yZXN1bHRfKTticmVhaztkZWZhdWx0OnRocm93IEVycm9yKCJVbmV4cGVjdGVkIHN0YXRlOiAiK0Euc3RhdGVfKTt9fXZhciBBPXRoaXM7bnVsbD09dGhpcy5vblNldHRsZWRDYWxsYmFja3NfP3kuYXN5bmNFeGVjdXRlKHUpOnRoaXMub25TZXR0bGVkQ2FsbGJhY2tzXy5wdXNoKHUpO3RoaXMuaXNSZWplY3Rpb25IYW5kbGVkXz0hMH07bC5yZXNvbHZlPWs7bC5yZWplY3Q9ZnVuY3Rpb24oZil7cmV0dXJuIG5ldyBsKGZ1bmN0aW9uKHEsdSl7dShmKX0pfTtsLnJhY2U9ZnVuY3Rpb24oZil7cmV0dXJuIG5ldyBsKGZ1bmN0aW9uKHEsdSl7Zm9yKHZhciBBPSRqc2NvbXAubWFrZUl0ZXJhdG9yKGYpLEY9QS5uZXh0KCk7IUYuZG9uZTtGPUEubmV4dCgpKWsoRi52YWx1ZSkuY2FsbFdoZW5TZXR0bGVkXyhxLHUpfSl9O2wuYWxsPWZ1bmN0aW9uKGYpe3ZhciBxPSRqc2NvbXAubWFrZUl0ZXJhdG9yKGYpLHU9cS5uZXh0KCk7cmV0dXJuIHUuZG9uZT9rKFtdKTpuZXcgbChmdW5jdGlvbihBLApGKXtmdW5jdGlvbiB2KFIpe3JldHVybiBmdW5jdGlvbihaKXt3W1JdPVo7Qi0tOzA9PUImJkEodyl9fXZhciB3PVtdLEI9MDtkbyB3LnB1c2godm9pZCAwKSxCKyssayh1LnZhbHVlKS5jYWxsV2hlblNldHRsZWRfKHYody5sZW5ndGgtMSksRiksdT1xLm5leHQoKTt3aGlsZSghdS5kb25lKX0pfTtyZXR1cm4gbH0sImVzNiIsImVzMyIpOyRqc2NvbXAub3ducz1mdW5jdGlvbihoLG4pe3JldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoaCxuKX07JGpzY29tcC5hc3NpZ249JGpzY29tcC5UUlVTVF9FUzZfUE9MWUZJTExTJiYiZnVuY3Rpb24iPT10eXBlb2YgT2JqZWN0LmFzc2lnbj9PYmplY3QuYXNzaWduOmZ1bmN0aW9uKGgsbil7Zm9yKHZhciBrPTE7azxhcmd1bWVudHMubGVuZ3RoO2srKyl7dmFyIHA9YXJndW1lbnRzW2tdO2lmKHApZm9yKHZhciBsIGluIHApJGpzY29tcC5vd25zKHAsbCkmJihoW2xdPXBbbF0pfXJldHVybiBofTsKJGpzY29tcC5wb2x5ZmlsbCgiT2JqZWN0LmFzc2lnbiIsZnVuY3Rpb24oaCl7cmV0dXJuIGh8fCRqc2NvbXAuYXNzaWdufSwiZXM2IiwiZXMzIik7JGpzY29tcC5jaGVja1N0cmluZ0FyZ3M9ZnVuY3Rpb24oaCxuLGspe2lmKG51bGw9PWgpdGhyb3cgbmV3IFR5cGVFcnJvcigiVGhlICd0aGlzJyB2YWx1ZSBmb3IgU3RyaW5nLnByb3RvdHlwZS4iK2srIiBtdXN0IG5vdCBiZSBudWxsIG9yIHVuZGVmaW5lZCIpO2lmKG4gaW5zdGFuY2VvZiBSZWdFeHApdGhyb3cgbmV3IFR5cGVFcnJvcigiRmlyc3QgYXJndW1lbnQgdG8gU3RyaW5nLnByb3RvdHlwZS4iK2srIiBtdXN0IG5vdCBiZSBhIHJlZ3VsYXIgZXhwcmVzc2lvbiIpO3JldHVybiBoKyIifTsKJGpzY29tcC5wb2x5ZmlsbCgiU3RyaW5nLnByb3RvdHlwZS5zdGFydHNXaXRoIixmdW5jdGlvbihoKXtyZXR1cm4gaD9oOmZ1bmN0aW9uKG4sayl7dmFyIHA9JGpzY29tcC5jaGVja1N0cmluZ0FyZ3ModGhpcyxuLCJzdGFydHNXaXRoIik7bis9IiI7dmFyIGw9cC5sZW5ndGgseT1uLmxlbmd0aDtrPU1hdGgubWF4KDAsTWF0aC5taW4oa3wwLHAubGVuZ3RoKSk7Zm9yKHZhciBmPTA7Zjx5JiZrPGw7KWlmKHBbaysrXSE9bltmKytdKXJldHVybiExO3JldHVybiBmPj15fX0sImVzNiIsImVzMyIpOwokanNjb21wLnBvbHlmaWxsKCJBcnJheS5wcm90b3R5cGUuY29weVdpdGhpbiIsZnVuY3Rpb24oaCl7ZnVuY3Rpb24gbihrKXtrPU51bWJlcihrKTtyZXR1cm4gSW5maW5pdHk9PT1rfHwtSW5maW5pdHk9PT1rP2s6a3wwfXJldHVybiBoP2g6ZnVuY3Rpb24oayxwLGwpe3ZhciB5PXRoaXMubGVuZ3RoO2s9bihrKTtwPW4ocCk7bD12b2lkIDA9PT1sP3k6bihsKTtrPTA+az9NYXRoLm1heCh5K2ssMCk6TWF0aC5taW4oayx5KTtwPTA+cD9NYXRoLm1heCh5K3AsMCk6TWF0aC5taW4ocCx5KTtsPTA+bD9NYXRoLm1heCh5K2wsMCk6TWF0aC5taW4obCx5KTtpZihrPHApZm9yKDtwPGw7KXAgaW4gdGhpcz90aGlzW2srK109dGhpc1twKytdOihkZWxldGUgdGhpc1trKytdLHArKyk7ZWxzZSBmb3IobD1NYXRoLm1pbihsLHkrcC1rKSxrKz1sLXA7bD5wOyktLWwgaW4gdGhpcz90aGlzWy0ta109dGhpc1tsXTpkZWxldGUgdGhpc1stLWtdO3JldHVybiB0aGlzfX0sImVzNiIsImVzMyIpOwokanNjb21wLnR5cGVkQXJyYXlDb3B5V2l0aGluPWZ1bmN0aW9uKGgpe3JldHVybiBoP2g6QXJyYXkucHJvdG90eXBlLmNvcHlXaXRoaW59OyRqc2NvbXAucG9seWZpbGwoIkludDhBcnJheS5wcm90b3R5cGUuY29weVdpdGhpbiIsJGpzY29tcC50eXBlZEFycmF5Q29weVdpdGhpbiwiZXM2IiwiZXM1Iik7JGpzY29tcC5wb2x5ZmlsbCgiVWludDhBcnJheS5wcm90b3R5cGUuY29weVdpdGhpbiIsJGpzY29tcC50eXBlZEFycmF5Q29weVdpdGhpbiwiZXM2IiwiZXM1Iik7JGpzY29tcC5wb2x5ZmlsbCgiVWludDhDbGFtcGVkQXJyYXkucHJvdG90eXBlLmNvcHlXaXRoaW4iLCRqc2NvbXAudHlwZWRBcnJheUNvcHlXaXRoaW4sImVzNiIsImVzNSIpOyRqc2NvbXAucG9seWZpbGwoIkludDE2QXJyYXkucHJvdG90eXBlLmNvcHlXaXRoaW4iLCRqc2NvbXAudHlwZWRBcnJheUNvcHlXaXRoaW4sImVzNiIsImVzNSIpOwokanNjb21wLnBvbHlmaWxsKCJVaW50MTZBcnJheS5wcm90b3R5cGUuY29weVdpdGhpbiIsJGpzY29tcC50eXBlZEFycmF5Q29weVdpdGhpbiwiZXM2IiwiZXM1Iik7JGpzY29tcC5wb2x5ZmlsbCgiSW50MzJBcnJheS5wcm90b3R5cGUuY29weVdpdGhpbiIsJGpzY29tcC50eXBlZEFycmF5Q29weVdpdGhpbiwiZXM2IiwiZXM1Iik7JGpzY29tcC5wb2x5ZmlsbCgiVWludDMyQXJyYXkucHJvdG90eXBlLmNvcHlXaXRoaW4iLCRqc2NvbXAudHlwZWRBcnJheUNvcHlXaXRoaW4sImVzNiIsImVzNSIpOyRqc2NvbXAucG9seWZpbGwoIkZsb2F0MzJBcnJheS5wcm90b3R5cGUuY29weVdpdGhpbiIsJGpzY29tcC50eXBlZEFycmF5Q29weVdpdGhpbiwiZXM2IiwiZXM1Iik7JGpzY29tcC5wb2x5ZmlsbCgiRmxvYXQ2NEFycmF5LnByb3RvdHlwZS5jb3B5V2l0aGluIiwkanNjb21wLnR5cGVkQXJyYXlDb3B5V2l0aGluLCJlczYiLCJlczUiKTsKdmFyIERyYWNvRGVjb2Rlck1vZHVsZT1mdW5jdGlvbigpe3ZhciBoPSJ1bmRlZmluZWQiIT09dHlwZW9mIGRvY3VtZW50JiZkb2N1bWVudC5jdXJyZW50U2NyaXB0P2RvY3VtZW50LmN1cnJlbnRTY3JpcHQuc3JjOnZvaWQgMDsidW5kZWZpbmVkIiE9PXR5cGVvZiBfX2ZpbGVuYW1lJiYoaD1ofHxfX2ZpbGVuYW1lKTtyZXR1cm4gZnVuY3Rpb24obil7ZnVuY3Rpb24gayhlKXtyZXR1cm4gYS5sb2NhdGVGaWxlP2EubG9jYXRlRmlsZShlLFUpOlUrZX1mdW5jdGlvbiBwKGUsYil7aWYoZSl7dmFyIGM9aWE7dmFyIGQ9ZStiO2ZvcihiPWU7Y1tiXSYmIShiPj1kKTspKytiO2lmKDE2PGItZSYmYy5idWZmZXImJnJhKWM9cmEuZGVjb2RlKGMuc3ViYXJyYXkoZSxiKSk7ZWxzZXtmb3IoZD0iIjtlPGI7KXt2YXIgZz1jW2UrK107aWYoZyYxMjgpe3ZhciB0PWNbZSsrXSY2MztpZigxOTI9PShnJjIyNCkpZCs9U3RyaW5nLmZyb21DaGFyQ29kZSgoZyYzMSk8PDZ8dCk7ZWxzZXt2YXIgYWE9Y1tlKytdJgo2MztnPTIyND09KGcmMjQwKT8oZyYxNSk8PDEyfHQ8PDZ8YWE6KGcmNyk8PDE4fHQ8PDEyfGFhPDw2fGNbZSsrXSY2Mzs2NTUzNj5nP2QrPVN0cmluZy5mcm9tQ2hhckNvZGUoZyk6KGctPTY1NTM2LGQrPVN0cmluZy5mcm9tQ2hhckNvZGUoNTUyOTZ8Zz4+MTAsNTYzMjB8ZyYxMDIzKSl9fWVsc2UgZCs9U3RyaW5nLmZyb21DaGFyQ29kZShnKX1jPWR9fWVsc2UgYz0iIjtyZXR1cm4gY31mdW5jdGlvbiBsKCl7dmFyIGU9amEuYnVmZmVyO2EuSEVBUDg9Vz1uZXcgSW50OEFycmF5KGUpO2EuSEVBUDE2PW5ldyBJbnQxNkFycmF5KGUpO2EuSEVBUDMyPWNhPW5ldyBJbnQzMkFycmF5KGUpO2EuSEVBUFU4PWlhPW5ldyBVaW50OEFycmF5KGUpO2EuSEVBUFUxNj1uZXcgVWludDE2QXJyYXkoZSk7YS5IRUFQVTMyPVk9bmV3IFVpbnQzMkFycmF5KGUpO2EuSEVBUEYzMj1uZXcgRmxvYXQzMkFycmF5KGUpO2EuSEVBUEY2ND1uZXcgRmxvYXQ2NEFycmF5KGUpfWZ1bmN0aW9uIHkoZSl7aWYoYS5vbkFib3J0KWEub25BYm9ydChlKTsKZT0iQWJvcnRlZCgiK2UrIikiO2RhKGUpO3NhPSEwO2U9bmV3IFdlYkFzc2VtYmx5LlJ1bnRpbWVFcnJvcihlKyIuIEJ1aWxkIHdpdGggLXNBU1NFUlRJT05TIGZvciBtb3JlIGluZm8uIik7a2EoZSk7dGhyb3cgZTt9ZnVuY3Rpb24gZihlKXt0cnl7aWYoZT09UCYmZWEpcmV0dXJuIG5ldyBVaW50OEFycmF5KGVhKTtpZihtYSlyZXR1cm4gbWEoZSk7dGhyb3ciYm90aCBhc3luYyBhbmQgc3luYyBmZXRjaGluZyBvZiB0aGUgd2FzbSBmYWlsZWQiO31jYXRjaChiKXt5KGIpfX1mdW5jdGlvbiBxKCl7aWYoIWVhJiYodGF8fGZhKSl7aWYoImZ1bmN0aW9uIj09dHlwZW9mIGZldGNoJiYhUC5zdGFydHNXaXRoKCJmaWxlOi8vIikpcmV0dXJuIGZldGNoKFAse2NyZWRlbnRpYWxzOiJzYW1lLW9yaWdpbiJ9KS50aGVuKGZ1bmN0aW9uKGUpe2lmKCFlLm9rKXRocm93ImZhaWxlZCB0byBsb2FkIHdhc20gYmluYXJ5IGZpbGUgYXQgJyIrUCsiJyI7cmV0dXJuIGUuYXJyYXlCdWZmZXIoKX0pLmNhdGNoKGZ1bmN0aW9uKCl7cmV0dXJuIGYoUCl9KTsKaWYobmEpcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uKGUsYil7bmEoUCxmdW5jdGlvbihjKXtlKG5ldyBVaW50OEFycmF5KGMpKX0sYil9KX1yZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCkudGhlbihmdW5jdGlvbigpe3JldHVybiBmKFApfSl9ZnVuY3Rpb24gdShlKXtmb3IoOzA8ZS5sZW5ndGg7KWUuc2hpZnQoKShhKX1mdW5jdGlvbiBBKGUpe3RoaXMuZXhjUHRyPWU7dGhpcy5wdHI9ZS0yNDt0aGlzLnNldF90eXBlPWZ1bmN0aW9uKGIpe1lbdGhpcy5wdHIrND4+Ml09Yn07dGhpcy5nZXRfdHlwZT1mdW5jdGlvbigpe3JldHVybiBZW3RoaXMucHRyKzQ+PjJdfTt0aGlzLnNldF9kZXN0cnVjdG9yPWZ1bmN0aW9uKGIpe1lbdGhpcy5wdHIrOD4+Ml09Yn07dGhpcy5nZXRfZGVzdHJ1Y3Rvcj1mdW5jdGlvbigpe3JldHVybiBZW3RoaXMucHRyKzg+PjJdfTt0aGlzLnNldF9yZWZjb3VudD1mdW5jdGlvbihiKXtjYVt0aGlzLnB0cj4+Ml09Yn07dGhpcy5zZXRfY2F1Z2h0PWZ1bmN0aW9uKGIpe1dbdGhpcy5wdHIrCjEyPj4wXT1iPzE6MH07dGhpcy5nZXRfY2F1Z2h0PWZ1bmN0aW9uKCl7cmV0dXJuIDAhPVdbdGhpcy5wdHIrMTI+PjBdfTt0aGlzLnNldF9yZXRocm93bj1mdW5jdGlvbihiKXtXW3RoaXMucHRyKzEzPj4wXT1iPzE6MH07dGhpcy5nZXRfcmV0aHJvd249ZnVuY3Rpb24oKXtyZXR1cm4gMCE9V1t0aGlzLnB0cisxMz4+MF19O3RoaXMuaW5pdD1mdW5jdGlvbihiLGMpe3RoaXMuc2V0X2FkanVzdGVkX3B0cigwKTt0aGlzLnNldF90eXBlKGIpO3RoaXMuc2V0X2Rlc3RydWN0b3IoYyk7dGhpcy5zZXRfcmVmY291bnQoMCk7dGhpcy5zZXRfY2F1Z2h0KCExKTt0aGlzLnNldF9yZXRocm93bighMSl9O3RoaXMuYWRkX3JlZj1mdW5jdGlvbigpe2NhW3RoaXMucHRyPj4yXSs9MX07dGhpcy5yZWxlYXNlX3JlZj1mdW5jdGlvbigpe3ZhciBiPWNhW3RoaXMucHRyPj4yXTtjYVt0aGlzLnB0cj4+Ml09Yi0xO3JldHVybiAxPT09Yn07dGhpcy5zZXRfYWRqdXN0ZWRfcHRyPWZ1bmN0aW9uKGIpe1lbdGhpcy5wdHIrCjE2Pj4yXT1ifTt0aGlzLmdldF9hZGp1c3RlZF9wdHI9ZnVuY3Rpb24oKXtyZXR1cm4gWVt0aGlzLnB0cisxNj4+Ml19O3RoaXMuZ2V0X2V4Y2VwdGlvbl9wdHI9ZnVuY3Rpb24oKXtpZih1YSh0aGlzLmdldF90eXBlKCkpKXJldHVybiBZW3RoaXMuZXhjUHRyPj4yXTt2YXIgYj10aGlzLmdldF9hZGp1c3RlZF9wdHIoKTtyZXR1cm4gMCE9PWI/Yjp0aGlzLmV4Y1B0cn19ZnVuY3Rpb24gRigpe2Z1bmN0aW9uIGUoKXtpZighbGEmJihsYT0hMCxhLmNhbGxlZFJ1bj0hMCwhc2EpKXt2YT0hMDt1KG9hKTt3YShhKTtpZihhLm9uUnVudGltZUluaXRpYWxpemVkKWEub25SdW50aW1lSW5pdGlhbGl6ZWQoKTtpZihhLnBvc3RSdW4pZm9yKCJmdW5jdGlvbiI9PXR5cGVvZiBhLnBvc3RSdW4mJihhLnBvc3RSdW49W2EucG9zdFJ1bl0pO2EucG9zdFJ1bi5sZW5ndGg7KXhhLnVuc2hpZnQoYS5wb3N0UnVuLnNoaWZ0KCkpO3UoeGEpfX1pZighKDA8YmEpKXtpZihhLnByZVJ1bilmb3IoImZ1bmN0aW9uIj09CnR5cGVvZiBhLnByZVJ1biYmKGEucHJlUnVuPVthLnByZVJ1bl0pO2EucHJlUnVuLmxlbmd0aDspeWEudW5zaGlmdChhLnByZVJ1bi5zaGlmdCgpKTt1KHlhKTswPGJhfHwoYS5zZXRTdGF0dXM/KGEuc2V0U3RhdHVzKCJSdW5uaW5nLi4uIiksc2V0VGltZW91dChmdW5jdGlvbigpe3NldFRpbWVvdXQoZnVuY3Rpb24oKXthLnNldFN0YXR1cygiIil9LDEpO2UoKX0sMSkpOmUoKSl9fWZ1bmN0aW9uIHYoKXt9ZnVuY3Rpb24gdyhlKXtyZXR1cm4oZXx8dikuX19jYWNoZV9ffWZ1bmN0aW9uIEIoZSxiKXt2YXIgYz13KGIpLGQ9Y1tlXTtpZihkKXJldHVybiBkO2Q9T2JqZWN0LmNyZWF0ZSgoYnx8dikucHJvdG90eXBlKTtkLnB0cj1lO3JldHVybiBjW2VdPWR9ZnVuY3Rpb24gUihlKXtpZigic3RyaW5nIj09PXR5cGVvZiBlKXtmb3IodmFyIGI9MCxjPTA7YzxlLmxlbmd0aDsrK2Mpe3ZhciBkPWUuY2hhckNvZGVBdChjKTsxMjc+PWQ/YisrOjIwNDc+PWQ/Yis9Mjo1NTI5Njw9ZCYmNTczNDM+PQpkPyhiKz00LCsrYyk6Yis9M31iPUFycmF5KGIrMSk7Yz0wO2Q9Yi5sZW5ndGg7aWYoMDxkKXtkPWMrZC0xO2Zvcih2YXIgZz0wO2c8ZS5sZW5ndGg7KytnKXt2YXIgdD1lLmNoYXJDb2RlQXQoZyk7aWYoNTUyOTY8PXQmJjU3MzQzPj10KXt2YXIgYWE9ZS5jaGFyQ29kZUF0KCsrZyk7dD02NTUzNisoKHQmMTAyMyk8PDEwKXxhYSYxMDIzfWlmKDEyNz49dCl7aWYoYz49ZClicmVhaztiW2MrK109dH1lbHNle2lmKDIwNDc+PXQpe2lmKGMrMT49ZClicmVhaztiW2MrK109MTkyfHQ+PjZ9ZWxzZXtpZig2NTUzNT49dCl7aWYoYysyPj1kKWJyZWFrO2JbYysrXT0yMjR8dD4+MTJ9ZWxzZXtpZihjKzM+PWQpYnJlYWs7YltjKytdPTI0MHx0Pj4xODtiW2MrK109MTI4fHQ+PjEyJjYzfWJbYysrXT0xMjh8dD4+NiY2M31iW2MrK109MTI4fHQmNjN9fWJbY109MH1lPXIuYWxsb2MoYixXKTtyLmNvcHkoYixXLGUpO3JldHVybiBlfXJldHVybiBlfWZ1bmN0aW9uIFooZSl7aWYoIm9iamVjdCI9PT0KdHlwZW9mIGUpe3ZhciBiPXIuYWxsb2MoZSxXKTtyLmNvcHkoZSxXLGIpO3JldHVybiBifXJldHVybiBlfWZ1bmN0aW9uIFgoKXt0aHJvdyJjYW5ub3QgY29uc3RydWN0IGEgVm9pZFB0ciwgbm8gY29uc3RydWN0b3IgaW4gSURMIjt9ZnVuY3Rpb24gUygpe3RoaXMucHRyPXphKCk7dyhTKVt0aGlzLnB0cl09dGhpc31mdW5jdGlvbiBRKCl7dGhpcy5wdHI9QWEoKTt3KFEpW3RoaXMucHRyXT10aGlzfWZ1bmN0aW9uIFYoKXt0aGlzLnB0cj1CYSgpO3coVilbdGhpcy5wdHJdPXRoaXN9ZnVuY3Rpb24geCgpe3RoaXMucHRyPUNhKCk7dyh4KVt0aGlzLnB0cl09dGhpc31mdW5jdGlvbiBEKCl7dGhpcy5wdHI9RGEoKTt3KEQpW3RoaXMucHRyXT10aGlzfWZ1bmN0aW9uIEcoKXt0aGlzLnB0cj1FYSgpO3coRylbdGhpcy5wdHJdPXRoaXN9ZnVuY3Rpb24gSCgpe3RoaXMucHRyPUZhKCk7dyhIKVt0aGlzLnB0cl09dGhpc31mdW5jdGlvbiBFKCl7dGhpcy5wdHI9R2EoKTt3KEUpW3RoaXMucHRyXT0KdGhpc31mdW5jdGlvbiBUKCl7dGhpcy5wdHI9SGEoKTt3KFQpW3RoaXMucHRyXT10aGlzfWZ1bmN0aW9uIEMoKXt0aHJvdyJjYW5ub3QgY29uc3RydWN0IGEgU3RhdHVzLCBubyBjb25zdHJ1Y3RvciBpbiBJREwiO31mdW5jdGlvbiBJKCl7dGhpcy5wdHI9SWEoKTt3KEkpW3RoaXMucHRyXT10aGlzfWZ1bmN0aW9uIEooKXt0aGlzLnB0cj1KYSgpO3coSilbdGhpcy5wdHJdPXRoaXN9ZnVuY3Rpb24gSygpe3RoaXMucHRyPUthKCk7dyhLKVt0aGlzLnB0cl09dGhpc31mdW5jdGlvbiBMKCl7dGhpcy5wdHI9TGEoKTt3KEwpW3RoaXMucHRyXT10aGlzfWZ1bmN0aW9uIE0oKXt0aGlzLnB0cj1NYSgpO3coTSlbdGhpcy5wdHJdPXRoaXN9ZnVuY3Rpb24gTigpe3RoaXMucHRyPU5hKCk7dyhOKVt0aGlzLnB0cl09dGhpc31mdW5jdGlvbiBPKCl7dGhpcy5wdHI9T2EoKTt3KE8pW3RoaXMucHRyXT10aGlzfWZ1bmN0aW9uIHooKXt0aGlzLnB0cj1QYSgpO3coeilbdGhpcy5wdHJdPXRoaXN9ZnVuY3Rpb24gbSgpe3RoaXMucHRyPQpRYSgpO3cobSlbdGhpcy5wdHJdPXRoaXN9bj12b2lkIDA9PT1uP3t9Om47dmFyIGE9InVuZGVmaW5lZCIhPXR5cGVvZiBuP246e30sd2Esa2E7YS5yZWFkeT1uZXcgUHJvbWlzZShmdW5jdGlvbihlLGIpe3dhPWU7a2E9Yn0pO3ZhciBSYT0hMSxTYT0hMTthLm9uUnVudGltZUluaXRpYWxpemVkPWZ1bmN0aW9uKCl7UmE9ITA7aWYoU2EmJiJmdW5jdGlvbiI9PT10eXBlb2YgYS5vbk1vZHVsZUxvYWRlZClhLm9uTW9kdWxlTG9hZGVkKGEpfTthLm9uTW9kdWxlUGFyc2VkPWZ1bmN0aW9uKCl7U2E9ITA7aWYoUmEmJiJmdW5jdGlvbiI9PT10eXBlb2YgYS5vbk1vZHVsZUxvYWRlZClhLm9uTW9kdWxlTG9hZGVkKGEpfTthLmlzVmVyc2lvblN1cHBvcnRlZD1mdW5jdGlvbihlKXtpZigic3RyaW5nIiE9PXR5cGVvZiBlKXJldHVybiExO2U9ZS5zcGxpdCgiLiIpO3JldHVybiAyPmUubGVuZ3RofHwzPGUubGVuZ3RoPyExOjE9PWVbMF0mJjA8PWVbMV0mJjU+PWVbMV0/ITA6MCE9ZVswXXx8MTA8CmVbMV0/ITE6ITB9O3ZhciBUYT1PYmplY3QuYXNzaWduKHt9LGEpLHRhPSJvYmplY3QiPT10eXBlb2Ygd2luZG93LGZhPSJmdW5jdGlvbiI9PXR5cGVvZiBpbXBvcnRTY3JpcHRzLFVhPSJvYmplY3QiPT10eXBlb2YgcHJvY2VzcyYmIm9iamVjdCI9PXR5cGVvZiBwcm9jZXNzLnZlcnNpb25zJiYic3RyaW5nIj09dHlwZW9mIHByb2Nlc3MudmVyc2lvbnMubm9kZSxVPSIiO2lmKFVhKXt2YXIgVmE9cmVxdWlyZSgiZnMiKSxwYT1yZXF1aXJlKCJwYXRoIik7VT1mYT9wYS5kaXJuYW1lKFUpKyIvIjpfX2Rpcm5hbWUrIi8iO3ZhciBXYT1mdW5jdGlvbihlLGIpe2U9ZS5zdGFydHNXaXRoKCJmaWxlOi8vIik/bmV3IFVSTChlKTpwYS5ub3JtYWxpemUoZSk7cmV0dXJuIFZhLnJlYWRGaWxlU3luYyhlLGI/dm9pZCAwOiJ1dGY4Iil9O3ZhciBtYT1mdW5jdGlvbihlKXtlPVdhKGUsITApO2UuYnVmZmVyfHwoZT1uZXcgVWludDhBcnJheShlKSk7cmV0dXJuIGV9O3ZhciBuYT1mdW5jdGlvbihlLApiLGMpe2U9ZS5zdGFydHNXaXRoKCJmaWxlOi8vIik/bmV3IFVSTChlKTpwYS5ub3JtYWxpemUoZSk7VmEucmVhZEZpbGUoZSxmdW5jdGlvbihkLGcpe2Q/YyhkKTpiKGcuYnVmZmVyKX0pfTsxPHByb2Nlc3MuYXJndi5sZW5ndGgmJnByb2Nlc3MuYXJndlsxXS5yZXBsYWNlKC9cXC9nLCIvIik7cHJvY2Vzcy5hcmd2LnNsaWNlKDIpO2EuaW5zcGVjdD1mdW5jdGlvbigpe3JldHVybiJbRW1zY3JpcHRlbiBNb2R1bGUgb2JqZWN0XSJ9fWVsc2UgaWYodGF8fGZhKWZhP1U9c2VsZi5sb2NhdGlvbi5ocmVmOiJ1bmRlZmluZWQiIT10eXBlb2YgZG9jdW1lbnQmJmRvY3VtZW50LmN1cnJlbnRTY3JpcHQmJihVPWRvY3VtZW50LmN1cnJlbnRTY3JpcHQuc3JjKSxoJiYoVT1oKSxVPTAhPT1VLmluZGV4T2YoImJsb2I6Iik/VS5zdWJzdHIoMCxVLnJlcGxhY2UoL1s/I10uKi8sIiIpLmxhc3RJbmRleE9mKCIvIikrMSk6IiIsV2E9ZnVuY3Rpb24oZSl7dmFyIGI9bmV3IFhNTEh0dHBSZXF1ZXN0O2Iub3BlbigiR0VUIiwKZSwhMSk7Yi5zZW5kKG51bGwpO3JldHVybiBiLnJlc3BvbnNlVGV4dH0sZmEmJihtYT1mdW5jdGlvbihlKXt2YXIgYj1uZXcgWE1MSHR0cFJlcXVlc3Q7Yi5vcGVuKCJHRVQiLGUsITEpO2IucmVzcG9uc2VUeXBlPSJhcnJheWJ1ZmZlciI7Yi5zZW5kKG51bGwpO3JldHVybiBuZXcgVWludDhBcnJheShiLnJlc3BvbnNlKX0pLG5hPWZ1bmN0aW9uKGUsYixjKXt2YXIgZD1uZXcgWE1MSHR0cFJlcXVlc3Q7ZC5vcGVuKCJHRVQiLGUsITApO2QucmVzcG9uc2VUeXBlPSJhcnJheWJ1ZmZlciI7ZC5vbmxvYWQ9ZnVuY3Rpb24oKXsyMDA9PWQuc3RhdHVzfHwwPT1kLnN0YXR1cyYmZC5yZXNwb25zZT9iKGQucmVzcG9uc2UpOmMoKX07ZC5vbmVycm9yPWM7ZC5zZW5kKG51bGwpfTthLnByaW50fHxjb25zb2xlLmxvZy5iaW5kKGNvbnNvbGUpO3ZhciBkYT1hLnByaW50RXJyfHxjb25zb2xlLndhcm4uYmluZChjb25zb2xlKTtPYmplY3QuYXNzaWduKGEsVGEpO1RhPW51bGw7dmFyIGVhO2Eud2FzbUJpbmFyeSYmCihlYT1hLndhc21CaW5hcnkpOyJvYmplY3QiIT10eXBlb2YgV2ViQXNzZW1ibHkmJnkoIm5vIG5hdGl2ZSB3YXNtIHN1cHBvcnQgZGV0ZWN0ZWQiKTt2YXIgamEsc2E9ITEscmE9InVuZGVmaW5lZCIhPXR5cGVvZiBUZXh0RGVjb2Rlcj9uZXcgVGV4dERlY29kZXIoInV0ZjgiKTp2b2lkIDAsVyxpYSxjYSxZLHlhPVtdLG9hPVtdLHhhPVtdLHZhPSExLGJhPTAscWE9bnVsbCxoYT1udWxsO3ZhciBQPSJkcmFjb19kZWNvZGVyX2dsdGYud2FzbSI7UC5zdGFydHNXaXRoKCJkYXRhOmFwcGxpY2F0aW9uL29jdGV0LXN0cmVhbTtiYXNlNjQsIil8fChQPWsoUCkpO3ZhciBwZD0wLHFkPXtiOmZ1bmN0aW9uKGUsYixjKXsobmV3IEEoZSkpLmluaXQoYixjKTtwZCsrO3Rocm93IGU7fSxhOmZ1bmN0aW9uKCl7eSgiIil9LGQ6ZnVuY3Rpb24oZSxiLGMpe2lhLmNvcHlXaXRoaW4oZSxiLGIrYyl9LGM6ZnVuY3Rpb24oZSl7dmFyIGI9aWEubGVuZ3RoO2U+Pj49MDtpZigyMTQ3NDgzNjQ4PGUpcmV0dXJuITE7CmZvcih2YXIgYz0xOzQ+PWM7Yyo9Mil7dmFyIGQ9YiooMSsuMi9jKTtkPU1hdGgubWluKGQsZSsxMDA2NjMyOTYpO3ZhciBnPU1hdGg7ZD1NYXRoLm1heChlLGQpO2c9Zy5taW4uY2FsbChnLDIxNDc0ODM2NDgsZCsoNjU1MzYtZCU2NTUzNiklNjU1MzYpO2E6e2Q9amEuYnVmZmVyO3RyeXtqYS5ncm93KGctZC5ieXRlTGVuZ3RoKzY1NTM1Pj4+MTYpO2woKTt2YXIgdD0xO2JyZWFrIGF9Y2F0Y2goYWEpe310PXZvaWQgMH1pZih0KXJldHVybiEwfXJldHVybiExfX07KGZ1bmN0aW9uKCl7ZnVuY3Rpb24gZShnLHQpe2EuYXNtPWcuZXhwb3J0cztqYT1hLmFzbS5lO2woKTtvYS51bnNoaWZ0KGEuYXNtLmYpO2JhLS07YS5tb25pdG9yUnVuRGVwZW5kZW5jaWVzJiZhLm1vbml0b3JSdW5EZXBlbmRlbmNpZXMoYmEpOzA9PWJhJiYobnVsbCE9PXFhJiYoY2xlYXJJbnRlcnZhbChxYSkscWE9bnVsbCksaGEmJihnPWhhLGhhPW51bGwsZygpKSl9ZnVuY3Rpb24gYihnKXtlKGcuaW5zdGFuY2UpfQpmdW5jdGlvbiBjKGcpe3JldHVybiBxKCkudGhlbihmdW5jdGlvbih0KXtyZXR1cm4gV2ViQXNzZW1ibHkuaW5zdGFudGlhdGUodCxkKX0pLnRoZW4oZnVuY3Rpb24odCl7cmV0dXJuIHR9KS50aGVuKGcsZnVuY3Rpb24odCl7ZGEoImZhaWxlZCB0byBhc3luY2hyb25vdXNseSBwcmVwYXJlIHdhc206ICIrdCk7eSh0KX0pfXZhciBkPXthOnFkfTtiYSsrO2EubW9uaXRvclJ1bkRlcGVuZGVuY2llcyYmYS5tb25pdG9yUnVuRGVwZW5kZW5jaWVzKGJhKTtpZihhLmluc3RhbnRpYXRlV2FzbSl0cnl7cmV0dXJuIGEuaW5zdGFudGlhdGVXYXNtKGQsZSl9Y2F0Y2goZyl7ZGEoIk1vZHVsZS5pbnN0YW50aWF0ZVdhc20gY2FsbGJhY2sgZmFpbGVkIHdpdGggZXJyb3I6ICIrZyksa2EoZyl9KGZ1bmN0aW9uKCl7cmV0dXJuIGVhfHwiZnVuY3Rpb24iIT10eXBlb2YgV2ViQXNzZW1ibHkuaW5zdGFudGlhdGVTdHJlYW1pbmd8fFAuc3RhcnRzV2l0aCgiZGF0YTphcHBsaWNhdGlvbi9vY3RldC1zdHJlYW07YmFzZTY0LCIpfHwKUC5zdGFydHNXaXRoKCJmaWxlOi8vIil8fFVhfHwiZnVuY3Rpb24iIT10eXBlb2YgZmV0Y2g/YyhiKTpmZXRjaChQLHtjcmVkZW50aWFsczoic2FtZS1vcmlnaW4ifSkudGhlbihmdW5jdGlvbihnKXtyZXR1cm4gV2ViQXNzZW1ibHkuaW5zdGFudGlhdGVTdHJlYW1pbmcoZyxkKS50aGVuKGIsZnVuY3Rpb24odCl7ZGEoIndhc20gc3RyZWFtaW5nIGNvbXBpbGUgZmFpbGVkOiAiK3QpO2RhKCJmYWxsaW5nIGJhY2sgdG8gQXJyYXlCdWZmZXIgaW5zdGFudGlhdGlvbiIpO3JldHVybiBjKGIpfSl9KX0pKCkuY2F0Y2goa2EpO3JldHVybnt9fSkoKTt2YXIgWGE9YS5fZW1zY3JpcHRlbl9iaW5kX1ZvaWRQdHJfX19kZXN0cm95X19fMD1mdW5jdGlvbigpe3JldHVybihYYT1hLl9lbXNjcmlwdGVuX2JpbmRfVm9pZFB0cl9fX2Rlc3Ryb3lfX18wPWEuYXNtLmgpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0semE9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJCdWZmZXJfRGVjb2RlckJ1ZmZlcl8wPQpmdW5jdGlvbigpe3JldHVybih6YT1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2RlckJ1ZmZlcl9EZWNvZGVyQnVmZmVyXzA9YS5hc20uaSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxZYT1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2RlckJ1ZmZlcl9Jbml0XzI9ZnVuY3Rpb24oKXtyZXR1cm4oWWE9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJCdWZmZXJfSW5pdF8yPWEuYXNtLmopLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sWmE9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJCdWZmZXJfX19kZXN0cm95X19fMD1mdW5jdGlvbigpe3JldHVybihaYT1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2RlckJ1ZmZlcl9fX2Rlc3Ryb3lfX18wPWEuYXNtLmspLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sQWE9YS5fZW1zY3JpcHRlbl9iaW5kX0F0dHJpYnV0ZVRyYW5zZm9ybURhdGFfQXR0cmlidXRlVHJhbnNmb3JtRGF0YV8wPWZ1bmN0aW9uKCl7cmV0dXJuKEFhPWEuX2Vtc2NyaXB0ZW5fYmluZF9BdHRyaWJ1dGVUcmFuc2Zvcm1EYXRhX0F0dHJpYnV0ZVRyYW5zZm9ybURhdGFfMD0KYS5hc20ubCkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSwkYT1hLl9lbXNjcmlwdGVuX2JpbmRfQXR0cmlidXRlVHJhbnNmb3JtRGF0YV90cmFuc2Zvcm1fdHlwZV8wPWZ1bmN0aW9uKCl7cmV0dXJuKCRhPWEuX2Vtc2NyaXB0ZW5fYmluZF9BdHRyaWJ1dGVUcmFuc2Zvcm1EYXRhX3RyYW5zZm9ybV90eXBlXzA9YS5hc20ubSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxhYj1hLl9lbXNjcmlwdGVuX2JpbmRfQXR0cmlidXRlVHJhbnNmb3JtRGF0YV9fX2Rlc3Ryb3lfX18wPWZ1bmN0aW9uKCl7cmV0dXJuKGFiPWEuX2Vtc2NyaXB0ZW5fYmluZF9BdHRyaWJ1dGVUcmFuc2Zvcm1EYXRhX19fZGVzdHJveV9fXzA9YS5hc20ubikuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxCYT1hLl9lbXNjcmlwdGVuX2JpbmRfR2VvbWV0cnlBdHRyaWJ1dGVfR2VvbWV0cnlBdHRyaWJ1dGVfMD1mdW5jdGlvbigpe3JldHVybihCYT1hLl9lbXNjcmlwdGVuX2JpbmRfR2VvbWV0cnlBdHRyaWJ1dGVfR2VvbWV0cnlBdHRyaWJ1dGVfMD0KYS5hc20ubykuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxiYj1hLl9lbXNjcmlwdGVuX2JpbmRfR2VvbWV0cnlBdHRyaWJ1dGVfX19kZXN0cm95X19fMD1mdW5jdGlvbigpe3JldHVybihiYj1hLl9lbXNjcmlwdGVuX2JpbmRfR2VvbWV0cnlBdHRyaWJ1dGVfX19kZXN0cm95X19fMD1hLmFzbS5wKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LENhPWEuX2Vtc2NyaXB0ZW5fYmluZF9Qb2ludEF0dHJpYnV0ZV9Qb2ludEF0dHJpYnV0ZV8wPWZ1bmN0aW9uKCl7cmV0dXJuKENhPWEuX2Vtc2NyaXB0ZW5fYmluZF9Qb2ludEF0dHJpYnV0ZV9Qb2ludEF0dHJpYnV0ZV8wPWEuYXNtLnEpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sY2I9YS5fZW1zY3JpcHRlbl9iaW5kX1BvaW50QXR0cmlidXRlX3NpemVfMD1mdW5jdGlvbigpe3JldHVybihjYj1hLl9lbXNjcmlwdGVuX2JpbmRfUG9pbnRBdHRyaWJ1dGVfc2l6ZV8wPWEuYXNtLnIpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sZGI9YS5fZW1zY3JpcHRlbl9iaW5kX1BvaW50QXR0cmlidXRlX0dldEF0dHJpYnV0ZVRyYW5zZm9ybURhdGFfMD0KZnVuY3Rpb24oKXtyZXR1cm4oZGI9YS5fZW1zY3JpcHRlbl9iaW5kX1BvaW50QXR0cmlidXRlX0dldEF0dHJpYnV0ZVRyYW5zZm9ybURhdGFfMD1hLmFzbS5zKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LGViPWEuX2Vtc2NyaXB0ZW5fYmluZF9Qb2ludEF0dHJpYnV0ZV9hdHRyaWJ1dGVfdHlwZV8wPWZ1bmN0aW9uKCl7cmV0dXJuKGViPWEuX2Vtc2NyaXB0ZW5fYmluZF9Qb2ludEF0dHJpYnV0ZV9hdHRyaWJ1dGVfdHlwZV8wPWEuYXNtLnQpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sZmI9YS5fZW1zY3JpcHRlbl9iaW5kX1BvaW50QXR0cmlidXRlX2RhdGFfdHlwZV8wPWZ1bmN0aW9uKCl7cmV0dXJuKGZiPWEuX2Vtc2NyaXB0ZW5fYmluZF9Qb2ludEF0dHJpYnV0ZV9kYXRhX3R5cGVfMD1hLmFzbS51KS5hcHBseShudWxsLGFyZ3VtZW50cyl9LGdiPWEuX2Vtc2NyaXB0ZW5fYmluZF9Qb2ludEF0dHJpYnV0ZV9udW1fY29tcG9uZW50c18wPWZ1bmN0aW9uKCl7cmV0dXJuKGdiPWEuX2Vtc2NyaXB0ZW5fYmluZF9Qb2ludEF0dHJpYnV0ZV9udW1fY29tcG9uZW50c18wPQphLmFzbS52KS5hcHBseShudWxsLGFyZ3VtZW50cyl9LGhiPWEuX2Vtc2NyaXB0ZW5fYmluZF9Qb2ludEF0dHJpYnV0ZV9ub3JtYWxpemVkXzA9ZnVuY3Rpb24oKXtyZXR1cm4oaGI9YS5fZW1zY3JpcHRlbl9iaW5kX1BvaW50QXR0cmlidXRlX25vcm1hbGl6ZWRfMD1hLmFzbS53KS5hcHBseShudWxsLGFyZ3VtZW50cyl9LGliPWEuX2Vtc2NyaXB0ZW5fYmluZF9Qb2ludEF0dHJpYnV0ZV9ieXRlX3N0cmlkZV8wPWZ1bmN0aW9uKCl7cmV0dXJuKGliPWEuX2Vtc2NyaXB0ZW5fYmluZF9Qb2ludEF0dHJpYnV0ZV9ieXRlX3N0cmlkZV8wPWEuYXNtLngpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0samI9YS5fZW1zY3JpcHRlbl9iaW5kX1BvaW50QXR0cmlidXRlX2J5dGVfb2Zmc2V0XzA9ZnVuY3Rpb24oKXtyZXR1cm4oamI9YS5fZW1zY3JpcHRlbl9iaW5kX1BvaW50QXR0cmlidXRlX2J5dGVfb2Zmc2V0XzA9YS5hc20ueSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxrYj1hLl9lbXNjcmlwdGVuX2JpbmRfUG9pbnRBdHRyaWJ1dGVfdW5pcXVlX2lkXzA9CmZ1bmN0aW9uKCl7cmV0dXJuKGtiPWEuX2Vtc2NyaXB0ZW5fYmluZF9Qb2ludEF0dHJpYnV0ZV91bmlxdWVfaWRfMD1hLmFzbS56KS5hcHBseShudWxsLGFyZ3VtZW50cyl9LGxiPWEuX2Vtc2NyaXB0ZW5fYmluZF9Qb2ludEF0dHJpYnV0ZV9fX2Rlc3Ryb3lfX18wPWZ1bmN0aW9uKCl7cmV0dXJuKGxiPWEuX2Vtc2NyaXB0ZW5fYmluZF9Qb2ludEF0dHJpYnV0ZV9fX2Rlc3Ryb3lfX18wPWEuYXNtLkEpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sRGE9YS5fZW1zY3JpcHRlbl9iaW5kX0F0dHJpYnV0ZVF1YW50aXphdGlvblRyYW5zZm9ybV9BdHRyaWJ1dGVRdWFudGl6YXRpb25UcmFuc2Zvcm1fMD1mdW5jdGlvbigpe3JldHVybihEYT1hLl9lbXNjcmlwdGVuX2JpbmRfQXR0cmlidXRlUXVhbnRpemF0aW9uVHJhbnNmb3JtX0F0dHJpYnV0ZVF1YW50aXphdGlvblRyYW5zZm9ybV8wPWEuYXNtLkIpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sbWI9YS5fZW1zY3JpcHRlbl9iaW5kX0F0dHJpYnV0ZVF1YW50aXphdGlvblRyYW5zZm9ybV9Jbml0RnJvbUF0dHJpYnV0ZV8xPQpmdW5jdGlvbigpe3JldHVybihtYj1hLl9lbXNjcmlwdGVuX2JpbmRfQXR0cmlidXRlUXVhbnRpemF0aW9uVHJhbnNmb3JtX0luaXRGcm9tQXR0cmlidXRlXzE9YS5hc20uQykuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxuYj1hLl9lbXNjcmlwdGVuX2JpbmRfQXR0cmlidXRlUXVhbnRpemF0aW9uVHJhbnNmb3JtX3F1YW50aXphdGlvbl9iaXRzXzA9ZnVuY3Rpb24oKXtyZXR1cm4obmI9YS5fZW1zY3JpcHRlbl9iaW5kX0F0dHJpYnV0ZVF1YW50aXphdGlvblRyYW5zZm9ybV9xdWFudGl6YXRpb25fYml0c18wPWEuYXNtLkQpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sb2I9YS5fZW1zY3JpcHRlbl9iaW5kX0F0dHJpYnV0ZVF1YW50aXphdGlvblRyYW5zZm9ybV9taW5fdmFsdWVfMT1mdW5jdGlvbigpe3JldHVybihvYj1hLl9lbXNjcmlwdGVuX2JpbmRfQXR0cmlidXRlUXVhbnRpemF0aW9uVHJhbnNmb3JtX21pbl92YWx1ZV8xPWEuYXNtLkUpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0scGI9CmEuX2Vtc2NyaXB0ZW5fYmluZF9BdHRyaWJ1dGVRdWFudGl6YXRpb25UcmFuc2Zvcm1fcmFuZ2VfMD1mdW5jdGlvbigpe3JldHVybihwYj1hLl9lbXNjcmlwdGVuX2JpbmRfQXR0cmlidXRlUXVhbnRpemF0aW9uVHJhbnNmb3JtX3JhbmdlXzA9YS5hc20uRikuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxxYj1hLl9lbXNjcmlwdGVuX2JpbmRfQXR0cmlidXRlUXVhbnRpemF0aW9uVHJhbnNmb3JtX19fZGVzdHJveV9fXzA9ZnVuY3Rpb24oKXtyZXR1cm4ocWI9YS5fZW1zY3JpcHRlbl9iaW5kX0F0dHJpYnV0ZVF1YW50aXphdGlvblRyYW5zZm9ybV9fX2Rlc3Ryb3lfX18wPWEuYXNtLkcpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sRWE9YS5fZW1zY3JpcHRlbl9iaW5kX0F0dHJpYnV0ZU9jdGFoZWRyb25UcmFuc2Zvcm1fQXR0cmlidXRlT2N0YWhlZHJvblRyYW5zZm9ybV8wPWZ1bmN0aW9uKCl7cmV0dXJuKEVhPWEuX2Vtc2NyaXB0ZW5fYmluZF9BdHRyaWJ1dGVPY3RhaGVkcm9uVHJhbnNmb3JtX0F0dHJpYnV0ZU9jdGFoZWRyb25UcmFuc2Zvcm1fMD0KYS5hc20uSCkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxyYj1hLl9lbXNjcmlwdGVuX2JpbmRfQXR0cmlidXRlT2N0YWhlZHJvblRyYW5zZm9ybV9Jbml0RnJvbUF0dHJpYnV0ZV8xPWZ1bmN0aW9uKCl7cmV0dXJuKHJiPWEuX2Vtc2NyaXB0ZW5fYmluZF9BdHRyaWJ1dGVPY3RhaGVkcm9uVHJhbnNmb3JtX0luaXRGcm9tQXR0cmlidXRlXzE9YS5hc20uSSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxzYj1hLl9lbXNjcmlwdGVuX2JpbmRfQXR0cmlidXRlT2N0YWhlZHJvblRyYW5zZm9ybV9xdWFudGl6YXRpb25fYml0c18wPWZ1bmN0aW9uKCl7cmV0dXJuKHNiPWEuX2Vtc2NyaXB0ZW5fYmluZF9BdHRyaWJ1dGVPY3RhaGVkcm9uVHJhbnNmb3JtX3F1YW50aXphdGlvbl9iaXRzXzA9YS5hc20uSikuYXBwbHkobnVsbCxhcmd1bWVudHMpfSx0Yj1hLl9lbXNjcmlwdGVuX2JpbmRfQXR0cmlidXRlT2N0YWhlZHJvblRyYW5zZm9ybV9fX2Rlc3Ryb3lfX18wPWZ1bmN0aW9uKCl7cmV0dXJuKHRiPQphLl9lbXNjcmlwdGVuX2JpbmRfQXR0cmlidXRlT2N0YWhlZHJvblRyYW5zZm9ybV9fX2Rlc3Ryb3lfX18wPWEuYXNtLkspLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sRmE9YS5fZW1zY3JpcHRlbl9iaW5kX1BvaW50Q2xvdWRfUG9pbnRDbG91ZF8wPWZ1bmN0aW9uKCl7cmV0dXJuKEZhPWEuX2Vtc2NyaXB0ZW5fYmluZF9Qb2ludENsb3VkX1BvaW50Q2xvdWRfMD1hLmFzbS5MKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LHViPWEuX2Vtc2NyaXB0ZW5fYmluZF9Qb2ludENsb3VkX251bV9hdHRyaWJ1dGVzXzA9ZnVuY3Rpb24oKXtyZXR1cm4odWI9YS5fZW1zY3JpcHRlbl9iaW5kX1BvaW50Q2xvdWRfbnVtX2F0dHJpYnV0ZXNfMD1hLmFzbS5NKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LHZiPWEuX2Vtc2NyaXB0ZW5fYmluZF9Qb2ludENsb3VkX251bV9wb2ludHNfMD1mdW5jdGlvbigpe3JldHVybih2Yj1hLl9lbXNjcmlwdGVuX2JpbmRfUG9pbnRDbG91ZF9udW1fcG9pbnRzXzA9YS5hc20uTikuYXBwbHkobnVsbCwKYXJndW1lbnRzKX0sd2I9YS5fZW1zY3JpcHRlbl9iaW5kX1BvaW50Q2xvdWRfX19kZXN0cm95X19fMD1mdW5jdGlvbigpe3JldHVybih3Yj1hLl9lbXNjcmlwdGVuX2JpbmRfUG9pbnRDbG91ZF9fX2Rlc3Ryb3lfX18wPWEuYXNtLk8pLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sR2E9YS5fZW1zY3JpcHRlbl9iaW5kX01lc2hfTWVzaF8wPWZ1bmN0aW9uKCl7cmV0dXJuKEdhPWEuX2Vtc2NyaXB0ZW5fYmluZF9NZXNoX01lc2hfMD1hLmFzbS5QKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LHhiPWEuX2Vtc2NyaXB0ZW5fYmluZF9NZXNoX251bV9mYWNlc18wPWZ1bmN0aW9uKCl7cmV0dXJuKHhiPWEuX2Vtc2NyaXB0ZW5fYmluZF9NZXNoX251bV9mYWNlc18wPWEuYXNtLlEpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0seWI9YS5fZW1zY3JpcHRlbl9iaW5kX01lc2hfbnVtX2F0dHJpYnV0ZXNfMD1mdW5jdGlvbigpe3JldHVybih5Yj1hLl9lbXNjcmlwdGVuX2JpbmRfTWVzaF9udW1fYXR0cmlidXRlc18wPQphLmFzbS5SKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LHpiPWEuX2Vtc2NyaXB0ZW5fYmluZF9NZXNoX251bV9wb2ludHNfMD1mdW5jdGlvbigpe3JldHVybih6Yj1hLl9lbXNjcmlwdGVuX2JpbmRfTWVzaF9udW1fcG9pbnRzXzA9YS5hc20uUykuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxBYj1hLl9lbXNjcmlwdGVuX2JpbmRfTWVzaF9fX2Rlc3Ryb3lfX18wPWZ1bmN0aW9uKCl7cmV0dXJuKEFiPWEuX2Vtc2NyaXB0ZW5fYmluZF9NZXNoX19fZGVzdHJveV9fXzA9YS5hc20uVCkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxIYT1hLl9lbXNjcmlwdGVuX2JpbmRfTWV0YWRhdGFfTWV0YWRhdGFfMD1mdW5jdGlvbigpe3JldHVybihIYT1hLl9lbXNjcmlwdGVuX2JpbmRfTWV0YWRhdGFfTWV0YWRhdGFfMD1hLmFzbS5VKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LEJiPWEuX2Vtc2NyaXB0ZW5fYmluZF9NZXRhZGF0YV9fX2Rlc3Ryb3lfX18wPWZ1bmN0aW9uKCl7cmV0dXJuKEJiPWEuX2Vtc2NyaXB0ZW5fYmluZF9NZXRhZGF0YV9fX2Rlc3Ryb3lfX18wPQphLmFzbS5WKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LENiPWEuX2Vtc2NyaXB0ZW5fYmluZF9TdGF0dXNfY29kZV8wPWZ1bmN0aW9uKCl7cmV0dXJuKENiPWEuX2Vtc2NyaXB0ZW5fYmluZF9TdGF0dXNfY29kZV8wPWEuYXNtLlcpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sRGI9YS5fZW1zY3JpcHRlbl9iaW5kX1N0YXR1c19va18wPWZ1bmN0aW9uKCl7cmV0dXJuKERiPWEuX2Vtc2NyaXB0ZW5fYmluZF9TdGF0dXNfb2tfMD1hLmFzbS5YKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LEViPWEuX2Vtc2NyaXB0ZW5fYmluZF9TdGF0dXNfZXJyb3JfbXNnXzA9ZnVuY3Rpb24oKXtyZXR1cm4oRWI9YS5fZW1zY3JpcHRlbl9iaW5kX1N0YXR1c19lcnJvcl9tc2dfMD1hLmFzbS5ZKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LEZiPWEuX2Vtc2NyaXB0ZW5fYmluZF9TdGF0dXNfX19kZXN0cm95X19fMD1mdW5jdGlvbigpe3JldHVybihGYj1hLl9lbXNjcmlwdGVuX2JpbmRfU3RhdHVzX19fZGVzdHJveV9fXzA9CmEuYXNtLlopLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sSWE9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvRmxvYXQzMkFycmF5X0RyYWNvRmxvYXQzMkFycmF5XzA9ZnVuY3Rpb24oKXtyZXR1cm4oSWE9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvRmxvYXQzMkFycmF5X0RyYWNvRmxvYXQzMkFycmF5XzA9YS5hc20uXykuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxHYj1hLl9lbXNjcmlwdGVuX2JpbmRfRHJhY29GbG9hdDMyQXJyYXlfR2V0VmFsdWVfMT1mdW5jdGlvbigpe3JldHVybihHYj1hLl9lbXNjcmlwdGVuX2JpbmRfRHJhY29GbG9hdDMyQXJyYXlfR2V0VmFsdWVfMT1hLmFzbS4kKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LEhiPWEuX2Vtc2NyaXB0ZW5fYmluZF9EcmFjb0Zsb2F0MzJBcnJheV9zaXplXzA9ZnVuY3Rpb24oKXtyZXR1cm4oSGI9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvRmxvYXQzMkFycmF5X3NpemVfMD1hLmFzbS5hYSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxJYj0KYS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvRmxvYXQzMkFycmF5X19fZGVzdHJveV9fXzA9ZnVuY3Rpb24oKXtyZXR1cm4oSWI9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvRmxvYXQzMkFycmF5X19fZGVzdHJveV9fXzA9YS5hc20uYmEpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sSmE9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvSW50OEFycmF5X0RyYWNvSW50OEFycmF5XzA9ZnVuY3Rpb24oKXtyZXR1cm4oSmE9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvSW50OEFycmF5X0RyYWNvSW50OEFycmF5XzA9YS5hc20uY2EpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sSmI9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvSW50OEFycmF5X0dldFZhbHVlXzE9ZnVuY3Rpb24oKXtyZXR1cm4oSmI9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvSW50OEFycmF5X0dldFZhbHVlXzE9YS5hc20uZGEpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sS2I9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvSW50OEFycmF5X3NpemVfMD0KZnVuY3Rpb24oKXtyZXR1cm4oS2I9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvSW50OEFycmF5X3NpemVfMD1hLmFzbS5lYSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxMYj1hLl9lbXNjcmlwdGVuX2JpbmRfRHJhY29JbnQ4QXJyYXlfX19kZXN0cm95X19fMD1mdW5jdGlvbigpe3JldHVybihMYj1hLl9lbXNjcmlwdGVuX2JpbmRfRHJhY29JbnQ4QXJyYXlfX19kZXN0cm95X19fMD1hLmFzbS5mYSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxLYT1hLl9lbXNjcmlwdGVuX2JpbmRfRHJhY29VSW50OEFycmF5X0RyYWNvVUludDhBcnJheV8wPWZ1bmN0aW9uKCl7cmV0dXJuKEthPWEuX2Vtc2NyaXB0ZW5fYmluZF9EcmFjb1VJbnQ4QXJyYXlfRHJhY29VSW50OEFycmF5XzA9YS5hc20uZ2EpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sTWI9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvVUludDhBcnJheV9HZXRWYWx1ZV8xPWZ1bmN0aW9uKCl7cmV0dXJuKE1iPWEuX2Vtc2NyaXB0ZW5fYmluZF9EcmFjb1VJbnQ4QXJyYXlfR2V0VmFsdWVfMT0KYS5hc20uaGEpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sTmI9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvVUludDhBcnJheV9zaXplXzA9ZnVuY3Rpb24oKXtyZXR1cm4oTmI9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvVUludDhBcnJheV9zaXplXzA9YS5hc20uaWEpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sT2I9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvVUludDhBcnJheV9fX2Rlc3Ryb3lfX18wPWZ1bmN0aW9uKCl7cmV0dXJuKE9iPWEuX2Vtc2NyaXB0ZW5fYmluZF9EcmFjb1VJbnQ4QXJyYXlfX19kZXN0cm95X19fMD1hLmFzbS5qYSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxMYT1hLl9lbXNjcmlwdGVuX2JpbmRfRHJhY29JbnQxNkFycmF5X0RyYWNvSW50MTZBcnJheV8wPWZ1bmN0aW9uKCl7cmV0dXJuKExhPWEuX2Vtc2NyaXB0ZW5fYmluZF9EcmFjb0ludDE2QXJyYXlfRHJhY29JbnQxNkFycmF5XzA9YS5hc20ua2EpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sUGI9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvSW50MTZBcnJheV9HZXRWYWx1ZV8xPQpmdW5jdGlvbigpe3JldHVybihQYj1hLl9lbXNjcmlwdGVuX2JpbmRfRHJhY29JbnQxNkFycmF5X0dldFZhbHVlXzE9YS5hc20ubGEpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sUWI9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvSW50MTZBcnJheV9zaXplXzA9ZnVuY3Rpb24oKXtyZXR1cm4oUWI9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvSW50MTZBcnJheV9zaXplXzA9YS5hc20ubWEpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sUmI9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvSW50MTZBcnJheV9fX2Rlc3Ryb3lfX18wPWZ1bmN0aW9uKCl7cmV0dXJuKFJiPWEuX2Vtc2NyaXB0ZW5fYmluZF9EcmFjb0ludDE2QXJyYXlfX19kZXN0cm95X19fMD1hLmFzbS5uYSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxNYT1hLl9lbXNjcmlwdGVuX2JpbmRfRHJhY29VSW50MTZBcnJheV9EcmFjb1VJbnQxNkFycmF5XzA9ZnVuY3Rpb24oKXtyZXR1cm4oTWE9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvVUludDE2QXJyYXlfRHJhY29VSW50MTZBcnJheV8wPQphLmFzbS5vYSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxTYj1hLl9lbXNjcmlwdGVuX2JpbmRfRHJhY29VSW50MTZBcnJheV9HZXRWYWx1ZV8xPWZ1bmN0aW9uKCl7cmV0dXJuKFNiPWEuX2Vtc2NyaXB0ZW5fYmluZF9EcmFjb1VJbnQxNkFycmF5X0dldFZhbHVlXzE9YS5hc20ucGEpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sVGI9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvVUludDE2QXJyYXlfc2l6ZV8wPWZ1bmN0aW9uKCl7cmV0dXJuKFRiPWEuX2Vtc2NyaXB0ZW5fYmluZF9EcmFjb1VJbnQxNkFycmF5X3NpemVfMD1hLmFzbS5xYSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxVYj1hLl9lbXNjcmlwdGVuX2JpbmRfRHJhY29VSW50MTZBcnJheV9fX2Rlc3Ryb3lfX18wPWZ1bmN0aW9uKCl7cmV0dXJuKFViPWEuX2Vtc2NyaXB0ZW5fYmluZF9EcmFjb1VJbnQxNkFycmF5X19fZGVzdHJveV9fXzA9YS5hc20ucmEpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sTmE9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvSW50MzJBcnJheV9EcmFjb0ludDMyQXJyYXlfMD0KZnVuY3Rpb24oKXtyZXR1cm4oTmE9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvSW50MzJBcnJheV9EcmFjb0ludDMyQXJyYXlfMD1hLmFzbS5zYSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxWYj1hLl9lbXNjcmlwdGVuX2JpbmRfRHJhY29JbnQzMkFycmF5X0dldFZhbHVlXzE9ZnVuY3Rpb24oKXtyZXR1cm4oVmI9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvSW50MzJBcnJheV9HZXRWYWx1ZV8xPWEuYXNtLnRhKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LFdiPWEuX2Vtc2NyaXB0ZW5fYmluZF9EcmFjb0ludDMyQXJyYXlfc2l6ZV8wPWZ1bmN0aW9uKCl7cmV0dXJuKFdiPWEuX2Vtc2NyaXB0ZW5fYmluZF9EcmFjb0ludDMyQXJyYXlfc2l6ZV8wPWEuYXNtLnVhKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LFhiPWEuX2Vtc2NyaXB0ZW5fYmluZF9EcmFjb0ludDMyQXJyYXlfX19kZXN0cm95X19fMD1mdW5jdGlvbigpe3JldHVybihYYj1hLl9lbXNjcmlwdGVuX2JpbmRfRHJhY29JbnQzMkFycmF5X19fZGVzdHJveV9fXzA9CmEuYXNtLnZhKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LE9hPWEuX2Vtc2NyaXB0ZW5fYmluZF9EcmFjb1VJbnQzMkFycmF5X0RyYWNvVUludDMyQXJyYXlfMD1mdW5jdGlvbigpe3JldHVybihPYT1hLl9lbXNjcmlwdGVuX2JpbmRfRHJhY29VSW50MzJBcnJheV9EcmFjb1VJbnQzMkFycmF5XzA9YS5hc20ud2EpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sWWI9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvVUludDMyQXJyYXlfR2V0VmFsdWVfMT1mdW5jdGlvbigpe3JldHVybihZYj1hLl9lbXNjcmlwdGVuX2JpbmRfRHJhY29VSW50MzJBcnJheV9HZXRWYWx1ZV8xPWEuYXNtLnhhKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LFpiPWEuX2Vtc2NyaXB0ZW5fYmluZF9EcmFjb1VJbnQzMkFycmF5X3NpemVfMD1mdW5jdGlvbigpe3JldHVybihaYj1hLl9lbXNjcmlwdGVuX2JpbmRfRHJhY29VSW50MzJBcnJheV9zaXplXzA9YS5hc20ueWEpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sJGI9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvVUludDMyQXJyYXlfX19kZXN0cm95X19fMD0KZnVuY3Rpb24oKXtyZXR1cm4oJGI9YS5fZW1zY3JpcHRlbl9iaW5kX0RyYWNvVUludDMyQXJyYXlfX19kZXN0cm95X19fMD1hLmFzbS56YSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxQYT1hLl9lbXNjcmlwdGVuX2JpbmRfTWV0YWRhdGFRdWVyaWVyX01ldGFkYXRhUXVlcmllcl8wPWZ1bmN0aW9uKCl7cmV0dXJuKFBhPWEuX2Vtc2NyaXB0ZW5fYmluZF9NZXRhZGF0YVF1ZXJpZXJfTWV0YWRhdGFRdWVyaWVyXzA9YS5hc20uQWEpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sYWM9YS5fZW1zY3JpcHRlbl9iaW5kX01ldGFkYXRhUXVlcmllcl9IYXNFbnRyeV8yPWZ1bmN0aW9uKCl7cmV0dXJuKGFjPWEuX2Vtc2NyaXB0ZW5fYmluZF9NZXRhZGF0YVF1ZXJpZXJfSGFzRW50cnlfMj1hLmFzbS5CYSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxiYz1hLl9lbXNjcmlwdGVuX2JpbmRfTWV0YWRhdGFRdWVyaWVyX0dldEludEVudHJ5XzI9ZnVuY3Rpb24oKXtyZXR1cm4oYmM9YS5fZW1zY3JpcHRlbl9iaW5kX01ldGFkYXRhUXVlcmllcl9HZXRJbnRFbnRyeV8yPQphLmFzbS5DYSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxjYz1hLl9lbXNjcmlwdGVuX2JpbmRfTWV0YWRhdGFRdWVyaWVyX0dldEludEVudHJ5QXJyYXlfMz1mdW5jdGlvbigpe3JldHVybihjYz1hLl9lbXNjcmlwdGVuX2JpbmRfTWV0YWRhdGFRdWVyaWVyX0dldEludEVudHJ5QXJyYXlfMz1hLmFzbS5EYSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxkYz1hLl9lbXNjcmlwdGVuX2JpbmRfTWV0YWRhdGFRdWVyaWVyX0dldERvdWJsZUVudHJ5XzI9ZnVuY3Rpb24oKXtyZXR1cm4oZGM9YS5fZW1zY3JpcHRlbl9iaW5kX01ldGFkYXRhUXVlcmllcl9HZXREb3VibGVFbnRyeV8yPWEuYXNtLkVhKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LGVjPWEuX2Vtc2NyaXB0ZW5fYmluZF9NZXRhZGF0YVF1ZXJpZXJfR2V0U3RyaW5nRW50cnlfMj1mdW5jdGlvbigpe3JldHVybihlYz1hLl9lbXNjcmlwdGVuX2JpbmRfTWV0YWRhdGFRdWVyaWVyX0dldFN0cmluZ0VudHJ5XzI9YS5hc20uRmEpLmFwcGx5KG51bGwsCmFyZ3VtZW50cyl9LGZjPWEuX2Vtc2NyaXB0ZW5fYmluZF9NZXRhZGF0YVF1ZXJpZXJfTnVtRW50cmllc18xPWZ1bmN0aW9uKCl7cmV0dXJuKGZjPWEuX2Vtc2NyaXB0ZW5fYmluZF9NZXRhZGF0YVF1ZXJpZXJfTnVtRW50cmllc18xPWEuYXNtLkdhKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LGdjPWEuX2Vtc2NyaXB0ZW5fYmluZF9NZXRhZGF0YVF1ZXJpZXJfR2V0RW50cnlOYW1lXzI9ZnVuY3Rpb24oKXtyZXR1cm4oZ2M9YS5fZW1zY3JpcHRlbl9iaW5kX01ldGFkYXRhUXVlcmllcl9HZXRFbnRyeU5hbWVfMj1hLmFzbS5IYSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxoYz1hLl9lbXNjcmlwdGVuX2JpbmRfTWV0YWRhdGFRdWVyaWVyX19fZGVzdHJveV9fXzA9ZnVuY3Rpb24oKXtyZXR1cm4oaGM9YS5fZW1zY3JpcHRlbl9iaW5kX01ldGFkYXRhUXVlcmllcl9fX2Rlc3Ryb3lfX18wPWEuYXNtLklhKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LFFhPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0RlY29kZXJfMD0KZnVuY3Rpb24oKXtyZXR1cm4oUWE9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJfRGVjb2Rlcl8wPWEuYXNtLkphKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LGljPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0RlY29kZUFycmF5VG9Qb2ludENsb3VkXzM9ZnVuY3Rpb24oKXtyZXR1cm4oaWM9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJfRGVjb2RlQXJyYXlUb1BvaW50Q2xvdWRfMz1hLmFzbS5LYSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxqYz1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2Rlcl9EZWNvZGVBcnJheVRvTWVzaF8zPWZ1bmN0aW9uKCl7cmV0dXJuKGpjPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0RlY29kZUFycmF5VG9NZXNoXzM9YS5hc20uTGEpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sa2M9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJfR2V0QXR0cmlidXRlSWRfMj1mdW5jdGlvbigpe3JldHVybihrYz1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2Rlcl9HZXRBdHRyaWJ1dGVJZF8yPQphLmFzbS5NYSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxsYz1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2Rlcl9HZXRBdHRyaWJ1dGVJZEJ5TmFtZV8yPWZ1bmN0aW9uKCl7cmV0dXJuKGxjPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0dldEF0dHJpYnV0ZUlkQnlOYW1lXzI9YS5hc20uTmEpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sbWM9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJfR2V0QXR0cmlidXRlSWRCeU1ldGFkYXRhRW50cnlfMz1mdW5jdGlvbigpe3JldHVybihtYz1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2Rlcl9HZXRBdHRyaWJ1dGVJZEJ5TWV0YWRhdGFFbnRyeV8zPWEuYXNtLk9hKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LG5jPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0dldEF0dHJpYnV0ZV8yPWZ1bmN0aW9uKCl7cmV0dXJuKG5jPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0dldEF0dHJpYnV0ZV8yPWEuYXNtLlBhKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LApvYz1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2Rlcl9HZXRBdHRyaWJ1dGVCeVVuaXF1ZUlkXzI9ZnVuY3Rpb24oKXtyZXR1cm4ob2M9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJfR2V0QXR0cmlidXRlQnlVbmlxdWVJZF8yPWEuYXNtLlFhKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LHBjPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0dldE1ldGFkYXRhXzE9ZnVuY3Rpb24oKXtyZXR1cm4ocGM9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJfR2V0TWV0YWRhdGFfMT1hLmFzbS5SYSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxxYz1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2Rlcl9HZXRBdHRyaWJ1dGVNZXRhZGF0YV8yPWZ1bmN0aW9uKCl7cmV0dXJuKHFjPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0dldEF0dHJpYnV0ZU1ldGFkYXRhXzI9YS5hc20uU2EpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0scmM9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJfR2V0RmFjZUZyb21NZXNoXzM9CmZ1bmN0aW9uKCl7cmV0dXJuKHJjPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0dldEZhY2VGcm9tTWVzaF8zPWEuYXNtLlRhKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LHNjPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0dldFRyaWFuZ2xlU3RyaXBzRnJvbU1lc2hfMj1mdW5jdGlvbigpe3JldHVybihzYz1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2Rlcl9HZXRUcmlhbmdsZVN0cmlwc0Zyb21NZXNoXzI9YS5hc20uVWEpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sdGM9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJfR2V0VHJpYW5nbGVzVUludDE2QXJyYXlfMz1mdW5jdGlvbigpe3JldHVybih0Yz1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2Rlcl9HZXRUcmlhbmdsZXNVSW50MTZBcnJheV8zPWEuYXNtLlZhKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LHVjPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0dldFRyaWFuZ2xlc1VJbnQzMkFycmF5XzM9ZnVuY3Rpb24oKXtyZXR1cm4odWM9CmEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0dldFRyaWFuZ2xlc1VJbnQzMkFycmF5XzM9YS5hc20uV2EpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sdmM9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJfR2V0QXR0cmlidXRlRmxvYXRfMz1mdW5jdGlvbigpe3JldHVybih2Yz1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2Rlcl9HZXRBdHRyaWJ1dGVGbG9hdF8zPWEuYXNtLlhhKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LHdjPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0dldEF0dHJpYnV0ZUZsb2F0Rm9yQWxsUG9pbnRzXzM9ZnVuY3Rpb24oKXtyZXR1cm4od2M9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJfR2V0QXR0cmlidXRlRmxvYXRGb3JBbGxQb2ludHNfMz1hLmFzbS5ZYSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSx4Yz1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2Rlcl9HZXRBdHRyaWJ1dGVJbnRGb3JBbGxQb2ludHNfMz1mdW5jdGlvbigpe3JldHVybih4Yz1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2Rlcl9HZXRBdHRyaWJ1dGVJbnRGb3JBbGxQb2ludHNfMz0KYS5hc20uWmEpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0seWM9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJfR2V0QXR0cmlidXRlSW50OEZvckFsbFBvaW50c18zPWZ1bmN0aW9uKCl7cmV0dXJuKHljPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0dldEF0dHJpYnV0ZUludDhGb3JBbGxQb2ludHNfMz1hLmFzbS5fYSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfSx6Yz1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2Rlcl9HZXRBdHRyaWJ1dGVVSW50OEZvckFsbFBvaW50c18zPWZ1bmN0aW9uKCl7cmV0dXJuKHpjPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0dldEF0dHJpYnV0ZVVJbnQ4Rm9yQWxsUG9pbnRzXzM9YS5hc20uJGEpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sQWM9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJfR2V0QXR0cmlidXRlSW50MTZGb3JBbGxQb2ludHNfMz1mdW5jdGlvbigpe3JldHVybihBYz1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2Rlcl9HZXRBdHRyaWJ1dGVJbnQxNkZvckFsbFBvaW50c18zPQphLmFzbS5hYikuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxCYz1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2Rlcl9HZXRBdHRyaWJ1dGVVSW50MTZGb3JBbGxQb2ludHNfMz1mdW5jdGlvbigpe3JldHVybihCYz1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2Rlcl9HZXRBdHRyaWJ1dGVVSW50MTZGb3JBbGxQb2ludHNfMz1hLmFzbS5iYikuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxDYz1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2Rlcl9HZXRBdHRyaWJ1dGVJbnQzMkZvckFsbFBvaW50c18zPWZ1bmN0aW9uKCl7cmV0dXJuKENjPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0dldEF0dHJpYnV0ZUludDMyRm9yQWxsUG9pbnRzXzM9YS5hc20uY2IpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sRGM9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJfR2V0QXR0cmlidXRlVUludDMyRm9yQWxsUG9pbnRzXzM9ZnVuY3Rpb24oKXtyZXR1cm4oRGM9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJfR2V0QXR0cmlidXRlVUludDMyRm9yQWxsUG9pbnRzXzM9CmEuYXNtLmRiKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LEVjPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0dldEF0dHJpYnV0ZURhdGFBcnJheUZvckFsbFBvaW50c181PWZ1bmN0aW9uKCl7cmV0dXJuKEVjPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0dldEF0dHJpYnV0ZURhdGFBcnJheUZvckFsbFBvaW50c181PWEuYXNtLmViKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LEZjPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX1NraXBBdHRyaWJ1dGVUcmFuc2Zvcm1fMT1mdW5jdGlvbigpe3JldHVybihGYz1hLl9lbXNjcmlwdGVuX2JpbmRfRGVjb2Rlcl9Ta2lwQXR0cmlidXRlVHJhbnNmb3JtXzE9YS5hc20uZmIpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sR2M9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJfR2V0RW5jb2RlZEdlb21ldHJ5VHlwZV9EZXByZWNhdGVkXzE9ZnVuY3Rpb24oKXtyZXR1cm4oR2M9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJfR2V0RW5jb2RlZEdlb21ldHJ5VHlwZV9EZXByZWNhdGVkXzE9CmEuYXNtLmdiKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LEhjPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0RlY29kZUJ1ZmZlclRvUG9pbnRDbG91ZF8yPWZ1bmN0aW9uKCl7cmV0dXJuKEhjPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0RlY29kZUJ1ZmZlclRvUG9pbnRDbG91ZF8yPWEuYXNtLmhiKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LEljPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0RlY29kZUJ1ZmZlclRvTWVzaF8yPWZ1bmN0aW9uKCl7cmV0dXJuKEljPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX0RlY29kZUJ1ZmZlclRvTWVzaF8yPWEuYXNtLmliKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LEpjPWEuX2Vtc2NyaXB0ZW5fYmluZF9EZWNvZGVyX19fZGVzdHJveV9fXzA9ZnVuY3Rpb24oKXtyZXR1cm4oSmM9YS5fZW1zY3JpcHRlbl9iaW5kX0RlY29kZXJfX19kZXN0cm95X19fMD1hLmFzbS5qYikuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxLYz1hLl9lbXNjcmlwdGVuX2VudW1fZHJhY29fQXR0cmlidXRlVHJhbnNmb3JtVHlwZV9BVFRSSUJVVEVfSU5WQUxJRF9UUkFOU0ZPUk09CmZ1bmN0aW9uKCl7cmV0dXJuKEtjPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19BdHRyaWJ1dGVUcmFuc2Zvcm1UeXBlX0FUVFJJQlVURV9JTlZBTElEX1RSQU5TRk9STT1hLmFzbS5rYikuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxMYz1hLl9lbXNjcmlwdGVuX2VudW1fZHJhY29fQXR0cmlidXRlVHJhbnNmb3JtVHlwZV9BVFRSSUJVVEVfTk9fVFJBTlNGT1JNPWZ1bmN0aW9uKCl7cmV0dXJuKExjPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19BdHRyaWJ1dGVUcmFuc2Zvcm1UeXBlX0FUVFJJQlVURV9OT19UUkFOU0ZPUk09YS5hc20ubGIpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sTWM9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX0F0dHJpYnV0ZVRyYW5zZm9ybVR5cGVfQVRUUklCVVRFX1FVQU5USVpBVElPTl9UUkFOU0ZPUk09ZnVuY3Rpb24oKXtyZXR1cm4oTWM9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX0F0dHJpYnV0ZVRyYW5zZm9ybVR5cGVfQVRUUklCVVRFX1FVQU5USVpBVElPTl9UUkFOU0ZPUk09CmEuYXNtLm1iKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LE5jPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19BdHRyaWJ1dGVUcmFuc2Zvcm1UeXBlX0FUVFJJQlVURV9PQ1RBSEVEUk9OX1RSQU5TRk9STT1mdW5jdGlvbigpe3JldHVybihOYz1hLl9lbXNjcmlwdGVuX2VudW1fZHJhY29fQXR0cmlidXRlVHJhbnNmb3JtVHlwZV9BVFRSSUJVVEVfT0NUQUhFRFJPTl9UUkFOU0ZPUk09YS5hc20ubmIpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sT2M9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX0dlb21ldHJ5QXR0cmlidXRlX1R5cGVfSU5WQUxJRD1mdW5jdGlvbigpe3JldHVybihPYz1hLl9lbXNjcmlwdGVuX2VudW1fZHJhY29fR2VvbWV0cnlBdHRyaWJ1dGVfVHlwZV9JTlZBTElEPWEuYXNtLm9iKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LFBjPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19HZW9tZXRyeUF0dHJpYnV0ZV9UeXBlX1BPU0lUSU9OPWZ1bmN0aW9uKCl7cmV0dXJuKFBjPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19HZW9tZXRyeUF0dHJpYnV0ZV9UeXBlX1BPU0lUSU9OPQphLmFzbS5wYikuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxRYz1hLl9lbXNjcmlwdGVuX2VudW1fZHJhY29fR2VvbWV0cnlBdHRyaWJ1dGVfVHlwZV9OT1JNQUw9ZnVuY3Rpb24oKXtyZXR1cm4oUWM9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX0dlb21ldHJ5QXR0cmlidXRlX1R5cGVfTk9STUFMPWEuYXNtLnFiKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LFJjPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19HZW9tZXRyeUF0dHJpYnV0ZV9UeXBlX0NPTE9SPWZ1bmN0aW9uKCl7cmV0dXJuKFJjPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19HZW9tZXRyeUF0dHJpYnV0ZV9UeXBlX0NPTE9SPWEuYXNtLnJiKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LFNjPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19HZW9tZXRyeUF0dHJpYnV0ZV9UeXBlX1RFWF9DT09SRD1mdW5jdGlvbigpe3JldHVybihTYz1hLl9lbXNjcmlwdGVuX2VudW1fZHJhY29fR2VvbWV0cnlBdHRyaWJ1dGVfVHlwZV9URVhfQ09PUkQ9CmEuYXNtLnNiKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LFRjPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19HZW9tZXRyeUF0dHJpYnV0ZV9UeXBlX0dFTkVSSUM9ZnVuY3Rpb24oKXtyZXR1cm4oVGM9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX0dlb21ldHJ5QXR0cmlidXRlX1R5cGVfR0VORVJJQz1hLmFzbS50YikuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxVYz1hLl9lbXNjcmlwdGVuX2VudW1fZHJhY29fRW5jb2RlZEdlb21ldHJ5VHlwZV9JTlZBTElEX0dFT01FVFJZX1RZUEU9ZnVuY3Rpb24oKXtyZXR1cm4oVWM9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX0VuY29kZWRHZW9tZXRyeVR5cGVfSU5WQUxJRF9HRU9NRVRSWV9UWVBFPWEuYXNtLnViKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LFZjPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19FbmNvZGVkR2VvbWV0cnlUeXBlX1BPSU5UX0NMT1VEPWZ1bmN0aW9uKCl7cmV0dXJuKFZjPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19FbmNvZGVkR2VvbWV0cnlUeXBlX1BPSU5UX0NMT1VEPQphLmFzbS52YikuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxXYz1hLl9lbXNjcmlwdGVuX2VudW1fZHJhY29fRW5jb2RlZEdlb21ldHJ5VHlwZV9UUklBTkdVTEFSX01FU0g9ZnVuY3Rpb24oKXtyZXR1cm4oV2M9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX0VuY29kZWRHZW9tZXRyeVR5cGVfVFJJQU5HVUxBUl9NRVNIPWEuYXNtLndiKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LFhjPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19EYXRhVHlwZV9EVF9JTlZBTElEPWZ1bmN0aW9uKCl7cmV0dXJuKFhjPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19EYXRhVHlwZV9EVF9JTlZBTElEPWEuYXNtLnhiKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LFljPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19EYXRhVHlwZV9EVF9JTlQ4PWZ1bmN0aW9uKCl7cmV0dXJuKFljPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19EYXRhVHlwZV9EVF9JTlQ4PWEuYXNtLnliKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LFpjPQphLl9lbXNjcmlwdGVuX2VudW1fZHJhY29fRGF0YVR5cGVfRFRfVUlOVDg9ZnVuY3Rpb24oKXtyZXR1cm4oWmM9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX0RhdGFUeXBlX0RUX1VJTlQ4PWEuYXNtLnpiKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LCRjPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19EYXRhVHlwZV9EVF9JTlQxNj1mdW5jdGlvbigpe3JldHVybigkYz1hLl9lbXNjcmlwdGVuX2VudW1fZHJhY29fRGF0YVR5cGVfRFRfSU5UMTY9YS5hc20uQWIpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sYWQ9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX0RhdGFUeXBlX0RUX1VJTlQxNj1mdW5jdGlvbigpe3JldHVybihhZD1hLl9lbXNjcmlwdGVuX2VudW1fZHJhY29fRGF0YVR5cGVfRFRfVUlOVDE2PWEuYXNtLkJiKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LGJkPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19EYXRhVHlwZV9EVF9JTlQzMj1mdW5jdGlvbigpe3JldHVybihiZD1hLl9lbXNjcmlwdGVuX2VudW1fZHJhY29fRGF0YVR5cGVfRFRfSU5UMzI9CmEuYXNtLkNiKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LGNkPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19EYXRhVHlwZV9EVF9VSU5UMzI9ZnVuY3Rpb24oKXtyZXR1cm4oY2Q9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX0RhdGFUeXBlX0RUX1VJTlQzMj1hLmFzbS5EYikuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxkZD1hLl9lbXNjcmlwdGVuX2VudW1fZHJhY29fRGF0YVR5cGVfRFRfSU5UNjQ9ZnVuY3Rpb24oKXtyZXR1cm4oZGQ9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX0RhdGFUeXBlX0RUX0lOVDY0PWEuYXNtLkViKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LGVkPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19EYXRhVHlwZV9EVF9VSU5UNjQ9ZnVuY3Rpb24oKXtyZXR1cm4oZWQ9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX0RhdGFUeXBlX0RUX1VJTlQ2ND1hLmFzbS5GYikuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxmZD1hLl9lbXNjcmlwdGVuX2VudW1fZHJhY29fRGF0YVR5cGVfRFRfRkxPQVQzMj0KZnVuY3Rpb24oKXtyZXR1cm4oZmQ9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX0RhdGFUeXBlX0RUX0ZMT0FUMzI9YS5hc20uR2IpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sZ2Q9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX0RhdGFUeXBlX0RUX0ZMT0FUNjQ9ZnVuY3Rpb24oKXtyZXR1cm4oZ2Q9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX0RhdGFUeXBlX0RUX0ZMT0FUNjQ9YS5hc20uSGIpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0saGQ9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX0RhdGFUeXBlX0RUX0JPT0w9ZnVuY3Rpb24oKXtyZXR1cm4oaGQ9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX0RhdGFUeXBlX0RUX0JPT0w9YS5hc20uSWIpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0saWQ9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX0RhdGFUeXBlX0RUX1RZUEVTX0NPVU5UPWZ1bmN0aW9uKCl7cmV0dXJuKGlkPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19EYXRhVHlwZV9EVF9UWVBFU19DT1VOVD0KYS5hc20uSmIpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0samQ9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX1N0YXR1c0NvZGVfT0s9ZnVuY3Rpb24oKXtyZXR1cm4oamQ9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX1N0YXR1c0NvZGVfT0s9YS5hc20uS2IpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sa2Q9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX1N0YXR1c0NvZGVfRFJBQ09fRVJST1I9ZnVuY3Rpb24oKXtyZXR1cm4oa2Q9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX1N0YXR1c0NvZGVfRFJBQ09fRVJST1I9YS5hc20uTGIpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sbGQ9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX1N0YXR1c0NvZGVfSU9fRVJST1I9ZnVuY3Rpb24oKXtyZXR1cm4obGQ9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX1N0YXR1c0NvZGVfSU9fRVJST1I9YS5hc20uTWIpLmFwcGx5KG51bGwsYXJndW1lbnRzKX0sbWQ9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX1N0YXR1c0NvZGVfSU5WQUxJRF9QQVJBTUVURVI9CmZ1bmN0aW9uKCl7cmV0dXJuKG1kPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19TdGF0dXNDb2RlX0lOVkFMSURfUEFSQU1FVEVSPWEuYXNtLk5iKS5hcHBseShudWxsLGFyZ3VtZW50cyl9LG5kPWEuX2Vtc2NyaXB0ZW5fZW51bV9kcmFjb19TdGF0dXNDb2RlX1VOU1VQUE9SVEVEX1ZFUlNJT049ZnVuY3Rpb24oKXtyZXR1cm4obmQ9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX1N0YXR1c0NvZGVfVU5TVVBQT1JURURfVkVSU0lPTj1hLmFzbS5PYikuYXBwbHkobnVsbCxhcmd1bWVudHMpfSxvZD1hLl9lbXNjcmlwdGVuX2VudW1fZHJhY29fU3RhdHVzQ29kZV9VTktOT1dOX1ZFUlNJT049ZnVuY3Rpb24oKXtyZXR1cm4ob2Q9YS5fZW1zY3JpcHRlbl9lbnVtX2RyYWNvX1N0YXR1c0NvZGVfVU5LTk9XTl9WRVJTSU9OPWEuYXNtLlBiKS5hcHBseShudWxsLGFyZ3VtZW50cyl9O2EuX21hbGxvYz1mdW5jdGlvbigpe3JldHVybihhLl9tYWxsb2M9YS5hc20uUWIpLmFwcGx5KG51bGwsYXJndW1lbnRzKX07CmEuX2ZyZWU9ZnVuY3Rpb24oKXtyZXR1cm4oYS5fZnJlZT1hLmFzbS5SYikuYXBwbHkobnVsbCxhcmd1bWVudHMpfTt2YXIgdWE9ZnVuY3Rpb24oKXtyZXR1cm4odWE9YS5hc20uU2IpLmFwcGx5KG51bGwsYXJndW1lbnRzKX07YS5fX19zdGFydF9lbV9qcz0xMTY2MDthLl9fX3N0b3BfZW1fanM9MTE3NTg7dmFyIGxhO2hhPWZ1bmN0aW9uIGIoKXtsYXx8RigpO2xhfHwoaGE9Yil9O2lmKGEucHJlSW5pdClmb3IoImZ1bmN0aW9uIj09dHlwZW9mIGEucHJlSW5pdCYmKGEucHJlSW5pdD1bYS5wcmVJbml0XSk7MDxhLnByZUluaXQubGVuZ3RoOylhLnByZUluaXQucG9wKCkoKTtGKCk7di5wcm90b3R5cGU9T2JqZWN0LmNyZWF0ZSh2LnByb3RvdHlwZSk7di5wcm90b3R5cGUuY29uc3RydWN0b3I9djt2LnByb3RvdHlwZS5fX2NsYXNzX189djt2Ll9fY2FjaGVfXz17fTthLldyYXBwZXJPYmplY3Q9djthLmdldENhY2hlPXc7YS53cmFwUG9pbnRlcj1CO2EuY2FzdE9iamVjdD1mdW5jdGlvbihiLApjKXtyZXR1cm4gQihiLnB0cixjKX07YS5OVUxMPUIoMCk7YS5kZXN0cm95PWZ1bmN0aW9uKGIpe2lmKCFiLl9fZGVzdHJveV9fKXRocm93IkVycm9yOiBDYW5ub3QgZGVzdHJveSBvYmplY3QuIChEaWQgeW91IGNyZWF0ZSBpdCB5b3Vyc2VsZj8pIjtiLl9fZGVzdHJveV9fKCk7ZGVsZXRlIHcoYi5fX2NsYXNzX18pW2IucHRyXX07YS5jb21wYXJlPWZ1bmN0aW9uKGIsYyl7cmV0dXJuIGIucHRyPT09Yy5wdHJ9O2EuZ2V0UG9pbnRlcj1mdW5jdGlvbihiKXtyZXR1cm4gYi5wdHJ9O2EuZ2V0Q2xhc3M9ZnVuY3Rpb24oYil7cmV0dXJuIGIuX19jbGFzc19ffTt2YXIgcj17YnVmZmVyOjAsc2l6ZTowLHBvczowLHRlbXBzOltdLG5lZWRlZDowLHByZXBhcmU6ZnVuY3Rpb24oKXtpZihyLm5lZWRlZCl7Zm9yKHZhciBiPTA7YjxyLnRlbXBzLmxlbmd0aDtiKyspYS5fZnJlZShyLnRlbXBzW2JdKTtyLnRlbXBzLmxlbmd0aD0wO2EuX2ZyZWUoci5idWZmZXIpO3IuYnVmZmVyPTA7ci5zaXplKz0Kci5uZWVkZWQ7ci5uZWVkZWQ9MH1yLmJ1ZmZlcnx8KHIuc2l6ZSs9MTI4LHIuYnVmZmVyPWEuX21hbGxvYyhyLnNpemUpLHIuYnVmZmVyfHx5KHZvaWQgMCkpO3IucG9zPTB9LGFsbG9jOmZ1bmN0aW9uKGIsYyl7ci5idWZmZXJ8fHkodm9pZCAwKTtiPWIubGVuZ3RoKmMuQllURVNfUEVSX0VMRU1FTlQ7Yj1iKzcmLTg7ci5wb3MrYj49ci5zaXplPygwPGJ8fHkodm9pZCAwKSxyLm5lZWRlZCs9YixjPWEuX21hbGxvYyhiKSxyLnRlbXBzLnB1c2goYykpOihjPXIuYnVmZmVyK3IucG9zLHIucG9zKz1iKTtyZXR1cm4gY30sY29weTpmdW5jdGlvbihiLGMsZCl7ZD4+Pj0wO3N3aXRjaChjLkJZVEVTX1BFUl9FTEVNRU5UKXtjYXNlIDI6ZD4+Pj0xO2JyZWFrO2Nhc2UgNDpkPj4+PTI7YnJlYWs7Y2FzZSA4OmQ+Pj49M31mb3IodmFyIGc9MDtnPGIubGVuZ3RoO2crKyljW2QrZ109YltnXX19O1gucHJvdG90eXBlPU9iamVjdC5jcmVhdGUodi5wcm90b3R5cGUpO1gucHJvdG90eXBlLmNvbnN0cnVjdG9yPQpYO1gucHJvdG90eXBlLl9fY2xhc3NfXz1YO1guX19jYWNoZV9fPXt9O2EuVm9pZFB0cj1YO1gucHJvdG90eXBlLl9fZGVzdHJveV9fPVgucHJvdG90eXBlLl9fZGVzdHJveV9fPWZ1bmN0aW9uKCl7WGEodGhpcy5wdHIpfTtTLnByb3RvdHlwZT1PYmplY3QuY3JlYXRlKHYucHJvdG90eXBlKTtTLnByb3RvdHlwZS5jb25zdHJ1Y3Rvcj1TO1MucHJvdG90eXBlLl9fY2xhc3NfXz1TO1MuX19jYWNoZV9fPXt9O2EuRGVjb2RlckJ1ZmZlcj1TO1MucHJvdG90eXBlLkluaXQ9Uy5wcm90b3R5cGUuSW5pdD1mdW5jdGlvbihiLGMpe3ZhciBkPXRoaXMucHRyO3IucHJlcGFyZSgpOyJvYmplY3QiPT10eXBlb2YgYiYmKGI9WihiKSk7YyYmIm9iamVjdCI9PT10eXBlb2YgYyYmKGM9Yy5wdHIpO1lhKGQsYixjKX07Uy5wcm90b3R5cGUuX19kZXN0cm95X189Uy5wcm90b3R5cGUuX19kZXN0cm95X189ZnVuY3Rpb24oKXtaYSh0aGlzLnB0cil9O1EucHJvdG90eXBlPU9iamVjdC5jcmVhdGUodi5wcm90b3R5cGUpOwpRLnByb3RvdHlwZS5jb25zdHJ1Y3Rvcj1RO1EucHJvdG90eXBlLl9fY2xhc3NfXz1RO1EuX19jYWNoZV9fPXt9O2EuQXR0cmlidXRlVHJhbnNmb3JtRGF0YT1RO1EucHJvdG90eXBlLnRyYW5zZm9ybV90eXBlPVEucHJvdG90eXBlLnRyYW5zZm9ybV90eXBlPWZ1bmN0aW9uKCl7cmV0dXJuICRhKHRoaXMucHRyKX07US5wcm90b3R5cGUuX19kZXN0cm95X189US5wcm90b3R5cGUuX19kZXN0cm95X189ZnVuY3Rpb24oKXthYih0aGlzLnB0cil9O1YucHJvdG90eXBlPU9iamVjdC5jcmVhdGUodi5wcm90b3R5cGUpO1YucHJvdG90eXBlLmNvbnN0cnVjdG9yPVY7Vi5wcm90b3R5cGUuX19jbGFzc19fPVY7Vi5fX2NhY2hlX189e307YS5HZW9tZXRyeUF0dHJpYnV0ZT1WO1YucHJvdG90eXBlLl9fZGVzdHJveV9fPVYucHJvdG90eXBlLl9fZGVzdHJveV9fPWZ1bmN0aW9uKCl7YmIodGhpcy5wdHIpfTt4LnByb3RvdHlwZT1PYmplY3QuY3JlYXRlKHYucHJvdG90eXBlKTt4LnByb3RvdHlwZS5jb25zdHJ1Y3Rvcj0KeDt4LnByb3RvdHlwZS5fX2NsYXNzX189eDt4Ll9fY2FjaGVfXz17fTthLlBvaW50QXR0cmlidXRlPXg7eC5wcm90b3R5cGUuc2l6ZT14LnByb3RvdHlwZS5zaXplPWZ1bmN0aW9uKCl7cmV0dXJuIGNiKHRoaXMucHRyKX07eC5wcm90b3R5cGUuR2V0QXR0cmlidXRlVHJhbnNmb3JtRGF0YT14LnByb3RvdHlwZS5HZXRBdHRyaWJ1dGVUcmFuc2Zvcm1EYXRhPWZ1bmN0aW9uKCl7cmV0dXJuIEIoZGIodGhpcy5wdHIpLFEpfTt4LnByb3RvdHlwZS5hdHRyaWJ1dGVfdHlwZT14LnByb3RvdHlwZS5hdHRyaWJ1dGVfdHlwZT1mdW5jdGlvbigpe3JldHVybiBlYih0aGlzLnB0cil9O3gucHJvdG90eXBlLmRhdGFfdHlwZT14LnByb3RvdHlwZS5kYXRhX3R5cGU9ZnVuY3Rpb24oKXtyZXR1cm4gZmIodGhpcy5wdHIpfTt4LnByb3RvdHlwZS5udW1fY29tcG9uZW50cz14LnByb3RvdHlwZS5udW1fY29tcG9uZW50cz1mdW5jdGlvbigpe3JldHVybiBnYih0aGlzLnB0cil9O3gucHJvdG90eXBlLm5vcm1hbGl6ZWQ9CngucHJvdG90eXBlLm5vcm1hbGl6ZWQ9ZnVuY3Rpb24oKXtyZXR1cm4hIWhiKHRoaXMucHRyKX07eC5wcm90b3R5cGUuYnl0ZV9zdHJpZGU9eC5wcm90b3R5cGUuYnl0ZV9zdHJpZGU9ZnVuY3Rpb24oKXtyZXR1cm4gaWIodGhpcy5wdHIpfTt4LnByb3RvdHlwZS5ieXRlX29mZnNldD14LnByb3RvdHlwZS5ieXRlX29mZnNldD1mdW5jdGlvbigpe3JldHVybiBqYih0aGlzLnB0cil9O3gucHJvdG90eXBlLnVuaXF1ZV9pZD14LnByb3RvdHlwZS51bmlxdWVfaWQ9ZnVuY3Rpb24oKXtyZXR1cm4ga2IodGhpcy5wdHIpfTt4LnByb3RvdHlwZS5fX2Rlc3Ryb3lfXz14LnByb3RvdHlwZS5fX2Rlc3Ryb3lfXz1mdW5jdGlvbigpe2xiKHRoaXMucHRyKX07RC5wcm90b3R5cGU9T2JqZWN0LmNyZWF0ZSh2LnByb3RvdHlwZSk7RC5wcm90b3R5cGUuY29uc3RydWN0b3I9RDtELnByb3RvdHlwZS5fX2NsYXNzX189RDtELl9fY2FjaGVfXz17fTthLkF0dHJpYnV0ZVF1YW50aXphdGlvblRyYW5zZm9ybT0KRDtELnByb3RvdHlwZS5Jbml0RnJvbUF0dHJpYnV0ZT1ELnByb3RvdHlwZS5Jbml0RnJvbUF0dHJpYnV0ZT1mdW5jdGlvbihiKXt2YXIgYz10aGlzLnB0cjtiJiYib2JqZWN0Ij09PXR5cGVvZiBiJiYoYj1iLnB0cik7cmV0dXJuISFtYihjLGIpfTtELnByb3RvdHlwZS5xdWFudGl6YXRpb25fYml0cz1ELnByb3RvdHlwZS5xdWFudGl6YXRpb25fYml0cz1mdW5jdGlvbigpe3JldHVybiBuYih0aGlzLnB0cil9O0QucHJvdG90eXBlLm1pbl92YWx1ZT1ELnByb3RvdHlwZS5taW5fdmFsdWU9ZnVuY3Rpb24oYil7dmFyIGM9dGhpcy5wdHI7YiYmIm9iamVjdCI9PT10eXBlb2YgYiYmKGI9Yi5wdHIpO3JldHVybiBvYihjLGIpfTtELnByb3RvdHlwZS5yYW5nZT1ELnByb3RvdHlwZS5yYW5nZT1mdW5jdGlvbigpe3JldHVybiBwYih0aGlzLnB0cil9O0QucHJvdG90eXBlLl9fZGVzdHJveV9fPUQucHJvdG90eXBlLl9fZGVzdHJveV9fPWZ1bmN0aW9uKCl7cWIodGhpcy5wdHIpfTtHLnByb3RvdHlwZT0KT2JqZWN0LmNyZWF0ZSh2LnByb3RvdHlwZSk7Ry5wcm90b3R5cGUuY29uc3RydWN0b3I9RztHLnByb3RvdHlwZS5fX2NsYXNzX189RztHLl9fY2FjaGVfXz17fTthLkF0dHJpYnV0ZU9jdGFoZWRyb25UcmFuc2Zvcm09RztHLnByb3RvdHlwZS5Jbml0RnJvbUF0dHJpYnV0ZT1HLnByb3RvdHlwZS5Jbml0RnJvbUF0dHJpYnV0ZT1mdW5jdGlvbihiKXt2YXIgYz10aGlzLnB0cjtiJiYib2JqZWN0Ij09PXR5cGVvZiBiJiYoYj1iLnB0cik7cmV0dXJuISFyYihjLGIpfTtHLnByb3RvdHlwZS5xdWFudGl6YXRpb25fYml0cz1HLnByb3RvdHlwZS5xdWFudGl6YXRpb25fYml0cz1mdW5jdGlvbigpe3JldHVybiBzYih0aGlzLnB0cil9O0cucHJvdG90eXBlLl9fZGVzdHJveV9fPUcucHJvdG90eXBlLl9fZGVzdHJveV9fPWZ1bmN0aW9uKCl7dGIodGhpcy5wdHIpfTtILnByb3RvdHlwZT1PYmplY3QuY3JlYXRlKHYucHJvdG90eXBlKTtILnByb3RvdHlwZS5jb25zdHJ1Y3Rvcj1IO0gucHJvdG90eXBlLl9fY2xhc3NfXz0KSDtILl9fY2FjaGVfXz17fTthLlBvaW50Q2xvdWQ9SDtILnByb3RvdHlwZS5udW1fYXR0cmlidXRlcz1ILnByb3RvdHlwZS5udW1fYXR0cmlidXRlcz1mdW5jdGlvbigpe3JldHVybiB1Yih0aGlzLnB0cil9O0gucHJvdG90eXBlLm51bV9wb2ludHM9SC5wcm90b3R5cGUubnVtX3BvaW50cz1mdW5jdGlvbigpe3JldHVybiB2Yih0aGlzLnB0cil9O0gucHJvdG90eXBlLl9fZGVzdHJveV9fPUgucHJvdG90eXBlLl9fZGVzdHJveV9fPWZ1bmN0aW9uKCl7d2IodGhpcy5wdHIpfTtFLnByb3RvdHlwZT1PYmplY3QuY3JlYXRlKHYucHJvdG90eXBlKTtFLnByb3RvdHlwZS5jb25zdHJ1Y3Rvcj1FO0UucHJvdG90eXBlLl9fY2xhc3NfXz1FO0UuX19jYWNoZV9fPXt9O2EuTWVzaD1FO0UucHJvdG90eXBlLm51bV9mYWNlcz1FLnByb3RvdHlwZS5udW1fZmFjZXM9ZnVuY3Rpb24oKXtyZXR1cm4geGIodGhpcy5wdHIpfTtFLnByb3RvdHlwZS5udW1fYXR0cmlidXRlcz1FLnByb3RvdHlwZS5udW1fYXR0cmlidXRlcz0KZnVuY3Rpb24oKXtyZXR1cm4geWIodGhpcy5wdHIpfTtFLnByb3RvdHlwZS5udW1fcG9pbnRzPUUucHJvdG90eXBlLm51bV9wb2ludHM9ZnVuY3Rpb24oKXtyZXR1cm4gemIodGhpcy5wdHIpfTtFLnByb3RvdHlwZS5fX2Rlc3Ryb3lfXz1FLnByb3RvdHlwZS5fX2Rlc3Ryb3lfXz1mdW5jdGlvbigpe0FiKHRoaXMucHRyKX07VC5wcm90b3R5cGU9T2JqZWN0LmNyZWF0ZSh2LnByb3RvdHlwZSk7VC5wcm90b3R5cGUuY29uc3RydWN0b3I9VDtULnByb3RvdHlwZS5fX2NsYXNzX189VDtULl9fY2FjaGVfXz17fTthLk1ldGFkYXRhPVQ7VC5wcm90b3R5cGUuX19kZXN0cm95X189VC5wcm90b3R5cGUuX19kZXN0cm95X189ZnVuY3Rpb24oKXtCYih0aGlzLnB0cil9O0MucHJvdG90eXBlPU9iamVjdC5jcmVhdGUodi5wcm90b3R5cGUpO0MucHJvdG90eXBlLmNvbnN0cnVjdG9yPUM7Qy5wcm90b3R5cGUuX19jbGFzc19fPUM7Qy5fX2NhY2hlX189e307YS5TdGF0dXM9QztDLnByb3RvdHlwZS5jb2RlPQpDLnByb3RvdHlwZS5jb2RlPWZ1bmN0aW9uKCl7cmV0dXJuIENiKHRoaXMucHRyKX07Qy5wcm90b3R5cGUub2s9Qy5wcm90b3R5cGUub2s9ZnVuY3Rpb24oKXtyZXR1cm4hIURiKHRoaXMucHRyKX07Qy5wcm90b3R5cGUuZXJyb3JfbXNnPUMucHJvdG90eXBlLmVycm9yX21zZz1mdW5jdGlvbigpe3JldHVybiBwKEViKHRoaXMucHRyKSl9O0MucHJvdG90eXBlLl9fZGVzdHJveV9fPUMucHJvdG90eXBlLl9fZGVzdHJveV9fPWZ1bmN0aW9uKCl7RmIodGhpcy5wdHIpfTtJLnByb3RvdHlwZT1PYmplY3QuY3JlYXRlKHYucHJvdG90eXBlKTtJLnByb3RvdHlwZS5jb25zdHJ1Y3Rvcj1JO0kucHJvdG90eXBlLl9fY2xhc3NfXz1JO0kuX19jYWNoZV9fPXt9O2EuRHJhY29GbG9hdDMyQXJyYXk9STtJLnByb3RvdHlwZS5HZXRWYWx1ZT1JLnByb3RvdHlwZS5HZXRWYWx1ZT1mdW5jdGlvbihiKXt2YXIgYz10aGlzLnB0cjtiJiYib2JqZWN0Ij09PXR5cGVvZiBiJiYoYj1iLnB0cik7cmV0dXJuIEdiKGMsCmIpfTtJLnByb3RvdHlwZS5zaXplPUkucHJvdG90eXBlLnNpemU9ZnVuY3Rpb24oKXtyZXR1cm4gSGIodGhpcy5wdHIpfTtJLnByb3RvdHlwZS5fX2Rlc3Ryb3lfXz1JLnByb3RvdHlwZS5fX2Rlc3Ryb3lfXz1mdW5jdGlvbigpe0liKHRoaXMucHRyKX07Si5wcm90b3R5cGU9T2JqZWN0LmNyZWF0ZSh2LnByb3RvdHlwZSk7Si5wcm90b3R5cGUuY29uc3RydWN0b3I9SjtKLnByb3RvdHlwZS5fX2NsYXNzX189SjtKLl9fY2FjaGVfXz17fTthLkRyYWNvSW50OEFycmF5PUo7Si5wcm90b3R5cGUuR2V0VmFsdWU9Si5wcm90b3R5cGUuR2V0VmFsdWU9ZnVuY3Rpb24oYil7dmFyIGM9dGhpcy5wdHI7YiYmIm9iamVjdCI9PT10eXBlb2YgYiYmKGI9Yi5wdHIpO3JldHVybiBKYihjLGIpfTtKLnByb3RvdHlwZS5zaXplPUoucHJvdG90eXBlLnNpemU9ZnVuY3Rpb24oKXtyZXR1cm4gS2IodGhpcy5wdHIpfTtKLnByb3RvdHlwZS5fX2Rlc3Ryb3lfXz1KLnByb3RvdHlwZS5fX2Rlc3Ryb3lfXz1mdW5jdGlvbigpe0xiKHRoaXMucHRyKX07CksucHJvdG90eXBlPU9iamVjdC5jcmVhdGUodi5wcm90b3R5cGUpO0sucHJvdG90eXBlLmNvbnN0cnVjdG9yPUs7Sy5wcm90b3R5cGUuX19jbGFzc19fPUs7Sy5fX2NhY2hlX189e307YS5EcmFjb1VJbnQ4QXJyYXk9SztLLnByb3RvdHlwZS5HZXRWYWx1ZT1LLnByb3RvdHlwZS5HZXRWYWx1ZT1mdW5jdGlvbihiKXt2YXIgYz10aGlzLnB0cjtiJiYib2JqZWN0Ij09PXR5cGVvZiBiJiYoYj1iLnB0cik7cmV0dXJuIE1iKGMsYil9O0sucHJvdG90eXBlLnNpemU9Sy5wcm90b3R5cGUuc2l6ZT1mdW5jdGlvbigpe3JldHVybiBOYih0aGlzLnB0cil9O0sucHJvdG90eXBlLl9fZGVzdHJveV9fPUsucHJvdG90eXBlLl9fZGVzdHJveV9fPWZ1bmN0aW9uKCl7T2IodGhpcy5wdHIpfTtMLnByb3RvdHlwZT1PYmplY3QuY3JlYXRlKHYucHJvdG90eXBlKTtMLnByb3RvdHlwZS5jb25zdHJ1Y3Rvcj1MO0wucHJvdG90eXBlLl9fY2xhc3NfXz1MO0wuX19jYWNoZV9fPXt9O2EuRHJhY29JbnQxNkFycmF5PQpMO0wucHJvdG90eXBlLkdldFZhbHVlPUwucHJvdG90eXBlLkdldFZhbHVlPWZ1bmN0aW9uKGIpe3ZhciBjPXRoaXMucHRyO2ImJiJvYmplY3QiPT09dHlwZW9mIGImJihiPWIucHRyKTtyZXR1cm4gUGIoYyxiKX07TC5wcm90b3R5cGUuc2l6ZT1MLnByb3RvdHlwZS5zaXplPWZ1bmN0aW9uKCl7cmV0dXJuIFFiKHRoaXMucHRyKX07TC5wcm90b3R5cGUuX19kZXN0cm95X189TC5wcm90b3R5cGUuX19kZXN0cm95X189ZnVuY3Rpb24oKXtSYih0aGlzLnB0cil9O00ucHJvdG90eXBlPU9iamVjdC5jcmVhdGUodi5wcm90b3R5cGUpO00ucHJvdG90eXBlLmNvbnN0cnVjdG9yPU07TS5wcm90b3R5cGUuX19jbGFzc19fPU07TS5fX2NhY2hlX189e307YS5EcmFjb1VJbnQxNkFycmF5PU07TS5wcm90b3R5cGUuR2V0VmFsdWU9TS5wcm90b3R5cGUuR2V0VmFsdWU9ZnVuY3Rpb24oYil7dmFyIGM9dGhpcy5wdHI7YiYmIm9iamVjdCI9PT10eXBlb2YgYiYmKGI9Yi5wdHIpO3JldHVybiBTYihjLGIpfTsKTS5wcm90b3R5cGUuc2l6ZT1NLnByb3RvdHlwZS5zaXplPWZ1bmN0aW9uKCl7cmV0dXJuIFRiKHRoaXMucHRyKX07TS5wcm90b3R5cGUuX19kZXN0cm95X189TS5wcm90b3R5cGUuX19kZXN0cm95X189ZnVuY3Rpb24oKXtVYih0aGlzLnB0cil9O04ucHJvdG90eXBlPU9iamVjdC5jcmVhdGUodi5wcm90b3R5cGUpO04ucHJvdG90eXBlLmNvbnN0cnVjdG9yPU47Ti5wcm90b3R5cGUuX19jbGFzc19fPU47Ti5fX2NhY2hlX189e307YS5EcmFjb0ludDMyQXJyYXk9TjtOLnByb3RvdHlwZS5HZXRWYWx1ZT1OLnByb3RvdHlwZS5HZXRWYWx1ZT1mdW5jdGlvbihiKXt2YXIgYz10aGlzLnB0cjtiJiYib2JqZWN0Ij09PXR5cGVvZiBiJiYoYj1iLnB0cik7cmV0dXJuIFZiKGMsYil9O04ucHJvdG90eXBlLnNpemU9Ti5wcm90b3R5cGUuc2l6ZT1mdW5jdGlvbigpe3JldHVybiBXYih0aGlzLnB0cil9O04ucHJvdG90eXBlLl9fZGVzdHJveV9fPU4ucHJvdG90eXBlLl9fZGVzdHJveV9fPWZ1bmN0aW9uKCl7WGIodGhpcy5wdHIpfTsKTy5wcm90b3R5cGU9T2JqZWN0LmNyZWF0ZSh2LnByb3RvdHlwZSk7Ty5wcm90b3R5cGUuY29uc3RydWN0b3I9TztPLnByb3RvdHlwZS5fX2NsYXNzX189TztPLl9fY2FjaGVfXz17fTthLkRyYWNvVUludDMyQXJyYXk9TztPLnByb3RvdHlwZS5HZXRWYWx1ZT1PLnByb3RvdHlwZS5HZXRWYWx1ZT1mdW5jdGlvbihiKXt2YXIgYz10aGlzLnB0cjtiJiYib2JqZWN0Ij09PXR5cGVvZiBiJiYoYj1iLnB0cik7cmV0dXJuIFliKGMsYil9O08ucHJvdG90eXBlLnNpemU9Ty5wcm90b3R5cGUuc2l6ZT1mdW5jdGlvbigpe3JldHVybiBaYih0aGlzLnB0cil9O08ucHJvdG90eXBlLl9fZGVzdHJveV9fPU8ucHJvdG90eXBlLl9fZGVzdHJveV9fPWZ1bmN0aW9uKCl7JGIodGhpcy5wdHIpfTt6LnByb3RvdHlwZT1PYmplY3QuY3JlYXRlKHYucHJvdG90eXBlKTt6LnByb3RvdHlwZS5jb25zdHJ1Y3Rvcj16O3oucHJvdG90eXBlLl9fY2xhc3NfXz16O3ouX19jYWNoZV9fPXt9O2EuTWV0YWRhdGFRdWVyaWVyPQp6O3oucHJvdG90eXBlLkhhc0VudHJ5PXoucHJvdG90eXBlLkhhc0VudHJ5PWZ1bmN0aW9uKGIsYyl7dmFyIGQ9dGhpcy5wdHI7ci5wcmVwYXJlKCk7YiYmIm9iamVjdCI9PT10eXBlb2YgYiYmKGI9Yi5wdHIpO2M9YyYmIm9iamVjdCI9PT10eXBlb2YgYz9jLnB0cjpSKGMpO3JldHVybiEhYWMoZCxiLGMpfTt6LnByb3RvdHlwZS5HZXRJbnRFbnRyeT16LnByb3RvdHlwZS5HZXRJbnRFbnRyeT1mdW5jdGlvbihiLGMpe3ZhciBkPXRoaXMucHRyO3IucHJlcGFyZSgpO2ImJiJvYmplY3QiPT09dHlwZW9mIGImJihiPWIucHRyKTtjPWMmJiJvYmplY3QiPT09dHlwZW9mIGM/Yy5wdHI6UihjKTtyZXR1cm4gYmMoZCxiLGMpfTt6LnByb3RvdHlwZS5HZXRJbnRFbnRyeUFycmF5PXoucHJvdG90eXBlLkdldEludEVudHJ5QXJyYXk9ZnVuY3Rpb24oYixjLGQpe3ZhciBnPXRoaXMucHRyO3IucHJlcGFyZSgpO2ImJiJvYmplY3QiPT09dHlwZW9mIGImJihiPWIucHRyKTtjPWMmJiJvYmplY3QiPT09CnR5cGVvZiBjP2MucHRyOlIoYyk7ZCYmIm9iamVjdCI9PT10eXBlb2YgZCYmKGQ9ZC5wdHIpO2NjKGcsYixjLGQpfTt6LnByb3RvdHlwZS5HZXREb3VibGVFbnRyeT16LnByb3RvdHlwZS5HZXREb3VibGVFbnRyeT1mdW5jdGlvbihiLGMpe3ZhciBkPXRoaXMucHRyO3IucHJlcGFyZSgpO2ImJiJvYmplY3QiPT09dHlwZW9mIGImJihiPWIucHRyKTtjPWMmJiJvYmplY3QiPT09dHlwZW9mIGM/Yy5wdHI6UihjKTtyZXR1cm4gZGMoZCxiLGMpfTt6LnByb3RvdHlwZS5HZXRTdHJpbmdFbnRyeT16LnByb3RvdHlwZS5HZXRTdHJpbmdFbnRyeT1mdW5jdGlvbihiLGMpe3ZhciBkPXRoaXMucHRyO3IucHJlcGFyZSgpO2ImJiJvYmplY3QiPT09dHlwZW9mIGImJihiPWIucHRyKTtjPWMmJiJvYmplY3QiPT09dHlwZW9mIGM/Yy5wdHI6UihjKTtyZXR1cm4gcChlYyhkLGIsYykpfTt6LnByb3RvdHlwZS5OdW1FbnRyaWVzPXoucHJvdG90eXBlLk51bUVudHJpZXM9ZnVuY3Rpb24oYil7dmFyIGM9dGhpcy5wdHI7CmImJiJvYmplY3QiPT09dHlwZW9mIGImJihiPWIucHRyKTtyZXR1cm4gZmMoYyxiKX07ei5wcm90b3R5cGUuR2V0RW50cnlOYW1lPXoucHJvdG90eXBlLkdldEVudHJ5TmFtZT1mdW5jdGlvbihiLGMpe3ZhciBkPXRoaXMucHRyO2ImJiJvYmplY3QiPT09dHlwZW9mIGImJihiPWIucHRyKTtjJiYib2JqZWN0Ij09PXR5cGVvZiBjJiYoYz1jLnB0cik7cmV0dXJuIHAoZ2MoZCxiLGMpKX07ei5wcm90b3R5cGUuX19kZXN0cm95X189ei5wcm90b3R5cGUuX19kZXN0cm95X189ZnVuY3Rpb24oKXtoYyh0aGlzLnB0cil9O20ucHJvdG90eXBlPU9iamVjdC5jcmVhdGUodi5wcm90b3R5cGUpO20ucHJvdG90eXBlLmNvbnN0cnVjdG9yPW07bS5wcm90b3R5cGUuX19jbGFzc19fPW07bS5fX2NhY2hlX189e307YS5EZWNvZGVyPW07bS5wcm90b3R5cGUuRGVjb2RlQXJyYXlUb1BvaW50Q2xvdWQ9bS5wcm90b3R5cGUuRGVjb2RlQXJyYXlUb1BvaW50Q2xvdWQ9ZnVuY3Rpb24oYixjLGQpe3ZhciBnPQp0aGlzLnB0cjtyLnByZXBhcmUoKTsib2JqZWN0Ij09dHlwZW9mIGImJihiPVooYikpO2MmJiJvYmplY3QiPT09dHlwZW9mIGMmJihjPWMucHRyKTtkJiYib2JqZWN0Ij09PXR5cGVvZiBkJiYoZD1kLnB0cik7cmV0dXJuIEIoaWMoZyxiLGMsZCksQyl9O20ucHJvdG90eXBlLkRlY29kZUFycmF5VG9NZXNoPW0ucHJvdG90eXBlLkRlY29kZUFycmF5VG9NZXNoPWZ1bmN0aW9uKGIsYyxkKXt2YXIgZz10aGlzLnB0cjtyLnByZXBhcmUoKTsib2JqZWN0Ij09dHlwZW9mIGImJihiPVooYikpO2MmJiJvYmplY3QiPT09dHlwZW9mIGMmJihjPWMucHRyKTtkJiYib2JqZWN0Ij09PXR5cGVvZiBkJiYoZD1kLnB0cik7cmV0dXJuIEIoamMoZyxiLGMsZCksQyl9O20ucHJvdG90eXBlLkdldEF0dHJpYnV0ZUlkPW0ucHJvdG90eXBlLkdldEF0dHJpYnV0ZUlkPWZ1bmN0aW9uKGIsYyl7dmFyIGQ9dGhpcy5wdHI7YiYmIm9iamVjdCI9PT10eXBlb2YgYiYmKGI9Yi5wdHIpO2MmJiJvYmplY3QiPT09dHlwZW9mIGMmJgooYz1jLnB0cik7cmV0dXJuIGtjKGQsYixjKX07bS5wcm90b3R5cGUuR2V0QXR0cmlidXRlSWRCeU5hbWU9bS5wcm90b3R5cGUuR2V0QXR0cmlidXRlSWRCeU5hbWU9ZnVuY3Rpb24oYixjKXt2YXIgZD10aGlzLnB0cjtyLnByZXBhcmUoKTtiJiYib2JqZWN0Ij09PXR5cGVvZiBiJiYoYj1iLnB0cik7Yz1jJiYib2JqZWN0Ij09PXR5cGVvZiBjP2MucHRyOlIoYyk7cmV0dXJuIGxjKGQsYixjKX07bS5wcm90b3R5cGUuR2V0QXR0cmlidXRlSWRCeU1ldGFkYXRhRW50cnk9bS5wcm90b3R5cGUuR2V0QXR0cmlidXRlSWRCeU1ldGFkYXRhRW50cnk9ZnVuY3Rpb24oYixjLGQpe3ZhciBnPXRoaXMucHRyO3IucHJlcGFyZSgpO2ImJiJvYmplY3QiPT09dHlwZW9mIGImJihiPWIucHRyKTtjPWMmJiJvYmplY3QiPT09dHlwZW9mIGM/Yy5wdHI6UihjKTtkPWQmJiJvYmplY3QiPT09dHlwZW9mIGQ/ZC5wdHI6UihkKTtyZXR1cm4gbWMoZyxiLGMsZCl9O20ucHJvdG90eXBlLkdldEF0dHJpYnV0ZT0KbS5wcm90b3R5cGUuR2V0QXR0cmlidXRlPWZ1bmN0aW9uKGIsYyl7dmFyIGQ9dGhpcy5wdHI7YiYmIm9iamVjdCI9PT10eXBlb2YgYiYmKGI9Yi5wdHIpO2MmJiJvYmplY3QiPT09dHlwZW9mIGMmJihjPWMucHRyKTtyZXR1cm4gQihuYyhkLGIsYykseCl9O20ucHJvdG90eXBlLkdldEF0dHJpYnV0ZUJ5VW5pcXVlSWQ9bS5wcm90b3R5cGUuR2V0QXR0cmlidXRlQnlVbmlxdWVJZD1mdW5jdGlvbihiLGMpe3ZhciBkPXRoaXMucHRyO2ImJiJvYmplY3QiPT09dHlwZW9mIGImJihiPWIucHRyKTtjJiYib2JqZWN0Ij09PXR5cGVvZiBjJiYoYz1jLnB0cik7cmV0dXJuIEIob2MoZCxiLGMpLHgpfTttLnByb3RvdHlwZS5HZXRNZXRhZGF0YT1tLnByb3RvdHlwZS5HZXRNZXRhZGF0YT1mdW5jdGlvbihiKXt2YXIgYz10aGlzLnB0cjtiJiYib2JqZWN0Ij09PXR5cGVvZiBiJiYoYj1iLnB0cik7cmV0dXJuIEIocGMoYyxiKSxUKX07bS5wcm90b3R5cGUuR2V0QXR0cmlidXRlTWV0YWRhdGE9bS5wcm90b3R5cGUuR2V0QXR0cmlidXRlTWV0YWRhdGE9CmZ1bmN0aW9uKGIsYyl7dmFyIGQ9dGhpcy5wdHI7YiYmIm9iamVjdCI9PT10eXBlb2YgYiYmKGI9Yi5wdHIpO2MmJiJvYmplY3QiPT09dHlwZW9mIGMmJihjPWMucHRyKTtyZXR1cm4gQihxYyhkLGIsYyksVCl9O20ucHJvdG90eXBlLkdldEZhY2VGcm9tTWVzaD1tLnByb3RvdHlwZS5HZXRGYWNlRnJvbU1lc2g9ZnVuY3Rpb24oYixjLGQpe3ZhciBnPXRoaXMucHRyO2ImJiJvYmplY3QiPT09dHlwZW9mIGImJihiPWIucHRyKTtjJiYib2JqZWN0Ij09PXR5cGVvZiBjJiYoYz1jLnB0cik7ZCYmIm9iamVjdCI9PT10eXBlb2YgZCYmKGQ9ZC5wdHIpO3JldHVybiEhcmMoZyxiLGMsZCl9O20ucHJvdG90eXBlLkdldFRyaWFuZ2xlU3RyaXBzRnJvbU1lc2g9bS5wcm90b3R5cGUuR2V0VHJpYW5nbGVTdHJpcHNGcm9tTWVzaD1mdW5jdGlvbihiLGMpe3ZhciBkPXRoaXMucHRyO2ImJiJvYmplY3QiPT09dHlwZW9mIGImJihiPWIucHRyKTtjJiYib2JqZWN0Ij09PXR5cGVvZiBjJiYoYz1jLnB0cik7CnJldHVybiBzYyhkLGIsYyl9O20ucHJvdG90eXBlLkdldFRyaWFuZ2xlc1VJbnQxNkFycmF5PW0ucHJvdG90eXBlLkdldFRyaWFuZ2xlc1VJbnQxNkFycmF5PWZ1bmN0aW9uKGIsYyxkKXt2YXIgZz10aGlzLnB0cjtiJiYib2JqZWN0Ij09PXR5cGVvZiBiJiYoYj1iLnB0cik7YyYmIm9iamVjdCI9PT10eXBlb2YgYyYmKGM9Yy5wdHIpO2QmJiJvYmplY3QiPT09dHlwZW9mIGQmJihkPWQucHRyKTtyZXR1cm4hIXRjKGcsYixjLGQpfTttLnByb3RvdHlwZS5HZXRUcmlhbmdsZXNVSW50MzJBcnJheT1tLnByb3RvdHlwZS5HZXRUcmlhbmdsZXNVSW50MzJBcnJheT1mdW5jdGlvbihiLGMsZCl7dmFyIGc9dGhpcy5wdHI7YiYmIm9iamVjdCI9PT10eXBlb2YgYiYmKGI9Yi5wdHIpO2MmJiJvYmplY3QiPT09dHlwZW9mIGMmJihjPWMucHRyKTtkJiYib2JqZWN0Ij09PXR5cGVvZiBkJiYoZD1kLnB0cik7cmV0dXJuISF1YyhnLGIsYyxkKX07bS5wcm90b3R5cGUuR2V0QXR0cmlidXRlRmxvYXQ9bS5wcm90b3R5cGUuR2V0QXR0cmlidXRlRmxvYXQ9CmZ1bmN0aW9uKGIsYyxkKXt2YXIgZz10aGlzLnB0cjtiJiYib2JqZWN0Ij09PXR5cGVvZiBiJiYoYj1iLnB0cik7YyYmIm9iamVjdCI9PT10eXBlb2YgYyYmKGM9Yy5wdHIpO2QmJiJvYmplY3QiPT09dHlwZW9mIGQmJihkPWQucHRyKTtyZXR1cm4hIXZjKGcsYixjLGQpfTttLnByb3RvdHlwZS5HZXRBdHRyaWJ1dGVGbG9hdEZvckFsbFBvaW50cz1tLnByb3RvdHlwZS5HZXRBdHRyaWJ1dGVGbG9hdEZvckFsbFBvaW50cz1mdW5jdGlvbihiLGMsZCl7dmFyIGc9dGhpcy5wdHI7YiYmIm9iamVjdCI9PT10eXBlb2YgYiYmKGI9Yi5wdHIpO2MmJiJvYmplY3QiPT09dHlwZW9mIGMmJihjPWMucHRyKTtkJiYib2JqZWN0Ij09PXR5cGVvZiBkJiYoZD1kLnB0cik7cmV0dXJuISF3YyhnLGIsYyxkKX07bS5wcm90b3R5cGUuR2V0QXR0cmlidXRlSW50Rm9yQWxsUG9pbnRzPW0ucHJvdG90eXBlLkdldEF0dHJpYnV0ZUludEZvckFsbFBvaW50cz1mdW5jdGlvbihiLGMsZCl7dmFyIGc9dGhpcy5wdHI7CmImJiJvYmplY3QiPT09dHlwZW9mIGImJihiPWIucHRyKTtjJiYib2JqZWN0Ij09PXR5cGVvZiBjJiYoYz1jLnB0cik7ZCYmIm9iamVjdCI9PT10eXBlb2YgZCYmKGQ9ZC5wdHIpO3JldHVybiEheGMoZyxiLGMsZCl9O20ucHJvdG90eXBlLkdldEF0dHJpYnV0ZUludDhGb3JBbGxQb2ludHM9bS5wcm90b3R5cGUuR2V0QXR0cmlidXRlSW50OEZvckFsbFBvaW50cz1mdW5jdGlvbihiLGMsZCl7dmFyIGc9dGhpcy5wdHI7YiYmIm9iamVjdCI9PT10eXBlb2YgYiYmKGI9Yi5wdHIpO2MmJiJvYmplY3QiPT09dHlwZW9mIGMmJihjPWMucHRyKTtkJiYib2JqZWN0Ij09PXR5cGVvZiBkJiYoZD1kLnB0cik7cmV0dXJuISF5YyhnLGIsYyxkKX07bS5wcm90b3R5cGUuR2V0QXR0cmlidXRlVUludDhGb3JBbGxQb2ludHM9bS5wcm90b3R5cGUuR2V0QXR0cmlidXRlVUludDhGb3JBbGxQb2ludHM9ZnVuY3Rpb24oYixjLGQpe3ZhciBnPXRoaXMucHRyO2ImJiJvYmplY3QiPT09dHlwZW9mIGImJihiPQpiLnB0cik7YyYmIm9iamVjdCI9PT10eXBlb2YgYyYmKGM9Yy5wdHIpO2QmJiJvYmplY3QiPT09dHlwZW9mIGQmJihkPWQucHRyKTtyZXR1cm4hIXpjKGcsYixjLGQpfTttLnByb3RvdHlwZS5HZXRBdHRyaWJ1dGVJbnQxNkZvckFsbFBvaW50cz1tLnByb3RvdHlwZS5HZXRBdHRyaWJ1dGVJbnQxNkZvckFsbFBvaW50cz1mdW5jdGlvbihiLGMsZCl7dmFyIGc9dGhpcy5wdHI7YiYmIm9iamVjdCI9PT10eXBlb2YgYiYmKGI9Yi5wdHIpO2MmJiJvYmplY3QiPT09dHlwZW9mIGMmJihjPWMucHRyKTtkJiYib2JqZWN0Ij09PXR5cGVvZiBkJiYoZD1kLnB0cik7cmV0dXJuISFBYyhnLGIsYyxkKX07bS5wcm90b3R5cGUuR2V0QXR0cmlidXRlVUludDE2Rm9yQWxsUG9pbnRzPW0ucHJvdG90eXBlLkdldEF0dHJpYnV0ZVVJbnQxNkZvckFsbFBvaW50cz1mdW5jdGlvbihiLGMsZCl7dmFyIGc9dGhpcy5wdHI7YiYmIm9iamVjdCI9PT10eXBlb2YgYiYmKGI9Yi5wdHIpO2MmJiJvYmplY3QiPT09dHlwZW9mIGMmJgooYz1jLnB0cik7ZCYmIm9iamVjdCI9PT10eXBlb2YgZCYmKGQ9ZC5wdHIpO3JldHVybiEhQmMoZyxiLGMsZCl9O20ucHJvdG90eXBlLkdldEF0dHJpYnV0ZUludDMyRm9yQWxsUG9pbnRzPW0ucHJvdG90eXBlLkdldEF0dHJpYnV0ZUludDMyRm9yQWxsUG9pbnRzPWZ1bmN0aW9uKGIsYyxkKXt2YXIgZz10aGlzLnB0cjtiJiYib2JqZWN0Ij09PXR5cGVvZiBiJiYoYj1iLnB0cik7YyYmIm9iamVjdCI9PT10eXBlb2YgYyYmKGM9Yy5wdHIpO2QmJiJvYmplY3QiPT09dHlwZW9mIGQmJihkPWQucHRyKTtyZXR1cm4hIUNjKGcsYixjLGQpfTttLnByb3RvdHlwZS5HZXRBdHRyaWJ1dGVVSW50MzJGb3JBbGxQb2ludHM9bS5wcm90b3R5cGUuR2V0QXR0cmlidXRlVUludDMyRm9yQWxsUG9pbnRzPWZ1bmN0aW9uKGIsYyxkKXt2YXIgZz10aGlzLnB0cjtiJiYib2JqZWN0Ij09PXR5cGVvZiBiJiYoYj1iLnB0cik7YyYmIm9iamVjdCI9PT10eXBlb2YgYyYmKGM9Yy5wdHIpO2QmJiJvYmplY3QiPT09CnR5cGVvZiBkJiYoZD1kLnB0cik7cmV0dXJuISFEYyhnLGIsYyxkKX07bS5wcm90b3R5cGUuR2V0QXR0cmlidXRlRGF0YUFycmF5Rm9yQWxsUG9pbnRzPW0ucHJvdG90eXBlLkdldEF0dHJpYnV0ZURhdGFBcnJheUZvckFsbFBvaW50cz1mdW5jdGlvbihiLGMsZCxnLHQpe3ZhciBhYT10aGlzLnB0cjtiJiYib2JqZWN0Ij09PXR5cGVvZiBiJiYoYj1iLnB0cik7YyYmIm9iamVjdCI9PT10eXBlb2YgYyYmKGM9Yy5wdHIpO2QmJiJvYmplY3QiPT09dHlwZW9mIGQmJihkPWQucHRyKTtnJiYib2JqZWN0Ij09PXR5cGVvZiBnJiYoZz1nLnB0cik7dCYmIm9iamVjdCI9PT10eXBlb2YgdCYmKHQ9dC5wdHIpO3JldHVybiEhRWMoYWEsYixjLGQsZyx0KX07bS5wcm90b3R5cGUuU2tpcEF0dHJpYnV0ZVRyYW5zZm9ybT1tLnByb3RvdHlwZS5Ta2lwQXR0cmlidXRlVHJhbnNmb3JtPWZ1bmN0aW9uKGIpe3ZhciBjPXRoaXMucHRyO2ImJiJvYmplY3QiPT09dHlwZW9mIGImJihiPWIucHRyKTtGYyhjLApiKX07bS5wcm90b3R5cGUuR2V0RW5jb2RlZEdlb21ldHJ5VHlwZV9EZXByZWNhdGVkPW0ucHJvdG90eXBlLkdldEVuY29kZWRHZW9tZXRyeVR5cGVfRGVwcmVjYXRlZD1mdW5jdGlvbihiKXt2YXIgYz10aGlzLnB0cjtiJiYib2JqZWN0Ij09PXR5cGVvZiBiJiYoYj1iLnB0cik7cmV0dXJuIEdjKGMsYil9O20ucHJvdG90eXBlLkRlY29kZUJ1ZmZlclRvUG9pbnRDbG91ZD1tLnByb3RvdHlwZS5EZWNvZGVCdWZmZXJUb1BvaW50Q2xvdWQ9ZnVuY3Rpb24oYixjKXt2YXIgZD10aGlzLnB0cjtiJiYib2JqZWN0Ij09PXR5cGVvZiBiJiYoYj1iLnB0cik7YyYmIm9iamVjdCI9PT10eXBlb2YgYyYmKGM9Yy5wdHIpO3JldHVybiBCKEhjKGQsYixjKSxDKX07bS5wcm90b3R5cGUuRGVjb2RlQnVmZmVyVG9NZXNoPW0ucHJvdG90eXBlLkRlY29kZUJ1ZmZlclRvTWVzaD1mdW5jdGlvbihiLGMpe3ZhciBkPXRoaXMucHRyO2ImJiJvYmplY3QiPT09dHlwZW9mIGImJihiPWIucHRyKTtjJiYib2JqZWN0Ij09PQp0eXBlb2YgYyYmKGM9Yy5wdHIpO3JldHVybiBCKEljKGQsYixjKSxDKX07bS5wcm90b3R5cGUuX19kZXN0cm95X189bS5wcm90b3R5cGUuX19kZXN0cm95X189ZnVuY3Rpb24oKXtKYyh0aGlzLnB0cil9OyhmdW5jdGlvbigpe2Z1bmN0aW9uIGIoKXthLkFUVFJJQlVURV9JTlZBTElEX1RSQU5TRk9STT1LYygpO2EuQVRUUklCVVRFX05PX1RSQU5TRk9STT1MYygpO2EuQVRUUklCVVRFX1FVQU5USVpBVElPTl9UUkFOU0ZPUk09TWMoKTthLkFUVFJJQlVURV9PQ1RBSEVEUk9OX1RSQU5TRk9STT1OYygpO2EuSU5WQUxJRD1PYygpO2EuUE9TSVRJT049UGMoKTthLk5PUk1BTD1RYygpO2EuQ09MT1I9UmMoKTthLlRFWF9DT09SRD1TYygpO2EuR0VORVJJQz1UYygpO2EuSU5WQUxJRF9HRU9NRVRSWV9UWVBFPVVjKCk7YS5QT0lOVF9DTE9VRD1WYygpO2EuVFJJQU5HVUxBUl9NRVNIPVdjKCk7YS5EVF9JTlZBTElEPVhjKCk7YS5EVF9JTlQ4PVljKCk7YS5EVF9VSU5UOD1aYygpO2EuRFRfSU5UMTY9CiRjKCk7YS5EVF9VSU5UMTY9YWQoKTthLkRUX0lOVDMyPWJkKCk7YS5EVF9VSU5UMzI9Y2QoKTthLkRUX0lOVDY0PWRkKCk7YS5EVF9VSU5UNjQ9ZWQoKTthLkRUX0ZMT0FUMzI9ZmQoKTthLkRUX0ZMT0FUNjQ9Z2QoKTthLkRUX0JPT0w9aGQoKTthLkRUX1RZUEVTX0NPVU5UPWlkKCk7YS5PSz1qZCgpO2EuRFJBQ09fRVJST1I9a2QoKTthLklPX0VSUk9SPWxkKCk7YS5JTlZBTElEX1BBUkFNRVRFUj1tZCgpO2EuVU5TVVBQT1JURURfVkVSU0lPTj1uZCgpO2EuVU5LTk9XTl9WRVJTSU9OPW9kKCl9dmE/YigpOm9hLnVuc2hpZnQoYil9KSgpO2lmKCJmdW5jdGlvbiI9PT10eXBlb2YgYS5vbk1vZHVsZVBhcnNlZClhLm9uTW9kdWxlUGFyc2VkKCk7YS5EZWNvZGVyLnByb3RvdHlwZS5HZXRFbmNvZGVkR2VvbWV0cnlUeXBlPWZ1bmN0aW9uKGIpe2lmKGIuX19jbGFzc19fJiZiLl9fY2xhc3NfXz09PWEuRGVjb2RlckJ1ZmZlcilyZXR1cm4gYS5EZWNvZGVyLnByb3RvdHlwZS5HZXRFbmNvZGVkR2VvbWV0cnlUeXBlX0RlcHJlY2F0ZWQoYik7CmlmKDg+Yi5ieXRlTGVuZ3RoKXJldHVybiBhLklOVkFMSURfR0VPTUVUUllfVFlQRTtzd2l0Y2goYls3XSl7Y2FzZSAwOnJldHVybiBhLlBPSU5UX0NMT1VEO2Nhc2UgMTpyZXR1cm4gYS5UUklBTkdVTEFSX01FU0g7ZGVmYXVsdDpyZXR1cm4gYS5JTlZBTElEX0dFT01FVFJZX1RZUEV9fTtyZXR1cm4gbi5yZWFkeX19KCk7Im9iamVjdCI9PT10eXBlb2YgZXhwb3J0cyYmIm9iamVjdCI9PT10eXBlb2YgbW9kdWxlP21vZHVsZS5leHBvcnRzPURyYWNvRGVjb2Rlck1vZHVsZToiZnVuY3Rpb24iPT09dHlwZW9mIGRlZmluZSYmZGVmaW5lLmFtZD9kZWZpbmUoW10sZnVuY3Rpb24oKXtyZXR1cm4gRHJhY29EZWNvZGVyTW9kdWxlfSk6Im9iamVjdCI9PT10eXBlb2YgZXhwb3J0cyYmKGV4cG9ydHMuRHJhY29EZWNvZGVyTW9kdWxlPURyYWNvRGVjb2Rlck1vZHVsZSk7Cg==", dm = new URL("./assets/draco_decoder.wasm", import.meta.url).href, fm = [
	"glb",
	"gltf",
	"fbx",
	"obj",
	"stl",
	"ply",
	"3mf"
], pm = ".glb,.gltf,.fbx,.obj,.stl,.ply,.3mf,.bin,.mtl,.png,.jpg,.jpeg,.webp,.tga,.bmp", mm = (e) => e.toLowerCase().split(".").pop() ?? "", hm = (e) => decodeURIComponent(e.split(/[?#]/)[0].split(/[\\/]/).pop() ?? "").toLowerCase();
function gm(e, t, n = 2048) {
	let r = e.image;
	if (!r || !r.width || !r.height || e.isCompressedTexture) return null;
	let i = Math.min(1, n / Math.max(r.width, r.height)), [a, o] = t ?? [Math.max(1, Math.round(r.width * i)), Math.max(1, Math.round(r.height * i))], s = new OffscreenCanvas(a, o).getContext("2d", { willReadFrequently: !0 });
	try {
		if (r.data) {
			let e = r.data, t = e.length / (r.width * r.height);
			if (t !== 3 && t !== 4) return null;
			let n = new Uint8ClampedArray(r.width * r.height * 4);
			for (let i = 0; i < r.width * r.height; i++) n[i * 4] = e[i * t], n[i * 4 + 1] = e[i * t + 1], n[i * 4 + 2] = e[i * t + 2], n[i * 4 + 3] = t === 4 ? e[i * t + 3] : 255;
			let i = new OffscreenCanvas(r.width, r.height);
			i.getContext("2d").putImageData(new ImageData(n, r.width, r.height), 0, 0), s.drawImage(i, 0, 0, a, o);
		} else s.drawImage(r, 0, 0, a, o);
	} catch {
		return null;
	}
	return s;
}
var _m = async (e, t) => {
	let n = await e.convertToBlob({
		type: t,
		quality: .9
	});
	return {
		mime: n.type,
		bytes: new Uint8Array(await n.arrayBuffer())
	};
}, vm = async (e, t) => {
	let n = gm(e);
	if (!n) return null;
	let r = t === "data";
	if (!r) {
		let e = n.getImageData(0, 0, n.canvas.width, n.canvas.height).data;
		for (let t = 3; t < e.length; t += 4) if (e[t] < 250) {
			r = !0;
			break;
		}
	}
	return _m(n.canvas, r ? "image/png" : "image/jpeg");
}, ym = async (e, t) => {
	let n = gm(e ?? t);
	if (!n) return null;
	let r = [n.canvas.width, n.canvas.height], i = e ? gm(e, r)?.getImageData(0, 0, ...r).data : null, a = t ? gm(t, r)?.getImageData(0, 0, ...r).data : null, o = new ImageData(...r);
	for (let e = 0; e < o.data.length; e += 4) o.data[e] = 255, o.data[e + 1] = i ? i[e + 1] : 255, o.data[e + 2] = a ? a[e + 2] : 255, o.data[e + 3] = 255;
	let s = new OffscreenCanvas(...r);
	return s.getContext("2d").putImageData(o, 0, 0), _m(s, "image/png");
};
function bm(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(n.name.toLowerCase(), URL.createObjectURL(n));
	let n = new Me(), r = 0, i = null;
	n.setURLModifier((e) => e.startsWith("blob:") || e.startsWith("data:") ? e : t.get(hm(e)) ?? e), n.itemStart = ((e) => (t) => {
		r++, e(t);
	})(n.itemStart.bind(n));
	let a = (e) => (r = Math.max(0, r - 1), r || i?.(), e);
	return n.itemEnd = ((e) => (t) => e(a(t)))(n.itemEnd.bind(n)), n.itemError = ((e) => (t) => e(a(t)))(n.itemError.bind(n)), {
		manager: n,
		settled: () => new Promise((e) => {
			if (!r) return e();
			i = e, setTimeout(e, 2e4);
		}),
		dispose: () => t.forEach((e) => URL.revokeObjectURL(e))
	};
}
async function xm(e) {
	let t = e.find((e) => fm.includes(mm(e.name)));
	if (!t) throw Error(`Pick a 3D model: ${fm.map((e) => `.${e}`).join(", ")}.`);
	if (t.size > 2e8) throw Error("That model is over 200 MB; make it smaller first.");
	let n = mm(t.name), { manager: r, settled: i, dispose: a } = bm(e);
	try {
		let a, o = await t.arrayBuffer();
		if (n === "glb" || n === "gltf") {
			let [{ GLTFLoader: e }, { DRACOLoader: t }, { MeshoptDecoder: n }] = await Promise.all([
				import("./GLTFLoader-J2WflOAg.js"),
				import("./DRACOLoader-DokUApsL.js"),
				import("./meshopt_decoder.module-B2eONCO9.js")
			]), i = new e(r), s = new t(r);
			s.setDecoderPath({
				js: um,
				wasm: dm
			}), i.setDRACOLoader(s), i.setMeshoptDecoder(n);
			try {
				a = (await i.parseAsync(o, "")).scene;
			} finally {
				s.dispose();
			}
		} else if (n === "fbx") {
			let { FBXLoader: e } = await import("./FBXLoader-DpT2LdDo.js");
			a = new e(r).parse(o, "");
		} else if (n === "obj") {
			let [{ OBJLoader: t }, { MTLLoader: n }] = await Promise.all([import("./OBJLoader-BSsL_mG0.js"), import("./MTLLoader-DHa1sCB_.js")]), i = new t(r), s = e.find((e) => mm(e.name) === "mtl");
			if (s) {
				let e = new n(r).parse(await s.text(), "");
				e.preload(), i.setMaterials(e);
			}
			a = i.parse(new TextDecoder().decode(o));
		} else if (n === "stl") {
			let { STLLoader: e } = await import("./STLLoader-BlcQUutx.js"), t = new e(r).parse(o);
			t.computeVertexNormals();
			let n = !!t.getAttribute("color");
			a = new N(t, new ft({
				color: 14210268,
				roughness: .55,
				vertexColors: n
			})), a.rotation.x = -Math.PI / 2;
		} else if (n === "ply") {
			let { PLYLoader: e } = await import("./PLYLoader-OHhF-aWB.js"), t = new e(r).parse(o), n = !!t.getAttribute("color");
			a = new N(t, new ft({
				color: 14210268,
				roughness: .55,
				vertexColors: n
			}));
		} else {
			let { ThreeMFLoader: e } = await import("./3MFLoader-rnIv0uAn.js");
			a = new e(r).parse(o);
		}
		await i();
		let { asset: s, warnings: c } = await ro(a, vm, ym);
		return {
			asset: io(s, t.name.replace(/\.[^.]+$/, "")),
			warnings: c
		};
	} catch (e) {
		let t = e instanceof Error ? e.message : String(e);
		throw Error(t.startsWith("This model") || t.startsWith("There is") ? t : `That model could not be read: ${t}`);
	} finally {
		a();
	}
}
//#endregion
//#region src/model3d/fonts.ts
var Sm = [
	100,
	200,
	300,
	400,
	500,
	600,
	700,
	800,
	900
], Cm = (e, t) => Sm.filter((n) => n >= e && n <= t), wm = [
	"Arial",
	"Helvetica",
	"Georgia",
	"Times New Roman",
	"Verdana",
	"Trebuchet MS",
	"Impact",
	"Courier New",
	"Comic Sans MS"
].map((e) => ({
	family: e,
	source: "standard",
	weights: [400, 700]
})), Tm = [
	[
		"Bebas Neue",
		[400],
		"tall headline"
	],
	[
		"Anton",
		[400],
		"bold headline"
	],
	[
		"Archivo Black",
		[400],
		"heavy"
	],
	[
		"Montserrat",
		Cm(100, 900),
		"clean"
	],
	[
		"Poppins",
		Cm(100, 900),
		"round, clean"
	],
	[
		"Oswald",
		Cm(200, 700),
		"narrow"
	],
	[
		"Rubik",
		Cm(300, 900),
		"soft corners"
	],
	[
		"Fredoka",
		Cm(300, 700),
		"round, friendly"
	],
	[
		"Baloo 2",
		Cm(400, 800),
		"chunky, friendly"
	],
	[
		"Lilita One",
		[400],
		"chunky"
	],
	[
		"Titan One",
		[400],
		"chunky"
	],
	[
		"Luckiest Guy",
		[400],
		"comic"
	],
	[
		"Bangers",
		[400],
		"comic"
	],
	[
		"Bungee",
		[400],
		"signs"
	],
	[
		"Russo One",
		[400],
		"sporty"
	],
	[
		"Black Ops One",
		[400],
		"stencil"
	],
	[
		"Righteous",
		[400],
		"retro"
	],
	[
		"Monoton",
		[400],
		"neon lines"
	],
	[
		"Press Start 2P",
		[400],
		"pixel"
	],
	[
		"Permanent Marker",
		[400],
		"marker"
	],
	[
		"Pacifico",
		[400],
		"script"
	],
	[
		"Lobster",
		[400],
		"script"
	],
	[
		"Dancing Script",
		Cm(400, 700),
		"script"
	],
	[
		"Great Vibes",
		[400],
		"elegant script"
	],
	[
		"Playfair Display",
		Cm(400, 900),
		"elegant"
	],
	[
		"Abril Fatface",
		[400],
		"fashion"
	],
	[
		"Shrikhand",
		[400],
		"bold italic"
	],
	[
		"Comfortaa",
		Cm(300, 700),
		"rounded"
	],
	[
		"Noto Sans JP",
		Cm(100, 900),
		"Japanese, clean"
	],
	[
		"M PLUS Rounded 1c",
		[
			100,
			300,
			400,
			500,
			700,
			800,
			900
		],
		"Japanese, rounded"
	],
	[
		"Zen Maru Gothic",
		[
			300,
			400,
			500,
			700,
			900
		],
		"Japanese, soft"
	],
	[
		"Kosugi Maru",
		[400],
		"Japanese, rounded"
	],
	[
		"Dela Gothic One",
		[400],
		"Japanese, heavy"
	],
	[
		"Mochiy Pop One",
		[400],
		"Japanese, pop"
	],
	[
		"Reggae One",
		[400],
		"Japanese, bold"
	],
	[
		"RocknRoll One",
		[400],
		"Japanese, playful"
	],
	[
		"Yusei Magic",
		[400],
		"Japanese, marker"
	],
	[
		"DotGothic16",
		[400],
		"Japanese, pixel"
	]
].map(([e, t, n]) => ({
	family: e,
	source: "online",
	weights: [...t],
	note: n
})), Em = (e) => `family=${encodeURIComponent(e.family).replace(/%20/g, "+")}${e.weights.length > 1 ? `:wght@${e.weights.join(";")}` : ""}`, Dm = /* @__PURE__ */ new Set();
function Om(e) {
	return Dm.has(e) ? Promise.resolve() : (Dm.add(e), new Promise((t, n) => {
		let r = document.createElement("link");
		r.rel = "stylesheet", r.href = e, r.onload = () => t(), r.onerror = () => {
			Dm.delete(e), r.remove(), n(/* @__PURE__ */ Error("The online font could not be loaded (no internet?)."));
		}, document.head.appendChild(r);
	}));
}
async function km(e, t, n) {
	await Om(`https://fonts.googleapis.com/css2?${Em(e)}&display=block`), await document.fonts.load(`${t} 48px "${e.family}"`, n || e.family);
}
function Am(e) {
	let t = [...new Set(e.map((e) => e.family).join(""))].join("");
	return Om(`https://fonts.googleapis.com/css2?${e.map((e) => `family=${encodeURIComponent(e.family).replace(/%20/g, "+")}`).join("&")}&text=${encodeURIComponent(t)}&display=swap`).catch(() => void 0);
}
var jm = () => typeof window < "u" && typeof window.queryLocalFonts == "function", Mm = [
	[/thin|hairline/i, 100],
	[/extra ?light|ultra ?light/i, 200],
	[/light/i, 300],
	[/medium/i, 500],
	[/semi ?bold|demi ?bold/i, 600],
	[/extra ?bold|ultra ?bold/i, 800],
	[/black|heavy/i, 900],
	[/bold/i, 700]
];
async function Nm() {
	if (!window.queryLocalFonts) return [];
	let e = await window.queryLocalFonts(), t = /* @__PURE__ */ new Map();
	for (let n of e) {
		let e = Mm.find(([e]) => e.test(n.style))?.[1] ?? 400, r = t.get(n.family) ?? /* @__PURE__ */ new Set();
		r.add(e), t.set(n.family, r);
	}
	return [...t].sort(([e], [t]) => e.localeCompare(t)).map(([e, t]) => ({
		family: e,
		source: "computer",
		weights: [...t].sort((e, t) => e - t)
	}));
}
var Pm = /* @__PURE__ */ new Map(), Fm = () => [...Pm.values()];
async function Im(e) {
	let t = e.name.replace(/\.(ttf|otf|woff2?)$/i, "").replace(/[^\w -]+/g, " ").trim().slice(0, 60) || "My font", n = new FontFace(t, await e.arrayBuffer(), { weight: "100 900" });
	try {
		await n.load();
	} catch {
		throw Error("That file is not a font this browser can read (TTF, OTF, WOFF or WOFF2).");
	}
	document.fonts.add(n);
	let r = {
		family: t,
		source: "file",
		weights: [400]
	};
	return Pm.set(t, r), r;
}
function Lm(e) {
	if (wm.some((t) => t.family === e)) return !0;
	let t = document.createElement("canvas").getContext("2d");
	if (!t) return !0;
	let n = "mmmmmmmmmmlli WQ@#";
	return ["monospace", "serif"].some((r) => {
		t.font = `72px ${r}`;
		let i = t.measureText(n).width;
		return t.font = `72px "${e}", ${r}`, t.measureText(n).width !== i;
	});
}
async function Rm(e, t, n) {
	let r = Tm.find((t) => t.family === e);
	if (r) return km(r, t, n);
	if (await document.fonts.load(`${t} 48px "${e}"`, n).catch(() => void 0), !Lm(e)) throw Error(`“${e}” is not on this computer: pick another font, or load its font file.`);
}
//#endregion
//#region src/model3d/PenPad.tsx
var zm = 300, Bm = 15, Vm = ([e, t]) => [(e + .5) * zm, (.5 - t) * zm], Hm = ([e, t]) => [Math.round((e / zm - .5) * 1e4) / 1e4, Math.round((.5 - t / zm) * 1e4) / 1e4], Um = (e) => e.map((e) => ({
	closed: e.closed,
	nodes: e.nodes.map((e) => ({
		p: Vm(e.p),
		...e.in ? { in: Vm(e.in) } : {},
		...e.out ? { out: Vm(e.out) } : {}
	}))
})), Wm = (e) => e.map((e) => ({
	closed: e.closed,
	nodes: e.nodes.map((e) => ({
		p: Hm(e.p),
		...e.in ? { in: Hm(e.in) } : {},
		...e.out ? { out: Hm(e.out) } : {}
	}))
})), Gm = (e, t) => [e[0] - t[0], e[1] - t[1]], Km = (e, t) => [e[0] + t[0], e[1] + t[1]], qm = (e) => Math.hypot(e[0], e[1]), Jm = (e) => e.map((e) => ({
	closed: e.closed,
	nodes: e.nodes.map((e) => ({ ...e }))
}));
function Ym(e, t = e.closed) {
	let n = e.nodes;
	if (!n.length) return "";
	let r = (e, t) => e.out || t.in ? `C${(e.out ?? e.p).join(" ")} ${(t.in ?? t.p).join(" ")} ${t.p.join(" ")}` : `L${t.p.join(" ")}`, i = `M${n[0].p.join(" ")}`;
	for (let e = 1; e < n.length; e++) i += r(n[e - 1], n[e]);
	return t && n.length > 1 && (i += `${r(n[n.length - 1], n[0])}Z`), i;
}
function Xm(e, t) {
	let n = e.nodes, r = n[t];
	if (r.in || r.out) {
		delete r.in, delete r.out;
		return;
	}
	let i = n[(t - 1 + n.length) % n.length].p, a = n[(t + 1) % n.length].p, o = Gm(a, i), s = qm(o) || 1, c = Math.min(qm(Gm(a, r.p)), qm(Gm(r.p, i))) / 3 || 20, l = [o[0] / s * c, o[1] / s * c];
	r.in = Gm(r.p, l), r.out = Km(r.p, l);
}
function Zm({ initial: e, onPaths: t }) {
	let [n, r] = H(() => Um(e ?? [])), [i, a] = H(null), [o, s] = H(null), [c, l] = H(null), [u, d] = H(!1), f = un([]), p = un(null), m = un(null), h = un({
		paths: n,
		active: i
	});
	h.current = {
		paths: n,
		active: i
	}, ln(() => t(Wm(n)), [n, t]);
	let g = () => {
		f.current.push(Jm(h.current.paths)), f.current.length > 100 && f.current.shift();
	}, _ = () => {
		let e = f.current.pop();
		e && (r(e), a(null), s(null));
	}, v = () => {
		let { paths: e, active: t } = h.current;
		if (t === null) return;
		let n = e[t], i = Jm(e);
		n.nodes.length < 2 ? i.splice(t, 1) : i[t].closed = !0, r(i), a(null);
	}, y = () => {
		if (!o) return;
		g();
		let e = Jm(n);
		e[o[0]].nodes.splice(o[1], 1), e[o[0]].nodes.length < 2 && i !== o[0] && e.splice(o[0], 1), r(e.filter((e) => e.nodes.length)), s(null), i !== null && !e[i]?.nodes.length && a(null);
	};
	ln(() => {
		let e = (e) => {
			e.key === "Escape" && h.current.active !== null && (e.stopImmediatePropagation(), v());
		};
		return window.addEventListener("keydown", e, !0), () => window.removeEventListener("keydown", e, !0);
	}, []);
	let b = (e, t, n = !1) => {
		let r = m.current.getBoundingClientRect(), i = [(e.clientX - r.left) / r.width * zm, (e.clientY - r.top) / r.height * zm];
		if (n && t) {
			let e = Gm(i, t), n = Math.round(Math.atan2(e[1], e[0]) / (Math.PI / 4)) * (Math.PI / 4), r = qm(e);
			i = [t[0] + Math.cos(n) * r, t[1] + Math.sin(n) * r];
		}
		return u && (i = [Math.round(i[0] / Bm) * Bm, Math.round(i[1] / Bm) * Bm]), [Math.min(zm, Math.max(0, i[0])), Math.min(zm, Math.max(0, i[1]))];
	}, x = () => i === null ? null : n[i]?.nodes.at(-1)?.p ?? null, S = (e) => {
		if (e.button !== 0) return;
		m.current.setPointerCapture(e.pointerId), m.current.focus();
		let t = b(e, x(), e.shiftKey);
		g();
		let o = Jm(n), c = i;
		(c === null || !o[c]) && (o.push({
			closed: !1,
			nodes: []
		}), c = o.length - 1, a(c)), o[c].nodes.push({ p: t }), r(o);
		let l = o[c].nodes.length - 1;
		s([c, l]), p.current = {
			kind: "new",
			path: c,
			node: l,
			from: t,
			moved: !1
		};
	}, C = (e, t, o) => {
		if (e.button !== 0) return;
		e.stopPropagation(), m.current.setPointerCapture(e.pointerId), m.current.focus(), g();
		let c = Jm(n);
		i === t && o === 0 && c[t].nodes.length >= 2 ? (c[t].closed = !0, r(c), a(null), s([t, 0]), p.current = {
			kind: "new",
			path: t,
			node: 0,
			from: c[t].nodes[0].p,
			moved: !1
		}) : e.altKey ? (Xm(c[t], o), r(c), s([t, o])) : (s([t, o]), p.current = {
			kind: "node",
			path: t,
			node: o,
			from: b(e),
			moved: !1
		});
	}, w = (e, t, n, r) => {
		e.button === 0 && (e.stopPropagation(), m.current.setPointerCapture(e.pointerId), g(), p.current = {
			kind: "handle",
			path: t,
			node: n,
			side: r,
			moved: !1
		});
	}, T = (e) => {
		let t = p.current;
		if (!t) {
			l(i === null ? null : b(e, x(), e.shiftKey));
			return;
		}
		let n = Jm(h.current.paths), a = n[t.path]?.nodes[t.node];
		if (a) {
			if (t.kind === "new") {
				let n = b(e);
				if (!t.moved && qm(Gm(n, t.from)) < 3) return;
				t.moved = !0, a.out = n, a.in = Gm(a.p, Gm(n, a.p));
			} else if (t.kind === "node") {
				let n = b(e), r = Gm(n, t.from);
				if (!t.moved && qm(r) < 1) return;
				t.moved = !0, t.from = n, a.p = Km(a.p, r), a.in &&= Km(a.in, r), a.out &&= Km(a.out, r);
			} else {
				let n = b(e);
				t.moved = !0, a[t.side] = n;
				let r = t.side === "in" ? "out" : "in", i = a[r];
				if (i && !e.altKey) {
					let e = Gm(a.p, n), t = qm(e) || 1, o = qm(Gm(i, a.p));
					a[r] = Km(a.p, [e[0] / t * o, e[1] / t * o]);
				}
			}
			r(n);
		}
	}, E = () => {
		let e = p.current;
		p.current = null, e && e.kind !== "new" && !e.moved && f.current.pop();
	}, D = (e) => {
		(e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "z" ? (e.preventDefault(), e.stopPropagation(), _()) : e.key === "Delete" || e.key === "Backspace" ? (e.preventDefault(), e.stopPropagation(), y()) : e.key === "Enter" && (e.preventDefault(), v());
	}, O = (e, t) => {
		g();
		let i = Jm(n);
		Xm(i[e], t), r(i);
	}, ee = n.map((e, t) => e.closed || t === i && e.nodes.length >= 3 ? Ym(e, !0) : "").filter(Boolean).join(""), k = i === null ? void 0 : n[i], A = k?.nodes.at(-1), te = (e, t) => o?.[0] === e && o[1] === t || e === i && t === (k?.nodes.length ?? 0) - 1;
	return /* @__PURE__ */ W("div", {
		className: "gs-pen",
		children: [/* @__PURE__ */ W("svg", {
			ref: m,
			className: "gs-m3d__pad gs-pen__pad",
			viewBox: `0 0 ${zm} ${zm}`,
			tabIndex: 0,
			"aria-label": "Pen: click for a corner, drag for a curve, click the first point to close",
			onPointerDown: S,
			onPointerMove: T,
			onPointerUp: E,
			onPointerLeave: () => l(null),
			onKeyDown: D,
			children: [
				/* @__PURE__ */ U("defs", { children: /* @__PURE__ */ U("pattern", {
					id: "gs-pen-grid",
					width: 30,
					height: 30,
					patternUnits: "userSpaceOnUse",
					children: /* @__PURE__ */ U("path", {
						className: "gs-pen__gridline",
						d: "M30 0H0V30"
					})
				}) }),
				/* @__PURE__ */ U("rect", {
					width: zm,
					height: zm,
					fill: "url(#gs-pen-grid)"
				}),
				ee && /* @__PURE__ */ U("path", {
					className: "gs-pen__fill",
					d: ee,
					fillRule: "evenodd"
				}),
				n.map((e, t) => /* @__PURE__ */ U("path", {
					className: "gs-pen__line",
					d: Ym(e),
					strokeWidth: 2
				}, t)),
				A && c && /* @__PURE__ */ U("path", {
					d: `M${A.p.join(" ")}${A.out ? `C${A.out.join(" ")} ${c.join(" ")} ${c.join(" ")}` : `L${c.join(" ")}`}`,
					className: "gs-pen__line",
					strokeDasharray: "4 4",
					strokeWidth: 1.5,
					pointerEvents: "none"
				}),
				n.map((e, t) => e.nodes.map((e, n) => te(t, n) ? /* @__PURE__ */ U("g", { children: ["in", "out"].map((r) => e[r] ? /* @__PURE__ */ W("g", { children: [/* @__PURE__ */ U("line", {
					x1: e.p[0],
					y1: e.p[1],
					x2: e[r][0],
					y2: e[r][1],
					className: "gs-pen__arm",
					strokeWidth: 1,
					pointerEvents: "none"
				}), /* @__PURE__ */ U("circle", {
					className: "gs-pen__handle",
					cx: e[r][0],
					cy: e[r][1],
					r: 4.5,
					onPointerDown: (e) => w(e, t, n, r)
				})] }, r) : null) }, `h${t}-${n}`) : null)),
				n.map((e, t) => e.nodes.map((n, r) => {
					let a = o?.[0] === t && o[1] === r, s = t === i && r === 0 && e.nodes.length >= 2, c = !!(n.in || n.out), l = {
						className: `gs-pen__node${a ? " is-on" : ""}${s ? " is-first" : ""}`,
						onPointerDown: (e) => C(e, t, r),
						onDoubleClick: () => O(t, r)
					};
					return c ? /* @__PURE__ */ U("circle", {
						cx: n.p[0],
						cy: n.p[1],
						r: s ? 7 : 5,
						...l
					}, `n${t}-${r}`) : /* @__PURE__ */ U("rect", {
						x: n.p[0] - (s ? 6 : 4.5),
						y: n.p[1] - (s ? 6 : 4.5),
						width: s ? 12 : 9,
						height: s ? 12 : 9,
						...l
					}, `n${t}-${r}`);
				}))
			]
		}), /* @__PURE__ */ W("div", {
			className: "gs-m3d__actions",
			children: [
				/* @__PURE__ */ U("button", {
					type: "button",
					className: "gs-m3d__btn",
					disabled: !f.current.length && !n.length,
					onClick: _,
					title: "Undo (Ctrl Z)",
					children: "Undo"
				}),
				/* @__PURE__ */ U("button", {
					type: "button",
					className: "gs-m3d__btn",
					disabled: !o,
					onClick: y,
					title: "Delete the picked point (Delete)",
					children: "Delete point"
				}),
				/* @__PURE__ */ U("button", {
					type: "button",
					className: "gs-m3d__btn",
					disabled: !n.length,
					onClick: () => {
						g(), r([]), a(null), s(null);
					},
					children: "Clear"
				}),
				/* @__PURE__ */ W("label", {
					className: "gs-m3d__check",
					children: [/* @__PURE__ */ U("input", {
						type: "checkbox",
						checked: u,
						onChange: (e) => d(e.target.checked)
					}), " Snap to grid"]
				})
			]
		})]
	});
}
//#endregion
//#region src/model3d/dialogs.tsx
function Qm({ title: e, onClose: t, children: n }) {
	return ln(() => {
		let e = (e) => {
			e.key === "Escape" && (e.stopPropagation(), t());
		};
		return window.addEventListener("keydown", e, !0), () => window.removeEventListener("keydown", e, !0);
	}, [t]), /* @__PURE__ */ U("div", {
		className: "gs-m3d__scrim",
		onPointerDown: t,
		children: /* @__PURE__ */ W("div", {
			className: "gs-m3d__dialog",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": e,
			onPointerDown: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ U("h3", { children: e }), n]
		})
	});
}
var $m = (e) => tn(e.map((e) => e.map(([e, t]) => [50 + e * 90, 50 - t * 90]))), eh = 24;
function th({ initial: e, onPick: t, onClose: n }) {
	let [r, i] = H(e ?? []), o = kt(r);
	return /* @__PURE__ */ W(Qm, {
		title: e ? "Change the outline" : "Push out an outline",
		onClose: n,
		children: [
			!e && /* @__PURE__ */ U(a, { id: "m3dOutlineShape" }),
			!e && /* @__PURE__ */ U("div", {
				className: "gs-m3d__presets",
				children: Object.entries(Ft).map(([e, n]) => /* @__PURE__ */ W("button", {
					type: "button",
					onClick: () => {
						let e = Jt(n.contours), r = e.outline.reduce((e, t) => e + t.length, 0);
						t(e.outline, e.aspect, n.label, r <= eh ? jt(e.outline.map((e) => e.map(([e, t]) => [e * .8, t * .8]))) : void 0);
					},
					children: [/* @__PURE__ */ U("svg", {
						viewBox: "0 0 100 100",
						width: "48",
						height: "48",
						"aria-hidden": "true",
						children: /* @__PURE__ */ U("path", {
							d: $m(Jt(n.contours).outline),
							fill: "currentColor",
							fillRule: "evenodd"
						})
					}), /* @__PURE__ */ U("span", { children: n.label })]
				}, e))
			}),
			!e && /* @__PURE__ */ U("h4", { children: "Or draw one with the pen" }),
			/* @__PURE__ */ U(a, { id: "m3dPen" }),
			/* @__PURE__ */ U(Zm, {
				initial: e,
				onPaths: i
			}),
			/* @__PURE__ */ W("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ U("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ U("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: n,
						children: "Cancel"
					}),
					/* @__PURE__ */ U("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: !o.length,
						onClick: () => {
							if (!o.length) return;
							let e = Jt(o);
							t(e.outline, e.aspect, "Drawn outline", r);
						},
						children: e ? "Change" : "Use outline"
					})
				]
			})
		]
	});
}
var nh = {
	100: "Thin",
	200: "Extra light",
	300: "Light",
	400: "Regular",
	500: "Medium",
	600: "Semi-bold",
	700: "Bold",
	800: "Extra bold",
	900: "Black"
}, rh = {
	left: "Left",
	center: "Middle",
	right: "Right"
};
function ih({ initial: e, onDone: t, onClose: n }) {
	let [r, i] = H(e?.value ?? "Sale"), [o, s] = H(() => ah(e?.font ?? "Arial")), [c, l] = H(e?.weight ?? 800), [u, d] = H(e?.align ?? "center"), [f, p] = H(e?.lineHeight ?? 1.15), [m, h] = H(e?.spacing ?? 0), [g, _] = H(null), v = e && !Lm(e.font) && !Tm.some((t) => t.family === e.font) && o.family === e.font, y = r.split("\n").length, b = o.source === "online" || o.source === "file" ? o.weights : [
		400,
		500,
		600,
		700,
		800,
		900
	], x = b.includes(c) ? c : b.reduce((e, t) => Math.abs(t - c) < Math.abs(e - c) ? t : e), S = () => {
		let n = r.replace(/\s+$/, "").replace(/^\s*\n/, "");
		n.trim() && t({
			value: n,
			font: o.family,
			weight: x,
			...y > 1 || e?.align ? {
				align: u,
				lineHeight: f
			} : {},
			...m || e?.spacing ? { spacing: m } : {}
		});
	};
	return /* @__PURE__ */ W(Qm, {
		title: e ? "Change the text" : "3D text",
		onClose: n,
		children: [
			/* @__PURE__ */ U(a, { id: "m3dText" }),
			/* @__PURE__ */ W("label", {
				className: "gs-m3d__field gs-m3d__field--top",
				children: [/* @__PURE__ */ U("span", { children: "Text" }), /* @__PURE__ */ U("textarea", {
					autoFocus: !0,
					rows: Math.min(5, Math.max(2, y)),
					value: r,
					maxLength: 200,
					onChange: (e) => i(e.target.value.split("\n").slice(0, 8).join("\n")),
					onKeyDown: (e) => {
						e.key === "Enter" && (e.metaKey || e.ctrlKey) && S();
					}
				})]
			}),
			/* @__PURE__ */ W("div", {
				className: "gs-m3d__field gs-m3d__field--top",
				children: [/* @__PURE__ */ U("span", { children: "Font" }), /* @__PURE__ */ U(ch, {
					value: o,
					onPick: (e) => {
						if (s(e), e.source !== "online") return _(null);
						_("Loading the font…"), km(e, e.weights.includes(c) ? c : e.weights[0], r).then(() => _(null)).catch((e) => _(e instanceof Error ? e.message : "The font could not be loaded."));
					}
				})]
			}),
			v && /* @__PURE__ */ W("p", {
				className: "gs-m3d__note",
				children: [
					"“",
					e.font,
					"” is not on this computer: pick a font, or load its file under Font file."
				]
			}),
			/* @__PURE__ */ W("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ U("span", { children: "Weight" }), /* @__PURE__ */ U("select", {
					value: x,
					onChange: (e) => l(Number(e.target.value)),
					children: b.map((e) => /* @__PURE__ */ U("option", {
						value: e,
						children: nh[e] ?? e
					}, e))
				})]
			}),
			y > 1 && /* @__PURE__ */ W(fn, { children: [/* @__PURE__ */ W("div", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ U("span", { children: "Lines" }), /* @__PURE__ */ U("div", {
					className: "gs-m3d__segments",
					role: "group",
					"aria-label": "Line up",
					children: [
						"left",
						"center",
						"right"
					].map((e) => /* @__PURE__ */ U("button", {
						type: "button",
						className: u === e ? "is-on" : "",
						onClick: () => d(e),
						children: rh[e]
					}, e))
				})]
			}), /* @__PURE__ */ W("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ U("span", { children: "Line gap" }), /* @__PURE__ */ U("input", {
					type: "range",
					min: .7,
					max: 2,
					step: .05,
					value: f,
					onChange: (e) => p(Number(e.target.value))
				})]
			})] }),
			/* @__PURE__ */ W("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ U("span", { children: "Spacing" }), /* @__PURE__ */ U("input", {
					type: "range",
					min: -.1,
					max: .6,
					step: .01,
					value: m,
					onChange: (e) => h(Number(e.target.value))
				})]
			}),
			/* @__PURE__ */ U("p", {
				className: "gs-m3d__textpreview",
				style: {
					fontFamily: `"${o.family}", sans-serif`,
					fontWeight: x,
					textAlign: u,
					lineHeight: f,
					letterSpacing: `${m}em`,
					whiteSpace: "pre"
				},
				children: r || " "
			}),
			g && /* @__PURE__ */ U("p", {
				className: "gs-m3d__note",
				children: g
			}),
			/* @__PURE__ */ W("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ U("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ U("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: n,
						children: "Cancel"
					}),
					/* @__PURE__ */ U("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: !r.trim(),
						onClick: S,
						children: e ? "Change" : "Add text"
					})
				]
			})
		]
	});
}
function ah(e) {
	return [
		...wm,
		...Tm,
		...Fm()
	].find((t) => t.family === e) ?? {
		family: e,
		source: "computer",
		weights: [400, 700]
	};
}
var oh = {
	standard: "Standard",
	online: "Online",
	computer: "This computer",
	file: "Font file"
}, sh = null;
function ch({ value: e, onPick: t }) {
	let [n, r] = H(e.source), [i, a] = H(""), [o, s] = H(sh), [c, l] = H(null), [u, d] = H(""), [, f] = H(0), p = un(null);
	ln(() => {
		n === "online" && Am(Tm);
	}, [n]);
	let m = n === "standard" ? wm : n === "online" ? Tm : n === "computer" ? o ?? [] : Fm(), h = i.trim().toLowerCase(), g = h ? m.filter((e) => e.family.toLowerCase().includes(h) || e.note?.toLowerCase().includes(h)) : m;
	return /* @__PURE__ */ W("div", {
		className: "gs-fonts",
		children: [
			/* @__PURE__ */ U("div", {
				className: "gs-m3d__segments",
				role: "group",
				"aria-label": "Fonts from",
				children: Object.keys(oh).map((e) => /* @__PURE__ */ U("button", {
					type: "button",
					className: n === e ? "is-on" : "",
					onClick: () => r(e),
					children: oh[e]
				}, e))
			}),
			n === "online" && /* @__PURE__ */ U("p", {
				className: "gs-m3d__note",
				children: "Free fonts from Google Fonts: each loads from the internet when picked."
			}),
			n === "computer" && /* @__PURE__ */ W("div", {
				className: "gs-fonts__ask",
				children: [o?.length ? null : jm() ? /* @__PURE__ */ U("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => {
						l(null), Nm().then((e) => {
							sh = e, s(e), e.length || l("The browser shared no fonts (it may have been told not to). Type a font’s name instead.");
						}).catch(() => l("The browser did not share this computer’s fonts."));
					},
					children: "Show this computer’s fonts"
				}) : /* @__PURE__ */ U("p", {
					className: "gs-m3d__note",
					children: "This browser cannot list fonts."
				}), /* @__PURE__ */ W("form", {
					className: "gs-fonts__typed",
					onSubmit: (e) => {
						e.preventDefault();
						let n = u.trim();
						if (n) {
							if (!Lm(n)) return l(`“${n}” is not on this computer.`);
							l(null), t({
								family: n,
								source: "computer",
								weights: [400, 700]
							});
						}
					},
					children: [/* @__PURE__ */ U("input", {
						value: u,
						placeholder: "Or type an installed font’s name",
						"aria-label": "Font name",
						onChange: (e) => d(e.target.value)
					}), /* @__PURE__ */ U("button", {
						type: "submit",
						className: "gs-m3d__btn",
						children: "Use"
					})]
				})]
			}),
			n === "file" && /* @__PURE__ */ W(fn, { children: [
				/* @__PURE__ */ U("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => p.current?.click(),
					children: "Load a font file…"
				}),
				/* @__PURE__ */ U("input", {
					ref: p,
					type: "file",
					accept: ".ttf,.otf,.woff,.woff2",
					hidden: !0,
					onChange: (e) => {
						let n = e.target.files?.[0];
						e.target.value = "", n && (l(null), Im(n).then((e) => {
							f((e) => e + 1), t(e);
						}).catch((e) => l(e instanceof Error ? e.message : "That font file could not be read.")));
					}
				}),
				/* @__PURE__ */ U("p", {
					className: "gs-m3d__note",
					children: "Kept until the page closes; the letters stay in the design after that."
				})
			] }),
			m.length > 8 && /* @__PURE__ */ U("input", {
				className: "gs-fonts__search",
				value: i,
				placeholder: "Search fonts",
				"aria-label": "Search fonts",
				onChange: (e) => a(e.target.value)
			}),
			g.length > 0 && /* @__PURE__ */ U("ul", {
				className: "gs-fonts__list",
				role: "listbox",
				"aria-label": "Fonts",
				children: g.slice(0, 400).map((n) => /* @__PURE__ */ U("li", { children: /* @__PURE__ */ W("button", {
					type: "button",
					role: "option",
					"aria-selected": e.family === n.family,
					className: e.family === n.family ? "is-on" : "",
					onClick: () => t(n),
					children: [/* @__PURE__ */ U("span", {
						style: { fontFamily: `"${n.family}", sans-serif` },
						children: n.family
					}), n.note && /* @__PURE__ */ U("small", { children: n.note })]
				}) }, `${n.source}-${n.family}`))
			}),
			c && /* @__PURE__ */ U("p", {
				className: "gs-m3d__note",
				children: c
			})
		]
	});
}
function lh({ initialKind: e = "turntable", initialSeconds: t = 4, moving: n = !1, onMake: r, onClose: i }) {
	let [o, s] = H(e), [c, l] = H(t), [u, d] = H(1080);
	return /* @__PURE__ */ W(Qm, {
		title: "Make a video",
		onClose: i,
		children: [
			/* @__PURE__ */ U(a, { id: "m3dVideo" }),
			n && /* @__PURE__ */ U("p", {
				className: "gs-m3d__note",
				children: "The shapes move as their Motion says, fitted to the clip’s length; pick what the camera does too."
			}),
			/* @__PURE__ */ U("div", {
				className: "gs-m3d__segments",
				role: "group",
				"aria-label": "Clip",
				children: Object.keys(sm).map((e) => /* @__PURE__ */ U("button", {
					type: "button",
					className: o === e ? "is-on" : "",
					onClick: () => s(e),
					children: sm[e]
				}, e))
			}),
			/* @__PURE__ */ W("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ U("span", { children: "Length" }), /* @__PURE__ */ U("select", {
					value: c,
					onChange: (e) => l(Number(e.target.value)),
					children: [
						2,
						4,
						6,
						8,
						12
					].map((e) => /* @__PURE__ */ W("option", {
						value: e,
						children: [e, " seconds"]
					}, e))
				})]
			}),
			/* @__PURE__ */ W("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ U("span", { children: "Size" }), /* @__PURE__ */ W("select", {
					value: u,
					onChange: (e) => d(Number(e.target.value)),
					children: [
						/* @__PURE__ */ U("option", {
							value: 720,
							children: "720 px"
						}),
						/* @__PURE__ */ U("option", {
							value: 1080,
							children: "1080 px"
						}),
						/* @__PURE__ */ U("option", {
							value: 1440,
							children: "1440 px"
						})
					]
				})]
			}),
			/* @__PURE__ */ W("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ U("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ U("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: i,
						children: "Cancel"
					}),
					/* @__PURE__ */ U("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						onClick: () => r(o, c, u),
						children: "Make video"
					})
				]
			})
		]
	});
}
//#endregion
//#region src/model3d/AdDialog.tsx
var uh = "gleamshelf.shop.logo";
function dh() {
	try {
		let e = JSON.parse(localStorage.getItem(uh) ?? "null");
		return e && typeof e.svg == "string" && typeof e.name == "string" ? {
			name: e.name,
			svg: e.svg
		} : null;
	} catch {
		return null;
	}
}
function fh(e) {
	try {
		e ? localStorage.setItem(uh, JSON.stringify(e)) : localStorage.removeItem(uh);
	} catch {}
}
function ph({ start: e, onMake: t, onClose: n }) {
	let [r, i] = H(e?.picture ?? null), [o, s] = H(null), [c, l] = H(e?.headline ?? ""), [u, d] = H(e?.tagline ?? "New arrival"), [f, p] = H(e?.price ?? ""), [m, h] = H(dh), [g, _] = H("podium"), [v, y] = H("blossom"), [b, x] = H(() => ah("Arial")), [S, C] = H(!0), [w, T] = H(null), E = un(null), D = un(null);
	ln(() => {
		if (!r) return s(null);
		let e = URL.createObjectURL(r);
		return s(e), () => URL.revokeObjectURL(e);
	}, [r]);
	let O = !!(r || c.trim() || f.trim());
	return /* @__PURE__ */ W(Qm, {
		title: "Make a 3D ad",
		onClose: n,
		children: [
			/* @__PURE__ */ U(a, { id: "m3dAd" }),
			/* @__PURE__ */ W("div", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ U("span", { children: "Product" }), /* @__PURE__ */ W("div", {
					className: "gs-ad__picture",
					children: [
						o ? /* @__PURE__ */ U("img", {
							src: o,
							alt: "The product"
						}) : /* @__PURE__ */ U("span", {
							className: "gs-m3d__note",
							children: "No picture"
						}),
						/* @__PURE__ */ U("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: () => E.current?.click(),
							children: r ? "Change…" : "Choose a picture…"
						}),
						/* @__PURE__ */ U("input", {
							ref: E,
							type: "file",
							accept: "image/png,image/webp,image/jpeg",
							hidden: !0,
							onChange: (e) => {
								let t = e.target.files?.[0];
								e.target.value = "", t && i(t);
							}
						})
					]
				})]
			}),
			/* @__PURE__ */ W("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ U("span", { children: "Headline" }), /* @__PURE__ */ U("input", {
					value: c,
					maxLength: 60,
					placeholder: "What it is",
					onChange: (e) => l(e.target.value)
				})]
			}),
			/* @__PURE__ */ W("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ U("span", { children: "Small line" }), /* @__PURE__ */ U("input", {
					value: u,
					maxLength: 40,
					placeholder: "New arrival",
					onChange: (e) => d(e.target.value)
				})]
			}),
			/* @__PURE__ */ W("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ U("span", { children: "Price" }), /* @__PURE__ */ U("input", {
					value: f,
					maxLength: 14,
					placeholder: "$45 (none: no badge)",
					onChange: (e) => p(e.target.value)
				})]
			}),
			/* @__PURE__ */ W("div", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ U("span", { children: "Logo" }), /* @__PURE__ */ W("div", {
					className: "gs-ad__picture",
					children: [
						/* @__PURE__ */ U("span", {
							className: "gs-m3d__note",
							children: m ? m.name : "None"
						}),
						/* @__PURE__ */ U("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: () => D.current?.click(),
							children: m ? "Change…" : "Choose an SVG…"
						}),
						m && /* @__PURE__ */ U("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: () => {
								h(null), fh(null);
							},
							children: "No logo"
						}),
						/* @__PURE__ */ U("input", {
							ref: D,
							type: "file",
							accept: ".svg,image/svg+xml",
							hidden: !0,
							onChange: (e) => {
								let t = e.target.files?.[0];
								if (e.target.value = "", t) {
									if (t.size > 4e5) return T("That SVG is very large; a logo is usually a few kilobytes.");
									t.text().then((e) => {
										let n = {
											name: t.name.replace(/\.svg$/i, ""),
											svg: e
										};
										h(n), fh(n), T(null);
									});
								}
							}
						})
					]
				})]
			}),
			/* @__PURE__ */ W("div", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ U("span", { children: "Layout" }), /* @__PURE__ */ U("div", {
					className: "gs-m3d__segments",
					role: "group",
					"aria-label": "Layout",
					children: Object.keys(en).map((e) => /* @__PURE__ */ U("button", {
						type: "button",
						className: g === e ? "is-on" : "",
						onClick: () => _(e),
						children: en[e]
					}, e))
				})]
			}),
			/* @__PURE__ */ W("div", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ U("span", { children: "Colours" }), /* @__PURE__ */ U("div", {
					className: "gs-ad__palettes",
					role: "group",
					"aria-label": "Colours",
					children: Object.entries(Zt).map(([e, t]) => /* @__PURE__ */ U("button", {
						type: "button",
						className: v === e ? "is-on" : "",
						title: t.label,
						"aria-label": t.label,
						onClick: () => y(e),
						children: [
							t.colours.background,
							t.colours.main,
							t.colours.accent,
							t.colours.text
						].map((e, t) => /* @__PURE__ */ U("span", { style: { background: e } }, t))
					}, e))
				})]
			}),
			/* @__PURE__ */ W("div", {
				className: "gs-m3d__field gs-m3d__field--top",
				children: [/* @__PURE__ */ U("span", { children: "Font" }), /* @__PURE__ */ U(ch, {
					value: b,
					onPick: x
				})]
			}),
			/* @__PURE__ */ W("label", {
				className: "gs-m3d__check",
				children: [/* @__PURE__ */ U("input", {
					type: "checkbox",
					checked: S,
					onChange: (e) => C(e.target.checked)
				}), " Make it move (the product floats, the words pop in, the price pulses)"]
			}),
			w && /* @__PURE__ */ U("p", {
				className: "gs-m3d__note",
				children: w
			}),
			/* @__PURE__ */ W("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ U("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ U("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: n,
						children: "Cancel"
					}),
					/* @__PURE__ */ U("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: !O,
						onClick: () => t({
							picture: r,
							headline: c,
							tagline: u,
							price: f,
							logo: m,
							style: g,
							colours: Zt[v].colours,
							font: b,
							moving: S
						}),
						children: "Make the ad"
					})
				]
			})
		]
	});
}
//#endregion
//#region src/model3d/clipboard.ts
var mh = null, hh = null;
function gh(e, t) {
	mh = {
		shapes: structuredClone(t),
		assets: bt(e, t),
		pastes: 0
	};
}
var _h = () => mh;
function vh() {
	let e = mh ? ++mh.pastes : 1;
	return [
		.5 * e,
		0,
		.5 * e
	];
}
function yh(e) {
	hh = {
		color: e.color,
		finish: e.finish
	};
}
var bh = () => hh;
async function xh(e) {
	if (!navigator.clipboard?.write || typeof ClipboardItem > "u") throw Error("This browser cannot put pictures on the clipboard.");
	await navigator.clipboard.write([new ClipboardItem({ "image/png": e })]).catch(Sh);
}
function Sh(e) {
	throw e instanceof Error && /denied|not allowed|permission|focus/i.test(e.message) ? Error("The browser did not allow copying here. Use Save instead, or allow the clipboard for this page.") : e;
}
async function Ch(e) {
	let t = e.then((e) => new Blob([e], { type: "text/plain" }));
	if (navigator.clipboard?.write && typeof ClipboardItem < "u") {
		let n = ClipboardItem.supports?.("image/svg+xml"), r = { "text/plain": t };
		n && (r["image/svg+xml"] = e.then((e) => new Blob([e], { type: "image/svg+xml" }))), await navigator.clipboard.write([new ClipboardItem(r)]).catch(Sh);
	} else await navigator.clipboard.writeText(await e).catch(Sh);
}
//#endregion
//#region src/model3d/parts.tsx
function wh({ kind: e }) {
	return /* @__PURE__ */ U("svg", {
		width: "22",
		height: "22",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: 1.6,
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: {
			box: /* @__PURE__ */ U("path", { d: "M12 3l8 4.5v9L12 21l-8-4.5v-9L12 3zM4 7.5L12 12l8-4.5M12 12v9" }),
			sphere: /* @__PURE__ */ W(fn, { children: [/* @__PURE__ */ U("circle", {
				cx: "12",
				cy: "12",
				r: "8.5"
			}), /* @__PURE__ */ U("path", { d: "M3.5 12c3 3 14 3 17 0" })] }),
			cylinder: /* @__PURE__ */ W(fn, { children: [/* @__PURE__ */ U("ellipse", {
				cx: "12",
				cy: "6",
				rx: "7",
				ry: "2.6"
			}), /* @__PURE__ */ U("path", { d: "M5 6v12c0 1.4 3.1 2.6 7 2.6s7-1.2 7-2.6V6" })] }),
			cone: /* @__PURE__ */ W(fn, { children: [/* @__PURE__ */ U("path", { d: "M12 3L5 18M12 3l7 15" }), /* @__PURE__ */ U("ellipse", {
				cx: "12",
				cy: "18",
				rx: "7",
				ry: "2.6"
			})] }),
			torus: /* @__PURE__ */ W(fn, { children: [/* @__PURE__ */ U("ellipse", {
				cx: "12",
				cy: "12",
				rx: "9",
				ry: "5"
			}), /* @__PURE__ */ U("ellipse", {
				cx: "12",
				cy: "11.4",
				rx: "3.6",
				ry: "1.6"
			})] }),
			capsule: /* @__PURE__ */ U("rect", {
				x: "7",
				y: "3",
				width: "10",
				height: "18",
				rx: "5"
			}),
			pyramid: /* @__PURE__ */ U("path", { d: "M12 3l8 15H4L12 3zM12 3l2 15" }),
			extrude: /* @__PURE__ */ U("path", { d: "M12 3l2.6 5.6 6.2.7-4.6 4.2 1.3 6.1L12 16.5l-5.5 3.1 1.3-6.1-4.6-4.2 6.2-.7L12 3z" }),
			text: /* @__PURE__ */ U("path", { d: "M5 6V4h14v2M12 4v16M9 20h6" }),
			mesh: /* @__PURE__ */ W(fn, { children: [/* @__PURE__ */ U("path", { d: "M12 3.5l7 4v8l-7 4-7-4v-8l7-4z" }), /* @__PURE__ */ U("path", { d: "M5 7.5l7 4 7-4M12 11.5v8M8.5 5.5l7 4" })] }),
			group: /* @__PURE__ */ W(fn, { children: [/* @__PURE__ */ U("rect", {
				x: "3",
				y: "3",
				width: "11",
				height: "11",
				rx: "2"
			}), /* @__PURE__ */ U("rect", {
				x: "10",
				y: "10",
				width: "11",
				height: "11",
				rx: "2"
			})] }),
			ad: /* @__PURE__ */ W(fn, { children: [/* @__PURE__ */ U("path", { d: "M6 21h12M8 21v-5h8v5" }), /* @__PURE__ */ U("path", { d: "M12 3l1.8 3.7 4 .6-2.9 2.8.7 4-3.6-1.9-3.6 1.9.7-4-2.9-2.8 4-.6L12 3z" })] }),
			svg: /* @__PURE__ */ W(fn, { children: [/* @__PURE__ */ U("path", { d: "M3 19c4-1 6-6 9-6s4 4 9 2" }), /* @__PURE__ */ U("path", { d: "M12 3l4 6-4 4-4-4 4-6zM12 9v1" })] })
		}[e]
	});
}
function Th(e) {
	let { label: t, value: n, min: r, max: a, step: o, format: s, onBegin: c, onChange: l, onEnd: u } = e;
	return /* @__PURE__ */ W("label", {
		className: "gs-m3d__slider",
		children: [/* @__PURE__ */ W("span", {
			className: "gs-m3d__row",
			children: [/* @__PURE__ */ U("span", { children: t }), /* @__PURE__ */ U("output", { children: s ? s(n) : n })]
		}), /* @__PURE__ */ U("input", {
			type: "range",
			min: r,
			max: a,
			step: o,
			value: n,
			style: i(n, r, a),
			onPointerDown: c,
			onPointerUp: u,
			onLostPointerCapture: u,
			onKeyDown: c,
			onKeyUp: u,
			onChange: (e) => l(Number(e.target.value))
		})]
	});
}
function Eh({ label: e, value: t, step: n, min: r, onChange: i }) {
	return /* @__PURE__ */ W("div", {
		className: "gs-m3d__triple",
		children: [/* @__PURE__ */ U("span", { children: e }), [
			"X",
			"Y",
			"Z"
		].map((e, a) => /* @__PURE__ */ W("label", { children: [/* @__PURE__ */ U("i", { children: e }), /* @__PURE__ */ U("input", {
			type: "number",
			step: n,
			min: r,
			value: Math.round(t[a] * 1e3) / 1e3,
			onChange: (e) => {
				let n = Number(e.target.value);
				if (!Number.isFinite(n)) return;
				let r = [...t];
				r[a] = n, i(r);
			}
		})] }, e))]
	});
}
function Dh({ value: e, options: t, labels: n, onChange: r, label: i }) {
	return /* @__PURE__ */ U("div", {
		className: "gs-m3d__segments",
		role: "group",
		"aria-label": i,
		children: t.map((t) => /* @__PURE__ */ U("button", {
			type: "button",
			className: e === t ? "is-on" : "",
			"aria-pressed": e === t,
			onClick: () => r(t),
			children: n[t]
		}, t))
	});
}
//#endregion
//#region src/model3d/MotionSection.tsx
var Oh = {
	spin: "turns",
	float: "rises",
	bounce: "hops",
	sway: "sways",
	pulse: "pulses",
	wiggle: "wiggles",
	orbit: "times round",
	pop: "pops"
}, kh = [
	"float",
	"bounce",
	"sway",
	"pulse",
	"wiggle"
];
function Ah({ editor: e, items: t, playing: n, onPlay: r }) {
	let i = t.find((e) => e.shape.motion)?.shape.motion, o = t.some((e) => e.shape.motion?.kind !== i?.kind), s = (n, r) => e.updateShapesAt(t.map(({ ref: e, shape: t }) => [e, { motion: n === null ? void 0 : {
		...wt,
		...t.motion ?? i ?? {},
		...n
	} }]), r), c = (n, r, a) => i && /* @__PURE__ */ U(Th, {
		label: n,
		value: i[r],
		min: 0,
		max: 1,
		step: .01,
		format: a,
		onBegin: () => e.begin(n),
		onChange: (n) => e.updateShapesAt(t.map(({ ref: e, shape: t }) => [e, { motion: {
			...wt,
			...t.motion ?? i,
			[r]: n
		} }])),
		onEnd: () => e.commit()
	});
	return /* @__PURE__ */ W("section", { children: [
		/* @__PURE__ */ U("h4", { children: "Motion" }),
		/* @__PURE__ */ W("label", {
			className: "gs-m3d__field",
			children: [/* @__PURE__ */ U("span", { children: "Moves" }), /* @__PURE__ */ W("select", {
				value: o ? "" : i?.kind ?? "none",
				onChange: (e) => {
					let t = e.target.value;
					t === "none" ? s(null, "No motion") : t && s({ kind: t }, Dt[t]);
				},
				children: [
					o && /* @__PURE__ */ U("option", {
						value: "",
						children: "Different ones"
					}),
					/* @__PURE__ */ U("option", {
						value: "none",
						children: "Does not move"
					}),
					Et.map((e) => /* @__PURE__ */ U("option", {
						value: e,
						children: Dt[e]
					}, e))
				]
			})]
		}),
		i && !o && /* @__PURE__ */ W(fn, { children: [
			/* @__PURE__ */ W("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ U("span", { children: "Times" }), /* @__PURE__ */ U("select", {
					value: i.times,
					onChange: (e) => s({ times: Number(e.target.value) }, "Motion times"),
					children: [
						1,
						2,
						3,
						4,
						6,
						8
					].map((e) => /* @__PURE__ */ W("option", {
						value: e,
						children: [
							e,
							" ",
							Oh[i.kind],
							" a clip"
						]
					}, e))
				})]
			}),
			kh.includes(i.kind) && c("How far", "amount", (e) => `${Math.round(e * 100)}%`),
			i.kind === "spin" && /* @__PURE__ */ U(Dh, {
				label: "About",
				value: i.axis,
				options: [
					"y",
					"x",
					"z"
				],
				labels: {
					y: "Upright",
					x: "Tumble",
					z: "Roll"
				},
				onChange: (e) => s({ axis: e }, "Spin axis")
			}),
			i.kind === "sway" && /* @__PURE__ */ U(Dh, {
				label: "Sways",
				value: i.axis === "x" ? "x" : "z",
				options: ["z", "x"],
				labels: {
					z: "Side to side",
					x: "Front to back"
				},
				onChange: (e) => s({ axis: e }, "Sway direction")
			}),
			(i.kind === "spin" || i.kind === "orbit") && /* @__PURE__ */ W("label", {
				className: "gs-m3d__check",
				children: [/* @__PURE__ */ U("input", {
					type: "checkbox",
					checked: i.reverse,
					onChange: (e) => s({ reverse: e.target.checked }, "Motion direction")
				}), " The other way"]
			}),
			c("Start later", "delay", (e) => `${Math.round(e * 100)}%`)
		] }),
		/* @__PURE__ */ W("div", {
			className: "gs-m3d__row",
			children: [/* @__PURE__ */ U("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: r,
				title: "Space",
				children: n ? "Stop" : "Play"
			}), t.length > 1 && i && /* @__PURE__ */ U("button", {
				type: "button",
				className: "gs-m3d__btn",
				title: "Each one starts a little after the one before, in the list's order",
				onClick: () => e.updateShapesAt([...t].sort((e, t) => e.ref[0] - t.ref[0]).map(({ ref: e, shape: n }, r) => [e, { motion: {
					...wt,
					...n.motion ?? i,
					delay: r / t.length / 2
				} }]), "Stagger"),
				children: "Stagger"
			})]
		}),
		/* @__PURE__ */ U(a, { id: "m3dMotion" })
	] });
}
//#endregion
//#region src/model3d/scene.ts
var jh = [
	"a wooden shop shelf, warm soft light",
	"a pastel photo studio with soft shadows",
	"a cosy room, blurred, evening light",
	"a city street at night, neon lights, bokeh",
	"a cherry blossom park in spring, soft focus",
	"a festive gift table, fairy lights, bokeh"
], Mh = "text, letters, watermark, logo, people, person, figure, toy, product, frame, border", Nh = 1024, Ph = (e, t) => {
	let n = document.createElement("canvas");
	return n.width = e, n.height = t, n;
}, Fh = (e) => new Promise((t, n) => e.toBlob((e) => e ? t(e) : n(/* @__PURE__ */ Error("The picture could not be made.")), "image/png"));
function Ih(e) {
	return new Promise((t, n) => {
		let r = new FileReader();
		r.onload = () => t(String(r.result)), r.onerror = () => n(/* @__PURE__ */ Error("The picture could not be read.")), r.readAsDataURL(e);
	});
}
async function Lh(e, t = 1600) {
	let n = await createImageBitmap(e), r = Math.min(1, t / Math.max(n.width, n.height)), i = Ph(Math.round(n.width * r), Math.round(n.height * r));
	return i.getContext("2d").drawImage(n, 0, 0, i.width, i.height), n.close(), Ih(await new Promise((e, t) => i.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be made.")), "image/jpeg", .9)));
}
async function Rh(e, t, n, r) {
	let [i, a] = t >= 1 ? [Nh, Math.round(Nh / t / 8) * 8] : [Math.round(Nh * t / 8) * 8, Nh], o = Ph(i, a);
	return r("Painting the scene… (about a minute)"), Lh(await e.redraw(await Fh(o), {
		prompt: `${n}, product photography background, depth of field, detailed, realistic, high quality`,
		negative: Mh,
		strength: 1
	}));
}
//#endregion
//#region src/model3d/ScenePanel.tsx
function zh({ editor: e, doc: t, aspect: n }) {
	let r = s(), [i, o] = H(jh[0]), [c, l] = H(null), [u, d] = H(null), f = un(null), p = r.state === "ready" ? r.installed("redraw")[0] : void 0, m = t.background.picture, h = (t, n) => e.setSetting("background", "picture", t, n), g = async () => {
		d(null);
		try {
			h(await Rh(r.client, n(), i.trim() || jh[0], l), "Scene behind");
		} catch (e) {
			d(e instanceof Error ? e.message : "The scene could not be made.");
		} finally {
			l(null);
		}
	};
	return /* @__PURE__ */ W("section", { children: [
		/* @__PURE__ */ U("h4", { children: "Scene behind" }),
		m && /* @__PURE__ */ W("div", {
			className: "gs-scene__now",
			children: [/* @__PURE__ */ U("img", {
				src: m,
				alt: "The scene behind the design"
			}), /* @__PURE__ */ U("button", {
				type: "button",
				className: "gs-m3d__btn",
				disabled: !!c,
				onClick: () => h("", "No scene"),
				children: "Remove the scene"
			})]
		}),
		/* @__PURE__ */ W("label", {
			className: "gs-m3d__field gs-m3d__field--top",
			children: [/* @__PURE__ */ U("span", { children: "Paint" }), /* @__PURE__ */ U("textarea", {
				rows: 2,
				value: i,
				maxLength: 200,
				onChange: (e) => o(e.target.value),
				disabled: !!c
			})]
		}),
		/* @__PURE__ */ U("div", {
			className: "gs-scene__ideas",
			children: jh.map((e) => /* @__PURE__ */ U("button", {
				type: "button",
				className: i === e ? "is-on" : "",
				disabled: !!c,
				onClick: () => o(e),
				children: e.split(",")[0]
			}, e))
		}),
		/* @__PURE__ */ U("p", {
			className: "gs-m3d__note",
			children: p ? "Free: painted by the image model on this computer, about a minute; nothing is sent anywhere. The scene goes behind; every shape and the product photo stay as they are." : r.state === "ready" ? "Painting a scene needs the image model, set up once with: npm run redraw:setup (free, on this computer). Your own picture works without it." : "Painting a scene needs the Gleamshelf app running on this computer. Your own picture works without it."
		}),
		/* @__PURE__ */ W("div", {
			className: "gs-m3d__row",
			children: [
				/* @__PURE__ */ U("button", {
					type: "button",
					className: "gs-m3d__btn gs-m3d__btn--primary",
					disabled: !p || !!c,
					onClick: () => void g(),
					children: c ?? (m ? "Paint another" : "Paint a scene")
				}),
				/* @__PURE__ */ U("button", {
					type: "button",
					className: "gs-m3d__btn",
					disabled: !!c,
					onClick: () => f.current?.click(),
					children: "Use my own picture…"
				}),
				/* @__PURE__ */ U("input", {
					ref: f,
					type: "file",
					accept: "image/png,image/jpeg,image/webp",
					hidden: !0,
					onChange: (e) => {
						let t = e.target.files?.[0];
						e.target.value = "", t && Lh(t).then((e) => h(e, "Scene behind"));
					}
				})
			]
		}),
		u && /* @__PURE__ */ U("p", {
			className: "gs-m3d__note",
			children: u
		}),
		/* @__PURE__ */ U(a, { id: "m3dScene" })
	] });
}
//#endregion
//#region src/model3d/labels.ts
var Bh = {
	add: "Add",
	subtract: "Cut",
	intersect: "Intersect"
}, Vh = {
	matte: "Matte",
	satin: "Satin",
	glossy: "Glossy",
	metal: "Metal"
}, Hh = [
	"#ff7ab6",
	"#f87171",
	"#fbbf24",
	"#34d399",
	"#67e8f9",
	"#60a5fa",
	"#a78bfa",
	"#f4f1fb",
	"#9ca3af",
	"#1f2937"
], Uh = [
	{
		axis: 0,
		name: "Across",
		labels: {
			min: "Left",
			mid: "Middle",
			max: "Right"
		}
	},
	{
		axis: 1,
		name: "Up",
		labels: {
			min: "Bottom",
			mid: "Middle",
			max: "Top"
		}
	},
	{
		axis: 2,
		name: "Depth",
		labels: {
			min: "Back",
			mid: "Middle",
			max: "Front"
		}
	}
];
function Wh(e, t) {
	return t.flatMap((t) => {
		let n = e.shapes[t];
		return n ? n.kind === "group" ? (n.children ?? []).map((e, n) => ({
			ref: [t, n],
			shape: e
		})) : [{
			ref: [t],
			shape: n
		}] : [];
	});
}
var Gh = (e, t) => e.kind === "mesh" && e.ownColors !== !1 && ("color" in t || "finish" in t) ? {
	...t,
	ownColors: !1
} : t;
function Kh({ editor: e, doc: t, picked: n, onDuplicate: r, onDelete: i, onGroup: o, motion: s }) {
	let c = Wh(t, n), l = c[0]?.shape, u = n.map((e) => t.shapes[e]).filter((e) => !!e), d = (t, n) => e.updateShapesAt(c.map(({ ref: e, shape: n }) => [e, Gh(n, t)]), n), f = c.filter((e) => e.shape.kind !== "mesh"), p = u.every((e) => e.locked), m = u.every((e) => e.hidden), h = bh();
	return l ? /* @__PURE__ */ W("div", {
		className: "gs-m3d__panel",
		children: [
			/* @__PURE__ */ W("section", { children: [
				/* @__PURE__ */ W("h4", { children: [n.length, " shapes picked"] }),
				/* @__PURE__ */ W("div", {
					className: "gs-m3d__row",
					children: [
						/* @__PURE__ */ U("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: o,
							title: "Group them (Ctrl G)",
							children: "Group"
						}),
						/* @__PURE__ */ U("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: r,
							title: "Duplicate them (Ctrl D)",
							children: "Duplicate"
						}),
						/* @__PURE__ */ U("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: i,
							title: "Delete them (Delete)",
							children: "Delete"
						}),
						/* @__PURE__ */ U("button", {
							type: "button",
							className: "gs-m3d__btn",
							title: "Locked shapes are not picked or dragged in the view (Ctrl Alt L)",
							onClick: () => e.updateShapesAt(n.map((e) => [[e], { locked: !p }]), p ? "Unlock" : "Lock"),
							children: p ? "Unlock" : "Lock"
						}),
						/* @__PURE__ */ U("button", {
							type: "button",
							className: "gs-m3d__btn",
							title: "Ctrl Shift H",
							onClick: () => e.updateShapesAt(n.map((e) => [[e], { hidden: !m }]), m ? "Show" : "Hide"),
							children: m ? "Show" : "Hide"
						})
					]
				}),
				/* @__PURE__ */ U(a, { id: "m3dMulti" })
			] }),
			/* @__PURE__ */ W("section", { children: [
				/* @__PURE__ */ U("h4", { children: "Line up" }),
				Uh.map(({ axis: t, name: r, labels: i }) => /* @__PURE__ */ W("div", {
					className: "gs-m3d__align",
					children: [/* @__PURE__ */ U("span", { children: r }), [
						"min",
						"mid",
						"max"
					].map((r) => /* @__PURE__ */ U("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => e.align(n, t, r),
						children: i[r]
					}, r))]
				}, t)),
				/* @__PURE__ */ W("div", {
					className: "gs-m3d__align",
					children: [/* @__PURE__ */ U("span", { children: "Spread" }), Uh.map(({ axis: t, name: r }) => /* @__PURE__ */ U("button", {
						type: "button",
						className: "gs-m3d__btn",
						disabled: n.length < 3,
						title: n.length < 3 ? "Pick three or more to spread them" : `Equal gaps ${r.toLowerCase()}`,
						onClick: () => e.spread(n, t),
						children: r
					}, t))]
				}),
				/* @__PURE__ */ U("div", {
					className: "gs-m3d__row",
					children: /* @__PURE__ */ U("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => e.toGround(n),
						children: "Put them on the ground"
					})
				}),
				/* @__PURE__ */ U(a, { id: "m3dAlign" })
			] }),
			/* @__PURE__ */ W("section", { children: [
				/* @__PURE__ */ U("h4", { children: "Colour and finish" }),
				/* @__PURE__ */ W("div", {
					className: "gs-m3d__swatches",
					children: [Hh.map((e) => /* @__PURE__ */ U("button", {
						type: "button",
						style: { background: e },
						className: c.every((t) => t.shape.color === e) ? "is-on" : "",
						"aria-label": `Colour ${e}`,
						onClick: () => d({ color: e }, "Colour")
					}, e)), /* @__PURE__ */ U("input", {
						type: "color",
						value: l.color,
						"aria-label": "Any colour",
						onChange: (e) => d({ color: e.target.value }, "Colour")
					})]
				}),
				/* @__PURE__ */ U(Dh, {
					label: "Finish",
					value: c.every((e) => e.shape.finish === l.finish) ? l.finish : "",
					options: Nt,
					labels: Vh,
					onChange: (e) => d({ finish: e }, Vh[e])
				}),
				/* @__PURE__ */ W("div", {
					className: "gs-m3d__row",
					children: [/* @__PURE__ */ U("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => yh(l),
						title: "Copy the first one's colour and finish (Ctrl Alt C)",
						children: "Copy look"
					}), /* @__PURE__ */ U("button", {
						type: "button",
						className: "gs-m3d__btn",
						disabled: !h,
						title: "Give them all the copied colour and finish (Ctrl Alt V)",
						onClick: () => h && d({
							color: h.color,
							finish: h.finish
						}, "Paste look"),
						children: "Paste look"
					})]
				}),
				/* @__PURE__ */ U(a, { id: "m3dLookCopy" })
			] }),
			s,
			f.length > 0 && /* @__PURE__ */ W("section", { children: [
				/* @__PURE__ */ U("h4", { children: "Combine" }),
				/* @__PURE__ */ U(Dh, {
					label: "Combine",
					value: f.every((e) => e.shape.combine === f[0].shape.combine) ? f[0].shape.combine : "",
					options: on,
					labels: Bh,
					onChange: (t) => e.updateShapesAt(f.map((e) => [e.ref, { combine: t }]), Bh[t])
				}),
				/* @__PURE__ */ U(Th, {
					label: "Blend",
					value: f[0].shape.blend,
					min: 0,
					max: 1,
					step: .01,
					format: (e) => `${Math.round(e * 100)}%`,
					onBegin: () => e.begin("Blend"),
					onChange: (t) => e.updateShapesAt(f.map((e) => [e.ref, { blend: t }])),
					onEnd: () => e.commit()
				})
			] })
		]
	}) : null;
}
//#endregion
//#region src/model3d/ModelMode.tsx
var qh = {
	soft: "Soft",
	toon: "Toon",
	flat: "Flat",
	clay: "Clay",
	pixel: "Pixel"
}, Jh = {
	perspective: "Perspective (0)",
	front: "Front (5)",
	left: "Left (4)",
	side: "Right (6)",
	back: "Back",
	top: "Top (8)",
	bottom: "Bottom (2)",
	"isometric-left": "Isometric, left (7)",
	isometric: "Isometric, right (9)",
	"isometric-below-left": "From below, left (1)",
	"isometric-below": "From below, right (3)"
}, Yh = {
	0: "perspective",
	5: "front",
	4: "left",
	6: "side",
	8: "top",
	2: "bottom",
	7: "isometric-left",
	9: "isometric",
	1: "isometric-below-left",
	3: "isometric-below"
}, Xh = [
	{
		mode: "translate",
		label: "Move",
		key: "W"
	},
	{
		mode: "rotate",
		label: "Turn",
		key: "E"
	},
	{
		mode: "scale",
		label: "Resize",
		key: "R"
	}
], Zh = "gleamshelf.model3d.grid", Qh = [
	.1,
	.25,
	.5,
	1,
	2
], $h = (e) => Math.min(10, Math.max(.05, Math.round(e * 100) / 100));
function eg() {
	try {
		let e = JSON.parse(localStorage.getItem(Zh) ?? "null");
		if (e && typeof e.size == "number" && Number.isFinite(e.size)) return {
			on: e.on !== !1,
			size: $h(e.size),
			snap: !!e.snap
		};
	} catch {}
	return {
		on: !0,
		size: .5,
		snap: !1
	};
}
var tg = (e, t) => !!e && !!t && e.length === t.length && e[0] === t[0] && e[1] === t[1], ng = (e, t) => {
	let n = document.createElement("a");
	n.href = URL.createObjectURL(e), n.download = t, n.click(), setTimeout(() => URL.revokeObjectURL(n.href), 4e3);
};
function rg({ open: e, title: t = "3D design", onDone: n, doneLabel: i = "Use in design", onClose: s, renderSize: c = 2e3, ad: l }) {
	let u = un(null);
	u.current ||= new sn(e ?? St());
	let d = u.current, f = dn(d.subscribe, d.getSnapshot), p = f.doc, m = un(null), h = un(null), g = un(null), [_, v] = H(e ? null : [0]), [y, b] = H([]), [x, S] = H("translate"), [C, w] = H(eg), [T, E] = H("shape"), [D, O] = H(null), [ee, k] = H(null), [A, te] = H(l ? "ad" : null), ne = t.replace(/[^\w -]+/g, "").trim() || "3d-design", re = un(null), ie = un(null), [ae, oe] = H(!1), [se, ce] = H(!1), [le, ue] = H(4);
	ln(() => {
		if (m.current) try {
			let e = new im(m.current, d, { onPick: (e, t) => {
				if (t.extend && e) {
					let t = e[0];
					b((e) => e.includes(t) ? e.filter((e) => e !== t) : [...e, t]), v([t]);
				} else v(e), b(e ? [e[0]] : []);
			} });
			return h.current = e, () => {
				e.dispose(), h.current = null;
			};
		} catch (e) {
			k(e instanceof Error ? `3D drawing could not start: ${e.message}` : "3D drawing could not start on this computer.");
		}
	}, [d]), ln(() => {
		y.length > 1 ? h.current?.selectSeveral(y) : h.current?.select(_);
	}, [_, y]), ln(() => h.current?.setGizmo(x), [x]), ln(() => {
		h.current?.setGrid(C.on ? C.size : 0, C.on && C.snap);
		try {
			localStorage.setItem(Zh, JSON.stringify(C));
		} catch {}
	}, [C]), ln(() => g.current?.focus(), []), ln(() => {
		_ && !qt(p, _) && v(null), b((e) => e.filter((e) => p.shapes[e]));
	}, [p, _]), ln(() => {
		y.length === 1 && _?.[0] !== y[0] && v([y[0]]);
	}, [y, _]);
	let j = qt(p, _), M = (e, t) => _ && d.updateShapeAt(_, e, t), de = (e) => () => d.begin(e), fe = () => d.commit(), pe = () => k("The design is full: it holds 48 shapes (a group counts two more) and 16 outlines or texts."), me = (e, t) => {
		v(e), e.length === 1 && b((n) => t ? n.includes(e[0]) ? n.filter((t) => t !== e[0]) : [...n, e[0]] : [e[0]]);
	}, he = (e) => {
		let t = d.addShape(e);
		if (t < 0) return pe();
		me([t], !1), E("shape");
	}, ge = (e, t, n, r) => {
		te(null);
		let i = t >= 1 ? 1 / t : 1, a = t >= 1 ? 1 : t, o = d.addShape("extrude", {
			name: n,
			outline: e,
			size: [
				a * 1.4,
				i * 1.4,
				.35
			],
			...r ? { pen: r } : {}
		});
		if (o < 0) return pe();
		me([o], !1), E("shape");
	}, _e = (e, t, n, r) => {
		if (te(null), !j || j.kind !== "extrude") return;
		let i = j.size[1];
		M({
			outline: e,
			pen: r,
			size: [
				i * t,
				i,
				j.size[2]
			]
		}, "Change outline");
	}, ve = (e) => e.value.replace(/\s+/g, " ").trim().slice(0, 30), ye = async (e) => {
		await Rm(e.font, e.weight, e.value);
		let t = rn(e.value, e.font, e.weight, Rt, e);
		if (!t) throw Error("That text draws nothing in this font.");
		return t;
	}, be = (e) => {
		te(null), R("Drawing the letters…", async () => {
			let t = await ye(e), n = .6 * Math.max(1, e.value.split("\n").length * .8), r = d.addShape("text", {
				name: ve(e),
				text: e,
				outline: t.outline,
				size: [
					n * t.aspect,
					n,
					.3
				]
			});
			if (r < 0) return pe();
			me([r], !1), E("shape");
		});
	}, xe = (e) => {
		if (te(null), !j || j.kind !== "text") return;
		let t = _, [n, r] = [j.size[1], j.size[2]];
		R("Drawing the letters…", async () => {
			let i = await ye(e);
			t && d.updateShapeAt(t, {
				text: e,
				outline: i.outline,
				name: ve(e),
				size: [
					n * i.aspect,
					n,
					r
				]
			}, "Change text");
		});
	}, Se = (e) => R("Reading the SVG…", async () => {
		let t = Ct(d.document.shapes), n = Math.min(16 - t.fields, 48 - t.slots - 2);
		if (n < 1) return pe();
		let r = zt(await e.text(), { maxParts: n }), [i, , a] = d.document.camera.target, o = e.name.replace(/\.svg$/i, "").slice(0, 60) || "Logo", s = Bt(r, {
			long: 2,
			at: [i, a]
		});
		s.length === 1 && (s[0].name = o);
		let c = d.addShapes(s, `Import ${o}`, o);
		if (c < 0) return pe();
		me([c], !1), E("shape"), d.frameAll(L()), r.warnings.length && k(`Imported. ${r.warnings.join(" ")}`);
	}), N = (e) => {
		te(null), R("Making the ad…", async () => {
			let t = [], n;
			if (e.picture) {
				let r = await ag(e.picture);
				n = {
					asset: ao(r.bytes, "image/png", r.width, r.height, "Product photo"),
					aspect: r.width / r.height
				}, r.seeThrough < .02 && t.push("The picture has no see-through background, so its rectangle shows: a cut-out looks best.");
			}
			let r = [
				e.headline,
				e.tagline,
				e.price
			].join(" ");
			await Rm(e.font.family, 900, r);
			let i = e.logo ? zt(e.logo.svg, { maxParts: 6 }) : void 0, a = Kt({
				style: e.style,
				colours: e.colours,
				picture: n,
				headline: e.headline,
				tagline: e.tagline,
				price: e.price,
				logo: i,
				font: e.font.family,
				moving: e.moving,
				text: (e) => rn(e.value, e.font, e.weight, Rt, e)
			}, L());
			d.replaceDesign(a, "Make an ad"), v(null), b([]), E("shape"), e.moving && ce(!0), i && t.push(...i.warnings.filter((e) => /^(Text|Lines|Strokes|Pictures)/.test(e))), t.length && k(t.join(" "));
		});
	}, Ce = (e) => {
		let t = e.find((e) => /\.svg$/i.test(e.name) || e.type === "image/svg+xml");
		t ? Se(t) : Fe(e);
	}, we = () => {
		let e = d.group(y.length ? y : _?.length === 1 ? [_[0]] : []);
		if (e < 0) return pe();
		me([e], !1);
	}, Te = () => {
		_ && _.length === 1 && j?.kind === "group" && me([d.ungroup(_[0])], !1);
	}, Ee = () => {
		if (y.length > 1) d.removeShapes(y);
		else if (_) d.removeShapeAt(_);
		else return;
		v(null), b([]);
	}, De = () => {
		if (y.length > 1) {
			let e = d.pasteShapes(y.map((e) => p.shapes[e]).filter(Boolean), {}, [
				.6,
				0,
				0
			]);
			if (!e) return pe();
			b(e), v([e[e.length - 1]]);
			return;
		}
		if (!_) return;
		let e = d.duplicateShapeAt(_);
		if (!e) return pe();
		me(e, !1);
	}, Oe = () => (y.length ? y : _ ? [_[0]] : []).filter((e) => p.shapes[e]), ke = (e = !1) => {
		let t = Oe();
		t.length && (gh(d.document, t.map((e) => p.shapes[e])), e && (d.removeShapes(t), v(null), b([])));
	}, Ae = () => {
		let e = _h();
		if (!e) return !1;
		let t = d.pasteShapes(e.shapes, e.assets, vh());
		return t ? (b(t), v([t[t.length - 1]]), E("shape"), !0) : (pe(), !0);
	}, je = un(null), P = (e) => {
		if (je.current && clearTimeout(je.current), je.current = null, A) return;
		let t = e.target;
		if (t.tagName === "INPUT" || t.tagName === "TEXTAREA") return;
		let n = e.clipboardData.getData("text/plain");
		/^\s*(<\?xml[^>]*>\s*)?(<!--[\s\S]*?-->\s*)*<svg[\s>]/i.test(n) ? (e.preventDefault(), Se(new File([n], "Pasted logo.svg", { type: "image/svg+xml" }))) : Ae() && e.preventDefault();
	}, Me = (e) => {
		let t = Oe();
		if (!t.length) return;
		let n = !t.every((t) => p.shapes[t][e]);
		d.updateShapesAt(t.map((t) => [[t], { [e]: n }]), e === "locked" ? n ? "Lock" : "Unlock" : n ? "Hide" : "Show");
	}, Ne = () => {
		let e = bh();
		if (!e) return;
		let t = y.length > 1 ? Wh(p, y) : _ ? j?.kind === "group" ? Wh(p, [_[0]]) : [{
			ref: _,
			shape: j
		}] : [];
		d.updateShapesAt(t.map(({ ref: t, shape: n }) => [t, {
			color: e.color,
			finish: e.finish,
			...n.kind === "mesh" ? { ownColors: !1 } : {}
		}]), "Paste look");
	}, F = (e, t = !1) => {
		if (!_) return;
		let n = _;
		for (let r = 0; r < (t ? 48 : 1); r++) {
			let t = d.moveShapeAt(n, e);
			if (tg(t, n)) break;
			n = t;
		}
		me(n, !1);
	}, I = (e) => {
		if (A) return;
		let t = e.target;
		if (t.tagName === "INPUT" && t.type !== "range" || t.tagName === "SELECT") return;
		let n = e.metaKey || e.ctrlKey, r = e.code.startsWith("Key") ? e.code.slice(3).toLowerCase() : e.key.toLowerCase(), i = /^(?:Digit|Numpad)(\d)$/.exec(e.code)?.[1], a = (t) => {
			e.preventDefault(), t();
		};
		n && r === "z" ? a(() => e.shiftKey ? d.redo() : d.undo()) : n && r === "y" ? a(() => d.redo()) : n && r === "a" ? a(() => {
			b(p.shapes.map((e, t) => t)), v(p.shapes.length ? [p.shapes.length - 1] : null);
		}) : n && e.altKey && r === "c" ? a(() => j && j.kind !== "group" && yh(j)) : n && e.altKey && r === "v" ? a(Ne) : n && e.altKey && r === "l" ? a(() => Me("locked")) : n && e.shiftKey && r === "h" ? a(() => Me("hidden")) : n && e.shiftKey && r === "c" ? a(() => void ze()) : n && r === "c" ? a(() => ke()) : n && r === "x" ? a(() => ke(!0)) : n && r === "v" && !e.shiftKey ? (je.current && clearTimeout(je.current), je.current = setTimeout(() => {
			je.current = null, Ae();
		}, 80)) : n && r === "d" ? a(De) : n && r === "g" ? a(() => e.shiftKey ? Te() : we()) : n && (e.code === "BracketRight" || e.code === "BracketLeft") ? a(() => F(e.code === "BracketRight" ? 1 : -1, e.altKey)) : n && e.key.startsWith("Arrow") ? a(() => d.snapOrbit(e.key === "ArrowLeft" ? -1 : +(e.key === "ArrowRight"), e.key === "ArrowUp" ? 1 : e.key === "ArrowDown" ? -1 : 0)) : !n && i && Yh[i] ? a(() => d.setView(Yh[i])) : !n && r === "w" ? S("translate") : !n && r === "e" ? S("rotate") : !n && r === "r" ? S("scale") : !n && r === "f" ? d.frameAll(L()) : !n && r === "g" ? w((e) => ({
			...e,
			on: !e.on
		})) : !n && (e.code === "Space" || e.key === " ") ? a(V) : (e.key === "Delete" || e.key === "Backspace") && (_ || y.length) ? a(Ee) : e.key === "Escape" && (v(null), b([]));
	}, L = () => {
		let e = m.current?.getBoundingClientRect();
		return e && e.height > 0 ? e.width / e.height : 1;
	}, Pe = async () => {
		let e = L(), t = d.document.background.transparent && !d.document.background.picture, n = t ? 1.8 : 1, r = Math.round(c * n), [i, a] = e >= 1 ? [r, Math.round(r / e)] : [Math.round(r * e), r], s = await om(d.document, i, a, "image/png", n);
		if (!t) return s;
		let l = await o(await createImageBitmap(s)), u = document.createElement("canvas");
		return u.width = l.width, u.height = l.height, u.getContext("2d").drawImage(l, 0, 0), l.close(), new Promise((e, t) => u.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be made.")), "image/png"));
	}, R = async (e, t) => {
		O(e);
		try {
			await t();
		} catch (e) {
			k(e instanceof Error ? e.message : "That did not work.");
		} finally {
			O(null);
		}
	}, Fe = (e) => R("Reading the model…", async () => {
		let { asset: t, warnings: n } = await xm(e), r = d.addModel(t);
		r < 0 ? k("The design holds 16 imported models; remove one first.") : (me([r], !1), E("shape"), d.frameAll(L()), n.length && k(`Imported. ${n.join(" ")}`));
	}), Ie = (e) => {
		let t = Tt(e.rotation);
		return [
			0,
			1,
			2
		].reduce((n, r) => n + Math.abs(t[3 + r]) * e.size[r] / 2, 0);
	}, Le = () => R("Drawing the picture…", async () => ng(await Pe(), `${ne}.png`)), Re = async () => {
		let e = L(), t = d.document.background.transparent && !d.document.background.picture, n = t ? 1200 : 900, [r, i] = e >= 1 ? [n, Math.round(n / e)] : [Math.round(n * e), n];
		return Qt(d.document, {
			width: r,
			height: i,
			frame: t ? 1.6 : 1,
			tones: d.document.style.look === "toon" ? d.document.style.bands : 3,
			onProgress: async (e) => {
				O(`Tracing the vectors… ${Math.round(e * 100)}%`), await new Promise((e) => setTimeout(e, 0));
			}
		});
	}, z = () => R("Tracing the vectors…", async () => ng(new Blob([await Re()], { type: "image/svg+xml" }), `${ne}.svg`)), ze = () => R("Copying the picture…", async () => {
		await xh(Pe()), k("Picture copied: paste it into another app.");
	}), B = () => R("Tracing the vectors…", async () => {
		await Ch(Re()), k("Vectors copied: paste them into a drawing app.");
	});
	ln(() => {
		let e = h.current;
		if (!se || !e) return;
		let t = performance.now(), n = 0, r = (i) => {
			e.showFrame(Mt(d.document, ((i - t) / 1e3 / le % 1 + 1) % 1)), n = requestAnimationFrame(r);
		};
		return n = requestAnimationFrame(r), () => {
			cancelAnimationFrame(n), e.showFrame(null);
		};
	}, [
		se,
		le,
		d
	]);
	let V = () => ce((e) => !e), Be = (e, t, n) => {
		ue(t), te(null), R("Making the video…", async () => {
			let r = await lm(d.document, {
				kind: e,
				seconds: t,
				size: n,
				aspect: L(),
				onProgress: (e) => O(`Making the video… ${Math.round(e * 100)}%`)
			});
			ng(r.blob, `${ne}-${e}.${r.extension}`);
		});
	}, Ve = () => n && R("Drawing the picture…", async () => n(await Pe(), yt(d.document))), He = p.light, Ue = p.style, We = (e) => e.kind === "text" ? "text" : e.kind, Ge = (y.length ? y : _?.length === 1 ? [_[0]] : []).some((e) => p.shapes[e] && p.shapes[e].kind !== "group"), Ke = (e, t, n) => /* @__PURE__ */ W("li", {
		className: `${tg(t, _) ? "is-on" : ""} ${t.length === 1 && y.includes(t[0]) && !tg(t, _) ? "is-picked" : ""}`,
		style: { paddingLeft: n * 14 },
		children: [
			/* @__PURE__ */ W("button", {
				type: "button",
				className: "gs-m3d__item",
				onClick: (e) => me(t, e.shiftKey || e.metaKey || e.ctrlKey),
				children: [
					e.kind === "group" ? /* @__PURE__ */ U(wh, { kind: "group" }) : /* @__PURE__ */ U("span", {
						className: "gs-m3d__dot",
						style: { background: e.color }
					}),
					/* @__PURE__ */ U("span", {
						className: "gs-m3d__name",
						children: e.name
					}),
					e.combine !== "add" && /* @__PURE__ */ U("span", {
						className: "gs-m3d__tag",
						children: Bh[e.combine]
					})
				]
			}),
			t.length === 1 && /* @__PURE__ */ U("button", {
				type: "button",
				className: `gs-m3d__icon ${e.locked ? "is-locked" : "gs-m3d__icon--quiet"}`,
				title: e.locked ? "Unlock: it can be picked and dragged again" : "Lock: it cannot be picked or dragged in the view",
				"aria-pressed": !!e.locked,
				onClick: () => d.updateShapeAt(t, { locked: !e.locked }, e.locked ? "Unlock" : "Lock"),
				children: /* @__PURE__ */ U(ig, { open: !e.locked })
			}),
			/* @__PURE__ */ U("button", {
				type: "button",
				className: "gs-m3d__icon",
				title: e.hidden ? "Show" : "Hide",
				onClick: () => d.updateShapeAt(t, { hidden: !e.hidden }, e.hidden ? "Show" : "Hide"),
				children: e.hidden ? "◌" : "●"
			})
		]
	}, e.id);
	return /* @__PURE__ */ W("div", {
		className: "gs-m3d",
		ref: g,
		tabIndex: -1,
		onKeyDown: I,
		onPaste: P,
		children: [
			/* @__PURE__ */ W("header", {
				className: "gs-m3d__top",
				children: [
					/* @__PURE__ */ U("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: s,
						children: "← Back"
					}),
					/* @__PURE__ */ U("strong", {
						className: "gs-m3d__title",
						children: t
					}),
					/* @__PURE__ */ U("button", {
						type: "button",
						className: `gs-m3d__btn ${se ? "is-on" : ""}`,
						onClick: V,
						title: cn(p) ? "Play the shapes’ motion (Space)" : "Give a shape a motion (in its panel), then play it here (Space)",
						children: se ? "■ Stop" : "▶ Play"
					}),
					/* @__PURE__ */ U("div", {
						className: "gs-m3d__group",
						role: "group",
						"aria-label": "Gizmo",
						children: Xh.map((e) => /* @__PURE__ */ W("button", {
							type: "button",
							className: `gs-m3d__btn ${x === e.mode ? "is-on" : ""}`,
							onClick: () => S(e.mode),
							title: `${e.label} (${e.key})`,
							children: [
								e.label,
								" ",
								/* @__PURE__ */ U("kbd", { children: e.key })
							]
						}, e.mode))
					}),
					/* @__PURE__ */ W("select", {
						className: "gs-m3d__select",
						"aria-label": "View",
						value: "",
						onChange: (e) => {
							e.target.value === "frame" ? d.frameAll(L()) : e.target.value && d.setView(e.target.value), e.currentTarget.blur();
						},
						children: [
							/* @__PURE__ */ U("option", {
								value: "",
								children: "View…"
							}),
							Object.keys(Jh).map((e) => /* @__PURE__ */ U("option", {
								value: e,
								children: Jh[e]
							}, e)),
							/* @__PURE__ */ U("option", {
								value: "frame",
								children: "Frame all (F)"
							})
						]
					}),
					/* @__PURE__ */ W("div", {
						className: "gs-m3d__group",
						role: "group",
						"aria-label": "Grid",
						children: [
							/* @__PURE__ */ W("button", {
								type: "button",
								className: `gs-m3d__btn ${C.on ? "is-on" : ""}`,
								onClick: () => w((e) => ({
									...e,
									on: !e.on
								})),
								title: "Show the grid on the ground (G); it is never in saved pictures or video",
								children: ["Grid ", /* @__PURE__ */ U("kbd", { children: "G" })]
							}),
							/* @__PURE__ */ U("input", {
								className: "gs-m3d__cell",
								type: "number",
								list: "gs-m3d-cells",
								min: .05,
								max: 10,
								step: .05,
								value: C.size,
								disabled: !C.on,
								"aria-label": "Grid cell size",
								title: "Grid cell size, in the same units as Size and Place (the starter box is 1 across)",
								onChange: (e) => {
									let t = Number(e.target.value);
									Number.isFinite(t) && t > 0 && w((e) => ({
										...e,
										size: $h(t)
									}));
								}
							}),
							/* @__PURE__ */ U("datalist", {
								id: "gs-m3d-cells",
								children: Qh.map((e) => /* @__PURE__ */ U("option", { value: e }, e))
							}),
							/* @__PURE__ */ U("button", {
								type: "button",
								className: `gs-m3d__btn ${C.on && C.snap ? "is-on" : ""}`,
								disabled: !C.on,
								onClick: () => w((e) => ({
									...e,
									snap: !e.snap
								})),
								title: "Snap: moving goes in whole grid cells, turning in 15° steps",
								children: "Snap"
							})
						]
					}),
					/* @__PURE__ */ U("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ U("button", {
						type: "button",
						className: "gs-m3d__btn",
						disabled: !f.canUndo,
						onClick: () => d.undo(),
						title: f.undoLabel ? `Undo ${f.undoLabel}` : "Undo",
						children: "Undo"
					}),
					/* @__PURE__ */ U("button", {
						type: "button",
						className: "gs-m3d__btn",
						disabled: !f.canRedo,
						onClick: () => d.redo(),
						title: f.redoLabel ? `Redo ${f.redoLabel}` : "Redo",
						children: "Redo"
					}),
					/* @__PURE__ */ W("select", {
						className: "gs-m3d__select",
						"aria-label": "Save",
						value: "",
						disabled: !!D,
						onChange: (e) => {
							let t = e.target.value;
							e.currentTarget.blur(), t === "png" ? Le() : t === "svg" ? z() : t === "copy-png" ? ze() : t === "copy-svg" ? B() : t === "video" && te("video");
						},
						children: [
							/* @__PURE__ */ U("option", {
								value: "",
								children: "Save…"
							}),
							/* @__PURE__ */ U("option", {
								value: "png",
								children: "Picture (PNG)"
							}),
							/* @__PURE__ */ U("option", {
								value: "svg",
								children: "Vectors (SVG)"
							}),
							/* @__PURE__ */ U("option", {
								value: "video",
								children: "Video…"
							}),
							/* @__PURE__ */ U("option", {
								value: "copy-png",
								children: "Copy the picture (Ctrl Shift C)"
							}),
							/* @__PURE__ */ U("option", {
								value: "copy-svg",
								children: "Copy as vectors (SVG)"
							})
						]
					}),
					n && /* @__PURE__ */ U("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: !!D,
						onClick: () => void Ve(),
						children: i
					})
				]
			}),
			/* @__PURE__ */ W("div", {
				className: "gs-m3d__body",
				children: [
					/* @__PURE__ */ W("aside", {
						className: "gs-m3d__left",
						"aria-label": "Shapes",
						children: [
							/* @__PURE__ */ U("h3", { children: "Add a shape" }),
							/* @__PURE__ */ W("div", {
								className: "gs-m3d__add",
								children: [
									an.map((e) => /* @__PURE__ */ W("button", {
										type: "button",
										onClick: () => he(e),
										title: `Add a ${Pt[e].toLowerCase()}`,
										children: [/* @__PURE__ */ U(wh, { kind: e }), /* @__PURE__ */ U("span", { children: Pt[e] })]
									}, e)),
									/* @__PURE__ */ W("button", {
										type: "button",
										onClick: () => te("outline"),
										title: "Push out an outline: a star, a heart, or one you draw",
										children: [/* @__PURE__ */ U(wh, { kind: "extrude" }), /* @__PURE__ */ U("span", { children: "Outline" })]
									}),
									/* @__PURE__ */ W("button", {
										type: "button",
										onClick: () => te("text"),
										title: "3D text",
										children: [/* @__PURE__ */ U(wh, { kind: "text" }), /* @__PURE__ */ U("span", { children: "Text" })]
									}),
									/* @__PURE__ */ W("button", {
										type: "button",
										onClick: () => te("ad"),
										title: "A 3D ad: the product's photo, a headline, the price and your logo",
										children: [/* @__PURE__ */ U(wh, { kind: "ad" }), /* @__PURE__ */ U("span", { children: "Ad" })]
									}),
									/* @__PURE__ */ W("button", {
										type: "button",
										onClick: () => ie.current?.click(),
										title: "A logo or drawing from an SVG file: one 3D piece per colour",
										children: [/* @__PURE__ */ U(wh, { kind: "svg" }), /* @__PURE__ */ U("span", { children: "SVG logo" })]
									}),
									/* @__PURE__ */ W("button", {
										type: "button",
										onClick: () => re.current?.click(),
										title: "Import a 3D model: GLB, glTF, FBX, OBJ, STL, PLY or 3MF",
										children: [/* @__PURE__ */ U(wh, { kind: "mesh" }), /* @__PURE__ */ U("span", { children: "Import" })]
									}),
									/* @__PURE__ */ U("input", {
										ref: ie,
										type: "file",
										accept: ".svg,image/svg+xml",
										hidden: !0,
										onChange: (e) => {
											let t = e.target.files?.[0];
											e.target.value = "", t && Se(t);
										}
									}),
									/* @__PURE__ */ U("input", {
										ref: re,
										type: "file",
										multiple: !0,
										accept: pm,
										hidden: !0,
										onChange: (e) => {
											let t = [...e.target.files ?? []];
											e.target.value = "", t.length && Ce(t);
										}
									})
								]
							}),
							/* @__PURE__ */ U(a, { id: "m3dAdd" }),
							/* @__PURE__ */ U("h3", { children: "Shapes" }),
							/* @__PURE__ */ U("ul", {
								className: "gs-m3d__list",
								children: p.shapes.map((e, t) => [Ke(e, [t], 0), ...e.kind === "group" ? (e.children ?? []).map((e, n) => Ke(e, [t, n], 1)) : []])
							}),
							/* @__PURE__ */ W("div", {
								className: "gs-m3d__listtools",
								children: [
									_ && /* @__PURE__ */ W(fn, { children: [
										/* @__PURE__ */ U("button", {
											type: "button",
											onClick: () => v(d.moveShapeAt(_, -1)),
											title: "Earlier: joined before the ones below",
											children: "↑"
										}),
										/* @__PURE__ */ U("button", {
											type: "button",
											onClick: () => v(d.moveShapeAt(_, 1)),
											title: "Later: joined onto the ones above",
											children: "↓"
										}),
										/* @__PURE__ */ U("button", {
											type: "button",
											onClick: De,
											title: "Duplicate (Ctrl D)",
											children: "Duplicate"
										}),
										/* @__PURE__ */ U("button", {
											type: "button",
											onClick: Ee,
											title: "Delete",
											children: "Delete"
										})
									] }),
									Ge && /* @__PURE__ */ W("button", {
										type: "button",
										onClick: we,
										title: "Group the picked shapes (Ctrl G); Shift-click to pick several",
										children: ["Group", y.length > 1 ? ` ${y.length}` : ""]
									}),
									j?.kind === "group" && /* @__PURE__ */ U("button", {
										type: "button",
										onClick: Te,
										title: "Ungroup (Ctrl Shift G)",
										children: "Ungroup"
									})
								]
							}),
							/* @__PURE__ */ U(a, { id: "m3dShapes" }),
							/* @__PURE__ */ U(a, { id: "m3dGroup" })
						]
					}),
					/* @__PURE__ */ W("main", {
						className: `gs-m3d__stage ${ae ? "is-dropping" : ""}`,
						onDragOver: (e) => {
							e.dataTransfer.types.includes("Files") && (e.preventDefault(), oe(!0));
						},
						onDragLeave: () => oe(!1),
						onDrop: (e) => {
							e.preventDefault(), oe(!1);
							let t = [...e.dataTransfer.files];
							t.length && Ce(t);
						},
						children: [
							/* @__PURE__ */ U("div", {
								className: "gs-m3d__viewport",
								ref: m
							}),
							/* @__PURE__ */ U("div", {
								className: "gs-m3d__hint",
								children: /* @__PURE__ */ U(a, { id: j ? "m3dGizmo" : "m3dView" })
							}),
							D && /* @__PURE__ */ W("div", {
								className: "gs-m3d__busy",
								role: "status",
								children: [
									/* @__PURE__ */ U("span", {
										className: "gs-m3d__spin",
										"aria-hidden": "true"
									}),
									" ",
									D
								]
							}),
							ee && /* @__PURE__ */ W("div", {
								className: "gs-m3d__problem",
								role: "alert",
								children: [ee, /* @__PURE__ */ U("button", {
									type: "button",
									onClick: () => k(null),
									children: "Dismiss"
								})]
							})
						]
					}),
					/* @__PURE__ */ W("aside", {
						className: "gs-m3d__right",
						"aria-label": "Settings",
						children: [
							/* @__PURE__ */ W("nav", {
								className: "gs-m3d__tabs",
								role: "tablist",
								children: [/* @__PURE__ */ U("button", {
									type: "button",
									role: "tab",
									"aria-selected": T === "shape",
									className: T === "shape" ? "is-on" : "",
									onClick: () => E("shape"),
									children: "Shape"
								}), /* @__PURE__ */ U("button", {
									type: "button",
									role: "tab",
									"aria-selected": T === "scene",
									className: T === "scene" ? "is-on" : "",
									onClick: () => E("scene"),
									children: "Light and look"
								})]
							}),
							T === "shape" && (y.length > 1 ? /* @__PURE__ */ U(Kh, {
								editor: d,
								doc: p,
								picked: y,
								onDuplicate: De,
								onDelete: Ee,
								onGroup: we,
								motion: /* @__PURE__ */ U(Ah, {
									editor: d,
									items: y.flatMap((e) => p.shapes[e] ? [{
										ref: [e],
										shape: p.shapes[e]
									}] : []),
									playing: se,
									onPlay: V
								})
							}) : j ? /* @__PURE__ */ W("div", {
								className: "gs-m3d__panel",
								children: [
									/* @__PURE__ */ U("input", {
										className: "gs-m3d__rename",
										value: j.name,
										"aria-label": "Shape name",
										onChange: (e) => M({ name: e.target.value }, "Rename")
									}),
									(j.locked || _?.length === 2 && p.shapes[_[0]]?.locked) && /* @__PURE__ */ U("p", {
										className: "gs-m3d__note",
										children: "Locked: it is not picked or dragged in the view. Unlock it in the list to move it there."
									}),
									j.kind === "mesh" && /* @__PURE__ */ W("section", { children: [
										/* @__PURE__ */ U("h4", { children: "Imported model" }),
										/* @__PURE__ */ W("p", {
											className: "gs-m3d__meta",
											children: [
												p.assets?.[j.asset ?? ""]?.name ?? "Model",
												" ·",
												" ",
												(p.assets?.[j.asset ?? ""]?.triangles ?? 0).toLocaleString("en"),
												" triangles"
											]
										}),
										/* @__PURE__ */ U(Dh, {
											label: "Colours",
											value: j.ownColors === !1 ? "one" : "own",
											options: ["own", "one"],
											labels: {
												own: "Its own",
												one: "One colour"
											},
											onChange: (e) => M({ ownColors: e === "own" }, e === "own" ? "Own colours" : "One colour")
										}),
										/* @__PURE__ */ W("div", {
											className: "gs-m3d__row",
											children: [/* @__PURE__ */ U("button", {
												type: "button",
												className: "gs-m3d__btn",
												title: "For a model made lying down (z up): turns it a quarter round to stand on the ground",
												onClick: () => {
													let e = [
														j.rotation[0] === -90 ? 0 : -90,
														j.rotation[1],
														j.rotation[2]
													];
													M({
														rotation: e,
														position: [
															j.position[0],
															Ie({
																...j,
																rotation: e
															}),
															j.position[2]
														]
													}, "Stand it up");
												},
												children: "Stand it up"
											}), /* @__PURE__ */ U("button", {
												type: "button",
												className: "gs-m3d__btn",
												onClick: () => M({ position: [
													j.position[0],
													Ie(j),
													j.position[2]
												] }, "Put on the ground"),
												children: "Put on the ground"
											})]
										}),
										/* @__PURE__ */ U(a, { id: "m3dImport" })
									] }),
									/* @__PURE__ */ W("section", { children: [/* @__PURE__ */ U("h4", { children: j.kind === "group" ? "How the group joins" : "Combine" }), j.kind === "mesh" ? /* @__PURE__ */ U("p", {
										className: "gs-m3d__meta",
										children: "An imported model is always added as it is: Cut and Blend work between the shapes you build, not on a model."
									}) : /* @__PURE__ */ W(fn, { children: [
										/* @__PURE__ */ U(Dh, {
											label: "Combine",
											value: j.combine,
											options: on,
											labels: Bh,
											onChange: (e) => M({ combine: e }, Bh[e])
										}),
										/* @__PURE__ */ U(Th, {
											label: "Blend",
											value: j.blend,
											min: 0,
											max: 1,
											step: .01,
											format: (e) => `${Math.round(e * 100)}%`,
											onBegin: de("Blend"),
											onChange: (e) => M({ blend: e }),
											onEnd: fe
										}),
										/* @__PURE__ */ U(a, { id: j.kind === "group" ? "m3dGroup" : "m3dCombine" })
									] })] }),
									_ && /* @__PURE__ */ U(Ah, {
										editor: d,
										items: [{
											ref: _,
											shape: j
										}],
										playing: se,
										onPlay: V
									}),
									We(j) === "text" && j.text && /* @__PURE__ */ W("section", { children: [
										/* @__PURE__ */ U("h4", { children: "Text" }),
										/* @__PURE__ */ U("p", {
											className: "gs-m3d__textpreview",
											style: {
												fontFamily: `"${j.text.font}", sans-serif`,
												fontWeight: j.text.weight,
												whiteSpace: "pre",
												textAlign: j.text.align ?? "center"
											},
											children: j.text.value
										}),
										/* @__PURE__ */ U("button", {
											type: "button",
											className: "gs-m3d__btn",
											onClick: () => te("edit-text"),
											children: "Change text or font…"
										}),
										/* @__PURE__ */ U(a, { id: "m3dText" })
									] }),
									j.kind === "extrude" && /* @__PURE__ */ W("section", { children: [
										/* @__PURE__ */ U("h4", { children: "Outline" }),
										j.pen ? /* @__PURE__ */ U("button", {
											type: "button",
											className: "gs-m3d__btn",
											onClick: () => te("edit-outline"),
											children: "Edit points…"
										}) : /* @__PURE__ */ U("p", {
											className: "gs-m3d__note",
											children: "Made from a picture or a logo, so it has no pen points to edit."
										}),
										/* @__PURE__ */ U(a, { id: "m3dPen" })
									] }),
									j.kind !== "group" && /* @__PURE__ */ W(fn, { children: [(j.kind !== "mesh" || j.ownColors === !1) && /* @__PURE__ */ W("section", { children: [
										/* @__PURE__ */ U("h4", { children: "Colour and finish" }),
										/* @__PURE__ */ W("div", {
											className: "gs-m3d__swatches",
											children: [Hh.map((e) => /* @__PURE__ */ U("button", {
												type: "button",
												style: { background: e },
												className: j.color === e ? "is-on" : "",
												"aria-label": `Colour ${e}`,
												onClick: () => M({ color: e }, "Colour")
											}, e)), /* @__PURE__ */ U("input", {
												type: "color",
												value: j.color,
												"aria-label": "Any colour",
												onChange: (e) => M({ color: e.target.value }, "Colour")
											})]
										}),
										/* @__PURE__ */ U(Dh, {
											label: "Finish",
											value: j.finish,
											options: Nt,
											labels: Vh,
											onChange: (e) => M({ finish: e }, Vh[e])
										}),
										/* @__PURE__ */ W("div", {
											className: "gs-m3d__row",
											children: [/* @__PURE__ */ U("button", {
												type: "button",
												className: "gs-m3d__btn",
												onClick: () => yh(j),
												title: "Ctrl Alt C",
												children: "Copy look"
											}), /* @__PURE__ */ U("button", {
												type: "button",
												className: "gs-m3d__btn",
												disabled: !bh(),
												onClick: Ne,
												title: "Ctrl Alt V",
												children: "Paste look"
											})]
										}),
										/* @__PURE__ */ U(a, { id: "m3dMaterial" })
									] }), /* @__PURE__ */ W("section", { children: [
										/* @__PURE__ */ U("h4", { children: "Size and place" }),
										/* @__PURE__ */ U(Eh, {
											label: j.outline ? "W, H, depth" : "Size",
											value: j.size,
											step: .05,
											min: .01,
											onChange: (e) => M({ size: e }, "Size")
										}),
										/* @__PURE__ */ U(Eh, {
											label: "Place",
											value: j.position,
											step: .05,
											onChange: (e) => M({ position: e }, "Move")
										}),
										/* @__PURE__ */ U(Eh, {
											label: "Turn",
											value: j.rotation,
											step: 5,
											onChange: (e) => M({ rotation: e }, "Turn")
										}),
										_?.length === 1 && /* @__PURE__ */ W("div", {
											className: "gs-m3d__row",
											children: [/* @__PURE__ */ U("button", {
												type: "button",
												className: "gs-m3d__btn",
												onClick: () => d.toGround([_[0]]),
												children: "On the ground"
											}), /* @__PURE__ */ U("button", {
												type: "button",
												className: "gs-m3d__btn",
												title: "To the middle of the scene, left to right and front to back",
												onClick: () => {
													d.begin("To the middle"), d.align([_[0]], 0, "mid"), d.align([_[0]], 2, "mid"), d.commit();
												},
												children: "To the middle"
											})]
										}),
										j.kind !== "sphere" && j.kind !== "torus" && j.kind !== "capsule" && j.kind !== "mesh" && /* @__PURE__ */ U(Th, {
											label: j.outline ? "Bevel" : "Rounding",
											value: j.round,
											min: 0,
											max: .5,
											step: .01,
											format: (e) => `${Math.round(e * 200)}%`,
											onBegin: de("Rounding"),
											onChange: (e) => M({ round: e }),
											onEnd: fe
										}),
										j.kind === "torus" && /* @__PURE__ */ U(Th, {
											label: "Tube",
											value: j.thickness,
											min: .05,
											max: .5,
											step: .01,
											format: (e) => `${Math.round(e * 100)}%`,
											onBegin: de("Tube"),
											onChange: (e) => M({ thickness: e }),
											onEnd: fe
										}),
										/* @__PURE__ */ U(a, { id: j.outline ? "m3dOutlineShape" : "m3dSize" })
									] })] })
								]
							}) : /* @__PURE__ */ W("div", {
								className: "gs-m3d__panel",
								children: [/* @__PURE__ */ U("p", {
									className: "gs-m3d__empty",
									children: "Pick a shape in the view or the list to change it, or add one on the left."
								}), /* @__PURE__ */ U(a, { id: "m3dView" })]
							})),
							T === "scene" && /* @__PURE__ */ W("div", {
								className: "gs-m3d__panel",
								children: [
									/* @__PURE__ */ W("section", { children: [
										/* @__PURE__ */ U("h4", { children: "Look" }),
										/* @__PURE__ */ U(Dh, {
											label: "Look",
											value: Ue.look,
											options: xt,
											labels: qh,
											onChange: (e) => d.setSetting("style", "look", e, `${qh[e]} look`)
										}),
										Ue.look === "pixel" && /* @__PURE__ */ U(Th, {
											label: "Pixel size",
											value: Ue.pixel,
											min: 3,
											max: 40,
											step: 1,
											format: (e) => `${e}`,
											onBegin: de("Pixel size"),
											onChange: (e) => d.setSetting("style", "pixel", e),
											onEnd: fe
										}),
										(Ue.look === "toon" || Ue.look === "pixel") && /* @__PURE__ */ U(Th, {
											label: "Steps of light",
											value: Ue.bands,
											min: 2,
											max: 6,
											step: 1,
											onBegin: de("Steps of light"),
											onChange: (e) => d.setSetting("style", "bands", e),
											onEnd: fe
										}),
										/* @__PURE__ */ U(a, { id: "m3dLook" })
									] }),
									/* @__PURE__ */ W("section", { children: [
										/* @__PURE__ */ U("h4", { children: "Outline" }),
										/* @__PURE__ */ U(Th, {
											label: "Width",
											value: Ue.outline,
											min: 0,
											max: 12,
											step: .5,
											format: (e) => e ? `${e} px` : "None",
											onBegin: de("Outline"),
											onChange: (e) => d.setSetting("style", "outline", e),
											onEnd: fe
										}),
										Ue.outline > 0 && /* @__PURE__ */ W("label", {
											className: "gs-m3d__colour",
											children: [
												/* @__PURE__ */ U("input", {
													type: "color",
													value: Ue.outlineColor,
													onChange: (e) => d.setSetting("style", "outlineColor", e.target.value, "Outline colour")
												}),
												" ",
												"Outline colour"
											]
										}),
										/* @__PURE__ */ U(a, { id: "m3dOutline" })
									] }),
									/* @__PURE__ */ W("section", { children: [
										/* @__PURE__ */ U("h4", { children: "Light" }),
										/* @__PURE__ */ U(Th, {
											label: "Around",
											value: He.azimuth,
											min: -180,
											max: 180,
											step: 1,
											format: (e) => `${e}°`,
											onBegin: de("Light around"),
											onChange: (e) => d.setSetting("light", "azimuth", e),
											onEnd: fe
										}),
										/* @__PURE__ */ U(Th, {
											label: "Height",
											value: He.elevation,
											min: 0,
											max: 90,
											step: 1,
											format: (e) => `${e}°`,
											onBegin: de("Light height"),
											onChange: (e) => d.setSetting("light", "elevation", e),
											onEnd: fe
										}),
										/* @__PURE__ */ U(Th, {
											label: "Brightness",
											value: He.intensity,
											min: 0,
											max: 3,
											step: .05,
											onBegin: de("Brightness"),
											onChange: (e) => d.setSetting("light", "intensity", e),
											onEnd: fe
										}),
										/* @__PURE__ */ U(Th, {
											label: "Fill",
											value: He.ambient,
											min: 0,
											max: 1,
											step: .01,
											format: (e) => `${Math.round(e * 100)}%`,
											onBegin: de("Fill light"),
											onChange: (e) => d.setSetting("light", "ambient", e),
											onEnd: fe
										}),
										/* @__PURE__ */ W("label", {
											className: "gs-m3d__check",
											children: [
												/* @__PURE__ */ U("input", {
													type: "checkbox",
													checked: He.shadows,
													onChange: (e) => d.setSetting("light", "shadows", e.target.checked, "Shadows")
												}),
												" ",
												"Shadows"
											]
										}),
										/* @__PURE__ */ W("label", {
											className: "gs-m3d__colour",
											children: [
												/* @__PURE__ */ U("input", {
													type: "color",
													value: He.color,
													onChange: (e) => d.setSetting("light", "color", e.target.value, "Light colour")
												}),
												" ",
												"Light colour"
											]
										}),
										/* @__PURE__ */ U(a, { id: "m3dLight" })
									] }),
									/* @__PURE__ */ W("section", { children: [
										/* @__PURE__ */ U("h4", { children: "Floor and background" }),
										/* @__PURE__ */ W("label", {
											className: "gs-m3d__check",
											children: [
												/* @__PURE__ */ U("input", {
													type: "checkbox",
													checked: p.ground.on,
													onChange: (e) => d.setSetting("ground", "on", e.target.checked, "Floor")
												}),
												" ",
												"Floor shadow"
											]
										}),
										p.ground.on && /* @__PURE__ */ U(Th, {
											label: "Shadow strength",
											value: p.ground.shadow,
											min: 0,
											max: 1,
											step: .01,
											format: (e) => `${Math.round(e * 100)}%`,
											onBegin: de("Floor shadow"),
											onChange: (e) => d.setSetting("ground", "shadow", e),
											onEnd: fe
										}),
										/* @__PURE__ */ W("label", {
											className: "gs-m3d__check",
											children: [
												/* @__PURE__ */ U("input", {
													type: "checkbox",
													checked: p.background.transparent,
													onChange: (e) => d.setSetting("background", "transparent", e.target.checked, "Background")
												}),
												" ",
												"See-through background"
											]
										}),
										!p.background.transparent && /* @__PURE__ */ W("label", {
											className: "gs-m3d__colour",
											children: [
												/* @__PURE__ */ U("input", {
													type: "color",
													value: p.background.color,
													onChange: (e) => d.setSetting("background", "color", e.target.value, "Background colour")
												}),
												" ",
												"Background colour"
											]
										}),
										/* @__PURE__ */ U(a, { id: "m3dFloor" })
									] }),
									/* @__PURE__ */ U(zh, {
										editor: d,
										doc: p,
										aspect: L
									}),
									/* @__PURE__ */ W("section", { children: [
										/* @__PURE__ */ U("h4", { children: "Camera" }),
										/* @__PURE__ */ U(Dh, {
											label: "Projection",
											value: p.camera.projection,
											options: ["perspective", "orthographic"],
											labels: {
												perspective: "Perspective",
												orthographic: "Flat (no perspective)"
											},
											onChange: (e) => d.setSetting("camera", "projection", e, "Projection")
										}),
										p.camera.projection === "perspective" && /* @__PURE__ */ U(Th, {
											label: "Lens",
											value: p.camera.fov,
											min: 10,
											max: 90,
											step: 1,
											format: (e) => `${e}°`,
											onBegin: de("Lens"),
											onChange: (e) => d.setSetting("camera", "fov", e),
											onEnd: fe
										}),
										/* @__PURE__ */ U(a, { id: "m3dView" }),
										/* @__PURE__ */ U(a, { id: "m3dGrid" })
									] }),
									/* @__PURE__ */ W("section", { children: [
										/* @__PURE__ */ U("h4", { children: "Finish" }),
										n && /* @__PURE__ */ U(a, { id: "m3dUse" }),
										/* @__PURE__ */ U(a, { id: "m3dSave" }),
										/* @__PURE__ */ U(a, { id: "m3dSvg" }),
										/* @__PURE__ */ U(a, { id: "m3dVideo" })
									] })
								]
							}),
							/* @__PURE__ */ U("footer", {
								className: "gs-m3d__foot",
								children: /* @__PURE__ */ U(r, {})
							})
						]
					})
				]
			}),
			A === "outline" && /* @__PURE__ */ U(th, {
				onPick: ge,
				onClose: () => te(null)
			}),
			A === "text" && /* @__PURE__ */ U(ih, {
				onDone: be,
				onClose: () => te(null)
			}),
			A === "edit-text" && j?.text && /* @__PURE__ */ U(ih, {
				initial: j.text,
				onDone: xe,
				onClose: () => te(null)
			}),
			A === "edit-outline" && j?.pen && /* @__PURE__ */ U(th, {
				initial: j.pen,
				onPick: _e,
				onClose: () => te(null)
			}),
			A === "ad" && /* @__PURE__ */ U(ph, {
				start: l,
				onMake: N,
				onClose: () => te(null)
			}),
			A === "video" && /* @__PURE__ */ U(lh, {
				initialKind: cn(p) ? "still" : "turntable",
				initialSeconds: le,
				moving: cn(p),
				onMake: Be,
				onClose: () => te(null)
			})
		]
	});
}
function ig({ open: e }) {
	return /* @__PURE__ */ W("svg", {
		width: "12",
		height: "12",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: 2.2,
		"aria-hidden": "true",
		children: [/* @__PURE__ */ U("rect", {
			x: "5",
			y: "11",
			width: "14",
			height: "10",
			rx: "2"
		}), /* @__PURE__ */ U("path", { d: e ? "M8 11V7a4 4 0 0 1 7.5-2" : "M8 11V7a4 4 0 0 1 8 0v4" })]
	});
}
async function ag(e) {
	let t = await createImageBitmap(e), n = Math.min(1, 1600 / Math.max(t.width, t.height)), [r, i] = [Math.max(1, Math.round(t.width * n)), Math.max(1, Math.round(t.height * n))], a = document.createElement("canvas");
	a.width = r, a.height = i;
	let o = a.getContext("2d");
	o.drawImage(t, 0, 0, r, i), t.close();
	let s = o.getImageData(0, 0, r, i).data, c = 0;
	for (let e = 3; e < s.length; e += 16) s[e] < 128 && c++;
	let l = await new Promise((e, t) => a.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be read.")), "image/png"));
	return {
		bytes: new Uint8Array(await l.arrayBuffer()),
		width: r,
		height: i,
		seeThrough: c / (s.length / 16)
	};
}
//#endregion
export { rg as ModelMode, io as i, no as n, ro as r, ao as t };

//# sourceMappingURL=ModelMode-vwpxX65d.js.map