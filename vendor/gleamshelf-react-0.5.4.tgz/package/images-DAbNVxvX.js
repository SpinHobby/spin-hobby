import { i as e } from "./rolldown-runtime-DArdT4gl.js";
import { _ as t, h as n, v as r } from "./src-L5EyMOAw.js";
import { useCallback as i, useEffect as a, useMemo as o, useState as s } from "react";
var c = {
	id: "birefnet-general-fp16",
	name: "BiRefNet (whole box, larger)",
	task: "cutout",
	summary: "Cuts a whole box or product out of any background. Four times the size of the compact model, and it was never fooled by artwork on a cover (the compact one took a girl on the cover for the object on one box in ten).",
	recommended: !1,
	license: {
		name: "MIT",
		commercialUse: "allowed",
		url: "https://huggingface.co/ZhengPeng7/BiRefNet"
	},
	sizeMb: 489.7,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/ZhengPeng7/BiRefNet",
		download: "https://huggingface.co/onnx-community/BiRefNet-ONNX/resolve/main/onnx/model_fp16.onnx"
	},
	file: {
		name: "birefnet-general-fp16.onnx",
		bytes: 489666272
	},
	input: {
		size: 1024,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "logits-mask"
}, l = {
	id: "birefnet-lite-fp16",
	name: "BiRefNet lite (compact)",
	task: "cutout",
	summary: "Separates the product from any background, with clean edges. The compact version: half the download, nearly the same quality.",
	recommended: !0,
	license: {
		name: "MIT",
		commercialUse: "allowed",
		url: "https://huggingface.co/ZhengPeng7/BiRefNet_lite"
	},
	sizeMb: 114.5,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/ZhengPeng7/BiRefNet_lite",
		download: "https://huggingface.co/onnx-community/BiRefNet_lite-ONNX/resolve/main/onnx/model_fp16.onnx"
	},
	file: {
		name: "birefnet-lite-fp16.onnx",
		bytes: 114538221
	},
	input: {
		size: 1024,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "logits-mask"
}, u = {
	id: "birefnet-lite",
	name: "BiRefNet lite (full precision)",
	task: "cutout",
	summary: "The same cut-out model at full precision. A bigger download for slightly finer edges.",
	recommended: !1,
	license: {
		name: "MIT",
		commercialUse: "allowed",
		url: "https://huggingface.co/ZhengPeng7/BiRefNet_lite"
	},
	sizeMb: 224,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/ZhengPeng7/BiRefNet_lite",
		download: "https://huggingface.co/onnx-community/BiRefNet_lite-ONNX/resolve/main/onnx/model.onnx"
	},
	file: {
		name: "birefnet-lite.onnx",
		bytes: 224005088
	},
	input: {
		size: 1024,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "logits-mask"
}, d = {
	id: "lama-fp32",
	name: "LaMa fill (removes marks and lettering)",
	task: "inpaint",
	summary: "Paints over what you mask (printed words, stickers, marks) with realistic detail from around it. Much cleaner than the free fill on hair and fabric. Takes a few seconds per patch on a laptop.",
	recommended: !0,
	license: {
		name: "Apache-2.0",
		commercialUse: "allowed",
		url: "https://huggingface.co/Carve/LaMa-ONNX"
	},
	sizeMb: 208,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/Carve/LaMa-ONNX",
		download: "https://huggingface.co/Carve/LaMa-ONNX/resolve/main/lama_fp32.onnx"
	},
	file: {
		name: "lama-fp32.onnx",
		bytes: 208044816
	},
	input: {
		size: 512,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image"
}, f = {
	id: "ppocr-det-v4",
	name: "Text finder (PaddleOCR v4, compact)",
	task: "text-detect",
	summary: "Finds where printed text is on a picture (any colour, many languages including Japanese), so it can be filled in. Tiny and quick.",
	recommended: !0,
	license: {
		name: "Apache-2.0",
		commercialUse: "allowed",
		url: "https://huggingface.co/SWHL/RapidOCR"
	},
	sizeMb: 4.7,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/SWHL/RapidOCR",
		download: "https://huggingface.co/SWHL/RapidOCR/resolve/main/PP-OCRv4/ch_PP-OCRv4_det_infer.onnx"
	},
	file: {
		name: "ppocr-det-v4.onnx",
		bytes: 4745517
	},
	input: {
		size: 960,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "probability-map"
}, p = {
	id: "ppocr-rec-v4",
	name: "Text reader (PaddleOCR v4, compact)",
	task: "text-read",
	summary: "Reads what printed text says (numbers, prices, English, Chinese, Japanese kana), so a shop's price sticker can be told apart from the box's own printing. Used together with the text finder.",
	recommended: !0,
	license: {
		name: "Apache-2.0",
		commercialUse: "allowed",
		url: "https://huggingface.co/SWHL/RapidOCR"
	},
	sizeMb: 10.9,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/SWHL/RapidOCR",
		download: "https://huggingface.co/SWHL/RapidOCR/resolve/main/PP-OCRv4/ch_PP-OCRv4_rec_infer.onnx"
	},
	file: {
		name: "ppocr-rec-v4.onnx",
		bytes: 10857958
	},
	input: {
		size: 48,
		mean: [
			.5,
			.5,
			.5
		],
		std: [
			.5,
			.5,
			.5
		]
	},
	output: "probability-map"
}, m = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realesr-general-x4",
	name: "Sharpen & enlarge (fast, small)",
	recommended: !1,
	summary: "Makes a picture 4 times larger and clearly sharper, adding believable fine detail. The small, quick one (about a quarter of a second for a face-sized area). Best first choice for photos of figures and boxes. In the benchmark it over-sharpened (1.13 times the original's edge detail) and lost some structure, so the x4plus model is the default.",
	sizeMb: 4.95,
	license: {
		name: "BSD-3-Clause (Real-ESRGAN)",
		commercialUse: "check",
		url: "https://github.com/xinntao/Real-ESRGAN/blob/master/LICENSE"
	},
	links: {
		modelCard: "https://huggingface.co/baker76/upscale-models",
		download: "https://huggingface.co/baker76/upscale-models/resolve/main/RealESR_General_x4.onnx"
	},
	file: {
		name: "realesr-general-x4.onnx",
		bytes: 4954907
	}
}, h = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realesrgan-anime-x4",
	name: "Sharpen & enlarge (illustrations)",
	recommended: !1,
	summary: "Tuned for drawn art: very clean lines and flat colour, but it smooths skin and plastic texture, so it suits flat box illustrations more than photos of figures.",
	sizeMb: 18.7,
	license: {
		name: "BSD-3-Clause (Real-ESRGAN)",
		commercialUse: "check",
		url: "https://github.com/xinntao/Real-ESRGAN/blob/master/LICENSE"
	},
	links: {
		modelCard: "https://huggingface.co/baker76/upscale-models",
		download: "https://huggingface.co/baker76/upscale-models/resolve/main/RealESRGAN_anime_x4.onnx"
	},
	file: {
		name: "realesrgan-anime-x4.onnx",
		bytes: 18688425
	}
}, g = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realesrgan-x4plus",
	name: "Sharpen & enlarge (best photo quality)",
	recommended: !1,
	summary: "Sharpens and enlarges 4x with the larger photo model. On a benchmark (half-size, compressed crops restored and compared with the originals) it was the most faithful and best balanced of the Real-ESRGAN models: highest SSIM and sharpness closest to the original. Slower (a few seconds for a face-sized area).",
	sizeMb: 69.9,
	license: {
		name: "BSD-3-Clause (Real-ESRGAN)",
		commercialUse: "check",
		url: "https://github.com/xinntao/Real-ESRGAN/blob/master/LICENSE"
	},
	links: {
		modelCard: "https://huggingface.co/baker76/upscale-models",
		download: "https://huggingface.co/baker76/upscale-models/resolve/main/RealESRGAN_x4plus.onnx"
	},
	file: {
		name: "realesrgan-x4plus.onnx",
		bytes: 69879921
	}
}, _ = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realplksr-x4",
	name: "Photo restore 4x (RealPLKSR, small and fast)",
	recommended: !0,
	summary: "A small 4x restoration model from darktable (MIT), trained for photographs. Best of every enlarging method on ten real product photos (bench/enlarge): sharper and truer than Real-ESRGAN, and it keeps printed text readable.",
	sizeMb: 29.7,
	license: {
		name: "MIT (darktable RealPLKSR)",
		commercialUse: "yes",
		url: "https://huggingface.co/darktable-org/upscale-realplksr-onnx"
	},
	links: {
		modelCard: "https://huggingface.co/darktable-org/upscale-realplksr-onnx",
		download: "https://huggingface.co/darktable-org/upscale-realplksr-onnx/resolve/main/onnx/model_x4.onnx"
	},
	file: {
		name: "realplksr-x4.onnx",
		bytes: 29711010
	}
}, v = {
	id: "sdxl-inpaint",
	name: "Redraw (Stable Diffusion XL inpainting)",
	task: "redraw",
	summary: "Redraws part of a picture with a believable continuation: a missing antenna, an edge that was cut off. Runs on this computer's GPU (about 30 seconds). It invents what it draws, so use it where the picture really is missing a part.",
	recommended: !0,
	license: {
		name: "OpenRAIL++-M (commercial use of the pictures is allowed; see the licence for its use restrictions)",
		commercialUse: "check",
		url: "https://huggingface.co/diffusers/stable-diffusion-xl-1.0-inpainting-0.1"
	},
	sizeMb: 6940,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/diffusers/stable-diffusion-xl-1.0-inpainting-0.1",
		download: "https://huggingface.co/diffusers/stable-diffusion-xl-1.0-inpainting-0.1"
	},
	file: {
		name: "sdxl-inpaint/unet/diffusion_pytorch_model.fp16.safetensors",
		bytes: 5135178560
	},
	input: {
		size: 1024,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image"
}, y = {
	id: "sdxl-tile",
	name: "Sharpen with detail (SDXL tile ControlNet)",
	task: "enhance",
	summary: "Makes a picture crisper and cleaner while every shape stays where it was: hair strands, fabric folds, edges. The original colours are kept. Runs on this computer's GPU (about half a minute to a minute for a 1024 pixel picture once the models are loaded). Works together with the redraw model.",
	recommended: !0,
	license: {
		name: "Apache-2.0 (used with SDXL, OpenRAIL++-M)",
		commercialUse: "allowed",
		url: "https://huggingface.co/xinsir/controlnet-tile-sdxl-1.0"
	},
	sizeMb: 2502,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/xinsir/controlnet-tile-sdxl-1.0",
		download: "https://huggingface.co/xinsir/controlnet-tile-sdxl-1.0"
	},
	file: {
		name: "sdxl-tile/diffusion_pytorch_model.safetensors",
		bytes: 2502139104
	},
	input: {
		size: 1024,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image"
}, b = (e) => {
	let t = e;
	return !!t && typeof t.id == "string" && /^[a-z0-9][a-z0-9-]*$/.test(t.id) && typeof t.name == "string" && (t.task === "cutout" || t.task === "inpaint" || t.task === "text-detect" || t.task === "text-read" || t.task === "upscale" || t.task === "redraw" || t.task === "enhance") && typeof t.file?.name == "string" && typeof t.links?.download == "string" && typeof t.input?.size == "number";
};
function x(e) {
	return [...e].filter(b).sort((e, t) => Number(t.recommended) - Number(e.recommended) || e.name.localeCompare(t.name));
}
function S(e) {
	return {
		MODELS: e,
		findModel: (t) => e.find((e) => e.id === t),
		modelsFor: (t) => e.filter((e) => e.task === t)
	};
}
var { MODELS: C, findModel: w, modelsFor: T } = S(x(Object.values(/* @__PURE__ */ Object.assign({
	"../registry/birefnet-general-fp16.json": c,
	"../registry/birefnet-lite-fp16.json": l,
	"../registry/birefnet-lite.json": u,
	"../registry/lama-fp32.json": d,
	"../registry/ppocr-det-v4.json": f,
	"../registry/ppocr-rec-v4.json": p,
	"../registry/realesr-general-x4.json": m,
	"../registry/realesrgan-anime-x4.json": h,
	"../registry/realesrgan-x4plus.json": g,
	"../registry/realplksr-x4.json": _,
	"../registry/sdxl-inpaint.json": v,
	"../registry/sdxl-tile.json": y
})))), E = {
	strength: .5,
	control: .6,
	guidance: 6,
	keepColour: !1,
	seed: 7,
	prompt: "professional studio product photograph of a collectible, clean even soft lighting, glossy finish, crisp detail, true to the original colours, e-commerce pack shot",
	negativePrompt: "blurry, low quality, noise, artifacts, deformed, extra parts, changed design, text, watermark, logo"
}, D = class extends Error {
	status;
	constructor(e, t) {
		super(t), this.status = e;
	}
}, O = "http://127.0.0.1:47321", k = {
	start: "npm run local:start",
	token: "npm run local:token",
	models: "npm run models",
	redrawSetup: "npm run redraw:setup",
	install: (e) => e && e !== "birefnet-lite-fp16" ? `npm run models:install -- ${e}` : "npm run models:install"
}, A = class {
	options;
	base;
	doFetch;
	constructor(e = {}) {
		this.options = e, this.base = (e.url ?? "http://127.0.0.1:47321").replace(/\/$/, "");
		let t = e.fetch;
		this.doFetch = (e, n) => (t ?? fetch)(e, n);
	}
	headers(e = {}) {
		return this.options.token ? {
			Authorization: `Bearer ${this.options.token}`,
			...e
		} : e;
	}
	async probe() {
		if (await this.health()) return "ok";
		try {
			return await this.doFetch(`${this.base}/health`, {
				mode: "no-cors",
				signal: AbortSignal.timeout(2500)
			}), "blocked";
		} catch {
			return "offline";
		}
	}
	async health() {
		try {
			let e = await this.doFetch(`${this.base}/health`, { signal: AbortSignal.timeout(2500) });
			if (!e.ok) return null;
			let t = await e.json();
			return t.app === "gleamshelf-local" ? t : null;
		} catch {
			return null;
		}
	}
	async inpaint(e, t, n) {
		let r = await this.doFetch(`${this.base}/inpaint?model=${encodeURIComponent(t)}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "image/png" }),
			body: e,
			signal: n
		});
		if (!r.ok) throw new D(r.status, await j(r));
		return new Blob([await r.arrayBuffer()], { type: "image/png" });
	}
	async upscale(e, t, n) {
		let r = await this.doFetch(`${this.base}/upscale?model=${encodeURIComponent(t)}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!r.ok) throw new D(r.status, await j(r));
		return new Blob([await r.arrayBuffer()], { type: "image/png" });
	}
	async redraw(e, t, n) {
		let r = new URLSearchParams({ prompt: t.prompt });
		t.stacked && r.set("stacked", "true"), t.box && r.set("box", t.box.join(",")), t.negative && r.set("negative", t.negative);
		for (let e of [
			"strength",
			"steps",
			"guidance",
			"candidates",
			"seed"
		]) t[e] !== void 0 && r.set(e, String(t[e]));
		let i = await this.doFetch(`${this.base}/redraw?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "image/png" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new D(i.status, await j(i));
		return new Blob([await i.arrayBuffer()], { type: "image/png" });
	}
	async enhance(e, t = {}, n) {
		let r = new URLSearchParams();
		t.prompt && r.set("prompt", t.prompt), t.negativePrompt && r.set("negativePrompt", t.negativePrompt);
		for (let e of [
			"strength",
			"seed",
			"control",
			"guidance"
		]) t[e] !== void 0 && r.set(e, String(t[e]));
		t.keepColour === !1 && r.set("keepColour", "false");
		let i = await this.doFetch(`${this.base}/enhance?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "image/png" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new D(i.status, await j(i));
		return new Blob([await i.arrayBuffer()], { type: "image/png" });
	}
	gloss(e, t) {
		return this.enhance(e, E, t);
	}
	async readText(e, t) {
		let n = await this.doFetch(`${this.base}/read-text`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: t
		});
		if (!n.ok) throw new D(n.status, await j(n));
		return (await n.json()).boxes;
	}
	async detectText(e, t, n) {
		let r = await this.doFetch(`${this.base}/detect-text?model=${encodeURIComponent(t)}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!r.ok) throw new D(r.status, await j(r));
		return (await r.json()).boxes;
	}
	async startProcess(e, t = {}, n) {
		let r = new URLSearchParams();
		t.mode && r.set("mode", t.mode), t.vivid !== void 0 && r.set("vivid", String(t.vivid));
		for (let e of [
			"find",
			"listing",
			"enlarge",
			"stickers",
			"lettering",
			"thinParts",
			"colour",
			"look",
			"gloss",
			"review"
		]) t[e] !== void 0 && r.set(e, t[e] ? "1" : "0");
		let i = await this.doFetch(`${this.base}/process?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new D(i.status, await j(i));
		return (await i.json()).id;
	}
	async processStatus(e, t) {
		let n = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}`, {
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new D(n.status, await j(n));
		return await n.json();
	}
	async foundPicture(e, t, n) {
		let r = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/found/${t}.jpg`, {
			headers: this.headers(),
			signal: n
		});
		if (!r.ok) throw new D(r.status, await j(r));
		return new Blob([await r.arrayBuffer()], { type: "image/jpeg" });
	}
	async chooseReferences(e, t, n) {
		let r = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/choose`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify({ use: t }),
			signal: n
		});
		if (!r.ok) throw new D(r.status, await j(r));
	}
	async cancelProcess(e, t) {
		let n = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/cancel`, {
			method: "POST",
			headers: this.headers(),
			signal: t
		});
		if (!n.ok && n.status !== 404) throw new D(n.status, await j(n));
	}
	async processPicture(e, t = "cutout", n) {
		let r = t === "cutout" ? "cutout.png" : t === "changes" ? "changes.png" : "studio.jpg", i = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/${r}`, {
			headers: this.headers(),
			signal: n
		});
		if (!i.ok) throw new D(i.status, await j(i));
		return new Blob([await i.arrayBuffer()], { type: t === "studio" ? "image/jpeg" : "image/png" });
	}
	async recentRuns(e) {
		let t = await this.doFetch(`${this.base}/process/recent`, {
			headers: this.headers(),
			signal: e
		});
		if (!t.ok) throw new D(t.status, await j(t));
		return (await t.json()).runs;
	}
	async shopStatus(e) {
		let t = await this.doFetch(`${this.base}/shop`, {
			headers: this.headers(),
			signal: e
		});
		if (!t.ok) throw new D(t.status, await j(t));
		return await t.json();
	}
	async shopConnect(e, t, n) {
		let r = await this.doFetch(`${this.base}/shop/connect`, {
			method: "POST",
			headers: {
				...this.headers(),
				"Content-Type": "application/json"
			},
			body: JSON.stringify({
				address: e,
				code: t
			}),
			signal: n
		});
		if (!r.ok) throw new D(r.status, await j(r));
		return await r.json();
	}
	async sendRun(e, t) {
		let n = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/send`, {
			method: "POST",
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new D(n.status, await j(n));
		return await n.json();
	}
	async phoneStart(e) {
		let t = await this.doFetch(`${this.base}/phone/start`, {
			method: "POST",
			headers: this.headers(),
			signal: e
		});
		if (!t.ok) throw new D(t.status, await j(t));
		return await t.json();
	}
	async phonePhotos(e) {
		let t = await this.doFetch(`${this.base}/phone/photos`, {
			headers: this.headers(),
			signal: e
		});
		if (!t.ok) throw new D(t.status, await j(t));
		return (await t.json()).photos;
	}
	async phonePhoto(e, t) {
		let n = await this.doFetch(`${this.base}/phone/photos/${encodeURIComponent(e)}`, {
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new D(n.status, await j(n));
		return new Blob([await n.arrayBuffer()], { type: n.headers.get("Content-Type") ?? "image/jpeg" });
	}
	async models() {
		let e = await this.doFetch(`${this.base}/models`, { headers: this.headers() });
		if (!e.ok) throw new D(e.status, await j(e));
		return (await e.json()).models;
	}
	async cutout(e, t, n, r = {}) {
		let i = await this.doFetch(`${this.base}/cutout?model=${encodeURIComponent(t)}${r.thinParts ? "&refine=thin" : ""}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new D(i.status, await j(i));
		let a = Number(i.headers.get("X-Mask-Width")), o = Number(i.headers.get("X-Mask-Height")), s = new Uint8Array(await i.arrayBuffer());
		if (!(a > 0 && o > 0) || s.length !== a * o) throw new D(502, "The companion app sent a mask in a format this editor does not understand.");
		return {
			alpha: s,
			width: a,
			height: o,
			...i.headers.get("X-Mask-Parts") === "kept" ? { partsKept: !0 } : {}
		};
	}
};
async function j(e) {
	let t = await e.json().catch(() => null);
	return e.status === 401 ? "The companion app did not accept the pairing token. Copy it again from the app and paste it in." : t?.error ?? `The companion app answered ${e.status}.`;
}
//#endregion
//#region src/useLocalApp.ts
var M = "gleamshelf:local-app";
function N() {
	try {
		let e = /(?:^#|&)pair=([A-Za-z0-9_-]{16,128})/.exec(window.location.hash);
		return e ? (window.history.replaceState(null, "", window.location.pathname + window.location.search), e[1]) : null;
	} catch {
		return null;
	}
}
function P() {
	let e = N();
	if (e) {
		let t = O;
		try {
			let e = JSON.parse(localStorage.getItem(M) ?? "{}");
			typeof e.url == "string" && (t = e.url);
		} catch {}
		return F({
			url: t,
			token: e
		}), {
			url: t,
			token: e
		};
	}
	try {
		let e = JSON.parse(localStorage.getItem(M) ?? "{}");
		return {
			url: typeof e.url == "string" ? e.url : O,
			token: typeof e.token == "string" ? e.token : ""
		};
	} catch {
		return {
			url: O,
			token: ""
		};
	}
}
function F(e) {
	try {
		localStorage.setItem(M, JSON.stringify(e));
	} catch {}
}
function I(e) {
	let [t, n] = s(() => ({
		...P(),
		...e?.url ? { url: e.url } : {},
		...e?.token ? { token: e.token } : {}
	})), [r, c] = s("checking"), [l, u] = s(null), [d, f] = s(null), [p, m] = s([]), h = o(() => new A({
		url: t.url,
		token: t.token
	}), [t]), g = i(async () => {
		f(null);
		let e = await h.probe();
		if (e === "ok" && m((await h.health())?.features ?? []), e !== "ok") c(e === "blocked" ? "blocked" : "offline"), u(null);
		else if (!t.token) c("needs-token"), u(null);
		else try {
			u(await h.models()), c("ready");
		} catch (e) {
			u(null), f(e instanceof Error ? e.message : "The companion app did not answer."), e instanceof D && e.status === 401 ? (n((e) => ({
				...e,
				token: ""
			})), c("needs-token")) : c("offline");
		}
	}, [h, t.token]);
	return a(() => {
		g();
	}, [g]), a(() => {
		if (r !== "offline" && r !== "blocked") return;
		let e = setInterval(() => void g(), 3e3);
		return () => clearInterval(e);
	}, [r, g]), {
		state: r,
		saved: t,
		client: h,
		models: l,
		installed: (e) => l?.filter((t) => t.task === e && t.installed) ?? [],
		problem: d,
		setProblem: f,
		check: g,
		connect: (e) => {
			let r = {
				...t,
				token: e.trim()
			};
			F(r), n(r);
		},
		canProcess: p.includes("process"),
		canPhone: p.includes("phone"),
		canShop: p.includes("shop")
	};
}
//#endregion
//#region ../heic/src/index.ts
var L = (e, t, n) => String.fromCharCode(...e.subarray(t, n)), R = /* @__PURE__ */ new Set([
	"heic",
	"heix",
	"hevc",
	"hevx",
	"heim",
	"heis"
]);
function z(e) {
	if (e.length < 16 || L(e, 4, 8) !== "ftyp") return !1;
	let t = Math.min(e.length, new DataView(e.buffer, e.byteOffset, e.byteLength).getUint32(0), 256), n = [L(e, 8, 12)];
	for (let r = 16; r + 4 <= t; r += 4) n.push(L(e, r, r + 4));
	return n.includes("avif") || n.includes("avis") ? !1 : n.some((e) => R.has(e));
}
async function B(t) {
	let { default: n } = await import("./heic-decode-BYdIj7Hj.js").then((t) => /* @__PURE__ */ e(t.default, 1)), { width: r, height: i, data: a } = await n({ buffer: t });
	return {
		width: r,
		height: i,
		data: a instanceof Uint8ClampedArray ? a : new Uint8ClampedArray(a.buffer, a.byteOffset, a.byteLength)
	};
}
//#endregion
//#region src/images.ts
var V;
function H() {
	if (V === void 0) {
		let e = document.createElement("canvas").getContext("webgl2");
		V = e ? e.getParameter(e.MAX_TEXTURE_SIZE) : 4096, e?.getExtension("WEBGL_lose_context")?.loseContext();
	}
	return V;
}
var U = 2048;
async function W(e) {
	let t = URL.createObjectURL(e);
	try {
		let n = new Image();
		n.src = t, await n.decode();
		let r = n.naturalWidth || U, i = n.naturalHeight || U;
		if (e.type === "image/svg+xml") {
			let e = U / Math.max(r, i);
			r = Math.round(r * e), i = Math.round(i * e);
		}
		let a = document.createElement("canvas");
		return a.width = r, a.height = i, a.getContext("2d").drawImage(n, 0, 0, r, i), await createImageBitmap(a);
	} catch {
		throw Error("This file couldn't be opened as an image. Try a JPEG, PNG, WebP or HEIC.");
	} finally {
		URL.revokeObjectURL(t);
	}
}
async function G(e) {
	if (!z(new Uint8Array(await e.slice(0, 512).arrayBuffer()))) return null;
	let { width: t, height: n, data: r } = await B(new Uint8Array(await e.arrayBuffer()));
	return createImageBitmap(new ImageData(new Uint8ClampedArray(r), t, n));
}
async function K(e, t = H()) {
	let n;
	try {
		n = await createImageBitmap(e, { imageOrientation: "from-image" });
	} catch {
		n = await G(e).catch(() => null) ?? await W(e);
	}
	let r = Math.max(n.width, n.height);
	if (r <= t) return n;
	let i = t / r, a = await createImageBitmap(n, {
		resizeWidth: Math.floor(n.width * i),
		resizeHeight: Math.floor(n.height * i),
		resizeQuality: "high"
	});
	return n.close(), a;
}
async function q(e) {
	let t = Math.min(1, 512 / Math.max(e.width, e.height)), n = Math.max(1, Math.round(e.width * t)), r = Math.max(1, Math.round(e.height * t)), i = document.createElement("canvas");
	i.width = n, i.height = r;
	let a = i.getContext("2d", { willReadFrequently: !0 });
	a.drawImage(e, 0, 0, n, r);
	let o = a.getImageData(0, 0, n, r).data, s = n, c = -1, l = r, u = -1;
	for (let e = 0; e < r; e++) for (let t = 0; t < n; t++) o[(e * n + t) * 4 + 3] > 16 && (t < s && (s = t), t > c && (c = t), e < l && (l = e), e > u && (u = e));
	if (c < 0 || s === 0 && l === 0 && c === n - 1 && u === r - 1) return e;
	let d = Math.max(0, Math.floor((s - 1) / t)), f = Math.max(0, Math.floor((l - 1) / t)), p = Math.min(e.width, Math.ceil((c + 2) / t)), m = Math.min(e.height, Math.ceil((u + 2) / t));
	return createImageBitmap(e, d, f, p - d, m - f);
}
async function J(e, t) {
	let n;
	try {
		n = await fetch(e, {
			mode: "cors",
			signal: t
		});
	} catch (e) {
		throw t?.aborted ? e : Error("The photo couldn't be downloaded. Its server may not allow other sites to read it (CORS).");
	}
	if (!n.ok) throw Error(`The photo couldn't be downloaded (${n.status}).`);
	return n.blob();
}
async function Y(e) {
	let t = document.createElement("canvas");
	t.width = e.width, t.height = e.height;
	let n = new Uint8ClampedArray(e.width * e.height * 4);
	for (let t = 0; t < e.alpha.length; t++) n.set([
		e.alpha[t],
		e.alpha[t],
		e.alpha[t],
		255
	], t * 4);
	return t.getContext("2d").putImageData(new ImageData(n, e.width, e.height), 0, 0), new Promise((e, n) => t.toBlob((t) => t ? e(t) : n(/* @__PURE__ */ Error("The mask could not be saved.")), "image/png"));
}
async function X(e) {
	let t = await createImageBitmap(e, { colorSpaceConversion: "none" }), n = document.createElement("canvas");
	n.width = t.width, n.height = t.height;
	let r = n.getContext("2d", { willReadFrequently: !0 });
	r.drawImage(t, 0, 0);
	let { data: i } = r.getImageData(0, 0, t.width, t.height), a = new Uint8Array(t.width * t.height);
	for (let e = 0; e < a.length; e++) a[e] = i[e * 4];
	let o = {
		alpha: a,
		width: t.width,
		height: t.height
	};
	return t.close(), o;
}
async function Z(e, t = 1536) {
	let n = Math.min(1, t / Math.max(e.width, e.height)), r = document.createElement("canvas");
	return r.width = Math.max(1, Math.round(e.width * n)), r.height = Math.max(1, Math.round(e.height * n)), r.getContext("2d").drawImage(e, 0, 0, r.width, r.height), new Promise((e, t) => r.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The photo could not be prepared.")), "image/jpeg", .92));
}
async function Q(e, i, a = 1536) {
	let o = {
		...i,
		recipe: {
			...i.recipe,
			ops: {
				...i.recipe.ops,
				canvas: {
					...i.recipe.ops.canvas,
					square: !1,
					margin: 0
				}
			}
		}
	}, { width: s, height: c } = t(o, a), l = n(r(o));
	if (!l) throw Error("This crop cannot be used.");
	let u = document.createElement("canvas");
	u.width = s, u.height = c;
	let d = u.getContext("2d");
	return d.fillStyle = "#ffffff", d.fillRect(0, 0, s, c), d.setTransform(s * l.a / e.width, c * l.b / e.width, s * l.c / e.height, c * l.d / e.height, s * l.e, c * l.f), d.drawImage(e, 0, 0), new Promise((e, t) => u.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The crop could not be prepared.")), "image/jpeg", .92));
}
//#endregion
export { Y as a, q as c, w as d, T as f, H as i, I as l, K as n, Q as o, J as r, Z as s, X as t, k as u };

//# sourceMappingURL=images-DAbNVxvX.js.map