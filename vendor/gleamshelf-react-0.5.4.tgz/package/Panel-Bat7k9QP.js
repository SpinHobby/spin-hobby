import { A as e, D as t, E as n, O as r, T as i, k as a, n as o, t as s, u as c, w as l } from "./src-L5EyMOAw.js";
import { useEffect as u, useRef as d, useState as f, useSyncExternalStore as p } from "react";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
//#region ../shaders/src/parse.ts
var _ = class extends Error {
	constructor(e, t, n) {
		super(`${e}${n ? `:${n}` : ""}: ${t}`);
	}
}, v = [
	"uInput",
	"uResolution",
	"uTime",
	"uFlipY"
], y = /^\s*uniform\s+(\w+)\s+(\w+)\s*;\s*(?:\/\/\s*@param\b(.*))?$/, b = /^#[0-9a-fA-F]{6}$/, x = (e) => e.slice(1, 2).toLowerCase() + e.slice(2);
function S(e) {
	let t = /^\s*"([^"]*)"/.exec(e)?.[1], n = {};
	for (let [, t, r] of e.matchAll(/(\w+)=("[^"]*"|\S+)/g)) n[t] = r.replace(/^"|"$/g, "");
	return {
		label: t,
		values: n
	};
}
function C(e, t, n, r, i = !0) {
	let a = n[r];
	if (a === void 0) {
		if (i) throw new _(e, `this slider needs ${r}=… (for example min=0 max=1 step=0.01 default=0.5)`, t);
		return;
	}
	let o = Number(a);
	if (!Number.isFinite(o)) throw new _(e, `${r}=${a} is not a number`, t);
	return o;
}
function w(e, t, n, r, i) {
	if (!/^u[A-Z]\w*$/.test(r)) throw new _(e, `uniform "${r}" should start with u and a capital letter, like uAmount`, t);
	let { label: a = r.slice(1), values: o } = S(i), s;
	if (n === "float" || n === "int") {
		if (o.options !== void 0) {
			if (n !== "int") throw new _(e, "a list of options goes on an int uniform (the chosen position)", t);
			let r = o.options.split("|").map((e) => e.trim()).filter(Boolean);
			if (r.length < 2) throw new _(e, "options=… needs at least two choices separated by |", t);
			let i = o.default ?? r[0];
			if (!r.includes(i)) throw new _(e, `default=${i} is not one of the options`, t);
			s = {
				kind: "choice",
				label: a,
				options: r,
				default: i
			};
		} else {
			let r = C(e, t, o, "min"), i = C(e, t, o, "max"), c = C(e, t, o, "step", !1) ?? (n === "int" ? 1 : (i - r) / 100), l = C(e, t, o, "default");
			if (!(r < i)) throw new _(e, "min must be smaller than max", t);
			if (!(c > 0)) throw new _(e, "step must be above 0", t);
			if (l < r || l > i) throw new _(e, `default=${l} is outside min=${r} max=${i}`, t);
			if (n === "int" && !(Number.isInteger(r) && Number.isInteger(i) && Number.isInteger(l) && Number.isInteger(c))) throw new _(e, "an int slider needs whole numbers for min, max, step and default", t);
			s = {
				kind: "number",
				label: a,
				min: r,
				max: i,
				step: c,
				default: l,
				...o.unit ? { unit: o.unit } : {}
			};
		}
	} else if (n === "bool") {
		if (o.default !== "true" && o.default !== "false") throw new _(e, "a bool needs default=true or default=false", t);
		s = {
			kind: "boolean",
			label: a,
			default: o.default === "true"
		};
	} else if (n === "vec3") {
		if (!b.test(o.default ?? "")) throw new _(e, "a vec3 is a colour and needs default=#rrggbb", t);
		s = {
			kind: "color",
			label: a,
			default: o.default.toLowerCase()
		};
	} else throw new _(e, `uniforms of type ${n} are not supported (use float, int, bool or vec3)`, t);
	return {
		uniform: r,
		key: x(r),
		glslType: n,
		spec: s
	};
}
function T(e, t, n) {
	let r = `${e}.${t === "fragment" ? "frag" : "vert"}.glsl`, i = n.split(/\r?\n/), a = {}, o = [], s = /* @__PURE__ */ new Set();
	i.forEach((e, n) => {
		let i = n + 1, c = /^\s*\/\/\s*@(shader|description|scope|contract|animated)\b\s*(.*)$/.exec(e);
		if (c) {
			a[c[1]] = c[2].trim();
			return;
		}
		if (/^\s*#\s*version\b/.test(e) && (t !== "vertex" || n !== 0)) throw new _(r, "leave out #version: it is added for you", i);
		let l = y.exec(e);
		if (!l) {
			if (/^\s*uniform\b/.test(e)) throw new _(r, "write each uniform on its own line like: uniform float uAmount; // @param \"Amount\" min=0 max=1 default=0.5", i);
			return;
		}
		let [, u, d, f] = l;
		if (v.includes(d)) throw new _(r, `${d} is provided for you; remove this line`, i);
		if (f === void 0) throw new _(r, `uniform ${d} has no slider. Add // @param "Label" min=… max=… default=… (or remove the uniform)`, i);
		let p = w(r, i, u, d, f);
		if (s.has(p.key)) throw new _(r, `two uniforms would both be called "${p.key}"`, i);
		s.add(p.key), o.push(p);
	});
	let c = t === "fragment" ? "effect" : a.contract === "fullscreen" || /\bvoid\s+main\s*\(/.test(n) ? "fullscreen" : "displace";
	if (c === "effect" && !/\bvec4\s+effect\s*\(\s*vec2\s+\w+\s*,\s*vec4\s+\w+\s*\)/.test(n)) throw new _(r, "write a function vec4 effect(vec2 uv, vec4 color) that returns the new colour");
	if (c === "displace" && !/\bvec3\s+displace\s*\(\s*vec3\s+\w+\s*,\s*vec3\s+\w+\s*,\s*vec2\s+\w+\s*\)/.test(n)) throw new _(r, "write a function vec3 displace(vec3 position, vec3 normal, vec2 uv) that returns the new position");
	let l = a.scope === "product" ? "product" : "image";
	if (a.scope && a.scope !== "image" && a.scope !== "product") throw new _(r, "@scope must be image or product");
	return {
		id: e,
		kind: t,
		name: a.shader || e,
		description: a.description ?? "",
		contract: c,
		scope: l,
		animated: "animated" in a,
		params: o,
		source: n
	};
}
function E(e) {
	return Object.fromEntries(e.params.map((e) => [e.key, e.spec.default]));
}
function D(e, t) {
	return Object.fromEntries(e.params.map((e) => [e.key, a(e.spec, t?.[e.key]) ?? e.spec.default]));
}
function O(e, t) {
	let n = e.spec, r = a(n, t) ?? n.default;
	if (n.kind === "boolean") return +!!r;
	if (n.kind === "choice") return Math.max(0, n.options.indexOf(String(r)));
	if (n.kind === "color") {
		let e = String(r);
		return [
			parseInt(e.slice(1, 3), 16) / 255,
			parseInt(e.slice(3, 5), 16) / 255,
			parseInt(e.slice(5, 7), 16) / 255
		];
	}
	return Number(r);
}
//#endregion
//#region ../shaders/fragment/chromatic-aberration.frag.glsl?raw
var ee = "// @shader Colour fringe\n// @description Splits red and blue slightly towards the edges, like a vintage lens.\n// @scope image\n\nuniform float uAmount; // @param \"Amount\" min=0 max=12 step=0.1 default=2.5\n\nvec4 effect(vec2 uv, vec4 color) {\n  vec2 away = (uv - 0.5) * uAmount * 0.003;\n  vec4 r = sampleInput(uv + away);\n  vec4 b = sampleInput(uv - away);\n  return vec4(r.r, color.g, b.b, max(color.a, max(r.a, b.a)));\n}\n", te = "// @shader Contact shadow\n// @description The dark, soft shadow right where the product meets the floor, so it stands on the surface instead of floating. Works on the product, before the background is added.\n// @scope product\n\nuniform float uOpacity;  // @param \"Darkness\" min=0 max=1 step=0.01 default=0.45\nuniform float uSize;     // @param \"Depth\" min=2 max=80 step=0.5 default=14\nuniform float uSpread;   // @param \"Spread\" min=0 max=60 step=0.5 default=10\nuniform vec3 uColor;     // @param \"Colour\" default=#000000\n\nconst int STEPS = 24;\n\n// true when the product is beside this point (left or right, on its own row) closer than `d`: the point is next to a slanted side, not under the base\nbool besideProduct(vec2 uv, float d) {\n  float dx = d * uResolution.y / uResolution.x;\n  for (int k = 1; k <= 4; k++) {\n    float o = dx * float(k) / 4.0;\n    if (sampleInput(vec2(uv.x - o, uv.y)).a > 0.5 || sampleInput(vec2(uv.x + o, uv.y)).a > 0.5) return true;\n  }\n  return false;\n}\n\nvec4 effect(vec2 uv, vec4 color) {\n  if (color.a > 0.995) return color;\n  float reach = perMille(uSize * 3.0).y;\n  float shade = 0.0;\n  // a few columns either side soften the shadow's ends; in each, how close the product's base is above this pixel\n  for (int k = -3; k <= 3; k++) {\n    float x = uv.x + perMille(uSpread).x * float(k) / 3.0;\n    for (int i = 1; i <= STEPS; i++) {\n      float d = reach * float(i) / float(STEPS);\n      float y = uv.y - d;\n      if (y < 0.0) break;\n      if (sampleInput(vec2(x, y)).a > 0.5) {\n        if (besideProduct(vec2(x, uv.y), d)) break;\n        float near = exp(-d / perMille(uSize).y);\n        float side = 1.0 - abs(float(k)) / 4.0;\n        shade = max(shade, near * side);\n        break;\n      }\n    }\n  }\n  float s = shade * uOpacity;\n  float alpha = color.a + s * (1.0 - color.a);\n  vec3 rgb = alpha > 0.0 ? (color.rgb * color.a + uColor * s * (1.0 - color.a)) / alpha : vec3(0.0);\n  return vec4(rgb, alpha);\n}\n", ne = "// @shader Drop shadow\n// @description A soft shadow cast by the product onto whatever is behind it. Works on the product, before the background is added.\n// @scope product\n\nuniform float uOpacity;  // @param \"Darkness\" min=0 max=1 step=0.01 default=0.35\nuniform float uBlur;     // @param \"Softness\" min=1 max=80 step=0.5 default=18\nuniform float uOffsetX;  // @param \"Across\" min=-60 max=60 step=0.5 default=0\nuniform float uOffsetY;  // @param \"Down\" min=-60 max=60 step=0.5 default=22\nuniform vec3 uColor;     // @param \"Colour\" default=#000000\n\nvec4 effect(vec2 uv, vec4 color) {\n  vec2 origin = uv - perMille(1.0) * vec2(uOffsetX, uOffsetY);\n  float seen = 0.0;\n  for (int i = 0; i < 28; i++) {\n    float angle = float(i) * 2.39996;\n    float dist = sqrt((float(i) + 0.5) / 28.0) * uBlur;\n    seen += sampleInput(origin + perMille(dist) * vec2(cos(angle), sin(angle))).a;\n  }\n  float shadow = seen / 28.0 * uOpacity;\n  float alpha = color.a + shadow * (1.0 - color.a);\n  vec3 rgb = alpha > 0.0 ? (color.rgb * color.a + uColor * shadow * (1.0 - color.a)) / alpha : vec3(0.0);\n  return vec4(rgb, alpha);\n}\n", re = "// @shader Duotone\n// @description Repaints the picture with two colours: one for the darks, one for the lights.\n// @scope image\n\nuniform vec3 uShadow;     // @param \"Darks\" default=#1b1b3a\nuniform vec3 uHighlight;  // @param \"Lights\" default=#ffd6a5\nuniform float uStrength;  // @param \"Strength\" min=0 max=1 step=0.01 default=1\n\nvec4 effect(vec2 uv, vec4 color) {\n  float luma = dot(color.rgb, vec3(0.2126, 0.7152, 0.0722));\n  vec3 toned = mix(uShadow, uHighlight, luma);\n  return vec4(mix(color.rgb, toned, uStrength), color.a);\n}\n", ie = "// @shader Film grain\n// @description Fine speckle like photographic film. It also hides banding in smooth areas.\n// @scope image\n// @animated\n\nuniform float uAmount; // @param \"Amount\" min=0 max=0.5 step=0.005 default=0.08\nuniform float uSize;   // @param \"Grain size\" min=0.5 max=6 step=0.1 default=1.2\nuniform bool uMono;    // @param \"Black and white grain\" default=true\n\nfloat hash(vec2 p) {\n  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);\n}\n\nvec4 effect(vec2 uv, vec4 color) {\n  float cell = max(1.0, uSize * max(uResolution.x, uResolution.y) * 0.001);\n  vec2 id = floor(uv * uResolution / cell) + floor(uTime * 24.0);\n  vec3 n = uMono ? vec3(hash(id) - 0.5) : vec3(hash(id) - 0.5, hash(id + 17.0) - 0.5, hash(id + 41.0) - 0.5);\n  // Most visible in the midtones, like real film.\n  float luma = dot(color.rgb, vec3(0.2126, 0.7152, 0.0722));\n  float weight = 1.0 - abs(luma - 0.5) * 1.4;\n  return vec4(clamp(color.rgb + n * uAmount * weight, 0.0, 1.0), color.a);\n}\n", ae = "// @shader Pixelate\n// @description Chunky square pixels, like an old video game.\n// @scope image\n\nuniform int uCells; // @param \"Pixels across\" min=16 max=400 step=1 default=96\n\nvec4 effect(vec2 uv, vec4 color) {\n  vec2 grid = uResolution / max(uResolution.x, uResolution.y) * float(uCells);\n  return sampleInput((floor(uv * grid) + 0.5) / grid);\n}\n", oe = "// @shader Reflection\n// @description The product mirrored on a glossy surface under it, fading away. Works on the product, before the background is added.\n// @scope product\n\nuniform float uOpacity;  // @param \"Strength\" min=0 max=1 step=0.01 default=0.28\nuniform float uLength;   // @param \"Length\" min=20 max=400 step=1 default=140\nuniform float uGap;      // @param \"Gap\" min=0 max=40 step=0.5 default=1\nuniform float uBlur;     // @param \"Blur\" min=0 max=30 step=0.5 default=3\n\nconst int STEPS = 64;\n\n// true when the product is beside this point (left or right, on its own row) closer than `d`: the point is next to a slanted side, not under the base\nbool besideProduct(vec2 uv, float d) {\n  float dx = d * uResolution.y / uResolution.x;\n  for (int k = 1; k <= 4; k++) {\n    float o = dx * float(k) / 4.0;\n    if (sampleInput(vec2(uv.x - o, uv.y)).a > 0.5 || sampleInput(vec2(uv.x + o, uv.y)).a > 0.5) return true;\n  }\n  return false;\n}\n\nvec4 effect(vec2 uv, vec4 color) {\n  if (color.a > 0.995) return color;\n  // the product's base in this column: the first solid pixel going up from here, within the reflection's length\n  float reach = perMille(uLength).y;\n  float base = -1.0;\n  for (int i = 1; i <= STEPS; i++) {\n    float y = uv.y - reach * float(i) / float(STEPS);\n    if (y < 0.0) break;\n    if (sampleInput(vec2(uv.x, y)).a > 0.5) {\n      base = y;\n      break;\n    }\n  }\n  if (base < 0.0 || besideProduct(uv, uv.y - base)) return color;\n  float gap = perMille(uGap).y;\n  float d = uv.y - base - gap;\n  if (d <= 0.0) return color;\n  float fade = 1.0 - d / reach;\n  fade = fade * fade * uOpacity;\n  // mirrored about the base, a little blurred across so it reads as a surface, not a copy\n  vec2 mirror = vec2(uv.x, base - d);\n  vec4 refl = vec4(0.0);\n  for (int k = -2; k <= 2; k++) {\n    vec4 s = sampleInput(mirror + vec2(perMille(uBlur).x * float(k) * 0.5, 0.0));\n    refl += vec4(s.rgb * s.a, s.a);\n  }\n  refl /= 5.0;\n  float ra = refl.a * fade;\n  vec3 rrgb = refl.a > 0.0 ? refl.rgb / refl.a : vec3(0.0);\n  float alpha = color.a + ra * (1.0 - color.a);\n  vec3 rgb = alpha > 0.0 ? (color.rgb * color.a + rrgb * ra * (1.0 - color.a)) / alpha : vec3(0.0);\n  return vec4(rgb, alpha);\n}\n", se = "// @shader Sharpen\n// @description Crisper fine detail, like the print on a box. Gentle amounts look best.\n// @scope image\n\nuniform float uAmount; // @param \"Amount\" min=0 max=2 step=0.01 default=0.6\nuniform float uRadius; // @param \"Radius\" min=0.5 max=4 step=0.1 default=1.2\n\n// `uv` is where we are in the picture (0,0 top-left to 1,1 bottom-right); `color` is what is there now.\n// Return the new colour (red, green, blue, alpha, each 0 to 1).\nvec4 effect(vec2 uv, vec4 color) {\n  vec2 r = perMille(uRadius);\n  vec3 blur = (sampleInput(uv + vec2(r.x, 0.0)).rgb + sampleInput(uv - vec2(r.x, 0.0)).rgb +\n               sampleInput(uv + vec2(0.0, r.y)).rgb + sampleInput(uv - vec2(0.0, r.y)).rgb) * 0.25;\n  return vec4(clamp(color.rgb + (color.rgb - blur) * uAmount * 2.0, 0.0, 1.0), color.a);\n}\n", ce = "// @shader Soft glow\n// @description Bright areas bloom softly, for a dreamy, polished look.\n// @scope image\n\nuniform float uThreshold; // @param \"Only brighter than\" min=0 max=0.95 step=0.01 default=0.7\nuniform float uStrength;  // @param \"Strength\" min=0 max=2 step=0.01 default=0.5\nuniform float uRadius;    // @param \"Spread\" min=1 max=40 step=0.5 default=10\n\nvec4 effect(vec2 uv, vec4 color) {\n  vec3 glow = vec3(0.0);\n  // 20 samples spread over a disc (the golden angle keeps them evenly scattered).\n  for (int i = 0; i < 20; i++) {\n    float angle = float(i) * 2.39996;\n    float dist = sqrt((float(i) + 0.5) / 20.0) * uRadius;\n    vec3 s = sampleInput(uv + perMille(dist) * vec2(cos(angle), sin(angle))).rgb;\n    glow += max(s - uThreshold, 0.0) / (1.0 - uThreshold + 0.001);\n  }\n  glow /= 20.0;\n  vec3 screen = 1.0 - (1.0 - color.rgb) * (1.0 - clamp(glow * uStrength, 0.0, 1.0));\n  return vec4(screen, color.a);\n}\n", le = "// @shader Bulge\n// @description Puffs the middle of the product towards the viewer, like a pillow. Shows in the 3D scene.\n// @contract displace\n\nuniform float uAmount; // @param \"Puff\" min=-0.2 max=0.3 step=0.005 default=0.08\nuniform float uSpread; // @param \"Spread\" min=0.1 max=1 step=0.01 default=0.55\n\nvec3 displace(vec3 position, vec3 normal, vec2 uv) {\n  float centre = 1.0 - smoothstep(0.0, uSpread, length(position.xy));\n  position.z += uAmount * centre;\n  return position;\n}\n", ue = "#version 300 es\n// @shader Fullscreen triangle\n// @description Used by every effect to cover the whole picture. A system shader: it is not offered as an effect.\n// @contract fullscreen\n\n// One triangle that covers the viewport; no vertex buffers needed.\nvoid main() {\n  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));\n  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);\n}\n", de = "// @shader Sway\n// @description The product leans gently from side to side, as if in a breeze. Shows in the 3D scene.\n// @contract displace\n// @animated\n\nuniform float uAmount; // @param \"Lean\" min=0 max=0.2 step=0.002 default=0.04\nuniform float uSpeed;  // @param \"Speed\" min=0.1 max=4 step=0.05 default=1\n\n// Called for every vertex of the product. Returns where it should be. `position` is where it normally sits.\nvec3 displace(vec3 position, vec3 normal, vec2 uv) {\n  float height = position.y + 0.5;                         // 0 at the bottom, 1 at the top\n  position.x += sin(uTime * uSpeed) * uAmount * height;    // the top moves most, the base stays put\n  return position;\n}\n", k = "// @shader Ripple\n// @description A soft wave runs across the product, like a flag or a poster in a draught. Shows in the 3D scene.\n// @contract displace\n// @animated\n\nuniform float uAmount;    // @param \"Height\" min=0 max=0.15 step=0.002 default=0.025\nuniform float uFrequency; // @param \"Waves\" min=1 max=16 step=0.1 default=6\nuniform float uSpeed;     // @param \"Speed\" min=0 max=6 step=0.05 default=1.5\n\nvec3 displace(vec3 position, vec3 normal, vec2 uv) {\n  position.z += sin(position.x * uFrequency + uTime * uSpeed) * uAmount;\n  return position;\n}\n", fe = (e, t) => e.slice(e.lastIndexOf("/") + 1).replace(t, "");
function pe(e) {
	let t = {
		fragment: [],
		vertex: [],
		errors: []
	};
	for (let [n, r] of Object.entries(e)) {
		let e = n.endsWith(".frag.glsl") ? "fragment" : n.endsWith(".vert.glsl") ? "vertex" : null;
		if (!e) continue;
		let i = fe(n, e === "fragment" ? ".frag.glsl" : ".vert.glsl");
		try {
			t[e].push(T(i, e, r));
		} catch (e) {
			t.errors.push(e instanceof _ ? e.message : `${n}: ${String(e)}`);
		}
	}
	for (let e of [t.fragment, t.vertex]) e.sort((e, t) => e.name.localeCompare(t.name));
	return t;
}
var A = pe(/* @__PURE__ */ Object.assign({
	"../fragment/chromatic-aberration.frag.glsl": ee,
	"../fragment/contact-shadow.frag.glsl": te,
	"../fragment/drop-shadow.frag.glsl": ne,
	"../fragment/duotone.frag.glsl": re,
	"../fragment/film-grain.frag.glsl": ie,
	"../fragment/pixelate.frag.glsl": ae,
	"../fragment/reflection.frag.glsl": oe,
	"../fragment/sharpen.frag.glsl": se,
	"../fragment/soft-glow.frag.glsl": ce,
	"../vertex/bulge.vert.glsl": le,
	"../vertex/fullscreen.vert.glsl": ue,
	"../vertex/sway.vert.glsl": de,
	"../vertex/wave.vert.glsl": k
}));
A.errors.length && console.warn(`Some shaders were skipped:\n${A.errors.join("\n")}`);
var j = (e) => A.fragment.find((t) => t.id === e);
function me(e = ["image", "product"]) {
	return A.fragment.filter((t) => e.includes(t.scope));
}
var he = (A.vertex.find((e) => e.id === "fullscreen")?.source ?? "").replace(/^\s*\/\/.*\n/gm, "");
//#endregion
//#region src/ShaderControls.tsx
function ge(e, t, n) {
	let r = t < .1 ? 2 : +(t < 1);
	return `${e.toFixed(r)}${n ?? ""}`;
}
function _e({ spec: e, value: t, onChange: n, onBegin: r, onCommit: i }) {
	if (e.kind === "number") {
		let a = Number(t);
		return /* @__PURE__ */ g("label", {
			className: "gs-control",
			children: [/* @__PURE__ */ g("span", {
				className: "gs-control__row",
				children: [/* @__PURE__ */ h("span", { children: e.label }), /* @__PURE__ */ h("output", {
					className: a === e.default ? "" : "is-changed",
					children: ge(a, e.step, e.unit)
				})]
			}), /* @__PURE__ */ h("input", {
				type: "range",
				style: Q(a, e.min, e.max),
				min: e.min,
				max: e.max,
				step: e.step,
				value: a,
				onPointerDown: r,
				onPointerUp: i,
				onLostPointerCapture: i,
				onChange: (e) => n(Number(e.target.value)),
				onDoubleClick: () => n(e.default)
			})]
		});
	}
	return e.kind === "boolean" ? /* @__PURE__ */ g("label", {
		className: "gs-control gs-control--inline",
		children: [/* @__PURE__ */ h("input", {
			type: "checkbox",
			checked: t === !0,
			onChange: (e) => n(e.target.checked)
		}), e.label]
	}) : e.kind === "color" ? /* @__PURE__ */ g("label", {
		className: "gs-control gs-control--inline",
		children: [/* @__PURE__ */ h("input", {
			type: "color",
			value: String(t),
			"aria-label": e.label,
			onFocus: r,
			onBlur: i,
			onChange: (e) => n(e.target.value)
		}), e.label]
	}) : /* @__PURE__ */ g("label", {
		className: "gs-control",
		children: [/* @__PURE__ */ h("span", {
			className: "gs-control__row",
			children: /* @__PURE__ */ h("span", { children: e.label })
		}), /* @__PURE__ */ h("select", {
			value: String(t),
			onChange: (e) => n(e.target.value),
			children: e.options.map((e) => /* @__PURE__ */ h("option", {
				value: e,
				children: e
			}, e))
		})]
	});
}
function ve({ steps: e, catalog: t, known: n, title: r, empty: i, onAdd: a, onRemove: o, onMove: s, onParam: c, onBegin: l, onCommit: u }) {
	return /* @__PURE__ */ g("section", { children: [
		/* @__PURE__ */ h("h2", { children: r }),
		e.length === 0 && /* @__PURE__ */ h("p", {
			className: "gs-hint",
			children: i
		}),
		e.map((t, r) => {
			let i = n(t.id), a = i ? D(i, t.params) : t.params;
			return /* @__PURE__ */ g("div", {
				className: "gs-effect",
				children: [
					/* @__PURE__ */ g("div", {
						className: "gs-effect__head",
						children: [/* @__PURE__ */ h("strong", {
							title: i?.description,
							children: i?.name ?? t.id
						}), /* @__PURE__ */ g("span", {
							className: "gs-effect__buttons",
							children: [
								/* @__PURE__ */ h("button", {
									type: "button",
									className: "gs-button gs-button--small",
									disabled: r === 0,
									onClick: () => s(r, -1),
									"aria-label": "Move up",
									title: "Move up (it runs earlier)",
									children: "↑"
								}),
								/* @__PURE__ */ h("button", {
									type: "button",
									className: "gs-button gs-button--small",
									disabled: r === e.length - 1,
									onClick: () => s(r, 1),
									"aria-label": "Move down",
									title: "Move down (it runs later)",
									children: "↓"
								}),
								/* @__PURE__ */ h("button", {
									type: "button",
									className: "gs-button gs-button--small",
									onClick: () => o(r),
									"aria-label": `Remove ${i?.name ?? t.id}`,
									title: "Remove",
									children: "✕"
								})
							]
						})]
					}),
					!i && /* @__PURE__ */ h("p", {
						className: "gs-hint",
						children: "This effect's shader file is not installed, so it is skipped."
					}),
					i?.params.map((e) => /* @__PURE__ */ h(_e, {
						spec: e.spec,
						value: a[e.key] ?? e.spec.default,
						onChange: (t) => c(r, e.key, t, `${i.name}: ${e.spec.label}`),
						onBegin: () => l(`${i.name}: ${e.spec.label}`),
						onCommit: u
					}, e.key))
				]
			}, `${t.id}-${r}`);
		}),
		e.length < 12 && t.length > 0 && /* @__PURE__ */ g("select", {
			className: "gs-effect__add",
			"aria-label": `Add to ${r.toLowerCase()}`,
			value: "",
			onChange: (e) => {
				let n = t.find((t) => t.id === e.target.value);
				n && a(n), e.currentTarget.blur();
			},
			children: [/* @__PURE__ */ h("option", {
				value: "",
				children: "+ Add…"
			}), t.map((e) => /* @__PURE__ */ h("option", {
				value: e.id,
				title: e.description,
				children: e.name
			}, e.id))]
		})
	] });
}
//#endregion
//#region src/instructions.ts
var ye = [
	"Top bar",
	"One click",
	"Cut out",
	"Clean up",
	"Adjust",
	"Edit mode",
	"Photo lab",
	"3D mode"
], M = {
	undo: {
		group: "Top bar",
		name: "Undo and redo",
		user: "Steps back one change at a time (Ctrl+Z); Ctrl+Shift+Z steps forward again.",
		dev: "editor.undo()/redo() over the recipe history: packages/core/src/history.ts. A slider drag is one step (editor.begin/commit)."
	},
	compare: {
		group: "Top bar",
		name: "Compare",
		user: "Hold it (or hold \\) to see the photo as it was; let go to see your changes.",
		dev: "While held, GleamEditor draws createDocument(doc.source) instead of the edited document; nothing is changed."
	},
	reset: {
		group: "Top bar",
		name: "Reset",
		user: "Takes every change off and shows the photo as it was. Undo brings them back.",
		dev: "editor.reset() sets the default recipe as one undo step: packages/core/src/editor.ts."
	},
	editMode: {
		group: "Top bar",
		name: "Edit mode",
		user: "Opens the picture with layers, brushes, selections, shapes and text (E). Done brings it back here.",
		dev: "packages/react/src/edit/EditMode.tsx over @gleamshelf/canvas (CanvasDocument, COMMANDS). The same commands run headless: npm run mcp, docs/MCP.md."
	},
	photoLab: {
		group: "Top bar",
		name: "Photo lab",
		user: "Opens the photo for hand editing: develop sliders, looks, retouching, every filter and adjustment, layers (L).",
		dev: "packages/react/src/photolab/PhotoLab.tsx over @gleamshelf/craft (PhotoCraft engine + LightCraft develop in WebAssembly, in a worker)."
	},
	phone: {
		group: "Top bar",
		name: "From phone",
		user: "Scan the code with a phone on the same Wi-Fi, take photos, and click one here to edit it. Photos stay on your network.",
		dev: "startPhoneCapture (apps/local/src/phone.ts): a LAN page with a random code; /phone routes on 127.0.0.1; PhoneCapture.tsx polls phonePhotos. A host start screen uses PhoneStart (same panel, before a photo is open)."
	},
	done: {
		group: "Top bar",
		name: "Done",
		user: "Saves the finished picture and closes the editor.",
		dev: "Renders the recipe at full size (packages/render2d) and calls onDone(blob, recipe); export options come from GleamEditorProps.exportOptions."
	},
	guide: {
		group: "Top bar",
		name: "Guide",
		user: "Lists every feature with how to use it. Tick \"Developer notes\" to see how each one works.",
		dev: "Built from HELP in packages/react/src/instructions.ts; the switch is stored in localStorage \"gleamshelf:dev-notes\"."
	},
	autoRun: {
		group: "One click",
		name: "Make it listing-ready",
		user: "Pick what to keep, untick any step you do not want (under Steps), then press the button. It takes a few minutes.",
		dev: "Steps fold under one summary line; the running step also shows as a badge on the picture (GleamEditor). POST /process on the companion app (startProcess, polled with processStatus) runs processPhoto in apps/local/src/chain.ts, the same as `npm run batch -- <dir> --out <dir>`."
	},
	autoMode: {
		group: "One click",
		name: "Whole box, Character on cover, Auto",
		user: "Whole box keeps the box; Character on cover keeps only the character; Auto picks for each photo.",
		dev: "ChainOptions.mode = product | character | auto (batch --mode). Auto uses classifyBoxView in packages/pipeline/src/view.ts."
	},
	foundPhotos: {
		group: "One click",
		name: "Found online",
		user: "Untick any picture that isn't your product, then Use. With no choice in 20 s it goes on with the ones that line up.",
		dev: "The run waits (status \"waiting\", found: FoundOnline) after lookUp in chain.ts; POST /process/:id/choose {use} lets it go on; FOUND_WAIT_SECONDS countdown in Panel.tsx."
	},
	autoReport: {
		group: "One click",
		name: "What the run found",
		user: "Check the score, anything marked, and the listing before you list. Copy takes the text; Every marketplace saves the pictures.",
		dev: "ProcessStatus.report: notes (folded under What the run did), flags, lookup and listing from processPhoto; the panel scrolls to it when it arrives; the batch writes the same to reports/<name>.json and needs-review.txt."
	},
	sendToShop: {
		group: "One click",
		name: "Send to the shop",
		user: "Sends the photo and listing to the shop’s Imports as a draft; nothing is published until someone there adds it.",
		dev: "ShopSend (Panel.tsx) → POST /process/<id>/send and /shop/connect on the companion app (apps/local/src/shoplink.ts): draftFrom + pushDraft, the same as npm run push."
	},
	makeAd: {
		group: "One click",
		name: "3D ad",
		user: "Opens 3D mode with this product’s cut-out, name and series ready for an ad; type the price, pick a layout, then save a video.",
		dev: "GleamEditor makeAd: processPicture(runId, cutout) and the report’s identity and listing into ModelMode’s ad (AdDialog, buildAd)."
	},
	autoBack: {
		group: "One click",
		name: "Back to the original photo",
		user: "Closes the finished picture and opens your photo as it was.",
		dev: "full.goBack in GleamEditor: reloads `source` and drops the processPicture result."
	},
	"step.stickers": {
		group: "One click",
		name: "Remove price stickers",
		user: "Paints out the shop’s price stickers so the photo stays right when the price changes.",
		dev: "findPriceStickers in chain.ts (text reader + prices.ts), then LaMa inpaint. Batch: --no-stickers turns it off."
	},
	"step.lettering": {
		group: "One click",
		name: "Repaint lettering",
		user: "For a character on a cover: paints out the title and printed text before cutting out.",
		dev: "cleanPicture in chain.ts (text finder, titleInk/thinStrokes in packages/pipeline/src/printed.ts, LaMa). Batch: --no-lettering."
	},
	"step.find": {
		group: "One click",
		name: "Look the product up",
		user: "Searches the web first, with words read from the box (never the photo), and shows you what it found before using any.",
		dev: "identifyProduct (identify.ts, local VLM) then findReferenceFiles (refs.ts, SearXNG) and findOfficialPhoto (official.ts). Batch: --offline turns it off."
	},
	"step.thinParts": {
		group: "One click",
		name: "Complete what the box hides",
		user: "Finds thin parts the cut-out missed and fills parts hidden by printing from a matching official photo. Check them.",
		dev: "completeFromReferences + fillFromReference in apps/local/src/reference.ts (register.py: SIFT + RANSAC). Batch: --no-thin-parts."
	},
	"step.colour": {
		group: "One click",
		name: "Match colours",
		user: "Brings the colours to the product’s official picture. Needs the web lookup.",
		dev: "colourFromReferences in reference.ts (Lab transfer from registered references). Batch: --no-colour."
	},
	"step.vivid": {
		group: "One click",
		name: "Punchier colours",
		user: "Makes the matched colours 40% stronger. Untick to keep the softer published colours.",
		dev: "Chroma gain after colour matching; batch --vivid <1-2> (default 1.4, 1 is off)."
	},
	"step.look": {
		group: "One click",
		name: "Brighten and sharpen",
		user: "Gives the finished picture a little more light, colour and sharpness.",
		dev: "The \"Bright & sharp\" look (packages/core/src/looks.ts) via enhance() in packages/pipeline/src/enhance.ts. Batch: --no-look."
	},
	"step.gloss": {
		group: "One click",
		name: "Studio gloss",
		user: "Redraws the product as a glossy studio shot. It changes the product, so it is off unless you tick it.",
		dev: "client.gloss → POST /enhance with STUDIO_GLOSS (SDXL tile, apps/modelserver); printed text pasted back. Batch: --gloss; setup: npm run redraw:setup."
	},
	"step.enlarge": {
		group: "One click",
		name: "Enlarge",
		user: "Makes the picture bigger with more detail; printed text is enlarged plainly so it is not rewritten.",
		dev: "POST /upscale (RealPLKSR / Real-ESRGAN, apps/local/src/enlarge.ts). Batch: --no-enlarge; --size sets the output."
	},
	"step.listing": {
		group: "One click",
		name: "Write a title and description",
		user: "Writes the listing only from facts that were found. Check any numbers it marks.",
		dev: "apps/local/src/listing.ts (factList, local VLM, withoutSellerTalk filters). Batch: --write-listing; needs npm run vlm:setup."
	},
	green: {
		group: "Cut out",
		name: "Remove green backdrop",
		user: "For photos on a green cloth: press it and the green goes. Free and instant.",
		dev: "editor.removeGreenBackdrop() adds a \"green\" mask op; keyOutGreen in packages/pipeline/src/key.ts."
	},
	cutManual: {
		group: "Cut out",
		name: "Cut out by hand",
		user: "Press Cut out product, then tap the background or paint with Erase and Restore. Press Done when it looks right.",
		dev: "CutoutOverlay.tsx appends \"fill\" and \"brush\" ops to recipe.mask (packages/core/src/mask.ts); the renderer turns them into alpha."
	},
	"cut.tap": {
		group: "Cut out",
		name: "Tap",
		user: "Click the background to remove everything of a similar colour around it. Tolerance sets how similar.",
		dev: "A FillOp {x, y, tolerance} in recipe.mask: the connected region of similar colour (packages/core/src/mask.ts)."
	},
	"cut.erase": {
		group: "Cut out",
		name: "Erase",
		user: "Paint over anything that should go. Brush size sets the width.",
		dev: "A BrushOp {mode: \"remove\", radius, points} in recipe.mask (packages/core/src/mask.ts); radius is a share of the long side."
	},
	"cut.restore": {
		group: "Cut out",
		name: "Restore",
		user: "Paint over anything that should come back.",
		dev: "A BrushOp with mode \"keep\" in recipe.mask (packages/core/src/mask.ts): later ops win over earlier ones."
	},
	fade: {
		group: "Cut out",
		name: "Fade bottom",
		user: "Softens a hard bottom edge, such as a figure cut off at the waist.",
		dev: "editor.fadeBottom(0.1): a FadeOp {edge: \"bottom\", size} in recipe.mask (packages/core/src/mask.ts)."
	},
	clearMask: {
		group: "Cut out",
		name: "Clear",
		user: "Brings back the whole photo, background and all.",
		dev: "editor.clearMask() empties recipe.mask as one undo step."
	},
	aiCutout: {
		group: "Cut out",
		name: "AI cut-out",
		user: "Choose Whole product or Character on cover, then press the cut-out button. For a character, crop to the artwork first.",
		dev: "client.cutout → POST /cutout (BiRefNet; SAM 3.1 with thinParts for characters). The mask lands as a \"model\" op: AiCutout.tsx."
	},
	studio: {
		group: "Cut out",
		name: "Studio photo",
		user: "After cutting out: one press gives a white, square picture with a soft shadow.",
		dev: "studioPhoto in GleamEditor: white backdrop, editor.fitSquareToProduct(box, 0.07) and a \"drop-shadow\" effect, as one undo step."
	},
	recentRuns: {
		group: "One click",
		name: "Recent results",
		user: "Every finished run is kept on this computer: open one again instantly, with its picture and listing, no waiting.",
		dev: "ProcessJobs keeps runs in ~/.gleamshelf/runs/<id> (apps/local/src/jobs.ts); /process/recent lists them; opening one reuses openFinishedRun in GleamEditor."
	},
	fidelityGuard: {
		group: "One click",
		name: "Fidelity guard",
		user: "Where enlarging made detail up, the plain picture goes back. \"Show what is not as photographed\" tints what was changed.",
		dev: "guardChanges after the enlarge step in processPhoto; fidelityOverlay (packages/pipeline/src/quality.ts) as /process/<id>/changes.png."
	},
	flatten: {
		group: "Cut out",
		name: "Flatten card or box front",
		user: "After cutting out a card or a box front shot at an angle: one press pulls its corners straight, only its own pixels.",
		dev: "quadFromMask and flattenCutout (packages/pipeline/src/flatten.ts): largest four-cornered shape in the hull, then a perspective warp."
	},
	listingHealth: {
		group: "One click",
		name: "Listing health",
		user: "After a run: a score out of 100, how sure the cut-out is, how much is as photographed, and the top three fixes.",
		dev: "listingHealth (apps/local/src/health.ts) over the listing; cutoutConfidence and fidelityCheck (packages/pipeline/src/quality.ts) in processPhoto."
	},
	ground: {
		group: "Cut out",
		name: "Shadow and reflection",
		user: "Soft shadow, Contact shadow and Reflection make the product stand on a surface; fine-tune each under Look.",
		dev: "Effects drop-shadow, contact-shadow and reflection (packages/shaders/fragment/*.frag.glsl, scope product): each finds the base per column."
	},
	listingSet: {
		group: "Cut out",
		name: "Listing set",
		user: "Tick the marketplaces and save: one picture each, in that site's size and framing, all in one zip.",
		dev: "MARKETPLACE_PRESETS and presetDocument (packages/core/src/presets.ts) give each variant; renderer.export per preset; zipFiles (packages/react/src/zip.ts). Also under a finished one-click run (AutoSection)."
	},
	backdrop: {
		group: "Cut out",
		name: "Behind the product",
		user: "Choose None (transparent), a Colour, or your own Photo to go behind the cut-out.",
		dev: "The \"backdrop\" op (mode, color) in packages/core/src/ops.ts; a photo is passed to the renderer as `background`."
	},
	square: {
		group: "Cut out",
		name: "Square picture",
		user: "Fit square to product centres the product on a square; Space around sets the margin.",
		dev: "editor.fitSquareToProduct(maskBounds(...)); the \"canvas\" op (square, margin %) in packages/core/src/ops.ts."
	},
	stickers: {
		group: "Clean up",
		name: "Remove price stickers",
		user: "Press it and the shop’s price stickers are found and painted out.",
		dev: "client.readText → POST /read-text, prices told from printing (apps/local/src/prices.ts), then POST /inpaint (LaMa)."
	},
	stickerClick: {
		group: "Clean up",
		name: "Click a sticker",
		user: "If one was missed, press this and click the sticker on the picture.",
		dev: "PickOverlay.tsx → tightenStickerBox (packages/pipeline/src/stickers.ts) → inpaint."
	},
	textClick: {
		group: "Clean up",
		name: "Click printed text",
		user: "For a big title left behind: click one letter and the rest of that text is painted out.",
		dev: "colourKeyedStrokes in packages/pipeline/src/printed.ts from the clicked colour, inside the detectText box; then inpaint."
	},
	lettering: {
		group: "Clean up",
		name: "Remove white lettering",
		user: "Press it to paint out white words across the picture. Cut out first to keep it to the product.",
		dev: "editor.setWords(true): findWhiteWords / removeWhiteWords in packages/pipeline/src/words.ts."
	},
	letteringSliders: {
		group: "Clean up",
		name: "Lettering settings",
		user: "Lower How white if lettering is missed; Thickest stroke and Shortest piece leave bows and glints alone.",
		dev: "WordsOptions lightness, maxWidth, minLength (packages/pipeline/src/words.ts); each drag is one undo step."
	},
	aiFill: {
		group: "Clean up",
		name: "AI fill",
		user: "Press Fill with AI to repaint the lettering cleanly instead of the soft free fill.",
		dev: "AiFill.tsx: client.inpaint → POST /inpaint (LaMa), optionally with detectText boxes for other printed text."
	},
	finish: {
		group: "Clean up",
		name: "Finishing touches",
		user: "Type what the area should be, press Choose the area, and drag over it. Check the result before listing.",
		dev: "AiFinish.tsx + AreaOverlay.tsx: client.redraw → POST /redraw (SDXL inpaint, box). Set up with npm run redraw:setup."
	},
	rotate: {
		group: "Adjust",
		name: "Rotate and flip",
		user: "Turn the picture a quarter at a time, or mirror it.",
		dev: "editor.rotate(±1) / flip(axis): the \"orient\" op; rotate also turns the crop (packages/core/src/editor.ts)."
	},
	crop: {
		group: "Adjust",
		name: "Crop",
		user: "Press Crop (C), drag the corners, then press Done or Enter. Pick a shape from the list first if you need one.",
		dev: "CropOverlay.tsx edits the \"crop\" op; editor.setCropAspect(aspect) with CROP_ASPECTS from packages/core."
	},
	straighten: {
		group: "Adjust",
		name: "Straighten",
		user: "Drag until the box stands straight. Double-click the slider to reset.",
		dev: "The \"straighten\" op (angle, ±45°), applied by the renderer in packages/render2d."
	},
	looks: {
		group: "Adjust",
		name: "Looks",
		user: "Press a look for livelier colour and detail; Natural takes it off.",
		dev: "LOOKS in packages/core/src/looks.ts set light, colour and a sharpen effect; editor.applyLook / clearLook."
	},
	autoLook: {
		group: "Adjust",
		name: "Brighter and sharper after an AI step",
		user: "Leave it ticked to brighten and sharpen automatically after AI cut-outs and fills.",
		dev: "onAutoEnhance in GleamEditor: applies the \"bright\" look after an AI op unless the person set their own."
	},
	enlarge: {
		group: "Adjust",
		name: "Sharpen and enlarge",
		user: "Choose a model and press Sharpen & enlarge to make the picture bigger and crisper.",
		dev: "AiEnlarge.tsx: client.upscale → POST /upscale; the optional extra detail is POST /enhance (SDXL tile)."
	},
	light: {
		group: "Adjust",
		name: "Light",
		user: "Drag a slider to change brightness, contrast, highlights or shadows. Double-click one to reset it.",
		dev: "The \"light\" op in packages/core/src/ops.ts, drawn by the WebGL shader in packages/render2d."
	},
	color: {
		group: "Adjust",
		name: "Colour",
		user: "Drag a slider to warm, cool or strengthen the colour. Double-click one to reset it.",
		dev: "The \"color\" op in packages/core/src/ops.ts (temperature, tint, vibrance, saturation), drawn in packages/render2d."
	},
	recolour: {
		group: "Adjust",
		name: "Colour swap",
		user: "Tick it, pick the colour to change and the new colour. Use it only for a colour version you really sell.",
		dev: "The \"recolour\" op (from, to, range) in packages/core/src/recolour.ts; off by default because it changes the product."
	},
	effects: {
		group: "Adjust",
		name: "Effects",
		user: "Choose an effect to add it, then set it with its sliders. Arrows change the order.",
		dev: "recipe.effects: shader steps from packages/shaders (listEffects, defaultParams); editor.addEffect / moveEffect."
	},
	m3dAdd: {
		group: "3D mode",
		name: "Add a shape",
		user: "Click a shape to add it, or Outline, Text or SVG logo to push one out. It lands on the ground; drag its arrows to place it.",
		dev: "ModelEditor.addShape in packages/scene3d/src/model/editor.ts; kinds, sizes and defaults in packages/scene3d/src/model/document.ts."
	},
	m3dOutlineShape: {
		group: "3D mode",
		name: "Outlines",
		user: "Pick a ready-made outline or draw one with the pen; it is pushed out into a solid. Depth and Bevel shape its sides.",
		dev: "kind extrude: Shape3D.outline (unit-box contours) as a 2D distance field (fieldOf, packages/scene3d/src/model/outline.ts) pushed out along z."
	},
	m3dText: {
		group: "3D mode",
		name: "3D text",
		user: "Type one or more lines and pick a font: standard, online, this computer’s or your own file. The letters become solid 3D text.",
		dev: "textOutline (scene3d/src/model/text.ts) draws the lines on a canvas and traces them; fonts and loading in react/src/model3d/fonts.ts (TextSpec)."
	},
	m3dMulti: {
		group: "3D mode",
		name: "Several shapes",
		user: "Shift-click shapes in the view or the list to pick several (Ctrl A: all). Drag the arrows to move them together, or set them here.",
		dev: "ModelViewport.selectSeveral (scene3d renderer.ts) and ModelEditor.updateShapesAt; the panel is react/src/model3d/MultiPanel.tsx."
	},
	m3dAlign: {
		group: "3D mode",
		name: "Line up",
		user: "Line the picked shapes up by their sides or middles, spread three or more evenly, or put them on the ground.",
		dev: "alignMoves, spreadMoves and groundMoves (scene3d/src/model/arrange.ts) by turned boxes; ModelEditor.align, spread, toGround."
	},
	m3dLookCopy: {
		group: "3D mode",
		name: "Copy a look",
		user: "Copy look takes a shape’s colour and finish; Paste look gives it to the picked shapes (Ctrl Alt C and Ctrl Alt V).",
		dev: "copyLook and copiedLook in react/src/model3d/clipboard.ts; pasted with ModelEditor.updateShapesAt (models switch to one colour)."
	},
	m3dLock: {
		group: "3D mode",
		name: "Lock",
		user: "A locked shape cannot be clicked or dragged in the view, so it stays put while you work on others. Its settings still change.",
		dev: "Shape3D.locked (kept only when true): ModelViewport skips it when picking and shows no gizmo (scene3d/src/model/renderer.ts)."
	},
	m3dCopy: {
		group: "3D mode",
		name: "Copy and paste",
		user: "Ctrl C, X and V copy, cut and paste shapes, into this design or another. Paste an SVG copied from a drawing app to make a logo.",
		dev: "copyShapes in react/src/model3d/clipboard.ts with assetsOf; ModelEditor.pasteShapes; an SVG pasted as text goes to svgOutlines."
	},
	m3dPen: {
		group: "3D mode",
		name: "Pen",
		user: "Click for a corner, drag for a curve, click the first point to close. Drag points or handles to reshape them.",
		dev: "PenPad (react/src/model3d/PenPad.tsx) edits Shape3D.pen; penContours (scene3d/src/model/pen.ts) flattens it into the outline."
	},
	m3dSvgImport: {
		group: "3D mode",
		name: "SVG logo",
		user: "SVG logo (or drop an .svg): each colour becomes its own 3D piece, placed as in the logo. Outline any text in the file first.",
		dev: "svgOutlines (scene3d/src/model/svg.ts) reads paths and fills, paints them in order, traces each colour; shapesFromSvg + ModelEditor.addShapes."
	},
	m3dGroup: {
		group: "3D mode",
		name: "Groups",
		user: "Shift-click shapes in the list and press Group (Ctrl G). A cut inside a group only cuts that group; move it all at once.",
		dev: "kind group with children, one level: steps() in document.ts marks begin and end; map() in glsl.ts joins the children, then the group."
	},
	m3dSvg: {
		group: "3D mode",
		name: "Save as vectors",
		user: "Save, then Vectors (SVG): the design in flat steps of light, each region a shape you can edit in a vector app.",
		dev: "modelToSvg (packages/scene3d/src/model/vector.ts): renderModelCpu with tones, regions by colour traced by traceContours, cropped when see-through."
	},
	m3dVideo: {
		group: "3D mode",
		name: "Video",
		user: "Save, then Video: the shapes move as set, with the camera still, turning round or swaying, or the light sweeping. Saved as MP4.",
		dev: "recordClip (scene3d/src/model/video.ts): clipFrame = animate (motion.ts) plus the camera; frames encoded with WebCodecs via Mediabunny."
	},
	m3dAd: {
		group: "3D mode",
		name: "3D ad",
		user: "The product photo on a stage with a 3D headline, price badge and logo. The photo stays as photographed; change anything after.",
		dev: "buildAd (scene3d/src/model/ad.ts) with pictureCard (card.ts: an unlit, cut-out card); AdDialog.tsx; replaceDesign is one undo step."
	},
	m3dScene: {
		group: "3D mode",
		name: "Scene behind",
		user: "Paint a scene behind the design with the image model on this computer (free), or use a picture. The design itself is not redrawn.",
		dev: "makeScene (react/src/model3d/scene.ts): the redraw model paints a blank picture; kept as background.picture, laid under the design by finish.ts."
	},
	m3dMotion: {
		group: "3D mode",
		name: "Motion",
		user: "Pick how it moves: spin, float, bounce, sway, pulse, wiggle, go round or pop in. Play shows it; Stagger makes several follow on.",
		dev: "Shape3D.motion (Motion in scene3d/src/model/motion.ts): poseAt per body, animate per frame; ModelViewport.showFrame plays it."
	},
	m3dShapes: {
		group: "3D mode",
		name: "Shapes, top to bottom",
		user: "Shapes are joined in order: each one adds to, cuts or intersects everything above it. The arrows change the order.",
		dev: "doc.shapes order is the join order of map() in packages/scene3d/src/model/glsl.ts and sceneDistance in packages/scene3d/src/model/sdf.ts."
	},
	m3dGizmo: {
		group: "3D mode",
		name: "Move, turn and resize",
		user: "Pick a shape, then drag the arrows, rings or boxes on it. W moves, E turns, R resizes; Delete removes it.",
		dev: "Three.js TransformControls on a proxy object in ModelViewport (packages/scene3d/src/model/renderer.ts); one undo step per drag."
	},
	m3dView: {
		group: "3D mode",
		name: "Views",
		user: "Drag to orbit, right-drag to pan, scroll to zoom. Number keys give flat views (5 front, 8 top); Ctrl and arrows turn in steps.",
		dev: "OrbitControls write doc.camera (yaw, pitch, distance, target) in renderer.ts; VIEWS in packages/scene3d/src/model/document.ts."
	},
	m3dImport: {
		group: "3D mode",
		name: "Import a model",
		user: "Import (or drop a file on the view): GLB, glTF, FBX, OBJ, STL, PLY or 3MF. Pick a .gltf or .obj with its .bin, .mtl and pictures.",
		dev: "importModelFiles (packages/scene3d/src/model/importer.ts) to a plain GLB in doc.assets (PBR maps, clearcoat, sheen, glass); kind mesh: MeshLayer in renderer.ts, meshcpu.ts on the CPU."
	},
	m3dGrid: {
		group: "3D mode",
		name: "Grid",
		user: "Grid (G) shows lines on the ground; type the cell size beside it. Snap moves shapes in whole cells and turns in 15° steps.",
		dev: "uGrid in gridAt() of packages/scene3d/src/model/glsl.ts, set by ModelViewport.setGrid (renderer.ts), viewport only; kept in localStorage."
	},
	m3dCombine: {
		group: "3D mode",
		name: "Combine and blend",
		user: "Add joins the shape on, Cut carves it out, Intersect keeps only the overlap. Blend melts the join into one smooth form.",
		dev: "Polynomial smooth min/max per shape in map() (packages/scene3d/src/model/glsl.ts); the blend radius is blend x 0.6 scene units."
	},
	m3dSize: {
		group: "3D mode",
		name: "Size, place and rounding",
		user: "Type exact sizes, places and turns, or round the edges. A ring also has a tube thickness.",
		dev: "Shape3D.size, position, rotation (degrees, XYZ), round and thickness; distance functions in shapeDist (glsl.ts) and sdf.ts."
	},
	m3dMaterial: {
		group: "3D mode",
		name: "Colour and finish",
		user: "Pick a colour and how the surface shines: matte, satin, glossy or metal.",
		dev: "Shape3D.color and finish become uCol and uMat (shininess, metal) in fillUniforms, packages/scene3d/src/model/renderer.ts."
	},
	m3dLook: {
		group: "3D mode",
		name: "Look",
		user: "Soft looks lifelike, Toon is drawn in steps of light, Flat is plain colour, Clay is matte white, Pixel is chunky pixel art.",
		dev: "style.look becomes uLook in shade() (scene3d glsl.ts); pixel: drawn small as toon, enlarged with hard edges (finish.ts, style.pixel)."
	},
	m3dOutline: {
		group: "3D mode",
		name: "Outline",
		user: "Give the design an inked outline, in any width and colour.",
		dev: "style.outline in pixels per 1000: the silhouette from the ray’s closest approach, plus edges turning away, in render() of glsl.ts."
	},
	m3dLight: {
		group: "3D mode",
		name: "Light",
		user: "Swing the light around and up, set how bright it is, and how much soft fill reaches the shadows.",
		dev: "light.azimuth and elevation become uLightDir; soft shadows and ambient occlusion are marched in packages/scene3d/src/model/glsl.ts."
	},
	m3dFloor: {
		group: "3D mode",
		name: "Floor and background",
		user: "A floor that only shows the shadows, and a see-through or coloured background.",
		dev: "ground.on and shadow (the plane y = 0, shadow only) and background in render() of packages/scene3d/src/model/glsl.ts."
	},
	m3dUse: {
		group: "3D mode",
		name: "Use in design",
		user: "Places the 3D picture as a layer. To change it later, pick that layer and choose Edit 3D layer in the Layer menu.",
		dev: "renderModel (renderer.ts) draws in tiles, four samples a pixel; the design rides on the layer as RasterLayer.model3d (packages/canvas/src/document.ts)."
	},
	m3dMake: {
		group: "3D mode",
		name: "Make 3D from a layer",
		user: "In Edit mode, pick a layer and choose Make 3D in the Layer menu: its shape becomes a solid in its own colour.",
		dev: "layerPicture in packages/react/src/edit/EditMode.tsx, then modelFromPicture (packages/scene3d/src/model/text.ts); MCP model_from_layer does the same."
	},
	m3dSave: {
		group: "3D mode",
		name: "Save a picture",
		user: "Saves a PNG of the design, see-through wherever there is nothing.",
		dev: "renderModel(doc, width, height) in packages/scene3d/src/model/renderer.ts, saved through a download link."
	},
	labDevelop: {
		group: "Photo lab",
		name: "Develop",
		user: "Drag the sliders to change light, colour, detail and lens faults across the photo. Apply keeps the result.",
		dev: "LightCraft develop pipeline: develop.render on the active layer (DevelopSource in packages/craft/rust/src/lib.rs), applied with replace_active_rgba."
	},
	labLooks: {
		group: "Photo lab",
		name: "Looks",
		user: "Click a look to try it on the photo; Strength sets how much. Apply keeps it.",
		dev: "LightCraft's built-in presets (develop_presets) applied with develop_apply_preset at the chosen amount, then rendered like Develop."
	},
	labTools: {
		group: "Photo lab",
		name: "Tools",
		user: "Pick a tool and use it on the photo: select, remove marks, heal, copy, lighten, paint.",
		dev: "packages/react/src/photolab/tools.ts; gestureCommand (photolab/gestures.ts) turns a drag, stroke or click into one engine command."
	},
	labSelect: {
		group: "Photo lab",
		name: "Selection buttons",
		user: "Main thing and Sky select for you; Refine edge softens a selection round hair and fur.",
		dev: "select.subject, select.sky, select.focusArea, select.refineEdge, select.inverse, select.deselect, edit.contentAwareFill through Craft.execute."
	},
	labEverything: {
		group: "Photo lab",
		name: "Everything",
		user: "Every filter, adjustment, layer and selection command. Search, click one, set it and press Apply.",
		dev: "Craft.commands() (PhotoCraft's command.list); forms come from each command's parameter text via parseParams (packages/craft/src/params.ts)."
	},
	labLayers: {
		group: "Photo lab",
		name: "Layers",
		user: "Click a layer to work on it; the eye hides it. Opacity and blend apply to the picked layer.",
		dev: "layer.list, layer.select, layer.setProps, layer.new.layer, layer.duplicate, layer.delete, layer.mergeDown, layer.flattenImage."
	},
	labHistory: {
		group: "Photo lab",
		name: "History",
		user: "Every change so far. Click one to go back to it; Redo steps forward again until you change something.",
		dev: "document.inspect's history list; a click runs history.selectState {state}."
	},
	labFiles: {
		group: "Photo lab",
		name: "Open and save files",
		user: "Open a layered file (PSD) or any photo; Save a copy as PSD with layers, or PNG, JPEG, WebP or TIFF.",
		dev: "Craft.openFile / Craft.export (photocraft-io import and export, PSD and PSB included) in packages/craft/src/index.ts."
	}
}, N = [
	{
		name: "Arrange",
		tools: [
			{
				id: "move",
				label: "Move and transform",
				key: "v",
				hint: "Drag a layer to move it. Corners resize (Shift keeps the shape), the round handle turns it. Arrow keys nudge.",
				dev: "Changes layer.transform (x, y, scaleX, scaleY, rotation): packages/canvas/src/geometry.ts. Command: set_layer."
			},
			{
				id: "crop",
				label: "Crop canvas",
				key: "c",
				hint: "Drag the area to keep, then press Enter. Esc cancels.",
				dev: "resizeCanvas in packages/canvas/src/document.ts moves every layer. Command: crop."
			},
			{
				id: "hand",
				label: "Pan",
				key: "h",
				hint: "Drag to move around. Hold Space with any tool to pan.",
				dev: "View only (pan offset in EditMode state); the document is not changed."
			},
			{
				id: "zoom",
				label: "Zoom",
				key: "z",
				hint: "Click to zoom in, Alt-click to zoom out. Ctrl or Cmd with the wheel zooms anywhere.",
				dev: "View only (zoom in EditMode state); the document is not changed."
			}
		]
	},
	{
		name: "Select",
		tools: [
			{
				id: "box",
				label: "Box selection",
				key: "m",
				hint: "Drag a box. Shift adds, Alt takes away, both keep the overlap.",
				dev: "selectRect + combine in packages/canvas/src/selection.ts (a bitmap the size of the canvas). Command: select_rect."
			},
			{
				id: "oval",
				label: "Oval selection",
				key: "m",
				shift: !0,
				hint: "Drag an oval. Shift adds, Alt takes away.",
				dev: "selectEllipse + combine in packages/canvas/src/selection.ts. Command: select_ellipse."
			},
			{
				id: "lasso",
				label: "Lasso",
				key: "l",
				hint: "Draw round what you want. Shift adds, Alt takes away.",
				dev: "selectPolygon + combine in packages/canvas/src/selection.ts. Command: select_polygon."
			},
			{
				id: "wand",
				label: "Magic wand",
				key: "w",
				hint: "Click a colour to select it. Tolerance sets how alike colours must be.",
				dev: "magicWand(picture, at, tolerance, contiguous) in packages/canvas/src/selection.ts. Command: magic_wand."
			}
		]
	},
	{
		name: "Paint",
		tools: [
			{
				id: "brush",
				label: "Brush",
				key: "b",
				hint: "Paint on a picture layer. [ and ] change the size. On a mask it shows the layer.",
				dev: "strokeTo / dab in packages/canvas/src/paint.ts, clipped to the selection; on a mask it paints the mask. Command: brush_stroke."
			},
			{
				id: "eraser",
				label: "Eraser",
				key: "e",
				hint: "Rub out to transparency. On a mask it hides the layer.",
				dev: "strokeTo with erase in packages/canvas/src/paint.ts (alpha to 0, or hides through a mask). Command: brush_stroke with erase."
			},
			{
				id: "clone",
				label: "Clone",
				key: "s",
				hint: "Alt-click where to copy from, then paint where to copy to.",
				dev: "cloneDab in packages/canvas/src/paint.ts, copying from the Alt-clicked offset."
			},
			{
				id: "bucket",
				label: "Fill",
				key: "g",
				hint: "Click to fill a patch of similar colour with the main colour.",
				dev: "floodFill(target, at, colour, tolerance) in packages/canvas/src/paint.ts. Command: flood_fill."
			},
			{
				id: "gradient",
				label: "Gradient",
				key: "g",
				shift: !0,
				hint: "Drag from where the main colour starts to where the second colour ends.",
				dev: "linearGradient in packages/canvas/src/paint.ts, clipped to the selection. Command: gradient."
			},
			{
				id: "dropper",
				label: "Pick colour",
				key: "i",
				hint: "Click to take a colour as the main colour; Alt-click for the second colour.",
				dev: "sample(picture, at) in packages/canvas/src/paint.ts on the flattened picture. Command: set_colours."
			}
		]
	},
	{
		name: "Draw",
		tools: [
			{
				id: "rect",
				label: "Rectangle",
				key: "r",
				hint: "Drag a rectangle (Shift for a square). It stays an editable shape.",
				dev: "Adds a shape layer {shape: \"rect\"} drawn by packages/canvas/src/render.ts. Command: add_shape."
			},
			{
				id: "ellipse",
				label: "Ellipse",
				key: "o",
				hint: "Drag an ellipse (Shift for a circle).",
				dev: "Adds a shape layer {shape: \"ellipse\"}. Command: add_shape."
			},
			{
				id: "line",
				label: "Line",
				key: "n",
				hint: "Drag a line (Shift snaps the angle).",
				dev: "Adds a shape layer {shape: \"line\"}. Command: add_shape."
			},
			{
				id: "pen",
				label: "Pen",
				key: "p",
				hint: "Click for corners, drag for curves. Click the first point to close; Enter finishes an open path.",
				dev: "Builds PathData (pathD in packages/canvas/src/geometry.ts) as a path layer. Command: add_path."
			},
			{
				id: "text",
				label: "Text",
				key: "t",
				hint: "Click to type. Click existing text to change it.",
				dev: "A text layer drawn with measureText/drawLayer in packages/canvas/src/render.ts. Command: add_text."
			}
		]
	}
], P = N.flatMap((e) => e.tools), be = (e) => P.find((t) => t.id === e), F = [
	"size",
	"hardness",
	"opacity",
	"flow"
], I = [
	{
		id: "hand",
		label: "Move around",
		group: "View",
		gesture: "pan",
		options: [],
		hint: "Drag to move around the photo; the wheel zooms. Hold Space with any tool to move around.",
		dev: "View only (zoom and pan in PhotoLab state); nothing is sent to the engine."
	},
	{
		id: "crop",
		label: "Crop",
		group: "View",
		gesture: "box",
		command: "image.crop",
		options: [],
		hint: "Drag the part of the photo to keep. The canvas is cut to it (undo brings it back).",
		dev: "image.crop {x, y, width, height} through Craft.execute (packages/craft/src/index.ts)."
	},
	{
		id: "dropper",
		label: "Pick a colour",
		group: "View",
		gesture: "click",
		command: "document.pixel",
		options: ["colors"],
		hint: "Click the photo to make that colour the paint colour.",
		dev: "document.pixel {x, y} reads the composite; the result becomes the paint colour (tools.setColors)."
	},
	{
		id: "box",
		label: "Box selection",
		group: "Select",
		gesture: "box",
		command: "select.rect",
		options: ["mode"],
		hint: "Drag a box to select. Shift adds to the selection, Alt takes away.",
		dev: "select.rect {x, y, width, height, mode}. The selection is read back with Craft.selection() and drawn as a tint."
	},
	{
		id: "oval",
		label: "Oval selection",
		group: "Select",
		gesture: "box",
		command: "select.rect",
		options: ["mode"],
		hint: "Drag an oval to select. Shift adds, Alt takes away.",
		dev: "select.rect with ellipse: true."
	},
	{
		id: "lasso",
		label: "Lasso",
		group: "Select",
		gesture: "lasso",
		command: "select.lasso",
		options: ["mode"],
		hint: "Draw round what you want to select. Shift adds, Alt takes away.",
		dev: "select.lasso {points, mode}."
	},
	{
		id: "quick",
		label: "Smart brush selection",
		group: "Select",
		gesture: "stroke",
		command: "select.quick",
		options: ["size", "mode"],
		hint: "Paint over a thing and the selection spreads to its edges. Alt paints to take away.",
		dev: "select.quick {points, size, mode}: a graph cut on colour (crates/algo/src/segment in PhotoCraft)."
	},
	{
		id: "object",
		label: "Object selection",
		group: "Select",
		gesture: "box",
		command: "select.object",
		options: ["mode"],
		hint: "Drag a loose box round one thing and it is selected to its outline.",
		dev: "select.object {rect: [x, y, w, h], mode}: GrabCut inside the box."
	},
	{
		id: "wand",
		label: "Colour selection",
		group: "Select",
		gesture: "click",
		command: "select.magicWand",
		options: ["tolerance", "mode"],
		hint: "Click a colour to select it and the touching pixels like it. Tolerance sets how alike.",
		dev: "select.magicWand {x, y, tolerance, mode}."
	},
	{
		id: "remove",
		label: "Remove",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.remove",
		options: ["size"],
		hint: "Paint over a speck, sticker or stand to remove it; drawing round a thing removes what is inside.",
		dev: "paint.remove {points, size}: patch-based completion from the surroundings (no AI, nothing leaves the computer)."
	},
	{
		id: "spot",
		label: "Spot fix",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.spotHealing",
		options: F,
		hint: "Dab dust and small marks away: the texture around them fills in.",
		dev: "paint.spotHealing {points, size, hardness, opacity, flow}."
	},
	{
		id: "heal",
		label: "Heal",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.healingBrush",
		options: F,
		source: !0,
		hint: "Alt-click a clean area, then paint over the mark: the clean texture blends into its light and colour.",
		dev: "paint.healingBrush {points, source: [x, y]}; the Alt-click point is kept in PhotoLab state."
	},
	{
		id: "clone",
		label: "Copy paint",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.cloneStamp",
		options: F,
		source: !0,
		hint: "Alt-click where to copy from, then paint where to copy to.",
		dev: "paint.cloneStamp {points, source: [x, y], aligned: true}."
	},
	{
		id: "redEye",
		label: "Red eye",
		group: "Retouch",
		gesture: "click",
		command: "paint.redEye",
		options: [],
		hint: "Click a red pupil to darken it back to natural.",
		dev: "paint.redEye {x, y}: finds the red pupil round the click and darkens it."
	},
	{
		id: "dodge",
		label: "Lighten by hand",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.dodge",
		options: F,
		hint: "Paint to lighten just those areas.",
		dev: "paint.dodge {points, size, ...}."
	},
	{
		id: "burn",
		label: "Darken by hand",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.burn",
		options: F,
		hint: "Paint to darken just those areas.",
		dev: "paint.burn {points, size, ...}."
	},
	{
		id: "sponge",
		label: "Colour strength",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.sponge",
		options: F,
		hint: "Paint to make colours richer where you paint.",
		dev: "paint.sponge {points, size, ...}."
	},
	{
		id: "soften",
		label: "Soften by hand",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.blur",
		options: F,
		hint: "Paint to soften detail, such as a busy edge.",
		dev: "paint.blur {points, size, ...}."
	},
	{
		id: "crisp",
		label: "Crisp by hand",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.sharpen",
		options: F,
		hint: "Paint to bring out detail where you paint.",
		dev: "paint.sharpen {points, size, ...}."
	},
	{
		id: "smudge",
		label: "Smudge",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.smudge",
		options: F,
		hint: "Drag to push paint along, like a finger in wet paint.",
		dev: "paint.smudge {points, size, ...}."
	},
	{
		id: "shift",
		label: "Move a thing",
		group: "Retouch",
		gesture: "line",
		command: "paint.contentAwareMove",
		options: [],
		needsSelection: !0,
		hint: "Select a thing first, then drag it somewhere else: the gap it leaves fills in.",
		dev: "paint.contentAwareMove {offset: [dx, dy]} on the current selection."
	},
	{
		id: "patch",
		label: "Patch",
		group: "Retouch",
		gesture: "line",
		command: "paint.patch",
		options: [],
		needsSelection: !0,
		hint: "Select a mark first, then drag to a clean area: the selection is repaired from there.",
		dev: "paint.patch {offset: [dx, dy], mode: \"source\"} on the current selection."
	},
	{
		id: "brush",
		label: "Brush",
		group: "Paint",
		gesture: "stroke",
		command: "paint.stroke",
		options: [...F, "colors"],
		hint: "Paint with the paint colour. [ and ] change the size.",
		dev: "paint.stroke {points, size, hardness, opacity, flow, color}."
	},
	{
		id: "pencil",
		label: "Pencil",
		group: "Paint",
		gesture: "stroke",
		command: "paint.pencil",
		options: [
			"size",
			"opacity",
			"colors"
		],
		hint: "Hard-edged lines, pixel exact.",
		dev: "paint.pencil {points, size, opacity, color}."
	},
	{
		id: "eraser",
		label: "Eraser",
		group: "Paint",
		gesture: "stroke",
		command: "paint.stroke",
		options: F,
		hint: "Rub out to see-through.",
		dev: "paint.stroke with erase: true."
	},
	{
		id: "bgEraser",
		label: "Background eraser",
		group: "Paint",
		gesture: "stroke",
		command: "paint.backgroundEraser",
		options: [
			"size",
			"hardness",
			"tolerance"
		],
		hint: "Paint along an edge: the colour under the centre is rubbed out, the thing beside it stays.",
		dev: "paint.backgroundEraser {points, size, hardness, tolerance}."
	},
	{
		id: "magicEraser",
		label: "Erase a colour",
		group: "Paint",
		gesture: "click",
		command: "paint.magicEraser",
		options: ["tolerance"],
		hint: "Click a plain background to rub out that colour in one go.",
		dev: "paint.magicEraser {x, y, tolerance}."
	},
	{
		id: "bucket",
		label: "Fill",
		group: "Paint",
		gesture: "click",
		command: "paint.bucket",
		options: ["tolerance", "colors"],
		hint: "Click to fill a patch of similar colour with the paint colour.",
		dev: "paint.bucket {x, y, tolerance, color}."
	},
	{
		id: "gradient",
		label: "Gradient",
		group: "Paint",
		gesture: "line",
		command: "paint.gradient",
		options: ["colors"],
		hint: "Drag from where the paint colour starts to where the second colour ends.",
		dev: "paint.gradient {from, to, colors: [paint, second]}."
	},
	{
		id: "mixer",
		label: "Wet paint",
		group: "Paint",
		gesture: "stroke",
		command: "paint.mixerBrush",
		options: ["size", "colors"],
		hint: "Paint that mixes with the colours already there.",
		dev: "paint.mixerBrush {points, size, color}."
	},
	{
		id: "recolour",
		label: "Recolour",
		group: "Paint",
		gesture: "stroke",
		command: "paint.colorReplacement",
		options: [
			"size",
			"tolerance",
			"colors"
		],
		hint: "Paint over a colour to swap it for the paint colour, keeping its shading.",
		dev: "paint.colorReplacement {points, size, tolerance, color}."
	}
], xe = [
	"View",
	"Select",
	"Retouch",
	"Paint"
], Se = [
	{
		id: "replace",
		label: "New"
	},
	{
		id: "add",
		label: "Add (Shift)"
	},
	{
		id: "subtract",
		label: "Take away (Alt)"
	},
	{
		id: "intersect",
		label: "Overlap"
	}
], L = "gleamshelf:dev-notes", R = /* @__PURE__ */ new Set(), z = (() => {
	try {
		return localStorage.getItem(L) === "1";
	} catch {
		return !1;
	}
})();
function Ce(e) {
	z = e;
	try {
		localStorage.setItem(L, e ? "1" : "0");
	} catch {}
	for (let e of R) e();
}
function B() {
	return p((e) => (R.add(e), () => R.delete(e)), () => z, () => !1);
}
function we({ text: e }) {
	return B() ? /* @__PURE__ */ h("span", {
		className: "gs-devnote",
		children: e
	}) : null;
}
function V({ id: e, inline: t }) {
	let n = B(), r = M[e];
	return t ? /* @__PURE__ */ g("span", {
		className: "gs-help",
		children: [/* @__PURE__ */ h("span", {
			className: "gs-howto",
			children: r.user
		}), n && /* @__PURE__ */ h("span", {
			className: "gs-devnote",
			children: r.dev
		})]
	}) : /* @__PURE__ */ g("div", {
		className: "gs-help",
		children: [/* @__PURE__ */ h("p", {
			className: "gs-howto",
			children: r.user
		}), n && /* @__PURE__ */ h("p", {
			className: "gs-devnote",
			children: r.dev
		})]
	});
}
function H() {
	let e = B();
	return /* @__PURE__ */ g("label", {
		className: "gs-control gs-control--inline gs-devswitch",
		children: [/* @__PURE__ */ h("input", {
			type: "checkbox",
			checked: e,
			onChange: (e) => Ce(e.target.checked)
		}), "Developer notes"]
	});
}
function Te({ onClose: e }) {
	let t = B();
	u(() => {
		let t = (t) => {
			t.key === "Escape" && (t.stopPropagation(), e());
		};
		return window.addEventListener("keydown", t, !0), () => window.removeEventListener("keydown", t, !0);
	}, [e]);
	let n = Object.values(M);
	return /* @__PURE__ */ h("div", {
		className: "gs-guide",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Guide",
		onClick: e,
		children: /* @__PURE__ */ g("div", {
			className: "gs-guide__sheet",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ g("header", {
				className: "gs-guide__head",
				children: [
					/* @__PURE__ */ h("h2", { children: "Guide" }),
					/* @__PURE__ */ h(H, {}),
					/* @__PURE__ */ h("button", {
						type: "button",
						className: "gs-icon-button",
						onClick: e,
						"aria-label": "Close the guide",
						children: /* @__PURE__ */ h($, { name: "close" })
					})
				]
			}), /* @__PURE__ */ h("div", {
				className: "gs-guide__body",
				children: ye.map((e) => /* @__PURE__ */ g("section", { children: [
					/* @__PURE__ */ h("h3", { children: e }),
					/* @__PURE__ */ h("dl", { children: n.filter((t) => t.group === e).map((e) => /* @__PURE__ */ g("div", {
						className: "gs-guide__item",
						children: [
							/* @__PURE__ */ h("dt", { children: e.name }),
							/* @__PURE__ */ h("dd", { children: e.user }),
							t && /* @__PURE__ */ h("dd", {
								className: "gs-devnote",
								children: e.dev
							})
						]
					}, e.name)) }),
					e === "Photo lab" && /* @__PURE__ */ h("dl", { children: I.map((e) => /* @__PURE__ */ g("div", {
						className: "gs-guide__item",
						children: [
							/* @__PURE__ */ h("dt", { children: e.label }),
							/* @__PURE__ */ h("dd", { children: e.hint }),
							t && /* @__PURE__ */ h("dd", {
								className: "gs-devnote",
								children: e.dev
							})
						]
					}, e.id)) }),
					e === "Edit mode" && /* @__PURE__ */ h("dl", { children: P.map((e) => /* @__PURE__ */ g("div", {
						className: "gs-guide__item",
						children: [
							/* @__PURE__ */ g("dt", { children: [
								e.label,
								" ",
								/* @__PURE__ */ h("kbd", { children: e.shift ? `Shift+${e.key.toUpperCase()}` : e.key.toUpperCase() })
							] }),
							/* @__PURE__ */ h("dd", { children: e.hint }),
							t && /* @__PURE__ */ h("dd", {
								className: "gs-devnote",
								children: e.dev
							})
						]
					}, e.id)) })
				] }, e))
			})]
		})
	});
}
//#endregion
//#region src/Panel.tsx
var Ee = [
	{
		tool: "tap",
		label: "Tap",
		title: "Tap the background to remove everything of a similar colour around that point"
	},
	{
		tool: "erase",
		label: "Erase",
		title: "Paint over what should be removed"
	},
	{
		tool: "restore",
		label: "Restore",
		title: "Paint over what should come back"
	}
];
function De({ editor: e, doc: t, cutout: n, onToggleCutout: r, cutSettings: i, onCutSettings: a, aiCutout: o, flatten: s }) {
	let c = t.recipe.mask.length > 0, l = t.recipe.mask.some((e) => e.kind === "green");
	return /* @__PURE__ */ g("section", { children: [
		/* @__PURE__ */ h("h2", { children: "Background" }),
		/* @__PURE__ */ h("div", {
			className: "gs-crop-tools",
			children: /* @__PURE__ */ h("button", {
				type: "button",
				className: "gs-button",
				disabled: l,
				onClick: () => e.removeGreenBackdrop(),
				title: "For photos shot on a green cloth or screen: makes the green transparent in one click. Free.",
				children: l ? "Green removed" : "Remove green backdrop"
			})
		}),
		/* @__PURE__ */ h(V, { id: "green" }),
		/* @__PURE__ */ g("div", {
			className: "gs-crop-tools",
			children: [/* @__PURE__ */ h("button", {
				type: "button",
				className: `gs-button ${n ? "gs-button--primary" : ""}`,
				onClick: r,
				children: n ? "Done" : c ? "Edit cut-out" : "Cut out product"
			}), c && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
				type: "button",
				className: "gs-button",
				onClick: () => e.fadeBottom(.1),
				title: "Fade the bottom edge of the cut-out out softly, instead of ending in a hard line (good for a figure cut off at the waist)",
				children: "Fade bottom"
			}), /* @__PURE__ */ h("button", {
				type: "button",
				className: "gs-button",
				onClick: () => e.clearMask(),
				title: "Bring back the whole photo",
				children: "Clear"
			})] })]
		}),
		!n && /* @__PURE__ */ h(V, { id: "cutManual" }),
		!n && c && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(V, { id: "fade" }), /* @__PURE__ */ h(V, { id: "clearMask" })] }),
		n && /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("div", {
				className: "gs-segmented",
				role: "group",
				"aria-label": "Cut-out tool",
				children: Ee.map(({ tool: e, label: t, title: n }) => /* @__PURE__ */ h("button", {
					type: "button",
					className: `gs-button ${i.tool === e ? "is-active" : ""}`,
					"aria-pressed": i.tool === e,
					title: n,
					onClick: () => a({ tool: e }),
					children: t
				}, e))
			}),
			/* @__PURE__ */ h(V, { id: `cut.${i.tool}` }),
			i.tool === "tap" ? /* @__PURE__ */ g("label", {
				className: "gs-control",
				children: [/* @__PURE__ */ g("span", {
					className: "gs-control__row",
					children: [/* @__PURE__ */ h("span", { children: "Tolerance" }), /* @__PURE__ */ h("output", { children: i.tolerance })]
				}), /* @__PURE__ */ h("input", {
					type: "range",
					style: Q(i.tolerance, 1, 100),
					min: 1,
					max: 100,
					step: 1,
					value: i.tolerance,
					onChange: (e) => a({ tolerance: Number(e.target.value) })
				})]
			}) : /* @__PURE__ */ g("label", {
				className: "gs-control",
				children: [/* @__PURE__ */ g("span", {
					className: "gs-control__row",
					children: [/* @__PURE__ */ h("span", { children: "Brush size" }), /* @__PURE__ */ g("output", { children: [Math.round(i.brush * 1e3) / 10, "%"] })]
				}), /* @__PURE__ */ h("input", {
					type: "range",
					style: Q(i.brush, .003, .08),
					min: .003,
					max: .08,
					step: .001,
					value: i.brush,
					onChange: (e) => a({ brush: Number(e.target.value) })
				})]
			})
		] }),
		o,
		s && c && !n && /* @__PURE__ */ g("div", {
			className: "gs-control",
			children: [
				/* @__PURE__ */ h("button", {
					type: "button",
					className: "gs-button",
					disabled: s.busy,
					onClick: s.run,
					title: "For a trading card, a box's front or a print photographed at an angle: pulls its four corners straight",
					children: s.busy ? "Straightening…" : "Flatten card or box front"
				}),
				s.note && /* @__PURE__ */ h("p", {
					className: "gs-hint",
					children: s.note
				}),
				/* @__PURE__ */ h(V, { id: "flatten" })
			]
		})
	] });
}
var Oe = [
	{
		key: "lightness",
		label: "How white",
		min: 150,
		max: 255,
		step: 1,
		help: "Lower catches creamier lettering. Too low starts to catch light parts of the picture."
	},
	{
		key: "maxWidth",
		label: "Thickest stroke",
		min: 4,
		max: 80,
		step: 1,
		help: "Fatter white shapes (a bow, a pompom) are left alone."
	},
	{
		key: "minLength",
		label: "Shortest piece",
		min: 5,
		max: 200,
		step: 1,
		help: "Smaller white specks (a glint in an eye) are left alone."
	}
];
function ke({ lookup: e }) {
	let t = {
		found: "✓ Product found online",
		"no-match": "✗ Product not found online",
		"no-pictures": "✗ Product not found online",
		off: "– Web lookup not used"
	}[e.state];
	return /* @__PURE__ */ g("div", {
		className: `gs-lookup is-${e.state}`,
		role: "status",
		children: [
			/* @__PURE__ */ h("strong", { children: t }),
			e.read && /* @__PURE__ */ g("span", {
				className: "gs-hint",
				children: [" · the cover reads: ", e.read]
			}),
			/* @__PURE__ */ h("p", {
				className: "gs-hint",
				children: e.detail
			}),
			e.state === "no-match" || e.state === "no-pictures" ? /* @__PURE__ */ h("p", {
				className: "gs-hint",
				children: "The picture was finished without it. For this product you can give the batch command official pictures with --ref-dir."
			}) : null
		]
	});
}
var Ae = (e) => {
	try {
		return e ? new URL(e).hostname.replace(/^www\./, "") : null;
	} catch {
		return null;
	}
}, je = 20;
function U({ found: e }) {
	let t = e.photos.filter((e) => e.linesUp), n = e.photos.filter((e) => !e.linesUp), [r, i] = f(je), a = d(e);
	a.current = e;
	let o = e.waiting;
	u(() => {
		if (!o || r === null) return;
		if (r <= 0) {
			let e = a.current;
			e.photos.some((e) => e.linesUp) && e.ticked.length ? e.use() : e.skip();
			return;
		}
		let e = setTimeout(() => i((e) => e === null ? null : e - 1), 1e3);
		return () => clearTimeout(e);
	}, [o, r]);
	let s = d(null);
	u(() => {
		o && s.current?.scrollIntoView({
			behavior: "smooth",
			block: "start"
		});
	}, [o]);
	let c = e.identity ? [
		e.identity.character,
		e.identity.printedTitle,
		e.identity.variant
	].filter(Boolean).join(" · ") : null, l = (t) => {
		let n = Ae(t.page), r = e.ticked.includes(t.index);
		return /* @__PURE__ */ g("li", {
			className: `gs-found__card ${r ? "is-on" : ""} ${t.linesUp ? "" : "is-off"}`,
			children: [/* @__PURE__ */ g("label", { children: [t.thumb ? /* @__PURE__ */ h("img", {
				src: t.thumb,
				alt: t.title ?? "A picture found online"
			}) : /* @__PURE__ */ h("span", {
				className: "gs-found__blank",
				"aria-hidden": "true"
			}), /* @__PURE__ */ g("span", {
				className: "gs-found__meta",
				children: [t.linesUp ? /* @__PURE__ */ h("input", {
					type: "checkbox",
					checked: r,
					disabled: !e.waiting,
					onChange: () => {
						i(null), e.toggle(t.index);
					},
					"aria-label": `Use this picture${t.title ? `: ${t.title}` : ""}`
				}) : null, /* @__PURE__ */ h("span", {
					className: `gs-found__badge ${t.linesUp ? "is-match" : ""}`,
					children: t.linesUp ? t.shows === "figure" ? "The figure: fills what the print hides" : "The box: for colours" : "Doesn't line up"
				})]
			})] }), n && /* @__PURE__ */ h("a", {
				href: t.page,
				target: "_blank",
				rel: "noreferrer",
				className: "gs-found__source",
				title: t.title ?? t.page,
				children: n
			})]
		}, t.index);
	};
	return /* @__PURE__ */ g("div", {
		className: "gs-found",
		role: "region",
		"aria-label": "Pictures found online",
		ref: s,
		children: [
			/* @__PURE__ */ g("div", {
				className: "gs-found__head",
				children: [/* @__PURE__ */ h("strong", { children: e.waiting ? "Found online" : `Using ${e.ticked.length} of ${t.length} found online` }), c && /* @__PURE__ */ h("span", {
					className: "gs-hint",
					children: c
				})]
			}),
			e.waiting && /* @__PURE__ */ h(V, { id: "foundPhotos" }),
			t.length ? /* @__PURE__ */ h("ul", {
				className: "gs-found__grid",
				children: t.map(l)
			}) : /* @__PURE__ */ h("p", {
				className: "gs-hint",
				children: "None of these lines up with your photo, so none can be used to finish it."
			}),
			n.length > 0 && /* @__PURE__ */ g("details", {
				className: "gs-found__more",
				children: [/* @__PURE__ */ g("summary", { children: [
					n.length,
					" more ",
					n.length === 1 ? "doesn't" : "don't",
					" line up with your photo"
				] }), /* @__PURE__ */ h("ul", {
					className: "gs-found__grid",
					children: n.slice(0, 12).map(l)
				})]
			}),
			e.waiting && r !== null && /* @__PURE__ */ g("p", {
				className: "gs-found__countdown",
				role: "status",
				children: [
					t.length && e.ticked.length ? `Going on with the ${e.ticked.length} that line up in ${r} s.` : `Going on without them in ${r} s.`,
					" ",
					/* @__PURE__ */ h("button", {
						type: "button",
						className: "gs-link",
						onClick: () => i(null),
						children: "Let me choose"
					})
				]
			}),
			e.waiting && /* @__PURE__ */ g("div", {
				className: "gs-found__actions",
				children: [/* @__PURE__ */ g("button", {
					type: "button",
					className: "gs-button gs-button--primary",
					onClick: e.use,
					disabled: !t.length || !e.ticked.length,
					children: [
						"Use ",
						e.ticked.length,
						" ",
						e.ticked.length === 1 ? "picture" : "pictures",
						" and continue"
					]
				}), /* @__PURE__ */ h("button", {
					type: "button",
					className: "gs-button",
					onClick: e.skip,
					children: "Continue without them"
				})]
			})
		]
	});
}
var W = (e) => {
	let t = Math.max(0, Math.round(e));
	return t < 60 ? `${t}s` : `${Math.floor(t / 60)}:${String(t % 60).padStart(2, "0")}`;
};
function Me(e) {
	let t = (e) => {
		try {
			return new URL(e).hostname.replace(/^www\./, "");
		} catch {
			return "a page";
		}
	}, n = (e) => e.length > 60 ? `${e.slice(0, 60)}…` : e, r = /^(search|picture search|page|picture): (.*)$/.exec(e);
	if (!r) return `Looking it up: ${n(e)}`;
	let [, i, a] = r;
	return i === "search" ? a.startsWith("(") ? "Found before: no web requests needed" : `Searching the web for “${n(a)}”` : i === "picture search" ? `Searching for pictures of “${n(a)}”` : i === "page" ? `Reading a page on ${t(a)}` : `Checking a picture from ${t(a.split(" ")[0])}`;
}
var G = (e) => e < 1.5 ? `${Math.round(e * 100)}% of a processor core` : `${e.toFixed(1).replace(/\.0$/, "")} processor cores busy`, K = (e) => e.health ? e.health.now + (Date.now() - e.receivedAt) : Date.now(), Ne = {
	slow: 25,
	stuck: 75
}, Pe = {
	slow: 60,
	stuck: 180
};
function Fe({ watch: e }) {
	let [, t] = f(0);
	u(() => {
		let e = setInterval(() => t((e) => e + 1), 1e3);
		return () => clearInterval(e);
	}, []);
	let n = e.health, r = "ok", i;
	if (e.unanswered >= 2) r = "stuck", i = `The Gleamshelf app is not answering (${e.unanswered} tries). Is it still running? If it was closed, start it again with npm run local:start.`;
	else if (e.queued || !n) i = e.queued ? "Waiting for the app to finish another job first" : "Starting";
	else {
		let t = (K(e) - n.lastActivity) / 1e3, a = n.models === "working" ? Pe : Ne, o = n.modelJob ? Le[n.modelJob] ?? n.modelJob : "an AI model";
		t >= a.stuck ? (r = "stuck", i = n.models === "working" ? `Nothing has happened for ${W(t)}: ${o} looks stuck. Stop it and try again; if it happens again, restart the Gleamshelf app.` : `Nothing has happened for ${W(t)}: the run looks stuck. Stop it and try again; if it happens again, restart the Gleamshelf app.`) : t >= a.slow ? (r = "slow", i = `No sign of work for ${W(t)}${n.models === "working" ? ` (${o} may be thinking on the GPU)` : ""}. Still waiting.`) : i = n.models === "starting" ? "Loading the AI models into memory (the first run after a while can take a minute)" : n.models === "working" ? `${o[0].toUpperCase()}${o.slice(1)} is at work${n.cpu.models === null ? "" : ` · ${G(n.cpu.models)}`}` : n.detail ? Me(n.detail) : n.cpu.app > .1 ? `Working on this computer · ${G(n.cpu.app)}` : "Working";
	}
	return /* @__PURE__ */ g("div", {
		className: `gs-health gs-health--${r}`,
		role: "status",
		"aria-live": "polite",
		children: [
			/* @__PURE__ */ h("span", {
				className: "gs-health__dot",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ g("span", {
				className: "gs-health__text",
				children: [i, n && /* @__PURE__ */ g("span", {
					className: "gs-health__total",
					children: [
						" · ",
						W((K(e) - n.startedAt) / 1e3),
						" in all"
					]
				})]
			}),
			/* @__PURE__ */ h("button", {
				type: "button",
				className: "gs-button gs-health__stop",
				onClick: e.stop,
				title: "Stop this run (nothing is changed)",
				children: "Stop"
			})
		]
	});
}
function Ie(e) {
	return /not answering|stopped answering|fetch|network|ECONNREFUSED/i.test(e) ? "The Gleamshelf app on this computer is not running or was closed. Start it with npm run local:start, then try again." : /not installed|install/i.test(e) ? "A model it needs is missing: npm run models lists them and how to install each." : /took over|too long|timed? ?out/i.test(e) ? "The computer may have been busy with something else. Close other heavy apps and try again." : /model server|python/i.test(e) ? "The AI model process had a problem. Try again; if it keeps happening, restart the Gleamshelf app." : "Try again. If it keeps failing, restart the Gleamshelf app; the error above says what went wrong.";
}
var Le = {
	ask: "the vision model",
	figure: "SAM (finding the figure)",
	redraw: "Stable Diffusion",
	enhance: "Stable Diffusion"
};
function Re({ auto: e, listingSet: t, hasCutout: n }) {
	let r = {
		todo: "·",
		running: "…",
		done: "✓",
		skipped: "–"
	}, i = e.full, [a, o] = f(!1), s = d(null), c = i?.report;
	u(() => {
		c && s.current?.scrollIntoView({
			behavior: "smooth",
			block: "start"
		});
	}, [c]);
	let l = i?.report?.listing ? `${i.report.listing.title}\n\nCategory: ${i.report.listing.category}\nSeries: ${i.report.listing.series ?? "(not found)"}\n\n${i.report.listing.description}${i.report.listing.highlights.length ? `\n\n${i.report.listing.highlights.map((e) => `- ${e}`).join("\n")}` : ""}` : "";
	return /* @__PURE__ */ g("section", { children: [
		/* @__PURE__ */ h("h2", { children: "One click" }),
		/* @__PURE__ */ h("button", {
			type: "button",
			className: "gs-button gs-button--primary gs-auto__button",
			disabled: e.busy || !!i && !i.available,
			onClick: e.run,
			title: "Cut out, remove lettering, brighten and sharpen, enlarge, and finish as a white square photo",
			children: e.busy ? "Working…" : "Make it listing-ready"
		}),
		/* @__PURE__ */ h(V, { id: "autoRun" }),
		/* @__PURE__ */ g("div", {
			className: "gs-segmented",
			role: "group",
			"aria-label": "What to cut out",
			children: [
				/* @__PURE__ */ h("button", {
					type: "button",
					className: `gs-button ${e.mode === "product" ? "is-active" : ""}`,
					"aria-pressed": e.mode === "product",
					disabled: e.busy,
					onClick: () => e.setMode("product"),
					title: "Keep the whole box or product",
					children: "Whole box"
				}),
				/* @__PURE__ */ h("button", {
					type: "button",
					className: `gs-button ${e.mode === "character" ? "is-active" : ""}`,
					"aria-pressed": e.mode === "character",
					disabled: e.busy,
					onClick: () => e.setMode("character"),
					title: "Keep only the character in the artwork on the cover",
					children: "Character on cover"
				}),
				i && /* @__PURE__ */ h("button", {
					type: "button",
					className: `gs-button ${e.mode === "auto" ? "is-active" : ""}`,
					"aria-pressed": e.mode === "auto",
					disabled: e.busy,
					onClick: () => e.setMode("auto"),
					title: "The character for a flat front cover, the whole box for a box seen at an angle",
					children: "Auto"
				})
			]
		}),
		/* @__PURE__ */ h(V, { id: "autoMode" }),
		i && /* @__PURE__ */ g("details", {
			className: "gs-steps-box",
			children: [/* @__PURE__ */ g("summary", { children: [
				"Steps: ",
				i.steps.filter((e) => e.on && !e.disabled).length,
				" of ",
				i.steps.length,
				" on (untick to skip)"
			] }), /* @__PURE__ */ h("fieldset", {
				className: "gs-steps",
				disabled: e.busy,
				children: i.steps.map((t) => /* @__PURE__ */ g("label", {
					className: "gs-control gs-control--inline",
					title: t.title,
					children: [/* @__PURE__ */ h("input", {
						type: "checkbox",
						checked: t.on && !t.disabled,
						disabled: e.busy || t.disabled,
						onChange: (e) => i.setStep(t.key, e.target.checked)
					}), /* @__PURE__ */ g("span", { children: [t.label, /* @__PURE__ */ h(V, {
						id: `step.${t.key}`,
						inline: !0
					})] })]
				}, t.key))
			})]
		}),
		e.detail?.available && !i && /* @__PURE__ */ g("label", {
			className: "gs-control gs-control--inline",
			title: "Re-draws the picture slightly with Stable Diffusion, pinned to the original shapes, so hair, fabric and edges come back crisper. Free, on your computer, about a minute. Colours are kept.",
			children: [/* @__PURE__ */ h("input", {
				type: "checkbox",
				checked: e.detail.on,
				disabled: e.busy,
				onChange: (t) => e.detail.set(t.target.checked)
			}), "Extra detail (slower, about 1 more minute)"]
		}),
		e.gloss?.available && !i && /* @__PURE__ */ g("label", {
			className: "gs-control gs-control--inline",
			title: "Redraws the product as a glossy studio pack shot with Stable Diffusion, free, on your computer, about a minute. It changes the product itself: finish, small details and printed text may no longer match the real item.",
			children: [/* @__PURE__ */ h("input", {
				type: "checkbox",
				checked: e.gloss.on,
				disabled: e.busy,
				onChange: (t) => e.gloss.set(t.target.checked)
			}), "Studio gloss (changes the product; off unless ticked)"]
		}),
		/* @__PURE__ */ g("p", {
			className: "gs-hint",
			children: [i ? "Runs on this computer; the finished picture opens here. " : e.greenBackdrop ? "Green backdrop found: it is removed for free. " : e.appReady ? "" : "For anything but a green backdrop, start the Gleamshelf app first (see AI cut-out in the Cut out tab). ", !i && "Every step stays adjustable in the other tabs, and Undo steps back one at a time."]
		}),
		e.steps && /* @__PURE__ */ h("ul", {
			className: "gs-auto__steps",
			children: e.steps.map((t) => /* @__PURE__ */ g("li", {
				className: `is-${t.state}`,
				children: [
					/* @__PURE__ */ h("span", {
						"aria-hidden": "true",
						children: t.state === "running" && e.watch ? /* @__PURE__ */ h("span", { className: "gs-spin" }) : r[t.state]
					}),
					" ",
					t.label.charAt(0).toUpperCase() + t.label.slice(1),
					t.state === "done" && t.seconds !== void 0 && /* @__PURE__ */ h("span", {
						className: "gs-auto__time",
						children: W(t.seconds)
					}),
					t.state === "running" && e.watch?.health && t.startedAt !== void 0 && /* @__PURE__ */ h("span", {
						className: "gs-auto__time",
						children: W((K(e.watch) - t.startedAt) / 1e3)
					}),
					t.note && /* @__PURE__ */ g("span", {
						className: "gs-hint",
						children: [" · ", t.note]
					})
				]
			}, t.label))
		}),
		i?.found && /* @__PURE__ */ h(U, { found: i.found }),
		e.busy && e.watch && !i?.found?.waiting && /* @__PURE__ */ h(Fe, { watch: e.watch }),
		!e.busy && e.end && /* @__PURE__ */ g("div", {
			className: `gs-runend gs-runend--${e.end.kind}`,
			role: e.end.kind === "failed" ? "alert" : "status",
			children: [
				/* @__PURE__ */ h("strong", { children: e.end.kind === "failed" ? "This run did not finish" : "Stopped" }),
				/* @__PURE__ */ h("p", { children: e.end.message.charAt(0).toUpperCase() + e.end.message.slice(1) }),
				e.end.kind === "failed" && !/npm run/.test(e.end.message) && /* @__PURE__ */ h("p", {
					className: "gs-hint",
					children: Ie(e.end.message)
				}),
				/* @__PURE__ */ g("div", {
					className: "gs-runend__actions",
					children: [/* @__PURE__ */ h("button", {
						type: "button",
						className: "gs-button gs-button--primary",
						onClick: e.run,
						children: "Try again"
					}), e.dismissEnd && /* @__PURE__ */ h("button", {
						type: "button",
						className: "gs-button",
						onClick: e.dismissEnd,
						children: "Dismiss"
					})]
				})
			]
		}),
		i?.report && /* @__PURE__ */ g("div", {
			className: "gs-auto__report",
			ref: s,
			children: [
				/* @__PURE__ */ h(V, { id: "autoReport" }),
				i.report.lookup && /* @__PURE__ */ h(ke, { lookup: i.report.lookup }),
				(i.report.health || i.report.quality) && /* @__PURE__ */ h(Ve, {
					health: i.report.health,
					quality: i.report.quality,
					changesUrl: i.report.changesUrl
				}),
				i.report.flags.length > 0 && /* @__PURE__ */ h("ul", {
					className: "gs-auto__flags",
					"aria-label": "Worth a look",
					children: i.report.flags.map((e) => /* @__PURE__ */ h("li", { children: e }, e))
				}),
				i.report.listing && /* @__PURE__ */ g("div", {
					className: "gs-listing",
					children: [
						/* @__PURE__ */ h("h3", { children: "Listing" }),
						/* @__PURE__ */ h("strong", {
							className: "gs-listing__title",
							children: i.report.listing.title
						}),
						/* @__PURE__ */ g("p", {
							className: "gs-hint",
							children: [i.report.listing.category, i.report.listing.series ? ` · ${i.report.listing.series}` : ""]
						}),
						/* @__PURE__ */ h("p", {
							className: "gs-listing__description",
							children: i.report.listing.description
						}),
						i.report.listing.highlights.length > 0 && /* @__PURE__ */ h("ul", {
							className: "gs-listing__highlights",
							children: i.report.listing.highlights.map((e) => /* @__PURE__ */ h("li", { children: e }, e))
						}),
						i.report.listing.unsupported.length > 0 && /* @__PURE__ */ g("p", {
							className: "gs-hint",
							children: ["Not found, add by hand: ", i.report.listing.unsupported.join("; ")]
						}),
						i.report.listing.unverifiedNumbers.length > 0 && /* @__PURE__ */ g("p", {
							className: "gs-hint gs-auto__flags",
							children: ["Check these numbers, no source gave them: ", i.report.listing.unverifiedNumbers.join(", ")]
						}),
						/* @__PURE__ */ h("button", {
							type: "button",
							className: "gs-button",
							onClick: () => void navigator.clipboard.writeText(`${i.report.listing.title}\n\n${l.split("\n\n").slice(1).join("\n\n")}`).then(() => o(!0), () => o(!1)),
							children: a ? "Copied" : "Copy title and description"
						})
					]
				}),
				t && /* @__PURE__ */ g("div", {
					className: "gs-listing",
					children: [/* @__PURE__ */ h("h3", { children: "Every marketplace" }), /* @__PURE__ */ h(Y, {
						...t,
						hasCutout: n
					})]
				}),
				i.shop && i.report.runId && /* @__PURE__ */ h(Be, {
					shop: i.shop,
					runId: i.report.runId
				}),
				i.makeAd && /* @__PURE__ */ h(ze, { make: i.makeAd }),
				i.report.notes.length > 0 && /* @__PURE__ */ g("details", {
					className: "gs-auto__notes",
					children: [/* @__PURE__ */ g("summary", { children: [
						"What the run did (",
						i.report.notes.length,
						" notes)"
					] }), i.report.notes.map((e) => /* @__PURE__ */ h("p", {
						className: "gs-hint",
						children: e.charAt(0).toUpperCase() + e.slice(1)
					}, e))]
				})
			]
		}),
		i?.goBack && /* @__PURE__ */ h("button", {
			type: "button",
			className: "gs-button",
			onClick: i.goBack,
			title: "Close this picture and open the photo as it was",
			children: "Back to the original photo"
		}),
		i?.goBack && /* @__PURE__ */ h(V, { id: "autoBack" }),
		i?.recent && i.recent.runs.length > 0 && !e.busy && /* @__PURE__ */ g("details", {
			className: "gs-recent",
			children: [
				/* @__PURE__ */ g("summary", { children: [
					"Recent results (",
					i.recent.runs.length,
					")"
				] }),
				/* @__PURE__ */ h("ul", { children: i.recent.runs.map((e) => /* @__PURE__ */ h("li", { children: /* @__PURE__ */ g("button", {
					type: "button",
					onClick: () => i.recent.open(e.id),
					title: "Open this finished picture and its listing again, instantly",
					children: [
						e.thumb ? /* @__PURE__ */ h("img", {
							src: e.thumb,
							alt: ""
						}) : /* @__PURE__ */ h("span", { className: "gs-recent__blank" }),
						/* @__PURE__ */ h("span", {
							className: "gs-recent__title",
							children: e.title
						}),
						/* @__PURE__ */ g("span", {
							className: "gs-hint",
							children: [e.health === null ? "" : `${e.health}/100 · `, new Date(e.finishedAt).toLocaleString([], {
								month: "short",
								day: "numeric",
								hour: "2-digit",
								minute: "2-digit"
							})]
						})
					]
				}) }, e.id)) }),
				/* @__PURE__ */ h(V, { id: "recentRuns" })
			]
		})
	] });
}
var q = (e) => {
	try {
		return new URL(e).host;
	} catch {
		return e;
	}
};
function ze({ make: e }) {
	let [t, n] = f(!1), [r, i] = f(null);
	return /* @__PURE__ */ g("div", {
		className: "gs-listing",
		children: [
			/* @__PURE__ */ h("h3", { children: "3D ad" }),
			/* @__PURE__ */ h("p", {
				className: "gs-hint",
				children: "The product on a stage with its name, the price and your logo, moving: for posts, banners and short videos."
			}),
			/* @__PURE__ */ h("div", {
				className: "gs-button-row",
				children: /* @__PURE__ */ h("button", {
					type: "button",
					className: "gs-button",
					disabled: t,
					onClick: () => {
						n(!0), i(null), e().catch((e) => i(e instanceof Error ? e.message : "The ad maker could not open.")).finally(() => n(!1));
					},
					children: t ? "Opening…" : "Make a 3D ad"
				})
			}),
			r && /* @__PURE__ */ h("p", {
				className: "gs-hint",
				children: r
			}),
			/* @__PURE__ */ h(V, { id: "makeAd" })
		]
	});
}
function Be({ shop: e, runId: t }) {
	let [n, r] = f(null), [i, a] = f(""), [o, s] = f(""), [c, l] = f(!1), [d, p] = f(null);
	u(() => {
		let t = !1;
		return e.status().then((e) => !t && r(e), () => !t && r({ connected: !1 })), () => {
			t = !0;
		};
	}, [e]), u(() => p(null), [t]);
	let _ = (e) => p({
		ok: !1,
		text: e instanceof Error ? e.message : "That did not work."
	}), v = async () => {
		l(!0), p(null);
		try {
			let t = await e.connect(i, o);
			r({
				connected: !0,
				url: t.url,
				label: t.label,
				answering: !0
			}), s("");
		} catch (e) {
			_(e);
		} finally {
			l(!1);
		}
	}, y = async () => {
		l(!0), p(null);
		try {
			let n = await e.send(t);
			p({
				ok: !0,
				text: n.sent === "new" ? `Sent: it waits in ${q(n.shop)} › Imports for a price and stock.` : n.sent === "replaced" ? "Sent again: its earlier draft in Imports was replaced." : `The shop already has this photo (${n.status}), so it was left as it is.`
			});
		} catch (e) {
			_(e);
		} finally {
			l(!1);
		}
	};
	return /* @__PURE__ */ g("div", {
		className: "gs-listing gs-shop",
		children: [
			/* @__PURE__ */ h("h3", { children: "Send to the shop" }),
			n ? n.connected ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("p", {
				className: "gs-hint",
				children: [
					"Connected to ",
					q(n.url),
					n.answering ? "" : ": not answering, or the shop removed this computer"
				]
			}), /* @__PURE__ */ g("div", {
				className: "gs-button-row",
				children: [/* @__PURE__ */ h("button", {
					type: "button",
					className: "gs-button gs-button--primary",
					disabled: c,
					onClick: () => void y(),
					children: c ? "Sending…" : "Send as a draft"
				}), /* @__PURE__ */ h("button", {
					type: "button",
					className: "gs-link",
					disabled: c,
					onClick: () => {
						a(n.url), r({ connected: !1 });
					},
					children: "Connect again"
				})]
			})] }) : /* @__PURE__ */ g("form", {
				className: "gs-shop__connect",
				onSubmit: (e) => {
					e.preventDefault(), v();
				},
				children: [
					/* @__PURE__ */ h("p", {
						className: "gs-hint",
						children: "Connect once: the shop’s Imports page › Connect the app shows the address and a code."
					}),
					/* @__PURE__ */ h("input", {
						className: "gs-input",
						value: i,
						onChange: (e) => a(e.target.value),
						placeholder: "Shop address",
						"aria-label": "Shop address",
						autoComplete: "off"
					}),
					/* @__PURE__ */ h("input", {
						className: "gs-input",
						value: o,
						onChange: (e) => s(e.target.value),
						placeholder: "Code",
						"aria-label": "Code from the shop",
						inputMode: "numeric",
						autoComplete: "off"
					}),
					/* @__PURE__ */ h("button", {
						type: "submit",
						className: "gs-button",
						disabled: c || !i.trim() || !o.trim(),
						children: c ? "Connecting…" : "Connect"
					})
				]
			}) : /* @__PURE__ */ h("p", {
				className: "gs-hint",
				children: "Checking the shop…"
			}),
			d && /* @__PURE__ */ h("p", {
				className: d.ok ? "gs-hint gs-shop__ok" : "gs-error",
				children: d.text
			}),
			/* @__PURE__ */ h(V, { id: "sendToShop" })
		]
	});
}
function Ve({ health: e, quality: t, changesUrl: n }) {
	return /* @__PURE__ */ g("div", {
		className: `gs-score gs-score--${e?.level ?? "fair"}`,
		children: [
			e && /* @__PURE__ */ g("div", {
				className: "gs-score__head",
				children: [/* @__PURE__ */ h("span", {
					className: "gs-score__score",
					"aria-label": `Listing health ${e.score} out of 100`,
					children: e.score
				}), /* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h("strong", { children: "Listing health" }), /* @__PURE__ */ g("span", {
					className: "gs-hint",
					children: [" ", e.level === "good" ? "ready to list" : e.level === "fair" ? "a few things to fix" : "needs work"]
				})] })]
			}),
			t && /* @__PURE__ */ g("div", {
				className: "gs-score__badges",
				children: [/* @__PURE__ */ g("span", {
					className: `gs-badge ${t.cutout.score >= .8 ? "is-ok" : "is-warn"}`,
					title: t.cutout.reasons.join("; ") || "Nothing doubtful seen",
					children: [
						"Cut-out ",
						Math.round(t.cutout.score * 100),
						"% sure"
					]
				}), /* @__PURE__ */ g("span", {
					className: `gs-badge ${t.fidelity.original >= .9 ? "is-ok" : "is-warn"}`,
					title: "Share of the product that is still the photo's own detail; colour and light changes do not count",
					children: [Math.round(t.fidelity.original * 100), "% as photographed"]
				})]
			}),
			n && /* @__PURE__ */ g("details", {
				className: "gs-score__changes",
				children: [
					/* @__PURE__ */ h("summary", { children: "Show what is not as photographed" }),
					/* @__PURE__ */ h("img", {
						src: n,
						alt: "The product with the parts that were repainted, completed or redrawn tinted pink"
					}),
					/* @__PURE__ */ h("p", {
						className: "gs-hint",
						children: "Tinted: repainted (a sticker, a title), completed from an official picture, or redrawn. Compare these with the real item."
					})
				]
			}),
			e && e.fixes.length > 0 && /* @__PURE__ */ h("ol", {
				className: "gs-score__fixes",
				"aria-label": "Top fixes",
				children: e.fixes.map((e) => /* @__PURE__ */ h("li", { children: e }, e))
			}),
			e && /* @__PURE__ */ g("details", { children: [/* @__PURE__ */ h("summary", { children: "Every check" }), /* @__PURE__ */ h("ul", {
				className: "gs-score__checks",
				children: e.checks.map((e) => /* @__PURE__ */ g("li", {
					className: e.ok ? "is-ok" : "is-warn",
					children: [
						e.ok ? "✓" : "•",
						" ",
						e.label
					]
				}, e.id))
			})] }),
			/* @__PURE__ */ h(V, { id: "listingHealth" })
		]
	});
}
function He({ stickers: e }) {
	return /* @__PURE__ */ g("section", { children: [
		/* @__PURE__ */ h("h2", { children: "Price stickers and printed text" }),
		/* @__PURE__ */ h("button", {
			type: "button",
			className: "gs-button",
			disabled: e.busy,
			onClick: e.run,
			title: "Reads the prices on the photo and paints the shop's price stickers out. Free; needs the Gleamshelf app with the text finder, the text reader and the AI fill.",
			children: e.busy ? "Working…" : "Remove price stickers"
		}),
		/* @__PURE__ */ h("button", {
			type: "button",
			className: `gs-button ${e.picking && !e.pickingText ? "is-active" : ""}`,
			disabled: e.busy,
			onClick: () => e.setPicking(!(e.picking && !e.pickingText)),
			title: "If a sticker was missed, click it on the picture and it is painted out",
			children: e.picking && !e.pickingText ? "Cancel" : "Click a sticker"
		}),
		e.setPickingText && /* @__PURE__ */ h("button", {
			type: "button",
			className: `gs-button ${e.pickingText ? "is-active" : ""}`,
			disabled: e.busy,
			onClick: () => e.setPickingText(!e.pickingText),
			title: "For printed text the automatic search left, such as a big title: click one letter and every letter of that colour in the same text is painted out",
			children: e.pickingText ? "Cancel" : "Click printed text"
		}),
		/* @__PURE__ */ h(V, { id: "stickers" }),
		/* @__PURE__ */ h(V, { id: "stickerClick" }),
		e.setPickingText && /* @__PURE__ */ h(V, { id: "textClick" }),
		e.note && /* @__PURE__ */ h("p", {
			className: "gs-hint",
			children: e.note
		})
	] });
}
function Ue({ editor: e, doc: t, hasCutout: n, lettering: r, aiFill: i, onRemoveLettering: a }) {
	let o = t.recipe.words;
	return /* @__PURE__ */ g("section", { children: [/* @__PURE__ */ h("h2", { children: "Printed lettering" }), o ? /* @__PURE__ */ g(m, { children: [
		/* @__PURE__ */ g("div", {
			className: "gs-crop-tools",
			children: [/* @__PURE__ */ h("button", {
				type: "button",
				className: "gs-button",
				onClick: () => e.setWords(!1),
				children: "Put lettering back"
			}), /* @__PURE__ */ h("span", {
				className: "gs-hint",
				children: r?.busy ? "Working…" : r && r.filled === 0 ? "No lettering found: try a lower \"How white\"." : r?.filled === -1 ? "Filled with AI." : r?.aiReady ? "Free fill shown; AI fill is ready below." : "Soft free fill. For a clean result set up the AI fill below."
			})]
		}),
		/* @__PURE__ */ h(V, { id: "letteringSliders" }),
		Oe.map(({ key: t, label: n, min: r, max: i, step: a, help: s }) => /* @__PURE__ */ g("label", {
			className: "gs-control",
			title: s,
			children: [/* @__PURE__ */ g("span", {
				className: "gs-control__row",
				children: [/* @__PURE__ */ h("span", { children: n }), /* @__PURE__ */ h("output", { children: o[t] })]
			}), /* @__PURE__ */ h("input", {
				type: "range",
				style: Q(o[t], r, i),
				min: r,
				max: i,
				step: a,
				value: o[t],
				onPointerDown: () => e.begin(`Lettering: ${n}`),
				onPointerUp: () => e.commit(),
				onLostPointerCapture: () => e.commit(),
				onChange: (r) => e.setWordsParam(t, Number(r.target.value), `Lettering: ${n}`)
			})]
		}, t)),
		i
	] }) : /* @__PURE__ */ g(m, { children: [
		/* @__PURE__ */ h("button", {
			type: "button",
			className: "gs-button",
			onClick: () => a ? a() : e.setWords(!0),
			title: "Paints over white lettering, such as a title written across the picture",
			children: "Remove white lettering"
		}),
		/* @__PURE__ */ h(V, { id: "lettering" }),
		/* @__PURE__ */ g("p", {
			className: "gs-hint",
			children: [
				"Free. ",
				n ? "Only the cut-out is touched." : "With no cut-out, the whole picture is searched.",
				" Cleanest with the AI fill, offered once this is on."
			]
		})
	] })] });
}
var We = [
	{
		id: "drop-shadow",
		label: "Soft shadow",
		title: "A soft shadow cast behind and under the product"
	},
	{
		id: "contact-shadow",
		label: "Contact shadow",
		title: "The dark line where the product meets the floor, so it stands instead of floating"
	},
	{
		id: "reflection",
		label: "Reflection",
		title: "The product mirrored on a glossy surface under it"
	}
];
function Ge({ editor: e }) {
	let t = (t) => e.effects.findIndex((e) => e.id === t);
	return /* @__PURE__ */ g("div", {
		className: "gs-control",
		children: [/* @__PURE__ */ h("div", {
			className: "gs-segmented gs-segmented--wrap",
			role: "group",
			"aria-label": "Shadow and reflection",
			children: We.map(({ id: r, label: i, title: a }) => {
				let o = t(r);
				return /* @__PURE__ */ h("button", {
					type: "button",
					className: `gs-button ${o >= 0 ? "is-active" : ""}`,
					"aria-pressed": o >= 0,
					title: a,
					onClick: () => {
						if (o >= 0) e.removeEffect(o, `Remove ${i.toLowerCase()}`);
						else {
							let t = j(r);
							t && e.addEffect(r, E(t), `Add ${i.toLowerCase()}`), r === "reflection" && l(e.document.recipe, "canvas", "square") && n(e.document.recipe, "canvas", "margin") < 14 && e.set("recipe/ops/canvas/margin", 14, "Room for the reflection");
						}
					},
					children: i
				}, r);
			})
		}), /* @__PURE__ */ h(V, { id: "ground" })]
	});
}
var J = "gleamshelf:listing-set";
function Y({ run: e, busy: t, note: n, hasCutout: r }) {
	let [i, a] = f(() => {
		try {
			let e = JSON.parse(localStorage.getItem(J) ?? "null");
			if (Array.isArray(e)) return e.filter((e) => typeof e == "string" && !!o(e));
		} catch {}
		return s.map((e) => e.id);
	}), c = (e, t) => {
		let n = s.map((e) => e.id).filter((n) => n === e ? t : i.includes(n));
		a(n);
		try {
			localStorage.setItem(J, JSON.stringify(n));
		} catch {}
	};
	return /* @__PURE__ */ g("div", {
		className: "gs-listing-set",
		children: [
			/* @__PURE__ */ h("div", {
				className: "gs-listing-set__presets",
				role: "group",
				"aria-label": "Marketplaces",
				children: s.map((e) => /* @__PURE__ */ g("label", {
					className: "gs-control gs-control--inline",
					title: e.rule,
					children: [
						/* @__PURE__ */ h("input", {
							type: "checkbox",
							checked: i.includes(e.id),
							onChange: (t) => c(e.id, t.target.checked)
						}),
						e.name,
						" ",
						/* @__PURE__ */ g("span", {
							className: "gs-hint",
							children: [e.size, "px"]
						})
					]
				}, e.id))
			}),
			/* @__PURE__ */ h("button", {
				type: "button",
				className: "gs-button",
				disabled: !r || t || !i.length,
				onClick: () => e(i),
				title: r ? "Saves one picture per ticked marketplace, each in its own size and framing, in one zip" : "Cut the product out first",
				children: t ? "Making the set…" : `Save the listing set (${i.length})`
			}),
			n && /* @__PURE__ */ h("p", {
				className: "gs-hint",
				children: n
			}),
			/* @__PURE__ */ h(V, { id: "listingSet" })
		]
	});
}
var Ke = [
	{
		mode: "transparent",
		label: "None",
		title: "Keep the cut-out transparent (saves as PNG or WebP)"
	},
	{
		mode: "color",
		label: "Colour",
		title: "A flat colour behind the product"
	},
	{
		mode: "image",
		label: "Photo",
		title: "Your own background photo"
	}
];
function qe({ editor: t, doc: n, onFitProduct: r, onStudio: a, listingSet: o, onBackgroundPhoto: s, hasBackgroundPhoto: c, backgroundName: u }) {
	let d = i(n.recipe, "backdrop", "mode"), f = i(n.recipe, "backdrop", "color") || "#ffffff", p = n.recipe.mask.length > 0, _ = l(n.recipe, "canvas", "square");
	return /* @__PURE__ */ g("section", { children: [
		/* @__PURE__ */ h("h2", { children: "Behind the product" }),
		a && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
			type: "button",
			className: "gs-button gs-button--primary",
			disabled: !p,
			onClick: a,
			title: p ? "White background, the product centred on a square, and a soft shadow" : "Cut the product out first",
			children: "Studio photo: white and square"
		}), /* @__PURE__ */ h(V, { id: "studio" })] }),
		p && /* @__PURE__ */ h(Ge, { editor: t }),
		o && /* @__PURE__ */ h(Y, {
			...o,
			hasCutout: p
		}),
		/* @__PURE__ */ h(V, { id: "backdrop" }),
		/* @__PURE__ */ h("div", {
			className: "gs-segmented",
			role: "group",
			"aria-label": "What is behind the product",
			children: Ke.map(({ mode: e, label: n, title: r }) => /* @__PURE__ */ h("button", {
				type: "button",
				className: `gs-button ${d === e ? "is-active" : ""}`,
				"aria-pressed": d === e,
				title: r,
				onClick: () => t.set("recipe/ops/backdrop/mode", e, `Backdrop: ${n}`),
				children: n
			}, e))
		}),
		d === "color" && /* @__PURE__ */ g("label", {
			className: "gs-control gs-control--inline",
			children: [/* @__PURE__ */ h("input", {
				type: "color",
				value: f,
				"aria-label": "Backdrop colour",
				onChange: (e) => t.set("recipe/ops/backdrop/color", e.target.value, "Backdrop colour")
			}), f]
		}),
		d === "image" && /* @__PURE__ */ g("div", {
			className: "gs-control",
			children: [/* @__PURE__ */ g("label", {
				className: "gs-button gs-file",
				children: [c ? "Choose another photo" : "Choose background photo", /* @__PURE__ */ h("input", {
					type: "file",
					accept: "image/*,.heic,.heif",
					onChange: (e) => {
						let t = e.target.files?.[0];
						e.target.value = "", t && s(t);
					}
				})]
			}), /* @__PURE__ */ h("span", {
				className: "gs-hint",
				children: c ? u ?? "Background photo" : "The photo fills the whole picture behind the product."
			})]
		}),
		d !== "transparent" && !p && /* @__PURE__ */ h("p", {
			className: "gs-hint",
			children: "Cut the product out above first, or the photo will cover it."
		}),
		/* @__PURE__ */ g("div", {
			className: "gs-control",
			children: [
				/* @__PURE__ */ h("span", {
					className: "gs-control__row",
					children: /* @__PURE__ */ h("span", { children: "Square picture" })
				}),
				/* @__PURE__ */ g("div", {
					className: "gs-crop-tools",
					children: [/* @__PURE__ */ h("button", {
						type: "button",
						className: "gs-button",
						disabled: !p,
						onClick: r,
						title: p ? "Crop to the product and centre it on a square, with space around it" : "Cut the product out first",
						children: "Fit square to product"
					}), /* @__PURE__ */ g("label", {
						className: "gs-control gs-control--inline",
						children: [/* @__PURE__ */ h("input", {
							type: "checkbox",
							checked: _,
							onChange: (e) => t.set("recipe/ops/canvas/square", e.target.checked, "Square canvas")
						}), "Square"]
					})]
				}),
				/* @__PURE__ */ h(V, { id: "square" })
			]
		}),
		_ && /* @__PURE__ */ h(X, {
			editor: t,
			type: "canvas",
			name: "margin",
			spec: e("canvas", "margin"),
			value: n.recipe.ops.canvas?.margin
		})
	] });
}
var Je = {
	free: "Free",
	original: "Original",
	"1:1": "Square 1:1",
	"4:5": "Portrait 4:5",
	"3:4": "Portrait 3:4",
	"2:3": "Portrait 2:3",
	"16:9": "Wide 16:9"
};
function Ye(e, t) {
	let n = t.step < .1 ? 2 : +(t.step < 1);
	return `${e > 0 && t.min < 0 ? "+" : ""}${e.toFixed(n)}${t.unit ?? ""}`;
}
function Xe({ editor: e, path: t, spec: n, value: r }) {
	return /* @__PURE__ */ g("label", {
		className: "gs-control",
		children: [/* @__PURE__ */ g("span", {
			className: "gs-control__row",
			children: [/* @__PURE__ */ h("span", { children: n.label }), /* @__PURE__ */ h("output", {
				className: r === n.default ? "" : "is-changed",
				children: Ye(r, n)
			})]
		}), /* @__PURE__ */ h("input", {
			type: "range",
			style: Q(r, n.min, n.max),
			min: n.min,
			max: n.max,
			step: n.step,
			value: r,
			onPointerDown: () => e.begin(n.label),
			onPointerUp: () => e.commit(),
			onLostPointerCapture: () => e.commit(),
			onChange: (n) => e.set(t, Number(n.target.value)),
			onDoubleClick: () => e.set(t, n.default, `Reset ${n.label}`)
		})]
	});
}
function X({ editor: e, type: t, name: n, spec: r, value: i }) {
	let a = `recipe/ops/${t}/${n}`;
	if (r.kind === "number") return /* @__PURE__ */ h(Xe, {
		editor: e,
		path: a,
		spec: r,
		value: typeof i == "number" ? i : r.default
	});
	if (r.kind === "boolean") return /* @__PURE__ */ g("label", {
		className: "gs-control gs-control--inline",
		children: [/* @__PURE__ */ h("input", {
			type: "checkbox",
			checked: i === !0,
			onChange: (t) => e.set(a, t.target.checked)
		}), r.label]
	});
	if (r.kind === "color") {
		let t = typeof i == "string" ? i : r.default;
		return /* @__PURE__ */ g("label", {
			className: "gs-control gs-control--inline",
			children: [/* @__PURE__ */ h("input", {
				type: "color",
				value: t,
				"aria-label": r.label,
				onChange: (t) => e.set(a, t.target.value, r.label)
			}), r.label]
		});
	}
	return null;
}
var Ze = [
	{
		id: "quick",
		label: "One click",
		icon: "spark",
		title: "Make it listing-ready in one click"
	},
	{
		id: "cutout",
		label: "Cut out",
		icon: "scissors",
		title: "Take the background away, and choose what goes behind the product"
	},
	{
		id: "clean",
		label: "Clean up",
		icon: "brush",
		title: "Price stickers, printed lettering, finishing touches"
	},
	{
		id: "adjust",
		label: "Adjust",
		icon: "sliders",
		title: "Rotate and crop, look, light, colour, effects"
	}
], Z = {
	light: "light",
	color: "color",
	recolour: "recolour"
};
function Qe(n) {
	let { editor: a, doc: o, cropping: s, onToggleCrop: l, autoEnhance: p, onAutoEnhance: _, aiEnlarge: v } = n, y = i(o.recipe, "crop", "aspect"), b = Ze.filter((e) => e.id !== "quick" || n.auto), [x, S] = f(b[0].id), C = d(!1), w = (e) => {
		C.current = !0, S(e);
	}, T = !!n.auto;
	return u(() => {
		T && !C.current && S("quick");
	}, [T]), u(() => {
		s && S("adjust");
	}, [s]), /* @__PURE__ */ g("div", {
		className: "gs-panel",
		children: [
			/* @__PURE__ */ h("nav", {
				className: "gs-tabs",
				role: "tablist",
				"aria-label": "Tools",
				children: b.map((e) => /* @__PURE__ */ g("button", {
					type: "button",
					role: "tab",
					"aria-selected": x === e.id,
					className: `gs-tab ${x === e.id ? "is-active" : ""}`,
					title: e.title,
					onClick: () => w(e.id),
					children: [
						/* @__PURE__ */ h($, { name: e.icon }),
						/* @__PURE__ */ h("span", { children: e.label }),
						e.id === "quick" && n.auto?.busy && /* @__PURE__ */ h("span", {
							className: "gs-tab__live",
							"aria-label": "running"
						})
					]
				}, e.id))
			}),
			/* @__PURE__ */ g("div", {
				className: "gs-tabpanel",
				role: "tabpanel",
				children: [
					x === "quick" && n.auto && /* @__PURE__ */ h(Re, {
						auto: n.auto,
						listingSet: n.listingSet,
						hasCutout: n.doc.recipe.mask.length > 0
					}),
					x === "cutout" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(De, { ...n }), /* @__PURE__ */ h(qe, { ...n })] }),
					x === "clean" && /* @__PURE__ */ g(m, { children: [
						n.stickers && /* @__PURE__ */ h(He, { stickers: n.stickers }),
						/* @__PURE__ */ h(Ue, { ...n }),
						n.aiFinish && /* @__PURE__ */ g("section", { children: [/* @__PURE__ */ h("h2", { children: "Finishing touches" }), n.aiFinish] })
					] }),
					x === "adjust" && /* @__PURE__ */ g(m, { children: [
						/* @__PURE__ */ g("section", { children: [
							/* @__PURE__ */ h("h2", { children: "Geometry" }),
							/* @__PURE__ */ g("div", {
								className: "gs-button-row",
								children: [
									/* @__PURE__ */ h("button", {
										type: "button",
										className: "gs-button",
										onClick: () => a.rotate(-1),
										title: "Rotate left",
										children: "⟲ Left"
									}),
									/* @__PURE__ */ h("button", {
										type: "button",
										className: "gs-button",
										onClick: () => a.rotate(1),
										title: "Rotate right",
										children: "⟳ Right"
									}),
									/* @__PURE__ */ h("button", {
										type: "button",
										className: "gs-button",
										onClick: () => a.flip("horizontal"),
										children: "Flip ↔"
									}),
									/* @__PURE__ */ h("button", {
										type: "button",
										className: "gs-button",
										onClick: () => a.flip("vertical"),
										children: "Flip ↕"
									})
								]
							}),
							/* @__PURE__ */ h(V, { id: "rotate" }),
							/* @__PURE__ */ g("div", {
								className: "gs-control",
								children: [
									/* @__PURE__ */ h("span", {
										className: "gs-control__row",
										children: /* @__PURE__ */ h("span", { children: "Crop" })
									}),
									/* @__PURE__ */ g("div", {
										className: "gs-crop-tools",
										children: [/* @__PURE__ */ h("button", {
											type: "button",
											className: `gs-button ${s ? "gs-button--primary" : ""}`,
											onClick: l,
											title: "Crop (C)",
											children: s ? "Done" : "Crop"
										}), /* @__PURE__ */ h("select", {
											"aria-label": "Aspect ratio",
											value: y,
											onChange: (e) => {
												a.setCropAspect(e.target.value), e.currentTarget.blur();
											},
											children: t.map((e) => /* @__PURE__ */ h("option", {
												value: e,
												children: Je[e]
											}, e))
										})]
									}),
									/* @__PURE__ */ h(V, { id: "crop" })
								]
							}),
							/* @__PURE__ */ h(X, {
								editor: a,
								type: "straighten",
								name: "angle",
								spec: e("straighten", "angle"),
								value: o.recipe.ops.straighten?.angle
							}),
							/* @__PURE__ */ h(V, { id: "straighten" })
						] }),
						/* @__PURE__ */ g("section", { children: [
							/* @__PURE__ */ h("h2", { children: "Look" }),
							/* @__PURE__ */ g("div", {
								className: "gs-segmented",
								role: "group",
								"aria-label": "Look",
								children: [/* @__PURE__ */ h("button", {
									type: "button",
									className: "gs-button",
									title: "Back to the photo's own light and colour",
									onClick: () => a.clearLook(),
									children: "Natural"
								}), c.map((e) => /* @__PURE__ */ h("button", {
									type: "button",
									className: "gs-button",
									title: e.description,
									onClick: () => a.applyLook(e.id),
									children: e.label
								}, e.id))]
							}),
							/* @__PURE__ */ h(V, { id: "looks" }),
							_ && /* @__PURE__ */ g("label", {
								className: "gs-control gs-control--inline",
								title: "After an AI cut-out or fill, apply the Bright & sharp look, unless you have already set your own",
								children: [/* @__PURE__ */ h("input", {
									type: "checkbox",
									checked: !!p,
									onChange: (e) => _(e.target.checked)
								}), "Brighter and sharper after an AI step"]
							}),
							_ && /* @__PURE__ */ h(V, { id: "autoLook" }),
							v
						] }),
						r.filter((e) => e.group !== "geometry" && Object.values(e.params).some((e) => !e.hidden)).map((e) => /* @__PURE__ */ g("section", { children: [
							/* @__PURE__ */ h("h2", { children: e.label }),
							Z[e.type] && /* @__PURE__ */ h(V, { id: Z[e.type] }),
							Object.entries(e.params).filter(([t, n]) => !n.hidden && (t === "on" || !("on" in e.params) || o.recipe.ops[e.type]?.on === !0)).map(([t, n]) => /* @__PURE__ */ h(X, {
								editor: a,
								type: e.type,
								name: t,
								spec: n,
								value: o.recipe.ops[e.type]?.[t]
							}, t)),
							e.hint && /* @__PURE__ */ h("p", {
								className: "gs-hint",
								children: e.hint
							})
						] }, e.type)),
						/* @__PURE__ */ h(V, { id: "effects" }),
						/* @__PURE__ */ h(ve, {
							title: "Effects",
							empty: "Add a look from the shaders folder: sharpen, shadow, glow, grain and more.",
							steps: o.recipe.effects,
							catalog: me(),
							known: j,
							onAdd: (e) => a.addEffect(e.id, E(e), `Add ${e.name}`),
							onRemove: (e) => a.removeEffect(e),
							onMove: (e, t) => a.moveEffect(e, t),
							onParam: (e, t, n, r) => a.setEffectParam(e, t, n, r),
							onBegin: (e) => a.begin(e),
							onCommit: () => a.commit()
						})
					] })
				]
			}, x),
			/* @__PURE__ */ g("footer", {
				className: "gs-panel__foot",
				children: [n.onOpenGuide && /* @__PURE__ */ h("button", {
					type: "button",
					className: "gs-link",
					onClick: n.onOpenGuide,
					children: "Guide to every feature"
				}), /* @__PURE__ */ h(H, {})]
			})
		]
	});
}
var Q = (e, t, n) => ({ "--fill": `${Math.max(0, Math.min(100, (e - t) / (n - t || 1) * 100))}%` }), $e = {
	undo: /* @__PURE__ */ h("path", { d: "M9 14L4 9l5-5M4 9h10a6 6 0 010 12h-3" }),
	redo: /* @__PURE__ */ h("path", { d: "M15 14l5-5-5-5M20 9H10a6 6 0 000 12h3" }),
	compare: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("rect", {
		x: "3",
		y: "5",
		width: "18",
		height: "14",
		rx: "3"
	}), /* @__PURE__ */ h("path", { d: "M12 5v14" })] }),
	reset: /* @__PURE__ */ h("path", { d: "M4 12a8 8 0 102.3-5.7M4 4v4h4" }),
	layers: /* @__PURE__ */ h("path", { d: "M12 3l9 5-9 5-9-5 9-5zM3 13l9 5 9-5" }),
	close: /* @__PURE__ */ h("path", { d: "M6 6l12 12M18 6L6 18" }),
	spark: /* @__PURE__ */ h("path", { d: "M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z" }),
	scissors: /* @__PURE__ */ g(m, { children: [
		/* @__PURE__ */ h("circle", {
			cx: "6",
			cy: "7",
			r: "3"
		}),
		/* @__PURE__ */ h("circle", {
			cx: "6",
			cy: "17",
			r: "3"
		}),
		/* @__PURE__ */ h("path", { d: "M8.5 8.5L20 19M8.5 15.5L20 5" })
	] }),
	brush: /* @__PURE__ */ h("path", { d: "M14 4l6 6-8 8-6-6zM6 12c-2 1-2.5 4-3 8 4-.5 7-1 8-3" }),
	sliders: /* @__PURE__ */ h("path", { d: "M4 7h10M18 7h2M4 17h4M12 17h8M14 4v6M8 14v6" }),
	help: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("circle", {
		cx: "12",
		cy: "12",
		r: "9"
	}), /* @__PURE__ */ h("path", { d: "M9.5 9.5a2.5 2.5 0 114 2c-1 .6-1.5 1.2-1.5 2.3M12 17h.01" })] })
};
function $({ name: e, size: t = 16 }) {
	return /* @__PURE__ */ h("svg", {
		width: t,
		height: t,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: 1.8,
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: $e[e]
	});
}
//#endregion
export { O as _, H as a, I as c, P as d, N as f, D as g, j as h, we as i, xe as l, he as m, Qe as n, Te as o, be as p, Q as r, V as s, $ as t, Se as u };

//# sourceMappingURL=Panel-Bat7k9QP.js.map