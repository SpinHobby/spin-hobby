import type { LocalModelClient } from '../../../models/src/index.js';
/**
 * The scene behind a 3D design, made by the image model on this computer (free; about a minute). The design itself is never redrawn: it is
 * drawn over the scene, live, as it is, so moving a shape later needs no new scene.
 */
export declare const SCENE_IDEAS: readonly ["a wooden shop shelf, warm soft light", "a pastel photo studio with soft shadows", "a cosy room, blurred, evening light", "a city street at night, neon lights, bokeh", "a cherry blossom park in spring, soft focus", "a festive gift table, fairy lights, bokeh"];
export declare function toDataUrl(blob: Blob): Promise<string>;
/** A picture made smaller (at most `long` on its long side) as JPEG, to keep inside a design. */
export declare function sceneFromPicture(blob: Blob, long?: number): Promise<string>;
/**
 * Makes a scene for a design seen in a view `aspect` wide over high: `describe` is what to paint. The scene is painted on its own, with
 * nothing of the design in it (shown the design, the model carries its lettering and shapes on into the scene), then placed behind it.
 */
export declare function makeScene(client: LocalModelClient, aspect: number, describe: string, onStep: (step: string) => void): Promise<string>;
