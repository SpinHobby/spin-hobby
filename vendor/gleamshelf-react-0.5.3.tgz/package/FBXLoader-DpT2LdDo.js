import { $n as e, A as t, At as n, Bt as r, It as i, Jn as a, Ln as o, N as s, Nt as c, O as l, P as u, St as d, Un as f, Vn as p, Vt as m, Wn as h, Xn as g, Zn as _, _t as v, a as y, d as b, dr as x, et as S, f as C, fr as w, gt as T, ht as E, jn as D, kt as O, l as k, lt as A, mr as ee, mt as j, n as te, p as M, pr as N, r as ne, tt as re, ut as P, v as ie, xt as F, z as I, zt as L } from "./three.core-Bn_95pMq.js";
import { n as ae } from "./fflate.module-d2PQQWvd.js";
//#region ../../node_modules/three/examples/jsm/curves/NURBSUtils.js
function R(e, t, n) {
	let r = n.length - e - 1;
	if (t >= n[r]) return r - 1;
	if (t <= n[e]) return e;
	let i = e, a = r, o = Math.floor((i + a) / 2);
	for (; t < n[o] || t >= n[o + 1];) t < n[o] ? a = o : i = o, o = Math.floor((i + a) / 2);
	return o;
}
function oe(e, t, n, r) {
	let i = [], a = [], o = [];
	i[0] = 1;
	for (let s = 1; s <= n; ++s) {
		a[s] = t - r[e + 1 - s], o[s] = r[e + s] - t;
		let n = 0;
		for (let e = 0; e < s; ++e) {
			let t = o[e + 1], r = a[s - e], c = i[e] / (t + r);
			i[e] = n + t * c, n = r * c;
		}
		i[s] = n;
	}
	return i;
}
function se(e, t, n, r) {
	let i = R(e, r, t), a = oe(i, r, e, t), o = new N(0, 0, 0, 0);
	for (let t = 0; t <= e; ++t) {
		let r = n[i - e + t], s = a[t], c = r.w * s;
		o.x += r.x * c, o.y += r.y * c, o.z += r.z * c, o.w += r.w * s;
	}
	return o;
}
function ce(e, t, n, r, i) {
	let a = [];
	for (let e = 0; e <= n; ++e) a[e] = 0;
	let o = [];
	for (let e = 0; e <= r; ++e) o[e] = a.slice(0);
	let s = [];
	for (let e = 0; e <= n; ++e) s[e] = a.slice(0);
	s[0][0] = 1;
	let c = a.slice(0), l = a.slice(0);
	for (let r = 1; r <= n; ++r) {
		c[r] = t - i[e + 1 - r], l[r] = i[e + r] - t;
		let n = 0;
		for (let e = 0; e < r; ++e) {
			let t = l[e + 1], i = c[r - e];
			s[r][e] = t + i;
			let a = s[e][r - 1] / s[r][e];
			s[e][r] = n + t * a, n = i * a;
		}
		s[r][r] = n;
	}
	for (let e = 0; e <= n; ++e) o[0][e] = s[e][n];
	for (let e = 0; e <= n; ++e) {
		let t = 0, i = 1, c = [];
		for (let e = 0; e <= n; ++e) c[e] = a.slice(0);
		c[0][0] = 1;
		for (let a = 1; a <= r; ++a) {
			let r = 0, l = e - a, u = n - a;
			e >= a && (c[i][0] = c[t][0] / s[u + 1][l], r = c[i][0] * s[l][u]);
			let d = l >= -1 ? 1 : -l, f = e - 1 <= u ? a - 1 : n - e;
			for (let e = d; e <= f; ++e) c[i][e] = (c[t][e] - c[t][e - 1]) / s[u + 1][l + e], r += c[i][e] * s[l + e][u];
			e <= u && (c[i][a] = -c[t][a - 1] / s[u + 1][e], r += c[i][a] * s[e][u]), o[a][e] = r;
			let p = t;
			t = i, i = p;
		}
	}
	let u = n;
	for (let e = 1; e <= r; ++e) {
		for (let t = 0; t <= n; ++t) o[e][t] *= u;
		u *= n - e;
	}
	return o;
}
function le(e, t, n, r, i) {
	let a = i < e ? i : e, o = [], s = R(e, r, t), c = ce(s, r, e, a, t), l = [];
	for (let e = 0; e < n.length; ++e) {
		let t = n[e].clone(), r = t.w;
		t.x *= r, t.y *= r, t.z *= r, l[e] = t;
	}
	for (let t = 0; t <= a; ++t) {
		let n = l[s - e].clone().multiplyScalar(c[t][0]);
		for (let r = 1; r <= e; ++r) n.add(l[s - e + r].clone().multiplyScalar(c[t][r]));
		o[t] = n;
	}
	for (let e = a + 1; e <= i + 1; ++e) o[e] = new N(0, 0, 0);
	return o;
}
function ue(e, t) {
	let n = 1;
	for (let t = 2; t <= e; ++t) n *= t;
	let r = 1;
	for (let e = 2; e <= t; ++e) r *= e;
	for (let n = 2; n <= e - t; ++n) r *= n;
	return n / r;
}
function de(e) {
	let t = e.length, n = [], r = [];
	for (let i = 0; i < t; ++i) {
		let t = e[i];
		n[i] = new w(t.x, t.y, t.z), r[i] = t.w;
	}
	let i = [];
	for (let e = 0; e < t; ++e) {
		let t = n[e].clone();
		for (let n = 1; n <= e; ++n) t.sub(i[e - n].clone().multiplyScalar(ue(e, n) * r[n]));
		i[e] = t.divideScalar(r[0]);
	}
	return i;
}
function fe(e, t, n, r, i) {
	return de(le(e, t, n, r, i));
}
//#endregion
//#region ../../node_modules/three/examples/jsm/curves/NURBSCurve.js
var pe = class extends ie {
	constructor(e, t, n, r, i) {
		super();
		let a = t ? t.length - 1 : 0, o = n ? n.length : 0;
		this.degree = e, this.knots = t, this.controlPoints = [], this.startKnot = r || 0, this.endKnot = i || a;
		for (let e = 0; e < o; ++e) {
			let t = n[e];
			this.controlPoints[e] = new N(t.x, t.y, t.z, t.w);
		}
	}
	getPoint(e, t = new w()) {
		let n = t, r = this.knots[this.startKnot] + e * (this.knots[this.endKnot] - this.knots[this.startKnot]), i = se(this.degree, this.knots, this.controlPoints, r);
		return i.w !== 1 && i.divideScalar(i.w), n.set(i.x, i.y, i.z);
	}
	getTangent(e, t = new w()) {
		let n = t, r = this.knots[0] + e * (this.knots[this.knots.length - 1] - this.knots[0]), i = fe(this.degree, this.knots, this.controlPoints, r, 1);
		return n.copy(i[1]).normalize(), n;
	}
	toJSON() {
		let e = super.toJSON();
		return e.degree = this.degree, e.knots = [...this.knots], e.controlPoints = this.controlPoints.map((e) => e.toArray()), e.startKnot = this.startKnot, e.endKnot = this.endKnot, e;
	}
	fromJSON(e) {
		return super.fromJSON(e), this.degree = e.degree, this.knots = [...e.knots], this.controlPoints = e.controlPoints.map((e) => new N(e[0], e[1], e[2], e[3])), this.startKnot = e.startKnot, this.endKnot = e.endKnot, this;
	}
}, z, B, V, me = class extends A {
	constructor(e) {
		super(e), this.trimAnimationClips = !1;
	}
	load(e, t, n, r) {
		let i = this, a = i.path === "" ? P.extractUrlBase(e) : i.path, o = new s(this.manager);
		o.setPath(i.path), o.setResponseType("arraybuffer"), o.setRequestHeader(i.requestHeader), o.setWithCredentials(i.withCredentials), o.load(e, function(n) {
			try {
				t(i.parse(n, a));
			} catch (t) {
				r ? r(t) : console.error(t), i.manager.itemError(e);
			}
		}, n, r);
	}
	parse(e, t) {
		if (ye(e)) z = new ve().parse(e);
		else {
			let t = $(e);
			if (!be(t)) throw Error("THREE.FBXLoader: Unknown format.");
			if (G(t) < 7e3) throw Error("THREE.FBXLoader: FBX version not supported, FileVersion: " + G(t));
			z = new _e().parse(t);
		}
		return new H(new _(this.manager).setPath(this.resourcePath || t).setCrossOrigin(this.crossOrigin), this.manager, this.trimAnimationClips).parse(z);
	}
}, H = class {
	constructor(e, t, n) {
		this.textureLoader = e, this.manager = t, this.trimAnimationClips = n;
	}
	parse() {
		B = this.parseConnections();
		let e = this.parseImages(), t = this.parseTextures(e), n = this.parseMaterials(t), r = this.parseDeformers(), i = new he().parse(r);
		return this.parseScene(r, i, n), V;
	}
	parseConnections() {
		let e = /* @__PURE__ */ new Map();
		return "Connections" in z && z.Connections.connections.forEach(function(t) {
			let n = t[0], r = t[1], i = t[2];
			e.has(n) || e.set(n, {
				parents: [],
				children: []
			});
			let a = {
				ID: r,
				relationship: i
			};
			e.get(n).parents.push(a), e.has(r) || e.set(r, {
				parents: [],
				children: []
			});
			let o = {
				ID: n,
				relationship: i
			};
			e.get(r).children.push(o);
		}), e;
	}
	parseImages() {
		let e = {}, t = {};
		if ("Video" in z.Objects) {
			let n = z.Objects.Video;
			for (let r in n) {
				let i = n[r], a = parseInt(r);
				if (e[a] = i.RelativeFilename || i.Filename, "Content" in i) {
					let e = i.Content instanceof ArrayBuffer && i.Content.byteLength > 0, a = typeof i.Content == "string" && i.Content !== "";
					if (e || a) {
						let e = this.parseImage(n[r]);
						t[i.RelativeFilename || i.Filename] = e;
					}
				}
			}
		}
		for (let n in e) {
			let r = e[n];
			e[n] = t[r] === void 0 ? e[n].split("\\").pop() : t[r];
		}
		return e;
	}
	parseImage(e) {
		let t = e.Content, n = e.RelativeFilename || e.Filename, r = n.slice(n.lastIndexOf(".") + 1).toLowerCase(), i;
		switch (r) {
			case "bmp":
				i = "image/bmp";
				break;
			case "jpg":
			case "jpeg":
				i = "image/jpeg";
				break;
			case "png":
				i = "image/png";
				break;
			case "tif":
				i = "image/tiff";
				break;
			case "tga":
				this.manager.getHandler(".tga") === null && console.warn("FBXLoader: TGA loader not found, skipping ", n), i = "image/tga";
				break;
			case "webp":
				i = "image/webp";
				break;
			default:
				console.warn("FBXLoader: Image type \"" + r + "\" is not supported.");
				return;
		}
		if (typeof t == "string") return "data:" + i + ";base64," + t;
		{
			let e = new Uint8Array(t);
			return URL.createObjectURL(new Blob([e], { type: i }));
		}
	}
	parseTextures(e) {
		let t = /* @__PURE__ */ new Map();
		if ("Texture" in z.Objects) {
			let n = z.Objects.Texture;
			for (let r in n) {
				let i = this.parseTexture(n[r], e);
				t.set(parseInt(r), i);
			}
		}
		return t;
	}
	parseTexture(e, t) {
		let n = this.loadTexture(e, t);
		n.ID = e.id, n.name = e.attrName;
		let r = e.WrapModeU, i = e.WrapModeV, a = r === void 0 ? 0 : r.value, o = i === void 0 ? 0 : i.value;
		if (n.wrapS = a === 0 ? D : b, n.wrapT = o === 0 ? D : b, "Scaling" in e) {
			let t = e.Scaling.value;
			n.repeat.x = t[0], n.repeat.y = t[1];
		}
		if ("Translation" in e) {
			let t = e.Translation.value;
			n.offset.x = t[0], n.offset.y = t[1];
		}
		return n;
	}
	loadTexture(e, t) {
		let n = e.FileName.split(".").pop().toLowerCase(), r = this.manager.getHandler(`.${n}`);
		r === null && (r = this.textureLoader);
		let i = r.path;
		i || r.setPath(this.textureLoader.path);
		let a = B.get(e.id).children, o;
		if (a !== void 0 && a.length > 0 && t[a[0].ID] !== void 0 && (o = t[a[0].ID], (o.indexOf("blob:") === 0 || o.indexOf("data:") === 0) && r.setPath(void 0)), o === void 0) return console.warn("FBXLoader: Undefined filename, creating placeholder texture."), new g();
		let s = r.load(o);
		return r.setPath(i), s;
	}
	parseMaterials(e) {
		let t = /* @__PURE__ */ new Map();
		if ("Material" in z.Objects) {
			let n = z.Objects.Material;
			for (let r in n) {
				let i = this.parseMaterial(n[r], e);
				i !== null && t.set(parseInt(r), i);
			}
		}
		return t;
	}
	parseMaterial(e, t) {
		let n = e.id, r = e.attrName, i = e.ShadingModel;
		if (typeof i == "object" && (i = i.value), !B.has(n)) return null;
		let a = this.parseParameters(e, t, n), o;
		switch (i.toLowerCase()) {
			case "phong":
				o = new d();
				break;
			case "lambert":
				o = new F();
				break;
			default: console.warn("THREE.FBXLoader: unknown material type \"%s\". Defaulting to MeshPhongMaterial.", i), o = new d();
		}
		return o.setValues(a), o.name = r, o;
	}
	parseParameters(e, t, n) {
		let r = {};
		e.BumpFactor && (r.bumpScale = e.BumpFactor.value), e.Diffuse ? r.color = M.colorSpaceToWorking(new C().fromArray(e.Diffuse.value), o) : e.DiffuseColor && (e.DiffuseColor.type === "Color" || e.DiffuseColor.type === "ColorRGB") && (r.color = M.colorSpaceToWorking(new C().fromArray(e.DiffuseColor.value), o)), e.DisplacementFactor && (r.displacementScale = e.DisplacementFactor.value), e.Emissive ? r.emissive = M.colorSpaceToWorking(new C().fromArray(e.Emissive.value), o) : e.EmissiveColor && (e.EmissiveColor.type === "Color" || e.EmissiveColor.type === "ColorRGB") && (r.emissive = M.colorSpaceToWorking(new C().fromArray(e.EmissiveColor.value), o)), e.EmissiveFactor && (r.emissiveIntensity = parseFloat(e.EmissiveFactor.value)), r.opacity = 1 - (e.TransparencyFactor ? parseFloat(e.TransparencyFactor.value) : 0), (r.opacity === 1 || r.opacity === 0) && (r.opacity = e.Opacity ? parseFloat(e.Opacity.value) : null, r.opacity === null && (r.opacity = 1)), r.opacity < 1 && (r.transparent = !0), e.ReflectionFactor && (r.reflectivity = e.ReflectionFactor.value), e.Shininess && (r.shininess = e.Shininess.value), e.Specular ? r.specular = M.colorSpaceToWorking(new C().fromArray(e.Specular.value), o) : e.SpecularColor && e.SpecularColor.type === "Color" && (r.specular = M.colorSpaceToWorking(new C().fromArray(e.SpecularColor.value), o));
		let i = this;
		return B.get(n).children.forEach(function(e) {
			let n = e.relationship;
			switch (n) {
				case "Bump":
					r.bumpMap = i.getTexture(t, e.ID);
					break;
				case "Maya|TEX_ao_map":
					r.aoMap = i.getTexture(t, e.ID);
					break;
				case "DiffuseColor":
				case "Maya|TEX_color_map":
					r.map = i.getTexture(t, e.ID), r.map !== void 0 && (r.map.colorSpace = o);
					break;
				case "DisplacementColor":
					r.displacementMap = i.getTexture(t, e.ID);
					break;
				case "EmissiveColor":
					r.emissiveMap = i.getTexture(t, e.ID), r.emissiveMap !== void 0 && (r.emissiveMap.colorSpace = o);
					break;
				case "NormalMap":
				case "Maya|TEX_normal_map":
					r.normalMap = i.getTexture(t, e.ID);
					break;
				case "ReflectionColor":
					r.envMap = i.getTexture(t, e.ID), r.envMap !== void 0 && (r.envMap.mapping = 303, r.envMap.colorSpace = o);
					break;
				case "SpecularColor":
					r.specularMap = i.getTexture(t, e.ID), r.specularMap !== void 0 && (r.specularMap.colorSpace = o);
					break;
				case "TransparentColor":
				case "TransparencyFactor":
					r.alphaMap = i.getTexture(t, e.ID), r.transparent = !0;
					break;
				default: console.warn("THREE.FBXLoader: %s map is not supported in three.js, skipping texture.", n);
			}
		}), r;
	}
	getTexture(e, t) {
		return "LayeredTexture" in z.Objects && t in z.Objects.LayeredTexture && (console.warn("THREE.FBXLoader: layered textures are not supported in three.js. Discarding all but first layer."), t = B.get(t).children[0].ID), e.get(t);
	}
	parseDeformers() {
		let e = {}, t = {};
		if ("Deformer" in z.Objects) {
			let n = z.Objects.Deformer;
			for (let r in n) {
				let i = n[r], a = B.get(parseInt(r));
				if (i.attrType === "Skin") {
					let t = this.parseSkeleton(a, n);
					t.ID = r, a.parents.length > 1 && console.warn("THREE.FBXLoader: skeleton attached to more than one geometry is not supported."), t.geometryID = a.parents[0].ID, e[r] = t;
				} else if (i.attrType === "BlendShape") {
					let e = { id: r };
					e.rawTargets = this.parseMorphTargets(a, n), e.id = r, a.parents.length > 1 && console.warn("THREE.FBXLoader: morph target attached to more than one geometry is not supported."), t[r] = e;
				}
			}
		}
		return {
			skeletons: e,
			morphTargets: t
		};
	}
	parseSkeleton(e, t) {
		let n = [];
		return e.children.forEach(function(e) {
			let r = t[e.ID];
			if (r.attrType !== "Cluster") return;
			let i = {
				ID: e.ID,
				indices: [],
				weights: [],
				transformLink: new T().fromArray(r.TransformLink.a)
			};
			"Indexes" in r && (i.indices = r.Indexes.a, i.weights = r.Weights.a), n.push(i);
		}), {
			rawBones: n,
			bones: []
		};
	}
	parseMorphTargets(e, t) {
		let n = [];
		for (let r = 0; r < e.children.length; r++) {
			let i = e.children[r], a = t[i.ID], o = {
				name: a.attrName,
				initialWeight: a.DeformPercent,
				id: a.id,
				fullWeights: a.FullWeights.a
			};
			if (a.attrType !== "BlendShapeChannel") return;
			o.geoID = B.get(parseInt(i.ID)).children.filter(function(e) {
				return e.relationship === void 0;
			})[0].ID, n.push(o);
		}
		return n;
	}
	parseScene(e, t, n) {
		V = new I();
		let r = this.parseModels(e.skeletons, t, n), i = z.Objects.Model, a = this;
		r.forEach(function(e) {
			let t = i[e.ID];
			a.setLookAtProperties(e, t), B.get(e.ID).parents.forEach(function(t) {
				let n = r.get(t.ID);
				n !== void 0 && n.add(e);
			}), e.parent === null && V.add(e);
		}), this.addGlobalSceneSettings(), V.traverse(function(e) {
			if (e.userData.transformData) {
				e.parent && (e.userData.transformData.parentMatrix = e.parent.matrix, e.userData.transformData.parentMatrixWorld = e.parent.matrixWorld);
				let t = X(e.userData.transformData);
				e.applyMatrix4(t), e.updateWorldMatrix();
			}
		});
		let o = this.parsePoseNodes(), s = /* @__PURE__ */ new Set();
		for (let t in e.skeletons) e.skeletons[t].rawBones.forEach(function(n, r) {
			let i = e.skeletons[t].bones[r];
			i && s.add(i.ID);
		});
		let c = new T();
		V.traverse(function(e) {
			if (e.isBone && e.ID !== void 0 && !s.has(e.ID)) {
				let t = o[e.ID];
				t !== void 0 && (e.parent ? (c.copy(e.parent.matrixWorld).invert(), c.multiply(t)) : c.copy(t), c.decompose(e.position, e.quaternion, e.scale), e.updateMatrix(), e.matrixWorld.copy(t));
			}
		}), this.bindSkeleton(e.skeletons, t, r);
		let l = new ge(this.trimAnimationClips).parse();
		V.children.length === 1 && V.children[0].isGroup && (V.children[0].animations = l, Object.assign(V.children[0].userData, V.userData), V = V.children[0]), V.animations = l, "GlobalSettings" in z && "UpAxis" in z.GlobalSettings && z.GlobalSettings.UpAxis.value === 2 && (console.warn("THREE.FBXLoader: You are loading an asset with a Z-UP coordinate system. The loader just rotates the asset to transform it into Y-UP. The vertex data are not converted."), V.rotation.set(-Math.PI / 2, 0, 0));
	}
	parseModels(e, t, n) {
		let r = /* @__PURE__ */ new Map(), i = z.Objects.Model;
		for (let a in i) {
			let o = parseInt(a), s = i[a], c = B.get(o), l = this.buildSkeleton(c, e, o, s.attrName);
			if (!l) {
				switch (s.attrType) {
					case "Camera":
						l = this.createCamera(c);
						break;
					case "Light":
						l = this.createLight(c);
						break;
					case "Mesh":
						l = this.createMesh(c, t, n);
						break;
					case "NurbsCurve":
						l = this.createCurve(c, t);
						break;
					case "LimbNode":
					case "Root":
						l = new y();
						break;
					default: l = new I();
				}
				l.name = s.attrName ? L.sanitizeNodeName(s.attrName) : "", l.userData.originalName = s.attrName, l.ID = o;
			}
			this.getTransformData(l, s), r.set(o, l);
		}
		return r;
	}
	buildSkeleton(e, t, n, r) {
		let i = null;
		return e.parents.forEach(function(e) {
			for (let a in t) {
				let o = t[a];
				o.rawBones.forEach(function(t, a) {
					if (t.ID === e.ID) {
						let e = i;
						i = new y(), i.matrixWorld.copy(t.transformLink), i.name = r ? L.sanitizeNodeName(r) : "", i.userData.originalName = r, i.ID = n, o.bones[a] = i, e !== null && i.add(e);
					}
				});
			}
		}), i;
	}
	createCamera(e) {
		let t, r;
		if (e.children.forEach(function(e) {
			let t = z.Objects.NodeAttribute[e.ID];
			t !== void 0 && (r = t);
		}), r === void 0) t = new n();
		else {
			let e = 0;
			r.CameraProjectionType !== void 0 && r.CameraProjectionType.value === 1 && (e = 1);
			let i = 1;
			r.NearPlane !== void 0 && (i = r.NearPlane.value / 1e3);
			let a = 1e3;
			r.FarPlane !== void 0 && (a = r.FarPlane.value / 1e3);
			let o = window.innerWidth, s = window.innerHeight;
			r.AspectWidth !== void 0 && r.AspectHeight !== void 0 && (o = r.AspectWidth.value, s = r.AspectHeight.value);
			let l = o / s, u = 45;
			r.FieldOfView !== void 0 && (u = r.FieldOfView.value);
			let d = r.FocalLength ? r.FocalLength.value : null;
			switch (e) {
				case 0:
					t = new c(u, l, i, a), d !== null && t.setFocalLength(d);
					break;
				case 1:
					console.warn("THREE.FBXLoader: Orthographic cameras not supported yet."), t = new n();
					break;
				default: console.warn("THREE.FBXLoader: Unknown camera type " + e + "."), t = new n();
			}
		}
		return t;
	}
	createLight(e) {
		let t, r;
		if (e.children.forEach(function(e) {
			let t = z.Objects.NodeAttribute[e.ID];
			t !== void 0 && (r = t);
		}), r === void 0) t = new n();
		else {
			let e;
			e = r.LightType === void 0 ? 0 : r.LightType.value;
			let n = 16777215;
			r.Color !== void 0 && (n = M.colorSpaceToWorking(new C().fromArray(r.Color.value), o));
			let s = r.Intensity === void 0 ? 1 : r.Intensity.value / 100;
			r.CastLightOnObject !== void 0 && r.CastLightOnObject.value === 0 && (s = 0);
			let c = 0;
			switch (r.FarAttenuationEnd !== void 0 && (c = r.EnableFarAttenuation !== void 0 && r.EnableFarAttenuation.value === 0 ? 0 : r.FarAttenuationEnd.value), e) {
				case 0:
					t = new i(n, s, c, 1);
					break;
				case 1:
					t = new l(n, s);
					break;
				case 2:
					let e = Math.PI / 3, o = 0;
					r.OuterAngle === void 0 ? r.InnerAngle !== void 0 && (e = j.degToRad(r.InnerAngle.value)) : (e = j.degToRad(r.OuterAngle.value), r.InnerAngle !== void 0 && (o = 1 - r.InnerAngle.value / r.OuterAngle.value, o = Math.max(0, o))), t = new a(n, s, c, e, o, 1);
					break;
				default: console.warn("THREE.FBXLoader: Unknown light type " + r.LightType.value + ", defaulting to a PointLight."), t = new i(n, s);
			}
			r.CastShadows !== void 0 && r.CastShadows.value === 1 && (t.castShadow = !0);
		}
		return t;
	}
	createMesh(e, t, n) {
		let r, i = null, a = null, o = [];
		if (e.children.forEach(function(e) {
			t.has(e.ID) && (i = t.get(e.ID)), n.has(e.ID) && o.push(n.get(e.ID));
		}), o.length > 1 ? a = o : o.length > 0 ? a = o[0] : (a = new d({
			name: A.DEFAULT_MATERIAL_NAME,
			color: 13421772
		}), o.push(a)), "color" in i.attributes && o.forEach(function(e) {
			e.vertexColors = !0;
		}), i.groups.length > 0) {
			let e = !1;
			for (let t = 0, n = i.groups.length; t < n; t++) {
				let n = i.groups[t];
				(n.materialIndex < 0 || n.materialIndex >= o.length) && (n.materialIndex = o.length, e = !0);
			}
			if (e) {
				let e = new d();
				o.push(e);
			}
		}
		return i.FBX_Deformer ? (r = new h(i, a), r.normalizeSkinWeights()) : r = new v(i, a), r;
	}
	createCurve(e, t) {
		let n = e.children.reduce(function(e, n) {
			return t.has(n.ID) && (e = t.get(n.ID)), e;
		}, null), r = new re({
			name: A.DEFAULT_MATERIAL_NAME,
			color: 3342591,
			linewidth: 1
		});
		return new S(n, r);
	}
	getTransformData(e, t) {
		let n = {};
		"InheritType" in t && (n.inheritType = parseInt(t.InheritType.value)), n.eulerOrder = "RotationOrder" in t ? Z(t.RotationOrder.value) : Z(0), "Lcl_Translation" in t && (n.translation = t.Lcl_Translation.value), "PreRotation" in t && (n.preRotation = t.PreRotation.value), "Lcl_Rotation" in t && (n.rotation = t.Lcl_Rotation.value), "PostRotation" in t && (n.postRotation = t.PostRotation.value), "Lcl_Scaling" in t && (n.scale = t.Lcl_Scaling.value), "ScalingOffset" in t && (n.scalingOffset = t.ScalingOffset.value), "ScalingPivot" in t && (n.scalingPivot = t.ScalingPivot.value), "RotationOffset" in t && (n.rotationOffset = t.RotationOffset.value), "RotationPivot" in t && (n.rotationPivot = t.RotationPivot.value), e.userData.transformData = n;
	}
	setLookAtProperties(e, t) {
		"LookAtProperty" in t && B.get(e.ID).children.forEach(function(t) {
			if (t.relationship === "LookAtProperty") {
				let n = z.Objects.Model[t.ID];
				if ("Lcl_Translation" in n) {
					let t = n.Lcl_Translation.value;
					e.target === void 0 ? e.lookAt(new w().fromArray(t)) : (e.target.position.fromArray(t), V.add(e.target));
				}
			}
		});
	}
	bindSkeleton(e, t, n) {
		for (let r in e) {
			let i = e[r], a = [];
			for (let e = 0, t = i.bones.length; e < t; e++) {
				let t = new T();
				i.bones[e] && i.rawBones[e] && t.copy(i.rawBones[e].transformLink).invert(), a.push(t);
			}
			B.get(parseInt(i.ID)).parents.forEach(function(e) {
				if (t.has(e.ID)) {
					let t = e.ID;
					B.get(t).parents.forEach(function(e) {
						if (n.has(e.ID)) {
							let t = n.get(e.ID);
							t.updateMatrixWorld(!0), t.bind(new f(i.bones, a), t.matrixWorld);
						}
					});
				}
			});
		}
	}
	parsePoseNodes() {
		let e = {};
		if ("Pose" in z.Objects) {
			let t = z.Objects.Pose;
			for (let n in t) if (t[n].attrType === "BindPose" && t[n].NbPoseNodes > 0) {
				let r = t[n].PoseNode;
				Array.isArray(r) ? r.forEach(function(t) {
					e[t.Node] = new T().fromArray(t.Matrix.a);
				}) : e[r.Node] = new T().fromArray(r.Matrix.a);
			}
		}
		return e;
	}
	addGlobalSceneSettings() {
		if ("GlobalSettings" in z) {
			if ("AmbientColor" in z.GlobalSettings) {
				let e = z.GlobalSettings.AmbientColor.value, t = e[0], n = e[1], r = e[2];
				if (t !== 0 || n !== 0 || r !== 0) {
					let e = new C().setRGB(t, n, r, o);
					V.add(new te(e, 1));
				}
			}
			"UnitScaleFactor" in z.GlobalSettings && (V.userData.unitScaleFactor = z.GlobalSettings.UnitScaleFactor.value);
		}
	}
}, he = class {
	constructor() {
		this.negativeMaterialIndices = !1;
	}
	parse(e) {
		let t = /* @__PURE__ */ new Map();
		if ("Geometry" in z.Objects) {
			let n = z.Objects.Geometry;
			for (let r in n) {
				let i = B.get(parseInt(r)), a = this.parseGeometry(i, n[r], e);
				t.set(parseInt(r), a);
			}
		}
		return this.negativeMaterialIndices === !0 && console.warn("THREE.FBXLoader: The FBX file contains invalid (negative) material indices. The asset might not render as expected."), t;
	}
	parseGeometry(e, t, n) {
		switch (t.attrType) {
			case "Mesh": return this.parseMeshGeometry(e, t, n);
			case "NurbsCurve": return this.parseNurbsGeometry(t);
		}
	}
	parseMeshGeometry(e, t, n) {
		let r = n.skeletons, i = [], a = e.parents.map(function(e) {
			return z.Objects.Model[e.ID];
		});
		if (a.length === 0) return;
		let o = e.children.reduce(function(e, t) {
			return r[t.ID] !== void 0 && (e = r[t.ID]), e;
		}, null);
		e.children.forEach(function(e) {
			n.morphTargets[e.ID] !== void 0 && i.push(n.morphTargets[e.ID]);
		});
		let s = a[0], c = {};
		"RotationOrder" in s && (c.eulerOrder = Z(s.RotationOrder.value)), "InheritType" in s && (c.inheritType = parseInt(s.InheritType.value)), "GeometricTranslation" in s && (c.translation = s.GeometricTranslation.value), "GeometricRotation" in s && (c.rotation = s.GeometricRotation.value), "GeometricScaling" in s && (c.scale = s.GeometricScaling.value);
		let l = X(c);
		return this.genGeometry(t, o, i, l);
	}
	genGeometry(t, n, r, i) {
		let a = new k();
		t.attrName && (a.name = t.attrName);
		let o = this.parseGeoNode(t, n), s = this.genBuffers(o), c = new u(s.vertex, 3);
		if (c.applyMatrix4(i), a.setAttribute("position", c), s.colors.length > 0 && a.setAttribute("color", new u(s.colors, 3)), n && (a.setAttribute("skinIndex", new e(s.weightsIndices, 4)), a.setAttribute("skinWeight", new u(s.vertexWeights, 4)), a.FBX_Deformer = n), s.normal.length > 0) {
			let e = new E().getNormalMatrix(i), t = new u(s.normal, 3);
			t.applyNormalMatrix(e), a.setAttribute("normal", t);
		}
		if (s.uvs.forEach(function(e, t) {
			let n = t === 0 ? "uv" : `uv${t}`;
			a.setAttribute(n, new u(s.uvs[t], 2));
		}), o.material && o.material.mappingType !== "AllSame") {
			let e = s.materialIndex[0], t = 0;
			if (s.materialIndex.forEach(function(n, r) {
				n !== e && (a.addGroup(t, r - t, e), e = n, t = r);
			}), a.groups.length > 0) {
				let t = a.groups[a.groups.length - 1], n = t.start + t.count;
				n !== s.materialIndex.length && a.addGroup(n, s.materialIndex.length - n, e);
			}
			a.groups.length === 0 && a.addGroup(0, s.materialIndex.length, s.materialIndex[0]);
		}
		return this.addMorphTargets(a, t, r, i), a;
	}
	parseGeoNode(e, t) {
		let n = {};
		if (n.vertexPositions = e.Vertices === void 0 ? [] : e.Vertices.a, n.vertexIndices = e.PolygonVertexIndex === void 0 ? [] : e.PolygonVertexIndex.a, e.LayerElementColor && e.LayerElementColor[0].Colors && (n.color = this.parseVertexColors(e.LayerElementColor[0])), e.LayerElementMaterial && (n.material = this.parseMaterialIndices(e.LayerElementMaterial[0])), e.LayerElementNormal && (n.normal = this.parseNormals(e.LayerElementNormal[0])), e.LayerElementUV) {
			n.uv = [];
			let t = 0;
			for (; e.LayerElementUV[t];) e.LayerElementUV[t].UV && n.uv.push(this.parseUVs(e.LayerElementUV[t])), t++;
		}
		return n.weightTable = {}, t !== null && (n.skeleton = t, t.rawBones.forEach(function(e, t) {
			e.indices.forEach(function(r, i) {
				n.weightTable[r] === void 0 && (n.weightTable[r] = []), n.weightTable[r].push({
					id: t,
					weight: e.weights[i]
				});
			});
		})), n;
	}
	genBuffers(e) {
		let t = {
			vertex: [],
			normal: [],
			colors: [],
			uvs: [],
			materialIndex: [],
			vertexWeights: [],
			weightsIndices: []
		}, n = 0, r = 0, i = !1, a = [], o = [], s = [], c = [], l = [], u = [], d = this;
		return e.vertexIndices.forEach(function(f, p) {
			let m, h = !1;
			f < 0 && (f ^= -1, h = !0);
			let g = [], _ = [];
			if (a.push(f * 3, f * 3 + 1, f * 3 + 2), e.color) {
				let t = q(p, n, f, e.color);
				s.push(t[0], t[1], t[2]);
			}
			if (e.skeleton) {
				if (e.weightTable[f] !== void 0 && e.weightTable[f].forEach(function(e) {
					_.push(e.weight), g.push(e.id);
				}), _.length > 4) {
					i ||= (console.warn("THREE.FBXLoader: Vertex has more than 4 skinning weights assigned to vertex. Deleting additional weights."), !0);
					let e = [
						0,
						0,
						0,
						0
					], t = [
						0,
						0,
						0,
						0
					];
					_.forEach(function(n, r) {
						let i = n, a = g[r];
						t.forEach(function(t, n, r) {
							if (i > t) {
								r[n] = i, i = t;
								let o = e[n];
								e[n] = a, a = o;
							}
						});
					}), g = e, _ = t;
				}
				for (; _.length < 4;) _.push(0), g.push(0);
				for (let e = 0; e < 4; ++e) l.push(_[e]), u.push(g[e]);
			}
			if (e.normal) {
				let t = q(p, n, f, e.normal);
				o.push(t[0], t[1], t[2]);
			}
			e.material && e.material.mappingType !== "AllSame" && (m = q(p, n, f, e.material)[0], m < 0 && (d.negativeMaterialIndices = !0, m = 0)), e.uv && e.uv.forEach(function(e, t) {
				let r = q(p, n, f, e);
				c[t] === void 0 && (c[t] = []), c[t].push(r[0]), c[t].push(r[1]);
			}), r++, h && (d.genFace(t, e, a, m, o, s, c, l, u, r), n++, r = 0, a = [], o = [], s = [], c = [], l = [], u = []);
		}), t;
	}
	getNormalNewell(e) {
		let t = new w(0, 0, 0);
		for (let n = 0; n < e.length; n++) {
			let r = e[n], i = e[(n + 1) % e.length];
			t.x += (r.y - i.y) * (r.z + i.z), t.y += (r.z - i.z) * (r.x + i.x), t.z += (r.x - i.x) * (r.y + i.y);
		}
		return t.normalize(), t;
	}
	getNormalTangentAndBitangent(e) {
		let t = this.getNormalNewell(e), n = (Math.abs(t.z) > .5 ? new w(0, 1, 0) : new w(0, 0, 1)).cross(t).normalize();
		return {
			normal: t,
			tangent: n,
			bitangent: t.clone().cross(n).normalize()
		};
	}
	flattenVertex(e, t, n) {
		return new x(e.dot(t), e.dot(n));
	}
	genFace(e, t, n, r, i, a, o, s, c, l) {
		let u;
		if (l > 3) {
			let e = [], r = t.baseVertexPositions || t.vertexPositions;
			for (let t = 0; t < n.length; t += 3) e.push(new w(r[n[t]], r[n[t + 1]], r[n[t + 2]]));
			let { tangent: i, bitangent: a } = this.getNormalTangentAndBitangent(e), o = [];
			for (let t of e) o.push(this.flattenVertex(t, i, a));
			u = p.triangulateShape(o, []);
		} else u = [[
			0,
			1,
			2
		]];
		for (let [l, d, f] of u) e.vertex.push(t.vertexPositions[n[l * 3]]), e.vertex.push(t.vertexPositions[n[l * 3 + 1]]), e.vertex.push(t.vertexPositions[n[l * 3 + 2]]), e.vertex.push(t.vertexPositions[n[d * 3]]), e.vertex.push(t.vertexPositions[n[d * 3 + 1]]), e.vertex.push(t.vertexPositions[n[d * 3 + 2]]), e.vertex.push(t.vertexPositions[n[f * 3]]), e.vertex.push(t.vertexPositions[n[f * 3 + 1]]), e.vertex.push(t.vertexPositions[n[f * 3 + 2]]), t.skeleton && (e.vertexWeights.push(s[l * 4]), e.vertexWeights.push(s[l * 4 + 1]), e.vertexWeights.push(s[l * 4 + 2]), e.vertexWeights.push(s[l * 4 + 3]), e.vertexWeights.push(s[d * 4]), e.vertexWeights.push(s[d * 4 + 1]), e.vertexWeights.push(s[d * 4 + 2]), e.vertexWeights.push(s[d * 4 + 3]), e.vertexWeights.push(s[f * 4]), e.vertexWeights.push(s[f * 4 + 1]), e.vertexWeights.push(s[f * 4 + 2]), e.vertexWeights.push(s[f * 4 + 3]), e.weightsIndices.push(c[l * 4]), e.weightsIndices.push(c[l * 4 + 1]), e.weightsIndices.push(c[l * 4 + 2]), e.weightsIndices.push(c[l * 4 + 3]), e.weightsIndices.push(c[d * 4]), e.weightsIndices.push(c[d * 4 + 1]), e.weightsIndices.push(c[d * 4 + 2]), e.weightsIndices.push(c[d * 4 + 3]), e.weightsIndices.push(c[f * 4]), e.weightsIndices.push(c[f * 4 + 1]), e.weightsIndices.push(c[f * 4 + 2]), e.weightsIndices.push(c[f * 4 + 3])), t.color && (e.colors.push(a[l * 3]), e.colors.push(a[l * 3 + 1]), e.colors.push(a[l * 3 + 2]), e.colors.push(a[d * 3]), e.colors.push(a[d * 3 + 1]), e.colors.push(a[d * 3 + 2]), e.colors.push(a[f * 3]), e.colors.push(a[f * 3 + 1]), e.colors.push(a[f * 3 + 2])), t.material && t.material.mappingType !== "AllSame" && (e.materialIndex.push(r), e.materialIndex.push(r), e.materialIndex.push(r)), t.normal && (e.normal.push(i[l * 3]), e.normal.push(i[l * 3 + 1]), e.normal.push(i[l * 3 + 2]), e.normal.push(i[d * 3]), e.normal.push(i[d * 3 + 1]), e.normal.push(i[d * 3 + 2]), e.normal.push(i[f * 3]), e.normal.push(i[f * 3 + 1]), e.normal.push(i[f * 3 + 2])), t.uv && t.uv.forEach(function(t, n) {
			e.uvs[n] === void 0 && (e.uvs[n] = []), e.uvs[n].push(o[n][l * 2]), e.uvs[n].push(o[n][l * 2 + 1]), e.uvs[n].push(o[n][d * 2]), e.uvs[n].push(o[n][d * 2 + 1]), e.uvs[n].push(o[n][f * 2]), e.uvs[n].push(o[n][f * 2 + 1]);
		});
	}
	addMorphTargets(e, t, n, r) {
		if (n.length === 0) return;
		e.morphTargetsRelative = !0, e.morphAttributes.position = [];
		let i = r.clone().setPosition(0, 0, 0), a = this;
		n.forEach(function(n) {
			n.rawTargets.forEach(function(n) {
				let r = z.Objects.Geometry[n.geoID];
				r !== void 0 && a.genMorphGeometry(e, t, r, i, n.name);
			});
		});
	}
	genMorphGeometry(e, t, n, r, i) {
		let a = t.Vertices === void 0 ? [] : t.Vertices.a, o = t.PolygonVertexIndex === void 0 ? [] : t.PolygonVertexIndex.a, s = n.Vertices === void 0 ? [] : n.Vertices.a, c = n.Indexes === void 0 ? [] : n.Indexes.a, l = e.attributes.position.count * 3, d = new Float32Array(l);
		for (let e = 0; e < c.length; e++) {
			let t = c[e] * 3;
			d[t] = s[e * 3], d[t + 1] = s[e * 3 + 1], d[t + 2] = s[e * 3 + 2];
		}
		let f = {
			vertexIndices: o,
			vertexPositions: d,
			baseVertexPositions: a
		}, p = this.genBuffers(f), m = new u(p.vertex, 3);
		m.name = i || n.attrName, m.applyMatrix4(r), e.morphAttributes.position.push(m);
	}
	parseNormals(e) {
		let t = e.MappingInformationType, n = e.ReferenceInformationType, r = e.Normals.a, i = [];
		return n === "IndexToDirect" && ("NormalIndex" in e ? i = e.NormalIndex.a : "NormalsIndex" in e && (i = e.NormalsIndex.a)), {
			dataSize: 3,
			buffer: r,
			indices: i,
			mappingType: t,
			referenceType: n
		};
	}
	parseUVs(e) {
		let t = e.MappingInformationType, n = e.ReferenceInformationType, r = e.UV.a, i = [];
		return n === "IndexToDirect" && (i = e.UVIndex.a), {
			dataSize: 2,
			buffer: r,
			indices: i,
			mappingType: t,
			referenceType: n
		};
	}
	parseVertexColors(e) {
		let t = e.MappingInformationType, n = e.ReferenceInformationType, r = e.Colors.a, i = [];
		n === "IndexToDirect" && (i = e.ColorIndex.a);
		for (let e = 0, t = new C(); e < r.length; e += 4) t.fromArray(r, e), M.colorSpaceToWorking(t, o), t.toArray(r, e);
		return {
			dataSize: 4,
			buffer: r,
			indices: i,
			mappingType: t,
			referenceType: n
		};
	}
	parseMaterialIndices(e) {
		let t = e.MappingInformationType, n = e.ReferenceInformationType;
		if (t === "NoMappingInformation") return {
			dataSize: 1,
			buffer: [0],
			indices: [0],
			mappingType: "AllSame",
			referenceType: n
		};
		let r = e.Materials.a, i = [];
		for (let e = 0; e < r.length; ++e) i.push(e);
		return {
			dataSize: 1,
			buffer: r,
			indices: i,
			mappingType: t,
			referenceType: n
		};
	}
	parseNurbsGeometry(e) {
		let t = parseInt(e.Order);
		if (isNaN(t)) return console.error("THREE.FBXLoader: Invalid Order %s given for geometry ID: %s", e.Order, e.id), new k();
		let n = t - 1, r = e.KnotVector.a, i = [], a = e.Points.a;
		for (let e = 0, t = a.length; e < t; e += 4) i.push(new N().fromArray(a, e));
		let o, s;
		if (e.Form === "Closed") i.push(i[0]);
		else if (e.Form === "Periodic") {
			o = n, s = r.length - 1 - o;
			for (let e = 0; e < n; ++e) i.push(i[e]);
		}
		let c = new pe(n, r, i, o, s).getPoints(i.length * 12);
		return new k().setFromPoints(c);
	}
}, ge = class {
	constructor(e) {
		this.trimAnimationClips = e;
	}
	parse() {
		let e = [], t = this.parseClips();
		if (t !== void 0) for (let n in t) {
			let r = t[n], i = this.addClip(r);
			e.push(i);
		}
		return e;
	}
	parseClips() {
		if (z.Objects.AnimationCurve === void 0) return;
		let e = this.parseAnimationCurveNodes();
		this.parseAnimationCurves(e);
		let t = this.parseAnimationLayers(e);
		return this.parseAnimStacks(t);
	}
	parseAnimationCurveNodes() {
		let e = z.Objects.AnimationCurveNode, t = /* @__PURE__ */ new Map();
		for (let n in e) {
			let r = e[n];
			if (r.attrName.match(/S|R|T|DeformPercent/) !== null) {
				let e = {
					id: r.id,
					attr: r.attrName,
					curves: {}
				};
				t.set(e.id, e);
			}
		}
		return t;
	}
	parseAnimationCurves(e) {
		let t = z.Objects.AnimationCurve;
		for (let n in t) {
			let r = {
				id: t[n].id,
				times: t[n].KeyTime.a.map(K),
				values: t[n].KeyValueFloat.a
			}, i = B.get(r.id);
			if (i !== void 0) {
				let t = i.parents[0].ID, n = i.parents[0].relationship;
				n.match(/X/) ? e.get(t).curves.x = r : n.match(/Y/) ? e.get(t).curves.y = r : n.match(/Z/) ? e.get(t).curves.z = r : n.match(/DeformPercent/) && e.has(t) && (e.get(t).curves.morph = r);
			}
		}
	}
	parseAnimationLayers(e) {
		let t = z.Objects.AnimationLayer, n = /* @__PURE__ */ new Map();
		for (let r in t) {
			let t = [], i = B.get(parseInt(r));
			i !== void 0 && (i.children.forEach(function(n, r) {
				if (e.has(n.ID)) {
					let i = e.get(n.ID);
					if (i.curves.x !== void 0 || i.curves.y !== void 0 || i.curves.z !== void 0) {
						if (t[r] === void 0) {
							let e = B.get(n.ID).parents.filter(function(e) {
								return e.relationship !== void 0;
							});
							if (e.length === 0) return;
							let i = e[0].ID;
							if (i !== void 0) {
								let e = z.Objects.Model[i.toString()];
								if (e === void 0) {
									console.warn("THREE.FBXLoader: Encountered a unused curve.", n);
									return;
								}
								let a = {
									modelName: e.attrName ? L.sanitizeNodeName(e.attrName) : "",
									ID: e.id,
									initialPosition: [
										0,
										0,
										0
									],
									initialRotation: [
										0,
										0,
										0
									],
									initialScale: [
										1,
										1,
										1
									]
								};
								V.traverse(function(t) {
									t.ID === e.id && (a.transform = t.matrix, t.userData.transformData && (a.eulerOrder = t.userData.transformData.eulerOrder, t.userData.transformData.rotation && (a.initialRotation = t.userData.transformData.rotation)));
								}), a.transform ||= new T(), "PreRotation" in e && (a.preRotation = e.PreRotation.value), "PostRotation" in e && (a.postRotation = e.PostRotation.value), t[r] = a;
							}
						}
						t[r] && (t[r][i.attr] = i);
					} else if (i.curves.morph !== void 0) {
						if (t[r] === void 0) {
							let e = B.get(n.ID).parents.filter(function(e) {
								return e.relationship !== void 0;
							});
							if (e.length === 0) return;
							let i = e[0].ID, a = B.get(i).parents[0].ID, o = B.get(a).parents[0].ID, s = B.get(o).parents[0].ID, c = z.Objects.Model[s], l = {
								modelName: c.attrName ? L.sanitizeNodeName(c.attrName) : "",
								morphName: z.Objects.Deformer[i].attrName
							};
							t[r] = l;
						}
						t[r][i.attr] = i;
					}
				}
			}), n.set(parseInt(r), t));
		}
		return n;
	}
	parseAnimStacks(e) {
		let t = z.Objects.AnimationStack, n = {};
		for (let r in t) {
			let i = B.get(parseInt(r)).children;
			i.length > 1 && console.warn("THREE.FBXLoader: Encountered an animation stack with multiple layers, this is currently not supported. Ignoring subsequent layers.");
			let a = e.get(i[0].ID), o = t[r];
			n[r] = {
				name: o.attrName,
				layer: a,
				localStart: o.LocalStart === void 0 ? 0 : K(Number(o.LocalStart.value)),
				localStop: o.LocalStop === void 0 ? 0 : K(Number(o.LocalStop.value))
			};
		}
		return n;
	}
	addClip(e) {
		let t = [], n = this;
		return e.layer.forEach(function(e) {
			t = t.concat(n.generateTracks(e));
		}), this.trimAnimationClips === !0 && e.localStop > e.localStart && (t = this.trimTracks(t, e.localStart, e.localStop)), new ne(e.name, -1, t);
	}
	trimTracks(e, t, n) {
		let r = Math.fround(t), i = Math.fround(n), a = [];
		for (let t = 0; t < e.length; t++) {
			let n = e[t], o = n.getValueSize(), s = [], c = [];
			for (let e = 0; e < n.times.length; e++) {
				let t = n.times[e];
				if (!(t < r || t > i)) {
					s.push(t - r);
					for (let t = 0; t < o; t++) c.push(n.values[e * o + t]);
				}
			}
			s.length !== 0 && (n.times = new Float32Array(s), n.values = new Float32Array(c), a.push(n));
		}
		return a;
	}
	generateTracks(e) {
		let t = [], n = new w(), i = new w();
		if (e.transform && e.transform.decompose(n, new r(), i), n = n.toArray(), i = i.toArray(), e.T !== void 0 && Object.keys(e.T.curves).length > 0) {
			let r = this.generateVectorTrack(e.modelName, e.T.curves, n, "position");
			r !== void 0 && t.push(r);
		}
		if (e.R !== void 0 && Object.keys(e.R.curves).length > 0) {
			let n = this.generateRotationTrack(e.modelName, e.R.curves, e.preRotation, e.postRotation, e.eulerOrder, e.initialRotation);
			n !== void 0 && t.push(n);
		}
		if (e.S !== void 0 && Object.keys(e.S.curves).length > 0) {
			let n = this.generateVectorTrack(e.modelName, e.S.curves, i, "scale");
			n !== void 0 && t.push(n);
		}
		if (e.DeformPercent !== void 0) {
			let n = this.generateMorphTrack(e);
			n !== void 0 && t.push(n);
		}
		return t;
	}
	generateVectorTrack(e, t, n, r) {
		let i = this.getTimesForAllAxes(t), a = this.getKeyframeTrackValues(i, t, n);
		return new ee(e + "." + r, i, a);
	}
	generateRotationTrack(e, n, i, a, o, s) {
		let c, l;
		if (n.x !== void 0 || n.y !== void 0 || n.z !== void 0) {
			let e = this.getTimesForAllAxes(n);
			if (e.length > 0) {
				let t = s || [
					0,
					0,
					0
				], r = this.synchronizeCurve(n.x, e, t[0]), i = this.synchronizeCurve(n.y, e, t[1]), a = this.synchronizeCurve(n.z, e, t[2]), u = this.interpolateRotations(r, i, a, o);
				c = u[0], l = u[1];
			}
		}
		let u = Z(0);
		i !== void 0 && (i = i.map(j.degToRad), i.push(u), i = new t().fromArray(i), i = new r().setFromEuler(i)), a !== void 0 && (a = a.map(j.degToRad), a.push(u), a = new t().fromArray(a), a = new r().setFromEuler(a).invert());
		let d = new r(), f = new t(), p = [];
		if (l && c) {
			for (let e = 0; e < l.length; e += 3) f.set(l[e], l[e + 1], l[e + 2], o), d.setFromEuler(f), i !== void 0 && d.premultiply(i), a !== void 0 && d.multiply(a), e > 2 && new r().fromArray(p, (e - 3) / 3 * 4).dot(d) < 0 && d.set(-d.x, -d.y, -d.z, -d.w), d.toArray(p, e / 3 * 4);
			return new m(e + ".quaternion", c, p);
		}
	}
	generateMorphTrack(e) {
		let t = e.DeformPercent.curves.morph, n = t.values.map(function(e) {
			return e / 100;
		}), r = V.getObjectByName(e.modelName).morphTargetDictionary[e.morphName];
		return new O(e.modelName + ".morphTargetInfluences[" + r + "]", t.times, n);
	}
	getTimesForAllAxes(e) {
		let t = [];
		if (e.x !== void 0 && (t = t.concat(e.x.times)), e.y !== void 0 && (t = t.concat(e.y.times)), e.z !== void 0 && (t = t.concat(e.z.times)), t = t.sort(function(e, t) {
			return e - t;
		}), t.length > 1) {
			let e = 1, n = t[0];
			for (let r = 1; r < t.length; r++) {
				let i = t[r];
				i !== n && (t[e] = i, n = i, e++);
			}
			t = t.slice(0, e);
		}
		return t;
	}
	getKeyframeTrackValues(e, t, n) {
		let r = n, i = [], a = -1, o = -1, s = -1;
		return e.forEach(function(e) {
			if (t.x && (a = t.x.times.indexOf(e)), t.y && (o = t.y.times.indexOf(e)), t.z && (s = t.z.times.indexOf(e)), a !== -1) {
				let e = t.x.values[a];
				i.push(e), r[0] = e;
			} else i.push(r[0]);
			if (o !== -1) {
				let e = t.y.values[o];
				i.push(e), r[1] = e;
			} else i.push(r[1]);
			if (s !== -1) {
				let e = t.z.values[s];
				i.push(e), r[2] = e;
			} else i.push(r[2]);
		}), i;
	}
	synchronizeCurve(e, t, n) {
		if (e === void 0) return {
			times: t,
			values: t.map(() => n)
		};
		if (e.times.length === t.length) return e;
		let r = [];
		for (let i = 0; i < t.length; i++) r.push(this.sampleCurveValue(e, t[i], n));
		return {
			times: t,
			values: r
		};
	}
	sampleCurveValue(e, t, n) {
		let r = e.times, i = e.values;
		if (t <= r[0]) return i[0];
		if (t >= r[r.length - 1]) return i[i.length - 1];
		for (let e = 0; e < r.length - 1; e++) if (t >= r[e] && t <= r[e + 1]) {
			if (r[e] === t) return i[e];
			let n = (t - r[e]) / (r[e + 1] - r[e]);
			return i[e] * (1 - n) + i[e + 1] * n;
		}
		return n;
	}
	interpolateRotations(e, n, i, a) {
		let o = [], s = [];
		o.push(e.times[0]), s.push(j.degToRad(e.values[0])), s.push(j.degToRad(n.values[0])), s.push(j.degToRad(i.values[0]));
		for (let c = 1; c < e.values.length; c++) {
			let l = [
				e.values[c - 1],
				n.values[c - 1],
				i.values[c - 1]
			];
			if (isNaN(l[0]) || isNaN(l[1]) || isNaN(l[2])) continue;
			let u = l.map(j.degToRad), d = [
				e.values[c],
				n.values[c],
				i.values[c]
			];
			if (isNaN(d[0]) || isNaN(d[1]) || isNaN(d[2])) continue;
			let f = d.map(j.degToRad), p = [
				d[0] - l[0],
				d[1] - l[1],
				d[2] - l[2]
			], m = [
				Math.abs(p[0]),
				Math.abs(p[1]),
				Math.abs(p[2])
			];
			if (m[0] >= 180 || m[1] >= 180 || m[2] >= 180) {
				let n = Math.max(...m) / 180, i = new t(...u, a), l = new t(...f, a), d = new r().setFromEuler(i), p = new r().setFromEuler(l);
				d.dot(p) < 0 && p.set(-p.x, -p.y, -p.z, -p.w);
				let h = e.times[c - 1], g = e.times[c] - h, _ = new r(), v = new t();
				for (let e = 0; e < 1; e += 1 / n) _.copy(d.clone().slerp(p.clone(), e)), o.push(h + e * g), v.setFromQuaternion(_, a), s.push(v.x), s.push(v.y), s.push(v.z);
			} else o.push(e.times[c]), s.push(j.degToRad(e.values[c])), s.push(j.degToRad(n.values[c])), s.push(j.degToRad(i.values[c]));
		}
		return [o, s];
	}
}, _e = class {
	getPrevNode() {
		return this.nodeStack[this.currentIndent - 2];
	}
	getCurrentNode() {
		return this.nodeStack[this.currentIndent - 1];
	}
	getCurrentProp() {
		return this.currentProp;
	}
	pushStack(e) {
		this.nodeStack.push(e), this.currentIndent += 1;
	}
	popStack() {
		this.nodeStack.pop(), --this.currentIndent;
	}
	setCurrentProp(e, t) {
		this.currentProp = e, this.currentPropName = t;
	}
	parse(e) {
		this.currentIndent = 0, this.allNodes = new W(), this.nodeStack = [], this.currentProp = [], this.currentPropName = "";
		let t = this, n = e.split(/[\r\n]+/);
		return n.forEach(function(e, r) {
			let i = e.match(/^[\s\t]*;/), a = e.match(/^[\s\t]*$/);
			if (i || a) return;
			let o = e.match("^\\t{" + t.currentIndent + "}(\\w+):(.*){", ""), s = e.match("^\\t{" + t.currentIndent + "}(\\w+):[\\s\\t\\r\\n](.*)"), c = e.match("^\\t{" + (t.currentIndent - 1) + "}}");
			o ? t.parseNodeBegin(e, o) : s ? t.parseNodeProperty(e, s, n[++r]) : c ? t.popStack() : e.match(/^[^\s\t}]/) && t.parseNodePropertyContinued(e);
		}), this.allNodes;
	}
	parseNodeBegin(e, t) {
		let n = t[1].trim().replace(/^"/, "").replace(/"$/, ""), r = t[2].split(",").map(function(e) {
			return e.trim().replace(/^"/, "").replace(/"$/, "");
		}), i = { name: n }, a = this.parseNodeAttr(r), o = this.getCurrentNode();
		this.currentIndent === 0 ? this.allNodes.add(n, i) : n in o ? (n === "PoseNode" ? o.PoseNode.push(i) : o[n].id !== void 0 && (o[n] = {}, o[n][o[n].id] = o[n]), a.id !== "" && (o[n][a.id] = i)) : typeof a.id == "number" ? (o[n] = {}, o[n][a.id] = i) : n !== "Properties70" && (o[n] = n === "PoseNode" ? [i] : i), typeof a.id == "number" && (i.id = a.id), a.name !== "" && (i.attrName = a.name), a.type !== "" && (i.attrType = a.type), this.pushStack(i);
	}
	parseNodeAttr(e) {
		let t = e[0];
		e[0] !== "" && (t = parseInt(e[0]), isNaN(t) && (t = e[0]));
		let n = "", r = "";
		return e.length > 1 && (n = e[1].replace(/^(\w+)::/, ""), r = e[2]), {
			id: t,
			name: n,
			type: r
		};
	}
	parseNodeProperty(e, t, n) {
		let r = t[1].replace(/^"/, "").replace(/"$/, "").trim(), i = t[2].replace(/^"/, "").replace(/"$/, "").trim();
		r === "Content" && i === "," && (i = n.replace(/"/g, "").replace(/,$/, "").trim());
		let a = this.getCurrentNode();
		if (a.name === "Properties70") this.parseNodeSpecialProperty(e, r, i);
		else {
			if (r === "C") {
				let e = i.split(",").slice(1), t = parseInt(e[0]), n = parseInt(e[1]), o = i.split(",").slice(3);
				o = o.map(function(e) {
					return e.trim().replace(/^"/, "");
				}), r = "connections", i = [t, n], Se(i, o), a[r] === void 0 && (a[r] = []);
			}
			r === "Node" && (a.id = i), r in a && Array.isArray(a[r]) ? a[r].push(i) : r === "a" ? a.a = i : a[r] = i, this.setCurrentProp(a, r), r === "a" && i.slice(-1) !== "," && (a.a = Q(i));
		}
	}
	parseNodePropertyContinued(e) {
		let t = this.getCurrentNode();
		t.a += e, e.slice(-1) !== "," && (t.a = Q(t.a));
	}
	parseNodeSpecialProperty(e, t, n) {
		let r = n.split("\",").map(function(e) {
			return e.trim().replace(/^\"/, "").replace(/\s/, "_");
		}), i = r[0], a = r[1], o = r[2], s = r[3], c = r[4];
		switch (a) {
			case "int":
			case "enum":
			case "bool":
			case "ULongLong":
			case "double":
			case "Number":
			case "FieldOfView":
				c = parseFloat(c);
				break;
			case "Color":
			case "ColorRGB":
			case "Vector3D":
			case "Lcl_Translation":
			case "Lcl_Rotation":
			case "Lcl_Scaling": c = Q(c);
		}
		this.getPrevNode()[i] = {
			type: a,
			type2: o,
			flag: s,
			value: c
		}, this.setCurrentProp(this.getPrevNode(), i);
	}
}, ve = class {
	parse(e) {
		let t = new U(e);
		t.skip(23);
		let n = t.getUint32();
		if (n < 6400) throw Error("THREE.FBXLoader: FBX version not supported, FileVersion: " + n);
		let r = new W();
		for (; !this.endOfContent(t);) {
			let e = this.parseNode(t, n);
			e !== null && r.add(e.name, e);
		}
		return r;
	}
	endOfContent(e) {
		return e.size() % 16 == 0 ? (e.getOffset() + 160 + 16 & -16) >= e.size() : e.getOffset() + 160 + 16 >= e.size();
	}
	parseNode(e, t) {
		let n = {}, r = t >= 7500 ? e.getUint64() : e.getUint32(), i = t >= 7500 ? e.getUint64() : e.getUint32();
		t >= 7500 ? e.getUint64() : e.getUint32();
		let a = e.getUint8(), o = e.getString(a);
		if (r === 0) return null;
		let s = [];
		for (let t = 0; t < i; t++) s.push(this.parseProperty(e));
		let c = s.length > 0 ? s[0] : "", l = s.length > 1 ? s[1] : "", u = s.length > 2 ? s[2] : "";
		for (n.singleProperty = i === 1 && e.getOffset() === r; r > e.getOffset();) {
			let r = this.parseNode(e, t);
			r !== null && this.parseSubNode(o, n, r);
		}
		return n.propertyList = s, typeof c == "number" && (n.id = c), l !== "" && (n.attrName = l), u !== "" && (n.attrType = u), o !== "" && (n.name = o), n;
	}
	parseSubNode(e, t, n) {
		if (n.singleProperty === !0) {
			let e = n.propertyList[0];
			Array.isArray(e) ? (t[n.name] = n, n.a = e) : t[n.name] = e;
		} else if (e === "Connections" && n.name === "C") {
			let e = [];
			n.propertyList.forEach(function(t, n) {
				n !== 0 && e.push(t);
			}), t.connections === void 0 && (t.connections = []), t.connections.push(e);
		} else if (n.name === "Properties70") Object.keys(n).forEach(function(e) {
			t[e] = n[e];
		});
		else if (e === "Properties70" && n.name === "P") {
			let e = n.propertyList[0], r = n.propertyList[1], i = n.propertyList[2], a = n.propertyList[3], o;
			e.indexOf("Lcl ") === 0 && (e = e.replace("Lcl ", "Lcl_")), r.indexOf("Lcl ") === 0 && (r = r.replace("Lcl ", "Lcl_")), o = r === "Color" || r === "ColorRGB" || r === "Vector" || r === "Vector3D" || r.indexOf("Lcl_") === 0 ? [
				n.propertyList[4],
				n.propertyList[5],
				n.propertyList[6]
			] : n.propertyList[4], t[e] = {
				type: r,
				type2: i,
				flag: a,
				value: o
			};
		} else t[n.name] === void 0 ? typeof n.id == "number" ? (t[n.name] = {}, t[n.name][n.id] = n) : t[n.name] = n : n.name === "PoseNode" ? (Array.isArray(t[n.name]) || (t[n.name] = [t[n.name]]), t[n.name].push(n)) : t[n.name][n.id] === void 0 && (t[n.name][n.id] = n);
	}
	parseProperty(e) {
		let t = e.getString(1), n;
		switch (t) {
			case "C": return e.getBoolean();
			case "D": return e.getFloat64();
			case "F": return e.getFloat32();
			case "I": return e.getInt32();
			case "L": return e.getInt64();
			case "R": return n = e.getUint32(), e.getArrayBuffer(n);
			case "S": return n = e.getUint32(), e.getString(n);
			case "Y": return e.getInt16();
			case "b":
			case "c":
			case "d":
			case "f":
			case "i":
			case "l":
				let r = e.getUint32(), i = e.getUint32(), a = e.getUint32();
				if (i === 0) switch (t) {
					case "b":
					case "c": return e.getBooleanArray(r);
					case "d": return e.getFloat64Array(r);
					case "f": return e.getFloat32Array(r);
					case "i": return e.getInt32Array(r);
					case "l": return e.getInt64Array(r);
				}
				let o = new U(ae(new Uint8Array(e.getArrayBuffer(a))).buffer);
				switch (t) {
					case "b":
					case "c": return o.getBooleanArray(r);
					case "d": return o.getFloat64Array(r);
					case "f": return o.getFloat32Array(r);
					case "i": return o.getInt32Array(r);
					case "l": return o.getInt64Array(r);
				}
				break;
			default: throw Error("THREE.FBXLoader: Unknown property type " + t);
		}
	}
}, U = class {
	constructor(e, t) {
		this.dv = new DataView(e), this.offset = 0, this.littleEndian = t === void 0 || t, this._textDecoder = new TextDecoder();
	}
	getOffset() {
		return this.offset;
	}
	size() {
		return this.dv.buffer.byteLength;
	}
	skip(e) {
		this.offset += e;
	}
	getBoolean() {
		return (this.getUint8() & 1) == 1;
	}
	getBooleanArray(e) {
		let t = [];
		for (let n = 0; n < e; n++) t.push(this.getBoolean());
		return t;
	}
	getUint8() {
		let e = this.dv.getUint8(this.offset);
		return this.offset += 1, e;
	}
	getInt16() {
		let e = this.dv.getInt16(this.offset, this.littleEndian);
		return this.offset += 2, e;
	}
	getInt32() {
		let e = this.dv.getInt32(this.offset, this.littleEndian);
		return this.offset += 4, e;
	}
	getInt32Array(e) {
		let t = [];
		for (let n = 0; n < e; n++) t.push(this.getInt32());
		return t;
	}
	getUint32() {
		let e = this.dv.getUint32(this.offset, this.littleEndian);
		return this.offset += 4, e;
	}
	getInt64() {
		let e, t;
		return this.littleEndian ? (e = this.getUint32(), t = this.getUint32()) : (t = this.getUint32(), e = this.getUint32()), t & 2147483648 ? (t = ~t | 0, e = ~e | 0, e === 4294967295 && (t = t + 1 | 0), e = e + 1 | 0, -(t * 4294967296 + e)) : t * 4294967296 + e;
	}
	getInt64Array(e) {
		let t = [];
		for (let n = 0; n < e; n++) t.push(this.getInt64());
		return t;
	}
	getUint64() {
		let e, t;
		return this.littleEndian ? (e = this.getUint32(), t = this.getUint32()) : (t = this.getUint32(), e = this.getUint32()), t * 4294967296 + e;
	}
	getFloat32() {
		let e = this.dv.getFloat32(this.offset, this.littleEndian);
		return this.offset += 4, e;
	}
	getFloat32Array(e) {
		let t = [];
		for (let n = 0; n < e; n++) t.push(this.getFloat32());
		return t;
	}
	getFloat64() {
		let e = this.dv.getFloat64(this.offset, this.littleEndian);
		return this.offset += 8, e;
	}
	getFloat64Array(e) {
		let t = [];
		for (let n = 0; n < e; n++) t.push(this.getFloat64());
		return t;
	}
	getArrayBuffer(e) {
		let t = this.dv.buffer.slice(this.offset, this.offset + e);
		return this.offset += e, t;
	}
	getString(e) {
		let t = this.offset, n = new Uint8Array(this.dv.buffer, t, e);
		this.skip(e);
		let r = n.indexOf(0);
		return r >= 0 && (n = new Uint8Array(this.dv.buffer, t, r)), this._textDecoder.decode(n);
	}
}, W = class {
	add(e, t) {
		this[e] = t;
	}
};
function ye(e) {
	return e.byteLength >= 21 && $(e, 0, 21) === "Kaydara FBX Binary  \0";
}
function be(e) {
	let t = [
		"K",
		"a",
		"y",
		"d",
		"a",
		"r",
		"a",
		"\\",
		"F",
		"B",
		"X",
		"\\",
		"B",
		"i",
		"n",
		"a",
		"r",
		"y",
		"\\",
		"\\"
	], n = 0;
	function r(t) {
		let r = e[t - 1];
		return e = e.slice(n + t), n++, r;
	}
	for (let e = 0; e < t.length; ++e) if (r(1) === t[e]) return !1;
	return !0;
}
function G(e) {
	let t = e.match(/FBXVersion: (\d+)/);
	if (t) return parseInt(t[1]);
	throw Error("THREE.FBXLoader: Cannot find the version number for the file given.");
}
function K(e) {
	return e / 46186158e3;
}
var xe = [];
function q(e, t, n, r) {
	let i;
	switch (r.mappingType) {
		case "ByPolygonVertex":
			i = e;
			break;
		case "ByPolygon":
			i = t;
			break;
		case "ByVertice":
			i = n;
			break;
		case "AllSame":
			i = r.indices[0];
			break;
		default: console.warn("THREE.FBXLoader: unknown attribute mapping type " + r.mappingType);
	}
	r.referenceType === "IndexToDirect" && (i = r.indices[i]);
	let a = i * r.dataSize, o = a + r.dataSize;
	return Ce(xe, r.buffer, a, o);
}
var J = new t(), Y = new w();
function X(e) {
	let t = new T(), n = new T(), r = new T(), i = new T(), a = new T(), o = new T(), s = new T(), c = new T(), l = new T(), u = new T(), d = new T(), f = new T(), p = e.inheritType ? e.inheritType : 0;
	e.translation && t.setPosition(Y.fromArray(e.translation));
	let m = Z(0);
	if (e.preRotation) {
		let t = e.preRotation.map(j.degToRad);
		t.push(m), n.makeRotationFromEuler(J.fromArray(t));
	}
	if (e.rotation) {
		let t = e.rotation.map(j.degToRad);
		t.push(e.eulerOrder || m), r.makeRotationFromEuler(J.fromArray(t));
	}
	if (e.postRotation) {
		let t = e.postRotation.map(j.degToRad);
		t.push(m), i.makeRotationFromEuler(J.fromArray(t)), i.invert();
	}
	e.scale && a.scale(Y.fromArray(e.scale)), e.scalingOffset && s.setPosition(Y.fromArray(e.scalingOffset)), e.scalingPivot && o.setPosition(Y.fromArray(e.scalingPivot)), e.rotationOffset && c.setPosition(Y.fromArray(e.rotationOffset)), e.rotationPivot && l.setPosition(Y.fromArray(e.rotationPivot)), e.parentMatrixWorld && (d.copy(e.parentMatrix), u.copy(e.parentMatrixWorld));
	let h = n.clone().multiply(r).multiply(i), g = new T();
	g.extractRotation(u);
	let _ = new T();
	_.copyPosition(u);
	let v = _.clone().invert().multiply(u), y = g.clone().invert().multiply(v), b = a, x = new T();
	if (p === 0) x.copy(g).multiply(h).multiply(y).multiply(b);
	else if (p === 1) x.copy(g).multiply(y).multiply(h).multiply(b);
	else {
		let e = new T().scale(new w().setFromMatrixScale(d)).clone().invert(), t = y.clone().multiply(e);
		x.copy(g).multiply(h).multiply(t).multiply(b);
	}
	let S = l.clone().invert(), C = o.clone().invert(), E = t.clone().multiply(c).multiply(l).multiply(n).multiply(r).multiply(i).multiply(S).multiply(s).multiply(o).multiply(a).multiply(C), D = new T().copyPosition(E), O = u.clone().multiply(D);
	return f.copyPosition(O), E = f.clone().multiply(x), E.premultiply(u.invert()), E;
}
function Z(e) {
	e ||= 0;
	let t = [
		"ZYX",
		"YZX",
		"XZY",
		"ZXY",
		"YXZ",
		"XYZ"
	];
	return e === 6 ? (console.warn("THREE.FBXLoader: unsupported Euler Order: Spherical XYZ. Animations and rotations may be incorrect."), t[0]) : t[e];
}
function Q(e) {
	return e.split(",").map(function(e) {
		return parseFloat(e);
	});
}
function $(e, t, n) {
	return t === void 0 && (t = 0), n === void 0 && (n = e.byteLength), new TextDecoder().decode(new Uint8Array(e, t, n));
}
function Se(e, t) {
	for (let n = 0, r = e.length, i = t.length; n < i; n++, r++) e[r] = t[n];
}
function Ce(e, t, n, r) {
	for (let i = n, a = 0; i < r; i++, a++) e[a] = t[i];
	return e;
}
//#endregion
export { me as FBXLoader };

//# sourceMappingURL=FBXLoader-DpT2LdDo.js.map