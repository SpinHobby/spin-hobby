import { type ClipKind, type Contour } from '../../../scene3d/src/index.js';
export declare function OutlineDialog({ onPick, onClose, }: {
    onPick: (outline: Contour[], aspect: number, name: string) => void;
    onClose: () => void;
}): import("react").JSX.Element;
export declare const FONTS: string[];
export declare function TextDialog({ initial, onDone, onClose, }: {
    initial?: {
        value: string;
        font: string;
        weight: number;
    };
    onDone: (text: {
        value: string;
        font: string;
        weight: number;
    }) => void;
    onClose: () => void;
}): import("react").JSX.Element;
export declare function VideoDialog({ onMake, onClose }: {
    onMake: (kind: ClipKind, seconds: number, size: number) => void;
    onClose: () => void;
}): import("react").JSX.Element;
