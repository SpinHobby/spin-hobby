import type { ModelDocument } from './document.js';
/**
 * Short clips of a 3D design, made in the browser: a turntable (the camera goes once round), a bounce (it rocks side to side) or a light sweep (the
 * light goes once round, so the shadows play). Every frame is drawn by the shader off screen and encoded by the browser's own video encoder
 * (WebCodecs, through Mediabunny): H.264 in MP4 where the browser has it, VP9 in WebM otherwise.
 */
export declare const CLIPS: {
    readonly turntable: "Turntable";
    readonly bounce: "Bounce";
    readonly light: "Light sweep";
};
export type ClipKind = keyof typeof CLIPS;
export interface ClipOptions {
    kind: ClipKind;
    /** Length in seconds (1-20). */
    seconds?: number;
    fps?: number;
    /** Pixels on the long side (frames are even-sized for the encoder). */
    size?: number;
    /** Width over height of the frame. */
    aspect?: number;
    onProgress?: (done: number) => void;
}
/** The design at time `t` (0-1) of a clip. */
export declare function clipFrame(doc: ModelDocument, kind: ClipKind, t: number): ModelDocument;
export declare function recordClip(doc: ModelDocument, options: ClipOptions): Promise<{
    blob: Blob;
    type: string;
    extension: string;
}>;
