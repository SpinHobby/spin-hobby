import * as THREE from 'three';
import { type ModelDocument, type ShapeRef } from './document.js';
import type { ModelEditor } from './editor.js';
/**
 * Draws a 3D design in a page and lets a person work on it: the design is ray marched on a full-screen quad (glsl.ts), and on top sit an orbiting
 * camera, a gizmo to move, turn and resize the picked shape or group, and a box round it. Every change goes through the ModelEditor, so it is
 * undoable. ModelPainter draws pictures and video frames off screen with the same shader.
 */
export type GizmoMode = 'translate' | 'rotate' | 'scale';
export interface ViewportHooks {
    /** A shape was clicked (its place in the design), or empty space (null). */
    onPick?: (ref: ShapeRef | null) => void;
}
/** The camera's place in the scene from the design's orbit settings. */
export declare function cameraPose(cam: ModelDocument['camera']): {
    position: THREE.Vector3;
    target: THREE.Vector3;
};
/** A camera that sees exactly what the shader draws (for imported models and the depth they share): `frame` widens it the same way. */
export declare function designCamera(doc: ModelDocument, aspect: number, frame?: number): THREE.PerspectiveCamera | THREE.OrthographicCamera;
export declare class ModelViewport {
    private readonly container;
    private readonly editor;
    private readonly hooks;
    readonly canvas: HTMLCanvasElement;
    private readonly renderer;
    private readonly atlas;
    private readonly uniforms;
    private readonly meshes;
    private readonly quadScene;
    private readonly quadCamera;
    private readonly overlay;
    private readonly perspective;
    private readonly ortho;
    private orbit;
    private readonly gizmo;
    private readonly proxy;
    private readonly outline;
    private selected;
    private doc;
    private width;
    private height;
    private frame;
    /** Set while the design's camera is being written into the controls, so the controls' change does not write it back. */
    private applying;
    private readonly resize;
    /** While the gizmo is dragged: the shape (or a group's shapes) as they were, where the proxy was, and the box's size. */
    private gizmoStart;
    private down;
    private readonly unsubscribe;
    /** The editing grid's cell (scene units), 0 for none, and whether moves snap to it. */
    private grid;
    private snap;
    constructor(container: HTMLElement, editor: ModelEditor, hooks?: ViewportHooks);
    private activeCamera;
    private makeOrbit;
    /** The design changed (an edit, an undo, a load): the shader, cameras, gizmo and selection box follow. */
    setDocument(doc: ModelDocument): void;
    /** The picked shape or group (its place in the design), or null. */
    select(ref: ShapeRef | null): void;
    setGizmo(mode: GizmoMode): void;
    /**
     * The grid on the ground, `size` scene units a cell (0 hides it), only on screen. With `snap`, a drag moves a shape or group in whole cells from
     * where it started (so one resting on the ground stays there) and turns it in 15° steps.
     */
    setGrid(size: number, snap?: boolean): void;
    private placeProxy;
    private gizmoBegin;
    private gizmoChange;
    private gizmoEnd;
    /** The design's camera into the Three.js cameras and the orbit controls. */
    private applyCamera;
    /** The orbit controls moved the camera: written back into the design (one undo step per drag). */
    private orbitChange;
    private onPointerDown;
    /** A click without a drag picks the shape under it (by marching the same field on the CPU). */
    private onPointerUp;
    private fit;
    /** Draws on the next frame (several changes in one frame draw once). */
    request(): void;
    private draw;
    dispose(): void;
}
/**
 * Draws designs off screen with the same shader: pictures (in tiles, so a big one does not stall the graphics card) and video frames. Reuse one
 * for many frames; dispose it after.
 */
export declare class ModelPainter {
    readonly canvas: HTMLCanvasElement;
    private readonly renderer;
    private readonly atlas;
    private readonly uniforms;
    private readonly meshes;
    private readonly scene;
    private readonly camera;
    constructor();
    /**
     * Draws a design onto the painter's canvas at `width` x `height`. `samples` 2 gives four samples a pixel (smooth edges); `frame` widens the view
     * from the same camera. A big picture is drawn in tiles, with a pause between them so the page stays responsive.
     */
    paint(doc: ModelDocument, width: number, height: number, options?: {
        samples?: 1 | 2;
        frame?: number;
        tile?: number;
    }): Promise<HTMLCanvasElement>;
    dispose(): void;
}
/** Renders a design to a picture file, off screen, with four samples a pixel. Transparent where there is nothing, unless it has a background colour. */
export declare function renderModel(doc: ModelDocument, width: number, height: number, type?: 'image/png' | 'image/jpeg', 
/** Widen the view from the same camera by this much (the picture grows with it): a caller then trims the empty border. */
frame?: number): Promise<Blob>;
