import { type ModelDocument, type Shape3D, type Vec3 } from './document.js';
import { type MeshAsset, type MeshBvh } from './mesh.js';
/**
 * Imported models drawn on the CPU (cpu.ts): a ray is taken into each model's own space and its BVH finds the nearest triangle; the hit's normal,
 * colour (material, texture, vertex colour) and finish come back for the same shading as the shapes. Shadow rays ask whether any model is in the way.
 */
/** A decoded picture: RGBA, sRGB, top row first. */
export interface DecodedPicture {
    width: number;
    height: number;
    data: Uint8Array | Uint8ClampedArray;
}
export type DecodePicture = (bytes: Uint8Array, mime: string) => Promise<DecodedPicture | null>;
export interface PreparedMesh {
    shape: Shape3D;
    asset: MeshAsset;
    bvh: MeshBvh;
    textures: (DecodedPicture | null)[];
    /** Local to world rotation (row-major), the stretch from the model's units to the shape's, and the model's middle. */
    rot: number[];
    scale: Vec3;
    centre: Vec3;
    position: Vec3;
}
/** Pictures decoded by the browser, where there is one (Node passes its own decoder). */
export declare const browserDecode: DecodePicture | undefined;
/** Every model a design draws, ready for rays: its triangles in a BVH and its pictures decoded (none without a decoder: colours only). */
export declare function prepareMeshes(doc: Pick<ModelDocument, 'shapes' | 'assets'>, decode?: DecodePicture | undefined): Promise<PreparedMesh[]>;
export interface MeshSurface {
    t: number;
    normal: Vec3;
    /** Linear albedo and the finish (shininess, metal). */
    color: Vec3;
    shine: number;
    metal: number;
    /** The model's own ambient occlusion there (1 for none), and the light it gives off (linear). */
    occ: number;
    emissive: Vec3;
    /** The surface's shape before its normal map (eye-facing), for a clear coat. */
    shapeNormal: Vec3;
    /** The physical layers there, pictures applied: clear coat (amount, roughness, its normal), sheen (colour, roughness), light passing through. */
    clearcoat: number;
    clearcoatRoughness: number;
    coatNormal: Vec3;
    sheen: Vec3;
    sheenRoughness: number;
    transmission: number;
    ior: number;
}
/** The nearest model surface along the ray before tMax (holes in cut-out materials let the ray through), or null. */
export declare function traceMeshes(meshes: PreparedMesh[], o: Vec3, d: Vec3, tMax?: number): MeshSurface | null;
/** Whether a model is in the way along the ray before tMax (cut-out holes count as solid here; mostly clear glass lets the light through). */
export declare function meshBlocks(meshes: PreparedMesh[], o: Vec3, d: Vec3, tMax?: number): boolean;
