import { type ModelDocument } from './document.js';
import { type DecodePicture, type PreparedMesh } from './meshcpu.js';
/**
 * A 3D design drawn without a graphics card: the shader's ray marcher (glsl.ts) step for step on the CPU, for the MCP server and command line
 * (no WebGL there) and for vector export. Slower than the shader (seconds, not milliseconds), the same picture up to small differences in noise.
 * With `tones`, every surface is flat colour in a few steps of light, one region per shape and step, ready to be traced into vectors (vector.ts).
 */
export interface CpuRenderOptions {
    width: number;
    height: number;
    /** 2: smooth edges (more samples where a pixel differs from its neighbours). */
    samples?: 1 | 2;
    /** Only this part of the picture, [left, top, right, bottom) in its pixels; the result is that size. */
    region?: [number, number, number, number];
    /** Widens the view from the same camera. */
    frame?: number;
    /** Flat colour in this many steps of light (for vectors): no highlights, soft shadows or edge smoothing. */
    tones?: number;
    /** Imported models made ready for rays (prepareMeshes); made here when left out, with `decodeImage` for their pictures. */
    meshes?: PreparedMesh[];
    /** Decodes a model's pictures (the browser's own when left out; Node passes one, or models draw in their material colours). */
    decodeImage?: DecodePicture;
    /** Told how far it has got (0-1) now and then; it also gives way to other work then. */
    onProgress?: (done: number) => void | Promise<void>;
}
export interface CpuPicture {
    width: number;
    height: number;
    /** RGBA, not premultiplied, top row first. */
    data: Uint8ClampedArray;
}
export declare function renderModelCpu(doc: ModelDocument, options: CpuRenderOptions): Promise<CpuPicture>;
