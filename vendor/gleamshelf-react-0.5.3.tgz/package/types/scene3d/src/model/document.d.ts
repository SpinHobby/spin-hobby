/**
 * A 3D design built from simple shapes, the way a 2D designer builds a picture from shapes: each shape is added to, cut from or intersected with what
 * came before, with a blend that rounds the join into one smooth form. The design is drawn by ray marching the shapes' distance fields (see glsl.ts),
 * so blends, bevels and booleans are exact at any zoom and cost nothing to change. Plain JSON: saved with a design, edited through ModelEditor.
 */
import { type Contour } from './outline.js';
export type Vec3 = [number, number, number];
/** The solid shapes, offered on the add buttons. */
export declare const SHAPE_KINDS: readonly ["box", "sphere", "cylinder", "cone", "torus", "capsule", "pyramid"];
/**
 * Every kind: the solids, an outline pushed out into a solid (`extrude`), letters pushed out (`text`), an imported model (`mesh`, drawn as
 * triangles beside the distance field: it hides and is hidden, casts and takes shadows, but is never cut or blended), and a group of shapes joined
 * on their own.
 */
export declare const ALL_KINDS: readonly ["box", "sphere", "cylinder", "cone", "torus", "capsule", "pyramid", "extrude", "text", "mesh", "group"];
export type ShapeKind = (typeof ALL_KINDS)[number];
export type SolidKind = (typeof SHAPE_KINDS)[number];
/** How a shape joins what came before it in the list. */
export declare const COMBINE: readonly ["add", "subtract", "intersect"];
export type Combine = (typeof COMBINE)[number];
export declare const FINISHES: readonly ["matte", "satin", "glossy", "metal"];
export type Finish = (typeof FINISHES)[number];
export declare const LOOKS: readonly ["soft", "toon", "flat", "clay"];
export type Look3D = (typeof LOOKS)[number];
export interface Shape3D {
    id: string;
    name: string;
    kind: ShapeKind;
    /** Centre, in scene units (the ground is y = 0). */
    position: Vec3;
    /** Degrees about x, y, z (applied in that order). */
    rotation: Vec3;
    /** Width, height, depth of the shape's box. A sphere with unequal sizes is an ellipsoid. */
    size: Vec3;
    /** Rounded edges, as a share of the smallest size (0-0.5). */
    round: number;
    /** A torus's tube, as a share of its width (0.05-0.5). */
    thickness: number;
    combine: Combine;
    /** How softly it melts into what came before (0 = a crisp edge, 1 = very soft). */
    blend: number;
    /** `#rrggbb`. */
    color: string;
    finish: Finish;
    hidden: boolean;
    /** `extrude` and `text`: the outline pushed out (closed contours in a unit box, y up, holes even-odd); its depth is the size's z. */
    outline?: Contour[];
    /** `text`: what it says and in which font (the outline is drawn from it where there is a font to draw with, and kept). */
    text?: {
        value: string;
        font: string;
        weight: number;
    };
    /** `group`: its shapes, joined to each other first; the group then joins what came before it by its own combine and blend. One level deep. */
    children?: Shape3D[];
    /** `mesh`: the imported model it draws (a key of the design's `assets`), stretched to the shape's size. */
    asset?: string;
    /** `mesh`: the model's own colours and textures (true), or the shape's one colour and finish. */
    ownColors?: boolean;
}
/** An imported model, kept in the design: a GLB in Gleamshelf's plain form (mesh.ts) as base64, with its box (in its own units) and size. */
export interface ModelAsset {
    name: string;
    data: string;
    triangles: number;
    /** The model's box: its size and middle, in the model's own units. */
    size: Vec3;
    centre: Vec3;
}
export interface ModelDocument {
    version: 1;
    shapes: Shape3D[];
    /** Imported models by id, used by `mesh` shapes. */
    assets?: Record<string, ModelAsset>;
    light: {
        /** Where the key light comes from, degrees around (0 = front) and up from the ground. */
        azimuth: number;
        elevation: number;
        /** 0-3. */
        intensity: number;
        /** Fill light everywhere, 0-1. */
        ambient: number;
        color: string;
        shadows: boolean;
    };
    style: {
        look: Look3D;
        /** Outline width in pixels at 1000 px (0 = none). */
        outline: number;
        outlineColor: string;
        /** Steps of light for the toon look (2-6). */
        bands: number;
    };
    background: {
        transparent: boolean;
        color: string;
    };
    /** A floor that only catches shadows. */
    ground: {
        on: boolean;
        shadow: number;
    };
    camera: {
        /** Degrees around the target and up from level. */
        yaw: number;
        pitch: number;
        distance: number;
        target: Vec3;
        /** Field of view in degrees (perspective). */
        fov: number;
        projection: 'perspective' | 'orthographic';
    };
}
/** Shapes in a design, counting a group's shapes and its start and end (the shader's limit). */
export declare const MAX_SHAPES = 48;
/** Outlines and texts in a design (each takes a layer of the shader's field texture). */
export declare const MAX_FIELDS = 16;
/** Imported models placed in a design, and how big their files may be (as base64 text, one and all together). */
export declare const MAX_MESHES = 16;
export declare const MAX_ASSET_CHARS = 64000000;
export declare const MAX_ASSETS_CHARS = 128000000;
export declare const SHAPE_LABELS: Record<ShapeKind, string>;
export declare const newId: () => string;
export declare function createShape(kind: ShapeKind, index?: number, partial?: Partial<Shape3D>): Shape3D;
export declare function createModel(): ModelDocument;
/** Contours made safe: up to 64 contours of 3-2000 finite points, each brought into the unit box. */
export declare function checkOutline(raw: unknown): Contour[] | undefined;
/** An outline from any contours (pixels, a path, a preset): brought into the unit box, with its own width over height to size the shape by. */
export declare function outlineFrom(contours: Contour[]): {
    outline: Contour[];
    aspect: number;
};
/** Counts what a design asks of the shader: shape slots (a group takes two more), outline fields, and imported models (drawn apart, no slot). */
export declare function budget(shapes: readonly Shape3D[]): {
    slots: number;
    fields: number;
    meshes: number;
};
/** Whether a design fits what can be drawn. */
export declare const fitsBudget: (shapes: readonly Shape3D[]) => boolean;
/** A shape made safe: every field present and in range (for a file, an MCP call or a slider). A group's shapes are checked too (no groups inside). */
export declare function checkShape(raw: unknown, index?: number, nested?: boolean): Shape3D;
/** Imported models made safe: base64 text within the size limits, with a box. */
export declare function checkAssets(raw: unknown): Record<string, ModelAsset>;
/** The ids of the models a design's shapes use. */
export declare function usedAssets(shapes: readonly Shape3D[]): Set<string>;
/** The design without models no shape uses any more (they stay while editing, for undo; dropped when it is saved or placed). */
export declare function pruneAssets(doc: ModelDocument): ModelDocument;
/** Every imported model that draws: the shape, its place, and its asset. A model inside a group draws where it is (a group has no transform). */
export declare function meshShapes(doc: Pick<ModelDocument, 'shapes' | 'assets'>): {
    shape: Shape3D;
    path: ShapeRef;
    asset: ModelAsset;
}[];
/** Where a shape is in a design: its index, or a group's index and its index in the group. */
export type ShapeRef = [number] | [number, number];
/** The shape at a place in the design, if there is one. */
export declare function shapeAt(doc: Pick<ModelDocument, 'shapes'>, ref: ShapeRef | null): Shape3D | undefined;
/** Every shape that draws, in order, with a group's start and end marked: what the shader and the CPU field walk through. */
export type Step = {
    op: 'shape';
    shape: Shape3D;
    path: ShapeRef;
} | {
    op: 'begin';
    group: Shape3D;
    path: [number];
} | {
    op: 'end';
    group: Shape3D;
    path: [number];
};
export declare function steps(doc: Pick<ModelDocument, 'shapes'>): Step[];
/** A design from a file or another program: anything missing or out of range is filled in or brought into range. */
export declare function checkModel(raw: unknown): ModelDocument;
/** Views a designer reaches for: straight on, from the side or above, and the classic isometric. */
export declare const VIEWS: {
    readonly front: {
        readonly yaw: 0;
        readonly pitch: 0;
        readonly projection: "orthographic";
    };
    readonly side: {
        readonly yaw: 90;
        readonly pitch: 0;
        readonly projection: "orthographic";
    };
    readonly top: {
        readonly yaw: 0;
        readonly pitch: 89;
        readonly projection: "orthographic";
    };
    readonly isometric: {
        readonly yaw: 45;
        readonly pitch: 35.264;
        readonly projection: "orthographic";
    };
    readonly perspective: {
        readonly yaw: 30;
        readonly pitch: 22;
        readonly projection: "perspective";
    };
};
export type ViewName = keyof typeof VIEWS;
