import { DocumentStore, type StoreSnapshot } from '../../../core/src/index.js';
import { type ModelAsset, type ModelDocument, type Shape3D, type ShapeKind, type ShapeRef, type ViewName } from './document.js';
import type { Contour } from './outline.js';
export type ModelSnapshot = StoreSnapshot<ModelDocument>;
declare const SECTIONS: readonly ["light", "style", "background", "ground", "camera"];
export type Section = (typeof SECTIONS)[number];
/** Edits a 3D design: every change is checked and undoable, whether it comes from the panel, the gizmo, a keyboard shortcut or an MCP call. */
export declare class ModelEditor extends DocumentStore<ModelDocument> {
    constructor(doc: ModelDocument);
    get shapes(): readonly Shape3D[];
    /** Whether one more shape (and one more outline, if it has one) fits the shader. */
    private fits;
    /**
     * Adds a shape (beside the last one, resting on the ground) and returns its index, or -1 when the design is full. An outline shape (`extrude`,
     * `text`) needs `partial.outline`.
     */
    addShape(kind: ShapeKind, partial?: Partial<Shape3D>): number;
    /**
     * Adds an imported model (and its file, kept in the design) as one step; returns its index, or -1 when the design holds no more models. It
     * stands on the ground beside the last shape, `long` units on its long side, unless `partial` places and sizes it.
     */
    addModel(asset: ModelAsset, partial?: Partial<Shape3D>, long?: number): number;
    /** Changes some of a shape's fields as one step (merged into a gesture if one is open). */
    updateShapeAt(ref: ShapeRef, patch: Partial<Shape3D>, label?: string): void;
    /** A top-level shape's fields (kept for callers that only know an index). */
    updateShape(index: number, patch: Partial<Shape3D>, label?: string): void;
    /** Replaces a group's shapes at once (the gizmo moving a group): merged into an open gesture. */
    setChildren(group: number, children: Shape3D[]): void;
    /** The list a shape is in (the design's, or its group's), with a way to write it back. */
    private listOf;
    removeShapeAt(ref: ShapeRef): void;
    removeShape(index: number): void;
    /** A copy beside the original, in the same list; returns its place, or null when the design is full. */
    duplicateShapeAt(ref: ShapeRef): ShapeRef | null;
    duplicateShape(index: number): number;
    /** Moves a shape up or down its list: later shapes are joined onto earlier ones, so the order decides what cuts what. Returns its new place. */
    moveShapeAt(ref: ShapeRef, by: 1 | -1): ShapeRef;
    moveShape(index: number, by: 1 | -1): number;
    /**
     * Puts top-level shapes into a new group, where the first of them was; returns the group's index, or -1 (nothing to group, a group among them, or
     * the design is full: a group takes two more of the shader's slots).
     */
    group(indices: number[]): number;
    /** Lets a group's shapes back out into the design where the group was; returns the first one's index. */
    ungroup(index: number): number;
    /** One setting of the light, look, background, ground or camera. */
    setSetting(section: Section, key: string, value: unknown, label?: string): void;
    /** Front, side, top, isometric or the default perspective. */
    setView(view: ViewName): void;
    /** Frames every visible shape: the camera's target moves to their middle and it backs off until they fit a view `aspect` wide over high. */
    frameAll(aspect?: number): void;
    /** Writes a whole camera (an orbit gesture): merged into the open gesture, so a drag is one step. */
    setCamera(camera: Partial<ModelDocument['camera']>): void;
}
/**
 * A new design of one outline pushed out into a solid (a layer's shape from Edit mode, a logo): standing on the ground facing the camera, `long`
 * units on its long side, and framed for a view `viewAspect` wide over high. `aspect` is the outline's width over height (from outlineFrom).
 */
export declare function modelFromOutline(outline: Contour[], aspect: number, options?: {
    color?: string;
    name?: string;
    depth?: number;
    long?: number;
    viewAspect?: number;
}): ModelDocument;
export {};
