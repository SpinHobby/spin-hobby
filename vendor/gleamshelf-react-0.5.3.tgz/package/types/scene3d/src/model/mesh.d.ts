import type { Vec3 } from './document.js';
/**
 * Imported 3D models (meshes), the plain way: every model is kept in a design as one GLB in a small, fixed subset (triangles, positions, normals,
 * texture coordinates, vertex colours, one colour texture per material, all baked into one space). The browser's importer turns any format into
 * it (importer.ts); here it is written and read with no Three.js, so Node (the MCP server, the command line) and the CPU drawing read the same
 * bytes. A bounding volume hierarchy (BVH) answers which triangle a ray meets first, for drawing on the CPU.
 */
/** A material as drawn: colours are linear, the texture is an index into `textures` (-1 none). */
export interface MeshMaterial {
    color: Vec3;
    opacity: number;
    metalness: number;
    roughness: number;
    texture: number;
    /** A tangent-space normal map (glTF's convention: +Y up the picture), an index into `textures` (-1 none), and how strong it is. */
    normalTexture: number;
    normalScale: number;
    /** glTF's metallic-roughness picture (roughness in green, metalness in blue, scaling the factors), -1 none. */
    roughnessTexture: number;
    /** An ambient occlusion picture (red), -1 none, and how strongly it darkens the light that is not direct. */
    occlusionTexture: number;
    occlusionStrength: number;
    /** Light the surface gives off, linear (strength included), and a picture scaling it (sRGB), -1 none. */
    emissive: Vec3;
    emissiveTexture: number;
    /**
     * A clear varnish over the surface (KHR_materials_clearcoat): how much (0-1, scaled by its picture's red), how rough (scaled by its
     * picture's green), and its own normal map (-1: the surface's shape without the base normal map).
     */
    clearcoat: number;
    clearcoatTexture: number;
    clearcoatRoughness: number;
    clearcoatRoughnessTexture: number;
    clearcoatNormalTexture: number;
    clearcoatNormalScale: number;
    /** A velvet glow at grazing angles (KHR_materials_sheen): its colour (linear; scaled by its sRGB picture) and roughness (scaled by alpha). */
    sheenColor: Vec3;
    sheenColorTexture: number;
    sheenRoughness: number;
    sheenRoughnessTexture: number;
    /** How much light passes through, like glass (KHR_materials_transmission; scaled by its picture's red), and the index of refraction. */
    transmission: number;
    transmissionTexture: number;
    ior: number;
    /** Alpha below one half is a hole (leaves, hair cards, lace). */
    cutout: boolean;
    doubleSided: boolean;
}
export interface MeshPart {
    positions: Float32Array;
    normals: Float32Array;
    uvs: Float32Array | null;
    /** Linear RGB per vertex. */
    colors: Float32Array | null;
    indices: Uint32Array;
    material: number;
}
export interface MeshAsset {
    parts: MeshPart[];
    materials: MeshMaterial[];
    /** Encoded pictures (PNG, JPEG or WebP), sRGB. */
    textures: {
        mime: string;
        bytes: Uint8Array;
    }[];
    min: Vec3;
    max: Vec3;
    triangles: number;
}
export declare const defaultMaterial: () => MeshMaterial;
export declare function toBase64(bytes: Uint8Array): string;
export declare function fromBase64(text: string): Uint8Array;
export declare function boundsOf(parts: MeshPart[]): {
    min: Vec3;
    max: Vec3;
};
/** Smooth normals from the triangles (each vertex the area-weighted average of its faces). */
export declare function computeNormals(positions: Float32Array, indices: Uint32Array): Float32Array;
/** The model as a GLB in Gleamshelf's plain subset. */
export declare function writeGlb(asset: MeshAsset): Uint8Array;
type Json = Record<string, any>;
/**
 * A glTF model read into the plain form: every mesh in the default scene, its nodes' transforms baked in, triangles only. `files` gives the bytes
 * of a .gltf's separate files by their uri (a .bin, pictures); a GLB carries its own.
 */
export declare function readGltf(json: Json, bin: Uint8Array | null, files?: (uri: string) => Uint8Array | null): MeshAsset;
/** Bounds and the triangle count; materials not used are kept (indices stay valid). */
export declare function finish(parts: MeshPart[], materials: MeshMaterial[], textures: MeshAsset['textures']): MeshAsset;
/** A GLB (or a .gltf file's text, with `files` for what it points at) read into the plain form. */
export declare function readModelFile(bytes: Uint8Array, files?: (uri: string) => Uint8Array | null): MeshAsset;
export declare function meshAsset(id: string, data: string): MeshAsset;
export interface MeshHit {
    t: number;
    part: number;
    /** The triangle's corners (vertex indices in its part) and the hit's barycentric weights for the second and third. */
    a: number;
    b: number;
    c: number;
    u: number;
    v: number;
}
export interface MeshBvh {
    /** The nearest triangle along origin + t·dir for t in (tMin, tMax); dir need not be unit length (t is in its units). */
    intersect(origin: Vec3, dir: Vec3, tMin?: number, tMax?: number): MeshHit | null;
    /** Whether anything is hit in (tMin, tMax): for shadows. */
    occluded(origin: Vec3, dir: Vec3, tMin?: number, tMax?: number): boolean;
}
/** A BVH over every triangle of the model (median splits, four triangles a leaf); built once per model. */
export declare function meshBvh(asset: MeshAsset): MeshBvh;
export {};
