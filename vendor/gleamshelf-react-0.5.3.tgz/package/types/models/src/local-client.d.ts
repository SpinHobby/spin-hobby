import type { LocalHealth, LocalModelStatus } from './types';
/** What a background run of the whole listing chain reports (see the companion app's /process routes). */
export interface ProcessStatus {
    id: string;
    /** 'waiting': the run found pictures online and waits for the person to choose which to use (see `found`, `chooseReferences`). */
    status: 'queued' | 'running' | 'waiting' | 'done' | 'failed';
    steps: {
        name: string;
        state: 'running' | 'done';
        startedAt?: number;
        seconds?: number;
    }[];
    /** What the online lookup found, once it has looked (kept after the choice, so it can still be shown). */
    found?: FoundOnline;
    /** Signs of life while it runs (the app's clock, ms): see the app's jobs.ts. */
    health?: ProcessHealth;
    report?: {
        notes: string[];
        flags: string[];
        modeUsed: string;
        view: string;
        identity: {
            printedTitle: string | null;
            character: string | null;
            franchise: string | null;
        } | null;
        listing: {
            title: string;
            description: string;
            category: string;
            series: string | null;
            highlights: string[];
            unsupported: string[];
            unverifiedNumbers: string[];
            sources: string[];
        } | null;
        /** The product lookup's outcome: whether it was on, whether a picture showing this cover was found, and what it was used for. */
        lookup: {
            state: 'off' | 'found' | 'no-match' | 'no-pictures';
            read: string | null;
            tried: number;
            matched: number;
            bestMatch: number;
            completedParts: number;
            colourFit: number | null;
            detail: string;
        };
        /** How sure the cut-out is (0-1, with reasons), and the share of the product still as photographed (0-1) with a coarse map of what changed. */
        quality?: {
            cutout: {
                score: number;
                reasons: string[];
            };
            fidelity: {
                original: number;
                map: {
                    cols: number;
                    rows: number;
                    changed: number[];
                };
            };
        };
        /** Listing health: a 0-100 score, each check, and the top fixes. */
        health?: ListingHealthReport;
    };
    error?: string;
}
/** A finished run the app kept (see the app's jobs.ts). */
/** The shop finished runs are sent to (see shopStatus). */
export type ShopStatus = {
    connected: false;
} | {
    connected: true;
    url: string;
    label: string;
    answering: boolean;
};
/** A run sent to the shop: a new draft, its earlier draft replaced, or kept as the shop already has it (added or rejected). */
export interface SentRun {
    sent: 'new' | 'replaced' | 'kept';
    status: string;
    shop: string;
    label: string;
}
export interface RecentRun {
    id: string;
    title: string;
    /** When it finished (the app's clock, ms). */
    finishedAt: number;
    /** Its listing health score, when it has one. */
    health: number | null;
}
/** A photo a phone sent to the app (see the app's phone.ts). */
export interface PhonePhoto {
    id: string;
    name: string;
    bytes: number;
    /** When it arrived (the app's clock, ms). */
    at: number;
}
/** What a buyer and a marketplace's search look for, scored by the app (apps/local/src/health.ts). */
export interface ListingHealthReport {
    score: number;
    level: 'good' | 'fair' | 'poor';
    checks: {
        id: string;
        ok: boolean;
        label: string;
        fix?: string;
        weight: number;
    }[];
    fixes: string[];
}
/** The pictures a run found online, to show a person before any is used. */
export interface FoundOnline {
    /** What the local model read off the cover. */
    identity: {
        printedTitle: string | null;
        character: string | null;
        franchise: string | null;
        maker?: string | null;
        variant?: string | null;
    } | null;
    photos: FoundOnlinePhoto[];
    /** The indexes the person chose, once they have (null until then). */
    chosen: number[] | null;
}
export interface FoundOnlinePhoto {
    /** Its number in the list: what `foundPicture` and `chooseReferences` take. */
    index: number;
    /** 'product': a picture of the product (often its box); 'unboxed': the figure out of its box, which shows what the box's printing hides. */
    purpose: 'product' | 'unboxed';
    /** Whether it lines up with the photo: only those can be used. */
    linesUp: boolean;
    /** For one that lines up: a photo of the box (good for colours; it hides what the cover hides) or of the figure itself (it can finish what the print hides). */
    shows?: 'box' | 'figure';
    inliers: number;
    page?: string;
    title?: string;
}
export interface ProcessHealth {
    now: number;
    startedAt: number;
    lastActivity: number;
    models: 'off' | 'starting' | 'working' | 'idle';
    modelJob: string | null;
    cpu: {
        app: number;
        models: number | null;
    };
    detail: string | null;
}
export interface ProcessOptions {
    mode?: 'product' | 'character' | 'auto';
    /** Search the web for reference pictures of the product (free; the search words go to DuckDuckGo, the photo stays here). */
    find?: boolean;
    /** Write a title and description with the local model. */
    listing?: boolean;
    /** Colour strength after a reference colour match, 1 to 2 (1 = the product's published colours). */
    vivid?: number;
    enlarge?: boolean;
    /** Steps of the chain; each is on unless set to false. */
    stickers?: boolean;
    /** Repaint lettering and printed text (character covers). */
    lettering?: boolean;
    /** Complete thin or detached parts of the figure. */
    thinParts?: boolean;
    /** Match the colours to the product's published picture (needs `find`). */
    colour?: boolean;
    /** The brighter and sharper look. */
    look?: boolean;
    /** Redraw the product with AI (see STUDIO_GLOSS). The one step that is off unless set to true. */
    gloss?: boolean;
    /** Stop once the pictures are found online, until `chooseReferences` says which to use (status 'waiting'). Off by default: the run uses every one that lines up. */
    review?: boolean;
}
/** Settings for the sharpening model (`/enhance`). */
export interface EnhanceOptions {
    /** 0.1-0.6: how far the picture may be redrawn. */
    strength?: number;
    prompt?: string;
    negativePrompt?: string;
    seed?: number;
    /** Keep the original colours and take only the brightness detail from the model (default true). */
    keepColour?: boolean;
    /** 0.3-1: how tightly the shapes are pinned to the original (default 1). */
    control?: number;
    /** 1-12: how closely the prompt is followed (default 5). */
    guidance?: number;
}
/**
 * Studio gloss: the product redrawn as a clean studio pack shot. Twice the strength of "Extra detail", the shapes held
 * more loosely and the colours left to the model, so plastic, paint and highlights come back glossier, and so may details that are not on the real item.
 * Off by default everywhere and labelled wherever it is used.
 */
export declare const STUDIO_GLOSS: EnhanceOptions;
export declare class LocalModelError extends Error {
    readonly status: number;
    constructor(status: number, message: string);
}
/** The address the companion app listens on by default. */
export declare const DEFAULT_LOCAL_URL = "http://127.0.0.1:47321";
/**
 * The commands that run the companion app, as a person types them in the repo's folder. One place, so the editor's help,
 * the app's own messages and the docs never disagree.
 */
export declare const LOCAL_COMMANDS: {
    readonly start: "npm run local:start";
    readonly token: "npm run local:token";
    readonly models: "npm run models";
    /** Sets up the redraw model: a Python environment and a 7 GB download, after asking. */
    readonly redrawSetup: "npm run redraw:setup";
    /** The recommended model when no id is given; any other model by its id. */
    readonly install: (id?: string) => string;
};
/** A box around some text, as fractions (0-1) of the picture that was sent. */
export interface TextBox {
    x: number;
    y: number;
    width: number;
    height: number;
}
/** A box around some text with what it says. */
export interface ReadTextBox extends TextBox {
    text: string;
    /** 0-1: how sure the reader is. */
    score: number;
}
export interface CutoutMask {
    /** One byte per pixel: 255 is product, 0 is background. */
    alpha: Uint8Array;
    width: number;
    height: number;
    /** The mask already has stray pieces dropped and its thin or detached parts of the figure added, so it must not be filtered by "keep the main piece" again. */
    partsKept?: boolean;
}
/**
 * Talks to the Gleamshelf companion app running on the user's own computer. The photo never leaves the machine,
 * and running a model there costs nothing. The app is protected by a pairing token the user copies from its window.
 */
export declare class LocalModelClient {
    private readonly options;
    private readonly base;
    private readonly doFetch;
    constructor(options?: {
        url?: string;
        token?: string;
        fetch?: typeof fetch;
    });
    private headers;
    /**
     * Tells "not running" apart from "running, but this browser will not let the page talk to it" (a browser that blocks
     * calls to http://127.0.0.1 from a page, such as Safari). A blocked call and a refused one both look like a network
     * error to the page, so a second, opaque request is tried: it can reach the app even where reading the answer is blocked.
     */
    probe(): Promise<'ok' | 'blocked' | 'offline'>;
    /** Whether the companion app is running here. Never throws: not running is a normal answer. */
    health(): Promise<LocalHealth | null>;
    /**
     * Repaints part of a picture. `picture` is a PNG whose transparent pixels are the ones to fill in (what is kept must be
     * opaque). Returns the finished picture as a PNG, the same size. The first call loads the model; large areas take a while.
     */
    inpaint(picture: Blob, modelId: string, signal?: AbortSignal): Promise<Blob>;
    /** Makes a picture 4 times larger and sharper. Returns a PNG. Large pictures take a while; send at most about 1024 pixels on the long side. */
    upscale(picture: Blob, modelId: string, signal?: AbortSignal): Promise<Blob>;
    /**
     * Redraws part of a picture with the local image model. The part to redraw is the PNG's transparent pixels and/or `box` (normalized
     * x, y, width, height); a rough sketch drawn into the opaque part of the box steers it, and a `strength` below 1 keeps that sketch's
     * shape. With `stacked`, `picture` is an opaque PNG twice as tall as the picture: the picture on top and the part to repaint below it in
     * white, so the pixels under the part to repaint are kept (a transparent PNG loses them). About a minute.
     */
    redraw(picture: Blob, options: {
        prompt: string;
        negative?: string;
        strength?: number;
        steps?: number;
        guidance?: number;
        candidates?: number;
        seed?: number;
        box?: [number, number, number, number];
        stacked?: boolean;
    }, signal?: AbortSignal): Promise<Blob>;
    /**
     * Sharpens a picture (1400 pixels or less) while keeping every shape and, by default, its colours. About a minute for 1024 pixels.
     * `strength` (0.1-0.6) is how far it may be redrawn; low keeps the finest detail exactly where it was.
     */
    enhance(picture: Blob, options?: EnhanceOptions, signal?: AbortSignal): Promise<Blob>;
    /**
     * Studio gloss: the product redrawn as a studio pack shot by the sharpening model, much further than `enhance` goes (see STUDIO_GLOSS). It changes the
     * product's own pixels, so callers offer it off by default and label the result.
     */
    gloss(picture: Blob, signal?: AbortSignal): Promise<Blob>;
    /** Finds printed text in a photo and reads it. Needs both the text finder and the text reader installed. */
    readText(photo: Blob, signal?: AbortSignal): Promise<ReadTextBox[]>;
    /** Finds printed text in a photo and returns boxes around it. */
    detectText(photo: Blob, modelId: string, signal?: AbortSignal): Promise<TextBox[]>;
    /** Starts the whole listing chain on a photo in the app (the same chain as the batch command). Returns the job's id at once; follow it with `processStatus`. */
    startProcess(photo: Blob, options?: ProcessOptions, signal?: AbortSignal): Promise<string>;
    processStatus(id: string, signal?: AbortSignal): Promise<ProcessStatus>;
    /** A picture a waiting (or finished) run found online, made small for showing. */
    foundPicture(id: string, index: number, signal?: AbortSignal): Promise<Blob>;
    /** Lets a waiting run go on with the pictures the person chose (indexes from `found`), or with every one that lines up (null). */
    chooseReferences(id: string, use: number[] | null, signal?: AbortSignal): Promise<void>;
    /** Stops a job: it ends at its next step, and a model job it is stuck in is stopped now. */
    cancelProcess(id: string, signal?: AbortSignal): Promise<void>;
    /** The finished picture of a job: the figure or product alone on a transparent background (`cutout`), or the white square (`studio`). */
    processPicture(id: string, which?: 'cutout' | 'studio' | 'changes', signal?: AbortSignal): Promise<Blob>;
    /** Finished runs the app kept, newest first: each opens again instantly with processStatus and processPicture. */
    recentRuns(signal?: AbortSignal): Promise<RecentRun[]>;
    /** Whether this computer is connected to a shop (where finished runs go as drafts), which one, and whether it answers. */
    shopStatus(signal?: AbortSignal): Promise<ShopStatus>;
    /** Connects this computer to a shop with the code its admin shows (Imports › Connect the app). */
    shopConnect(address: string, code: string, signal?: AbortSignal): Promise<{
        url: string;
        label: string;
    }>;
    /** Sends a finished run to the connected shop as a draft in its Imports inbox (nothing is published). */
    sendRun(id: string, signal?: AbortSignal): Promise<SentRun>;
    /** Starts phone capture (or returns the one running): the address the phone opens on the Wi-Fi, and the same as a QR code (SVG text). */
    phoneStart(signal?: AbortSignal): Promise<{
        url: string;
        qrSvg: string;
    }>;
    /** The photos a phone has sent, newest first. */
    phonePhotos(signal?: AbortSignal): Promise<PhonePhoto[]>;
    /** One photo a phone sent, as it came (JPEG, PNG, WebP or HEIC). */
    phonePhoto(id: string, signal?: AbortSignal): Promise<Blob>;
    models(): Promise<LocalModelStatus[]>;
    /** Runs a cut-out model on a photo and returns its mask. The first run of a model loads it, which can take a few seconds. */
    cutout(photo: Blob, modelId: string, signal?: AbortSignal, options?: {
        thinParts?: boolean;
    }): Promise<CutoutMask>;
}
