import { Bt as e, Et as t, Kn as n, Ln as r, N as i, P as a, St as o, Tt as s, Zn as c, _t as l, at as u, c as d, d as f, f as p, fr as m, gt as h, it as g, jn as _, l as v, lt as y, wt as b, y as ee, z as x } from "./three.core-Bn_95pMq.js";
import { t as S } from "./fflate.module-d2PQQWvd.js";
import { t as te } from "./BufferGeometryUtils-a60fER9N.js";
//#region ../../node_modules/three/examples/jsm/loaders/3MFLoader.js
var C = r, w = "http://schemas.microsoft.com/3dmanufacturing/beamlattice/2017/02", T = "http://schemas.microsoft.com/3dmanufacturing/beamlattice/balls/2020/07", E = class extends y {
	constructor(e) {
		super(e), this.availableExtensions = [];
	}
	load(e, t, n, r) {
		let a = this, o = new i(a.manager);
		o.setPath(a.path), o.setResponseType("arraybuffer"), o.setRequestHeader(a.requestHeader), o.setWithCredentials(a.withCredentials), o.load(e, function(n) {
			try {
				t(a.parse(n));
			} catch (t) {
				r ? r(t) : console.error(t), a.manager.itemError(e);
			}
		}, n, r);
	}
	parse(r) {
		let i = this, E = new c(this.manager);
		function D(e) {
			let t = null, n = null, r, i, a = [], o = [], s, c = {}, l = {}, u = {}, d = new TextDecoder();
			try {
				t = S(new Uint8Array(e));
			} catch (e) {
				if (e instanceof ReferenceError) return console.error("THREE.3MFLoader: fflate missing and file is compressed."), null;
			}
			let f = null;
			for (n in t) n.match(/\_rels\/.rels$/) ? r = n : n.match(/3D\/_rels\/.*\.model\.rels$/) ? i = n : n.match(/^3D\/[^\/]*\.model$/) ? f = n : n.match(/^3D\/.*\/.*\.model$/) ? a.push(n) : n.match(/^3D\/Textures?\/.*/) && o.push(n);
			if (a.push(f), r === void 0) throw Error("THREE.ThreeMFLoader: Cannot find relationship file `rels` in 3MF archive.");
			let p = t[r], m = O(d.decode(p));
			if (i) {
				let e = t[i];
				s = O(d.decode(e));
			}
			for (let e = 0; e < a.length; e++) {
				let n = a[e], r = t[n], i = d.decode(r), o = new DOMParser().parseFromString(i, "application/xml");
				o.documentElement.nodeName.toLowerCase() !== "model" && console.error("THREE.3MFLoader: Error loading 3MF - no 3MF document found: ", n);
				let s = o.querySelector("model"), l = {};
				for (let e = 0; e < s.attributes.length; e++) {
					let t = s.attributes[e];
					t.name.match(/^xmlns:(.+)$/) && (l[t.value] = RegExp.$1);
				}
				let u = W(s);
				u.xml = s, 0 < Object.keys(l).length && (u.extensions = l), c[n] = u;
			}
			for (let e = 0; e < o.length; e++) {
				let n = o[e];
				u[n] = t[n].buffer;
			}
			return {
				rels: m,
				modelRels: s,
				model: c,
				printTicket: l,
				texture: u
			};
		}
		function O(e) {
			let t = [], n = new DOMParser().parseFromString(e, "application/xml").querySelectorAll("Relationship");
			for (let e = 0; e < n.length; e++) {
				let r = n[e], i = {
					target: r.getAttribute("Target"),
					id: r.getAttribute("Id"),
					type: r.getAttribute("Type")
				};
				t.push(i);
			}
			return t;
		}
		function k(e) {
			let t = {};
			for (let n = 0; n < e.length; n++) {
				let r = e[n], i = r.getAttribute("name");
				0 <= [
					"Title",
					"Designer",
					"Description",
					"Copyright",
					"LicenseTerms",
					"Rating",
					"CreationDate",
					"ModificationDate"
				].indexOf(i) && (t[i] = r.textContent);
			}
			return t;
		}
		function ne(e) {
			let t = {
				id: e.getAttribute("id"),
				basematerials: []
			}, n = e.querySelectorAll("base");
			for (let e = 0; e < n.length; e++) {
				let r = n[e], i = F(r);
				i.index = e, t.basematerials.push(i);
			}
			return t;
		}
		function re(e) {
			return {
				id: e.getAttribute("id"),
				path: e.getAttribute("path"),
				contenttype: e.getAttribute("contenttype"),
				tilestyleu: e.getAttribute("tilestyleu"),
				tilestylev: e.getAttribute("tilestylev"),
				filter: e.getAttribute("filter")
			};
		}
		function A(e) {
			let t = {
				id: e.getAttribute("id"),
				texid: e.getAttribute("texid"),
				displaypropertiesid: e.getAttribute("displaypropertiesid")
			}, n = e.querySelectorAll("tex2coord"), r = [];
			for (let e = 0; e < n.length; e++) {
				let t = n[e], i = t.getAttribute("u"), a = t.getAttribute("v");
				r.push(parseFloat(i), parseFloat(a));
			}
			return t.uvs = new Float32Array(r), t;
		}
		function j(e) {
			let t = {
				id: e.getAttribute("id"),
				displaypropertiesid: e.getAttribute("displaypropertiesid")
			}, n = e.querySelectorAll("color"), r = [], i = new p();
			for (let e = 0; e < n.length; e++) {
				let t = n[e].getAttribute("color");
				i.setStyle(t.substring(0, 7), C), r.push(i.r, i.g, i.b);
			}
			return t.colors = new Float32Array(r), t;
		}
		function M(e) {
			let t = e.children, n = {};
			for (let e = 0; e < t.length; e++) {
				let r = { type: t[e].nodeName.substring(2) };
				for (let n = 0; n < t[e].attributes.length; n++) {
					let i = t[e].attributes[n];
					i.specified && (r[i.name] = i.value);
				}
				n[t[e].getAttribute("identifier")] = r;
			}
			return n;
		}
		function N(e) {
			let t = {
				id: e.getAttribute("id"),
				displayname: e.getAttribute("displayname")
			}, n = e.children, r = {};
			for (let e = 0; e < n.length; e++) {
				let t = n[e];
				if (t.nodeName === "i:in" || t.nodeName === "i:out") r[t.nodeName === "i:in" ? "inputs" : "outputs"] = M(t);
				else {
					let e = t.children, n = {
						op: t.nodeName.substring(2),
						identifier: t.getAttribute("identifier")
					};
					for (let t = 0; t < e.length; t++) n[e[t].nodeName.substring(2)] = M(e[t]);
					r[n.identifier] = n;
				}
			}
			return t.operations = r, t;
		}
		function P(e) {
			let t = { id: e.getAttribute("id") }, n = e.querySelectorAll("pbmetallic"), r = [];
			for (let e = 0; e < n.length; e++) {
				let t = n[e];
				r.push({
					name: t.getAttribute("name"),
					metallicness: parseFloat(t.getAttribute("metallicness")),
					roughness: parseFloat(t.getAttribute("roughness"))
				});
			}
			return t.data = r, t;
		}
		function F(e) {
			let t = {};
			return t.name = e.getAttribute("name"), t.displaycolor = e.getAttribute("displaycolor"), t.displaypropertiesid = e.getAttribute("displaypropertiesid"), t;
		}
		function I(e) {
			let t = {}, n = [], r = e.querySelectorAll("vertices vertex");
			for (let e = 0; e < r.length; e++) {
				let t = r[e], i = t.getAttribute("x"), a = t.getAttribute("y"), o = t.getAttribute("z");
				n.push(parseFloat(i), parseFloat(a), parseFloat(o));
			}
			t.vertices = new Float32Array(n);
			let i = [], a = [], o = e.querySelectorAll("triangles triangle");
			for (let e = 0; e < o.length; e++) {
				let t = o[e], n = t.getAttribute("v1"), r = t.getAttribute("v2"), s = t.getAttribute("v3"), c = t.getAttribute("p1"), l = t.getAttribute("p2"), u = t.getAttribute("p3"), d = t.getAttribute("pid"), f = {};
				f.v1 = parseInt(n, 10), f.v2 = parseInt(r, 10), f.v3 = parseInt(s, 10), a.push(f.v1, f.v2, f.v3), c && (f.p1 = parseInt(c, 10)), l && (f.p2 = parseInt(l, 10)), u && (f.p3 = parseInt(u, 10)), d && (f.pid = d), 0 < Object.keys(f).length && i.push(f);
			}
			t.triangleProperties = i, t.triangles = new Uint32Array(a);
			let s = e.getElementsByTagNameNS(w, "beamlattice")[0];
			return s !== void 0 && (t.beamlattice = L(s)), t;
		}
		function L(e) {
			let t = {
				radius: parseFloat(e.getAttribute("radius")),
				minLength: parseFloat(e.getAttribute("minlength")),
				cap: e.getAttribute("cap") || "sphere",
				ballMode: e.getAttributeNS(T, "ballmode") || "none",
				ballRadius: parseFloat(e.getAttributeNS(T, "ballradius")),
				beams: [],
				balls: []
			}, n = e.getAttribute("clippingmode") || e.getAttribute("clipping");
			n !== null && n !== "none" && console.warn("THREE.3MFLoader: Beam lattice clipping is not supported. The lattice is rendered unclipped.");
			let r = e.getElementsByTagNameNS(w, "beam");
			for (let e = 0; e < r.length; e++) {
				let n = r[e], i = {
					v1: parseInt(n.getAttribute("v1"), 10),
					v2: parseInt(n.getAttribute("v2"), 10)
				}, a = n.getAttribute("r1"), o = n.getAttribute("r2");
				a !== null && (i.r1 = parseFloat(a)), o !== null && (i.r2 = parseFloat(o)), t.beams.push(i);
			}
			let i = e.getElementsByTagNameNS(T, "ball");
			for (let e = 0; e < i.length; e++) {
				let n = i[e], r = { vindex: parseInt(n.getAttribute("vindex"), 10) }, a = n.getAttribute("r");
				a !== null && (r.r = parseFloat(a)), t.balls.push(r);
			}
			return t;
		}
		function R(e) {
			let t = [], n = e.querySelectorAll("component");
			for (let e = 0; e < n.length; e++) {
				let r = n[e], i = z(r);
				t.push(i);
			}
			return t;
		}
		function z(e) {
			let t = {};
			t.objectId = e.getAttribute("objectid");
			let n = e.getAttribute("transform");
			return n && (t.transform = B(n)), t;
		}
		function B(e) {
			let t = [];
			e.split(" ").forEach(function(e) {
				t.push(parseFloat(e));
			});
			let n = new h();
			return n.set(t[0], t[3], t[6], t[9], t[1], t[4], t[7], t[10], t[2], t[5], t[8], t[11], 0, 0, 0, 1), n;
		}
		function V(e) {
			let t = { type: e.getAttribute("type") }, n = e.getAttribute("id");
			n && (t.id = n);
			let r = e.getAttribute("pid");
			r && (t.pid = r);
			let i = e.getAttribute("pindex");
			i && (t.pindex = i);
			let a = e.getAttribute("thumbnail");
			a && (t.thumbnail = a);
			let o = e.getAttribute("partnumber");
			o && (t.partnumber = o);
			let s = e.getAttribute("name");
			s && (t.name = s);
			let c = e.querySelector("mesh");
			c && (t.mesh = I(c));
			let l = e.querySelector("components");
			return l && (t.components = R(l)), t;
		}
		function H(e) {
			let t = {};
			t.basematerials = {};
			let n = e.querySelectorAll("basematerials");
			for (let e = 0; e < n.length; e++) {
				let r = n[e], i = ne(r);
				t.basematerials[i.id] = i;
			}
			t.texture2d = {};
			let r = e.querySelectorAll("texture2d");
			for (let e = 0; e < r.length; e++) {
				let n = r[e], i = re(n);
				t.texture2d[i.id] = i;
			}
			t.colorgroup = {};
			let i = e.querySelectorAll("colorgroup");
			for (let e = 0; e < i.length; e++) {
				let n = i[e], r = j(n);
				t.colorgroup[r.id] = r;
			}
			let a = e.querySelectorAll("implicitfunction");
			a.length > 0 && (t.implicitfunction = {});
			for (let e = 0; e < a.length; e++) {
				let n = a[e], r = N(n);
				t.implicitfunction[r.id] = r;
			}
			t.pbmetallicdisplayproperties = {};
			let o = e.querySelectorAll("pbmetallicdisplayproperties");
			for (let e = 0; e < o.length; e++) {
				let n = o[e], r = P(n);
				t.pbmetallicdisplayproperties[r.id] = r;
			}
			t.texture2dgroup = {};
			let s = e.querySelectorAll("texture2dgroup");
			for (let e = 0; e < s.length; e++) {
				let n = s[e], r = A(n);
				t.texture2dgroup[r.id] = r;
			}
			t.object = {};
			let c = e.querySelectorAll("object");
			for (let e = 0; e < c.length; e++) {
				let n = c[e], r = V(n);
				t.object[r.id] = r;
			}
			return t;
		}
		function U(e) {
			let t = [], n = e.querySelectorAll("item");
			for (let e = 0; e < n.length; e++) {
				let r = n[e], i = { objectId: r.getAttribute("objectid") }, a = r.getAttribute("transform");
				a && (i.transform = B(a)), t.push(i);
			}
			return t;
		}
		function W(e) {
			let t = { unit: e.getAttribute("unit") || "millimeter" }, n = e.querySelectorAll("metadata");
			n && (t.metadata = k(n));
			let r = e.querySelector("resources");
			r && (t.resources = H(r));
			let i = e.querySelector("build");
			return i && (t.build = U(i)), t;
		}
		function G(e, n, r, i) {
			let a = e.texid, o = r.resources.texture2d[a];
			if (o) {
				let e = i[o.path], n = o.contenttype, r = new Blob([e], { type: n }), a = URL.createObjectURL(r), c = E.load(a, function() {
					URL.revokeObjectURL(a);
				});
				switch (c.colorSpace = C, o.tilestyleu) {
					case "wrap":
						c.wrapS = _;
						break;
					case "mirror":
						c.wrapS = s;
						break;
					case "none":
					case "clamp":
						c.wrapS = f;
						break;
					default: c.wrapS = _;
				}
				switch (o.tilestylev) {
					case "wrap":
						c.wrapT = _;
						break;
					case "mirror":
						c.wrapT = s;
						break;
					case "none":
					case "clamp":
						c.wrapT = f;
						break;
					default: c.wrapT = _;
				}
				switch (o.filter) {
					case "auto":
						c.magFilter = g, c.minFilter = u;
						break;
					case "linear":
						c.magFilter = g, c.minFilter = g, c.generateMipmaps = !1;
						break;
					case "nearest":
						c.magFilter = t, c.minFilter = t, c.generateMipmaps = !1;
						break;
					default: c.magFilter = g, c.minFilter = u;
				}
				return c;
			}
			return null;
		}
		function ie(e, t, n, r, i, o, s) {
			let c = s.pindex, u = {};
			for (let e = 0, n = t.length; e < n; e++) {
				let n = t[e], r = n.p1 === void 0 ? c : n.p1;
				u[r] === void 0 && (u[r] = []), u[r].push(n);
			}
			let d = Object.keys(u), f = [];
			for (let t = 0, c = d.length; t < c; t++) {
				let c = d[t], p = u[c], m = e.basematerials[c], h = X(m, r, i, o, s, Z), g = new v(), _ = [], y = n.vertices;
				for (let e = 0, t = p.length; e < t; e++) {
					let t = p[e];
					_.push(y[t.v1 * 3 + 0]), _.push(y[t.v1 * 3 + 1]), _.push(y[t.v1 * 3 + 2]), _.push(y[t.v2 * 3 + 0]), _.push(y[t.v2 * 3 + 1]), _.push(y[t.v2 * 3 + 2]), _.push(y[t.v3 * 3 + 0]), _.push(y[t.v3 * 3 + 1]), _.push(y[t.v3 * 3 + 2]);
				}
				g.setAttribute("position", new a(_, 3));
				let b = new l(g, h);
				f.push(b);
			}
			return f;
		}
		function K(e, t, n, r, i, s, c) {
			let u = new v(), d = [], f = [], p = n.vertices, m = e.uvs;
			for (let e = 0, n = t.length; e < n; e++) {
				let n = t[e];
				d.push(p[n.v1 * 3 + 0]), d.push(p[n.v1 * 3 + 1]), d.push(p[n.v1 * 3 + 2]), d.push(p[n.v2 * 3 + 0]), d.push(p[n.v2 * 3 + 1]), d.push(p[n.v2 * 3 + 2]), d.push(p[n.v3 * 3 + 0]), d.push(p[n.v3 * 3 + 1]), d.push(p[n.v3 * 3 + 2]), f.push(m[n.p1 * 2 + 0]), f.push(m[n.p1 * 2 + 1]), f.push(m[n.p2 * 2 + 0]), f.push(m[n.p2 * 2 + 1]), f.push(m[n.p3 * 2 + 0]), f.push(m[n.p3 * 2 + 1]);
			}
			u.setAttribute("position", new a(d, 3)), u.setAttribute("uv", new a(f, 2));
			let h = X(e, r, i, s, c, G), g = new o({
				map: h,
				flatShading: !0
			});
			return new l(u, g);
		}
		function q(e, t, n, r) {
			let i = new v(), s = [], c = [], u = n.vertices, d = e.colors;
			for (let e = 0, n = t.length; e < n; e++) {
				let n = t[e], i = n.v1, a = n.v2, o = n.v3;
				s.push(u[i * 3 + 0]), s.push(u[i * 3 + 1]), s.push(u[i * 3 + 2]), s.push(u[a * 3 + 0]), s.push(u[a * 3 + 1]), s.push(u[a * 3 + 2]), s.push(u[o * 3 + 0]), s.push(u[o * 3 + 1]), s.push(u[o * 3 + 2]);
				let l = n.p1 === void 0 ? r.pindex : n.p1, f = n.p2 === void 0 ? l : n.p2, p = n.p3 === void 0 ? l : n.p3;
				c.push(d[l * 3 + 0]), c.push(d[l * 3 + 1]), c.push(d[l * 3 + 2]), c.push(d[f * 3 + 0]), c.push(d[f * 3 + 1]), c.push(d[f * 3 + 2]), c.push(d[p * 3 + 0]), c.push(d[p * 3 + 1]), c.push(d[p * 3 + 2]);
			}
			i.setAttribute("position", new a(s, 3)), i.setAttribute("color", new a(c, 3));
			let f = new o({
				vertexColors: !0,
				flatShading: !0
			});
			return new l(i, f);
		}
		function J(e) {
			let t = new v();
			t.setIndex(new d(e.triangles, 1)), t.setAttribute("position", new d(e.vertices, 3));
			let n = new o({
				name: y.DEFAULT_MATERIAL_NAME,
				color: 16777215,
				flatShading: !0
			});
			return new l(t, n);
		}
		function Y(t) {
			let r = t.beamlattice, i = t.vertices, a = [], s = new m(), c = new m(), u = new m(), d = new m(0, 1, 0), f = new e(), p = new h(), g = r.beams, _ = r.cap !== "butt", v = /* @__PURE__ */ new Map();
			for (let e = 0; e < g.length; e++) {
				let t = g[e];
				s.fromArray(i, t.v1 * 3), c.fromArray(i, t.v2 * 3);
				let n = s.distanceTo(c);
				if (n < r.minLength) continue;
				let o = t.r1 === void 0 ? r.radius : t.r1, l = t.r2 === void 0 ? o : t.r2, m = new ee(l, o, n, 8, 1, _);
				u.subVectors(c, s).divideScalar(n), f.setFromUnitVectors(d, u), p.makeRotationFromQuaternion(f), p.setPosition(s.add(c).multiplyScalar(.5)), m.applyMatrix4(p), a.push(m), _ && (v.set(t.v1, Math.max(o, v.get(t.v1) || 0)), v.set(t.v2, Math.max(l, v.get(t.v2) || 0))), r.ballMode === "all" && (v.set(t.v1, Math.max(r.ballRadius, v.get(t.v1) || 0)), v.set(t.v2, Math.max(r.ballRadius, v.get(t.v2) || 0)));
			}
			let b = r.balls;
			for (let e = 0; e < b.length; e++) {
				let t = b[e], n = t.r === void 0 ? r.ballRadius : t.r;
				v.set(t.vindex, Math.max(n, v.get(t.vindex) || 0));
			}
			for (let [e, t] of v) {
				let r = new n(t, 8, 6);
				s.fromArray(i, e * 3), r.translate(s.x, s.y, s.z), a.push(r);
			}
			let x = te(a), S = new o({
				name: y.DEFAULT_MATERIAL_NAME,
				color: 16777215
			});
			return new l(x, S);
		}
		function ae(e, t, n, r, i, a) {
			let o = Object.keys(e), s = [];
			for (let c = 0, l = o.length; c < l; c++) {
				let l = o[c], u = e[l];
				switch (oe(l, r)) {
					case "material":
						let e = r.resources.basematerials[l], o = ie(e, u, t, n, r, i, a);
						for (let e = 0, t = o.length; e < t; e++) s.push(o[e]);
						break;
					case "texture":
						let c = r.resources.texture2dgroup[l];
						s.push(K(c, u, t, n, r, i, a));
						break;
					case "vertexColors":
						let d = r.resources.colorgroup[l];
						s.push(q(d, u, t, a));
						break;
					case "default":
						s.push(J(t));
						break;
					default: console.error("THREE.3MFLoader: Unsupported resource type.");
				}
			}
			if (a.name) for (let e = 0; e < s.length; e++) s[e].name = a.name;
			return s;
		}
		function oe(e, t) {
			if (t.resources.texture2dgroup[e] !== void 0) return "texture";
			if (t.resources.basematerials[e] !== void 0) return "material";
			if (t.resources.colorgroup[e] !== void 0) return "vertexColors";
			if (e === "default") return "default";
		}
		function se(e, t) {
			let n = {}, r = e.triangleProperties, i = t.pid;
			for (let e = 0, t = r.length; e < t; e++) {
				let t = r[e], a = t.pid === void 0 ? i : t.pid;
				a === void 0 && (a = "default"), n[a] === void 0 && (n[a] = []), n[a].push(t);
			}
			return n;
		}
		function ce(e, t, n, r, i) {
			let a = new x(), o = ae(se(e, i), e, t, n, r, i);
			if (e.beamlattice !== void 0) {
				let t = Y(e);
				i.name && (t.name = i.name), o.push(t);
			}
			for (let e = 0, t = o.length; e < t; e++) a.add(o[e]);
			return a;
		}
		function le(e, t, n) {
			if (!e) return;
			let r = [], a = Object.keys(e);
			for (let e = 0; e < a.length; e++) {
				let t = a[e];
				for (let e = 0; e < i.availableExtensions.length; e++) {
					let n = i.availableExtensions[e];
					n.ns === t && r.push(n);
				}
			}
			for (let i = 0; i < r.length; i++) {
				let a = r[i];
				a.apply(n, e[a.ns], t);
			}
		}
		function X(e, t, n, r, i, a) {
			return e.build === void 0 && (e.build = a(e, t, n, r, i)), e.build;
		}
		function Z(e, t, n) {
			let r, i = e.displaypropertiesid, a = n.resources.pbmetallicdisplayproperties;
			if (i !== null && a[i] !== void 0) {
				let t = a[i].data[e.index];
				r = new b({
					flatShading: !0,
					roughness: t.roughness,
					metalness: t.metallicness
				});
			} else r = new o({ flatShading: !0 });
			r.name = e.name;
			let s = e.displaycolor, c = s.substring(0, 7);
			return r.color.setStyle(c, C), s.length === 9 && (r.opacity = parseInt(s.charAt(7) + s.charAt(8), 16) / 255), r;
		}
		function ue(e, t, n, r) {
			let i = new x();
			for (let a = 0; a < e.length; a++) {
				let o = e[a], s = t[o.objectId];
				s === void 0 && (Q(o.objectId, t, n, r), s = t[o.objectId]);
				let c = s.clone(), l = o.transform;
				l && c.applyMatrix4(l), i.add(c);
			}
			return i;
		}
		function Q(e, t, n, r) {
			let i = n.resources.object[e];
			if (i.mesh) {
				let e = i.mesh, a = n.extensions, o = n.xml;
				le(a, e, o), t[i.id] = X(e, t, n, r, i, ce);
			} else {
				let e = i.components;
				t[i.id] = X(e, t, n, r, i, ue);
			}
			i.name && (t[i.id].name = i.name), n.resources.implicitfunction && console.warn("THREE.ThreeMFLoader: Implicit Functions are implemented in data-only.", n.resources.implicitfunction);
		}
		function de(e) {
			let t = e.model, n = e.modelRels, r = {}, i = Object.keys(t), a = {};
			if (n) for (let t = 0, r = n.length; t < r; t++) {
				let r = n[t], i = r.target.substring(1);
				e.texture[i] && (a[r.target] = e.texture[i]);
			}
			for (let e = 0; e < i.length; e++) {
				let n = t[i[e]], o = Object.keys(n.resources.object);
				for (let e = 0; e < o.length; e++) {
					let t = o[e];
					Q(t, r, n, a);
				}
			}
			return r;
		}
		function fe(e) {
			for (let t = 0; t < e.length; t++) {
				let n = e[t];
				if (n.target.split(".").pop().toLowerCase() === "model") return n;
			}
		}
		function pe(e, t) {
			let n = new x(), r = fe(t.rels), i = t.model[r.target.substring(1)].build;
			for (let t = 0; t < i.length; t++) {
				let r = i[t], a = e[r.objectId].clone(), o = r.transform;
				o && a.applyMatrix4(o), n.add(a);
			}
			return n;
		}
		let $ = D(r);
		return pe(de($), $);
	}
	addExtension(e) {
		this.availableExtensions.push(e);
	}
};
//#endregion
export { E as ThreeMFLoader };

//# sourceMappingURL=3MFLoader-rnIv0uAn.js.map