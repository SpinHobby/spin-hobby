import { c as e, l as t } from "./three.core-Bn_95pMq.js";
//#region ../../node_modules/three/examples/jsm/utils/BufferGeometryUtils.js
function n(e, n = !1) {
	let i = e[0].index !== null, a = new Set(Object.keys(e[0].attributes)), o = new Set(Object.keys(e[0].morphAttributes)), s = {}, c = {}, l = e[0].morphTargetsRelative, u = new t(), d = 0;
	for (let t = 0; t < e.length; ++t) {
		let r = e[t], f = 0;
		if (i !== (r.index !== null)) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + t + ". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."), null;
		for (let e in r.attributes) {
			if (!a.has(e)) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + t + ". All geometries must have compatible attributes; make sure \"" + e + "\" attribute exists among all geometries, or in none of them."), null;
			s[e] === void 0 && (s[e] = []), s[e].push(r.attributes[e]), f++;
		}
		if (f !== a.size) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + t + ". Make sure all geometries have the same number of attributes."), null;
		if (l !== r.morphTargetsRelative) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + t + ". .morphTargetsRelative must be consistent throughout all geometries."), null;
		for (let e in r.morphAttributes) {
			if (!o.has(e)) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + t + ".  .morphAttributes must be consistent throughout all geometries."), null;
			c[e] === void 0 && (c[e] = []), c[e].push(r.morphAttributes[e]);
		}
		if (n) {
			let e;
			if (i) e = r.index.count;
			else if (r.attributes.position !== void 0) e = r.attributes.position.count;
			else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + t + ". The geometry must have either an index or a position attribute"), null;
			u.addGroup(d, e, t), d += e;
		}
	}
	if (i) {
		let t = 0, n = [];
		for (let r = 0; r < e.length; ++r) {
			let i = e[r].index;
			for (let e = 0; e < i.count; ++e) n.push(i.getX(e) + t);
			t += e[r].attributes.position.count;
		}
		u.setIndex(n);
	}
	for (let e in s) {
		let t = r(s[e]);
		if (!t) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the " + e + " attribute."), null;
		u.setAttribute(e, t);
	}
	for (let e in c) {
		let t = c[e][0].length;
		if (t !== 0) {
			u.morphAttributes = u.morphAttributes || {}, u.morphAttributes[e] = [];
			for (let n = 0; n < t; ++n) {
				let t = [];
				for (let r = 0; r < c[e].length; ++r) t.push(c[e][r][n]);
				let i = r(t);
				if (!i) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the " + e + " morphAttribute."), null;
				u.morphAttributes[e].push(i);
			}
		}
	}
	return u;
}
function r(t) {
	let n, r, i, a = -1, o = 0;
	for (let e = 0; e < t.length; ++e) {
		let s = t[e];
		if (n === void 0 && (n = s.array.constructor), n !== s.array.constructor) return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."), null;
		if (r === void 0 && (r = s.itemSize), r !== s.itemSize) return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."), null;
		if (i === void 0 && (i = s.normalized), i !== s.normalized) return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."), null;
		if (a === -1 && (a = s.gpuType), a !== s.gpuType) return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."), null;
		o += s.count * r;
	}
	let s = new n(o), c = new e(s, r, i), l = 0;
	for (let e = 0; e < t.length; ++e) {
		let n = t[e];
		if (n.isInterleavedBufferAttribute) {
			let e = l / r;
			for (let t = 0, i = n.count; t < i; t++) for (let i = 0; i < r; i++) {
				let r = n.getComponent(t, i);
				c.setComponent(t + e, i, r);
			}
		} else s.set(n.array, l);
		l += n.count * r;
	}
	return a !== void 0 && (c.gpuType = a), c;
}
function i(e, t) {
	if (t === 0) return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."), e;
	if (t === 2 || t === 1) {
		let n = e.getIndex();
		if (n === null) {
			let t = [], r = e.getAttribute("position");
			if (r !== void 0) {
				for (let e = 0; e < r.count; e++) t.push(e);
				e.setIndex(t), n = e.getIndex();
			} else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."), e;
		}
		let r = n.count - 2, i = [];
		if (t === 2) for (let e = 1; e <= r; e++) i.push(n.getX(0)), i.push(n.getX(e)), i.push(n.getX(e + 1));
		else for (let e = 0; e < r; e++) e % 2 == 0 ? (i.push(n.getX(e)), i.push(n.getX(e + 1)), i.push(n.getX(e + 2))) : (i.push(n.getX(e + 2)), i.push(n.getX(e + 1)), i.push(n.getX(e)));
		return i.length / 3 !== r && console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles."), e.setIndex(i), e.clearGroups(), e;
	}
	return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:", t), e;
}
//#endregion
export { i as n, n as t };

//# sourceMappingURL=BufferGeometryUtils-a60fER9N.js.map