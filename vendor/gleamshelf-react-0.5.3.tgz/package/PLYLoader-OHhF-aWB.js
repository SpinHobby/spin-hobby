import { $n as e, G as t, K as n, Ln as r, N as i, P as a, W as o, c as s, er as c, f as l, l as u, lt as d, tr as f } from "./three.core-Bn_95pMq.js";
//#region ../../node_modules/three/examples/jsm/loaders/PLYLoader.js
var p = new l(), m = class extends d {
	constructor(e) {
		super(e), this.propertyNameMapping = {}, this.customPropertyMapping = {};
	}
	load(e, t, n, r) {
		let a = this, o = new i(this.manager);
		o.setPath(this.path), o.setResponseType("arraybuffer"), o.setRequestHeader(this.requestHeader), o.setWithCredentials(this.withCredentials), o.load(e, function(n) {
			try {
				t(a.parse(n));
			} catch (t) {
				r ? r(t) : console.error(t), a.manager.itemError(e);
			}
		}, n, r);
	}
	setPropertyNameMapping(e) {
		this.propertyNameMapping = e;
	}
	setCustomPropertyNameMapping(e) {
		this.customPropertyMapping = e;
	}
	parse(i) {
		function s(e, t = 0) {
			let n = /^ply([\s\S]*)end_header(\r\n|\r|\n)/, r = "", i = n.exec(e);
			i !== null && (r = i[1]);
			let a = {
				comments: [],
				elements: [],
				headerLength: t,
				objInfo: ""
			}, o = r.split(/\r\n|\r|\n/), s;
			function c(e, t) {
				let n = { type: e[0] };
				return n.type === "list" ? (n.name = e[3], n.countType = e[1], n.itemType = e[2]) : n.name = e[1], n.name in t && (n.name = t[n.name]), n;
			}
			for (let e = 0; e < o.length; e++) {
				let t = o[e];
				if (t = t.trim(), t === "") continue;
				let n = t.split(/\s+/), r = n.shift();
				switch (t = n.join(" "), r) {
					case "format":
						a.format = n[0], a.version = n[1];
						break;
					case "comment":
						a.comments.push(t);
						break;
					case "element":
						s !== void 0 && a.elements.push(s), s = {}, s.name = n[0], s.count = parseInt(n[1]), s.properties = [];
						break;
					case "property":
						s.properties.push(c(n, k.propertyNameMapping));
						break;
					case "obj_info":
						a.objInfo = t;
						break;
					default: console.log("unhandled", r, n);
				}
			}
			return s !== void 0 && a.elements.push(s), a;
		}
		function l(e, t) {
			switch (t) {
				case "char":
				case "uchar":
				case "short":
				case "ushort":
				case "int":
				case "uint":
				case "int8":
				case "uint8":
				case "int16":
				case "uint16":
				case "int32":
				case "uint32": return parseInt(e);
				case "float":
				case "double":
				case "float32":
				case "float64": return parseFloat(e);
			}
		}
		function d(e, t) {
			let n = {};
			for (let r = 0; r < e.length; r++) {
				if (t.empty()) return null;
				if (e[r].type === "list") {
					let i = [], a = l(t.next(), e[r].countType);
					for (let n = 0; n < a; n++) {
						if (t.empty()) return null;
						i.push(l(t.next(), e[r].itemType));
					}
					n[e[r].name] = i;
				} else n[e[r].name] = l(t.next(), e[r].type);
			}
			return n;
		}
		function m() {
			let e = {
				indices: [],
				vertices: [],
				normals: [],
				uvs: [],
				faceVertexUvs: [],
				colors: [],
				faceVertexColors: [],
				descriptors: {}
			};
			for (let t of Object.keys(k.customPropertyMapping)) e[t] = [];
			return e;
		}
		function _(r) {
			switch (r) {
				case "int8":
				case "char": return n;
				case "uint8":
				case "uchar": return f;
				case "int16":
				case "short": return o;
				case "uint16":
				case "ushort": return e;
				case "int32":
				case "int": return t;
				case "uint32":
				case "uint": return c;
				case "float32":
				case "float": return a;
				case "float64":
				case "double": return h;
			}
		}
		function v(e) {
			switch (e) {
				case "uchar":
				case "uint8": return 1 / 255;
				case "ushort":
				case "uint16": return 1 / 65535;
				case "float":
				case "float32":
				case "double":
				case "float64": return 1;
				default: return 1 / 255;
			}
		}
		function y(e) {
			return e === "float" || e === "float32" || e === "double" || e === "float64";
		}
		function b(e) {
			function t(t) {
				for (let n of t) {
					let t = e.find((e) => e.name === n);
					if (t) return t;
				}
				return null;
			}
			let n = t([
				"x",
				"px",
				"posx"
			]), r = t([
				"y",
				"py",
				"posy"
			]), i = t([
				"z",
				"pz",
				"posz"
			]), a = t(["nx", "normalx"]), o = t(["ny", "normaly"]), s = t(["nz", "normalz"]), c = t([
				"s",
				"u",
				"texture_u",
				"tx"
			]), l = t([
				"t",
				"v",
				"texture_v",
				"ty"
			]), u = t([
				"red",
				"diffuse_red",
				"r",
				"diffuse_r"
			]), d = t([
				"green",
				"diffuse_green",
				"g",
				"diffuse_g"
			]), f = t([
				"blue",
				"diffuse_blue",
				"b",
				"diffuse_b"
			]), p = t(["texcoord"]), m = {};
			for (let t of Object.keys(k.customPropertyMapping)) {
				let n = k.customPropertyMapping[t].map((t) => e.find((e) => e.name === t)), r = n.filter((e) => e).map((e) => e.type);
				m[t] = {
					type: r.length > 0 && r.every((e) => e === r[0]) ? r[0] : "float32",
					usage: n.every((e) => e !== void 0)
				};
			}
			return {
				position: {
					names: [
						n ? n.name : "x",
						r ? r.name : "y",
						i ? i.name : "z"
					],
					type: n ? n.type : "float32",
					usage: !!(n && r && i)
				},
				normal: {
					names: [
						a ? a.name : "nx",
						o ? o.name : "ny",
						s ? s.name : "nz"
					],
					type: a ? a.type : "float32",
					usage: !!(a && o && s)
				},
				uv: {
					names: [c ? c.name : "s", l ? l.name : "t"],
					type: c ? c.type : "float32",
					usage: !!(c && l)
				},
				texcoord: {
					type: p ? p.itemType : "float32",
					usage: !!p
				},
				color: {
					names: [
						u ? u.name : "red",
						d ? d.name : "green",
						f ? f.name : "blue"
					],
					type: u ? u.type : "uchar",
					usage: !!(u && d && f)
				},
				custom: m
			};
		}
		function x(e, t) {
			let n = m(), r = /end_header\s+(\S[\s\S]*\S|\S)\s*$/, i, a;
			i = (a = r.exec(e)) === null ? [] : a[1].split(/\s+/);
			let o = new g(i);
			loop: for (let e = 0; e < t.elements.length; e++) {
				let r = t.elements[e], i = b(r.properties);
				n.descriptors[r.name] = i;
				for (let e = 0; e < r.count; e++) {
					let e = d(r.properties, o);
					if (!e) break loop;
					C(n, r.name, e, i);
				}
			}
			return S(n);
		}
		function S(e) {
			let t = new u(), n = e.descriptors.vertex;
			e.indices.length > 0 && t.setIndex(e.indices);
			let r = _(n ? n.position.type : "float32");
			if (t.setAttribute("position", new r(e.vertices, 3)), e.normals.length > 0) {
				let r = _(n.normal.type);
				t.setAttribute("normal", new r(e.normals, 3));
			}
			if (e.uvs.length > 0) {
				let r = _(n.uv.type);
				t.setAttribute("uv", new r(e.uvs, 2));
			}
			if (e.colors.length > 0) {
				let r = n.color.type, i = !y(r), a = _(r);
				t.setAttribute("color", new a(e.colors, 3, i));
			}
			if (e.faceVertexUvs.length > 0 || e.faceVertexColors.length > 0) {
				if (t = t.toNonIndexed(), e.faceVertexUvs.length > 0) {
					let n = _(e.descriptors.face.texcoord.type);
					t.setAttribute("uv", new n(e.faceVertexUvs, 2));
				}
				if (e.faceVertexColors.length > 0) {
					let n = e.descriptors.face.color.type, r = !y(n), i = _(n);
					t.setAttribute("color", new i(e.faceVertexColors, 3, r));
				}
			}
			for (let r of Object.keys(k.customPropertyMapping)) if (e[r].length > 0) {
				let i = _(n.custom[r].type);
				t.setAttribute(r, new i(e[r], k.customPropertyMapping[r].length));
			}
			return t.computeBoundingSphere(), t;
		}
		function C(e, t, n, i) {
			if (t === "vertex") {
				let { position: t, normal: a, uv: o, color: s } = i;
				if (t.usage && e.vertices.push(n[t.names[0]], n[t.names[1]], n[t.names[2]]), a.usage && e.normals.push(n[a.names[0]], n[a.names[1]], n[a.names[2]]), o.usage && e.uvs.push(n[o.names[0]], n[o.names[1]]), s.usage) {
					let t = v(s.type), i = y(s.type);
					p.setRGB(n[s.names[0]] * t, n[s.names[1]] * t, n[s.names[2]] * t, r);
					let a = 1 / t;
					e.colors.push(i ? p.r : Math.round(p.r * a), i ? p.g : Math.round(p.g * a), i ? p.b : Math.round(p.b * a));
				}
				for (let t of Object.keys(k.customPropertyMapping)) for (let r of k.customPropertyMapping[t]) e[t].push(n[r]);
			} else if (t === "face") {
				let t = n.vertex_indices || n.vertex_index, a = n.texcoord;
				t.length === 3 ? (e.indices.push(t[0], t[1], t[2]), a && a.length === 6 && (e.faceVertexUvs.push(a[0], a[1]), e.faceVertexUvs.push(a[2], a[3]), e.faceVertexUvs.push(a[4], a[5]))) : t.length === 4 && (e.indices.push(t[0], t[1], t[3]), e.indices.push(t[1], t[2], t[3]));
				let { color: o } = i;
				if (o.usage) {
					let t = v(o.type);
					p.setRGB(n[o.names[0]] * t, n[o.names[1]] * t, n[o.names[2]] * t, r);
					let i = 1 / t, a = p.r * i, s = p.g * i, c = p.b * i;
					e.faceVertexColors.push(a, s, c), e.faceVertexColors.push(a, s, c), e.faceVertexColors.push(a, s, c);
				}
			}
		}
		function w(e, t) {
			let n = {}, r = 0;
			for (let i = 0; i < t.length; i++) {
				let a = t[i], o = a.valueReader;
				if (a.type === "list") {
					let t = [], i = a.countReader.read(e + r);
					r += a.countReader.size;
					for (let n = 0; n < i; n++) t.push(o.read(e + r)), r += o.size;
					n[a.name] = t;
				} else n[a.name] = o.read(e + r), r += o.size;
			}
			return [n, r];
		}
		function T(e, t, n) {
			function r(e, t, n) {
				switch (t) {
					case "int8":
					case "char": return {
						read: (t) => e.getInt8(t),
						size: 1
					};
					case "uint8":
					case "uchar": return {
						read: (t) => e.getUint8(t),
						size: 1
					};
					case "int16":
					case "short": return {
						read: (t) => e.getInt16(t, n),
						size: 2
					};
					case "uint16":
					case "ushort": return {
						read: (t) => e.getUint16(t, n),
						size: 2
					};
					case "int32":
					case "int": return {
						read: (t) => e.getInt32(t, n),
						size: 4
					};
					case "uint32":
					case "uint": return {
						read: (t) => e.getUint32(t, n),
						size: 4
					};
					case "float32":
					case "float": return {
						read: (t) => e.getFloat32(t, n),
						size: 4
					};
					case "float64":
					case "double": return {
						read: (t) => e.getFloat64(t, n),
						size: 8
					};
				}
			}
			for (let i = 0, a = e.length; i < a; i++) {
				let a = e[i];
				a.type === "list" ? (a.countReader = r(t, a.countType, n), a.valueReader = r(t, a.itemType, n)) : a.valueReader = r(t, a.type, n);
			}
		}
		function E(e, t) {
			let n = m(), r = t.format === "binary_little_endian", i = new DataView(e, t.headerLength), a, o = 0;
			for (let e = 0; e < t.elements.length; e++) {
				let s = t.elements[e], c = s.properties, l = b(c);
				n.descriptors[s.name] = l, T(c, i, r);
				for (let e = 0; e < s.count; e++) {
					a = w(o, c), o += a[1];
					let e = a[0];
					C(n, s.name, e, l);
				}
			}
			return S(n);
		}
		function D(e) {
			let t = 0, n = !0, r = "", i = [], a = new TextDecoder().decode(e.subarray(0, 5)), o = /^ply\r\n/.test(a);
			do {
				let a = String.fromCharCode(e[t++]);
				a !== "\n" && a !== "\r" ? r += a : (r === "end_header" && (n = !1), r !== "" && (i.push(r), r = ""));
			} while (n && t < e.length);
			return o === !0 && t++, {
				headerText: i.join("\r") + "\r",
				headerLength: t
			};
		}
		let O, k = this;
		if (i instanceof ArrayBuffer) {
			let e = new Uint8Array(i), { headerText: t, headerLength: n } = D(e), r = s(t, n);
			O = r.format === "ascii" ? x(new TextDecoder().decode(e), r) : E(i, r);
		} else O = x(i, s(i));
		return O;
	}
}, h = class extends s {
	constructor(e, t, n) {
		super(new Float64Array(e), t, n);
	}
}, g = class {
	constructor(e) {
		this.arr = e, this.i = 0;
	}
	empty() {
		return this.i >= this.arr.length;
	}
	next() {
		return this.arr[this.i++];
	}
};
//#endregion
export { m as PLYLoader };

//# sourceMappingURL=PLYLoader-OHhF-aWB.js.map