import { Ln as e, N as t, P as n, c as r, f as i, fr as a, l as o, lt as s } from "./three.core-Bn_95pMq.js";
//#region ../../node_modules/three/examples/jsm/loaders/STLLoader.js
var c = class extends s {
	constructor(e) {
		super(e);
	}
	load(e, n, r, i) {
		let a = this, o = new t(this.manager);
		o.setPath(this.path), o.setResponseType("arraybuffer"), o.setRequestHeader(this.requestHeader), o.setWithCredentials(this.withCredentials), o.load(e, function(t) {
			try {
				n(a.parse(t));
			} catch (t) {
				i ? i(t) : console.error(t), a.manager.itemError(e);
			}
		}, r, i);
	}
	parse(t) {
		function s(e) {
			let t = new DataView(e);
			if (84 + t.getUint32(80, !0) * 50 === t.byteLength) return !0;
			let n = [
				115,
				111,
				108,
				105,
				100
			];
			for (let e = 0; e < 5; e++) if (c(n, t, e)) return !1;
			return !0;
		}
		function c(e, t, n) {
			for (let r = 0, i = e.length; r < i; r++) if (e[r] !== t.getUint8(n + r)) return !1;
			return !0;
		}
		function l(t) {
			let n = new DataView(t), a = n.getUint32(80, !0), s, c, l, u = !1, d, f, p, m, h;
			for (let e = 0; e < 70; e++) n.getUint32(e, !1) == 1129270351 && n.getUint8(e + 4) == 82 && n.getUint8(e + 5) == 61 && (u = !0, d = new Float32Array(a * 3 * 3), f = n.getUint8(e + 6) / 255, p = n.getUint8(e + 7) / 255, m = n.getUint8(e + 8) / 255, h = n.getUint8(e + 9) / 255);
			let g = new o(), _ = new Float32Array(a * 3 * 3), v = new Float32Array(a * 3 * 3), y = new i();
			for (let t = 0; t < a; t++) {
				let r = 84 + t * 50, i = n.getFloat32(r, !0), a = n.getFloat32(r + 4, !0), o = n.getFloat32(r + 8, !0);
				if (u) {
					let e = n.getUint16(r + 48, !0);
					e & 32768 ? (s = f, c = p, l = m) : (s = (e & 31) / 31, c = (e >> 5 & 31) / 31, l = (e >> 10 & 31) / 31);
				}
				for (let f = 1; f <= 3; f++) {
					let p = r + f * 12, m = t * 3 * 3 + (f - 1) * 3;
					_[m] = n.getFloat32(p, !0), _[m + 1] = n.getFloat32(p + 4, !0), _[m + 2] = n.getFloat32(p + 8, !0), v[m] = i, v[m + 1] = a, v[m + 2] = o, u && (y.setRGB(s, c, l, e), d[m] = y.r, d[m + 1] = y.g, d[m + 2] = y.b);
				}
			}
			return g.setAttribute("position", new r(_, 3)), g.setAttribute("normal", new r(v, 3)), u && (g.setAttribute("color", new r(d, 3)), g.hasColors = !0, g.alpha = h), g;
		}
		function u(e) {
			let t = new o(), r = /solid([\s\S]*?)endsolid/g, i = /facet([\s\S]*?)endfacet/g, s = /solid\s(.+)/, c = 0, l = "[\\s]+([+-]?(?:\\d*)(?:\\.\\d*)?(?:[eE][+-]?\\d+)?)", u = RegExp("vertex" + l + l + l, "g"), d = RegExp("normal" + l + l + l, "g"), f = [], p = [], m = [], h = new a(), g, _ = 0, v = 0, y = 0;
			for (; (g = r.exec(e)) !== null;) {
				v = y;
				let e = g[0], n = (g = s.exec(e)) === null ? "" : g[1];
				for (m.push(n); (g = i.exec(e)) !== null;) {
					let e = 0, t = 0, n = g[0];
					for (; (g = d.exec(n)) !== null;) h.x = parseFloat(g[1]), h.y = parseFloat(g[2]), h.z = parseFloat(g[3]), t++;
					for (; (g = u.exec(n)) !== null;) f.push(parseFloat(g[1]), parseFloat(g[2]), parseFloat(g[3])), p.push(h.x, h.y, h.z), e++, y++;
					t !== 1 && console.error("THREE.STLLoader: Something isn't right with the normal of face number " + c), e !== 3 && console.error("THREE.STLLoader: Something isn't right with the vertices of face number " + c), c++;
				}
				let r = v, a = y - v;
				t.userData.groupNames = m, t.addGroup(r, a, _), _++;
			}
			return t.setAttribute("position", new n(f, 3)), t.setAttribute("normal", new n(p, 3)), t;
		}
		function d(e) {
			return typeof e == "string" ? e : new TextDecoder().decode(e);
		}
		function f(e) {
			if (typeof e == "string") {
				let t = new Uint8Array(e.length);
				for (let n = 0; n < e.length; n++) t[n] = e.charCodeAt(n) & 255;
				return t.buffer || t;
			}
			return e;
		}
		let p = f(t);
		return s(p) ? l(p) : u(d(t));
	}
};
//#endregion
export { c as STLLoader };

//# sourceMappingURL=STLLoader-BlcQUutx.js.map