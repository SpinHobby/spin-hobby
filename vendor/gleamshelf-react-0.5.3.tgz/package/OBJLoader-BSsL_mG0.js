import { Ln as e, Lt as t, N as n, P as r, Rt as i, St as a, _t as o, f as s, fr as c, l, lt as u, pt as d, rt as f, tt as p, z as m } from "./three.core-Bn_95pMq.js";
//#region ../../node_modules/three/examples/jsm/loaders/OBJLoader.js
var h = /^[og]\s*(.+)?/, g = /^mtllib /, _ = /^usemtl /, v = /^usemap /, y = /\s+/, b = new c(), x = new c(), S = new c(), C = new c(), w = new c(), T = new s();
function E() {
	let e = {
		objects: [],
		object: {},
		vertices: [],
		normals: [],
		colors: [],
		uvs: [],
		materials: {},
		materialLibraries: [],
		startObject: function(e, t) {
			if (this.object && this.object.fromDeclaration === !1) {
				this.object.name = e, this.object.fromDeclaration = t !== !1;
				return;
			}
			let n = this.object && typeof this.object.currentMaterial == "function" ? this.object.currentMaterial() : void 0;
			if (this.object && typeof this.object._finalize == "function" && this.object._finalize(!0), this.object = {
				name: e || "",
				fromDeclaration: t !== !1,
				geometry: {
					vertices: [],
					normals: [],
					colors: [],
					uvs: [],
					hasUVIndices: !1
				},
				materials: [],
				smooth: !0,
				startMaterial: function(e, t) {
					let n = this._finalize(!1);
					n && (n.inherited || n.groupCount <= 0) && this.materials.splice(n.index, 1);
					let r = {
						index: this.materials.length,
						name: e || "",
						mtllib: Array.isArray(t) && t.length > 0 ? t[t.length - 1] : "",
						smooth: n === void 0 ? this.smooth : n.smooth,
						groupStart: n === void 0 ? 0 : n.groupEnd,
						groupEnd: -1,
						groupCount: -1,
						inherited: !1,
						clone: function(e) {
							let t = {
								index: typeof e == "number" ? e : this.index,
								name: this.name,
								mtllib: this.mtllib,
								smooth: this.smooth,
								groupStart: 0,
								groupEnd: -1,
								groupCount: -1,
								inherited: !1
							};
							return t.clone = this.clone.bind(t), t;
						}
					};
					return this.materials.push(r), r;
				},
				currentMaterial: function() {
					if (this.materials.length > 0) return this.materials[this.materials.length - 1];
				},
				_finalize: function(e) {
					let t = this.currentMaterial();
					if (t && t.groupEnd === -1 && (t.groupEnd = this.geometry.vertices.length / 3, t.groupCount = t.groupEnd - t.groupStart, t.inherited = !1), e && this.materials.length > 1) for (let e = this.materials.length - 1; e >= 0; e--) this.materials[e].groupCount <= 0 && this.materials.splice(e, 1);
					return e && this.materials.length === 0 && this.materials.push({
						name: "",
						smooth: this.smooth
					}), t;
				}
			}, n && n.name && typeof n.clone == "function") {
				let e = n.clone(0);
				e.inherited = !0, this.object.materials.push(e);
			}
			this.objects.push(this.object);
		},
		finalize: function() {
			this.object && typeof this.object._finalize == "function" && this.object._finalize(!0);
		},
		parseVertexIndex: function(e, t) {
			let n = parseInt(e, 10);
			return (n >= 0 ? n - 1 : n + t / 3) * 3;
		},
		parseNormalIndex: function(e, t) {
			let n = parseInt(e, 10);
			return (n >= 0 ? n - 1 : n + t / 3) * 3;
		},
		parseUVIndex: function(e, t) {
			let n = parseInt(e, 10);
			return (n >= 0 ? n - 1 : n + t / 2) * 2;
		},
		addVertex: function(e, t, n) {
			let r = this.vertices, i = this.object.geometry.vertices;
			i.push(r[e + 0], r[e + 1], r[e + 2]), i.push(r[t + 0], r[t + 1], r[t + 2]), i.push(r[n + 0], r[n + 1], r[n + 2]);
		},
		addVertexPoint: function(e) {
			let t = this.vertices;
			this.object.geometry.vertices.push(t[e + 0], t[e + 1], t[e + 2]);
		},
		addVertexLine: function(e) {
			let t = this.vertices;
			this.object.geometry.vertices.push(t[e + 0], t[e + 1], t[e + 2]);
		},
		addNormal: function(e, t, n) {
			let r = this.normals, i = this.object.geometry.normals;
			i.push(r[e + 0], r[e + 1], r[e + 2]), i.push(r[t + 0], r[t + 1], r[t + 2]), i.push(r[n + 0], r[n + 1], r[n + 2]);
		},
		addFaceNormal: function(e, t, n) {
			let r = this.vertices, i = this.object.geometry.normals;
			b.fromArray(r, e), x.fromArray(r, t), S.fromArray(r, n), w.subVectors(S, x), C.subVectors(b, x), w.cross(C), w.normalize(), i.push(w.x, w.y, w.z), i.push(w.x, w.y, w.z), i.push(w.x, w.y, w.z);
		},
		addColor: function(e, t, n) {
			let r = this.colors, i = this.object.geometry.colors;
			r[e] !== void 0 && i.push(r[e + 0], r[e + 1], r[e + 2]), r[t] !== void 0 && i.push(r[t + 0], r[t + 1], r[t + 2]), r[n] !== void 0 && i.push(r[n + 0], r[n + 1], r[n + 2]);
		},
		addUV: function(e, t, n) {
			let r = this.uvs, i = this.object.geometry.uvs;
			i.push(r[e + 0], r[e + 1]), i.push(r[t + 0], r[t + 1]), i.push(r[n + 0], r[n + 1]);
		},
		addDefaultUV: function() {
			let e = this.object.geometry.uvs;
			e.push(0, 0), e.push(0, 0), e.push(0, 0);
		},
		addUVLine: function(e) {
			let t = this.uvs;
			this.object.geometry.uvs.push(t[e + 0], t[e + 1]);
		},
		addFace: function(e, t, n, r, i, a, o, s, c) {
			let l = this.vertices.length, u = this.parseVertexIndex(e, l), d = this.parseVertexIndex(t, l), f = this.parseVertexIndex(n, l);
			if (this.addVertex(u, d, f), this.addColor(u, d, f), o !== void 0 && o !== "") {
				let e = this.normals.length;
				u = this.parseNormalIndex(o, e), d = this.parseNormalIndex(s, e), f = this.parseNormalIndex(c, e), this.addNormal(u, d, f);
			} else this.addFaceNormal(u, d, f);
			if (r !== void 0 && r !== "") {
				let e = this.uvs.length;
				u = this.parseUVIndex(r, e), d = this.parseUVIndex(i, e), f = this.parseUVIndex(a, e), this.addUV(u, d, f), this.object.geometry.hasUVIndices = !0;
			} else this.addDefaultUV();
		},
		addPointGeometry: function(e) {
			this.object.geometry.type = "Points";
			let t = this.vertices.length;
			for (let n = 0, r = e.length; n < r; n++) {
				let r = this.parseVertexIndex(e[n], t);
				this.addVertexPoint(r), this.addColor(r);
			}
		},
		addLineGeometry: function(e, t) {
			this.object.geometry.type = "Line";
			let n = this.vertices.length, r = this.uvs.length;
			for (let t = 0, r = e.length; t < r; t++) this.addVertexLine(this.parseVertexIndex(e[t], n));
			for (let e = 0, n = t.length; e < n; e++) this.addUVLine(this.parseUVIndex(t[e], r));
		}
	};
	return e.startObject("", !1), e;
}
var D = class extends u {
	constructor(e) {
		super(e), this.materials = null;
	}
	load(e, t, r, i) {
		let a = this, o = new n(this.manager);
		o.setPath(this.path), o.setRequestHeader(this.requestHeader), o.setWithCredentials(this.withCredentials), o.load(e, function(n) {
			try {
				t(a.parse(n));
			} catch (t) {
				i ? i(t) : console.error(t), a.manager.itemError(e);
			}
		}, r, i);
	}
	setMaterials(e) {
		return this.materials = e, this;
	}
	parse(n) {
		let s = new E();
		n.indexOf("\r\n") !== -1 && (n = n.replace(/\r\n/g, "\n")), n.indexOf("\\\n") !== -1 && (n = n.replace(/\\\n/g, ""));
		let c = n.split("\n"), u = [];
		for (let t = 0, n = c.length; t < n; t++) {
			let n = c[t].trimStart();
			if (n.length === 0) continue;
			let r = n.charAt(0);
			if (r !== "#") {
				if (r === "v") {
					let t = n.split(y);
					switch (t[0]) {
						case "v":
							s.vertices.push(parseFloat(t[1]), parseFloat(t[2]), parseFloat(t[3])), t.length >= 7 ? (T.setRGB(parseFloat(t[4]), parseFloat(t[5]), parseFloat(t[6]), e), s.colors.push(T.r, T.g, T.b)) : s.colors.push(void 0, void 0, void 0);
							break;
						case "vn":
							s.normals.push(parseFloat(t[1]), parseFloat(t[2]), parseFloat(t[3]));
							break;
						case "vt": s.uvs.push(parseFloat(t[1]), parseFloat(t[2]));
					}
				} else if (r === "f") {
					let e = n.slice(1).trim().split(y), t = [];
					for (let n = 0, r = e.length; n < r; n++) {
						let r = e[n];
						if (r.length > 0) {
							let e = r.split("/");
							t.push(e);
						}
					}
					let r = t[0];
					for (let e = 1, n = t.length - 1; e < n; e++) {
						let n = t[e], i = t[e + 1];
						s.addFace(r[0], n[0], i[0], r[1], n[1], i[1], r[2], n[2], i[2]);
					}
				} else if (r === "l") {
					let e = n.substring(1).trim().split(" "), t = [], r = [];
					if (n.indexOf("/") === -1) t = e;
					else for (let n = 0, i = e.length; n < i; n++) {
						let i = e[n].split("/");
						i[0] !== "" && t.push(i[0]), i[1] !== "" && r.push(i[1]);
					}
					s.addLineGeometry(t, r);
				} else if (r === "p") {
					let e = n.slice(1).trim().split(" ");
					s.addPointGeometry(e);
				} else if ((u = h.exec(n)) !== null) {
					let e = (" " + u[0].slice(1).trim()).slice(1);
					s.startObject(e);
				} else if (_.test(n)) s.object.startMaterial(n.substring(7).trim(), s.materialLibraries);
				else if (g.test(n)) s.materialLibraries.push(n.substring(7).trim());
				else if (v.test(n)) console.warn("THREE.OBJLoader: Rendering identifier \"usemap\" not supported. Textures must be defined in MTL files.");
				else if (r === "s") {
					if (u = n.split(" "), u.length > 1) {
						let e = u[1].trim().toLowerCase();
						s.object.smooth = e !== "0" && e !== "off";
					} else s.object.smooth = !0;
					let e = s.object.currentMaterial();
					e && (e.smooth = s.object.smooth);
				} else {
					if (n === "\0") continue;
					console.warn("THREE.OBJLoader: Unexpected line: \"" + n + "\"");
				}
			}
		}
		s.finalize();
		let b = new m();
		if (b.materialLibraries = [].concat(s.materialLibraries), s.objects.length !== 1 || s.objects[0].geometry.vertices.length !== 0) for (let e = 0, n = s.objects.length; e < n; e++) {
			let n = s.objects[e], c = n.geometry, u = n.materials, m = c.type === "Line", h = c.type === "Points", g = !1;
			if (c.vertices.length === 0) continue;
			let _ = new l();
			_.setAttribute("position", new r(c.vertices, 3)), c.normals.length > 0 && _.setAttribute("normal", new r(c.normals, 3)), c.colors.length > 0 && (g = !0, _.setAttribute("color", new r(c.colors, 3))), c.hasUVIndices === !0 && _.setAttribute("uv", new r(c.uvs, 2));
			let v = [];
			for (let e = 0, t = u.length; e < t; e++) {
				let t = u[e], n = t.name + "_" + t.smooth + "_" + g, r = s.materials[n];
				if (this.materials !== null) {
					if (r = this.materials.create(t.name), m && r && !(r instanceof p)) {
						let e = new p();
						d.prototype.copy.call(e, r), e.color.copy(r.color), r = e;
					} else if (h && r && !(r instanceof i)) {
						let e = new i({
							size: 10,
							sizeAttenuation: !1
						});
						d.prototype.copy.call(e, r), e.color.copy(r.color), e.map = r.map, r = e;
					}
				}
				r === void 0 && (r = m ? new p() : h ? new i({
					size: 1,
					sizeAttenuation: !1
				}) : new a(), r.name = t.name, r.flatShading = !t.smooth, r.vertexColors = g, s.materials[n] = r), v.push(r);
			}
			let y;
			if (v.length > 1) {
				for (let e = 0, t = u.length; e < t; e++) {
					let t = u[e];
					_.addGroup(t.groupStart, t.groupCount, e);
				}
				y = m ? new f(_, v) : h ? new t(_, v) : new o(_, v);
			} else y = m ? new f(_, v[0]) : h ? new t(_, v[0]) : new o(_, v[0]);
			y.name = n.name, b.add(y);
		}
		else if (s.vertices.length > 0) {
			let e = new i({
				size: 1,
				sizeAttenuation: !1
			}), n = new l();
			n.setAttribute("position", new r(s.vertices, 3)), s.colors.length > 0 && s.colors[0] !== void 0 && (n.setAttribute("color", new r(s.colors, 3)), e.vertexColors = !0);
			let a = new t(n, e);
			b.add(a);
		}
		return b;
	}
};
//#endregion
export { D as OBJLoader };

//# sourceMappingURL=OBJLoader-BSsL_mG0.js.map