import { A as e, C as t, M as n, S as r, b as i, j as a, k as o, l as s, n as c, t as l, x as u } from "./GleamEditor-BwL_fApV.js";
import { t as d } from "./PhotoLab-CAAOzhnO.js";
import { n as f, t as p } from "./places-CIrqIjZW.js";
import { o as m, r as h } from "./library-BhwMQqZz.js";
import { lazy as g, useEffect as _, useState as v } from "react";
import { Fragment as y, jsx as b, jsxs as x } from "react/jsx-runtime";
import { createPortal as S } from "react-dom";
//#region src/PhoneStart.tsx
function C({ onOpen: e, className: n, label: r = "From phone" }) {
	let i = t(), [a, o] = v(!1);
	return i.state !== "ready" || !i.canPhone ? null : /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("button", {
		type: "button",
		className: n,
		onClick: () => o(!0),
		title: "Take photos on a phone and edit them here",
		children: r
	}), a && S(/* @__PURE__ */ b("div", {
		className: "gs-editor gs-editor--host",
		children: /* @__PURE__ */ b(s, {
			client: i.client,
			onClose: () => o(!1),
			onOpen: (t, n) => {
				o(!1), e(t, n);
			}
		})
	}), document.body)] });
}
//#endregion
//#region src/GleamEditorModal.tsx
function w({ open: e, ...t }) {
	return _(() => {
		if (!e) return;
		let t = document.body.style.overflow;
		return document.body.style.overflow = "hidden", () => {
			document.body.style.overflow = t;
		};
	}, [e]), e ? S(/* @__PURE__ */ b("div", {
		className: "gs-modal",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Edit photo",
		children: /* @__PURE__ */ b("div", {
			className: "gs-modal__sheet",
			children: /* @__PURE__ */ b(l, { ...t })
		})
	}), document.body) : null;
}
//#endregion
//#region src/index.ts
var T = g(() => import("./AvatarMode-BYEvOCr4.js").then((e) => e.n).then((e) => ({ default: e.AvatarMode }))), E = g(() => import("./MarketMode-DNr0oBct.js").then((e) => e.n).then((e) => ({ default: e.MarketMode })));
//#endregion
export { T as AvatarMode, c as EditMode, l as GleamEditor, w as GleamEditorModal, p as MODEL_PLACES, E as MarketMode, i as NoCloudAi, C as PhoneStart, d as PhotoLab, o as decodePhoto, e as fetchPhoto, a as gpuMaxTextureSize, f as modelPlace, m as setEditorLanguage, u as setLocalAppGuide, r as setLookForLocalApp, h as setModelLibrary, n as trimTransparent };

//# sourceMappingURL=index.js.map