import { Cr as e, Kn as t, R as n, _t as r, d as i, h as a, u as o, z as s } from "./three.core-BCwsimN9.js";
//#region ../../node_modules/three/examples/jsm/loaders/STLLoader.js
var c = class extends r {
	constructor(e) {
		super(e);
	}
	load(e, t, r, i) {
		let a = this, o = new n(this.manager);
		o.setPath(this.path), o.setResponseType("arraybuffer"), o.setRequestHeader(this.requestHeader), o.setWithCredentials(this.withCredentials), o.load(e, function(n) {
			try {
				t(a.parse(n));
			} catch (t) {
				i ? i(t) : console.error(t), a.manager.itemError(e);
			}
		}, r, i);
	}
	parse(n) {
		function r(e) {
			let t = new DataView(e);
			if (84 + t.getUint32(80, !0) * 50 === t.byteLength) return !0;
			let n = [
				115,
				111,
				108,
				105,
				100
			];
			for (let e = 0; e < 5; e++) if (c(n, t, e)) return !1;
			return !0;
		}
		function c(e, t, n) {
			for (let r = 0, i = e.length; r < i; r++) if (e[r] !== t.getUint8(n + r)) return !1;
			return !0;
		}
		function l(e) {
			let n = new DataView(e), r = n.getUint32(80, !0), s, c, l, u = !1, d, f, p, m, h;
			for (let e = 0; e < 70; e++) n.getUint32(e, !1) == 1129270351 && n.getUint8(e + 4) == 82 && n.getUint8(e + 5) == 61 && (u = !0, d = new Float32Array(r * 3 * 3), f = n.getUint8(e + 6) / 255, p = n.getUint8(e + 7) / 255, m = n.getUint8(e + 8) / 255, h = n.getUint8(e + 9) / 255);
			let g = new i(), _ = new Float32Array(r * 3 * 3), v = new Float32Array(r * 3 * 3), y = new a();
			for (let e = 0; e < r; e++) {
				let r = 84 + e * 50, i = n.getFloat32(r, !0), a = n.getFloat32(r + 4, !0), o = n.getFloat32(r + 8, !0);
				if (u) {
					let e = n.getUint16(r + 48, !0);
					e & 32768 ? (s = f, c = p, l = m) : (s = (e & 31) / 31, c = (e >> 5 & 31) / 31, l = (e >> 10 & 31) / 31);
				}
				for (let f = 1; f <= 3; f++) {
					let p = r + f * 12, m = e * 3 * 3 + (f - 1) * 3;
					_[m] = n.getFloat32(p, !0), _[m + 1] = n.getFloat32(p + 4, !0), _[m + 2] = n.getFloat32(p + 8, !0), v[m] = i, v[m + 1] = a, v[m + 2] = o, u && (y.setRGB(s, c, l, t), d[m] = y.r, d[m + 1] = y.g, d[m + 2] = y.b);
				}
			}
			return g.setAttribute("position", new o(_, 3)), g.setAttribute("normal", new o(v, 3)), u && (g.setAttribute("color", new o(d, 3)), g.hasColors = !0, g.alpha = h), g;
		}
		function u(t) {
			let n = new i(), r = /solid([\s\S]*?)endsolid/g, a = /facet([\s\S]*?)endfacet/g, o = /solid\s(.+)/, c = 0, l = "[\\s]+([+-]?(?:\\d*)(?:\\.\\d*)?(?:[eE][+-]?\\d+)?)", u = RegExp("vertex" + l + l + l, "g"), d = RegExp("normal" + l + l + l, "g"), f = [], p = [], m = [], h = new e(), g, _ = 0, v = 0, y = 0;
			for (; (g = r.exec(t)) !== null;) {
				v = y;
				let e = g[0], t = (g = o.exec(e)) === null ? "" : g[1];
				for (m.push(t); (g = a.exec(e)) !== null;) {
					let e = 0, t = 0, n = g[0];
					for (; (g = d.exec(n)) !== null;) h.x = parseFloat(g[1]), h.y = parseFloat(g[2]), h.z = parseFloat(g[3]), t++;
					for (; (g = u.exec(n)) !== null;) f.push(parseFloat(g[1]), parseFloat(g[2]), parseFloat(g[3])), p.push(h.x, h.y, h.z), e++, y++;
					t !== 1 && console.error("THREE.STLLoader: Something isn't right with the normal of face number " + c), e !== 3 && console.error("THREE.STLLoader: Something isn't right with the vertices of face number " + c), c++;
				}
				let r = v, i = y - v;
				n.userData.groupNames = m, n.addGroup(r, i, _), _++;
			}
			return n.setAttribute("position", new s(f, 3)), n.setAttribute("normal", new s(p, 3)), n;
		}
		function d(e) {
			return typeof e == "string" ? e : new TextDecoder().decode(e);
		}
		function f(e) {
			if (typeof e == "string") {
				let t = new Uint8Array(e.length);
				for (let n = 0; n < e.length; n++) t[n] = e.charCodeAt(n) & 255;
				return t.buffer || t;
			}
			return e;
		}
		let p = f(n);
		return r(p) ? l(p) : u(d(n));
	}
};
//#endregion
export { c as STLLoader };

//# sourceMappingURL=STLLoader-D0Aftpgw.js.map