import { d as e } from "./GleamEditor-BwL_fApV.js";
import { Fragment as t, jsx as n, jsxs as r } from "react/jsx-runtime";
//#region src/model3d/parts.tsx
function i({ kind: e }) {
	return /* @__PURE__ */ n("svg", {
		width: "22",
		height: "22",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: 1.6,
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: {
			box: /* @__PURE__ */ n("path", { d: "M12 3l8 4.5v9L12 21l-8-4.5v-9L12 3zM4 7.5L12 12l8-4.5M12 12v9" }),
			sphere: /* @__PURE__ */ r(t, { children: [/* @__PURE__ */ n("circle", {
				cx: "12",
				cy: "12",
				r: "8.5"
			}), /* @__PURE__ */ n("path", { d: "M3.5 12c3 3 14 3 17 0" })] }),
			cylinder: /* @__PURE__ */ r(t, { children: [/* @__PURE__ */ n("ellipse", {
				cx: "12",
				cy: "6",
				rx: "7",
				ry: "2.6"
			}), /* @__PURE__ */ n("path", { d: "M5 6v12c0 1.4 3.1 2.6 7 2.6s7-1.2 7-2.6V6" })] }),
			cone: /* @__PURE__ */ r(t, { children: [/* @__PURE__ */ n("path", { d: "M12 3L5 18M12 3l7 15" }), /* @__PURE__ */ n("ellipse", {
				cx: "12",
				cy: "18",
				rx: "7",
				ry: "2.6"
			})] }),
			torus: /* @__PURE__ */ r(t, { children: [/* @__PURE__ */ n("ellipse", {
				cx: "12",
				cy: "12",
				rx: "9",
				ry: "5"
			}), /* @__PURE__ */ n("ellipse", {
				cx: "12",
				cy: "11.4",
				rx: "3.6",
				ry: "1.6"
			})] }),
			capsule: /* @__PURE__ */ n("rect", {
				x: "7",
				y: "3",
				width: "10",
				height: "18",
				rx: "5"
			}),
			pyramid: /* @__PURE__ */ n("path", { d: "M12 3l8 15H4L12 3zM12 3l2 15" }),
			extrude: /* @__PURE__ */ n("path", { d: "M12 3l2.6 5.6 6.2.7-4.6 4.2 1.3 6.1L12 16.5l-5.5 3.1 1.3-6.1-4.6-4.2 6.2-.7L12 3z" }),
			text: /* @__PURE__ */ n("path", { d: "M5 6V4h14v2M12 4v16M9 20h6" }),
			revolve: /* @__PURE__ */ r(t, { children: [/* @__PURE__ */ n("path", { d: "M9 3h6M9.5 3c0 3-4.5 5-4.5 10 0 4 3 7 7 7s7-3 7-7c0-5-4.5-7-4.5-10" }), /* @__PURE__ */ n("ellipse", {
				cx: "12",
				cy: "13",
				rx: "7",
				ry: "2",
				strokeDasharray: "2 2"
			})] }),
			mesh: /* @__PURE__ */ r(t, { children: [/* @__PURE__ */ n("path", { d: "M12 3.5l7 4v8l-7 4-7-4v-8l7-4z" }), /* @__PURE__ */ n("path", { d: "M5 7.5l7 4 7-4M12 11.5v8M8.5 5.5l7 4" })] }),
			group: /* @__PURE__ */ r(t, { children: [/* @__PURE__ */ n("rect", {
				x: "3",
				y: "3",
				width: "11",
				height: "11",
				rx: "2"
			}), /* @__PURE__ */ n("rect", {
				x: "10",
				y: "10",
				width: "11",
				height: "11",
				rx: "2"
			})] }),
			ad: /* @__PURE__ */ r(t, { children: [/* @__PURE__ */ n("path", { d: "M6 21h12M8 21v-5h8v5" }), /* @__PURE__ */ n("path", { d: "M12 3l1.8 3.7 4 .6-2.9 2.8.7 4-3.6-1.9-3.6 1.9.7-4-2.9-2.8 4-.6L12 3z" })] }),
			svg: /* @__PURE__ */ r(t, { children: [/* @__PURE__ */ n("path", { d: "M3 19c4-1 6-6 9-6s4 4 9 2" }), /* @__PURE__ */ n("path", { d: "M12 3l4 6-4 4-4-4 4-6zM12 9v1" })] })
		}[e]
	});
}
function a(t) {
	let { label: i, value: a, min: o, max: s, step: c, format: l, onBegin: u, onChange: d, onEnd: f } = t;
	return /* @__PURE__ */ r("label", {
		className: "gs-m3d__slider",
		children: [/* @__PURE__ */ r("span", {
			className: "gs-m3d__row",
			children: [/* @__PURE__ */ n("span", { children: i }), /* @__PURE__ */ n("output", { children: l ? l(a) : a })]
		}), /* @__PURE__ */ n("input", {
			type: "range",
			min: o,
			max: s,
			step: c,
			value: a,
			style: e(a, o, s),
			onPointerDown: u,
			onPointerUp: f,
			onLostPointerCapture: f,
			onKeyDown: u,
			onKeyUp: f,
			onChange: (e) => d(Number(e.target.value))
		})]
	});
}
function o({ label: e, value: t, step: i, min: a, onChange: o }) {
	return /* @__PURE__ */ r("div", {
		className: "gs-m3d__triple",
		children: [/* @__PURE__ */ n("span", { children: e }), [
			"X",
			"Y",
			"Z"
		].map((e, s) => /* @__PURE__ */ r("label", { children: [/* @__PURE__ */ n("i", { children: e }), /* @__PURE__ */ n("input", {
			type: "number",
			step: i,
			min: a,
			value: Math.round(t[s] * 1e3) / 1e3,
			onChange: (e) => {
				let n = Number(e.target.value);
				if (!Number.isFinite(n)) return;
				let r = [...t];
				r[s] = n, o(r);
			}
		})] }, e))]
	});
}
function s({ value: e, options: t, labels: r, onChange: i, label: a }) {
	return /* @__PURE__ */ n("div", {
		className: "gs-m3d__segments",
		role: "group",
		"aria-label": a,
		children: t.map((t) => /* @__PURE__ */ n("button", {
			type: "button",
			className: e === t ? "is-on" : "",
			"aria-pressed": e === t,
			onClick: () => i(t),
			children: r[t]
		}, t))
	});
}
//#endregion
//#region src/model3d/scene.ts
var c = [
	"a wooden shop shelf, warm soft light",
	"a pastel photo studio with soft shadows",
	"a cosy room, blurred, evening light",
	"a city street at night, neon lights, bokeh",
	"a cherry blossom park in spring, soft focus",
	"a festive gift table, fairy lights, bokeh"
], l = "text, letters, watermark, logo, people, person, figure, toy, product, frame, border", u = 1024, d = (e, t) => {
	let n = document.createElement("canvas");
	return n.width = e, n.height = t, n;
}, f = (e) => new Promise((t, n) => e.toBlob((e) => e ? t(e) : n(/* @__PURE__ */ Error("The picture could not be made.")), "image/png"));
function p(e) {
	return new Promise((t, n) => {
		let r = new FileReader();
		r.onload = () => t(String(r.result)), r.onerror = () => n(/* @__PURE__ */ Error("The picture could not be read.")), r.readAsDataURL(e);
	});
}
async function m(e, t = 1600) {
	let n = await createImageBitmap(e), r = Math.min(1, t / Math.max(n.width, n.height)), i = d(Math.round(n.width * r), Math.round(n.height * r));
	return i.getContext("2d").drawImage(n, 0, 0, i.width, i.height), n.close(), p(await new Promise((e, t) => i.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be made.")), "image/jpeg", .9)));
}
async function h(e, t, n, r) {
	let [i, a] = t >= 1 ? [u, Math.round(u / t / 8) * 8] : [Math.round(u * t / 8) * 8, u], o = d(i, a);
	return r("Painting the scene… (about a minute)"), m(await e.redraw(await f(o), {
		prompt: `${n}, product photography background, depth of field, detailed, realistic, high quality`,
		negative: l,
		strength: 1
	}));
}
var g = "gleamshelf.scene.last";
function _() {
	try {
		return localStorage.getItem(g);
	} catch {
		return null;
	}
}
function v(e) {
	try {
		e && localStorage.setItem(g, e);
	} catch {}
}
//#endregion
export { m as a, a as c, v as i, o as l, _ as n, s as o, h as r, i as s, c as t };

//# sourceMappingURL=scene-BPfcQvQO.js.map