import type { Img } from '../../pipeline/src/index.js';
/**
 * True for a HEIC/HEIF photo, as iPhones save them. Looks at the file's own first bytes (its "ftyp" box), not its name,
 * so a mislabelled file is still recognised. AVIF files are not HEIC: sharp and browsers read those on their own.
 */
export declare function isHeic(bytes: Uint8Array): boolean;
type Matrix = [number, number, number, number, number, number, number, number, number];
/**
 * How to bring a photo's colours to sRGB, from the colour box (`colr`) the file carries; null when they are sRGB already or the file does not say.
 * An iPhone shoots in Display P3, and the decoder hands over those numbers as they are. Read as sRGB they look washed out.
 */
export declare function heicColourConversion(bytes: Uint8Array): Matrix | null;
/** Applies a conversion to RGBA pixels, in place. iPhone profiles use sRGB's own tone curve, so only the primaries differ. */
export declare function convertColours(data: Uint8ClampedArray, m: Matrix): void;
/**
 * Decodes a HEIC photo to RGBA pixels in sRGB, upright (the camera's rotation is applied). The decoder is loaded the first time
 * this is called, so a page that never meets a HEIC file never downloads it.
 */
export declare function decodeHeic(bytes: Uint8Array): Promise<Img>;
export {};
