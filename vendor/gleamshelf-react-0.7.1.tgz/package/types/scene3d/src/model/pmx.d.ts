import { type MeshAsset } from './mesh.js';
/** The pictures a model asks for, when they can be read: a picture by the path its file names, or null. */
export type MmdPictures = (path: string) => Promise<{
    mime: string;
    bytes: Uint8Array;
} | null>;
/** Reads a .pmx or .pmd; throws a plain message when it is neither. */
export declare function readMmdModel(bytes: Uint8Array, pictures?: MmdPictures): Promise<{
    asset: MeshAsset;
    name: string;
    warnings: string[];
}>;
