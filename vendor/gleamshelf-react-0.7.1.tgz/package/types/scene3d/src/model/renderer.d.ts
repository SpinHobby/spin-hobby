import * as THREE from 'three';
import { type ModelDocument, type ShapeRef, type Vec3 } from './document.js';
import type { ModelEditor } from './editor.js';
import { type MeshMaterial } from './mesh.js';
import { type TraceMesh } from './meshtrace.js';
import { type DecodedPicture, type DecodePicture } from './meshcpu.js';
/**
 * Draws a 3D design in a page and lets a person work on it: the design is ray marched on a full-screen quad (glsl.ts), and on top sit an orbiting
 * camera, a gizmo to move, turn and resize the picked shape or group, and a box round it. Every change goes through the ModelEditor, so it is
 * undoable. ModelPainter draws pictures and video frames off screen with the same shader.
 */
export type GizmoMode = 'translate' | 'rotate' | 'scale';
/** What the live view does, for a performance gauge (ModelViewport.stats). */
export interface ViewStats {
    /** Frames drawn in the last second (0 once nothing has moved for a while: the view draws only when something changes). */
    fps: number;
    /** The typical time between the last frames, ms (0 when still). */
    frameMs: number;
    /** Whether it is drawing at its moving resolution now. */
    moving: boolean;
    /** The pixels drawn, and their share of the screen's (dynamic resolution). */
    width: number;
    height: number;
    share: number;
    /** What this computer manages, pixels a millisecond (learned while moving; 0 before). */
    rate: number;
    /** The shapes the shader measures (a group's start and end count too), the imported models, and what the last frame sent the GPU. */
    shapes: number;
    models: number;
    triangles: number;
    calls: number;
    /** The graphics card, as the browser names it ('' when it will not say). */
    gpu: string;
    /** What the last frames cost the page's own thread, ms (the draw calls' bookkeeping, not the graphics card's work): the median of the last 20. */
    cpuMs: number;
    /** The baked field's texels (width, height, depth), or null with no shapes. */
    field: [number, number, number] | null;
    /** The tile lists' entries for the last draw (TileLists), 0 when off. */
    tileEntries: number;
    /** What the models' pictures take on the graphics card, MB (MeshLayer.textureBytes), and the budget they are kept to. */
    textureMB: number;
    textureBudgetMB: number;
}
export interface ViewportHooks {
    /** A shape was clicked (its place in the design), or empty space (null). */
    /** A click picked a shape (null: nothing). `extend`: Shift (or Ctrl or Cmd) was held, to add it to the picked ones. */
    onPick?: (ref: ShapeRef | null, how: {
        extend: boolean;
    }) => void;
}
/** The camera's place in the scene from the design's orbit settings. */
export declare function cameraPose(cam: ModelDocument['camera']): {
    position: THREE.Vector3;
    target: THREE.Vector3;
};
/** A camera that sees exactly what the shader draws (for imported models and the depth they share): `frame` widens it the same way. */
export declare function designCamera(doc: ModelDocument, aspect: number, frame?: number): THREE.PerspectiveCamera | THREE.OrthographicCamera;
export declare class ModelViewport {
    private readonly container;
    private readonly editor;
    private readonly hooks;
    private readonly effectLayer;
    private readonly unlabel;
    readonly canvas: HTMLCanvasElement;
    private readonly renderer;
    private readonly atlas;
    private readonly uniforms;
    private readonly meshes;
    private readonly focus;
    private readonly volume;
    private readonly tiles;
    private readonly quadScene;
    private readonly quadCamera;
    private readonly overlay;
    private readonly perspective;
    private readonly ortho;
    private orbit;
    private readonly gizmo;
    private readonly proxy;
    private readonly outline;
    private selected;
    /** Several top-level shapes picked together: the gizmo moves, turns and grows them as one. */
    private several;
    /** A moment of a clip shown instead of the design while its motion plays (no gizmo meanwhile). */
    private playing;
    private doc;
    private width;
    private height;
    private frame;
    /** Set while the design's camera is being written into the controls, so the controls' change does not write it back. */
    private applying;
    private readonly resize;
    /** While the gizmo is dragged: the shapes it moves (one, a group's, or several picked) as they were, where the proxy was, and the box's size. */
    private gizmoStart;
    private down;
    private readonly unsubscribe;
    /** The editing grid's cell (scene units), 0 for none, and whether moves snap to it. */
    private grid;
    private snap;
    /**
     * Models' pictures waiting to go to the GPU, one a frame: a scene of many models (anime figures carry several 2048-pixel pictures each)
     * comes in model by model instead of the page stopping while every picture is sent in one frame.
     */
    private readonly uploads;
    private uploading;
    private disposed;
    /** Flying from the keyboard (fly): the keys held, the camera's speed (eased), its target unrounded, and the loop's frame and clock. */
    private flyPush;
    private flying;
    private readonly flyVelocity;
    private readonly flyTarget;
    private flyFrame;
    private flyAt;
    private readonly upload;
    constructor(container: HTMLElement, editor: ModelEditor, hooks?: ViewportHooks);
    private activeCamera;
    private makeOrbit;
    /** The design changed (an edit, an undo, a load): the shader, cameras, gizmo and selection box follow. */
    setDocument(doc: ModelDocument): void;
    /** Shows a moment of a clip (animate or clipFrame) instead of the design, as the motion preview plays; null shows the design again. */
    showFrame(frame: ModelDocument | null): void;
    /** The picked shape or group (its place in the design), or null. */
    select(ref: ShapeRef | null): void;
    /** Several top-level shapes picked together (two or more): one box round them all, and the gizmo moves, turns and grows them as one. */
    selectSeveral(indices: number[]): void;
    /** The shapes the gizmo works on, each with its place: one shape, a group's shapes, or every picked shape (groups' shapes for a group). */
    private items;
    setGizmo(mode: GizmoMode): void;
    /**
     * The grid on the ground, `size` scene units a cell (0 hides it), only on screen. With `snap`, a drag moves a shape or group in whole cells from
     * where it started (so one resting on the ground stays there) and turns it in 15° steps.
     */
    setGrid(size: number, snap?: boolean): void;
    private placeProxy;
    private gizmoBegin;
    private gizmoChange;
    private gizmoEnd;
    /** The design's camera into the Three.js cameras and the orbit controls. */
    private applyCamera;
    /** The orbit controls moved the camera: written back into the design (one undo step per drag). */
    private orbitChange;
    private onPointerDown;
    /** A click without a drag picks the shape under it (by marching the same field on the CPU). */
    private onPointerUp;
    /** An imported model under a point of the view: which shape, where (scene) and which way its surface faces there; null for none. */
    modelHitAt(clientX: number, clientY: number): {
        ref: ShapeRef;
        point: Vec3;
        normal: Vec3;
    } | null;
    /** The view's ray through a point (page pixels): where it starts and which way it goes, in the scene. */
    rayAt(clientX: number, clientY: number): {
        origin: Vec3;
        dir: Vec3;
    };
    private rayFor;
    /** Turning the view by dragging, on or off (a brush stroke drags on the model instead). */
    setOrbit(on: boolean): void;
    /**
     * Flying the view from the keyboard, as in a game's replay camera: `push` is where the held keys point (forward and back along the ground the
     * way the camera faces, across, and straight up or down; each -1, 0 or 1), `fast` with Shift. The camera and its target move together, so
     * the angle and distance stay; the speed is the distance a second (a tiny design and a big scene feel the same), easing in and out. One undo
     * step per flight. Null lets go of every key (the camera eases to a stop); `now` stops it at once (before an undo or another edit).
     */
    fly(push: {
        forward: number;
        across: number;
        up: number;
        fast: boolean;
    } | null, { now }?: {
        now?: boolean;
    }): void;
    private flyStep;
    /**
     * Marks over the drawing, in the scene: dots and lines in the theme's focus colour, always on top (picked points, edges and faces, a rig's
     * bones), kept by who set them (each section its own). Null clears that owner's.
     */
    setMarks(owner: string, marks: {
        points: Vec3[];
        lines: [Vec3, Vec3][];
        strong?: Vec3[];
    } | null): void;
    private readonly marks;
    /** A model's points shown as given while a brush stroke is under way (MeshLayer.preview). */
    previewModel(assetId: string, parts: {
        positions: Float32Array;
        normals: Float32Array;
        colors: Float32Array | null;
    }[]): void;
    /** A model's material shown as given while it is changed (a slider dragged); null goes back to the model's own. */
    previewMaterial(assetId: string, index: number, material: MeshMaterial | null): void;
    /** A model's picture shown from a canvas while it is drawn on; false when the model is not drawn yet. */
    previewPicture(assetId: string, index: number, image: HTMLCanvasElement): boolean;
    /**
     * The shape under a point of the view (page pixels), as drawn: the design, or the frame playing (its shapes moved and its camera); null for
     * none. Locked shapes are passed through to what is behind them. Used for picking, and for click and hover triggers while playing.
     */
    shapeAt(clientX: number, clientY: number): ShapeRef | null;
    private fit;
    /** The look and pixel size the canvas was last sized for. */
    private fitted;
    /** A scene behind the design, shown behind the see-through canvas (filling the view, as in pictures). */
    private showScene;
    /**
     * Dynamic resolution, as game engines do it: while something moves (the camera turned, a shape dragged, a clip playing: a frame drawn
     * right after the last), the view is drawn at the share of its pixels that keeps it near 60 frames a second, found from how long the
     * frames take; once it stops, one frame at full sharpness. Every pixel is ray marched, so a big window or screen costs in proportion.
     */
    private quality;
    private moving;
    private lastDraw;
    /** When a draw was last asked for, and whether asks are coming one after another (a drag sends one a mouse move, however slow the frames). */
    private lastAsk;
    private asking;
    /** The last frames' times: their middle one is judged by (a slow computer is slow every frame; a page busy for one frame is not). */
    private gaps;
    private since;
    private sharpen;
    /** When the last frames were drawn (the last second or so), for stats(). */
    private drawn;
    private gpuName;
    /** Pixels a frame drawn smoothly while moving (about what an M-series Mac ray marches at 60 frames a second); the start of the search. */
    private static readonly MOVING_PIXELS;
    /** The least of the screen's pixels the view is drawn at while moving. */
    private static readonly FLOOR;
    /** How long a still frame may take: a slow computer draws it smaller rather than stopping for longer. */
    private static readonly STILL_MS;
    private static readonly SPEED_KEY;
    /** What this computer manages, pixels a millisecond, learned from the frames while moving and kept for next time. */
    private rate;
    private static savedRate;
    /** The screen's pixels per CSS pixel, at most 1.5 (every pixel is ray marched). */
    private static full;
    /** Pixels per CSS pixel: the screen's, less while moving, and less for a still frame when this computer could not draw it in STILL_MS. */
    private pixelRatio;
    /** The quality to start moving at: from this computer's rate when known, else from the pixels it would draw. */
    private startQuality;
    private setQuality;
    private paced;
    /** Draws on the next frame (several changes in one frame draw once). */
    request(): void;
    /** The page-thread time of the last draws (see ViewStats.cpuMs). */
    private readonly cpu;
    private draw;
    /** What the view is doing now: frames, resolution, this computer's speed, what is drawn and on which graphics card. */
    stats(): ViewStats;
    dispose(): void;
}
/**
 * Draws designs off screen with the same shader: pictures (in tiles, so a big one does not stall the graphics card) and video frames. Reuse one
 * for many frames; dispose it after.
 */
export declare class ModelPainter {
    readonly canvas: HTMLCanvasElement;
    /** The finished picture when the design needs last steps (the pixel look, a scene behind): see `surfaceFor`. */
    readonly output: HTMLCanvasElement;
    private backdrop;
    private readonly renderer;
    private readonly atlas;
    private readonly uniforms;
    private readonly meshes;
    private readonly focus;
    private readonly volume;
    private readonly tiles;
    private readonly scene;
    private readonly camera;
    constructor();
    /**
     * Draws a design onto the painter's canvas at `width` x `height`. `samples` 2 gives four samples a pixel (smooth edges); `frame` widens the view
     * from the same camera. A big picture is drawn in tiles, with a pause between them so the page stays responsive.
     */
    paint(doc: ModelDocument, width: number, height: number, options?: {
        samples?: 1 | 2;
        frame?: number;
        tile?: number;
    }): Promise<HTMLCanvasElement>;
    /** The canvas `paint` draws a design into (a video's frames are read from it). */
    surfaceFor(doc: ModelDocument): HTMLCanvasElement;
    private scenePicture;
    /** The 3D drawing itself, onto the painter's own canvas. */
    private draw;
    dispose(): void;
}
/** Renders a design to a picture file, off screen, with four samples a pixel. Transparent where there is nothing, unless it has a background colour. */
export declare function renderModel(doc: ModelDocument, width: number, height: number, type?: 'image/png' | 'image/jpeg', 
/** Widen the view from the same camera by this much (the picture grows with it): a caller then trims the empty border. */
frame?: number): Promise<Blob>;
/**
 * The photo-real render of a design (TRACE_FRAGMENT in glsl.ts): passes of one light path a pixel are averaged in a float target, so the
 * picture sharpens as it goes; `run` draws the average onto `canvas` every few passes. The background is the design's colour, or a white
 * studio when it is see-through. Imported models are traced triangle by triangle (meshtrace.ts); make one with `PhotoRender.create`, which
 * reads their pictures and labels first.
 */
export declare class PhotoRender {
    readonly width: number;
    readonly height: number;
    readonly canvas: HTMLCanvasElement;
    private readonly renderer;
    private readonly atlas;
    private readonly uniforms;
    private readonly targets;
    /** The first surfaces (normal and distance), for the denoiser, and its two working pictures. */
    private readonly guide;
    private readonly cleaned;
    private readonly trace;
    private readonly show;
    private readonly guidePass;
    private readonly denoisePass;
    private readonly camera;
    private stopped;
    private readonly meshTextures;
    private readonly envTexture;
    /** Passes done so far. */
    frames: number;
    /** Whether the picture shown (and saved) is cleaned of grain by the denoiser. */
    denoise: boolean;
    /** A render of a design, with its imported models, labels and environment picture read first. `keepClear` keeps a see-through background clear in the picture. */
    static create(doc: ModelDocument, width: number, height: number, decode?: DecodePicture | undefined, keepClear?: boolean): Promise<PhotoRender>;
    constructor(doc: ModelDocument, width: number, height: number, trace?: TraceMesh | null, env?: DecodedPicture | null, keepClear?: boolean);
    /** The average so far onto the canvas: through the denoiser (passes 1, 2, 4, 8 pixels apart) when it is on. */
    private present;
    /** Renders up to `passes` passes, drawing the picture so far onto the canvas every few and saying how far it is (0-1). */
    run(passes: number, onProgress?: (done: number) => void): Promise<void>;
    /** Shows the picture again with the denoiser on or off. */
    redraw(): void;
    stop(): void;
    dispose(): void;
}
/**
 * Confetti and sparkles of a frame (effects.ts) drawn onto a picture `width` x `height`, seen from the design's camera: confetti as small
 * turning cards, sparkles as glowing four-pointed stars. Drawn over the design.
 */
export declare function drawEffects(ctx: CanvasRenderingContext2D, frame: ModelDocument, width: number, height: number): void;
