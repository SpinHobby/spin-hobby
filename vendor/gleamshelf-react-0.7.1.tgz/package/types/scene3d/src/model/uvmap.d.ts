import { type MeshAsset } from './mesh.js';
/**
 * UV unwrapping (Blender's Smart UV Project, the simple way): each part's triangles are grouped by which of the six directions they face
 * most, joined where they touch into islands, each island laid flat seen from its direction, and the islands packed side by side in the
 * square, all at one scale (so a picture's detail is even over the model). Points are split where islands meet. The model's look (its
 * pictures, colours and point colours) is then painted into one new picture per part with the new places (bakeLook), so it looks the same
 * and can be painted or exported as one texture.
 */
export interface Unwrapped {
    asset: MeshAsset;
    /** For each part, each new point's point in the model before (for baking). */
    from: Uint32Array[];
}
/** New texture places for every part, islands packed into the square with a small gap. */
export declare function unwrap(asset: MeshAsset, gap?: number): Unwrapped;
/** A picture's colour at a texture place, sRGB 0-255 (with alpha), or null where there is no picture. */
export type SampleTexture = (texture: number, u: number, v: number) => [number, number, number, number] | null;
/**
 * The model's look painted into one picture per part (`size` square, RGBA sRGB), at the unwrapped places: its picture at the old places,
 * times its material's colour and its point colours. Pixels round the islands' edges are filled from their neighbours so no seam shows.
 */
export declare function bakeLook(before: MeshAsset, unwrapped: Unwrapped, size: number, sample: SampleTexture): Uint8ClampedArray[];
/**
 * The unwrapped model wearing its baked pictures (encoded, one a part): each part gets a material of its own showing its picture, the
 * colour and point colours now in the picture. Pictures that followed the old places (normal, roughness, glow maps) are dropped.
 */
export declare function withBakedPictures(unwrapped: Unwrapped, pictures: {
    mime: string;
    bytes: Uint8Array;
}[]): MeshAsset;
