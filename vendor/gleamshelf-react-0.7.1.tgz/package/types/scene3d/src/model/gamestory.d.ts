import type { Shape3D, Vec3 } from './document.js';
import type { GameFilm, GameQuest, GameRule, GameSetup, GameShot, RoutineBlock } from './game.js';
/**
 * What makes a level a place people live in: a clock, routines (who is where and when), and quests. Routines walk by a grid over the level, so people
 * go round walls. A quest is rules underneath (questRules), so it plays anywhere rules play. Each is checked for what only shows once it runs: nobody can
 * walk there in time, two people stand on one spot, a quest points at a shape that's gone.
 */
export declare const DEFAULT_CLOCK: {
    start: number;
    minutesPerSecond: number;
};
/** How fast a character walks, in metres a second. */
export declare const ROUTINE_WALK = 1.4;
export declare const clockText: (minute: number) => string;
/** "13:30" as minutes, or null if it isn't a time. */
export declare function parseClock(text: string): number | null;
export interface RouteGrid {
    x0: number;
    z0: number;
    width: number;
    height: number;
    blocked: Uint8Array;
}
/** What blocks walking in a level: every shape standing at walking height, except those walked through, trigger areas and what's hidden and not solid. */
export declare function routeGrid(shapes: readonly Shape3D[], game: Pick<GameSetup, 'areas' | 'passable' | 'actors'>): RouteGrid;
/** The way from one place to another, as points to walk through; null when there's no way. Spots beside furniture count from the nearest free cell. */
export declare function findRoute(g: RouteGrid, from: Vec3, to: Vec3): Vec3[] | null;
export declare const routeLength: (from: Vec3, route: readonly Vec3[]) => number;
/** The block a routine has for this time of day and weekday (0 Monday). */
export declare const blockAt: (routine: readonly RoutineBlock[] | undefined, minute: number, day?: number) => RoutineBlock | undefined;
export interface StoryFinding {
    kind: 'routine' | 'quest';
    message: string;
}
/** Whatever will go wrong with a level's routines: spots that are gone or out of reach, walks too long for the time, two people on one spot. */
export declare function routineFindings(shapes: readonly Shape3D[], game: GameSetup): StoryFinding[];
export declare const questStepFlag: (quest: string, step: number) => string;
/** A quest as rules: each step needs the step before, runs once, says its lines and sets its own flag. */
export declare function questRules(q: GameQuest): GameRule[];
/** What a game runs: its own rules, then its quests'. */
export declare const playableGame: (game: GameSetup) => GameSetup;
/** What's left to do: each quest not yet finished, with its next step's hint. */
export declare function questObjectives(quests: readonly GameQuest[] | undefined, flags: {
    has: (f: string) => boolean;
}): {
    quest: string;
    hint: string;
}[];
/** Whatever's wrong with a level's quests. */
export declare function questFindings(shapes: readonly Shape3D[], game: GameSetup): StoryFinding[];
/** How long a film runs, in seconds. */
export declare const filmSeconds: (film: GameFilm) => number;
/**
 * Where the camera is `t` seconds into a film: each step glides from the shot before (eased in and out) to its own over its seconds, or is there
 * at once when it's a cut. The first step starts at its shot. Null when its shots are gone.
 */
export declare function filmCamera(film: GameFilm, shots: readonly GameShot[], t: number): {
    position: Vec3;
    target: Vec3;
} | null;
/** A level's routines, shots and quests by shape name, for a game that isn't reading the design itself. */
export declare function storyData(level: {
    id: string;
    name: string;
    design: {
        shapes: readonly Shape3D[];
        game?: GameSetup;
    };
}): {
    level: string;
    clock: {
        start: number;
        minutesPerSecond: number;
    };
    routines: {
        who: string;
        character: string;
        blocks: {
            spot: string;
            from: number;
            to: number;
            days?: number;
        }[];
    }[];
    shots: GameShot[];
    films: {
        seconds: number;
        steps: {
            id?: string | undefined;
            name?: string | undefined;
            position?: Vec3 | undefined;
            target?: Vec3 | undefined;
            shot: string;
            seconds: number;
            cut?: boolean;
        }[];
        id: string;
        name: string;
    }[];
    idle: {
        moves: string[];
        every: number;
        for: number;
        talk?: boolean;
        who: string;
        character: string;
    }[];
    daylight: {
        azimuth: number;
        elevation: number;
        direction: Vec3;
        sunColor: string;
        intensity: number;
        ambient: number;
        skyLow: string;
        skyHigh: string;
        warmth: number;
        minute: number;
    }[];
    quests: {
        steps: {
            shape: string;
            kind: import("./game.js").QuestStepKind;
            hint: string;
            lines: string[];
            ja?: string[];
            voices?: string[];
            gives?: string;
        }[];
        id: string;
        title: string;
    }[];
};
