/**
 * Ambient occlusion baked into a character's points: for each point, how much of the sky above its surface it can see, past the rest of the
 * character (0 all hidden, 1 all open). Deep inside the mouth, under the chin and the fringe, between the arm and the side, inside a sleeve:
 * a game multiplies its soft light by it, so those places darken as real ones do, whichever way the light falls. Worked out once, on the
 * character at rest, by casting rays from each point over its half of the sky against every triangle (a bounding-volume tree keeps it to a
 * second or two for a whole character).
 */
export interface OcclusionPart {
    positions: Float32Array;
    normals: Float32Array;
    indices: Uint32Array;
    /** False: it gets its own occlusion but casts none (see-through and cut-out layers: an anime face's blush lines and eye
     * highlights lie over the skin as nearly invisible quads, and would darken it in streaks; hair cards would lay a band under the fringe) */
    blocks?: boolean;
}
/**
 * Each part's points' openness, 0-255 (255 open sky), from `rays` directions over each point's half of the sky, no further than `reach` (in
 * the parts' units: what's further than that doesn't darken). Points start a hair's breadth off their surface so they don't hit themselves.
 */
export declare function bakeOcclusion(parts: readonly OcclusionPart[], reach: number, rays?: number): Uint8Array[];
