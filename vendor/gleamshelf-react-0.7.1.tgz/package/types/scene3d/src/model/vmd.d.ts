import type { Vec3 } from './document.js';
import { type Bone3D } from './rig.js';
import { type BoneTake, type CameraTake } from './take.js';
/**
 * MikuMikuDance's motion files (.vmd): a dance's bone keys, face keys and camera keys. Bones are keyed by their Japanese names on MikuMikuDance's
 * standard skeleton, legs mostly by inverse kinematics, so the motion is played once on a stand-in of that skeleton (legs reaching for their IK
 * targets, as MikuMikuDance does) and each frame kept as a take. It then goes on any figure by what each bone is (take.ts).
 */
export interface VmdBoneKey {
    frame: number;
    position: Vec3;
    /** x, y, z, w, in the design's axes. */
    rotation: [number, number, number, number];
    /** Four Bézier curves (x, y, z, turn), each x1, y1, x2, y2 in 0-1. */
    curves: number[];
}
export interface VmdFaceKey {
    frame: number;
    weight: number;
}
export interface VmdCameraKey {
    frame: number;
    distance: number;
    target: Vec3;
    /** Turns in radians, as the file has them. */
    turn: Vec3;
    curves: number[];
    fov: number;
}
export interface Vmd {
    model: string;
    bones: Map<string, VmdBoneKey[]>;
    faces: Map<string, VmdFaceKey[]>;
    camera: VmdCameraKey[];
    /** The last keyed frame (30 a second). */
    frames: number;
}
/** Reads a .vmd; throws a plain message when it is not one. */
export declare function parseVmd(file: Uint8Array): Vmd;
/** The stand-in skeleton motions are played on. */
export declare const VMD_SKELETON: Bone3D[];
/** Expressions MikuMikuDance names, as the names characters here have. */
export declare const VMD_FACES: Record<string, string>;
/** A motion played on the stand-in skeleton: every frame's turns, and the face keys. Null when it moves no bones. */
export declare function vmdToTake(vmd: Vmd, name?: string, fps?: number): BoneTake | null;
/** A motion's camera as a take of the camera, for a figure of `height` standing at `at` (MikuMikuDance's figures being about 20 tall). */
export declare function vmdCamera(vmd: Vmd, height: number, at: Vec3, fps?: number): CameraTake | null;
