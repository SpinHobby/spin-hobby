import type { Shape3D, Vec3 } from './document.js';
import { type MeshAsset } from './mesh.js';
/**
 * Brushes on an imported model (sculpting and painting): a stroke works on copies of the model's points in its own space. Draw raises the
 * surface where the brush is, Inflate puffs it out along its own facing, Smooth evens it, Grab drags it with the pointer, Paint colours its
 * points. Every brush fades out smoothly to its edge, and points that share a place (either side of a texture seam) move together.
 */
export declare const BRUSHES: readonly ["draw", "inflate", "smooth", "grab", "paint"];
export type BrushKind = (typeof BRUSHES)[number];
export declare const BRUSH_LABEL: Record<BrushKind, string>;
interface StrokePart {
    positions: Float32Array;
    normals: Float32Array;
    colors: Float32Array | null;
    indices: Uint32Array;
    /** Each point's shared place, and each place's points and neighbouring places. */
    place: Uint32Array;
    points: number[][];
    neighbours: Set<number>[];
}
export interface Stroke {
    parts: StrokePart[];
    /** Whether painting has given the model point colours (its materials' colour moved into them, the materials then white). */
    painted: boolean;
}
/** A stroke's working copies of a model's points. */
export declare function startStroke(asset: MeshAsset): Stroke;
export interface BrushTouch {
    kind: BrushKind;
    /** Where the brush is and which way the surface faces there, in the model's own space. */
    at: Vec3;
    normal: Vec3;
    /** The brush's radius in the model's own units, and how strong (0-1). */
    radius: number;
    strength: number;
    /** Paint: the colour (linear). */
    color?: Vec3;
    /** Grab: how far the pointer moved since the last touch, in the model's own space. */
    move?: Vec3;
}
/** One touch of the brush: the points within its radius changed, fading to its edge. Returns whether anything changed. */
export declare function brush(stroke: Stroke, asset: MeshAsset, touch: BrushTouch): boolean;
/** The stroke's model: the changed points (and colours), and white materials where painting moved their colour into the points. */
export declare function strokeModel(stroke: Stroke, asset: MeshAsset): MeshAsset;
/** How a model sits in the scene through its shape: a scene point or direction into the model's own space, and its stretch. */
export declare function modelSpace(shape: Pick<Shape3D, 'position' | 'rotation' | 'size'>, asset: MeshAsset): {
    point: (p: Vec3) => Vec3;
    move: (d: Vec3) => Vec3;
    normal: (n: Vec3) => Vec3;
    /** A point of the model's own space in the scene (the other way). */
    toScene: (p: Vec3) => Vec3;
    /** Scene units in the model's own (the stretch's average). */
    units: (d: number) => number;
};
export {};
