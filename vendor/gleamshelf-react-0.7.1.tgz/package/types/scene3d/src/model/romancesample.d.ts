import { type Romance } from './romance.js';
export declare function sampleRomance(): Romance;
