import type { ModelDocument } from './document.js';
import { type Sequence3D } from './strips.js';
export interface SequenceOptions {
    size?: number;
    aspect?: number;
    fps?: number;
    /** Music under the video (cut to its length, fading out at the end). */
    music?: AudioBuffer | null;
    onProgress?: (done: number) => void;
}
/** The sequence as a video file (MP4 where the browser can, WebM otherwise). */
export declare function recordSequence(doc: ModelDocument, seq: Sequence3D, options?: SequenceOptions): Promise<{
    blob: Blob;
    type: string;
    extension: string;
}>;
