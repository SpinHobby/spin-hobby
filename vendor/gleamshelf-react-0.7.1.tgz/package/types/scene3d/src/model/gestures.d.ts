import type { Vec3 } from './document.js';
import { type HandShape } from './animations.js';
import { type Rig3D } from './rig.js';
/**
 * Gestures for a standing picture (a visual novel's sprite): where each hand goes, not how each joint turns. A hand's place is
 * given beside a part of the body (the head, the chest) in shoulder widths, so the same gesture fits a small anime figure and a tall
 * realistic one; the arm reaches it with two-bone inverse kinematics (the elbow falls down and out, as an arm hangs), the fingers take a
 * hand shape, and the wrist can turn. Moves made of joint angles (animations.ts) land in the wrong place on a body with other proportions,
 * so a sprite's hand to cheek or over the heart is a gesture.
 *
 * Places are in the figure's own frame, facing +z with its left on +x: x across (+ her left), y up, z towards the viewer.
 */
export interface GestureHand {
    /** The part the hand is placed beside. */
    to: 'head' | 'chest' | 'hips';
    /** Where the wrist goes, from that part, in shoulder widths. */
    at: Vec3;
    /** The fingers (animations.ts' hand shapes). */
    shape?: HandShape;
    /** The wrist's own turn (degrees). */
    wrist?: Vec3;
    /** Which way the elbow points, as well as down: + away from the body, - in; 1 is about as far out as down. */
    elbowOut?: number;
    /** And forward (+) or back (-). */
    elbowForward?: number;
}
export interface Gesture {
    id: string;
    name: string;
    note: string;
    hands: {
        L?: GestureHand;
        R?: GestureHand;
    };
    /** The spine and head's own turns (degrees: x leans forward, y turns, z tilts), added to the pose. */
    spine?: Vec3;
    head?: Vec3;
}
export declare const GESTURES: Gesture[];
export declare const gestureById: (id: string) => Gesture | undefined;
/**
 * The rig posed in a gesture: the spine and head turned, then each hand's arm reaching its place (two-bone IK), the wrist turned and
 * the fingers shaped. Starts from `pose` (the rig's own when left out). Null when the rig is not a person with arms.
 */
export declare function gesturePose(rig: Rig3D, g: Gesture, pose?: readonly Vec3[]): Vec3[] | null;
