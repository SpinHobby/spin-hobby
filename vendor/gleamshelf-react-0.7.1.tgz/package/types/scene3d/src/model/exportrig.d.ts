import type { ModelDocument, Shape3D } from './document.js';
import { type MeshAsset } from './mesh.js';
import { type Rig3D } from './rig.js';
/**
 * A rigged model out of a design for other apps: Blender, Unity and Unreal take the GLB with its bones and animation; VRoid Hub, VRChat tools and
 * VTuber apps take the VRM. A bone rests turned as the model is, so its turn in a pose is the turn the design keeps; what the design plays (a
 * take, keys, a move) is sampled and written as glTF animation.
 */
/** A shape's model with the rig's bones and skin in it, whichever way its weights came: from its file, or worked out by distance. */
export declare function riggedAsset(model: MeshAsset, rig: Rig3D, key?: string): MeshAsset;
/** A row-major turn as a quaternion (x, y, z, w). */
export declare function turnToQuaternion(m: readonly number[]): [number, number, number, number];
/** A rigged shape as a GLB, with its bones and whatever it plays. Throws a plain message when it has no bones. */
export declare function exportRiggedGlb(doc: ModelDocument, shape: Shape3D): Uint8Array;
/** Who made a VRM and what may be done with it: a VRM carries these, and viewers show them. */
export interface VrmMeta {
    name: string;
    authors: string[];
    /** The terms for the character as a whole, as a link. */
    licenceUrl?: string;
    avatarPermission?: 'onlyAuthor' | 'onlySeparatelyLicensedPerson' | 'everyone';
    commercialUsage?: 'personalNonProfit' | 'personalProfit' | 'corporation';
    allowRedistribution?: boolean;
}
/** Which parts a figure lacks for a VRM (none: it can be one). */
export declare function vrmMissing(rig: Rig3D): string[];
/**
 * A rigged shape as a VRM 1.0: standing on the ground at about a person's height, facing +z, arms out, each of its bones named for what it is, and
 * its expressions if it has them. Throws a plain message when it is not a person. What it plays is not written (a VRM is a character, not a clip).
 */
export declare function exportVrm(doc: ModelDocument, shape: Shape3D, meta: VrmMeta): Uint8Array;
