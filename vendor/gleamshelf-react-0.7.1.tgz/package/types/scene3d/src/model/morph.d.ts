import type { ModelDocument, Shape3D } from './document.js';
import { type MeshAsset, type MeshPart } from './mesh.js';
/**
 * An imported model's morph (Shape3D.morph): another version of it with the same points (made by an edit that only moves them: smoothing,
 * sculpting), blended in by an amount that keys can change over the clip. The quick view, the photo-real render, pictures and 3D model
 * export all draw the blended model.
 */
/** Two models' points blended (`amount` of the way to `target`); the base where their parts do not match point for point. */
export declare function blendParts(base: MeshAsset, target: MeshAsset, amount: number): MeshPart[];
/** Whether two models can morph into each other: the same parts with the same number of points. */
export declare const canMorph: (a: MeshAsset, b: MeshAsset) => boolean;
/** A model's parts with its expressions added in, by how much each shows; parts they leave alone stay as they are. */
export declare function facedParts(asset: MeshAsset, face: Record<string, number>): MeshAsset['parts'];
/** A model shape's model as it is drawn: blended with its morph when it has one, then posed by its bones (the last few kept). */
export declare function shapeModel(doc: Pick<ModelDocument, 'assets'>, shape: Shape3D): MeshAsset | null;
