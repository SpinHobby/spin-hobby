import type { ModelDocument, Shape3D, ShapeRef, Vec3 } from './document.js';
import { type GameSetup } from './game.js';
/** A design's game (game.ts) running, without a screen: 3D mode's Play game draws it, the tests drive it. */
/** The shape with an id, at the top or in a group, and the group it is in. */
export declare function shapeById(doc: Pick<ModelDocument, 'shapes'>, shapeId: string): {
    shape: Shape3D;
    group?: Shape3D;
} | null;
/** A shape's id and its group's (for events: a rule about a group is about every shape in it). */
export declare function idsAt(doc: Pick<ModelDocument, 'shapes'>, ref: ShapeRef | null): string[];
/** What the screen shows of a running game. */
export interface GameView {
    /** The line being said ("Name: words" shows the name), or null. */
    line: string | null;
    choices: string[] | null;
    /** Numbers shown on the screen: their names and values. */
    numbers: [string, number][];
    /** The name of the shape the player looks at, when using it does something. */
    prompt: string | null;
    /** A title over the view, for a few seconds. */
    title: string | null;
    items: string[];
    tension: number;
    /** A camera shot is playing (a cutscene): no crosshair. */
    shot: boolean;
    /** What's left to do in each quest, and the time of day if the level has routines. */
    objectives: {
        quest: string;
        hint: string;
    }[];
    clock: string | null;
    /** The game's end (its words), or the level it goes to. */
    ended: string | null;
    level: string | null;
}
/** A sound a rule played, for the screen to play: a sound effect, or the music (none: stop the music). */
export interface GameSound {
    sound: string;
    volume: number;
    music: boolean;
    /** For a line's voice: the line it goes with. */
    line?: string;
}
/** A running game at a moment, as data (GameRun.snapshot). */
export interface GameSnapshot {
    minute: number;
    clock: string;
    player: Vec3;
    actors: {
        shape: string;
        name: string;
        at: Vec3;
        move: string;
        spot?: string;
    }[];
    flags: string[];
    items: string[];
    achieved: string[];
}
/** What goes from one level to the next. */
export interface GameCarry {
    /** Achievements earned so far (the project's ids). */
    achieved?: string[];
    flags: string[];
    variables: [string, number][];
    items: string[];
    tension: number;
}
/** A design's game, running. */
export declare class GameRun {
    private doc;
    readonly game: GameSetup;
    readonly flags: Set<string>;
    readonly variables: Map<string, number>;
    readonly items: Set<string>;
    /** The project's achievements earned, and those not yet shown. */
    readonly achieved: Set<string>;
    private newlyAchieved;
    /** Shapes hidden by rules. */
    readonly hidden: Set<string>;
    /** How far rules and characters have moved shapes from where the design has them. */
    readonly offsets: Map<string, Vec3>;
    feet: Vec3;
    yaw: number;
    pitch: number;
    time: number;
    tension: number;
    private fired;
    private queue;
    private pumping;
    private lines;
    /** Each character's life as it really moves (life.ts), and the time it was last worked out. */
    private lively;
    private lifeClock;
    private choices;
    private ended;
    private level;
    private inside;
    private looking;
    private reacting;
    private tweens;
    private shot;
    /** A film playing (a camera action's `film`): which, and when it began; it sets the shot as it goes. */
    private film;
    private title;
    private waitUntil;
    private sounds;
    private actorYaw;
    private actorSpeed;
    private wanderTo;
    private wanderSeed;
    private routes;
    private grid;
    private vy;
    private grounded;
    private walking;
    private heading;
    /** `carry`: what the player brings from the level before (flags, numbers, items, and the tension, if higher than this level's). */
    constructor(doc: ModelDocument, carry?: GameCarry);
    /** What the player takes on to the next level. */
    carry(): GameCarry;
    /** The design changed while playing (3D mode lets it be edited): the rules and shapes are read again; where the player is stays. */
    setDocument(doc: ModelDocument): void;
    start(): void;
    /** The player is busy reading, choosing or watching (no walking, looking round or using). */
    get busy(): boolean;
    get eye(): Vec3;
    get facing(): Vec3;
    /** Sounds rules played since last asked (the screen plays them). */
    /** Achievements earned since this was last asked, each once ever (for the screen to show and a store to be told of). */
    takeAchievements(): string[];
    takeSounds(): GameSound[];
    /** The design as it is now: hidden shapes and areas, moved shapes, characters turned to the player. */
    private now;
    /**
     * A character's life (life.ts) over its move, with what the game knows: how it's really moving (its hair swinging, out of breath after a
     * run), whether it's saying the line on screen ("Name: words" with its name) or talking with its hands. Then animate leaves it be.
     */
    private live;
    /** A rigged figure in the move it is doing now. */
    private gait;
    /**
     * The design to draw now: areas and hidden shapes left out, moved shapes where they are, motions and reactions played at `t` (0-1 of the
     * clip), seen through the player's eyes, or a camera shot's (an orbit camera, so the 3D view draws it as any design).
     */
    frame(t: number, fov?: number): ModelDocument;
    /** How far behind the player the camera can be, stopping short of a wall. */
    private cameraBack;
    /** The height of what is under a point, looking down from `from`; the ground at the lowest. */
    private groundUnder;
    /** Falls, lands, and comes up steps and slopes (a third of the player's eye height at a time). */
    private fall;
    /** The player jumps, from the ground. */
    jump(): boolean;
    /** The design as walls: areas, shapes walked through and hidden shapes left out. */
    private walls;
    /** Where a placed character stands now, and how wide it is. */
    private actorAt;
    /**
     * Walks for `dt` seconds, `ahead` and to the `side` (-1 to 1, from the keys): level only, and pushed back out of any wall it would walk
     * into, at three heights of the body, and out of the characters standing there.
     */
    walk(ahead: number, side: number, dt: number): void;
    /** Turns the view by the mouse (degrees). */
    turn(dyaw: number, dpitch: number): void;
    /** The shape in the middle of the view, near enough to use: its ids (the shape's and its group's), a placed character's too. */
    private target;
    /** Time passes: moves and walks, characters, reactions, waits and shots, time rules, areas, what the player looks at. */
    tick(dt: number): void;
    /** A small random number, the same every run of a level. */
    private random;
    /** Whether a character can stand somewhere: clear of walls at its height. */
    private clearAt;
    /**
     * Characters turn to the player, the ones that creep come closer while the player looks away, the ones that follow walk after them, and the ones
     * that wander walk about where they were placed.
     */
    private moveActors;
    /**
     * Straight to a minute of the day, for testing a scene at any time: the clock set, and every character on a routine standing at that time's
     * spot (a game's own walk there is skipped).
     */
    jumpTo(minute: number): void;
    /** Where everyone is and what they're doing, as plain data: for a test's log, and to compare one build with the last. */
    snapshot(): GameSnapshot;
    /** The minute of the day, by the level's clock. */
    get minute(): number;
    /** A character on its routine: to the block's spot, by a route round the walls, worked out when the block changes. */
    private walkRoutine;
    /** The player uses what they look at (E). */
    use(): void;
    /** On to the next line. */
    next(): void;
    choose(index: number): void;
    view(): GameView;
    private about;
    private allowed;
    /**
     * Runs every rule for an event (about one of `about`'s shapes, when it is a shape event; the flag, for a flag event) its needs allow, in
     * order. A flag's rules go first in line: what a choice leads to comes before the rest of the rule that asked.
     */
    private fire;
    private run;
    private setFlag;
    /** Runs actions until one waits for the player (lines to read, a choice), a wait or a shot, or the game ends. */
    private pump;
}
