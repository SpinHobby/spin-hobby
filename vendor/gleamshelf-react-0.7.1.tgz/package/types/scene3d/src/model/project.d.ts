import { type ModelAsset, type ModelDocument, type Shape3D, type Vec3 } from './document.js';
import { type Romance } from './romance.js';
/**
 * A game made in 3D mode: its levels and its characters, each a design, in one file (Unreal's project of levels and Blueprint classes, kept
 * simple). A level's game (game.ts) places characters by id and goes to other levels by id; the game opens the start level first. Sounds and
 * music the rules play are kept in the project too (data URLs). 3D mode edits one design at a time: switching level or character keeps the
 * one being left in the project.
 */
export interface GameLevel {
    id: string;
    name: string;
    design: ModelDocument;
    /** More of another level, by id: a design holds only so much (splitDesign), so a big level comes in as several. A game engine's world pack
     * reads every level into one world, so the parts pack as the whole. */
    partOf?: string;
}
export type GameCharacter = Omit<GameLevel, 'partOf'>;
export interface GameSoundFile {
    name: string;
    /** A data URL of the sound (wav, ogg, mp3). */
    data: string;
}
/**
 * Something a player can do worth a badge: kept in the project once, so the game, its Japanese, a store's sheet (Game Center, Google Play) and the
 * badges all come from the same list (npm run game -- achievements). A rule earns one with the Earn an achievement action.
 */
export interface GameAchievement {
    id: string;
    title: string;
    /** What to do to earn it, shown before and after. */
    how: string;
    titleJa?: string;
    howJa?: string;
    /** A store's points for it (Game Center's add up to 1000 at most). */
    points?: number;
    /** Says nothing until it's earned. */
    hidden?: boolean;
}
export interface GameProject {
    kind: 'gleamshelf-game';
    version: 1;
    title: string;
    /** The level the game opens with. */
    start: string;
    levels: GameLevel[];
    characters: GameCharacter[];
    sounds: Record<string, GameSoundFile>;
    /** Shown on the game's credits screen. */
    credits?: string;
    achievements?: GameAchievement[];
    /** A romance story (romance.ts): heroines, scenes, choices, routes and endings, played as a visual novel. */
    romance?: Romance;
}
export declare const MAX_LEVELS = 64;
export declare const MAX_CHARACTERS = 32;
export declare const MAX_SOUNDS = 64;
export declare const MAX_ACHIEVEMENTS = 100;
/** The longest sound kept (as data URL text): a minute or two of compressed audio. */
export declare const MAX_SOUND_CHARS = 8000000;
/** Whether some JSON is a game project (and not a single design). */
export declare const isProject: (raw: unknown) => boolean;
/**
 * A design from a file as designs that each fit what 3D mode draws at once (MAX_SHAPES rows, MAX_MESHES models, MAX_FIELDS outlines): its shapes
 * in order, cut where the next would not fit, each part with the first's light, camera and settings and only the models it uses. One design
 * when it fits (the usual case).
 */
export declare function splitDesign(raw: unknown): ModelDocument[];
/** A project made safe for a file: at least one level, a start that is one of them. */
export declare function checkProject(raw: unknown): GameProject;
/** Achievements made safe: each with an id of its own, a title and how to earn it. */
export declare function checkAchievements(raw: unknown): GameAchievement[];
/** A new project whose first level is `design`. */
export declare function newProject(design: ModelDocument, title?: string): GameProject;
/** The project as a file (.json). */
export declare const projectFile: (p: GameProject) => string;
/** A project from a .json file, or an error that says so when it is not one. */
export declare function openProjectFile(text: string): GameProject;
/** What opening a project leaves out of its levels, in a line; null when they all fit. */
export declare function projectLosses(text: string): string | null;
/** An id not yet used by any level or character, from a name. */
export declare function freeId(p: GameProject, base: string): string;
/** A model a design keeps, from the bytes of a GLB. */
export declare function modelAssetFromGlb(modelName: string, bytes: Uint8Array): ModelAsset;
/** A character that is one imported model (the character creator's): that model's shape, or null for a character built of shapes. */
export declare function characterModel(character: GameCharacter): Shape3D | null;
/**
 * A character baked into a model, for showing it in a level in 3D mode (models do not use the level's 48 shapes). As tall as the character
 * stands; `cells` along its longest side (more is finer and slower). A character that is already one model is used as it is.
 */
export declare function bakeCharacter(character: GameCharacter, cells?: number): Promise<{
    asset: ModelAsset;
    height: number;
}>;
/** A shape (an imported model) standing for a placed character, at `at` on the ground, facing +z. */
export declare function actorShape(character: GameCharacter, assetId: string, asset: ModelAsset, height: number, at: Vec3): Shape3D;
