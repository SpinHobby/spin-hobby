import type { Vec3 } from './document.js';
import { type MeshAsset, type MeshMaterial } from './mesh.js';
/**
 * Drawing on an imported model's pictures, for artists refining it: a pen, an eraser and a softener that work on the picture's own pixels
 * where the brush touches the model, so a line is as fine as the picture allows (not the model's points, as Paint in Brush). The brush is
 * a ball on the model: every pixel whose place on the surface falls inside it is drawn, so a line crosses the picture's seams unbroken and
 * keeps its width however the picture is stretched. Only the surface facing the view is drawn on, and (when asked) only the part the stroke
 * began on, so eyeliner stays off the eye. Within one stroke the brush's cover is kept, not added up, so overlapping touches do not darken.
 */
/** A picture's pixels (RGBA, sRGB, rows from the top, as glTF lays them out). */
export interface Picture {
    width: number;
    height: number;
    data: Uint8ClampedArray;
}
/**
 * What a stroke paints: the colour picture, or one of the material's other pictures (glTF's): roughness (green) and metal (blue) of the
 * metal-roughness picture, glow (the emissive picture), bumps (a height drawn here, turned into the normal picture), the clear coat (red)
 * and holes (the colour picture's see-through, as cut-outs).
 */
export declare const DRAW_CHANNELS: readonly ["color", "rough", "metal", "glow", "bump", "coat", "holes"];
export type DrawChannel = (typeof DRAW_CHANNELS)[number];
export declare const DRAW_CHANNEL_LABEL: Record<DrawChannel, string>;
/** Which of a picture's red, green, blue and see-through each channel writes. */
export declare const CHANNEL_WRITES: Record<DrawChannel, [boolean, boolean, boolean, boolean]>;
/** Bumps are drawn as heights kept beside the pictures (not in the model): the height picture for a normal picture. */
export declare const heightKey: (normalPicture: number) => number;
/** The picture a channel paints for a material (-1: it has none yet; bumps: the normal picture, whose height picture is drawn on). */
export declare function channelPicture(m: MeshMaterial, channel: DrawChannel): number;
export declare const DRAW_TOOLS: readonly ["pen", "erase", "soften"];
export type DrawTool = (typeof DRAW_TOOLS)[number];
export declare const DRAW_TOOL_LABEL: Record<DrawTool, string>;
/** The model being drawn on: its pictures' pixels (changed in place), how they were when drawing began, and its triangles in a grid. */
export interface DrawSurface {
    asset: MeshAsset;
    pictures: Map<number, Picture>;
    originals: Map<number, Uint8ClampedArray>;
    /** Each drawable triangle: its part, its three points and the picture it is drawn with. */
    tris: {
        part: number;
        a: number;
        b: number;
        c: number;
        picture: number;
    }[];
    grid: Map<number, number[]>;
    cell: number;
    min: Vec3;
    dims: [number, number, number];
    /** Pictures laid out more than once (hair strands sharing one): what is drawn on one place shows on the others. */
    repeats: Set<number>;
}
/** One stroke under way: each touched picture's pixels as the stroke found them, the brush's cover, and the pixels it changed. */
export interface DrawStroke {
    start: Map<number, Uint8ClampedArray>;
    cover: Map<number, Float32Array>;
    box: Map<number, [number, number, number, number]>;
}
/** What a finished stroke changed, to take it back: each picture's changed box of pixels as they were. */
export interface DrawUndo {
    pieces: {
        picture: number;
        x: number;
        y: number;
        w: number;
        h: number;
        pixels: Uint8ClampedArray;
    }[];
}
export interface DrawTouch {
    tool: DrawTool;
    /** The brush's middle on the model and its radius, in the model's own space. */
    at: Vec3;
    radius: number;
    /** sRGB, 0-255. */
    color: Vec3;
    /** How much one stroke covers (0-1), and how much of the radius is drawn fully before it fades (0 soft, 1 hard edged). */
    opacity: number;
    hardness: number;
    /** The way the view looks (model space): surfaces facing away are left alone. */
    facing?: Vec3;
    /** Only this part is drawn on. */
    part?: number;
    /** Which of red, green, blue and see-through are written (left out: the colour, not the see-through). */
    write?: [boolean, boolean, boolean, boolean];
    /** The pen's see-through (0-255), when it is written. */
    alpha?: number;
    /**
     * A picture stamped where the brush lands instead of a colour (the sticker): its pixels, its plane on the model (`u` across and `v` up,
     * both unit length in the model's own space) and `half` its width from the middle. Its see-through pixels leave the model alone, and its
     * cover is its see-through times `opacity` (no soft brush edge). The brush's `radius` must reach the corners: at least `half` × 1.5.
     */
    image?: {
        data: Uint8ClampedArray;
        width: number;
        height: number;
        u: Vec3;
        v: Vec3;
        half: number;
    };
}
/** The pictures drawing works on: each base colour picture of a part laid out on one (with texture coordinates). */
export declare function drawingPictures(asset: MeshAsset): number[];
/** Whether any part can be drawn on: it is laid out on a picture (it has texture coordinates). */
export declare const canDraw: (asset: MeshAsset) => boolean;
/** A picture resized (bilinear), for drawing finer than it was made. */
export declare function resizePicture(p: Picture, width: number, height: number): Picture;
/**
 * The model made ready to draw on, with its pictures' pixels (`pictures`, the decoded drawingPictures): a part laid out on no picture gets
 * one of its colour; a material's colour that tints its picture (VRoid's hair) is painted into it, so what is drawn shows as itself; and
 * pictures smaller than `detail` pixels on their long side are enlarged to it. `changed` lists the pictures whose look changed, to write
 * again (a new one has no bytes yet), and `remade` says whether the materials changed with them; `enlarged` lists the pictures only
 * enlarged (the same picture, finer: shown as they are, written only when drawn on).
 */
export declare function readyToDraw(asset: MeshAsset, pictures: Map<number, Picture>, detail: number): {
    asset: MeshAsset;
    pictures: Map<number, Picture>;
    changed: number[];
    enlarged: number[];
    remade: boolean;
};
/**
 * Starts drawing on a model (made readyToDraw, and readyChannel for a channel other than colour), its pictures' pixels given: they are kept
 * as they are now, for the eraser (`originals`, when drawing goes on in another channel, keeps the ones kept before).
 */
export declare function startDrawing(asset: MeshAsset, pictures: Map<number, Picture>, channel?: DrawChannel, originals?: Map<number, Uint8ClampedArray>): DrawSurface;
export declare const beginStroke: () => DrawStroke;
/**
 * One touch of the brush: every pixel of the pictures whose place on the model is within the brush's radius takes the pen's colour (the
 * eraser: the picture as it was when drawing began; soften: the average of the pixels round it), by the brush's cover there. Returns the
 * pictures it changed.
 */
export declare function drawTouch(s: DrawSurface, stroke: DrawStroke, touch: DrawTouch): Set<number>;
/** A finished stroke's undo: the pixels it changed, as they were before it. */
export declare function endStroke(s: DrawSurface, stroke: DrawStroke): DrawUndo;
/** Takes a stroke back. Returns the pictures it changed. */
export declare function undoStroke(s: DrawSurface, undo: DrawUndo): Set<number>;
/**
 * What is drawn at a point on the model (model space): the part there and the picture's colour (sRGB) at that place; null when no drawable
 * surface is within `reach`. For picking a colour off the model, and for the part a stroke begins on.
 */
export declare function drawnAt(s: DrawSurface, at: Vec3, reach: number): {
    part: number;
    color: Vec3;
} | null;
/**
 * AI details: what the artist drew is marked (each picture's pixels a stroke covered), and an image model on this computer redraws the
 * marked area with more detail, guided by the drawing, a description and what to avoid. The area goes to the model as a square of the
 * picture round the marks; what comes back is blended in only where they were (grown a little and softened at its edge), as one more
 * stroke that Undo takes back.
 */
/** Adds a finished stroke's covered pixels to each picture's marks (one byte a pixel, 1 marked). */
export declare function markStroke(s: DrawSurface, marks: Map<number, Uint8Array>, stroke: DrawStroke): void;
/** The square of a picture round its marks, with a margin of a quarter of their size, at least `least` pixels wide: [x, y, size]. */
export declare function markedSquare(marks: Uint8Array, width: number, height: number, least?: number): [number, number, number] | null;
/** How much of the redrawn square goes in at each of its pixels (0-255): the marks grown by `grow` pixels, their edge softened. */
export declare function blendWeights(marks: Uint8Array, width: number, square: [number, number, number], grow: number): Uint8Array;
/** A redrawn square (RGBA, `square` sized) blended into a picture by `weights` (blendWeights): returns its undo, as a stroke's. */
export declare function blendSquare(s: DrawSurface, picture: number, square: [number, number, number], pixels: Uint8ClampedArray, weights: Uint8Array): DrawUndo;
/**
 * The model made ready to paint a channel: each drawable material without that channel's picture gets one, filled so the model looks as it
 * did (the metal-roughness picture with its roughness and metal, the factors then 1; a black glow picture; no clear coat yet; a flat normal
 * picture), and bumps get a flat height picture for each normal picture (kept beside the model, not in it). `changed` lists the new
 * pictures to write; `remade` says whether the materials changed.
 */
export declare function readyChannel(asset: MeshAsset, pictures: Map<number, Picture>, channel: DrawChannel): {
    asset: MeshAsset;
    pictures: Map<number, Picture>;
    changed: number[];
    remade: boolean;
};
/**
 * A normal picture made from its drawn heights: each pixel's slope (how the height changes across it) tilts the normal it had when drawing
 * began (`base`), by `strength`. Only the box given is worked out again.
 */
export declare function bumpNormals(height: Picture, base: Uint8ClampedArray, normal: Picture, strength: number, box?: [number, number, number, number]): void;
