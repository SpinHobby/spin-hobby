/**
 * A romance story (a dating sim or visual novel), kept in a game project: heroines, the pictures they appear in, scenes of lines that end in a
 * choice, a branch or an ending, and how each choice moves a heroine's affection. Choices add affection and set flags; a branch reads them, so the
 * player's choices open one heroine's route or another. Every scene, line and picture has a rating, so the same story exports as an all-ages game
 * (a phone store, a browser demo) and as a mature one (an opt-in patch).
 *
 * RomanceRun plays it. It is the reference a game engine follows (Pocket Hearts, in C++, reads romance.json the same way), and Play in the editor
 * uses it. checkRomance makes a file safe; romanceFindings says what a writer should fix: a way to a scene that isn't there, a heroine whose route no
 * set of choices can open, an ending nobody can reach, and any heroine in mature content who isn't stated to be an adult.
 */
export declare const RATINGS: readonly ["all", "mature"];
export type Rating = (typeof RATINGS)[number];
export declare const RATING_LABEL: Record<Rating, string>;
export declare const PICTURE_KINDS: readonly ["background", "portrait", "cg"];
export type PictureKind = (typeof PICTURE_KINDS)[number];
export declare const PICTURE_KIND_LABEL: Record<PictureKind, string>;
export declare const STAGE_PLACES: readonly ["left", "centre", "right"];
export type StagePlace = (typeof STAGE_PLACES)[number];
export declare const ENDING_KINDS: readonly ["true", "good", "normal", "bad"];
export type EndingKind = (typeof ENDING_KINDS)[number];
/** Who says a line: the narrator, the player, or a heroine by id. */
export declare const NARRATOR = "";
export declare const PLAYER = "me";
/** The youngest a character in mature content may be. Every heroine states an age; mature content needs every heroine in it at this or over. */
export declare const ADULT_AGE = 18;
export interface RomanceHeroine {
    id: string;
    name: string;
    nameJa?: string;
    /** Her stated age. A mature export refuses a heroine without one, or under ADULT_AGE. */
    age?: number;
    /** Her name tag's colour, #rrggbb. */
    colour: string;
    /** A line about her for the character select and the gallery. */
    profile?: string;
    profileJa?: string;
    /** Her picture for each expression (`smile`, `shy`, ...), by picture id. `normal` is the one shown when a line names none. */
    faces: Record<string, string>;
    /** The affection that opens her route (a branch's "her route" asks for at least this, and the most of anyone). */
    routeAt: number;
    /** The project's character (3D mode) her portraits were posed from, by id. */
    character?: string;
    /**
     * A side character (a rival, a friend, a parent): speaks and has faces like a heroine, but has no route, no affection of the player's to
     * win and no endings. Left out, she is a heroine.
     */
    side?: boolean;
}
export interface RomancePicture {
    id: string;
    name: string;
    kind: PictureKind;
    /** A data URL (PNG, JPEG or WebP). */
    data: string;
    rating: Rating;
    /** Whose illustration it is, for the gallery. */
    heroine?: string;
}
export interface RomanceLine {
    /** NARRATOR, PLAYER or a heroine's id. */
    who: string;
    text: string;
    textJa?: string;
    /** The speaker's expression from this line on. */
    face?: string;
    /** An illustration shown full screen from this line on (null on a later line clears it). Seeing it unlocks it in the gallery. */
    cg?: string | null;
    /** A voice line, by the project's sound id. */
    voice?: string;
    rating?: Rating;
}
export interface StageSpot {
    heroine: string;
    at: StagePlace;
}
export type RomanceCondition = {
    kind: 'affection';
    heroine: string;
    atLeast: number;
} | {
    kind: 'flag';
    flag: string;
    is: boolean;
}
/** Her affection is at least her routeAt and more than anyone else's. */
 | {
    kind: 'route';
    heroine: string;
};
export interface RomanceChoice {
    text: string;
    textJa?: string;
    /** Added to each heroine's affection, by id. */
    affection?: Record<string, number>;
    /** Flags this choice sets. */
    set?: string[];
    /** Shown only when this holds. */
    when?: RomanceCondition;
    go: string;
}
export type RomanceNext = {
    kind: 'go';
    go: string;
} | {
    kind: 'choose';
    choices: RomanceChoice[];
}
/** The first `if` that holds wins, else `else`. */
 | {
    kind: 'branch';
    ways: {
        if: RomanceCondition;
        go: string;
    }[];
    else: string;
} | {
    kind: 'end';
    ending: string;
}
/** Back to the world: the scene is over but the story isn't (an open-world game's town or map, where the player walks to the next event). */
 | {
    kind: 'return';
};
export interface RomanceScene {
    id: string;
    title: string;
    background?: string;
    music?: string;
    /** Who stands where as the scene opens. */
    stage: StageSpot[];
    lines: RomanceLine[];
    /** A mature scene: an all-ages export plays `safe` in its place (a fade, a knock at the door), or skips straight to what follows. */
    rating?: Rating;
    safe?: RomanceLine[];
    /** An event: it can start from the world (talking to a heroine in a game's town, entering her room), not only from another scene. */
    entry?: boolean;
    next: RomanceNext;
}
export interface RomanceEnding {
    id: string;
    title: string;
    titleJa?: string;
    heroine?: string;
    kind: EndingKind;
    cg?: string;
    /** The project's achievement earned on reaching it. */
    achievement?: string;
}
export interface Romance {
    start: string;
    heroines: RomanceHeroine[];
    pictures: RomancePicture[];
    scenes: RomanceScene[];
    endings: RomanceEnding[];
    /** The line on the title and credits screens: whatever made it, the game says so. */
    madeWith?: string;
}
export declare const MAX_HEROINES = 12;
export declare const MAX_PICTURES = 400;
export declare const MAX_SCENES = 600;
export declare const MAX_SCENE_LINES = 400;
export declare const MAX_CHOICES = 6;
export declare const MAX_ENDINGS = 64;
/** The largest picture kept, as data URL text (about 6 MB of image). */
export declare const MAX_ROMANCE_PICTURE_CHARS = 8000000;
export declare const MADE_WITH = "Made with Gleamshelf: open this game in Gleamshelf and make your own.";
/** A romance from a file, made safe: ids of their own, pictures that are images, lines with words. Null when there's no scene. */
export declare function checkRomance(raw: unknown): Romance | undefined;
/**
 * The story as one rating plays it. All ages: mature pictures go, mature lines go, a mature scene plays its `safe` lines (or none) and goes on, and
 * anything that pointed at a picture that went points at nothing. Mature: the story as written.
 */
export declare function romanceForRating(r: Romance, rating: Rating): Romance;
/** Whether a story has anything an all-ages export would take out. */
export declare const hasMature: (r: Romance) => boolean;
export interface RomanceState {
    scene: string;
    line: number;
    affection: Record<string, number>;
    flags: string[];
    /** Each on-stage heroine's current expression. */
    faces: Record<string, string>;
    stage: StageSpot[];
    cg: string | null;
    ending: string | null;
    /** The scene ended back in the world (an event is over); play() starts the next one. */
    returned?: boolean;
}
/** What the screen shows now. */
export interface RomanceView {
    scene: RomanceScene;
    background?: string;
    music?: string;
    stage: {
        heroine: RomanceHeroine;
        at: StagePlace;
        picture?: string;
        speaking: boolean;
    }[];
    cg: string | null;
    line: RomanceLine | null;
    /** The speaker's name and tag colour; empty for the narrator. */
    speaker: {
        name: string;
        colour?: string;
    } | null;
    /** The choices to pick from, once the scene's lines are done. */
    choices: {
        index: number;
        text: string;
    }[] | null;
    ending: RomanceEnding | null;
}
export declare function holds(r: Romance, c: RomanceCondition, affection: Record<string, number>, flags: readonly string[]): boolean;
/** The heroine whose route the player is on now (most affection, past her routeAt), or null. */
export declare function leadingHeroine(r: Romance, affection: Record<string, number>): RomanceHeroine | null;
/**
 * Plays a story. Call view() for the screen, next() to go on a line (it does nothing while a choice waits), choose() to pick. A branch or a go
 * passes through at once, so the player only ever stops on a line, a choice or an ending. save() and RomanceRun.load are for save slots.
 */
export declare class RomanceRun {
    readonly story: Romance;
    state: RomanceState;
    /** Illustrations seen (for the gallery) and endings reached, over the run. */
    readonly seen: Set<string>;
    readonly endings: Set<string>;
    private readonly earned;
    constructor(story: Romance, from?: RomanceState);
    static load(story: Romance, saved: string): RomanceRun;
    save: () => string;
    /** Plays an event from the world (an entry scene, or any scene): affection, flags and faces carry on from before. */
    play(key: string): void;
    private scene;
    private enter;
    private showLine;
    /** What happens once a scene's lines are done: a go or branch moves on, an end ends, a choose waits. */
    private finish;
    private waitingForChoice;
    /** Go on a line. False when it can't (a choice waits, or the story has ended). */
    next(): boolean;
    /** The choices shown now (those whose `when` holds), with their places in the scene's list. */
    choices(): {
        index: number;
        choice: RomanceChoice;
    }[];
    choose(index: number): boolean;
    /** Achievements earned since last asked. */
    takeAchievements(): string[];
    view(japanese?: boolean): RomanceView;
}
export interface RomanceFinding {
    level: 'error' | 'warning';
    text: string;
    scene?: string;
}
/**
 * The most affection each heroine can have on reaching each ending, over every way through the story (each scene at most once on a way, and at
 * most `budget` steps in all, so a big story is sampled rather than walked forever). Used to say which routes no choices can open.
 */
export declare function bestAffection(r: Romance, budget?: number): Record<string, number>;
/** Every ending some way of playing reaches (sampled like bestAffection). */
export declare function reachableEndings(r: Romance, budget?: number): Set<string>;
/** What a writer should fix before the story ships, worst first. */
export declare function romanceFindings(r: Romance): RomanceFinding[];
/** Errors that stop an export of this rating: a mature export with anyone under age is refused outright. */
export declare function exportBlockers(r: Romance, rating: Rating): string[];
export interface RomancePackFile {
    path: string;
    bytes: Uint8Array;
}
/**
 * The story for a game engine at one rating: `romance.json` with every picture a file under `pictures/` (named by id) instead of a data URL, and
 * the pictures themselves. Throws the blockers when there are any. The engine needs nothing else from Gleamshelf (sounds come with the game pack).
 */
export declare function romancePack(r: Romance, rating: Rating, title: string): RomancePackFile[];
