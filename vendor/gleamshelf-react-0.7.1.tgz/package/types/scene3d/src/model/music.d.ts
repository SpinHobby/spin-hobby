/**
 * The music a clip plays to, kept with the design: a sound file as a data URL. A dance is keyed to its song, so the timeline shows its loudness and
 * where its beats fall, and a video of the clip carries it.
 */
export interface Music3D {
    name: string;
    /** A data URL of the sound (mp3, wav, ogg, m4a). */
    data: string;
    /** Seconds into the music the clip starts at. */
    from?: number;
}
/** The most a design's music may take, as base64 text. */
export declare const MAX_MUSIC_CHARS = 40000000;
export declare function checkMusic(raw: unknown): Music3D | undefined;
/** How loud the music is across its length: `buckets` numbers from 0 to 1. */
export declare function loudness(samples: Float32Array, buckets: number): Float32Array;
/**
 * Finds a song's beat: how hard the sound rises, a hundred times a second, compared with itself at every tempo from 60 to 180 beats a minute, the
 * most self-alike tempo winning, then lined up with the rises themselves. Null when it is too short or has no steady beat.
 */
export declare function findBeat(samples: Float32Array, sampleRate: number): {
    bpm: number;
    first: number;
} | null;
