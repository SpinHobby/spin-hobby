import type { ModelDocument, Vec3 } from './document.js';
/**
 * The light through a game's day, from its clock: the sun climbs from the east to its height after one and goes down rose-gold toward the
 * west, never so low that rooms fall into their walls' shadows; the sky and the light round everything warm with the afternoon. One set of
 * numbers for 3D mode's preview (a time-of-day slider shows any minute of the day as the game will) and for a game engine (Shelved's
 * Renderer::setDaylight is these numbers in Metal).
 */
export interface Daylight {
    /** Where the sun is, as a design's light has it: degrees round (0 = +z) and up. */
    azimuth: number;
    elevation: number;
    /** Toward the sun, a unit vector. */
    direction: Vec3;
    sunColor: string;
    /** For a design's key light (its 0-3), and its fill (0-1). */
    intensity: number;
    ambient: number;
    /** The sky at the horizon and overhead. */
    skyLow: string;
    skyHigh: string;
    /** 0 at noon, 1 in the late afternoon: for warmer haze and a glow round the sun. */
    warmth: number;
}
export interface DaySpan {
    /** The game's day, in minutes: 08:00 to 18:00 unless said. */
    from?: number;
    to?: number;
    /** Where the sun is at its height, degrees round as a design's light (default 52: front right). */
    noon?: number;
}
export declare function daylight(minute: number, span?: DaySpan): Daylight;
/** A design lit as at `minute`: its key light the sun, its background the sky's colour at the horizon (a picture of the sky can go over it). */
export declare function withDaylight(doc: ModelDocument, minute: number, span?: DaySpan): ModelDocument;
/**
 * The sky as a picture (RGBA, `width` × `height`, the horizon at the bottom): the colour from the horizon up, the glow toward the sun, and
 * fair-weather clouds lit on the sun's side, as Shelved's sky shader draws them. For a design's background, so the preview shows the sky.
 */
export declare function skyPixels(d: Daylight, width?: number, height?: number, drift?: number): Uint8Array;
