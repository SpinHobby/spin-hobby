import type { ModelDocument, Vec3 } from './document.js';
import { type MeshAsset } from './mesh.js';
/**
 * A cloth draped over the design (Blender's cloth, the simple way): a square of cloth held flat above the shapes is let fall, and settles
 * over them and onto the floor. Points joined by springs (along, across and two apart, so it bends but does not stretch) are stepped with
 * Verlet's method; the shapes push it out by their distance field, with grip. The settled cloth becomes an imported model (both sides
 * drawn), so it renders, exports and prints like any other. It rests on the shapes and the floor; imported models are passed through.
 */
export interface ClothOptions {
    /** The cloth's side (scene units) and where its middle starts, over the floor. */
    size: number;
    centre: [number, number];
    /** Points along a side (16-64). */
    cells?: number;
    /** How far above the design's top it starts (scene units). */
    lift?: number;
    /** How long it falls (seconds, simulated). */
    seconds?: number;
    /** Its colour (linear). */
    color?: Vec3;
}
/** The cloth after falling, as a model in scene units (a grid of points, texture places across it). */
export declare function drapeCloth(doc: Pick<ModelDocument, 'shapes'>, options: ClothOptions): MeshAsset;
