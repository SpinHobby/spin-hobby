import type { MeshAsset } from './mesh.js';
import type { AvatarLook, PictureCodec } from './avatar.js';
/**
 * The face's lines drawn by Gleamshelf: the eyes' upper lines (soft, bold, a cat's flick, droopy or a doll's), lashes, the lower lash line and
 * the lid's crease, and the brows (soft, straight, arched, thick or short). They replace the model's own drawn lines and are drawn onto the same
 * pieces (its eye line, lash and brow pieces), placed by where the eye and brow are on the face as made, so the face sliders, blinks, winks
 * and every expression move them just as they moved the lines they replace. Any creator face works: each eye's shape is read from its eye
 * white.
 */
export declare const FACE_LINE_STYLES: readonly ["soft", "bold", "cat", "droopy", "doll"];
export type FaceLineStyle = (typeof FACE_LINE_STYLES)[number];
export declare const FACE_LINE_STYLE_LABEL: Record<FaceLineStyle, string>;
export declare const FACE_BROW_STYLES: readonly ["soft", "straight", "arched", "thick", "short"];
export type FaceBrowStyle = (typeof FACE_BROW_STYLES)[number];
export declare const FACE_BROW_STYLE_LABEL: Record<FaceBrowStyle, string>;
export interface AvatarFacePaint {
    /** The eyes' lines (left out: as the model draws them). */
    lines?: FaceLineStyle;
    /** Lash length, 0-1. */
    lashes?: number;
    /** The lower lash line, 0 (none) to 1. */
    lower?: number;
    /** The double lid's crease above each eye. */
    crease?: boolean;
    /** The brows (left out: as the model draws them). */
    brows?: FaceBrowStyle;
    /** Brows thinner (-1) or bolder (1). */
    browWeight?: number;
    lineColour?: string;
    browColour?: string;
}
/** Face lines as a design keeps them, made safe; undefined when nothing is drawn anew. */
export declare function checkFacePaint(raw: unknown): AvatarFacePaint | undefined;
/**
 * The face's lines drawn anew into `textures` (assembleAvatar's character, `look` with its face at rest): each eye line, lash and brow
 * picture cleared and drawn at twice its size (at least 1024 across).
 */
export declare function paintFaceLines(asset: MeshAsset, look: AvatarLook, f: AvatarFacePaint, hairColour: string | undefined, codec: PictureCodec, textures: MeshAsset['textures']): Promise<void>;
