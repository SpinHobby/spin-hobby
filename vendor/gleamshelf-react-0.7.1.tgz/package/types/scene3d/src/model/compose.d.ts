/**
 * The compositor (Blender's, the simple way): finishing touches on a finished picture, in a set order, as a photo editor would: exposure,
 * warmth, contrast and colour, a glow round bright things (glare), colour fringes towards the edges (lens), darker corners (vignette), a
 * little sharpening and film grain. Kept with the design; used by the photo-real render, pictures and videos. Works on RGBA pixels, so it
 * runs anywhere.
 */
export interface Compose3D {
    /** Brighter or darker, in stops (-2 to 2). */
    exposure: number;
    /** Warmer (orange) or cooler (blue), -1 to 1. */
    warmth: number;
    /** -1 to 1. */
    contrast: number;
    /** 0 grey to 2 twice as colourful. */
    saturation: number;
    /** A glow round bright things (0-1). */
    glare: number;
    /** Colour fringes towards the edges (0-1). */
    fringe: number;
    /** Darker corners (0-1). */
    vignette: number;
    /** Film grain (0-1). */
    grain: number;
    /** Sharper edges (0-1). */
    sharpen: number;
}
export declare const NO_COMPOSE: Compose3D;
/** Settings made safe for a file; undefined when nothing is changed. */
export declare function checkCompose(raw: unknown): Compose3D | undefined;
/** Whether settings change nothing. */
export declare const isPlain: (c: Compose3D | undefined) => boolean;
/** The settings applied to a picture's pixels (RGBA, sRGB), in place. `seed` keeps the grain the same for the same frame. */
export declare function composePixels(px: Uint8ClampedArray, w: number, h: number, c: Compose3D, seed?: number): void;
