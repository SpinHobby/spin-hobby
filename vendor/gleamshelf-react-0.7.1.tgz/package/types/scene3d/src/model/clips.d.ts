import * as THREE from 'three';
import { type Bone3D } from './rig.js';
import { type BoneTake } from './take.js';
export interface SampledTakes {
    /** The bones the takes are for, as they rest. */
    bones: Bone3D[];
    takes: BoneTake[];
}
/**
 * Plays each of `clips` on `root` and keeps every frame. `bind` says how a bone stood when bound (a matrix from bone space to the model's), and
 * `bones` lists the bones in the order the design keeps them. `fps` is how often it samples (a long clip is sampled less, to stay within a take's size).
 */
export declare function sampleClips(root: THREE.Object3D, clips: readonly THREE.AnimationClip[], order: readonly THREE.Object3D[], bones: readonly Bone3D[], fromBind: (bone: number) => THREE.Matrix4, toModel?: THREE.Matrix4, fps?: number, mixerRoot?: THREE.Object3D): BoneTake[];
/** The bones of a file with no skinned mesh (bones and motion only: Mixamo "without skin", BVH): each as it stands now. */
export declare function bareSkeleton(root: THREE.Object3D): {
    order: THREE.Object3D[];
    bones: Bone3D[];
    inverses: THREE.Matrix4[];
} | null;
/** The takes in a file a loader read: its own model's bones when it has a skinned mesh, else the bare bones; null when it has no bones. */
export declare function takesFromThree(root: THREE.Object3D, clips: readonly THREE.AnimationClip[], mixerRoot?: THREE.Object3D): SampledTakes | null;
