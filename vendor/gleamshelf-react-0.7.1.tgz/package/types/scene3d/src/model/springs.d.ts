import type { ModelDocument, Shape3D, Vec3 } from './document.js';
import { type Bone3D } from './rig.js';
/**
 * Spring bones (VRM's way): the bones of hair, skirts, ribbons and tails that no animation turns swing on their own, lagging behind the figure,
 * pulled back towards rest and kept out of the body. Worked out once for a whole clip and kept (a drop does the same: physics.ts), so a clip always
 * plays the same, in the preview, a video and an exported file, and the second time round starts where the first ended, so it loops.
 */
export interface SpringSettings {
    /** Left out or false: they swing when the figure has such bones. */
    off?: boolean;
    /** How strongly they return to rest (x the kind's own, 0-3). */
    stiffness?: number;
    /** How much they hang (0-3). */
    gravity?: number;
    /** How quickly a swing dies away (0-1). */
    drag?: number;
}
export declare function checkSprings(raw: unknown): SpringSettings | undefined;
interface Joint {
    bone: number;
    length: number;
    stiffness: number;
    drag: number;
    gravity: number;
    radius: number;
}
/** The bones of a rig that swing, each after its parent; none is a part of the person. */
export declare function springJoints(bones: readonly Bone3D[]): Joint[];
/** The balls round a figure, in the model's own space at rest (bone, where, how big). */
export declare function bodyBalls(bones: readonly Bone3D[]): {
    bone: number;
    at: Vec3;
    radius: number;
}[];
/** What the springs did over a clip: each joint's turn at every frame. */
export interface SpringFrames {
    bones: number[];
    /** Frames after one another, three numbers a joint. */
    turns: Float32Array;
    frames: number;
}
/**
 * Runs the springs over a clip of `seconds`, twice (the second time is kept, so it loops); `pose(t)` gives the figure as its animation has it at `t`
 * (0-1) and how far it has travelled in its own units. Null when nothing swings.
 */
export declare function bakeSprings(bones: readonly Bone3D[], seconds: number, pose: (t: number) => {
    pose: readonly Vec3[];
    root: Vec3 | undefined;
    travel: Vec3;
}, settings?: SpringSettings): SpringFrames | null;
/** A pose with what the springs did at `t` (0-1) of the clip laid over it. */
export declare function sprungPose(pose: readonly Vec3[], baked: SpringFrames, t: number): Vec3[];
/** What a shape's springs do over the design's clip, worked out the first time it plays and kept until the shape changes. */
export declare function shapeSprings(doc: Pick<ModelDocument, 'clip' | 'assets'>, raw: Shape3D, shapeAt: (t: number) => Shape3D): SpringFrames | null;
/** How a VRM file describes these springs (VRMC_springBone 1.0), for the bones numbered as its nodes (a bone's node is its index + 1). */
export declare function vrmSprings(bones: readonly Bone3D[]): Record<string, unknown> | null;
export {};
