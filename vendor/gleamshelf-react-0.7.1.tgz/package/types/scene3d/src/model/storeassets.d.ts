/**
 * A game's store pictures and preview from what was captured while playing: screenshots fitted to each store's exact sizes, and a preview cut
 * from clips with cross-fades, the music under it and the voices and sounds put back where they happen (a simulator's screen recording has
 * none). Pure planning here, so it can be tested; npm run game -- store does the pixels with sharp and the video with ffmpeg.
 */
/** Landscape sizes in pixels; a portrait game turns them round. */
export declare const SCREENSHOT_SIZES: Record<string, {
    size: [number, number];
    label: string;
}>;
/** App previews: the size a store takes for each screen, and how long one may be. */
export declare const PREVIEW_SIZES: Record<string, {
    size: [number, number];
    label: string;
}>;
export declare const PREVIEW_SECONDS: {
    readonly min: 15;
    readonly max: 30;
};
export interface StoreClip {
    file: string;
    /** Where to start in it, and how long to take, in seconds. */
    from: number;
    seconds: number;
}
export interface StoreSound {
    file: string;
    /** Seconds into the preview it starts. */
    at: number;
    volume?: number;
}
export interface StoreSpec {
    /** Which sizes to make (keys of SCREENSHOT_SIZES); all of them when left out. */
    sizes?: string[];
    /** Tall rather than wide. */
    portrait?: boolean;
    /**
     * Pictures to fit: `cover` fills the size, cutting what overflows (the default); `contain` shows it all on the background colour. A
     * `caption` puts a line over the top, as store pages show them, and the picture under it, smaller, with round corners: one text, or
     * one for each language ({ "en": "...", "ja": "..." }), each language in its own folder; "{lang}" in `file` takes each language's
     * own screenshot.
     */
    screenshots?: {
        file: string;
        name?: string;
        fit?: 'cover' | 'contain';
        caption?: string | Record<string, string>;
    }[];
    /** How captions look: the band's colour (else the background), the words' colour, and a second colour for the band's lower edge. */
    caption?: {
        band?: string;
        colour?: string;
        glow?: string;
    };
    background?: string;
    preview?: {
        size?: string;
        clips: StoreClip[];
        /** The cross-fade between clips, in seconds. */
        fade?: number;
        /** A simulator records a landscape game turned on its side: `left` or `right` turns it back. */
        turn?: 'left' | 'right';
        music?: {
            file: string;
            volume?: number;
        };
        sounds?: StoreSound[];
    };
}
/**
 * A captioned store picture's layout at W × H: the band over the top for the words (their size and lines, wrapped by width, Japanese
 * by character), and where the screenshot goes under it, scaled to fit with a margin.
 */
export declare function captionLayout(text: string, W: number, H: number, shotW: number, shotH: number): {
    band: number;
    size: number;
    lines: string[];
    shot: {
        left: number;
        top: number;
        scale: number;
        width: number;
        height: number;
    };
    radius: number;
};
/** How a picture of `w` × `h` fills `W` × `H`: the part of it to take, and the size it's drawn at, centred. */
export declare function fitRect(w: number, h: number, W: number, H: number, fit?: 'cover' | 'contain'): {
    scale: number;
    width: number;
    height: number;
    left: number;
    top: number;
};
export interface PreviewPlan {
    /** ffmpeg's arguments before the filter graph: each input with its own start and length. */
    inputs: string[];
    graph: string;
    /** The arguments after it: the output's codecs and length, without the file. */
    output: string[];
    seconds: number;
    warnings: string[];
}
/** The preview as one ffmpeg run: clips scaled and cut to the store's size, cross-faded in turn, with the music and the sounds mixed in. */
export declare function previewPlan(spec: NonNullable<StoreSpec['preview']>, portrait?: boolean): PreviewPlan;
