import type { ModelDocument, Vec3 } from './document.js';
/**
 * Effects for ads: a burst of confetti, sparkles twinkling round a point, smoke rising, a flame, or a liquid pouring and splashing. Every particle's place at a moment is worked out from the
 * moment alone (seeded), so the preview, the viewer and every video show the same. They are drawn over the design (drawEffects in
 * renderer.ts), not hidden by it.
 */
export declare const EFFECT_KINDS: readonly ["confetti", "sparkles", "smoke", "flame", "pour"];
export type EffectKind = (typeof EFFECT_KINDS)[number];
export declare const MAX_EFFECTS = 4;
export interface Effect3D {
    kind: EffectKind;
    /** Where it bursts or twinkles, in the scene. */
    at: Vec3;
    /** How many particles (10-400). */
    amount: number;
    /** When it starts, as a share of the clip (0-1). */
    start: number;
    /** How far it spreads (0.2-5, scene units). */
    spread: number;
    /** Smoke's or a liquid's colour (#rrggbb); its own when not set. */
    color?: string;
}
export interface Particle {
    at: Vec3;
    /** Its size in scene units. */
    size: number;
    color: string;
    /** How far it has turned (radians), how much shows (0-1), and how it is drawn. */
    turn: number;
    alpha: number;
    look: 'card' | 'star' | 'puff' | 'flame' | 'drop';
}
/** Effects made safe for a file; undefined for none. */
export declare function checkEffects(raw: unknown): Effect3D[] | undefined;
/** Every particle at `t` (0-1 of a clip `seconds` long). */
export declare function effectParticles(effects: readonly Effect3D[] | undefined, t: number, seconds: number): Particle[];
/** The effects of a frame of a design (its moment set by animate), for drawing. */
export declare const frameParticles: (doc: Pick<ModelDocument, "effects" | "now" | "clip">) => Particle[];
