import { type ModelDocument, type Shape3D } from './document.js';
/**
 * Anime characters from a few choices: a figure built from 3D mode's own shapes (capsules, spheres, cones), so every part stays a shape the
 * person can pick, recolour, move or blend afterwards. Pairs (eyes, arms, legs, hair locks) are two shapes each, not one with a mirror: a
 * mirror and a ring of copies fold round the design's middle, so a figure dragged aside would leave its twins behind. A figure takes 33 to 43 of
 * the design's 48 slots. `characterDesign` gives it the toon look with an ink outline, the look the figures are drawn for.
 */
export declare const HAIR_STYLES: readonly ["twin-tails", "ponytail", "long", "bob", "short"];
export type HairStyle = (typeof HAIR_STYLES)[number];
export declare const OUTFITS: readonly ["sailor", "dress", "hoodie"];
export type Outfit = (typeof OUTFITS)[number];
export declare const BUILDS: readonly ["chibi", "anime", "tall"];
export type Build = (typeof BUILDS)[number];
export declare const ACCESSORIES: readonly ["none", "bow", "cat-ears"];
export type Accessory = (typeof ACCESSORIES)[number];
export declare const HAIR_LABEL: Record<HairStyle, string>;
export declare const OUTFIT_LABEL: Record<Outfit, string>;
export declare const BUILD_LABEL: Record<Build, string>;
export declare const ACCESSORY_LABEL: Record<Accessory, string>;
export interface CharacterOptions {
    name: string;
    hair: HairStyle;
    outfit: Outfit;
    build: Build;
    accessory: Accessory;
    /** `#rrggbb` each. */
    hairColor: string;
    eyeColor: string;
    skin: string;
    /** The outfit's main colour, its trim, and a small accent (ribbon, bow, hair ties). */
    primary: string;
    secondary: string;
    accent: string;
    /** Height in scene units (the ground is y = 0). */
    height: number;
}
/** Ready-made characters to start from. */
export declare const CHARACTER_PRESETS: Record<string, CharacterOptions>;
/** A character's shapes, in a group named after it, standing on the ground at x = 0, z = 0 and facing +z (the camera's front). */
export declare function characterShapes(o: CharacterOptions): Shape3D;
/** A new design of one character: the toon look with an ink outline, a soft key light, a rim light behind, framed head to toe. */
export declare function characterDesign(o: CharacterOptions): ModelDocument;
