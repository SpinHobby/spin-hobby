import type { ModelDocument, Shape3D, Vec3 } from './document.js';
import type { Bone3D, Rig3D } from './rig.js';
/**
 * Life: what makes a character read as a person rather than a doll, laid over whatever its take, keys or move do. Blinks at their own
 * irregular times (quicker when nervous, two together now and then); eyes that flit about rather than stare; a breath; the weight going from
 * foot to foot; a head never quite still; how the feeling on its face sits in its body (sad sinks, worry lifts the shoulders, a fright throws
 * the head back, laughing shakes them); a mouth that talks in syllables; and in Play game, hair and the like swinging as it starts, stops and
 * turns, and running leaving it out of breath. Pure functions of time, so a clip plays the same every time; looped to the clip in a video.
 * The same layer Shelved draws in its own engine (Renderer.mm's Motion).
 */
export interface LifeSettings {
    /** Left out or false: a rigged character has it. */
    off?: boolean;
    /** How much of it (0-2, 1 as made). */
    amount?: number;
}
export declare function checkLife(raw: unknown): LifeSettings | undefined;
/** What the moment adds: all optional. */
export interface LifeCue {
    /** Saying a line: the mouth moves in syllables and the head goes with the words. */
    talking?: boolean;
    /** Walking or running: less drift, no shifting of weight. */
    moving?: boolean;
    /** Sitting, crouching, lying: no shifting of weight. */
    seated?: boolean;
    /** Out of breath, 0-1: the breath heaves and quickens and the mouth hangs open with it. */
    winded?: number;
    /** Hair and the like swung by the body's moves, degrees forward (back of the head swinging back) and to the side (Lively.swing). */
    swing?: {
        fore: number;
        side: number;
    };
    /**
     * How the body carries its going (Lively.update): degrees forward with speed and on pulling up, degrees banked into a turn, and how fast it
     * is turning (degrees a second), which the head goes ahead of.
     */
    carry?: {
        lean: number;
        bank: number;
        turning: number;
    };
    /** The length of the clip in seconds to loop to (a video, the preview); left out, time just goes on (Play game). */
    loop?: number;
}
interface LifeBones {
    spine: number;
    chest: number;
    upperChest: number;
    neck: number;
    head: number;
    shoulders: [number, number];
    eyes: number[];
    /** what hangs loose, and how far it swings forward and to the side */
    loose: {
        bone: number;
        fore: number;
        side: number;
    }[];
}
/** The bones life turns, found once a skeleton by their names (VRoid's, Mixamo's, Blender's, MikuMikuDance's). */
export declare function lifeBones(bones: readonly Bone3D[]): LifeBones;
/** A model shape's expressions, by name: what its face can do (none for a model that can't be read). */
export declare function faceNames(doc: Pick<ModelDocument, 'assets'>, s: Shape3D): readonly string[];
/** 0-1 for whole number n and seed: the same every time. */
export declare function dice(n: number, seed: number): number;
/** A seed from a name (a shape's id): each character its own times. */
export declare function seedOf(name: string): number;
/**
 * A mouth saying something, 0-1: syllables of their own lengths and sizes, a few to a word and a little gap between words, rather than a
 * metronome.
 */
export declare function talkingMouth(seconds: number, seed?: number): number;
/** How shut the eyes are, 0-1: a blink every two to six seconds (one to three when nervous), now and then two together. */
export declare function blinkAt(seconds: number, seed: number, nervous?: boolean, loop?: number): number;
/**
 * A rigged character's pose and face with life laid over them, at `seconds`. `names` are its face's expressions (its model's morphs);
 * `face` what its take or keys already show, which life reads the feeling from and never undoes.
 */
export declare function livePose(rig: Rig3D, names: readonly string[], face: Record<string, number> | undefined, seconds: number, seed: number, settings: LifeSettings | undefined, cue?: LifeCue): {
    pose: Vec3[];
    face: Record<string, number> | undefined;
};
/**
 * Play game's side of it: how each character is really moving, from where it is frame to frame, which life's swing and breath follow.
 * Speeding up, slowing down and swerving swing what hangs loose; running leaves it out of breath for half a minute.
 */
export declare class Lively {
    private state;
    /** Where `id` is now and which way it faces (degrees), `dt` seconds since the last; returns its cue's swing, carry and winded. */
    update(id: string, at: Vec3, yaw: number, dt: number, running: boolean): Pick<LifeCue, 'swing' | 'winded' | 'carry'>;
    forget(id: string): void;
}
export {};
