import { type ModelDocument, type Shape3D, type Step, type Vec3 } from './document.js';
/**
 * A shape's rotation as a 3x3 matrix (row-major), local to world. Euler angles in x, y, z order as Three.js reads them (R = Rx · Ry · Rz), so the
 * gizmo and the field agree.
 */
export declare function rotationMatrix([ax, ay, az]: Vec3): number[];
/** A world point in a shape's own frame: moved to its centre, then turned back (the transpose of its rotation). */
export declare function toLocal(s: Pick<Shape3D, 'position' | 'rotation'>, p: Vec3): Vec3;
/** One shape's distance in its own frame. Kept line for line with `shapeDist` in glsl.ts. */
export declare function shapeDistance(s: Shape3D, p: Vec3): number;
/** A shape's form as the shader reads it: wall thickness, twist and bend (radians over its height and over its width), taper. */
export declare function formOf(s: Shape3D): [number, number, number, number];
/**
 * One shape's distance with its form, in its own frame: the point is tapered, twisted round the upright axis and bent across before the shape
 * is measured, and the distance is slowed by how much those stretch space (so ray marching never steps through it); a hollow shape then keeps
 * a shell inside its surface. Kept line for line with `formedDist` in glsl.ts.
 */
export declare function formedDistance(s: Shape3D, p: Vec3): number;
/** Smooth value noise (-1 to 1): the corners' random values blended smoothly across each cell. Kept line for line with valueNoise in glsl.ts. */
export declare function valueNoise(x: number, y: number, z: number): number;
/**
 * A revolve that sweeps less than all the way round: the solid kept to the slice from the +x side towards +z, `sweep` degrees wide (two half
 * planes through the axis, intersected under 180°, joined over it). Kept in step with `sweepCut` in glsl.ts.
 */
export declare function sweepCut(d: number, x: number, z: number, sweep: number): number;
/** A shape's twin and copies as the shader reads them (uRepA, uRepB in glsl.ts). */
export declare function copyUniforms(s: Shape3D): {
    a: [number, number, number, number];
    b: [number, number, number, number];
};
/** A shape's distance at a world point, with its twin and copies. */
export declare function copiesDistance(s: Shape3D, p: Vec3): number;
/** Where a shape and each of its twins and copies sit in the scene (for boxes round it and framing the view). Grids give their corner copies. */
export declare function copyCentres(s: Shape3D): Vec3[];
/** How soft a blend is in scene units. */
export declare const blendRadius: (s: Pick<Shape3D, "blend">) => number;
/**
 * Joins a shape (distance `di`) onto what came before (`d`): added, cut away or intersected, softly over `k`. Returns the new distance and how much
 * the shape now decides the surface (0-1), for its colour. Kept in step with `join` in glsl.ts.
 */
export declare function join(d: number, di: number, combine: Shape3D['combine'], k: number): {
    d: number;
    h: number;
};
export interface FieldSample {
    d: number;
    /** The colour there, mixed across soft joins (0-1 sRGB), and the finish's shininess and metalness. */
    color: Vec3;
    shine: number;
    metal: number;
    /** How much it glows, and how much of it is glass (mixed across soft joins too). */
    glow: number;
    glass: number;
    /** The shape that decides the surface there: its place in the design (index, or group index and index in the group), or null. */
    owner: [number] | [number, number] | null;
}
export declare const FINISH: Record<Shape3D['finish'], [number, number]>;
/** How much a finish glows and how much of it is glass (uPos.w and uHalf.w in the shader). */
export declare const FINISH_EXTRA: Record<Shape3D['finish'], [number, number]>;
/** The design at a world point: distance, colour and finish, walking its shapes in order (a group joins its own shapes first). */
export declare function sampleScene(doc: Pick<ModelDocument, 'shapes'>, p: Vec3, walk?: Step[]): FieldSample;
/** The design's distance at a world point, and which shape the surface there belongs to (its place in the design). */
export declare function sceneDistance(doc: Pick<ModelDocument, 'shapes'>, p: Vec3): {
    d: number;
    shape: [number] | [number, number] | null;
};
/** Marches a ray into the design: the first surface it meets, or null. */
export declare function march(doc: Pick<ModelDocument, 'shapes'>, origin: Vec3, dir: Vec3, maxDistance?: number): {
    t: number;
    shape: [number] | [number, number] | null;
} | null;
