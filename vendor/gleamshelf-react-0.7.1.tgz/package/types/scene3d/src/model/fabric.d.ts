import type { MeshAsset } from './mesh.js';
/**
 * Woven cloth: a character's clothes made from flat colour pictures (VRoid's are painted for toon shading) look like smooth plastic once
 * they are lit as real surfaces. A fine plain weave is pressed into each cloth picture, into its colour (threads a little lighter on top,
 * each thread a touch different, as yarn is) and into a bump picture, so the light catches the threads. The cloth is also made matte.
 */
export interface FabricCodec {
    decode: (bytes: Uint8Array, mime: string) => Promise<{
        width: number;
        height: number;
        data: Uint8Array | Uint8ClampedArray;
    }>;
    encode: (width: number, height: number, data: Uint8Array | Uint8ClampedArray) => Promise<{
        bytes: Uint8Array;
        mime: string;
    }>;
}
export interface FabricOptions {
    /** Texels from one thread to the next (2-16); 0 picks one from the picture's size. */
    thread?: number;
    /** How deep the weave is (0-1). */
    depth?: number;
    /** How many times the picture is enlarged first (1-4), so a thread is finer than the picture's own texels. */
    enlarge?: number;
}
/** The weave's height (0-1) at a texel: threads one way over threads the other, swapping every thread, each a rounded ridge. */
export declare function weaveHeight(x: number, y: number, thread: number): number;
/**
 * The asset with its cloth materials (`cloth[i]` true) woven and matte. A picture also used by a material that is not cloth is copied
 * first, so skin and hair keep theirs.
 */
export declare function wovenCloth(asset: MeshAsset, cloth: boolean[], codec: FabricCodec, options?: FabricOptions): Promise<MeshAsset>;
