import type { ModelDocument, Shape3D, Vec3 } from './document.js';
import { type MeshAsset } from './mesh.js';
/** The model smoothed `rounds` times. */
export declare function smoothMesh(asset: MeshAsset, rounds?: number): MeshAsset;
/** The model with about `share` of its triangles left (points close together merged). */
export declare function simplifyMesh(asset: MeshAsset, share?: number): MeshAsset;
/** The model turned inside out (its triangles face the other way), for one made with its faces pointing in. */
export declare function flipMesh(asset: MeshAsset): MeshAsset;
/**
 * The model cut flat at a height (`at`: a share of its height from the bottom), keeping what is above or below; the hole is closed with a
 * flat cap in the cut's colour (each part's own).
 */
export declare function cutMesh(asset: MeshAsset, at: number, keep: 'above' | 'below'): MeshAsset;
/**
 * Where a model's shape goes after its model changed, so what is left stays where it was: the same stretch (scene units per model unit), its
 * size following the model's new extent and its middle moved by how the model's middle moved (turned as the shape is).
 */
export declare function refit(shape: Shape3D, before: MeshAsset, after: MeshAsset): Pick<Shape3D, 'position' | 'size'>;
/**
 * Several imported models joined into one, as they sit in the scene: the new model's own space is the scene's moved to their middle, so its
 * shape stands at that middle, unturned, as big as they are together. Their materials and pictures are all kept.
 */
export declare function joinMeshes(doc: Pick<ModelDocument, 'assets'>, shapes: Shape3D[]): Promise<{
    asset: MeshAsset;
    position: Vec3;
    size: Vec3;
}>;
/** The model rebuilt as one even, closed surface (`cells` along its longest side). Its pictures go; it keeps its first material's colour. */
export declare function remeshMesh(asset: MeshAsset, cells?: number): Promise<MeshAsset>;
/**
 * An imported model (as placed by `modelShape`) joined with, cut by or kept where it meets a shape, through a grid of distances: the result
 * is one closed model in the scene's space, with its middle, size and an unturned shape to place it with.
 */
export declare function modelWithShape(doc: Pick<ModelDocument, 'assets'>, modelShape: Shape3D, shape: Shape3D, op: 'add' | 'subtract' | 'intersect', cells?: number): Promise<{
    asset: MeshAsset;
    position: Vec3;
    size: Vec3;
}>;
/** The model with each triangle cut into four (texture seams kept), then smoothed once: rounder and finer. */
export declare function subdivideMesh(asset: MeshAsset): MeshAsset;
