import type { Vec3 } from './document.js';
import type { MeshAsset, MeshMaterial } from './mesh.js';
/**
 * Changing an imported model's materials: each material's shader (physical, toon, flat, clay, or unlit: drawn as its colours are, with no
 * light) and its settings, with ready-made materials (metal, gold, car paint, velvet, glass, neon…) set in one click. A shader other than
 * physical stands in for the design's look on that material only (MeshMaterial.look), so a toon face can sit on a physical body.
 */
export declare const MATERIAL_SHADERS: readonly ["physical", "toon", "flat", "clay", "unlit"];
export type MaterialShader = (typeof MATERIAL_SHADERS)[number];
export declare const MATERIAL_SHADER_LABEL: Record<MaterialShader, string>;
/** A material's shader. A material following the design's look (no look of its own) is physical when the design's look is. */
export declare function shaderOf(m: MeshMaterial): MaterialShader;
/** A material with another shader. Physical keeps it physical (soft) whatever the design's look; the others stand in for it too. */
export declare function withShader(m: MeshMaterial, shader: MaterialShader): MeshMaterial;
/** Ready-made materials: each sets the shader and the settings that make it, keeping the material's pictures. */
export declare const MATERIAL_PRESETS: {
    id: string;
    label: string;
    make: (m: MeshMaterial) => MeshMaterial;
}[];
/** The material on the model nearest a point (model space): its index, or -1. */
export declare function materialAt(asset: MeshAsset, at: Vec3): number;
