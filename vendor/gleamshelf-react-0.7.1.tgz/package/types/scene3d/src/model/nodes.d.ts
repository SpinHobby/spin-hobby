import type { Vec3 } from './document.js';
import { type MeshAsset } from './mesh.js';
/**
 * Node editors (Blender's geometry and shader nodes, the simple way): boxes joined by wires, each doing one small thing, worked out from
 * the output back. Geometry nodes make places (a grid, a line, a ring, a scatter), join them and shake them up, and the output puts a copy
 * of a shape at every place, all made into one model that keeps the graph (so it can be changed and made again; up to 200 copies, far more
 * than a design's shapes). Material nodes work out a colour for
 * every point of an imported model from where it is and which way it faces (gradients, noise, checks, waves, ramps, mixes), and colour it.
 */
export type NodeKind = 'geometry' | 'material';
export type Socket = 'places' | 'value' | 'colour';
export interface ParamSpec {
    key: string;
    label: string;
    kind: 'number' | 'colour' | 'axis' | 'shape';
    min?: number;
    max?: number;
    step?: number;
    default: number | string;
}
export interface NodeSpec {
    label: string;
    inputs: {
        key: string;
        label: string;
        type: Socket;
    }[];
    output: Socket | null;
    params: ParamSpec[];
}
export declare const GEOMETRY_NODES: Record<string, NodeSpec>;
export declare const MATERIAL_NODES: Record<string, NodeSpec>;
export declare const nodeSpecs: (kind: NodeKind) => Record<string, NodeSpec>;
export interface GraphNode {
    id: string;
    type: string;
    /** Where its box is on the canvas (pixels). */
    x: number;
    y: number;
    values: Record<string, number | string>;
}
export interface GraphLink {
    /** From a node's output, to an input of another. */
    from: string;
    to: string;
    input: string;
}
export interface NodeGraph {
    kind: NodeKind;
    nodes: GraphNode[];
    links: GraphLink[];
}
export declare const MAX_NODES = 24;
export declare const MAX_COPIES = 200;
/** A node of a type with its values as they start. */
export declare function newNode(kind: NodeKind, type: string, x: number, y: number, id?: string): GraphNode;
/** A graph made safe for a file (unknown nodes and broken wires dropped, values in range); undefined for none. */
export declare function checkGraph(raw: unknown): NodeGraph | undefined;
/** Whether a wire from `from` into `to`'s input would fit (the kinds match, and no loop). */
export declare function canLink(graph: NodeGraph, from: string, to: string, input: string): boolean;
/** A place a copy goes: where, how turned (degrees) and how big (1 = as the shape is). */
export interface Place {
    at: Vec3;
    turn: Vec3;
    scale: number;
}
/** The places a geometry graph's output gets (at most MAX_COPIES), and the shape it copies; null when nothing is wired to it. */
export declare function geometryPlaces(graph: NodeGraph): {
    places: Place[];
    shape: string;
} | null;
/**
 * The copies as one model (scene units): `base` is the copied shape as a model where it stands, and every copy is it turned, sized (standing
 * on the same ground) and moved by its place, round the shape's middle `centre`.
 */
export declare function instanceCopies(base: MeshAsset, centre: Vec3, places: Place[]): MeshAsset;
/** A material graph's colour (linear) for a point: `p` its place in the model's box (0-1 each way), `n` its facing. */
export declare function materialColour(graph: NodeGraph): ((p: Vec3, n: Vec3) => Vec3) | null;
/** An imported model coloured by a material graph: every point gets its colour, the materials white so the colours show as they are. */
export declare function colourByNodes(asset: MeshAsset, graph: NodeGraph): MeshAsset;
/** A graph to start from: for geometry, a grid of the shape's copies; for a material, noise through a colour ramp. */
export declare function startingGraph(kind: NodeKind, shapeId?: string): NodeGraph;
