import { type MeshAsset } from './mesh.js';
import type { Shape3D } from './document.js';
import { type GameProject } from './project.js';
/**
 * What goes wrong in a game project and only shows once it's on a device: floors fighting at the same height, places nobody can walk to, a marker
 * inside a wall, a turn beyond what a design keeps. Each finding says where and what to do. Walls and spots are read as the game pack reads them.
 */
export interface ProjectFinding {
    kind: 'fighting' | 'unreachable' | 'in-wall' | 'duplicate-spot' | 'turn' | 'open-sky' | 'routine' | 'quest';
    level: string;
    message: string;
}
export interface ProjectCheckOptions {
    /** The spot walking starts from; left out, the first spot. */
    start?: string;
    /** Spots the game moves people to itself, so walking there isn't expected. */
    placed?: string[];
    /** Walking grid, in metres. */
    cell?: number;
}
export interface WalkSpot {
    name: string;
    level: string;
    id: string;
    x: number;
    z: number;
    reached: boolean;
}
/** Where people can walk, seen from above: for the map in the Game tab, and the checks below. */
export interface WalkGrid {
    x0: number;
    z0: number;
    cell: number;
    width: number;
    height: number;
    /** A cell: 0 free but out of reach, 1 blocked, 2 reached from the start. */
    cells: Uint8Array;
    spots: WalkSpot[];
    start: string | null;
}
export declare function walkGrid(project: Pick<GameProject, 'levels'>, options?: ProjectCheckOptions): WalkGrid | null;
export declare function lintGameProject(project: Pick<GameProject, 'levels'>, options?: ProjectCheckOptions): ProjectFinding[];
/** What opening a project's file would turn differently from what's written: a design keeps turns within a full turn each way. */
export declare function turnFindings(raw: {
    levels?: {
        name?: string;
        design?: {
            shapes?: {
                name?: string;
                rotation?: number[];
            }[];
        };
    }[];
}): ProjectFinding[];
export interface CreditEntry {
    name: string;
    author: string;
    licence: string;
    source?: string;
}
/** What a project and cast use, credited: one line per thing, with the licences to pass on. Anything not from the library is listed as the project's own. */
export declare function projectCredits(used: string[], library: {
    id: string;
    name: string;
    author: string;
    licence: string;
    source?: string;
}[]): {
    credits: CreditEntry[];
    own: string[];
};
export type ShapeRole = 'wall' | 'solid' | 'spot' | 'scenery';
export declare const SHAPE_ROLE_LABEL: Record<ShapeRole, string>;
export declare function shapeRole(name: string): ShapeRole;
/** The shape's name without what marks its role. */
export declare const shapeBaseName: (name: string) => string;
/** What to change on a shape to give it a role. A spot is hidden, because nobody should see a marker. */
export declare function shapeWithRole(s: Pick<Shape3D, 'name' | 'hidden'>, role: ShapeRole): {
    name: string;
    hidden: boolean;
};
export interface GameTarget {
    label: string;
    /** Everything in a level drawn at once. */
    levelTriangles: number;
    characterTriangles: number;
    bones: number;
    /** All the project's models and pictures together. */
    megabytes: number;
}
export declare const GAME_TARGETS: {
    readonly phone: {
        readonly label: "Phone";
        readonly levelTriangles: 100000;
        readonly characterTriangles: 50000;
        readonly bones: 256;
        readonly megabytes: 200;
    };
    readonly computer: {
        readonly label: "Computer";
        readonly levelTriangles: 2000000;
        readonly characterTriangles: 200000;
        readonly bones: 1024;
        readonly megabytes: 4000;
    };
};
export type GameTargetId = keyof typeof GAME_TARGETS;
export interface CostLine {
    name: string;
    kind: 'level' | 'character';
    id: string;
    triangles: number;
    limit: number;
    bones?: number;
    boneLimit?: number;
}
export interface ProjectCost {
    lines: CostLine[];
    megabytes: number;
    megabyteLimit: number;
    over: string[];
}
/** The project's weight, line by line. Bones come from each character's model file, which it has to read. */
export declare function projectCost(project: Pick<GameProject, 'levels' | 'characters'>, target: GameTargetId): ProjectCost;
/**
 * At most `max` bones: the lightest bones at the ends of chains go first, and their skin follows their parent. A person's own bones (hips, arms and
 * so on) stay, so moves still fit. A long hair chain gets shorter, and swings a little less finely.
 */
export declare function reduceBones(asset: MeshAsset, max: number): MeshAsset;
/** A project made to fit: each level's unrigged models lightened by the same share. Characters keep their looks; the pack trims their bones. */
export declare function fitProject<P extends Pick<GameProject, 'levels' | 'characters'>>(project: P, target: GameTargetId): {
    project: P;
    lightened: number;
};
export interface SayLine {
    speaker: string;
    text: string;
    line: string;
    voice?: string;
}
/** Every Say line in the project, once each, with whether it has a voice yet. */
export declare function sayLines(project: Pick<GameProject, 'levels'>): SayLine[];
/** The project with its lines given voices: a Say of several lines becomes one Say each, so each plays its own. */
export declare function withLineVoices<P extends Pick<GameProject, 'levels'>>(project: P, voices: Record<string, string>): P;
/** How alike two same-sized pictures are, 0 (nothing alike) to 1 (the same), by colour where either has something drawn. */
export declare function pictureLikeness(a: {
    width: number;
    height: number;
    data: ArrayLike<number>;
}, b: {
    width: number;
    height: number;
    data: ArrayLike<number>;
}): number;
