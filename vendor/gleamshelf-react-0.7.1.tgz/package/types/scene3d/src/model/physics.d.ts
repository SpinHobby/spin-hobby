import type { ModelDocument } from './document.js';
import { type Key } from './keys.js';
/**
 * Dropping and stacking: the picked shapes fall from where they are, under gravity, onto the floor and the design's other shapes (which stay
 * put), bouncing and sliding as set. The fall is worked out once (cannon-es) and kept as keys, so it plays, makes videos and is shared like
 * any other animation. A ball falls as a ball; every other shape as its box.
 */
export interface DropOptions {
    /** How long the fall is worked out for, in seconds (the clip's length). */
    seconds: number;
    /** How bouncy (0-0.9) and how much things grip (0-1). */
    bounce: number;
    grip: number;
}
/**
 * The fall of the shapes at `drop` (top-level indices), as keys for each: where each is and how it is turned through the clip (steady
 * between keys). The other visible shapes and the floor (y = 0) are what they land on.
 */
export declare function simulateDrop(doc: Pick<ModelDocument, 'shapes'>, drop: number[], options: DropOptions): Map<number, Key[]>;
