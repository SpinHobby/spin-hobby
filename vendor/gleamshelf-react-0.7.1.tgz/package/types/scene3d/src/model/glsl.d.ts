/**
 * The design drawn by ray marching its distance field on a full-screen quad. The shapes come in as uniform arrays (see uniforms in renderer.ts), so
 * changing a shape is a uniform update, never a recompile. `shapeDist` and `map` are kept line for line with sdf.ts.
 */
export declare const MODEL_VERTEX = "\nout vec2 vUv;\nvoid main() {\n  vUv = uv;\n  gl_Position = vec4(position.xy, 0.0, 1.0);\n}\n";
/** The shapes' pass: the field ray marched on a full-screen quad, writing colour and depth. */
export declare const MODEL_FRAGMENT: string;
/** The field baked slice by slice into the 3D picture (DistanceVolume): the whole picture is one slice at uVolSlice of the box's depth. */
export declare const VOLUME_FRAGMENT: string;
/** Imported models: their triangles in world space, for the same shading as the shapes. */
export declare const MESH_VERTEX = "\nin vec3 aColor;\nuniform mat3 uNormalWorld;\nout vec3 vWorld;\nout vec3 vNormal;\nout vec2 vMeshUv;\nout vec3 vColor;\nvoid main() {\n  vec4 w = modelMatrix * vec4(position, 1.0);\n  vWorld = w.xyz;\n  vNormal = uNormalWorld * normal;\n  vMeshUv = uv;\n  vColor = aColor;\n  gl_Position = projectionMatrix * viewMatrix * w;\n}\n";
/**
 * An imported model's surface, its material's own look (soft, toon, flat, clay) able to stand in for the design's: the shading shared with
 * the shapes reads the look and toon steps through gLook and gBands, set from the material's (uMatLook -1 and uMatBands 0: the design's).
 */
export declare const MESH_FRAGMENT: string;
/** The toon outline round an imported model: its back faces pushed out a few pixels on screen, in the outline colour. */
export declare const HULL_VERTEX = "\nin vec3 aHull;\nuniform mat3 uNormalWorld;\nuniform float uOutline;\nuniform vec2 uRes;\nvoid main() {\n  vec4 clip = projectionMatrix * viewMatrix * modelMatrix * vec4(position, 1.0);\n  vec4 nclip = projectionMatrix * viewMatrix * vec4(normalize(uNormalWorld * aHull), 0.0);\n  vec2 dir = nclip.xy;\n  float l = length(dir);\n  dir = l > 1e-6 ? dir / l : vec2(0.0);\n  clip.xy += dir * (uOutline * uRes.y / 1000.0) * 2.0 / uRes * clip.w;\n  gl_Position = clip;\n}\n";
export declare const HULL_FRAGMENT = "\nprecision highp float;\nuniform vec3 uOutlineCol;\nout vec4 fragColor;\nvoid main() {\n  fragColor = vec4(pow(uOutlineCol, vec3(1.0 / 2.2)), 1.0);\n}\n";
/** Depth of field over a drawn picture and its depth: the steps of blurByDepth in focus.ts, kept in step with it. */
export declare const FOCUS_FRAGMENT: string;
/**
 * The photo-real render (PhotoRender in renderer.ts): one random light path a pixel each pass, added into a running average. Glass refracts and
 * reflects by Fresnel, metal and glossy finishes reflect (rougher for lower shininess), glowing surfaces give light, light bounces between
 * surfaces, and each light's direct light comes with the quick drawing's soft shadows. The floor is a studio's: the background's colour,
 * darkened where shadows and nearby surfaces fall. Writes linear colour; TRACE_SHOW turns the average into sRGB.
 */
export declare const TRACE_FRAGMENT: string;
/** The photo-real render's first surfaces, for its denoiser: each pixel's normal (xyz) and how far it is (w), seen without a lens. */
export declare const TRACE_GUIDE: string;
/**
 * The photo-real render's denoiser: an edge-aware blur in passes of growing reach (a-trous), each neighbour weighted by how alike its
 * surface's facing, distance and brightness are, so edges and shading stay and the grain goes.
 */
export declare const TRACE_DENOISE = "\nprecision highp float;\nin vec2 vUv;\nuniform sampler2D uColor;\nuniform sampler2D uGuide;\nuniform float uStep;\nout vec4 fragColor;\nvoid main() {\n  vec2 px = 1.0 / vec2(textureSize(uColor, 0));\n  vec4 g0 = texture(uGuide, vUv);\n  vec4 c0 = texture(uColor, vUv);\n  float l0 = dot(c0.rgb, vec3(0.2126, 0.7152, 0.0722));\n  float k[3] = float[3](0.375, 0.25, 0.0625);\n  vec4 sum = vec4(0.0);\n  float wsum = 0.0;\n  for (int y = -2; y <= 2; y++)\n    for (int x = -2; x <= 2; x++) {\n      vec2 uv = vUv + vec2(float(x), float(y)) * uStep * px;\n      vec4 c = texture(uColor, uv);\n      vec4 g = texture(uGuide, uv);\n      float w = k[abs(x)] * k[abs(y)];\n      w *= exp(-max(0.0, 1.0 - dot(g.xyz, g0.xyz)) * 32.0);\n      w *= exp(-abs(g.w - g0.w) / (0.02 * g0.w + 1e-3));\n      float l = dot(c.rgb, vec3(0.2126, 0.7152, 0.0722));\n      w *= exp(-abs(l - l0) / (0.35 * max(l0, l) + 0.05));\n      sum += c * w;\n      wsum += w;\n    }\n  // the clear parts' alpha is smoothed with the same weights, so the shadow's grain goes the same way the colours' does\n  fragColor = sum / max(wsum, 1e-6);\n}\n";
/**
 * The photo-real render's average shown: to sRGB, with a soft roll-off of what is brighter than white. The average's colour is
 * weighed down by any clear passes (alpha), so it is divided back out first; the canvas keeps the alpha (it is made with
 * premultipliedAlpha off), and a clear background saves as real transparency.
 */
export declare const TRACE_SHOW = "\nprecision highp float;\nin vec2 vUv;\nuniform sampler2D uAccum;\nout vec4 fragColor;\nvoid main() {\n  vec4 a = texture(uAccum, vUv);\n  vec3 c = a.a > 0.001 ? a.rgb / a.a : vec3(0.0);\n  c = c / (1.0 + max(c - 1.0, 0.0) * 0.5);\n  fragColor = vec4(pow(max(c, 0.0), vec3(1.0 / 2.2)), a.a);\n}\n";
