import type { Vec3 } from './document.js';
import { type MeshAsset, type MeshPart } from './mesh.js';
/**
 * Editing an imported model point by point (Blender's edit mode): pick points, edges or faces on it, then move or grow them, push faces out
 * (extrude) or in from their edges (inset), delete, merge points into one, fill a gap with a face, or cut a loop across the model at an edge.
 * Points at one place (either side of a texture seam) count as one, so a seam never tears. A face is a flat patch of triangles, as a
 * modelling program's faces are; edits work on copies, and give a new model.
 */
export declare const ELEMENT_MODES: readonly ["vertex", "edge", "face"];
export type ElementMode = (typeof ELEMENT_MODES)[number];
export declare const ELEMENT_LABEL: Record<ElementMode, string>;
/** What is picked: in one part of the model, its places (welded points) and, for faces, its triangles. */
export interface ElementSelection {
    part: number;
    mode: ElementMode;
    places: number[];
    triangles: number[];
}
export interface Welded {
    /** Each point's place, and each place's points. */
    place: Uint32Array;
    points: number[][];
}
/** A part's points grouped by where they are. */
export declare function welded(positions: Float32Array): Welded;
/** The flat patch of triangles round one (neighbours whose facing differs by under 2 degrees). */
export declare function flatPatch(part: MeshPart, start: number): number[];
/** What is under a point on the model (its own space): the nearest point, edge or flat face. */
export declare function pickElement(asset: MeshAsset, at: Vec3, mode: ElementMode): ElementSelection | null;
/** Two picks together (a new pick in another part, or of another kind, starts again); picking a picked point again lets it go. */
export declare function addToSelection(sel: ElementSelection | null, pick: ElementSelection): ElementSelection;
/** The picked edges (pairs of places): for edges, consecutive picks; for faces, their triangles' edges. */
export declare function selectionEdges(asset: MeshAsset, sel: ElementSelection): [number, number][];
/** Where a place is (its first point), in the model's own space. */
export declare const placeAt: (asset: MeshAsset, part: number, place: number) => Vec3;
/** The middle of what is picked. */
export declare function selectionCentre(asset: MeshAsset, sel: ElementSelection): Vec3;
/** The picked points moved by `delta` (the model's own space). */
export declare const moveElements: (asset: MeshAsset, sel: ElementSelection, delta: Vec3) => MeshAsset;
/** The picked points grown (or shrunk, under 1) round their middle. */
export declare function scaleElements(asset: MeshAsset, sel: ElementSelection, factor: number): MeshAsset;
/** The picked points turned round their middle, `degrees` about an axis (0 x, 1 y, 2 z). */
export declare function turnElements(asset: MeshAsset, sel: ElementSelection, axis: 0 | 1 | 2, degrees: number): MeshAsset;
/** The picked faces deleted; for points, every triangle touching them; for edges, the triangles along them. */
export declare function deleteElements(asset: MeshAsset, sel: ElementSelection): MeshAsset;
/** The picked points made one, at their middle (triangles that close up are dropped). */
export declare function mergeElements(asset: MeshAsset, sel: ElementSelection): MeshAsset;
/** A face across 3 or 4 picked points (facing out of the model), as a modelling program's Fill. */
export declare function fillElements(asset: MeshAsset, sel: ElementSelection): MeshAsset;
/**
 * The picked faces pushed out along their facing by `distance` (the model's own units), with walls joining them to the rest (Extrude), and,
 * with `inset` (0-1), shrunk towards their middle first, so a rim is left round them (Inset, when the distance is 0).
 */
export declare function extrudeFaces(asset: MeshAsset, sel: ElementSelection, distance: number, inset?: number): MeshAsset;
/**
 * The model cut through by a flat plane, every triangle it crosses split, so a new ring of edges runs round the model there and nothing is
 * taken away (a loop cut). The cut's points take the values between their ends (texture places, colours).
 */
export declare function cutAcross(asset: MeshAsset, point: Vec3, normal: Vec3): MeshAsset;
/** A loop cut at the middle of a picked edge, across the edge. */
export declare function loopCut(asset: MeshAsset, sel: ElementSelection): MeshAsset;
