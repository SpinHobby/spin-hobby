import type { Vec3 } from './document.js';
import { type AvatarEyes, type AvatarMakeup } from './avatardetail.js';
import { type MadeHairStyle } from './animehair.js';
import { type AvatarFacePaint } from './facepaint.js';
import { type MeshAsset, type MeshMaterial, type MeshPart, type SkeletonBone } from './mesh.js';
/**
 * The character creator's characters: anime figures put together from the parts of the library's VRoid characters (pixiv's CC0 samples).
 * Every character comes as three models, its face (with its expressions), its body (skin and outfit) and its hair; any face and any hair
 * go on any body, set on its head at its size, and the face can take its eyes, lashes, brows, mouth and makeup each from another face. An
 * expression moves the face's points (VRoid's own: joy, fun, angry, sorrow…); the shape sliders size the head and eyes, lengthen the legs
 * and swell or slim the body round its joints (bust, waist, hips), and styles set them all at once (chibi to glamorous). What comes out is
 * one model, with each material's role (skin, hair, iris, top, bottom, shoes) so the creator can recolour its pictures.
 *
 * Other styles (low-poly, realistic) come as kits: characters on one skeleton cut into the same pieces, any piece going with any other of
 * the same build (assembleKit).
 *
 * Made by apps/web/scripts/characters.ts into the library's characters/ folder (index.json, a folder of models for each character, the
 * expressions' moves and the legs' weights, and thumbnails).
 */
export type AvatarRole = 'skin' | 'hair' | 'iris' | 'top' | 'bottom' | 'shoes' | 'cloth' | 'face';
/**
 * What each of a face's materials draws (from VRoid's material names): the skin, the eyes' iris, highlight, white and extra, the lines round
 * the eyes, the lashes, the brows, the mouth.
 */
export type AvatarFaceKind = 'skin' | 'iris' | 'highlight' | 'white' | 'extra' | 'eyeline' | 'eyelash' | 'brow' | 'mouth';
/** The face's features the creator takes from another character, each on its own. */
export declare const AVATAR_FEATURES: readonly ["eyes", "lashes", "brows", "mouth", "makeup"];
export type AvatarFeature = (typeof AVATAR_FEATURES)[number];
export declare const AVATAR_FEATURE_LABEL: Record<AvatarFeature, string>;
/** The roles the creator recolours, in the order it shows them. */
export declare const AVATAR_COLOURS: readonly ["hair", "iris", "skin", "top", "bottom", "shoes"];
export type AvatarColour = (typeof AVATAR_COLOURS)[number];
export declare const AVATAR_COLOUR_LABEL: Record<AvatarColour, string>;
export interface AvatarPart {
    /** Under the characters folder. */
    file: string;
    /** Each material's role, in the model's material order. */
    roles: AvatarRole[];
}
export interface AvatarModel {
    id: string;
    name: string;
    author: string;
    source: string;
    licence: string;
    sex: 'female' | 'male';
    /** Pictures for the creator's choices: its face from the front, its hair from the side, its whole body, its eyes and its mouth close. */
    thumbs: {
        face: string;
        hair: string;
        body: string;
        eyes?: string;
        mouth?: string;
    };
    /** Joints in the model's space (metres, standing on y = 0, facing +z): the head's base, the chest, the waist, the hips, the bust. */
    joints: {
        head: Vec3;
        chest: Vec3;
        waist: Vec3;
        hips: Vec3;
        bust?: [Vec3, Vec3];
    };
    /** How tall its head is, chin to crown (metres). */
    headSize: number;
    height: number;
    face: AvatarPart & {
        /** The expressions' moves file. */
        moves: string;
        /** Each expression's moves, by the face's part: [byte offset, points] in the moves file. */
        expressions: Record<string, [number, number][]>;
        /** What each material draws, in the model's material order (left out: features cannot be taken from it). */
        kinds?: AvatarFaceKind[];
    };
    body: AvatarPart & {
        /** A file of how much each point of the body follows the legs (one byte each, 0-255, the parts' points one after another). */
        legs?: string;
    };
    hair: AvatarPart;
    /** Its real skeleton and skin (the VRoid samples'), so a character made from it has bones of its own. */
    skin?: {
        file: string;
    };
}
/** A skin file read: the sample's bones, and each of its three parts' points' skin (eight bytes a point: four bones, four weights). */
export interface AvatarSkin {
    bones: SkeletonBone[];
    body: Uint8Array;
    face: Uint8Array;
    hair: Uint8Array;
}
/** Reads a model's skin file (its bones and how many points each part has, as text, then the skin of the body, the face and the hair). */
export declare function readAvatarSkin(file: ArrayBuffer): AvatarSkin;
export interface AvatarIndex {
    /** The anime characters (VRoid's), whose faces, features, hair and bodies mix. */
    models: AvatarModel[];
    /** Characters in other styles, each style a kit of pieces that fit together. */
    kits?: AvatarKit[];
}
/**
 * A style of character other than the anime one: characters made on one skeleton, each cut into the same pieces (a head, a top, legs, feet),
 * so any piece goes with any other of the same build. A kit with one piece has whole characters to pick from.
 */
export interface AvatarKit {
    id: string;
    label: string;
    /** Who made it, under what licence, for the creator to say. */
    credit: string;
    /** The pieces, in the order the creator shows them. */
    slots: string[];
    models: AvatarKitModel[];
}
export interface AvatarKitModel {
    id: string;
    name: string;
    author: string;
    source: string;
    licence: string;
    sex: 'female' | 'male';
    /** Which characters' pieces fit this one's (the same skeleton). */
    build: string;
    /** A picture of the whole character. */
    thumb: string;
    /** Each piece it has, by slot. */
    pieces: Record<string, AvatarPart>;
}
/** Expressions as blends of VRoid's own. */
export declare const AVATAR_EXPRESSIONS: Record<string, {
    label: string;
    mix: Record<string, number>;
}>;
/** The shape sliders, each -1 to 1 (0 as the character was made). */
export declare const AVATAR_SHAPES: readonly ["head", "eyes", "legs", "bust", "waist", "hips", "shoulders", "neck", "thighs"];
export type AvatarShape = (typeof AVATAR_SHAPES)[number];
export declare const AVATAR_SHAPE_LABEL: Record<AvatarShape, string>;
/** Ready-made proportions, from a small chibi to a tall, glamorous grown-up. */
export declare const AVATAR_STYLES: Record<string, {
    label: string;
    shape: Partial<Record<AvatarShape, number>>;
}>;
/**
 * The face's own shape, like VRoid's face sliders, each -1 to 1 (0 as the face was made): where the eyes sit, how far apart, how they tilt
 * (outer corners up or down) and how wide; the brows' height and angle (inner ends up reads worried or sad); the mouth's height and width;
 * the chin's length and the cheeks' fullness; how open the eyes are (narrow and sharp to round), the irises' size within them, and the jaw's
 * width (a slim V-shaped jaw to a round, soft one).
 */
export declare const AVATAR_FACE_SHAPES: readonly ["eyeHeight", "eyeSpacing", "eyeTilt", "eyeWidth", "browHeight", "browTilt", "mouthHeight", "mouthWidth", "chin", "cheeks", "eyeOpen", "irisSize", "jaw"];
export type AvatarFaceShape = (typeof AVATAR_FACE_SHAPES)[number];
export declare const AVATAR_FACE_SHAPE_LABEL: Record<AvatarFaceShape, string>;
export interface AvatarChoice {
    name: string;
    /** The characters whose body (and outfit), face and hair it takes. */
    body: string;
    face: string;
    hair: string;
    /** The characters whose eyes, lashes, brows, mouth and skin (with its makeup) the face takes instead of its own. */
    features?: Partial<Record<AvatarFeature, string>>;
    expression: string;
    shape: Partial<Record<AvatarShape, number>>;
    /** The face's own shape (AVATAR_FACE_SHAPES), and what is painted on it: makeup, and the eyes drawn anew (avatardetail.ts). */
    faceShape?: Partial<Record<AvatarFaceShape, number>>;
    makeup?: AvatarMakeup;
    eyes?: AvatarEyes;
    /** `#rrggbb` for each recoloured role (left out: as drawn). */
    colours: Partial<Record<AvatarColour, string>>;
    wardrobe?: AvatarWardrobe;
    /** The hair below the jaw made longer or shorter: 1 as made, 0.4 cuts long hair to a bob, 1.8 lets a bob fall past the shoulders. */
    hairLength?: number;
    /** Hair made by Gleamshelf (animehair.ts) instead of `hair`'s: a hairstyle built as locks on this face's head. */
    madeHair?: MadeHairStyle;
    /** The eyes' lines, lashes and brows drawn by Gleamshelf (facepaint.ts) instead of as the face's model draws them. */
    facePaint?: AvatarFacePaint;
    /** A character of another style (a kit's id) instead of an anime one, and the character each of its pieces comes from. */
    kit?: string;
    pieces?: Record<string, string>;
    /** Layers left out (3D mode's Layers panel): the character comes out without them, its skeleton whole. Anime characters only. */
    hidden?: AvatarLayer[];
    /**
     * How the face takes the light: 'anime' (left out) shades the face's skin as one smooth rounded surface, as anime is drawn, so the nose and
     * cheeks throw no grey patches; 'model' keeps the model's own shading.
     */
    shading?: 'anime' | 'model';
}
/** A character's recipe as a design keeps it (ModelAsset.character), made safe; null when it isn't one. */
export declare function checkAvatarChoice(raw: unknown): AvatarChoice | null;
export declare const AVATAR_PATTERNS: readonly ["stripes", "check", "dots", "denim"];
export type AvatarPattern = (typeof AVATAR_PATTERNS)[number];
export declare const AVATAR_PATTERN_LABEL: Record<AvatarPattern, string>;
/** Clothes beyond their colour. Left out, an outfit is as it was drawn. */
export interface AvatarWardrobe {
    /** A dress only (a body with no separate bottom): 1 is as drawn; how long below the waist (0.6-1.4), and how full at the hem (0.6-1.5). */
    length?: number;
    fullness?: number;
    /** A pattern painted over a role's picture, and its colour. */
    patterns?: Partial<Record<'top' | 'bottom', {
        pattern: AvatarPattern;
        colour: string;
    }>>;
    /** A second colour for a role's printed outfit: its dark takes the role's colour, and its light this one. */
    prints?: Partial<Record<'top' | 'bottom', string>>;
    /** Underwear under a dress or skirt (wearUnderwear): its colour, and how far down the legs it comes (briefs or short shorts). */
    underwear?: {
        colour: string;
        style?: 'briefs' | 'shorts';
    };
}
/** The three models of a choice, read (readModelFile), the face's expressions file, the body's legs file and the faces features come from. */
export interface AvatarPieces {
    body: MeshAsset;
    face: MeshAsset;
    hair: MeshAsset;
    moves: ArrayBuffer;
    legs?: Uint8Array;
    /** The three models' skin files, when they have them: then the character has bones of its own. */
    skins?: {
        body: AvatarSkin;
        face: AvatarSkin;
        hair: AvatarSkin;
    };
    features?: Partial<Record<AvatarFeature, MeshAsset>>;
}
/**
 * The face's points moved into an expression: each of VRoid's expressions in `mix` adds its moves (by its weight) to the points it moves.
 */
export declare function applyExpression(face: MeshPart[], model: AvatarModel, moves: ArrayBuffer, expression: string): void;
/**
 * The key a model's own face shape goes by in AVATAR_EXPRESSIONS' mixes: VRoid Studio's names (Fcl_ALL_Joy, Fcl_BRW_Angry, Fcl_EYE_Joy_L,
 * Fcl_MTH_Fun, Fcl_MTH_A), VRM 1.0's presets (happy, relaxed, sad, aa, blinkLeft) and the creator's own (joy, brow_angry) all land on one.
 */
export declare function faceShapeKey(name: string): string;
/**
 * A whole model (a cast member's own VRoid Studio VRM, say) moved into one of the creator's expressions, by its own face shapes: each shape
 * in the expression's mix that the model has (by faceShapeKey) adds its moves at its weight. Returns how many of the mix's shapes it had, so
 * a caller can say when a model's face can't make the expression.
 */
export declare function expressionOnModel(asset: MeshAsset, expression: string): number;
/**
 * Hair made longer or shorter: every point below the ears moves down or up in proportion to how far below them it is, so the ends go where the
 * length says and the crown stays as drawn. Bangs over the face (in front, between the eyes' outer corners) are left alone, so they don't cover
 * the eyes. In the hair model's own space.
 */
export declare function lengthenHair(parts: MeshPart[], m: AvatarModel, length: number): void;
/**
 * A dress made longer, shorter, fuller or narrower: its points below the waist move, more towards the hem, and the rest of it stays. Only for a body
 * whose outfit is one piece (trousers would be pulled apart), and only near the middle of the body, so a sleeve hanging beside it is left alone.
 */
export declare function cutDress(parts: MeshPart[], m: AvatarModel, wardrobe: AvatarWardrobe | undefined): void;
/**
 * Underwear under a dress or skirt, modelled: a band round the hips from a little under the waist, its front and back panels drawn down to meet
 * between the legs, the leg openings cut high at the sides (briefs) or level a few centimetres down the thighs (shorts). It is sized to the body:
 * as wide and deep as the tops of the thighs and the hips are (VRoid bodies keep little skin under a skirt, so it can't be the skin itself), a
 * little off them, and each point follows the bones of the body point nearest it, so it moves with every pose. Returns the part, its material and
 * each point's nearest body point (part, point), or null for a body with no legs to fit it to.
 */
export declare function wearUnderwear(parts: MeshPart[], m: AvatarModel, underwear: NonNullable<AvatarWardrobe['underwear']>, materials: readonly MeshMaterial[]): {
    part: MeshPart;
    material: MeshMaterial;
    from: Int32Array;
} | null;
/**
 * The body's shape: the bust swelled (or flattened) round its middles, the waist and hips widened (or slimmed) round their heights. Each
 * change fades out from its joint, so the body stays one smooth surface; the outfit, part of the same model, follows.
 */
export declare function shapeBody(parts: MeshPart[], m: AvatarModel, shape: AvatarChoice['shape']): void;
/**
 * The body's shoulders, neck and thighs, by its own skeleton (the points each bone moves): the arms, and the sleeves hanging from them, moved
 * out (or in) for broader or narrower shoulders; the head and all on it raised for a longer neck, the neck stretching under it; the thighs
 * made fuller or slimmer round their bones. Needs the body's skin (a VRoid sample's); returns how far the head rose.
 */
export declare function shapeLimbs(parts: MeshPart[], skin: Pick<AvatarSkin, 'bones' | 'body'> | undefined, shape: AvatarChoice['shape'], headSize: number): number;
/**
 * The face's skin shaded as anime draws it: its normals turned towards a smooth rounded head's (an ellipse round the face), so the light falls
 * on the face as one soft surface and the nose, lips and cheekbones throw no grey patches; the face's drawn lines carry its features. Points
 * far outside that head (the ears) keep their own normals. In the face's own space.
 */
export declare function smoothFaceShading(parts: MeshPart[], model: AvatarModel, kinds: (AvatarFaceKind | undefined)[], amount?: number): MeshPart[];
/** A box round some parts' points: its middle and half sizes. */
declare function boxOf(parts: MeshPart[]): {
    mid: Vec3;
    half: Vec3;
} | null;
/** The face's eyes, each a box: the left and right halves of its eye whites (or irises) on either side of the head's middle. */
declare function eyesOf(parts: MeshPart[], kinds: (AvatarFaceKind | undefined)[], middle: number): {
    mid: Vec3;
    half: Vec3;
}[];
/**
 * A chibi's face, in the face's own space before it is seated: drawn chibi faces are round and flat below the eyes, with a small mouth.
 * VRoid faces have a modelled nose, lips and chin, which a head made twice as big turns into a snout. Here everything in front below the
 * eyes is pressed back toward the eyes' depth (most at the mouth and chin, none at the eyes), the mouth and the skin round it drawn in to
 * about half its width and height, the chin brought up, and the jaw rounded out.
 */
export declare function chibiFace(parts: MeshPart[], model: AvatarModel, kinds: (AvatarFaceKind | undefined)[]): void;
/**
 * The face reshaped by its sliders (AVATAR_FACE_SHAPES), in the face's own space before it is seated: each eye with what is drawn round it
 * moved, turned and widened about its middle, the skin round it following and easing back to as it was; the brows raised and turned (each
 * about its own middle, inner ends up for a worried look); the mouth moved and widened; the face below the mouth lengthened (the chin) and the
 * cheeks filled out. Points behind the face are left alone.
 */
export declare function shapeFace(parts: MeshPart[], model: AvatarModel, kinds: (AvatarFaceKind | undefined)[], shape: Partial<Record<AvatarFaceShape, number>> | undefined): void;
/**
 * Longer (or shorter) legs: each point moves up by how much it follows the legs (`legs`, a byte for each of the parts' points; without it,
 * guessed from how far below the hips it is). The legs stretch from the ground, and all above them rises by as much as the hips do; returns
 * that rise, for setting the head on.
 */
export declare function stretchLegs(parts: MeshPart[], model: AvatarModel, by: number, legs?: Uint8Array): number;
/** A character's layers, in the order assembleAvatar puts their parts: what 3D mode's Layers panel shows, hides and swaps. */
export declare const AVATAR_LAYERS: readonly ["body", "face", "hair"];
export type AvatarLayer = (typeof AVATAR_LAYERS)[number];
export declare const AVATAR_LAYER_LABEL: Record<AvatarLayer, string>;
/** How many of a character's parts each layer has (assembleAvatar's `layers`). */
export type AvatarLayerSizes = Record<AvatarLayer, number>;
/**
 * A character put together with only some of its layers (`show`), keeping only the materials and pictures those use. The skeleton stays
 * whole, so a hair layer drawn over a body layer poses alike, and a character with its hair hidden can still have it put back.
 */
export declare function avatarLayers(a: MeshAsset, sizes: AvatarLayerSizes, show: readonly AvatarLayer[]): MeshAsset;
/**
 * A character put together: `body`'s body, `face`'s face (with any features of other faces) in the chosen expression and `hair`'s hair set
 * on the body's head (the head size slider scales both), the body shaped, all as one model with each material's role.
 */
export declare function assembleAvatar(models: {
    body: AvatarModel;
    face: AvatarModel;
    hair: AvatarModel;
    features?: Partial<Record<AvatarFeature, AvatarModel>>;
}, pieces: AvatarPieces, choice: Pick<AvatarChoice, 'expression' | 'shape' | 'wardrobe' | 'faceShape' | 'hairLength' | 'shading' | 'madeHair'> & {
    chibiFace?: boolean;
}): {
    asset: MeshAsset;
    roles: AvatarRole[];
    layers: AvatarLayerSizes;
    look: AvatarLook;
};
/** What painting a put-together character needs (avatardetail.ts): each material's face kind, the head's middle line and its size. */
export interface AvatarLook {
    kinds: (AvatarFaceKind | undefined)[];
    middle: number;
    headSize: number;
    /** The face's parts' points as made (no expression or face sliders), seated, from part `from` of the character: where lines are painted. */
    rest?: {
        from: number;
        positions: Float32Array[];
    };
}
/** Helpers avatardetail.ts shares (not for apps). */
export declare const avatarGeometry: {
    boxOf: typeof boxOf;
    eyesOf: typeof eyesOf;
    smooth: (t: number) => number;
};
/**
 * Finer face controls than VRoid's presets, made from the face's own shape so they fit any creator face: the eyes
 * looking left, right, up and down (the irises and their highlights slide inside the eye), the brows raised, lowered
 * or worried (inner ends up), and the mouth's corners up (a smile) or down. Each is a move of the points it touches,
 * named as a game's cast file names them in `expressions` (look_l, look_r, look_u, look_d, brow_up, brow_down,
 * brow_worried, mouth_smile, mouth_frown).
 */
export declare const FACE_CONTROLS: readonly ["look_l", "look_r", "look_u", "look_d", "brow_up", "brow_down", "brow_worried", "mouth_smile", "mouth_frown"];
/** A character of a kit put together: each chosen piece's model, as one model with each material's role. Pieces of one build line up as they are. */
export declare function assembleKit(pieces: {
    part: AvatarPart;
    asset: MeshAsset;
}[]): {
    asset: MeshAsset;
    roles: AvatarRole[];
};
/** The pictures (by index) each recoloured role paints with: a material's base picture, for every material of that role. */
export declare function avatarPictures(asset: MeshAsset, roles: AvatarRole[]): Partial<Record<AvatarColour, number[]>>;
/**
 * A picture's pixels recoloured (RGBA, in place): each takes the new colour at its own lightness, measured against the picture's middle
 * lightness, so shading, lines and highlights stay as drawn. See-through pixels are left alone.
 */
export declare function recolourPixels(data: Uint8Array | Uint8ClampedArray, hex: string, print?: string): void;
/** A pattern painted over a picture in `hex`, keeping the shading that's already there. */
export declare function paintPattern(data: Uint8Array | Uint8ClampedArray, width: number, height: number, pattern: AvatarPattern, hex: string): void;
/** Reading and writing a picture's pixels (the browser's canvas, or sharp in Node). */
export interface PictureCodec {
    decode: (bytes: Uint8Array, mime: string) => Promise<{
        width: number;
        height: number;
        data: Uint8Array | Uint8ClampedArray;
    }>;
    encode: (width: number, height: number, data: Uint8Array | Uint8ClampedArray) => Promise<{
        bytes: Uint8Array;
        mime: string;
    }>;
}
/**
 * A character recoloured: each chosen role's pictures painted in its colour (recolourPixels), and its materials' own colour and glow
 * cleared, since VRoid often colours hair by the material over a light grey picture; a material with no picture takes the colour itself.
 * Returns a new model; the given one is left as it was.
 */
export declare function recolourAvatar(asset: MeshAsset, roles: AvatarRole[], colours: AvatarChoice['colours'] | undefined, codec: PictureCodec, wardrobe?: AvatarWardrobe): Promise<MeshAsset>;
export {};
