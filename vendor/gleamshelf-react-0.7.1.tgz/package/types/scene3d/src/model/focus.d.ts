import type { ModelDocument } from './document.js';
/**
 * Depth of field, applied after drawing: each pixel gathers neighbours on a spiral out to the most blur there is. A neighbour whose own blur
 * reaches this pixel adds its colour, one that does not adds the average so far (so every tap weighs the same and no sharp pixel can speckle a
 * blurred one); a neighbour behind this pixel reaches no further than this pixel's own blur allows, so a sharp surface hides the blur behind it
 * while a blurred one in front spreads over it. The same steps run in the shader (FOCUS_FRAGMENT in glsl.ts) over the drawn picture and its
 * depth, and here over the CPU drawing.
 */
/** Neighbours gathered for a pixel, on a spiral. */
export declare const FOCUS_TAPS = 64;
/** The depth range of the drawing camera (designCamera in renderer.ts), for reading depth back. */
export declare const DEPTH_NEAR = 0.05;
export declare const DEPTH_FAR = 500;
export interface FocusSetting {
    /** The distance in focus along the view, scene units. */
    at: number;
    /** The blur of the far distance, pixels across (the most any pixel gets). */
    radius: number;
}
/** The depth of field of a design drawn `height` pixels tall, or null when everything is sharp. */
export declare function focusFor(doc: Pick<ModelDocument, 'camera'>, height: number): FocusSetting | null;
/**
 * How much faster the blur grows away from the focus than a real lens at this size would: designs are a few units deep, so without it only the
 * floor far away would blur.
 */
export declare const FOCUS_SPREAD = 2.5;
/** How blurred a point `z` away along the view is, pixels across. Kept in step with circleOf in glsl.ts. */
export declare const circleOf: (z: number, f: FocusSetting) => number;
/** Where tap `t` of the spiral sits, pixels from the centre. Kept in step with glsl.ts. */
export declare const tapAt: (t: number, radius: number) => [number, number];
/** Blurs a picture by depth. `rgba`: linear colour premultiplied by alpha, and alpha; `depth`: each pixel's distance along the view (DEPTH_FAR where there is nothing). */
export declare function blurByDepth(rgba: Float32Array, depth: Float32Array, width: number, height: number, f: FocusSetting): Float32Array;
/** The focus offset that makes `point` sharp: how far it is beyond the camera's target along the view. */
export declare function focusOffsetTo(camera: Pick<ModelDocument['camera'], 'yaw' | 'pitch' | 'target'>, point: readonly number[]): number;
