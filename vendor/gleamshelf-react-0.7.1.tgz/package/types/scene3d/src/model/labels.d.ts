import type { ModelDocument, Shape3D, ShapeRef, Vec3 } from './document.js';
import { type DecodedPicture, type DecodePicture } from './meshcpu.js';
/**
 * Labels: a picture put on a shape, as a sticker on a box or a label round a bottle. It sits on the shape's front, back or top (seen along
 * the shape's own axis), or wraps round it; `width` is its share of that face's width, `x` and `y` where its middle is (shares of the face,
 * from the middle), and its height follows the picture's own proportions. The quick drawing (shader and CPU) and the photo-real render all
 * paint it the same way (`labelUv` here, `labelled` in glsl.ts). A design shows up to MAX_LABELS.
 */
export declare const LABEL_SIDES: readonly ["front", "back", "top", "around"];
export type LabelSide = (typeof LABEL_SIDES)[number];
export declare const LABEL_SIDE_LABEL: Record<LabelSide, string>;
export declare const MAX_LABELS = 4;
/** Labels are kept up to this many characters (a data URL), so designs stay quick to open. */
export declare const MAX_LABEL_CHARS = 4000000;
export interface Label3D {
    /** The picture, a PNG, JPEG or WebP data URL (see-through parts show the shape). */
    picture: string;
    side: LabelSide;
    /** Its width as a share of the face's (0.05-1). */
    width: number;
    /** Its middle, as shares of the face from the face's middle (-0.5 to 0.5; y up). */
    x: number;
    y: number;
}
/** A label made safe for a file; undefined without a picture. */
export declare function checkLabel(raw: unknown): Label3D | undefined;
export declare const SIDE_CODE: Record<LabelSide, number>;
/**
 * A label's size and middle on its face, in scene units, for a picture `aspect` wide over high: [width, height, middle x, middle y]. The face
 * of `around` is the shape's girth (its width's circle) by its height.
 */
export declare function labelRect(s: Pick<Shape3D, 'size'>, label: Label3D, aspect: number): [number, number, number, number];
/**
 * Where on a label a point of a shape's surface is ([u, v], 0-1 each, v up), or null when the label is not there: `p` and `n` are in the
 * shape's own frame. The point must be on the shape's box (within `slack`) and face the label's way. Kept line for line with glsl.ts.
 */
export declare function labelUv(s: Pick<Shape3D, 'size'>, label: Label3D, aspect: number, p: Vec3, n: Vec3, slack?: number): [number, number] | null;
/** The labelled shapes a design shows (up to MAX_LABELS), in the order they are drawn. */
export declare function labelledShapes(doc: Pick<ModelDocument, 'shapes'>): {
    path: ShapeRef;
    shape: Shape3D;
    label: Label3D;
}[];
/** Told when a label's picture has been read (the 3D view draws again). */
export declare function onLabelReady(listener: () => void): () => void;
/** A label's picture if it has been read; otherwise null, and it starts being read (in a browser). */
export declare function labelPicture(url: string): DecodedPicture | null;
/** Reads every label picture of a design (before drawing it where nothing can wait: pictures, the command line, the render). */
export declare function prepareLabels(doc: Pick<ModelDocument, 'shapes'>, decode?: DecodePicture | undefined): Promise<void>;
/** The label's colour at (u, v) (sRGB 0-1, and its alpha), from its picture. */
export declare function labelSample(pic: DecodedPicture, u: number, v: number): [number, number, number, number];
