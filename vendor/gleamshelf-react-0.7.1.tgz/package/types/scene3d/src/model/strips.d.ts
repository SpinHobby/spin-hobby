import type { ClipKind } from './video.js';
export type Strip = {
    kind: 'clip';
    camera: ClipKind;
    seconds: number;
    from: number;
    to: number;
} | {
    kind: 'title';
    text: string;
    seconds: number;
    background: string;
    color: string;
} | {
    kind: 'picture';
    picture: string;
    seconds: number;
};
export interface Sequence3D {
    strips: Strip[];
    /** How long each strip fades into the next (seconds, 0-1.5). */
    fade: number;
}
export declare const MAX_STRIPS = 16;
/** A sequence made safe for a file; undefined for none. */
export declare function checkSequence(raw: unknown): Sequence3D | undefined;
/** How long the whole video is (seconds). */
export declare const sequenceSeconds: (seq: Sequence3D) => number;
