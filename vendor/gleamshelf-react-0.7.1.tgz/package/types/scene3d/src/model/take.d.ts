import type { Vec3 } from './document.js';
import { type HumanBone } from './humanoid.js';
import { type Bone3D, type Rig3D } from './rig.js';
/**
 * A take: a long recorded motion of a figure's bones (a clip from a file, a dance), a pose for every frame. Keys are few and made to be edited;
 * a take is thousands of frames, kept in a design as numbers packed in base64 rather than as keys. A shape plays one over the design's clip
 * (`Shape3D.take`). Turns are as a rig keeps them: degrees, x then y then z, round the model's own axes.
 *
 * Retargeting puts a take on another figure by what each bone is (humanoid.ts): each part is turned in the world as the source's is, corrected
 * by how the two rest differently (a T-pose and arms down), and the hips travel in proportion to the two figures' legs.
 */
export interface BoneTake {
    name: string;
    seconds: number;
    fps: number;
    /** The bones the turns are for, by name. */
    bones: string[];
    /** Int16 turns in 1/50 degree, three a bone, frame after frame, in base64. */
    turns: string;
    /** Float32 moves of the whole figure (the model's own units), three a frame, in base64. */
    root: string;
    /** Expressions: their names, and bytes of how much each (0-255), a row a frame, in base64. */
    faces?: {
        names: string[];
        amounts: string;
    };
}
/** A camera's motion over a dance, kept as a take is: yaw, pitch, distance, aim and zoom, seven numbers a frame. */
export interface CameraTake {
    fps: number;
    data: string;
}
/** What a shape plays: a take of the design's, how fast, and whether its hips stay where they are. */
export interface ShapeTake {
    id: string;
    speed?: number;
    inPlace?: boolean;
}
/** A take's frames as they are made and read. */
export interface TakeFrame {
    turns: Vec3[];
    root: Vec3;
}
export declare const MAX_TAKE_CHARS = 24000000;
/** A take from its frames. */
export declare function makeTake(name: string, bones: readonly string[], fps: number, frames: readonly TakeFrame[], faces?: {
    names: string[];
    amounts: readonly (readonly number[])[];
}): BoneTake;
/** A take's expressions at a moment (seconds): how much each, by name; undefined when it has none. */
export declare function takeFaces(take: BoneTake, seconds: number): Record<string, number> | undefined;
/** The camera at a moment (seconds), from a take of it. */
export declare function cameraTakeAt(take: CameraTake, seconds: number): {
    yaw: number;
    pitch: number;
    distance: number;
    target: Vec3;
    fov: number;
};
/** How many frames a take has. */
export declare const takeFrames: (take: BoneTake) => number;
/** A take's pose for a rig at a moment (seconds; past its end it starts again): bones it does not name rest. */
export declare function takePose(take: BoneTake, rig: Pick<Rig3D, 'bones'>, seconds: number, inPlace?: boolean): {
    pose: Vec3[];
    root: Vec3;
};
/** A take's pose at one of its frames, exactly (its last one too, which `takePose` would start again from). */
export declare function takeFramePose(take: BoneTake, rig: Pick<Rig3D, 'bones'>, frame: number): {
    pose: Vec3[];
    root: Vec3;
};
/** A shape's take as it stands at `t` (0-1) of a clip of `clip` seconds. */
export declare const shapeTakePose: (take: BoneTake, rig: Pick<Rig3D, "bones">, st: ShapeTake, t: number, clip: number) => {
    pose: Vec3[];
    root: Vec3;
};
/** A camera take made safe for a file. */
export declare function checkCameraTake(raw: unknown): CameraTake | undefined;
/** Takes made safe for a file. */
export declare function checkTakes(raw: unknown): Record<string, BoneTake> | undefined;
/** A shape's take made safe; undefined for none. */
export declare function checkShapeTake(raw: unknown): ShapeTake | undefined;
type Turn = number[];
/** How a source skeleton's motion is put on a target's, worked out once. */
export interface Retarget {
    /** For each target bone, its source bone (-1: it just follows its parent), and the correction for how the two rest differently. */
    source: number[];
    correct: Turn[];
    /** The two figures' facings, as a turn to +z. */
    from: Turn;
    to: Turn;
    /** Source hips, target hips (-1: the first bone), and how far target hips travel for each unit of the source's. */
    hips: [number, number];
    scale: number;
    sourceBones: Bone3D[];
    targetBones: Bone3D[];
    /** Parts the target has that the source does not move, by name (for saying so). */
    missing: HumanBone[];
}
/** Whether a skeleton is a person's, so takes and moves can pass between figures. */
export declare const isPerson: (bones: readonly {
    name: string;
    parent: number;
}[]) => boolean;
/** Works out how to put `source`'s motion on `target`; null when they are not both people. */
export declare function planRetarget(sourceBones: readonly Bone3D[], targetBones: readonly Bone3D[]): Retarget | null;
/** A source pose on the target: its turns and how far the whole figure moves. */
export declare function retargetPose(plan: Retarget, pose: readonly Vec3[], root: Vec3 | undefined): {
    turns: Vec3[];
    root: Vec3;
};
/** A whole take put on another figure: takes named for the target's bones, or null when the two are not both people. */
export declare function retargetTake(take: BoneTake, source: readonly Bone3D[], target: readonly Bone3D[]): {
    take: BoneTake;
    missing: HumanBone[];
} | null;
/** A take as keys to edit: even samples over the clip (at most `most`). */
export declare function takeKeys(take: BoneTake, rig: Rig3D, st: ShapeTake, clip: number, most?: number): {
    at: number;
    bones: Vec3[];
    root: Vec3;
}[];
export {};
