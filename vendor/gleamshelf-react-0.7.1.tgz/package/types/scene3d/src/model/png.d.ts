/**
 * A picture written as a PNG with no help (no canvas, no library): RGBA rows, stored uncompressed inside zlib's frame. For the small
 * pictures Gleamshelf draws itself (a hairstyle's shading), where a few kilobytes more cost nothing and every reader can open it.
 */
export declare function encodePng(width: number, height: number, rgba: Uint8Array | Uint8ClampedArray): Uint8Array;
