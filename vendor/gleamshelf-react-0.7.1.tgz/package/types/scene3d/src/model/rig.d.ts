import type { Vec3 } from './document.js';
import { type MeshAsset, type MeshPart } from './mesh.js';
/**
 * Rigging an imported model (Blender's armatures, the simple way): bones in the model's own space, each turning round its head and carrying
 * its children. Every point follows its two nearest bones, blended by distance (weights worked out, never painted), so a figure bends at
 * its joints. A pose is each bone's turn (degrees, like a shape's rotation); keys keep poses, so a figure can wave or walk over a clip.
 * Reach (inverse kinematics) turns a chain of bones so its end touches a point. A model that came rigged keeps its own bones and weights (up to
 * four bones a point), and `root` carries the whole figure along when a take of a file moves it.
 */
export interface Bone3D {
    name: string;
    /** Where it starts (its joint) and ends, in the model's own space as it was imported. */
    head: Vec3;
    tail: Vec3;
    /** The bone it hangs from, -1 for none (a parent comes before its children). */
    parent: number;
}
export interface Rig3D {
    bones: Bone3D[];
    /** Each bone's turn round its head (degrees, x then y then z), as posed now. */
    pose: Vec3[];
    /** How far the whole figure has moved from where it rests, in the model's own space (a take's hips, leaving the ground in a jump). */
    root?: Vec3;
}
export declare const MAX_BONES = 256;
/** A rig made safe for a file; undefined for none. */
export declare function checkRig(raw: unknown): Rig3D | undefined;
/** A model's own bones as a rig, standing at rest; undefined when it came without any. */
export declare const ownRig: (a: MeshAsset) => Rig3D | undefined;
/**
 * A figure's bones placed by the model's box: hips, spine, chest, neck, head, both arms (upper and fore) and both legs (thigh and shin), for
 * a figure standing up and facing forward with its arms out or down. Moved into place after by turning the bones' sliders if need be.
 */
export declare function figureRig(a: MeshAsset): Rig3D;
/** A chain of bones up the middle of the model (a tail, a plant, a stand, a snake), `count` long. */
export declare function chainRig(a: MeshAsset, count?: number): Rig3D;
/** A turn and a move: p -> r p + t (r row-major). */
interface Frame {
    r: number[];
    t: Vec3;
}
export declare const mulTurn: (a: number[], b: number[]) => number[];
export declare const transposeTurn: (r: number[]) => number[];
/** Each bone's frame as posed: from the model as imported to the model posed. */
export declare function boneFrames(rig: Rig3D, pose?: readonly Vec3[], root?: Vec3 | undefined): Frame[];
/** The bones as posed (heads and tails, the model's own space), for drawing them. */
export declare const posedBones: (rig: Rig3D, pose?: readonly Vec3[]) => {
    head: Vec3;
    tail: Vec3;
}[];
export interface PartWeights {
    /** How many bones a point has: four for a model's own skin, two when worked out. */
    per: number;
    /** `per` bones a point, and how much each (summing to 1). */
    bones: Uint8Array | Uint16Array;
    weights: Float32Array;
}
/** How much each point follows which bones: the model's own skin when these are its bones, else its two nearest, the nearer more (by the inverse fourth power of distance). */
export declare function boneWeights(asset: MeshAsset, rig: Rig3D, key?: string): PartWeights[];
/** Whether a pose turns anything. */
export declare const isPosed: (rig: Rig3D | undefined) => boolean;
/** The model's points and normals as posed (each the blend of its bones' frames), with no allocation per point: this runs every frame of a dance. */
export declare function posedParts(asset: MeshAsset, rig: Rig3D, key?: string): MeshPart[];
/** Euler angles (degrees, x then y then z, as rotationMatrix reads them) of a turn. */
export declare function turnToEuler(m: number[]): Vec3;
/** The turn taking direction a to direction b (both unit), round their cross. */
export declare function turnBetween(a: Vec3, b: Vec3): number[];
export declare const unit: (v: Vec3) => Vec3;
/**
 * Reach (inverse kinematics, by cyclic coordinate descent): the bone's chain (it and up to `chain - 1` bones above it) turned, nearest the
 * end first, so the bone's tip comes as near `target` (the model's own space) as the chain allows. Returns the new pose.
 */
export declare function reach(rig: Rig3D, bone: number, target: Vec3, chain?: number, rounds?: number): Vec3[];
export {};
