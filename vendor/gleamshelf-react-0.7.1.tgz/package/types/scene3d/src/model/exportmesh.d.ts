import { type ModelDocument, type Shape3D, type Vec3 } from './document.js';
import { type MeshAsset, type MeshPart } from './mesh.js';
/**
 * A 3D design as a real 3D model, for other apps (Blender, Illustrator's 3D, a website's model viewer, AR, a 3D printer). The shapes'
 * distance field is sampled on a grid and its surface turned into triangles (surface nets: one point per cell the surface passes through,
 * moved to where the surface crosses the cell's edges, and a square between the four cells round every crossing edge). Blocks of the grid
 * far from any surface are skipped, which is what makes it quick enough for a browser. Each point gets the design's colour there (soft joins
 * blend) and a normal from the field. Imported models are added as their own triangles. The design is taken as it stands (not animated).
 */
export declare const EXPORT_FORMATS: {
    readonly glb: "GLB (3D apps, AR, the web)";
    readonly obj: "OBJ (3D apps)";
    readonly stl: "STL (3D printing)";
};
export type ExportFormat = keyof typeof EXPORT_FORMATS;
export declare const EXPORT_DETAIL: {
    readonly draft: 80;
    readonly good: 140;
    readonly fine: 220;
};
export type ExportDetail = keyof typeof EXPORT_DETAIL;
export interface ExportOptions {
    /** Cells along the design's longest side (more: finer, slower). */
    cells?: number;
    /** How tall the design is in the real world, in millimetres (models are written in metres for GLB, millimetres for OBJ and STL). */
    heightMm?: number;
    /** Told how far along it is (0-1); it also gives the page a moment to draw. */
    onProgress?: (done: number) => void | Promise<void>;
}
/** The design's surface (and imported models) as one model in its own units (the starter box is 1 wide), y up. */
export declare function designMesh(doc: ModelDocument, options?: ExportOptions): Promise<MeshAsset>;
/** The design as a file: GLB, OBJ (with vertex colours) or binary STL. */
export declare function exportModel(doc: ModelDocument, format: ExportFormat, options?: ExportOptions): Promise<Uint8Array>;
/** Wavefront OBJ, with each point's colour after its position (the common extension Blender and MeshLab read). */
export declare function writeObj(asset: MeshAsset): Uint8Array;
/** Binary STL (triangles and their facing; no colour, as printers take it). */
export declare function writeStl(asset: MeshAsset): Uint8Array;
/** An imported model's parts placed as it is drawn in the scene: stretched to its shape's size about its middle, turned, then moved. */
export declare function placedParts(shape: Shape3D, asset: MeshAsset): MeshPart[];
/**
 * Surface nets over a grid of distances (negative inside; NaN where nothing was measured): one point per cell the surface passes through,
 * moved to where it crosses the cell's edges, and a square (two triangles, facing outwards) across every grid edge it crosses. The grid's
 * corner (i, j, k) is at lo + (i, j, k) * h.
 */
export declare function surfaceNets(d: Float32Array, [nx, ny, nz]: Vec3, lo: Vec3, h: number): {
    positions: number[];
    indices: number[];
};
