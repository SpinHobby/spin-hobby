import type { ModelDocument, ShapeRef } from './document.js';
/**
 * Click and hover triggers: what a shape (or a group) does, once, when it is clicked or the pointer comes over it while a design plays live
 * (3D mode's Play, the website). A reaction is one cycle of a motion (motion.ts, `reactionMotion`) over its own few seconds, added on top of
 * the shape's keys and motion; `animate` takes the reactions running at a moment. Videos have no pointer, so they show none.
 */
export declare const REACTION_LABEL: {
    readonly spin: "Spin once";
    readonly bounce: "Hop";
    readonly wiggle: "Wiggle";
    readonly pulse: "Pulse";
    readonly sway: "Sway";
};
export type Reaction = keyof typeof REACTION_LABEL;
export declare const REACTIONS: Reaction[];
export declare const TRIGGER_EVENTS: readonly ["click", "hover"];
export type TriggerEvent = (typeof TRIGGER_EVENTS)[number];
export interface Triggers {
    /** What it does when clicked; nothing when left out. */
    click?: Reaction;
    /** What it does when the pointer comes over it; nothing when left out. */
    hover?: Reaction;
    /** How long a reaction takes, in seconds (0.3-3). */
    seconds: number;
}
export declare const DEFAULT_TRIGGER_SECONDS = 0.8;
/** Triggers made safe for a file; undefined when the shape reacts to nothing. */
export declare function checkTriggers(raw: unknown): Triggers | undefined;
/**
 * What reacts when the shape at `ref` is clicked or pointed at: the shape itself if it has that trigger, otherwise the group it is in.
 * Null when neither reacts.
 */
export declare function reactionFor(doc: Pick<ModelDocument, 'shapes'>, ref: ShapeRef | null, on: TriggerEvent): {
    id: string;
    reaction: Reaction;
    seconds: number;
} | null;
/** Whether anything in a design reacts to a click or the pointer. */
export declare const hasTriggers: (doc: Pick<ModelDocument, "shapes">) => boolean;
