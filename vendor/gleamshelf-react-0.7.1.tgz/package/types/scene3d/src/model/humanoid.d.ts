import type { Vec3 } from './document.js';
/**
 * Which bone of a skeleton is which part of a person, read from its names: Mixamo, VRoid and VRM, Unity, Unreal, Blender's Rigify, Rocketbox's
 * Biped, MikuMikuDance's Japanese names and Gleamshelf's own figure rig. The part names are VRM 1.0's, which is also what a VRM file calls them.
 */
export declare const HUMAN_BONES: readonly ["hips", "spine", "chest", "upperChest", "neck", "head", ...string[]];
export type HumanBone = string;
/** The parts a VRM file must have. */
export declare const REQUIRED_HUMAN_BONES: string[];
/** Which bone is which part (each part's shallowest bone), the spine's numbered bones sharing out spine, chest and upper chest in order up the chain. */
export declare function humanoidOf(bones: readonly {
    name: string;
    parent: number;
}[]): Map<HumanBone, number>;
/** Whether a skeleton has what a person needs to take a move: hips, a spine, a head, arms and legs. */
export declare const isHumanoid: (m: ReadonlyMap<HumanBone, number>) => boolean;
/** The part a limb bone points at: how a bone's direction is measured when two skeletons rest differently (a T-pose and arms down). */
export declare const NEXT_PART: Record<string, string>;
/** Whether a figure's left is on -x: it faces away (-z) rather than towards +z, as VRM 0 and MikuMikuDance figures do. */
export declare function facesBack(bones: readonly {
    head: Vec3;
}[], m: ReadonlyMap<HumanBone, number>): boolean;
