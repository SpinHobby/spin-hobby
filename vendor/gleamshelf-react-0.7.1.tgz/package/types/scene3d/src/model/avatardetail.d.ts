import type { Vec3 } from './document.js';
import { type MeshAsset, type MeshPart } from './mesh.js';
import { type AvatarLook, type PictureCodec } from './avatar.js';
import { type AvatarFacePaint } from './facepaint.js';
export interface AvatarMakeup {
    /** Each 0-1 (left out: none). */
    blush?: number;
    /** Three short strokes across each blush, as anime draws a flush. */
    blushLines?: boolean;
    shadow?: number;
    /** Darkness under the eyes: tired, sad. */
    under?: number;
    lips?: number;
    tears?: number;
    /** A beauty mark under one eye (the character's own left or right). */
    mole?: 'left' | 'right';
    blushColour?: string;
    shadowColour?: string;
    lipColour?: string;
}
export declare const AVATAR_MAKEUP_AMOUNTS: readonly ["blush", "shadow", "under", "lips", "tears"];
export type AvatarMakeupAmount = (typeof AVATAR_MAKEUP_AMOUNTS)[number];
export declare const AVATAR_MAKEUP_LABEL: Record<AvatarMakeupAmount, string>;
export declare const AVATAR_EYE_STYLES: readonly ["anime", "sparkle", "soft", "starry", "hollow", "ringed", "shutter"];
export type AvatarEyeStyle = (typeof AVATAR_EYE_STYLES)[number];
export declare const AVATAR_EYE_STYLE_LABEL: Record<AvatarEyeStyle, string>;
/**
 * The eyes drawn anew: a style, the pupil's size (-1 to 1), the colour of the glow at the iris's bottom (left out: a lighter iris colour)
 * and, for odd eyes, the character's own left eye in another colour (`second`).
 */
export interface AvatarEyes {
    style: AvatarEyeStyle;
    pupil?: number;
    glow?: string;
    second?: string;
    /** Thicker lashes and lash lines (0-1: how much they're drawn out), in `lashColour` (left out: a dark warm brown). */
    lashes?: number;
    lashColour?: string;
}
/** Makeup as a design keeps it, made safe; undefined when there is none. */
export declare function checkMakeup(raw: unknown): AvatarMakeup | undefined;
/** Eyes as a design keeps them, made safe; undefined when they are as drawn. */
export declare function checkEyes(raw: unknown): AvatarEyes | undefined;
type RGB = [number, number, number];
interface Picture {
    width: number;
    height: number;
    data: Uint8Array | Uint8ClampedArray;
}
/** A picture enlarged `by` times, smoothly (bilinear, colours weighted by their cover so see-through edges keep no dark fringe). */
export declare function enlargePicture(p: Picture, by: number): Picture;
/** What a painter puts at a point of the face: a colour and how much of it (0-1), or nothing. */
type Paint = (p: Vec3, n: Vec3, pixel: number) => {
    colour: RGB;
    alpha: number;
} | null;
/**
 * Each of `parts`' triangles drawn into the picture through its UVs: every pixel it covers asks `paint` about the point of the model (and its
 * normal) under it, and takes the colour over what is there (`pixel` is which pixel, for reading the picture there). A pixel's edge is let out by one pixel, so seams get painted too.
 */
export declare function paintByPlace(pic: Picture, parts: MeshPart[], paint: Paint): void;
/**
 * A put-together character (assembleAvatar, then recolourAvatar) with its details painted: makeup on its face's skin and its eyes drawn
 * anew. `look` is assembleAvatar's. Returns a new model; the given one is left as it was. Nothing to paint: the same model.
 */
export declare function detailAvatar(asset: MeshAsset, look: AvatarLook, detail: {
    makeup?: AvatarMakeup;
    eyes?: AvatarEyes;
    irisColour?: string;
    facePaint?: AvatarFacePaint;
    hairColour?: string;
}, codec: PictureCodec): Promise<MeshAsset>;
export {};
