import type { MeshAsset } from './mesh.js';
import type { Vec3 } from './document.js';
/**
 * A character's signature items: bear ears, round glasses, goggles pushed up on the head, a camera on a strap, a ribbon bow, a star hairpin… Each
 * is built of simple shapes and skinned wholly to one bone, so it follows every move and pose with no physics, in any engine that reads the pack.
 * They are what makes a character recognisable at a glance (and what a cosplayer carries), so a cast member lists them in cast.json:
 *
 *   "accessories": [{ "kind": "bear-ears", "colour": "#dba84d", "colour2": "#ee8c99" }, { "kind": "bow", "bone": "upperChest", "at": [0, 0.03, 0.15] }]
 *
 * Places are in metres in the model's own space (+y up, +z the way the character faces, +x her left), from the bone's head; head items default
 * to sitting on the crown or over the eyes of a VRoid-sized head. `move` nudges an item from its usual place, `turn` turns it (degrees, the same
 * order as Godot's rotation_degrees: y, then x, then z) and `size` scales it.
 */
export declare const WORN_ITEM_KINDS: readonly ["bear-ears", "round-glasses", "goggles", "camera", "bow", "star-pin", "pen", "spatula", "pincushion", "paint-smear", "cat-ears", "maid-headdress"];
export type WornItemKind = (typeof WORN_ITEM_KINDS)[number];
export declare const WORN_ITEM_LABEL: Record<WornItemKind, string>;
export interface WornItem {
    kind: WornItemKind;
    /** The bone it's pinned to: a VRoid name (J_Bip_C_Head) or head, neck, upperChest, chest, spine, hips, leftHand, rightHand. */
    bone?: string;
    /** Where its middle sits (replaces its usual place), from `from`. */
    at?: Vec3;
    /** Measured from the head's top (crown) or the bone's head. Left out: the kind's own, or the bone when it's pinned to another bone. */
    from?: 'crown' | 'bone';
    /** Added to its place. */
    move?: Vec3;
    turn?: Vec3;
    size?: number;
    /** #rrggbb: its main colour and its second (an ear's inside, a strap, a lens). */
    colour?: string;
    colour2?: string;
}
/** Accessories from a file, made safe: known kinds only, at most 24. */
export declare function checkAccessories(raw: unknown): WornItem[];
/**
 * The model wearing its accessories: each one's shapes as new parts, every point skinned wholly to its bone, with a plain material per colour.
 * A model with no skeleton, or without the bone named, wears it unskinned. Expressions leave the new parts alone. Throws on an unknown bone so a
 * typo doesn't silently drop an item.
 */
export declare function wearAccessories(a: MeshAsset, list: readonly WornItem[]): MeshAsset;
