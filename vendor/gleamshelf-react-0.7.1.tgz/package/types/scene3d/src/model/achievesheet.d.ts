import type { GameAchievement } from './project.js';
/**
 * A project's achievements (project.ts) as what a store and a game need, from the one list: Game Center's sheet (its ids are the game's own
 * ids behind a prefix, as the game reports them), a CSV for Google Play Games' import, the list a game reads (with the Japanese), and a badge
 * for each, so nothing is typed twice or drifts.
 */
export interface AchievementSheet {
    /** For a person filling in App Store Connect: a table of everything it asks. */
    markdown: string;
    /** Rows for a spreadsheet or Google Play Games' bulk import: name, description, points, hidden. */
    csv: string;
    /** What a game reads: the list with its store ids. */
    json: string;
    /** Points over Game Center's 1000, and anything else a store would refuse. */
    warnings: string[];
}
/** Game Center's limits: 1000 points in all, 100 for one, a title of 64 characters, a description of 255. */
export declare const GAME_CENTER: {
    readonly points: 1000;
    readonly each: 100;
    readonly title: 64;
    readonly how: 255;
};
export declare function achievementSheet(list: readonly GameAchievement[], prefix: string): AchievementSheet;
export interface BadgeColours {
    background: string;
    ring: string;
    ink: string;
}
/**
 * A badge as a 1024-pixel square SVG: the title, a word a line, sized to sit inside a ring on a soft glow. Plain shapes and text, so any SVG
 * renderer (sharp's, a browser's) draws it the same.
 */
export declare function badgeSvg(a: Pick<GameAchievement, 'title'>, c: BadgeColours): string;
