import type { GameProject } from './project.js';
import { type MeshAsset } from './mesh.js';
import { type SpringSettings } from './springs.js';
/** Makes a texture smaller for the game: whatever the game can decode. */
export type PackTexture = (t: {
    mime: string;
    bytes: Uint8Array;
}) => Promise<Uint8Array>;
export interface PackBudget {
    triangles?: number;
    bones?: number;
    bytes?: number;
}
export interface CharacterPackOptions {
    name: string;
    /** How tall it stands in the game, in metres: everything is scaled to this. */
    height: number;
    /** Ids from 3D mode's list of moves. */
    moves: string[];
    /** Expressions by name, each a blend of the model's own (`morphs.names`). */
    expressions?: Record<string, Record<string, number>>;
    /** Adds the talking mouths and a blink under fixed names (`talkExpressions`), so a game can move the mouth with a voice. Expressions named the same win. */
    talk?: boolean;
    /** Figures stand with arms out; this many degrees brings them down (0 to leave them). */
    armsDown?: number;
    /** Leave out the outline data (OUTL). */
    outlines?: boolean;
    /** Leave out the baked ambient occlusion (OCCL), which takes a second or two a character to work out. */
    occlusion?: boolean;
    /** Key frames a second, for a move with springs. */
    fps?: number;
    springs?: SpringSettings | false;
    budget?: PackBudget;
    /** The character's voice in each language, a Kokoro voice id by language code ({ en: 'af_sky', ja: 'jf_gongitsune' }): a game speaks and
     * changes a player's voice with it. Written after the parts as an optional VOIC block, so readers that stop at the parts are unaffected. */
    voices?: Record<string, string>;
    /** The box it's sized and centred by, if not its own: a layer of a character (its hair alone) packs in the box of the body under it, so the layers line up. */
    frame?: {
        min: number[];
        max: number[];
    };
}
/** What a cast part can be, by its number in the part's flags (bits 8-15; 0 for not known). */
export declare const CAST_ROLES: readonly ["", "skin", "hair", "iris", "top", "bottom", "shoes", "cloth", "face", "mouth", "faceskin"];
export declare const castRole: (tag: string | undefined) => number;
/** A spoken line's file name: 32-bit FNV-1a of who says it, a newline and the line, in hex. A game finds a line's voice from what it's showing. */
export declare function voiceName(cast: string, text: string): string;
/** The five mouths and the blink a talking character needs, as the names a game reads, each with what models from different places call it. */
export declare const TALK_SHAPES: Record<string, readonly string[]>;
/**
 * The talking mouths and blink this model can make, from its own expression names; `borrowed` are made from aa or oh (a lighter open mouth) as
 * the model has no own, and `missing` are those it has nothing for.
 */
export declare function talkExpressions(names: readonly string[]): {
    expressions: Record<string, Record<string, number>>;
    borrowed: string[];
    missing: string[];
};
/**
 * The model with its arms resting as the creator's characters rest theirs: a VRM in a T-pose holds them level, and every move, hand shape and
 * "armsDown" was tuned on the creator's. Each upper arm and everything below it turns about the shoulder (round the model's z axis); the points
 * follow by their skin weights, expressions too. A skeleton already resting lower, or not a person, comes back as it was.
 */
export declare function armsResting(a: MeshAsset, degrees?: number): MeshAsset;
export interface PackReport {
    bytes: Uint8Array;
    triangles: number;
    bones: number;
    swinging: number;
    warnings: string[];
}
export declare function packCharacter(a: MeshAsset, o: CharacterPackOptions, shrink: PackTexture): Promise<PackReport>;
/**
 * A surface for boxes: those whose name starts with `match` (the longest match wins) wear this picture, repeating every `metres`, tinted by
 * their colour unless it says not. `gloss`, `metal` and `bumps` (each 0-1) say how it takes the light, for boxes and placed models alike; a
 * surface may give only those, with no picture (shiny cars, wet roads).
 */
export interface PackMaterial {
    match: string;
    image?: Uint8Array;
    metres?: number;
    /** False for a photo: it keeps its own colours rather than taking the box's. */
    tint?: boolean;
    /** 0 a dull surface, 1 a mirror. */
    gloss?: number;
    /** 0 not metal, 1 metal. */
    metal?: number;
    /** How deep the picture's relief reads (the game raises it from the picture's light and dark): 0 flat, 1 deep. */
    bumps?: number;
}
/**
 * A batch's flags with its light in the high bits (docs/game-pack.md): 8 says they're there, then a byte each of gloss (bits 8-15), metal
 * (16-23) and bumps (24-31). A reader that knows only 1, 2 and 4 draws it as before.
 */
export declare function lightFlags(flags: number, gloss: number, metal: number, bumps: number): number;
export interface WorldPackReport extends Omit<PackReport, 'bones' | 'swinging'> {
    colliders: number;
    spots: number;
    /** The heaviest models, for when it's over budget: each one's triangles and how many times it's placed. */
    heaviest: {
        id: string;
        triangles: number;
        placed: number;
    }[];
}
/**
 * Every level of a project in one world, in the same coordinates. A shape named `wall...` or `solid...` blocks walking, by its box; a hidden
 * `spot:<name>` is a named place, with its turn. Boxes and models are drawn, in batches by texture.
 */
export declare function packWorld(project: Pick<GameProject, 'levels'>, shrink: PackTexture, budget?: PackBudget, materials?: PackMaterial[]): Promise<WorldPackReport>;
