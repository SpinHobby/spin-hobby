import type { Vec3 } from './document.js';
import { type MeshAsset } from './mesh.js';
/**
 * Anime hair made by Gleamshelf: a hairstyle from a few choices (how long the back and the sides fall, the bangs' cut, tails or buns, volume,
 * waves, an ahoge), built as locks over any creator head. Each lock is a ribbon with a raised middle, running from the crown over the skull,
 * then falling under its weight to a pointed tip; neighbours overlap, in two layers, so no scalp shows. One picture shades every lock: darker
 * roots and edges, fine strands, and the bright band across the crown (the "angel ring") that anime hair is drawn with. It recolours as the
 * creator's other hair does.
 *
 * Built in a head's own units (one head size, from the head joint, facing +z, +x the character's left), then set on the face it is made for.
 */
export declare const HAIR_BANGS: readonly ["blunt", "swept", "parted", "wispy", "none"];
export type HairBangs = (typeof HAIR_BANGS)[number];
export declare const HAIR_BANGS_LABEL: Record<HairBangs, string>;
export declare const HAIR_TAILS: readonly ["none", "pony", "twin", "side", "drills", "buns"];
export type HairTails = (typeof HAIR_TAILS)[number];
export declare const HAIR_TAILS_LABEL: Record<HairTails, string>;
export interface MadeHairStyle {
    /** How far the back hair falls below the skull, in head sizes: 0 short at the nape, 1 to the shoulders, 3 to the waist. */
    back: number;
    /** How far the hair at the sides of the face falls, in head sizes (0 at the ears, 0.6 to the chin, 2 over the chest). */
    sides: number;
    bangs: HairBangs;
    /** How low the bangs come: 0 high on the forehead, 1 to the eyes. */
    bangLength: number;
    tails: HairTails;
    /** How long the tails fall, in head sizes. */
    tailLength: number;
    /** How full the hair stands from the head (0 sleek, 1 big). */
    volume: number;
    /** Waves along the falling hair (0 straight, 1 wavy). */
    wave: number;
    /** The tips curling in (a bob's) or out: -1 out, 1 in. */
    curl: number;
    /** The single lock standing up from the crown. */
    ahoge: boolean;
    /** How many locks (0.5 a few broad ones, 1.5 many fine ones). */
    density: number;
    seed: number;
}
export declare const DEFAULT_HAIR_STYLE: MadeHairStyle;
/** Ready-made hairstyles, each a whole MadeHairStyle (a starting point to change). */
export declare const HAIR_STYLE_PRESETS: Record<string, {
    label: string;
    style: Partial<MadeHairStyle>;
}>;
/** A hairstyle made safe (numbers in range, names known); undefined when it isn't one. */
export declare function checkHairStyle(raw: unknown): MadeHairStyle | undefined;
/** One lock: its middle line, how wide it is along it, and which way is "out" (away from what it lies on) at each point. */
interface Lock {
    path: Vec3[];
    width: number[];
    out: Vec3[];
    /** Distance from the crown where the lock starts (for the texture's bright band). */
    start: number;
    /** Where along its path it starts to hang free (and swing), and the locks that swing together (one chain of bones each). */
    hang?: number;
    group?: string;
}
/** Every lock of a hairstyle, in head units. */
export declare function hairLocks(style: MadeHairStyle): Lock[];
/** The picture every lock is shaded with (64 across a lock, 256 along it, the root at the top): a warm brown the creator recolours. */
export declare function hairPicture(): Uint8Array;
/**
 * A hairstyle as a model, set on a head: `head` (the head joint) and `headSize` place it, so it fits that face. One material (the hair
 * role), double-sided, shaded with hairPicture.
 */
export declare function makeHair(style: MadeHairStyle, head: Vec3, headSize: number): MeshAsset;
/**
 * A hairstyle with its bones: the head (bone 0), which the hair over the skull, the bangs and the buns follow, and a chain of bones for each
 * group of hanging locks and each tail, named as hair so a game's springs swing them. `skin` has eight bytes a point (four bones, four
 * weights), in the parts' order, as the creator's skin files do.
 */
export declare function makeRiggedHair(style: MadeHairStyle, head: Vec3, headSize: number): {
    asset: MeshAsset;
    bones: {
        name: string;
        parent: number;
        head: Vec3;
        tail: Vec3;
    }[];
    skin: Uint8Array;
};
export {};
