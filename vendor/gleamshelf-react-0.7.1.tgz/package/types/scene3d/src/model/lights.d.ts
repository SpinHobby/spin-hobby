import type { ModelDocument, Vec3 } from './document.js';
/** A design's lights as the drawing uses them: the key light first, then the extra ones. */
export interface DrawnLight {
    /** Towards the light (unit length). */
    dir: Vec3;
    intensity: number;
    color: string;
    shadows: boolean;
}
/** Towards a light from degrees around (0 = front) and up from the ground. */
export declare const lightDirection: (azimuth: number, elevation: number) => Vec3;
export declare function designLights(doc: Pick<ModelDocument, 'light'>): DrawnLight[];
