import { type MeshAsset } from './mesh.js';
/**
 * A rigged character in other proportions, made through its own skeleton so it still moves with every clip: each bone gets a stretch of its
 * own (along its length, and round it), each bone's joint goes where its parent's stretch puts it, and every point follows its bones by its
 * skin weights, as a pose would move it. Expressions (morphs) and normals follow the same way, so the face still smiles and the light still
 * falls right. The feet are set back on the ground at the end.
 *
 * `chibi` is the 3D chibi: a head about twice as big (and everything on it: face, eyes, hair and its swing bones), a body squashed to about
 * half its height and no neck to speak of, short soft arms and legs that keep most of their girth, small rounded hands with stubby fingers,
 * and next to no chest. About 2.6 heads tall where the VRoid characters stand about 7.
 */
export interface Proportions {
    /** the head and all on it, as many times as big */
    head: number;
    /** the trunk (hips to neck): its height, and its width and depth */
    trunk: {
        length: number;
        girth: number;
    };
    arms: {
        length: number;
        girth: number;
    };
    legs: {
        length: number;
        girth: number;
    };
    /** the hand as a whole, and its fingers along their length */
    hands: number;
    fingers: number;
    feet: {
        length: number;
        girth: number;
    };
    /** the chest's own bones (VRoid's bust), shrunk toward the chest */
    bust: number;
}
export declare const CHIBI: Proportions;
export declare const PROPORTIONS: Record<string, Proportions>;
/** what part of the body a bone is, by VRoid's names (and the usual humanoid ones) */
export declare function boneKind(name: string): 'head' | 'trunk' | 'arm' | 'hand' | 'finger' | 'leg' | 'foot' | 'bust' | 'root' | 'other';
/**
 * The character in the proportions given. Needs a skeleton and skin weights (a rigged character); one without is handed back as it was.
 * Each bone's stretch is about its own joint; a bone of no known kind takes its parent's.
 */
export declare function reproportion(a: MeshAsset, p: Proportions): MeshAsset;
