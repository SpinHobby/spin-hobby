/**
 * Textures a phone's GPU reads as they are: ETC2 with EAC alpha (OpenGL ES 3's and Metal's EAC_RGBA8, every iPhone since the A7 and
 * every Android with ES 3), 8 bits a pixel, a quarter of the memory of the picture opened, and nothing to decode when a game loads it.
 * Written here, with no encoder to install: the colour half uses ETC1's two modes (two colours a block, each nudged lighter or darker
 * by one of eight tables), which every ETC2 reader reads, and never lets the differential mode overflow into ETC2's other modes.
 *
 * A game pack's picture in this form (packTextureEtc2) is a small container: "ETC2", width and height (u16 little-endian), mip levels
 * (u8), 1 when the blocks after the header are deflated (raw deflate) else 0, two bytes reserved, then each level's blocks, largest
 * first, rows of 4x4 blocks, 16 bytes a block (the 8 alpha bytes, then the 8 colour bytes, each big-endian as the format has them).
 */
/** One 4x4 block's colour half (64 bits as two big-endian 32-bit words), from 16 RGBA pixels in x*4+y order. */
export declare function encodeEtc1Block(px: Uint8Array): [number, number];
/** One 4x4 block's alpha (64 bits as two big-endian words): EAC, its base, multiplier and table chosen to fit. */
export declare function encodeEacBlock(px: Uint8Array): [number, number];
/** A whole RGBA picture as EAC_RGBA8 blocks (16 bytes each, rows of blocks); a size not a multiple of 4 repeats its edge. */
export declare function encodeEtc2Rgba(width: number, height: number, rgba: Uint8Array | Uint8ClampedArray): Uint8Array;
/** EAC_RGBA8 blocks read back to RGBA (for tests and checks; a game's GPU does this itself). Throws on a block in ETC2's other modes. */
export declare function decodeEtc2Rgba(width: number, height: number, blocks: Uint8Array): Uint8Array;
/** The container a game pack's picture goes in (see the top of this file): every level's blocks, deflated by `deflate` if given. */
export declare function etc2Container(width: number, height: number, levels: Uint8Array[], deflate?: (b: Uint8Array) => Uint8Array): Uint8Array;
