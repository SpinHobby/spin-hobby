/**
 * A surface photo made right for a game, on its pixels (RGBA, as any picture codec decodes it): recoloured while keeping its own detail (a brown
 * lawn green, a grey plaster white), broad patches that break up a repeat and still tile, its seams blended away, and a score for how much a seam
 * still shows. What Shelved's lawn, hedge and plaster needed, done here instead of in scripts.
 */
export interface Pixels {
    width: number;
    height: number;
    data: Uint8Array;
}
type Rgb = [number, number, number];
/** #rrggbb as 0-1 numbers. */
export declare function rgbOf(hex: string): Rgb;
export interface RecolourOptions {
    /** The colour it becomes, over its broad areas. */
    tint: string;
    /** A second colour for what was greenest in it, for a lawn whose blades should stay fresher than the ground under them. */
    fresh?: string;
    /** How strongly its own light and dark show through: 1 as it was, 0 flat. */
    detail?: number;
    /** How wide the "broad areas" are, in pixels: the detail is what differs from the picture blurred this much. */
    radius?: number;
}
/** The picture in a new colour, its detail (its light and dark against its own blur) kept, so it still reads as grass, plaster or stone. */
export declare function recolourTexture(p: Pixels, o: RecolourOptions): Pixels;
/**
 * Broad soft patches of another colour (drier grass, damp plaster) laid over it, made of waves that go a whole number of times across, so the
 * picture still tiles with no seam.
 */
export declare function addPatches(p: Pixels, colour: string, amount?: number, seed?: number): Pixels;
/**
 * The picture made to tile: blended near its edges with itself moved half a tile, whose edges are the picture's middle and so carry on
 * across a repeat. `width` is how much of each side is blended (0-0.5 of the picture).
 */
export declare function makeSeamless(p: Pixels, width?: number): Pixels;
/**
 * How much a seam shows when the picture repeats: the difference across its wrapped edges over the difference between neighbouring pixels
 * inside it. About 1 tiles cleanly; over 1.5 a repeat shows a line.
 */
export declare function seamScore(p: Pixels): number;
export {};
