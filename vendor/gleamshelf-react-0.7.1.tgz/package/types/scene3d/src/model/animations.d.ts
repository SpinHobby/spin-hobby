import type { Shape3D, Vec3 } from './document.js';
import { type Key } from './keys.js';
import { type Rig3D } from './rig.js';
/**
 * Ready-made moves for a figure (Mixamo's way): pick one (walk, run, wave, dance, punch, sit…) and set its sliders (speed, energy, arm
 * space, mirror, in place, and the move's own: stride, bounce, height…); the move is baked into the figure's keys over the clip, its bones
 * turned at each key and the figure lifted or carried forward, looping so a game can play it on and on. Moves turn the bones of a figure
 * rig (figureRig: hips, spine, chest, neck, head, upper arms, forearms, thighs, shins), so any standing model can take any move.
 *
 * Turns are degrees round the model's own axes, the figure facing +z with its left on +x: a thigh or arm turned by -x swings forward, an
 * upper arm raised sideways is +z on the left and -z on the right, a spine turned by +x bends forward.
 */
export type BoneName = 'Hips' | 'Spine' | 'Chest' | 'Neck' | 'Head' | 'Upper arm L' | 'Forearm L' | 'Upper arm R' | 'Forearm R' | 'Thigh L' | 'Shin L' | 'Thigh R' | 'Shin R';
export type AnimationGroup = 'Basics' | 'Gestures' | 'Together' | 'Dance' | 'Fight' | 'Sitting' | 'Story' | 'Poses';
export declare const ANIMATION_GROUPS: AnimationGroup[];
/**
 * How a hand holds its fingers, for skeletons that have them (VRoid, VRM, Mixamo…): each finger curled at its three
 * joints by a share of a full curl, the thumb across the palm. Moves name a shape per hand; left out, a hand is relaxed.
 */
export type HandShape = 'relaxed' | 'open' | 'fist' | 'point' | 'peace' | 'clasp';
export declare const HAND_SHAPES: HandShape[];
/** A move's slider. */
export interface AnimationParam {
    id: string;
    name: string;
    min: number;
    max: number;
    step: number;
    value: number;
    /** How the value reads (default: as a number). */
    unit?: 'x' | '°' | '%';
}
/** The sliders every move has (speed, energy, arm space) and its switches (mirror; in place for moves that travel). */
export declare const COMMON_PARAMS: AnimationParam[];
export interface AnimationSettings {
    /** Slider values by id (missing ones take their default). */
    values: Record<string, number>;
    /** Left and right swapped. */
    mirror: boolean;
    /** A move that travels (walk, run…) stays where it is. */
    inPlace: boolean;
    /** Degrees the upper arms come down from how the model stands, for one modelled with its arms out. */
    armsDown?: number;
}
/** One moment of a move: the bones' turns, how far the figure is lifted (a share of its height) and turned round (degrees). */
export interface MovePose {
    bones: Partial<Record<BoneName, Vec3>>;
    lift?: number;
    spin?: number;
    /** Each hand's shape (fingers), for skeletons with fingers. */
    hands?: {
        L?: HandShape;
        R?: HandShape;
    };
    /** Turns of the skeleton's own humanoid bones beyond the figure's (shoulders, wrists…), by humanoid name, e.g. rightHand. */
    extra?: Partial<Record<string, Vec3>>;
}
export interface Animation {
    id: string;
    name: string;
    group: AnimationGroup;
    /** What it looks like, for the list's tooltip. */
    note: string;
    /** One loop's length at speed 1 (seconds). */
    cycle: number;
    /** How far one loop carries the figure forward, a share of its height (0 for moves done on the spot). */
    travel?: number;
    /** The move's own sliders. */
    params?: AnimationParam[];
    /** The pose at `p` (0-1 of a loop), given the sliders' values. */
    pose: (p: number, v: Record<string, number>) => MovePose;
}
export declare const ANIMATIONS: Animation[];
/** A move by its id. */
export declare const animationById: (id: string) => Animation | undefined;
/** A named still pose: a moment of a move, held. What the Poses buttons offer beside the saved ones. */
export interface StillPose {
    id: string;
    name: string;
    /** The move it is a moment of, and where in its loop (0-1). */
    move: string;
    at: number;
}
export declare const STILL_POSES: StillPose[];
/** A still pose as a rig's bone turns (movePoseOn retargets it to any person), or null when the rig has no figure in it. */
export declare function stillPoseOn(rig: Rig3D, p: StillPose): Vec3[] | null;
/** Every slider a move shows: the common ones, then its own. */
export declare const animationParams: (a: Animation) => AnimationParam[];
/** The bones a model plays moves on: its own when they are a person's, else the rig made for it (`made`). */
export declare const moveRig: (rig: Rig3D | undefined, made: () => Rig3D) => Rig3D;
/** Whether a rig is a figure's (its bones named as figureRig names them), so moves can turn it. */
export declare function isFigureRig(rig: Rig3D | undefined): boolean;
/**
 * A move's pose at `p` (0-1 of a loop) with the settings applied: turns scaled by Energy, mirrored (left for right, turns round and
 * sideways reversed), and the arms held out by Arm space.
 */
export declare function movePose(a: Animation, p: number, settings: AnimationSettings): MovePose;
/**
 * A pose's hands and extra humanoid turns put on a skeleton's own bones (fingers, shoulders, wrists): every finger joint
 * curled by its share (about the bone's own z, the way it bends towards the palm on that side), the thumb across the palm.
 * Bones the skeleton lacks are skipped, so figures without fingers are left as they were.
 */
export declare function applyHands(bones: Vec3[], human: Map<string, number>, pose: Pick<MovePose, 'hands' | 'extra'>): void;
/** How many loops of a move fit a clip, and how many keys each loop gets (within MAX_KEYS). */
export declare function animationTiming(a: Animation, speed: number, clipSeconds: number): {
    loops: number;
    perLoop: number;
};
/** A figure's pose in a move at a moment of play (a game's walk and run), however its bones are named; null when it has no such bones. */
export declare function movePoseOn(rig: Rig3D, id: string, seconds: number): Vec3[] | null;
/**
 * A move baked into a shape's keys over the clip: at each key the figure's bones turned (round its rig's own rest), and the shape lifted,
 * carried forward (the way it faces, unless In place) and turned round as the move says, from where it stands now (its first key, when it
 * already has keys). The loop is fitted to the clip, so the last key is the first again and the clip loops cleanly.
 */
export declare function bakeAnimation(shape: Shape3D, rig: Rig3D, a: Animation, settings: AnimationSettings, clipSeconds: number): Key[];
