import { type ModelDocument } from './document.js';
import { type Contour } from './outline.js';
/**
 * Outlines from pictures: the letters of a text (drawn in a font on a canvas, then traced), or the shape of any picture's opaque pixels (a layer
 * from Edit mode, a logo). The canvas is passed in, so this runs in a browser (OffscreenCanvas or a canvas element) and in Node (@napi-rs/canvas).
 */
/** What drawing text needs from a canvas. */
export interface TextCanvas {
    width: number;
    height: number;
    getContext(kind: '2d'): {
        font: string;
        fillStyle: unknown;
        textBaseline: unknown;
        measureText(text: string): {
            width: number;
            actualBoundingBoxAscent?: number;
            actualBoundingBoxDescent?: number;
        };
        fillText(text: string, x: number, y: number): void;
        getImageData(x: number, y: number, w: number, h: number): {
            data: Uint8ClampedArray;
        };
    } | null;
}
/** The outline of a picture's opaque pixels (alpha at or above `threshold`), in the unit box, with its width over height. Null when it is empty. */
export declare function outlineFromAlpha(rgba: Uint8ClampedArray | Uint8Array, width: number, height: number, threshold?: number): {
    outline: Contour[];
    aspect: number;
} | null;
/** The commonest colour among a picture's opaque pixels (by 16 steps a channel, then averaged): a layer's main colour. */
export declare function mainColour(rgba: Uint8ClampedArray | Uint8Array, width: number, height: number): string | null;
/**
 * Make 3D: a picture's opaque shape (a logo, text, a cut-out) pushed out into a solid in its main colour, as a new design framed for a view
 * `viewAspect` wide over high. Null when the picture has nothing solid.
 */
export declare function modelFromPicture(rgba: Uint8ClampedArray | Uint8Array, width: number, height: number, options?: {
    name?: string;
    viewAspect?: number;
}): ModelDocument | null;
/**
 * The outline of a text in a font, drawn big for clean edges: one line or several (split at \n), lined up left, in the middle or right, with
 * the line spacing and extra letter spacing given (shares of the font size). Null when the text draws nothing.
 */
export declare function textOutline(value: string, font: string, weight: number, makeCanvas: (w: number, h: number) => TextCanvas, layout?: {
    align?: 'left' | 'center' | 'right';
    lineHeight?: number;
    spacing?: number;
}): {
    outline: Contour[];
    aspect: number;
} | null;
/** A canvas in a browser, for textOutline. */
export declare const browserCanvas: (w: number, h: number) => TextCanvas;
/**
 * The shape of any picture, pushed out: its opaque pixels when it has a see-through background, otherwise everything that differs from its
 * background (the colour round its edges), so a logo on white or a drawing on paper works too. With the picture's main colour there.
 * Null when nothing stands out.
 */
export declare function outlineFromPicture(rgba: Uint8ClampedArray | Uint8Array, width: number, height: number): {
    outline: Contour[];
    aspect: number;
    color: string | null;
} | null;
