/**
 * A 3D design built from simple shapes, the way a 2D designer builds a picture from shapes: each shape is added to, cut from or intersected with what
 * came before, with a blend that rounds the join into one smooth form. The design is drawn by ray marching the shapes' distance fields (see glsl.ts),
 * so blends, bevels and booleans are exact at any zoom and cost nothing to change. Plain JSON: saved with a design, edited through ModelEditor.
 */
import { type AvatarChoice } from './avatar.js';
import { type Rig3D } from './rig.js';
import { type LifeSettings } from './life.js';
import { type SpringSettings } from './springs.js';
import { type Music3D } from './music.js';
import { type BoneTake, type CameraTake, type ShapeTake } from './take.js';
import { type GameSetup } from './game.js';
import { type NodeGraph } from './nodes.js';
import { type Contour } from './outline.js';
import { type Motion } from './motion.js';
import { type CameraKey, type Key, type KeyBase, type KeyPath } from './keys.js';
import { type Triggers } from './triggers.js';
import { type Label3D } from './labels.js';
import { type Effect3D } from './effects.js';
import { type Compose3D } from './compose.js';
import { type Sequence3D } from './strips.js';
import { type PenPath } from './pen.js';
export type Vec3 = [number, number, number];
/** The solid shapes, offered on the add buttons. */
export declare const SHAPE_KINDS: readonly ["box", "sphere", "cylinder", "cone", "torus", "capsule", "pyramid"];
/**
 * Every kind: the solids, an outline pushed out into a solid (`extrude`), letters pushed out (`text`), an outline spun round an upright axis
 * (`revolve`: vases, bottles, cups, stands), an imported model (`mesh`, drawn as triangles beside the distance field: it hides and is hidden,
 * casts and takes shadows, but is never cut or blended), and a group of shapes joined on their own.
 */
export declare const ALL_KINDS: readonly ["box", "sphere", "cylinder", "cone", "torus", "capsule", "pyramid", "extrude", "text", "revolve", "mesh", "group"];
export type ShapeKind = (typeof ALL_KINDS)[number];
export type SolidKind = (typeof SHAPE_KINDS)[number];
/** How a shape joins what came before it in the list. */
export declare const COMBINE: readonly ["add", "subtract", "intersect"];
export type Combine = (typeof COMBINE)[number];
export declare const FINISHES: readonly ["matte", "satin", "glossy", "metal", "glass", "glow", "velvet", "coat"];
export type Finish = (typeof FINISHES)[number];
export declare const LOOKS: readonly ["soft", "toon", "flat", "clay", "pixel"];
export type Look3D = (typeof LOOKS)[number];
/**
 * `revolve`: the outline is the right half of the cut through the middle; its left edge sits `offset` of the radius out from the axis (0: on the
 * axis, a solid vase; more: a hole down the middle, a ring) and it sweeps `sweep` degrees round (360: all the way; less: a slice is left open).
 */
export interface Revolve3D {
    offset: number;
    sweep: number;
}
/**
 * Mirror: a twin of the shape on the other side of the scene's middle, left and right (`x`, across x = 0) or front and back (`z`, across
 * z = 0). Up and down is left out on purpose: the ground is y = 0, so a twin below it would be under the floor.
 */
export interface Mirror3D {
    x?: true;
    z?: true;
}
/**
 * Repeat: copies of the shape, drawn by folding space (a hundred copies cost what one does).
 * - `grid`: `count` copies along the shape's own x, y and z (1 for none), `spacing` apart (centre to centre, in scene units), going from the shape
 *   towards +x, +y and +z, so the shape is the first copy and turns with it.
 * - `around`: `count` copies round the scene's middle `axis` (y: round a vertical line through the ground's centre), over `arc` degrees (360: an
 *   even ring; less: from the shape onwards over that arc, the first and last copies at its ends).
 */
export type Repeat3D = {
    kind: 'grid';
    count: [number, number, number];
    spacing: Vec3;
} | {
    kind: 'around';
    count: number;
    axis: 'x' | 'y' | 'z';
    arc: number;
};
export declare const REPEAT_KINDS: readonly ["grid", "around"];
export declare const AXES: readonly ["x", "y", "z"];
/** Copies along one axis of a grid, and round a ring. */
export declare const MAX_GRID = 20;
export declare const MAX_AROUND = 64;
/** A light besides the key light: a rim or a fill, from its own direction. */
export interface ExtraLight3D {
    /** Degrees around (0 = front) and up from the ground, as the key light. */
    azimuth: number;
    elevation: number;
    /** 0-3. */
    intensity: number;
    color: string;
    /** Casts shadows of the shapes (imported models cast them from the key light only). */
    shadows: boolean;
    /**
     * What sort of light: the sun (far away, the same from everywhere; the default), a point (a bulb), a spot (a bulb in a cone) or an area (a
     * soft round panel). The photo-real render puts the last three `distance` from the camera's target in their direction, the spot and the
     * panel facing it; the quick view lights from their direction.
     */
    kind?: LightKind;
    /** Point, spot, area: how far from the camera's target (scene units, 1-50). */
    distance?: number;
    /** Area: the panel's radius (0.05-5). */
    size?: number;
    /** Spot: the cone's width in degrees (5-170). */
    cone?: number;
}
export declare const LIGHT_KINDS: readonly ["sun", "point", "spot", "area"];
export type LightKind = (typeof LIGHT_KINDS)[number];
/** A picture all round the design (an equirectangular photo), lighting the photo-real render and seen in its reflections. */
export interface Environment3D {
    /** A PNG, JPEG or WebP data URL, twice as wide as tall. */
    picture: string;
    /** How bright (0-4). */
    strength: number;
    /** Turned round the upright axis, degrees. */
    turn: number;
    /** Shown behind the design in the render (otherwise the background colour shows there). */
    show: boolean;
}
/** Lights besides the key light. */
export declare const MAX_EXTRA_LIGHTS = 2;
/** An environment made safe for a file; undefined without a picture. */
export declare function checkEnvironment(raw: unknown): Environment3D | undefined;
/** Depth of field: what is nearer or further than the focus is blurred, as through a camera's lens. */
export interface Focus3D {
    /** How blurred the far distance gets, 0-1 (0: everything sharp): at 1, as wide as 5% of the picture's height. */
    blur: number;
    /** Where it is sharp: this far beyond the camera's target along the view (negative: nearer), in scene units. */
    offset: number;
}
export interface Shape3D {
    id: string;
    name: string;
    kind: ShapeKind;
    /** Centre, in scene units (the ground is y = 0). */
    position: Vec3;
    /** Degrees about x, y, z (applied in that order). */
    rotation: Vec3;
    /** Width, height, depth of the shape's box. A sphere with unequal sizes is an ellipsoid. */
    size: Vec3;
    /** Rounded edges, as a share of the smallest size (0-0.5). */
    round: number;
    /** A torus's tube, as a share of its width (0.05-0.5). */
    thickness: number;
    combine: Combine;
    /** How softly it melts into what came before (0 = a crisp edge, 1 = very soft). */
    blend: number;
    /** `#rrggbb`. */
    color: string;
    finish: Finish;
    hidden: boolean;
    /** Locked: the view does not pick or drag it (its settings still change); kept only when true. */
    locked?: boolean;
    /** How it moves while a clip plays (a group: all its shapes together); none when left out. */
    motion?: Motion;
    /** A twin across the scene's middle; none when left out (not for a group or an imported model). */
    mirror?: Mirror3D;
    /** Copies in a grid or round the middle; none when left out (not for a group or an imported model). */
    repeat?: Repeat3D;
    /** `revolve`: where the outline sits from the axis and how far it sweeps round. */
    revolve?: Revolve3D;
    /**
     * `extrude` and `text`: the outline pushed out (closed contours in a unit box, y up, holes even-odd); its depth is the size's z. `revolve`: the
     * outline spun round (x from the axis outwards, y up).
     */
    outline?: Contour[];
    /** `text`: what it says and in which font (the outline is drawn from it where there is a font to draw with, and kept). */
    text?: TextSpec;
    /** `extrude` drawn with the pen (or a ready-made outline): its points, so the outline can be edited again. In -0.5 to 0.5, y up. */
    pen?: PenPath[];
    /** `group`: its shapes, joined to each other first; the group then joins what came before it by its own combine and blend. One level deep. */
    children?: Shape3D[];
    /** `mesh`: the imported model it draws (a key of the design's `assets`), stretched to the shape's size. */
    asset?: string;
    /** `mesh`: the model's own colours and textures (true), or the shape's one colour and finish. */
    ownColors?: boolean;
    /** Where it is, how it is turned and how big it is at moments of a clip (keys.ts); none when left out. A group's keys move it as one. */
    keys?: Key[];
    /** A group with keys: its shapes as they were when its first key was made, which its keys move, turn and resize (keys.ts). */
    keyBase?: KeyBase[];
    /** How it goes between its keys: a smooth curve through them, and turned to face the way it goes (keys.ts); straight when left out. */
    keyPath?: KeyPath;
    /** An imported model's morph: another version of it with the same points (a key of the design's assets), blended in by `amount` (0-1). */
    morph?: {
        asset: string;
        amount: number;
    };
    /** An imported model's bones and their pose (rig.ts). */
    rig?: Rig3D;
    /** How its hair and clothes swing as it moves (springs.ts); they do when it has such bones, unless turned off. */
    springs?: SpringSettings;
    /** A rigged character's life while it plays (life.ts): blinks, eyes, breath, weight, the feeling in its body; it has it unless turned off. */
    life?: LifeSettings;
    /** How much of each of its expressions shows at this moment, set by animate; never saved. */
    face?: Record<string, number>;
    /** A recorded motion it plays over the clip (a key of the design's takes; take.ts); its bones then move as the take says. */
    take?: ShapeTake;
    /** The geometry nodes a model was made by (nodes.ts), to change and make it again. */
    nodes?: NodeGraph;
    /** While it plays (and in videos and the viewer), it keeps turning to face this: another shape (its id) or the camera. */
    lookAt?: string;
    /** What it does when clicked or pointed at while the design plays live (triggers.ts); none when left out. */
    triggers?: Triggers;
    /** Its form: hollowed, twisted, bent or tapered (sdf.ts, formedDistance); none when left out. Not for a group or an imported model. */
    form?: Form3D;
    /** A picture on it, as a sticker or a label round it (labels.ts); none when left out. Not for a group or an imported model. */
    label?: Label3D;
}
/**
 * A shape's form, for detail beyond the plain solids: `hollow` a shell with walls this thick (scene units; 0 solid), `twist` degrees turned
 * from bottom to top round its upright axis, `bend` degrees bent from left to right, `taper` how much wider (+) or narrower (-) it gets towards
 * its top (-0.9 to 0.9).
 */
export interface Form3D {
    hollow?: number;
    twist?: number;
    bend?: number;
    taper?: number;
    /** Bumps all over its surface: how high (scene units, 0-0.3) and how many across a unit (1-40). */
    noise?: number;
    noiseScale?: number;
}
/** A form made safe for a file; undefined when it changes nothing. */
export declare function checkForm(raw: unknown): Form3D | undefined;
/** An imported model, kept in the design: a GLB in Gleamshelf's plain form (mesh.ts) as base64, with its box (in its own units) and size. */
export interface ModelAsset {
    name: string;
    data: string;
    triangles: number;
    /** The model's box: its size and middle, in the model's own units. */
    size: Vec3;
    centre: Vec3;
    /** A character made in the character creator: its recipe, so its layers (body, face, hair) can be changed or hidden later. */
    character?: AvatarChoice;
}
/** A 3D text: its words (lines split by \n), font and weight, and how the lines sit. */
export interface TextSpec {
    value: string;
    font: string;
    weight: number;
    /** Lines lined up on the left, the middle (the default) or the right. */
    align?: 'left' | 'center' | 'right';
    /** Line spacing, as a share of the font size (default 1.15). */
    lineHeight?: number;
    /** Extra room between letters, as a share of the font size (default 0). */
    spacing?: number;
}
export declare const TEXT_ALIGNS: readonly ["left", "center", "right"];
export interface ModelDocument {
    version: 1;
    shapes: Shape3D[];
    /** Imported models by id, used by `mesh` shapes. */
    assets?: Record<string, ModelAsset>;
    /** Recorded motions by id, played by rigged models (take.ts). */
    takes?: Record<string, BoneTake>;
    /** The camera's recorded motion (a dance's camera), over its keys. */
    cameraTake?: CameraTake;
    /** The music the clip plays to. */
    music?: Music3D;
    light: {
        /** Where the key light comes from, degrees around (0 = front) and up from the ground. */
        azimuth: number;
        elevation: number;
        /** 0-3. */
        intensity: number;
        /** Fill light everywhere, 0-1. */
        ambient: number;
        color: string;
        shadows: boolean;
        /** Up to MAX_EXTRA_LIGHTS more lights. */
        extra?: ExtraLight3D[];
    };
    style: {
        look: Look3D;
        /** Outline width in pixels at 1000 px (0 = none). */
        outline: number;
        outlineColor: string;
        /** Steps of light for the toon look (2-6), and for the pixel look's shading. */
        bands: number;
        /** The pixel look: one pixel's size at 1000 pixels tall (3-40). */
        pixel: number;
    };
    /**
     * See-through, or a colour; `picture` (a data URL, empty for none) is a scene drawn behind everything, filling the view (the generated
     * scene behind, or any picture), with the design over it.
     */
    background: {
        transparent: boolean;
        color: string;
        picture: string;
    };
    /** A floor that only catches shadows. */
    ground: {
        on: boolean;
        shadow: number;
    };
    camera: {
        /** Degrees around the target and up from level. */
        yaw: number;
        pitch: number;
        distance: number;
        target: Vec3;
        /** Field of view in degrees (perspective). */
        fov: number;
        projection: 'perspective' | 'orthographic';
        /** Depth of field; none when left out. */
        focus?: Focus3D;
    };
    /** Where the camera is at moments of a clip (keys.ts); none when left out. */
    cameraKeys?: CameraKey[];
    /** How long the design's clip is, in seconds (1-600; 4 when left out): keys, motions and the camera play over it. */
    clip?: number;
    /** A picture all round, for the photo-real render; none when left out. */
    environment?: Environment3D;
    /** Confetti and sparkles over the design while it plays (effects.ts); none when left out. */
    effects?: Effect3D[];
    /** Finishing touches on renders, pictures and videos (compose.ts); none when left out. */
    compose?: Compose3D;
    /** The video editor's strips (strips.ts, made into a video by sequence.ts); none when left out. */
    sequence?: Sequence3D;
    /** The moment of the clip a frame shows (0-1), set by animate for the effects; never saved. */
    now?: number;
    /** Played as a game (game.ts): where the player starts, trigger areas, shapes walked through, and the rules; none when left out. */
    game?: GameSetup;
}
/** Extra lights made safe: up to MAX_EXTRA_LIGHTS, each in range; none when there are none. */
export declare function checkExtraLights(raw: unknown): ExtraLight3D[] | undefined;
/** Depth of field made safe; none when there is no blur. */
export declare function checkFocus(raw: unknown): Focus3D | undefined;
/** Shapes in a design, counting a group's shapes and its start and end (the rows of the shader's shape table, ShapeTable in renderer.ts). */
export declare const MAX_SHAPES = 256;
/** Outlines and texts in a design (each takes a layer of the shader's field texture). */
export declare const MAX_FIELDS = 16;
/** Imported models placed in a design, and how big their files may be (as base64 text, one and all together). */
export declare const MAX_MESHES = 16;
export declare const MAX_ASSET_CHARS = 64000000;
export declare const MAX_ASSETS_CHARS = 128000000;
export declare const SHAPE_LABELS: Record<ShapeKind, string>;
export declare const newId: () => string;
export declare function createShape(kind: ShapeKind, index?: number, partial?: Partial<Shape3D>): Shape3D;
export declare function createModel(): ModelDocument;
/**
 * A design colour (`#rrggbb`, sRGB) as the linear light the shaders light and mix, undone by the 1/2.2 at the end of every drawing. The CPU and
 * the GPU both use this one, so a flat background comes out exactly as its hex on both. (Three.js's `Color` must not be used for this: with
 * colour management on it already turns the hex linear, and a second 2.2 on top drew #f4f1fb as #e8e2f4 on the GPU, 2026-10-29.)
 */
export declare const linearColor: (hex: string) => Vec3;
/** Contours made safe: up to 64 contours of 3-2000 finite points, each brought into the unit box. */
export declare function checkOutline(raw: unknown): Contour[] | undefined;
/** An outline from any contours (pixels, a path, a preset): brought into the unit box, with its own width over height to size the shape by. */
export declare function outlineFrom(contours: Contour[]): {
    outline: Contour[];
    aspect: number;
};
/** Counts what a design asks of the shader: shape slots (a group takes two more), outline fields, and imported models (drawn apart, no slot). */
export declare function budget(shapes: readonly Shape3D[]): {
    slots: number;
    fields: number;
    meshes: number;
};
/** Whether a design fits what can be drawn. */
export declare const fitsBudget: (shapes: readonly Shape3D[]) => boolean;
/** Whether a kind is drawn from an outline (and so takes a layer of the shader's field texture). */
export declare const hasOutline: (kind: ShapeKind) => kind is "text" | "revolve" | "extrude";
/**
 * The width and height an outline's distance field is built for: the shape's width and height; a revolve's silhouette is as wide as the round
 * shape (the smaller of its width and depth).
 */
export declare function outlineSize(s: Pick<Shape3D, 'kind' | 'size'>): [number, number];
/** The contours a shape's distance field is built from: its outline, or a revolve's whole silhouette (its profile and the profile's mirror). */
export declare function fieldContours(s: Pick<Shape3D, 'kind' | 'outline' | 'revolve'>): Contour[];
export declare function checkRevolve(raw: unknown): Revolve3D;
/** A mirror made safe: only the axes asked for, or none (undefined). */
export declare function checkMirror(raw: unknown): Mirror3D | undefined;
/** A repeat made safe, or none (undefined) when it would draw only the shape itself. */
export declare function checkRepeat(raw: unknown): Repeat3D | undefined;
/** A shape made safe: every field present and in range (for a file, an MCP call or a slider). A group's shapes are checked too (no groups inside). */
export declare function checkShape(raw: unknown, index?: number, nested?: boolean): Shape3D;
/** Imported models made safe: base64 text within the size limits, with a box. */
export declare function checkAssets(raw: unknown): Record<string, ModelAsset>;
/** The ids of the models a design's shapes use. */
export declare function usedAssets(shapes: readonly Shape3D[]): Set<string>;
/** The ids of the takes a design's shapes play. */
export declare function usedTakes(shapes: readonly Shape3D[]): Set<string>;
/** The design without models no shape uses any more (they stay while editing, for undo; dropped when it is saved or placed). */
export declare function pruneAssets(doc: ModelDocument): ModelDocument;
/**
 * A design as a file: the .json that 3D mode's Save > Design, the MCP server's model_save and `npm run model -- ... --out x.json` all write,
 * without imported models no shape uses. Other programs read it too (Shelf Life plays it as a game level).
 */
export declare const designFile: (doc: ModelDocument) => string;
/**
 * What opening a design's raw JSON leaves out, in a line for the person opening it; null when it all fits. A design holds MAX_SHAPES shapes and
 * MAX_MESHES placed models, and checkModel keeps what fits, so without this a save after opening would quietly lose the rest.
 */
export declare function designLosses(raw: unknown): string | null;
/** A design from a .json file, made safe by checkModel; an error that says so when the file is not a 3D design. */
export declare function openDesignFile(text: string): ModelDocument;
/** Every imported model that draws: the shape, its place, and its asset. A model inside a group draws where it is (a group has no transform). */
export declare function meshShapes(doc: Pick<ModelDocument, 'shapes' | 'assets'>): {
    shape: Shape3D;
    path: ShapeRef;
    asset: ModelAsset;
}[];
/** Where a shape is in a design: its index, or a group's index and its index in the group. */
export type ShapeRef = [number] | [number, number];
/** The shape at a place in the design, if there is one. */
export declare function shapeAt(doc: Pick<ModelDocument, 'shapes'>, ref: ShapeRef | null): Shape3D | undefined;
/** Every shape that draws, in order, with a group's start and end marked: what the shader and the CPU field walk through. */
export type Step = {
    op: 'shape';
    shape: Shape3D;
    path: ShapeRef;
} | {
    op: 'begin';
    group: Shape3D;
    path: [number];
} | {
    op: 'end';
    group: Shape3D;
    path: [number];
};
export declare function steps(doc: Pick<ModelDocument, 'shapes'>): Step[];
/** The longest background picture kept in a design (as data URL text). */
export declare const MAX_PICTURE_CHARS = 12000000;
/** A design from a file or another program: anything missing or out of range is filled in or brought into range. */
export declare function checkModel(raw: unknown): ModelDocument;
/** Views a designer reaches for: straight on, from the side or above, and the classic isometric. */
export declare const VIEWS: {
    readonly front: {
        readonly yaw: 0;
        readonly pitch: 0;
        readonly projection: "orthographic";
    };
    /** The right side (kept as `side` for designs and agents that name it). */
    readonly side: {
        readonly yaw: 90;
        readonly pitch: 0;
        readonly projection: "orthographic";
    };
    readonly left: {
        readonly yaw: -90;
        readonly pitch: 0;
        readonly projection: "orthographic";
    };
    readonly back: {
        readonly yaw: 180;
        readonly pitch: 0;
        readonly projection: "orthographic";
    };
    readonly top: {
        readonly yaw: 0;
        readonly pitch: 89;
        readonly projection: "orthographic";
    };
    readonly bottom: {
        readonly yaw: 0;
        readonly pitch: -89;
        readonly projection: "orthographic";
    };
    /** From above on the right; the others from above on the left, and from below on either side. */
    readonly isometric: {
        readonly yaw: 45;
        readonly pitch: 35.264;
        readonly projection: "orthographic";
    };
    readonly 'isometric-left': {
        readonly yaw: -45;
        readonly pitch: 35.264;
        readonly projection: "orthographic";
    };
    readonly 'isometric-below': {
        readonly yaw: 45;
        readonly pitch: -35.264;
        readonly projection: "orthographic";
    };
    readonly 'isometric-below-left': {
        readonly yaw: -45;
        readonly pitch: -35.264;
        readonly projection: "orthographic";
    };
    readonly perspective: {
        readonly yaw: 30;
        readonly pitch: 22;
        readonly projection: "perspective";
    };
};
export type ViewName = keyof typeof VIEWS;
