import type { ModelAsset } from './document.js';
import { type SampledTakes } from './clips.js';
import type { BoneTake } from './take.js';
import { type Vmd } from './vmd.js';
/**
 * Importing a 3D model in the browser: the person picks the model (and, for a .gltf or .obj, the files beside it: .bin, .mtl, pictures), a Three.js
 * loader reads it (Draco and meshopt compression decoded here, nothing fetched from the internet), and it becomes the plain GLB a design keeps.
 * Each loader is fetched only when its kind of file is imported, so 3D mode opens quickly.
 */
/** The model files 3D mode opens, by extension. */
export declare const MODEL_EXTENSIONS: readonly ["glb", "gltf", "fbx", "obj", "stl", "ply", "3mf", "pmx", "pmd"];
/** For a file input's accept: the models and the files that come with them. */
export declare const MODEL_ACCEPT = ".glb,.gltf,.fbx,.obj,.stl,.ply,.3mf,.pmx,.pmd,.bin,.mtl,.png,.jpg,.jpeg,.webp,.tga,.bmp,.spa,.sph";
/** What a MikuMikuDance model's or motion's author allows is said in its readme, and varies. */
export declare const MMD_TERMS = "MikuMikuDance models and dances have their own authors' terms: check the readme before sharing or selling anything made with it.";
export interface ImportedModel {
    asset: ModelAsset;
    /** Things the person should know (textures that could not come along). */
    warnings: string[];
    /** The animations in the file, on its own bones. */
    takes?: BoneTake[];
}
/** The animation files 3D mode reads for a figure to play. */
export declare const TAKE_ACCEPT = ".glb,.gltf,.fbx,.bvh,.vmd,.bin";
/**
 * Reads a file only for its motion (a Mixamo FBX, a motion-capture BVH, a GLB with animations): its bones as they rest and its takes, for
 * putting on a figure (take.ts retargetTake). Throws a plain message when there is no motion in it.
 */
export declare function importTakeFiles(files: File[]): Promise<SampledTakes & {
    vmd?: Vmd;
}>;
/**
 * Reads a model the person picked: `files` holds the model and any files it points at. Returns it in the form a design keeps, or throws a plain
 * message.
 */
export declare function importModelFiles(files: File[]): Promise<ImportedModel>;
