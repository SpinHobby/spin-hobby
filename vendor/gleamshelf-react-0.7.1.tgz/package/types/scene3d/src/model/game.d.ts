import type { ModelDocument, Vec3 } from './document.js';
import { type Reaction } from './triggers.js';
/**
 * A design played as a game, the way a game engine's editor does it (Unreal's Player Start, trigger volumes, collision, Level Blueprint and
 * Play In Editor, kept simple): where the player starts, which shapes are invisible trigger areas and which can be walked through, characters
 * placed in it, and rules, each an event (the game starts, the player uses or looks at a shape, walks into or out of an area, a flag is set,
 * some seconds pass) with what it needs (flags, numbers, items) and actions it runs (lines, a choice, flags, numbers and items changed, shapes
 * shown, hidden or moved, a character walked somewhere, a camera shot, a title, sounds and music, a wait, the tension, another level, the end).
 * Plain JSON in `doc.game`, so the same file plays in 3D mode's Play game and in games built on Gleamshelf (Shelf Life). `GameRun`
 * (gamerun.ts) is the rules running; a game of several levels and characters is a project (project.ts).
 */
export declare const GAME_EVENTS: readonly ["start", "use", "look", "enter", "leave", "flag", "time"];
export type GameEvent = (typeof GAME_EVENTS)[number];
export declare const GAME_EVENT_LABEL: Record<GameEvent, string>;
/** Events about a shape (the others are about the game). */
export declare const SHAPE_EVENTS: readonly GameEvent[];
export declare const GAME_ACTIONS: readonly ["say", "ask", "set", "clear", "add", "give", "take", "show", "hide", "move", "walk", "react", "camera", "title", "sound", "music", "wait", "tension", "achieve", "level", "end"];
export type GameActionKind = (typeof GAME_ACTIONS)[number];
export declare const GAME_ACTION_LABEL: Record<GameActionKind, string>;
export type GameAction = {
    kind: 'say';
    lines: string[];
    voice?: string;
} | {
    kind: 'ask';
    options: {
        text: string;
        flag: string;
    }[];
} | {
    kind: 'set' | 'clear';
    flag: string;
} | {
    kind: 'add';
    variable: string;
    by: number;
} | {
    kind: 'give' | 'take';
    item: string;
} | {
    kind: 'show' | 'hide';
    shape: string;
} | {
    kind: 'move';
    shape: string;
    by: Vec3;
    seconds: number;
} | {
    kind: 'walk';
    shape: string;
    to: Vec3;
    seconds: number;
} | {
    kind: 'react';
    shape: string;
    reaction: Reaction;
} | {
    kind: 'camera';
    position: Vec3;
    target: Vec3;
    seconds: number;
    shot?: string;
    film?: string;
} | {
    kind: 'title';
    text: string;
    seconds: number;
} | {
    kind: 'sound';
    sound: string;
    volume: number;
} | {
    kind: 'music';
    sound: string;
    volume: number;
} | {
    kind: 'wait';
    seconds: number;
} | {
    kind: 'tension';
    by: number;
}
/** One of the project's achievements (project.ts), by id: earned once, shown, and kept from level to level. */
 | {
    kind: 'achieve';
    achievement: string;
} | {
    kind: 'level';
    level: string;
} | {
    kind: 'end';
    text: string;
};
export declare const COMPARE: readonly [">=", "<=", "=", "!=", ">", "<"];
export type Compare = (typeof COMPARE)[number];
export interface GameRule {
    id: string;
    on: GameEvent;
    /** The shape (or group) it is about, by id: for use, look, enter and leave. */
    shape?: string;
    /** More shapes it is about as well (several shapes of one name, a door of two parts). */
    also?: string[];
    /** For flag: the flag whose setting starts it. */
    flag?: string;
    /** For time: seconds after the start. */
    seconds?: number;
    /** Flags it needs set, and flags it needs not set. */
    if?: string[];
    unless?: string[];
    /** Numbers it needs (coins >= 3), and items the player must have. */
    need?: {
        variable: string;
        op: Compare;
        value: number;
    }[];
    has?: string[];
    /** Runs only the first time. */
    once?: boolean;
    actions: GameAction[];
}
export interface GamePlayer {
    /** Where the player's feet start, and the way they face (degrees round from +z, as the camera's yaw). */
    position: Vec3;
    yaw: number;
    /** Eye height above the feet, and walking speed (scene units a second). */
    eye: number;
    speed: number;
    /** How hard a jump is (scene units a second). Left out: no jumping or falling, the player keeps to the height they start at. */
    jump?: number;
    /** Seen from behind rather than through their eyes. */
    third?: boolean;
    /** The shape that is the player: it walks where they walk, and is hidden when seen through its own eyes. */
    shape?: string;
}
/**
 * A character placed in a level: the shape that stands for it (3D mode shows the character baked into a model there) and the project's
 * character it is (a game draws that design in its place). It may turn to face the player, creep closer while not looked at, and melt as the
 * tension rises (its joins soften).
 */
export interface GameActor {
    shape: string;
    character: string;
    faces?: boolean;
    creeps?: boolean;
    /** Walks after the player, stopping a little way off. */
    follows?: boolean;
    /** Walks about where it was placed, resting now and then. */
    wanders?: boolean;
    melt?: number;
    /** Who is where and when: it walks to each block's spot as the clock reaches it. */
    routine?: RoutineBlock[];
    /** What it does standing about, instead of standing still. */
    idle?: ActorIdle;
}
/**
 * A standing character's own small business: now and then one of its moves (checking a phone, looking round, thinking) for a few seconds, at
 * its own times so a room doesn't move together; with `talk`, a conversation's turns, talking a while and then listening. Only how it looks:
 * where it goes and what the rules see don't change. A game engine plays the same with idleMove.
 */
export interface ActorIdle {
    moves: string[];
    /** Seconds from one move to the next, and how long each lasts. */
    every: number;
    for: number;
    talk?: boolean;
}
/** The move a standing character shows at `seconds`, `seed` setting its own times (its place among the characters will do). */
export declare function idleMove(idle: ActorIdle | undefined, seconds: number, seed: number): string;
/** Part of a character's day. */
export interface RoutineBlock {
    /** Minutes of the day. */
    from: number;
    to: number;
    /** The shape it goes to, by id: usually a named spot. */
    spot: string;
    /** Which weekdays, a bit each, Monday first. Left out: all five. */
    days?: number;
}
/** A level's time of day: when it starts, and how fast it passes. */
export interface GameClock {
    start: number;
    minutesPerSecond: number;
    /** The sun and sky follow the clock while playing (daylight.ts): morning light, noon, a rose-gold late afternoon. */
    daylight?: boolean;
}
/** A camera shot with a name, to use in rules and hand to a game engine. */
export interface GameShot {
    id: string;
    name: string;
    position: Vec3;
    target: Vec3;
}
/**
 * Shots one after another, a cutscene or an opening: the camera glides from each to the next over its seconds (eased), or cuts to it. Made in
 * 3D mode from saved shots, played by a camera action, and handed to a game engine in story.json with every shot's place.
 */
export interface GameFilm {
    id: string;
    name: string;
    steps: {
        shot: string;
        seconds: number;
        cut?: boolean;
    }[];
}
export declare const QUEST_STEPS: readonly ["talk", "use", "go"];
export type QuestStepKind = (typeof QUEST_STEPS)[number];
export declare const QUEST_STEP_LABEL: Record<QuestStepKind, string>;
export interface GameQuestStep {
    kind: QuestStepKind;
    shape: string;
    /** What the player is told to do next. */
    hint: string;
    /** What's said when it's done ("Name: words"). */
    lines: string[];
    /** The same lines in Japanese, one each. */
    ja?: string[];
    /** A sound for each line, by the project's sound id ('' for none). */
    voices?: string[];
    gives?: string;
}
/** Steps done in order. Its rules come from questRules (gamestory.ts). */
export interface GameQuest {
    id: string;
    title: string;
    steps: GameQuestStep[];
}
export interface GameSetup {
    player: GamePlayer;
    /** Shapes that are trigger areas: not drawn while playing, walked through, and the player walking in or out is an event. */
    areas?: string[];
    /** Shapes the player walks through (drawn, but no wall). */
    passable?: string[];
    actors?: GameActor[];
    /** The time of day, for routines. Left out: 08:00, a minute every 0.75 seconds. */
    clock?: GameClock;
    shots?: GameShot[];
    films?: GameFilm[];
    quests?: GameQuest[];
    /** The tension when the level starts (0-1): a game darkens and roughens with it. */
    tension?: number;
    /** Numbers shown on the screen while playing. */
    hud?: string[];
    rules: GameRule[];
}
export declare const MAX_RULES = 96;
export declare const MAX_ACTIONS = 16;
export declare const MAX_LINES = 12;
export declare const MAX_OPTIONS = 4;
/** A flag's, number's or item's name: a few words. */
export declare const flagName: (v: unknown) => string | undefined;
/** A design's game made safe for a file; undefined when there is none. */
export declare function checkGame(raw: unknown): GameSetup | undefined;
/** A game for a design that has none: the player stands where the camera is, facing what it looks at, with no rules yet. */
export declare function defaultGame(doc: Pick<ModelDocument, 'camera'>): GameSetup;
