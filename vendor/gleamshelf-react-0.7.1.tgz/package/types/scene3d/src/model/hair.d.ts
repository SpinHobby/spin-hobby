import type { Vec3 } from './document.js';
import { type MeshAsset } from './mesh.js';
/**
 * Hair and fur on an imported model (Blender's hair particles, the simple way): strands grown from random places on its surface (as many
 * as asked, spread by area), each starting along the surface's facing, drooping under its weight, curling round itself, and thinning to a
 * tip. Each strand is a thin three-sided tube, so it draws, renders and exports as part of the model (a part of its own, one colour).
 */
export interface HairOptions {
    /** How many strands (10-5000). */
    count: number;
    /** A strand's length, as a share of the model's size (0.01-0.6). */
    length: number;
    /** How much they hang down (0 standing out, 1 hanging). */
    droop: number;
    /** How much they curl (0 straight, 1 tight curls). */
    curl: number;
    /** How thick at the root, as a share of the length (0.005-0.1). */
    thickness?: number;
    /** Where they grow: everywhere, or only on surfaces facing up (a head's top, a cushion). */
    where?: 'all' | 'top';
    /** Their colour (linear). */
    color?: Vec3;
    seed?: number;
}
export declare const HAIR_SEGMENTS = 6;
/** The model with hair grown on it (a new part and material). */
export declare function growHair(asset: MeshAsset, options: HairOptions): MeshAsset;
