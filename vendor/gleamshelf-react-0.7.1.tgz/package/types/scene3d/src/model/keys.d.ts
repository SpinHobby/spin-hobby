import type { ModelDocument, Shape3D, ShapeRef, Vec3 } from './document.js';
/**
 * Keyframes: where a shape is, how it is turned and how big it is at moments of the clip, and how it gets from one to the next (its ease).
 * Times are shares of the clip (0-1), like motions, so a longer clip plays the same moves slower. Before the first key a shape stays at the
 * first; after the last it stays at the last. Motions (spin, float, ...) are added on top of the keyed place. `keyedAt` gives a shape's place
 * at a moment; `animate` (motion.ts) uses it for the preview and videos, and `poseAtTime` puts every keyed shape there for editing.
 */
export declare const EASE_LABEL: {
    readonly inOut: "Smooth";
    readonly linear: "Steady";
    readonly in: "Speed up";
    readonly out: "Slow down";
    readonly back: "Overshoot";
    readonly bounce: "Bounce";
};
export type Ease = keyof typeof EASE_LABEL;
export declare const EASES: Ease[];
/**
 * A key. For a shape, where it is, how it is turned and how big it is. For a group, how it is moved, turned and resized from its shapes as
 * they were at its first key (`keyBase`): `position` is the move, `rotation` the turn (degrees) and `size` the growth (1 = as it was).
 */
export interface Key {
    /** When, as a share of the clip (0-1). */
    at: number;
    position: Vec3;
    rotation: Vec3;
    size: Vec3;
    /** An imported model's morph amount then (0-1), when it has a morph. */
    morph?: number;
    /** An imported model's bones' turns then (degrees), when it has a rig. */
    bones?: Vec3[];
    /** How the shape arrives at this key from the one before. */
    ease: Ease;
}
/** The parts of a shape that keys set. */
export type KeyPose = Pick<Shape3D, 'position' | 'rotation' | 'size'> & {
    morphAmount?: number;
    bonePose?: Vec3[];
};
/** A pose as changes to a shape (its morph's amount too, when it has a morph). */
export declare function poseToShape(s: Pick<Shape3D, 'morph' | 'rig'>, p: KeyPose): Partial<Shape3D>;
/** Keys a shape may have. */
export declare const MAX_KEYS = 120;
/** Two keys closer than this (a share of the clip) are the same key. */
export declare const KEY_SNAP = 0.005;
/** Keys made safe for a file: in time order, one per moment, at most MAX_KEYS; undefined for none. */
export declare function checkKeys(raw: unknown): Key[] | undefined;
/** Where keys put a shape at `t` (0-1 of the clip). Rotations go the way the numbers say, so 0 to 360 is a whole turn. */
export declare function keyedAt(keys: readonly Key[], t: number, path?: KeyPath): KeyPose;
/** How a shape goes between its keys: along a smooth curve through them (rather than straight), and turned to face the way it goes. */
export interface KeyPath {
    curve?: boolean;
    face?: boolean;
}
/** The key at `t`, if there is one. */
export declare const keyAt: (keys: readonly Key[] | undefined, t: number) => Key | undefined;
/** The keys with the shape's place as it is now kept at `t` (the key there replaced, keeping its ease, or a new one with `ease`). */
export declare function setKey(shape: Shape3D, t: number, ease?: Ease): Key[];
/** The changes that keep a shape's place at `t` as a key: its keys, and for a group its shapes as they are when it gets its first key. */
export declare function keyPatch(shape: Shape3D, t: number): Partial<Shape3D>;
/** The changes that take every key off a shape (and a group's base). */
export declare const noKeys: (shape: Shape3D) => Partial<Shape3D>;
/** Whether a shape is somewhere other than its keys put it at `t` (moved since, and not kept yet). */
export declare function movedFromKeys(shape: Shape3D, t: number): boolean;
/** Every keyed shape (a group, or a group's shapes) put where its keys say at `t`: the changes to make, for going to a moment while editing. */
export declare function poseAtTime(doc: Pick<ModelDocument, 'shapes'> & Partial<Pick<ModelDocument, 'takes' | 'clip'>>, t: number): [ShapeRef, Partial<Shape3D>][];
/** A group's shape as it was at the group's first key. */
export interface KeyBase extends KeyPose {
    id: string;
}
/** A group's base made safe for a file; undefined for none. */
export declare function checkKeyBase(raw: unknown): KeyBase[] | undefined;
/** A keyed group at `t`: its base's shapes moved, turned and resized as its keys say (shapes added since its first key stay as they are). */
export declare function groupKeyed(group: Shape3D, t: number): Shape3D;
/** Where the camera is at a moment of the clip: the view's direction, height, distance, aim and zoom (not its projection). */
export type CameraPose = Pick<ModelDocument['camera'], 'yaw' | 'pitch' | 'distance' | 'target' | 'fov'>;
export interface CameraKey extends CameraPose {
    at: number;
    /** How the camera arrives at this key from the one before. */
    ease: Ease;
}
/** Camera keys made safe for a file, as checkKeys; undefined for none. */
export declare function checkCameraKeys(raw: unknown): CameraKey[] | undefined;
/** Where camera keys put the camera at `t`. It goes round the short way (turning the view gives -180 to 180); a whole turn is the Turntable clip. */
export declare function cameraAt(keys: readonly CameraKey[], t: number): CameraPose;
/** The camera key at `t`, if there is one. */
export declare const cameraKeyAt: (keys: readonly CameraKey[] | undefined, t: number) => CameraKey | undefined;
/** The camera keys with the view as it is now kept at `t` (as setKey). */
export declare function setCameraKey(doc: Pick<ModelDocument, 'camera' | 'cameraKeys'>, t: number, ease?: Ease): CameraKey[];
/** Whether the view was turned or moved away from where the camera keys put it at `t`. */
export declare function cameraMovedFromKeys(doc: Pick<ModelDocument, 'camera' | 'cameraKeys'>, t: number): boolean;
