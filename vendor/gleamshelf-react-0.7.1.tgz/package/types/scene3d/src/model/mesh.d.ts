import type { Vec3 } from './document.js';
/**
 * Imported 3D models (meshes), the plain way: every model is kept in a design as one GLB in a small, fixed subset (triangles, positions, normals,
 * texture coordinates, vertex colours, one colour texture per material, all baked into one space). The browser's importer turns any format into
 * it (importer.ts); here it is written and read with no Three.js, so Node (the MCP server, the command line) and the CPU drawing read the same
 * bytes. A bounding volume hierarchy (BVH) answers which triangle a ray meets first, for drawing on the CPU. A rigged model keeps its bones and
 * skin weights: the GLB then has a real glTF skin, every bone turned the same way as the model (rest turns baked in), so it opens rigged elsewhere.
 */
/** A material as drawn: colours are linear, the texture is an index into `textures` (-1 none). */
export interface MeshMaterial {
    color: Vec3;
    opacity: number;
    metalness: number;
    roughness: number;
    texture: number;
    /** A tangent-space normal map (glTF's convention: +Y up the picture), an index into `textures` (-1 none), and how strong it is. */
    normalTexture: number;
    normalScale: number;
    /** glTF's metallic-roughness picture (roughness in green, metalness in blue, scaling the factors), -1 none. */
    roughnessTexture: number;
    /** An ambient occlusion picture (red), -1 none, and how strongly it darkens the light that is not direct. */
    occlusionTexture: number;
    occlusionStrength: number;
    /** Light the surface gives off, linear (strength included), and a picture scaling it (sRGB), -1 none. */
    emissive: Vec3;
    emissiveTexture: number;
    /**
     * A clear varnish over the surface (KHR_materials_clearcoat): how much (0-1, scaled by its picture's red), how rough (scaled by its
     * picture's green), and its own normal map (-1: the surface's shape without the base normal map).
     */
    clearcoat: number;
    clearcoatTexture: number;
    clearcoatRoughness: number;
    clearcoatRoughnessTexture: number;
    clearcoatNormalTexture: number;
    clearcoatNormalScale: number;
    /** A velvet glow at grazing angles (KHR_materials_sheen): its colour (linear; scaled by its sRGB picture) and roughness (scaled by alpha). */
    sheenColor: Vec3;
    sheenColorTexture: number;
    sheenRoughness: number;
    sheenRoughnessTexture: number;
    /** How much light passes through, like glass (KHR_materials_transmission; scaled by its picture's red), and the index of refraction. */
    transmission: number;
    transmissionTexture: number;
    ior: number;
    /** Alpha below one half is a hole (leaves, hair cards, lace). */
    cutout: boolean;
    doubleSided: boolean;
    /** Drawn as its colours are, with no light or shade (KHR_materials_unlit): a photo shown exactly as photographed. */
    unlit?: boolean;
    /** Its own look instead of the design's (Light and look): soft (physical), toon, flat or clay; kept in the GLB's extras. */
    look?: MaterialLook;
    /** Toon: how many steps of light (2-8; left out: the design's). */
    bands?: number;
    /** What the material is, when a game needs to know (a character's `iris`, recoloured by the player); kept in the GLB's extras. */
    tag?: string;
}
export declare const MATERIAL_LOOKS: readonly ["soft", "toon", "flat", "clay"];
export type MaterialLook = (typeof MATERIAL_LOOKS)[number];
export interface MeshPart {
    positions: Float32Array;
    normals: Float32Array;
    uvs: Float32Array | null;
    /** Linear RGB per vertex. */
    colors: Float32Array | null;
    indices: Uint32Array;
    material: number;
    /** A rigged model's skin: up to four bones a point (indices into the asset's skeleton) and how much each, four numbers a point. */
    joints?: Uint16Array | null;
    skinWeights?: Float32Array | null;
}
/** A bone of a rigged model, in the model's own space as it rests (its turn at rest is baked in). */
export interface SkeletonBone {
    name: string;
    /** The bone it hangs from, -1 for none (a parent comes before its children). */
    parent: number;
    head: Vec3;
    tail: Vec3;
}
/**
 * The model turned half round about its up axis: VRM 0 characters face away from the viewer (-z) where glTF, VRM 1 and every game here face
 * +z. A turn, not a mirror, so the triangles keep their winding and the left hand stays left.
 */
export declare function turnedAround(a: MeshAsset): MeshAsset;
/** The most bones a model keeps; more than that follow their nearest kept parent. */
export declare const MAX_SKELETON_BONES = 256;
export interface MeshAsset {
    parts: MeshPart[];
    materials: MeshMaterial[];
    /** Encoded pictures (PNG, JPEG or WebP), sRGB. */
    textures: {
        mime: string;
        bytes: Uint8Array;
    }[];
    min: Vec3;
    max: Vec3;
    triangles: number;
    /** The model's own bones, when it came rigged (or was made so): the parts' `joints` point into it. */
    skeleton?: SkeletonBone[];
    /** A character's expressions: each one's name and how it moves each part's points (null: not that part). */
    morphs?: {
        names: string[];
        moves: (Float32Array | null)[][];
    };
}
export declare const defaultMaterial: () => MeshMaterial;
export declare function toBase64(bytes: Uint8Array): string;
export declare function fromBase64(text: string): Uint8Array;
export declare function boundsOf(parts: MeshPart[]): {
    min: Vec3;
    max: Vec3;
};
/** Smooth normals from the triangles (each vertex the area-weighted average of its faces). */
export declare function computeNormals(positions: Float32Array, indices: Uint32Array): Float32Array;
/** The model as a GLB in Gleamshelf's plain subset. */
/** Adds data to a GLB being written: its bytes, glTF's component type, how many, its type; returns the accessor's index. */
export type AddAccessor = (bytes: Uint8Array, componentType: number, count: number, type: 'SCALAR' | 'VEC2' | 'VEC3' | 'VEC4' | 'MAT4', opts?: {
    target?: number;
    normalized?: boolean;
    min?: number[];
    max?: number[];
}) => number;
/** What a GLB may carry beyond the plain form: morph targets (by part, each a move of its points; null moves nothing there), and anything else a caller writes in. */
export interface GlbExtras {
    morphs?: (Float32Array | null)[][];
    morphNames?: string[];
    extend?: (json: Record<string, unknown>, add: AddAccessor) => void;
}
export declare function writeGlb(asset: MeshAsset, more?: GlbExtras): Uint8Array;
type Json = Record<string, any>;
/**
 * A glTF model read into the plain form: every mesh in the default scene, its nodes' transforms baked in, triangles only. `files` gives the bytes
 * of a .gltf's separate files by their uri (a .bin, pictures); a GLB carries its own.
 */
export declare function readGltf(json: Json, bin: Uint8Array | null, files?: (uri: string) => Uint8Array | null, options?: ReadOptions): MeshAsset;
/** Where a bone with no stated tail ends: at its children (the middle of them), else on along its parent, a little way. */
export declare function boneTail(bones: readonly SkeletonBone[], i: number): Vec3;
/** Bounds and the triangle count; materials not used are kept (indices stay valid). */
export declare function finish(parts: MeshPart[], materials: MeshMaterial[], textures: MeshAsset['textures']): MeshAsset;
export interface ReadOptions {
    /** Keep another maker's expressions (a VRM's mouths and blinks) as morphs, posed as the points are; off, they are left behind. */
    expressions?: boolean;
    /** Drop the points no triangle of a part uses (a VRM's parts share their mesh's whole list). */
    trim?: boolean;
}
/** A GLB (or a .gltf file's text, with `files` for what it points at) read into the plain form. */
export declare function readModelFile(bytes: Uint8Array, files?: (uri: string) => Uint8Array | null, options?: ReadOptions): MeshAsset;
export declare function meshAsset(id: string, data: string): MeshAsset;
export interface MeshHit {
    t: number;
    part: number;
    /** The triangle's corners (vertex indices in its part) and the hit's barycentric weights for the second and third. */
    a: number;
    b: number;
    c: number;
    u: number;
    v: number;
}
export interface MeshBvh {
    /** The nearest triangle along origin + t·dir for t in (tMin, tMax); dir need not be unit length (t is in its units). */
    intersect(origin: Vec3, dir: Vec3, tMin?: number, tMax?: number): MeshHit | null;
    /** Whether anything is hit in (tMin, tMax): for shadows. */
    occluded(origin: Vec3, dir: Vec3, tMin?: number, tMax?: number): boolean;
}
/** A BVH over every triangle of the model (median splits, four triangles a leaf); built once per model. */
export declare function meshBvh(asset: MeshAsset): MeshBvh;
export {};
