import type { Clip, PixelData, Point, Rect } from '../../../canvas/src/index.js';
/**
 * The heal tool's pixels: the stroke gathers a soft cover of what to remove (coverDab), and when the pointer lifts, healPixels fills
 * the covered pixels from what surrounds them — the free inpaint from the pipeline, run on a crop round the stroke — and blends the
 * fill back in by the cover, so the edges melt instead of cutting.
 */
/** One soft dab of healing cover at `at`, with the brush's fall-off; `cover` holds one 0-1 float a pixel. Returns the box it touched. */
export declare function coverDab(cover: Float32Array, width: number, height: number, at: Point, size: number, hardness: number, clip?: Clip): Rect | null;
/**
 * Heals `working` from `snapshot` (the pixels as they were before the stroke, which may have drawn a veil over them): everything the
 * cover touches is put back from the snapshot, the covered pixels are filled from their surroundings, and the fill is blended in by
 * the cover. The crop keeps the fill quick and gives it enough around the stroke to read from. Returns the box it changed.
 */
export declare function healPixels(working: PixelData, snapshot: PixelData, cover: Float32Array): Rect | null;
