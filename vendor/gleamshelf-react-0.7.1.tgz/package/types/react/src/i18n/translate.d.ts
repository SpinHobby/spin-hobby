/**
 * The editors in another language (Japanese for now). Rather than threading a language through every panel, the words the editors show
 * are swapped for their translation as they appear: text, and the title, aria-label, placeholder and alt attributes. A dictionary maps
 * the English (spaces evened out) to the translation; an entry with {} matches words around a gap (a number, a name), and {1} {2} in the
 * translation put the gaps in another order. What has no entry stays English. The website's language switch turns it on.
 */
export type EditorLang = 'en' | 'ja';
export type Dictionary = Record<string, string>;
interface Compiled {
    exact: Map<string, string>;
    /** `bare`: the pattern has no words of its own (only "{} ({})"), so it is used only when a gap is a known phrase. */
    patterns: {
        re: RegExp;
        to: string;
        bare: boolean;
    }[];
}
/** A dictionary ready to look up. */
export declare function compile(dict: Dictionary): Compiled;
/** A string's translation (its surrounding spaces kept), or null when there is none. */
export declare function translateText(c: Compiled, text: string): string | null;
declare const ATTRS: readonly ["title", "aria-label", "placeholder", "alt"];
/** An element's words in English, whatever language is showing (the tutorials look for controls by them). */
export declare function englishText(el: Node): string;
/** An element's title, aria-label, placeholder or alt in English, whatever language is showing; null when it has none. */
export declare function englishAttr(el: Element, name: (typeof ATTRS)[number]): string | null;
/**
 * The editors' language. In Japanese, everything under `root` (the page, by default; dialogs open at its end) is translated now and as it
 * changes; back in English, the English is put back.
 */
export declare function setEditorLanguage(lang: EditorLang, root?: Element): Promise<void>;
/** For tests: forget the loaded dictionaries. */
export declare const resetDictionaries: () => void;
export {};
