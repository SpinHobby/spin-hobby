/**
 * The editors in Japanese (translate.ts): English as it appears on screen (spaces evened out) to Japanese. Developer notes stay in English.
 * Button names in the help lines are in 「」 as the buttons themselves read. {} stands for a gap (a number, a name).
 */
export declare const JA: Record<string, string>;
