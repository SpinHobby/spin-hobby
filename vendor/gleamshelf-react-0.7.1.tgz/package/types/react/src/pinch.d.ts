export interface PanZoom {
    zoom: number;
    x: number;
    y: number;
}
interface Point {
    x: number;
    y: number;
}
/**
 * The view after two fingers moved from a0/b0 to a1/b1 (canvas pixels): the picture point under the fingers' midpoint stays under it, and
 * the zoom follows their spread.
 */
export declare function pinchView(v0: PanZoom, a0: Point, b0: Point, a1: Point, b1: Point, min: number, max: number): PanZoom;
/**
 * Follows the fingers on one canvas. Only touch pointers count; a pen or a mouse is always 'free'. Once a second finger lands, every finger
 * steers until all of them lift, so lifting one finger mid-pinch never starts a brush stroke.
 */
export declare class TwoFingers {
    private min;
    private max;
    private fingers;
    private from;
    private held;
    /** The view this pinch last gave out: the caller's state may lag a frame behind it. */
    private last;
    constructor(min: number, max: number);
    /** True while the fingers own the view: the canvas ignores its own tools. */
    get steering(): boolean;
    /**
     * A pointer went down. 'begin': a second finger just landed, so the caller drops whatever the first finger started. 'steer': part of a
     * pinch. 'free': handle it as usual.
     */
    down(e: {
        pointerId: number;
        pointerType: string;
    }, at: Point, view: PanZoom): 'free' | 'begin' | 'steer';
    /** A pointer moved: the new view while steering, else null. */
    move(e: {
        pointerId: number;
        pointerType: string;
    }, at: Point): PanZoom | null;
    /** A pointer lifted or was cancelled. True when it was steering (the caller does nothing else with it). */
    up(e: {
        pointerId: number;
        pointerType: string;
    }, view: PanZoom): boolean;
    private pair;
    private restart;
}
export {};
