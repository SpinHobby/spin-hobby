import '../model3d/model3d.css';
import './market.css';
/**
 * Market mode: what a product is worth and where. Sold comps from a sales file, asking prices by country with what landing them costs, a landed-cost
 * calculator, the listing in another language for another country's marketplace, and points to check against the maker's photo before buying or listing a
 * possible bootleg. Everything runs in the Gleamshelf app on this computer (apps/local/src/market.ts); nothing here costs money.
 */
export interface MarketProduct {
    title?: string;
    /** JAN, UPC or EAN. */
    code?: string;
    /** What was read off the box (the app's identify step), for finding the version and the Japanese name. */
    identity?: object;
    listing?: {
        title: string;
        description: string;
    };
}
export interface MarketModeProps {
    onClose: () => void;
    title?: string;
    product?: MarketProduct;
    /** The shop's photo of the product, for the bootleg check. */
    photo?: Blob;
    /**
     * Called when the person chooses to use something in the product's listing (a price from the comps, a translation). The host decides what to do
     * with it (fill its listing form, save a draft); without it, the "Use" buttons are not shown.
     */
    onUse?: (patch: ListingPatch) => void;
}
/** What Market mode hands back to the listing: only the parts the person chose. */
export interface ListingPatch {
    price?: {
        amount: number;
        currency: string;
        grade: string;
        why: string;
    };
    title?: string;
    description?: string;
    bullets?: string[];
    searchTerms?: string;
    language?: string;
    marketplace?: string;
}
export declare function MarketMode({ onClose, title, product, photo, onUse }: MarketModeProps): import("react").JSX.Element;
