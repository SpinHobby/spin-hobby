import type { useLocalApp } from '../useLocalApp';
/**
 * Market mode's "What to import": series and products scored from anime trends (AniList), the shop's sales and stock, and a supplier's list with the price
 * gap between Japan and Canada. Each score shows its parts and their reasons; the written brief is the local model's and only restates them
 * (apps/local/src/plan.ts, trends.ts).
 */
type App = ReturnType<typeof useLocalApp>;
export declare function ImportPlanTab({ app }: {
    app: App;
}): import("react").JSX.Element;
export {};
