import type { useLocalApp } from '../useLocalApp';
/**
 * Market mode's tools for selling more, as the big marketplaces do: "frequently bought together", best sellers and badges, deals for slow stock (Sell more),
 * "Customers say" over the reviews, and search synonyms. Everything is worked out by the Gleamshelf app on this computer from the shop's own exports
 * (apps/local/src/insights.ts, reviews.ts, synonyms.ts); each answer can be saved as a file for the shop's site.
 */
type App = ReturnType<typeof useLocalApp>;
export declare function SellMoreTab({ app }: {
    app: App;
}): import("react").JSX.Element;
export declare function ReviewsTab({ app, title }: {
    app: App;
    title: string;
}): import("react").JSX.Element;
export declare function SynonymsTab({ app }: {
    app: App;
}): import("react").JSX.Element;
export {};
