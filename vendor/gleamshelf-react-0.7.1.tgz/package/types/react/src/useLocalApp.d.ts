import { LocalModelClient, type LocalModelStatus } from '../../models/src/index.js';
interface Saved {
    url: string;
    token: string;
}
export type LocalAppState = 'checking' | 'offline' | 'blocked' | 'needs-token' | 'ready';
/**
 * A page on the public web turns this off before showing the editor: then nothing is sent to this computer's address (newer browsers ask
 * visitors about that) until the person clicks "Look for the app", or has paired with the app before. On by default.
 */
export declare function setLookForLocalApp(on: boolean): void;
export declare function setLocalAppGuide(url: string | null): void;
/** The guide set by setLocalAppGuide, kept current. */
export declare function useLocalAppGuide(): string | null;
/**
 * Finds the Gleamshelf companion app on this computer and reports where things stand: not running, blocked by the browser,
 * needs the pairing token, or ready with a list of models. Keeps looking while it is not found, so starting the app in a
 * terminal is noticed without clicking anything. Shared by every control that uses a local model.
 */
export declare function useLocalApp(override?: {
    url?: string;
    token?: string;
}): {
    state: LocalAppState;
    saved: Saved;
    client: LocalModelClient;
    models: LocalModelStatus[] | null;
    installed: (task: LocalModelStatus["task"]) => LocalModelStatus[];
    problem: string | null;
    setProblem: import("react").Dispatch<import("react").SetStateAction<string | null>>;
    check: () => Promise<void>;
    connect: (token: string) => void;
    canProcess: boolean;
    canPhone: boolean;
    canShop: boolean;
    canMarket: boolean;
    looking: boolean;
};
export {};
