/**
 * One instruction per feature, twice: `user` for the person using the editor (what to do, in a sentence), `dev` for someone working on Gleamshelf (what runs,
 * where it lives, how to try it without the editor). The plain line is always on screen; the developer line shows when "Developer notes" is switched on.
 * Add an entry here with every new feature: instructions.test.ts checks each one has both, and that the plain line stays short.
 */
export interface HelpEntry {
    /** The section of the guide it is listed under. */
    group: HelpGroup;
    /** Its name in the guide. */
    name: string;
    user: string;
    dev: string;
}
export type HelpGroup = 'Top bar' | 'One click' | 'Cut out' | 'Clean up' | 'Adjust' | 'Edit mode' | 'Photo lab' | '3D mode' | 'Avatar mode' | 'Market';
export declare const HELP_GROUPS: readonly HelpGroup[];
export declare const HELP: {
    undo: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    ask: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    compare: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    reset: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    editMode: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    photoLab: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    phone: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    done: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    guide: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    lookForApp: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    handTools: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    noCloudAi: {
        group: "Top bar";
        name: string;
        user: string;
        dev: string;
    };
    autoRun: {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    autoMode: {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    foundPhotos: {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    autoReport: {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    sendToShop: {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    makeAd: {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    make3d: {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    autoBack: {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.stickers': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.lettering': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.find': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.thinParts': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.colour': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.vivid': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.look': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.gloss': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.enlarge': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    'step.listing': {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    green: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    cutManual: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    'cut.tap': {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    'cut.erase': {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    'cut.restore': {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    fade: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    clearMask: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    aiCutout: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    promoPicture: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    cleanPhoto: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    studio: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    recentRuns: {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    fidelityGuard: {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    flatten: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    listingHealth: {
        group: "One click";
        name: string;
        user: string;
        dev: string;
    };
    ground: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    listingSet: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    backdrop: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    square: {
        group: "Cut out";
        name: string;
        user: string;
        dev: string;
    };
    stickers: {
        group: "Clean up";
        name: string;
        user: string;
        dev: string;
    };
    stickerClick: {
        group: "Clean up";
        name: string;
        user: string;
        dev: string;
    };
    textClick: {
        group: "Clean up";
        name: string;
        user: string;
        dev: string;
    };
    lettering: {
        group: "Clean up";
        name: string;
        user: string;
        dev: string;
    };
    letteringSliders: {
        group: "Clean up";
        name: string;
        user: string;
        dev: string;
    };
    aiFill: {
        group: "Clean up";
        name: string;
        user: string;
        dev: string;
    };
    finish: {
        group: "Clean up";
        name: string;
        user: string;
        dev: string;
    };
    rotate: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    crop: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    straighten: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    looks: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    autoLook: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    enlarge: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    light: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    color: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    recolour: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    effects: {
        group: "Adjust";
        name: string;
        user: string;
        dev: string;
    };
    avAvatar: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    avColours: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    avMood: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    avGestures: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    avCamera: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    avMic: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    avBackdrop: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    avPopout: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    avVoice: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    avClear: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    avTranslate: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    avCaptions: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    avAgent: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    avVideo: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    avWebsite: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    avCalls: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    avStage: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    avLive: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    avShopWords: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    avSay: {
        group: "Avatar mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dAdd: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dOutlineShape: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dRevolve: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dMirror: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dRepeat: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dText: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dMulti: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dAlign: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dLookCopy: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dLock: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dCopy: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dPen: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dSvgImport: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dGroup: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dSvg: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dVideo: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dAd: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dPhotos: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dScene: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dMotion: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dKeys: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dTriggers: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dForm: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dMeshEdit: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dRoom: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dDrop: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dEffects: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dLearn: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dVoice: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dModelMaterial: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dDraw: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dDrawTouch: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dBrush: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dElements: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dUnwrap: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dRig: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dLife: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dCloth: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dHair: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dNodes: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dCompose: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dSequence: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dScript: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dLibrary: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dAvatar: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dLayers: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dLooks: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dPoses: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dSticker: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dAnimations: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dWebGame: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dRoutine: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dShots: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dDaylight: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dFilms: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dIdle: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dTestPlay: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dAchievements: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dRomance: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dQuests: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dFaceLines: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dMadeHair: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dFaceShape: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dEyeStyle: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dMakeup: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dWardrobe: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dShapeRole: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dGameCheck: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dWalkMap: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dGameBudget: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dGameSurfaces: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dGameVoices: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dCastSheet: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dGamePack: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dGameCredits: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dArmsDown: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dMusic: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dDance: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dScenes: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dCurves: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dLookAt: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dMorph: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dTimeline: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dLabel: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dEnvironment: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dRender: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dExport: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dViewer: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dCameraKeys: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dShapes: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dGizmo: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dPerf: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dView: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dImport: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dGrid: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dCombine: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dSize: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dMaterial: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dLook: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dOutline: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dLight: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dLights: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dFocus: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dFloor: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dUse: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dMake: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dProject: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dActors: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dGame: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dPlayerStart: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dGameAreas: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dGameRules: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dDesignFile: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    m3dSave: {
        group: "3D mode";
        name: string;
        user: string;
        dev: string;
    };
    labDevelop: {
        group: "Photo lab";
        name: string;
        user: string;
        dev: string;
    };
    labLooks: {
        group: "Photo lab";
        name: string;
        user: string;
        dev: string;
    };
    labTools: {
        group: "Photo lab";
        name: string;
        user: string;
        dev: string;
    };
    labSelect: {
        group: "Photo lab";
        name: string;
        user: string;
        dev: string;
    };
    labEverything: {
        group: "Photo lab";
        name: string;
        user: string;
        dev: string;
    };
    labLayers: {
        group: "Photo lab";
        name: string;
        user: string;
        dev: string;
    };
    labHistory: {
        group: "Photo lab";
        name: string;
        user: string;
        dev: string;
    };
    labFiles: {
        group: "Photo lab";
        name: string;
        user: string;
        dev: string;
    };
    market: {
        group: "Market";
        name: string;
        user: string;
        dev: string;
    };
    marketComps: {
        group: "Market";
        name: string;
        user: string;
        dev: string;
    };
    marketRegions: {
        group: "Market";
        name: string;
        user: string;
        dev: string;
    };
    marketLanded: {
        group: "Market";
        name: string;
        user: string;
        dev: string;
    };
    marketLocalise: {
        group: "Market";
        name: string;
        user: string;
        dev: string;
    };
    marketBootleg: {
        group: "Market";
        name: string;
        user: string;
        dev: string;
    };
    marketSellMore: {
        group: "Market";
        name: string;
        user: string;
        dev: string;
    };
    marketReviews: {
        group: "Market";
        name: string;
        user: string;
        dev: string;
    };
    marketSynonyms: {
        group: "Market";
        name: string;
        user: string;
        dev: string;
    };
    marketPlan: {
        group: "Market";
        name: string;
        user: string;
        dev: string;
    };
};
export type HelpId = keyof typeof HELP;
