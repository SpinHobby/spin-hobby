import { type CSSProperties } from 'react';
/** How far along a slider is, for its filled track (see the range styles in gleamshelf.css). */
export declare const rangeFill: (value: number, min: number, max: number) => CSSProperties;
export declare function Glyph({ name, size }: {
    name: string;
    size?: number;
}): import("react").JSX.Element;
