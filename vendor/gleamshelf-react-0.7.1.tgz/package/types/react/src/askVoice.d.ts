import type { LocalModelClient } from '../../models/src/index.js';
/**
 * Ask's answers said aloud: in the app's voice (Kokoro, the avatar's) when it is set up for the language (English always, Japanese with
 * `npm run voice:setup -- --japanese`), else this computer's own (Kyoko on a Mac, Haruka or Nanami on Windows). Only voices that run on the
 * computer are used: a browser's online voices send the text away, so a language with only those is not spoken.
 */
/** The language a question is written in: Japanese when it has kana or kanji, else English (the two the editors speak). */
export declare const questionLang: (text: string) => "en" | "ja";
/**
 * An answer as it is said: each control code ([c12]) said as the control's name (the model sometimes writes the code alone), unless the
 * words just before it have said the name already ("…「Scenes」ボタンで開きます。[c5]").
 */
export declare function spokenText(answer: string, controls?: {
    id: string;
    label: string;
}[]): string;
/** This computer's voice for a language: one it runs itself, a well-known natural one first; null when it has none. */
export declare function localVoice(lang: 'en' | 'ja', voices: SpeechSynthesisVoice[]): SpeechSynthesisVoice | null;
/** Stops whatever Ask is saying. */
export declare function stopSpeaking(): void;
/**
 * Says `text` in `lang`, stopping what was being said; resolves once it has started, false when there is no voice for the language here.
 * `app` is the Gleamshelf app's client and the languages its voice speaks, when it is set up.
 */
export declare function speak(text: string, lang: 'en' | 'ja', app: {
    client: LocalModelClient;
    langs: ('en' | 'ja')[];
} | null): Promise<boolean>;
