import type { HelpEntry } from './instructions';
/** A word as it is compared: lower case, a plural, -ing, -ed or a last e taken off; Japanese and Chinese text as pairs of characters. */
export declare function words(text: string): string[];
export interface FoundHelp {
    id: string;
    entry: HelpEntry;
    score: number;
}
/**
 * The instructions for a question, best first: its name counts twice its line; the editor's own groups (`prefer`) a little more. `also` adds
 * text to search an entry by (its Japanese, when the editor is in Japanese).
 */
export declare function rankHelp(question: string, help: Record<string, HelpEntry>, { prefer, also, max }?: {
    prefer?: readonly string[];
    also?: (e: HelpEntry) => string;
    max?: number;
}): FoundHelp[];
/** A control on the screen, as the panel and the model see it. */
export interface ScreenControl {
    id: string;
    label: string;
    title: string;
    el: HTMLElement;
}
/** The controls a person can see now, outside `skip` (the panel itself), in page order, at most `max`. */
export declare function screenControls(skip: Element | null, max?: number): ScreenControl[];
/**
 * The controls that fit a question best: their words against the question's (the label counting double), and against the instructions
 * found for it, so "where do I make a character" finds Character even when the question does not name it.
 */
export declare function rankControls(question: string, controls: ScreenControl[], found: FoundHelp[], max?: number): ScreenControl[];
/**
 * An answer cut into its text and the controls it names (written [c12]); a code for no control on the list is left out. The control's name
 * just before its code ("Press Save [c5]") is taken out of the text, as the control's chip shows it.
 */
export declare function answerParts(answer: string, controls: {
    id: string;
    label?: string;
}[]): (string | {
    control: string;
})[];
