import { Editor, type BitmapMask } from '../../core/src/index.js';
import { type ExportOptions } from '../../render2d/src/index.js';
import type { FullReport, GleamResult } from './GleamEditor';
import './gleamshelf.css';
interface WorkspaceProps {
    editor: Editor;
    image: ImageBitmap;
    initialBackground?: Blob | string;
    initialMasks?: Record<string, Blob | string>;
    initialRepairs?: Record<string, Blob | string>;
    initialEnlargements?: Record<string, Blob | string>;
    initialFinishes?: Record<string, Blob | string>;
    localApp?: {
        url?: string;
        token?: string;
    };
    /** The photo as the host gave it (null once the whole chain's picture is open: that one is not sent anywhere). */
    sourceBlob: Blob | null;
    /** Set when the picture open is one the whole chain made: its cut-out mask, and whether it gets a shadow. */
    startFrom: {
        mask: BitmapMask;
        shadow: boolean;
    } | null;
    fullReport: FullReport | null;
    onOpenProcessed: (png: Blob, shadow: boolean, report: FullReport | null) => Promise<void>;
    onBackToOriginal?: () => void;
    /** Opens the picture Edit mode made as a new photo to finish here. */
    onEdited: (png: Blob) => void;
    exportOptions: ExportOptions;
    onDone: (result: GleamResult) => void;
    onCancel?: () => void;
    doneLabel: string;
    handToolsOnly: boolean;
}
export declare function Workspace({ editor, image, initialBackground, initialMasks, initialRepairs, initialEnlargements, initialFinishes, localApp, sourceBlob, startFrom, fullReport, onOpenProcessed, onBackToOriginal, onEdited, exportOptions, onDone, onCancel, doneLabel, handToolsOnly, }: WorkspaceProps): import("react").JSX.Element;
export {};
