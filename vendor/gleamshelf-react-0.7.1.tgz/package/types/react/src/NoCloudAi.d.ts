import { useLocalApp } from './useLocalApp';
/**
 * What an AI control says on a page with no AI of its own (the free website) while the app on this computer is not reached: cloud AI is not
 * available yet, the tool runs free in the app on your own computer, with a link to the step-by-step guide (setLocalAppGuide) and, for people
 * who already run the app, "Look for the app". Renders nothing when no guide is set, so the app's own editor and Spin Hobby's admin keep their
 * own messages.
 */
export declare function NoCloudAi({ app, feature, compact, }: {
    app: ReturnType<typeof useLocalApp>;
    /** The tool, as a person would name it ("The AI cut-out"). */
    feature: string;
    /** One line, for small panels. */
    compact?: boolean;
}): import("react").JSX.Element | null;
