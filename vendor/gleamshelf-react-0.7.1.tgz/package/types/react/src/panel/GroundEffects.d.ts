import { type Editor } from '../../../core/src/index.js';
export declare function GroundEffects({ editor }: {
    editor: Editor;
}): import("react").JSX.Element;
