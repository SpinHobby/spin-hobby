import { type PanelProps } from './types';
/** Paints over white printed lettering inside the cut-out, from the picture's own surroundings. Free, runs here. */
export declare function LetteringSection({ editor, doc, hasCutout, lettering, aiFill, onRemoveLettering }: PanelProps): import("react").JSX.Element;
