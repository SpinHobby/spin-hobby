import { type ShopLinkProps } from './types';
/**
 * Sends the finished run to the shop as a draft in its Imports inbox, where a person types the price and stock and adds it; nothing is published from here.
 * A computer not yet connected is connected first, with the address and code the shop's Imports page shows (Connect the app).
 */
/** The 3D ad card: opens 3D mode's ad maker with this run's cut-out and words. */
export declare function MakeAd({ make }: {
    make: () => Promise<void>;
}): import("react").JSX.Element;
export declare function Make3D({ make }: {
    make: () => Promise<void>;
}): import("react").JSX.Element;
export declare function ShopSend({ shop, runId }: {
    shop: ShopLinkProps;
    runId: string;
}): import("react").JSX.Element;
/** The listing's score and the fixes that matter most, with how sure the cut-out is and how much of the product is still as photographed. */
export declare function ListingHealthCard({ health, quality, changesUrl, }: {
    changesUrl?: string;
    health?: {
        score: number;
        level: 'good' | 'fair' | 'poor';
        checks: {
            id: string;
            ok: boolean;
            label: string;
        }[];
        fixes: string[];
    };
    quality?: {
        cutout: {
            score: number;
            reasons: string[];
        };
        fidelity: {
            original: number;
        };
    };
}): import("react").JSX.Element;
