import { type PanelProps } from './types';
/** What sits behind a cut-out product: nothing, a colour, or a photo the user uploads. Also frames the product on a square. */
export declare function BackdropSection({ editor, doc, onFitProduct, onStudio, listingSet, onBackgroundPhoto, hasBackgroundPhoto, backgroundName, }: PanelProps): import("react").JSX.Element;
