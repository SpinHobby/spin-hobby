import { type PanelProps } from './types';
/** The Background section: cut the product out of its photo. */
export declare function CutoutSection({ editor, doc, cutout, onToggleCutout, cutSettings, onCutSettings, aiCutout, flatten }: PanelProps): import("react").JSX.Element;
