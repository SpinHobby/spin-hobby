import { type PanelProps } from './types';
/** Removes the shop's own price stickers (they go stale the day the price changes) by reading the prices and repainting. */
export declare function StickerSection({ stickers }: {
    stickers: NonNullable<PanelProps['stickers']>;
}): import("react").JSX.Element;
