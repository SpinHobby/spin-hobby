import { type CropAspect, type Editor, type ParamSpec, type ParamValue } from '../../../core/src/index.js';
export declare const ASPECT_LABELS: Record<CropAspect, string>;
export declare function Control({ editor, type, name, spec, value, }: {
    editor: Editor;
    type: string;
    name: string;
    spec: ParamSpec;
    value: ParamValue | undefined;
}): import("react").JSX.Element | null;
/** Controls generated from the op definitions, plus dedicated tools for orientation and crop. */
