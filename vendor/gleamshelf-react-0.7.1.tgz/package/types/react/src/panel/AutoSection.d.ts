import { type PanelProps } from './types';
export declare function AutoSection({ auto, listingSet, hasCutout, }: {
    auto: NonNullable<PanelProps['auto']>;
    listingSet?: PanelProps['listingSet'];
    hasCutout: boolean;
}): import("react").JSX.Element;
