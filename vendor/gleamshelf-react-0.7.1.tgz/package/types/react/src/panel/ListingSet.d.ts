import { type PanelProps } from './types';
/** One click to every marketplace's picture: each preset ticked here, sized and framed its own way, saved together as a zip. */
export declare function ListingSet({ run, busy, note, hasCutout }: NonNullable<PanelProps['listingSet']> & {
    hasCutout: boolean;
}): import("react").JSX.Element;
