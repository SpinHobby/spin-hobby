import { type ExportDetail, type ExportFormat } from '../../../scene3d/src/index.js';
/**
 * Save as a 3D model: GLB for 3D apps, AR and the web; OBJ for 3D apps; STL for 3D printing. The shapes become a surface of triangles
 * (finer detail takes longer), at the real height asked for. Imported models are added as they are.
 */
/** The 3D model files offered: the export's own, and USDZ (for iPhone's AR Quick Look), made from GLB in the browser. */
export type ModelFormat = ExportFormat | 'usdz' | 'rigged' | 'vrm';
/** What a VRM says about itself. */
export interface VrmChoice {
    name: string;
    author: string;
}
export declare function ExportDialog({ onExport, onClose, rigged, }: {
    onExport: (format: ModelFormat, detail: ExportDetail, heightMm: number, vrm: VrmChoice) => void;
    onClose: () => void;
    /** The rigged model that Bones and VRM would save (the one picked, else the first); none hides them. */
    rigged?: {
        name: string;
        person: boolean;
    };
}): import("react").JSX.Element;
