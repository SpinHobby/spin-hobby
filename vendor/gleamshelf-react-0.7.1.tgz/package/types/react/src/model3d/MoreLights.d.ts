import { type ModelDocument, type ModelEditor } from '../../../scene3d/src/index.js';
export declare function MoreLights({ editor, light, gesture, end, }: {
    editor: ModelEditor;
    light: ModelDocument['light'];
    gesture: (label: string) => () => void;
    end: () => void;
}): import("react").JSX.Element;
