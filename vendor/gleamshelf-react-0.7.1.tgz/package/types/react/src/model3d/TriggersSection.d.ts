import { type ModelEditor, type Shape3D, type ShapeRef } from '../../../scene3d/src/index.js';
export declare function TriggersSection({ editor, at, shape, playing, onPlay, }: {
    editor: ModelEditor;
    at: ShapeRef;
    shape: Shape3D;
    playing: boolean;
    onPlay: () => void;
}): import("react").JSX.Element;
