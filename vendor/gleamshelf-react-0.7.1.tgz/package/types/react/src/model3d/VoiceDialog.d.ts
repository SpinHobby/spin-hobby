/**
 * The Voice studio: lines for a game or narration, made without voice actors. Type a line and pick one of the app's voices (Kokoro,
 * made-up voices, none copied from a real person), or say it and keep your voice or change it into one of them; then an effect (higher,
 * deeper, monster, robot, radio, cave, ghost) and a pitch. All on this computer, free. What comes out is a WAV: added to the game's sounds
 * (a Say lines action's voice) or saved.
 */
export declare function VoiceDialog({ initialText, title, onMake, onClose, }: {
    initialText?: string;
    title?: string;
    /** The finished line (a WAV), named after its words. */
    onMake: (file: File) => void;
    onClose: () => void;
}): import("react").JSX.Element;
