import { type ModelDocument } from '../../../scene3d/src/index.js';
/** The design as a USDZ file (for AR Quick Look, and other apps that read USD). */
export declare function designUsdz(doc: ModelDocument, heightMm: number): Promise<Uint8Array>;
/** Whether this browser opens AR Quick Look (Safari on iPhone and iPad). */
export declare const canQuickLook: () => boolean;
/** Whether this browser can place things in the room (WebXR AR, Chrome on Android). */
export declare function canPlaceInRoom(): Promise<boolean>;
/** Opens AR Quick Look with the design (Safari wants a link with a picture in it, clicked). */
export declare function quickLook(doc: ModelDocument, heightMm: number): Promise<void>;
/**
 * Places the design in the room with WebXR: a ring shows where the phone finds a surface, a tap puts the model there (tap again to move
 * it), and Close (or the phone's back) ends it. `overlay` is shown over the camera for the Close button.
 */
export declare function placeInRoom(doc: ModelDocument, heightMm: number, overlay: HTMLElement): Promise<() => void>;
