import { type ModelDocument } from '../../../scene3d/src/index.js';
import { type ReactNode } from 'react';
import './player.css';
export interface ModelPlayerProps {
    /** The 3D design to show (as 3D mode saves it). */
    design: ModelDocument;
    /** Buttons of the host's own, shown in the player's bar (Edit, Copy link, Close...). */
    actions?: ReactNode;
    /** The words on the play button, in the host's language (English when left out). */
    labels?: {
        play: string;
        pause: string;
    };
}
/**
 * A 3D design shown as its viewer sees it, with nothing to edit: it plays (keys, camera moves, motions, over the design's clip), a click or
 * the pointer sets off its shapes' triggers, and dragging turns the view round it (unless the camera has keys). For sharing a design on a
 * page; 3D mode's Play is the same thing while editing.
 */
export declare function ModelPlayer({ design, actions, labels }: ModelPlayerProps): import("react").JSX.Element;
