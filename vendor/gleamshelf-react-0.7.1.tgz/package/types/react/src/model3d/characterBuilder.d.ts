import { type AvatarChoice, type AvatarIndex, type AvatarKit, type PictureCodec } from '../../../scene3d/src/index.js';
/** Pictures read and written with a canvas. */
export declare const canvasCodec: PictureCodec;
/** A kit's character by id, or its first. */
export declare const kitModel: (kit: AvatarKit, id: string | undefined) => import("../../../scene3d/src/index.js").AvatarKitModel;
/**
 * Builds characters from the library's parts (its characters/ folder at `root`): the character creator's preview and what it makes, and
 * 3D mode's Layers panel when a layer is hidden or shown again. Each file is fetched once.
 */
export declare function characterBuilder(root: string): {
    /** The library's characters (index.json). */
    index(): Promise<AvatarIndex>;
    /** The character as a GLB, without any layers it hides, and how big its head is (for the preview's face view). */
    build(c: AvatarChoice): Promise<{
        glb: Uint8Array;
        headSize: number;
    }>;
};
export type CharacterBuilder = ReturnType<typeof characterBuilder>;
/** The builder for a library (its address), one for the page, so the creator and the Layers panel share what they've fetched. */
export declare function charactersAt(base: string): CharacterBuilder;
