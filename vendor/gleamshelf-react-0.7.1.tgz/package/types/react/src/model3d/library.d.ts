import { type ModelDocument } from '../../../scene3d/src/index.js';
export declare function setModelLibrary(url: string | undefined): void;
/** The library's address: a ModelMode prop first, then the host's setting, then the connected app's; undefined for none. */
export declare function libraryAt(prop: string | undefined, app: {
    ready: boolean;
    url?: string;
}): string | undefined;
/** A model in the library (index.json, made by apps/web/scripts/library.ts). */
export interface LibraryItem {
    id: string;
    name: string;
    shelf: string;
    model: string;
    thumb: string;
    /** Its real size in metres (across, up, deep). */
    size: [number, number, number];
    triangles: number;
    bytes: number;
    author: string;
    /** The site or pack it came from (Poly Haven, VRoid, KayKit); Poly Haven when left out. */
    from?: string;
    source: string;
    licence: string;
}
/** A scene to start from: a design whose models are library models, each named by its library id. */
export interface LibraryScene {
    id: string;
    name: string;
    note: string;
    thumb: string;
    design: ModelDocument;
}
export interface LibraryIndex {
    items: LibraryItem[];
    scenes?: LibraryScene[];
}
/**
 * A library scene made a design of its own: each model it names fetched (`read`, by its path in the library) and kept in the design, named
 * with its maker so the credit travels with it.
 */
export declare function openLibraryScene(scene: LibraryScene, items: LibraryItem[], read: (path: string) => Promise<Uint8Array>, 
/** Told as each model is read (done of total), to show how far it is. */
onProgress?: (done: number, total: number) => void): Promise<ModelDocument>;
