import { type ModelDocument, type ModelEditor, type ModelViewport, type Shape3D, type ShapeRef } from '../../../scene3d/src/index.js';
import { type RefObject } from 'react';
/**
 * The Brush section for an imported model: sculpt it (Draw, Inflate, Smooth, Grab) or Paint it, by dragging on it in the view while the
 * brush is on (the view does not turn then; switch the brush off to turn it). A stroke shows as it goes and is kept when the pointer is let
 * go: one undo step, or the morph's other version when "As a morph" is ticked.
 */
export declare function BrushSection({ editor, doc, at, shape, viewRef, stageRef, }: {
    editor: ModelEditor;
    doc: ModelDocument;
    at: ShapeRef;
    shape: Shape3D;
    viewRef: RefObject<ModelViewport | null>;
    stageRef: RefObject<HTMLElement | null>;
}): import("react").JSX.Element | null;
