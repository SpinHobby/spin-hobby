import { type MeshAsset } from '../../../scene3d/src/index.js';
/** The model unwrapped (uvmap.ts) with its look baked into a new PNG a part, `size` pixels square. */
export declare function unwrapModel(asset: MeshAsset, size?: number): Promise<MeshAsset>;
