/**
 * Learn: the tutorials (tutorials.ts) to pick from, by level and topic, and the one being followed: a small card saying what to do, a
 * ring round the control to use, and the next step by itself once this one is done. Opened from Learn in 3D mode, never on its own.
 */
export declare function LearnPanel({ open, onClose }: {
    open: boolean;
    onClose: () => void;
}): import("react").JSX.Element;
