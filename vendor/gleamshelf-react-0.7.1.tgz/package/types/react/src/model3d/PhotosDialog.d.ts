import type { MadeShapeModel, ShapeModelStatus } from '../../../models/src/index.js';
/** What 3D mode opens From photos with: a finished run's cut-out and what was read off its box (to find the maker's photos). */
export interface PhotosStart {
    cutout?: Blob;
    identity?: object | null;
    name?: string;
}
/**
 * Photo to 3D model: the figure's photos (the shop's cut-out, more angles the shop adds, the maker's photos or ones found online) made into a 3D
 * model on this computer, which 3D mode then imports. The person picks the pictures and the model; the model is always marked as generated.
 */
export declare function PhotosDialog({ start, onMade, onClose, }: {
    start?: PhotosStart;
    onMade: (file: File, made: MadeShapeModel, model: ShapeModelStatus) => void;
    onClose: () => void;
}): import("react").JSX.Element;
