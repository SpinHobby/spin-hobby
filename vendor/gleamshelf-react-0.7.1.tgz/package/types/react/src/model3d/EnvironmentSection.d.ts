import type { ModelDocument, ModelEditor } from '../../../scene3d/src/index.js';
/**
 * The Environment section: a picture all round the design (an equirectangular photo of a room, a street, a studio) that lights the
 * photo-real render and shows in its reflections, and can show behind the design there.
 */
export declare function EnvironmentSection({ editor, doc }: {
    editor: ModelEditor;
    doc: ModelDocument;
}): import("react").JSX.Element;
