import { type ModelEditor } from '../../../scene3d/src/index.js';
/**
 * The video editor: strips one after another (parts of the design's clip with a camera move, title cards, pictures), faded into each
 * other, music under them if picked; made into one video. The strips are kept with the design (music is not: pick it each time).
 */
export declare function SequenceDialog({ editor, title, onClose, run, setBusy, }: {
    editor: ModelEditor;
    title: string;
    onClose: () => void;
    run: (label: string, work: () => Promise<void>) => Promise<void>;
    setBusy: (note: string) => void;
}): import("react").JSX.Element;
