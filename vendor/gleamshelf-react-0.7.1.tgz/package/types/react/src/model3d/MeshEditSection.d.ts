import { type MeshAsset, type ModelDocument, type ModelEditor, type Shape3D, type ShapeRef } from '../../../scene3d/src/index.js';
/** A new id for a changed model in the design's assets. */
export declare const modelId: () => string;
/** Puts a changed model in the design in place of a shape's model, refitted so what is left stays where it was: one undo step. */
export declare function replaceModel(editor: ModelEditor, at: ShapeRef, shape: Shape3D, before: MeshAsset, after: MeshAsset, name: string, label: string): void;
/**
 * The Edit the model section for an imported model: smooth it, simplify it (about half the triangles), cut it flat at a height keeping one
 * side (the cut is closed), or turn it inside out. Each is one undo step.
 */
export declare function MeshEditSection({ editor, doc, at, shape, run, }: {
    editor: ModelEditor;
    doc: ModelDocument;
    at: ShapeRef;
    shape: Shape3D;
    /** Runs work with a busy note (and says what went wrong). */
    run: (label: string, work: () => Promise<void>) => Promise<void>;
}): import("react").JSX.Element | null;
