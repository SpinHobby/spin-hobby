import { type ModelDocument } from '../../../scene3d/src/index.js';
/**
 * Photo-real render: light traced through the design (glass bends it, metal and gloss reflect it, glowing finishes give it), the picture
 * sharpening as passes are added; stop at any time and save what is there. Runs on this computer's graphics card.
 */
export declare function RenderDialog({ design, aspect, title, onClose, }: {
    design: ModelDocument;
    /** Width over height of the view, so the render frames what the view shows. */
    aspect: number;
    title: string;
    onClose: () => void;
}): import("react").JSX.Element;
