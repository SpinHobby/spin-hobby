import { type ModelDocument, type ModelEditor, type ShapeRef } from '../../../scene3d/src/index.js';
import './timeline.css';
/**
 * The timeline under the 3D view: the clip from start to end with a mark for the moment being edited, and a row per keyed thing (the camera,
 * each shape or group) with its keys. Click or drag along the top to go to a moment (keyed shapes and the camera are put there); drag a key
 * to move it in time (one undo step); click a key to go to it and pick its shape.
 */
export declare function Timeline({ editor, doc, seconds, time, onTime, onPick, selected, onSeconds, }: {
    editor: ModelEditor;
    doc: ModelDocument;
    seconds: number;
    time: number;
    onTime: (t: number) => void;
    onPick: (ref: ShapeRef) => void;
    /** The picked shape, whose curves the Curves view shows. */
    selected?: ShapeRef | null;
    /** Sets the clip's length. */
    onSeconds: (seconds: number) => void;
}): import("react").JSX.Element;
