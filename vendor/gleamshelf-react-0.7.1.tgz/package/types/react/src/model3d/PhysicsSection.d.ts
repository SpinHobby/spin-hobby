import { type ModelDocument, type ModelEditor } from '../../../scene3d/src/index.js';
/**
 * Drop and stack: the picked shapes fall from where they are onto the floor and the other shapes, worked out once and kept as their keys
 * (so it plays, makes videos and is shared like any animation). Lift them up first; drop again after moving things.
 */
export declare function DropSection({ editor, doc, picked, seconds, }: {
    editor: ModelEditor;
    doc: ModelDocument;
    picked: number[];
    seconds: number;
}): import("react").JSX.Element | null;
/**
 * A cloth draped over the design: a square of cloth let fall from above the picked shape (or the middle) settles over the shapes and onto
 * the floor, and is added as an imported model (one undo step). Imported models do not hold it up; the shapes and the floor do.
 */
export declare function ClothSection({ editor, doc, picked, run, }: {
    editor: ModelEditor;
    doc: ModelDocument;
    picked: number | null;
    run: (label: string, work: () => Promise<void>) => Promise<void>;
}): import("react").JSX.Element;
/** Effects at the picked shape (or the middle), while it plays: confetti, sparkles, smoke, a flame, or a liquid pouring down. */
export declare function EffectsSection({ editor, doc, picked }: {
    editor: ModelEditor;
    doc: ModelDocument;
    picked: number | null;
}): import("react").JSX.Element;
