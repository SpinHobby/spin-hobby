/**
 * Where in 3D mode it is, for a host that gives each its own address (the website's /3d/game): '' the Shape tab, 'light' and 'game' the
 * other tabs, or a tool open over them: the tutorials, the 3D library, the ready-made scenes, the character creator, the photo-real render
 * and the Voice studio. Kept apart from ModelMode so a host can read an address without loading 3D.
 */
export declare const MODEL_PLACES: readonly ["", "light", "game", "learn", "library", "scenes", "character", "render", "voice"];
export type ModelPlace = (typeof MODEL_PLACES)[number];
/** The place an address's part names ('' for none it knows). */
export declare const modelPlace: (part: string) => ModelPlace;
