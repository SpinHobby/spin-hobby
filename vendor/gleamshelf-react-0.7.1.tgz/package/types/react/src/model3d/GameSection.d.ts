import { type ModelDocument, type ModelEditor, type Shape3D } from '../../../scene3d/src/index.js';
import { type ReactNode } from 'react';
import type { ProjectApi } from './useGameProject';
/**
 * The Game tab: the design as a game level, the way a game engine's editor sets one up (game.ts). The project of levels and characters
 * (`projectPanel`), where the player starts, what the picked shape is to the player (solid, walked through, an invisible trigger area, or a
 * placed character), and the rules: When something happens, If and Unless flags, numbers and items it Needs, Do these actions.
 */
export declare function GameSection({ editor, doc, selected, onPlay, project, projectPanel, }: {
    editor: ModelEditor;
    doc: ModelDocument;
    selected: Shape3D | null;
    onPlay: () => void;
    project: ProjectApi | null;
    projectPanel: ReactNode;
}): import("react").JSX.Element;
