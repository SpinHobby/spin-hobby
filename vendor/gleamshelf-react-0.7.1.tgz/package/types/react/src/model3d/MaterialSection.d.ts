import { type ModelDocument, type ModelEditor, type ModelViewport, type Shape3D, type ShapeRef } from '../../../scene3d/src/index.js';
import { type RefObject } from 'react';
/**
 * The Material section for an imported model: pick one of its materials (from the list, or by clicking the model), give it a shader of its
 * own (physical, toon, flat, clay or unlit) or a ready-made material (metal, gold, car paint, velvet, glass, neon…), and set its colour,
 * roughness, metal, glow, clear coat, sheen, glass and bumps. A slider shows as it is dragged and is kept when let go (one undo step). The
 * Draw section paints these over the model where they should differ (roughness, metal, glow, bumps, clear coat, holes).
 */
export declare function MaterialSection({ editor, doc, at, shape, viewRef, stageRef, }: {
    editor: ModelEditor;
    doc: ModelDocument;
    at: ShapeRef;
    shape: Shape3D;
    viewRef: RefObject<ModelViewport | null>;
    stageRef: RefObject<HTMLElement | null>;
}): import("react").JSX.Element | null;
