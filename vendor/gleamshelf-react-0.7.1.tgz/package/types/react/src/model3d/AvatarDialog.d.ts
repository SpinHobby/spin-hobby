import { type AvatarChoice } from '../../../scene3d/src/index.js';
/**
 * The character creator: an anime character put together from the library's VRoid characters (pixiv's CC0 samples) by picking pictures:
 * an outfit (a body), a face (its eyes) and an expression, hair, the body's shape, and colours for hair, eyes, skin and clothes. The preview
 * follows every change (drag it to turn it round); the character comes out as one model, ready to pose with Animations.
 */
export declare function AvatarDialog({ base, forGame, start, startTab, onMake, onClose, }: {
    /** The library's address (its characters/ folder holds the parts); none says where the characters come from instead. */
    base: string | undefined;
    /** Made for a game project (one button: add it to the game's characters). */
    forGame?: boolean;
    /** A character already made, to change (its recipe from the design): the creator opens on it, at `startTab`, and offers Update character. */
    start?: AvatarChoice;
    startTab?: string;
    /** `replace`: the character being changed, in place. `choice` is the recipe, kept with the model so it can be changed again. */
    onMake: (file: File, into: 'design' | 'new' | 'replace', note: string, choice: AvatarChoice) => void;
    onClose: () => void;
}): import("react").JSX.Element;
