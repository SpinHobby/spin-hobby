import { type Shape3D } from '../../../scene3d/src/index.js';
export declare function CopiesSection({ shape, update, gesture, end, }: {
    shape: Shape3D;
    update: (patch: Partial<Shape3D>, label?: string) => void;
    gesture: (label: string) => () => void;
    end: () => void;
}): import("react").JSX.Element;
