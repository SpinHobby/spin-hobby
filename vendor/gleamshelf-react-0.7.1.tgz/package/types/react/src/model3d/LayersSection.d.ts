import { type ModelDocument, type ModelEditor, type Shape3D, type ShapeRef } from '../../../scene3d/src/index.js';
/**
 * Layers for a character made in the character creator (a model whose design keeps its recipe, ModelAsset.character): hide or show its hair,
 * face or body, or open the creator on one layer to change it; the character is rebuilt and swapped in where it stands.
 */
export declare function LayersSection({ editor, doc, at, shape, base, run, onEdit, }: {
    editor: ModelEditor;
    doc: ModelDocument;
    at: ShapeRef;
    shape: Shape3D;
    /** The library's address, where the characters' parts are. */
    base: string | undefined;
    run: (label: string, work: () => Promise<void>) => Promise<void>;
    /** Opens the creator on this character, at a tab. */
    onEdit: (tab: string) => void;
}): import("react").JSX.Element | null;
