import { type ModelDocument, type ModelEditor, type ModelViewport, type Shape3D, type ShapeRef } from '../../../scene3d/src/index.js';
import { type RefObject } from 'react';
/**
 * Edit points, edges and faces of an imported model (Blender's edit mode). With picking on, a click on the model picks the point, edge or
 * flat face under it (click more to add; a picked point clicked again is let go) and the view marks them. The sliders move, grow and turn
 * what is picked, shown as they go and kept on letting go; the buttons push faces out, inset them, delete, merge, fill or cut a loop. Each
 * change is one undo step.
 */
export declare function ElementsSection({ editor, doc, at, shape, viewRef, stageRef, run, }: {
    editor: ModelEditor;
    doc: ModelDocument;
    at: ShapeRef;
    shape: Shape3D;
    viewRef: RefObject<ModelViewport | null>;
    stageRef: RefObject<HTMLElement | null>;
    /** Runs work with a busy note (and says what went wrong). */
    run: (label: string, work: () => Promise<void>) => Promise<void>;
}): import("react").JSX.Element | null;
