export declare const TUTORIAL_LEVELS: readonly ["beginner", "intermediate", "advanced"];
export type TutorialLevel = (typeof TUTORIAL_LEVELS)[number];
export declare const TUTORIAL_LEVEL_LABEL: Record<TutorialLevel, string>;
export type TutorialTopic = '3d' | 'voice';
export declare const TUTORIAL_TOPIC_LABEL: Record<TutorialTopic, string>;
/**
 * A control on the page: a CSS selector, and/or the text it shows (exactly), and/or how its tooltip or label starts, looked for within
 * `within` when given. Text and labels are the English ones, in any language (i18n/translate.ts knows what each said): never write them
 * into `css`, which sees the words on the screen.
 */
export interface TutorialTarget {
    css?: string;
    text?: string;
    label?: string;
    within?: string;
}
export interface TutorialStep {
    say: string;
    point?: TutorialTarget;
    /** Done when this is on the page (a dialog opened), or no longer is (it closed); left out, the Next button moves on. */
    until?: {
        shows: TutorialTarget;
    } | {
        hides: TutorialTarget;
    };
}
export interface Tutorial {
    id: string;
    level: TutorialLevel;
    topic: TutorialTopic;
    title: string;
    blurb: string;
    minutes: number;
    steps: TutorialStep[];
}
export declare const TUTORIALS: Tutorial[];
/** Where a target is on the page now: the first matching element that is shown, or null. */
export declare function findTarget(t: TutorialTarget, root?: ParentNode): HTMLElement | null;
/** Whether a step is done (null: it moves on with Next). */
export declare function stepDone(step: TutorialStep, root?: ParentNode): boolean | null;
