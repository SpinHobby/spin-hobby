import { type ModelEditor } from '../../../scene3d/src/index.js';
/**
 * Scripts: Python that changes the open design (import gleamshelf: shapes, add, change, remove, key, light, camera, clip, background), each
 * change checked like any edit and the whole run one undo step. Python runs in this browser; the first run fetches it (about 10 MB).
 */
export declare function ScriptDialog({ editor, onClose }: {
    editor: ModelEditor;
    onClose: () => void;
}): import("react").JSX.Element;
