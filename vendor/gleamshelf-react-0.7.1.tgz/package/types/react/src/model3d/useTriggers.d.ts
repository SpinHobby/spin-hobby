import { type ModelEditor, type ModelViewport, type Running, type ShapeRef } from '../../../scene3d/src/index.js';
import { type RefObject } from 'react';
/**
 * Click and hover triggers while a design plays live: a click on a shape (or the group it is in) with a click reaction starts it, and the
 * pointer coming over one with a hover reaction starts that; each plays once. `at` gives the reactions running at a moment, for animate.
 */
export declare function useTriggers(stageRef: RefObject<HTMLElement | null>, viewRef: RefObject<ModelViewport | null>, editor: ModelEditor, playing: boolean): {
    /** A click on `ref` while playing: starts its click reaction, if it has one. */
    click: (ref: ShapeRef | null) => void;
    /** The reactions running at `now` (performance.now()), each with how far through it is; finished ones are dropped. */
    at: (now: number) => Map<string, Running>;
};
