import { type ModelEditor, type ModelViewport } from '../../../scene3d/src/index.js';
import type { ProjectApi } from './useGameProject';
/**
 * Play game: the design walked through in first person, its rules running (GameRun, packages/scene3d/src/model/gamerun.ts), drawn by the 3D view
 * as a moving frame whose camera is the player's eyes.
 * Click to take the mouse; WASD (or the arrows) walk, the mouse looks, E (or Space, or a click) uses what is in the middle of the view and
 * goes on to the next line, 1 to 4 answer; Esc lets go of the mouse. In a project, "Go to a level" opens that level and play goes on there,
 * with the flags, numbers and items the player has; the rules' sounds, voices and music come from the project.
 */
export declare function GamePlay({ editor, viewport, onStop, project, }: {
    editor: ModelEditor;
    viewport: ModelViewport;
    onStop: () => void;
    project: Pick<ProjectApi, 'project' | 'open'> | null;
}): import("react").JSX.Element;
