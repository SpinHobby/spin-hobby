import type { ModelEditor, Shape3D, ShapeRef } from '../../../scene3d/src/index.js';
import type { ProjectApi } from './useGameProject';
/**
 * The Game tab's project (useGameProject): a game of several levels and characters in one file. Levels and characters open in 3D mode one at a
 * time; characters are placed in levels; sounds and music are kept for the rules to play.
 */
export declare function ProjectSection({ api, libraryUrl, onStart, onOpen, run, editor, selected, shape, takePicture, }: {
    api: ProjectApi | null;
    /** 3D mode's finished picture of the view, for the romance's portraits, backgrounds and illustrations. */
    takePicture: () => Promise<Blob>;
    editor: ModelEditor;
    selected: ShapeRef | null;
    shape: Shape3D | null;
    /** The 3D library's address: new characters come from its character creator (else they are built of shapes). */
    libraryUrl?: string | null;
    onStart: (title: string) => void;
    onOpen: (file: File) => void;
    run: (label: string, work: () => Promise<void>) => Promise<void>;
}): import("react").JSX.Element;
