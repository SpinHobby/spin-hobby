import { type ModelDocument, type ModelEditor, type Shape3D, type ShapeRef } from '../../../scene3d/src/index.js';
/**
 * Animations for an imported figure (Mixamo's way): pick a move (walk, run, wave, dance, punch, sit…) and it plays at once, baked into the
 * model's keys over the clip; a model with no bones gets a figure rig first. The sliders (speed, energy, arm space and the move's own) and
 * the Mirror and In place switches bake it again when let go, so the move can be tuned while it plays. A person's own bones take the moves as they
 * are. From a file: a clip from a file (Mixamo's FBX, a GLB, motion capture's BVH) goes on the figure, however its bones are named, and plays as a take.
 */
export declare function AnimationSection({ editor, doc, at, shape, seconds, onPlay, onClip, }: {
    editor: ModelEditor;
    doc: ModelDocument;
    at: ShapeRef;
    shape: Shape3D;
    /** The clip's length: the move loops to fill it. */
    seconds: number;
    /** Starts the preview, so the move shows as soon as it is picked. */
    onPlay: () => void;
    /** Says the clip's length changed (a take fits the clip to itself). */
    onClip: (seconds: number) => void;
}): import("react").JSX.Element | null;
