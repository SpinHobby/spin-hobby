import { type ModelEditor, type Shape3D, type ShapeRef } from '../../../scene3d/src/index.js';
/**
 * The Form section of 3D mode's panel: detail past the plain solids. Hollow leaves a shell (cut it open with a box set to Cut to see inside,
 * or print it with less material); Twist turns it more towards its top; Bend curves it across; Taper narrows or widens its top.
 */
export declare function FormSection({ editor, at, shape }: {
    editor: ModelEditor;
    at: ShapeRef;
    shape: Shape3D;
}): import("react").JSX.Element;
