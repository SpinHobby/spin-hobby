import { type ModelDocument, type ModelEditor, type ModelViewport } from '../../../scene3d/src/index.js';
import { type RefObject } from 'react';
/**
 * The compositor: finishing touches for the photo-real render, saved pictures and videos (not the working view). Preview shows the view as
 * it will be finished.
 */
export declare function CompositorSection({ editor, doc, viewRef, }: {
    editor: ModelEditor;
    doc: ModelDocument;
    viewRef: RefObject<ModelViewport | null>;
}): import("react").JSX.Element;
