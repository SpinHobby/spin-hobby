import { type ModelDocument } from '../../../scene3d/src/index.js';
import { type AdStart } from './AdDialog';
import { type PhotosStart } from './PhotosDialog';
import type { ModelPlace } from './places';
import './model3d.css';
/**
 * 3D mode: build a 3D design from simple shapes, outlines and text, joined, cut and softly blended (and grouped), then light it, give it a look, and
 * place it in a 2D design as a picture, or save it as a picture, an SVG of flat regions, or a short video. The design is a ModelDocument
 * (packages/scene3d/src/model), drawn live by ray marching.
 */
export interface ModelModeProps {
    /** A design to reopen (from a 3D layer, or made from a layer's outline); a new one with a single box when left out. */
    open?: ModelDocument | null;
    title?: string;
    /** The finished picture (PNG, transparent where there is nothing) and the design, to keep beside it. */
    onDone?: (picture: Blob, design: ModelDocument) => void;
    doneLabel?: string;
    onClose: () => void;
    /** Pixel size of the finished picture (long side). */
    renderSize?: number;
    /** Opens with the 3D ad dialog, filled in (a finished run's cut-out, title and series). */
    ad?: AdStart;
    /** Opens with From photos (a 3D model of the figure made from photos), with a finished run's cut-out and what was read off its box. */
    photos?: PhotosStart;
    /** The host's own buttons in the top bar (the website's View), each given the design as it is now. */
    actions?: {
        label: string;
        title?: string;
        run: (design: ModelDocument) => void;
    }[];
    /** Where the 3D library is (a folder with index.json, made by apps/web/scripts/library.ts); else setModelLibrary's, else the app's. */
    library?: string;
    /** Where to be (an address's part, Back and Forward): it opens there, and goes there when it changes. */
    place?: ModelPlace;
    /** Told each time the place changes (a tab picked, a tool opened or closed), to keep an address in step. */
    onPlace?: (place: ModelPlace) => void;
}
export declare function ModelMode({ open, title, onDone, doneLabel, onClose, renderSize, ad, photos, actions, library, place, onPlace, }: ModelModeProps): import("react").JSX.Element;
