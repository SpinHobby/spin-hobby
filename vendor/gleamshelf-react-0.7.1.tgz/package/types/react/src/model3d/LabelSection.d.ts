import { type ModelDocument, type ModelEditor, type Shape3D, type ShapeRef } from '../../../scene3d/src/index.js';
/**
 * The Label section of 3D mode's panel: a picture on the shape, as a sticker on a box (front, back or top) or a label wrapped round a bottle,
 * at a size and place on that face.
 */
export declare function LabelSection({ editor, doc, at, shape }: {
    editor: ModelEditor;
    doc: ModelDocument;
    at: ShapeRef;
    shape: Shape3D;
}): import("react").JSX.Element;
