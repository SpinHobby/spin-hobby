import { type ModelEditor, type Shape3D, type ShapeRef } from '../../../scene3d/src/index.js';
import type { ProjectApi } from './useGameProject';
/**
 * The Game tab's tools for finishing a game: what a shape is, checking the project, whether it fits a device, surfaces, credits, a cast sheet, voices
 * for its lines, and the pack a game engine reads. All of it runs in this page, except voices, which need the local app.
 */
export declare function GamePackSection({ api, editor, selected, shape, libraryUrl, run, }: {
    api: ProjectApi;
    editor: ModelEditor;
    selected: ShapeRef | null;
    shape: Shape3D | null;
    libraryUrl?: string | null;
    run: (label: string, work: () => Promise<void>) => Promise<void>;
}): import("react").JSX.Element;
