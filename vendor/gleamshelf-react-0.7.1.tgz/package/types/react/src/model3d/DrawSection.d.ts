import { type ModelDocument, type ModelEditor, type ModelViewport, type Shape3D, type ShapeRef } from '../../../scene3d/src/index.js';
import { type RefObject } from 'react';
/**
 * The Draw section for an imported model: draw on its pictures with a pen, an eraser or a softener, to refine what it looks like (eyes,
 * lashes, makeup, a pattern on a dress). Drawing on, a drag on the model draws (a pen's pressure sets the line's width and strength); Alt
 * and a click, or Pick a colour, takes a colour off the model. Strokes show as they go and can be taken back one by one (Undo stroke, or
 * Ctrl+Z while drawing); Done keeps them all in the design as one undo step.
 */
export declare function DrawSection({ editor, doc, at, shape, viewRef, stageRef, }: {
    editor: ModelEditor;
    doc: ModelDocument;
    at: ShapeRef;
    shape: Shape3D;
    viewRef: RefObject<ModelViewport | null>;
    stageRef: RefObject<HTMLElement | null>;
}): import("react").JSX.Element | null;
