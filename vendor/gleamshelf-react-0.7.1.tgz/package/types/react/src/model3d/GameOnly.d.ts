import { type GameProject } from '../../../scene3d/src/index.js';
import './model3d.css';
/** The game alone, with no editor round it: what a game saved for the web shows (apps/web/play). */
export declare function GameOnly({ game }: {
    game: GameProject | unknown;
}): import("react").JSX.Element;
