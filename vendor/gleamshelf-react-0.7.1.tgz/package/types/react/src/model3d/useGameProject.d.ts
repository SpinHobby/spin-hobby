import { type CharacterOptions, type GameAchievement, type Romance, type GameProject, type ModelEditor } from '../../../scene3d/src/index.js';
export type EntryKind = 'level' | 'character';
export interface ProjectApi {
    project: GameProject;
    /** What 3D mode is editing now. */
    current: {
        kind: EntryKind;
        id: string;
    };
    /** The project with the design being edited put back in it. */
    synced: () => GameProject;
    open: (kind: EntryKind, id: string) => void;
    addLevel: (copy: boolean) => void;
    addCharacter: (options: CharacterOptions) => void;
    /** A character that is one model (the character creator's GLB), opened standing in its own design. */
    addCharacterModel: (name: string, file: File) => Promise<void>;
    rename: (kind: EntryKind, id: string, name: string) => void;
    remove: (kind: EntryKind, id: string) => void;
    setStart: (id: string) => void;
    setTitle: (title: string) => void;
    setCredits: (credits: string) => void;
    setAchievements: (achievements: GameAchievement[]) => void;
    /** The romance story (romance.ts); undefined takes it out. */
    setRomance: (romance: Romance | undefined) => void;
    addSound: (file: File) => Promise<string>;
    removeSound: (id: string) => void;
    /** The whole project replaced by a changed copy of it (lightened models, voiced lines), and what's being edited reopened from it. */
    adopt: (project: GameProject) => void;
    /** Places a character in the level being edited: baked into a model there, and a game actor. */
    place: (characterId: string) => Promise<void>;
    save: () => void;
    close: () => void;
}
/**
 * A game project open in 3D mode (project.ts): its levels and characters, the one being edited in the editor. Switching keeps the design being
 * left in the project, so nothing is lost; Save project writes it all as one .json.
 */
export declare function useGameProject(editor: ModelEditor, onError: (message: string) => void): {
    api: ProjectApi | null;
    start: (title: string) => void;
    load: (text: string) => void;
};
