import { type ModelDocument, type ModelEditor, type ShapeRef } from '../../../scene3d/src/index.js';
/**
 * The curve editor: one number of the picked shape's keys over the clip, drawn as it really goes (ease and curved paths included), each key
 * a dot to drag up and down (its value) or along (its time). One undo step per drag.
 */
export declare function Curves({ editor, doc, at, seconds, time, }: {
    editor: ModelEditor;
    doc: ModelDocument;
    at: ShapeRef | null;
    seconds: number;
    time: number;
}): import("react").JSX.Element;
