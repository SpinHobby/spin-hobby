import { type ModelDocument, type ModelEditor, type Shape3D, type ShapeRef } from '../../../scene3d/src/index.js';
/**
 * Still poses for a figure: a click holds it in a moment of a move (standing, waving, sitting…) with no animation playing — for a
 * promo picture, a thumbnail or a scene. A pose the person set up by hand (Bones, or a tuned move) can be kept by name and struck
 * again later, on this figure or another with the same bones. Applying a pose removes the animation; the Animations list brings
 * movement back.
 */
export declare function PoseSection({ editor, doc, at, shape }: {
    editor: ModelEditor;
    doc: ModelDocument;
    at: ShapeRef;
    shape: Shape3D;
}): import("react").JSX.Element | null;
