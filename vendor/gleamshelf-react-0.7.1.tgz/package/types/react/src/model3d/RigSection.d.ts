import { type ModelDocument, type ModelEditor, type ModelViewport, type Shape3D, type ShapeRef } from '../../../scene3d/src/index.js';
import { type RefObject } from 'react';
/**
 * The Rig section for an imported model (Blender's armature): add a figure's bones (or a simple chain), then pose it by turning a bone's
 * sliders or by dragging a bone's tip in the view with Reach on (the bone and the one above it turn to follow). The bones are drawn over the
 * view. Keys keep the pose, so a figure can move over the clip.
 */
export declare function RigSection({ editor, doc, at, shape, viewRef, stageRef, }: {
    editor: ModelEditor;
    doc: ModelDocument;
    at: ShapeRef;
    shape: Shape3D;
    viewRef: RefObject<ModelViewport | null>;
    stageRef: RefObject<HTMLElement | null>;
}): import("react").JSX.Element | null;
