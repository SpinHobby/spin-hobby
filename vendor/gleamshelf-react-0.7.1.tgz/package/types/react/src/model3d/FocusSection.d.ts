import { type ModelDocument, type ModelEditor, type Shape3D } from '../../../scene3d/src/index.js';
/** Depth of field: a blur that grows away from the distance in focus, as through a camera's lens (scene3d focus.ts). */
export declare function FocusSection({ editor, camera, shape, gesture, end, }: {
    editor: ModelEditor;
    camera: ModelDocument['camera'];
    /** The picked shape, to focus on. */
    shape: Shape3D | undefined;
    gesture: (label: string) => () => void;
    end: () => void;
}): import("react").JSX.Element;
