import type { ModelDocument } from '../../../scene3d/src/index.js';
import { type LibraryItem, type LibraryScene } from './library';
export type { LibraryItem, LibraryScene } from './library';
/**
 * The 3D library: ready-made models (anime and other characters, people, animals, furniture, plants, decor, gadgets, food, Halloween and
 * game pieces) to put into the design with one click. They come from the folder at `base` (the website keeps them in public/library), all
 * free to use in anything sold: CC0 (Poly Haven, pixiv's VRoid samples, KayKit, Quaternius) or the VRM Public License (two VRM samples).
 */
export declare function LibraryDialog({ base, onPick, onClose, }: {
    base: string;
    /** The model's file and its name; the dialog stays open while it is added. */
    onPick: (file: File, item: LibraryItem) => Promise<void>;
    onClose: () => void;
}): import("react").JSX.Element;
/**
 * Scenes to start from: ready-made designs of library models (a figure shelf, an anime cast, a café table…). Picking one fetches its
 * models and hands the design over, to open in place of this one.
 */
export declare function ScenesDialog({ base, onOpen, onClose, }: {
    base: string;
    onOpen: (design: ModelDocument, scene: LibraryScene) => void;
    onClose: () => void;
}): import("react").JSX.Element;
