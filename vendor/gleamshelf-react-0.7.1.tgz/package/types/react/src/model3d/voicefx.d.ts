/**
 * Voice effects for game lines and narration, worked out on the sound itself (no server, free): a voice made higher or deeper without
 * changing its speed (a time stretch by overlapping grains, then played faster or slower), and characters' sounds: robot, radio, cave,
 * ghost, monster. Sounds are mono samples (-1 to 1) at their own rate; WAVs are read and written here too.
 */
export interface Sound {
    samples: Float32Array;
    rate: number;
}
export declare const VOICE_EFFECTS: readonly ["none", "cute", "deep", "monster", "robot", "radio", "cave", "ghost"];
export type VoiceEffect = (typeof VOICE_EFFECTS)[number];
export declare const VOICE_EFFECT_LABEL: Record<VoiceEffect, string>;
/** A WAV's sound (16-bit or float PCM), its channels mixed to one. */
export declare function readWav(buffer: ArrayBuffer): Sound;
/** A sound as a 16-bit mono WAV. */
export declare function writeWav({ samples, rate }: Sound): ArrayBuffer;
/**
 * The sound made `factor` times as long without changing its pitch: grains of it laid over each other at a new spacing, each placed
 * where it best continues the one before (WSOLA), so the voice stays smooth.
 */
export declare function stretch(x: Float32Array, rate: number, factor: number): Float32Array;
/** A sound at another rate (a microphone's 48 kHz kept at 24 kHz: plenty for a voice, half the size). */
export declare function toRate(s: Sound, rate: number): Sound;
/** The voice made higher (semitones above 0) or deeper (below), at the same speed. */
export declare function pitchShift(x: Float32Array, rate: number, semitones: number): Float32Array;
/** The sound with an effect and a pitch change (semitones; 0 none), its loudest point brought just under full. */
export declare function applyVoiceEffect({ samples, rate }: Sound, effect: VoiceEffect, semitones?: number): Sound;
