import { type Compose3D } from '../../../scene3d/src/index.js';
/** A picture finished by the compositor (compose.ts) as a PNG; the picture as it was when there is nothing to do. */
export declare function composed(picture: Blob | HTMLCanvasElement, compose: Compose3D | undefined): Promise<Blob>;
