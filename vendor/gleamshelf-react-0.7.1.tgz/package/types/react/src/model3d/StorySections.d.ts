import { type GameSetup, type ModelDocument, type ModelEditor } from '../../../scene3d/src/index.js';
type Put = (next: GameSetup, label: string) => void;
type Choice = {
    id: string;
    label: string;
};
/** Each character's day as a bar, and their blocks to edit. */
export declare function RoutineSection({ game, put, shapes, spots, }: {
    game: GameSetup;
    put: Put;
    shapes: readonly Choice[];
    spots: readonly Choice[];
}): import("react").JSX.Element;
/** Camera shots with names: saved from the view, gone back to, used by rules. */
export declare function ShotSection({ game, put, doc, editor }: {
    game: GameSetup;
    put: Put;
    doc: ModelDocument;
    editor: ModelEditor;
}): import("react").JSX.Element;
/** Quests: steps in order, each a thing to do and what's said when it's done. */
export declare function QuestSection({ game, put, shapes }: {
    game: GameSetup;
    put: Put;
    shapes: readonly Choice[];
}): import("react").JSX.Element;
/** What's wrong with this level's routines and quests, right where they're edited. */
export declare function StoryWarnings({ doc, game }: {
    doc: ModelDocument;
    game: GameSetup;
}): import("react").JSX.Element | null;
/** The sky at a moment as a picture a design can keep behind everything (its background picture). */
export declare function skyPicture(minute: number, drift?: number): string;
/**
 * Time of day: how the level looks at any minute of its day, as it will in play (daylight.ts), and whether play moves the sun with its clock.
 * Lighting the level for a time is one change, undone like any other.
 */
export declare function DaylightSection({ game, put, doc, editor }: {
    game: GameSetup;
    put: Put;
    doc: ModelDocument;
    editor: ModelEditor;
}): import("react").JSX.Element;
/**
 * Films: saved shots one after another, each glided to or cut to, for an opening or a cutscene. Preview plays it in the view; a camera action
 * plays it in the game, and story.json hands it to a game engine.
 */
export declare function FilmSection({ game, put, editor }: {
    game: GameSetup;
    put: Put;
    editor: ModelEditor;
}): import("react").JSX.Element | null;
export {};
