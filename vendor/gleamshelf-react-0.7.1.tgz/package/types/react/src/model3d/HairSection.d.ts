import { type ModelDocument, type ModelEditor, type Shape3D, type ShapeRef } from '../../../scene3d/src/index.js';
/** Hair and fur for an imported model: strands grown over it (or only on its top), long or short, standing or hanging, straight or curly. */
export declare function HairSection({ editor, doc, at, shape, run, }: {
    editor: ModelEditor;
    doc: ModelDocument;
    at: ShapeRef;
    shape: Shape3D;
    run: (label: string, work: () => Promise<void>) => Promise<void>;
}): import("react").JSX.Element | null;
