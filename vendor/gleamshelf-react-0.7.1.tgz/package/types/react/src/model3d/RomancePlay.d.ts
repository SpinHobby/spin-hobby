import { type GameSoundFile, type Romance } from '../../../scene3d/src/index.js';
/**
 * A romance story played as the game will play it (RomanceRun, romance.ts): the background, who stands where with which face, the speaker's name in
 * her colour, the line, the choices, and the ending with the Made with Gleamshelf line. Click, Space or Enter goes on; 1-6 pick a choice; Esc closes.
 * Language, rating and the affection meters are for testing the story.
 */
export declare function RomancePlay({ story, sounds, onClose }: {
    story: Romance;
    sounds: Record<string, GameSoundFile>;
    onClose: () => void;
}): import("react").JSX.Element;
