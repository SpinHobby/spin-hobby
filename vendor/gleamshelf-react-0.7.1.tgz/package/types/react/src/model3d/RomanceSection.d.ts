import { type GameAchievement, type GameCharacter, type GameSoundFile, type Romance } from '../../../scene3d/src/index.js';
export declare function RomanceSection({ story, onChange, title, characters, achievements, sounds, takePicture, run, }: {
    story: Romance | undefined;
    onChange: (story: Romance | undefined) => void;
    title: string;
    characters: GameCharacter[];
    achievements: GameAchievement[];
    sounds: Record<string, GameSoundFile>;
    /** 3D mode's finished picture of the view (see-through when the background is). */
    takePicture: () => Promise<Blob>;
    run: (label: string, work: () => Promise<void>) => Promise<void>;
}): import("react").JSX.Element;
