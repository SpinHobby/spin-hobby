import { type ModelDocument, type ModelEditor, type Shape3D, type ShapeRef } from '../../../scene3d/src/index.js';
import './keys.css';
/** What the keys are for: a shape, or the camera. */
export type KeysTarget = {
    kind: 'shape';
    at: ShapeRef;
    shape: Shape3D;
} | {
    kind: 'camera';
    doc: ModelDocument;
};
/** Puts every keyed shape, and the camera when it has keys, where their keys say at `t` (merged into the open gesture). */
export declare function showMoment(editor: ModelEditor, t: number): void;
export declare function KeysSection({ editor, target, seconds, onSeconds, time, onTime, playing, onPlay, }: {
    editor: ModelEditor;
    target: KeysTarget;
    /** How long the clip is, and how to change it (keys stay at the same share of it). */
    seconds: number;
    onSeconds: (seconds: number) => void;
    /** The moment being edited, 0-1 of the clip. */
    time: number;
    onTime: (time: number) => void;
    playing: boolean;
    onPlay: () => void;
}): import("react").JSX.Element;
