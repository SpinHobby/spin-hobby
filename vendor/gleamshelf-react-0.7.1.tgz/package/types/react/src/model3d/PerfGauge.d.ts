import type { ModelViewport } from '../../../scene3d/src/index.js';
/** Whether the gauge was on last time (kept in the browser; a private window starts with it off). */
export declare function perfGaugeWasOn(): boolean;
export declare function keepPerfGauge(on: boolean): void;
/**
 * The performance gauge: a small panel in the view's corner, read four times a second from the view (ModelViewport.stats). Frames a second
 * and their time while something moves, the resolution drawn (dynamic resolution lowers it while moving), what this computer manages, what
 * is drawn, and the graphics card. Turned on and off with P or View > Performance; it lets clicks through to the view.
 */
export declare function PerfGauge({ viewport }: {
    viewport: () => ModelViewport | null;
}): import("react").JSX.Element | null;
