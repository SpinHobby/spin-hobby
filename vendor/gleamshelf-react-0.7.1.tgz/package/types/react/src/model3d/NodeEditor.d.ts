import { type ModelDocument, type ModelEditor, type NodeGraph, type Shape3D, type ShapeRef } from '../../../scene3d/src/index.js';
/**
 * A node editor: boxes on a canvas joined by wires. Drag a box by its title; drag from a box's right dot to another's left dot to wire them
 * (a dot that does not fit will not take it); click a left dot to unwire it. Each box's settings are in it.
 */
export declare function NodeEditor({ initial, shapes, done, onDone, onClose, }: {
    initial: NodeGraph;
    /** The shapes a geometry graph can copy (id and name). */
    shapes: {
        id: string;
        name: string;
    }[];
    /** The finishing button's words. */
    done: string;
    onDone: (graph: NodeGraph) => void;
    onClose: () => void;
}): import("react").JSX.Element;
/**
 * The Nodes section: for a shape, copies of it placed by geometry nodes (made into one model that keeps its graph; the shape copied is
 * hidden); for a model made by nodes, its nodes to change and make again; for an imported model, a colour worked out by material nodes.
 */
export declare function NodesSection({ editor, doc, at, shape, run, }: {
    editor: ModelEditor;
    doc: ModelDocument;
    at: ShapeRef;
    shape: Shape3D;
    run: (label: string, work: () => Promise<void>) => Promise<void>;
}): import("react").JSX.Element | null;
