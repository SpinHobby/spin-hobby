import { type GameProject } from '../../../scene3d/src/index.js';
/** Makes the zip and hands it to the person. */
export declare function saveWebGame(project: GameProject): Promise<void>;
