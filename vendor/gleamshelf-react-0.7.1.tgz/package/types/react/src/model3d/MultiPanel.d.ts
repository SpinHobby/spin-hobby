import { type ModelDocument, type ModelEditor, type Shape3D, type ShapeRef } from '../../../scene3d/src/index.js';
/** The shapes a look or join applies to: each picked shape, or every shape in a picked group. */
export declare function leavesOf(doc: ModelDocument, picked: number[]): {
    ref: ShapeRef;
    shape: Shape3D;
}[];
export declare function MultiPanel({ editor, doc, picked, onDuplicate, onDelete, onGroup, onJoin, onModelWithShape, motion, physics, }: {
    editor: ModelEditor;
    doc: ModelDocument;
    picked: number[];
    onDuplicate: () => void;
    onDelete: () => void;
    onGroup: () => void;
    /** Joins the picked imported models into one (shown only when every picked shape is one). */
    onJoin?: () => void;
    /** An imported model and a shape picked together: the model cut by, joined with or kept where it meets the shape. */
    onModelWithShape?: (op: 'add' | 'subtract' | 'intersect') => void;
    /** The Motion section, for all of them. */
    motion?: React.ReactNode;
    /** Drop and stack for the picked shapes. */
    physics?: React.ReactNode;
}): import("react").JSX.Element | null;
