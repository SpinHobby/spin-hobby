import { type HelpGroup } from './instructions';
import './ask.css';
/**
 * Ask: a chat about the editor itself ("where is the character maker?", "how do I change the light?"). It answers from the instructions
 * (instructions.ts) and the controls on the screen, and lights up the control to press, with a ring like the tutorials' (LearnPanel).
 * With the Gleamshelf app and its vision model the answer is written by that model (help.ts in apps/local: free, on this computer);
 * without, the best instruction is the answer. `prefer` is the editor's own guide groups, searched first. It answers in the question's
 * language (English or Japanese), and can say each answer aloud (askVoice.ts: the app's voice, or this computer's own).
 */
export declare function AskPanel({ open, onClose, prefer }: {
    open: boolean;
    onClose: () => void;
    prefer?: readonly HelpGroup[];
}): import("react").JSX.Element | null;
