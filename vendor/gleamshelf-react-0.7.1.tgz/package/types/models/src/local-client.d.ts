import type { LocalHealth, LocalModelStatus } from './types';
/** What a background run of the whole listing chain reports (see the companion app's /process routes). */
export interface ProcessStatus {
    id: string;
    /** 'waiting': the run found pictures online and waits for the person to choose which to use (see `found`, `chooseReferences`). */
    status: 'queued' | 'running' | 'waiting' | 'done' | 'failed';
    steps: {
        name: string;
        state: 'running' | 'done';
        startedAt?: number;
        seconds?: number;
    }[];
    /** What the online lookup found, once it has looked (kept after the choice, so it can still be shown). */
    found?: FoundOnline;
    /** Signs of life while it runs (the app's clock, ms): see the app's jobs.ts. */
    health?: ProcessHealth;
    report?: {
        notes: string[];
        flags: string[];
        modeUsed: string;
        view: string;
        identity: {
            printedTitle: string | null;
            character: string | null;
            franchise: string | null;
        } | null;
        listing: {
            title: string;
            description: string;
            category: string;
            series: string | null;
            highlights: string[];
            unsupported: string[];
            unverifiedNumbers: string[];
            sources: string[];
        } | null;
        /** The product lookup's outcome: whether it was on, whether a picture showing this cover was found, and what it was used for. */
        lookup: {
            state: 'off' | 'found' | 'no-match' | 'no-pictures';
            read: string | null;
            tried: number;
            matched: number;
            bestMatch: number;
            completedParts: number;
            colourFit: number | null;
            detail: string;
        };
        /** How sure the cut-out is (0-1, with reasons), and the share of the product still as photographed (0-1) with a coarse map of what changed. */
        quality?: {
            cutout: {
                score: number;
                reasons: string[];
            };
            fidelity: {
                original: number;
                map: {
                    cols: number;
                    rows: number;
                    changed: number[];
                };
            };
        };
        /** Listing health: a 0-100 score, each check, and the top fixes. */
        health?: ListingHealthReport;
    };
    error?: string;
}
/** A finished run the app kept (see the app's jobs.ts). */
/** The shop finished runs are sent to (see shopStatus). */
export type ShopStatus = {
    connected: false;
} | {
    connected: true;
    url: string;
    label: string;
    answering: boolean;
};
/** A run sent to the shop: a new draft, its earlier draft replaced, or kept as the shop already has it (added or rejected). */
export interface SentRun {
    sent: 'new' | 'replaced' | 'kept';
    status: string;
    shop: string;
    label: string;
}
export interface RecentRun {
    id: string;
    title: string;
    /** When it finished (the app's clock, ms). */
    finishedAt: number;
    /** Its listing health score, when it has one. */
    health: number | null;
}
/** A photo a phone sent to the app (see the app's phone.ts). */
export interface PhonePhoto {
    id: string;
    name: string;
    bytes: number;
    /** When it arrived (the app's clock, ms). */
    at: number;
}
/** What a buyer and a marketplace's search look for, scored by the app (apps/local/src/health.ts). */
export interface ListingHealthReport {
    score: number;
    level: 'good' | 'fair' | 'poor';
    checks: {
        id: string;
        ok: boolean;
        label: string;
        fix?: string;
        weight: number;
    }[];
    fixes: string[];
}
/** The pictures a run found online, to show a person before any is used. */
export interface FoundOnline {
    /** What the local model read off the cover. */
    identity: {
        printedTitle: string | null;
        character: string | null;
        franchise: string | null;
        maker?: string | null;
        variant?: string | null;
    } | null;
    photos: FoundOnlinePhoto[];
    /** The indexes the person chose, once they have (null until then). */
    chosen: number[] | null;
}
export interface FoundOnlinePhoto {
    /** Its number in the list: what `foundPicture` and `chooseReferences` take. */
    index: number;
    /** 'product': a picture of the product (often its box); 'unboxed': the figure out of its box, which shows what the box's printing hides. */
    purpose: 'product' | 'unboxed';
    /** Whether it lines up with the photo: only those can be used. */
    linesUp: boolean;
    /** For one that lines up: a photo of the box (good for colours; it hides what the cover hides) or of the figure itself (it can finish what the print hides). */
    shows?: 'box' | 'figure';
    inliers: number;
    page?: string;
    title?: string;
}
export interface ProcessHealth {
    now: number;
    startedAt: number;
    lastActivity: number;
    models: 'off' | 'starting' | 'working' | 'idle';
    modelJob: string | null;
    cpu: {
        app: number;
        models: number | null;
    };
    detail: string | null;
}
export interface ProcessOptions {
    mode?: 'product' | 'character' | 'auto';
    /** Search the web for reference pictures of the product (free; the search words go to DuckDuckGo, the photo stays here). */
    find?: boolean;
    /** Write a title and description with the local model. */
    listing?: boolean;
    /** Colour strength after a reference colour match, 1 to 2 (1 = the product's published colours). */
    vivid?: number;
    enlarge?: boolean;
    /** Steps of the chain; each is on unless set to false. */
    stickers?: boolean;
    /** Repaint lettering and printed text (character covers). */
    lettering?: boolean;
    /** Complete thin or detached parts of the figure. */
    thinParts?: boolean;
    /** Match the colours to the product's published picture (needs `find`). */
    colour?: boolean;
    /** The brighter and sharper look. */
    look?: boolean;
    /** Redraw the product with AI (see STUDIO_GLOSS). The one step that is off unless set to true. */
    gloss?: boolean;
    /** Stop once the pictures are found online, until `chooseReferences` says which to use (status 'waiting'). Off by default: the run uses every one that lines up. */
    review?: boolean;
}
/** Settings for the sharpening model (`/enhance`). */
export interface EnhanceOptions {
    /** 0.1-0.6: how far the picture may be redrawn. */
    strength?: number;
    prompt?: string;
    negativePrompt?: string;
    seed?: number;
    /** Keep the original colours and take only the brightness detail from the model (default true). */
    keepColour?: boolean;
    /** 0.3-1: how tightly the shapes are pinned to the original (default 1). */
    control?: number;
    /** 1-12: how closely the prompt is followed (default 5). */
    guidance?: number;
}
/**
 * Studio gloss: the product redrawn as a clean studio pack shot. Twice the strength of "Extra detail", the shapes held
 * more loosely and the colours left to the model, so plastic, paint and highlights come back glossier, and so may details that are not on the real item.
 * Off by default everywhere and labelled wherever it is used.
 */
export declare const STUDIO_GLOSS: EnhanceOptions;
export declare class LocalModelError extends Error {
    readonly status: number;
    constructor(status: number, message: string);
}
/** The address the companion app listens on by default. */
export declare const DEFAULT_LOCAL_URL = "http://127.0.0.1:47321";
/**
 * The commands that run the companion app, as a person types them in the repo's folder. One place, so the editor's help,
 * the app's own messages and the docs never disagree.
 */
export declare const LOCAL_COMMANDS: {
    readonly start: "npm run local:start";
    readonly token: "npm run local:token";
    readonly models: "npm run models";
    /** Sets up the redraw model: a Python environment and a 7 GB download, after asking. */
    readonly redrawSetup: "npm run redraw:setup";
    /** Sets up the clean product photo model (FLUX.2 klein 4B): about 16 GB, after asking. */
    readonly cleanPhotoSetup: "npm run clean-photo:setup";
    /** The recommended model when no id is given; any other model by its id. */
    readonly install: (id?: string) => string;
};
/**
 * The avatar's voices (Kokoro-82M, Apache 2.0): made-up voices, none copied from a real person. The model server keeps the same list
 * (apps/modelserver/modelserver/voice.py).
 */
export declare const AVATAR_VOICES: readonly [{
    readonly id: "af_heart";
    readonly label: "Heart";
    readonly accent: "American";
    readonly kind: "female";
}, {
    readonly id: "af_bella";
    readonly label: "Bella";
    readonly accent: "American";
    readonly kind: "female";
}, {
    readonly id: "af_nicole";
    readonly label: "Nicole (soft)";
    readonly accent: "American";
    readonly kind: "female";
}, {
    readonly id: "af_sarah";
    readonly label: "Sarah";
    readonly accent: "American";
    readonly kind: "female";
}, {
    readonly id: "af_sky";
    readonly label: "Sky";
    readonly accent: "American";
    readonly kind: "female";
}, {
    readonly id: "af_nova";
    readonly label: "Nova";
    readonly accent: "American";
    readonly kind: "female";
}, {
    readonly id: "af_river";
    readonly label: "River";
    readonly accent: "American";
    readonly kind: "female";
}, {
    readonly id: "af_aoede";
    readonly label: "Aoede";
    readonly accent: "American";
    readonly kind: "female";
}, {
    readonly id: "af_kore";
    readonly label: "Kore";
    readonly accent: "American";
    readonly kind: "female";
}, {
    readonly id: "af_jessica";
    readonly label: "Jessica";
    readonly accent: "American";
    readonly kind: "female";
}, {
    readonly id: "af_alloy";
    readonly label: "Alloy";
    readonly accent: "American";
    readonly kind: "female";
}, {
    readonly id: "am_michael";
    readonly label: "Michael";
    readonly accent: "American";
    readonly kind: "male";
}, {
    readonly id: "am_adam";
    readonly label: "Adam";
    readonly accent: "American";
    readonly kind: "male";
}, {
    readonly id: "am_eric";
    readonly label: "Eric";
    readonly accent: "American";
    readonly kind: "male";
}, {
    readonly id: "am_liam";
    readonly label: "Liam";
    readonly accent: "American";
    readonly kind: "male";
}, {
    readonly id: "am_puck";
    readonly label: "Puck";
    readonly accent: "American";
    readonly kind: "male";
}, {
    readonly id: "am_echo";
    readonly label: "Echo";
    readonly accent: "American";
    readonly kind: "male";
}, {
    readonly id: "am_fenrir";
    readonly label: "Fenrir";
    readonly accent: "American";
    readonly kind: "male";
}, {
    readonly id: "am_onyx";
    readonly label: "Onyx (deep)";
    readonly accent: "American";
    readonly kind: "male";
}, {
    readonly id: "bf_emma";
    readonly label: "Emma";
    readonly accent: "British";
    readonly kind: "female";
}, {
    readonly id: "bf_isabella";
    readonly label: "Isabella";
    readonly accent: "British";
    readonly kind: "female";
}, {
    readonly id: "bf_alice";
    readonly label: "Alice";
    readonly accent: "British";
    readonly kind: "female";
}, {
    readonly id: "bf_lily";
    readonly label: "Lily";
    readonly accent: "British";
    readonly kind: "female";
}, {
    readonly id: "bm_george";
    readonly label: "George";
    readonly accent: "British";
    readonly kind: "male";
}, {
    readonly id: "bm_fable";
    readonly label: "Fable";
    readonly accent: "British";
    readonly kind: "male";
}, {
    readonly id: "bm_lewis";
    readonly label: "Lewis";
    readonly accent: "British";
    readonly kind: "male";
}, {
    readonly id: "bm_daniel";
    readonly label: "Daniel";
    readonly accent: "British";
    readonly kind: "male";
}, {
    readonly id: "jf_alpha";
    readonly label: "Alpha";
    readonly accent: "Japanese";
    readonly kind: "female";
}, {
    readonly id: "jf_gongitsune";
    readonly label: "Gongitsune";
    readonly accent: "Japanese";
    readonly kind: "female";
}, {
    readonly id: "jf_nezumi";
    readonly label: "Nezumi";
    readonly accent: "Japanese";
    readonly kind: "female";
}, {
    readonly id: "jf_tebukuro";
    readonly label: "Tebukuro";
    readonly accent: "Japanese";
    readonly kind: "female";
}, {
    readonly id: "jm_kumo";
    readonly label: "Kumo";
    readonly accent: "Japanese";
    readonly kind: "male";
}];
export type AvatarVoiceId = (typeof AVATAR_VOICES)[number]['id'];
/** Kokoro's Japanese voices (in AVATAR_VOICES, set up with `npm run voice:setup -- --japanese`): they read Japanese text only. */
export declare const JAPANESE_VOICES: ({
    readonly id: "jf_alpha";
    readonly label: "Alpha";
    readonly accent: "Japanese";
    readonly kind: "female";
} | {
    readonly id: "jf_gongitsune";
    readonly label: "Gongitsune";
    readonly accent: "Japanese";
    readonly kind: "female";
} | {
    readonly id: "jf_nezumi";
    readonly label: "Nezumi";
    readonly accent: "Japanese";
    readonly kind: "female";
} | {
    readonly id: "jf_tebukuro";
    readonly label: "Tebukuro";
    readonly accent: "Japanese";
    readonly kind: "female";
} | {
    readonly id: "jm_kumo";
    readonly label: "Kumo";
    readonly accent: "Japanese";
    readonly kind: "male";
})[];
/** The language a voice speaks: a Japanese voice says Japanese, the others English. */
export declare const voiceLanguage: (id: string) => "en" | "ja";
/** What the speech-to-text model heard. */
export interface HeardSpeech {
    text: string;
    /** The language it heard ("en", "vi", ...). */
    language: string;
    seconds: number;
}
/** Photo to 3D model (apps/local/src/shape3d.ts): the models this computer can use. */
export type ShapeModelId = 'triposr' | 'trellis2' | 'trellis-multi';
export interface ShapeModelStatus {
    id: ShapeModelId;
    name: string;
    /** The most photos it uses (1: only the first). */
    photos: number;
    about: string;
    ready: boolean;
    /** Why it cannot be used, when it cannot ("needs an NVIDIA graphics card with 24 GB", "not set up yet"). */
    why: string | null;
    setup: string;
}
/** A picture found for the figure: the maker's (confirmed to be this figure) or from a web search (a person checks it). */
export interface FoundShapePicture {
    id: string;
    source: 'official' | 'web';
    page: string;
    site: string;
}
export interface MadeShapeModel {
    id: string;
    model: ShapeModelId;
    pictures: number;
    /** Always true: the back and sides are the model's work, not photographed. */
    generated: true;
    bytes: number;
    seconds: number;
}
/** The website's shop assistant on this computer (apps/local/src/website.ts). */
export interface WebsiteStatus {
    on: boolean;
    shop: string | null;
    answering: boolean;
    answered: number;
    last: {
        question: string;
        answer: string;
        at: string;
    } | null;
    problem: string | null;
}
/** Whether the voice is set up in the companion app, and if not, what is missing and the command that sets it up. */
export interface VoiceStatus {
    ok: boolean;
    missing: string[];
    setup: string;
    /** Whether it speaks Japanese too (JAPANESE_VOICES): set up with `npm run voice:setup -- --japanese`. */
    japanese?: boolean;
    /** The live voice (the owner's voice changed as they talk): set up or not, and the avatar voices whose live voice is made. */
    live?: {
        ok: boolean;
        missing: string[];
        setup: string;
        voices: string[];
    };
}
/** A box around some text, as fractions (0-1) of the picture that was sent. */
export interface TextBox {
    x: number;
    y: number;
    width: number;
    height: number;
}
/** A box around some text with what it says. */
export interface ReadTextBox extends TextBox {
    text: string;
    /** 0-1: how sure the reader is. */
    score: number;
}
export interface CutoutMask {
    /** One byte per pixel: 255 is product, 0 is background. */
    alpha: Uint8Array;
    width: number;
    height: number;
    /** The mask already has stray pieces dropped and its thin or detached parts of the figure added, so it must not be filtered by "keep the main piece" again. */
    partsKept?: boolean;
}
/**
 * Talks to the Gleamshelf companion app running on the user's own computer. The photo never leaves the machine,
 * and running a model there costs nothing. The app is protected by a pairing token the user copies from its window.
 */
export declare class LocalModelClient {
    private readonly options;
    private readonly base;
    private readonly doFetch;
    constructor(options?: {
        url?: string;
        token?: string;
        fetch?: typeof fetch;
    });
    private headers;
    /**
     * Tells "not running" apart from "running, but this browser will not let the page talk to it" (a browser that blocks
     * calls to http://127.0.0.1 from a page, such as Safari). A blocked call and a refused one both look like a network
     * error to the page, so a second, opaque request is tried: it can reach the app even where reading the answer is blocked.
     */
    probe(): Promise<'ok' | 'blocked' | 'offline'>;
    /** Whether the companion app is running here. Never throws: not running is a normal answer. */
    health(): Promise<LocalHealth | null>;
    /**
     * Repaints part of a picture. `picture` is a PNG whose transparent pixels are the ones to fill in (what is kept must be
     * opaque). Returns the finished picture as a PNG, the same size. The first call loads the model; large areas take a while.
     */
    inpaint(picture: Blob, modelId: string, signal?: AbortSignal): Promise<Blob>;
    /** Makes a picture 4 times larger and sharper. Returns a PNG. Large pictures take a while; send at most about 1024 pixels on the long side. */
    upscale(picture: Blob, modelId: string, signal?: AbortSignal): Promise<Blob>;
    /**
     * Redraws part of a picture with the local image model. The part to redraw is the PNG's transparent pixels and/or `box` (normalized
     * x, y, width, height); a rough sketch drawn into the opaque part of the box steers it, and a `strength` below 1 keeps that sketch's
     * shape. With `stacked`, `picture` is an opaque PNG twice as tall as the picture: the picture on top and the part to repaint below it in
     * white, so the pixels under the part to repaint are kept (a transparent PNG loses them). About a minute.
     */
    redraw(picture: Blob, options: {
        prompt: string;
        negative?: string;
        strength?: number;
        steps?: number;
        guidance?: number;
        candidates?: number;
        seed?: number;
        box?: [number, number, number, number];
        stacked?: boolean;
        clamp?: boolean;
    }, signal?: AbortSignal): Promise<Blob>;
    /**
     * Turns a photo of a figure's box (any photo the app reads, an iPhone's HEIC too) into a clean picture of the figure alone: no lettering,
     * logos, stickers or box edges, on a studio backdrop (FLUX.2 klein 4B). A redraw: small details can differ from the real figure. About 2-3
     * minutes on a 16 GB Mac. A different `seed` draws a different take.
     */
    cleanPhoto(photo: Blob, options?: {
        backdrop?: 'artwork' | 'dark' | 'white';
        seed?: number;
    }, signal?: AbortSignal): Promise<Blob>;
    /**
     * Sharpens a picture (1400 pixels or less) while keeping every shape and, by default, its colours. About a minute for 1024 pixels.
     * `strength` (0.1-0.6) is how far it may be redrawn; low keeps the finest detail exactly where it was.
     */
    enhance(picture: Blob, options?: EnhanceOptions, signal?: AbortSignal): Promise<Blob>;
    /**
     * Studio gloss: the product redrawn as a studio pack shot by the sharpening model, much further than `enhance` goes (see STUDIO_GLOSS). It changes the
     * product's own pixels, so callers offer it off by default and label the result.
     */
    gloss(picture: Blob, signal?: AbortSignal): Promise<Blob>;
    /** Finds printed text in a photo and reads it. Needs both the text finder and the text reader installed. */
    readText(photo: Blob, signal?: AbortSignal): Promise<ReadTextBox[]>;
    /** Finds printed text in a photo and returns boxes around it. */
    detectText(photo: Blob, modelId: string, signal?: AbortSignal): Promise<TextBox[]>;
    /** Whether the avatar's voice is set up in the app (null when the app is too old to have one). */
    voiceStatus(signal?: AbortSignal): Promise<VoiceStatus | null>;
    /** Speech to text (Whisper). `wav` is a WAV recording; `words` are names it should spell right (shop and product names). */
    listen(wav: Blob, options?: {
        language?: string;
        words?: string[];
    }, signal?: AbortSignal): Promise<HeardSpeech>;
    /** Tidies what was heard (grammar, misheard words) with the app's text model, translating it into English when another language was heard. */
    fixWording(text: string, options?: {
        language?: string;
        words?: string[];
    }, signal?: AbortSignal): Promise<string>;
    /** A translation for a call (`to`: en, ja, zh, ko, vi, ...), by the app's own model; `from` is the language Whisper heard. */
    translate(text: string, options: {
        to: string;
        from?: string;
        words?: string[];
    }, signal?: AbortSignal): Promise<string>;
    /**
     * Text to speech (Kokoro) in one of AVATAR_VOICES (a Japanese one reads Japanese text, once the status says `japanese`). `words` are the
     * shop's own pronunciations ("Gunpla": "GUN plah"). Returns a WAV.
     */
    speak(text: string, options?: {
        voice?: AvatarVoiceId;
        speed?: number;
        words?: Record<string, string>;
    }, signal?: AbortSignal): Promise<Blob>;
    /**
     * The market tools (apps/local/src/market.ts): sold comps from a sales file, prices by region with what landing them costs, landed cost, a listing in
     * another language, and the bootleg check. Answers are JSON as the app sends them.
     */
    market<T = Record<string, unknown>>(route: 'comps' | 'regions' | 'landed' | 'localise' | 'insights' | 'reviews' | 'synonyms' | 'plan', body: object, signal?: AbortSignal): Promise<T>;
    /** The duty, tax and fee rules the landed cost uses, and the regions prices come from; null when the app is too old to have them. */
    marketRules<T = Record<string, unknown>>(signal?: AbortSignal): Promise<T | null>;
    /** Points to check against the maker's official photo (never a verdict of fake or genuine). `model: false` skips the vision model's look. */
    bootlegCheck<T = Record<string, unknown>>(photo: Blob, official: Blob, options?: {
        model?: boolean;
    }, signal?: AbortSignal): Promise<T>;
    /** Photo to 3D model: which models this computer can use; null when the app cannot make 3D models. */
    shapeModels(signal?: AbortSignal): Promise<ShapeModelStatus[] | null>;
    /** Other photos of the figure (the maker's, then from a web search), from what was read off its box; `cutout` is the shop's, to compare. */
    findShapePictures(identity: object, cutout?: Blob | null, signal?: AbortSignal): Promise<FoundShapePicture[]>;
    /** A found picture, by its id. */
    shapePicture(id: string, signal?: AbortSignal): Promise<Blob>;
    /** Makes a 3D model from pictures: found ones by id, or the shop's own (photos or cut-outs; photos are cut out first). Then shapeModelFile. */
    makeShapeModel(model: ShapeModelId, pictures: ({
        found: string;
    } | Blob)[], signal?: AbortSignal): Promise<MadeShapeModel>;
    /** A made model's GLB. */
    shapeModelFile(id: string, signal?: AbortSignal): Promise<Blob>;
    /** Whether the AI assistant can answer (it needs the vision model); null when the app has none. */
    agentStatus(signal?: AbortSignal): Promise<{
        ok: boolean;
        missing: string[];
        setup: string;
    } | null>;
    /**
     * The AI assistant's answer to a viewer's question, from the connected shop's catalogue and the app's own model (free, on this computer).
     * `history` is the last few questions and answers, so it can follow the chat.
     */
    askAgent(question: string, options?: {
        name?: string;
        history?: {
            question: string;
            answer: string;
        }[];
        language?: 'en' | 'ja';
    }, signal?: AbortSignal): Promise<{
        answer: string;
        products: {
            name: string;
            price: string;
            status: string;
        }[];
        shop: string | null;
    }>;
    /** Whether the editors' help assistant can write answers (it needs the vision model); null when the app has none. */
    helpStatus(signal?: AbortSignal): Promise<{
        ok: boolean;
        missing: string[];
        setup: string;
    } | null>;
    /**
     * The help assistant's answer (free, the app's own model on this computer): from `facts` (instructions found for the question) and the
     * `controls` on the screen, each with a code (c12) the answer names in square brackets, so the page can light the control up.
     */
    askHelp(question: {
        question: string;
        lang: 'en' | 'ja';
        facts: {
            name: string;
            text: string;
        }[];
        controls: {
            id: string;
            label: string;
            title?: string;
        }[];
        history?: {
            question: string;
            answer: string;
        }[];
    }, signal?: AbortSignal): Promise<{
        answer: string;
    }>;
    /** Products for a product video: those matching `query`, or the shop's newest. */
    shopProducts(query?: string, signal?: AbortSignal): Promise<{
        shop: string;
        products: {
            id: string;
            name: string;
            series: string | null;
            price: string;
            status: string;
            image: string | null;
        }[];
    }>;
    /** A product picture from the shop, fetched by the app (so it can be drawn into a video; a picture from another site cannot). */
    shopImage(url: string, signal?: AbortSignal): Promise<Blob>;
    /** A product video's script, written by the app's model from the product's facts (about `seconds` long when spoken), in `language`. */
    writeScript(id: string, seconds?: number, signal?: AbortSignal, language?: 'en' | 'ja'): Promise<string>;
    /** The shop assistant on the shop's website: whether this computer answers its visitors, and how it is going; null when the app cannot. */
    websiteStatus(signal?: AbortSignal): Promise<WebsiteStatus | null>;
    /** Turns the website's shop assistant on or off on this computer, with its name and voice. */
    setWebsite(settings: {
        on: boolean;
        name: string;
        voice: boolean;
        voiceId: AvatarVoiceId;
        speed: number;
        words: Record<string, string>;
    }, signal?: AbortSignal): Promise<WebsiteStatus>;
    /** The website's shop assistant's portrait (a JPEG or PNG, 400 KB or less). */
    setWebsitePortrait(picture: Blob, signal?: AbortSignal): Promise<void>;
    /** The stage for OBS: its link (with its own view-only key) and how many stages are watching; null when the app has no stage. */
    stageLink(signal?: AbortSignal): Promise<{
        url: string;
        viewers: number;
    } | null>;
    /** A new stage link: every OBS scene with the old link stops showing the avatar until the new one is pasted in. */
    newStageLink(signal?: AbortSignal): Promise<string>;
    /** Gives the stage the avatar file (a VRM) it draws. */
    setStageAvatar(vrm: Blob, signal?: AbortSignal): Promise<string>;
    /** The WebSocket address Avatar mode feeds the stage on (it proves itself with the pairing token in its first message). */
    get stageSocket(): string;
    /** The pairing token, for the stage's WebSocket (a browser cannot put it in a WebSocket's headers). */
    get pairingToken(): string;
    /**
     * A whole recording (a WAV of a game line or narration, up to a minute) changed into one of AVATAR_VOICES, as a 16 kHz WAV. The voice
     * is made the first time it is used (about a minute); after that a line takes seconds.
     */
    changeVoice(wav: Blob, voice: AvatarVoiceId, signal?: AbortSignal): Promise<Blob>;
    /** Makes the live voice for one of AVATAR_VOICES (about a minute, once per voice). */
    buildLiveVoice(voice: AvatarVoiceId, signal?: AbortSignal): Promise<{
        voice: string;
        frames: number;
        seconds: number;
    }>;
    /**
     * One chunk of the owner's voice (a 16 kHz WAV, about 160 ms) in the avatar's voice: a WAV of the same length, 60 ms behind. Chunks of one
     * `session` are heard together, so send them in order; `reset` starts the session afresh.
     */
    convertLive(chunk: Blob, options: {
        voice: AvatarVoiceId;
        session: string;
        reset?: boolean;
    }, signal?: AbortSignal): Promise<Blob>;
    /** Starts the whole listing chain on a photo in the app (the same chain as the batch command). Returns the job's id at once; follow it with `processStatus`. */
    startProcess(photo: Blob, options?: ProcessOptions, signal?: AbortSignal): Promise<string>;
    processStatus(id: string, signal?: AbortSignal): Promise<ProcessStatus>;
    /** A picture a waiting (or finished) run found online, made small for showing. */
    foundPicture(id: string, index: number, signal?: AbortSignal): Promise<Blob>;
    /** Lets a waiting run go on with the pictures the person chose (indexes from `found`), or with every one that lines up (null). */
    chooseReferences(id: string, use: number[] | null, signal?: AbortSignal): Promise<void>;
    /** Stops a job: it ends at its next step, and a model job it is stuck in is stopped now. */
    cancelProcess(id: string, signal?: AbortSignal): Promise<void>;
    /** The finished picture of a job: the figure or product alone on a transparent background (`cutout`), or the white square (`studio`). */
    processPicture(id: string, which?: 'cutout' | 'studio' | 'changes' | 'promo', signal?: AbortSignal): Promise<Blob>;
    /** Finished runs the app kept, newest first: each opens again instantly with processStatus and processPicture. */
    recentRuns(signal?: AbortSignal): Promise<RecentRun[]>;
    /** Whether this computer is connected to a shop (where finished runs go as drafts), which one, and whether it answers. */
    shopStatus(signal?: AbortSignal): Promise<ShopStatus>;
    /** Connects this computer to a shop with the code its admin shows (Imports › Connect the app). */
    shopConnect(address: string, code: string, signal?: AbortSignal): Promise<{
        url: string;
        label: string;
    }>;
    /** Sends a finished run to the connected shop as a draft in its Imports inbox (nothing is published). */
    sendRun(id: string, signal?: AbortSignal): Promise<SentRun>;
    /** Starts phone capture (or returns the one running): the address the phone opens on the Wi-Fi, and the same as a QR code (SVG text). */
    phoneStart(signal?: AbortSignal): Promise<{
        url: string;
        qrSvg: string;
    }>;
    /** The photos a phone has sent, newest first. */
    phonePhotos(signal?: AbortSignal): Promise<PhonePhoto[]>;
    /** One photo a phone sent, as it came (JPEG, PNG, WebP or HEIC). */
    phonePhoto(id: string, signal?: AbortSignal): Promise<Blob>;
    models(): Promise<LocalModelStatus[]>;
    /** Runs a cut-out model on a photo and returns its mask. The first run of a model loads it, which can take a few seconds. */
    cutout(photo: Blob, modelId: string, signal?: AbortSignal, options?: {
        thinParts?: boolean;
    }): Promise<CutoutMask>;
}
