import type { BlendMode, PixelData } from './document.js';
/** One layer as Photoshop gets it: canvas-size pixels (cropped to what is drawn when written), and its settings. */
export interface PsdLayer {
    name: string;
    pixels: PixelData;
    opacity: number;
    blend: BlendMode;
    hidden: boolean;
}
/** One row of one channel PackBits-packed: runs of a repeated byte, and literal stretches, each at most 128 long. */
export declare function packBits(row: Uint8Array): Uint8Array;
/**
 * The design as a .psd file. `layers` go bottom to top, each canvas-size; `flat` is the finished picture at canvas size. Names outside Latin-1
 * (Japanese) are kept through the Unicode name record Photoshop reads first.
 */
export declare function toPsd(width: number, height: number, layers: readonly PsdLayer[], flat: PixelData): Uint8Array;
