import type { PixelData } from './document.js';
import type { Point, Rect } from './geometry.js';
import type { Selection } from './selection.js';
/** A point of an ink line and its width there, in pixels. */
export interface InkPoint {
    x: number;
    y: number;
    w: number;
}
/** One line drawn in one go. */
export interface InkStroke {
    points: InkPoint[];
}
/**
 * A "pulled string" stabiliser: the line follows the pointer on a string `radius` long, so it only moves when the pointer pulls it, and a
 * shaky hand draws a smooth line. Independent of how often the pointer reports. `radius` 0 is off.
 */
export interface Stabiliser {
    radius: number;
    at: Point | null;
}
export declare const startStabiliser: (radius: number) => Stabiliser;
/** How long the string is for a stabiliser setting of 0-10 (0 off), at a brush size: steadier for bigger numbers, and for bigger brushes. */
export declare const stabiliserRadius: (level: number, size: number) => number;
/** Where the line is after the pointer moves to `to`: null while the string is still slack (nothing to draw yet). */
export declare function stabilise(s: Stabiliser, to: Point): Point | null;
/** When the pointer lifts: the line catches up to where it was let go, in steps (empty when it is already there). */
export declare function finishStabiliser(s: Stabiliser, to: Point, step?: number): Point[];
export interface InkOptions {
    /** The widest the line gets, pixels. */
    size: number;
    /** How far, in pixels, the line takes to swell from a point at its start and thin back to one at its end (0: blunt ends). */
    taper: number;
    /** How much a fast hand thins the line, 0-1 (0: the same width at any speed). */
    speed: number;
}
export declare const INK_DEFAULTS: InkOptions;
/**
 * Builds a line as the hand draws it: each point gets a width from how fast it was drawn (pixels since the last point; a hand moving
 * quickly draws thinner) and the start's taper. `pressure` 0-1, where a pen gives one, scales the width too. The end's taper is put on
 * by `finishInk`, once it is known where the line ends.
 */
export declare function addInkPoint(stroke: InkStroke, at: Point, o: InkOptions, pressure?: number): void;
/** The line done: both ends tapered. A tap with no movement becomes a round dot. */
export declare function finishInk(stroke: InkStroke, o: InkOptions): InkStroke;
/**
 * The outline of a set of ink lines as SVG path data (also what Path2D takes), to fill with the nonzero rule: a round cap at every point and,
 * between each two, the band joining them, each piece wound the same way, so where lines and pieces overlap they simply add up.
 */
export declare function inkD(strokes: readonly InkStroke[]): string;
/** The box round a set of ink lines, widths included. */
export declare function inkBounds(strokes: readonly InkStroke[]): Rect;
/**
 * The space inside the lines round `at`, as a selection the size of the canvas: every pixel reachable from `at` without crossing a line
 * (a pixel of `lines` more than half covered), grown `under` pixels so the colour tucks under the lines' soft edges and no pale rim shows.
 * `gap`: lines that nearly meet, up to this many pixels apart, are treated as closed (0 for none). Empty when `at` is on a line.
 */
export declare function insideLines(lines: PixelData, at: Point, under?: number, gap?: number): Selection;
