import { type Img } from './image';
/**
 * How far a box leans, in degrees (positive: its top is to the right), from the two sides of its outline. On a box seen from below or above its sides lean opposite ways
 * and cancel out, so what is left is the camera's own tilt. Null when the outline has no straight sides to go by (a figure, a torn cut-out).
 */
export declare function boxLean(product: Img): number | null;
/** A picture turned by `degrees` (positive: clockwise on screen), on a canvas big enough for it, see-through round it. */
export declare function turned(src: Img, degrees: number): Img;
/**
 * The colour a product's backdrop takes: the fullest hue round the edges of the package (its own colour, as the figure in the middle is not), leaving out skin tones. A
 * package with little colour gets a quiet cool grey. Returns the backdrop's edge and its lit middle.
 */
export declare function backdropColours(product: Img): {
    edge: [number, number, number];
    middle: [number, number, number];
    hue: number | null;
};
export interface PromoOptions {
    size: number;
    /** Stand a box upright (it has straight sides to go by). A figure is left as it is. */
    straighten?: boolean;
}
/** The promo picture: see the top of this file. */
export declare function promoShot(product: Img, { size, straighten }: PromoOptions): Img;
/**
 * Takes a green backdrop's colour off a product's pale parts: its whites come out mint, as light bounces off the cloth. What the near-white pixels lean to is measured and
 * taken off them (fading out as a pixel has more colour of its own, so the printing stays as it is). Only a lean towards green is touched. Returns how much was taken off.
 */
export declare function neutralizeGreenCast(img: Img, alpha: Uint8Array): number;
