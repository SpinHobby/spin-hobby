import type { Img, Rect } from './image';
/**
 * An AI (or a person) points at a sticker roughly. This snaps that box to the sticker itself: the connected light, colourless
 * patch (white or cream paper) that sits mostly inside the rough box, plus a little room for the dark rules printed on the
 * label's edges. A rough box that is too wide would smear the box artwork around it; one that is too short would leave a strip
 * of the sticker behind. If no clear sticker is found, or the patch runs on into the box's own white areas, the rough box is
 * returned unchanged.
 */
export declare function tightenStickerBox(img: Img, rough: Rect): Rect;
/** A label on a product: its four corners in pixels, round the paper (it can be turned, as the side of a box is in a photo), and its box as fractions. */
export interface PaperLabel {
    corners: [number, number][];
    box: Rect;
}
/**
 * The paper label round a price the text reader found. The label is whatever is about as light as the lightest paper near that price, so it comes apart from a
 * white panel it is stuck on (a label is a little brighter) and from warm or cool light alike. Null when no label's shape holds the price: then it is no sticker.
 */
export declare function paperAroundPrice(img: Img, price: Rect): PaperLabel | null;
/**
 * Labels a shop stuck on: small, rectangular patches of paper standing alone on the product. A price sticker that the text reader missed still looks like
 * this, and its whole shape is what must come off (a box round its price leaves the rest behind). A box's own white labels look the same, so a caller
 * confirms each by reading it. Worked out on a grid of 4 pixels, so the print on a label does not break it up. `inside` limits it to the product.
 */
export declare function findPaperLabels(img: Img, inside?: Uint8Array, productArea?: number): PaperLabel[];
/** 1 inside a four-cornered shape. */
export declare function maskFromCorners(width: number, height: number, shapes: [number, number][][]): Uint8Array;
/**
 * Whether a fill looks like the surface round it. A fill that went wrong shows as a seam at the hole's edge, or as more fine detail inside than outside (the
 * scribbles left where a model half remembers the print). `hole` is 1 where it was filled; `area` is the part of the picture to judge, round that hole.
 */
export declare function fillLooksClean(filled: Img, hole: Uint8Array, shape: [number, number][]): boolean;
/**
 * Blends a fill into what is round it (seamless cloning): at the hole's edge the fill is out by some colour, and that difference is spread smoothly across the hole
 * and added, so the fill keeps its detail and the edge disappears. A fill that came out a shade lighter or darker than the box stops showing as a rectangle.
 * Changes `filled` in place, inside the hole; `original` gives the pixels outside it.
 */
export declare function blendFill(original: Img, filled: Img, hole: Uint8Array, shape: [number, number][]): void;
