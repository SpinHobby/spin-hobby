//#region ../scene3d/src/model/mesh.ts
var e = [
	"soft",
	"toon",
	"flat",
	"clay"
];
function t(e) {
	let t = (e, t) => {
		let n = e.slice();
		for (let e = 0; e < n.length; e += t) n[e] = -n[e], n[e + 2] = -n[e + 2];
		return n;
	}, n = (e) => [
		-e[0],
		e[1],
		-e[2]
	];
	return {
		...e,
		parts: e.parts.map((e) => ({
			...e,
			positions: t(e.positions, 3),
			normals: t(e.normals, 3)
		})),
		min: [
			-e.max[0],
			e.min[1],
			-e.max[2]
		],
		max: [
			-e.min[0],
			e.max[1],
			-e.min[2]
		],
		...e.skeleton ? { skeleton: e.skeleton.map((e) => ({
			...e,
			head: n(e.head),
			tail: n(e.tail)
		})) } : {},
		...e.morphs ? { morphs: {
			names: e.morphs.names,
			moves: e.morphs.moves.map((e) => e.map((e) => e ? t(e, 3) : null))
		} } : {}
	};
}
var n = () => ({
	color: [
		.8,
		.8,
		.8
	],
	opacity: 1,
	metalness: 0,
	roughness: .6,
	texture: -1,
	normalTexture: -1,
	normalScale: 1,
	roughnessTexture: -1,
	occlusionTexture: -1,
	occlusionStrength: 1,
	emissive: [
		0,
		0,
		0
	],
	emissiveTexture: -1,
	clearcoat: 0,
	clearcoatTexture: -1,
	clearcoatRoughness: 0,
	clearcoatRoughnessTexture: -1,
	clearcoatNormalTexture: -1,
	clearcoatNormalScale: 1,
	sheenColor: [
		0,
		0,
		0
	],
	sheenColorTexture: -1,
	sheenRoughness: 0,
	sheenRoughnessTexture: -1,
	transmission: 0,
	transmissionTexture: -1,
	ior: 1.5,
	cutout: !1,
	doubleSided: !1
}), r = Uint8Array;
function i(e) {
	let t = globalThis.Buffer;
	if (t) return t.from(e).toString("base64");
	if (r.prototype.toBase64) return r.prototype.toBase64.call(e);
	let n = "";
	for (let t = 0; t < e.length; t += 32768) n += String.fromCharCode(...e.subarray(t, t + 32768));
	return btoa(n);
}
function a(e) {
	let t = globalThis.Buffer;
	if (t) return new Uint8Array(t.from(e, "base64"));
	if (r.fromBase64) return r.fromBase64(e);
	let n = atob(e), i = new Uint8Array(n.length);
	for (let e = 0; e < n.length; e++) i[e] = n.charCodeAt(e);
	return i;
}
function o(e) {
	let t = [
		Infinity,
		Infinity,
		Infinity
	], n = [
		-Infinity,
		-Infinity,
		-Infinity
	];
	for (let r of e) for (let e = 0; e < r.positions.length; e += 3) for (let i = 0; i < 3; i++) {
		let a = r.positions[e + i];
		a < t[i] && (t[i] = a), a > n[i] && (n[i] = a);
	}
	return t[0] === Infinity ? {
		min: [
			0,
			0,
			0
		],
		max: [
			0,
			0,
			0
		]
	} : {
		min: t,
		max: n
	};
}
function s(e, t) {
	let n = new Float32Array(e.length);
	for (let r = 0; r < t.length; r += 3) {
		let [i, a, o] = [
			t[r] * 3,
			t[r + 1] * 3,
			t[r + 2] * 3
		], s = [
			e[a] - e[i],
			e[a + 1] - e[i + 1],
			e[a + 2] - e[i + 2]
		], c = [
			e[o] - e[i],
			e[o + 1] - e[i + 1],
			e[o + 2] - e[i + 2]
		], l = [
			s[1] * c[2] - s[2] * c[1],
			s[2] * c[0] - s[0] * c[2],
			s[0] * c[1] - s[1] * c[0]
		];
		for (let e of [
			i,
			a,
			o
		]) for (let t = 0; t < 3; t++) n[e + t] += l[t];
	}
	for (let e = 0; e < n.length; e += 3) {
		let t = Math.hypot(n[e], n[e + 1], n[e + 2]) || 1;
		n[e] /= t, n[e + 1] /= t, n[e + 2] /= t;
	}
	return n;
}
var c = 1179937895, l = 1313821514, u = 5130562, d = (e) => e + 3 & -4, f = (e, t = {}) => e >= 0 ? {
	index: e,
	...t
} : void 0, p = (e) => Object.fromEntries(Object.entries(e).filter(([, e]) => e !== void 0));
function m(e) {
	let t = {}, n = {}, r = Math.max(...e.emissive);
	if (r > 0 || e.emissiveTexture >= 0) {
		let i = Math.max(1, r);
		t.emissiveFactor = e.emissive.map((e) => e / i), e.emissiveTexture >= 0 && (t.emissiveTexture = { index: e.emissiveTexture }), i > 1 && (n.KHR_materials_emissive_strength = { emissiveStrength: i });
	}
	return e.unlit && (n.KHR_materials_unlit = {}), e.clearcoat > 0 && (n.KHR_materials_clearcoat = p({
		clearcoatFactor: e.clearcoat,
		clearcoatTexture: f(e.clearcoatTexture),
		clearcoatRoughnessFactor: e.clearcoatRoughness,
		clearcoatRoughnessTexture: f(e.clearcoatRoughnessTexture),
		clearcoatNormalTexture: f(e.clearcoatNormalTexture, { scale: e.clearcoatNormalScale })
	})), Math.max(...e.sheenColor) > 0 && (n.KHR_materials_sheen = p({
		sheenColorFactor: e.sheenColor,
		sheenColorTexture: f(e.sheenColorTexture),
		sheenRoughnessFactor: e.sheenRoughness,
		sheenRoughnessTexture: f(e.sheenRoughnessTexture)
	})), e.transmission > 0 && (n.KHR_materials_transmission = p({
		transmissionFactor: e.transmission,
		transmissionTexture: f(e.transmissionTexture)
	})), e.ior !== 1.5 && (n.KHR_materials_ior = { ior: e.ior }), Object.keys(n).length && (t.extensions = n), t;
}
function h(t) {
	let n = typeof t?.tag == "string" && t.tag ? { tag: t.tag } : {}, r = e.includes(t?.look) ? t.look : void 0;
	if (!r) return n;
	let i = typeof t?.bands == "number" && Number.isFinite(t.bands) ? Math.min(8, Math.max(2, Math.round(t.bands))) : void 0;
	return {
		look: r,
		...i ? { bands: i } : {},
		...n
	};
}
function g(e, t, n) {
	let r = n <= 256 ? new Uint8Array(t * 4) : new Uint16Array(t * 4), i = new Uint8Array(t * 4), a = e.joints && e.skinWeights && e.joints.length === t * 4 && e.skinWeights.length === t * 4;
	for (let n = 0; n < t; n++) {
		if (!a) {
			i[n * 4] = 255;
			continue;
		}
		let t = 0;
		for (let r = 0; r < 4; r++) t += e.skinWeights[n * 4 + r];
		let o = 0, s = 0;
		for (let a = 0; a < 4; a++) {
			let c = t > 0 ? Math.round(e.skinWeights[n * 4 + a] / t * 255) : a ? 0 : 255;
			r[n * 4 + a] = e.joints[n * 4 + a], i[n * 4 + a] = c, o += c, c > i[n * 4 + s] && (s = a);
		}
		i[n * 4 + s] += 255 - o;
	}
	return {
		joints: r,
		weights: i
	};
}
function _(e, t) {
	let n = [], r = [], i = [], a = 0, o = (e, t) => {
		n.push({
			buffer: 0,
			byteOffset: a,
			byteLength: e.byteLength,
			...t ? { target: t } : {}
		}), i.push(e);
		let r = d(e.byteLength);
		return r > e.byteLength && i.push(new Uint8Array(r - e.byteLength)), a += r, n.length - 1;
	}, s = (e, t, n, i = !1) => {
		let a = o(new Uint8Array(e.buffer, e.byteOffset, e.byteLength), n), s = t === "VEC3" ? 3 : t === "VEC2" ? 2 : 1, c = {
			bufferView: a,
			componentType: e instanceof Float32Array ? 5126 : 5125,
			count: e.length / s,
			type: t
		};
		if (i) {
			let t = [
				Infinity,
				Infinity,
				Infinity
			].slice(0, s), n = [
				-Infinity,
				-Infinity,
				-Infinity
			].slice(0, s);
			for (let r = 0; r < e.length; r++) {
				let i = r % s;
				t[i] = Math.min(t[i], e[r]), n[i] = Math.max(n[i], e[r]);
			}
			Object.assign(c, {
				min: t,
				max: n
			});
		}
		return r.push(c), r.length - 1;
	}, f = (e, t, n, i, a = {}) => {
		let s = o(e, a.target);
		return r.push({
			bufferView: s,
			componentType: t,
			count: n,
			type: i,
			...a.normalized ? { normalized: !0 } : {},
			...a.min ? {
				min: a.min,
				max: a.max
			} : {}
		}), r.length - 1;
	}, p = e.skeleton?.length ? e.skeleton : null, h = t?.morphs ?? (e.morphs ? e.parts.map((t, n) => e.morphs.moves.map((e) => e[n] ?? null)) : void 0), _ = t?.morphNames ?? e.morphs?.names, v = e.parts.map((e, t) => {
		let n = {
			POSITION: s(e.positions, "VEC3", 34962, !0),
			NORMAL: s(e.normals, "VEC3", 34962)
		};
		if (e.uvs && (n.TEXCOORD_0 = s(e.uvs, "VEC2", 34962)), e.colors && (n.COLOR_0 = s(e.colors, "VEC3", 34962)), p) {
			let t = e.positions.length / 3, { joints: r, weights: i } = g(e, t, p.length);
			n.JOINTS_0 = f(new Uint8Array(r.buffer, r.byteOffset, r.byteLength), r instanceof Uint8Array ? 5121 : 5123, t, "VEC4", { target: 34962 }), n.WEIGHTS_0 = f(i, 5121, t, "VEC4", {
				target: 34962,
				normalized: !0
			});
		}
		return {
			attributes: n,
			indices: s(e.indices, "SCALAR", 34963),
			material: e.material,
			mode: 4,
			...h?.[t]?.length ? { targets: h[t].map((t) => t ? { POSITION: s(t, "VEC3", 34962, !0) } : (r.push({
				componentType: 5126,
				count: e.positions.length / 3,
				type: "VEC3",
				min: [
					0,
					0,
					0
				],
				max: [
					0,
					0,
					0
				]
			}), { POSITION: r.length - 1 })) } : {}
		};
	}), y = p?.map((e, t) => {
		let n = e.parent >= 0 ? p[e.parent].head : [
			0,
			0,
			0
		], r = p.flatMap((e, n) => e.parent === t ? [n + 1] : []);
		return {
			name: e.name,
			translation: e.head.map((e, t) => e - n[t]),
			...r.length ? { children: r } : {},
			extras: { gleamshelf: { tail: e.tail } }
		};
	}), b = p ? (() => {
		let e = new Float32Array(p.length * 16);
		return p.forEach((t, n) => e.set([
			1,
			0,
			0,
			0,
			0,
			1,
			0,
			0,
			0,
			0,
			1,
			0,
			-t.head[0],
			-t.head[1],
			-t.head[2],
			1
		], n * 16)), f(new Uint8Array(e.buffer), 5126, p.length, "MAT4");
	})() : -1, x = p?.flatMap((e, t) => e.parent < 0 ? [t + 1] : []) ?? [], S = e.textures.map((e) => ({
		bufferView: o(e.bytes),
		mimeType: e.mime
	})), C = [...new Set(e.materials.flatMap((e) => Object.keys(m(e).extensions ?? {})))], w = {
		asset: {
			version: "2.0",
			generator: "Gleamshelf"
		},
		...C.length ? { extensionsUsed: C } : {},
		scene: 0,
		scenes: [{ nodes: [0, ...x] }],
		nodes: [{
			mesh: 0,
			...p ? { skin: 0 } : {},
			..._?.length ? { name: "Body" } : {}
		}, ...y ?? []],
		meshes: [{
			primitives: v,
			..._?.length ? { extras: { targetNames: _ } } : {}
		}],
		...p ? { skins: [{
			joints: p.map((e, t) => t + 1),
			inverseBindMatrices: b
		}] } : {},
		materials: e.materials.map((e) => ({
			pbrMetallicRoughness: {
				baseColorFactor: [...e.color, e.opacity],
				metallicFactor: e.metalness,
				roughnessFactor: e.roughness,
				...e.texture >= 0 ? { baseColorTexture: { index: e.texture } } : {},
				...e.roughnessTexture >= 0 ? { metallicRoughnessTexture: { index: e.roughnessTexture } } : {}
			},
			...e.normalTexture >= 0 ? { normalTexture: {
				index: e.normalTexture,
				scale: e.normalScale
			} } : {},
			...e.occlusionTexture >= 0 ? { occlusionTexture: {
				index: e.occlusionTexture,
				strength: e.occlusionStrength
			} } : {},
			...m(e),
			...e.look || e.tag ? { extras: { gleamshelf: {
				...e.look ? { look: e.look } : {},
				...e.look && e.bands ? { bands: e.bands } : {},
				...e.tag ? { tag: e.tag } : {}
			} } } : {},
			...e.cutout ? {
				alphaMode: "MASK",
				alphaCutoff: .5
			} : {},
			...e.doubleSided ? { doubleSided: !0 } : {}
		})),
		...S.length ? {
			images: S,
			textures: S.map((e, t) => ({
				source: t,
				sampler: 0
			})),
			samplers: [{
				magFilter: 9729,
				minFilter: 9987,
				wrapS: 10497,
				wrapT: 10497
			}]
		} : {},
		accessors: r,
		bufferViews: n,
		buffers: [{ byteLength: a }]
	};
	t?.extend?.(w, f), w.buffers = [{ byteLength: a }];
	let T = new TextEncoder().encode(JSON.stringify(w)), E = d(T.byteLength), D = 20 + E + 8 + a, O = new Uint8Array(D), k = new DataView(O.buffer);
	k.setUint32(0, c, !0), k.setUint32(4, 2, !0), k.setUint32(8, D, !0), k.setUint32(12, E, !0), k.setUint32(16, l, !0), O.set(T, 20), O.fill(32, 20 + T.byteLength, 20 + E);
	let A = 20 + E;
	k.setUint32(A, a, !0), k.setUint32(A + 4, u, !0), A += 8;
	for (let e of i) O.set(e, A), A += e.byteLength;
	return O;
}
var v = {
	KHR_draco_mesh_compression: "Draco compression",
	EXT_meshopt_compression: "meshopt compression",
	KHR_meshopt_compression: "meshopt compression",
	KHR_texture_basisu: "KTX2 textures"
}, y = [
	1,
	0,
	0,
	0,
	0,
	1,
	0,
	0,
	0,
	0,
	1,
	0,
	0,
	0,
	0,
	1
];
function b(e, t) {
	let n = Array(16).fill(0);
	for (let r = 0; r < 4; r++) for (let i = 0; i < 4; i++) for (let a = 0; a < 4; a++) n[r * 4 + i] += e[a * 4 + i] * t[r * 4 + a];
	return n;
}
function x(e = [
	0,
	0,
	0
], t = [
	0,
	0,
	0,
	1
], n = [
	1,
	1,
	1
]) {
	let [r, i, a, o] = t, [s, c, l] = n;
	return [
		(1 - 2 * (i * i + a * a)) * s,
		2 * (r * i + a * o) * s,
		2 * (r * a - i * o) * s,
		0,
		2 * (r * i - a * o) * c,
		(1 - 2 * (r * r + a * a)) * c,
		2 * (i * a + r * o) * c,
		0,
		2 * (r * a + i * o) * l,
		2 * (i * a - r * o) * l,
		(1 - 2 * (r * r + i * i)) * l,
		0,
		e[0],
		e[1],
		e[2],
		1
	];
}
function S(e) {
	let [t, n, r, i, a, o, s, c, l] = [
		e[0],
		e[4],
		e[8],
		e[1],
		e[5],
		e[9],
		e[2],
		e[6],
		e[10]
	], u = t * (a * l - o * c) - n * (i * l - o * s) + r * (i * c - a * s), d = 1 / (u || 1);
	return {
		n: [
			(a * l - o * c) * d,
			-(i * l - o * s) * d,
			(i * c - a * s) * d,
			-(n * l - r * c) * d,
			(t * l - r * s) * d,
			-(t * c - n * s) * d,
			(n * o - r * a) * d,
			-(t * o - r * i) * d,
			(t * a - n * i) * d
		],
		mirrored: u < 0
	};
}
var C = {
	SCALAR: 1,
	VEC2: 2,
	VEC3: 3,
	VEC4: 4,
	MAT4: 16
};
function w(e, t, n) {
	let r = e.accessors?.[n];
	if (!r) throw Error(`The model points at accessor ${n}, which is missing.`);
	let i = C[r.type] ?? 1, a = r.normalized === !0, o = r.bufferView === void 0 ? new Float32Array(r.count * i) : T(e, t, r.bufferView, r.byteOffset ?? 0, r.componentType, a, r.count, i), s = r.sparse;
	if (s?.count) {
		let n = T(e, t, s.indices.bufferView, s.indices.byteOffset ?? 0, s.indices.componentType, !1, s.count, 1), c = T(e, t, s.values.bufferView, s.values.byteOffset ?? 0, r.componentType, a, s.count, i);
		for (let e = 0; e < s.count; e++) {
			let t = n[e];
			t < r.count && o.set(c.subarray(e * i, e * i + i), t * i);
		}
	}
	return {
		data: o,
		size: i
	};
}
function T(e, t, n, r, i, a, o, s) {
	let c = new Float32Array(o * s), l = e.bufferViews[n], u = t[l.buffer ?? 0], d = {
		5120: 1,
		5121: 1,
		5122: 2,
		5123: 2,
		5125: 4,
		5126: 4
	}[i] ?? 4, f = l.byteStride || d * s, p = u.byteOffset + (l.byteOffset ?? 0) + r, m = new DataView(u.buffer);
	for (let e = 0; e < o; e++) for (let t = 0; t < s; t++) {
		let n = p + e * f + t * d, r;
		switch (i) {
			case 5126:
				r = m.getFloat32(n, !0);
				break;
			case 5125:
				r = m.getUint32(n, !0);
				break;
			case 5123:
				r = m.getUint16(n, !0), a && (r /= 65535);
				break;
			case 5122:
				r = m.getInt16(n, !0), a && (r = Math.max(r / 32767, -1));
				break;
			case 5121:
				r = m.getUint8(n), a && (r /= 255);
				break;
			default: r = m.getInt8(n), a && (r = Math.max(r / 127, -1));
		}
		c[e * s + t] = r;
	}
	return c;
}
var E = (e) => {
	let t = /^data:([^;,]*)(;base64)?,(.*)$/s.exec(e);
	return t ? {
		mime: t[1] || "application/octet-stream",
		bytes: t[2] ? a(t[3]) : new TextEncoder().encode(decodeURIComponent(t[3]))
	} : null;
};
function D(e, t, r = () => null, i = {}) {
	let a = (e.extensionsRequired ?? []).filter((e) => v[e]);
	if (a.length) throw Error(`This model uses ${a.map((e) => v[e]).join(" and ")}; import it in 3D mode, which decodes it.`);
	let o = (e.buffers ?? []).map((e, n) => {
		if (e.uri === void 0) {
			if (n === 0 && t) return t;
			throw Error("The model’s data is missing.");
		}
		let i = E(e.uri)?.bytes ?? r(decodeURIComponent(e.uri));
		if (!i) throw Error(`The model needs "${e.uri}" beside it.`);
		return i;
	}), c = /* @__PURE__ */ new Map(), l = [], u = (t) => {
		if (!t || typeof t.index != "number" || (t.texCoord ?? 0) !== 0) return -1;
		if (c.has(t.index)) return c.get(t.index);
		let n = e.textures?.[t.index], i = n?.source ?? n?.extensions?.EXT_texture_webp?.source, a = e.images?.[i], s = null;
		if (a?.bufferView !== void 0) {
			let t = e.bufferViews[a.bufferView], n = o[t.buffer ?? 0];
			s = {
				mime: a.mimeType ?? "image/png",
				bytes: n.slice(t.byteOffset ?? 0, (t.byteOffset ?? 0) + t.byteLength)
			};
		} else if (typeof a?.uri == "string" && (s = E(a.uri), !s)) {
			let e = r(decodeURIComponent(a.uri));
			e && (s = {
				mime: /\.jpe?g$/i.test(a.uri) ? "image/jpeg" : /\.webp$/i.test(a.uri) ? "image/webp" : "image/png",
				bytes: e
			});
		}
		let u = s && /^image\/(png|jpeg|webp)$/.test(s.mime) ? l.push(s) - 1 : -1;
		return c.set(t.index, u), u;
	}, d = (e.materials ?? []).map((e) => {
		let t = e.pbrMetallicRoughness ?? {}, n = t.baseColorFactor ?? [
			1,
			1,
			1,
			1
		];
		return {
			color: [
				n[0] ?? 1,
				n[1] ?? 1,
				n[2] ?? 1
			],
			opacity: n[3] ?? 1,
			metalness: t.metallicFactor ?? 1,
			roughness: t.roughnessFactor ?? 1,
			texture: u(t.baseColorTexture),
			normalTexture: u(e.normalTexture),
			normalScale: typeof e.normalTexture?.scale == "number" ? e.normalTexture.scale : 1,
			roughnessTexture: u(t.metallicRoughnessTexture),
			occlusionTexture: u(e.occlusionTexture),
			occlusionStrength: typeof e.occlusionTexture?.strength == "number" ? e.occlusionTexture.strength : 1,
			emissive: (e.emissiveFactor ?? [
				0,
				0,
				0
			]).slice(0, 3).map((t) => t * (e.extensions?.KHR_materials_emissive_strength?.emissiveStrength ?? 1)),
			emissiveTexture: u(e.emissiveTexture),
			...N(e.extensions ?? {}, u),
			cutout: e.alphaMode === "MASK" || e.alphaMode === "BLEND",
			doubleSided: e.doubleSided === !0,
			...e.extensions?.KHR_materials_unlit ? { unlit: !0 } : {},
			...h(e.extras?.gleamshelf)
		};
	}), f = -1, p = [], m = O(e, o), g = i.expressions && e.asset?.generator !== "Gleamshelf", _ = [], C = (t, r, a, c) => {
		let l = e.nodes?.[t];
		if (!l || a > 64) return;
		let u = b(r, l.matrix ?? x(l.translation, l.rotation, l.scale)), h = e.meshes?.[l.mesh], v = m?.boneOfNode.get(t) ?? c;
		if (h) {
			let { n: t, mirrored: r } = S(u);
			for (let a of h.primitives ?? []) {
				if ((a.mode ?? 4) !== 4 || a.attributes?.POSITION === void 0) continue;
				let c = w(e, o, a.attributes.POSITION).data, y = c.length / 3, b = new Float32Array(c.length), x = l.skin !== void 0 && m && a.attributes.JOINTS_0 !== void 0 ? w(e, o, a.attributes.JOINTS_0).data : null, S = x && a.attributes.WEIGHTS_0 !== void 0 ? w(e, o, a.attributes.WEIGHTS_0).data : null, C = S ? m.jointMatrices[l.skin] : void 0;
				for (let e = 0; e < y; e++) {
					let [t, n, r] = [
						c[e * 3],
						c[e * 3 + 1],
						c[e * 3 + 2]
					];
					if (C) for (let i = 0; i < 4; i++) {
						let a = S[e * 4 + i], o = a ? C[x[e * 4 + i]] : void 0;
						if (o) for (let i = 0; i < 3; i++) b[e * 3 + i] += a * (o[i] * t + o[4 + i] * n + o[8 + i] * r + o[12 + i]);
					}
					else for (let i = 0; i < 3; i++) b[e * 3 + i] = u[i] * t + u[4 + i] * n + u[8 + i] * r + u[12 + i];
				}
				let T = a.indices === void 0 ? Uint32Array.from({ length: y }, (e, t) => t) : Uint32Array.from(w(e, o, a.indices).data);
				if (r) for (let e = 0; e < T.length; e += 3) [T[e + 1], T[e + 2]] = [T[e + 2], T[e + 1]];
				let E;
				if (a.attributes.NORMAL !== void 0) {
					let n = w(e, o, a.attributes.NORMAL).data;
					E = new Float32Array(n.length);
					for (let e = 0; e < y; e++) {
						let [r, i, a] = [
							n[e * 3],
							n[e * 3 + 1],
							n[e * 3 + 2]
						], o = [
							t[0] * r + t[1] * i + t[2] * a,
							t[3] * r + t[4] * i + t[5] * a,
							t[6] * r + t[7] * i + t[8] * a
						];
						if (C) {
							o = [
								0,
								0,
								0
							];
							for (let t = 0; t < 4; t++) {
								let n = S[e * 4 + t], s = n ? C[x[e * 4 + t]] : void 0;
								if (s) for (let e = 0; e < 3; e++) o[e] += n * (s[e] * r + s[4 + e] * i + s[8 + e] * a);
							}
						}
						let s = Math.hypot(o[0], o[1], o[2]) || 1;
						E.set([
							o[0] / s,
							o[1] / s,
							o[2] / s
						], e * 3);
					}
				} else E = s(b, T);
				let D = a.attributes.TEXCOORD_0 === void 0 ? null : w(e, o, a.attributes.TEXCOORD_0).data, O = null;
				if (a.attributes.COLOR_0 !== void 0) {
					let t = w(e, o, a.attributes.COLOR_0);
					O = new Float32Array(y * 3);
					for (let e = 0; e < y; e++) O.set([
						t.data[e * t.size],
						t.data[e * t.size + 1],
						t.data[e * t.size + 2]
					], e * 3);
				}
				let k = typeof a.material == "number" && d[a.material] ? a.material : -1;
				k < 0 && (f < 0 && (f = d.push(n()) - 1), k = f);
				let j = {
					positions: b,
					normals: E,
					uvs: D,
					colors: O,
					indices: T,
					material: k
				}, M = h.extras?.targetNames ?? a.extras?.targetNames;
				if (g && M?.length && a.targets?.length) {
					let t = a.targets.slice(0, M.length).map((t) => {
						let n = t.POSITION === void 0 ? null : w(e, o, t.POSITION).data, r = new Float32Array(y * 3);
						if (!n) return r;
						for (let e = 0; e < y; e++) {
							let [t, i, a] = [
								n[e * 3],
								n[e * 3 + 1],
								n[e * 3 + 2]
							];
							if (C) for (let n = 0; n < 4; n++) {
								let o = S[e * 4 + n], s = o ? C[x[e * 4 + n]] : void 0;
								if (s) for (let n = 0; n < 3; n++) r[e * 3 + n] += o * (s[n] * t + s[4 + n] * i + s[8 + n] * a);
							}
							else for (let n = 0; n < 3; n++) r[e * 3 + n] = u[n] * t + u[4 + n] * i + u[8 + n] * a;
						}
						return r;
					});
					_.push({
						part: p.length,
						names: M.slice(0, t.length),
						moves: t
					});
				}
				if (m) {
					let t = l.skin !== void 0 && a.attributes.JOINTS_0 !== void 0 ? w(e, o, a.attributes.JOINTS_0).data : null, n = t && a.attributes.WEIGHTS_0 !== void 0 ? w(e, o, a.attributes.WEIGHTS_0).data : null, r = new Uint16Array(y * 4), i = new Float32Array(y * 4), s = l.skin === void 0 ? void 0 : m.boneOfJoint[l.skin];
					for (let e = 0; e < y; e++) if (!t || !n || !s) r[e * 4] = Math.max(0, v), i[e * 4] = 1;
					else for (let a = 0; a < 4; a++) r[e * 4 + a] = s[t[e * 4 + a]] ?? 0, i[e * 4 + a] = n[e * 4 + a];
					j.joints = r, j.skinWeights = i;
				}
				i.trim && A(j, _.at(-1)?.part === p.length ? _.at(-1).moves : []), p.push(j);
			}
		}
		for (let e of l.children ?? []) C(e, u, a + 1, v);
	}, T = e.scenes?.[e.scene ?? 0]?.nodes ?? (e.nodes ?? []).map((e, t) => t);
	for (let e of T) C(e, y, 0, -1);
	if (!p.length) throw Error("The model has no triangles to draw.");
	return {
		...P(p, d, l),
		...m ? { skeleton: m.bones } : {},
		..._.length ? j(_, p.length) : M(e, o)
	};
}
function O(e, t) {
	let n = e.skins ?? [], r = e.nodes ?? [];
	if (!n.length || !r.some((e) => e.skin !== void 0 && e.mesh !== void 0)) return null;
	let i = /* @__PURE__ */ new Map();
	r.forEach((e, t) => (e.children ?? []).forEach((e) => i.set(e, t)));
	let a = (e) => r[e].matrix ?? x(r[e].translation, r[e].rotation, r[e].scale), o = (e, t = 0) => i.has(e) && t < 64 ? b(o(i.get(e), t + 1), a(e)) : a(e), s = /* @__PURE__ */ new Map(), c = {};
	if (n.forEach((n, r) => {
		let i = n.inverseBindMatrices === void 0 ? null : w(e, t, n.inverseBindMatrices).data;
		c[r] = (n.joints ?? []).map((e, t) => {
			let n = o(e);
			return s.has(e) || s.set(e, [
				n[12],
				n[13],
				n[14]
			]), i ? b(n, Array.from(i.subarray(t * 16, t * 16 + 16))) : n;
		});
	}), !s.size) return null;
	let l = (e) => {
		let t = i.get(e);
		for (let e = 0; t !== void 0 && e < 64; e++, t = i.get(t)) if (s.has(t)) return t;
		return -1;
	}, u = (e) => {
		let t = l(e);
		return t < 0 ? 0 : 1 + u(t);
	}, d = [...s.keys()].sort((e, t) => u(e) - u(t) || e - t).slice(0, 256), f = new Map(d.map((e, t) => [e, t])), p = d.map((e) => ({
		name: String(r[e].name ?? `Bone ${f.get(e) + 1}`).slice(0, 40),
		parent: l(e) < 0 ? -1 : f.get(l(e)) ?? -1,
		head: s.get(e),
		tail: s.get(e)
	}));
	d.forEach((e, t) => {
		let n = r[e].extras?.gleamshelf?.tail;
		p[t].tail = Array.isArray(n) && n.length === 3 ? n : k(p, t);
	});
	let m = /* @__PURE__ */ new Map(), h = (e) => {
		for (let t = e, n = 0; t !== void 0 && n < 64; t = i.get(t), n++) if (f.has(t)) return f.get(t);
		return 0;
	};
	r.forEach((e, t) => {
		s.has(t) && m.set(t, h(t));
	});
	let g = {};
	return n.forEach((e, t) => g[t] = (e.joints ?? []).map((e) => h(e))), {
		bones: p,
		boneOfNode: m,
		boneOfJoint: g,
		jointMatrices: c
	};
}
function k(e, t) {
	let n = e[t], r = e.filter((e) => e.parent === t);
	if (r.length) {
		let e = r.map((e) => e.head), t = e.reduce((t, n) => [
			t[0] + n[0] / e.length,
			t[1] + n[1] / e.length,
			t[2] + n[2] / e.length
		], [
			0,
			0,
			0
		]);
		if (Math.hypot(t[0] - n.head[0], t[1] - n.head[1], t[2] - n.head[2]) > 1e-5) return t;
	}
	let i = n.parent >= 0 ? e[n.parent].head : [
		n.head[0],
		n.head[1] - .1,
		n.head[2]
	], a = n.head.map((e, t) => e - i[t]);
	return n.head.map((e, t) => e + a[t] * .3);
}
function A(e, t) {
	let n = e.positions.length / 3, r = new Int32Array(n).fill(-1), i = 0;
	for (let t of e.indices) r[t] === -1 && (r[t] = i++);
	if (i === n) return;
	let a = new Uint32Array(i);
	r.forEach((e, t) => e >= 0 && (a[e] = t));
	let o = (e, t) => {
		let n = new e.constructor(i * t);
		for (let r = 0; r < i; r++) n.set(e.subarray(a[r] * t, a[r] * t + t), r * t);
		return n;
	};
	e.positions = o(e.positions, 3), e.normals = o(e.normals, 3), e.uvs &&= o(e.uvs, 2), e.colors &&= o(e.colors, 3), e.joints &&= o(e.joints, 4), e.skinWeights &&= o(e.skinWeights, 4);
	for (let e = 0; e < t.length; e++) t[e] = o(t[e], 3);
	e.indices = e.indices.map((e) => r[e]);
}
function j(e, t) {
	let n = [];
	for (let t of e) for (let e of t.names) n.includes(e) || n.push(e);
	return { morphs: {
		names: n,
		moves: n.map((n) => {
			let r = Array.from({ length: t }, () => null);
			for (let t of e) {
				let e = t.names.indexOf(n);
				e >= 0 && (r[t.part] = t.moves[e]);
			}
			return r;
		})
	} };
}
function M(e, t) {
	let n = e.meshes?.[0], r = n?.extras?.targetNames;
	return e.asset?.generator !== "Gleamshelf" || !r?.length ? {} : { morphs: {
		names: r,
		moves: r.map((r, i) => n.primitives.map((n) => {
			let r = n.targets?.[i]?.POSITION;
			return r === void 0 || e.accessors[r].bufferView === void 0 ? null : w(e, t, r).data;
		}))
	} };
}
function N(e, t) {
	let n = e.KHR_materials_clearcoat ?? {}, r = e.KHR_materials_sheen ?? {}, i = e.KHR_materials_transmission ?? {}, a = (e, t) => typeof e == "number" && Number.isFinite(e) ? e : t;
	return {
		clearcoat: a(n.clearcoatFactor, 0),
		clearcoatTexture: t(n.clearcoatTexture),
		clearcoatRoughness: a(n.clearcoatRoughnessFactor, 0),
		clearcoatRoughnessTexture: t(n.clearcoatRoughnessTexture),
		clearcoatNormalTexture: t(n.clearcoatNormalTexture),
		clearcoatNormalScale: a(n.clearcoatNormalTexture?.scale, 1),
		sheenColor: e.KHR_materials_sheen ? (r.sheenColorFactor ?? [
			0,
			0,
			0
		]).slice(0, 3).map((e) => a(e, 0)) : [
			0,
			0,
			0
		],
		sheenColorTexture: t(r.sheenColorTexture),
		sheenRoughness: a(r.sheenRoughnessFactor, 0),
		sheenRoughnessTexture: t(r.sheenRoughnessTexture),
		transmission: a(i.transmissionFactor, 0),
		transmissionTexture: t(i.transmissionTexture),
		ior: Math.min(3, Math.max(1, a(e.KHR_materials_ior?.ior, 1.5)))
	};
}
function P(e, t, n) {
	let { min: r, max: i } = o(e);
	return {
		parts: e,
		materials: t,
		textures: n,
		min: r,
		max: i,
		triangles: e.reduce((e, t) => e + t.indices.length / 3, 0)
	};
}
function F(e, t, n = {}) {
	let r = new DataView(e.buffer, e.byteOffset, e.byteLength);
	if (e.byteLength >= 12 && r.getUint32(0, !0) === c) {
		let i = 12, a = null, o = null;
		for (; i + 8 <= e.byteLength;) {
			let t = r.getUint32(i, !0), n = r.getUint32(i + 4, !0), s = e.subarray(i + 8, i + 8 + t);
			n === l ? a = JSON.parse(new TextDecoder().decode(s)) : n === u && (o = s), i += 8 + d(t);
		}
		if (!a) throw Error("That GLB has no model description in it.");
		return D(a, o, t, n);
	}
	try {
		return D(JSON.parse(new TextDecoder().decode(e)), null, t, n);
	} catch (e) {
		throw e instanceof SyntaxError ? Error("That is not a glTF or GLB model.") : e;
	}
}
var I = /* @__PURE__ */ new Map();
function L(e, t) {
	let n = I.get(e);
	if (n && n.data === t) return n.asset;
	let r = F(a(t));
	return I.set(e, {
		data: t,
		asset: r
	}), I.size > 24 && I.delete(I.keys().next().value), r;
}
var R = /* @__PURE__ */ new WeakMap();
function z(e) {
	let t = R.get(e);
	if (t) return t;
	let n = e.triangles, r = new Float32Array(n * 9), i = new Uint32Array(n * 4), a = 0;
	e.parts.forEach((e, t) => {
		for (let n = 0; n < e.indices.length; n += 3, a++) {
			for (let t = 0; t < 3; t++) {
				let o = e.indices[n + t];
				r.set([
					e.positions[o * 3],
					e.positions[o * 3 + 1],
					e.positions[o * 3 + 2]
				], a * 9 + t * 3), i[a * 4 + 1 + t] = o;
			}
			i[a * 4] = t;
		}
	});
	let o = Uint32Array.from({ length: n }, (e, t) => t), s = new Float32Array(n * 3);
	for (let e = 0; e < n; e++) for (let t = 0; t < 3; t++) s[e * 3 + t] = (r[e * 9 + t] + r[e * 9 + 3 + t] + r[e * 9 + 6 + t]) / 3;
	let c = [], l = [], u = (e, t) => {
		let n = l.length / 3;
		l.push(0, 0, 0);
		let [i, a, d, f, p, m] = [
			Infinity,
			Infinity,
			Infinity,
			-Infinity,
			-Infinity,
			-Infinity
		];
		for (let n = e; n < t; n++) {
			let e = o[n] * 9;
			for (let t = 0; t < 9; t += 3) i = Math.min(i, r[e + t]), a = Math.min(a, r[e + t + 1]), d = Math.min(d, r[e + t + 2]), f = Math.max(f, r[e + t]), p = Math.max(p, r[e + t + 1]), m = Math.max(m, r[e + t + 2]);
		}
		if (c.push(i, a, d, f, p, m), t - e <= 4) return l[n * 3] = 1, l[n * 3 + 1] = e, l[n * 3 + 2] = t - e, n;
		let h = f - i >= p - a && f - i >= m - d ? 0 : p - a >= m - d ? 1 : 2, g = Array.from(o.subarray(e, t)).sort((e, t) => s[e * 3 + h] - s[t * 3 + h]);
		o.set(g, e);
		let _ = e + t >> 1;
		u(e, _);
		let v = u(_, t);
		return l[n * 3] = 0, l[n * 3 + 1] = v, n;
	};
	n && u(0, n);
	let d = Float32Array.from(c), f = Uint32Array.from(l), p = (e, t, a, s, c) => {
		if (!n) return null;
		let l = [
			1 / t[0],
			1 / t[1],
			1 / t[2]
		], u = null, p = s, m = [0];
		for (; m.length;) {
			let n = m.pop(), s = a, h = p;
			for (let t = 0; t < 3; t++) {
				let r = (d[n * 6 + t] - e[t]) * l[t], i = (d[n * 6 + 3 + t] - e[t]) * l[t];
				if (r > i && ([r, i] = [i, r]), s = Math.max(s, r), h = Math.min(h, i), s > h) break;
			}
			if (!(s > h)) {
				if (f[n * 3] === 1) {
					let s = f[n * 3 + 1], l = f[n * 3 + 2];
					for (let n = s; n < s + l; n++) {
						let s = o[n], l = s * 9, d = [
							r[l + 3] - r[l],
							r[l + 4] - r[l + 1],
							r[l + 5] - r[l + 2]
						], f = [
							r[l + 6] - r[l],
							r[l + 7] - r[l + 1],
							r[l + 8] - r[l + 2]
						], m = [
							t[1] * f[2] - t[2] * f[1],
							t[2] * f[0] - t[0] * f[2],
							t[0] * f[1] - t[1] * f[0]
						], h = d[0] * m[0] + d[1] * m[1] + d[2] * m[2];
						if (Math.abs(h) < 1e-12) continue;
						let g = 1 / h, _ = [
							e[0] - r[l],
							e[1] - r[l + 1],
							e[2] - r[l + 2]
						], v = (_[0] * m[0] + _[1] * m[1] + _[2] * m[2]) * g;
						if (v < 0 || v > 1) continue;
						let y = [
							_[1] * d[2] - _[2] * d[1],
							_[2] * d[0] - _[0] * d[2],
							_[0] * d[1] - _[1] * d[0]
						], b = (t[0] * y[0] + t[1] * y[1] + t[2] * y[2]) * g;
						if (b < 0 || v + b > 1) continue;
						let x = (f[0] * y[0] + f[1] * y[1] + f[2] * y[2]) * g;
						if (!(x <= a || x >= p) && (p = x, u = {
							t: x,
							part: i[s * 4],
							a: i[s * 4 + 1],
							b: i[s * 4 + 2],
							c: i[s * 4 + 3],
							u: v,
							v: b
						}, c)) return u;
					}
				} else m.push(f[n * 3 + 1], n + 1);
			}
		}
		return u;
	}, m = {
		intersect: (e, t, n = 0, r = Infinity) => p(e, t, n, r, !1),
		occluded: (e, t, n = 0, r = Infinity) => p(e, t, n, r, !0) !== null
	};
	return R.set(e, m), m;
}
//#endregion
export { n as a, L as c, F as d, i as f, s as i, z as l, _ as m, k as n, P as o, t as p, o as r, a as s, e as t, D as u };

//# sourceMappingURL=mesh-DZeCIO4D.js.map