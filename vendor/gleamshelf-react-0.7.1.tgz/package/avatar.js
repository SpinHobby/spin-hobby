export { t as AvatarMode } from "./AvatarMode-BYEvOCr4.js";
