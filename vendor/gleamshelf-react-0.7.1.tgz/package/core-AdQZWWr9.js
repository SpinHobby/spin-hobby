import { n as e } from "./rolldown-runtime-DArdT4gl.js";
import { d as t, s as n } from "./src-Dp2bJp0u.js";
import { Cr as r, i, wt as a } from "./three.core-BCwsimN9.js";
import { a as o, c as s, d as c, f as l, i as u, l as d, m as f, n as p, o as m, p as h, r as g, s as _, t as v, u as y } from "./mesh-DZeCIO4D.js";
import { $ as b, $i as x, $n as S, $r as C, $t as w, Ai as T, An as E, Ar as D, At as O, B as k, Bi as ee, Bn as te, Br as ne, Bt as re, C as ie, Ci as ae, Cn as oe, Cr as se, Ct as ce, D as A, Di as le, Dn as ue, Dr as de, Dt as fe, E as pe, Ei as me, En as he, Er as ge, Et as _e, F as ve, Fi as ye, Fn as be, Fr as xe, Ft as Se, G as Ce, Gi as j, Gn as we, Gr as M, Gt as Te, H as Ee, Hi as De, Hn as Oe, Hr as ke, Ht as Ae, I as je, Ii as Me, In as Ne, Ir as Pe, It as Fe, J as Ie, Ji as Le, Jn as Re, Jr as ze, Jt as Be, K as Ve, Ki as He, Kn as Ue, Kr as We, Kt as Ge, L as Ke, Li as qe, Ln as Je, Lr as Ye, Lt as Xe, M as Ze, Mi as Qe, Mn as $e, Mr as et, Mt as tt, N as nt, Ni as rt, Nn as it, Nr as at, Nt as ot, O as st, Oi as ct, On as lt, Or as ut, Ot as dt, P as ft, Pi as pt, Pn as mt, Pr as ht, Pt as gt, Q as _t, Qi as vt, Qn as yt, Qt as bt, R as xt, Ri as St, Rn as Ct, Rr as wt, Rt as Tt, S as Et, Si as Dt, Sn as Ot, Sr as kt, St as At, T as N, Ti as jt, Tn as Mt, Tr as Nt, Tt as Pt, U as Ft, Ui as It, Un as Lt, Ur as Rt, Ut as zt, V as Bt, Vi as Vt, Vn as Ht, Vr as Ut, Vt as Wt, W as Gt, Wi as Kt, Wn as qt, Wr as Jt, Wt as Yt, X as Xt, Xi as Zt, Xn as Qt, Xr as $t, Xt as en, Y as tn, Yi as nn, Yn as rn, Yr as an, Yt as on, Z as sn, Zi as cn, Zn as ln, Zr as un, Zt as dn, _ as fn, _a as pn, _i as mn, _n as hn, _r as gn, _t as _n, a as vn, aa as yn, ai as bn, an as xn, ar as Sn, at as Cn, b as wn, bi as Tn, bn as En, br as Dn, bt as On, c as kn, ca as An, ci as jn, cn as Mn, cr as Nn, ct as Pn, d as Fn, da as In, di as Ln, dn as Rn, dr as zn, dt as Bn, ea as Vn, ei as Hn, en as Un, er as Wn, et as Gn, f as Kn, fa as qn, fi as Jn, fn as Yn, fr as Xn, ft as Zn, g as Qn, ga as $n, gi as er, gn as tr, gr as nr, gt as rr, h as ir, ha as ar, hi as or, hn as sr, hr as cr, ht as lr, i as ur, ia as dr, ii as fr, in as pr, ir as mr, it as hr, j as gr, ji as _r, jn as vr, jr as yr, jt as br, k as xr, ki as Sr, kn as Cr, kr as wr, kt as Tr, l as Er, la as Dr, li as Or, ln as kr, lr as Ar, lt as jr, m as Mr, ma as Nr, mi as Pr, mn as Fr, mr as Ir, mt as Lr, n as Rr, na as zr, ni as Br, nn as Vr, nr as Hr, nt as Ur, o as Wr, oa as Gr, oi as Kr, on as qr, or as Jr, ot as Yr, p as Xr, pa as Zr, pi as Qr, pn as $r, pr as ei, pt as ti, q as ni, qi as ri, qn as ii, qr as ai, qt as oi, r as si, ra as ci, ri as li, rn as ui, rr as di, rt as fi, s as pi, sa as mi, si as hi, sn as gi, sr as _i, st as vi, t as yi, ta as bi, ti as xi, tr as Si, tt as Ci, u as wi, ua as Ti, ui as Ei, un as Di, ur as Oi, ut as ki, v as Ai, va as ji, vi as Mi, vn as Ni, vr as Pi, vt as Fi, w as Ii, wi as Li, wn as Ri, wr as zi, wt as Bi, x as P, xi as Vi, xn as Hi, xr as Ui, xt as Wi, y as Gi, ya as Ki, yi as qi, yn as Ji, yr as Yi, yt as Xi, z as Zi, zi as Qi, zn as $i, zr as ea, zt as ta } from "./document-CNMOilB9.js";
import { a as na, c as ra, d as ia, f as aa, i as oa, l as sa, n as ca, o as la, p as ua, s as da, t as fa, u as pa } from "./meshtrace-B2sLsePG.js";
import { $ as ma, A as ha, B as ga, C as _a, D as va, E as ya, F as ba, G as xa, H as Sa, I as Ca, J as wa, K as Ta, L as Ea, M as Da, N as Oa, O as ka, P as Aa, Q as ja, R as Ma, S as Na, T as Pa, U as Fa, V as Ia, W as La, X as Ra, Y as za, Z as Ba, _ as Va, a as Ha, b as Ua, c as Wa, d as Ga, et as Ka, f as qa, g as Ja, h as Ya, i as Xa, j as Za, k as Qa, l as $a, m as eo, o as to, p as no, q as ro, s as io, tt as ao, u as oo, v as so, w as co, x as lo, y as uo, z as fo } from "./ModelMode-D8KMyCwU.js";
import { a as po, i as mo, n as ho, t as go } from "./meshFromThree-C49cjhgD.js";
//#region ../scene3d/src/model/editor.ts
var _o = [
	"light",
	"style",
	"background",
	"ground",
	"camera"
], vo = ["light/extra", "camera/focus"], yo = Object.keys(A("box")).concat([
	"locked",
	"motion",
	"outline",
	"text",
	"pen",
	"children",
	"asset",
	"ownColors",
	"mirror",
	"repeat",
	"revolve"
]);
function bo(e, t, n) {
	return e === "outline" ? N({
		kind: "extrude",
		outline: t
	}, 0, n).outline : e === "revolve" ? Ii(t) : e === "mirror" ? wn(t) : e === "repeat" ? ie(t) : e === "pen" ? N({
		kind: "extrude",
		outline: [[
			[0, 0],
			[1, 0],
			[0, 1]
		]],
		pen: t
	}, 0, n).pen : e === "text" ? N({
		kind: "text",
		outline: [[
			[0, 0],
			[1, 0],
			[0, 1]
		]],
		text: t
	}, 0, n).text : e === "children" ? N({
		kind: "group",
		children: t
	}, 0).children : e === "keyBase" ? Ae(t) : e === "asset" ? N({
		kind: "mesh",
		asset: t
	}, 0, n).asset : e === "ownColors" ? N({
		kind: "mesh",
		asset: "a",
		ownColors: t
	}, 0, n).ownColors : e === "take" ? te(t) : e === "springs" ? mr(t) : e === "life" ? zn(t) : e === "morph" || e === "rig" || e === "nodes" ? N({
		kind: "mesh",
		asset: "a",
		[e]: t
	}, 0, n)[e] : N({
		...A("box"),
		kind: e === "kind" ? t : void 0,
		[e]: t
	}, 0, n)[e];
}
var xo = [
	"cameraKeys",
	"clip",
	"environment",
	"effects",
	"compose",
	"sequence",
	"game",
	"takes",
	"cameraTake",
	"music"
], So = (e, n) => {
	let r = t(e), [i, a] = r;
	if (i === "shapes") {
		if (r.length === 1) {
			if (!Array.isArray(n)) return "invalid-value";
			let e = n.map((e, t) => N(e, t));
			return Ze(e) ? {
				value: e,
				label: "Shapes"
			} : "invalid-value";
		}
		let e = Number(a);
		if (!Number.isInteger(e) || e < 0 || e >= 256) return "invalid-path";
		if (r.length === 2) return {
			value: N(n, e),
			label: "Shape"
		};
		if (r[2] === "children" && r.length >= 4) {
			let e = Number(r[3]);
			if (!Number.isInteger(e) || e < 0 || e >= 256) return "invalid-path";
			if (r.length === 4) return {
				value: N(n, e, !0),
				label: "Shape"
			};
			let t = r[4];
			return r.length !== 5 || !yo.includes(t) || t === "id" || t === "children" ? "invalid-path" : {
				value: bo(t, n, !0),
				label: t
			};
		}
		let t = r[2];
		return r.length !== 3 || !yo.includes(t) || t === "id" ? "invalid-path" : {
			value: bo(t, n, !1),
			label: t
		};
	}
	if (i === "assets" && r.length === 1) return {
		value: ir(n),
		label: "Models"
	};
	if (i === "cameraKeys" && r.length === 1) return {
		value: Wt(n),
		label: "Camera keys"
	};
	if (i === "environment" && r.length === 1) return {
		value: P({ environment: n }).environment,
		label: "Environment"
	};
	if (i === "effects" && r.length === 1) return {
		value: P({ effects: n }).effects,
		label: "Effects"
	};
	if (i === "compose" && r.length === 1) return {
		value: P({ compose: n }).compose,
		label: "Compositor"
	};
	if (i === "sequence" && r.length === 1) return {
		value: P({ sequence: n }).sequence,
		label: "Video strips"
	};
	if (i === "takes" && r.length === 1) return {
		value: Ht(n),
		label: "Takes"
	};
	if (i === "cameraTake" && r.length === 1) return {
		value: $i(n),
		label: "Camera"
	};
	if (i === "music" && r.length === 1) return {
		value: S(n),
		label: "Music"
	};
	if (i === "clip" && r.length === 1) return {
		value: P({ clip: n }).clip,
		label: "Clip length"
	};
	if (i === "game" && r.length === 1) return {
		value: P({ game: n }).game,
		label: "Game"
	};
	if (_o.includes(i ?? "") && r.length === 2 && a) {
		let e = i, t = P({});
		return !(a in t[e]) && !vo.includes(`${e}/${a}`) ? "invalid-path" : {
			value: P({ [e]: {
				...t[e],
				[a]: n
			} })[e][a],
			label: `${e} ${a}`
		};
	}
	return "invalid-path";
}, Co = (e) => e.length === 1 ? `shapes/${e[0]}` : `shapes/${e[0]}/children/${e[1]}`;
yo.push("keys", "keyBase", "keyPath", "triggers", "form", "label", "morph", "lookAt", "rig", "nodes", "take", "springs", "life");
var wo = class extends n {
	constructor(e) {
		super(P(e), So);
	}
	get shapes() {
		return this.doc.shapes;
	}
	fits(e) {
		return Ze([...this.doc.shapes, e]);
	}
	addShape(e, t = {}) {
		let n = N(A(e, this.doc.shapes.length, t), this.doc.shapes.length);
		if (n.kind !== e || !this.fits(n)) return -1;
		if (!t.position) {
			let [e, , t] = this.doc.camera.target, r = this.doc.shapes.length;
			n.position = [
				e + (r ? (r % 2 ? 1 : -1) * .7 * Math.ceil(r / 2) : 0),
				n.size[1] / 2,
				t
			];
		}
		return this.apply(`Add ${n.name.toLowerCase()}`, [["shapes", [...this.doc.shapes, n]]]), this.doc.shapes.length - 1;
	}
	addModel(e, t = {}, n = 1.5) {
		let r = je(), i = Math.max(...e.size, 1e-9), a = e.size.map((e) => Math.max(.01, e / i * n)), o = t.rig ?? yr(s(r, e.data)), c = N(A("mesh", this.doc.shapes.length, {
			name: e.name.slice(0, 60),
			size: a,
			asset: r,
			ownColors: !0,
			...t,
			...o ? { rig: o } : {}
		}), this.doc.shapes.length);
		if (c.kind !== "mesh" || !this.fits(c)) return -1;
		if (!t.position) {
			let [e, , t] = this.doc.camera.target, n = this.doc.shapes.length;
			c.position = [
				e + (n ? (n % 2 ? 1 : -1) * .9 * Math.ceil(n / 2) : 0),
				c.size[1] / 2,
				t
			];
		}
		return this.apply(`Import ${c.name}`, [["assets", {
			...this.doc.assets ?? {},
			[r]: e
		}], ["shapes", [...this.doc.shapes, c]]]), this.doc.shapes.length - 1;
	}
	replaceModelAt(e, t, n = "Change model") {
		let r = Bt(this.doc, e), i = r?.kind === "mesh" && r.asset ? this.doc.assets?.[r.asset] : void 0;
		if (!r || !i) return !1;
		let a = je(), o = r.size[1] / (i.size[1] || 1), c = t.size.map((e) => Math.max(.01, e * o)), l = yr(s(a, t.data)), u = l && r.rig && r.rig.bones.length === l.bones.length ? {
			...l,
			pose: r.rig.pose
		} : l, d = Ft(this.doc.shapes.filter((e) => e.id !== r.id)), f = Object.fromEntries(Object.entries({
			...this.doc.assets ?? {},
			[a]: t
		}).filter(([e]) => e !== r.asset || d.has(e)));
		return this.apply(n, [
			["assets", f],
			[`${Co(e)}/asset`, a],
			[`${Co(e)}/size`, c],
			[`${Co(e)}/position`, [
				r.position[0],
				r.position[1] + (c[1] - r.size[1]) / 2,
				r.position[2]
			]],
			[`${Co(e)}/rig`, u ?? void 0]
		]), !0;
	}
	addShapes(e, t, n) {
		let r = e.map((e, t) => N(e, this.doc.shapes.length + t, !0));
		if (!r.length) return -1;
		let i = r.length > 1 && n ? [A("group", 0, {
			name: n.slice(0, 60),
			children: r,
			combine: "add",
			blend: 0
		})] : r, a = [...this.doc.shapes, ...i];
		return Ze(a) ? (this.apply(t, [["shapes", a]]), this.doc.shapes.length - i.length) : -1;
	}
	playTake(e, t, n = !0, r = `Play ${t.name}`) {
		let i = je();
		this.begin(r), this.set("takes", {
			...this.doc.takes ?? {},
			[i]: t
		}, r);
		let a = e.length === 1 ? this.doc.shapes[e[0]] : this.doc.shapes[e[0]]?.children?.[e[1]];
		return this.updateShapeAt(e, {
			take: { id: i },
			...a?.keys?.[0]?.bones ? { keys: void 0 } : {}
		}, r), n && t.seconds >= 1 && this.set("clip", Math.min(600, Math.round(t.seconds * 100) / 100), r), this.commit(), i;
	}
	updateShapeAt(e, t, n = "Change shape") {
		Bt(this.doc, e) && this.apply(n, Object.entries(t).filter(([e]) => e !== "id").map(([t, n]) => [`${Co(e)}/${t}`, n]));
	}
	updateShapesAt(e, t = "Change shapes") {
		let n = e.filter(([e]) => Bt(this.doc, e)).flatMap(([e, t]) => Object.entries(t).filter(([e]) => e !== "id").map(([t, n]) => [`${Co(e)}/${t}`, n]));
		n.length && this.apply(t, n);
	}
	moveShapes(e, t, n = "Move") {
		this.updateShapesAt(e.flatMap((e, n) => {
			let r = this.doc.shapes[e], i = t[n];
			return r && i && i.some((e) => Math.abs(e) > 1e-9) ? [[[e], xn(r, i)]] : [];
		}), n);
	}
	align(e, t, n) {
		let r = e.map((e) => this.doc.shapes[e]).filter((e) => !!e);
		this.moveShapes(e, Un(r, t, n), "Line up");
	}
	spread(e, t) {
		let n = e.map((e) => this.doc.shapes[e]).filter((e) => !!e);
		this.moveShapes(e, gi(n, t), "Spread evenly");
	}
	toGround(e) {
		let t = e.map((e) => this.doc.shapes[e]).filter((e) => !!e);
		this.moveShapes(e, pr(t), "Put on the ground");
	}
	pasteShapes(e, t = {}, n = [
		.5,
		0,
		.5
	]) {
		let r = ui(e, n).map((e, t) => N(e, this.doc.shapes.length + t)), i = [...this.doc.shapes, ...r];
		if (!r.length || !Ze(i)) return null;
		let a = Object.fromEntries(Object.entries(t).filter(([e]) => !this.doc.assets?.[e]));
		return this.apply(`Paste ${r.length > 1 ? `${r.length} shapes` : r[0].name}`, [...Object.keys(a).length ? [["assets", {
			...this.doc.assets ?? {},
			...a
		}]] : [], ["shapes", i]]), r.map((e, t) => this.doc.shapes.length - r.length + t);
	}
	replaceDesign(e, t = "New design") {
		let n = P(e), r = [["assets", n.assets ?? {}], ["shapes", n.shapes]];
		for (let e of _o) for (let [t, i] of Object.entries(n[e])) r.push([`${e}/${t}`, i]);
		for (let e of xo) r.push([e, n[e]]);
		this.apply(t, r);
	}
	updateShape(e, t, n = "Change shape") {
		this.updateShapeAt([e], t, n);
	}
	setChildren(e, t) {
		this.doc.shapes[e]?.kind === "group" && this.apply("Move group", [[`shapes/${e}/children`, t]]);
	}
	listOf(e) {
		if (e.length === 1) return this.doc.shapes[e[0]] ? {
			list: [...this.doc.shapes],
			at: e[0],
			write: (e, t) => this.apply(t, [["shapes", e]])
		} : null;
		let t = this.doc.shapes[e[0]];
		return t?.children?.[e[1]] ? {
			list: [...t.children],
			at: e[1],
			write: (t, n) => this.apply(n, [[`shapes/${e[0]}/children`, t]])
		} : null;
	}
	removeShapeAt(e) {
		let t = this.listOf(e);
		if (!t) return;
		let n = t.list[t.at].name;
		t.write(t.list.filter((e, n) => n !== t.at), `Delete ${n}`);
	}
	removeShapes(e) {
		let t = new Set(e);
		e.some((e) => this.doc.shapes[e]) && this.apply(`Delete ${t.size} shapes`, [["shapes", this.doc.shapes.filter((e, n) => !t.has(n))]]);
	}
	removeShape(e) {
		this.removeShapeAt([e]);
	}
	duplicateShapeAt(e) {
		let t = this.listOf(e);
		if (!t) return null;
		let n = t.list[t.at], r = (e) => ({
			...e,
			id: je(),
			position: [
				e.position[0] + (n.kind === "group" ? 1 : n.size[0] * .6),
				e.position[1],
				e.position[2]
			],
			children: e.children?.map(r)
		}), i = {
			...r(n),
			name: `${n.name} copy`
		};
		return this.fits(i) ? (t.list.splice(t.at + 1, 0, i), t.write(t.list, `Duplicate ${n.name}`), e.length === 1 ? [t.at + 1] : [e[0], t.at + 1]) : null;
	}
	duplicateShape(e) {
		return this.duplicateShapeAt([e])?.[0] ?? -1;
	}
	moveShapeAt(e, t) {
		let n = this.listOf(e);
		if (!n) return e;
		let r = n.at + t;
		return r < 0 || r >= n.list.length ? e : ([n.list[n.at], n.list[r]] = [n.list[r], n.list[n.at]], n.write(n.list, "Reorder shapes"), e.length === 1 ? [r] : [e[0], r]);
	}
	moveShape(e, t) {
		return this.moveShapeAt([e], t)[0];
	}
	group(e) {
		let t = [...new Set(e)].filter((e) => this.doc.shapes[e] && this.doc.shapes[e].kind !== "group").sort((e, t) => e - t);
		if (!t.length) return -1;
		let n = t.map((e) => this.doc.shapes[e]), r = A("group", 0, {
			name: "Group",
			children: n,
			combine: "add",
			blend: 0
		}), i = this.doc.shapes.filter((e, n) => !t.includes(n)), a = t[0] - t.filter((e) => e < t[0]).length;
		return i.splice(a, 0, r), Ze(i) ? (this.apply("Group", [["shapes", i]]), a) : -1;
	}
	ungroup(e) {
		let t = this.doc.shapes[e];
		if (t?.kind !== "group") return -1;
		let n = [...this.doc.shapes];
		return n.splice(e, 1, ...t.children ?? []), this.apply("Ungroup", [["shapes", n]]), e;
	}
	setSetting(e, t, n, r) {
		this.apply(r ?? `${e} ${t}`, [[`${e}/${t}`, n]]);
	}
	setView(e) {
		let t = Xr[e];
		this.apply(`${e[0].toUpperCase()}${e.slice(1).replace(/-/g, " ")} view`, [
			["camera/yaw", t.yaw],
			["camera/pitch", t.pitch],
			["camera/projection", t.projection]
		]);
	}
	snapOrbit(e, t) {
		let { yaw: n, pitch: r } = this.doc.camera, i = e ? (Math.round(n / 45) + e) * 45 : n, a = t ? Math.min(89, Math.max(-89, (Math.round(r / 30) + t) * 30)) : r;
		this.apply("Turn the view", [["camera/yaw", ((i + 180) % 360 + 360) % 360 - 180], ["camera/pitch", a]]);
	}
	frameAll(e = 1, { nice: t = !1 } = {}) {
		let n = this.doc.shapes.flatMap((e) => e.hidden ? [] : e.kind === "group" ? (e.children ?? []).filter((e) => !e.hidden) : [e]).filter((e) => e.combine === "add");
		if (!n.length) return;
		let r = [];
		for (let e of n) {
			let t = an(e.rotation), n = e.size.map((e) => e / 2);
			for (let i of Rt(e)) for (let e = 0; e < 8; e++) {
				let a = [
					e & 1 ? n[0] : -n[0],
					e & 2 ? n[1] : -n[1],
					e & 4 ? n[2] : -n[2]
				];
				r.push([
					0,
					1,
					2
				].map((e) => i[e] + t[e * 3] * a[0] + t[e * 3 + 1] * a[1] + t[e * 3 + 2] * a[2]));
			}
		}
		let i = [
			0,
			1,
			2
		].map((e) => Math.min(...r.map((t) => t[e]))), a = [
			0,
			1,
			2
		].map((e) => Math.max(...r.map((t) => t[e]))), o = i.map((e, t) => (e + a[t]) / 2), s = this.doc.camera, c = t && (s.pitch < 5 || s.pitch > 60), l = c ? 20 : s.pitch, u = c && Math.abs(s.yaw % 90) < 1 ? s.yaw + 30 : s.yaw, [d, f] = [u * Math.PI / 180, l * Math.PI / 180], p = [
			Math.sin(d) * Math.cos(f),
			Math.sin(f),
			Math.cos(d) * Math.cos(f)
		], m = [
			Math.cos(d),
			0,
			-Math.sin(d)
		], h = [
			-Math.sin(f) * Math.sin(d),
			Math.cos(f),
			-Math.sin(f) * Math.cos(d)
		], g = (e, t) => e[0] * t[0] + e[1] * t[1] + e[2] * t[2], _ = Math.tan(s.fov / 2 * (Math.PI / 180)), v = _ * e, y = 1.12, b = 0;
		for (let e of r) {
			let t = [
				e[0] - o[0],
				e[1] - o[1],
				e[2] - o[2]
			], n = Math.abs(g(t, m)) * y, r = Math.abs(g(t, h)) * y;
			b = Math.max(b, s.projection === "orthographic" ? Math.max(n / v, r / _) : g(t, p) + Math.max(n / v, r / _));
		}
		this.apply(t ? "Fit all" : "Frame all", [
			["camera/target", o],
			["camera/distance", Math.min(200, Math.max(.3, b))],
			...l === s.pitch ? [] : [["camera/pitch", l]],
			...u === s.yaw ? [] : [["camera/yaw", u]]
		]);
	}
	setCamera(e) {
		this.apply("Turn the view", Object.entries(e).map(([e, t]) => [`camera/${e}`, t]));
	}
};
function To(e, t, n = {}) {
	let { color: r, name: i, depth: a = .35, long: o = 2, viewAspect: s = 1 } = n, [c, l] = t >= 1 ? [o, o / t] : [o * t, o], u = new wo({
		...pe(),
		shapes: []
	});
	return u.addShape("extrude", {
		outline: e,
		size: [
			c,
			l,
			a
		],
		position: [
			0,
			l / 2,
			0
		],
		...r ? { color: r } : {},
		...i ? { name: i } : {}
	}), u.frameAll(s), u.document;
}
function Eo(e, t = {}) {
	let { long: n = 2, depth: r = .3, at: i = [0, 0] } = t, a = n * (e.aspect >= 1 ? 1 / e.aspect : 1);
	return e.parts.map((e, t) => A("extrude", t, {
		name: e.name,
		outline: e.outline,
		color: e.color,
		size: [
			Math.max(.01, e.box.w * n),
			Math.max(.01, e.box.h * n),
			r
		],
		position: [
			i[0] + e.box.x * n,
			a / 2 + e.box.y * n,
			i[1]
		],
		round: .03,
		finish: "satin"
	}));
}
//#endregion
//#region ../scene3d/src/model/text.ts
function Do(e, t, n, r = 128) {
	let i = new Uint8Array(t * n), a = new Float32Array(t * n);
	for (let o = 0; o < t * n; o++) {
		let t = e[o * 4 + 3];
		i[o] = +(t >= r), a[o] = Math.min(1, Math.max(0, .5 + (t - r) / 255));
	}
	let o = Pr(i, t, n, Math.max(.25, Math.max(t, n) / 2e3), a).filter((e) => Math.abs(bn(e)) > t * n / 4e4).map((e) => e.map(([e, t]) => [e, -t]));
	return o.length ? xt(o) : null;
}
function Oo(e, t, n) {
	let r = /* @__PURE__ */ new Map();
	for (let i = 0; i < t * n; i++) {
		if (e[i * 4 + 3] < 200) continue;
		let [t, n, a] = [
			e[i * 4],
			e[i * 4 + 1],
			e[i * 4 + 2]
		], o = t >> 4 << 8 | n >> 4 << 4 | a >> 4, s = r.get(o) ?? {
			n: 0,
			r: 0,
			g: 0,
			b: 0
		};
		r.set(o, {
			n: s.n + 1,
			r: s.r + t,
			g: s.g + n,
			b: s.b + a
		});
	}
	let i;
	for (let e of r.values()) (!i || e.n > i.n) && (i = e);
	return i ? `#${[
		i.r,
		i.g,
		i.b
	].map((e) => Math.round(e / i.n).toString(16).padStart(2, "0")).join("")}` : null;
}
function ko(e, t, n, r = {}) {
	let i = Do(e, t, n);
	return i ? To(i.outline, i.aspect, {
		...r,
		color: Oo(e, t, n) ?? void 0
	}) : null;
}
function Ao(e, t, n, r, i = {}) {
	let a = e.split("\n").map((e) => e.trimEnd()).slice(0, 8);
	for (; a.length > 1 && !a[a.length - 1].trim();) a.pop();
	for (; a.length > 1 && !a[0].trim();) a.shift();
	if (!a.some((e) => e.trim())) return null;
	let { align: o = "center", lineHeight: s = 1.15, spacing: c = 0 } = i, l = a.length > 3 ? 160 : 240, u = `${n} ${l}px ${/[\s,]/.test(t) ? t : `"${t}"`}, sans-serif`, d = (e) => {
		e.font = u, c && "letterSpacing" in e && (e.letterSpacing = `${Math.round(c * l)}px`);
	}, f = r(8, 8).getContext("2d");
	if (!f) return null;
	d(f);
	let p = a.map((e) => f.measureText(e || " ").width), m = Math.max(...p, 1), h = l * .15, g = l * s, _ = Math.ceil(m + 2 * h + Math.abs(c) * l), v = Math.ceil(g * (a.length - 1) + l * 1.5), y = r(_, v).getContext("2d");
	return y ? (d(y), y.fillStyle = "#000", y.textBaseline = "middle", a.forEach((e, t) => {
		let n = o === "left" ? h : o === "right" ? h + m - p[t] : h + (m - p[t]) / 2;
		y.fillText(e, n, l * .75 + t * g);
	}), Do(y.getImageData(0, 0, _, v).data, _, v)) : null;
}
var jo = (e, t) => {
	if (typeof OffscreenCanvas < "u") return new OffscreenCanvas(e, t);
	let n = document.createElement("canvas");
	return n.width = e, n.height = t, n;
};
function Mo(e, t, n) {
	let r = t * n, i = 0;
	for (let t = 0; t < r; t++) e[t * 4 + 3] < 250 && i++;
	let a = e;
	if (i < r * .02) {
		let i = 0, o = 0, s = 0, c = 0, l = (n, r) => {
			let a = (r * t + n) * 4;
			i += e[a], o += e[a + 1], s += e[a + 2], c++;
		};
		for (let e = 0; e < t; e++) l(e, 0), l(e, n - 1);
		for (let e = 1; e < n - 1; e++) l(0, e), l(t - 1, e);
		let u = [
			i / c,
			o / c,
			s / c
		];
		a = new Uint8ClampedArray(e);
		for (let t = 0; t < r; t++) {
			let n = Math.hypot(e[t * 4] - u[0], e[t * 4 + 1] - u[1], e[t * 4 + 2] - u[2]) / 441.7;
			a[t * 4 + 3] = Math.round(Math.min(1, Math.max(0, (n - .06) / .08)) * 255);
		}
	}
	let o = Do(a, t, n);
	return o ? {
		...o,
		color: Oo(a, t, n)
	} : null;
}
//#endregion
//#region ../scene3d/src/model/finish.ts
var No = (e, t) => e.style.look === "pixel" ? Math.max(1, e.style.pixel * t / 1e3) : 1;
function Po(e, t, n) {
	let r = No(e, n);
	return [Math.max(1, Math.round(t / r)), Math.max(1, Math.round(n / r))];
}
var Fo = (e) => e.style.look === "pixel" || !!e.background.picture;
function Io(e, t) {
	let n = e.style.look === "pixel";
	return !n && !e.background.picture ? e : {
		...e,
		style: n ? {
			...e.style,
			look: "toon",
			outline: e.style.outline > 0 ? Math.max(e.style.outline, 1e3 / Math.max(1, t)) : 0
		} : e.style,
		background: e.background.picture ? {
			...e.background,
			transparent: !0
		} : e.background
	};
}
function Lo(e) {
	let t = /^data:(image\/[a-z]+);base64,(.*)$/.exec(e);
	if (!t) return null;
	let n = typeof atob == "function" ? atob(t[2]) : Buffer.from(t[2], "base64").toString("binary"), r = new Uint8Array(n.length);
	for (let e = 0; e < n.length; e++) r[e] = n.charCodeAt(e);
	return {
		bytes: r,
		mime: t[1]
	};
}
function Ro(e, t, n, r) {
	let i = new Uint8ClampedArray(t * n * 4), { scene: a, colour: o } = r, s = o ? [
		1,
		3,
		5
	].map((e) => parseInt(o.slice(e, e + 2), 16)) : null, c = a ? Math.max(t / a.width, n / a.height) : 1, l = a ? (a.width * c - t) / 2 : 0, u = a ? (a.height * c - n) / 2 : 0, d = e.width / t, f = e.height / n;
	for (let o = 0; o < n; o++) for (let n = 0; n < t; n++) {
		let p = (o * t + n) * 4, m = Math.min(e.width - 1, Math.floor(r.hard ? n * d : (n + .5) * d)), h = (Math.min(e.height - 1, Math.floor(r.hard ? o * f : (o + .5) * f)) * e.width + m) * 4, g = e.data[h + 3] / 255, _ = s;
		if (a) {
			let e = Math.min(a.width - 1, Math.max(0, Math.floor((n + l) / c))), t = (Math.min(a.height - 1, Math.max(0, Math.floor((o + u) / c))) * a.width + e) * 4;
			_ = [
				a.data[t],
				a.data[t + 1],
				a.data[t + 2]
			];
		}
		if (_) {
			for (let t = 0; t < 3; t++) i[p + t] = e.data[h + t] * g + _[t] * (1 - g);
			i[p + 3] = 255;
		} else for (let t = 0; t < 4; t++) i[p + t] = e.data[h + t];
	}
	return {
		width: t,
		height: n,
		data: i
	};
}
var zo = .05;
function Bo(e, t) {
	let n = e.camera.focus;
	if (!n) return null;
	let r = Math.min(n.blur * .05 * t, 96);
	return r >= .5 ? {
		at: Math.max(.05, e.camera.distance + n.offset),
		radius: r
	} : null;
}
var Vo = 2.5, Ho = (e, t) => t.radius * Math.min(1, Vo * Math.abs(e - t.at) / Math.max(e, 1e-4)), Uo = (e, t) => {
	let n = Math.sqrt((e + .5) / 64) * t, r = e * 2.39996323;
	return [Math.cos(r) * n, Math.sin(r) * n];
};
function Wo(e, t, n, r, i) {
	let a = new Float32Array(e.length), o = t.map((e) => Ho(e, i)), s = Array.from({ length: 64 }, (e, t) => Uo(t, i.radius)), c = [
		0,
		0,
		0,
		0
	];
	for (let i = 0; i < r; i++) for (let l = 0; l < n; l++) {
		let u = i * n + l, d = t[u], f = o[u];
		for (let t = 0; t < 4; t++) c[t] = e[u * 4 + t];
		let p = 1;
		s.forEach(([a, s]) => {
			let u = Math.hypot(a, s), m = Math.min(n - 1, Math.max(0, l + Math.floor(a + .5))), h = Math.min(r - 1, Math.max(0, i - Math.floor(s + .5))) * n + m, g = t[h] > d ? Math.min(o[h], f * 2) : o[h], _ = Go(u - .5, u + .5, g);
			for (let t = 0; t < 4; t++) c[t] += c[t] / p + (e[h * 4 + t] - c[t] / p) * _;
			p++;
		});
		for (let e = 0; e < 4; e++) a[u * 4 + e] = c[e] / p;
	}
	return a;
}
var Go = (e, t, n) => {
	let r = Math.min(1, Math.max(0, (n - e) / (t - e)));
	return r * r * (3 - 2 * r);
};
function Ko(e, t) {
	let n = Math.PI / 180;
	return -[
		Math.sin(e.yaw * n) * Math.cos(e.pitch * n),
		Math.sin(e.pitch * n),
		Math.cos(e.yaw * n) * Math.cos(e.pitch * n)
	].reduce((n, r, i) => n + r * (t[i] - e.target[i]), 0);
}
//#endregion
//#region ../scene3d/src/model/lights.ts
var qo = Math.PI / 180, Jo = (e, t) => [
	Math.sin(e * qo) * Math.cos(t * qo),
	Math.sin(t * qo),
	Math.cos(e * qo) * Math.cos(t * qo)
];
function Yo(e) {
	let { light: t } = e;
	return [{
		dir: Jo(t.azimuth, t.elevation),
		intensity: t.intensity,
		color: t.color,
		shadows: t.shadows
	}, ...(t.extra ?? []).map((e) => ({
		dir: Jo(e.azimuth, e.elevation),
		intensity: e.intensity,
		color: e.color,
		shadows: e.shadows
	}))];
}
//#endregion
//#region ../scene3d/src/model/cpu.ts
var Xo = (e, t) => [
	e[0] - t[0],
	e[1] - t[1],
	e[2] - t[2]
], F = (e, t) => [
	e[0] + t[0],
	e[1] + t[1],
	e[2] + t[2]
], I = (e, t) => [
	e[0] * t,
	e[1] * t,
	e[2] * t
], L = (e, t) => e[0] * t[0] + e[1] * t[1] + e[2] * t[2], Zo = (e, t) => [
	e[1] * t[2] - e[2] * t[1],
	e[2] * t[0] - e[0] * t[2],
	e[0] * t[1] - e[1] * t[0]
], Qo = (e) => I(e, 1 / (Math.hypot(...e) || 1)), R = (e, t, n) => e + (t - e) * n, $o = (e) => Math.min(1, Math.max(0, e)), es = (e, t, n) => {
	let r = $o((n - e) / (t - e));
	return r * r * (3 - 2 * r);
}, ts = (e) => ft(e), ns = Math.PI / 180;
async function rs(e, t) {
	if (!Fo(e)) return is(e, t);
	let { width: n, height: r, region: i } = t, [a, o] = Po(e, n, r), s = a / n, c = await is(Io(e, o), {
		...t,
		width: a,
		height: o,
		...e.style.look === "pixel" ? { samples: 1 } : {},
		...i ? { region: i.map((e, t) => Math.round(e * (t % 2 ? o / r : s))) } : {}
	}), [l, u] = i ? [i[2] - i[0], i[3] - i[1]] : [n, r], d = null, f = e.background.picture ? Lo(e.background.picture) : null, p = t.decodeImage ?? rr;
	return f && p && (d = await p(f.bytes, f.mime)), Ro(c, l, u, {
		hard: e.style.look === "pixel",
		scene: d,
		colour: e.background.transparent ? null : e.background.color
	});
}
async function is(e, t) {
	let { width: n, height: r, samples: i = 1, frame: a = 1, tones: o, region: s, onProgress: c } = t, l = t.meshes ?? await Fi(e, t.decodeImage ?? rr);
	await lr(e, t.decodeImage ?? rr);
	let u = ti(e).flatMap((e) => {
		let t = jr(e.label.picture);
		return t ? [{
			...e,
			pic: t,
			rot: an(e.shape.rotation)
		}] : [];
	}), d = Ee(e), f = (t) => $t(e, t, d), p = (e) => f(e).d, m = e.camera, h = m.target, g = F(h, I([
		Math.sin(m.yaw * ns) * Math.cos(m.pitch * ns),
		Math.sin(m.pitch * ns),
		Math.cos(m.yaw * ns) * Math.cos(m.pitch * ns)
	], m.distance)), _ = Qo(Xo(h, g)), v = Qo(Zo(_, [
		0,
		1,
		0
	])), y = Zo(v, _), b = Math.tan(m.fov / 2 * ns) * a, x = m.projection === "orthographic", S = m.distance * b, C = n / r, w = Yo(e).map((e) => ({
		...e,
		dir: e.dir,
		col: ts(e.color)
	})), T = w[0].dir, E = w[0].col, { intensity: D, ambient: O } = e.light, k = e.style.look, ee = o ? 0 : e.style.outline * r / 1e3, te = ts(e.style.outlineColor), ne = ts(e.background.color), re = x ? 2 * S / r : 2 * b / r, ie = (e, t) => {
		let n = 5e-4 * Math.max(1, t), r = [
			1,
			-1,
			-1
		], i = [
			-1,
			-1,
			1
		], a = [
			-1,
			1,
			-1
		], o = [
			1,
			1,
			1
		];
		return Qo(F(F(I(r, p(F(e, I(r, n)))), I(i, p(F(e, I(i, n))))), F(I(a, p(F(e, I(a, n)))), I(o, p(F(e, I(o, n)))))));
	}, ae = (e, t, n = !1, r = !0) => {
		if (r && l.length && _n(l, e, t, 60)) return 0;
		let i = 1, a = .02;
		for (let r = 0; r < 48; r++) {
			let r = p(F(e, I(t, a)));
			if (n && r < .002) return 0;
			if (i = Math.min(i, 10 * r / a), a += Math.min(Math.max(r, .02), .4), i < .002 || a > 30) break;
		}
		return n ? 1 : $o(i);
	}, oe = (e, t) => {
		let n = 0, r = 1;
		for (let i = 0; i < 5; i++) {
			let a = .02 + .12 * i;
			n += (a - p(F(e, I(t, a)))) * r, r *= .75;
		}
		return $o(1 - 1.6 * n);
	}, se = (e, t, n = !1) => w.map((r, i) => L(t, r.dir) <= 0 ? 0 : r.shadows ? ae(F(e, I(t, .003)), r.dir, n, i === 0) : 1), ce = (t, n, r, i, a, s, c = 1, l) => {
		let u = l?.look ?? k, d = l?.bands ?? e.style.bands;
		u === "clay" && (i = [
			.86,
			.84,
			.82
		]);
		let f = Math.max(L(n, T), 0);
		if (o) {
			let e = se(t, n, !0), r = w.reduce((t, r, i) => t + Math.max(L(n, r.dir), 0) * e[i] * r.intensity, 0) / (D || 1), a = Math.floor(Math.min(r, 1.5) * o + .5) / o;
			return I(i, O * .9 + D * .75 * a);
		}
		let p = se(t, n), m = oe(t, n) * c, h = .5 + .5 * n[1];
		if (u === "flat") return I(i, .82 + .18 * f);
		if (u === "toon") {
			let e = (1 - Math.max(L(n, I(r, -1)), 0)) ** 3 * .25, t = I(i, O * .9 * c);
			return w.forEach((o, s) => {
				let c = Math.max(L(n, o.dir), 0), l = Math.floor(c * p[s] * d + .5) / d, u = Math.max(L(n, Qo(Xo(o.dir, r))), 0) ** a * c * p[s], f = s === 0 ? [
					1,
					1,
					1
				] : o.col;
				t = F(t, [
					0,
					1,
					2
				].map((e) => i[e] * f[e] * o.intensity * .75 * l + o.col[e] * (u >= .92 ? .35 : 0))), s === 0 && (t = F(t, I(o.col, e * l)));
			}), t;
		}
		let g = [
			R(1, i[0], s),
			R(1, i[1], s),
			R(1, i[2], s)
		], _ = I(i, 1 - .6 * s), v = Qo([
			-T[0],
			.3,
			-T[2]
		]), y = Math.max(L(n, v), 0), b = (1 - Math.max(L(n, I(r, -1)), 0)) ** 4, x = [
			0,
			0,
			0
		];
		w.forEach((e, t) => {
			let i = Math.max(L(n, e.dir), 0), o = Math.max(L(n, Qo(Xo(e.dir, r))), 0) ** a * i * p[t] * Math.min(1, Math.max(.2, (a + 8) / 68));
			for (let n = 0; n < 3; n++) x[n] += _[n] * e.col[n] * e.intensity * i * p[t] + g[n] * e.col[n] * e.intensity * o * R(.35, 1.6, s) * (a > 60 ? 1 : .6);
		});
		for (let e = 0; e < 3; e++) x[e] += _[e] * [
			.72,
			.82,
			1
		][e] * O * (.25 + .75 * y) * m + _[e] * O * .45 * h * m + E[e] * b * .22 * D * m * h + _[e] * [
			1,
			.9,
			.8
		][e] * .05 * Math.max(-n[1], 0);
		return x;
	}, A = 500, le = (e, t) => {
		let i = e / n * 2 - 1, a = 1 - t / r * 2, o, s;
		return x ? (o = F(g, F(I(v, i * S * C), I(y, a * S))), s = _) : (o = g, s = Qo(F(_, F(I(v, i * b * C), I(y, a * b))))), pe(o, s, 0);
	}, ue = (e) => {
		let t = es(-.25, .6, e[1]), n = es(.22, .32, e[1]) * (1 - es(.5, .62, e[1]));
		return [
			0,
			1,
			2
		].map((e) => (R([
			.3,
			.28,
			.27
		][e], [
			.85,
			.9,
			1
		][e], t) + 1.6 * n) * (.5 + O) * E[e]);
	}, de = (e, t) => t + (1 - t) * (1 - e) ** 5, fe = (e, t) => Xo(e, I(t, 2 * L(e, t))), pe = (t, n, r) => {
		let i = (e) => {
			r === 0 && (A = e * L(n, _));
		};
		r === 0 && (A = 500);
		let a = e.ground.on && n[1] < -1e-4 ? -t[1] / n[1] : 1e9, s = r === 0 ? ee : 0, c = r ? 5e-4 : x ? 0 : .01, d = 1e9, p = !1, m = f(t);
		for (let e = 0; e < 200; e++) {
			let e = F(t, I(n, c));
			m = f(e);
			let r = x ? re : re * Math.max(c, .01);
			if (d = Math.min(d, m.d / r), m.d < 4e-4 * Math.max(1, c)) {
				p = !0;
				break;
			}
			if (c += m.d * .92, c > 120 || c > a + .5) break;
		}
		let h = l.length ? Xi(l, t, n, Math.min(p && c < a + .001 ? c : Infinity, a)) : null;
		if (h && i(h.t), h?.unlit) return [...h.color, 1];
		if (h) {
			let e = F(t, I(n, h.t)), i = h.normal, a = h.look ?? k, c = ce(e, i, n, h.color, h.shine, h.metal, h.occ, h), l = 1, u = I(n, -1), d = a === "soft" && !o, f = d && (h.clearcoat > 0 || Math.max(...h.sheen) > 0 || h.transmission > 0) && w[0].shadows ? ae(F(e, I(h.shapeNormal, .003)), T) : 1;
			if (h.transmission > 0 && a !== "clay" && !o && r < 4) {
				let t = ((h.ior - 1) / (h.ior + 1)) ** 2, a = de(Math.max(L(i, u), 0), t), o = pe(F(e, I(n, .001)), n, r + 1), s = [
					o[0] * h.color[0],
					o[1] * h.color[1],
					o[2] * h.color[2]
				], d = h.transmission * (1 - a), p = Qo(F(T, u)), m = Math.max(L(i, p), 0) ** Math.max(h.shine, 60) * Math.max(L(i, T), 0) * f * D, g = ue(fe(n, i));
				c = [
					0,
					1,
					2
				].map((e) => R(c[e], s[e], d) + g[e] * a * h.transmission + E[e] * m), l = $o(R(1, o[3], d) + m + a * h.transmission);
			}
			if (d && Math.max(...h.sheen) > 0) {
				let e = (1 - Math.max(L(i, u), 0)) ** R(5, 1.5, h.sheenRoughness), t = D * Math.max(L(i, T), 0) * f * .8;
				c = [
					0,
					1,
					2
				].map((n) => c[n] + h.sheen[n] * e * (E[n] * t + O * .6 * h.occ));
			}
			if (d && h.clearcoat > 0) {
				let e = h.coatNormal, t = de(Math.max(L(e, u), 0), .04), r = Qo(F(T, u)), i = 8 + (1 - h.clearcoatRoughness) ** 2 * 600, a = Math.max(L(e, r), 0) ** i * Math.max(L(e, T), 0) * f * D * (1 + i / 120), o = I(ue(fe(n, e)), R(1, .35, h.clearcoatRoughness));
				c = [
					0,
					1,
					2
				].map((e) => c[e] * (1 - h.clearcoat * t) + h.clearcoat * (E[e] * a + o[e] * t));
			}
			if (a !== "clay" && (c = F(c, h.emissive)), s > 0) {
				let e = es(.12 + .02 * s, .02, Math.abs(L(i, n)));
				c = [
					R(c[0], te[0], e),
					R(c[1], te[1], e),
					R(c[2], te[2], e)
				], l = R(l, 1, e);
			}
			return [...c, l];
		}
		if (p && c < a + .001) {
			i(c);
			let e = F(t, I(n, c)), r = ie(e, c), a = m.color.map((e) => e ** 2.2);
			for (let t of u) {
				let n = t.rot, i = [
					n[0] * r[0] + n[3] * r[1] + n[6] * r[2],
					n[1] * r[0] + n[4] * r[1] + n[7] * r[2],
					n[2] * r[0] + n[5] * r[1] + n[8] * r[2]
				], o = Zn(t.shape, t.label, t.pic.width / t.pic.height, xi(t.shape, e), i);
				if (!o) continue;
				let [s, c, l, u] = Bn(t.pic, o[0], o[1]);
				a = [
					R(a[0], s ** 2.2, u),
					R(a[1], c ** 2.2, u),
					R(a[2], l ** 2.2, u)
				];
			}
			let o = ce(e, r, n, I(a, 1 - .75 * m.glass), m.shine < 6 ? 8 : m.shine, m.metal);
			if (k === "soft") {
				let e = Math.min(1, Math.max(0, (6 - m.shine) / 2)), t = Math.min(1, Math.max(0, (m.shine - 300) / 100)), i = 1 - Math.max(L(r, I(n, -1)), 0);
				if (e > 0 && (o = [
					0,
					1,
					2
				].map((t) => o[t] + e * a[t] * i * i * .9 * (O + .5))), t > 0) {
					let e = .5 + .5 * (n[1] - 2 * L(n, r) * r[1]), a = [
						R(.3, .95, e),
						R(.3, .97, e),
						R(.32, 1, e)
					];
					o = [
						0,
						1,
						2
					].map((e) => o[e] + t * a[e] * (.04 + .5 * i ** 5));
				}
			}
			if (m.glass > 0 && k === "soft") {
				let e = (1 - Math.max(L(r, I(n, -1)), 0)) ** 3, t = .5 + .5 * (n[1] - 2 * L(n, r) * r[1]), i = [
					R(.55, .95, t),
					R(.6, .97, t),
					R(.68, 1, t)
				];
				o = [
					0,
					1,
					2
				].map((t) => o[t] + m.glass * (i[t] * (.08 + .7 * e) + a[t] * .1));
			}
			if (m.glow > 0 && k !== "clay" && (o = [
				0,
				1,
				2
			].map((e) => R(o[e], a[e] * 1.35, m.glow))), s > 0) {
				let e = es(.12 + .02 * s, .02, Math.abs(L(r, n)));
				o = [
					R(o[0], te[0], e),
					R(o[1], te[1], e),
					R(o[2], te[2], e)
				];
			}
			return [...o, 1];
		}
		if (s > 0 && d < s) return [...te, es(s, s * .6, d)];
		if (a < 1e8) {
			i(a);
			let r = F(t, I(n, a)), s = w.map((e) => Math.max(e.intensity, 1e-4)), c = 1 - w.reduce((e, t, n) => e + s[n] * (t.shadows ? ae(F(r, [
				0,
				.002,
				0
			]), t.dir, !!o, n === 0) : 1), 0) / s.reduce((e, t) => e + t, 0), l = o ? 1 : Math.exp(-.08 * Math.hypot(r[0], r[2])), u = c * e.ground.shadow * l;
			return e.background.transparent ? [
				0,
				0,
				0,
				o ? u > .05 ? e.ground.shadow : 0 : u
			] : [
				ne[0] * (1 - u),
				ne[1] * (1 - u),
				ne[2] * (1 - u),
				1
			];
		}
		return e.background.transparent ? [
			0,
			0,
			0,
			0
		] : [...ne, 1];
	}, [me, he, ge, _e] = s ? [
		Math.max(0, s[0]),
		Math.max(0, s[1]),
		Math.min(n, s[2]),
		Math.min(r, s[3])
	] : [
		0,
		0,
		n,
		r
	], ve = o ? null : Bo(e, r), ye = ve ? Math.ceil(ve.radius) + 1 : 0, [be, xe, Se, Ce] = [
		Math.max(0, me - ye),
		Math.max(0, he - ye),
		Math.min(n, ge + ye),
		Math.min(r, _e + ye)
	], [j, we] = [Math.max(0, Se - be), Math.max(0, Ce - xe)], M = new Float32Array(j * we * 4), Te = new Float32Array(ve ? j * we : 0), De = i > 1 && !o, Oe = we || 1;
	for (let e = 0; e < we; e++) {
		for (let t = 0; t < j; t++) {
			let n = le(be + t + .5, xe + e + .5);
			ve && (Te[e * j + t] = A);
			let r = (e * j + t) * 4;
			M[r] = n[0] * n[3], M[r + 1] = n[1] * n[3], M[r + 2] = n[2] * n[3], M[r + 3] = n[3];
		}
		c && e % 16 == 15 && await c((e + 1) / Oe * (De ? .75 : 1));
	}
	if (De) {
		let e = (e, t) => Math.abs(M[e] - M[t]) + Math.abs(M[e + 1] - M[t + 1]) + Math.abs(M[e + 2] - M[t + 2]) > .06 || Math.abs(M[e + 3] - M[t + 3]) > .1, t = new Uint8Array(j * we);
		for (let n = 0; n < we; n++) for (let r = 0; r < j; r++) {
			let i = (n * j + r) * 4;
			(r + 1 < j && e(i, i + 4) || n + 1 < we && e(i, i + j * 4)) && (t[n * j + r] = 1, r + 1 < j && (t[n * j + r + 1] = 1), n + 1 < we && (t[(n + 1) * j + r] = 1));
		}
		let n = [
			[-.375, -.125],
			[.125, -.375],
			[.375, .125],
			[-.125, .375]
		], r = new Float32Array(M);
		for (let e = 0; e < we; e++) {
			for (let i = 0; i < j; i++) {
				if (!t[e * j + i]) continue;
				let a = (e * j + i) * 4;
				for (let [t, o] of n) {
					let n = le(be + i + .5 + t, xe + e + .5 + o);
					r[a] += n[0] * n[3], r[a + 1] += n[1] * n[3], r[a + 2] += n[2] * n[3], r[a + 3] += n[3];
				}
				for (let e = 0; e < 4; e++) r[a + e] /= 5;
			}
			c && e % 16 == 15 && await c(.75 + (e + 1) / Oe * .25);
		}
		M.set(r);
	}
	ve && (M = Wo(M, Te, j, we, ve));
	let [ke, Ae] = [Math.max(0, ge - me), Math.max(0, _e - he)], je = new Uint8ClampedArray(ke * Ae * 4);
	for (let e = 0; e < Ae; e++) for (let t = 0; t < ke; t++) {
		let n = (e + he - xe) * j + (t + me - be), r = (e * ke + t) * 4, i = M[n * 4 + 3];
		i > 0 && (je[r] = 255 * Math.max(0, M[n * 4] / i) ** (1 / 2.2), je[r + 1] = 255 * Math.max(0, M[n * 4 + 1] / i) ** (1 / 2.2), je[r + 2] = 255 * Math.max(0, M[n * 4 + 2] / i) ** (1 / 2.2)), je[r + 3] = 255 * i;
	}
	return {
		width: ke,
		height: Ae,
		data: je
	};
}
//#endregion
//#region ../scene3d/src/model/vector.ts
var as = (e, t, n) => `#${[
	e,
	t,
	n
].map((e) => e.toString(16).padStart(2, "0")).join("")}`, os = (e) => String(Math.round(e * 10) / 10), ss = (e) => e.map((e) => `M${e.map(([e, t]) => `${os(e)} ${os(t)}`).join("L")}Z`).join("");
function cs(e) {
	let { width: t, height: n, data: r } = e, i = /* @__PURE__ */ new Map();
	for (let e = 0; e < t * n; e++) {
		let t = r[e * 4 + 3];
		if (t < 8) continue;
		let n = (r[e * 4] << 16 | r[e * 4 + 1] << 8 | r[e * 4 + 2]) * 256 + Math.round(t / 32);
		i.set(n, (i.get(n) ?? 0) + 1);
	}
	let a = [];
	for (let [e, o] of i) {
		if (o < 6) continue;
		let i = new Uint8Array(t * n);
		for (let a = 0; a < t * n; a++) {
			let t = r[a * 4 + 3];
			t < 8 || (r[a * 4] << 16 | r[a * 4 + 1] << 8 | r[a * 4 + 2]) * 256 + Math.round(t / 32) === e && (i[a] = 1);
		}
		let s = Math.floor(e / 256);
		a.push({
			fill: as(s >> 16 & 255, s >> 8 & 255, s & 255),
			opacity: Math.min(1, e % 256 * 32 / 255),
			contours: Pr(i, t, n, .6),
			size: o
		});
	}
	return a.sort((e, t) => Number(t.opacity < 1) - Number(e.opacity < 1) || t.size - e.size).map(({ fill: e, opacity: t, contours: n }) => ({
		fill: e,
		opacity: t,
		contours: n
	}));
}
async function ls(e, t) {
	let { width: n, height: r, tones: i = 3, frame: a = 1, trim: o = 12, decodeImage: s, onProgress: c } = t, l = e.background.picture, u = cs(await rs(l ? {
		...e,
		background: {
			...e.background,
			transparent: !0,
			picture: ""
		}
	} : e, {
		width: n,
		height: r,
		tones: Math.min(6, Math.max(2, i)),
		frame: a,
		decodeImage: s,
		onProgress: c
	})).filter((e) => e.contours.length), [d, f, p, m] = [
		0,
		0,
		n,
		r
	];
	if (e.background.transparent && !l && o >= 0 && u.length) {
		let e = u.flatMap((e) => e.contours.flat()), t = e.map((e) => e[0]), i = e.map((e) => e[1]);
		d = Math.max(0, Math.floor(Math.min(...t)) - o), f = Math.max(0, Math.floor(Math.min(...i)) - o), p = Math.min(n, Math.ceil(Math.max(...t)) + o) - d, m = Math.min(r, Math.ceil(Math.max(...i)) + o) - f;
	}
	let h = u.map((e) => `<path d="${ss(e.contours)}" fill="${e.fill}"${e.opacity < 1 ? ` fill-opacity="${os(e.opacity)}"` : ""} fill-rule="evenodd"/>`).join("\n"), g = l ? `<image href="${l}" width="${n}" height="${r}" preserveAspectRatio="xMidYMid slice"/>\n` : e.background.transparent ? "" : `<rect width="${n}" height="${r}" fill="${e.background.color}"/>\n`;
	return `<svg xmlns="http://www.w3.org/2000/svg" width="${p}" height="${m}" viewBox="${d} ${f} ${p} ${m}">\n${g}${h}\n</svg>\n`;
}
//#endregion
//#region ../scene3d/src/model/svg.ts
var us = {
	amp: "&",
	lt: "<",
	gt: ">",
	quot: "\"",
	apos: "'"
}, ds = (e) => e.replace(/&(#x[0-9a-f]+|#\d+|\w+);/gi, (e, t) => t[0] === "#" ? String.fromCodePoint(t[1] === "x" || t[1] === "X" ? parseInt(t.slice(2), 16) : parseInt(t.slice(1), 10)) : us[t] ?? e);
function fs(e) {
	let t = {
		tag: "#root",
		attrs: {},
		children: [],
		text: ""
	}, n = [t], r = e.replace(/<!--[\s\S]*?-->/g, "").replace(/<\?[\s\S]*?\?>/g, "").replace(/<!DOCTYPE[^>[]*(\[[\s\S]*?\])?\s*>/gi, "").replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, (e, t) => t.replace(/</g, "&lt;")), i = /<(\/?)([\w:.-]+)((?:\s+[\w:.-]+\s*=\s*(?:"[^"]*"|'[^']*'))*)\s*(\/?)>|([^<]+)/g;
	for (let e = i.exec(r); e; e = i.exec(r)) {
		let t = n[n.length - 1];
		if (e[5] !== void 0) {
			t.text += ds(e[5]);
			continue;
		}
		let r = e[2].replace(/^svg:/, "");
		if (e[1]) {
			let e = n.map((e) => e.tag).lastIndexOf(r);
			e > 0 && (n.length = e);
			continue;
		}
		let i = {}, a = /([\w:.-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g;
		for (let t = a.exec(e[3] ?? ""); t; t = a.exec(e[3] ?? "")) i[t[1]] = ds(t[2] ?? t[3] ?? "");
		let o = {
			tag: r,
			attrs: i,
			children: [],
			text: ""
		};
		t.children.push(o), e[4] || n.push(o);
	}
	return t;
}
var ps = {
	black: "#000000",
	white: "#ffffff",
	red: "#ff0000",
	green: "#008000",
	lime: "#00ff00",
	blue: "#0000ff",
	yellow: "#ffff00",
	cyan: "#00ffff",
	aqua: "#00ffff",
	magenta: "#ff00ff",
	fuchsia: "#ff00ff",
	gray: "#808080",
	grey: "#808080",
	silver: "#c0c0c0",
	maroon: "#800000",
	olive: "#808000",
	navy: "#000080",
	purple: "#800080",
	teal: "#008080",
	orange: "#ffa500",
	pink: "#ffc0cb",
	brown: "#a52a2a",
	gold: "#ffd700",
	indigo: "#4b0082",
	violet: "#ee82ee",
	crimson: "#dc143c",
	coral: "#ff7f50",
	salmon: "#fa8072",
	tomato: "#ff6347",
	darkred: "#8b0000",
	darkgreen: "#006400",
	darkblue: "#00008b",
	lightblue: "#add8e6",
	lightgray: "#d3d3d3",
	lightgrey: "#d3d3d3",
	darkgray: "#a9a9a9",
	darkgrey: "#a9a9a9",
	beige: "#f5f5dc",
	khaki: "#f0e68c",
	turquoise: "#40e0d0",
	skyblue: "#87ceeb",
	royalblue: "#4169e1",
	steelblue: "#4682b4",
	hotpink: "#ff69b4",
	deeppink: "#ff1493",
	orchid: "#da70d6",
	plum: "#dda0dd",
	tan: "#d2b48c",
	chocolate: "#d2691e",
	sienna: "#a0522d",
	forestgreen: "#228b22",
	seagreen: "#2e8b57",
	limegreen: "#32cd32",
	dodgerblue: "#1e90ff",
	slategray: "#708090",
	slategrey: "#708090",
	whitesmoke: "#f5f5f5",
	ivory: "#fffff0",
	lavender: "#e6e6fa"
};
function ms(e, t) {
	if (e === void 0) return;
	let n = e.trim().toLowerCase();
	if (!n || n === "none" || n === "transparent") return null;
	if (n === "currentcolor") return t;
	if (ps[n]) return ps[n];
	let r = /^#([0-9a-f]{3,4})$/.exec(n);
	if (r) return `#${[...r[1].slice(0, 3)].map((e) => e + e).join("")}`;
	if (r = /^#([0-9a-f]{6})([0-9a-f]{2})?$/.exec(n), r) return `#${r[1]}`;
	if (r = /^rgba?\(\s*([\d.]+)(%?)[\s,]+([\d.]+)(%?)[\s,]+([\d.]+)(%?)/.exec(n), r) {
		let e = (e, t) => Math.round(Math.min(255, Math.max(0, t ? Number(e) / 100 * 255 : Number(e))));
		return `#${[
			e(r[1], r[2]),
			e(r[3], r[4]),
			e(r[5], r[6])
		].map((e) => e.toString(16).padStart(2, "0")).join("")}`;
	}
}
var hs = (e) => [
	1,
	3,
	5
].map((t) => parseInt(e.slice(t, t + 2), 16)), gs = (e, t) => {
	let [n, r] = [hs(e), hs(t)];
	return (n[0] - r[0]) ** 2 + (n[1] - r[1]) ** 2 + (n[2] - r[2]) ** 2;
};
function _s(e) {
	let [t, n, r] = hs(e).map((e) => e / 255), i = Math.max(t, n, r), a = Math.min(t, n, r), o = (i + a) / 2;
	if ((i === a ? 0 : (i - a) / (1 - Math.abs(2 * o - 1))) < .15 || i - a < .08) return o > .9 ? "White" : o < .12 ? "Black" : "Grey";
	let s = 0;
	return s = i === t ? ((n - r) / (i - a) + 6) % 6 : i === n ? (r - t) / (i - a) + 2 : (t - n) / (i - a) + 4, s *= 60, s < 15 || s >= 345 ? o > .75 ? "Pink" : "Red" : s < 45 ? o < .4 ? "Brown" : "Orange" : s < 70 ? "Yellow" : s < 160 ? "Green" : s < 195 ? "Teal" : s < 255 ? "Blue" : s < 290 ? "Purple" : "Pink";
}
var vs = [
	1,
	0,
	0,
	1,
	0,
	0
], ys = (e, t) => [
	e[0] * t[0] + e[2] * t[1],
	e[1] * t[0] + e[3] * t[1],
	e[0] * t[2] + e[2] * t[3],
	e[1] * t[2] + e[3] * t[3],
	e[0] * t[4] + e[2] * t[5] + e[4],
	e[1] * t[4] + e[3] * t[5] + e[5]
], bs = (e, [t, n]) => [e[0] * t + e[2] * n + e[4], e[1] * t + e[3] * n + e[5]], xs = (e) => (e.match(/[-+]?(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?/gi) ?? []).map(Number);
function Ss(e) {
	let t = vs;
	if (!e) return t;
	let n = /(matrix|translate|scale|rotate|skewX|skewY)\s*\(([^)]*)\)/g;
	for (let r = n.exec(e); r; r = n.exec(e)) {
		let e = xs(r[2]), n = (e[0] ?? 0) * Math.PI / 180, i = vs;
		if (r[1] === "matrix" && e.length >= 6) i = e.slice(0, 6);
		else if (r[1] === "translate") i = [
			1,
			0,
			0,
			1,
			e[0] ?? 0,
			e[1] ?? 0
		];
		else if (r[1] === "scale") i = [
			e[0] ?? 1,
			0,
			0,
			e[1] ?? e[0] ?? 1,
			0,
			0
		];
		else if (r[1] === "rotate") {
			let [t, r] = [Math.cos(n), Math.sin(n)], [a, o] = [e[1] ?? 0, e[2] ?? 0];
			i = ys(ys([
				1,
				0,
				0,
				1,
				a,
				o
			], [
				t,
				r,
				-r,
				t,
				0,
				0
			]), [
				1,
				0,
				0,
				1,
				-a,
				-o
			]);
		} else r[1] === "skewX" ? i = [
			1,
			0,
			Math.tan(n),
			1,
			0,
			0
		] : r[1] === "skewY" && (i = [
			1,
			Math.tan(n),
			0,
			1,
			0,
			0
		]);
		t = ys(t, i);
	}
	return t;
}
function Cs(e) {
	let t = [], n = /([MLHVCSQTAZmlhvcsqtaz])|([-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?)/g, r = "", i = 0;
	for (let a = n.exec(e); a; a = n.exec(e)) a[1] ? (t.push(a[1]), r = a[1].toLowerCase(), i = 0) : (r === "a" && (i % 7 == 3 || i % 7 == 4) && /^[01]./.test(a[2]) ? (t.push(Number(a[2][0])), n.lastIndex = a.index + 1) : t.push(Number(a[2])), i++);
	return t;
}
function ws(e, t, n, r, i, a, o) {
	if (t === 0 || n === 0 || e[0] === o[0] && e[1] === o[1]) return e[0] === o[0] && e[1] === o[1] ? [] : [[
		e,
		o,
		o
	]];
	t = Math.abs(t), n = Math.abs(n);
	let [s, c] = [Math.cos(r), Math.sin(r)], l = (e[0] - o[0]) / 2, u = (e[1] - o[1]) / 2, d = s * l + c * u, f = -c * l + s * u, p = d * d / (t * t) + f * f / (n * n);
	p > 1 && (t *= Math.sqrt(p), n *= Math.sqrt(p));
	let m = t * t * n * n - t * t * f * f - n * n * d * d, h = t * t * f * f + n * n * d * d, g = (i === a ? -1 : 1) * Math.sqrt(Math.max(0, m / h)), _ = g * t * f / n, v = -g * n * d / t, y = s * _ - c * v + (e[0] + o[0]) / 2, b = c * _ + s * v + (e[1] + o[1]) / 2, x = (e, t, n, r) => Math.atan2(e * r - t * n, e * n + t * r), S = x(1, 0, (d - _) / t, (f - v) / n), C = x((d - _) / t, (f - v) / n, (-d - _) / t, (-f - v) / n);
	!a && C > 0 ? C -= 2 * Math.PI : a && C < 0 && (C += 2 * Math.PI);
	let w = Math.max(1, Math.ceil(Math.abs(C) / (Math.PI / 2) - 1e-9)), T = C / w, E = 4 / 3 * Math.tan(T / 4), D = (e) => [y + t * Math.cos(e) * s - n * Math.sin(e) * c, b + t * Math.cos(e) * c + n * Math.sin(e) * s], O = (e) => [-t * Math.sin(e) * s - n * Math.cos(e) * c, -t * Math.sin(e) * c + n * Math.cos(e) * s], k = [];
	for (let e = 0; e < w; e++) {
		let t = S + e * T, n = t + T, [r, i, a, s] = [
			D(t),
			e === w - 1 ? o : D(n),
			O(t),
			O(n)
		];
		k.push([
			[r[0] + E * a[0], r[1] + E * a[1]],
			[i[0] - E * s[0], i[1] - E * s[1]],
			i
		]);
	}
	return k;
}
function Ts(e) {
	let t = Cs(e), n = [], r = null, i = [0, 0], a = null, o = null, s = 0, c = "", l = () => {
		let e = t[s++];
		return typeof e == "number" ? e : NaN;
	}, u = (e) => {
		r.pieces.push([
			i,
			e,
			e
		]), i = e;
	};
	for (; s < t.length;) {
		if (typeof t[s] == "string") c = t[s++];
		else if (!c) {
			s++;
			continue;
		}
		let e = c === c.toLowerCase(), d = c.toUpperCase(), f = e ? i : [0, 0], p = () => {
			let e = l(), t = l();
			return [f[0] + e, f[1] + t];
		};
		if (d === "Z") {
			r && ((i[0] !== r.start[0] || i[1] !== r.start[1]) && u(r.start), i = r.start), r = null, a = o = null, c = "";
			continue;
		}
		if (d === "M") {
			let t = p();
			if ([...t].some(Number.isNaN)) break;
			r = {
				start: t,
				pieces: []
			}, n.push(r), i = t, c = e ? "l" : "L", a = o = null;
			continue;
		}
		r || (r = {
			start: i,
			pieces: []
		}, n.push(r));
		let m = null, h = null;
		if (d === "L") {
			let e = p();
			if ([...e].some(Number.isNaN)) break;
			u(e);
		} else if (d === "H") {
			let t = l();
			if (Number.isNaN(t)) break;
			u([e ? i[0] + t : t, i[1]]);
		} else if (d === "V") {
			let t = l();
			if (Number.isNaN(t)) break;
			u([i[0], e ? i[1] + t : t]);
		} else if (d === "C" || d === "S") {
			let e = d === "C" ? p() : a ? [2 * i[0] - a[0], 2 * i[1] - a[1]] : i, t = p(), n = p();
			if ([
				...e,
				...t,
				...n
			].some(Number.isNaN)) break;
			r.pieces.push([
				e,
				t,
				n
			]), i = n, m = t;
		} else if (d === "Q" || d === "T") {
			let e = d === "Q" ? p() : o ? [2 * i[0] - o[0], 2 * i[1] - o[1]] : i, t = p();
			if ([...e, ...t].some(Number.isNaN)) break;
			r.pieces.push([
				[i[0] + 2 / 3 * (e[0] - i[0]), i[1] + 2 / 3 * (e[1] - i[1])],
				[t[0] + 2 / 3 * (e[0] - t[0]), t[1] + 2 / 3 * (e[1] - t[1])],
				t
			]), i = t, h = e;
		} else if (d === "A") {
			let [e, t, n, a, o] = [
				l(),
				l(),
				l(),
				l(),
				l()
			], s = p();
			if ([
				e,
				t,
				n,
				a,
				o,
				...s
			].some(Number.isNaN)) break;
			r.pieces.push(...ws(i, e, t, n * Math.PI / 180, !!a, !!o, s)), i = s;
		} else {
			s++;
			continue;
		}
		a = m, o = h;
	}
	return n;
}
var Es = (e) => {
	let t = {};
	for (let n of e.split(";")) {
		let e = n.indexOf(":");
		e > 0 && (t[n.slice(0, e).trim().toLowerCase()] = n.slice(e + 1).replace(/!important/i, "").trim());
	}
	return t;
};
function Ds(e) {
	let t = [], n = e.replace(/\/\*[\s\S]*?\*\//g, ""), r = /([^{}]+)\{([^}]*)\}/g;
	for (let e = r.exec(n); e; e = r.exec(n)) {
		let n = Es(e[2]);
		for (let r of e[1].split(",")) r.trim() && !r.includes("@") && t.push({
			selector: r.trim(),
			decls: n
		});
	}
	return t;
}
function Os(e, t) {
	if (/[\s>+~[:*]/.test(e)) return !1;
	let n = /^([\w-]*)((?:[.#][\w-]+)*)$/.exec(e);
	if (!n || n[1] && n[1] !== t.tag) return !1;
	let r = (t.attrs.class ?? "").split(/\s+/);
	for (let e of n[2].match(/[.#][\w-]+/g) ?? []) if (e[0] === "." && !r.includes(e.slice(1)) || e[0] === "#" && t.attrs.id !== e.slice(1)) return !1;
	return !0;
}
var ks = /* @__PURE__ */ new Set([
	"defs",
	"clipPath",
	"mask",
	"symbol",
	"marker",
	"pattern",
	"metadata",
	"title",
	"desc",
	"style",
	"script",
	"filter",
	"linearGradient",
	"radialGradient",
	"foreignObject"
]);
function As(e, t, n) {
	let r = [bs(t, e.start)], i = e.start;
	for (let [a, o, s] of e.pieces) {
		let e = a[0] === i[0] && a[1] === i[1] && o[0] === s[0] && o[1] === s[1] || a[0] === s[0] && a[1] === s[1] && o[0] === s[0] && o[1] === s[1], c = Math.hypot(a[0] - i[0], a[1] - i[1]) + Math.hypot(o[0] - a[0], o[1] - a[1]) + Math.hypot(s[0] - o[0], s[1] - o[1]), l = e ? 1 : Math.min(64, Math.max(2, Math.ceil(c / n)));
		for (let e = 1; e <= l; e++) {
			let n = e / l, c = 1 - n, u = c * c * c * i[0] + 3 * c * c * n * a[0] + 3 * c * n * n * o[0] + n * n * n * s[0], d = c * c * c * i[1] + 3 * c * c * n * a[1] + 3 * c * n * n * o[1] + n * n * n * s[1];
			r.push(bs(t, [u, d]));
		}
		i = s;
	}
	return r;
}
var js = (e) => {
	let t = e.attrs, n = (e, n = 0) => {
		let r = parseFloat(t[e] ?? "");
		return Number.isFinite(r) ? r : n;
	};
	if (e.tag === "path") return t.d ?? null;
	if (e.tag === "rect") {
		let [e, r, i, a] = [
			n("x"),
			n("y"),
			n("width"),
			n("height")
		];
		if (i <= 0 || a <= 0) return null;
		let o = t.rx === void 0 ? t.ry === void 0 ? 0 : n("ry") : n("rx"), s = t.ry === void 0 ? o : n("ry");
		return o = Math.min(Math.max(0, o), i / 2), s = Math.min(Math.max(0, s), a / 2), !o || !s ? `M${e} ${r}H${e + i}V${r + a}H${e}Z` : `M${e + o} ${r}H${e + i - o}A${o} ${s} 0 0 1 ${e + i} ${r + s}V${r + a - s}A${o} ${s} 0 0 1 ${e + i - o} ${r + a}H${e + o}A${o} ${s} 0 0 1 ${e} ${r + a - s}V${r + s}A${o} ${s} 0 0 1 ${e + o} ${r}Z`;
	}
	if (e.tag === "circle" || e.tag === "ellipse") {
		let [t, r] = [n("cx"), n("cy")], i = e.tag === "circle" ? n("r") : n("rx"), a = e.tag === "circle" ? n("r") : n("ry");
		return i <= 0 || a <= 0 ? null : `M${t - i} ${r}A${i} ${a} 0 1 0 ${t + i} ${r}A${i} ${a} 0 1 0 ${t - i} ${r}Z`;
	}
	if (e.tag === "polygon" || e.tag === "polyline") {
		let e = xs(t.points ?? "");
		return e.length < 6 ? null : `M${e.slice(0, 2).join(" ")}L${e.slice(2, e.length - e.length % 2).join(" ")}Z`;
	}
	return null;
};
function Ms(e, t) {
	let n = /* @__PURE__ */ new Map(), r = [], i = (e) => {
		e.attrs.id && n.set(e.attrs.id, e), e.tag === "style" && r.push(e.text), e.children.forEach(i);
	};
	i(e);
	let a = Ds(r.join("\n")), o = /* @__PURE__ */ new Map(), s = (e, t = 0) => {
		let r = e.children.filter((e) => e.tag === "stop");
		if (!r.length) {
			let r = (e.attrs.href ?? e.attrs["xlink:href"] ?? "").replace(/^#/, ""), i = n.get(r);
			return i && t < 4 ? s(i, t + 1) : null;
		}
		let i = r[Math.floor((r.length - 1) / 2)];
		return ms({ ...Es(i.attrs.style ?? "") }["stop-color"] ?? i.attrs["stop-color"] ?? "black", "#000000") ?? null;
	};
	for (let [e, t] of n) (t.tag === "linearGradient" || t.tag === "radialGradient") && o.set(e, s(t) ?? "#000000");
	let c = [], l = [], u = (e) => {
		let t = {};
		for (let n of [
			"fill",
			"fill-rule",
			"stroke",
			"stroke-width",
			"color",
			"display",
			"visibility",
			"opacity",
			"fill-opacity"
		]) e.attrs[n] !== void 0 && (t[n] = e.attrs[n]);
		for (let n of a) Os(n.selector, e) && Object.assign(t, n.decls);
		return Object.assign(t, Es(e.attrs.style ?? "")), t;
	}, d = (e, r, i, a) => {
		if (a > 40 || ks.has(e.tag)) return;
		let s = u(e);
		if (s.display === "none") return;
		let c = ms(s.color, i.color) ?? i.color, f = i.fill;
		if (s.fill !== void 0) {
			let e = /url\(\s*['"]?#([^'")]+)['"]?\s*\)/.exec(s.fill);
			if (e) f = o.get(e[1]) ?? null;
			else {
				let e = ms(s.fill, c);
				e !== void 0 && (f = e);
			}
		}
		(Number(s.opacity) === 0 || Number(s["fill-opacity"]) === 0) && (f = null);
		let p = {
			fill: f,
			color: c,
			evenOdd: s["fill-rule"] === void 0 ? i.evenOdd : s["fill-rule"].trim() === "evenodd",
			stroked: s.stroke === void 0 ? i.stroked : ms(s.stroke, c) !== null && parseFloat(s["stroke-width"] ?? "1") !== 0
		}, m = ys(r, Ss(e.attrs.transform));
		if (e.tag === "svg" && a > 1 && (m = ys(m, [
			1,
			0,
			0,
			1,
			parseFloat(e.attrs.x ?? "0") || 0,
			parseFloat(e.attrs.y ?? "0") || 0
		])), e.tag === "text") t.add("Text in the file was left out: turn it into outlines in your drawing app (Create outlines), then import again.");
		else if (e.tag === "image") t.add("Pictures inside the file were left out; only its vector shapes are read.");
		else if (e.tag === "line") p.stroked && t.add("Lines drawn as strokes were left out: outline the strokes in your drawing app first.");
		else if (e.tag === "use") {
			let t = n.get((e.attrs.href ?? e.attrs["xlink:href"] ?? "").replace(/^#/, ""));
			if (!t) return;
			let r = ys(m, [
				1,
				0,
				0,
				1,
				parseFloat(e.attrs.x ?? "0") || 0,
				parseFloat(e.attrs.y ?? "0") || 0
			]), i = t.tag === "symbol" ? {
				...t,
				tag: "g"
			} : t;
			d(i, r, p, a + 1);
		} else if (js(e) !== null) p.stroked && t.add("Strokes (outlines drawn as lines) were left out: outline them in your drawing app to keep them."), p.fill && s.visibility !== "hidden" && l.push({
			node: e,
			m,
			style: p
		});
		else for (let t of e.children) d(t, m, p, a + 1);
	};
	d(e, vs, {
		fill: "#000000",
		color: "#000000",
		evenOdd: !1,
		stroked: !1
	}, 0);
	let f = l.map((e) => ({
		...e,
		subs: Ts(js(e.node))
	})), [p, m, h, g] = [
		Infinity,
		Infinity,
		-Infinity,
		-Infinity
	];
	for (let e of f) for (let t of e.subs) for (let n of [t.start, ...t.pieces.flat()]) {
		let [t, r] = bs(e.m, n);
		[p, m, h, g] = [
			Math.min(p, t),
			Math.min(m, r),
			Math.max(h, t),
			Math.max(g, r)
		];
	}
	let _ = Math.max(h - p, g - m);
	if (!Number.isFinite(_) || _ <= 0) return c;
	let v = (function e(t) {
		return t.tag === "svg" ? t : t.children.reduce((t, n) => t ?? e(n), null);
	})(e), y = xs(v?.attrs.viewBox ?? ""), b = y.length === 4 ? [
		y[0],
		y[1],
		y[2],
		y[3]
	] : v?.attrs.width && v.attrs.height && !/%/.test(v.attrs.width + v.attrs.height) ? [
		0,
		0,
		parseFloat(v.attrs.width),
		parseFloat(v.attrs.height)
	] : null;
	if (b && f.length > 1) {
		let e = f[0], n = e.subs.flatMap((t) => As(t, e.m, _ / 50)), r = n.map((e) => e[0]), i = n.map((e) => e[1]), [a, o, s, c] = [
			Math.min(...r),
			Math.max(...r),
			Math.min(...i),
			Math.max(...i)
		], l = (e, t) => Math.abs(e - t) <= Math.max(b[2], b[3]) * .01, u = l(a, b[0]) && l(s, b[1]) && l(o, b[0] + b[2]) && l(c, b[1] + b[3]), d = Math.abs(n.reduce((e, t, r) => e + t[0] * n[(r + 1) % n.length][1] - n[(r + 1) % n.length][0] * t[1], 0) / 2), p = Math.min(...hs(e.style.fill)) >= 235;
		u && p && e.subs.length === 1 && d >= (o - a) * (c - s) * .99 && (f.shift(), t.add("The drawing’s background rectangle was left out, so only the logo itself becomes 3D."));
	}
	for (let e of f) {
		let t = Math.sqrt(Math.abs(e.m[0] * e.m[3] - e.m[1] * e.m[2])) || 1, n = e.subs.map((n) => As(n, e.m, _ / 400 / t)).filter((e) => e.length >= 3);
		n.length && c.push({
			colour: e.style.fill,
			evenOdd: e.style.evenOdd,
			polygons: n
		});
	}
	return c;
}
function Ns(e, t, n, r, i, a) {
	let o = [], s = Infinity, c = -Infinity;
	for (let e of r) for (let t = 0; t < e.length; t++) {
		let n = e[t], r = e[(t + 1) % e.length];
		if (n[1] === r[1]) continue;
		let i = r[1] > n[1] ? 1 : -1, [a, l] = i > 0 ? [n, r] : [r, n];
		o.push({
			x0: a[0],
			y0: a[1],
			x1: l[0],
			y1: l[1],
			dir: i
		}), s = Math.min(s, a[1]), c = Math.max(c, l[1]);
	}
	if (!o.length) return;
	o.sort((e, t) => e.y0 - t.y0);
	let l = [], u = 0, d = [], f = Math.max(0, Math.floor(s - .5)), p = Math.min(n - 1, Math.ceil(c));
	for (let n = f; n <= p; n++) {
		let r = n + .5;
		for (; u < o.length && o[u].y0 <= r;) l.push(o[u++]);
		for (let e = l.length - 1; e >= 0; e--) l[e].y1 <= r && l.splice(e, 1);
		d.length = 0;
		for (let e of l) e.y0 <= r && e.y1 > r && d.push({
			x: e.x0 + (r - e.y0) / (e.y1 - e.y0) * (e.x1 - e.x0),
			dir: e.dir
		});
		d.sort((e, t) => e.x - t.x);
		let s = 0;
		for (let r = 0; r + 1 < d.length; r++) {
			if (s += i ? 1 : d[r].dir, !(i ? s % 2 == 1 : s !== 0)) continue;
			let o = Math.max(0, Math.ceil(d[r].x - .5)), c = Math.min(t - 1, Math.floor(d[r + 1].x - .5));
			e.fill(a, n * t + o, n * t + c + 1);
		}
	}
}
var Ps = 4, Fs = 64;
function Is(e, t = {}) {
	let n = Math.max(1, t.maxParts ?? 16), r = /* @__PURE__ */ new Set(), i = fs(e);
	if (!i.children.some(function e(t) {
		return t.tag === "svg" || t.children.some(e);
	})) throw Error("That file is not an SVG drawing.");
	let a = Ms(i, r);
	if (!a.length) throw Error("The SVG has no filled shapes to push out (only lines, text or pictures).");
	let [o, s, c, l] = [
		Infinity,
		Infinity,
		-Infinity,
		-Infinity
	];
	for (let e of a) for (let t of e.polygons) for (let [e, n] of t) [o, s, c, l] = [
		Math.min(o, e),
		Math.min(s, n),
		Math.max(c, e),
		Math.max(l, n)
	];
	let u = 1020 / Math.max(c - o, l - s), d = Math.max(8, Math.ceil((c - o) * u) + 4), f = Math.max(8, Math.ceil((l - s) * u) + 4), [p, m] = [d * Ps, f * Ps], h = new Uint8Array(p * m).fill(255), g = [], _ = (e) => {
		let t = g.indexOf(e);
		return t < 0 && g.length < 254 && (t = g.push(e) - 1), t < 0 && (t = g.reduce((t, n, r) => gs(n, e) < gs(g[t], e) ? r : t, 0)), t;
	};
	for (let e of a) Ns(h, p, m, e.polygons.map((e) => e.map(([e, t]) => [((e - o) * u + 2) * Ps, ((t - s) * u + 2) * Ps])), e.evenOdd, _(e.colour));
	let v = g.map(() => null), y = g.map(() => 0);
	for (let e = 0; e < m; e++) {
		let t = e / Ps | 0;
		for (let n = 0; n < p; n++) {
			let r = h[e * p + n];
			if (r === 255) continue;
			let i = v[r] ??= new Uint8Array(d * f), a = t * d + (n / Ps | 0);
			i[a] = i[a] + 1, y[r] = y[r] + 1;
		}
	}
	let b = g.map((e, t) => t).filter((e) => y[e] > 0), x = p * m * 2e-4, S = (e) => {
		let t = b.filter((t) => t !== e);
		if (!t.length) return;
		let n = t.reduce((t, n) => gs(g[n], g[e]) < gs(g[t], g[e]) ? n : t, t[0]), [r, i] = [v[n], v[e]];
		for (let e = 0; e < r.length; e++) r[e] = r[e] + i[e];
		y[n] = y[n] + y[e], b.splice(b.indexOf(e), 1);
	};
	for (;;) {
		let e = b.reduce((e, t) => y[t] < y[e] ? t : e, b[0]);
		if (b.length > n) r.add(`The drawing has more colours than fit; the smallest were joined to the nearest colour (${n} parts).`), S(e);
		else if (b.length > 1 && y[e] < x) S(e);
		else break;
	}
	let C = [];
	for (let e of b) {
		let t = v[e], n = new Uint8Array(d * f), i = new Float32Array(d * f);
		for (let e = 0; e < t.length; e++) n[e] = +(t[e] * 2 >= 16), i[e] = Math.min(1, t[e] / 16);
		let a = Pr(n, d, f, .35, i).filter((e) => Math.abs(bn(e)) > d * f / 4e4).map((e) => {
			let t = .7;
			for (; e.length > 1800 && t < 8;) e = Jn(e, t), t *= 2;
			return e;
		});
		a.length > Fs && (r.add("Some of the tiniest details were left out: one colour holds at most 64 separate pieces."), a = [...a].sort((e, t) => Math.abs(bn(t)) - Math.abs(bn(e))).slice(0, Fs)), a.length && C.push({
			colour: g[e],
			contours: a
		});
	}
	if (!C.length) throw Error("The SVG’s shapes are too small to push out.");
	let [w, T, E, D] = [
		Infinity,
		Infinity,
		-Infinity,
		-Infinity
	];
	for (let e of C) for (let t of e.contours) for (let [e, n] of t) [w, T, E, D] = [
		Math.min(w, e),
		Math.min(T, n),
		Math.max(E, e),
		Math.max(D, n)
	];
	let O = Math.max(E - w, D - T), [k, ee] = [(w + E) / 2, (T + D) / 2], te = /* @__PURE__ */ new Map();
	return {
		parts: C.map((e) => {
			let t = e.contours.flat(), n = t.map((e) => e[0]), r = t.map((e) => e[1]), [i, a, o, s] = [
				Math.min(...n),
				Math.max(...n),
				Math.min(...r),
				Math.max(...r)
			], c = xt(e.contours.map((e) => e.map(([e, t]) => [e, -t]))), l = _s(e.colour), u = (te.get(l) ?? 0) + 1;
			return te.set(l, u), {
				name: u > 1 ? `${l} ${u}` : l,
				color: e.colour,
				outline: c.outline,
				aspect: c.aspect,
				box: {
					x: ((i + a) / 2 - k) / O,
					y: -((o + s) / 2 - ee) / O,
					w: (a - i) / O,
					h: (s - o) / O
				}
			};
		}),
		aspect: (E - w) / (D - T),
		warnings: [...r]
	};
}
//#endregion
//#region ../scene3d/src/model/exportrig.ts
function Ls(e, t, n = "") {
	let r = Nt(e, t, n), i = e.parts.map((e, t) => {
		let n = r[t], i = e.positions.length / 3, a = new Uint16Array(i * 4), o = new Float32Array(i * 4);
		for (let e = 0; e < i; e++) for (let t = 0; t < n.per; t++) a[e * 4 + t] = n.bones[e * n.per + t], o[e * 4 + t] = n.weights[e * n.per + t];
		return {
			...e,
			joints: a,
			skinWeights: o
		};
	}), a = t.bones.map((e) => ({
		name: e.name,
		parent: e.parent,
		head: e.head,
		tail: e.tail
	}));
	return {
		...e,
		parts: i,
		skeleton: a
	};
}
var Rs = (e, t) => {
	for (let n of e) {
		if (n.id === t) return n;
		let e = n.children?.find((e) => e.id === t);
		if (e) return e;
	}
};
function zs(e) {
	let [t, n, r, i, a, o, s, c, l] = e, u = t + a + l, d;
	if (u > 0) {
		let e = Math.sqrt(u + 1) * 2;
		d = [
			(c - o) / e,
			(r - s) / e,
			(i - n) / e,
			e / 4
		];
	} else if (t > a && t > l) {
		let e = Math.sqrt(1 + t - a - l) * 2;
		d = [
			e / 4,
			(n + i) / e,
			(r + s) / e,
			(c - o) / e
		];
	} else if (a > l) {
		let e = Math.sqrt(1 + a - t - l) * 2;
		d = [
			(n + i) / e,
			e / 4,
			(o + c) / e,
			(r - s) / e
		];
	} else {
		let e = Math.sqrt(1 + l - t - a) * 2;
		d = [
			(r + s) / e,
			(o + c) / e,
			e / 4,
			(i - n) / e
		];
	}
	let f = Math.hypot(...d) || 1;
	return d.map((e) => e / f);
}
var Bs = (e, t) => [
	0,
	1,
	2
].map((n) => e[n * 3] * t[0] + e[n * 3 + 1] * t[1] + e[n * 3 + 2] * t[2]);
function Vs(e, t, n, r, i, a = 30) {
	if (!(t.take || t.keys?.length || t.motion)) return null;
	let o = e.clip ?? 4, s = Math.min(18e3, Math.max(2, Math.round(o * a) + 1)), c = Rs(e.shapes, t.id), l = r.max.map((e, t) => Math.max(1e-9, e - r.min[t])), u = r.min.map((e, t) => (e + r.max[t]) / 2), d = c.size.map((e, t) => e / l[t]), f = an(c.rotation), p = new Float32Array(s), m = n.bones.length, h = new Float32Array(s * m * 4), g = new Float32Array(s * m * 3);
	for (let r = 0; r < s; r++) {
		let i = r / (s - 1);
		p[r] = i * o;
		let a = Rs(fe(e, r === s - 1 ? 0 : i).shapes, t.id) ?? c, l = a.rig?.pose ?? n.pose, _ = a.rig?.root ?? [
			0,
			0,
			0
		], v = D(xe(f), an(a.rotation)), y = Bs(xe(f), a.position.map((e, t) => e - c.position[t])).map((e, t) => e / d[t]);
		n.bones.forEach((e, t) => {
			let i = an(l[t] ?? [
				0,
				0,
				0
			]), a = e.parent >= 0 ? n.bones[e.parent].head : [
				0,
				0,
				0
			], o = e.head.map((e, t) => e - a[t]), s = i;
			if (e.parent < 0) {
				let t = e.head.map((e, t) => e + _[t] - u[t]);
				o = Bs(v, t).map((e, t) => e + u[t] + y[t]), s = D(v, i);
			}
			h.set(zs(s), (r * m + t) * 4), g.set(o, (r * m + t) * 3);
		});
	}
	for (let e = 0; e < m; e++) for (let t = 1; t < s; t++) {
		let n = ((t - 1) * m + e) * 4, r = (t * m + e) * 4;
		if (h[n] * h[r] + h[n + 1] * h[r + 1] + h[n + 2] * h[r + 2] + h[n + 3] * h[r + 3] < 0) for (let e = 0; e < 4; e++) h[r + e] = -h[r + e];
	}
	return (e, t) => {
		let r = (e) => new Uint8Array(e.buffer, e.byteOffset, e.byteLength), a = t(r(p), 5126, s, "SCALAR", {
			min: [0],
			max: [o]
		}), c = [], l = [];
		n.bones.forEach((e, n) => {
			let i = new Float32Array(s * 4), o = !0;
			for (let e = 0; e < s; e++) {
				i.set(h.subarray((e * m + n) * 4, (e * m + n) * 4 + 4), e * 4);
				for (let t = 0; t < 4; t++) Math.abs(i[e * 4 + t] - i[t]) > 1e-4 && (o = !1);
			}
			if ((!o || Math.abs(i[3]) < .9999) && (l.push({
				sampler: c.length,
				target: {
					node: n + 1,
					path: "rotation"
				}
			}), c.push({
				input: a,
				output: t(r(i), 5126, s, "VEC4"),
				interpolation: "LINEAR"
			})), e.parent < 0) {
				let e = new Float32Array(s * 3);
				for (let t = 0; t < s; t++) e.set(g.subarray((t * m + n) * 3, (t * m + n) * 3 + 3), t * 3);
				l.push({
					sampler: c.length,
					target: {
						node: n + 1,
						path: "translation"
					}
				}), c.push({
					input: a,
					output: t(r(e), 5126, s, "VEC3"),
					interpolation: "LINEAR"
				});
			}
		}), e.animations = [{
			name: i,
			samplers: c,
			channels: l
		}];
	};
}
function Hs(e, t) {
	let n = t.asset ? e.assets?.[t.asset] : void 0;
	if (!n || !t.rig) throw Error("Pick a model with bones first: Rig adds them.");
	let r = s(t.asset, n.data), { root: i, ...a } = {
		...t.rig,
		pose: t.rig.pose.map(() => [
			0,
			0,
			0
		])
	}, o = Vs(e, t, a, r, t.take && e.takes?.[t.take.id]?.name || n.name || "Animation");
	return f(Ls(r, a, t.asset), o ? { extend: o } : void 0);
}
function Us(e, t) {
	let n = Ui(t.bones), r = [], i = t.bones.map(() => [
		0,
		0,
		0
	]), a = /* @__PURE__ */ new Map();
	for (let [e, t] of [["left", [
		1,
		0,
		0
	]], ["right", [
		-1,
		0,
		0
	]]]) for (let r of [
		"UpperArm",
		"LowerArm",
		"Hand"
	]) {
		let i = n.get(`${e}${r}`);
		i !== void 0 && a.set(i, t);
	}
	t.bones.forEach((e, n) => {
		let o = e.parent >= 0 ? r[e.parent] : [
			1,
			0,
			0,
			0,
			1,
			0,
			0,
			0,
			1
		], s = a.get(n);
		if (!s) {
			r.push(o);
			return;
		}
		let c = t.bones.findIndex((e) => e.parent === n && a.has(t.bones.indexOf(e))), l = (c >= 0 ? t.bones[c].head : e.tail).map((t, n) => t - e.head[n]), u = wt(Bs(o, l)), d = D(Pe(u, s), o);
		r.push(d), i[n] = Ye(D(xe(o), d));
	});
	let o = {
		...t,
		pose: i
	}, s = at(e, o), c = et(o);
	return {
		asset: {
			...e,
			parts: s
		},
		rig: {
			bones: t.bones.map((e, t) => ({
				...e,
				head: c[t].head,
				tail: c[t].tail
			})),
			pose: t.bones.map(() => [
				0,
				0,
				0
			])
		}
	};
}
function Ws(e, t, n, r, i) {
	let a = n ? -1 : 1, o = (e) => [
		e[0] * a * r + i[0],
		e[1] * r + i[1],
		e[2] * a * r + i[2]
	], s = e.parts.map((e) => {
		let t = new Float32Array(e.positions.length), n = new Float32Array(e.normals.length);
		for (let r = 0; r < t.length; r += 3) t.set(o([
			e.positions[r],
			e.positions[r + 1],
			e.positions[r + 2]
		]), r), n.set([
			e.normals[r] * a,
			e.normals[r + 1],
			e.normals[r + 2] * a
		], r);
		return {
			...e,
			positions: t,
			normals: n
		};
	});
	return {
		asset: {
			...e,
			parts: s
		},
		rig: {
			...t,
			bones: t.bones.map((e) => ({
				...e,
				head: o(e.head),
				tail: o(e.tail)
			}))
		}
	};
}
function Gs(e) {
	let t = Ui(e.bones);
	return Yi.filter((e) => !t.has(e));
}
var Ks = {
	joy: "happy",
	fun: "relaxed",
	angry: "angry",
	sorrow: "sad",
	surprised: "surprised",
	blink: "blink",
	blink_l: "blinkLeft",
	blink_r: "blinkRight",
	a: "aa",
	o: "oh"
};
function qs(e, t, n) {
	let r = t.asset ? e.assets?.[t.asset] : void 0;
	if (!r || !t.rig) throw Error("Pick a model with bones first: Rig adds them.");
	let i = Gs(t.rig);
	if (i.length) throw Error(`A VRM needs a person's bones; this figure has no ${i.join(", ")}. Add a figure rig again.`);
	let { root: a, ...o } = t.rig, c = {
		...o,
		pose: o.pose.map(() => [
			0,
			0,
			0
		])
	}, l = s(t.asset, r.data), u = Ui(c.bones), d = Dn(c.bones, u), p = Ls(l, c, t.asset), m = l.max[1] - l.min[1], h = m > .5 && m < 3 ? 1 : 1.6 / Math.max(1e-6, m), g = d ? Ws(p, c, !0, 1, [
		0,
		0,
		0
	]) : {
		asset: p,
		rig: c
	}, _ = Us(g.asset, g.rig), v = Infinity;
	for (let e of _.asset.parts) for (let t = 1; t < e.positions.length; t += 3) v = Math.min(v, e.positions[t]);
	let y = _.rig.bones[u.get("hips")].head, b = Ws(_.asset, _.rig, !1, h, [
		-y[0] * h,
		-v * h,
		-y[2] * h
	]), x = {
		...b.asset,
		skeleton: b.rig.bones.map((e) => ({
			name: e.name,
			parent: e.parent,
			head: e.head,
			tail: e.tail
		}))
	}, S = l.morphs?.names ?? [], C = l.morphs ? x.parts.map((e, t) => S.map((n, r) => Js(l.morphs.moves[r][t] ?? null, e.positions.length, d, h))) : void 0;
	return f(x, {
		extend: (e) => {
			let r = Object.fromEntries([...u].map(([e, t]) => [e, { node: t + 1 }])), i = {}, a = {};
			S.forEach((e, t) => {
				let n = {
					morphTargetBinds: [{
						node: 0,
						index: t,
						weight: 1
					}],
					isBinary: !1,
					overrideBlink: "none",
					overrideLookAt: "none",
					overrideMouth: "none"
				};
				Ks[e] ? i[Ks[e]] = n : a[e] = n;
			});
			let o = t.springs?.off ? null : Nn(b.rig.bones);
			e.extensionsUsed = [
				...e.extensionsUsed ?? [],
				"VRMC_vrm",
				...o ? ["VRMC_springBone"] : []
			], e.extensions = {
				...e.extensions,
				...o ? { VRMC_springBone: o } : {},
				VRMC_vrm: {
					specVersion: "1.0",
					meta: {
						name: n.name.slice(0, 80) || "Character",
						authors: n.authors.length ? n.authors : ["Unknown"],
						metaVersion: "1",
						licenseUrl: n.licenceUrl ?? "https://vrm.dev/licenses/1.0/",
						avatarPermission: n.avatarPermission ?? "onlyAuthor",
						allowExcessivelyViolentUsage: !1,
						allowExcessivelySexualUsage: !1,
						commercialUsage: n.commercialUsage ?? "personalNonProfit",
						allowPoliticalOrReligiousUsage: !1,
						allowAntisocialOrHateUsage: !1,
						creditNotation: "required",
						allowRedistribution: n.allowRedistribution ?? !1,
						modification: "prohibited"
					},
					humanoid: { humanBones: r },
					...S.length ? { expressions: {
						preset: i,
						custom: a
					} } : {}
				}
			};
		},
		...C ? {
			morphs: C,
			morphNames: S
		} : {}
	});
}
function Js(e, t, n, r) {
	if (!e || e.length !== t) return null;
	let i = n ? -1 : 1, a = new Float32Array(t);
	for (let n = 0; n < t; n += 3) a[n] = e[n] * i * r, a[n + 1] = e[n + 1] * r, a[n + 2] = e[n + 2] * i * r;
	return a;
}
//#endregion
//#region ../scene3d/src/model/meshedit.ts
function Ys(e) {
	let t = new Uint32Array(e.positions.length / 3), n = /* @__PURE__ */ new Map();
	for (let r = 0; r < t.length; r++) {
		let i = `${Math.round(e.positions[r * 3] * 1e5)},${Math.round(e.positions[r * 3 + 1] * 1e5)},${Math.round(e.positions[r * 3 + 2] * 1e5)}`, a = n.get(i);
		a === void 0 && n.set(i, a = n.size), t[r] = a;
	}
	return {
		id: t,
		count: n.size
	};
}
var Xs = (e, t, n = e.indices) => ({
	...e,
	positions: t,
	indices: n,
	normals: u(t, n)
});
function Zs(e, t = 2) {
	let n = e.parts.map((e) => {
		let { id: n, count: r } = Ys(e), i = new Float64Array(r * 3);
		for (let t = 0; t < n.length; t++) i.set(e.positions.subarray(t * 3, t * 3 + 3), n[t] * 3);
		let a = Array.from({ length: r }, () => /* @__PURE__ */ new Set());
		for (let t = 0; t < e.indices.length; t += 3) {
			let [r, i, o] = [
				n[e.indices[t]],
				n[e.indices[t + 1]],
				n[e.indices[t + 2]]
			];
			a[r].add(i).add(o), a[i].add(r).add(o), a[o].add(r).add(i);
		}
		let o = (e) => {
			let t = new Float64Array(i);
			for (let n = 0; n < r; n++) {
				let r = a[n];
				if (r.size) for (let a = 0; a < 3; a++) {
					let o = 0;
					for (let e of r) o += i[e * 3 + a];
					t[n * 3 + a] = i[n * 3 + a] + e * (o / r.size - i[n * 3 + a]);
				}
			}
			i.set(t);
		};
		for (let e = 0; e < t; e++) o(.5), o(-.53);
		let s = new Float32Array(e.positions.length);
		for (let e = 0; e < n.length; e++) s.set(i.subarray(n[e] * 3, n[e] * 3 + 3), e * 3);
		return Xs(e, s);
	});
	return m(n, e.materials, e.textures);
}
function Qs(e, t) {
	let n = e.positions.length / 3, r = /* @__PURE__ */ new Map(), i = new Uint32Array(n), a = [], o = [], s = [];
	for (let c = 0; c < n; c++) {
		let n = [
			0,
			1,
			2
		].map((n) => Math.floor(e.positions[c * 3 + n] / t)).join(","), l = r.get(n);
		l === void 0 && (r.set(n, l = o.length), a.push(0, 0, 0), o.push(0), s.push(c)), i[c] = l;
		for (let t = 0; t < 3; t++) a[l * 3 + t] += e.positions[c * 3 + t];
		o[l]++;
	}
	let c = new Float32Array(o.length * 3);
	for (let e = 0; e < o.length; e++) for (let t = 0; t < 3; t++) c[e * 3 + t] = a[e * 3 + t] / o[e];
	let l = (e, t) => {
		if (!e) return null;
		let n = new Float32Array(o.length * t);
		return s.forEach((r, i) => n.set(e.subarray(r * t, r * t + t), i * t)), n;
	}, d = [], f = /* @__PURE__ */ new Set();
	for (let t = 0; t < e.indices.length; t += 3) {
		let n = [
			i[e.indices[t]],
			i[e.indices[t + 1]],
			i[e.indices[t + 2]]
		];
		if (n[0] === n[1] || n[1] === n[2] || n[0] === n[2]) continue;
		let r = [...n].sort((e, t) => e - t).join(",");
		f.has(r) || (f.add(r), d.push(...n));
	}
	let p = new Uint32Array(d);
	return {
		...e,
		positions: c,
		normals: u(c, p),
		uvs: l(e.uvs, 2),
		colors: l(e.colors, 3),
		indices: p
	};
}
function $s(e, t = .5) {
	let n = Math.max(...e.max.map((t, n) => t - e.min[n]), 1e-9), r = e.triangles * t, i = e;
	for (let t of [
		512,
		384,
		256,
		192,
		128,
		96,
		64,
		48,
		32,
		24
	]) {
		let a = m(e.parts.map((e) => Qs(e, n / t)), e.materials, e.textures);
		if (i = a, a.triangles <= r) break;
	}
	return i;
}
function ec(e) {
	let t = e.parts.map((e) => {
		let t = new Uint32Array(e.indices.length);
		for (let n = 0; n < e.indices.length; n += 3) t.set([
			e.indices[n],
			e.indices[n + 2],
			e.indices[n + 1]
		], n);
		return {
			...e,
			indices: t,
			normals: e.normals.map((e) => -e)
		};
	});
	return m(t, e.materials, e.textures);
}
function tc(e) {
	let t = e.reduce((t, n, r) => t + n[0] * e[(r + 1) % e.length][1] - e[(r + 1) % e.length][0] * n[1], 0), n = e.map((e, t) => t);
	t < 0 && n.reverse();
	let r = [], i = (e, t, n) => (t[0] - e[0]) * (n[1] - e[1]) - (t[1] - e[1]) * (n[0] - e[0]), a = 0;
	for (; n.length > 3 && a++ < 1e4;) {
		let t = !1;
		for (let a = 0; a < n.length; a++) {
			let [o, s, c] = [
				n[(a + n.length - 1) % n.length],
				n[a],
				n[(a + 1) % n.length]
			], [l, u, d] = [
				e[o],
				e[s],
				e[c]
			];
			if (!(i(l, u, d) <= 1e-12) && !n.some((t) => {
				if (t === o || t === s || t === c) return !1;
				let n = e[t];
				return i(l, u, n) > 0 && i(u, d, n) > 0 && i(d, l, n) > 0;
			})) {
				r.push([
					o,
					s,
					c
				]), n.splice(a, 1), t = !0;
				break;
			}
		}
		if (!t) break;
	}
	return n.length === 3 && r.push([
		n[0],
		n[1],
		n[2]
	]), r;
}
function nc(e, t, n) {
	let r = e.min[1] + (e.max[1] - e.min[1]) * Math.min(1, Math.max(0, t)), i = (e) => n === "below" ? e <= r : e >= r, a = [];
	for (let t of e.parts) {
		let e = [], o = [], s = [], c = [], l = [], u = (n) => (e.push(...t.positions.subarray(n * 3, n * 3 + 3)), o.push(...t.normals.subarray(n * 3, n * 3 + 3)), t.uvs && s.push(...t.uvs.subarray(n * 2, n * 2 + 2)), t.colors && c.push(...t.colors.subarray(n * 3, n * 3 + 3)), e.length / 3 - 1), d = (n, i) => {
			let a = t.positions[n * 3 + 1], l = t.positions[i * 3 + 1], u = (r - a) / (l - a || 1e-12), d = (e, t, r) => {
				for (let a = 0; a < t; a++) r.push(e[n * t + a] + (e[i * t + a] - e[n * t + a]) * u);
			};
			return d(t.positions, 3, e), d(t.normals, 3, o), t.uvs && d(t.uvs, 2, s), t.colors && d(t.colors, 3, c), e.length / 3 - 1;
		}, f = /* @__PURE__ */ new Map(), p = (e) => {
			let t = f.get(e);
			return t === void 0 && f.set(e, t = u(e)), t;
		}, m = [];
		for (let e = 0; e < t.indices.length; e += 3) {
			let n = [
				t.indices[e],
				t.indices[e + 1],
				t.indices[e + 2]
			], r = n.map((e) => i(t.positions[e * 3 + 1])), a = r.filter(Boolean).length;
			if (a === 3 && l.push(...n.map(p)), a === 0 || a === 3) continue;
			let o = 0;
			for (; (a === 1 ? !r[o] : r[o]) && o < 2;) o++;
			if (a === 1 ? !r[o] : r[o]) continue;
			let [s, c, u] = [
				n[o],
				n[(o + 1) % 3],
				n[(o + 2) % 3]
			], f = d(s, c), h = d(s, u);
			a === 1 ? (l.push(p(s), f, h), m.push([f, h])) : (l.push(f, p(c), p(u), f, p(u), h), m.push([h, f]));
		}
		let h = (t) => `${Math.round(e[t * 3] * 1e5)},${Math.round(e[t * 3 + 2] * 1e5)}`, g = /* @__PURE__ */ new Map();
		for (let [e, t] of m) g.set(h(e), t);
		let _ = /* @__PURE__ */ new Set();
		for (let [i] of m) {
			if (_.has(h(i))) continue;
			let a = [], u = i;
			for (; !_.has(h(u)) && a.length < 1e5;) {
				_.add(h(u)), a.push(u);
				let e = g.get(h(u));
				if (e === void 0) break;
				u = e;
			}
			if (a.length < 3) continue;
			let d = n === "below" ? 1 : -1, f = e.length / 3;
			for (let n of a) e.push(e[n * 3], r, e[n * 3 + 2]), o.push(0, d, 0), t.uvs && s.push(s[n * 2], s[n * 2 + 1]), t.colors && c.push(c[n * 3], c[n * 3 + 1], c[n * 3 + 2]);
			for (let [t, n, r] of tc(a.map((t) => [e[t * 3], e[t * 3 + 2]]))) {
				let e = [
					f + t,
					f + n,
					f + r
				];
				l.push(...d > 0 ? [
					e[0],
					e[2],
					e[1]
				] : e);
			}
		}
		l.length && a.push({
			...t,
			positions: new Float32Array(e),
			normals: new Float32Array(o),
			uvs: t.uvs ? new Float32Array(s) : null,
			colors: t.colors ? new Float32Array(c) : null,
			indices: new Uint32Array(l)
		});
	}
	let o = a.length ? m(a, e.materials, e.textures) : null;
	if (!o || o.max[1] - o.min[1] < 1e-4 * (e.max[1] - e.min[1])) throw Error("Nothing would be left: cut at another height, or keep the other side.");
	return o;
}
function rc(e, t, n) {
	let r = (e) => e.max.map((t, n) => Math.max(t - e.min[n], 1e-9)), i = (e) => e.max.map((t, n) => (t + e.min[n]) / 2), a = e.size.map((e, n) => e / r(t)[n]), o = i(n).map((e, n) => (e - i(t)[n]) * a[n]), s = an(e.rotation), c = [
		0,
		1,
		2
	].map((e) => s[e * 3] * o[0] + s[e * 3 + 1] * o[1] + s[e * 3 + 2] * o[2]);
	return {
		size: r(n).map((e, t) => Math.max(.01, e * a[t])),
		position: e.position.map((e, t) => e + c[t])
	};
}
async function ic(e, t) {
	let n = await ra({
		shapes: t.filter((e) => e.kind === "mesh"),
		assets: e.assets
	});
	if (!n.triangles) throw Error("Pick two or more imported models to join.");
	let r = n.max.map((e, t) => (e + n.min[t]) / 2), i = n.parts.map((e) => {
		let t = new Float32Array(e.positions);
		for (let e = 0; e < t.length; e += 3) for (let n = 0; n < 3; n++) t[e + n] -= r[n];
		return {
			...e,
			positions: t
		};
	});
	return {
		asset: m(i, n.materials, n.textures),
		position: r,
		size: n.max.map((e, t) => Math.max(.01, e - n.min[t]))
	};
}
function ac(e, t) {
	let n = new Float64Array(t), r = new Int32Array(t), i = new Float64Array(t + 1), a = 0;
	r[0] = 0, i[0] = -Infinity, i[1] = Infinity;
	for (let n = 1; n < t; n++) {
		let t = (e[n] + n * n - (e[r[a]] + r[a] * r[a])) / (2 * n - 2 * r[a]);
		for (; t <= i[a];) a--, t = (e[n] + n * n - (e[r[a]] + r[a] * r[a])) / (2 * n - 2 * r[a]);
		a++, r[a] = n, i[a] = t, i[a + 1] = Infinity;
	}
	a = 0;
	for (let o = 0; o < t; o++) {
		for (; i[a + 1] < o;) a++;
		n[o] = (o - r[a]) * (o - r[a]) + e[r[a]];
	}
	e.set(n);
}
function oc(e, [t, n, r]) {
	let i = new Float64Array(t * n * r);
	for (let t = 0; t < i.length; t++) i[t] = e[t] ? 0 : 0x56bc75e2d63100000;
	let a = (e, t) => {
		let n = new Float64Array(e);
		for (let r = 0; r < e; r++) n[r] = i[t(r)];
		ac(n, e);
		for (let r = 0; r < e; r++) i[t(r)] = n[r];
	};
	for (let e = 0; e < r; e++) for (let r = 0; r < n; r++) a(t, (i) => (e * n + r) * t + i);
	for (let e = 0; e < r; e++) for (let r = 0; r < t; r++) a(n, (i) => (e * n + i) * t + r);
	for (let e = 0; e < n; e++) for (let i = 0; i < t; i++) a(r, (r) => (r * n + e) * t + i);
	return i.map(Math.sqrt);
}
function sc(e, t, n) {
	let r = Math.max(...t.map((t, n) => t - e[n]), 1e-6) / n, i = e.map((e) => e - 2 * r);
	return {
		lo: i,
		h: r,
		n: t.map((e, t) => Math.ceil((e - i[t]) / r) + 3)
	};
}
async function cc(e, t, n, [r, i, a]) {
	let { buildTraceMesh: o, traceMeshCpu: s } = await import("./meshtrace-B2sLsePG.js").then((e) => e.r), { toModelAsset: c } = await import("./meshFromThree-C49cjhgD.js").then((e) => e.r), { createShape: l } = await import("./document-CNMOilB9.js").then((e) => e.A), u = e.max.map((t, n) => Math.max(t - e.min[n], 1e-9)), d = await o({
		shapes: [l("mesh", 0, {
			asset: "w",
			position: e.max.map((t, n) => (t + e.min[n]) / 2),
			size: u
		})],
		assets: { w: c(e, "grid") }
	}), f = new Uint8Array(r * i * a);
	if (d) for (let e = 0; e < i; e++) for (let o = 0; o < r; o++) {
		let c = t[0] + o * n + n * .013, l = t[1] + e * n + n * .017, u = [], p = t[2] - n;
		for (let e = 0; e < 256; e++) {
			let e = s(d, [
				c,
				l,
				p
			], [
				0,
				0,
				1
			]);
			if (!e) break;
			u.push(p + e.t), p += e.t + 1e-5;
		}
		let m = 0;
		for (let s = 0; s < a; s++) {
			let a = t[2] + s * n;
			for (; m < u.length && u[m] < a;) m++;
			m % 2 == 1 && (f[(s * i + e) * r + o] = 1);
		}
	}
	let p = f.map((e) => 1 - e), m = oc(f, [
		r,
		i,
		a
	]), h = oc(p, [
		r,
		i,
		a
	]), g = new Float32Array(r * i * a);
	for (let e = 0; e < g.length; e++) g[e] = (f[e] ? -(h[e] - .5) : m[e] - .5) * n;
	return g;
}
function lc(e, t, n, r, i, a) {
	let { positions: o, indices: s } = ia(e, t, n, r), c = new Float32Array(o), l = new Uint32Array(s);
	if (!l.length) throw Error("Nothing would be left.");
	let d = {
		...a.materials[0] ?? { color: i },
		color: i,
		texture: -1,
		normalTexture: -1
	};
	return m([{
		positions: c,
		normals: u(c, l),
		uvs: null,
		colors: null,
		indices: l,
		material: 0
	}], [d], []);
}
async function uc(e, t = 96) {
	let { lo: n, h: r, n: i } = sc(e.min, e.max, t);
	return lc(await cc(e, n, r, i), i, n, r, e.materials[0]?.color ?? [
		.8,
		.8,
		.8
	], e);
}
async function dc(e, t, n, r, i = 96) {
	let a = await ra({
		shapes: [t],
		assets: e.assets
	});
	if (!a.triangles) throw Error("Pick an imported model and a shape.");
	let { shapeBox: o } = await import("./document-CNMOilB9.js").then((e) => e.tn), { copiesDistance: s } = await import("./document-CNMOilB9.js").then((e) => e.Qr), c = o(n) ?? {
		min: a.min,
		max: a.max
	}, l = r === "intersect" ? a.min.map((e, t) => Math.max(e, c.min[t])) : r === "add" ? a.min.map((e, t) => Math.min(e, c.min[t])) : a.min, u = r === "intersect" ? a.max.map((e, t) => Math.min(e, c.max[t])) : r === "add" ? a.max.map((e, t) => Math.max(e, c.max[t])) : a.max;
	if (l.some((e, t) => e >= u[t])) throw Error("The model and the shape do not meet.");
	let { lo: d, h: f, n: p } = sc(l, u, i), h = await cc(a, d, f, p);
	for (let e = 0; e < p[2]; e++) for (let t = 0; t < p[1]; t++) for (let i = 0; i < p[0]; i++) {
		let a = (e * p[1] + t) * p[0] + i, o = s(n, [
			d[0] + i * f,
			d[1] + t * f,
			d[2] + e * f
		]);
		h[a] = r === "add" ? Math.min(h[a], o) : r === "subtract" ? Math.max(h[a], -o) : Math.max(h[a], o);
	}
	let g = lc(h, p, d, f, a.materials[1]?.color ?? a.materials[0]?.color ?? [
		.8,
		.8,
		.8
	], a), _ = g.max.map((e, t) => (e + g.min[t]) / 2), v = g.parts.map((e) => {
		let t = new Float32Array(e.positions);
		for (let e = 0; e < t.length; e += 3) for (let n = 0; n < 3; n++) t[e + n] -= _[n];
		return {
			...e,
			positions: t
		};
	});
	return {
		asset: m(v, g.materials, g.textures),
		position: _,
		size: g.max.map((e, t) => Math.max(.01, e - g.min[t]))
	};
}
function fc(e) {
	if (e.triangles * 4 > 4e6) throw Error("That would be more than 4 million triangles: simplify it first.");
	let t = e.parts.map((e) => {
		let t = Array.from(e.positions), n = Array.from(e.normals), r = e.uvs ? Array.from(e.uvs) : null, i = e.colors ? Array.from(e.colors) : null, a = /* @__PURE__ */ new Map(), o = (e, o) => {
			let s = e < o ? `${e},${o}` : `${o},${e}`, c = a.get(s);
			if (c !== void 0) return c;
			c = t.length / 3;
			for (let r = 0; r < 3; r++) t.push((t[e * 3 + r] + t[o * 3 + r]) / 2), n.push((n[e * 3 + r] + n[o * 3 + r]) / 2), i && i.push((i[e * 3 + r] + i[o * 3 + r]) / 2);
			if (r) for (let t = 0; t < 2; t++) r.push((r[e * 2 + t] + r[o * 2 + t]) / 2);
			return a.set(s, c), c;
		}, s = [];
		for (let t = 0; t < e.indices.length; t += 3) {
			let [n, r, i] = [
				e.indices[t],
				e.indices[t + 1],
				e.indices[t + 2]
			], a = o(n, r), c = o(r, i), l = o(i, n);
			s.push(n, a, l, a, r, c, l, c, i, a, c, l);
		}
		let c = new Float32Array(t), l = new Uint32Array(s);
		return {
			...e,
			positions: c,
			normals: u(c, l),
			uvs: r ? new Float32Array(r) : null,
			colors: i ? new Float32Array(i) : null,
			indices: l
		};
	});
	return Zs(m(t, e.materials, e.textures), 1);
}
//#endregion
//#region ../scene3d/src/model/brush.ts
var pc = [
	"draw",
	"inflate",
	"smooth",
	"grab",
	"paint"
], mc = {
	draw: "Draw",
	inflate: "Inflate",
	smooth: "Smooth",
	grab: "Grab",
	paint: "Paint"
};
function hc(e) {
	return {
		painted: !1,
		parts: e.parts.map((e) => {
			let t = e.positions.length / 3, n = new Uint32Array(t), r = /* @__PURE__ */ new Map(), i = [];
			for (let a = 0; a < t; a++) {
				let t = `${Math.round(e.positions[a * 3] * 1e5)},${Math.round(e.positions[a * 3 + 1] * 1e5)},${Math.round(e.positions[a * 3 + 2] * 1e5)}`, o = r.get(t);
				o === void 0 && (r.set(t, o = i.length), i.push([])), n[a] = o, i[o].push(a);
			}
			let a = i.map(() => /* @__PURE__ */ new Set());
			for (let t = 0; t < e.indices.length; t += 3) {
				let [r, i, o] = [
					n[e.indices[t]],
					n[e.indices[t + 1]],
					n[e.indices[t + 2]]
				];
				a[r].add(i).add(o), a[i].add(r).add(o), a[o].add(r).add(i);
			}
			return {
				positions: new Float32Array(e.positions),
				normals: new Float32Array(e.normals),
				colors: e.colors ? new Float32Array(e.colors) : null,
				indices: e.indices,
				place: n,
				points: i,
				neighbours: a
			};
		})
	};
}
function gc(e, t, n) {
	let { at: r, radius: i, strength: a } = n, o = !1;
	return e.parts.forEach((s, c) => {
		let l = s.positions, d = [];
		if (s.points.forEach((e, t) => {
			let n = e[0], a = Math.hypot(l[n * 3] - r[0], l[n * 3 + 1] - r[1], l[n * 3 + 2] - r[2]);
			if (a < i) {
				let e = 1 - a / i;
				d.push([t, e * e * (3 - 2 * e)]);
			}
		}), !d.length) return;
		if (o = !0, n.kind === "paint") {
			if (!s.colors) {
				let n = t.materials[t.parts[c].material]?.color ?? [
					1,
					1,
					1
				];
				s.colors = new Float32Array(l.length);
				for (let e = 0; e < l.length; e += 3) s.colors.set(n, e);
				e.painted = !0;
			}
			let r = n.color ?? [
				1,
				1,
				1
			];
			for (let [e, t] of d) for (let n of s.points[e]) for (let e = 0; e < 3; e++) s.colors[n * 3 + e] += (r[e] - s.colors[n * 3 + e]) * t * a;
			return;
		}
		let f = d.map(([e, t]) => {
			let r = s.points[e][0];
			if (n.kind === "draw") return n.normal.map((e) => e * i * .08 * a * t);
			if (n.kind === "inflate") return [
				s.normals[r * 3],
				s.normals[r * 3 + 1],
				s.normals[r * 3 + 2]
			].map((e) => e * i * .08 * a * t);
			if (n.kind === "grab") return (n.move ?? [
				0,
				0,
				0
			]).map((e) => e * t);
			let o = s.neighbours[e];
			if (!o.size) return [
				0,
				0,
				0
			];
			let c = [
				0,
				0,
				0
			];
			for (let e of o) for (let t = 0; t < 3; t++) c[t] += l[s.points[e][0] * 3 + t] / o.size;
			return [
				0,
				1,
				2
			].map((e) => (c[e] - l[r * 3 + e]) * .5 * a * t);
		});
		d.forEach(([e], t) => {
			for (let n of s.points[e]) for (let e = 0; e < 3; e++) l[n * 3 + e] += f[t][e];
		}), s.normals = u(l, s.indices);
	}), o;
}
function _c(e, t) {
	let n = t.parts.map((t, n) => ({
		...t,
		positions: e.parts[n].positions,
		normals: e.parts[n].normals,
		colors: e.parts[n].colors
	})), r = new Set(e.parts.flatMap((e, n) => e.colors && !t.parts[n].colors ? [t.parts[n].material] : [])), i = t.materials.map((e, t) => r.has(t) ? {
		...e,
		color: [
			1,
			1,
			1
		]
	} : e);
	return m(n, i, t.textures);
}
function vc(e, t) {
	let n = t.max.map((e, n) => Math.max(e - t.min[n], 1e-9)), r = e.size.map((e, t) => e / n[t]), i = t.min.map((e, n) => (e + t.max[n]) / 2), a = an(e.rotation), o = (e, t, n) => [
		0,
		1,
		2
	].map((r) => a[r] * e + a[3 + r] * t + a[6 + r] * n);
	return {
		point: (t) => o(t[0] - e.position[0], t[1] - e.position[1], t[2] - e.position[2]).map((e, t) => e / r[t] + i[t]),
		move: (e) => o(...e).map((e, t) => e / r[t]),
		normal: (e) => {
			let t = o(...e).map((e, t) => e * r[t]), n = Math.hypot(...t) || 1;
			return t.map((e) => e / n);
		},
		toScene: (t) => {
			let n = t.map((e, t) => (e - i[t]) * r[t]);
			return [
				0,
				1,
				2
			].map((t) => a[t * 3] * n[0] + a[t * 3 + 1] * n[1] + a[t * 3 + 2] * n[2] + e.position[t]);
		},
		units: (e) => e / ((r[0] + r[1] + r[2]) / 3)
	};
}
//#endregion
//#region ../scene3d/src/model/animations.ts
var yc = [
	"Basics",
	"Gestures",
	"Together",
	"Dance",
	"Fight",
	"Sitting",
	"Story",
	"Poses"
], bc = {
	relaxed: [
		.15,
		.22,
		.28,
		.34,
		.4
	],
	open: [
		0,
		0,
		0,
		0,
		0
	],
	fist: [
		.85,
		1,
		1,
		1,
		1
	],
	point: [
		.75,
		0,
		1,
		1,
		1
	],
	peace: [
		.85,
		0,
		0,
		1,
		1
	],
	clasp: [
		.35,
		.5,
		.55,
		.6,
		.65
	]
}, xc = [
	{
		id: "speed",
		name: "Speed",
		min: .25,
		max: 3,
		step: .05,
		value: 1,
		unit: "x"
	},
	{
		id: "energy",
		name: "Energy",
		min: 0,
		max: 2,
		step: .05,
		value: 1,
		unit: "x"
	},
	{
		id: "armSpace",
		name: "Arm space",
		min: -30,
		max: 40,
		step: 1,
		value: 0,
		unit: "°"
	}
], Sc = Math.PI * 2, z = (e) => Math.sin(e * Sc), Cc = (e) => Math.cos(e * Sc), B = (e) => (1 - Cc(e)) / 2, wc = (e, t, n) => e <= t || e >= n ? 0 : (1 - Math.cos((e - t) / (n - t) * Sc)) / 2, V = (e) => Math.max(0, e), H = {
	"Forearm L": [
		-8,
		0,
		0
	],
	"Forearm R": [
		-8,
		0,
		0
	]
}, Tc = {
	id: "stride",
	name: "Stride",
	min: .2,
	max: 2,
	step: .05,
	value: 1,
	unit: "x"
}, Ec = {
	id: "bounce",
	name: "Bounce",
	min: 0,
	max: 2,
	step: .05,
	value: 1,
	unit: "x"
}, Dc = {
	id: "arms",
	name: "Arm swing",
	min: 0,
	max: 2,
	step: .05,
	value: 1,
	unit: "x"
}, Oc = (e) => ({
	id: "lean",
	name: "Lean",
	min: -20,
	max: 40,
	step: 1,
	value: e,
	unit: "°"
}), kc = {
	id: "height",
	name: "Height",
	min: 0,
	max: 2,
	step: .05,
	value: 1,
	unit: "x"
};
function Ac(e) {
	return (t, n) => {
		let r = n.stride ?? 1, i = n.arms ?? 1, a = (t) => -e.thigh * r * z(t), o = (t) => e.knee * r * V(Cc(t)) + (e.crouch ?? 0) * 1.6;
		return {
			bones: {
				Hips: [
					0,
					6 * z(t),
					0
				],
				Spine: [
					n.lean ?? 0,
					-5 * z(t),
					0
				],
				Chest: [
					0,
					-4 * z(t),
					0
				],
				Head: [
					0,
					3 * z(t),
					0
				],
				"Thigh L": [
					a(t) - (e.crouch ?? 0),
					0,
					0
				],
				"Shin L": [
					o(t),
					0,
					0
				],
				"Thigh R": [
					a(t + .5) - (e.crouch ?? 0),
					0,
					0
				],
				"Shin R": [
					o(t + .5),
					0,
					0
				],
				"Upper arm L": [
					e.arm * i * z(t),
					0,
					0
				],
				"Forearm L": [
					-e.elbow - e.elbow / 2 * i * V(-z(t)),
					0,
					0
				],
				"Upper arm R": [
					e.arm * i * z(t + .5),
					0,
					0
				],
				"Forearm R": [
					-e.elbow - e.elbow / 2 * i * V(-z(t + .5)),
					0,
					0
				]
			},
			lift: (n.bounce ?? 1) * e.bob * (1 - Cc(2 * t)) / 2 - (e.crouch ?? 0) / 300
		};
	};
}
var jc = [
	{
		id: "idle",
		name: "Idle",
		group: "Basics",
		note: "Standing, breathing, a little sway.",
		cycle: 3.2,
		pose: (e) => ({ bones: {
			...H,
			Spine: [
				2 + 1.5 * z(e),
				0,
				1.5 * z(e / 2)
			],
			Chest: [
				1.5 * z(e),
				0,
				0
			],
			Head: [
				2 * z(e + .25),
				4 * z(e / 2),
				0
			],
			"Upper arm L": [
				0,
				0,
				3 + 2 * z(e)
			],
			"Upper arm R": [
				0,
				0,
				-3 - 2 * z(e)
			]
		} })
	},
	{
		id: "walk",
		name: "Walk",
		group: "Basics",
		note: "An easy walk, arms swinging.",
		cycle: 1.1,
		travel: .8,
		params: [
			Tc,
			Dc,
			Ec,
			Oc(3)
		],
		pose: Ac({
			thigh: 26,
			knee: 38,
			arm: 22,
			elbow: 12,
			bob: .012
		})
	},
	{
		id: "run",
		name: "Run",
		group: "Basics",
		note: "Running, elbows bent, leaning in.",
		cycle: .7,
		travel: 1.6,
		params: [
			Tc,
			Dc,
			Ec,
			Oc(12)
		],
		pose: Ac({
			thigh: 45,
			knee: 85,
			arm: 45,
			elbow: 75,
			bob: .035
		})
	},
	{
		id: "sneak",
		name: "Sneak",
		group: "Basics",
		note: "Crouched and careful, on tiptoe.",
		cycle: 1.6,
		travel: .45,
		params: [
			Tc,
			Dc,
			Oc(22)
		],
		pose: Ac({
			thigh: 20,
			knee: 30,
			arm: 10,
			elbow: 50,
			bob: .006,
			crouch: 28
		})
	},
	{
		id: "zombie",
		name: "Zombie walk",
		group: "Basics",
		note: "Arms out in front, dragging along.",
		cycle: 1.8,
		travel: .4,
		params: [Tc, Oc(8)],
		pose: (e, t) => {
			let n = Ac({
				thigh: 14,
				knee: 18,
				arm: 0,
				elbow: 0,
				bob: .008
			})(e, {
				...t,
				arms: 0
			});
			return {
				...n,
				bones: {
					...n.bones,
					"Upper arm L": [
						-80 + 6 * z(e),
						0,
						-8
					],
					"Upper arm R": [
						-80 - 6 * z(e),
						0,
						8
					],
					"Forearm L": [
						-5,
						0,
						0
					],
					"Forearm R": [
						-5,
						0,
						0
					],
					Head: [
						10,
						0,
						14 + 4 * z(e)
					]
				}
			};
		}
	},
	{
		id: "skip",
		name: "Happy skip",
		group: "Basics",
		note: "Skipping along, arms up and swinging.",
		cycle: .9,
		travel: .9,
		params: [Tc, Ec],
		pose: (e, t) => ({
			...Ac({
				thigh: 35,
				knee: 70,
				arm: 50,
				elbow: 40,
				bob: 0
			})(e, {
				...t,
				arms: 1
			}),
			lift: (t.bounce ?? 1) * .06 * V(z(2 * e))
		})
	},
	{
		id: "jump",
		name: "Jump",
		group: "Basics",
		note: "Crouch, spring up with arms high, land.",
		cycle: 1.3,
		params: [kc],
		pose: (e, t) => {
			let n = wc(e, 0, .3) + wc(e, .75, 1), r = wc(e, .25, .8);
			return {
				bones: {
					Spine: [
						18 * n,
						0,
						0
					],
					"Thigh L": [
						-45 * n - 8 * r,
						0,
						0
					],
					"Thigh R": [
						-45 * n - 8 * r,
						0,
						0
					],
					"Shin L": [
						80 * n + 15 * r,
						0,
						0
					],
					"Shin R": [
						80 * n + 15 * r,
						0,
						0
					],
					"Upper arm L": [
						35 * n - 150 * r,
						0,
						10 * r
					],
					"Upper arm R": [
						35 * n - 150 * r,
						0,
						-10 * r
					],
					"Forearm L": [
						-15,
						0,
						0
					],
					"Forearm R": [
						-15,
						0,
						0
					],
					Head: [
						-10 * r,
						0,
						0
					]
				},
				lift: (t.height ?? 1) * .35 * r - .1 * n
			};
		}
	},
	{
		id: "climb",
		name: "Climb",
		group: "Basics",
		note: "Climbing a ladder on the spot, hand over hand.",
		cycle: 1.4,
		pose: (e) => ({ bones: {
			Spine: [
				6,
				0,
				0
			],
			"Upper arm L": [
				-150 + 30 * z(e),
				0,
				15
			],
			"Upper arm R": [
				-150 - 30 * z(e),
				0,
				-15
			],
			"Forearm L": [
				-40 - 30 * V(z(e)),
				0,
				0
			],
			"Forearm R": [
				-40 - 30 * V(-z(e)),
				0,
				0
			],
			"Thigh L": [
				-50 * V(-z(e)) - 10,
				0,
				0
			],
			"Thigh R": [
				-50 * V(z(e)) - 10,
				0,
				0
			],
			"Shin L": [
				70 * V(-z(e)) + 10,
				0,
				0
			],
			"Shin R": [
				70 * V(z(e)) + 10,
				0,
				0
			],
			Head: [
				-12,
				0,
				0
			]
		} })
	},
	{
		id: "wave",
		name: "Wave hello",
		group: "Gestures",
		note: "Waving hello with the right hand (Mirror for the left).",
		cycle: 1.2,
		params: [{
			id: "hand",
			name: "Hand height",
			min: .4,
			max: 1.2,
			step: .05,
			value: 1,
			unit: "x"
		}],
		pose: (e, t) => ({ bones: {
			...H,
			"Upper arm R": [
				-15,
				0,
				-150 * (t.hand ?? 1)
			],
			"Forearm R": [
				0,
				0,
				-15 + 28 * z(e * 2)
			],
			Head: [
				0,
				-8,
				-4
			],
			Chest: [
				0,
				-5,
				3
			]
		} })
	},
	{
		id: "handshake",
		name: "Shake hands",
		group: "Gestures",
		note: "The right hand offered at waist height and shaken; two people facing each other read as one handshake.",
		cycle: 1.6,
		pose: (e) => {
			let t = e < .25 ? e / .25 : e > .85 ? (1 - e) / .15 : 1, n = e > .3 && e < .75 ? z((e - .3) / .45 * 2) : 0;
			return { bones: {
				...H,
				"Upper arm R": [
					-72 * t - 7 * n,
					-14 * t,
					-10 * t
				],
				"Forearm R": [
					-14 * t - 7 * n,
					-8 * t,
					0
				],
				"Hand R": [
					10 * n,
					0,
					18 * t
				],
				Chest: [
					6 * t,
					-6 * t,
					0
				],
				Head: [
					4 * t,
					-6 * t,
					0
				]
			} };
		}
	},
	{
		id: "toss",
		name: "Underhand toss",
		group: "Gestures",
		note: "A ring or a ball tossed underhand: the right arm swings back, forward and up, letting go at the top, then comes back.",
		cycle: 1,
		pose: (e) => {
			let t = e < .35 ? e / .35 * 38 : e < .55 ? 38 - (e - .35) / .2 * 128 : -90 * (1 - (e - .55) / .45), n = e < .35 ? e / .35 : e < .7 ? 1 : (1 - e) / .3;
			return {
				bones: {
					...H,
					"Upper arm R": [
						t,
						0,
						8
					],
					"Forearm R": [
						Math.min(0, t) * .25,
						0,
						0
					],
					Chest: [
						8 * n,
						-6 * n,
						0
					],
					Head: [
						-4 * n,
						-4 * n,
						0
					]
				},
				hands: { R: e < .5 ? "fist" : "open" }
			};
		}
	},
	{
		id: "hug",
		name: "Hug",
		group: "Together",
		note: "Arms round someone standing close, head tipped to one side, a slow breath; two characters facing each other read as one hug.",
		cycle: 3,
		pose: (e) => ({
			bones: {
				"Upper arm L": [
					-68,
					0,
					22
				],
				"Upper arm R": [
					-62,
					0,
					-18
				],
				"Forearm L": [
					-24,
					-72,
					0
				],
				"Forearm R": [
					-30,
					68,
					0
				],
				Chest: [
					6 + 1.5 * z(e),
					0,
					0
				],
				Head: [
					6,
					-8,
					10
				]
			},
			hands: {
				L: "open",
				R: "open"
			},
			lift: -.004 * B(e)
		})
	},
	{
		id: "slow-dance",
		name: "Slow dance",
		group: "Together",
		note: "Arms up on a partner's shoulders, swaying from foot to foot; two characters facing each other read as dancing together.",
		cycle: 3.2,
		pose: (e) => ({
			bones: {
				"Upper arm L": [
					-62,
					0,
					16
				],
				"Upper arm R": [
					-62,
					0,
					-16
				],
				"Forearm L": [
					-30,
					-34,
					0
				],
				"Forearm R": [
					-30,
					34,
					0
				],
				Spine: [
					0,
					0,
					4 * z(e)
				],
				Chest: [
					4,
					4 * z(e),
					0
				],
				Head: [
					8,
					5 * z(e),
					-4 * z(e)
				],
				"Thigh L": [
					-6 * Math.max(0, z(e)),
					0,
					0
				],
				"Thigh R": [
					-6 * Math.max(0, -z(e)),
					0,
					0
				],
				"Shin L": [
					10 * Math.max(0, z(e)),
					0,
					0
				],
				"Shin R": [
					10 * Math.max(0, -z(e)),
					0,
					0
				]
			},
			hands: {
				L: "relaxed",
				R: "relaxed"
			}
		})
	},
	{
		id: "clap",
		name: "Clap",
		group: "Gestures",
		note: "Clapping in front of the chest.",
		cycle: .5,
		pose: (e) => {
			let t = B(e);
			return { bones: {
				"Upper arm L": [
					-55,
					18 * t - 30,
					0
				],
				"Upper arm R": [
					-55,
					-18 * t + 30,
					0
				],
				"Forearm L": [
					-55,
					-30 + 20 * t,
					0
				],
				"Forearm R": [
					-55,
					30 - 20 * t,
					0
				],
				Head: [
					4 * z(e),
					0,
					0
				]
			} };
		}
	},
	{
		id: "cheer",
		name: "Cheer",
		group: "Gestures",
		note: "Both arms up, bouncing with joy.",
		cycle: .8,
		params: [Ec],
		pose: (e, t) => ({
			bones: {
				"Upper arm L": [
					-10,
					0,
					150 + 15 * z(e)
				],
				"Upper arm R": [
					-10,
					0,
					-150 - 15 * z(e)
				],
				"Forearm L": [
					0,
					0,
					15 * z(e)
				],
				"Forearm R": [
					0,
					0,
					-15 * z(e)
				],
				Head: [
					-15,
					0,
					0
				],
				Spine: [
					-6,
					0,
					0
				],
				"Thigh L": [
					-12 * B(e),
					0,
					0
				],
				"Thigh R": [
					-12 * B(e),
					0,
					0
				],
				"Shin L": [
					22 * B(e),
					0,
					0
				],
				"Shin R": [
					22 * B(e),
					0,
					0
				]
			},
			lift: (t.bounce ?? 1) * .05 * V(z(e))
		})
	},
	{
		id: "victory",
		name: "Fist pump",
		group: "Gestures",
		note: "A winning fist pump.",
		cycle: .9,
		pose: (e) => ({ bones: {
			...H,
			"Upper arm R": [
				-20,
				0,
				-110 - 25 * B(e)
			],
			"Forearm R": [
				0,
				0,
				-70 + 30 * B(e)
			],
			Spine: [
				-4,
				0,
				-4
			],
			Head: [
				-10,
				-10,
				0
			]
		} })
	},
	{
		id: "point",
		name: "Point ahead",
		group: "Gestures",
		note: "Pointing ahead, looking where it points.",
		cycle: 2.4,
		pose: (e) => ({ bones: {
			...H,
			"Upper arm R": [
				-85 + 3 * z(e),
				10,
				-12
			],
			"Forearm R": [
				-4,
				0,
				0
			],
			Chest: [
				0,
				-12,
				0
			],
			Head: [
				0,
				-8 + 4 * z(e),
				0
			]
		} })
	},
	{
		id: "salute",
		name: "Salute",
		group: "Gestures",
		note: "A crisp salute, standing tall.",
		cycle: 2.4,
		pose: (e) => {
			let t = wc(e, .05, .95);
			return { bones: {
				"Upper arm R": [
					-25 * t,
					0,
					-85 * t
				],
				"Forearm R": [
					-120 * t,
					0,
					0
				],
				"Forearm L": [
					-4,
					0,
					0
				],
				Spine: [
					-3,
					0,
					0
				],
				Head: [
					-3,
					0,
					0
				]
			} };
		}
	},
	{
		id: "bow",
		name: "Bow (ojigi)",
		group: "Gestures",
		note: "A polite bow (ojigi) and back up.",
		cycle: 2.6,
		params: [{
			id: "depth",
			name: "Bow depth",
			min: .3,
			max: 2,
			step: .05,
			value: 1,
			unit: "x"
		}],
		pose: (e, t) => {
			let n = wc(e, .05, .85) * (t.depth ?? 1);
			return { bones: {
				Spine: [
					28 * n,
					0,
					0
				],
				Chest: [
					14 * n,
					0,
					0
				],
				Head: [
					10 * n,
					0,
					0
				],
				"Upper arm L": [
					-10 * n,
					0,
					-4
				],
				"Upper arm R": [
					-10 * n,
					0,
					4
				],
				"Forearm L": [
					-20 * n,
					0,
					0
				],
				"Forearm R": [
					-20 * n,
					0,
					0
				],
				Hips: [
					6 * n,
					0,
					0
				]
			} };
		}
	},
	{
		id: "nod",
		name: "Nod yes",
		group: "Gestures",
		note: "Nodding yes.",
		cycle: .8,
		pose: (e) => ({ bones: {
			...H,
			Head: [
				14 * z(e),
				0,
				0
			],
			Neck: [
				5 * z(e),
				0,
				0
			]
		} })
	},
	{
		id: "shake",
		name: "Shake head no",
		group: "Gestures",
		note: "Shaking the head no.",
		cycle: .8,
		pose: (e) => ({ bones: {
			...H,
			Head: [
				0,
				28 * z(e),
				0
			],
			Neck: [
				0,
				8 * z(e),
				0
			]
		} })
	},
	{
		id: "shrug",
		name: "Shrug",
		group: "Gestures",
		note: "A shrug: palms up, shoulders raised.",
		cycle: 1.8,
		pose: (e) => {
			let t = wc(e, .1, .9);
			return { bones: {
				"Upper arm L": [
					-15 * t,
					0,
					22 * t
				],
				"Upper arm R": [
					-15 * t,
					0,
					-22 * t
				],
				"Forearm L": [
					-70 * t,
					20 * t,
					0
				],
				"Forearm R": [
					-70 * t,
					-20 * t,
					0
				],
				Head: [
					0,
					0,
					10 * t
				],
				Chest: [
					-3 * t,
					0,
					0
				]
			} };
		}
	},
	{
		id: "think",
		name: "Thinking",
		group: "Gestures",
		note: "Hand to chin, head tilting, thinking it over.",
		cycle: 3.4,
		pose: (e) => ({ bones: {
			"Upper arm R": [
				-45,
				0,
				-25
			],
			"Forearm R": [
				-125,
				0,
				0
			],
			"Upper arm L": [
				-25,
				-20,
				5
			],
			"Forearm L": [
				-80,
				-30,
				0
			],
			Head: [
				10,
				6 * z(e),
				6 + 3 * z(e / 2)
			]
		} })
	},
	{
		id: "look",
		name: "Look around",
		group: "Gestures",
		note: "Looking left and right, turning the shoulders.",
		cycle: 4,
		pose: (e) => ({ bones: {
			...H,
			Head: [
				0,
				50 * z(e),
				0
			],
			Neck: [
				0,
				12 * z(e),
				0
			],
			Chest: [
				0,
				14 * z(e),
				0
			]
		} })
	},
	{
		id: "talk",
		name: "Talking",
		group: "Gestures",
		note: "Talking with both hands.",
		cycle: 2.6,
		pose: (e) => ({ bones: {
			"Upper arm L": [
				-20 - 12 * z(e),
				0,
				10
			],
			"Upper arm R": [
				-20 + 12 * z(e * 2),
				0,
				-10
			],
			"Forearm L": [
				-60 - 22 * z(e),
				15,
				0
			],
			"Forearm R": [
				-60 - 22 * Cc(e * 2),
				-15,
				0
			],
			Head: [
				4 * z(e * 3),
				8 * z(e),
				0
			],
			Chest: [
				0,
				5 * z(e),
				0
			]
		} })
	},
	{
		id: "sad",
		name: "Sad",
		group: "Gestures",
		note: "Slumped, head low, sighing.",
		cycle: 3.6,
		pose: (e) => ({ bones: {
			Spine: [
				12 + 3 * z(e),
				0,
				0
			],
			Chest: [
				8,
				0,
				0
			],
			Head: [
				26 + 4 * z(e),
				0,
				4
			],
			"Upper arm L": [
				5,
				0,
				-4
			],
			"Upper arm R": [
				5,
				0,
				4
			]
		} })
	},
	{
		id: "bounce-dance",
		name: "Hip-hop bounce",
		group: "Dance",
		note: "Bouncing to the beat, arms swinging.",
		cycle: .55,
		params: [Ec, Dc],
		pose: (e, t) => ({
			bones: {
				"Thigh L": [
					-18 * B(e),
					0,
					4
				],
				"Thigh R": [
					-18 * B(e),
					0,
					-4
				],
				"Shin L": [
					34 * B(e),
					0,
					0
				],
				"Shin R": [
					34 * B(e),
					0,
					0
				],
				Spine: [
					8 * B(e),
					0,
					0
				],
				Chest: [
					0,
					10 * z(e / 2),
					0
				],
				Head: [
					10 * B(e),
					0,
					0
				],
				"Upper arm L": [
					-30 * (t.arms ?? 1) * z(e / 2),
					0,
					12
				],
				"Upper arm R": [
					30 * (t.arms ?? 1) * z(e / 2),
					0,
					-12
				],
				"Forearm L": [
					-50,
					0,
					0
				],
				"Forearm R": [
					-50,
					0,
					0
				]
			},
			lift: -(t.bounce ?? 1) * .025 * B(e)
		})
	},
	{
		id: "disco",
		name: "Disco point",
		group: "Dance",
		note: "Pointing up and across, hips swaying.",
		cycle: 1,
		pose: (e) => {
			let t = V(z(e)), n = V(-z(e));
			return { bones: {
				"Upper arm R": [
					-20,
					0,
					-150 * t + 30 * n
				],
				"Forearm R": [
					0,
					0,
					0
				],
				"Upper arm L": [
					-20,
					0,
					25
				],
				"Forearm L": [
					-95,
					30,
					0
				],
				Hips: [
					0,
					14 * z(e),
					6 * z(e)
				],
				Chest: [
					0,
					-10 * z(e),
					0
				],
				Head: [
					0,
					-15 * z(e),
					0
				],
				"Thigh L": [
					-14 * n,
					0,
					0
				],
				"Thigh R": [
					-14 * t,
					0,
					0
				],
				"Shin L": [
					26 * n,
					0,
					0
				],
				"Shin R": [
					26 * t,
					0,
					0
				]
			} };
		}
	},
	{
		id: "twist",
		name: "The twist",
		group: "Dance",
		note: "Twisting low: hips one way, shoulders the other.",
		cycle: .5,
		pose: (e) => ({
			bones: {
				Hips: [
					0,
					28 * z(e),
					0
				],
				Chest: [
					0,
					-40 * z(e),
					0
				],
				"Thigh L": [
					-22,
					0,
					0
				],
				"Thigh R": [
					-22,
					0,
					0
				],
				"Shin L": [
					40,
					0,
					0
				],
				"Shin R": [
					40,
					0,
					0
				],
				"Upper arm L": [
					-30,
					0,
					30
				],
				"Upper arm R": [
					-30,
					0,
					-30
				],
				"Forearm L": [
					-70,
					0,
					0
				],
				"Forearm R": [
					-70,
					0,
					0
				]
			},
			lift: -.04
		})
	},
	{
		id: "robot",
		name: "Robot",
		group: "Dance",
		note: "Stiff, stepping robot arms.",
		cycle: 2,
		pose: (e) => {
			let t = Math.floor(e * 4) % 4, [n, r, i, a] = [
				[
					-90,
					-90,
					0,
					-90
				],
				[
					0,
					-90,
					-90,
					-90
				],
				[
					-90,
					0,
					-90,
					-90
				],
				[
					0,
					-90,
					0,
					0
				]
			][t];
			return { bones: {
				"Upper arm L": [
					n,
					0,
					20
				],
				"Forearm L": [
					r,
					0,
					0
				],
				"Upper arm R": [
					i,
					0,
					-20
				],
				"Forearm R": [
					a,
					0,
					0
				],
				Head: [
					0,
					[
						20,
						-20,
						0,
						0
					][t],
					0
				],
				Chest: [
					0,
					[
						10,
						-10,
						0,
						0
					][t],
					0
				]
			} };
		}
	},
	{
		id: "floss",
		name: "Floss",
		group: "Dance",
		note: "Arms swinging past the hips, hips the other way.",
		cycle: .6,
		pose: (e) => ({ bones: {
			"Upper arm L": [
				22 * z(e),
				0,
				20 + 30 * z(e)
			],
			"Upper arm R": [
				-22 * z(e),
				0,
				-20 + 30 * z(e)
			],
			"Forearm L": [
				-5,
				0,
				0
			],
			"Forearm R": [
				-5,
				0,
				0
			],
			Hips: [
				0,
				0,
				-10 * z(e)
			],
			Spine: [
				0,
				0,
				6 * z(e)
			]
		} })
	},
	{
		id: "spin",
		name: "Spin",
		group: "Dance",
		note: "A full turn on the spot, arms out.",
		cycle: 1.6,
		pose: (e) => ({
			bones: {
				"Upper arm L": [
					0,
					0,
					75
				],
				"Upper arm R": [
					0,
					0,
					-75
				],
				"Forearm L": [
					0,
					0,
					10
				],
				"Forearm R": [
					0,
					0,
					-10
				],
				Head: [
					-8,
					0,
					0
				]
			},
			spin: 360 * e
		})
	},
	{
		id: "guard",
		name: "Boxing guard",
		group: "Fight",
		note: "Fists up, bobbing on the toes.",
		cycle: .7,
		params: [Ec],
		pose: (e, t) => ({
			bones: {
				"Upper arm L": [
					-45,
					0,
					18
				],
				"Upper arm R": [
					-45,
					0,
					-18
				],
				"Forearm L": [
					-115,
					0,
					0
				],
				"Forearm R": [
					-115,
					0,
					0
				],
				Spine: [
					10,
					0,
					0
				],
				Chest: [
					0,
					-12 + 4 * z(e),
					0
				],
				Head: [
					6,
					8,
					0
				],
				"Thigh L": [
					-14,
					0,
					6
				],
				"Thigh R": [
					8,
					0,
					-6
				],
				"Shin L": [
					18,
					0,
					0
				],
				"Shin R": [
					12,
					0,
					0
				]
			},
			lift: (t.bounce ?? 1) * .015 * V(z(e))
		})
	},
	{
		id: "punch",
		name: "Punches",
		group: "Fight",
		note: "A left jab then a right cross.",
		cycle: 1,
		pose: (e) => {
			let t = wc(e, 0, .45), n = wc(e, .45, 1);
			return { bones: {
				"Upper arm L": [
					-45 - 40 * t,
					0,
					18 - 10 * t
				],
				"Upper arm R": [
					-45 - 40 * n,
					0,
					-18 + 10 * n
				],
				"Forearm L": [
					-115 + 110 * t,
					0,
					0
				],
				"Forearm R": [
					-115 + 110 * n,
					0,
					0
				],
				Chest: [
					0,
					-20 * n + 15 * t,
					0
				],
				Spine: [
					10,
					0,
					0
				],
				"Thigh L": [
					-14,
					0,
					6
				],
				"Thigh R": [
					8,
					0,
					-6
				],
				"Shin L": [
					18,
					0,
					0
				],
				"Shin R": [
					12,
					0,
					0
				]
			} };
		}
	},
	{
		id: "kick",
		name: "Kick",
		group: "Fight",
		note: "A high front kick, fists up.",
		cycle: 1.3,
		params: [kc],
		pose: (e, t) => {
			let n = wc(e, .1, .7);
			return { bones: {
				"Thigh R": [
					-95 * n * (t.height ?? 1),
					0,
					0
				],
				"Shin R": [
					70 * (1 - n) * wc(e, .05, .85) + 5,
					0,
					0
				],
				"Thigh L": [
					-5,
					0,
					0
				],
				"Shin L": [
					10,
					0,
					0
				],
				Spine: [
					-12 * n,
					0,
					0
				],
				"Upper arm L": [
					-45,
					0,
					18
				],
				"Upper arm R": [
					-45,
					0,
					-18
				],
				"Forearm L": [
					-115,
					0,
					0
				],
				"Forearm R": [
					-115,
					0,
					0
				]
			} };
		}
	},
	{
		id: "sit",
		name: "Sitting",
		group: "Sitting",
		note: "Sitting on a chair or a ledge, hands on the knees.",
		cycle: 3.2,
		params: [{
			id: "seat",
			name: "Seat height",
			min: 0,
			max: 1.5,
			step: .05,
			value: 1,
			unit: "x"
		}],
		pose: (e, t) => ({
			bones: {
				"Thigh L": [
					-88,
					0,
					4
				],
				"Thigh R": [
					-88,
					0,
					-4
				],
				"Shin L": [
					88,
					0,
					0
				],
				"Shin R": [
					88,
					0,
					0
				],
				Spine: [
					-4 + 1.5 * z(e),
					0,
					0
				],
				"Upper arm L": [
					-35,
					0,
					6
				],
				"Upper arm R": [
					-35,
					0,
					-6
				],
				"Forearm L": [
					-35,
					0,
					0
				],
				"Forearm R": [
					-35,
					0,
					0
				],
				Head: [
					2 * z(e + .25),
					0,
					0
				]
			},
			lift: -.24 * (1 - .3 * ((t.seat ?? 1) - 1))
		})
	},
	{
		id: "sit-talk",
		name: "Sitting and talking",
		group: "Sitting",
		note: "Seated, chatting with the hands.",
		cycle: 2.6,
		pose: (e) => ({
			bones: {
				"Thigh L": [
					-88,
					0,
					4
				],
				"Thigh R": [
					-88,
					0,
					-4
				],
				"Shin L": [
					88,
					0,
					0
				],
				"Shin R": [
					88,
					0,
					0
				],
				"Upper arm L": [
					-25 - 10 * z(e),
					0,
					8
				],
				"Upper arm R": [
					-25 + 10 * z(e * 2),
					0,
					-8
				],
				"Forearm L": [
					-65 - 20 * z(e),
					15,
					0
				],
				"Forearm R": [
					-65 - 20 * Cc(e * 2),
					-15,
					0
				],
				Head: [
					3 * z(e * 3),
					10 * z(e),
					0
				]
			},
			lift: -.24
		})
	},
	{
		id: "sit-floor",
		name: "Sitting on the floor",
		group: "Sitting",
		note: "Sitting cross-legged on the floor.",
		cycle: 3.6,
		pose: (e) => ({
			bones: {
				"Thigh L": [
					-80,
					-30,
					35
				],
				"Thigh R": [
					-80,
					30,
					-35
				],
				"Shin L": [
					140,
					0,
					0
				],
				"Shin R": [
					140,
					0,
					0
				],
				Spine: [
					6 + 1.5 * z(e),
					0,
					0
				],
				"Upper arm L": [
					-25,
					0,
					10
				],
				"Upper arm R": [
					-25,
					0,
					-10
				],
				"Forearm L": [
					-40,
					0,
					0
				],
				"Forearm R": [
					-40,
					0,
					0
				],
				Head: [
					4 + 2 * z(e),
					0,
					0
				]
			},
			lift: -.46
		})
	},
	{
		id: "carry",
		name: "Carry",
		group: "Story",
		note: "Walking with something held in both arms against the chest.",
		cycle: 1.3,
		travel: .6,
		params: [Tc, Oc(-4)],
		pose: (e, t) => {
			let n = Ac({
				thigh: 20,
				knee: 30,
				arm: 0,
				elbow: 0,
				bob: .01
			})(e, {
				...t,
				arms: 0
			});
			return {
				...n,
				bones: {
					...n.bones,
					"Upper arm L": [
						-26,
						-12,
						6
					],
					"Upper arm R": [
						-26,
						12,
						-6
					],
					"Forearm L": [
						-68,
						-20,
						0
					],
					"Forearm R": [
						-68,
						20,
						0
					],
					Head: [
						6,
						2 * z(e),
						0
					]
				}
			};
		}
	},
	{
		id: "mop",
		name: "Mop the floor",
		group: "Story",
		note: "Bent a little, sweeping a mop from side to side.",
		cycle: 1.4,
		pose: (e) => ({
			bones: {
				Spine: [
					16,
					10 * z(e),
					0
				],
				Chest: [
					6,
					14 * z(e),
					0
				],
				Head: [
					14,
					-8 * z(e),
					0
				],
				"Upper arm L": [
					-40 - 8 * z(e),
					0,
					10
				],
				"Upper arm R": [
					-55 + 8 * z(e),
					0,
					-12
				],
				"Forearm L": [
					-50,
					0,
					0
				],
				"Forearm R": [
					-30,
					0,
					0
				],
				"Thigh L": [
					-8,
					0,
					3
				],
				"Thigh R": [
					6,
					0,
					-3
				],
				"Shin L": [
					12,
					0,
					0
				],
				"Shin R": [
					6,
					0,
					0
				]
			},
			lift: -.006
		})
	},
	{
		id: "crouch",
		name: "Crouch and look",
		group: "Story",
		note: "Hunkered down low, keeping out of sight, looking about.",
		cycle: 4.2,
		params: [{
			id: "depth",
			name: "How low",
			min: .3,
			max: 1.2,
			step: .05,
			value: 1,
			unit: "x"
		}],
		pose: (e, t) => {
			let n = t.depth ?? 1;
			return {
				bones: {
					"Thigh L": [
						-100 * n,
						0,
						10
					],
					"Thigh R": [
						-100 * n,
						0,
						-10
					],
					"Shin L": [
						125 * n,
						0,
						0
					],
					"Shin R": [
						125 * n,
						0,
						0
					],
					Spine: [
						28 * n + 2 * z(e),
						0,
						0
					],
					Chest: [
						6,
						10 * z(e),
						0
					],
					Head: [
						-20 * n,
						35 * z(e),
						0
					],
					"Upper arm L": [
						-40,
						0,
						12
					],
					"Upper arm R": [
						-40,
						0,
						-12
					],
					"Forearm L": [
						-50,
						0,
						0
					],
					"Forearm R": [
						-50,
						0,
						0
					]
				},
				lift: -.3 * n
			};
		}
	},
	{
		id: "panic",
		name: "Run in panic",
		group: "Story",
		note: "Running with both hands at the head.",
		cycle: .65,
		travel: 1.4,
		params: [Tc, Oc(10)],
		pose: (e, t) => {
			let n = Ac({
				thigh: 42,
				knee: 80,
				arm: 0,
				elbow: 0,
				bob: .03
			})(e, {
				...t,
				arms: 0
			});
			return {
				...n,
				bones: {
					...n.bones,
					"Upper arm L": [
						-30,
						0,
						120 + 6 * z(e * 2)
					],
					"Upper arm R": [
						-30,
						0,
						-120 - 6 * z(e * 2)
					],
					"Forearm L": [
						-110,
						0,
						0
					],
					"Forearm R": [
						-110,
						0,
						0
					],
					Head: [
						-6,
						10 * z(e),
						0
					]
				}
			};
		}
	},
	{
		id: "startled",
		name: "Startled",
		group: "Story",
		note: "A jolt back, hands up, then a slow settle.",
		cycle: 1.6,
		pose: (e) => {
			let t = e < .12 ? e / .12 : Math.max(0, 1 - (e - .12) / .8) ** 2;
			return {
				bones: {
					Spine: [
						-12 * t,
						0,
						0
					],
					Chest: [
						-8 * t,
						0,
						0
					],
					Head: [
						-10 * t,
						0,
						4 * t
					],
					"Upper arm L": [
						-50 * t,
						0,
						25 * t
					],
					"Upper arm R": [
						-50 * t,
						0,
						-25 * t
					],
					"Forearm L": [
						-8 - 100 * t,
						0,
						0
					],
					"Forearm R": [
						-8 - 100 * t,
						0,
						0
					],
					"Thigh L": [
						8 * t,
						0,
						0
					],
					"Shin L": [
						10 * t,
						0,
						0
					]
				},
				lift: .012 * t
			};
		}
	},
	{
		id: "phone",
		name: "Phone photo",
		group: "Story",
		note: "Holding a phone up in front of the face, tapping to take a photo.",
		cycle: 2,
		pose: (e) => ({ bones: {
			...H,
			"Upper arm R": [
				-70,
				10,
				-10
			],
			"Forearm R": [
				-75,
				0,
				0
			],
			"Upper arm L": [
				-55,
				-10,
				10
			],
			"Forearm L": [
				-80 - 6 * wc(e, .6, .75),
				0,
				0
			],
			Head: [
				6,
				-4,
				0
			],
			Chest: [
				-2,
				-4,
				0
			]
		} })
	},
	{
		id: "push",
		name: "Push",
		group: "Story",
		note: "A shove forward with both hands, then back.",
		cycle: 1.1,
		pose: (e) => {
			let t = wc(e, .1, .7);
			return { bones: {
				Spine: [
					4 + 14 * t,
					0,
					0
				],
				Chest: [
					6 * t,
					0,
					0
				],
				"Upper arm L": [
					-30 - 50 * t,
					0,
					10
				],
				"Upper arm R": [
					-30 - 50 * t,
					0,
					-10
				],
				"Forearm L": [
					-90 + 80 * t,
					0,
					0
				],
				"Forearm R": [
					-90 + 80 * t,
					0,
					0
				],
				"Thigh L": [
					-14 * t,
					0,
					0
				],
				"Shin L": [
					10 * t,
					0,
					0
				],
				"Thigh R": [
					8 * t,
					0,
					0
				]
			} };
		}
	},
	{
		id: "wash",
		name: "Wash hands",
		group: "Story",
		note: "Head down at a sink, rubbing the hands together.",
		cycle: .9,
		pose: (e) => ({ bones: {
			Spine: [
				12,
				0,
				0
			],
			Head: [
				18,
				0,
				0
			],
			"Upper arm L": [
				-34,
				-14,
				4
			],
			"Upper arm R": [
				-34,
				14,
				-4
			],
			"Forearm L": [
				-70,
				-18 + 10 * z(e),
				0
			],
			"Forearm R": [
				-70,
				18 + 10 * z(e),
				0
			]
		} })
	},
	{
		id: "cower",
		name: "Cower",
		group: "Story",
		note: "Crouched with the arms over the head, trembling.",
		cycle: .4,
		pose: (e) => ({
			bones: {
				"Thigh L": [
					-95,
					0,
					8
				],
				"Thigh R": [
					-95,
					0,
					-8
				],
				"Shin L": [
					120,
					0,
					0
				],
				"Shin R": [
					120,
					0,
					0
				],
				Spine: [
					40 + z(e),
					0,
					0
				],
				Head: [
					25,
					0,
					0
				],
				"Upper arm L": [
					-130,
					0,
					30 + z(e)
				],
				"Upper arm R": [
					-130,
					0,
					-30 - z(e)
				],
				"Forearm L": [
					-120,
					0,
					0
				],
				"Forearm R": [
					-120,
					0,
					0
				]
			},
			lift: -.28
		})
	},
	{
		id: "pose-clasp",
		name: "Hands clasped",
		group: "Poses",
		note: "Hands clasped in front, shoulders a little in: polite, shy.",
		cycle: 4,
		pose: (e) => ({
			bones: {
				Spine: [
					2 + z(e),
					0,
					0
				],
				Head: [
					6,
					0,
					4
				],
				"Upper arm L": [
					-22,
					0,
					-14
				],
				"Forearm L": [
					-55,
					-45,
					0
				],
				"Upper arm R": [
					-22,
					0,
					14
				],
				"Forearm R": [
					-55,
					45,
					0
				]
			},
			hands: {
				L: "clasp",
				R: "clasp"
			},
			extra: {
				leftShoulder: [
					0,
					0,
					-4
				],
				rightShoulder: [
					0,
					0,
					4
				]
			}
		})
	},
	{
		id: "pose-cheek",
		name: "Hand to cheek",
		group: "Poses",
		note: "One hand resting on the cheek, the head leaning into it.",
		cycle: 4,
		pose: (e) => ({
			bones: {
				...H,
				Spine: [
					2 + z(e),
					0,
					0
				],
				Head: [
					4,
					-6,
					12
				],
				"Upper arm R": [
					-55,
					50,
					0
				],
				"Forearm R": [
					-148,
					0,
					0
				]
			},
			hands: { R: "open" },
			extra: { rightHand: [
				0,
				0,
				-25
			] }
		})
	},
	{
		id: "pose-peace",
		name: "Peace sign",
		group: "Poses",
		note: "A V sign by the face, a little tilt.",
		cycle: 4,
		pose: (e) => ({
			bones: {
				...H,
				Spine: [
					1 + z(e),
					0,
					0
				],
				Head: [
					2,
					-4,
					8
				],
				"Upper arm R": [
					-55,
					40,
					0
				],
				"Forearm R": [
					-130,
					0,
					0
				]
			},
			hands: { R: "peace" },
			extra: { rightHand: [
				0,
				-30,
				0
			] }
		})
	},
	{
		id: "pose-behind",
		name: "Hands behind",
		group: "Poses",
		note: "Hands held behind the back, leaning forward a touch.",
		cycle: 4,
		pose: (e) => ({
			bones: {
				Spine: [
					6 + z(e),
					0,
					0
				],
				Head: [
					-4,
					0,
					3
				],
				"Upper arm L": [
					35,
					0,
					-10
				],
				"Forearm L": [
					-40,
					-50,
					0
				],
				"Upper arm R": [
					35,
					0,
					10
				],
				"Forearm R": [
					-40,
					50,
					0
				]
			},
			hands: {
				L: "clasp",
				R: "clasp"
			}
		})
	},
	{
		id: "pose-chest",
		name: "Hand on chest",
		group: "Poses",
		note: "One hand over the heart.",
		cycle: 4,
		pose: (e) => ({
			bones: {
				...H,
				Spine: [
					2 + z(e),
					0,
					0
				],
				Head: [
					8,
					4,
					0
				],
				"Upper arm R": [
					-30,
					38,
					0
				],
				"Forearm R": [
					-118,
					0,
					0
				]
			},
			hands: { R: "open" }
		})
	},
	{
		id: "pose-hold",
		name: "Holding a photo",
		group: "Poses",
		note: "Both hands holding something flat at the chest, looking down at it.",
		cycle: 4,
		pose: (e) => ({
			bones: {
				Spine: [
					3 + z(e),
					0,
					0
				],
				Head: [
					18,
					0,
					0
				],
				"Upper arm L": [
					-35,
					0,
					-12
				],
				"Forearm L": [
					-80,
					-40,
					0
				],
				"Upper arm R": [
					-35,
					0,
					12
				],
				"Forearm R": [
					-80,
					40,
					0
				]
			},
			hands: {
				L: "clasp",
				R: "clasp"
			}
		})
	},
	{
		id: "pose-reach",
		name: "Reaching out",
		group: "Poses",
		note: "One hand reaching slowly towards whoever is watching.",
		cycle: 5,
		pose: (e) => ({
			bones: {
				...H,
				Spine: [
					6 + 2 * z(e),
					0,
					0
				],
				Head: [
					4,
					0,
					6
				],
				"Upper arm R": [
					-75 - 5 * z(e),
					0,
					-6
				],
				"Forearm R": [
					-10,
					0,
					0
				]
			},
			hands: { R: "open" }
		})
	}
], Mc = (e) => jc.find((t) => t.id === e), Nc = [
	{
		id: "stand",
		name: "Standing",
		move: "idle",
		at: 0
	},
	{
		id: "wave",
		name: "Waving",
		move: "wave",
		at: .35
	},
	{
		id: "step",
		name: "Mid-step",
		move: "walk",
		at: .25
	},
	{
		id: "run",
		name: "Running",
		move: "run",
		at: .3
	},
	{
		id: "point",
		name: "Pointing",
		move: "point",
		at: .5
	},
	{
		id: "think",
		name: "Thinking",
		move: "think",
		at: .5
	},
	{
		id: "cheer",
		name: "Cheering",
		move: "cheer",
		at: .45
	},
	{
		id: "bow",
		name: "Bowing",
		move: "bow",
		at: .5
	},
	{
		id: "salute",
		name: "Saluting",
		move: "salute",
		at: .5
	},
	{
		id: "guard",
		name: "On guard",
		move: "guard",
		at: .25
	},
	{
		id: "sit",
		name: "Sitting",
		move: "sit-floor",
		at: .5
	},
	{
		id: "shrug",
		name: "Shrugging",
		move: "shrug",
		at: .5
	}
];
function Pc(e, t) {
	let n = Mc(t.move);
	return n ? Wc(e, t.move, t.at * n.cycle) : null;
}
var Fc = (e) => [...xc, ...e.params ?? []], Ic = ut({
	min: [
		-.225,
		0,
		-.1
	],
	max: [
		.225,
		1,
		.1
	]
}), Lc = (e, t) => e && (Rc(e) || Oe(e.bones)) ? e : t();
function Rc(e) {
	if (!e) return !1;
	let t = new Set(e.bones.map((e) => e.name));
	return [
		"Hips",
		"Spine",
		"Upper arm L",
		"Upper arm R",
		"Thigh L",
		"Thigh R"
	].every((e) => t.has(e));
}
var zc = (e) => e.endsWith(" L") ? `${e.slice(0, -1)}R` : e.endsWith(" R") ? `${e.slice(0, -1)}L` : e;
function Bc(e, t, n) {
	let r = {};
	for (let t of Fc(e)) r[t.id] = n.values[t.id] ?? t.value;
	let i = e.pose((t % 1 + 1) % 1, r), a = r.energy, o = {};
	for (let [e, t] of Object.entries(i.bones)) {
		let r = n.mirror ? zc(e) : e;
		o[r] = (n.mirror ? [
			t[0],
			-t[1],
			-t[2]
		] : [...t]).map((e) => e * a);
	}
	let s = r.armSpace;
	if (s) {
		let e = o["Upper arm L"] ?? [
			0,
			0,
			0
		], t = o["Upper arm R"] ?? [
			0,
			0,
			0
		];
		o["Upper arm L"] = [
			e[0],
			e[1],
			e[2] + s
		], o["Upper arm R"] = [
			t[0],
			t[1],
			t[2] - s
		];
	}
	let c = n.mirror ? {
		L: i.hands?.R,
		R: i.hands?.L
	} : i.hands, l = i.extra ? Object.fromEntries(Object.entries(i.extra).map(([e, t]) => {
		let r = n.mirror ? e.replace(/^left/, "@").replace(/^right/, "left").replace(/^@/, "right") : e, i = t;
		return [r, (n.mirror ? [
			i[0],
			-i[1],
			-i[2]
		] : [...i]).map((e) => e * a)];
	})) : void 0;
	return {
		bones: o,
		lift: (i.lift ?? 0) * a,
		spin: n.mirror ? -(i.spin ?? 0) : i.spin,
		hands: c,
		extra: l
	};
}
function Vc(e, t, n) {
	for (let r of ["L", "R"]) {
		let i = r === "L" ? "left" : "right", a = r === "L" ? -1 : 1, o = n.hands?.[r] ?? "relaxed", s = bc[o];
		[
			"Index",
			"Middle",
			"Ring",
			"Little"
		].forEach((n, r) => {
			let c = s[r + 1];
			[
				"Proximal",
				"Intermediate",
				"Distal"
			].forEach((r, s) => {
				let l = t.get(`${i}${n}${r}`);
				if (l === void 0) return;
				let u = [
					75,
					95,
					65
				][s] * c, d = o === "peace" && s === 0 ? (n === "Index" ? 9 : n === "Middle" ? -9 : 0) * -a : 0;
				e[l] = [
					e[l][0],
					e[l][1] + d,
					e[l][2] + a * u
				];
			});
		});
		let c = s[0];
		[
			"ThumbMetacarpal",
			"ThumbProximal",
			"ThumbDistal"
		].forEach((n, r) => {
			let o = t.get(`${i}${n}`);
			if (o === void 0) return;
			let s = [
				25,
				40,
				45
			][r] * c;
			e[o] = [
				e[o][0],
				e[o][1] - a * s,
				e[o][2] + a * s * .35
			];
		});
	}
	for (let [r, i] of Object.entries(n.extra ?? {})) {
		let n = t.get(r);
		n !== void 0 && i && (e[n] = [
			e[n][0] + i[0],
			e[n][1] + i[1],
			e[n][2] + i[2]
		]);
	}
}
function Hc(e, t, n) {
	let r = e.cycle / Math.max(.05, t), i = e.id === "spin" ? 1 : Math.max(1, Math.min(29, Math.round(n / r)));
	return {
		loops: i,
		perLoop: Math.max(4, Math.min(e.id === "robot" ? 16 : 12, Math.floor(119 / i)))
	};
}
var Uc = /* @__PURE__ */ new WeakMap();
function Wc(e, t, n) {
	let r = Mc(t);
	if (!r) return null;
	let i = Uc.get(e.bones);
	if (i === void 0 && (i = Rc(e) ? "figure" : qt(Ic.bones, e.bones), Uc.set(e.bones, i)), !i) return null;
	let a = Bc(r, n / r.cycle % 1, {
		values: {},
		mirror: !1,
		inPlace: !0
	}), o = (i === "figure" ? e.bones : Ic.bones).map((e) => a.bones[e.name] ?? [
		0,
		0,
		0
	]);
	return i === "figure" ? o : we(i, o, void 0).turns;
}
function Gc(e, t, n, r, i) {
	let { loops: a, perLoop: o } = Hc(n, r.values.speed ?? 1, i), s = e.keys?.[0], c = {
		position: s?.position ?? e.position,
		rotation: s?.rotation ?? e.rotation,
		size: s?.size ?? e.size
	}, l = new Map(t.bones.map((e, t) => [e.name, t])), u = c.size[1], d = c.rotation[1] * Math.PI / 180, f = [
		Math.sin(d),
		0,
		Math.cos(d)
	], p = r.values.stride ?? n.params?.find((e) => e.id === "stride")?.value ?? 1, m = r.inPlace ? 0 : (n.travel ?? 0) * u * p, h = a * o, g = (c.rotation[1] % 360 + 540) % 360 - 180, _ = r.mirror ? -1 : 1, v = _ > 0 ? g > 0 ? g - 360 : g : g < 0 ? g + 360 : g, y = Rc(t) ? null : qt(Ic.bones, t.bones), b = new Map(Ic.bones.map((e, t) => [e.name, t])), x = r.armsDown ?? 0, S = x ? Ui(t.bones) : null, C = S?.get("leftUpperArm") ?? (x ? l.get("Upper arm L") : void 0), w = S?.get("rightUpperArm") ?? (x ? l.get("Upper arm R") : void 0), T = Rc(t) ? null : Ui(t.bones), E = T && T.has("leftIndexProximal") ? T : null, D = [];
	for (let e = 0; e <= h; e++) {
		let i = e / h, o = i * a, s = Bc(n, o % 1, r), d = t.bones.map((e, t) => [
			0,
			0,
			0
		]);
		if (y) {
			let e = Ic.bones.map(() => [
				0,
				0,
				0
			]);
			for (let [t, n] of Object.entries(s.bones)) {
				let r = b.get(t);
				r !== void 0 && (e[r] = n.map((e) => Math.max(-360, Math.min(360, e))));
			}
			d = we(y, e, void 0).turns;
		} else for (let [e, t] of Object.entries(s.bones)) {
			let n = l.get(e);
			n !== void 0 && (d[n] = t.map((e) => Math.max(-360, Math.min(360, e))));
		}
		x && (C !== void 0 && (d[C] = [
			d[C][0],
			d[C][1],
			d[C][2] - x
		]), w !== void 0 && (d[w] = [
			d[w][0],
			d[w][1],
			d[w][2] + x
		])), E && Vc(d, E, s);
		let p = m * o;
		D.push({
			at: i,
			position: [
				c.position[0] + f[0] * p,
				c.position[1] + (s.lift ?? 0) * u,
				c.position[2] + f[2] * p
			],
			rotation: [
				c.rotation[0],
				s.spin === void 0 ? c.rotation[1] : v + (e === h ? 360 * _ : s.spin),
				c.rotation[2]
			],
			size: c.size,
			bones: d,
			ease: "linear"
		});
	}
	return D;
}
//#endregion
//#region ../scene3d/src/model/daylight.ts
var Kc = (e, t, n) => [
	e[0] + (t[0] - e[0]) * n,
	e[1] + (t[1] - e[1]) * n,
	e[2] + (t[2] - e[2]) * n
], qc = (e) => "#" + e.map((e) => Math.round(Math.min(1, Math.max(0, e)) * 255).toString(16).padStart(2, "0")).join("");
function Jc(e, t = {}) {
	let n = t.from ?? 480, r = t.to ?? 1080, i = Math.min(1, Math.max(0, (e - n) / Math.max(1, r - n))), a = Math.sin(i * Math.PI), o = Math.min(1, Math.max(0, (i - .55) / .45));
	o = o * o * (3 - 2 * o);
	let s = Math.min(1, Math.max(0, (.3 - i) / .3)), c = 36 + 26 * a, l = (t.noon ?? 52) - (i - .5) * 126, u = l * Math.PI / 180, d = c * Math.PI / 180, f = Kc(Kc([
		1,
		.92,
		.82
	], [
		1,
		.87,
		.74
	], s), [
		1,
		.7,
		.54
	], o), p = Kc(Kc([
		.7,
		.8,
		.9
	], [
		.8,
		.83,
		.86
	], s), [
		.98,
		.76,
		.7
	], o), m = Kc([
		.32,
		.53,
		.86
	], [
		.42,
		.46,
		.74
	], o);
	return {
		azimuth: Math.round((l + 540) % 360 - 180),
		elevation: Math.round(c * 10) / 10,
		direction: [
			Math.sin(u) * Math.cos(d),
			Math.sin(d),
			Math.cos(u) * Math.cos(d)
		],
		sunColor: qc(f),
		intensity: Math.round((1.4 - .12 * o) * 100) / 100,
		ambient: Math.round((.35 + .04 * o) * 100) / 100,
		skyLow: qc(p),
		skyHigh: qc(m),
		warmth: Math.max(o, s * .4)
	};
}
function Yc(e, t, n) {
	let r = Jc(t, n);
	return {
		...e,
		light: {
			...e.light,
			azimuth: r.azimuth,
			elevation: r.elevation,
			color: r.sunColor,
			intensity: r.intensity,
			ambient: r.ambient
		},
		background: {
			...e.background,
			transparent: !1,
			color: r.skyLow
		}
	};
}
var Xc = (e) => {
	let t = parseInt(e.slice(1), 16);
	return [
		(t >> 16) / 255,
		(t >> 8 & 255) / 255,
		(t & 255) / 255
	];
};
function Zc(e, t) {
	let n = Math.sin(e * 127.1 + t * 311.7) * 43758.5453;
	return n - Math.floor(n);
}
function Qc(e, t) {
	let n = Math.floor(e), r = Math.floor(t), i = e - n, a = t - r;
	i = i * i * (3 - 2 * i), a = a * a * (3 - 2 * a);
	let o = Zc(n, r), s = Zc(n + 1, r), c = Zc(n, r + 1), l = Zc(n + 1, r + 1);
	return o + (s - o) * i + (c - o) * a + (o - s - c + l) * i * a;
}
function $c(e, t) {
	let n = 0, r = .5;
	for (let i = 0; i < 5; i++) n += r * Qc(e, t), e = e * 2.03 + 17.3, t = t * 2.03 + 9.1, r *= .5;
	return n;
}
function el(e, t = 512, n = 256, r = 0) {
	let i = new Uint8Array(t * n * 4), a = Xc(e.skyLow), o = Xc(e.skyHigh), s = Xc(e.sunColor);
	for (let c = 0; c < n; c++) for (let l = 0; l < t; l++) {
		let u = 1 - c / (n - 1), d = Math.min(1, u / .7), f = Kc(a, o, d * d * (3 - 2 * d)), p = Math.abs(l / (t - 1) - .5) * 2, m = Math.max(0, 1 - Math.hypot(p * 1.4, u - e.elevation / 90)) ** 6 * (.12 + .2 * e.warmth) * (1 - u * .6);
		if (f = [
			f[0] + s[0] * m,
			f[1] + s[1] * m,
			f[2] + s[2] * m
		], u > .02) {
			let n = (l / t - .5) / (u + .18) * 3 + r, i = 1 / (u + .18) * 1.5, o = $c(n, i), c = Math.min(1, Math.max(0, (o - .46) / .26)), d = c * c * (3 - 2 * c) * Math.min(1, u / .06), p = Math.min(1, Math.max(0, .6 + (o - $c(n + .08, i)) * 5)), m = Kc(Kc(a, [
				.72,
				.74,
				.8
			], .5), Kc([
				1,
				.99,
				.97
			], [
				s[0],
				s[1],
				s[2]
			], .3 + .3 * e.warmth), p);
			f = Kc(f, m, d * .9);
		}
		let h = (c * t + l) * 4;
		i[h] = Math.round(Math.min(1, f[0]) * 255), i[h + 1] = Math.round(Math.min(1, f[1]) * 255), i[h + 2] = Math.round(Math.min(1, f[2]) * 255), i[h + 3] = 255;
	}
	return i;
}
//#endregion
//#region ../scene3d/src/model/gamestory.ts
var tl = {
	start: 480,
	minutesPerSecond: 4 / 3
}, nl = 1.4, rl = .5, il = .25, al = (e) => {
	let t = Math.floor((e % 1440 + 1440) % 1440);
	return `${String(Math.floor(t / 60)).padStart(2, "0")}:${String(t % 60).padStart(2, "0")}`;
};
function ol(e) {
	let t = /^(\d{1,2})(?::(\d{2}))?$/.exec(e.trim());
	return !t || Number(t[1]) > 24 || Number(t[2] ?? 0) > 59 ? null : Math.min(1440, Number(t[1]) * 60 + Number(t[2] ?? 0));
}
var sl = (e) => e.flatMap((e) => [e, ...sl(e.children ?? [])]);
function cl(e, t) {
	let n = /* @__PURE__ */ new Set([
		...t.areas ?? [],
		...t.passable ?? [],
		...(t.actors ?? []).map((e) => e.shape)
	]), r = sl(e), i = r.filter((e) => !n.has(e.id) && !e.name.startsWith("spot:") && (!e.hidden || e.name.startsWith("wall") || e.name.startsWith("solid"))).map((e) => {
		let t = e.rotation[1] * Math.PI / 180, n = Math.abs(Math.cos(t)), r = Math.abs(Math.sin(t)), i = (n * e.size[0] + r * e.size[2]) / 2, a = (r * e.size[0] + n * e.size[2]) / 2;
		return {
			x0: e.position[0] - i,
			x1: e.position[0] + i,
			z0: e.position[2] - a,
			z1: e.position[2] + a,
			y0: e.position[1] - e.size[1] / 2,
			y1: e.position[1] + e.size[1] / 2
		};
	}).filter((e) => e.y0 < 1.6 && e.y1 > .2), a = [...r.map((e) => e.position[0]), ...i.flatMap((e) => [e.x0, e.x1])], o = [...r.map((e) => e.position[2]), ...i.flatMap((e) => [e.z0, e.z1])], s = (a.length ? Math.min(...a) : 0) - 2, c = (o.length ? Math.min(...o) : 0) - 2, l = Math.ceil(((a.length ? Math.max(...a) : 0) + 2 - s) / rl), u = Math.ceil(((o.length ? Math.max(...o) : 0) + 2 - c) / rl), d = new Uint8Array(l * u);
	for (let e of i) {
		let t = Math.max(0, Math.floor((e.x0 - il - s) / rl)), n = Math.min(l - 1, Math.floor((e.x1 + il - s) / rl)), r = Math.max(0, Math.floor((e.z0 - il - c) / rl)), i = Math.min(u - 1, Math.floor((e.z1 + il - c) / rl));
		for (let e = r; e <= i; e++) for (let r = t; r <= n; r++) d[e * l + r] = 1;
	}
	return {
		x0: s,
		z0: c,
		width: l,
		height: u,
		blocked: d
	};
}
function ll(e, t, n) {
	let r = (t, n) => {
		let r = Math.floor((t - e.x0) / rl), i = Math.floor((n - e.z0) / rl);
		return r < 0 || i < 0 || r >= e.width || i >= e.height ? -1 : i * e.width + r;
	}, i = (t, n) => {
		for (let i = 0; i <= 4; i++) for (let a = -i; a <= i; a++) for (let o = -i; o <= i; o++) {
			let i = r(t + a * rl, n + o * rl);
			if (i >= 0 && !e.blocked[i]) return i;
		}
		return -1;
	}, a = i(t[0], t[2]), o = i(n[0], n[2]);
	if (a < 0 || o < 0) return null;
	let s = new Int32Array(e.width * e.height).fill(-1);
	s[a] = a;
	let c = [a];
	for (let t = 0; t < c.length && s[o] < 0; t++) {
		let n = c[t], r = n % e.width;
		for (let t of [
			r > 0 ? n - 1 : -1,
			r < e.width - 1 ? n + 1 : -1,
			n - e.width,
			n + e.width
		]) t >= 0 && t < e.blocked.length && !e.blocked[t] && s[t] < 0 && (s[t] = n, c.push(t));
	}
	if (s[o] < 0) return null;
	let l = [];
	for (let e = o; l.unshift(e), e !== a; e = s[e]);
	let u = (n) => [
		e.x0 + (n % e.width + .5) * rl,
		t[1],
		e.z0 + (Math.floor(n / e.width) + .5) * rl
	], d = [];
	return l.forEach((e, t) => {
		let n = l[t - 1], r = l[t + 1];
		(r === void 0 || n === void 0 || r - e !== e - n) && d.push(u(e));
	}), d.push([
		n[0],
		t[1],
		n[2]
	]), d;
}
var ul = (e, t) => {
	let n = e, r = 0;
	for (let e of t) r += Math.hypot(e[0] - n[0], e[2] - n[2]), n = e;
	return r;
}, dl = (e, t, n = 0) => e?.find((e) => t >= e.from && t < e.to && (e.days ?? 31) >> n & 1);
function fl(e, t) {
	let n = [], r = sl(e), i = new Map(r.map((e) => [e.id, e])), a = (e) => (i.get(e)?.name ?? "someone").replace(/^spot:/, ""), o = t.clock?.minutesPerSecond ?? tl.minutesPerSecond, s = cl(e, t), c = (t.actors ?? []).filter((e) => e.routine?.length);
	for (let e of c) {
		let t = a(e.shape), r = [...e.routine].sort((e, t) => e.from - t.from);
		r.forEach((c, l) => {
			let u = i.get(c.spot);
			if (!u) {
				n.push({
					kind: "routine",
					message: `${t} goes somewhere that's no longer in this level at ${al(c.from)}.`
				});
				return;
			}
			c.to <= c.from && n.push({
				kind: "routine",
				message: `${t}'s ${al(c.from)} block ends before it starts.`
			});
			let d = r[l - 1], f = d ? i.get(d.spot)?.position : i.get(e.shape)?.position;
			if (!f) return;
			let p = ll(s, f, u.position);
			if (!p) {
				n.push({
					kind: "routine",
					message: `${t} can't walk to ${a(c.spot)}: there's no way through.`
				});
				return;
			}
			let m = ul(f, p) / nl;
			m > (c.to - c.from) / o * .9 && n.push({
				kind: "routine",
				message: `${t} needs ${Math.ceil(m * o)} minutes to reach ${a(c.spot)} at ${al(c.from)}, and the block is only ${c.to - c.from}.`
			});
		});
	}
	for (let e = 0; e < c.length; e++) for (let t = e + 1; t < c.length; t++) for (let r of c[e].routine) for (let i of c[t].routine) r.spot === i.spot && r.from < i.to && i.from < r.to && (r.days ?? 31) & (i.days ?? 31) && n.push({
		kind: "routine",
		message: `${a(c[e].shape)} and ${a(c[t].shape)} stand on ${a(r.spot)} together from ${al(Math.max(r.from, i.from))}: give one another spot.`
	});
	return n;
}
var pl = (e, t) => `quest ${e} ${t + 1}`;
function ml(e) {
	return e.steps.map((t, n) => ({
		id: `quest-${e.id}-${n + 1}`,
		on: t.kind === "go" ? "enter" : "use",
		shape: t.shape,
		...n ? { if: [pl(e.id, n - 1)] } : {},
		unless: [pl(e.id, n)],
		once: !0,
		actions: [
			...t.lines.length ? t.lines.map((e, n) => ({
				kind: "say",
				lines: [e],
				...t.voices?.[n] ? { voice: t.voices[n] } : {}
			})) : [],
			{
				kind: "set",
				flag: pl(e.id, n)
			},
			...t.gives ? [{
				kind: "give",
				item: t.gives
			}] : [],
			...n === e.steps.length - 1 ? [{
				kind: "title",
				text: `Finished: ${e.title}`,
				seconds: 3
			}] : []
		]
	}));
}
var hl = (e) => e.quests?.length ? {
	...e,
	rules: [...e.rules, ...e.quests.flatMap(ml)]
} : e;
function gl(e, t) {
	return (e ?? []).flatMap((e) => {
		let n = e.steps.findIndex((n, r) => !t.has(pl(e.id, r)));
		return n < 0 ? [] : [{
			quest: e.title,
			hint: e.steps[n].hint
		}];
	});
}
function _l(e, t) {
	let n = [], r = new Set(sl(e).map((e) => e.id)), i = /* @__PURE__ */ new Set();
	for (let e of t.quests ?? []) i.has(e.id) && n.push({
		kind: "quest",
		message: `Two quests share the id ${e.id}.`
	}), i.add(e.id), e.steps.length || n.push({
		kind: "quest",
		message: `${e.title} has no steps yet.`
	}), e.steps.forEach((i, a) => {
		let o = `${e.title}, step ${a + 1}`;
		r.has(i.shape) ? i.kind === "go" && !t.areas?.includes(i.shape) && n.push({
			kind: "quest",
			message: `${o}: walking into it needs it to be a Trigger area.`
		}) : n.push({
			kind: "quest",
			message: `${o}: its shape is no longer in this level.`
		}), i.hint.trim() || n.push({
			kind: "quest",
			message: `${o} has no hint, so players won't know what to do.`
		}), i.ja && i.ja.length !== i.lines.length && n.push({
			kind: "quest",
			message: `${o}: ${i.lines.length} lines but ${i.ja.length} in Japanese.`
		});
	});
	return n;
}
var vl = (e) => e.steps.reduce((e, t) => e + t.seconds, 0);
function yl(e, t, n) {
	let r = (e) => t.find((t) => t.id === e), i = r(e.steps[0]?.shot ?? "");
	if (!i) return null;
	let a = 0;
	for (let t of e.steps) {
		let o = r(t.shot);
		if (!o) return null;
		let s = a + t.seconds;
		if (n < s || t === e.steps.at(-1)) {
			let e = t.cut || t.seconds <= 0 ? 1 : Math.min(1, Math.max(0, (n - a) / t.seconds)), r = e < .5 ? 2 * e * e : 1 - (-2 * e + 2) ** 2 / 2, s = (e, t) => [
				e[0] + (t[0] - e[0]) * r,
				e[1] + (t[1] - e[1]) * r,
				e[2] + (t[2] - e[2]) * r
			];
			return {
				position: s(i.position, o.position),
				target: s(i.target, o.target)
			};
		}
		i = o, a = s;
	}
	return null;
}
function bl(e) {
	let t = e.design.game, n = new Map(sl(e.design.shapes).map((e) => [e.id, e])), r = (e) => (n.get(e)?.name ?? e).replace(/^spot:/, "");
	return {
		level: e.id,
		clock: t?.clock ?? tl,
		routines: (t?.actors ?? []).filter((e) => e.routine?.length).map((e) => ({
			who: r(e.shape),
			character: e.character,
			blocks: e.routine.map((e) => ({
				...e,
				spot: r(e.spot)
			}))
		})),
		shots: t?.shots ?? [],
		films: (t?.films ?? []).map((e) => ({
			...e,
			seconds: vl(e),
			steps: e.steps.map((e) => ({
				...e,
				...t?.shots?.find((t) => t.id === e.shot) ?? {}
			}))
		})),
		idle: (t?.actors ?? []).filter((e) => e.idle).map((e) => ({
			who: r(e.shape),
			character: e.character,
			...e.idle
		})),
		daylight: Array.from({ length: 21 }, (e, t) => ({
			minute: 480 + t * 30,
			...Jc(480 + t * 30)
		})),
		quests: (t?.quests ?? []).map((e) => ({
			...e,
			steps: e.steps.map((e) => ({
				...e,
				shape: r(e.shape)
			}))
		}))
	};
}
//#endregion
//#region ../scene3d/src/model/romance.ts
var xl = ["all", "mature"], Sl = {
	all: "All ages",
	mature: "Mature (adults only)"
}, Cl = [
	"background",
	"portrait",
	"cg"
], wl = {
	background: "Background",
	portrait: "Portrait",
	cg: "Illustration (CG)"
}, Tl = [
	"left",
	"centre",
	"right"
], El = [
	"true",
	"good",
	"normal",
	"bad"
], Dl = 8e6, Ol = "Made with Gleamshelf: open this game in Gleamshelf and make your own.", U = (e) => e && typeof e == "object" && !Array.isArray(e) ? e : {}, kl = (e, t) => Array.isArray(e) ? e.slice(0, t) : [], W = (e) => typeof e == "string" && /^[\w-]{1,40}$/.test(e) ? e : void 0, Al = (e, t) => typeof e == "string" && e.trim() ? e.trim().slice(0, t) : void 0, jl = (e, t, n) => typeof e == "number" && Number.isFinite(e) ? Math.round(Math.min(n, Math.max(t, e))) : void 0, Ml = (e, t, n) => t.includes(e) ? e : n, Nl = (e, t, n) => {
	let r = Al(t, n);
	return r ? { [e]: r } : {};
};
function Pl(e) {
	let t = U(e);
	if (t.kind === "affection" && W(t.heroine)) return {
		kind: "affection",
		heroine: t.heroine,
		atLeast: jl(t.atLeast, -999, 999) ?? 0
	};
	if (t.kind === "flag" && Al(t.flag, 40)) return {
		kind: "flag",
		flag: Al(t.flag, 40),
		is: t.is !== !1
	};
	if (t.kind === "route" && W(t.heroine)) return {
		kind: "route",
		heroine: t.heroine
	};
}
function Fl(e) {
	let t = U(e), n = Al(t.text, 1e3);
	return n ? {
		who: t.who === "me" ? "me" : W(t.who) ?? "",
		text: n,
		...Nl("textJa", t.textJa, 1e3),
		...W(t.face) ? { face: t.face } : {},
		...t.cg === null ? { cg: null } : W(t.cg) ? { cg: t.cg } : {},
		...W(t.voice) ? { voice: t.voice } : {},
		...t.rating === "mature" ? { rating: "mature" } : {}
	} : null;
}
var Il = (e) => kl(e, 400).flatMap((e) => Fl(e) ?? []);
function Ll(e) {
	let t = U(e);
	if (t.kind === "choose") {
		let e = kl(t.choices, 6).flatMap((e) => {
			let t = U(e), n = Al(t.text, 200), r = W(t.go);
			if (!n || !r) return [];
			let i = {};
			for (let [e, n] of Object.entries(U(t.affection))) {
				let t = jl(n, -100, 100);
				W(e) && t && (i[e] = t);
			}
			let a = kl(t.set, 8).flatMap((e) => Al(e, 40) ?? []), o = Pl(t.when);
			return [{
				text: n,
				...Nl("textJa", t.textJa, 200),
				...Object.keys(i).length ? { affection: i } : {},
				...a.length ? { set: a } : {},
				...o ? { when: o } : {},
				go: r
			}];
		});
		if (e.length) return {
			kind: "choose",
			choices: e
		};
	}
	return t.kind === "branch" && W(t.else) ? {
		kind: "branch",
		ways: kl(t.ways, 12).flatMap((e) => {
			let t = U(e), n = Pl(t.if);
			return n && W(t.go) ? [{
				if: n,
				go: t.go
			}] : [];
		}),
		else: t.else
	} : t.kind === "end" && W(t.ending) ? {
		kind: "end",
		ending: t.ending
	} : t.kind === "return" ? { kind: "return" } : t.kind === "go" && W(t.go) ? {
		kind: "go",
		go: t.go
	} : {
		kind: "end",
		ending: "the-end"
	};
}
function Rl(e) {
	let t = U(e), n = (e) => {
		let t = /* @__PURE__ */ new Set();
		return e.filter((e) => !t.has(e.id) && !!t.add(e.id));
	}, r = n(kl(t.heroines, 12).flatMap((e) => {
		let t = U(e), n = W(t.id);
		if (!n || n === "me") return [];
		let r = {};
		for (let [e, n] of Object.entries(U(t.faces))) W(e) && W(n) && (r[e] = n);
		let i = jl(t.age, 0, 999);
		return [{
			id: n,
			name: Al(t.name, 40) ?? n,
			...Nl("nameJa", t.nameJa, 40),
			...i === void 0 ? {} : { age: i },
			colour: typeof t.colour == "string" && /^#[0-9a-f]{6}$/i.test(t.colour) ? t.colour.toLowerCase() : "#d98aa4",
			...Nl("profile", t.profile, 400),
			...Nl("profileJa", t.profileJa, 400),
			faces: r,
			routeAt: jl(t.routeAt, 0, 999) ?? 30,
			...t.side === !0 ? { side: !0 } : {},
			...W(t.character) ? { character: t.character } : {}
		}];
	})), i = n(kl(t.pictures, 400).flatMap((e) => {
		let t = U(e), n = W(t.id);
		return !n || typeof t.data != "string" || t.data.length > 8e6 || !/^data:image\/(png|jpeg|webp);base64,/.test(t.data) ? [] : [{
			id: n,
			name: Al(t.name, 60) ?? n,
			kind: Ml(t.kind, Cl, "cg"),
			data: t.data,
			rating: Ml(t.rating, xl, "all"),
			...W(t.heroine) ? { heroine: t.heroine } : {}
		}];
	})), a = n(kl(t.scenes, 600).flatMap((e) => {
		let t = U(e), n = W(t.id);
		if (!n) return [];
		let r = kl(t.stage, 3).flatMap((e) => {
			let t = U(e);
			return W(t.heroine) ? [{
				heroine: t.heroine,
				at: Ml(t.at, Tl, "centre")
			}] : [];
		}), i = Il(t.safe);
		return [{
			id: n,
			title: Al(t.title, 60) ?? n,
			...W(t.background) ? { background: t.background } : {},
			...W(t.music) ? { music: t.music } : {},
			stage: r,
			lines: Il(t.lines),
			...t.rating === "mature" ? { rating: "mature" } : {},
			...i.length ? { safe: i } : {},
			...t.entry === !0 ? { entry: !0 } : {},
			next: Ll(t.next)
		}];
	}));
	if (!a.length) return;
	let o = n(kl(t.endings, 64).flatMap((e) => {
		let t = U(e), n = W(t.id);
		return n ? [{
			id: n,
			title: Al(t.title, 60) ?? n,
			...Nl("titleJa", t.titleJa, 60),
			...W(t.heroine) ? { heroine: t.heroine } : {},
			kind: Ml(t.kind, El, "normal"),
			...W(t.cg) ? { cg: t.cg } : {},
			...W(t.achievement) ? { achievement: t.achievement } : {}
		}] : [];
	}));
	return {
		start: W(t.start) && a.some((e) => e.id === t.start) ? t.start : a[0].id,
		heroines: r,
		pictures: i,
		scenes: a,
		endings: o,
		madeWith: Al(t.madeWith, 200) ?? "Made with Gleamshelf: open this game in Gleamshelf and make your own."
	};
}
function zl(e, t) {
	if (t === "mature") return e;
	let n = e.pictures.filter((e) => e.rating === "all"), r = new Set(n.map((e) => e.id)), i = (e) => e && r.has(e) ? e : void 0, a = (e) => {
		if (e.cg === void 0 || e.cg === null || r.has(e.cg)) return e;
		let { cg: t, ...n } = e;
		return n;
	}, o = (e) => e.filter((e) => e.rating !== "mature").map(a);
	return {
		...e,
		pictures: n,
		heroines: e.heroines.map((e) => ({
			...e,
			faces: Object.fromEntries(Object.entries(e.faces).filter(([, e]) => r.has(e)))
		})),
		scenes: e.scenes.map((e) => {
			let { rating: t, safe: n, background: r, ...a } = e, s = i(r);
			return {
				...a,
				...s ? { background: s } : {},
				lines: e.rating === "mature" ? o(n ?? []) : o(e.lines)
			};
		}),
		endings: e.endings.map((e) => {
			let { cg: t, ...n } = e, r = i(t);
			return {
				...n,
				...r ? { cg: r } : {}
			};
		})
	};
}
var Bl = (e) => e.pictures.some((e) => e.rating === "mature") || e.scenes.some((e) => e.rating === "mature" || e.lines.some((e) => e.rating === "mature"));
function Vl(e, t, n, r) {
	if (t.kind === "flag") return r.includes(t.flag) === t.is;
	let i = n[t.heroine] ?? 0;
	if (t.kind === "affection") return i >= t.atLeast;
	let a = e.heroines.find((e) => e.id === t.heroine && !e.side);
	return !a || i < a.routeAt ? !1 : e.heroines.every((e) => e.id === a.id || e.side || (n[e.id] ?? 0) < i);
}
var Hl = class e {
	story;
	state;
	seen = /* @__PURE__ */ new Set();
	endings = /* @__PURE__ */ new Set();
	earned = [];
	constructor(e, t) {
		this.story = e, this.state = t ?? {
			scene: e.start,
			line: 0,
			affection: Object.fromEntries(e.heroines.map((e) => [e.id, 0])),
			flags: [],
			faces: {},
			stage: [],
			cg: null,
			ending: null
		}, t || this.enter(e.start);
	}
	static load(t, n) {
		let r = JSON.parse(n);
		if (!t.scenes.some((e) => e.id === r.scene)) throw Error("That save is from another version of the story.");
		return new e(t, r);
	}
	save = () => JSON.stringify(this.state);
	play(e) {
		this.state = {
			...this.state,
			ending: null,
			returned: !1
		}, this.enter(e);
	}
	scene = (e = this.state.scene) => this.story.scenes.find((t) => t.id === e);
	enter(e, t = 0) {
		let n = this.scene(e);
		!n || t > 64 ? this.state = {
			...this.state,
			ending: this.state.ending ?? "the-end"
		} : (this.state = {
			...this.state,
			scene: e,
			line: 0,
			stage: n.stage,
			cg: null
		}, this.showLine(), n.lines.length || this.finish(t));
	}
	showLine() {
		let e = this.scene().lines[this.state.line];
		e && (e.face && e.who !== "" && e.who !== "me" && (this.state.faces = {
			...this.state.faces,
			[e.who]: e.face
		}), e.cg !== void 0 && (this.state.cg = e.cg), this.state.cg && this.seen.add(this.state.cg));
	}
	finish(e = 0) {
		let t = this.scene().next;
		if (t.kind === "go") this.enter(t.go, e + 1);
		else if (t.kind === "branch") {
			let n = t.ways.find((e) => Vl(this.story, e.if, this.state.affection, this.state.flags));
			this.enter(n?.go ?? t.else, e + 1);
		} else if (t.kind === "return") this.state = {
			...this.state,
			returned: !0
		};
		else if (t.kind === "end") {
			this.state = {
				...this.state,
				ending: t.ending
			}, this.endings.add(t.ending);
			let e = this.story.endings.find((e) => e.id === t.ending);
			e?.cg && this.seen.add(e.cg), e?.achievement && this.earned.push(e.achievement);
		}
	}
	waitingForChoice = () => {
		let e = this.scene();
		return !!e && !this.state.ending && this.state.line >= e.lines.length - 1 && e.next.kind === "choose";
	};
	next() {
		let e = this.scene();
		return !e || this.state.ending || this.state.returned || this.waitingForChoice() ? !1 : (this.state.line < e.lines.length - 1 ? (this.state = {
			...this.state,
			line: this.state.line + 1
		}, this.showLine()) : this.finish(), !0);
	}
	choices() {
		let e = this.scene();
		return !e || e.next.kind !== "choose" || !this.waitingForChoice() ? [] : e.next.choices.map((e, t) => ({
			index: t,
			choice: e
		})).filter(({ choice: e }) => !e.when || Vl(this.story, e.when, this.state.affection, this.state.flags));
	}
	choose(e) {
		let t = this.choices().find((t) => t.index === e)?.choice;
		if (!t) return !1;
		let n = { ...this.state.affection };
		for (let [e, r] of Object.entries(t.affection ?? {})) n[e] = (n[e] ?? 0) + r;
		let r = [.../* @__PURE__ */ new Set([...this.state.flags, ...t.set ?? []])];
		return this.state = {
			...this.state,
			affection: n,
			flags: r
		}, this.enter(t.go), !0;
	}
	takeAchievements() {
		return this.earned.splice(0);
	}
	view(e = !1) {
		let t = this.scene() ?? this.story.scenes[0], n = this.state.ending ? null : t.lines[this.state.line] ?? null, r = (e) => this.story.heroines.find((t) => t.id === e), i = (t) => {
			if (!t || t.who === "") return null;
			if (t.who === "me") return { name: e ? "僕" : "Me" };
			let n = r(t.who);
			return n ? {
				name: e && n.nameJa || n.name,
				colour: n.colour
			} : { name: t.who };
		}, a = this.choices(), o = this.state.ending ? this.story.endings.find((e) => e.id === this.state.ending) ?? null : null;
		return {
			scene: t,
			...t.background ? { background: t.background } : {},
			...t.music ? { music: t.music } : {},
			stage: this.state.stage.flatMap((e) => {
				let t = r(e.heroine);
				if (!t) return [];
				let i = this.state.faces[t.id] ?? "normal", a = t.faces[i] ?? t.faces.normal ?? Object.values(t.faces)[0];
				return [{
					heroine: t,
					at: e.at,
					...a ? { picture: a } : {},
					speaking: n?.who === t.id
				}];
			}),
			cg: this.state.cg ?? (o?.cg ? o.cg : null),
			line: n && e && n.textJa ? {
				...n,
				text: n.textJa
			} : n,
			speaker: i(n),
			choices: a.length ? a.map(({ index: t, choice: n }) => ({
				index: t,
				text: e && n.textJa || n.text
			})) : null,
			ending: o
		};
	}
}, Ul = (e) => [e.start, ...e.scenes.filter((t) => t.entry && t.id !== e.start).map((e) => e.id)], Wl = (e) => e.kind === "go" ? [e.go] : e.kind === "choose" ? e.choices.map((e) => e.go) : e.kind === "branch" ? [...e.ways.map((e) => e.go), e.else] : [];
function Gl(e, t = 2e5) {
	let n = Object.fromEntries(e.heroines.map((e) => [e.id, 0])), r = new Map(e.scenes.map((e) => [e.id, e])), i = 0, a = (o, s, c, l) => {
		if (++i > t || l.has(o)) return;
		let u = r.get(o);
		if (!u) return;
		for (let t of e.heroines) n[t.id] = Math.max(n[t.id], s[t.id] ?? 0);
		l.add(o);
		let d = u.next;
		if (d.kind === "go") a(d.go, s, c, l);
		else if (d.kind === "branch") {
			let t = d.ways.find((t) => Vl(e, t.if, s, c));
			a(t?.go ?? d.else, s, c, l);
		} else if (d.kind === "choose") for (let t of d.choices) {
			if (t.when && !Vl(e, t.when, s, c)) continue;
			let n = { ...s };
			for (let [e, r] of Object.entries(t.affection ?? {})) n[e] = (n[e] ?? 0) + r;
			a(t.go, n, [.../* @__PURE__ */ new Set([...c, ...t.set ?? []])], l);
		}
		l.delete(o);
	};
	for (let t of Ul(e)) a(t, Object.fromEntries(e.heroines.map((e) => [e.id, 0])), [], /* @__PURE__ */ new Set());
	return n;
}
function Kl(e, t = 2e5) {
	let n = /* @__PURE__ */ new Set(), r = new Map(e.scenes.map((e) => [e.id, e])), i = 0, a = !1, o = (s, c, l, u) => {
		if (++i > t || u.has(s)) return;
		let d = r.get(s);
		if (!d) return;
		u.add(s);
		let f = d.next;
		if (f.kind === "end") n.add(f.ending);
		else if (f.kind === "go") o(f.go, c, l, u);
		else if (f.kind === "branch") {
			if (a) for (let e of [...f.ways.map((e) => e.go), f.else]) o(e, c, l, u);
			else o(f.ways.find((t) => Vl(e, t.if, c, l))?.go ?? f.else, c, l, u);
		} else if (f.kind === "choose") for (let t of f.choices) {
			if (t.when && !Vl(e, t.when, c, l)) continue;
			let n = { ...c };
			for (let [e, r] of Object.entries(t.affection ?? {})) n[e] = (n[e] ?? 0) + r;
			o(t.go, n, [.../* @__PURE__ */ new Set([...l, ...t.set ?? []])], u);
		}
		u.delete(s);
	};
	for (let t of Ul(e)) a = t !== e.start, o(t, Object.fromEntries(e.heroines.map((e) => [e.id, 0])), [], /* @__PURE__ */ new Set());
	return n;
}
function ql(e) {
	let t = [], n = new Set(e.scenes.map((e) => e.id)), r = new Map(e.pictures.map((e) => [e.id, e])), i = new Map(e.heroines.map((e) => [e.id, e])), a = new Set(e.endings.map((e) => e.id));
	if (Bl(e)) {
		let n = /* @__PURE__ */ new Set();
		for (let t of e.scenes) {
			let e = t.rating === "mature";
			e && t.stage.forEach((e) => n.add(e.heroine));
			for (let r of t.lines) (e || r.rating === "mature") && i.has(r.who) && n.add(r.who);
		}
		for (let t of e.pictures) t.rating === "mature" && t.heroine && n.add(t.heroine);
		e.pictures.some((e) => e.rating === "mature" && !e.heroine) && e.heroines.forEach((e) => n.add(e.id));
		for (let e of n) {
			let n = i.get(e);
			n && (n.age === void 0 || n.age < 18) && t.push({
				level: "error",
				text: `${n.name} is in mature content but ${n.age === void 0 ? "has no age stated" : `is stated as ${n.age}`}: every character in it must be 18 or older. The mature export will refuse.`
			});
		}
	}
	for (let o of e.scenes) {
		for (let e of Wl(o.next)) n.has(e) || t.push({
			level: "error",
			scene: o.id,
			text: `${o.title} goes to a scene that isn't there (${e}).`
		});
		o.next.kind === "end" && !a.has(o.next.ending) && t.push({
			level: "warning",
			scene: o.id,
			text: `${o.title} ends with ${o.next.ending}, which isn't in the endings list.`
		}), o.background && !r.has(o.background) && t.push({
			level: "warning",
			scene: o.id,
			text: `${o.title}'s background is missing (${o.background}).`
		});
		for (let e of o.stage) i.has(e.heroine) || t.push({
			level: "error",
			scene: o.id,
			text: `${o.title} puts ${e.heroine} on stage, who isn't a heroine.`
		});
		for (let e of [...o.lines, ...o.safe ?? []]) e.who !== "" && e.who !== "me" && !i.has(e.who) && t.push({
			level: "error",
			scene: o.id,
			text: `${o.title}: a line is said by ${e.who}, who isn't a heroine.`
		}), e.cg && !r.has(e.cg) && t.push({
			level: "warning",
			scene: o.id,
			text: `${o.title} shows a picture that's missing (${e.cg}).`
		});
		o.rating === "mature" && !o.safe?.length && t.push({
			level: "warning",
			scene: o.id,
			text: `${o.title} is mature with no all-ages lines: the all-ages game skips straight past it.`
		}), !o.lines.length && o.rating !== "mature" && o.next.kind !== "branch" && t.push({
			level: "warning",
			scene: o.id,
			text: `${o.title} has no lines.`
		});
	}
	let o = /* @__PURE__ */ new Set(), s = Ul(e);
	for (; s.length;) {
		let t = s.pop();
		if (o.has(t)) continue;
		o.add(t);
		let n = e.scenes.find((e) => e.id === t);
		n && s.push(...Wl(n.next));
	}
	for (let n of e.scenes) o.has(n.id) || t.push({
		level: "warning",
		scene: n.id,
		text: `Nothing leads to ${n.title}.`
	});
	let c = Kl(e);
	for (let n of e.endings) c.has(n.id) || t.push({
		level: "warning",
		text: `No way of playing reaches the ending ${n.title}.`
	});
	let l = Gl(e), u = e.scenes.some((e) => e.entry);
	for (let n of e.heroines) !u && !n.side && (l[n.id] ?? 0) < n.routeAt && t.push({
		level: "warning",
		text: `${n.name}'s route opens at ${n.routeAt} affection, but the most any choices give her is ${l[n.id] ?? 0}.`
	});
	let d = e.scenes.reduce((e, t) => e + t.lines.filter((e) => !e.textJa).length, 0);
	return d && t.push({
		level: "warning",
		text: `${d} line${d === 1 ? "" : "s"} have no Japanese yet.`
	}), t.sort((e, t) => e.level === t.level ? 0 : e.level === "error" ? -1 : 1);
}
function Jl(e, t) {
	return ql(t === "mature" ? e : zl(e, "all")).filter((e) => e.level === "error").map((e) => e.text);
}
var Yl = {
	png: "png",
	jpeg: "jpg",
	webp: "webp"
};
function Xl(e) {
	if (typeof Buffer < "u") return new Uint8Array(Buffer.from(e, "base64"));
	let t = atob(e), n = new Uint8Array(t.length);
	for (let e = 0; e < t.length; e++) n[e] = t.charCodeAt(e);
	return n;
}
function Zl(e, t, n) {
	let r = Jl(e, t);
	if (r.length) throw Error(r.join("\n"));
	let i = zl(e, t), a = [], o = i.pictures.map(({ data: e, ...t }) => {
		let n = /^data:image\/(\w+);base64,(.*)$/s.exec(e), r = `pictures/${t.id}.${Yl[n[1]] ?? "png"}`;
		return a.push({
			path: r,
			bytes: Xl(n[2])
		}), {
			...t,
			file: r
		};
	}), s = {
		kind: "gleamshelf-romance",
		version: 1,
		title: n,
		rating: t,
		...i,
		pictures: o
	};
	return a.unshift({
		path: "romance.json",
		bytes: new TextEncoder().encode(JSON.stringify(s, null, 1) + "\n")
	}), a;
}
var Ql = 8e6, $l = (e) => typeof e == "string" && /^[\w-]{1,40}$/.test(e) ? e : void 0, eu = (e, t) => typeof e == "string" && e.trim() ? e.trim().slice(0, 60) : t, tu = (e) => !!e && typeof e == "object" && e.kind === "gleamshelf-game" && Array.isArray(e.levels);
function nu(e) {
	let t = (e) => {
		let t = e && typeof e == "object" ? e : {};
		return t.kind === "mesh" ? {
			slots: 0,
			fields: 0,
			meshes: 1
		} : {
			slots: 1,
			fields: +!!t.outline,
			meshes: 0
		};
	}, n = e && typeof e == "object" ? e : {};
	if (n.kind !== "group") return t(e);
	let r = {
		slots: 2,
		fields: 0,
		meshes: 0
	};
	for (let e of Array.isArray(n.children) ? n.children : []) {
		let n = t(e);
		r.slots += n.slots, r.fields += n.fields, r.meshes += n.meshes;
	}
	return r;
}
function ru(e) {
	let t = e && typeof e == "object" ? e : {}, n = Array.isArray(t.shapes) ? t.shapes : null;
	if (!n) return [P(e)];
	let r = [[]], i = {
		slots: 0,
		fields: 0,
		meshes: 0
	};
	for (let e of n) {
		let t = nu(e);
		!(i.slots + t.slots <= 256 && i.fields + t.fields <= 16 && i.meshes + t.meshes <= 16) && r.at(-1).length && (r.push([]), i = {
			slots: 0,
			fields: 0,
			meshes: 0
		}), r.at(-1).push(e), i = {
			slots: i.slots + t.slots,
			fields: i.fields + t.fields,
			meshes: i.meshes + t.meshes
		};
	}
	return r.map((e, n) => P(n === 0 ? {
		...t,
		shapes: e
	} : {
		...t,
		shapes: e,
		game: void 0,
		takes: void 0,
		cameraTake: void 0,
		music: void 0
	}));
}
function iu(e, t, n, r = !1) {
	let i = /* @__PURE__ */ new Set(), a = [], o = (e) => {
		for (; i.has(e);) e = `${e}x`;
		return i.add(e), e;
	};
	return (Array.isArray(e) ? e : []).forEach((e, i) => {
		let s = e && typeof e == "object" ? e : {}, c = o($l(s.id) ?? `${n}${i + 1}`), l = eu(s.name, `${n[0].toUpperCase()}${n.slice(1)} ${i + 1}`), u = $l(s.partOf);
		(r ? ru(s.design) : [P(s.design)]).forEach((e, n) => {
			a.length >= t || (n === 0 ? a.push({
				id: c,
				name: l,
				design: e,
				...u ? { partOf: u } : {}
			}) : a.push({
				id: o(`${c}-part${n + 1}`),
				name: `${l} (part ${n + 1})`.slice(0, 60),
				design: e,
				partOf: u ?? c
			}));
		});
	}), a.filter((e) => !e.partOf || a.some((t) => t.id === e.partOf && !t.partOf));
}
function au(e) {
	let t = e && typeof e == "object" ? e : {}, n = iu(t.levels, 64, "level", !0);
	n.length || (n = [{
		id: "level1",
		name: "Level 1",
		design: pe()
	}]);
	let r = iu(t.characters, 32, "character").map(({ partOf: e, ...t }) => t), i = {}, a = t.sounds && typeof t.sounds == "object" ? t.sounds : {};
	for (let [e, t] of Object.entries(a).slice(0, 64)) {
		let n = t && typeof t == "object" ? t : {};
		!$l(e) || typeof n.data != "string" || n.data.length > 8e6 || !/^data:audio\/[\w.+-]+;base64,/.test(n.data) || (i[e] = {
			name: eu(n.name, e),
			data: n.data
		});
	}
	let o = $l(t.start) && n.some((e) => e.id === t.start) ? t.start : n[0].id, s = typeof t.credits == "string" && t.credits.trim() ? t.credits.slice(0, 4e3) : void 0, c = su(t.achievements), l = Rl(t.romance);
	return {
		kind: "gleamshelf-game",
		version: 1,
		title: eu(t.title, "My game"),
		start: o,
		levels: n,
		characters: r,
		sounds: i,
		...s ? { credits: s } : {},
		...c.length ? { achievements: c } : {},
		...l ? { romance: l } : {}
	};
}
var ou = (e, t) => typeof e == "string" && e.trim() ? e.trim().slice(0, t) : void 0;
function su(e) {
	let t = /* @__PURE__ */ new Set();
	return (Array.isArray(e) ? e : []).slice(0, 100).flatMap((e) => {
		let n = e && typeof e == "object" ? e : {}, r = $l(n.id), i = ou(n.title, 60);
		if (!r || !i || t.has(r)) return [];
		t.add(r);
		let a = typeof n.points == "number" && Number.isFinite(n.points) ? Math.round(Math.min(100, Math.max(0, n.points))) : void 0, o = ou(n.titleJa, 60), s = ou(n.howJa, 200);
		return [{
			id: r,
			title: i,
			how: ou(n.how, 200) ?? i,
			...o ? { titleJa: o } : {},
			...s ? { howJa: s } : {},
			...a === void 0 ? {} : { points: a },
			...n.hidden === !0 ? { hidden: !0 } : {}
		}];
	});
}
function cu(e, t = "My game") {
	return au({
		title: t,
		levels: [{
			id: "level1",
			name: "Level 1",
			design: e
		}],
		characters: []
	});
}
var lu = (e) => JSON.stringify(e) + "\n";
function uu(e) {
	let t;
	try {
		t = JSON.parse(e);
	} catch {
		throw Error("That file is not a game project (it is not JSON).");
	}
	if (!tu(t)) throw Error("That .json is not a game project (it has no levels).");
	return au(t);
}
function du(e) {
	let t = JSON.parse(e).levels ?? [];
	for (let e of t) {
		let t = xr(e.design);
		if (t) return `Level ${String(e.name ?? "")}: ${t}`;
	}
	return null;
}
function fu(e, t) {
	let n = t.toLowerCase().replace(/[^\w]+/g, "-").replace(/^-|-$/g, "").slice(0, 30) || "item", r = new Set([...e.levels, ...e.characters].map((e) => e.id)), i = n, a = 2;
	for (; r.has(i);) i = `${n}-${a++}`;
	return i;
}
function pu(e, t) {
	let n = c(t), { min: r, max: i } = g(n.parts), a = n.parts.reduce((e, t) => e + t.indices.length / 3, 0);
	return {
		name: e.slice(0, 60),
		data: l(t),
		triangles: a,
		size: [
			i[0] - r[0],
			i[1] - r[1],
			i[2] - r[2]
		],
		centre: [
			(r[0] + i[0]) / 2,
			(r[1] + i[1]) / 2,
			(r[2] + i[2]) / 2
		]
	};
}
function mu(e) {
	let t = 0, n = (e) => {
		e.hidden || (e.children ? e.children.forEach(n) : t = Math.max(t, e.position[1] + Math.max(...e.size) / 2));
	};
	return e.shapes.forEach(n), Math.max(.1, t);
}
function hu(e) {
	let t = e.design.shapes.filter((e) => !e.hidden), n = t.length === 1 ? t[0] : null;
	return n?.kind === "mesh" && n.asset && e.design.assets?.[n.asset] ? n : null;
}
async function gu(e, t = 96) {
	let n = hu(e);
	if (n) return {
		asset: e.design.assets[n.asset],
		height: n.size[1]
	};
	let r = mu(e.design), i = await sa(e.design, "glb", {
		heightMm: r * 1e3,
		cells: t
	});
	return {
		asset: pu(e.name, i),
		height: r
	};
}
function _u(e, t, n, r, i) {
	let a = Math.max(...n.size, 1e-9), o = n.size.map((e) => Math.max(.01, e / a * r));
	return A("mesh", 0, {
		id: je(),
		name: e.name,
		kind: "mesh",
		asset: t,
		ownColors: !0,
		size: o,
		position: [
			i[0],
			i[1] + o[1] / 2,
			i[2]
		]
	});
}
//#endregion
//#region ../scene3d/src/model/gamecheck.ts
var vu = (e) => {
	let t = e.rotation[1] * Math.PI / 180, n = Math.abs(Math.cos(t)), r = Math.abs(Math.sin(t)), i = (n * e.size[0] + r * e.size[2]) / 2, a = (r * e.size[0] + n * e.size[2]) / 2;
	return {
		x0: e.position[0] - i,
		x1: e.position[0] + i,
		y0: e.position[1] - e.size[1] / 2,
		y1: e.position[1] + e.size[1] / 2,
		z0: e.position[2] - a,
		z1: e.position[2] + a
	};
}, yu = (e) => {
	let t = e.levels.flatMap((e) => e.design.shapes.map((t) => ({
		level: e.name,
		s: t
	})));
	return {
		all: t,
		walls: t.filter(({ s: e }) => e.name.startsWith("wall") || e.name.startsWith("solid")).map(({ s: e }) => vu(e)).filter((e) => e.y0 < 1.6 && e.y1 > .2),
		spots: t.filter(({ s: e }) => e.name.startsWith("spot:")).map(({ level: e, s: t }) => ({
			level: e,
			id: t.id,
			name: t.name.slice(5),
			x: t.position[0],
			z: t.position[2]
		}))
	};
};
function bu(e, t = {}) {
	let { walls: n, spots: r } = yu(e), i = r.find((e) => e.name === t.start) ?? r[0];
	if (!i) return null;
	let a = t.cell ?? .5, o = .25, s = [...n.flatMap((e) => [e.x0, e.x1]), ...r.map((e) => e.x)], c = [...n.flatMap((e) => [e.z0, e.z1]), ...r.map((e) => e.z)], l = Math.min(...s) - 2, u = Math.min(...c) - 2, d = Math.ceil((Math.max(...s) + 2 - l) / a), f = Math.ceil((Math.max(...c) + 2 - u) / a), p = new Uint8Array(d * f);
	for (let e = 0; e < f; e++) for (let t = 0; t < d; t++) {
		let r = l + (t + .5) * a, i = u + (e + .5) * a;
		n.some((e) => r > e.x0 - o && r < e.x1 + o && i > e.z0 - o && i < e.z1 + o) && (p[e * d + t] = 1);
	}
	let m = (e, t) => {
		let n = Math.floor((e - l) / a), r = Math.floor((t - u) / a);
		return n < 0 || r < 0 || n >= d || r >= f ? -1 : r * d + n;
	}, h = (e, t) => {
		for (let n = 0; n <= 4; n++) for (let r = -n; r <= n; r++) for (let i = -n; i <= n; i++) {
			let n = m(e + r * a, t + i * a);
			if (n >= 0 && p[n] !== 1) return n;
		}
		return -1;
	}, g = h(i.x, i.z), _ = g >= 0 ? [g] : [];
	for (g >= 0 && (p[g] = 2); _.length;) {
		let e = _.pop(), t = e % d;
		for (let n of [
			t > 0 ? e - 1 : -1,
			t < d - 1 ? e + 1 : -1,
			e - d,
			e + d
		]) n >= 0 && n < p.length && p[n] === 0 && (p[n] = 2, _.push(n));
	}
	return {
		x0: l,
		z0: u,
		cell: a,
		width: d,
		height: f,
		cells: p,
		start: i.name,
		spots: r.map((e) => {
			let t = h(e.x, e.z);
			return {
				...e,
				reached: t >= 0 && p[t] === 2
			};
		})
	};
}
function xu(e, t = {}) {
	let n = [], { all: r, walls: i, spots: a } = yu(e), o = (e) => !e.hidden && !e.name.startsWith("spot:"), s = r.filter(({ s: e }) => e.kind === "box" && o(e) && e.size[1] < .3);
	for (let e = 0; e < s.length; e++) for (let t = e + 1; t < s.length; t++) {
		let r = vu(s[e].s), i = vu(s[t].s);
		if (Math.abs(r.y1 - i.y1) > .002) continue;
		let a = Math.min(r.x1, i.x1) - Math.max(r.x0, i.x0), o = Math.min(r.z1, i.z1) - Math.max(r.z0, i.z0);
		a > .01 && o > .01 && n.push({
			kind: "fighting",
			level: s[e].level,
			message: `${s[e].s.name} and ${s[t].s.name} share a surface at height ${r.y1.toFixed(2)}: they'll flicker. Lower one a little.`
		});
	}
	let c = /* @__PURE__ */ new Set();
	for (let e of a) c.has(e.name) && n.push({
		kind: "duplicate-spot",
		level: e.level,
		message: `There are two spots called ${e.name}: a game can only find one of them.`
	}), c.add(e.name), !t.placed?.includes(e.name) && i.some((t) => e.x > t.x0 && e.x < t.x1 && e.z > t.z0 && e.z < t.z1) && n.push({
		kind: "in-wall",
		level: e.level,
		message: `Spot ${e.name} is inside something solid: move it into the open.`
	});
	let l = i.length ? bu(e, t) : null, u = r.filter(({ s: e }) => e.kind === "box" && o(e)).map(({ s: e }) => vu(e));
	for (let e of l?.spots ?? []) e.reached || (t.placed?.includes(e.name) || n.push({
		kind: "unreachable",
		level: e.level,
		message: `Nobody can walk from ${l.start} to spot ${e.name}: there's no way through the walls.`
	}), u.some((t) => t.y0 > 1.8 && e.x > t.x0 && e.x < t.x1 && e.z > t.z0 && e.z < t.z1) || n.push({
		kind: "open-sky",
		level: e.level,
		message: `The sealed room at spot ${e.name} has nothing over it: the sky will show. Give it a ceiling.`
	}));
	for (let t of e.levels) if (t.design.game) for (let e of [...fl(t.design.shapes, t.design.game), ..._l(t.design.shapes, t.design.game)]) n.push({
		kind: e.kind,
		level: t.name,
		message: e.message
	});
	return n;
}
function Su(e) {
	let t = [];
	for (let n of e.levels ?? []) for (let e of n.design?.shapes ?? []) e.rotation?.some((e) => Math.abs(e) > 360) && t.push({
		kind: "turn",
		level: n.name ?? "",
		message: `${e.name} is turned ${e.rotation.join(", ")}: beyond 360 opens as 360, so it won't face as written.`
	});
	return t;
}
function Cu(e, t) {
	let n = new Map(t.map((e) => [e.id, e])), r = [], i = [];
	for (let t of [...new Set(e)].sort()) {
		let e = n.get(t);
		e ? r.push({
			name: e.name,
			author: e.author,
			licence: e.licence,
			...e.source ? { source: e.source } : {}
		}) : i.push(t);
	}
	return {
		credits: r,
		own: i
	};
}
var wu = {
	wall: "Wall",
	solid: "Solid thing",
	spot: "Named spot",
	scenery: "Scenery"
};
function Tu(e) {
	return e.startsWith("spot:") ? "spot" : e.startsWith("wall") ? "wall" : e.startsWith("solid") ? "solid" : "scenery";
}
var Eu = (e) => e.replace(/^spot:/, "").replace(/^(wall|solid)\s*/, "");
function Du(e, t) {
	let n = Eu(e.name);
	if (t === "spot") return {
		name: `spot:${n || "place"}`,
		hidden: !0
	};
	let r = Tu(e.name) === "spot" ? !1 : e.hidden ?? !1;
	return t === "scenery" ? {
		name: n || "Shape",
		hidden: r
	} : {
		name: `${t} ${n}`.trim(),
		hidden: r
	};
}
var Ou = {
	phone: {
		label: "Phone",
		levelTriangles: 1e5,
		characterTriangles: 5e4,
		bones: 256,
		megabytes: 200
	},
	computer: {
		label: "Computer",
		levelTriangles: 2e6,
		characterTriangles: 2e5,
		bones: 1024,
		megabytes: 4e3
	}
}, ku = (e) => {
	let t = 0, n = (r) => {
		r.hidden || r.name.startsWith("spot:") || (t += r.kind === "mesh" && r.asset ? e.assets?.[r.asset]?.triangles ?? 0 : r.kind === "box" ? 12 : 200, r.children?.forEach(n));
	};
	return e.shapes.forEach(n), t;
};
function Au(e, t) {
	let n = Ou[t], r = e.levels.map((e) => ({
		name: e.name,
		kind: "level",
		id: e.id,
		triangles: ku(e.design),
		limit: n.levelTriangles
	})), i = 0, a = /* @__PURE__ */ new Set(), o = (e) => {
		for (let [t, n] of Object.entries(e.assets ?? {})) a.has(t) || (a.add(t), i += n.data.length * 3 / 4);
	};
	e.levels.forEach((e) => o(e.design));
	for (let t of e.characters) {
		o(t.design);
		let e = Object.values(t.design.assets ?? {})[0], i;
		if (e) try {
			i = c(_(e.data)).skeleton?.length;
		} catch {
			i = void 0;
		}
		r.push({
			name: t.name,
			kind: "character",
			id: t.id,
			triangles: ku(t.design),
			limit: n.characterTriangles,
			...i ? {
				bones: i,
				boneLimit: n.bones
			} : {}
		});
	}
	let s = i / 1e6, l = [
		...r.filter((e) => e.triangles > e.limit).map((e) => `${e.name}: ${e.triangles.toLocaleString("en")} triangles, over ${e.limit.toLocaleString("en")}.`),
		...r.filter((e) => e.bones && e.bones > e.boneLimit).map((e) => `${e.name}: ${e.bones} bones, over ${e.boneLimit}.`),
		...s > n.megabytes ? [`The models come to ${s.toFixed(0)} MB, over ${n.megabytes} MB.`] : []
	];
	return {
		lines: r,
		megabytes: s,
		megabyteLimit: n.megabytes,
		over: l
	};
}
function ju(e, t) {
	let n = e.skeleton;
	if (!n || n.length <= t) return e;
	let r = new Set(Ui(n).values()), i = new Float64Array(n.length);
	for (let t of e.parts) if (t.joints && t.skinWeights) for (let e = 0; e < t.joints.length; e++) i[t.joints[e]] += t.skinWeights[e];
	let a = n.map((e) => e.parent), o = /* @__PURE__ */ new Set(), s = n.length;
	for (; s > t;) {
		let e = -1;
		for (let t = 0; t < n.length; t++) o.has(t) || r.has(t) || a[t] < 0 || n.some((e, n) => !o.has(n) && e.parent === t) || (e < 0 || i[t] < i[e]) && (e = t);
		if (e < 0) break;
		o.add(e), i[a[e]] += i[e], s--;
	}
	let c = n.map((e, t) => t).filter((e) => !o.has(e)), l = new Map(c.map((e, t) => [e, t])), u = (e) => {
		let t = e;
		for (; o.has(t);) t = a[t];
		return l.get(t);
	};
	return {
		...e,
		skeleton: c.map((e) => ({
			...n[e],
			parent: n[e].parent < 0 ? -1 : l.get(n[e].parent)
		})),
		parts: e.parts.map((e) => e.joints ? {
			...e,
			joints: e.joints.map((e) => u(e))
		} : e)
	};
}
function Mu(e, t) {
	let n = Ou[t], r = 0, i = e.levels.map((e) => {
		let t = ku(e.design);
		if (t <= n.levelTriangles || !e.design.assets) return e;
		let i = n.levelTriangles / t, a = Object.fromEntries(Object.entries(e.design.assets).map(([e, t]) => {
			let n = c(_(t.data));
			if (n.skeleton?.length) return [e, t];
			let a = $s(n, i);
			return r++, [e, pu(t.name, f(a))];
		}));
		return {
			...e,
			design: {
				...e.design,
				assets: a
			}
		};
	});
	return {
		project: {
			...e,
			levels: i
		},
		lightened: r
	};
}
var Nu = (e, t) => {
	for (let n of e.levels) {
		for (let e of n.design.game?.rules ?? []) for (let n of e.actions) n.kind === "say" && t(n.lines, n.voice);
		for (let e of n.design.game?.quests ?? []) for (let n of e.steps) n.lines.forEach((e, r) => t([e], n.voices?.[r] || void 0));
	}
}, Pu = (e) => {
	let t = /^([^:]{1,30}):\s*(.+)$/s.exec(e);
	return t ? {
		speaker: t[1].trim(),
		text: t[2].trim()
	} : {
		speaker: "Narrator",
		text: e.trim()
	};
};
function Fu(e) {
	let t = /* @__PURE__ */ new Map();
	return Nu(e, (e, n) => {
		for (let r of e) t.has(r) || t.set(r, {
			...Pu(r),
			line: r,
			...e.length === 1 && n ? { voice: n } : {}
		});
	}), [...t.values()];
}
function Iu(e, t) {
	return {
		...e,
		levels: e.levels.map((e) => {
			let n = e.design.game;
			return n ? {
				...e,
				design: {
					...e.design,
					game: {
						...n,
						...n.quests ? { quests: n.quests.map((e) => ({
							...e,
							steps: e.steps.map((e) => ({
								...e,
								...e.lines.some((e) => t[e]) ? { voices: e.lines.map((n, r) => t[n] ?? e.voices?.[r] ?? "") } : {}
							}))
						})) } : {},
						rules: n.rules.map((e) => ({
							...e,
							actions: e.actions.flatMap((e) => e.kind !== "say" || !e.lines.some((e) => t[e]) ? [e] : e.lines.map((n) => ({
								kind: "say",
								lines: [n],
								...t[n] ? { voice: t[n] } : e.lines.length === 1 && e.voice ? { voice: e.voice } : {}
							})))
						}))
					}
				}
			} : e;
		})
	};
}
function Lu(e, t) {
	if (e.width !== t.width || e.height !== t.height) return 0;
	let n = 0, r = 0;
	for (let i = 0; i < e.data.length; i += 16) e.data[i + 3] < 128 && t.data[i + 3] < 128 || (r++, n += (Math.abs(e.data[i] - t.data[i]) + Math.abs(e.data[i + 1] - t.data[i + 1]) + Math.abs(e.data[i + 2] - t.data[i + 2])) / 765);
	return r ? 1 - n / r : 0;
}
//#endregion
//#region ../scene3d/src/model/occlusion.ts
var Ru = class {
	tri;
	nodes = [];
	order;
	constructor(e, t) {
		this.tri = e, this.order = new Uint32Array(t);
		for (let e = 0; e < t; e++) this.order[e] = e;
		let n = new Float32Array(t * 3);
		for (let r = 0; r < t; r++) for (let t = 0; t < 3; t++) n[r * 3 + t] = (e[r * 9 + t] + e[r * 9 + 3 + t] + e[r * 9 + 6 + t]) / 3;
		this.build(0, t, n);
	}
	build(e, t, n) {
		let r = [
			Infinity,
			Infinity,
			Infinity
		], i = [
			-Infinity,
			-Infinity,
			-Infinity
		];
		for (let n = e; n < e + t; n++) {
			let e = this.order[n];
			for (let t = 0; t < 3; t++) for (let n = 0; n < 3; n++) {
				let a = this.tri[e * 9 + t * 3 + n];
				a < r[n] && (r[n] = a), a > i[n] && (i[n] = a);
			}
		}
		let a = this.nodes.push({
			min: r,
			max: i,
			left: -1,
			right: -1,
			first: e,
			count: t
		}) - 1;
		if (t <= 6) return a;
		let o = [
			i[0] - r[0],
			i[1] - r[1],
			i[2] - r[2]
		], s = o[0] >= o[1] && o[0] >= o[2] ? 0 : o[1] >= o[2] ? 1 : 2, c = Infinity, l = -Infinity;
		for (let r = e; r < e + t; r++) {
			let e = n[this.order[r] * 3 + s];
			c = Math.min(c, e), l = Math.max(l, e);
		}
		let u = (c + l) / 2, d = e, f = e + t - 1;
		for (; d <= f;) if (n[this.order[d] * 3 + s] < u) d++;
		else {
			let e = this.order[d];
			this.order[d] = this.order[f], this.order[f] = e, f--;
		}
		let p = d - e;
		(p === 0 || p === t) && (p = t >> 1);
		let m = this.build(e, p, n), h = this.build(e + p, t - p, n), g = this.nodes[a];
		return g.left = m, g.right = h, g.count = 0, a;
	}
	hits(e, t, n, r, i, a, o) {
		let s = 1 / r, c = 1 / i, l = 1 / a, u = [0], d = this.tri;
		for (; u.length;) {
			let f = this.nodes[u.pop()], p = 0, m = o;
			for (let [r, i, a, o] of [
				[
					e,
					s,
					f.min[0],
					f.max[0]
				],
				[
					t,
					c,
					f.min[1],
					f.max[1]
				],
				[
					n,
					l,
					f.min[2],
					f.max[2]
				]
			]) {
				let e = (a - r) * i, t = (o - r) * i;
				if (e > t && ([e, t] = [t, e]), p = Math.max(p, e), m = Math.min(m, t), p > m) break;
			}
			if (!(p > m)) {
				if (f.count === 0) u.push(f.left, f.right);
				else for (let s = f.first; s < f.first + f.count; s++) {
					let c = this.order[s] * 9, l = d[c + 3] - d[c], u = d[c + 4] - d[c + 1], f = d[c + 5] - d[c + 2], p = d[c + 6] - d[c], m = d[c + 7] - d[c + 1], h = d[c + 8] - d[c + 2], g = i * h - a * m, _ = a * p - r * h, v = r * m - i * p, y = l * g + u * _ + f * v;
					if (Math.abs(y) < 1e-12) continue;
					let b = 1 / y, x = e - d[c], S = t - d[c + 1], C = n - d[c + 2], w = (x * g + S * _ + C * v) * b;
					if (w < 0 || w > 1) continue;
					let T = S * f - C * u, E = C * l - x * f, D = x * u - S * l, O = (r * T + i * E + a * D) * b;
					if (O < 0 || w + O > 1) continue;
					let k = (p * T + m * E + h * D) * b;
					if (k > 1e-5 && k < o) return !0;
				}
			}
		}
		return !1;
	}
};
function zu(e, t, n = 24) {
	let r = e.filter((e) => e.blocks !== !1), i = 0;
	for (let e of r) i += e.indices.length / 3;
	let a = new Float32Array(Math.max(1, i) * 9), o = 0;
	for (let e of r) for (let t = 0; t < e.indices.length; t++, o += 3) a.set(e.positions.subarray(e.indices[t] * 3, e.indices[t] * 3 + 3), o);
	let s = new Ru(a, i), c = [], l = n * 2;
	for (let e = 0; e < l; e++) {
		let t = 1 - (e + .5) / l * 2, n = Math.sqrt(1 - t * t), r = e * 2.399963229728653;
		c.push([
			Math.cos(r) * n,
			t,
			Math.sin(r) * n
		]);
	}
	let u = t * .004;
	return e.map((e) => {
		let n = e.positions.length / 3, r = new Uint8Array(n);
		for (let i = 0; i < n; i++) {
			let n = e.positions[i * 3], a = e.positions[i * 3 + 1], o = e.positions[i * 3 + 2], l = e.normals[i * 3], d = e.normals[i * 3 + 1], f = e.normals[i * 3 + 2], p = Math.hypot(l, d, f) || 1;
			l /= p, d /= p, f /= p;
			let m = 0, h = 0;
			for (let [e, r, i] of c) {
				let c = e * l + r * d + i * f;
				c <= .05 || (h += c, s.hits(n + l * u, a + d * u, o + f * u, e, r, i, t) || (m += c));
			}
			r[i] = h > 0 ? Math.round(m / h * 255) : 255;
		}
		return r;
	});
}
//#endregion
//#region ../scene3d/src/model/gamepack.ts
var Bu = class {
	chunks = [];
	four(e) {
		let t = /* @__PURE__ */ new Uint8Array(4);
		e(new DataView(t.buffer)), this.chunks.push(t);
	}
	u32(e) {
		this.four((t) => t.setUint32(0, e, !0));
	}
	i32(e) {
		this.four((t) => t.setInt32(0, e, !0));
	}
	f32(...e) {
		for (let t of e) this.four((e) => e.setFloat32(0, t, !0));
	}
	bytes(e) {
		this.chunks.push(e);
	}
	tag(e) {
		this.bytes(new TextEncoder().encode(e));
	}
	str(e) {
		let t = new TextEncoder().encode(e);
		this.u32(t.length), this.bytes(t);
	}
	blob(e) {
		this.u32(e.length), this.bytes(e);
	}
	array(e) {
		this.bytes(new Uint8Array(e.buffer, e.byteOffset, e.byteLength));
	}
	done() {
		let e = new Uint8Array(this.chunks.reduce((e, t) => e + t.length, 0)), t = 0;
		for (let n of this.chunks) e.set(n, t), t += n.length;
		return e;
	}
}, Vu = [
	"",
	"skin",
	"hair",
	"iris",
	"top",
	"bottom",
	"shoes",
	"cloth",
	"face",
	"mouth",
	"faceskin"
], Hu = (e) => Math.max(0, Vu.indexOf(e ?? "-"));
function Uu(e, t) {
	let n = 2166136261;
	for (let r of new TextEncoder().encode(`${e}\n${t}`)) n ^= r, n = Math.imul(n, 16777619) >>> 0;
	return n.toString(16).padStart(8, "0");
}
var Wu = {
	aa: [
		"a",
		"aa",
		"A",
		"Fcl_MTH_A",
		"あ",
		"viseme_aa",
		"mouthOpen"
	],
	ih: [
		"i",
		"ih",
		"I",
		"Fcl_MTH_I",
		"い",
		"viseme_I"
	],
	ou: [
		"u",
		"ou",
		"U",
		"Fcl_MTH_U",
		"う",
		"viseme_U"
	],
	ee: [
		"e",
		"ee",
		"E",
		"Fcl_MTH_E",
		"え",
		"viseme_E"
	],
	oh: [
		"o",
		"oh",
		"O",
		"Fcl_MTH_O",
		"お",
		"viseme_O"
	],
	blink: [
		"blink",
		"Blink",
		"Fcl_EYE_Close",
		"まばたき",
		"eyesClosed"
	]
}, Gu = {
	ih: ["aa", .35],
	ee: ["aa", .55],
	ou: ["oh", .6]
};
function Ku(e) {
	let t = {}, n = [], r = [], i = (t) => {
		for (let n of Wu[t]) {
			let t = e.includes(n) ? n : n.length >= 4 ? e.find((e) => e.endsWith(`.${n}`) || e.endsWith(`_${n}`)) : void 0;
			if (t) return t;
		}
	};
	for (let [a] of Object.entries(Wu)) {
		let o = i(a), s = Gu[a], c = s && i(s[0]);
		o ? t[a] = { [o]: 1 } : s && c ? (t[a] = { [c]: s[1] }, n.push(a)) : a === "blink" && e.includes("blink_l") && e.includes("blink_r") ? t[a] = {
			blink_l: 1,
			blink_r: 1
		} : a === "blink" && e.includes("eyeBlinkLeft") && e.includes("eyeBlinkRight") ? t[a] = {
			eyeBlinkLeft: 1,
			eyeBlinkRight: 1
		} : r.push(a);
	}
	return {
		expressions: t,
		borrowed: n,
		missing: r
	};
}
var qu = 68;
function Ju(e, t = qu) {
	let n = e.skeleton;
	if (!n) return e;
	let r = Ui(n);
	if (!kt(r)) return e;
	let i = n.map(() => null);
	for (let [e, a, o] of [[
		"leftUpperArm",
		"leftLowerArm",
		-1
	], [
		"rightUpperArm",
		"rightLowerArm",
		1
	]]) {
		let s = r.get(e), c = n[r.get(a)].head.map((e, t) => e - n[s].head[t]), l = Math.atan2(-c[1], Math.hypot(c[0], c[2])) * 180 / Math.PI;
		if (l >= t - 1) continue;
		let u = o * (t - l) * Math.PI / 180, d = [
			Math.cos(u),
			Math.sin(u),
			n[s].head[0],
			n[s].head[1]
		];
		n.forEach((e, t) => {
			(t === s || e.parent >= 0 && i[e.parent] === d) && (i[t] = d);
		});
	}
	if (i.every((e) => e === null)) return e;
	let a = (e, t, n, r) => {
		let [i, a, o, s] = e, [c, l] = r ? [t - o, n - s] : [t, n];
		return [i * c - a * l + (r ? o : 0), a * c + i * l + (r ? s : 0)];
	}, o = (e, t, n, r) => {
		if (!t || !n) return e;
		let o = e.slice();
		for (let s = 0; s < e.length / 3; s++) {
			let c = 0, l = 0, u = !1;
			for (let o = 0; o < 4; o++) {
				let d = n[s * 4 + o];
				if (!d) continue;
				let f = i[t[s * 4 + o]], [p, m] = f ? (u = !0, a(f, e[s * 3], e[s * 3 + 1], r)) : [e[s * 3], e[s * 3 + 1]];
				c += d * p, l += d * m;
			}
			if (!u) continue;
			let d = n[s * 4] + n[s * 4 + 1] + n[s * 4 + 2] + n[s * 4 + 3] || 1;
			o[s * 3] = c / d, o[s * 3 + 1] = l / d;
		}
		return o;
	}, s = (e, t) => t ? [...a(t, e[0], e[1], !0), e[2]] : e, c = e.parts.map((e) => {
		let t = o(e.normals, e.joints, e.skinWeights, !1);
		if (t !== e.normals) for (let e = 0; e < t.length; e += 3) {
			let n = Math.hypot(t[e], t[e + 1], t[e + 2]) || 1;
			t[e] /= n, t[e + 1] /= n, t[e + 2] /= n;
		}
		return {
			...e,
			positions: o(e.positions, e.joints, e.skinWeights, !0),
			normals: t
		};
	}), l = [
		Infinity,
		Infinity,
		Infinity
	], u = [
		-Infinity,
		-Infinity,
		-Infinity
	];
	for (let e of c) for (let t = 0; t < e.positions.length; t++) l[t % 3] = Math.min(l[t % 3], e.positions[t]), u[t % 3] = Math.max(u[t % 3], e.positions[t]);
	return {
		...e,
		parts: c,
		min: l,
		max: u,
		skeleton: n.map((e, t) => ({
			...e,
			head: s(e.head, i[t]),
			tail: s(e.tail, i[t])
		})),
		...e.morphs ? { morphs: {
			names: e.morphs.names,
			moves: e.morphs.moves.map((t) => t.map((t, n) => t ? o(t, e.parts[n].joints, e.parts[n].skinWeights, !1) : null))
		} } : {}
	};
}
var Yu = (e, t, n) => n !== void 0 && t > n ? [`${e}: ${t}, over the budget of ${n}.`] : [];
async function Xu(e, t, n) {
	if (e = t.budget?.bones ? ju(e, t.budget.bones) : e, e.skeleton) {
		let t = Ui(e.skeleton);
		kt(t) && Dn(e.skeleton, t) && (e = h(e)), e = Ju(e);
	}
	let r = yr(e);
	if (!r) throw Error(`${t.name} has no skeleton of its own, so it can't be packed for a game.`);
	let { min: i, max: a } = t.frame ?? e, o = t.height / (a[1] - i[1] || 1), s = [
		(i[0] + a[0]) / 2,
		i[1],
		(i[2] + a[2]) / 2
	], c = (e) => [
		(e[0] - s[0]) * o,
		(e[1] - s[1]) * o,
		(e[2] - s[2]) * o
	], l = new Bu();
	l.tag("GCST"), l.u32(3), l.str(t.name), l.f32(t.height), l.u32(r.bones.length);
	for (let e of r.bones) l.str(e.name), l.i32(e.parent), l.f32(...c(e.head));
	let u = t.fps ?? 15, d = t.armsDown ?? 0, f = A("mesh", 0, {
		asset: "x",
		size: [
			1,
			t.height,
			1
		],
		position: [
			0,
			0,
			0
		]
	}), p = 0;
	l.u32(t.moves.length);
	for (let e of t.moves) {
		let n = Mc(e);
		if (!n) throw Error(`There's no move called ${e}.`);
		let i = Gc(f, r, n, {
			values: {},
			mirror: !1,
			inPlace: !0,
			armsDown: d
		}, n.cycle), a = (e) => {
			let t = Math.max(0, Math.min(1, e)), n = 1;
			for (; n < i.length && i[n].at < t;) n++;
			n >= i.length && (n = i.length - 1);
			let a = i[n ? n - 1 : 0], o = i[n], s = o.at > a.at ? (t - a.at) / (o.at - a.at) : 0;
			return {
				pose: r.bones.map((e, t) => {
					let n = a.bones?.[t] ?? [
						0,
						0,
						0
					], r = o.bones?.[t] ?? [
						0,
						0,
						0
					];
					return [
						n[0] + (r[0] - n[0]) * s,
						n[1] + (r[1] - n[1]) * s,
						n[2] + (r[2] - n[2]) * s
					];
				}),
				lift: a.position[1] + (o.position[1] - a.position[1]) * s
			};
		}, o = t.springs === !1 ? null : Hr(r.bones, n.cycle, (e) => ({
			pose: a(e).pose,
			root: void 0,
			travel: [
				0,
				0,
				0
			]
		}), t.springs ?? {});
		o && (p = Math.max(p, o.bones.length));
		let s = o ? Math.max(2, Math.round(n.cycle * u)) : Math.max(1, i.length - 1), c = [];
		for (let e = 0; e <= s; e++) {
			let t = o ? e / s : i[e]?.at ?? e / s, n = a(t);
			c.push({
				at: t,
				lift: n.lift,
				pose: o ? _i(n.pose, o, t % 1) : n.pose
			});
		}
		let m = [];
		r.bones.forEach((e, t) => {
			c.some((e) => Math.abs(e.pose[t][0]) > .01 || Math.abs(e.pose[t][1]) > .01 || Math.abs(e.pose[t][2]) > .01) && m.push(t);
		}), l.str(e), l.f32(n.cycle), l.u32(m.length), l.array(Uint32Array.from(m)), l.u32(c.length);
		for (let e of c) {
			l.f32(e.at, e.lift);
			let t = new Int16Array(m.length * 3);
			m.forEach((n, r) => {
				for (let i = 0; i < 3; i++) t[r * 3 + i] = Math.max(-32767, Math.min(32767, Math.round(e.pose[n][i] * 90)));
			}), l.array(t);
		}
	}
	l.u32(e.textures.length);
	for (let t of e.textures) l.blob(await n(t));
	let m = e.morphs?.names ?? [], g = t.talk ? Ku(m) : null, _ = Object.entries({
		...g?.expressions,
		...t.expressions
	});
	l.u32(_.length);
	for (let [e] of _) l.str(e);
	let v = [..._.flatMap(([e, t]) => Object.keys(t).filter((e) => !m.includes(e)).map((t) => `Expression ${e}: this model has no ${t}.`)), ...g?.missing.length ? [`Talking: this model has nothing for ${g.missing.join(", ")}, so the game can't show it.`] : []];
	l.u32(e.parts.length), e.parts.forEach((t, n) => {
		let r = e.materials[t.material];
		l.i32(r.texture), l.f32(r.color[0], r.color[1], r.color[2], r.opacity), l.u32(+!!r.cutout | (r.doubleSided ? 2 : 0) | (r.opacity < 1 ? 4 : 0) | (r.tag === "iris" ? 16 : 0) | Hu(r.tag) << 8);
		let i = t.positions.length / 3;
		l.u32(i), l.u32(t.indices.length);
		let a = new Float32Array(i * 3);
		for (let e = 0; e < i; e++) a.set(c([
			t.positions[e * 3],
			t.positions[e * 3 + 1],
			t.positions[e * 3 + 2]
		]), e * 3);
		l.array(a), l.array(t.normals), l.array(t.uvs ?? new Float32Array(i * 2));
		let s = new Uint8Array(i * 4), u = new Uint8Array(i * 4);
		for (let e = 0; e < i; e++) {
			let n = 0, r = 255;
			for (let r = 0; r < 4; r++) n += t.skinWeights?.[e * 4 + r] ?? 0;
			for (let i = 0; i < 4; i++) {
				s[e * 4 + i] = t.joints?.[e * 4 + i] ?? 0;
				let a = i === 3 ? r : Math.min(r, Math.round(n > 0 ? t.skinWeights[e * 4 + i] / n * 255 : i ? 0 : 255));
				u[e * 4 + i] = a, r -= a;
			}
		}
		l.array(s), l.array(u), l.array(t.indices);
		let d = _.map(([, t]) => {
			let r = new Float32Array(i * 3);
			for (let [i, a] of Object.entries(t)) {
				let t = e.morphs?.moves[m.indexOf(i)]?.[n];
				if (t) for (let e = 0; e < r.length; e++) r[e] += t[e] * a * o;
			}
			return r;
		}), f = [];
		for (let e = 0; e < i; e++) d.some((t) => Math.abs(t[e * 3]) + Math.abs(t[e * 3 + 1]) + Math.abs(t[e * 3 + 2]) > 1e-6) && f.push(e);
		l.u32(f.length), l.array(Uint32Array.from(f));
		for (let e of d) {
			let t = new Float32Array(f.length * 3);
			f.forEach((n, r) => t.set(e.subarray(n * 3, n * 3 + 3), r * 3)), l.array(t);
		}
	});
	let y = Object.entries(t.voices ?? {}).filter(([e, t]) => /^[a-z]{2,3}$/.test(e) && /^[a-z]{2}_[a-z]{2,12}$/.test(t));
	if (y.length) {
		l.tag("VOIC"), l.u32(y.length);
		for (let [e, t] of y) l.str(e), l.str(t);
	}
	{
		let e = Jr(r.bones);
		if (e.length && t.springs !== !1) {
			let t = di(r.bones);
			l.tag("SPRG"), l.u32(e.length);
			for (let t of e) l.u32(t.bone), l.f32(t.stiffness, t.drag, t.gravity, t.radius * o, t.length * o);
			l.u32(t.length);
			for (let e of t) l.u32(e.bone), l.f32(...c(e.at), e.radius * o);
		}
	}
	if (t.occlusion !== !1) {
		let n = zu(e.parts.map((t) => {
			let n = new Float32Array(t.positions.length);
			for (let e = 0; e < n.length / 3; e++) n.set(c([
				t.positions[e * 3],
				t.positions[e * 3 + 1],
				t.positions[e * 3 + 2]
			]), e * 3);
			let r = e.materials[t.material];
			return {
				positions: n,
				normals: t.normals,
				indices: t.indices,
				blocks: !r.cutout && r.opacity >= 1
			};
		}), t.height * .12);
		l.tag("OCCL"), l.u32(n.length);
		for (let e of n) l.u32(e.length), l.array(e);
	}
	if (t.outlines !== !1) {
		let t = (e, t, n) => `${Math.round(e * 2e4)},${Math.round(t * 2e4)},${Math.round(n * 2e4)}`, n = /* @__PURE__ */ new Map();
		for (let r of e.parts) for (let e = 0; e < r.positions.length / 3; e++) {
			let i = t(r.positions[e * 3], r.positions[e * 3 + 1], r.positions[e * 3 + 2]), a = n.get(i) ?? [
				0,
				0,
				0
			];
			for (let t = 0; t < 3; t++) a[t] += r.normals[e * 3 + t];
			n.set(i, a);
		}
		let r = {
			hair: 255,
			skin: 200,
			faceskin: 150,
			top: 220,
			bottom: 220,
			cloth: 220,
			shoes: 220
		}, i = (e) => Math.max(0, Math.min(255, Math.round((e * .5 + .5) * 255)));
		l.tag("OUTL"), l.u32(e.parts.length);
		for (let a of e.parts) {
			let o = e.materials[a.material], s = o.opacity < 1 ? 0 : r[o.tag ?? ""] ?? (o.tag ? 0 : 200), c = a.positions.length / 3, u = new Uint8Array(c * 3);
			for (let e = 0; e < c; e++) {
				let r = n.get(t(a.positions[e * 3], a.positions[e * 3 + 1], a.positions[e * 3 + 2])), o = Math.abs(r[0]) + Math.abs(r[1]) + Math.abs(r[2]) || 1, c = r[0] / o, l = r[1] / o;
				r[2] < 0 && ([c, l] = [(1 - Math.abs(l)) * Math.sign(c || 1), (1 - Math.abs(c)) * Math.sign(l || 1)]), u[e * 3] = i(c), u[e * 3 + 1] = i(l), u[e * 3 + 2] = s;
			}
			l.u32(c), l.array(u);
		}
	}
	let b = l.done(), x = [
		...v,
		...Yu("Triangles", e.triangles, t.budget?.triangles),
		...Yu("Bones", r.bones.length, t.budget?.bones),
		...Yu("Bytes", b.length, t.budget?.bytes)
	];
	return {
		bytes: b,
		triangles: e.triangles,
		bones: r.bones.length,
		swinging: p,
		warnings: x
	};
}
var Zu = (e) => e <= .04045 ? e / 12.92 : ((e + .055) / 1.055) ** 2.4, Qu = (e) => [
	Zu(parseInt(e.slice(1, 3), 16) / 255),
	Zu(parseInt(e.slice(3, 5), 16) / 255),
	Zu(parseInt(e.slice(5, 7), 16) / 255)
], $u = [
	[
		[
			1,
			0,
			0
		],
		[
			0,
			0,
			-1
		],
		[
			0,
			1,
			0
		]
	],
	[
		[
			-1,
			0,
			0
		],
		[
			0,
			0,
			1
		],
		[
			0,
			1,
			0
		]
	],
	[
		[
			0,
			1,
			0
		],
		[
			1,
			0,
			0
		],
		[
			0,
			0,
			-1
		]
	],
	[
		[
			0,
			-1,
			0
		],
		[
			1,
			0,
			0
		],
		[
			0,
			0,
			1
		]
	],
	[
		[
			0,
			0,
			1
		],
		[
			1,
			0,
			0
		],
		[
			0,
			1,
			0
		]
	],
	[
		[
			0,
			0,
			-1
		],
		[
			-1,
			0,
			0
		],
		[
			0,
			1,
			0
		]
	]
], ed = {
	matte: [0, 0],
	satin: [.25, 0],
	glossy: [.65, 0],
	metal: [.7, 1],
	glass: [.95, 0],
	glow: [.3, 0],
	velvet: [.05, 0],
	coat: [.8, 0]
};
function td(e, t, n, r) {
	let i = (e) => Math.round(Math.min(1, Math.max(0, e)) * 255);
	return (e | 8 | i(t) << 8 | i(n) << 16 | i(r) << 24) >>> 0;
}
async function nd(e, t, n, r = []) {
	let i = /* @__PURE__ */ new Map(), a = (e, t) => {
		let n = `${e}/${t}`;
		return i.has(n) || i.set(n, {
			texture: e,
			flags: t,
			verts: [],
			indices: []
		}), i.get(n);
	}, o = [], s = [], l = [], u = /* @__PURE__ */ new Map(), d = async (e, n) => {
		let r = u.get(e);
		if (!r) {
			let i = c(_(n));
			r = {
				mesh: i,
				base: l.length,
				placed: 0
			};
			for (let e of i.textures) l.push(await t(e));
			u.set(e, r);
		}
		return r.placed++, r;
	}, f = /* @__PURE__ */ new Map(), p = (e) => r.filter((t) => e.startsWith(t.match)).sort((e, t) => t.match.length - e.match.length)[0], m = (e) => {
		let t = p(e.name), n = -1;
		t?.image && (f.has(t.image) || (f.set(t.image, l.length), l.push(t.image)), n = f.get(t.image));
		let [r, i] = ed[e.finish] ?? ed.satin, o = a(n, td(0, t?.gloss ?? r, t?.metal ?? i, t?.bumps ?? (t?.image ? .5 : 0))), s = t?.image ? 1 / (t.metres ?? 1) : 1, c = t?.image && t.tint === !1 ? [
			1,
			1,
			1
		] : Qu(e.color), u = e.rotation.some((e) => e !== 0) ? an(e.rotation) : null, d = (e) => u ? [
			0,
			1,
			2
		].map((t) => u[t * 3] * e[0] + u[t * 3 + 1] * e[1] + u[t * 3 + 2] * e[2]) : e;
		for (let [t, n, r] of $u) {
			let i = o.verts.length / 12, a = d(t);
			for (let [i, l] of [
				[-1, -1],
				[1, -1],
				[1, 1],
				[-1, 1]
			]) {
				let u = d([
					0,
					1,
					2
				].map((a) => (t[a] + n[a] * i + r[a] * l) * e.size[a] / 2)), f = [
					0,
					1,
					2
				].map((t) => e.position[t] + u[t]);
				o.verts.push(f[0], f[1], f[2], a[0], a[1], a[2], (f[0] + f[2] * Math.abs(a[0])) * s, (f[2] * Math.abs(a[1]) + f[1] * (1 - Math.abs(a[1]))) * s, c[0], c[1], c[2], 1);
			}
			o.indices.push(i, i + 1, i + 2, i, i + 2, i + 3);
		}
	};
	for (let { design: t } of e.levels) for (let e of t.shapes) {
		if (e.name.startsWith("spot:")) {
			s.push({
				name: e.name.slice(5),
				p: e.position,
				yaw: e.rotation[1]
			});
			continue;
		}
		let n = e.rotation[1] * Math.PI / 180, r = Math.cos(n), i = Math.sin(n);
		if (e.name.startsWith("wall") || e.name.startsWith("solid")) {
			let t = (Math.abs(r) * e.size[0] + Math.abs(i) * e.size[2]) / 2, n = (Math.abs(i) * e.size[0] + Math.abs(r) * e.size[2]) / 2;
			o.push([
				e.position[0] - t,
				e.position[1] - e.size[1] / 2,
				e.position[2] - n,
				e.position[0] + t,
				e.position[1] + e.size[1] / 2,
				e.position[2] + n
			]);
		}
		if (!e.hidden) {
			if (e.kind === "box") m(e);
			else if (e.kind === "mesh") {
				let n = t.assets[e.asset], { mesh: o, base: s } = await d(e.asset, n.data), c = p(e.name);
				for (let t of o.parts) {
					let l = o.materials[t.material], u = a(l.texture >= 0 ? s + l.texture : -1, td(+!!l.cutout | (l.doubleSided ? 2 : 0), c?.gloss ?? 1 - l.roughness, c?.metal ?? l.metalness, c?.bumps ?? 0)), d = u.verts.length / 12, f = t.positions.length / 3;
					for (let a = 0; a < f; a++) {
						let o = [
							0,
							1,
							2
						].map((r) => (t.positions[a * 3 + r] - n.centre[r]) / (n.size[r] || 1) * e.size[r]), s = [
							0,
							1,
							2
						].map((r) => t.normals[a * 3 + r] * (n.size[r] || 1) / (e.size[r] || 1)), c = Math.hypot(s[0], s[1], s[2]) || 1, d = t.colors ? [
							t.colors[a * 3],
							t.colors[a * 3 + 1],
							t.colors[a * 3 + 2]
						] : [
							1,
							1,
							1
						];
						u.verts.push(o[0] * r + o[2] * i + e.position[0], o[1] + e.position[1], -o[0] * i + o[2] * r + e.position[2], (s[0] * r + s[2] * i) / c, s[1] / c, (-s[0] * i + s[2] * r) / c, t.uvs ? t.uvs[a * 2] : 0, t.uvs ? t.uvs[a * 2 + 1] : 0, d[0] * l.color[0], d[1] * l.color[1], d[2] * l.color[2], l.opacity);
					}
					for (let e of t.indices) u.indices.push(d + e);
				}
			}
		}
	}
	let h = new Bu();
	h.tag("GWLD"), h.u32(1), h.u32(o.length);
	for (let e of o) h.array(Float32Array.from(e));
	h.u32(s.length);
	for (let e of s) h.str(e.name), h.f32(e.p[0], e.p[1], e.p[2], e.yaw);
	h.u32(l.length);
	for (let e of l) h.blob(e);
	h.u32(i.size);
	let g = 0;
	for (let e of i.values()) h.i32(e.texture), h.u32(e.flags), h.u32(e.verts.length / 12), h.u32(e.indices.length), h.array(Float32Array.from(e.verts)), h.array(Uint32Array.from(e.indices)), g += e.indices.length / 3;
	let v = h.done(), y = [...u].map(([e, t]) => ({
		id: e,
		triangles: t.mesh.triangles * t.placed,
		placed: t.placed
	})).sort((e, t) => t.triangles - e.triangles).slice(0, 5);
	return {
		bytes: v,
		triangles: g,
		colliders: o.length,
		spots: s.length,
		heaviest: y,
		warnings: [...Yu("Triangles", g, n?.triangles), ...Yu("Bytes", v.length, n?.bytes)]
	};
}
//#endregion
//#region ../scene3d/src/model/vmd.ts
var rd = new TextDecoder("shift-jis"), id = (e) => {
	let t = e.indexOf(0);
	return rd.decode(t >= 0 ? e.subarray(0, t) : e);
};
function ad(e) {
	let t = new DataView(e.buffer, e.byteOffset, e.byteLength), n = id(e.subarray(0, 30));
	if (!n.startsWith("Vocaloid Motion Data")) throw Error("That is not a MikuMikuDance motion (.vmd) file.");
	let r = n.includes("0002") ? 20 : 10, i = 30, a = id(e.subarray(i, i + r));
	i += r;
	let o = () => {
		let e = t.getUint32(i, !0);
		return i += 4, e;
	}, s = () => {
		let e = t.getFloat32(i, !0);
		return i += 4, e;
	}, c = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Map(), u = [], d = 0, f = o();
	if (f * 111 > e.byteLength) throw Error("That motion file is cut short.");
	for (let t = 0; t < f; t++) {
		let t = id(e.subarray(i, i + 15));
		i += 15;
		let n = o(), r = s(), a = s(), l = s(), u = s(), f = s(), p = s(), m = s(), h = e.subarray(i, i + 64);
		i += 64;
		let g = [];
		for (let e = 0; e < 4; e++) for (let t of [
			0,
			4,
			8,
			12
		]) g.push(h[e * 16 + t] / 127);
		let _ = {
			frame: n,
			position: [
				r,
				a,
				-l
			],
			rotation: [
				-u,
				-f,
				p,
				m
			],
			curves: g
		};
		c.has(t) || c.set(t, []), c.get(t).push(_), d = Math.max(d, n);
	}
	if (i + 4 <= e.byteLength) {
		let t = o();
		for (let n = 0; n < t && i + 23 <= e.byteLength; n++) {
			let t = id(e.subarray(i, i + 15));
			i += 15;
			let n = o(), r = s();
			l.has(t) || l.set(t, []), l.get(t).push({
				frame: n,
				weight: r
			}), d = Math.max(d, n);
		}
	}
	if (i + 4 <= e.byteLength) {
		let t = o();
		for (let n = 0; n < t && i + 61 <= e.byteLength; n++) {
			let t = o(), n = s(), r = [
				s(),
				s(),
				-s()
			], a = [
				s(),
				s(),
				s()
			], c = e.subarray(i, i + 24);
			i += 24;
			let l = o();
			i += 1;
			let f = [];
			for (let e = 0; e < 6; e++) f.push(c[e * 4] / 127, c[e * 4 + 2] / 127, c[e * 4 + 1] / 127, c[e * 4 + 3] / 127);
			u.push({
				frame: t,
				distance: n,
				target: r,
				turn: a,
				curves: f,
				fov: l
			}), d = Math.max(d, t);
		}
	}
	for (let e of c.values()) e.sort((e, t) => e.frame - t.frame);
	for (let e of l.values()) e.sort((e, t) => e.frame - t.frame);
	return u.sort((e, t) => e.frame - t.frame), {
		model: a,
		bones: c,
		faces: l,
		camera: u,
		frames: d
	};
}
function od(e, t, n, r, i) {
	if (t === n && r === i) return e;
	let a = 0, o = 1, s = e;
	for (let n = 0; n < 14; n++) {
		let n = 1 - s, i = 3 * n * n * s * t + 3 * n * s * s * r + s * s * s;
		if (Math.abs(i - e) < 1e-4) break;
		i < e ? a = s : o = s, s = (a + o) / 2;
	}
	let c = 1 - s;
	return 3 * c * c * s * n + 3 * c * s * s * i + s * s * s;
}
function sd(e, t, n) {
	let r = e[0] * t[0] + e[1] * t[1] + e[2] * t[2] + e[3] * t[3], i = r < 0 ? -1 : 1;
	if (r = Math.abs(r), r > .9995) {
		let r = e.map((e, r) => e + (t[r] * i - e) * n), a = Math.hypot(...r) || 1;
		return r.map((e) => e / a);
	}
	let a = Math.acos(r), o = Math.sin(a), s = Math.sin((1 - n) * a) / o, c = Math.sin(n * a) / o * i;
	return e.map((e, n) => e * s + t[n] * c);
}
var cd = ([e, t, n, r]) => [
	1 - 2 * (t * t + n * n),
	2 * (e * t - n * r),
	2 * (e * n + t * r),
	2 * (e * t + n * r),
	1 - 2 * (e * e + n * n),
	2 * (t * n - e * r),
	2 * (e * n - t * r),
	2 * (t * n + e * r),
	1 - 2 * (e * e + t * t)
];
function ld(e, t) {
	if (!e?.length) return null;
	if (t <= e[0].frame) return e[0];
	let n = e[e.length - 1];
	if (t >= n.frame) return n;
	let r = 0, i = e.length - 1;
	for (; i - r > 1;) {
		let n = r + i >> 1;
		e[n].frame <= t ? r = n : i = n;
	}
	let a = e[r], o = e[i], s = (t - a.frame) / Math.max(1, o.frame - a.frame), c = o.curves, l = (e) => od(s, c[e * 4], c[e * 4 + 1], c[e * 4 + 2], c[e * 4 + 3]);
	return {
		position: [
			0,
			1,
			2
		].map((e) => a.position[e] + (o.position[e] - a.position[e]) * l(e)),
		rotation: sd(a.rotation, o.rotation, l(3))
	};
}
var ud = (e, t) => {
	if (t <= e[0].frame) return e[0].weight;
	let n = e[e.length - 1];
	if (t >= n.frame) return n.weight;
	let r = 0, i = e.length - 1;
	for (; i - r > 1;) {
		let n = r + i >> 1;
		e[n].frame <= t ? r = n : i = n;
	}
	let a = e[r], o = e[i];
	return a.weight + (o.weight - a.weight) * ((t - a.frame) / Math.max(1, o.frame - a.frame));
}, dd = (e, t, n, r, i, a, o, s) => [["左", 1], ["右", -1]].map(([c, l]) => [
	`${c}${e}`,
	t ? `${t.startsWith("!") ? "" : c}${t.replace("!", "")}` : "",
	[
		n * l,
		r,
		i
	],
	[
		a * l,
		o,
		s
	]
]), fd = [
	[
		"全ての親",
		"",
		[
			0,
			0,
			0
		],
		[
			0,
			1,
			0
		]
	],
	[
		"センター",
		"全ての親",
		[
			0,
			8,
			0
		],
		[
			0,
			9,
			0
		]
	],
	[
		"グルーブ",
		"センター",
		[
			0,
			8.2,
			0
		],
		[
			0,
			9,
			0
		]
	],
	[
		"腰",
		"グルーブ",
		[
			0,
			12,
			.2
		],
		[
			0,
			11,
			.2
		]
	],
	[
		"上半身",
		"腰",
		[
			0,
			13.3,
			.26
		],
		[
			0,
			14.6,
			.13
		]
	],
	[
		"上半身2",
		"上半身",
		[
			0,
			14.6,
			.13
		],
		[
			0,
			16.42,
			0
		]
	],
	[
		"首",
		"上半身2",
		[
			0,
			16.42,
			0
		],
		[
			0,
			16.8,
			0
		]
	],
	[
		"頭",
		"首",
		[
			0,
			16.8,
			0
		],
		[
			0,
			19,
			0
		]
	],
	[
		"下半身",
		"腰",
		[
			0,
			13.24,
			.26
		],
		[
			0,
			11.36,
			.25
		]
	],
	...dd("足", "!下半身", .8, 10.75, .07, .67, 5.93, .05),
	...dd("ひざ", "足", .67, 5.93, .05, .88, 1.34, 0),
	...dd("足首", "ひざ", .88, 1.34, 0, .93, 0, 2.46),
	...dd("つま先", "足首", .93, 0, 2.46, .94, 0, 3.2),
	...dd("肩", "!上半身2", .14, 16.13, -.26, .89, 15.69, -.32),
	...dd("腕", "肩", .89, 15.69, -.32, 3.59, 14.15, -.28),
	...dd("腕捩", "腕", 1.84, 15.37, -.3, 3.59, 14.15, -.28),
	...dd("ひじ", "腕捩", 3.59, 14.15, -.28, 5.27, 12.73, -.27),
	...dd("手捩", "ひじ", 4.04, 13.78, -.28, 5.27, 12.73, -.27),
	...dd("手首", "手捩", 5.27, 12.73, -.27, 6.02, 12.01, -.32),
	...dd("親指1", "手首", 5.6, 12.18, .19, 5.83, 11.89, .35),
	...dd("親指2", "親指1", 5.83, 11.89, .35, 6.08, 11.66, .49),
	...[
		[
			"人指",
			6.13,
			11.97,
			-.05
		],
		[
			"中指",
			6.15,
			11.96,
			-.23
		],
		[
			"薬指",
			6.15,
			11.94,
			-.4
		],
		[
			"小指",
			6.01,
			11.92,
			-.58
		]
	].flatMap(([e, t, n, r]) => [
		1,
		2,
		3
	].flatMap((i) => {
		let a = t + (i - 1) * .26, o = n - (i - 1) * .19;
		return dd(`${e}${i}`, i === 1 ? "手首" : `${e}${i - 1}`, a, o, r, a + .26, o - .19, r);
	}))
], pd = fd.map(([e, t, n, r]) => ({
	name: e,
	parent: fd.findIndex((e) => e[0] === t),
	head: n,
	tail: r
})), md = [[
	"左足",
	"左ひざ",
	"左足首",
	"左つま先",
	"左足ＩＫ",
	"左つま先ＩＫ"
], [
	"右足",
	"右ひざ",
	"右足首",
	"右つま先",
	"右足ＩＫ",
	"右つま先ＩＫ"
]], hd = (e, t) => [
	0,
	1,
	2
].map((n) => e[n * 3] * t[0] + e[n * 3 + 1] * t[1] + e[n * 3 + 2] * t[2]), gd = [
	1,
	0,
	0,
	0,
	1,
	0,
	0,
	0,
	1
], _d = (e) => e.replace(/[０-９]/g, (e) => String(e.charCodeAt(0) - 65296)), vd = {
	あ: "a",
	い: "i",
	う: "u",
	え: "e",
	お: "o",
	まばたき: "blink",
	ウィンク: "blink_l",
	ウィンク右: "blink_r",
	笑い: "joy",
	にこり: "joy",
	怒り: "angry",
	困る: "sorrow",
	びっくり: "surprised"
};
function yd(e, t = "Dance", n = 30) {
	if (!e.bones.size) return null;
	let r = new Map([...e.bones].map(([e, t]) => [_d(e), t])), i = pd, a = new Map(i.map((e, t) => [e.name, t])), o = Math.max(2, Math.ceil(e.frames * n / 30) + 1), s = md.map((e) => r.has(e[4])), c = [];
	for (let e = 0; e < o; e++) {
		let t = e * 30 / n, o = [], l = [], u = i.map((e) => {
			let n = ld(r.get(e.name), t), a = e.parent >= 0 ? o[e.parent] : gd, s = n ? cd(n.rotation) : gd, c = D(a, s);
			o.push(c);
			let u = e.parent >= 0 ? l[e.parent] : [
				0,
				0,
				0
			], d = e.parent >= 0 ? i[e.parent].head : [
				0,
				0,
				0
			], f = hd(a, e.head.map((e, t) => e - d[t] + (n?.position[t] ?? 0))).map((e, t) => e + d[t] + u[t]);
			return l.push(f.map((t, n) => t - e.head[n])), { world: f };
		});
		md.forEach((e, n) => {
			if (!s[n]) return;
			let [c, d, f, p] = e.slice(0, 4).map((e) => a.get(e)), m = [
				c,
				d,
				f,
				p
			].map((e) => i[e].head), h = u[c].world, g = ld(r.get(e[4]), t), _ = o[a.get("全ての親")], v = l[a.get("全ての親")], y = hd(_, m[2].map((e, t) => e + (g?.position[t] ?? 0))).map((e, t) => e + v[t]), b = Math.hypot(...m[1].map((e, t) => e - m[0][t])), x = Math.hypot(...m[2].map((e, t) => e - m[1][t])), S = y.map((e, t) => e - h[t]), C = Math.min(b + x - 1e-4, Math.max(Math.abs(b - x) + 1e-4, Math.hypot(...S))), w = wt(S), T = o[i[c].parent], E = hd(T, [
				0,
				0,
				1
			]), O = E[0] * w[0] + E[1] * w[1] + E[2] * w[2], k = wt(E.map((e, t) => e - w[t] * O)), ee = (b * b + C * C - x * x) / (2 * b * C), te = Math.sqrt(Math.max(0, 1 - ee * ee)), ne = h.map((e, t) => e + b * (ee * w[t] + te * k[t])), re = h.map((e, t) => e + w[t] * C), ie = (e, t, n, r, i) => D(Pe(wt(hd(e, n.map((e, n) => e - t[n]))), wt(i.map((e, t) => e - r[t]))), e);
			o[c] = ie(T, m[0], m[1], h, ne), o[d] = ie(o[c], m[1], m[2], ne, re);
			let ae = g ? D(_, cd(g.rotation)) : _, oe = ld(r.get(e[5]), t), se = hd(ae, m[3].map((e, t) => e - m[2][t] + (oe?.position[t] ?? 0))).map((e, t) => e + re[t]);
			o[f] = ie(o[d], m[2], m[3], re, se), o[p] = o[f];
		});
		let d = i.map((e, t) => Ye(e.parent >= 0 ? D(xe(o[e.parent]), o[t]) : o[t])), f = l[a.get("グルーブ")];
		c.push({
			turns: d,
			root: f
		});
	}
	let l = [...e.faces.keys()], u = l.length ? {
		names: l.map((e) => vd[e] ?? e),
		amounts: Array.from({ length: o }, (t, r) => l.map((t) => Math.max(0, Math.min(1, ud(e.faces.get(t), r * 30 / n)))))
	} : void 0;
	return Lt(t, i.map((e) => e.name), n, c, u);
}
function bd(e, t, n, r = 30) {
	let i = e.camera;
	if (i.length < 2) return null;
	let a = t / 20, o = Math.max(2, Math.ceil(e.frames * r / 30) + 1), s = new Float32Array(o * 7), c = 180 / Math.PI;
	for (let e = 0; e < o; e++) {
		let t = e * 30 / r, o = i.findIndex((e) => e.frame > t);
		o < 0 && (o = i.length - 1);
		let l = i[Math.max(0, o - 1)], u = i[o], d = Math.max(1, u.frame - l.frame), f = Math.max(0, Math.min(1, (t - l.frame) / d)), p = u.curves, m = (e) => od(f, p[e * 4], p[e * 4 + 1], p[e * 4 + 2], p[e * 4 + 3]), h = (e, t, n) => e + (t - e) * m(n), g = -h(l.turn[1], u.turn[1], 3) * c, _ = h(l.turn[0], u.turn[0], 3) * c;
		s.set([
			g,
			_,
			Math.abs(h(l.distance, u.distance, 4)) * a,
			h(l.target[0], u.target[0], 0) * a + n[0],
			h(l.target[1], u.target[1], 1) * a + n[1],
			h(l.target[2], u.target[2], 2) * a + n[2],
			h(l.fov, u.fov, 5)
		], e * 7);
	}
	return {
		fps: r,
		data: xd(s)
	};
}
var xd = (e) => l(new Uint8Array(e.buffer, e.byteOffset, e.byteLength)), Sd = class {
	bytes;
	at = 0;
	dv;
	constructor(e) {
		this.bytes = e, this.dv = new DataView(e.buffer, e.byteOffset, e.byteLength);
	}
	u8 = () => this.dv.getUint8(this.at++);
	u16() {
		let e = this.dv.getUint16(this.at, !0);
		return this.at += 2, e;
	}
	i32() {
		let e = this.dv.getInt32(this.at, !0);
		return this.at += 4, e;
	}
	u32() {
		let e = this.dv.getUint32(this.at, !0);
		return this.at += 4, e;
	}
	f32() {
		let e = this.dv.getFloat32(this.at, !0);
		return this.at += 4, e;
	}
	vec3 = () => [
		this.f32(),
		this.f32(),
		this.f32()
	];
	skip(e) {
		this.at += e;
	}
	index(e, t = !1) {
		if (e === 1) {
			let e = this.u8();
			return t ? e : e === 255 ? -1 : e;
		}
		if (e === 2) {
			let e = this.u16();
			return t ? e : e === 65535 ? -1 : e;
		}
		return this.i32();
	}
};
function Cd(e) {
	let t = new Sd(e);
	t.skip(4), t.f32();
	let n = t.u8(), [r, i, a, o, s, c, l] = Array.from({ length: n }, () => t.u8()), u = new TextDecoder(r === 0 ? "utf-16le" : "utf-8"), d = () => {
		let n = t.i32(), r = u.decode(e.subarray(t.at, t.at + n));
		return t.skip(n), r;
	}, f = d();
	d(), d(), d();
	let p = t.i32(), m = new Float32Array(p * 3), h = new Float32Array(p * 3), g = new Float32Array(p * 2), _ = new Int32Array(p * 4), v = new Float32Array(p * 4);
	for (let e = 0; e < p; e++) {
		m.set(t.vec3(), e * 3), h.set(t.vec3(), e * 3), g[e * 2] = t.f32(), g[e * 2 + 1] = t.f32(), t.skip(i * 16);
		let n = t.u8();
		if (n === 0) _[e * 4] = t.index(c), v[e * 4] = 1;
		else if (n === 1 || n === 3) {
			_[e * 4] = t.index(c), _[e * 4 + 1] = t.index(c);
			let r = t.f32();
			v[e * 4] = r, v[e * 4 + 1] = 1 - r, n === 3 && t.skip(36);
		} else {
			for (let n = 0; n < 4; n++) _[e * 4 + n] = t.index(c);
			for (let n = 0; n < 4; n++) v[e * 4 + n] = t.f32();
		}
		t.f32();
	}
	let y = t.i32(), b = new Uint32Array(y);
	for (let e = 0; e < y; e++) b[e] = t.index(a, a < 4);
	let x = Array.from({ length: t.i32() }, () => d()), S = Array.from({ length: t.i32() }, () => {
		let e = d();
		d();
		let n = [
			t.f32(),
			t.f32(),
			t.f32(),
			t.f32()
		];
		t.skip(28);
		let r = t.u8();
		t.skip(20);
		let i = t.index(o);
		return t.index(o), t.u8(), t.u8() ? t.u8() : t.index(o), d(), {
			name: e,
			diffuse: n,
			doubleSided: !!(r & 1),
			texture: i >= 0 ? x[i] ?? null : null,
			faces: t.i32()
		};
	}), C = Array.from({ length: t.i32() }, () => {
		let e = d();
		d();
		let n = t.vec3(), r = t.index(c);
		t.i32();
		let i = t.u16(), a = {
			name: e,
			parent: r,
			head: n
		};
		if (i & 1) a.tailBone = t.index(c);
		else {
			let e = t.vec3();
			a.tail = [
				n[0] + e[0],
				n[1] + e[1],
				n[2] + e[2]
			];
		}
		if (i & 768 && (t.index(c), t.f32()), i & 1024 && t.skip(12), i & 2048 && t.skip(24), i & 8192 && t.skip(4), i & 32) {
			t.index(c), t.i32(), t.f32();
			let e = t.i32();
			for (let n = 0; n < e; n++) t.index(c), t.u8() && t.skip(24);
		}
		return a;
	}), w = [], T = t.i32();
	for (let e = 0; e < T; e++) {
		let e = d();
		d(), t.u8();
		let n = t.u8(), r = t.i32();
		if (n === 1) {
			let n = new Int32Array(r), i = new Float32Array(r * 3);
			for (let e = 0; e < r; e++) n[e] = t.index(a, a < 4), i.set(t.vec3(), e * 3);
			w.push({
				name: e,
				at: n,
				moves: i
			});
		} else {
			let e = n === 0 ? l + 4 : n === 2 ? c + 28 : n === 8 ? s + 1 + 112 - 1 : n === 9 ? l + 4 : n === 10 ? 29 : a + 16;
			t.skip(r * e);
		}
	}
	return {
		name: f,
		positions: m,
		normals: h,
		uvs: g,
		joints: _,
		weights: v,
		indices: b,
		materials: S,
		bones: C,
		morphs: w
	};
}
var wd = new TextDecoder("shift-jis"), Td = (e) => {
	let t = e.indexOf(0);
	return wd.decode(t >= 0 ? e.subarray(0, t) : e);
};
function Ed(e) {
	let t = new Sd(e);
	t.skip(7);
	let n = Td(e.subarray(t.at, t.at + 20));
	t.skip(276);
	let r = t.u32(), i = new Float32Array(r * 3), a = new Float32Array(r * 3), o = new Float32Array(r * 2), s = new Int32Array(r * 4), c = new Float32Array(r * 4);
	for (let e = 0; e < r; e++) {
		i.set(t.vec3(), e * 3), a.set(t.vec3(), e * 3), o[e * 2] = t.f32(), o[e * 2 + 1] = t.f32(), s[e * 4] = t.u16(), s[e * 4 + 1] = t.u16();
		let n = t.u8() / 100;
		c[e * 4] = n, c[e * 4 + 1] = 1 - n, t.u8();
	}
	let l = t.u32(), u = new Uint32Array(l);
	for (let e = 0; e < l; e++) u[e] = t.u16();
	let d = Array.from({ length: t.u32() }, (n, r) => {
		let i = [
			t.f32(),
			t.f32(),
			t.f32(),
			t.f32()
		];
		t.skip(29);
		let a = t.u8(), o = t.u32(), s = Td(e.subarray(t.at, t.at + 20));
		t.skip(20);
		let c = s.split("*").find((e) => e && !/\.(spa|sph)$/i.test(e)) ?? null;
		return {
			name: `Material ${r + 1}`,
			diffuse: i,
			doubleSided: a === 0,
			texture: c,
			faces: o
		};
	}), f = Array.from({ length: t.u16() }, () => {
		let n = Td(e.subarray(t.at, t.at + 20));
		t.skip(20);
		let r = t.u16(), i = t.u16();
		t.u8(), t.u16();
		let a = t.vec3();
		return {
			name: n,
			parent: r === 65535 ? -1 : r,
			head: a,
			...i && i !== 65535 ? { tailBone: i } : {}
		};
	}), p = t.u16();
	for (let e = 0; e < p; e++) {
		t.skip(4);
		let e = t.u8();
		t.skip(6 + e * 2);
	}
	let m = t.u16(), h = [];
	for (let n = 0; n < m; n++) {
		let n = Td(e.subarray(t.at, t.at + 20));
		t.skip(20);
		let r = t.u32(), i = t.u8(), a = new Int32Array(r), o = new Float32Array(r * 3);
		for (let e = 0; e < r; e++) a[e] = t.u32(), o.set(t.vec3(), e * 3);
		h.push({
			name: n,
			kind: i,
			at: a,
			moves: o
		});
	}
	let g = h.find((e) => e.kind === 0);
	return {
		name: n,
		positions: i,
		normals: a,
		uvs: o,
		joints: s,
		weights: c,
		indices: u,
		materials: d,
		bones: f,
		morphs: h.filter((e) => e.kind !== 0).map((e) => ({
			name: e.name,
			at: g ? e.at.map((e) => g.at[e] ?? 0) : e.at,
			moves: e.moves
		}))
	};
}
var Dd = (e) => {
	let t = /^(左|右)(足|ひざ|足首)D$/.exec(e);
	return t ? `${t[1]}${t[2]}` : /^(左|右)足先EX$/.test(e) ? `${e[0]}つま先` : null;
};
async function Od(e, t) {
	let n = new TextDecoder().decode(e.subarray(0, 4)), r = n === "PMX " ? Cd(e) : n.startsWith("Pmd") ? Ed(e) : null;
	if (!r) throw Error("That is not a MikuMikuDance model (.pmx or .pmd).");
	let i = r.positions.length / 3;
	for (let e = 0; e < i; e++) r.positions[e * 3 + 2] = -r.positions[e * 3 + 2], r.normals[e * 3 + 2] = -r.normals[e * 3 + 2];
	for (let e = 0; e + 2 < r.indices.length; e += 3) [r.indices[e + 1], r.indices[e + 2]] = [r.indices[e + 2], r.indices[e + 1]];
	let a = (e) => [
		e[0],
		e[1],
		-e[2]
	], s = new Map(r.bones.map((e, t) => [e.name, t])), c = r.bones.map((e, t) => {
		let n = Dd(e.name);
		return n && s.has(n) ? s.get(n) : t;
	}), l = /* @__PURE__ */ new Set();
	for (let e = 0; e < i * 4; e++) r.weights[e] > 0 && l.add(c[r.joints[e]] ?? 0);
	let d = new Set(Ui(r.bones.map((e) => ({
		name: e.name,
		parent: e.parent
	}))).values()), f = /* @__PURE__ */ new Set(), h = (e) => {
		for (let t = e, n = 0; t >= 0 && !f.has(t) && n < 512; t = r.bones[t].parent, n++) f.add(t);
	};
	l.forEach(h), d.forEach(h);
	let g = (e) => r.bones[e].parent >= 0 && r.bones[e].parent !== e ? g(r.bones[e].parent) + 1 : 0, _ = [...f].filter((e) => c[e] === e).sort((e, t) => g(e) - g(t) || e - t).slice(0, 256), v = new Map(_.map((e, t) => [e, t])), y = (e) => {
		for (let t = c[e] ?? e, n = 0; t >= 0 && n < 512; t = r.bones[t].parent, n++) if (v.has(t)) return v.get(t);
		return 0;
	}, b = _.map((e) => {
		let t = r.bones[e], n = t.parent;
		for (; n >= 0 && !v.has(n);) n = r.bones[n].parent;
		let i = a(t.head), o = t.tailBone !== void 0 && t.tailBone >= 0 && r.bones[t.tailBone] ? a(r.bones[t.tailBone].head) : t.tail ? a(t.tail) : null;
		return {
			name: t.name.slice(0, 40),
			parent: n >= 0 ? v.get(n) : -1,
			head: i,
			tail: o ?? i
		};
	});
	b.forEach((e, t) => {
		Math.hypot(e.tail[0] - e.head[0], e.tail[1] - e.head[1], e.tail[2] - e.head[2]) < 1e-5 && (e.tail = p(b, t));
	});
	let x = [], S = [], C = /* @__PURE__ */ new Map(), w = [], T = [], E = /* @__PURE__ */ new Map(), D = 0, O = 0;
	for (let e of r.materials) {
		let n = o(), i = -1;
		if (e.texture && t) {
			let n = e.texture.toLowerCase();
			if (!C.has(n)) {
				let r = await t(e.texture);
				r ? C.set(n, S.push(r) - 1) : (C.set(n, -1), O++);
			}
			i = C.get(n);
		}
		let a = {
			...n,
			color: i >= 0 ? [
				1,
				1,
				1
			] : [
				e.diffuse[0],
				e.diffuse[1],
				e.diffuse[2]
			],
			opacity: e.diffuse[3],
			metalness: 0,
			roughness: .7,
			texture: i,
			cutout: e.diffuse[3] < 1 || i >= 0,
			doubleSided: e.doubleSided,
			look: "toon"
		}, s = w.push(a) - 1, c = D + e.faces;
		if (e.faces > 0) {
			let t = /* @__PURE__ */ new Map(), n = new Uint32Array(e.faces);
			for (let e = D; e < c; e++) {
				let i = r.indices[e];
				t.has(i) || t.set(i, t.size), n[e - D] = t.get(i);
			}
			let i = t.size, a = new Float32Array(i * 3), o = new Float32Array(i * 3), l = new Float32Array(i * 2), d = new Uint16Array(i * 4), f = new Float32Array(i * 4), p = T.length;
			for (let [e, n] of t) {
				a.set(r.positions.subarray(e * 3, e * 3 + 3), n * 3), o.set(r.normals.subarray(e * 3, e * 3 + 3), n * 3), l.set(r.uvs.subarray(e * 2, e * 2 + 2), n * 2);
				for (let t = 0; t < 4; t++) d[n * 4 + t] = y(r.joints[e * 4 + t]), f[n * 4 + t] = r.weights[e * 4 + t];
				E.has(e) || E.set(e, []), E.get(e).push([p, n]);
			}
			let m = (() => {
				for (let e = 0; e < i * 3; e += 3) if (Math.hypot(o[e], o[e + 1], o[e + 2]) < 1e-4) return !1;
				return !0;
			})();
			T.push({
				positions: a,
				normals: m ? o : u(a, n),
				uvs: l,
				colors: null,
				indices: n,
				material: s,
				joints: d,
				skinWeights: f
			});
		}
		D = c;
	}
	if (O && x.push(`${O} of its pictures were not among the files picked; pick its whole folder.`), !T.length) throw Error("That model has no faces to draw.");
	let k = [...new Set(r.morphs.map((e) => e.name))], ee = k.map((e) => {
		let t = r.morphs.find((t) => t.name === e), n = T.map(() => null);
		for (let e = 0; e < t.at.length; e++) for (let [r, i] of E.get(t.at[e]) ?? []) {
			let a = n[r] ??= new Float32Array(T[r].positions.length);
			a[i * 3] = t.moves[e * 3], a[i * 3 + 1] = t.moves[e * 3 + 1], a[i * 3 + 2] = -t.moves[e * 3 + 2];
		}
		return n;
	});
	return {
		asset: {
			...m(T, w, S),
			skeleton: b,
			...k.length ? { morphs: {
				names: k.map((e) => e.slice(0, 40)),
				moves: ee
			} } : {}
		},
		name: r.name,
		warnings: x
	};
}
//#endregion
//#region ../scene3d/src/model/cloth.ts
var kd = .012;
function Ad(e, t) {
	let n = Math.round(Math.min(64, Math.max(16, t.cells ?? 40))), r = { shapes: e.shapes.filter((e) => e.kind !== "mesh" && !e.hidden) }, i = r.shapes.reduce((e, t) => Math.max(e, qr(t)?.max[1] ?? 0), 0) + (t.lift ?? .2), a = t.size / (n - 1), s = n * n, c = new Float64Array(s * 3), l = new Float64Array(s * 3);
	for (let e = 0; e < n; e++) for (let r = 0; r < n; r++) {
		let o = (e * n + r) * 3;
		c[o] = t.centre[0] - t.size / 2 + r * a, c[o + 1] = i, c[o + 2] = t.centre[1] - t.size / 2 + e * a;
	}
	l.set(c);
	let d = [], f = (e, t) => d.push([
		e,
		t,
		Math.hypot(c[e * 3] - c[t * 3], c[e * 3 + 1] - c[t * 3 + 1], c[e * 3 + 2] - c[t * 3 + 2])
	]);
	for (let e = 0; e < n; e++) for (let t = 0; t < n; t++) {
		let r = e * n + t;
		t + 1 < n && f(r, r + 1), e + 1 < n && f(r, r + n), t + 1 < n && e + 1 < n && (f(r, r + n + 1), f(r + 1, r + n)), t + 2 < n && f(r, r + 2), e + 2 < n && f(r, r + 2 * n);
	}
	let p = 1 / 120, h = Math.round((t.seconds ?? 2.5) / p), g = (e, t, n) => r.shapes.length ? un(r, [
		e,
		t,
		n
	]).d : Infinity;
	for (let e = 0; e < h; e++) {
		for (let e = 0; e < s; e++) {
			let t = e * 3;
			for (let e = 0; e < 3; e++) {
				let n = c[t + e];
				c[t + e] = n + (n - l[t + e]) * .995 + (e === 1 ? -9.8 * p * p : 0), l[t + e] = n;
			}
		}
		for (let e = 0; e < 6; e++) {
			for (let [e, t, n] of d) {
				let r = e * 3, i = t * 3, a = c[i] - c[r], o = c[i + 1] - c[r + 1], s = c[i + 2] - c[r + 2], l = Math.hypot(a, o, s) || 1e-9, u = (l - n) / l * .5;
				c[r] = c[r] + a * u, c[r + 1] = c[r + 1] + o * u, c[r + 2] = c[r + 2] + s * u, c[i] = c[i] - a * u, c[i + 1] = c[i + 1] - o * u, c[i + 2] = c[i + 2] - s * u;
			}
			for (let e = 0; e < s; e++) {
				let t = e * 3, [n, r, i] = [
					c[t],
					c[t + 1],
					c[t + 2]
				];
				r < kd && (c[t + 1] = kd, l[t] = l[t] + (n - l[t]) * .6, l[t + 2] = l[t + 2] + (i - l[t + 2]) * .6);
				let a = g(n, r, i);
				if (a < kd) {
					let e = .004, o = [
						g(n + e, r, i) - g(n - e, r, i),
						g(n, r + e, i) - g(n, r - e, i),
						g(n, r, i + e) - g(n, r, i - e)
					], s = Math.hypot(o[0], o[1], o[2]) || 1;
					for (let e = 0; e < 3; e++) c[t + e] = c[t + e] + o[e] / s * (kd - a), l[t + e] = l[t + e] + (c[t + e] - l[t + e]) * .6;
				}
			}
		}
	}
	let _ = new Float32Array(c), v = new Float32Array(s * 2), y = new Uint32Array((n - 1) * (n - 1) * 6), b = 0;
	for (let e = 0; e < n; e++) for (let t = 0; t < n; t++) if (v[(e * n + t) * 2] = t / (n - 1), v[(e * n + t) * 2 + 1] = e / (n - 1), t + 1 < n && e + 1 < n) {
		let r = e * n + t;
		y.set([
			r,
			r + n,
			r + 1,
			r + 1,
			r + n,
			r + n + 1
		], b), b += 6;
	}
	let x = {
		...o(),
		color: t.color ?? [
			.5,
			.08,
			.1
		],
		roughness: .85,
		sheenColor: (t.color ?? [
			.5,
			.08,
			.1
		]).map((e) => Math.min(1, e * .8 + .1)),
		sheenRoughness: .6,
		doubleSided: !0
	};
	return m([{
		positions: _,
		normals: u(_, y),
		uvs: v,
		colors: null,
		indices: y,
		material: 0
	}], [x], []);
}
//#endregion
//#region ../scene3d/src/model/script.ts
var jd = (e, t) => ({
	index: t,
	name: e.name,
	kind: e.kind,
	position: e.position,
	rotation: e.rotation,
	size: e.size,
	color: e.color,
	finish: e.finish,
	hidden: e.hidden
}), Md = (e) => {
	throw Error(e);
}, Nd = /* @__PURE__ */ new Set([
	"name",
	"position",
	"rotation",
	"size",
	"color",
	"finish",
	"hidden",
	"round",
	"combine",
	"blend",
	"thickness",
	"form",
	"mirror",
	"repeat",
	"motion"
]), Pd = (e) => {
	if (!e || typeof e != "object") return {};
	let t = {};
	for (let [n, r] of Object.entries(e)) Nd.has(n) || Md(`A script cannot set "${n}". It can set: ${[...Nd].join(", ")}.`), t[n] = r;
	return t;
};
function Fd(e) {
	let t = () => e.document, n = (e) => {
		let n = Number(e);
		return (!Number.isInteger(n) || n < 0 || n >= t().shapes.length) && Md(`There is no shape ${String(e)} (there are ${t().shapes.length}).`), n;
	};
	return {
		shapes: () => t().shapes.map(jd),
		add: (t, n) => {
			wi.includes(t) || Md(`A script can add: ${wi.join(", ")} (not "${String(t)}").`);
			let r = e.addShape(t, Pd(n));
			return r < 0 && Md("The design holds no more shapes."), r;
		},
		change: (r, i) => (e.updateShape(n(r), Pd(i), "Script"), jd(t().shapes[n(r)], n(r))),
		remove: (r) => (e.removeShape(n(r)), t().shapes.length),
		key: (r, i) => {
			let a = n(r), o = Number(i);
			return o >= 0 && o <= 1 || Md("A key is at a share of the clip, from 0 to 1."), e.updateShape(a, { keys: w(t().shapes[a], o) }, "Script"), t().shapes[a].keys?.length ?? 0;
		},
		light: (n) => {
			for (let [t, r] of Object.entries(n ?? {})) e.setSetting("light", t, r);
			return t().light;
		},
		camera: (n) => (e.setCamera(n ?? {}), t().camera),
		clip: (n) => (e.set("clip", Number(n)), t().clip),
		background: (n) => {
			for (let [t, r] of Object.entries(n ?? {})) e.setSetting("background", t, r);
			return t().background;
		}
	};
}
function Id(e, t, n) {
	let r = Fd(e);
	try {
		let e = r[t] ?? Md(`There is no call "${t}".`), i = JSON.parse(n);
		return JSON.stringify({ value: e(...i) ?? null });
	} catch (e) {
		return JSON.stringify({ error: e instanceof Error ? e.message : String(e) });
	}
}
var Ld = "\nimport json, sys, types\nfrom gleamshelf_bridge import call as _call\n\ndef _c(name, *args):\n    out = json.loads(_call(name, json.dumps(list(args))))\n    if \"error\" in out:\n        raise RuntimeError(out[\"error\"])\n    return out[\"value\"]\n\ngleamshelf = types.ModuleType(\"gleamshelf\")\ngleamshelf.__doc__ = \"The open 3D design: shapes(), add(kind, **props), change(i, **props), remove(i), key(i, at), light(**), camera(**), clip(seconds), background(**).\"\ngleamshelf.shapes = lambda: _c(\"shapes\")\ngleamshelf.add = lambda kind, **props: _c(\"add\", kind, props)\ngleamshelf.change = lambda i, **props: _c(\"change\", i, props)\ngleamshelf.remove = lambda i: _c(\"remove\", i)\ngleamshelf.key = lambda i, at: _c(\"key\", i, at)\ngleamshelf.light = lambda **props: _c(\"light\", props)\ngleamshelf.camera = lambda **props: _c(\"camera\", props)\ngleamshelf.clip = lambda seconds: _c(\"clip\", seconds)\ngleamshelf.background = lambda **props: _c(\"background\", props)\nsys.modules[\"gleamshelf\"] = gleamshelf\n", Rd = "import math\nimport gleamshelf as g\n\ncolours = [\"#ff7ab6\", \"#ffb347\", \"#ffe066\", \"#7be0a4\", \"#67e8f9\", \"#a78bfa\"]\nfor n in range(12):\n    a = n / 12 * math.tau\n    i = g.add(\"sphere\", position=[math.sin(a) * 2, 0.3, math.cos(a) * 2],\n              size=[0.5, 0.5, 0.5], color=colours[n % len(colours)], finish=\"glossy\")\n    g.key(i, 0)\n    g.change(i, position=[math.sin(a) * 2, 1.2 + 0.4 * math.sin(a * 3), math.cos(a) * 2])\n    g.key(i, 0.5)\n\nprint(len(g.shapes()), \"shapes\")\n", zd = class e {
	constructor(e) {
		e === void 0 && (e = [
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0
		]), this.elements = e;
	}
	identity() {
		let e = this.elements;
		e[0] = 1, e[1] = 0, e[2] = 0, e[3] = 0, e[4] = 1, e[5] = 0, e[6] = 0, e[7] = 0, e[8] = 1;
	}
	setZero() {
		let e = this.elements;
		e[0] = 0, e[1] = 0, e[2] = 0, e[3] = 0, e[4] = 0, e[5] = 0, e[6] = 0, e[7] = 0, e[8] = 0;
	}
	setTrace(e) {
		let t = this.elements;
		t[0] = e.x, t[4] = e.y, t[8] = e.z;
	}
	getTrace(e) {
		e === void 0 && (e = new G());
		let t = this.elements;
		return e.x = t[0], e.y = t[4], e.z = t[8], e;
	}
	vmult(e, t) {
		t === void 0 && (t = new G());
		let n = this.elements, r = e.x, i = e.y, a = e.z;
		return t.x = n[0] * r + n[1] * i + n[2] * a, t.y = n[3] * r + n[4] * i + n[5] * a, t.z = n[6] * r + n[7] * i + n[8] * a, t;
	}
	smult(e) {
		for (let t = 0; t < this.elements.length; t++) this.elements[t] *= e;
	}
	mmult(t, n) {
		n === void 0 && (n = new e());
		let r = this.elements, i = t.elements, a = n.elements, o = r[0], s = r[1], c = r[2], l = r[3], u = r[4], d = r[5], f = r[6], p = r[7], m = r[8], h = i[0], g = i[1], _ = i[2], v = i[3], y = i[4], b = i[5], x = i[6], S = i[7], C = i[8];
		return a[0] = o * h + s * v + c * x, a[1] = o * g + s * y + c * S, a[2] = o * _ + s * b + c * C, a[3] = l * h + u * v + d * x, a[4] = l * g + u * y + d * S, a[5] = l * _ + u * b + d * C, a[6] = f * h + p * v + m * x, a[7] = f * g + p * y + m * S, a[8] = f * _ + p * b + m * C, n;
	}
	scale(t, n) {
		n === void 0 && (n = new e());
		let r = this.elements, i = n.elements;
		for (let e = 0; e !== 3; e++) i[3 * e + 0] = t.x * r[3 * e + 0], i[3 * e + 1] = t.y * r[3 * e + 1], i[3 * e + 2] = t.z * r[3 * e + 2];
		return n;
	}
	solve(e, t) {
		t === void 0 && (t = new G());
		let n = [], r, i;
		for (r = 0; r < 12; r++) n.push(0);
		for (r = 0; r < 3; r++) for (i = 0; i < 3; i++) n[r + 4 * i] = this.elements[r + 3 * i];
		n[3] = e.x, n[7] = e.y, n[11] = e.z;
		let a = 3, o = a, s, c;
		do {
			if (r = o - a, n[r + 4 * r] === 0) {
				for (i = r + 1; i < o; i++) if (n[r + 4 * i] !== 0) {
					s = 4;
					do
						c = 4 - s, n[c + 4 * r] += n[c + 4 * i];
					while (--s);
					break;
				}
			}
			if (n[r + 4 * r] !== 0) for (i = r + 1; i < o; i++) {
				let e = n[r + 4 * i] / n[r + 4 * r];
				s = 4;
				do
					c = 4 - s, n[c + 4 * i] = c <= r ? 0 : n[c + 4 * i] - n[c + 4 * r] * e;
				while (--s);
			}
		} while (--a);
		if (t.z = n[11] / n[10], t.y = (n[7] - n[6] * t.z) / n[5], t.x = (n[3] - n[2] * t.z - n[1] * t.y) / n[0], isNaN(t.x) || isNaN(t.y) || isNaN(t.z) || t.x === Infinity || t.y === Infinity || t.z === Infinity) throw `Could not solve equation! Got x=[${t.toString()}], b=[${e.toString()}], A=[${this.toString()}]`;
		return t;
	}
	e(e, t, n) {
		if (n === void 0) return this.elements[t + 3 * e];
		this.elements[t + 3 * e] = n;
	}
	copy(e) {
		for (let t = 0; t < e.elements.length; t++) this.elements[t] = e.elements[t];
		return this;
	}
	toString() {
		let e = "";
		for (let t = 0; t < 9; t++) e += this.elements[t] + ",";
		return e;
	}
	reverse(t) {
		t === void 0 && (t = new e());
		let n = Bd, r, i;
		for (r = 0; r < 3; r++) for (i = 0; i < 3; i++) n[r + 6 * i] = this.elements[r + 3 * i];
		n[3] = 1, n[9] = 0, n[15] = 0, n[4] = 0, n[10] = 1, n[16] = 0, n[5] = 0, n[11] = 0, n[17] = 1;
		let a = 3, o = a, s, c;
		do {
			if (r = o - a, n[r + 6 * r] === 0) {
				for (i = r + 1; i < o; i++) if (n[r + 6 * i] !== 0) {
					s = 6;
					do
						c = 6 - s, n[c + 6 * r] += n[c + 6 * i];
					while (--s);
					break;
				}
			}
			if (n[r + 6 * r] !== 0) for (i = r + 1; i < o; i++) {
				let e = n[r + 6 * i] / n[r + 6 * r];
				s = 6;
				do
					c = 6 - s, n[c + 6 * i] = c <= r ? 0 : n[c + 6 * i] - n[c + 6 * r] * e;
				while (--s);
			}
		} while (--a);
		r = 2;
		do {
			i = r - 1;
			do {
				let e = n[r + 6 * i] / n[r + 6 * r];
				s = 6;
				do
					c = 6 - s, n[c + 6 * i] = n[c + 6 * i] - n[c + 6 * r] * e;
				while (--s);
			} while (i--);
		} while (--r);
		r = 2;
		do {
			let e = 1 / n[r + 6 * r];
			s = 6;
			do
				c = 6 - s, n[c + 6 * r] = n[c + 6 * r] * e;
			while (--s);
		} while (r--);
		r = 2;
		do {
			i = 2;
			do {
				if (c = n[3 + i + 6 * r], isNaN(c) || c === Infinity) throw `Could not reverse! A=[${this.toString()}]`;
				t.e(r, i, c);
			} while (i--);
		} while (r--);
		return t;
	}
	setRotationFromQuaternion(e) {
		let t = e.x, n = e.y, r = e.z, i = e.w, a = t + t, o = n + n, s = r + r, c = t * a, l = t * o, u = t * s, d = n * o, f = n * s, p = r * s, m = i * a, h = i * o, g = i * s, _ = this.elements;
		return _[0] = 1 - (d + p), _[1] = l - g, _[2] = u + h, _[3] = l + g, _[4] = 1 - (c + p), _[5] = f - m, _[6] = u - h, _[7] = f + m, _[8] = 1 - (c + d), this;
	}
	transpose(t) {
		t === void 0 && (t = new e());
		let n = this.elements, r = t.elements, i;
		return r[0] = n[0], r[4] = n[4], r[8] = n[8], i = n[1], r[1] = n[3], r[3] = i, i = n[2], r[2] = n[6], r[6] = i, i = n[5], r[5] = n[7], r[7] = i, t;
	}
}, Bd = [
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0
], G = class e {
	constructor(e, t, n) {
		e === void 0 && (e = 0), t === void 0 && (t = 0), n === void 0 && (n = 0), this.x = e, this.y = t, this.z = n;
	}
	cross(t, n) {
		n === void 0 && (n = new e());
		let r = t.x, i = t.y, a = t.z, o = this.x, s = this.y, c = this.z;
		return n.x = s * a - c * i, n.y = c * r - o * a, n.z = o * i - s * r, n;
	}
	set(e, t, n) {
		return this.x = e, this.y = t, this.z = n, this;
	}
	setZero() {
		this.x = this.y = this.z = 0;
	}
	vadd(t, n) {
		if (n) n.x = t.x + this.x, n.y = t.y + this.y, n.z = t.z + this.z;
		else return new e(this.x + t.x, this.y + t.y, this.z + t.z);
	}
	vsub(t, n) {
		if (n) n.x = this.x - t.x, n.y = this.y - t.y, n.z = this.z - t.z;
		else return new e(this.x - t.x, this.y - t.y, this.z - t.z);
	}
	crossmat() {
		return new zd([
			0,
			-this.z,
			this.y,
			this.z,
			0,
			-this.x,
			-this.y,
			this.x,
			0
		]);
	}
	normalize() {
		let e = this.x, t = this.y, n = this.z, r = Math.sqrt(e * e + t * t + n * n);
		if (r > 0) {
			let e = 1 / r;
			this.x *= e, this.y *= e, this.z *= e;
		} else this.x = 0, this.y = 0, this.z = 0;
		return r;
	}
	unit(t) {
		t === void 0 && (t = new e());
		let n = this.x, r = this.y, i = this.z, a = Math.sqrt(n * n + r * r + i * i);
		return a > 0 ? (a = 1 / a, t.x = n * a, t.y = r * a, t.z = i * a) : (t.x = 1, t.y = 0, t.z = 0), t;
	}
	length() {
		let e = this.x, t = this.y, n = this.z;
		return Math.sqrt(e * e + t * t + n * n);
	}
	lengthSquared() {
		return this.dot(this);
	}
	distanceTo(e) {
		let t = this.x, n = this.y, r = this.z, i = e.x, a = e.y, o = e.z;
		return Math.sqrt((i - t) * (i - t) + (a - n) * (a - n) + (o - r) * (o - r));
	}
	distanceSquared(e) {
		let t = this.x, n = this.y, r = this.z, i = e.x, a = e.y, o = e.z;
		return (i - t) * (i - t) + (a - n) * (a - n) + (o - r) * (o - r);
	}
	scale(t, n) {
		n === void 0 && (n = new e());
		let r = this.x, i = this.y, a = this.z;
		return n.x = t * r, n.y = t * i, n.z = t * a, n;
	}
	vmul(t, n) {
		return n === void 0 && (n = new e()), n.x = t.x * this.x, n.y = t.y * this.y, n.z = t.z * this.z, n;
	}
	addScaledVector(t, n, r) {
		return r === void 0 && (r = new e()), r.x = this.x + t * n.x, r.y = this.y + t * n.y, r.z = this.z + t * n.z, r;
	}
	dot(e) {
		return this.x * e.x + this.y * e.y + this.z * e.z;
	}
	isZero() {
		return this.x === 0 && this.y === 0 && this.z === 0;
	}
	negate(t) {
		return t === void 0 && (t = new e()), t.x = -this.x, t.y = -this.y, t.z = -this.z, t;
	}
	tangents(e, t) {
		let n = this.length();
		if (n > 0) {
			let r = Vd, i = 1 / n;
			r.set(this.x * i, this.y * i, this.z * i);
			let a = Hd;
			Math.abs(r.x) < .9 ? (a.set(1, 0, 0), r.cross(a, e)) : (a.set(0, 1, 0), r.cross(a, e)), r.cross(e, t);
		} else e.set(1, 0, 0), t.set(0, 1, 0);
	}
	toString() {
		return `${this.x},${this.y},${this.z}`;
	}
	toArray() {
		return [
			this.x,
			this.y,
			this.z
		];
	}
	copy(e) {
		return this.x = e.x, this.y = e.y, this.z = e.z, this;
	}
	lerp(e, t, n) {
		let r = this.x, i = this.y, a = this.z;
		n.x = r + (e.x - r) * t, n.y = i + (e.y - i) * t, n.z = a + (e.z - a) * t;
	}
	almostEquals(e, t) {
		return t === void 0 && (t = 1e-6), !(Math.abs(this.x - e.x) > t || Math.abs(this.y - e.y) > t || Math.abs(this.z - e.z) > t);
	}
	almostZero(e) {
		return e === void 0 && (e = 1e-6), !(Math.abs(this.x) > e || Math.abs(this.y) > e || Math.abs(this.z) > e);
	}
	isAntiparallelTo(e, t) {
		return this.negate(Ud), Ud.almostEquals(e, t);
	}
	clone() {
		return new e(this.x, this.y, this.z);
	}
};
G.ZERO = new G(0, 0, 0), G.UNIT_X = new G(1, 0, 0), G.UNIT_Y = new G(0, 1, 0), G.UNIT_Z = new G(0, 0, 1);
var Vd = new G(), Hd = new G(), Ud = new G(), Wd = class e {
	constructor(e) {
		e === void 0 && (e = {}), this.lowerBound = new G(), this.upperBound = new G(), e.lowerBound && this.lowerBound.copy(e.lowerBound), e.upperBound && this.upperBound.copy(e.upperBound);
	}
	setFromPoints(e, t, n, r) {
		let i = this.lowerBound, a = this.upperBound, o = n;
		i.copy(e[0]), o && o.vmult(i, i), a.copy(i);
		for (let t = 1; t < e.length; t++) {
			let n = e[t];
			o && (o.vmult(n, Gd), n = Gd), n.x > a.x && (a.x = n.x), n.x < i.x && (i.x = n.x), n.y > a.y && (a.y = n.y), n.y < i.y && (i.y = n.y), n.z > a.z && (a.z = n.z), n.z < i.z && (i.z = n.z);
		}
		return t && (t.vadd(i, i), t.vadd(a, a)), r && (i.x -= r, i.y -= r, i.z -= r, a.x += r, a.y += r, a.z += r), this;
	}
	copy(e) {
		return this.lowerBound.copy(e.lowerBound), this.upperBound.copy(e.upperBound), this;
	}
	clone() {
		return new e().copy(this);
	}
	extend(e) {
		this.lowerBound.x = Math.min(this.lowerBound.x, e.lowerBound.x), this.upperBound.x = Math.max(this.upperBound.x, e.upperBound.x), this.lowerBound.y = Math.min(this.lowerBound.y, e.lowerBound.y), this.upperBound.y = Math.max(this.upperBound.y, e.upperBound.y), this.lowerBound.z = Math.min(this.lowerBound.z, e.lowerBound.z), this.upperBound.z = Math.max(this.upperBound.z, e.upperBound.z);
	}
	overlaps(e) {
		let t = this.lowerBound, n = this.upperBound, r = e.lowerBound, i = e.upperBound, a = r.x <= n.x && n.x <= i.x || t.x <= i.x && i.x <= n.x, o = r.y <= n.y && n.y <= i.y || t.y <= i.y && i.y <= n.y, s = r.z <= n.z && n.z <= i.z || t.z <= i.z && i.z <= n.z;
		return a && o && s;
	}
	volume() {
		let e = this.lowerBound, t = this.upperBound;
		return (t.x - e.x) * (t.y - e.y) * (t.z - e.z);
	}
	contains(e) {
		let t = this.lowerBound, n = this.upperBound, r = e.lowerBound, i = e.upperBound;
		return t.x <= r.x && n.x >= i.x && t.y <= r.y && n.y >= i.y && t.z <= r.z && n.z >= i.z;
	}
	getCorners(e, t, n, r, i, a, o, s) {
		let c = this.lowerBound, l = this.upperBound;
		e.copy(c), t.set(l.x, c.y, c.z), n.set(l.x, l.y, c.z), r.set(c.x, l.y, l.z), i.set(l.x, c.y, l.z), a.set(c.x, l.y, c.z), o.set(c.x, c.y, l.z), s.copy(l);
	}
	toLocalFrame(e, t) {
		let n = Kd, r = n[0], i = n[1], a = n[2], o = n[3], s = n[4], c = n[5], l = n[6], u = n[7];
		this.getCorners(r, i, a, o, s, c, l, u);
		for (let t = 0; t !== 8; t++) {
			let r = n[t];
			e.pointToLocal(r, r);
		}
		return t.setFromPoints(n);
	}
	toWorldFrame(e, t) {
		let n = Kd, r = n[0], i = n[1], a = n[2], o = n[3], s = n[4], c = n[5], l = n[6], u = n[7];
		this.getCorners(r, i, a, o, s, c, l, u);
		for (let t = 0; t !== 8; t++) {
			let r = n[t];
			e.pointToWorld(r, r);
		}
		return t.setFromPoints(n);
	}
	overlapsRay(e) {
		let { direction: t, from: n } = e, r = 1 / t.x, i = 1 / t.y, a = 1 / t.z, o = (this.lowerBound.x - n.x) * r, s = (this.upperBound.x - n.x) * r, c = (this.lowerBound.y - n.y) * i, l = (this.upperBound.y - n.y) * i, u = (this.lowerBound.z - n.z) * a, d = (this.upperBound.z - n.z) * a, f = Math.max(Math.max(Math.min(o, s), Math.min(c, l)), Math.min(u, d)), p = Math.min(Math.min(Math.max(o, s), Math.max(c, l)), Math.max(u, d));
		return !(p < 0 || f > p);
	}
}, Gd = new G(), Kd = [
	new G(),
	new G(),
	new G(),
	new G(),
	new G(),
	new G(),
	new G(),
	new G()
], qd = class {
	constructor() {
		this.matrix = [];
	}
	get(e, t) {
		let { index: n } = e, { index: r } = t;
		if (r > n) {
			let e = r;
			r = n, n = e;
		}
		return this.matrix[(n * (n + 1) >> 1) + r - 1];
	}
	set(e, t, n) {
		let { index: r } = e, { index: i } = t;
		if (i > r) {
			let e = i;
			i = r, r = e;
		}
		this.matrix[(r * (r + 1) >> 1) + i - 1] = +!!n;
	}
	reset() {
		for (let e = 0, t = this.matrix.length; e !== t; e++) this.matrix[e] = 0;
	}
	setNumObjects(e) {
		this.matrix.length = e * (e - 1) >> 1;
	}
}, Jd = class {
	addEventListener(e, t) {
		this._listeners === void 0 && (this._listeners = {});
		let n = this._listeners;
		return n[e] === void 0 && (n[e] = []), n[e].includes(t) || n[e].push(t), this;
	}
	hasEventListener(e, t) {
		if (this._listeners === void 0) return !1;
		let n = this._listeners;
		return !!(n[e] !== void 0 && n[e].includes(t));
	}
	hasAnyEventListener(e) {
		return this._listeners !== void 0 && this._listeners[e] !== void 0;
	}
	removeEventListener(e, t) {
		if (this._listeners === void 0) return this;
		let n = this._listeners;
		if (n[e] === void 0) return this;
		let r = n[e].indexOf(t);
		return r !== -1 && n[e].splice(r, 1), this;
	}
	dispatchEvent(e) {
		if (this._listeners === void 0) return this;
		let t = this._listeners[e.type];
		if (t !== void 0) {
			e.target = this;
			for (let n = 0, r = t.length; n < r; n++) t[n].call(this, e);
		}
		return this;
	}
}, K = class e {
	constructor(e, t, n, r) {
		e === void 0 && (e = 0), t === void 0 && (t = 0), n === void 0 && (n = 0), r === void 0 && (r = 1), this.x = e, this.y = t, this.z = n, this.w = r;
	}
	set(e, t, n, r) {
		return this.x = e, this.y = t, this.z = n, this.w = r, this;
	}
	toString() {
		return `${this.x},${this.y},${this.z},${this.w}`;
	}
	toArray() {
		return [
			this.x,
			this.y,
			this.z,
			this.w
		];
	}
	setFromAxisAngle(e, t) {
		let n = Math.sin(t * .5);
		return this.x = e.x * n, this.y = e.y * n, this.z = e.z * n, this.w = Math.cos(t * .5), this;
	}
	toAxisAngle(e) {
		e === void 0 && (e = new G()), this.normalize();
		let t = 2 * Math.acos(this.w), n = Math.sqrt(1 - this.w * this.w);
		return n < .001 ? (e.x = this.x, e.y = this.y, e.z = this.z) : (e.x = this.x / n, e.y = this.y / n, e.z = this.z / n), [e, t];
	}
	setFromVectors(e, t) {
		if (e.isAntiparallelTo(t)) {
			let t = Yd, n = Xd;
			e.tangents(t, n), this.setFromAxisAngle(t, Math.PI);
		} else {
			let n = e.cross(t);
			this.x = n.x, this.y = n.y, this.z = n.z, this.w = Math.sqrt(e.length() ** 2 * t.length() ** 2) + e.dot(t), this.normalize();
		}
		return this;
	}
	mult(t, n) {
		n === void 0 && (n = new e());
		let r = this.x, i = this.y, a = this.z, o = this.w, s = t.x, c = t.y, l = t.z, u = t.w;
		return n.x = r * u + o * s + i * l - a * c, n.y = i * u + o * c + a * s - r * l, n.z = a * u + o * l + r * c - i * s, n.w = o * u - r * s - i * c - a * l, n;
	}
	inverse(t) {
		t === void 0 && (t = new e());
		let n = this.x, r = this.y, i = this.z, a = this.w;
		this.conjugate(t);
		let o = 1 / (n * n + r * r + i * i + a * a);
		return t.x *= o, t.y *= o, t.z *= o, t.w *= o, t;
	}
	conjugate(t) {
		return t === void 0 && (t = new e()), t.x = -this.x, t.y = -this.y, t.z = -this.z, t.w = this.w, t;
	}
	normalize() {
		let e = Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w);
		return e === 0 ? (this.x = 0, this.y = 0, this.z = 0, this.w = 0) : (e = 1 / e, this.x *= e, this.y *= e, this.z *= e, this.w *= e), this;
	}
	normalizeFast() {
		let e = (3 - (this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w)) / 2;
		return e === 0 ? (this.x = 0, this.y = 0, this.z = 0, this.w = 0) : (this.x *= e, this.y *= e, this.z *= e, this.w *= e), this;
	}
	vmult(e, t) {
		t === void 0 && (t = new G());
		let n = e.x, r = e.y, i = e.z, a = this.x, o = this.y, s = this.z, c = this.w, l = c * n + o * i - s * r, u = c * r + s * n - a * i, d = c * i + a * r - o * n, f = -a * n - o * r - s * i;
		return t.x = l * c + f * -a + u * -s - d * -o, t.y = u * c + f * -o + d * -a - l * -s, t.z = d * c + f * -s + l * -o - u * -a, t;
	}
	copy(e) {
		return this.x = e.x, this.y = e.y, this.z = e.z, this.w = e.w, this;
	}
	toEuler(e, t) {
		t === void 0 && (t = "YZX");
		let n, r, i, a = this.x, o = this.y, s = this.z, c = this.w;
		switch (t) {
			case "YZX":
				let e = a * o + s * c;
				if (e > .499 && (n = 2 * Math.atan2(a, c), r = Math.PI / 2, i = 0), e < -.499 && (n = -2 * Math.atan2(a, c), r = -Math.PI / 2, i = 0), n === void 0) {
					let t = a * a, l = o * o, u = s * s;
					n = Math.atan2(2 * o * c - 2 * a * s, 1 - 2 * l - 2 * u), r = Math.asin(2 * e), i = Math.atan2(2 * a * c - 2 * o * s, 1 - 2 * t - 2 * u);
				}
				break;
			default: throw Error(`Euler order ${t} not supported yet.`);
		}
		e.y = n, e.z = r, e.x = i;
	}
	setFromEuler(e, t, n, r) {
		r === void 0 && (r = "XYZ");
		let i = Math.cos(e / 2), a = Math.cos(t / 2), o = Math.cos(n / 2), s = Math.sin(e / 2), c = Math.sin(t / 2), l = Math.sin(n / 2);
		return r === "XYZ" ? (this.x = s * a * o + i * c * l, this.y = i * c * o - s * a * l, this.z = i * a * l + s * c * o, this.w = i * a * o - s * c * l) : r === "YXZ" ? (this.x = s * a * o + i * c * l, this.y = i * c * o - s * a * l, this.z = i * a * l - s * c * o, this.w = i * a * o + s * c * l) : r === "ZXY" ? (this.x = s * a * o - i * c * l, this.y = i * c * o + s * a * l, this.z = i * a * l + s * c * o, this.w = i * a * o - s * c * l) : r === "ZYX" ? (this.x = s * a * o - i * c * l, this.y = i * c * o + s * a * l, this.z = i * a * l - s * c * o, this.w = i * a * o + s * c * l) : r === "YZX" ? (this.x = s * a * o + i * c * l, this.y = i * c * o + s * a * l, this.z = i * a * l - s * c * o, this.w = i * a * o - s * c * l) : r === "XZY" && (this.x = s * a * o - i * c * l, this.y = i * c * o - s * a * l, this.z = i * a * l + s * c * o, this.w = i * a * o + s * c * l), this;
	}
	clone() {
		return new e(this.x, this.y, this.z, this.w);
	}
	slerp(t, n, r) {
		r === void 0 && (r = new e());
		let i = this.x, a = this.y, o = this.z, s = this.w, c = t.x, l = t.y, u = t.z, d = t.w, f, p, m, h, g;
		return p = i * c + a * l + o * u + s * d, p < 0 && (p = -p, c = -c, l = -l, u = -u, d = -d), 1 - p > 1e-6 ? (f = Math.acos(p), m = Math.sin(f), h = Math.sin((1 - n) * f) / m, g = Math.sin(n * f) / m) : (h = 1 - n, g = n), r.x = h * i + g * c, r.y = h * a + g * l, r.z = h * o + g * u, r.w = h * s + g * d, r;
	}
	integrate(t, n, r, i) {
		i === void 0 && (i = new e());
		let a = t.x * r.x, o = t.y * r.y, s = t.z * r.z, c = this.x, l = this.y, u = this.z, d = this.w, f = n * .5;
		return i.x += f * (a * d + o * u - s * l), i.y += f * (o * d + s * c - a * u), i.z += f * (s * d + a * l - o * c), i.w += f * (-a * c - o * l - s * u), i;
	}
}, Yd = new G(), Xd = new G(), Zd = {
	SPHERE: 1,
	PLANE: 2,
	BOX: 4,
	COMPOUND: 8,
	CONVEXPOLYHEDRON: 16,
	HEIGHTFIELD: 32,
	PARTICLE: 64,
	CYLINDER: 128,
	TRIMESH: 256
}, q = class e {
	constructor(t) {
		t === void 0 && (t = {}), this.id = e.idCounter++, this.type = t.type || 0, this.boundingSphereRadius = 0, this.collisionResponse = !t.collisionResponse || t.collisionResponse, this.collisionFilterGroup = t.collisionFilterGroup === void 0 ? 1 : t.collisionFilterGroup, this.collisionFilterMask = t.collisionFilterMask === void 0 ? -1 : t.collisionFilterMask, this.material = t.material ? t.material : null, this.body = null;
	}
	updateBoundingSphereRadius() {
		throw `computeBoundingSphereRadius() not implemented for shape type ${this.type}`;
	}
	volume() {
		throw `volume() not implemented for shape type ${this.type}`;
	}
	calculateLocalInertia(e, t) {
		throw `calculateLocalInertia() not implemented for shape type ${this.type}`;
	}
	calculateWorldAABB(e, t, n, r) {
		throw `calculateWorldAABB() not implemented for shape type ${this.type}`;
	}
};
q.idCounter = 0, q.types = Zd;
var J = class e {
	constructor(e) {
		e === void 0 && (e = {}), this.position = new G(), this.quaternion = new K(), e.position && this.position.copy(e.position), e.quaternion && this.quaternion.copy(e.quaternion);
	}
	pointToLocal(t, n) {
		return e.pointToLocalFrame(this.position, this.quaternion, t, n);
	}
	pointToWorld(t, n) {
		return e.pointToWorldFrame(this.position, this.quaternion, t, n);
	}
	vectorToWorldFrame(e, t) {
		return t === void 0 && (t = new G()), this.quaternion.vmult(e, t), t;
	}
	static pointToLocalFrame(e, t, n, r) {
		return r === void 0 && (r = new G()), n.vsub(e, r), t.conjugate(Qd), Qd.vmult(r, r), r;
	}
	static pointToWorldFrame(e, t, n, r) {
		return r === void 0 && (r = new G()), t.vmult(n, r), r.vadd(e, r), r;
	}
	static vectorToWorldFrame(e, t, n) {
		return n === void 0 && (n = new G()), e.vmult(t, n), n;
	}
	static vectorToLocalFrame(e, t, n, r) {
		return r === void 0 && (r = new G()), t.w *= -1, t.vmult(n, r), t.w *= -1, r;
	}
}, Qd = new K(), $d = class e extends q {
	constructor(e) {
		e === void 0 && (e = {});
		let { vertices: t = [], faces: n = [], normals: r = [], axes: i, boundingSphereRadius: a } = e;
		super({ type: q.types.CONVEXPOLYHEDRON }), this.vertices = t, this.faces = n, this.faceNormals = r, this.faceNormals.length === 0 && this.computeNormals(), a ? this.boundingSphereRadius = a : this.updateBoundingSphereRadius(), this.worldVertices = [], this.worldVerticesNeedsUpdate = !0, this.worldFaceNormals = [], this.worldFaceNormalsNeedsUpdate = !0, this.uniqueAxes = i ? i.slice() : null, this.uniqueEdges = [], this.computeEdges();
	}
	computeEdges() {
		let e = this.faces, t = this.vertices, n = this.uniqueEdges;
		n.length = 0;
		let r = new G();
		for (let i = 0; i !== e.length; i++) {
			let a = e[i], o = a.length;
			for (let e = 0; e !== o; e++) {
				let i = (e + 1) % o;
				t[a[e]].vsub(t[a[i]], r), r.normalize();
				let s = !1;
				for (let e = 0; e !== n.length; e++) if (n[e].almostEquals(r) || n[e].almostEquals(r)) {
					s = !0;
					break;
				}
				s || n.push(r.clone());
			}
		}
	}
	computeNormals() {
		this.faceNormals.length = this.faces.length;
		for (let e = 0; e < this.faces.length; e++) {
			for (let t = 0; t < this.faces[e].length; t++) if (!this.vertices[this.faces[e][t]]) throw Error(`Vertex ${this.faces[e][t]} not found!`);
			let t = this.faceNormals[e] || new G();
			this.getFaceNormal(e, t), t.negate(t), this.faceNormals[e] = t;
			let n = this.vertices[this.faces[e][0]];
			if (t.dot(n) < 0) {
				console.error(`.faceNormals[${e}] = Vec3(${t.toString()}) looks like it points into the shape? The vertices follow. Make sure they are ordered CCW around the normal, using the right hand rule.`);
				for (let t = 0; t < this.faces[e].length; t++) console.warn(`.vertices[${this.faces[e][t]}] = Vec3(${this.vertices[this.faces[e][t]].toString()})`);
			}
		}
	}
	getFaceNormal(t, n) {
		let r = this.faces[t], i = this.vertices[r[0]], a = this.vertices[r[1]], o = this.vertices[r[2]];
		e.computeNormal(i, a, o, n);
	}
	static computeNormal(e, t, n, r) {
		let i = new G(), a = new G();
		t.vsub(e, a), n.vsub(t, i), i.cross(a, r), r.isZero() || r.normalize();
	}
	clipAgainstHull(e, t, n, r, i, a, o, s, c) {
		let l = new G(), u = -1, d = -Number.MAX_VALUE;
		for (let e = 0; e < n.faces.length; e++) {
			l.copy(n.faceNormals[e]), i.vmult(l, l);
			let t = l.dot(a);
			t > d && (d = t, u = e);
		}
		let f = [];
		for (let e = 0; e < n.faces[u].length; e++) {
			let t = n.vertices[n.faces[u][e]], a = new G();
			a.copy(t), i.vmult(a, a), r.vadd(a, a), f.push(a);
		}
		u >= 0 && this.clipFaceAgainstHull(a, e, t, f, o, s, c);
	}
	findSeparatingAxis(e, t, n, r, i, a, o, s) {
		let c = new G(), l = new G(), u = new G(), d = new G(), f = new G(), p = new G(), m = Number.MAX_VALUE, h = this;
		if (h.uniqueAxes) for (let o = 0; o !== h.uniqueAxes.length; o++) {
			n.vmult(h.uniqueAxes[o], c);
			let s = h.testSepAxis(c, e, t, n, r, i);
			if (s === !1) return !1;
			s < m && (m = s, a.copy(c));
		}
		else {
			let s = o ? o.length : h.faces.length;
			for (let l = 0; l < s; l++) {
				let s = o ? o[l] : l;
				c.copy(h.faceNormals[s]), n.vmult(c, c);
				let u = h.testSepAxis(c, e, t, n, r, i);
				if (u === !1) return !1;
				u < m && (m = u, a.copy(c));
			}
		}
		if (e.uniqueAxes) for (let o = 0; o !== e.uniqueAxes.length; o++) {
			i.vmult(e.uniqueAxes[o], l);
			let s = h.testSepAxis(l, e, t, n, r, i);
			if (s === !1) return !1;
			s < m && (m = s, a.copy(l));
		}
		else {
			let o = s ? s.length : e.faces.length;
			for (let c = 0; c < o; c++) {
				let o = s ? s[c] : c;
				l.copy(e.faceNormals[o]), i.vmult(l, l);
				let u = h.testSepAxis(l, e, t, n, r, i);
				if (u === !1) return !1;
				u < m && (m = u, a.copy(l));
			}
		}
		for (let o = 0; o !== h.uniqueEdges.length; o++) {
			n.vmult(h.uniqueEdges[o], d);
			for (let o = 0; o !== e.uniqueEdges.length; o++) if (i.vmult(e.uniqueEdges[o], f), d.cross(f, p), !p.almostZero()) {
				p.normalize();
				let o = h.testSepAxis(p, e, t, n, r, i);
				if (o === !1) return !1;
				o < m && (m = o, a.copy(p));
			}
		}
		return r.vsub(t, u), u.dot(a) > 0 && a.negate(a), !0;
	}
	testSepAxis(t, n, r, i, a, o) {
		let s = this;
		e.project(s, t, r, i, ef), e.project(n, t, a, o, tf);
		let c = ef[0], l = ef[1], u = tf[0], d = tf[1];
		if (c < d || u < l) return !1;
		let f = c - d, p = u - l;
		return f < p ? f : p;
	}
	calculateLocalInertia(e, t) {
		let n = new G(), r = new G();
		this.computeLocalAABB(r, n);
		let i = n.x - r.x, a = n.y - r.y, o = n.z - r.z;
		t.x = 1 / 12 * e * (2 * a * 2 * a + 2 * o * 2 * o), t.y = 1 / 12 * e * (2 * i * 2 * i + 2 * o * 2 * o), t.z = 1 / 12 * e * (2 * a * 2 * a + 2 * i * 2 * i);
	}
	getPlaneConstantOfFace(e) {
		let t = this.faces[e], n = this.faceNormals[e], r = this.vertices[t[0]];
		return -n.dot(r);
	}
	clipFaceAgainstHull(e, t, n, r, i, a, o) {
		let s = new G(), c = new G(), l = new G(), u = new G(), d = new G(), f = new G(), p = new G(), m = new G(), h = this, g = [], _ = r, v = g, y = -1, b = Number.MAX_VALUE;
		for (let t = 0; t < h.faces.length; t++) {
			s.copy(h.faceNormals[t]), n.vmult(s, s);
			let r = s.dot(e);
			r < b && (b = r, y = t);
		}
		if (y < 0) return;
		let x = h.faces[y];
		x.connectedFaces = [];
		for (let e = 0; e < h.faces.length; e++) for (let t = 0; t < h.faces[e].length; t++) x.indexOf(h.faces[e][t]) !== -1 && e !== y && x.connectedFaces.indexOf(e) === -1 && x.connectedFaces.push(e);
		let S = x.length;
		for (let e = 0; e < S; e++) {
			let r = h.vertices[x[e]], i = h.vertices[x[(e + 1) % S]];
			r.vsub(i, c), l.copy(c), n.vmult(l, l), t.vadd(l, l), u.copy(this.faceNormals[y]), n.vmult(u, u), t.vadd(u, u), l.cross(u, d), d.negate(d), f.copy(r), n.vmult(f, f), t.vadd(f, f);
			let a = x.connectedFaces[e];
			p.copy(this.faceNormals[a]);
			let o = this.getPlaneConstantOfFace(a);
			m.copy(p), n.vmult(m, m);
			let s = o - m.dot(t);
			for (this.clipFaceAgainstPlane(_, v, m, s); _.length;) _.shift();
			for (; v.length;) _.push(v.shift());
		}
		p.copy(this.faceNormals[y]);
		let C = this.getPlaneConstantOfFace(y);
		m.copy(p), n.vmult(m, m);
		let w = C - m.dot(t);
		for (let e = 0; e < _.length; e++) {
			let t = m.dot(_[e]) + w;
			if (t <= i && (console.log(`clamped: depth=${t} to minDist=${i}`), t = i), t <= a) {
				let n = _[e];
				if (t <= 1e-6) {
					let e = {
						point: n,
						normal: m,
						depth: t
					};
					o.push(e);
				}
			}
		}
	}
	clipFaceAgainstPlane(e, t, n, r) {
		let i, a, o = e.length;
		if (o < 2) return t;
		let s = e[e.length - 1], c = e[0];
		i = n.dot(s) + r;
		for (let l = 0; l < o; l++) {
			if (c = e[l], a = n.dot(c) + r, i < 0) {
				if (a < 0) {
					let e = new G();
					e.copy(c), t.push(e);
				} else {
					let e = new G();
					s.lerp(c, i / (i - a), e), t.push(e);
				}
			} else if (a < 0) {
				let e = new G();
				s.lerp(c, i / (i - a), e), t.push(e), t.push(c);
			}
			s = c, i = a;
		}
		return t;
	}
	computeWorldVertices(e, t) {
		for (; this.worldVertices.length < this.vertices.length;) this.worldVertices.push(new G());
		let n = this.vertices, r = this.worldVertices;
		for (let i = 0; i !== this.vertices.length; i++) t.vmult(n[i], r[i]), e.vadd(r[i], r[i]);
		this.worldVerticesNeedsUpdate = !1;
	}
	computeLocalAABB(e, t) {
		let n = this.vertices;
		e.set(Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE), t.set(-Number.MAX_VALUE, -Number.MAX_VALUE, -Number.MAX_VALUE);
		for (let r = 0; r < this.vertices.length; r++) {
			let i = n[r];
			i.x < e.x ? e.x = i.x : i.x > t.x && (t.x = i.x), i.y < e.y ? e.y = i.y : i.y > t.y && (t.y = i.y), i.z < e.z ? e.z = i.z : i.z > t.z && (t.z = i.z);
		}
	}
	computeWorldFaceNormals(e) {
		let t = this.faceNormals.length;
		for (; this.worldFaceNormals.length < t;) this.worldFaceNormals.push(new G());
		let n = this.faceNormals, r = this.worldFaceNormals;
		for (let i = 0; i !== t; i++) e.vmult(n[i], r[i]);
		this.worldFaceNormalsNeedsUpdate = !1;
	}
	updateBoundingSphereRadius() {
		let e = 0, t = this.vertices;
		for (let n = 0; n !== t.length; n++) {
			let r = t[n].lengthSquared();
			r > e && (e = r);
		}
		this.boundingSphereRadius = Math.sqrt(e);
	}
	calculateWorldAABB(e, t, n, r) {
		let i = this.vertices, a, o, s, c, l, u, d = new G();
		for (let n = 0; n < i.length; n++) {
			d.copy(i[n]), t.vmult(d, d), e.vadd(d, d);
			let r = d;
			(a === void 0 || r.x < a) && (a = r.x), (c === void 0 || r.x > c) && (c = r.x), (o === void 0 || r.y < o) && (o = r.y), (l === void 0 || r.y > l) && (l = r.y), (s === void 0 || r.z < s) && (s = r.z), (u === void 0 || r.z > u) && (u = r.z);
		}
		n.set(a, o, s), r.set(c, l, u);
	}
	volume() {
		return 4 * Math.PI * this.boundingSphereRadius / 3;
	}
	getAveragePointLocal(e) {
		e === void 0 && (e = new G());
		let t = this.vertices;
		for (let n = 0; n < t.length; n++) e.vadd(t[n], e);
		return e.scale(1 / t.length, e), e;
	}
	transformAllPoints(e, t) {
		let n = this.vertices.length, r = this.vertices;
		if (t) {
			for (let e = 0; e < n; e++) {
				let n = r[e];
				t.vmult(n, n);
			}
			for (let e = 0; e < this.faceNormals.length; e++) {
				let n = this.faceNormals[e];
				t.vmult(n, n);
			}
		}
		if (e) for (let t = 0; t < n; t++) {
			let n = r[t];
			n.vadd(e, n);
		}
	}
	pointIsInside(e) {
		let t = this.vertices, n = this.faces, r = this.faceNormals, i = new G();
		this.getAveragePointLocal(i);
		for (let a = 0; a < this.faces.length; a++) {
			let o = r[a], s = t[n[a][0]], c = new G();
			e.vsub(s, c);
			let l = o.dot(c), u = new G();
			i.vsub(s, u);
			let d = o.dot(u);
			if (l < 0 && d > 0 || l > 0 && d < 0) return !1;
		}
		return -1;
	}
	static project(e, t, n, r, i) {
		let a = e.vertices.length, o = nf, s = 0, c = 0, l = rf, u = e.vertices;
		l.setZero(), J.vectorToLocalFrame(n, r, t, o), J.pointToLocalFrame(n, r, l, l);
		let d = l.dot(o);
		c = s = u[0].dot(o);
		for (let e = 1; e < a; e++) {
			let t = u[e].dot(o);
			t > s && (s = t), t < c && (c = t);
		}
		if (c -= d, s -= d, c > s) {
			let e = c;
			c = s, s = e;
		}
		i[0] = s, i[1] = c;
	}
}, ef = [], tf = [];
new G();
var nf = new G(), rf = new G(), af = class e extends q {
	constructor(e) {
		super({ type: q.types.BOX }), this.halfExtents = e, this.convexPolyhedronRepresentation = null, this.updateConvexPolyhedronRepresentation(), this.updateBoundingSphereRadius();
	}
	updateConvexPolyhedronRepresentation() {
		let e = this.halfExtents.x, t = this.halfExtents.y, n = this.halfExtents.z, r = G, i = new $d({
			vertices: [
				new r(-e, -t, -n),
				new r(e, -t, -n),
				new r(e, t, -n),
				new r(-e, t, -n),
				new r(-e, -t, n),
				new r(e, -t, n),
				new r(e, t, n),
				new r(-e, t, n)
			],
			faces: [
				[
					3,
					2,
					1,
					0
				],
				[
					4,
					5,
					6,
					7
				],
				[
					5,
					4,
					0,
					1
				],
				[
					2,
					3,
					7,
					6
				],
				[
					0,
					4,
					7,
					3
				],
				[
					1,
					2,
					6,
					5
				]
			],
			axes: [
				new r(0, 0, 1),
				new r(0, 1, 0),
				new r(1, 0, 0)
			]
		});
		this.convexPolyhedronRepresentation = i, i.material = this.material;
	}
	calculateLocalInertia(t, n) {
		return n === void 0 && (n = new G()), e.calculateInertia(this.halfExtents, t, n), n;
	}
	static calculateInertia(e, t, n) {
		let r = e;
		n.x = 1 / 12 * t * (2 * r.y * 2 * r.y + 2 * r.z * 2 * r.z), n.y = 1 / 12 * t * (2 * r.x * 2 * r.x + 2 * r.z * 2 * r.z), n.z = 1 / 12 * t * (2 * r.y * 2 * r.y + 2 * r.x * 2 * r.x);
	}
	getSideNormals(e, t) {
		let n = e, r = this.halfExtents;
		if (n[0].set(r.x, 0, 0), n[1].set(0, r.y, 0), n[2].set(0, 0, r.z), n[3].set(-r.x, 0, 0), n[4].set(0, -r.y, 0), n[5].set(0, 0, -r.z), t !== void 0) for (let e = 0; e !== n.length; e++) t.vmult(n[e], n[e]);
		return n;
	}
	volume() {
		return 8 * this.halfExtents.x * this.halfExtents.y * this.halfExtents.z;
	}
	updateBoundingSphereRadius() {
		this.boundingSphereRadius = this.halfExtents.length();
	}
	forEachWorldCorner(e, t, n) {
		let r = this.halfExtents, i = [
			[
				r.x,
				r.y,
				r.z
			],
			[
				-r.x,
				r.y,
				r.z
			],
			[
				-r.x,
				-r.y,
				r.z
			],
			[
				-r.x,
				-r.y,
				-r.z
			],
			[
				r.x,
				-r.y,
				-r.z
			],
			[
				r.x,
				r.y,
				-r.z
			],
			[
				-r.x,
				r.y,
				-r.z
			],
			[
				r.x,
				-r.y,
				r.z
			]
		];
		for (let r = 0; r < i.length; r++) of.set(i[r][0], i[r][1], i[r][2]), t.vmult(of, of), e.vadd(of, of), n(of.x, of.y, of.z);
	}
	calculateWorldAABB(e, t, n, r) {
		let i = this.halfExtents;
		sf[0].set(i.x, i.y, i.z), sf[1].set(-i.x, i.y, i.z), sf[2].set(-i.x, -i.y, i.z), sf[3].set(-i.x, -i.y, -i.z), sf[4].set(i.x, -i.y, -i.z), sf[5].set(i.x, i.y, -i.z), sf[6].set(-i.x, i.y, -i.z), sf[7].set(i.x, -i.y, i.z);
		let a = sf[0];
		t.vmult(a, a), e.vadd(a, a), r.copy(a), n.copy(a);
		for (let i = 1; i < 8; i++) {
			let a = sf[i];
			t.vmult(a, a), e.vadd(a, a);
			let o = a.x, s = a.y, c = a.z;
			o > r.x && (r.x = o), s > r.y && (r.y = s), c > r.z && (r.z = c), o < n.x && (n.x = o), s < n.y && (n.y = s), c < n.z && (n.z = c);
		}
	}
}, of = new G(), sf = [
	new G(),
	new G(),
	new G(),
	new G(),
	new G(),
	new G(),
	new G(),
	new G()
], cf = {
	DYNAMIC: 1,
	STATIC: 2,
	KINEMATIC: 4
}, lf = {
	AWAKE: 0,
	SLEEPY: 1,
	SLEEPING: 2
}, Y = class e extends Jd {
	constructor(t) {
		t === void 0 && (t = {}), super(), this.id = e.idCounter++, this.index = -1, this.world = null, this.vlambda = new G(), this.collisionFilterGroup = typeof t.collisionFilterGroup == "number" ? t.collisionFilterGroup : 1, this.collisionFilterMask = typeof t.collisionFilterMask == "number" ? t.collisionFilterMask : -1, this.collisionResponse = typeof t.collisionResponse != "boolean" || t.collisionResponse, this.position = new G(), this.previousPosition = new G(), this.interpolatedPosition = new G(), this.initPosition = new G(), t.position && (this.position.copy(t.position), this.previousPosition.copy(t.position), this.interpolatedPosition.copy(t.position), this.initPosition.copy(t.position)), this.velocity = new G(), t.velocity && this.velocity.copy(t.velocity), this.initVelocity = new G(), this.force = new G();
		let n = typeof t.mass == "number" ? t.mass : 0;
		this.mass = n, this.invMass = n > 0 ? 1 / n : 0, this.material = t.material || null, this.linearDamping = typeof t.linearDamping == "number" ? t.linearDamping : .01, this.type = n <= 0 ? e.STATIC : e.DYNAMIC, typeof t.type == typeof e.STATIC && (this.type = t.type), this.allowSleep = t.allowSleep === void 0 || t.allowSleep, this.sleepState = e.AWAKE, this.sleepSpeedLimit = t.sleepSpeedLimit === void 0 ? .1 : t.sleepSpeedLimit, this.sleepTimeLimit = t.sleepTimeLimit === void 0 ? 1 : t.sleepTimeLimit, this.timeLastSleepy = 0, this.wakeUpAfterNarrowphase = !1, this.torque = new G(), this.quaternion = new K(), this.initQuaternion = new K(), this.previousQuaternion = new K(), this.interpolatedQuaternion = new K(), t.quaternion && (this.quaternion.copy(t.quaternion), this.initQuaternion.copy(t.quaternion), this.previousQuaternion.copy(t.quaternion), this.interpolatedQuaternion.copy(t.quaternion)), this.angularVelocity = new G(), t.angularVelocity && this.angularVelocity.copy(t.angularVelocity), this.initAngularVelocity = new G(), this.shapes = [], this.shapeOffsets = [], this.shapeOrientations = [], this.inertia = new G(), this.invInertia = new G(), this.invInertiaWorld = new zd(), this.invMassSolve = 0, this.invInertiaSolve = new G(), this.invInertiaWorldSolve = new zd(), this.fixedRotation = t.fixedRotation !== void 0 && t.fixedRotation, this.angularDamping = t.angularDamping === void 0 ? .01 : t.angularDamping, this.linearFactor = new G(1, 1, 1), t.linearFactor && this.linearFactor.copy(t.linearFactor), this.angularFactor = new G(1, 1, 1), t.angularFactor && this.angularFactor.copy(t.angularFactor), this.aabb = new Wd(), this.aabbNeedsUpdate = !0, this.boundingRadius = 0, this.wlambda = new G(), this.isTrigger = !!t.isTrigger, t.shape && this.addShape(t.shape), this.updateMassProperties();
	}
	wakeUp() {
		let t = this.sleepState;
		this.sleepState = e.AWAKE, this.wakeUpAfterNarrowphase = !1, t === e.SLEEPING && this.dispatchEvent(e.wakeupEvent);
	}
	sleep() {
		this.sleepState = e.SLEEPING, this.velocity.set(0, 0, 0), this.angularVelocity.set(0, 0, 0), this.wakeUpAfterNarrowphase = !1;
	}
	sleepTick(t) {
		if (this.allowSleep) {
			let n = this.sleepState, r = this.velocity.lengthSquared() + this.angularVelocity.lengthSquared(), i = this.sleepSpeedLimit ** 2;
			n === e.AWAKE && r < i ? (this.sleepState = e.SLEEPY, this.timeLastSleepy = t, this.dispatchEvent(e.sleepyEvent)) : n === e.SLEEPY && r > i ? this.wakeUp() : n === e.SLEEPY && t - this.timeLastSleepy > this.sleepTimeLimit && (this.sleep(), this.dispatchEvent(e.sleepEvent));
		}
	}
	updateSolveMassProperties() {
		this.sleepState === e.SLEEPING || this.type === e.KINEMATIC ? (this.invMassSolve = 0, this.invInertiaSolve.setZero(), this.invInertiaWorldSolve.setZero()) : (this.invMassSolve = this.invMass, this.invInertiaSolve.copy(this.invInertia), this.invInertiaWorldSolve.copy(this.invInertiaWorld));
	}
	pointToLocalFrame(e, t) {
		return t === void 0 && (t = new G()), e.vsub(this.position, t), this.quaternion.conjugate().vmult(t, t), t;
	}
	vectorToLocalFrame(e, t) {
		return t === void 0 && (t = new G()), this.quaternion.conjugate().vmult(e, t), t;
	}
	pointToWorldFrame(e, t) {
		return t === void 0 && (t = new G()), this.quaternion.vmult(e, t), t.vadd(this.position, t), t;
	}
	vectorToWorldFrame(e, t) {
		return t === void 0 && (t = new G()), this.quaternion.vmult(e, t), t;
	}
	addShape(e, t, n) {
		let r = new G(), i = new K();
		return t && r.copy(t), n && i.copy(n), this.shapes.push(e), this.shapeOffsets.push(r), this.shapeOrientations.push(i), this.updateMassProperties(), this.updateBoundingRadius(), this.aabbNeedsUpdate = !0, e.body = this, this;
	}
	removeShape(e) {
		let t = this.shapes.indexOf(e);
		return t === -1 ? (console.warn("Shape does not belong to the body"), this) : (this.shapes.splice(t, 1), this.shapeOffsets.splice(t, 1), this.shapeOrientations.splice(t, 1), this.updateMassProperties(), this.updateBoundingRadius(), this.aabbNeedsUpdate = !0, e.body = null, this);
	}
	updateBoundingRadius() {
		let e = this.shapes, t = this.shapeOffsets, n = e.length, r = 0;
		for (let i = 0; i !== n; i++) {
			let n = e[i];
			n.updateBoundingSphereRadius();
			let a = t[i].length(), o = n.boundingSphereRadius;
			a + o > r && (r = a + o);
		}
		this.boundingRadius = r;
	}
	updateAABB() {
		let e = this.shapes, t = this.shapeOffsets, n = this.shapeOrientations, r = e.length, i = uf, a = df, o = this.quaternion, s = this.aabb, c = ff;
		for (let l = 0; l !== r; l++) {
			let r = e[l];
			o.vmult(t[l], i), i.vadd(this.position, i), o.mult(n[l], a), r.calculateWorldAABB(i, a, c.lowerBound, c.upperBound), l === 0 ? s.copy(c) : s.extend(c);
		}
		this.aabbNeedsUpdate = !1;
	}
	updateInertiaWorld(e) {
		let t = this.invInertia;
		if (t.x !== t.y || t.y !== t.z || e) {
			let e = pf, n = mf;
			e.setRotationFromQuaternion(this.quaternion), e.transpose(n), e.scale(t, e), e.mmult(n, this.invInertiaWorld);
		}
	}
	applyForce(t, n) {
		if (n === void 0 && (n = new G()), this.type !== e.DYNAMIC) return;
		this.sleepState === e.SLEEPING && this.wakeUp();
		let r = hf;
		n.cross(t, r), this.force.vadd(t, this.force), this.torque.vadd(r, this.torque);
	}
	applyLocalForce(t, n) {
		if (n === void 0 && (n = new G()), this.type !== e.DYNAMIC) return;
		let r = gf, i = _f;
		this.vectorToWorldFrame(t, r), this.vectorToWorldFrame(n, i), this.applyForce(r, i);
	}
	applyTorque(t) {
		this.type === e.DYNAMIC && (this.sleepState === e.SLEEPING && this.wakeUp(), this.torque.vadd(t, this.torque));
	}
	applyImpulse(t, n) {
		if (n === void 0 && (n = new G()), this.type !== e.DYNAMIC) return;
		this.sleepState === e.SLEEPING && this.wakeUp();
		let r = n, i = vf;
		i.copy(t), i.scale(this.invMass, i), this.velocity.vadd(i, this.velocity);
		let a = yf;
		r.cross(t, a), this.invInertiaWorld.vmult(a, a), this.angularVelocity.vadd(a, this.angularVelocity);
	}
	applyLocalImpulse(t, n) {
		if (n === void 0 && (n = new G()), this.type !== e.DYNAMIC) return;
		let r = bf, i = xf;
		this.vectorToWorldFrame(t, r), this.vectorToWorldFrame(n, i), this.applyImpulse(r, i);
	}
	updateMassProperties() {
		let e = Sf;
		this.invMass = this.mass > 0 ? 1 / this.mass : 0;
		let t = this.inertia, n = this.fixedRotation;
		this.updateAABB(), e.set((this.aabb.upperBound.x - this.aabb.lowerBound.x) / 2, (this.aabb.upperBound.y - this.aabb.lowerBound.y) / 2, (this.aabb.upperBound.z - this.aabb.lowerBound.z) / 2), af.calculateInertia(e, this.mass, t), this.invInertia.set(t.x > 0 && !n ? 1 / t.x : 0, t.y > 0 && !n ? 1 / t.y : 0, t.z > 0 && !n ? 1 / t.z : 0), this.updateInertiaWorld(!0);
	}
	getVelocityAtWorldPoint(e, t) {
		let n = new G();
		return e.vsub(this.position, n), this.angularVelocity.cross(n, t), this.velocity.vadd(t, t), t;
	}
	integrate(t, n, r) {
		if (this.previousPosition.copy(this.position), this.previousQuaternion.copy(this.quaternion), this.type !== e.DYNAMIC && this.type !== e.KINEMATIC || this.sleepState === e.SLEEPING) return;
		let i = this.velocity, a = this.angularVelocity, o = this.position, s = this.force, c = this.torque, l = this.quaternion, u = this.invMass, d = this.invInertiaWorld, f = this.linearFactor, p = u * t;
		i.x += s.x * p * f.x, i.y += s.y * p * f.y, i.z += s.z * p * f.z;
		let m = d.elements, h = this.angularFactor, g = c.x * h.x, _ = c.y * h.y, v = c.z * h.z;
		a.x += t * (m[0] * g + m[1] * _ + m[2] * v), a.y += t * (m[3] * g + m[4] * _ + m[5] * v), a.z += t * (m[6] * g + m[7] * _ + m[8] * v), o.x += i.x * t, o.y += i.y * t, o.z += i.z * t, l.integrate(this.angularVelocity, t, this.angularFactor, l), n && (r ? l.normalizeFast() : l.normalize()), this.aabbNeedsUpdate = !0, this.updateInertiaWorld();
	}
};
Y.idCounter = 0, Y.COLLIDE_EVENT_NAME = "collide", Y.DYNAMIC = cf.DYNAMIC, Y.STATIC = cf.STATIC, Y.KINEMATIC = cf.KINEMATIC, Y.AWAKE = lf.AWAKE, Y.SLEEPY = lf.SLEEPY, Y.SLEEPING = lf.SLEEPING, Y.wakeupEvent = { type: "wakeup" }, Y.sleepyEvent = { type: "sleepy" }, Y.sleepEvent = { type: "sleep" };
var uf = new G(), df = new K(), ff = new Wd(), pf = new zd(), mf = new zd();
new zd();
var hf = new G(), gf = new G(), _f = new G(), vf = new G(), yf = new G(), bf = new G(), xf = new G(), Sf = new G(), Cf = class {
	constructor() {
		this.world = null, this.useBoundingBoxes = !1, this.dirty = !0;
	}
	collisionPairs(e, t, n) {
		throw Error("collisionPairs not implemented for this BroadPhase class!");
	}
	needBroadphaseCollision(e, t) {
		return (e.collisionFilterGroup & t.collisionFilterMask) !== 0 && (t.collisionFilterGroup & e.collisionFilterMask) !== 0 && ((e.type & Y.STATIC) === 0 && e.sleepState !== Y.SLEEPING || (t.type & Y.STATIC) === 0 && t.sleepState !== Y.SLEEPING);
	}
	intersectionTest(e, t, n, r) {
		this.useBoundingBoxes ? this.doBoundingBoxBroadphase(e, t, n, r) : this.doBoundingSphereBroadphase(e, t, n, r);
	}
	doBoundingSphereBroadphase(e, t, n, r) {
		let i = wf;
		t.position.vsub(e.position, i);
		let a = (e.boundingRadius + t.boundingRadius) ** 2;
		i.lengthSquared() < a && (n.push(e), r.push(t));
	}
	doBoundingBoxBroadphase(e, t, n, r) {
		e.aabbNeedsUpdate && e.updateAABB(), t.aabbNeedsUpdate && t.updateAABB(), e.aabb.overlaps(t.aabb) && (n.push(e), r.push(t));
	}
	makePairsUnique(e, t) {
		let n = Tf, r = Ef, i = Df, a = e.length;
		for (let n = 0; n !== a; n++) r[n] = e[n], i[n] = t[n];
		e.length = 0, t.length = 0;
		for (let e = 0; e !== a; e++) {
			let t = r[e].id, a = i[e].id, o = t < a ? `${t},${a}` : `${a},${t}`;
			n[o] = e, n.keys.push(o);
		}
		for (let a = 0; a !== n.keys.length; a++) {
			let a = n.keys.pop(), o = n[a];
			e.push(r[o]), t.push(i[o]), delete n[a];
		}
	}
	setWorld(e) {}
	static boundingSphereCheck(e, t) {
		let n = new G();
		e.position.vsub(t.position, n);
		let r = e.shapes[0], i = t.shapes[0];
		return (r.boundingSphereRadius + i.boundingSphereRadius) ** 2 > n.lengthSquared();
	}
	aabbQuery(e, t, n) {
		return console.warn(".aabbQuery is not implemented in this Broadphase subclass."), [];
	}
}, wf = new G();
new G(), new K(), new G();
var Tf = { keys: [] }, Ef = [], Df = [];
new G(), new G(), new G();
var Of = class extends Cf {
	constructor() {
		super();
	}
	collisionPairs(e, t, n) {
		let r = e.bodies, i = r.length, a, o;
		for (let e = 0; e !== i; e++) for (let i = 0; i !== e; i++) a = r[e], o = r[i], this.needBroadphaseCollision(a, o) && this.intersectionTest(a, o, t, n);
	}
	aabbQuery(e, t, n) {
		n === void 0 && (n = []);
		for (let r = 0; r < e.bodies.length; r++) {
			let i = e.bodies[r];
			i.aabbNeedsUpdate && i.updateAABB(), i.aabb.overlaps(t) && n.push(i);
		}
		return n;
	}
}, kf = class {
	constructor() {
		this.rayFromWorld = new G(), this.rayToWorld = new G(), this.hitNormalWorld = new G(), this.hitPointWorld = new G(), this.hasHit = !1, this.shape = null, this.body = null, this.hitFaceIndex = -1, this.distance = -1, this.shouldStop = !1;
	}
	reset() {
		this.rayFromWorld.setZero(), this.rayToWorld.setZero(), this.hitNormalWorld.setZero(), this.hitPointWorld.setZero(), this.hasHit = !1, this.shape = null, this.body = null, this.hitFaceIndex = -1, this.distance = -1, this.shouldStop = !1;
	}
	abort() {
		this.shouldStop = !0;
	}
	set(e, t, n, r, i, a, o) {
		this.rayFromWorld.copy(e), this.rayToWorld.copy(t), this.hitNormalWorld.copy(n), this.hitPointWorld.copy(r), this.shape = i, this.body = a, this.distance = o;
	}
}, Af, jf, Mf, Nf, Pf, Ff, If, Lf = {
	CLOSEST: 1,
	ANY: 2,
	ALL: 4
};
Af = q.types.SPHERE, jf = q.types.PLANE, Mf = q.types.BOX, Nf = q.types.CYLINDER, Pf = q.types.CONVEXPOLYHEDRON, Ff = q.types.HEIGHTFIELD, If = q.types.TRIMESH;
var Rf = class e {
	get [Af]() {
		return this._intersectSphere;
	}
	get [jf]() {
		return this._intersectPlane;
	}
	get [Mf]() {
		return this._intersectBox;
	}
	get [Nf]() {
		return this._intersectConvex;
	}
	get [Pf]() {
		return this._intersectConvex;
	}
	get [Ff]() {
		return this._intersectHeightfield;
	}
	get [If]() {
		return this._intersectTrimesh;
	}
	constructor(t, n) {
		t === void 0 && (t = new G()), n === void 0 && (n = new G()), this.from = t.clone(), this.to = n.clone(), this.direction = new G(), this.precision = 1e-4, this.checkCollisionResponse = !0, this.skipBackfaces = !1, this.collisionFilterMask = -1, this.collisionFilterGroup = -1, this.mode = e.ANY, this.result = new kf(), this.hasHit = !1, this.callback = (e) => {};
	}
	intersectWorld(t, n) {
		return this.mode = n.mode || e.ANY, this.result = n.result || new kf(), this.skipBackfaces = !!n.skipBackfaces, this.collisionFilterMask = n.collisionFilterMask === void 0 ? -1 : n.collisionFilterMask, this.collisionFilterGroup = n.collisionFilterGroup === void 0 ? -1 : n.collisionFilterGroup, this.checkCollisionResponse = n.checkCollisionResponse === void 0 || n.checkCollisionResponse, n.from && this.from.copy(n.from), n.to && this.to.copy(n.to), this.callback = n.callback || (() => {}), this.hasHit = !1, this.result.reset(), this.updateDirection(), this.getAABB(zf), Bf.length = 0, t.broadphase.aabbQuery(t, zf, Bf), this.intersectBodies(Bf), this.hasHit;
	}
	intersectBody(e, t) {
		t && (this.result = t, this.updateDirection());
		let n = this.checkCollisionResponse;
		if (n && !e.collisionResponse || (this.collisionFilterGroup & e.collisionFilterMask) === 0 || (e.collisionFilterGroup & this.collisionFilterMask) === 0) return;
		let r = Uf, i = Wf;
		for (let t = 0, a = e.shapes.length; t < a; t++) {
			let a = e.shapes[t];
			if ((!n || a.collisionResponse) && (e.quaternion.mult(e.shapeOrientations[t], i), e.quaternion.vmult(e.shapeOffsets[t], r), r.vadd(e.position, r), this.intersectShape(a, i, r, e), this.result.shouldStop)) break;
		}
	}
	intersectBodies(e, t) {
		t && (this.result = t, this.updateDirection());
		for (let t = 0, n = e.length; !this.result.shouldStop && t < n; t++) this.intersectBody(e[t]);
	}
	updateDirection() {
		this.to.vsub(this.from, this.direction), this.direction.normalize();
	}
	intersectShape(e, t, n, r) {
		let i = this.from;
		if (fp(i, this.direction, n) > e.boundingSphereRadius) return;
		let a = this[e.type];
		a && a.call(this, e, t, n, r, e);
	}
	_intersectBox(e, t, n, r, i) {
		return this._intersectConvex(e.convexPolyhedronRepresentation, t, n, r, i);
	}
	_intersectPlane(e, t, n, r, i) {
		let a = this.from, o = this.to, s = this.direction, c = new G(0, 0, 1);
		t.vmult(c, c);
		let l = new G();
		a.vsub(n, l);
		let u = l.dot(c);
		if (o.vsub(n, l), u * l.dot(c) > 0 || a.distanceTo(o) < u) return;
		let d = c.dot(s);
		if (Math.abs(d) < this.precision) return;
		let f = new G(), p = new G(), m = new G();
		a.vsub(n, f);
		let h = -c.dot(f) / d;
		s.scale(h, p), a.vadd(p, m), this.reportIntersection(c, m, i, r, -1);
	}
	getAABB(e) {
		let { lowerBound: t, upperBound: n } = e, r = this.to, i = this.from;
		t.x = Math.min(r.x, i.x), t.y = Math.min(r.y, i.y), t.z = Math.min(r.z, i.z), n.x = Math.max(r.x, i.x), n.y = Math.max(r.y, i.y), n.z = Math.max(r.z, i.z);
	}
	_intersectHeightfield(e, t, n, r, i) {
		e.data, e.elementSize;
		let a = Xf;
		a.from.copy(this.from), a.to.copy(this.to), J.pointToLocalFrame(n, t, a.from, a.from), J.pointToLocalFrame(n, t, a.to, a.to), a.updateDirection();
		let o = Zf, s, c, l, u;
		s = c = 0, l = u = e.data.length - 1;
		let d = new Wd();
		a.getAABB(d), e.getIndexOfPosition(d.lowerBound.x, d.lowerBound.y, o, !0), s = Math.max(s, o[0]), c = Math.max(c, o[1]), e.getIndexOfPosition(d.upperBound.x, d.upperBound.y, o, !0), l = Math.min(l, o[0] + 1), u = Math.min(u, o[1] + 1);
		for (let o = s; o < l; o++) for (let s = c; s < u; s++) {
			if (this.result.shouldStop) return;
			if (e.getAabbAtIndex(o, s, d), d.overlapsRay(a)) {
				if (e.getConvexTrianglePillar(o, s, !1), J.pointToWorldFrame(n, t, e.pillarOffset, Yf), this._intersectConvex(e.pillarConvex, t, Yf, r, i, Jf), this.result.shouldStop) return;
				e.getConvexTrianglePillar(o, s, !0), J.pointToWorldFrame(n, t, e.pillarOffset, Yf), this._intersectConvex(e.pillarConvex, t, Yf, r, i, Jf);
			}
		}
	}
	_intersectSphere(e, t, n, r, i) {
		let a = this.from, o = this.to, s = e.radius, c = (o.x - a.x) ** 2 + (o.y - a.y) ** 2 + (o.z - a.z) ** 2, l = 2 * ((o.x - a.x) * (a.x - n.x) + (o.y - a.y) * (a.y - n.y) + (o.z - a.z) * (a.z - n.z)), u = (a.x - n.x) ** 2 + (a.y - n.y) ** 2 + (a.z - n.z) ** 2 - s ** 2, d = l ** 2 - 4 * c * u, f = Qf, p = $f;
		if (!(d < 0)) {
			if (d === 0) a.lerp(o, d, f), f.vsub(n, p), p.normalize(), this.reportIntersection(p, f, i, r, -1);
			else {
				let e = (-l - Math.sqrt(d)) / (2 * c), t = (-l + Math.sqrt(d)) / (2 * c);
				if (e >= 0 && e <= 1 && (a.lerp(o, e, f), f.vsub(n, p), p.normalize(), this.reportIntersection(p, f, i, r, -1)), this.result.shouldStop) return;
				t >= 0 && t <= 1 && (a.lerp(o, t, f), f.vsub(n, p), p.normalize(), this.reportIntersection(p, f, i, r, -1));
			}
		}
	}
	_intersectConvex(t, n, r, i, a, o) {
		let s = ep, c = tp, l = o && o.faceList || null, u = t.faces, d = t.vertices, f = t.faceNormals, p = this.direction, m = this.from, h = this.to, g = m.distanceTo(h), _ = l ? l.length : u.length, v = this.result;
		for (let t = 0; !v.shouldStop && t < _; t++) {
			let o = l ? l[t] : t, h = u[o], _ = f[o], y = n, b = r;
			c.copy(d[h[0]]), y.vmult(c, c), c.vadd(b, c), c.vsub(m, c), y.vmult(_, s);
			let x = p.dot(s);
			if (Math.abs(x) < this.precision) continue;
			let S = s.dot(c) / x;
			if (!(S < 0)) {
				p.scale(S, X), X.vadd(m, X), Gf.copy(d[h[0]]), y.vmult(Gf, Gf), b.vadd(Gf, Gf);
				for (let t = 1; !v.shouldStop && t < h.length - 1; t++) {
					Kf.copy(d[h[t]]), qf.copy(d[h[t + 1]]), y.vmult(Kf, Kf), y.vmult(qf, qf), b.vadd(Kf, Kf), b.vadd(qf, qf);
					let n = X.distanceTo(m);
					!(e.pointInTriangle(X, Gf, Kf, qf) || e.pointInTriangle(X, Kf, Gf, qf)) || n > g || this.reportIntersection(s, X, a, i, o);
				}
			}
		}
	}
	_intersectTrimesh(t, n, r, i, a, o) {
		let s = np, c = cp, l = lp, u = tp, d = rp, f = ip, p = ap, m = sp, h = op, g = t.indices;
		t.vertices;
		let _ = this.from, v = this.to, y = this.direction;
		l.position.copy(r), l.quaternion.copy(n), J.vectorToLocalFrame(r, n, y, d), J.pointToLocalFrame(r, n, _, f), J.pointToLocalFrame(r, n, v, p), p.x *= t.scale.x, p.y *= t.scale.y, p.z *= t.scale.z, f.x *= t.scale.x, f.y *= t.scale.y, f.z *= t.scale.z, p.vsub(f, d), d.normalize();
		let b = f.distanceSquared(p);
		t.tree.rayQuery(this, l, c);
		for (let o = 0, l = c.length; !this.result.shouldStop && o !== l; o++) {
			let l = c[o];
			t.getNormal(l, s), t.getVertex(g[l * 3], Gf), Gf.vsub(f, u);
			let p = d.dot(s), _ = s.dot(u) / p;
			if (_ < 0) continue;
			d.scale(_, X), X.vadd(f, X), t.getVertex(g[l * 3 + 1], Kf), t.getVertex(g[l * 3 + 2], qf);
			let v = X.distanceSquared(f);
			!(e.pointInTriangle(X, Kf, Gf, qf) || e.pointInTriangle(X, Gf, Kf, qf)) || v > b || (J.vectorToWorldFrame(n, s, h), J.pointToWorldFrame(r, n, X, m), this.reportIntersection(h, m, a, i, l));
		}
		c.length = 0;
	}
	reportIntersection(t, n, r, i, a) {
		let o = this.from, s = this.to, c = o.distanceTo(n), l = this.result;
		if (!(this.skipBackfaces && t.dot(this.direction) > 0)) switch (l.hitFaceIndex = a === void 0 ? -1 : a, this.mode) {
			case e.ALL:
				this.hasHit = !0, l.set(o, s, t, n, r, i, c), l.hasHit = !0, this.callback(l);
				break;
			case e.CLOSEST:
				(c < l.distance || !l.hasHit) && (this.hasHit = !0, l.hasHit = !0, l.set(o, s, t, n, r, i, c));
				break;
			case e.ANY: this.hasHit = !0, l.hasHit = !0, l.set(o, s, t, n, r, i, c), l.shouldStop = !0;
		}
	}
	static pointInTriangle(e, t, n, r) {
		r.vsub(t, up), n.vsub(t, Vf), e.vsub(t, Hf);
		let i = up.dot(up), a = up.dot(Vf), o = up.dot(Hf), s = Vf.dot(Vf), c = Vf.dot(Hf), l, u;
		return (l = s * o - a * c) >= 0 && (u = i * c - a * o) >= 0 && l + u < i * s - a * a;
	}
};
Rf.CLOSEST = Lf.CLOSEST, Rf.ANY = Lf.ANY, Rf.ALL = Lf.ALL;
var zf = new Wd(), Bf = [], Vf = new G(), Hf = new G(), Uf = new G(), Wf = new K(), X = new G(), Gf = new G(), Kf = new G(), qf = new G();
new G(), new kf();
var Jf = { faceList: [0] }, Yf = new G(), Xf = new Rf(), Zf = [], Qf = new G(), $f = new G(), ep = new G();
new G(), new G();
var tp = new G(), np = new G(), rp = new G(), ip = new G(), ap = new G(), op = new G(), sp = new G();
new Wd();
var cp = [], lp = new J(), up = new G(), dp = new G();
function fp(e, t, n) {
	n.vsub(e, up);
	let r = up.dot(t);
	return t.scale(r, dp), dp.vadd(e, dp), n.distanceTo(dp);
}
var pp = class {
	static defaults(e, t) {
		e === void 0 && (e = {});
		for (let n in t) n in e || (e[n] = t[n]);
		return e;
	}
}, mp = class {
	constructor() {
		this.spatial = new G(), this.rotational = new G();
	}
	multiplyElement(e) {
		return e.spatial.dot(this.spatial) + e.rotational.dot(this.rotational);
	}
	multiplyVectors(e, t) {
		return e.dot(this.spatial) + t.dot(this.rotational);
	}
}, hp = class e {
	constructor(t, n, r, i) {
		r === void 0 && (r = -1e6), i === void 0 && (i = 1e6), this.id = e.idCounter++, this.minForce = r, this.maxForce = i, this.bi = t, this.bj = n, this.a = 0, this.b = 0, this.eps = 0, this.jacobianElementA = new mp(), this.jacobianElementB = new mp(), this.enabled = !0, this.multiplier = 0, this.setSpookParams(1e7, 4, 1 / 60);
	}
	setSpookParams(e, t, n) {
		let r = t, i = e, a = n;
		this.a = 4 / (a * (1 + 4 * r)), this.b = 4 * r / (1 + 4 * r), this.eps = 4 / (a * a * i * (1 + 4 * r));
	}
	computeB(e, t, n) {
		let r = this.computeGW(), i = this.computeGq(), a = this.computeGiMf();
		return -i * e - r * t - a * n;
	}
	computeGq() {
		let e = this.jacobianElementA, t = this.jacobianElementB, n = this.bi, r = this.bj, i = n.position, a = r.position;
		return e.spatial.dot(i) + t.spatial.dot(a);
	}
	computeGW() {
		let e = this.jacobianElementA, t = this.jacobianElementB, n = this.bi, r = this.bj, i = n.velocity, a = r.velocity, o = n.angularVelocity, s = r.angularVelocity;
		return e.multiplyVectors(i, o) + t.multiplyVectors(a, s);
	}
	computeGWlambda() {
		let e = this.jacobianElementA, t = this.jacobianElementB, n = this.bi, r = this.bj, i = n.vlambda, a = r.vlambda, o = n.wlambda, s = r.wlambda;
		return e.multiplyVectors(i, o) + t.multiplyVectors(a, s);
	}
	computeGiMf() {
		let e = this.jacobianElementA, t = this.jacobianElementB, n = this.bi, r = this.bj, i = n.force, a = n.torque, o = r.force, s = r.torque, c = n.invMassSolve, l = r.invMassSolve;
		return i.scale(c, gp), o.scale(l, _p), n.invInertiaWorldSolve.vmult(a, vp), r.invInertiaWorldSolve.vmult(s, yp), e.multiplyVectors(gp, vp) + t.multiplyVectors(_p, yp);
	}
	computeGiMGt() {
		let e = this.jacobianElementA, t = this.jacobianElementB, n = this.bi, r = this.bj, i = n.invMassSolve, a = r.invMassSolve, o = n.invInertiaWorldSolve, s = r.invInertiaWorldSolve, c = i + a;
		return o.vmult(e.rotational, bp), c += bp.dot(e.rotational), s.vmult(t.rotational, bp), c += bp.dot(t.rotational), c;
	}
	addToWlambda(e) {
		let t = this.jacobianElementA, n = this.jacobianElementB, r = this.bi, i = this.bj, a = xp;
		r.vlambda.addScaledVector(r.invMassSolve * e, t.spatial, r.vlambda), i.vlambda.addScaledVector(i.invMassSolve * e, n.spatial, i.vlambda), r.invInertiaWorldSolve.vmult(t.rotational, a), r.wlambda.addScaledVector(e, a, r.wlambda), i.invInertiaWorldSolve.vmult(n.rotational, a), i.wlambda.addScaledVector(e, a, i.wlambda);
	}
	computeC() {
		return this.computeGiMGt() + this.eps;
	}
};
hp.idCounter = 0;
var gp = new G(), _p = new G(), vp = new G(), yp = new G(), bp = new G(), xp = new G(), Sp = class extends hp {
	constructor(e, t, n) {
		n === void 0 && (n = 1e6), super(e, t, 0, n), this.restitution = 0, this.ri = new G(), this.rj = new G(), this.ni = new G();
	}
	computeB(e) {
		let t = this.a, n = this.b, r = this.bi, i = this.bj, a = this.ri, o = this.rj, s = Cp, c = wp, l = r.velocity, u = r.angularVelocity;
		r.force, r.torque;
		let d = i.velocity, f = i.angularVelocity;
		i.force, i.torque;
		let p = Tp, m = this.jacobianElementA, h = this.jacobianElementB, g = this.ni;
		a.cross(g, s), o.cross(g, c), g.negate(m.spatial), s.negate(m.rotational), h.spatial.copy(g), h.rotational.copy(c), p.copy(i.position), p.vadd(o, p), p.vsub(r.position, p), p.vsub(a, p);
		let _ = g.dot(p), v = this.restitution + 1, y = v * d.dot(g) - v * l.dot(g) + f.dot(c) - u.dot(s), b = this.computeGiMf();
		return -_ * t - y * n - e * b;
	}
	getImpactVelocityAlongNormal() {
		let e = Ep, t = Dp, n = Op, r = kp, i = Ap;
		return this.bi.position.vadd(this.ri, n), this.bj.position.vadd(this.rj, r), this.bi.getVelocityAtWorldPoint(n, e), this.bj.getVelocityAtWorldPoint(r, t), e.vsub(t, i), this.ni.dot(i);
	}
}, Cp = new G(), wp = new G(), Tp = new G(), Ep = new G(), Dp = new G(), Op = new G(), kp = new G(), Ap = new G();
new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G();
var jp = class extends hp {
	constructor(e, t, n) {
		super(e, t, -n, n), this.ri = new G(), this.rj = new G(), this.t = new G();
	}
	computeB(e) {
		this.a;
		let t = this.b;
		this.bi, this.bj;
		let n = this.ri, r = this.rj, i = Mp, a = Np, o = this.t;
		n.cross(o, i), r.cross(o, a);
		let s = this.jacobianElementA, c = this.jacobianElementB;
		o.negate(s.spatial), i.negate(s.rotational), c.spatial.copy(o), c.rotational.copy(a);
		let l = this.computeGW(), u = this.computeGiMf();
		return -l * t - e * u;
	}
}, Mp = new G(), Np = new G(), Pp = class e {
	constructor(t, n, r) {
		r = pp.defaults(r, {
			friction: .3,
			restitution: .3,
			contactEquationStiffness: 1e7,
			contactEquationRelaxation: 3,
			frictionEquationStiffness: 1e7,
			frictionEquationRelaxation: 3
		}), this.id = e.idCounter++, this.materials = [t, n], this.friction = r.friction, this.restitution = r.restitution, this.contactEquationStiffness = r.contactEquationStiffness, this.contactEquationRelaxation = r.contactEquationRelaxation, this.frictionEquationStiffness = r.frictionEquationStiffness, this.frictionEquationRelaxation = r.frictionEquationRelaxation;
	}
};
Pp.idCounter = 0;
var Fp = class e {
	constructor(t) {
		t === void 0 && (t = {});
		let n = "";
		typeof t == "string" && (n = t, t = {}), this.name = n, this.id = e.idCounter++, this.friction = t.friction === void 0 ? -1 : t.friction, this.restitution = t.restitution === void 0 ? -1 : t.restitution;
	}
};
Fp.idCounter = 0, new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new Rf(), new G(), new G(), new G(), new G(1, 0, 0), new G(0, 1, 0), new G(0, 0, 1), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G();
var Ip = class extends q {
	constructor(e) {
		if (super({ type: q.types.SPHERE }), this.radius = e === void 0 ? 1 : e, this.radius < 0) throw Error("The sphere radius cannot be negative.");
		this.updateBoundingSphereRadius();
	}
	calculateLocalInertia(e, t) {
		t === void 0 && (t = new G());
		let n = 2 * e * this.radius * this.radius / 5;
		return t.x = n, t.y = n, t.z = n, t;
	}
	volume() {
		return 4 * Math.PI * this.radius ** 3 / 3;
	}
	updateBoundingSphereRadius() {
		this.boundingSphereRadius = this.radius;
	}
	calculateWorldAABB(e, t, n, r) {
		let i = this.radius, a = [
			"x",
			"y",
			"z"
		];
		for (let t = 0; t < a.length; t++) {
			let o = a[t];
			n[o] = e[o] - i, r[o] = e[o] + i;
		}
	}
};
new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G();
var Lp = class extends q {
	constructor() {
		super({ type: q.types.PLANE }), this.worldNormal = new G(), this.worldNormalNeedsUpdate = !0, this.boundingSphereRadius = Number.MAX_VALUE;
	}
	computeWorldNormal(e) {
		let t = this.worldNormal;
		t.set(0, 0, 1), e.vmult(t, t), this.worldNormalNeedsUpdate = !1;
	}
	calculateLocalInertia(e, t) {
		return t === void 0 && (t = new G()), t;
	}
	volume() {
		return Number.MAX_VALUE;
	}
	calculateWorldAABB(e, t, n, r) {
		Rp.set(0, 0, 1), t.vmult(Rp, Rp);
		let i = Number.MAX_VALUE;
		n.set(-i, -i, -i), r.set(i, i, i), Rp.x === 1 ? r.x = e.x : Rp.x === -1 && (n.x = e.x), Rp.y === 1 ? r.y = e.y : Rp.y === -1 && (n.y = e.y), Rp.z === 1 ? r.z = e.z : Rp.z === -1 && (n.z = e.z);
	}
	updateBoundingSphereRadius() {
		this.boundingSphereRadius = Number.MAX_VALUE;
	}
}, Rp = new G();
new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new Wd(), new G(), new Wd(), new G(), new G(), new G(), new G(), new G(), new G(), new G(), new Wd(), new G(), new J(), new Wd();
var zp = class {
	constructor() {
		this.equations = [];
	}
	solve(e, t) {
		return 0;
	}
	addEquation(e) {
		e.enabled && !e.bi.isTrigger && !e.bj.isTrigger && this.equations.push(e);
	}
	removeEquation(e) {
		let t = this.equations, n = t.indexOf(e);
		n !== -1 && t.splice(n, 1);
	}
	removeAllEquations() {
		this.equations.length = 0;
	}
}, Bp = class extends zp {
	constructor() {
		super(), this.iterations = 10, this.tolerance = 1e-7;
	}
	solve(e, t) {
		let n = 0, r = this.iterations, i = this.tolerance * this.tolerance, a = this.equations, o = a.length, s = t.bodies, c = s.length, l = e, u, d, f, p, m, h;
		if (o !== 0) for (let e = 0; e !== c; e++) s[e].updateSolveMassProperties();
		let g = Hp, _ = Up, v = Vp;
		g.length = o, _.length = o, v.length = o;
		for (let e = 0; e !== o; e++) {
			let t = a[e];
			v[e] = 0, _[e] = t.computeB(l), g[e] = 1 / t.computeC();
		}
		if (o !== 0) {
			for (let e = 0; e !== c; e++) {
				let t = s[e], n = t.vlambda, r = t.wlambda;
				n.set(0, 0, 0), r.set(0, 0, 0);
			}
			for (n = 0; n !== r; n++) {
				p = 0;
				for (let e = 0; e !== o; e++) {
					let t = a[e];
					u = _[e], d = g[e], h = v[e], m = t.computeGWlambda(), f = d * (u - m - t.eps * h), h + f < t.minForce ? f = t.minForce - h : h + f > t.maxForce && (f = t.maxForce - h), v[e] += f, p += f > 0 ? f : -f, t.addToWlambda(f);
				}
				if (p * p < i) break;
			}
			for (let e = 0; e !== c; e++) {
				let t = s[e], n = t.velocity, r = t.angularVelocity;
				t.vlambda.vmul(t.linearFactor, t.vlambda), n.vadd(t.vlambda, n), t.wlambda.vmul(t.angularFactor, t.wlambda), r.vadd(t.wlambda, r);
			}
			let e = a.length, t = 1 / l;
			for (; e--;) a[e].multiplier = v[e] * t;
		}
		return n;
	}
}, Vp = [], Hp = [], Up = [];
Y.STATIC;
var Wp = class {
	constructor() {
		this.objects = [], this.type = Object;
	}
	release() {
		let e = arguments.length;
		for (let t = 0; t !== e; t++) this.objects.push(t < 0 || arguments.length <= t ? void 0 : arguments[t]);
		return this;
	}
	get() {
		return this.objects.length === 0 ? this.constructObject() : this.objects.pop();
	}
	constructObject() {
		throw Error("constructObject() not implemented in this Pool subclass yet!");
	}
	resize(e) {
		let t = this.objects;
		for (; t.length > e;) t.pop();
		for (; t.length < e;) t.push(this.constructObject());
		return this;
	}
}, Gp = class extends Wp {
	constructor() {
		super(...arguments), this.type = G;
	}
	constructObject() {
		return new G();
	}
}, Z = {
	sphereSphere: q.types.SPHERE,
	spherePlane: q.types.SPHERE | q.types.PLANE,
	boxBox: q.types.BOX | q.types.BOX,
	sphereBox: q.types.SPHERE | q.types.BOX,
	planeBox: q.types.PLANE | q.types.BOX,
	convexConvex: q.types.CONVEXPOLYHEDRON,
	sphereConvex: q.types.SPHERE | q.types.CONVEXPOLYHEDRON,
	planeConvex: q.types.PLANE | q.types.CONVEXPOLYHEDRON,
	boxConvex: q.types.BOX | q.types.CONVEXPOLYHEDRON,
	sphereHeightfield: q.types.SPHERE | q.types.HEIGHTFIELD,
	boxHeightfield: q.types.BOX | q.types.HEIGHTFIELD,
	convexHeightfield: q.types.CONVEXPOLYHEDRON | q.types.HEIGHTFIELD,
	sphereParticle: q.types.PARTICLE | q.types.SPHERE,
	planeParticle: q.types.PLANE | q.types.PARTICLE,
	boxParticle: q.types.BOX | q.types.PARTICLE,
	convexParticle: q.types.PARTICLE | q.types.CONVEXPOLYHEDRON,
	cylinderCylinder: q.types.CYLINDER,
	sphereCylinder: q.types.SPHERE | q.types.CYLINDER,
	planeCylinder: q.types.PLANE | q.types.CYLINDER,
	boxCylinder: q.types.BOX | q.types.CYLINDER,
	convexCylinder: q.types.CONVEXPOLYHEDRON | q.types.CYLINDER,
	heightfieldCylinder: q.types.HEIGHTFIELD | q.types.CYLINDER,
	particleCylinder: q.types.PARTICLE | q.types.CYLINDER,
	sphereTrimesh: q.types.SPHERE | q.types.TRIMESH,
	planeTrimesh: q.types.PLANE | q.types.TRIMESH
}, Kp = class {
	get [Z.sphereSphere]() {
		return this.sphereSphere;
	}
	get [Z.spherePlane]() {
		return this.spherePlane;
	}
	get [Z.boxBox]() {
		return this.boxBox;
	}
	get [Z.sphereBox]() {
		return this.sphereBox;
	}
	get [Z.planeBox]() {
		return this.planeBox;
	}
	get [Z.convexConvex]() {
		return this.convexConvex;
	}
	get [Z.sphereConvex]() {
		return this.sphereConvex;
	}
	get [Z.planeConvex]() {
		return this.planeConvex;
	}
	get [Z.boxConvex]() {
		return this.boxConvex;
	}
	get [Z.sphereHeightfield]() {
		return this.sphereHeightfield;
	}
	get [Z.boxHeightfield]() {
		return this.boxHeightfield;
	}
	get [Z.convexHeightfield]() {
		return this.convexHeightfield;
	}
	get [Z.sphereParticle]() {
		return this.sphereParticle;
	}
	get [Z.planeParticle]() {
		return this.planeParticle;
	}
	get [Z.boxParticle]() {
		return this.boxParticle;
	}
	get [Z.convexParticle]() {
		return this.convexParticle;
	}
	get [Z.cylinderCylinder]() {
		return this.convexConvex;
	}
	get [Z.sphereCylinder]() {
		return this.sphereConvex;
	}
	get [Z.planeCylinder]() {
		return this.planeConvex;
	}
	get [Z.boxCylinder]() {
		return this.boxConvex;
	}
	get [Z.convexCylinder]() {
		return this.convexConvex;
	}
	get [Z.heightfieldCylinder]() {
		return this.heightfieldCylinder;
	}
	get [Z.particleCylinder]() {
		return this.particleCylinder;
	}
	get [Z.sphereTrimesh]() {
		return this.sphereTrimesh;
	}
	get [Z.planeTrimesh]() {
		return this.planeTrimesh;
	}
	constructor(e) {
		this.contactPointPool = [], this.frictionEquationPool = [], this.result = [], this.frictionResult = [], this.v3pool = new Gp(), this.world = e, this.currentContactMaterial = e.defaultContactMaterial, this.enableFrictionReduction = !1;
	}
	createContactEquation(e, t, n, r, i, a) {
		let o;
		this.contactPointPool.length ? (o = this.contactPointPool.pop(), o.bi = e, o.bj = t) : o = new Sp(e, t), o.enabled = e.collisionResponse && t.collisionResponse && n.collisionResponse && r.collisionResponse;
		let s = this.currentContactMaterial;
		o.restitution = s.restitution, o.setSpookParams(s.contactEquationStiffness, s.contactEquationRelaxation, this.world.dt);
		let c = n.material || e.material, l = r.material || t.material;
		return c && l && c.restitution >= 0 && l.restitution >= 0 && (o.restitution = c.restitution * l.restitution), o.si = i || n, o.sj = a || r, o;
	}
	createFrictionEquationsFromContact(e, t) {
		let n = e.bi, r = e.bj, i = e.si, a = e.sj, o = this.world, s = this.currentContactMaterial, c = s.friction, l = i.material || n.material, u = a.material || r.material;
		if (l && u && l.friction >= 0 && u.friction >= 0 && (c = l.friction * u.friction), c > 0) {
			let i = c * (o.frictionGravity || o.gravity).length(), a = n.invMass + r.invMass;
			a > 0 && (a = 1 / a);
			let l = this.frictionEquationPool, u = l.length ? l.pop() : new jp(n, r, i * a), d = l.length ? l.pop() : new jp(n, r, i * a);
			return u.bi = d.bi = n, u.bj = d.bj = r, u.minForce = d.minForce = -i * a, u.maxForce = d.maxForce = i * a, u.ri.copy(e.ri), u.rj.copy(e.rj), d.ri.copy(e.ri), d.rj.copy(e.rj), e.ni.tangents(u.t, d.t), u.setSpookParams(s.frictionEquationStiffness, s.frictionEquationRelaxation, o.dt), d.setSpookParams(s.frictionEquationStiffness, s.frictionEquationRelaxation, o.dt), u.enabled = d.enabled = e.enabled, t.push(u, d), !0;
		}
		return !1;
	}
	createFrictionFromAverage(e) {
		let t = this.result[this.result.length - 1];
		if (!this.createFrictionEquationsFromContact(t, this.frictionResult) || e === 1) return;
		let n = this.frictionResult[this.frictionResult.length - 2], r = this.frictionResult[this.frictionResult.length - 1];
		qp.setZero(), Jp.setZero(), Yp.setZero();
		let i = t.bi;
		t.bj;
		for (let n = 0; n !== e; n++) t = this.result[this.result.length - 1 - n], t.bi === i ? (qp.vsub(t.ni, qp), Jp.vadd(t.rj, Jp), Yp.vadd(t.ri, Yp)) : (qp.vadd(t.ni, qp), Jp.vadd(t.ri, Jp), Yp.vadd(t.rj, Yp));
		let a = 1 / e;
		Jp.scale(a, n.ri), Yp.scale(a, n.rj), r.ri.copy(n.ri), r.rj.copy(n.rj), qp.normalize(), qp.tangents(n.t, r.t);
	}
	getContacts(e, t, n, r, i, a, o) {
		this.contactPointPool = i, this.frictionEquationPool = o, this.result = r, this.frictionResult = a;
		let s = Qp, c = $p, l = Xp, u = Zp;
		for (let r = 0, i = e.length; r !== i; r++) {
			let i = e[r], a = t[r], o = null;
			i.material && a.material && (o = n.getContactMaterial(i.material, a.material) || null);
			let d = i.type & Y.KINEMATIC && a.type & Y.STATIC || i.type & Y.STATIC && a.type & Y.KINEMATIC || i.type & Y.KINEMATIC && a.type & Y.KINEMATIC;
			for (let e = 0; e < i.shapes.length; e++) {
				i.quaternion.mult(i.shapeOrientations[e], s), i.quaternion.vmult(i.shapeOffsets[e], l), l.vadd(i.position, l);
				let t = i.shapes[e];
				for (let e = 0; e < a.shapes.length; e++) {
					a.quaternion.mult(a.shapeOrientations[e], c), a.quaternion.vmult(a.shapeOffsets[e], u), u.vadd(a.position, u);
					let r = a.shapes[e];
					if (!(t.collisionFilterMask & r.collisionFilterGroup && r.collisionFilterMask & t.collisionFilterGroup) || l.distanceTo(u) > t.boundingSphereRadius + r.boundingSphereRadius) continue;
					let f = null;
					t.material && r.material && (f = n.getContactMaterial(t.material, r.material) || null), this.currentContactMaterial = f || o || n.defaultContactMaterial;
					let p = t.type | r.type, m = this[p];
					if (m) {
						let e = !1;
						e = t.type < r.type ? m.call(this, t, r, l, u, s, c, i, a, t, r, d) : m.call(this, r, t, u, l, c, s, a, i, t, r, d), e && d && (n.shapeOverlapKeeper.set(t.id, r.id), n.bodyOverlapKeeper.set(i.id, a.id));
					}
				}
			}
		}
	}
	sphereSphere(e, t, n, r, i, a, o, s, c, l, u) {
		if (u) return n.distanceSquared(r) < (e.radius + t.radius) ** 2;
		let d = this.createContactEquation(o, s, e, t, c, l);
		r.vsub(n, d.ni), d.ni.normalize(), d.ri.copy(d.ni), d.rj.copy(d.ni), d.ri.scale(e.radius, d.ri), d.rj.scale(-t.radius, d.rj), d.ri.vadd(n, d.ri), d.ri.vsub(o.position, d.ri), d.rj.vadd(r, d.rj), d.rj.vsub(s.position, d.rj), this.result.push(d), this.createFrictionEquationsFromContact(d, this.frictionResult);
	}
	spherePlane(e, t, n, r, i, a, o, s, c, l, u) {
		let d = this.createContactEquation(o, s, e, t, c, l);
		if (d.ni.set(0, 0, 1), a.vmult(d.ni, d.ni), d.ni.negate(d.ni), d.ni.normalize(), d.ni.scale(e.radius, d.ri), n.vsub(r, vm), d.ni.scale(d.ni.dot(vm), ym), vm.vsub(ym, d.rj), -vm.dot(d.ni) <= e.radius) {
			if (u) return !0;
			let e = d.ri, t = d.rj;
			e.vadd(n, e), e.vsub(o.position, e), t.vadd(r, t), t.vsub(s.position, t), this.result.push(d), this.createFrictionEquationsFromContact(d, this.frictionResult);
		}
	}
	boxBox(e, t, n, r, i, a, o, s, c, l, u) {
		return e.convexPolyhedronRepresentation.material = e.material, t.convexPolyhedronRepresentation.material = t.material, e.convexPolyhedronRepresentation.collisionResponse = e.collisionResponse, t.convexPolyhedronRepresentation.collisionResponse = t.collisionResponse, this.convexConvex(e.convexPolyhedronRepresentation, t.convexPolyhedronRepresentation, n, r, i, a, o, s, e, t, u);
	}
	sphereBox(e, t, n, r, i, a, o, s, c, l, u) {
		let d = this.v3pool, f = Om;
		n.vsub(r, wm), t.getSideNormals(f, a);
		let p = e.radius, m = !1, h = Am, g = jm, _ = Mm, v = null, y = 0, b = 0, x = 0, S = null;
		for (let e = 0, t = f.length; e !== t && m === !1; e++) {
			let t = Tm;
			t.copy(f[e]);
			let n = t.length();
			t.normalize();
			let r = wm.dot(t);
			if (r < n + p && r > 0) {
				let i = Em, a = Dm;
				i.copy(f[(e + 1) % 3]), a.copy(f[(e + 2) % 3]);
				let o = i.length(), s = a.length();
				i.normalize(), a.normalize();
				let c = wm.dot(i), l = wm.dot(a);
				if (c < o && c > -o && l < s && l > -s) {
					let e = Math.abs(r - n - p);
					if ((S === null || e < S) && (S = e, b = c, x = l, v = n, h.copy(t), g.copy(i), _.copy(a), y++, u)) return !0;
				}
			}
		}
		if (y) {
			m = !0;
			let i = this.createContactEquation(o, s, e, t, c, l);
			h.scale(-p, i.ri), i.ni.copy(h), i.ni.negate(i.ni), h.scale(v, h), g.scale(b, g), h.vadd(g, h), _.scale(x, _), h.vadd(_, i.rj), i.ri.vadd(n, i.ri), i.ri.vsub(o.position, i.ri), i.rj.vadd(r, i.rj), i.rj.vsub(s.position, i.rj), this.result.push(i), this.createFrictionEquationsFromContact(i, this.frictionResult);
		}
		let C = d.get(), w = km;
		for (let i = 0; i !== 2 && !m; i++) for (let a = 0; a !== 2 && !m; a++) for (let d = 0; d !== 2 && !m; d++) if (C.set(0, 0, 0), i ? C.vadd(f[0], C) : C.vsub(f[0], C), a ? C.vadd(f[1], C) : C.vsub(f[1], C), d ? C.vadd(f[2], C) : C.vsub(f[2], C), r.vadd(C, w), w.vsub(n, w), w.lengthSquared() < p * p) {
			if (u) return !0;
			m = !0;
			let i = this.createContactEquation(o, s, e, t, c, l);
			i.ri.copy(w), i.ri.normalize(), i.ni.copy(i.ri), i.ri.scale(p, i.ri), i.rj.copy(C), i.ri.vadd(n, i.ri), i.ri.vsub(o.position, i.ri), i.rj.vadd(r, i.rj), i.rj.vsub(s.position, i.rj), this.result.push(i), this.createFrictionEquationsFromContact(i, this.frictionResult);
		}
		d.release(C), C = null;
		let T = d.get(), E = d.get(), D = d.get(), O = d.get(), k = d.get(), ee = f.length;
		for (let i = 0; i !== ee && !m; i++) for (let a = 0; a !== ee && !m; a++) if (i % 3 != a % 3) {
			f[a].cross(f[i], T), T.normalize(), f[i].vadd(f[a], E), D.copy(n), D.vsub(E, D), D.vsub(r, D);
			let d = D.dot(T);
			T.scale(d, O);
			let h = 0;
			for (; h === i % 3 || h === a % 3;) h++;
			k.copy(n), k.vsub(O, k), k.vsub(E, k), k.vsub(r, k);
			let g = Math.abs(d), _ = k.length();
			if (g < f[h].length() && _ < p) {
				if (u) return !0;
				m = !0;
				let i = this.createContactEquation(o, s, e, t, c, l);
				E.vadd(O, i.rj), i.rj.copy(i.rj), k.negate(i.ni), i.ni.normalize(), i.ri.copy(i.rj), i.ri.vadd(r, i.ri), i.ri.vsub(n, i.ri), i.ri.normalize(), i.ri.scale(p, i.ri), i.ri.vadd(n, i.ri), i.ri.vsub(o.position, i.ri), i.rj.vadd(r, i.rj), i.rj.vsub(s.position, i.rj), this.result.push(i), this.createFrictionEquationsFromContact(i, this.frictionResult);
			}
		}
		d.release(T, E, D, O, k);
	}
	planeBox(e, t, n, r, i, a, o, s, c, l, u) {
		return t.convexPolyhedronRepresentation.material = t.material, t.convexPolyhedronRepresentation.collisionResponse = t.collisionResponse, t.convexPolyhedronRepresentation.id = t.id, this.planeConvex(e, t.convexPolyhedronRepresentation, n, r, i, a, o, s, e, t, u);
	}
	convexConvex(e, t, n, r, i, a, o, s, c, l, u, d, f) {
		let p = qm;
		if (!(n.distanceTo(r) > e.boundingSphereRadius + t.boundingSphereRadius) && e.findSeparatingAxis(t, n, i, r, a, p, d, f)) {
			let d = [], f = Jm;
			e.clipAgainstHull(n, i, t, r, a, p, -100, 100, d);
			let m = 0;
			for (let i = 0; i !== d.length; i++) {
				if (u) return !0;
				let a = this.createContactEquation(o, s, e, t, c, l), h = a.ri, g = a.rj;
				p.negate(a.ni), d[i].normal.negate(f), f.scale(d[i].depth, f), d[i].point.vadd(f, h), g.copy(d[i].point), h.vsub(n, h), g.vsub(r, g), h.vadd(n, h), h.vsub(o.position, h), g.vadd(r, g), g.vsub(s.position, g), this.result.push(a), m++, this.enableFrictionReduction || this.createFrictionEquationsFromContact(a, this.frictionResult);
			}
			this.enableFrictionReduction && m && this.createFrictionFromAverage(m);
		}
	}
	sphereConvex(e, t, n, r, i, a, o, s, c, l, u) {
		let d = this.v3pool;
		n.vsub(r, Nm);
		let f = t.faceNormals, p = t.faces, m = t.vertices, h = e.radius, g = !1;
		for (let i = 0; i !== m.length; i++) {
			let d = m[i], f = Lm;
			a.vmult(d, f), r.vadd(f, f);
			let p = Im;
			if (f.vsub(n, p), p.lengthSquared() < h * h) {
				if (u) return !0;
				g = !0;
				let i = this.createContactEquation(o, s, e, t, c, l);
				i.ri.copy(p), i.ri.normalize(), i.ni.copy(i.ri), i.ri.scale(h, i.ri), f.vsub(r, i.rj), i.ri.vadd(n, i.ri), i.ri.vsub(o.position, i.ri), i.rj.vadd(r, i.rj), i.rj.vsub(s.position, i.rj), this.result.push(i), this.createFrictionEquationsFromContact(i, this.frictionResult);
				return;
			}
		}
		for (let i = 0, _ = p.length; i !== _ && g === !1; i++) {
			let _ = f[i], v = p[i], y = Rm;
			a.vmult(_, y);
			let b = zm;
			a.vmult(m[v[0]], b), b.vadd(r, b);
			let x = Bm;
			y.scale(-h, x), n.vadd(x, x);
			let S = Vm;
			x.vsub(b, S);
			let C = S.dot(y), w = Hm;
			if (n.vsub(b, w), C < 0 && w.dot(y) > 0) {
				let i = [];
				for (let e = 0, t = v.length; e !== t; e++) {
					let t = d.get();
					a.vmult(m[v[e]], t), r.vadd(t, t), i.push(t);
				}
				if (Cm(i, y, n)) {
					if (u) return !0;
					g = !0;
					let a = this.createContactEquation(o, s, e, t, c, l);
					y.scale(-h, a.ri), y.negate(a.ni);
					let f = d.get();
					y.scale(-C, f);
					let p = d.get();
					y.scale(-h, p), n.vsub(r, a.rj), a.rj.vadd(p, a.rj), a.rj.vadd(f, a.rj), a.rj.vadd(r, a.rj), a.rj.vsub(s.position, a.rj), a.ri.vadd(n, a.ri), a.ri.vsub(o.position, a.ri), d.release(f), d.release(p), this.result.push(a), this.createFrictionEquationsFromContact(a, this.frictionResult);
					for (let e = 0, t = i.length; e !== t; e++) d.release(i[e]);
					return;
				}
				for (let f = 0; f !== v.length; f++) {
					let p = d.get(), g = d.get();
					a.vmult(m[v[(f + 1) % v.length]], p), a.vmult(m[v[(f + 2) % v.length]], g), r.vadd(p, p), r.vadd(g, g);
					let _ = Pm;
					g.vsub(p, _);
					let y = Fm;
					_.unit(y);
					let b = d.get(), x = d.get();
					n.vsub(p, x);
					let S = x.dot(y);
					y.scale(S, b), b.vadd(p, b);
					let C = d.get();
					if (b.vsub(n, C), S > 0 && S * S < _.lengthSquared() && C.lengthSquared() < h * h) {
						if (u) return !0;
						let a = this.createContactEquation(o, s, e, t, c, l);
						b.vsub(r, a.rj), b.vsub(n, a.ni), a.ni.normalize(), a.ni.scale(h, a.ri), a.rj.vadd(r, a.rj), a.rj.vsub(s.position, a.rj), a.ri.vadd(n, a.ri), a.ri.vsub(o.position, a.ri), this.result.push(a), this.createFrictionEquationsFromContact(a, this.frictionResult);
						for (let e = 0, t = i.length; e !== t; e++) d.release(i[e]);
						d.release(p), d.release(g), d.release(b), d.release(C), d.release(x);
						return;
					}
					d.release(p), d.release(g), d.release(b), d.release(C), d.release(x);
				}
				for (let e = 0, t = i.length; e !== t; e++) d.release(i[e]);
			}
		}
	}
	planeConvex(e, t, n, r, i, a, o, s, c, l, u) {
		let d = Um, f = Wm;
		f.set(0, 0, 1), i.vmult(f, f);
		let p = 0, m = Gm;
		for (let i = 0; i !== t.vertices.length; i++) if (d.copy(t.vertices[i]), a.vmult(d, d), r.vadd(d, d), d.vsub(n, m), f.dot(m) <= 0) {
			if (u) return !0;
			let i = this.createContactEquation(o, s, e, t, c, l), a = Km;
			f.scale(f.dot(m), a), d.vsub(a, a), a.vsub(n, i.ri), i.ni.copy(f), d.vsub(r, i.rj), i.ri.vadd(n, i.ri), i.ri.vsub(o.position, i.ri), i.rj.vadd(r, i.rj), i.rj.vsub(s.position, i.rj), this.result.push(i), p++, this.enableFrictionReduction || this.createFrictionEquationsFromContact(i, this.frictionResult);
		}
		this.enableFrictionReduction && p && this.createFrictionFromAverage(p);
	}
	boxConvex(e, t, n, r, i, a, o, s, c, l, u) {
		return e.convexPolyhedronRepresentation.material = e.material, e.convexPolyhedronRepresentation.collisionResponse = e.collisionResponse, this.convexConvex(e.convexPolyhedronRepresentation, t, n, r, i, a, o, s, e, t, u);
	}
	sphereHeightfield(e, t, n, r, i, a, o, s, c, l, u) {
		let d = t.data, f = e.radius, p = t.elementSize, m = ch, h = sh;
		J.pointToLocalFrame(r, a, n, h);
		let g = Math.floor((h.x - f) / p) - 1, _ = Math.ceil((h.x + f) / p) + 1, v = Math.floor((h.y - f) / p) - 1, y = Math.ceil((h.y + f) / p) + 1;
		if (_ < 0 || y < 0 || g > d.length || v > d[0].length) return;
		g < 0 && (g = 0), _ < 0 && (_ = 0), v < 0 && (v = 0), y < 0 && (y = 0), g >= d.length && (g = d.length - 1), _ >= d.length && (_ = d.length - 1), y >= d[0].length && (y = d[0].length - 1), v >= d[0].length && (v = d[0].length - 1);
		let b = [];
		t.getRectMinMax(g, v, _, y, b);
		let x = b[0], S = b[1];
		if (h.z - f > S || h.z + f < x) return;
		let C = this.result;
		for (let c = g; c < _; c++) for (let l = v; l < y; l++) {
			let d = C.length, f = !1;
			if (t.getConvexTrianglePillar(c, l, !1), J.pointToWorldFrame(r, a, t.pillarOffset, m), n.distanceTo(m) < t.pillarConvex.boundingSphereRadius + e.boundingSphereRadius && (f = this.sphereConvex(e, t.pillarConvex, n, m, i, a, o, s, e, t, u)), u && f || (t.getConvexTrianglePillar(c, l, !0), J.pointToWorldFrame(r, a, t.pillarOffset, m), n.distanceTo(m) < t.pillarConvex.boundingSphereRadius + e.boundingSphereRadius && (f = this.sphereConvex(e, t.pillarConvex, n, m, i, a, o, s, e, t, u)), u && f)) return !0;
			if (C.length - d > 2) return;
		}
	}
	boxHeightfield(e, t, n, r, i, a, o, s, c, l, u) {
		return e.convexPolyhedronRepresentation.material = e.material, e.convexPolyhedronRepresentation.collisionResponse = e.collisionResponse, this.convexHeightfield(e.convexPolyhedronRepresentation, t, n, r, i, a, o, s, e, t, u);
	}
	convexHeightfield(e, t, n, r, i, a, o, s, c, l, u) {
		let d = t.data, f = t.elementSize, p = e.boundingSphereRadius, m = ah, h = oh, g = ih;
		J.pointToLocalFrame(r, a, n, g);
		let _ = Math.floor((g.x - p) / f) - 1, v = Math.ceil((g.x + p) / f) + 1, y = Math.floor((g.y - p) / f) - 1, b = Math.ceil((g.y + p) / f) + 1;
		if (v < 0 || b < 0 || _ > d.length || y > d[0].length) return;
		_ < 0 && (_ = 0), v < 0 && (v = 0), y < 0 && (y = 0), b < 0 && (b = 0), _ >= d.length && (_ = d.length - 1), v >= d.length && (v = d.length - 1), b >= d[0].length && (b = d[0].length - 1), y >= d[0].length && (y = d[0].length - 1);
		let x = [];
		t.getRectMinMax(_, y, v, b, x);
		let S = x[0], C = x[1];
		if (!(g.z - p > C || g.z + p < S)) for (let c = _; c < v; c++) for (let l = y; l < b; l++) {
			let d = !1;
			if (t.getConvexTrianglePillar(c, l, !1), J.pointToWorldFrame(r, a, t.pillarOffset, m), n.distanceTo(m) < t.pillarConvex.boundingSphereRadius + e.boundingSphereRadius && (d = this.convexConvex(e, t.pillarConvex, n, m, i, a, o, s, null, null, u, h, null)), u && d || (t.getConvexTrianglePillar(c, l, !0), J.pointToWorldFrame(r, a, t.pillarOffset, m), n.distanceTo(m) < t.pillarConvex.boundingSphereRadius + e.boundingSphereRadius && (d = this.convexConvex(e, t.pillarConvex, n, m, i, a, o, s, null, null, u, h, null)), u && d)) return !0;
		}
	}
	sphereParticle(e, t, n, r, i, a, o, s, c, l, u) {
		let d = Qm;
		if (d.set(0, 0, 1), r.vsub(n, d), d.lengthSquared() <= e.radius * e.radius) {
			if (u) return !0;
			let n = this.createContactEquation(s, o, t, e, c, l);
			d.normalize(), n.rj.copy(d), n.rj.scale(e.radius, n.rj), n.ni.copy(d), n.ni.negate(n.ni), n.ri.set(0, 0, 0), this.result.push(n), this.createFrictionEquationsFromContact(n, this.frictionResult);
		}
	}
	planeParticle(e, t, n, r, i, a, o, s, c, l, u) {
		let d = Ym;
		d.set(0, 0, 1), o.quaternion.vmult(d, d);
		let f = Xm;
		if (r.vsub(o.position, f), d.dot(f) <= 0) {
			if (u) return !0;
			let n = this.createContactEquation(s, o, t, e, c, l);
			n.ni.copy(d), n.ni.negate(n.ni), n.ri.set(0, 0, 0);
			let i = Zm;
			d.scale(d.dot(r), i), r.vsub(i, i), n.rj.copy(i), this.result.push(n), this.createFrictionEquationsFromContact(n, this.frictionResult);
		}
	}
	boxParticle(e, t, n, r, i, a, o, s, c, l, u) {
		return e.convexPolyhedronRepresentation.material = e.material, e.convexPolyhedronRepresentation.collisionResponse = e.collisionResponse, this.convexParticle(e.convexPolyhedronRepresentation, t, n, r, i, a, o, s, e, t, u);
	}
	convexParticle(e, t, n, r, i, a, o, s, c, l, u) {
		let d = -1, f = th, p = rh, m = null, h = eh;
		if (h.copy(r), h.vsub(n, h), i.conjugate($m), $m.vmult(h, h), e.pointIsInside(h)) {
			e.worldVerticesNeedsUpdate && e.computeWorldVertices(n, i), e.worldFaceNormalsNeedsUpdate && e.computeWorldFaceNormals(i);
			for (let t = 0, n = e.faces.length; t !== n; t++) {
				let n = [e.worldVertices[e.faces[t][0]]], i = e.worldFaceNormals[t];
				r.vsub(n[0], nh);
				let a = -i.dot(nh);
				if (m === null || Math.abs(a) < Math.abs(m)) {
					if (u) return !0;
					m = a, d = t, f.copy(i);
				}
			}
			if (d !== -1) {
				let i = this.createContactEquation(s, o, t, e, c, l);
				f.scale(m, p), p.vadd(r, p), p.vsub(n, p), i.rj.copy(p), f.negate(i.ni), i.ri.set(0, 0, 0);
				let a = i.ri, u = i.rj;
				a.vadd(r, a), a.vsub(s.position, a), u.vadd(n, u), u.vsub(o.position, u), this.result.push(i), this.createFrictionEquationsFromContact(i, this.frictionResult);
			} else console.warn("Point found inside convex, but did not find penetrating face!");
		}
	}
	heightfieldCylinder(e, t, n, r, i, a, o, s, c, l, u) {
		return this.convexHeightfield(t, e, r, n, a, i, s, o, c, l, u);
	}
	particleCylinder(e, t, n, r, i, a, o, s, c, l, u) {
		return this.convexParticle(t, e, r, n, a, i, s, o, c, l, u);
	}
	sphereTrimesh(e, t, n, r, i, a, o, s, c, l, u) {
		let d = sm, f = cm, p = lm, m = um, h = dm, g = fm, _ = gm, v = om, y = im, b = _m;
		J.pointToLocalFrame(r, a, n, h);
		let x = e.radius;
		_.lowerBound.set(h.x - x, h.y - x, h.z - x), _.upperBound.set(h.x + x, h.y + x, h.z + x), t.getTrianglesInAABB(_, b);
		let S = am, C = e.radius * e.radius;
		for (let i = 0; i < b.length; i++) for (let d = 0; d < 3; d++) if (t.getVertex(t.indices[b[i] * 3 + d], S), S.vsub(h, y), y.lengthSquared() <= C) {
			if (v.copy(S), J.pointToWorldFrame(r, a, v, S), S.vsub(n, y), u) return !0;
			let i = this.createContactEquation(o, s, e, t, c, l);
			i.ni.copy(y), i.ni.normalize(), i.ri.copy(i.ni), i.ri.scale(e.radius, i.ri), i.ri.vadd(n, i.ri), i.ri.vsub(o.position, i.ri), i.rj.copy(S), i.rj.vsub(s.position, i.rj), this.result.push(i), this.createFrictionEquationsFromContact(i, this.frictionResult);
		}
		for (let i = 0; i < b.length; i++) for (let _ = 0; _ < 3; _++) {
			t.getVertex(t.indices[b[i] * 3 + _], d), t.getVertex(t.indices[b[i] * 3 + (_ + 1) % 3], f), f.vsub(d, p), h.vsub(f, g);
			let v = g.dot(p);
			h.vsub(d, g);
			let y = g.dot(p);
			if (y > 0 && v < 0 && (h.vsub(d, g), m.copy(p), m.normalize(), y = g.dot(m), m.scale(y, g), g.vadd(d, g), g.distanceTo(h) < e.radius)) {
				if (u) return !0;
				let i = this.createContactEquation(o, s, e, t, c, l);
				g.vsub(h, i.ni), i.ni.normalize(), i.ni.scale(e.radius, i.ri), i.ri.vadd(n, i.ri), i.ri.vsub(o.position, i.ri), J.pointToWorldFrame(r, a, g, g), g.vsub(s.position, i.rj), J.vectorToWorldFrame(a, i.ni, i.ni), J.vectorToWorldFrame(a, i.ri, i.ri), this.result.push(i), this.createFrictionEquationsFromContact(i, this.frictionResult);
			}
		}
		let w = pm, T = mm, E = hm, D = rm;
		for (let i = 0, d = b.length; i !== d; i++) {
			t.getTriangleVertices(b[i], w, T, E), t.getNormal(b[i], D), h.vsub(w, g);
			let d = g.dot(D);
			if (D.scale(d, g), h.vsub(g, g), d = g.distanceTo(h), Rf.pointInTriangle(g, w, T, E) && d < e.radius) {
				if (u) return !0;
				let i = this.createContactEquation(o, s, e, t, c, l);
				g.vsub(h, i.ni), i.ni.normalize(), i.ni.scale(e.radius, i.ri), i.ri.vadd(n, i.ri), i.ri.vsub(o.position, i.ri), J.pointToWorldFrame(r, a, g, g), g.vsub(s.position, i.rj), J.vectorToWorldFrame(a, i.ni, i.ni), J.vectorToWorldFrame(a, i.ri, i.ri), this.result.push(i), this.createFrictionEquationsFromContact(i, this.frictionResult);
			}
		}
		b.length = 0;
	}
	planeTrimesh(e, t, n, r, i, a, o, s, c, l, u) {
		let d = new G(), f = em;
		f.set(0, 0, 1), i.vmult(f, f);
		for (let i = 0; i < t.vertices.length / 3; i++) {
			t.getVertex(i, d);
			let p = new G();
			p.copy(d), J.pointToWorldFrame(r, a, p, d);
			let m = tm;
			if (d.vsub(n, m), f.dot(m) <= 0) {
				if (u) return !0;
				let n = this.createContactEquation(o, s, e, t, c, l);
				n.ni.copy(f);
				let r = nm;
				f.scale(m.dot(f), r), d.vsub(r, r), n.ri.copy(r), n.ri.vsub(o.position, n.ri), n.rj.copy(d), n.rj.vsub(s.position, n.rj), this.result.push(n), this.createFrictionEquationsFromContact(n, this.frictionResult);
			}
		}
	}
}, qp = new G(), Jp = new G(), Yp = new G(), Xp = new G(), Zp = new G(), Qp = new K(), $p = new K(), em = new G(), tm = new G(), nm = new G(), rm = new G(), im = new G();
new G();
var am = new G(), om = new G(), sm = new G(), cm = new G(), lm = new G(), um = new G(), dm = new G(), fm = new G(), pm = new G(), mm = new G(), hm = new G(), gm = new Wd(), _m = [], vm = new G(), ym = new G(), bm = new G(), xm = new G(), Sm = new G();
function Cm(e, t, n) {
	let r = null, i = e.length;
	for (let a = 0; a !== i; a++) {
		let o = e[a], s = bm;
		e[(a + 1) % i].vsub(o, s);
		let c = xm;
		s.cross(t, c);
		let l = Sm;
		n.vsub(o, l);
		let u = c.dot(l);
		if (r === null || u > 0 && r === !0 || u <= 0 && r === !1) r === null && (r = u > 0);
		else return !1;
	}
	return !0;
}
var wm = new G(), Tm = new G(), Em = new G(), Dm = new G(), Om = [
	new G(),
	new G(),
	new G(),
	new G(),
	new G(),
	new G()
], km = new G(), Am = new G(), jm = new G(), Mm = new G(), Nm = new G(), Pm = new G(), Fm = new G(), Im = new G(), Lm = new G(), Rm = new G(), zm = new G(), Bm = new G(), Vm = new G(), Hm = new G();
new G(), new G();
var Um = new G(), Wm = new G(), Gm = new G(), Km = new G(), qm = new G(), Jm = new G(), Ym = new G(), Xm = new G(), Zm = new G(), Qm = new G(), $m = new K(), eh = new G();
new G();
var th = new G(), nh = new G(), rh = new G(), ih = new G(), ah = new G(), oh = [0], sh = new G(), ch = new G(), lh = class {
	constructor() {
		this.current = [], this.previous = [];
	}
	getKey(e, t) {
		if (t < e) {
			let n = t;
			t = e, e = n;
		}
		return e << 16 | t;
	}
	set(e, t) {
		let n = this.getKey(e, t), r = this.current, i = 0;
		for (; n > r[i];) i++;
		if (n !== r[i]) {
			for (let e = r.length - 1; e >= i; e--) r[e + 1] = r[e];
			r[i] = n;
		}
	}
	tick() {
		let e = this.current;
		this.current = this.previous, this.previous = e, this.current.length = 0;
	}
	getDiff(e, t) {
		let n = this.current, r = this.previous, i = n.length, a = r.length, o = 0;
		for (let t = 0; t < i; t++) {
			let i = !1, a = n[t];
			for (; a > r[o];) o++;
			i = a === r[o], i || uh(e, a);
		}
		o = 0;
		for (let e = 0; e < a; e++) {
			let i = !1, a = r[e];
			for (; a > n[o];) o++;
			i = n[o] === a, i || uh(t, a);
		}
	}
};
function uh(e, t) {
	e.push((t & 4294901760) >> 16, t & 65535);
}
var dh = (e, t) => e < t ? `${e}-${t}` : `${t}-${e}`, fh = class {
	constructor() {
		this.data = { keys: [] };
	}
	get(e, t) {
		let n = dh(e, t);
		return this.data[n];
	}
	set(e, t, n) {
		let r = dh(e, t);
		this.get(e, t) || this.data.keys.push(r), this.data[r] = n;
	}
	delete(e, t) {
		let n = dh(e, t), r = this.data.keys.indexOf(n);
		r !== -1 && this.data.keys.splice(r, 1), delete this.data[n];
	}
	reset() {
		let e = this.data, t = e.keys;
		for (; t.length > 0;) {
			let n = t.pop();
			delete e[n];
		}
	}
}, ph = class extends Jd {
	constructor(e) {
		e === void 0 && (e = {}), super(), this.dt = -1, this.allowSleep = !!e.allowSleep, this.contacts = [], this.frictionEquations = [], this.quatNormalizeSkip = e.quatNormalizeSkip === void 0 ? 0 : e.quatNormalizeSkip, this.quatNormalizeFast = e.quatNormalizeFast !== void 0 && e.quatNormalizeFast, this.time = 0, this.stepnumber = 0, this.default_dt = 1 / 60, this.nextId = 0, this.gravity = new G(), e.gravity && this.gravity.copy(e.gravity), e.frictionGravity && (this.frictionGravity = new G(), this.frictionGravity.copy(e.frictionGravity)), this.broadphase = e.broadphase === void 0 ? new Of() : e.broadphase, this.bodies = [], this.hasActiveBodies = !1, this.solver = e.solver === void 0 ? new Bp() : e.solver, this.constraints = [], this.narrowphase = new Kp(this), this.collisionMatrix = new qd(), this.collisionMatrixPrevious = new qd(), this.bodyOverlapKeeper = new lh(), this.shapeOverlapKeeper = new lh(), this.contactmaterials = [], this.contactMaterialTable = new fh(), this.defaultMaterial = new Fp("default"), this.defaultContactMaterial = new Pp(this.defaultMaterial, this.defaultMaterial, {
			friction: .3,
			restitution: 0
		}), this.doProfiling = !1, this.profile = {
			solve: 0,
			makeContactConstraints: 0,
			broadphase: 0,
			integrate: 0,
			narrowphase: 0
		}, this.accumulator = 0, this.subsystems = [], this.addBodyEvent = {
			type: "addBody",
			body: null
		}, this.removeBodyEvent = {
			type: "removeBody",
			body: null
		}, this.idToBodyMap = {}, this.broadphase.setWorld(this);
	}
	getContactMaterial(e, t) {
		return this.contactMaterialTable.get(e.id, t.id);
	}
	collisionMatrixTick() {
		let e = this.collisionMatrixPrevious;
		this.collisionMatrixPrevious = this.collisionMatrix, this.collisionMatrix = e, this.collisionMatrix.reset(), this.bodyOverlapKeeper.tick(), this.shapeOverlapKeeper.tick();
	}
	addConstraint(e) {
		this.constraints.push(e);
	}
	removeConstraint(e) {
		let t = this.constraints.indexOf(e);
		t !== -1 && this.constraints.splice(t, 1);
	}
	rayTest(e, t, n) {
		n instanceof kf ? this.raycastClosest(e, t, { skipBackfaces: !0 }, n) : this.raycastAll(e, t, { skipBackfaces: !0 }, n);
	}
	raycastAll(e, t, n, r) {
		return n === void 0 && (n = {}), n.mode = Rf.ALL, n.from = e, n.to = t, n.callback = r, mh.intersectWorld(this, n);
	}
	raycastAny(e, t, n, r) {
		return n === void 0 && (n = {}), n.mode = Rf.ANY, n.from = e, n.to = t, n.result = r, mh.intersectWorld(this, n);
	}
	raycastClosest(e, t, n, r) {
		return n === void 0 && (n = {}), n.mode = Rf.CLOSEST, n.from = e, n.to = t, n.result = r, mh.intersectWorld(this, n);
	}
	addBody(e) {
		this.bodies.includes(e) || (e.index = this.bodies.length, this.bodies.push(e), e.world = this, e.initPosition.copy(e.position), e.initVelocity.copy(e.velocity), e.timeLastSleepy = this.time, e instanceof Y && (e.initAngularVelocity.copy(e.angularVelocity), e.initQuaternion.copy(e.quaternion)), this.collisionMatrix.setNumObjects(this.bodies.length), this.addBodyEvent.body = e, this.idToBodyMap[e.id] = e, this.dispatchEvent(this.addBodyEvent));
	}
	removeBody(e) {
		e.world = null;
		let t = this.bodies.length - 1, n = this.bodies, r = n.indexOf(e);
		if (r !== -1) {
			n.splice(r, 1);
			for (let e = 0; e !== n.length; e++) n[e].index = e;
			this.collisionMatrix.setNumObjects(t), this.removeBodyEvent.body = e, delete this.idToBodyMap[e.id], this.dispatchEvent(this.removeBodyEvent);
		}
	}
	getBodyById(e) {
		return this.idToBodyMap[e];
	}
	getShapeById(e) {
		let t = this.bodies;
		for (let n = 0; n < t.length; n++) {
			let r = t[n].shapes;
			for (let t = 0; t < r.length; t++) {
				let n = r[t];
				if (n.id === e) return n;
			}
		}
		return null;
	}
	addContactMaterial(e) {
		this.contactmaterials.push(e), this.contactMaterialTable.set(e.materials[0].id, e.materials[1].id, e);
	}
	removeContactMaterial(e) {
		let t = this.contactmaterials.indexOf(e);
		t !== -1 && (this.contactmaterials.splice(t, 1), this.contactMaterialTable.delete(e.materials[0].id, e.materials[1].id));
	}
	fixedStep(e, t) {
		e === void 0 && (e = 1 / 60), t === void 0 && (t = 10);
		let n = Q.now() / 1e3;
		if (!this.lastCallTime) this.step(e, void 0, t);
		else {
			let r = n - this.lastCallTime;
			this.step(e, r, t);
		}
		this.lastCallTime = n;
	}
	step(e, t, n) {
		if (n === void 0 && (n = 10), t === void 0) this.internalStep(e), this.time += e;
		else {
			this.accumulator += t;
			let r = Q.now(), i = 0;
			for (; this.accumulator >= e && i < n && (this.internalStep(e), this.accumulator -= e, i++, !(Q.now() - r > e * 1e3)););
			this.accumulator %= e;
			let a = this.accumulator / e;
			for (let e = 0; e !== this.bodies.length; e++) {
				let t = this.bodies[e];
				t.previousPosition.lerp(t.position, a, t.interpolatedPosition), t.previousQuaternion.slerp(t.quaternion, a, t.interpolatedQuaternion), t.previousQuaternion.normalize();
			}
			this.time += t;
		}
	}
	internalStep(e) {
		this.dt = e;
		let t = this.contacts, n = bh, r = xh, i = this.bodies.length, a = this.bodies, o = this.solver, s = this.gravity, c = this.doProfiling, l = this.profile, u = Y.DYNAMIC, d = -Infinity, f = this.constraints, p = yh;
		s.length();
		let m = s.x, h = s.y, g = s.z, _ = 0;
		for (c && (d = Q.now()), _ = 0; _ !== i; _++) {
			let e = a[_];
			if (e.type === u) {
				let t = e.force, n = e.mass;
				t.x += n * m, t.y += n * h, t.z += n * g;
			}
		}
		for (let e = 0, t = this.subsystems.length; e !== t; e++) this.subsystems[e].update();
		c && (d = Q.now()), n.length = 0, r.length = 0, this.broadphase.collisionPairs(this, n, r), c && (l.broadphase = Q.now() - d);
		let v = f.length;
		for (_ = 0; _ !== v; _++) {
			let e = f[_];
			if (!e.collideConnected) for (let t = n.length - 1; t >= 0; --t) (e.bodyA === n[t] && e.bodyB === r[t] || e.bodyB === n[t] && e.bodyA === r[t]) && (n.splice(t, 1), r.splice(t, 1));
		}
		this.collisionMatrixTick(), c && (d = Q.now());
		let y = vh, b = t.length;
		for (_ = 0; _ !== b; _++) y.push(t[_]);
		t.length = 0;
		let x = this.frictionEquations.length;
		for (_ = 0; _ !== x; _++) p.push(this.frictionEquations[_]);
		for (this.frictionEquations.length = 0, this.narrowphase.getContacts(n, r, this, t, y, this.frictionEquations, p), c && (l.narrowphase = Q.now() - d), c && (d = Q.now()), _ = 0; _ < this.frictionEquations.length; _++) o.addEquation(this.frictionEquations[_]);
		let S = t.length;
		for (let e = 0; e !== S; e++) {
			let n = t[e], r = n.bi, i = n.bj, a = n.si, s = n.sj, c;
			c = r.material && i.material && this.getContactMaterial(r.material, i.material) || this.defaultContactMaterial, c.friction, r.material && i.material && (r.material.friction >= 0 && i.material.friction >= 0 && r.material.friction * i.material.friction, r.material.restitution >= 0 && i.material.restitution >= 0 && (n.restitution = r.material.restitution * i.material.restitution)), o.addEquation(n), r.allowSleep && r.type === Y.DYNAMIC && r.sleepState === Y.SLEEPING && i.sleepState === Y.AWAKE && i.type !== Y.STATIC && i.velocity.lengthSquared() + i.angularVelocity.lengthSquared() >= i.sleepSpeedLimit ** 2 * 2 && (r.wakeUpAfterNarrowphase = !0), i.allowSleep && i.type === Y.DYNAMIC && i.sleepState === Y.SLEEPING && r.sleepState === Y.AWAKE && r.type !== Y.STATIC && r.velocity.lengthSquared() + r.angularVelocity.lengthSquared() >= r.sleepSpeedLimit ** 2 * 2 && (i.wakeUpAfterNarrowphase = !0), this.collisionMatrix.set(r, i, !0), this.collisionMatrixPrevious.get(r, i) || (_h.body = i, _h.contact = n, r.dispatchEvent(_h), _h.body = r, i.dispatchEvent(_h)), this.bodyOverlapKeeper.set(r.id, i.id), this.shapeOverlapKeeper.set(a.id, s.id);
		}
		for (this.emitContactEvents(), c && (l.makeContactConstraints = Q.now() - d, d = Q.now()), _ = 0; _ !== i; _++) {
			let e = a[_];
			e.wakeUpAfterNarrowphase &&= (e.wakeUp(), !1);
		}
		for (v = f.length, _ = 0; _ !== v; _++) {
			let e = f[_];
			e.update();
			for (let t = 0, n = e.equations.length; t !== n; t++) {
				let n = e.equations[t];
				o.addEquation(n);
			}
		}
		o.solve(e, this), c && (l.solve = Q.now() - d), o.removeAllEquations();
		let C = Math.pow;
		for (_ = 0; _ !== i; _++) {
			let t = a[_];
			if (t.type & u) {
				let n = C(1 - t.linearDamping, e), r = t.velocity;
				r.scale(n, r);
				let i = t.angularVelocity;
				if (i) {
					let n = C(1 - t.angularDamping, e);
					i.scale(n, i);
				}
			}
		}
		this.dispatchEvent(gh), c && (d = Q.now());
		let w = this.stepnumber % (this.quatNormalizeSkip + 1) === 0, T = this.quatNormalizeFast;
		for (_ = 0; _ !== i; _++) a[_].integrate(e, w, T);
		this.clearForces(), this.broadphase.dirty = !0, c && (l.integrate = Q.now() - d), this.stepnumber += 1, this.dispatchEvent(hh);
		let E = !0;
		if (this.allowSleep) for (E = !1, _ = 0; _ !== i; _++) {
			let e = a[_];
			e.sleepTick(this.time), e.sleepState !== Y.SLEEPING && (E = !0);
		}
		this.hasActiveBodies = E;
	}
	emitContactEvents() {
		let e = this.hasAnyEventListener("beginContact"), t = this.hasAnyEventListener("endContact");
		if ((e || t) && this.bodyOverlapKeeper.getDiff(Sh, Ch), e) {
			for (let e = 0, t = Sh.length; e < t; e += 2) wh.bodyA = this.getBodyById(Sh[e]), wh.bodyB = this.getBodyById(Sh[e + 1]), this.dispatchEvent(wh);
			wh.bodyA = wh.bodyB = null;
		}
		if (t) {
			for (let e = 0, t = Ch.length; e < t; e += 2) Th.bodyA = this.getBodyById(Ch[e]), Th.bodyB = this.getBodyById(Ch[e + 1]), this.dispatchEvent(Th);
			Th.bodyA = Th.bodyB = null;
		}
		Sh.length = Ch.length = 0;
		let n = this.hasAnyEventListener("beginShapeContact"), r = this.hasAnyEventListener("endShapeContact");
		if ((n || r) && this.shapeOverlapKeeper.getDiff(Sh, Ch), n) {
			for (let e = 0, t = Sh.length; e < t; e += 2) {
				let t = this.getShapeById(Sh[e]), n = this.getShapeById(Sh[e + 1]);
				Eh.shapeA = t, Eh.shapeB = n, t && (Eh.bodyA = t.body), n && (Eh.bodyB = n.body), this.dispatchEvent(Eh);
			}
			Eh.bodyA = Eh.bodyB = Eh.shapeA = Eh.shapeB = null;
		}
		if (r) {
			for (let e = 0, t = Ch.length; e < t; e += 2) {
				let t = this.getShapeById(Ch[e]), n = this.getShapeById(Ch[e + 1]);
				Dh.shapeA = t, Dh.shapeB = n, t && (Dh.bodyA = t.body), n && (Dh.bodyB = n.body), this.dispatchEvent(Dh);
			}
			Dh.bodyA = Dh.bodyB = Dh.shapeA = Dh.shapeB = null;
		}
	}
	clearForces() {
		let e = this.bodies, t = e.length;
		for (let n = 0; n !== t; n++) {
			let t = e[n];
			t.force, t.torque, t.force.set(0, 0, 0), t.torque.set(0, 0, 0);
		}
	}
};
new Wd();
var mh = new Rf(), Q = globalThis.performance || {};
if (!Q.now) {
	let e = Date.now();
	Q.timing && Q.timing.navigationStart && (e = Q.timing.navigationStart), Q.now = () => Date.now() - e;
}
new G();
var hh = { type: "postStep" }, gh = { type: "preStep" }, _h = {
	type: Y.COLLIDE_EVENT_NAME,
	body: null,
	contact: null
}, vh = [], yh = [], bh = [], xh = [], Sh = [], Ch = [], wh = {
	type: "beginContact",
	bodyA: null,
	bodyB: null
}, Th = {
	type: "endContact",
	bodyA: null,
	bodyB: null
}, Eh = {
	type: "beginShapeContact",
	bodyA: null,
	bodyB: null,
	shapeA: null,
	shapeB: null
}, Dh = {
	type: "endShapeContact",
	bodyA: null,
	bodyB: null,
	shapeA: null,
	shapeB: null
}, Oh = Math.PI / 180;
function kh(e) {
	let t = new K();
	return t.setFromEuler(e[0] * Oh, e[1] * Oh, e[2] * Oh, "XYZ"), t;
}
function Ah(e) {
	let { x: t, y: n, z: r, w: i } = e, a = [
		1 - 2 * (n * n + r * r),
		2 * (t * n - r * i),
		2 * (t * r + n * i),
		2 * (t * n + r * i),
		1 - 2 * (t * t + r * r),
		2 * (n * r - t * i),
		2 * (t * r - n * i),
		2 * (n * r + t * i),
		1 - 2 * (t * t + n * n)
	];
	return Tr(a);
}
function jh(e, t, n) {
	let r = new Y({
		mass: t,
		material: n
	});
	if (e.kind === "sphere" && !e.repeat && !e.mirror) r.addShape(new Ip(Math.min(...e.size) / 2)), r.position.set(...e.position), r.quaternion.copy(kh(e.rotation));
	else if (e.kind !== "group" && !e.repeat && !e.mirror && !e.form) r.addShape(new af(new G(...e.size.map((e) => e / 2)))), r.position.set(...e.position), r.quaternion.copy(kh(e.rotation));
	else {
		let t = qr(e);
		if (!t) return r;
		r.addShape(new af(new G(...t.max.map((e, n) => Math.max(.01, (e - t.min[n]) / 2)))));
		let [n, i, a] = t.max.map((e, n) => (e + t.min[n]) / 2);
		r.position.set(n, i, a);
	}
	return r;
}
function Mh(e, t) {
	let n = /* @__PURE__ */ new Set([0, e.length - 1]), r = (e, t, n) => {
		let r = (n.at - e.at) / (t.at - e.at || 1), i = Math.hypot(...n.position.map((n, i) => n - (e.position[i] + (t.position[i] - e.position[i]) * r))), a = Math.max(...n.rotation.map((n, i) => Math.abs(n - (e.rotation[i] + (t.rotation[i] - e.rotation[i]) * r)))) / 180;
		return Math.max(i, a);
	}, i = (a, o) => {
		let s = -1, c = -1;
		for (let t = a + 1; t < o; t++) {
			let n = r(e[a], e[o], e[t]);
			n > s && (s = n, c = t);
		}
		s > t && c > 0 && (n.add(c), i(a, c), i(c, o));
	};
	i(0, e.length - 1);
	let a = [...n].sort((e, t) => e - t).map((t) => e[t]);
	return a.length <= 120 ? a : Array.from({ length: 120 }, (e, t) => a[Math.round(t / 119 * (a.length - 1))]);
}
function Nh(e, t, n) {
	let r = new ph({ gravity: new G(0, -9.82, 0) }), i = new Fp("shape");
	r.addContactMaterial(new Pp(i, i, {
		restitution: n.bounce,
		friction: Math.max(.01, n.grip)
	})), r.defaultContactMaterial.restitution = n.bounce, r.defaultContactMaterial.friction = Math.max(.01, n.grip);
	let a = new Y({
		mass: 0,
		material: i
	});
	a.addShape(new Lp()), a.quaternion.setFromEuler(-Math.PI / 2, 0, 0), r.addBody(a);
	let o = /* @__PURE__ */ new Map();
	e.shapes.forEach((e, n) => {
		if (!e.hidden) {
			if (t.includes(n)) {
				let t = qr(e), a = t ? t.max.reduce((e, n, r) => e * Math.max(.05, n - t.min[r]), 1) : 1, s = jh(e, Math.max(.05, a), i);
				o.set(n, s), r.addBody(s);
			} else r.addBody(jh(e, 0, i));
		}
	});
	let s = Math.max(2, Math.round(n.seconds * 30)), c = new Map([...o.keys()].map((e) => [e, []]));
	for (let t = 0; t <= s; t++) {
		for (let [n, r] of o) {
			let i = e.shapes[n], a = c.get(n), o = a[a.length - 1], l = Ah(r.quaternion);
			o && (l = l.map((e, t) => e + 360 * Math.round((o.rotation[t] - e) / 360)));
			let u = i.kind === "group" || i.repeat || i.mirror || i.form ? Ph(i) : [
				0,
				0,
				0
			];
			a.push({
				at: t / s,
				position: [
					r.position.x - u[0],
					r.position.y - u[1],
					r.position.z - u[2]
				],
				rotation: l.map((e) => Math.max(-360, Math.min(360, e))),
				size: [...i.size],
				ease: "linear"
			});
		}
		for (let e = 0; e < 4; e++) r.step(1 / 120);
	}
	return new Map([...c].map(([e, t]) => [e, Mh(t, .01)]));
}
function Ph(e) {
	let t = qr(e);
	return t ? t.max.map((n, r) => (n + t.min[r]) / 2 - e.position[r]) : [
		0,
		0,
		0
	];
}
//#endregion
//#region ../scene3d/src/model/card.ts
function Fh(e, t, n, r, i = "Product photo") {
	let a = Math.max(.01, n / Math.max(1, r)), [s, c] = [-a / 2, a / 2], l = (e, t, n) => ({
		positions: new Float32Array([
			s,
			0,
			e,
			c,
			0,
			e,
			c,
			1,
			e,
			s,
			1,
			e
		]),
		normals: new Float32Array([
			0,
			0,
			t,
			0,
			0,
			t,
			0,
			0,
			t,
			0,
			0,
			t
		]),
		uvs: new Float32Array(n ? [
			1,
			1,
			0,
			1,
			0,
			0,
			1,
			0
		] : [
			0,
			1,
			1,
			1,
			1,
			0,
			0,
			0
		]),
		colors: null,
		indices: new Uint32Array(t === 1 ? [
			0,
			1,
			2,
			0,
			2,
			3
		] : [
			0,
			2,
			1,
			0,
			3,
			2
		]),
		material: 0
	}), u = {
		...o(),
		color: [
			1,
			1,
			1
		],
		roughness: 1,
		texture: 0,
		cutout: !0,
		unlit: !0
	}, d = m([l(0, 1, !1), l(-.002, -1, !0)], [u], [{
		mime: t,
		bytes: e
	}]);
	return po(d, i);
}
//#endregion
//#region ../scene3d/src/model/ad.ts
var Ih = {
	podium: "Podium",
	burst: "Starburst",
	shelf: "Shop shelf"
}, Lh = {
	blossom: {
		label: "Blossom",
		colours: {
			background: "#fde8ef",
			main: "#ffffff",
			accent: "#ff4d8d",
			text: "#2b1d3a",
			priceText: "#ffffff"
		}
	},
	night: {
		label: "Night",
		colours: {
			background: "#141826",
			main: "#2a3150",
			accent: "#ffd23f",
			text: "#ffffff",
			priceText: "#141826"
		}
	},
	mint: {
		label: "Mint",
		colours: {
			background: "#e6f6ef",
			main: "#ffffff",
			accent: "#00a37a",
			text: "#10302a",
			priceText: "#ffffff"
		}
	},
	sunset: {
		label: "Sunset",
		colours: {
			background: "#fff1e0",
			main: "#ffcf99",
			accent: "#ff5a36",
			text: "#3a1a0b",
			priceText: "#ffffff"
		}
	},
	studio: {
		label: "Studio grey",
		colours: {
			background: "#eceef1",
			main: "#ffffff",
			accent: "#1f2937",
			text: "#1f2937",
			priceText: "#ffffff"
		}
	}
};
function Rh(e) {
	let t = e.replace(/\s+/g, " ").trim();
	if (t.length <= 18 || t.includes("\n")) return t;
	let n = t.length / 2, r = -1;
	for (let e = 0; e < t.length; e++) t[e] === " " && (r < 0 || Math.abs(e - n) < Math.abs(r - n)) && (r = e);
	return r < 0 ? t : `${t.slice(0, r)}\n${t.slice(r + 1)}`;
}
var zh = (e) => ({
	...Bi,
	...e
});
function Bh(e, t) {
	return Array.from({ length: e * 2 }, (n, r) => {
		let i = Math.PI / 2 + r / (e * 2) * Math.PI * 2, a = r % 2 ? .5 * t : .5;
		return [Math.cos(i) * a, Math.sin(i) * a];
	});
}
function Vh(e, t, n, r, i, a, o = .22) {
	let s = e(t);
	if (!s) return null;
	let c = Math.min(i, r / s.aspect);
	return A("text", 0, {
		name: t.value.replace(/\s+/g, " ").slice(0, 30),
		text: t,
		outline: s.outline,
		size: [
			c * s.aspect,
			c,
			o
		],
		position: n,
		color: a,
		finish: "satin",
		round: .06
	});
}
function Hh(e, t = 1) {
	let n = e.colours, r = e.font ?? "Arial", i = e.moving !== !1, a = [], o = {}, s = e.picture?.aspect ?? .75, c = Math.min(2.2, 2.8 / s), l = c * s, u = e.style === "podium" ? .4 : e.style === "shelf" ? .95 : 0, d = e.style === "shelf" ? .1 : 0;
	e.style === "podium" && a.push(A("cylinder", 0, {
		name: "Podium",
		size: [
			Math.max(2.2, l + .6),
			u,
			Math.max(2.2, l + .6)
		],
		position: [
			0,
			u / 2,
			0
		],
		color: n.main,
		finish: "satin",
		round: .08
	})), e.style === "burst" && a.push(A("extrude", 0, {
		name: "Starburst",
		outline: [Bh(16, .78)],
		size: [
			c * 1.75,
			c * 1.75,
			.15
		],
		position: [
			0,
			c * .6,
			-.7
		],
		color: n.accent,
		finish: "satin",
		round: .04,
		...i ? { motion: zh({
			kind: "spin",
			axis: "z",
			times: 1
		}) } : {}
	})), e.style === "shelf" && a.push(A("box", 0, {
		name: "Back panel",
		size: [
			5.4,
			3.9,
			.2
		],
		position: [
			0,
			1.95,
			-.9
		],
		color: n.main,
		finish: "matte",
		round: .03
	}), A("box", 0, {
		name: "Shelf",
		size: [
			4.6,
			.14,
			1.3
		],
		position: [
			0,
			u - .07,
			-.2
		],
		color: n.accent,
		finish: "satin",
		round: .05
	}));
	let f = null;
	if (e.picture) {
		let t = je();
		o[t] = e.picture.asset, f = A("mesh", 0, {
			name: "Product photo",
			asset: t,
			ownColors: !0,
			size: [
				l,
				c,
				.01
			],
			position: [
				0,
				u + c / 2,
				d
			],
			...i ? { motion: zh({
				kind: "float",
				amount: .12,
				times: 1
			}) } : {}
		}), a.push(f);
	}
	let p = u + c + .25, m = e.headline?.trim() ? Vh(e.text, {
		value: Rh(e.headline),
		font: r,
		weight: 900,
		align: "center",
		lineHeight: 1
	}, [
		0,
		0,
		.1
	], 4.6, 1.1, n.text, .26) : null;
	m && (m.position = [
		0,
		p + m.size[1] / 2,
		-.15
	], i && (m.motion = zh({
		kind: "pop",
		delay: .05
	})), p += m.size[1] + .12, a.push(m));
	let h = e.tagline?.trim() ? Vh(e.text, {
		value: e.tagline.trim().toUpperCase(),
		font: r,
		weight: 700,
		spacing: .08
	}, [
		0,
		0,
		0
	], 3.6, .3, n.text, .12) : null;
	h && (h.position = [
		0,
		p + h.size[1] / 2,
		-.15
	], i && (h.motion = zh({
		kind: "pop",
		delay: 0
	})), p += h.size[1], a.push(h));
	let g = a.find((e) => e.name === "Back panel");
	if (g) {
		let e = Math.max(3.9, p + .35);
		g.size = [
			Math.max(5.4, (m?.size[0] ?? 0) + .8),
			e,
			g.size[2]
		], g.position = [
			0,
			e / 2,
			g.position[2]
		];
	}
	if (e.price?.trim()) {
		let t = l / 2 + .55, o = u + c * .32, s = 1.15, d = e.style === "shelf" ? A("box", 0, {
			name: "Price tag",
			size: [
				1.3,
				.75,
				.12
			],
			round: .35
		}) : A("extrude", 0, {
			name: "Price badge",
			outline: [Bh(14, .84)],
			size: [
				s,
				s,
				.14
			],
			round: .05
		});
		Object.assign(d, {
			position: [
				t,
				o,
				.55
			],
			rotation: [
				0,
				0,
				-10
			],
			color: n.accent,
			finish: "glossy"
		});
		let f = Vh(e.text, {
			value: e.price.trim(),
			font: r,
			weight: 900
		}, [
			t,
			o,
			.65
		], d.size[0] * .68, d.size[1] * .42, n.priceText, .08);
		f && (f.rotation = [
			0,
			0,
			-10
		], a.push(A("group", 0, {
			name: "Price",
			children: [d, f],
			combine: "add",
			blend: 0,
			...i ? { motion: zh({
				kind: "pulse",
				amount: .35,
				times: 2
			}) } : {}
		})));
	}
	let _ = new wo({
		...pe(),
		shapes: a,
		assets: o,
		background: {
			transparent: !1,
			color: n.background,
			picture: ""
		},
		ground: {
			on: !0,
			shadow: .45
		},
		light: {
			azimuth: -30,
			elevation: 48,
			intensity: 1.35,
			ambient: .45,
			color: "#ffffff",
			shadows: !0
		},
		camera: {
			yaw: 12,
			pitch: 10,
			distance: 8,
			target: [
				0,
				1.6,
				0
			],
			fov: 30,
			projection: "perspective"
		}
	});
	if (e.logo?.parts.length) {
		let t = Eo(e.logo, {
			long: 1,
			depth: .12,
			at: [-(l / 2 + .75), .9]
		});
		t.length === 1 && (t[0].name = "Logo"), _.addShapes(t, "Logo", "Logo");
	}
	return Uh(_, t), _.document;
}
function Uh(e, t) {
	let n = Mn(e.document.shapes.filter((e) => !e.hidden));
	if (!n) return e.frameAll(t);
	let r = e.document.camera, i = [
		0,
		1,
		2
	].map((e) => (n.max[e] - n.min[e]) / 2), a = Math.tan(r.fov * Math.PI / 360), o = Math.max(i[1], i[0] / Math.max(.1, t)) / a * 1.12 + i[2];
	e.setCamera({
		target: n.min.map((e, t) => (e + n.max[t]) / 2),
		distance: o
	});
}
//#endregion
//#region ../scene3d/src/model/clips.ts
var Wh = (e) => {
	let t = e.elements, n = [
		0,
		4,
		8
	].map((e) => Math.hypot(t[e], t[e + 1], t[e + 2]) || 1);
	return [
		t[0] / n[0],
		t[4] / n[1],
		t[8] / n[2],
		t[1] / n[0],
		t[5] / n[1],
		t[9] / n[2],
		t[2] / n[0],
		t[6] / n[1],
		t[10] / n[2]
	];
};
function Gh(e, t, n, o, s, c = new a(), l = 30, u = e) {
	let d = Ui(o).get("hips") ?? 0, f = /* @__PURE__ */ new Set();
	for (let e = o[d].parent; e >= 0; e = o[e].parent) f.add(e);
	let p = new i(u), m = [], h = new a(), g = new r();
	for (let r of t) {
		if (r.duration <= 0 || !r.tracks.length) continue;
		let t = p.clipAction(r);
		t.reset().play();
		let i = Math.min(l, Math.max(5, Math.floor(3e4 / Math.max(r.duration, 1) * 1e3) / 1e3)), a = Math.max(2, Math.round(r.duration * i) + 1), u = [];
		for (let t = 0; t < a; t++) {
			p.setTime(r.duration * t / (a - 1)), e.updateMatrixWorld(!0);
			let i = [], l = [
				0,
				0,
				0
			], m = n.map((e, t) => {
				if (f.has(t)) return i.push([
					1,
					0,
					0,
					0,
					1,
					0,
					0,
					0,
					1
				]), [
					0,
					0,
					0
				];
				h.copy(c).multiply(e.matrixWorld).multiply(s(t));
				let n = Wh(h);
				if (i.push(n), t === d) {
					let e = o[t].head;
					g.set(e[0], e[1], e[2]).applyMatrix4(h), l = [
						g.x - e[0],
						g.y - e[1],
						g.z - e[2]
					];
				}
				let r = o[t].parent;
				return Ye(r >= 0 ? D(xe(i[r]), n) : n);
			});
			u.push({
				turns: m,
				root: l
			});
		}
		t.stop(), p.uncacheClip(r), m.push(Lt(r.name || "Take", o.map((e) => e.name), (a - 1) / r.duration, u));
	}
	return p.stopAllAction(), p.uncacheRoot(u), m;
}
function Kh(e) {
	e.updateMatrixWorld(!0);
	let t = [];
	if (e.traverse((e) => {
		e.isBone && !e.children.some((t) => t.isBone && t.name === e.name) && t.push(e);
	}), !t.length) return null;
	let n = new Map(t.map((e, t) => [e, t])), i = (e) => {
		for (let t = e.parent; t; t = t.parent) if (n.has(t)) return n.get(t);
		return -1;
	}, a = (e) => {
		let t = new r().setFromMatrixPosition(e.matrixWorld);
		return [
			t.x,
			t.y,
			t.z
		];
	};
	return {
		order: t,
		bones: t.map((e, n) => {
			let r = t.filter((e) => i(e) === n), o = a(e), s = r.length ? r.map(a).reduce((e, t) => e.map((e, n) => e + t[n] / r.length), [
				0,
				0,
				0
			]) : o.map((n, r) => n + (i(e) >= 0 ? (n - a(t[i(e)])[r]) * .3 : 0));
			return {
				name: (e.name || `Bone ${n + 1}`).slice(0, 40),
				parent: i(e),
				head: o,
				tail: s
			};
		}),
		inverses: t.map((e) => e.matrixWorld.clone().invert())
	};
}
function qh(e, t, n = e) {
	e.updateMatrixWorld(!0);
	let r = mo(e);
	if (r) {
		let i = r.bones.map((e) => ({ ...e }));
		return {
			bones: i,
			takes: Gh(e, t, r.order, i, r.fromBind, void 0, 30, n)
		};
	}
	let i = Kh(e);
	return i ? {
		bones: i.bones,
		takes: Gh(e, t, i.order, i.bones, (e) => i.inverses[e], void 0, 30, n)
	} : null;
}
//#endregion
//#region ../scene3d/src/model/character.ts
var Jh = {
	chibi: 2.6,
	anime: 4.2,
	tall: 5.5
}, Yh = (e, t) => {
	let n = parseInt(e.slice(1), 16);
	return `#${[
		n >> 16 & 255,
		n >> 8 & 255,
		n & 255
	].map((e) => Math.round(Math.min(255, Math.max(0, e * t)))).map((e) => e.toString(16).padStart(2, "0")).join("")}`;
}, Xh = (e) => Math.round(e * 1e3) / 1e3, $ = (e, t, n) => [
	Xh(e),
	Xh(t),
	Xh(n)
];
function Zh(e) {
	let t = Math.min(4, Math.max(.3, e.height)), n = Jh[e.build], r = t / n, i = e.build === "chibi", a = t * (.1 + .065 * n), o = t * .025, s = t - r - a - o, c = Math.min(t * .19, r * (i ? .95 : 1.05)), l = a + s + o + r * .5, u = r * .44, d = [], f = r / .38, p = (e, t, n, r, i, a = {}) => {
		let { pair: o, ...s } = a, c = (n, o) => d.push(A(e, d.length, {
			name: t,
			size: r,
			color: i,
			finish: "satin",
			...s,
			position: n,
			rotation: o,
			blend: Xh(Math.min(1, (a.blend ?? .04) * f))
		})), [l, u, p] = s.rotation ?? [
			0,
			0,
			0
		];
		c(n, [
			l,
			u,
			p
		]), o && c([
			Xh(-n[0]),
			n[1],
			n[2]
		], [
			l,
			u ? -u : 0,
			p ? -p : 0
		]);
	}, m = { pair: !0 }, h = c * .32, g = e.outfit === "hoodie" ? e.secondary : Yh(e.secondary, .55);
	p("capsule", "Legs", $(c * .27, h * .5 + a / 2, 0), $(h, a + h * .5, h), g, m), p("box", "Shoes", $(c * .27, h * .32, h * .18), $(h * 1.3, h * .64, h * 1.75), Yh(e.accent, .45), {
		...m,
		round: .45
	}), e.outfit === "hoodie" ? p("capsule", "Shorts", $(0, a + s * .05, 0), $(c * .95, s * .35, c * .6), e.secondary, { blend: .08 }) : p("cone", "Skirt", $(0, a + s * (e.outfit === "dress" ? .12 : .2), 0), $(c * 1.4, s * (e.outfit === "dress" ? .72 : .56), c * 1.12), e.outfit === "dress" ? e.primary : e.secondary, { round: .05 }), p("capsule", "Body", $(0, a + s * .55, 0), $(c * (e.outfit === "hoodie" ? .98 : .78), s * .9, c * .56), e.primary, { blend: .08 }), e.outfit === "sailor" ? (p("box", "Collar", $(0, a + s * .86, -c * .04), $(c * .98, s * .12, c * .66), e.secondary, { round: .5 }), p("box", "Ribbon", $(0, a + s * .76, c * .3), $(c * .34, s * .09, c * .08), e.accent, {
		round: .4,
		blend: 0
	})) : e.outfit === "dress" ? (p("box", "Collar", $(0, a + s * .88, c * .05), $(c * .7, s * .08, c * .5), e.secondary, { round: .5 }), p("box", "Bow", $(0, a + s * .62, c * .3), $(c * .42, s * .08, c * .08), e.accent, {
		round: .45,
		blend: 0
	})) : (p("sphere", "Hood", $(0, a + s * .92, -c * .3), $(c * .85, s * .3, c * .45), e.primary, { blend: .1 }), p("box", "Pocket", $(0, a + s * .3, c * .28), $(c * .6, s * .18, c * .06), Yh(e.primary, .9), { round: .4 }));
	let _ = c * .24, v = s * .92, y = c * (e.outfit === "hoodie" ? .62 : .58);
	p("capsule", "Arms", $(y, a + s * .5, 0), $(_, v, _), Yh(e.primary, .93), {
		...m,
		rotation: [
			0,
			0,
			9
		],
		blend: .02
	}), p("sphere", "Hands", $(y + v / 2 * Math.sin(9 * Math.PI / 180), a + s * .5 - v / 2, 0), $(_ * 1.05, _ * 1.2, _ * 1.05), e.skin, m), p("cylinder", "Neck", $(0, a + s + o * .5, 0), $(c * .2, o + r * .25, c * .2), e.skin), p("sphere", "Face", $(0, l, 0), $(r * .92, r, r * .88), e.skin, { blend: .06 }), p("cone", "Face", $(0, l - r * .33, r * .08), $(r * .5, r * .3, r * .45), e.skin, {
		rotation: [
			180,
			0,
			0
		],
		blend: .22
	});
	let b = r * .18, x = l - r * .07;
	p("sphere", "Eyes", $(b, x, u - r * .035), $(r * .17, r * .25, r * .07), e.eyeColor, {
		...m,
		finish: "glossy",
		blend: 0
	}), p("sphere", "Eyes", $(b, x - r * .02, u - r * .012), $(r * .095, r * .14, r * .04), Yh(e.eyeColor, .35), {
		...m,
		finish: "glossy",
		blend: 0
	}), p("sphere", "Eyes", $(b + r * .035, x + r * .055, u + r * .005), $(r * .06, r * .07, r * .03), "#ffffff", {
		...m,
		finish: "glow",
		blend: 0
	}), p("capsule", "Lashes", $(b + r * .01, x + r * .118, u - r * .03), $(r * .028, r * .2, r * .04), "#2a1a24", {
		...m,
		rotation: [
			0,
			0,
			78
		],
		blend: 0
	}), p("sphere", "Blush", $(r * .27, x - r * .15, u - r * .09), $(r * .13, r * .05, r * .04), "#ff9eb5", {
		...m,
		finish: "matte",
		blend: .02
	});
	let S = -.27, C = u * Math.sqrt(Math.max(0, 1 - (S / .5) ** 2)) + r * .02;
	p("capsule", "Mouth", $(0, l + r * S, C), $(r * .025, r * .08, r * .03), "#b0414f", {
		rotation: [
			0,
			0,
			90
		],
		blend: 0
	});
	let w = e.hairColor;
	p("sphere", "Hair", $(0, l + r * .08, -r * .12), $(r * 1.06, r * 1.06, r * .98), w, { blend: .01 });
	for (let [e, t] of [[16, 1], [46, .85]]) {
		let n = e * Math.PI / 180;
		p("cone", "Fringe", $(r * .45 * Math.sin(n), l + r * .27, r * .45 * Math.cos(n)), $(r * .27, r * .36 * t, r * .22), w, {
			...m,
			rotation: [
				180,
				0,
				0
			],
			blend: .02
		});
	}
	let T = e.hair === "bob";
	if (p("capsule", "Hair", $(r * (T ? .42 : .44), l - r * (T ? .12 : .22), r * .1), $(r * (T ? .3 : .17), r * (T ? .62 : .78), r * .15), w, {
		...m,
		rotation: [
			0,
			0,
			5
		],
		blend: .02
	}), e.hair === "twin-tails") {
		let t = r * (i ? 1.2 : 1.9);
		p("capsule", "Twin tails", $(r * .66, l + r * .15 - t / 2, -r * .18), $(r * .32, t, r * .3), w, {
			...m,
			rotation: [
				0,
				0,
				10
			],
			blend: .12
		}), p("sphere", "Hair ties", $(r * .52, l + r * .22, -r * .14), $(r * .16, r * .16, r * .16), e.accent, {
			...m,
			blend: 0
		});
	} else if (e.hair === "ponytail") {
		let t = r * (i ? 1.1 : 1.6);
		p("capsule", "Ponytail", $(0, l + r * .25 - t / 2, -r * .62), $(r * .34, t, r * .32), w, {
			rotation: [
				-14,
				0,
				0
			],
			blend: .15
		}), p("sphere", "Hair tie", $(0, l + r * .2, -r * .5), $(r * .18, r * .18, r * .18), e.accent, { blend: 0 });
	} else if (e.hair === "long") {
		let e = Math.min(r * 2.4, l - r * .2);
		p("box", "Hair", $(0, l + r * .1 - e / 2, -r * .3), $(r * 1.02, e, r * .36), w, {
			round: .45,
			blend: .15
		});
	}
	return e.accessory === "bow" ? (p("cone", "Bow", $(r * .17, l + r * .5, -r * .05), $(r * .22, r * .26, r * .12), e.accent, {
		...m,
		rotation: [
			0,
			0,
			-90
		],
		blend: 0
	}), p("sphere", "Bow", $(0, l + r * .5, -r * .05), $(r * .1, r * .1, r * .1), Yh(e.accent, .85), { blend: 0 })) : e.accessory === "cat-ears" && (p("cone", "Ears", $(r * .3, l + r * .52, -r * .05), $(r * .28, r * .32, r * .12), w, {
		...m,
		rotation: [
			0,
			0,
			-16
		],
		blend: .05
	}), p("cone", "Ears", $(r * .31, l + r * .5, r * .005), $(r * .16, r * .2, r * .04), "#ffc2d4", {
		...m,
		rotation: [
			0,
			0,
			-16
		],
		blend: 0
	})), A("group", 0, {
		id: je(),
		name: e.name.trim().slice(0, 60) || "Character",
		children: d,
		combine: "add",
		blend: 0
	});
}
function Qh(e) {
	let t = pe(), n = Math.min(4, Math.max(.3, e.height));
	return {
		...t,
		shapes: [Zh(e)],
		light: {
			azimuth: -30,
			elevation: 40,
			intensity: 1.25,
			ambient: .55,
			color: "#fff8f0",
			shadows: !0,
			extra: [{
				azimuth: 160,
				elevation: 35,
				intensity: .7,
				color: "#ffe3ec",
				shadows: !1
			}]
		},
		style: {
			...t.style,
			look: "toon",
			outline: 2.5,
			outlineColor: "#3a2630",
			bands: 3
		},
		background: {
			transparent: !1,
			color: "#fbf4ee",
			picture: ""
		},
		ground: {
			on: !0,
			shadow: .3
		},
		camera: {
			yaw: 18,
			pitch: 6,
			distance: n * 2.6,
			target: [
				0,
				n * .55,
				0
			],
			fov: 30,
			projection: "perspective"
		}
	};
}
//#endregion
//#region ../scene3d/src/model/gamerun.ts
function $h(e, t) {
	for (let n of e.shapes) {
		if (n.id === t) return { shape: n };
		for (let e of n.children ?? []) if (e.id === t) return {
			shape: e,
			group: n
		};
	}
	return null;
}
function eg(e, t) {
	if (!t) return [];
	let n = e.shapes[t[0]];
	if (!n) return [];
	let r = t.length === 2 ? n.children?.[t[1]] : void 0;
	return r ? [r.id, n.id] : [n.id];
}
function tg(e, t) {
	return {
		...e,
		shapes: e.shapes.map((e) => e.children ? {
			...t(e, [e.id]),
			children: e.children.map((n) => t(n, [n.id, e.id]))
		} : t(e, [e.id]))
	};
}
var ng = (e, t = 0) => {
	let n = e * Math.PI / 180, r = t * Math.PI / 180;
	return [
		Math.sin(n) * Math.cos(r),
		Math.sin(r),
		Math.cos(n) * Math.cos(r)
	];
}, rg = (e, t, n = 1) => [
	e[0] + t[0] * n,
	e[1] + t[1] * n,
	e[2] + t[2] * n
], ig = (e) => e < .5 ? 2 * e * e : 1 - (-2 * e + 2) ** 2 / 2, ag = (e, t, n) => t === ">=" ? e >= n : t === "<=" ? e <= n : t === "=" ? e === n : t === "!=" ? e !== n : t === ">" ? e > n : e < n, og = class {
	doc;
	game;
	flags = /* @__PURE__ */ new Set();
	variables = /* @__PURE__ */ new Map();
	items = /* @__PURE__ */ new Set();
	achieved = /* @__PURE__ */ new Set();
	newlyAchieved = [];
	hidden = /* @__PURE__ */ new Set();
	offsets = /* @__PURE__ */ new Map();
	feet;
	yaw;
	pitch = 0;
	time = 0;
	tension;
	fired = /* @__PURE__ */ new Set();
	queue = [];
	pumping = !1;
	lines = [];
	lively = new Ar();
	lifeClock = -1;
	choices = null;
	ended = null;
	level = null;
	inside = /* @__PURE__ */ new Set();
	looking = [];
	reacting = /* @__PURE__ */ new Map();
	tweens = [];
	shot = null;
	film = null;
	title = null;
	waitUntil = 0;
	sounds = [];
	actorYaw = /* @__PURE__ */ new Map();
	actorSpeed = /* @__PURE__ */ new Map();
	wanderTo = /* @__PURE__ */ new Map();
	wanderSeed = 1;
	routes = /* @__PURE__ */ new Map();
	grid = null;
	vy = 0;
	grounded = !0;
	walking = 0;
	heading;
	constructor(e, t) {
		this.doc = e, this.game = hl(e.game ?? Cr(e)), this.feet = [...this.game.player.position], this.yaw = this.game.player.yaw, this.heading = this.yaw, this.tension = Math.max(this.game.tension ?? 0, t?.tension ?? 0);
		for (let e of t?.flags ?? []) this.flags.add(e);
		for (let [e, n] of t?.variables ?? []) this.variables.set(e, n);
		for (let e of t?.items ?? []) this.items.add(e);
		for (let e of t?.achieved ?? []) this.achieved.add(e);
	}
	carry() {
		return {
			achieved: [...this.achieved],
			flags: [...this.flags],
			variables: [...this.variables],
			items: [...this.items],
			tension: this.tension
		};
	}
	setDocument(e) {
		this.doc = e;
	}
	start() {
		this.fire("start", []);
	}
	get busy() {
		return this.lines.length > 0 || !!this.choices || !!this.shot || this.ended !== null || this.level !== null;
	}
	get eye() {
		return [
			this.feet[0],
			this.feet[1] + this.game.player.eye,
			this.feet[2]
		];
	}
	get facing() {
		return ng(this.yaw, this.pitch);
	}
	takeAchievements() {
		let e = this.newlyAchieved;
		return this.newlyAchieved = [], e;
	}
	takeSounds() {
		let e = this.sounds;
		return this.sounds = [], e;
	}
	now(e) {
		let t = new Set((this.game.actors ?? []).map((e) => e.shape)), n = this.lifeClock < 0 ? 0 : Math.max(0, this.time - this.lifeClock);
		return this.lifeClock = this.time, tg(this.doc, (r, i) => {
			let a = r;
			i.some((t) => e.has(t)) && (a = {
				...a,
				hidden: !0
			});
			let o = i.map((e) => this.offsets.get(e)).find(Boolean);
			o && (a = {
				...a,
				position: rg(a.position, o)
			});
			let s = t.has(r.id) ? this.actorYaw.get(r.id) : void 0;
			if (s !== void 0 && (a = {
				...a,
				rotation: [
					a.rotation[0],
					s,
					a.rotation[2]
				]
			}), r.id === this.game.player.shape) {
				a = {
					...a,
					...this.game.player.third ? {} : { hidden: !0 },
					position: [
						this.feet[0],
						this.feet[1] + a.size[1] / 2,
						this.feet[2]
					],
					rotation: [
						a.rotation[0],
						this.heading,
						a.rotation[2]
					]
				};
				let e = this.grounded ? this.walking > this.game.player.speed * 1.4 ? "run" : this.walking > .05 ? "walk" : "idle" : "jump";
				a = this.live(this.gait(a, e), e, n);
			} else if (t.has(r.id)) {
				let e = (this.game.actors ?? []).findIndex((e) => e.shape === r.id), t = this.game.actors[e], i = (this.actorSpeed.get(r.id) ?? 0) > .05 ? "walk" : vr(t.idle, this.time, e + 1);
				a = this.live(this.gait(a, i), i, n);
			}
			return a;
		});
	}
	live(e, t, n) {
		if (!e.rig || e.life?.off || e.take || e.keys?.length) return e;
		let r = ei(this.doc, e), i = this.lines[0]?.match(/^([^:]{1,40}):/)?.[1]?.trim(), a = this.lively.update(e.id, e.position, e.rotation[1], n, t === "run"), { pose: o, face: s } = cr(e.rig, r, e.face, this.time, nr(e.id), e.life, {
			...a,
			talking: t === "talk" || !!i && i === e.name,
			moving: t === "walk" || t === "run",
			seated: /sit|crouch|lie|kneel/.test(t)
		});
		return {
			...e,
			rig: {
				...e.rig,
				pose: o
			},
			...s ? { face: s } : {},
			life: {
				...e.life,
				off: !0
			}
		};
	}
	gait(e, t) {
		if (!e.rig || e.keys?.length || e.take) return e;
		let n = Wc(e.rig, t, this.time);
		return n ? {
			...e,
			rig: {
				...e.rig,
				pose: n
			}
		} : e;
	}
	frame(e, t = 70) {
		let n = /* @__PURE__ */ new Set([...this.game.areas ?? [], ...this.hidden]), r = new Map([...this.reacting].map(([e, t]) => [e, {
			reaction: t.reaction,
			at: t.at
		}])), i = fe(this.now(n), e, r), { focus: a, ...o } = i.camera;
		if (this.shot) {
			let e = [
				this.shot.position[0] - this.shot.target[0],
				this.shot.position[1] - this.shot.target[1],
				this.shot.position[2] - this.shot.target[2]
			], n = Math.max(.05, Math.hypot(...e)), r = 180 / Math.PI;
			return {
				...i,
				camera: {
					...o,
					yaw: Math.atan2(e[0], e[2]) * r,
					pitch: Math.asin(e[1] / n) * r,
					distance: n,
					target: this.shot.target,
					fov: t,
					projection: "perspective"
				}
			};
		}
		let s = this.eye, c = this.facing, l = this.game.player.third ? this.cameraBack() : .05;
		return this.game.player.third ? {
			...i,
			camera: {
				...o,
				yaw: (this.yaw + 360) % 360 - 180,
				pitch: -this.pitch,
				distance: l,
				target: s,
				fov: t,
				projection: "perspective"
			}
		} : {
			...i,
			camera: {
				...o,
				yaw: (this.yaw + 360) % 360 - 180,
				pitch: -this.pitch,
				distance: l,
				target: [
					s[0] + c[0] * l,
					s[1] + c[1] * l,
					s[2] + c[2] * l
				],
				fov: t,
				projection: "perspective"
			}
		};
	}
	cameraBack() {
		let e = this.game.player.eye * 2.2, t = this.walls(), n = this.eye, r = this.facing, i = .2;
		for (; i < e;) {
			let e = un(t, [
				n[0] - r[0] * i,
				n[1] - r[1] * i,
				n[2] - r[2] * i
			]).d;
			if (e < .12) return Math.max(.2, i - .12);
			i += Math.max(.05, e);
		}
		return e;
	}
	groundUnder(e, t, n) {
		let r = Math.min(0, this.game.player.position[1]), i = this.walls(), a = n;
		for (let n = 0; n < 48 && a > r; n++) {
			let n = un(i, [
				e,
				a,
				t
			]).d;
			if (n < .01) return a;
			a -= Math.max(.02, n);
		}
		return r;
	}
	fall(e) {
		if (!this.game.player.jump) return;
		let t = this.game.player.eye, n = this.groundUnder(this.feet[0], this.feet[2], this.feet[1] + t * .5), r = t * .34, i = n > this.feet[1] + r ? this.groundUnder(this.feet[0], this.feet[2], this.feet[1] + r) : n;
		this.vy -= 14 * t * e;
		let a = this.feet[1] + this.vy * e;
		a <= i ? (a = i, this.vy = 0, this.grounded = !0) : this.grounded && this.vy <= 0 && a - i < r * .5 ? (a = i, this.vy = 0) : this.grounded = !1, this.feet = [
			this.feet[0],
			a,
			this.feet[2]
		];
	}
	jump() {
		return !this.game.player.jump || !this.grounded || this.busy ? !1 : (this.vy = this.game.player.jump, this.grounded = !1, !0);
	}
	walls() {
		return this.now(/* @__PURE__ */ new Set([
			...this.game.areas ?? [],
			...this.game.passable ?? [],
			...this.hidden
		]));
	}
	actorAt(e) {
		let t = $h(this.doc, e);
		if (!t || this.hidden.has(e)) return null;
		let n = t.shape;
		return {
			at: rg(n.position, this.offsets.get(e) ?? [
				0,
				0,
				0
			]),
			radius: Math.max(.15, Math.min(n.size[0], n.size[2]) * .3)
		};
	}
	walk(e, t, n) {
		if (this.busy || !e && !t) {
			this.walking = 0;
			return;
		}
		let r = this.feet, i = ng(this.yaw), a = [
			-i[2],
			0,
			i[0]
		], o = Math.hypot(e, t) || 1, s = this.game.player.speed * n / o;
		this.feet = [
			this.feet[0] + (i[0] * e + a[0] * t) * s,
			this.feet[1],
			this.feet[2] + (i[2] * e + a[2] * t) * s
		];
		let c = this.walls(), l = .28 * Math.min(1, this.game.player.eye / 1.55);
		for (let e = 0; e < 3; e++) for (let e of this.game.player.jump ? [.58, .9] : [
			.22,
			.58,
			.9
		]) {
			let t = [
				this.feet[0],
				this.feet[1] + this.game.player.eye * e,
				this.feet[2]
			], n = un(c, t).d;
			if (n >= l) continue;
			let r = .001, i = un(c, [
				t[0] + r,
				t[1],
				t[2]
			]).d - un(c, [
				t[0] - r,
				t[1],
				t[2]
			]).d, a = un(c, [
				t[0],
				t[1],
				t[2] + r
			]).d - un(c, [
				t[0],
				t[1],
				t[2] - r
			]).d, o = Math.hypot(i, a);
			o < 1e-6 || (this.feet = [
				this.feet[0] + i / o * (l - n),
				this.feet[1],
				this.feet[2] + a / o * (l - n)
			]);
		}
		for (let e of this.game.actors ?? []) {
			let t = this.actorAt(e.shape);
			if (!t) continue;
			let n = this.feet[0] - t.at[0], r = this.feet[2] - t.at[2], i = Math.hypot(n, r), a = t.radius + l;
			i < a && i > 1e-6 && (this.feet = [
				t.at[0] + n / i * a,
				this.feet[1],
				t.at[2] + r / i * a
			]);
		}
		let u = this.feet[0] - r[0], d = this.feet[2] - r[2];
		this.walking = n > 0 ? Math.hypot(u, d) / n : 0, this.walking > .05 && (this.heading = Math.atan2(u, d) * 180 / Math.PI);
	}
	turn(e, t) {
		this.busy || (this.yaw = (this.yaw + e + 540) % 360 - 180, this.pitch = Math.min(85, Math.max(-85, this.pitch + t)));
	}
	target() {
		let e = ze(this.frame(0), this.eye, this.facing, 3), t = e ? eg(this.doc, e.shape) : [], n = this.facing;
		for (let t of this.game.actors ?? []) {
			let r = this.actorAt(t.shape);
			if (!r) continue;
			let i = [
				r.at[0] - this.feet[0],
				0,
				r.at[2] - this.feet[2]
			], a = i[0] * n[0] + i[2] * n[2], o = Math.hypot(i[0] - n[0] * a, i[2] - n[2] * a);
			if (a > 0 && a < 3 && o < r.radius * 1.6 && (!e || a < e.t)) return [t.shape];
		}
		return t;
	}
	tick(e) {
		this.time += e;
		for (let [t, n] of this.reacting) n.at += e / n.seconds, n.at >= 1 && this.reacting.delete(t);
		if (this.tweens = this.tweens.filter((e) => {
			let t = e.seconds > 0 ? Math.min(1, (this.time - e.start) / e.seconds) : 1, n = ig(t);
			return this.offsets.set(e.shape, [
				e.from[0] + (e.to[0] - e.from[0]) * n,
				e.from[1] + (e.to[1] - e.from[1]) * n,
				e.from[2] + (e.to[2] - e.from[2]) * n
			]), t < 1;
		}), this.title && this.time >= this.title.until && (this.title = null), this.film) {
			let e = yl(this.film.film, this.game.shots ?? [], this.time - this.film.start);
			e && this.shot && Object.assign(this.shot, e), (!e || this.time >= this.film.start + vl(this.film.film)) && (this.film = null);
		}
		if (this.shot && this.time >= this.shot.until && (this.shot = null, this.pump()), this.waitUntil && this.time >= this.waitUntil && (this.waitUntil = 0, this.pump()), this.moveActors(e), this.fall(e), this.ended !== null || this.level !== null) return;
		for (let e of this.game.rules) e.on === "time" && !this.fired.has(e.id) && this.time >= (e.seconds ?? 0) && this.allowed(e) && this.run(e);
		let t = [
			this.feet[0],
			this.feet[1] + this.game.player.eye * .5,
			this.feet[2]
		];
		for (let e of this.game.areas ?? []) {
			let n = $h(this.doc, e);
			if (!n) continue;
			let r = ke(n.shape, t) < 0;
			r && !this.inside.has(e) ? (this.inside.add(e), this.fire("enter", [e])) : !r && this.inside.has(e) && (this.inside.delete(e), this.fire("leave", [e]));
		}
		if (!this.busy) {
			let e = this.target();
			e.join() !== this.looking.join() && (this.looking = e, e.length && this.fire("look", e));
		}
	}
	random() {
		return this.wanderSeed = this.wanderSeed * 16807 % 2147483647, this.wanderSeed / 2147483647;
	}
	clearAt(e, t) {
		return un(this.walls(), [
			e[0],
			e[1] + .6,
			e[2]
		]).d > t * .5;
	}
	moveActors(e) {
		for (let t of this.game.actors ?? []) {
			this.actorSpeed.set(t.shape, 0);
			let n = this.actorAt(t.shape);
			if (!n || this.tweens.some((e) => e.shape === t.shape)) continue;
			let r = [
				this.feet[0] - n.at[0],
				0,
				this.feet[2] - n.at[2]
			], i = Math.hypot(r[0], r[2]);
			t.faces && i > .001 && this.actorYaw.set(t.shape, Math.atan2(r[0], r[2]) * 180 / Math.PI);
			let a = (r, i) => {
				let a = Math.hypot(r[0], r[2]);
				if (a < .001) return;
				let o = Math.min(a, e * i), s = [
					r[0] / a * o,
					0,
					r[2] / a * o
				];
				this.clearAt(rg(n.at, s), n.radius) && (this.offsets.set(t.shape, rg(this.offsets.get(t.shape) ?? [
					0,
					0,
					0
				], s)), this.actorSpeed.set(t.shape, i), this.actorYaw.set(t.shape, Math.atan2(r[0], r[2]) * 180 / Math.PI));
			};
			if (this.busy) continue;
			if (t.routine?.length) {
				this.walkRoutine(t, n.at, e);
				continue;
			}
			if (t.follows) {
				i > 1.6 && a(r, Math.min(this.game.player.speed * .9, 2.4));
				continue;
			}
			if (t.wanders) {
				let e = this.wanderTo.get(t.shape);
				if (!e || this.time > e.until) {
					let r = $h(this.doc, t.shape)?.shape.position ?? n.at, i = this.random() * Math.PI * 2, a = .8 + this.random() * 2.2;
					e = {
						to: [
							r[0] + Math.cos(i) * a,
							n.at[1],
							r[2] + Math.sin(i) * a
						],
						until: this.time + 3 + this.random() * 3
					}, this.wanderTo.set(t.shape, e);
				}
				let r = [
					e.to[0] - n.at[0],
					0,
					e.to[2] - n.at[2]
				];
				Math.hypot(r[0], r[2]) > .1 && a(r, .9);
				continue;
			}
			if (!t.creeps || i < 1.3) continue;
			let o = this.facing;
			if (-(o[0] * r[0] + o[2] * r[2]) / i > .2) continue;
			let s = Math.min(i - 1.3, e * 1.2);
			this.offsets.set(t.shape, rg(this.offsets.get(t.shape) ?? [
				0,
				0,
				0
			], [
				r[0] / i * s,
				0,
				r[2] / i * s
			]));
		}
	}
	jumpTo(e) {
		let t = this.game.clock ?? tl;
		this.time = Math.max(0, (e - t.start) / Math.max(1e-6, t.minutesPerSecond)), this.routes.clear();
		for (let t of this.game.actors ?? []) {
			let n = t.routine?.length ? dl(t.routine, e % 1440) : void 0, r = n ? $h(this.doc, n.spot)?.shape : void 0, i = $h(this.doc, t.shape)?.shape;
			r && i && this.offsets.set(t.shape, [
				r.position[0] - i.position[0],
				0,
				r.position[2] - i.position[2]
			]);
		}
	}
	snapshot() {
		let e = (e) => e.map((e) => Math.round(e * 100) / 100);
		return {
			minute: Math.round(this.minute * 10) / 10,
			clock: al(this.minute),
			player: e(this.feet),
			actors: (this.game.actors ?? []).flatMap((t, n) => {
				let r = this.actorAt(t.shape);
				if (!r) return [];
				let i = (this.actorSpeed.get(t.shape) ?? 0) > .05, a = t.routine?.length ? dl(t.routine, this.minute % 1440) : void 0;
				return [{
					shape: t.shape,
					name: $h(this.doc, t.shape)?.shape.name ?? t.shape,
					at: e(r.at),
					move: i ? "walk" : vr(t.idle, this.time, n + 1),
					...a ? { spot: a.spot } : {}
				}];
			}),
			flags: [...this.flags].sort(),
			items: [...this.items].sort(),
			achieved: [...this.achieved].sort()
		};
	}
	get minute() {
		let e = this.game.clock ?? tl;
		return e.start + this.time * e.minutesPerSecond;
	}
	walkRoutine(e, t, n) {
		let r = dl(e.routine, this.minute % 1440);
		if (!r) return;
		let i = this.routes.get(e.shape);
		if (!i || i.block !== r) {
			let n = $h(this.doc, r.spot)?.shape;
			if (!n) return;
			this.grid ??= cl(this.doc.shapes, this.game), i = {
				block: r,
				legs: ll(this.grid, t, [
					n.position[0],
					t[1],
					n.position[2]
				]) ?? []
			}, this.routes.set(e.shape, i);
		}
		let a = i.legs[0];
		if (!a) return;
		let o = [
			a[0] - t[0],
			0,
			a[2] - t[2]
		], s = Math.hypot(o[0], o[2]);
		s <= n * 1.4 ? (i.legs.shift(), this.offsets.set(e.shape, rg(this.offsets.get(e.shape) ?? [
			0,
			0,
			0
		], o))) : (this.offsets.set(e.shape, rg(this.offsets.get(e.shape) ?? [
			0,
			0,
			0
		], [
			o[0] / s * n * nl,
			0,
			o[2] / s * n * nl
		])), this.actorSpeed.set(e.shape, nl), this.actorYaw.set(e.shape, Math.atan2(o[0], o[2]) * 180 / Math.PI));
	}
	use() {
		this.busy || this.fire("use", this.target());
	}
	next() {
		this.lines.length && (this.lines.shift(), this.lines.length || this.pump());
	}
	choose(e) {
		let t = this.choices?.[e];
		t && (this.choices = null, this.setFlag(t.flag), this.pump());
	}
	view() {
		let e = null;
		if (!this.busy && this.looking.length) {
			let t = this.game.rules.find((e) => e.on === "use" && this.about(e, this.looking) && this.allowed(e));
			if (t) {
				let n = this.looking.find((e) => e === t.shape || t.also?.includes(e)) ?? t.shape;
				e = $h(this.doc, n)?.shape.name ?? "Use";
			}
		}
		return {
			line: this.lines[0] ?? null,
			choices: this.choices?.map((e) => e.text) ?? null,
			prompt: e,
			title: this.title?.text ?? null,
			items: [...this.items],
			numbers: (this.game.hud ?? []).map((e) => [e, this.variables.get(e) ?? 0]),
			tension: this.tension,
			shot: !!this.shot,
			objectives: gl(this.game.quests, this.flags),
			clock: this.game.actors?.some((e) => e.routine?.length) ? al(this.minute) : null,
			ended: this.ended,
			level: this.level
		};
	}
	about(e, t) {
		return t.some((t) => t === e.shape || e.also?.includes(t));
	}
	allowed(e) {
		return !(e.once && this.fired.has(e.id)) && (e.if ?? []).every((e) => this.flags.has(e)) && !(e.unless ?? []).some((e) => this.flags.has(e)) && (e.has ?? []).every((e) => this.items.has(e)) && (e.need ?? []).every((e) => ag(this.variables.get(e.variable) ?? 0, e.op, e.value));
	}
	fire(e, t) {
		let n = this.game.rules.filter((n) => n.on === e && (!ue.includes(e) || this.about(n, t)) && (e !== "flag" || t.includes(n.flag ?? "")) && this.allowed(n));
		if (!n.length) return;
		for (let e of n) this.fired.add(e.id);
		let r = n.flatMap((e) => e.actions);
		e === "flag" ? this.queue.unshift(...r) : this.queue.push(...r), this.pump();
	}
	run(e) {
		this.fired.add(e.id), this.queue.push(...e.actions), this.pump();
	}
	setFlag(e) {
		let t = this.flags.has(e);
		this.flags.add(e), t || this.fire("flag", [e]);
	}
	pump() {
		if (!this.pumping) {
			this.pumping = !0;
			try {
				for (; this.queue.length && !this.lines.length && !this.choices && !this.shot && !this.waitUntil && this.ended === null && this.level === null;) {
					let e = this.queue.shift();
					switch (e.kind) {
						case "say":
							this.lines = [...e.lines], e.voice && this.sounds.push({
								sound: e.voice,
								volume: 1,
								music: !1,
								line: e.lines[0]
							});
							break;
						case "ask":
							this.choices = e.options.map((e) => ({ ...e }));
							break;
						case "set":
							this.setFlag(e.flag);
							break;
						case "clear":
							this.flags.delete(e.flag);
							break;
						case "add":
							this.variables.set(e.variable, (this.variables.get(e.variable) ?? 0) + e.by);
							break;
						case "give":
							this.items.add(e.item);
							break;
						case "take":
							this.items.delete(e.item);
							break;
						case "show":
							this.hidden.delete(e.shape);
							break;
						case "hide":
							this.hidden.add(e.shape);
							break;
						case "move": {
							let t = this.offsets.get(e.shape) ?? [
								0,
								0,
								0
							];
							this.tweens = this.tweens.filter((t) => t.shape !== e.shape), this.tweens.push({
								shape: e.shape,
								from: t,
								to: rg(t, e.by),
								start: this.time,
								seconds: e.seconds
							});
							break;
						}
						case "walk": {
							let t = $h(this.doc, e.shape);
							if (!t) break;
							let n = this.offsets.get(e.shape) ?? [
								0,
								0,
								0
							], r = t.shape.position;
							this.tweens = this.tweens.filter((t) => t.shape !== e.shape), this.tweens.push({
								shape: e.shape,
								from: n,
								to: [
									e.to[0] - r[0],
									n[1],
									e.to[2] - r[2]
								],
								start: this.time,
								seconds: e.seconds
							});
							let i = [
								e.to[0] - r[0] - n[0],
								0,
								e.to[2] - r[2] - n[2]
							];
							Math.hypot(i[0], i[2]) > .001 && this.actorYaw.set(e.shape, Math.atan2(i[0], i[2]) * 180 / Math.PI);
							break;
						}
						case "react":
							this.reacting.set(e.shape, {
								reaction: e.reaction,
								at: 0,
								seconds: $h(this.doc, e.shape)?.shape.triggers?.seconds ?? .8
							});
							break;
						case "camera":
							{
								let t = e.shot ? this.game.shots?.find((t) => t.id === e.shot) : void 0;
								this.shot = {
									position: t?.position ?? e.position,
									target: t?.target ?? e.target,
									until: this.time + e.seconds
								};
								let n = e.film ? this.game.films?.find((t) => t.id === e.film) : void 0, r = n ? yl(n, this.game.shots ?? [], 0) : null;
								n && r && (this.film = {
									film: n,
									start: this.time
								}, this.shot = {
									...r,
									until: this.time + vl(n)
								});
							}
							break;
						case "title":
							this.title = {
								text: e.text,
								until: this.time + e.seconds
							};
							break;
						case "sound":
						case "music":
							this.sounds.push({
								sound: e.sound,
								volume: e.volume,
								music: e.kind === "music"
							});
							break;
						case "wait":
							e.seconds > 0 && (this.waitUntil = this.time + e.seconds);
							break;
						case "tension":
							this.tension = Math.min(1, Math.max(0, this.tension + e.by));
							break;
						case "achieve":
							this.achieved.has(e.achievement) || (this.achieved.add(e.achievement), this.newlyAchieved.push(e.achievement));
							break;
						case "level":
							this.level = e.level, this.queue = [];
							break;
						case "end": this.ended = e.text, this.queue = [];
					}
				}
			} finally {
				this.pumping = !1;
			}
		}
	}
}, sg = (e, t = [
	0,
	0,
	0
]) => [...[-1, 1].map((n) => ({
	prim: "sphere",
	dims: [
		e * .5,
		0,
		0
	],
	at: [
		t[0] + e * .48 * n,
		t[1],
		t[2]
	],
	turn: [
		0,
		0,
		14 * n
	],
	scale: [
		1,
		.62,
		.32
	],
	paint: "colour"
})), {
	prim: "sphere",
	dims: [
		e * .2,
		0,
		0
	],
	at: [
		t[0],
		t[1],
		t[2] + e * .06
	],
	scale: [
		1,
		1,
		.7
	],
	paint: "colour"
}];
[-1, 1].flatMap((e) => [{
	prim: "sphere",
	dims: [
		.036,
		0,
		0
	],
	at: [
		.075 * e,
		0,
		0
	],
	turn: [
		0,
		0,
		-18 * e
	],
	scale: [
		1,
		1,
		.45
	],
	paint: "colour"
}, {
	prim: "sphere",
	dims: [
		.022,
		0,
		0
	],
	at: [
		.075 * e,
		-.002,
		.012
	],
	turn: [
		0,
		0,
		-18 * e
	],
	scale: [
		1,
		1,
		.3
	],
	paint: "colour2"
}]), [...[-1, 1].map((e) => ({
	prim: "torus",
	dims: [
		.021,
		.0022,
		0
	],
	at: [
		.032 * e,
		-.002,
		-.001
	],
	turn: [
		90,
		0,
		0
	],
	paint: "colour",
	metal: .9,
	rough: .25
}))], [...[-1, 1].flatMap((e) => [{
	prim: "cylinder",
	dims: [
		.026,
		.022,
		0
	],
	at: [
		.034 * e,
		.01,
		.1
	],
	turn: [
		70,
		0,
		0
	],
	paint: "colour",
	rough: .4
}, {
	prim: "cylinder",
	dims: [
		.021,
		.004,
		0
	],
	at: [
		.034 * e,
		.018,
		.111
	],
	turn: [
		70,
		0,
		0
	],
	paint: "colour2",
	rough: .05
}])], [...[-1, 1].map((e) => ({
	prim: "box",
	dims: [
		.008,
		.15,
		.003
	],
	at: [
		.05 * e,
		.095,
		-.03
	],
	turn: [
		-35,
		0,
		22 * e
	],
	paint: "colour2"
}))], sg(.035), [...[
	0,
	1,
	2,
	3,
	4
].map((e) => ({
	prim: "sphere",
	dims: [
		.004,
		0,
		0
	],
	at: [
		(e - 2) * .007,
		.016,
		e % 2 * .004
	],
	paint: e % 2 ? "#4cb4ff" : "colour2",
	rough: .2
}))], [-1, 1].flatMap((e) => [{
	prim: "ear",
	dims: [
		.066,
		.078,
		.014
	],
	at: [
		.062 * e,
		0,
		0
	],
	turn: [
		0,
		14 * e,
		-24 * e
	],
	paint: "colour",
	rough: .75
}, {
	prim: "ear",
	dims: [
		.04,
		.052,
		.004
	],
	at: [
		.0655 * e,
		.004,
		.004
	],
	turn: [
		0,
		14 * e,
		-24 * e
	],
	paint: "colour2",
	rough: .85
}]);
//#endregion
//#region ../scene3d/src/model/core.ts
var cg = /* @__PURE__ */ e({
	ADULT_AGE: () => 18,
	AD_PALETTES: () => Lh,
	AD_STYLES: () => Ih,
	ALL_KINDS: () => yi,
	ANIMATIONS: () => jc,
	ANIMATION_GROUPS: () => yc,
	AVATAR_COLOURS: () => or,
	AVATAR_COLOUR_LABEL: () => er,
	AVATAR_EXPRESSIONS: () => mn,
	AVATAR_EYE_STYLES: () => yn,
	AVATAR_EYE_STYLE_LABEL: () => Gr,
	AVATAR_FACE_SHAPES: () => Mi,
	AVATAR_FACE_SHAPE_LABEL: () => qi,
	AVATAR_FEATURES: () => Tn,
	AVATAR_FEATURE_LABEL: () => Vi,
	AVATAR_LAYERS: () => Dt,
	AVATAR_LAYER_LABEL: () => ae,
	AVATAR_MAKEUP_AMOUNTS: () => mi,
	AVATAR_MAKEUP_LABEL: () => An,
	AVATAR_PATTERNS: () => Li,
	AVATAR_PATTERN_LABEL: () => jt,
	AVATAR_SHAPES: () => me,
	AVATAR_SHAPE_LABEL: () => le,
	AVATAR_STYLES: () => ct,
	AXES: () => Rr,
	BRUSHES: () => pc,
	BRUSH_LABEL: () => mc,
	CAST_ROLES: () => Vu,
	CHANNEL_WRITES: () => qa,
	COMBINE: () => si,
	COMMON_PARAMS: () => xc,
	COMPARE: () => En,
	DEFAULT_CLOCK: () => tl,
	DEFAULT_HAIR_STYLE: () => nn,
	DEFAULT_MOTION: () => Bi,
	DEFAULT_TRIGGER_SECONDS: () => $e,
	DEPTH_FAR: () => 500,
	DEPTH_NEAR: () => zo,
	DRAW_CHANNELS: () => no,
	DRAW_CHANNEL_LABEL: () => eo,
	DRAW_TOOLS: () => Ya,
	DRAW_TOOL_LABEL: () => Ja,
	EASES: () => Se,
	EASE_LABEL: () => Fe,
	EFFECT_KINDS: () => Gn,
	ELEMENT_LABEL: () => Ma,
	ELEMENT_MODES: () => fo,
	ENDING_KINDS: () => El,
	EXAMPLE_SCRIPT: () => Rd,
	EXPORT_DETAIL: () => la,
	EXPORT_FORMATS: () => da,
	FACE_BROW_STYLES: () => Nr,
	FACE_BROW_STYLE_LABEL: () => ar,
	FACE_LINE_STYLES: () => $n,
	FACE_LINE_STYLE_LABEL: () => pn,
	FIELD_RANGE: () => 24,
	FIELD_SIZE: () => 256,
	FINISH: () => ea,
	FINISHES: () => ur,
	FINISH_EXTRA: () => ne,
	FOCUS_SPREAD: () => Vo,
	FOCUS_TAPS: () => 64,
	GAME_ACTIONS: () => Hi,
	GAME_ACTION_LABEL: () => Ot,
	GAME_EVENTS: () => oe,
	GAME_EVENT_LABEL: () => Ri,
	GAME_TARGETS: () => Ou,
	GEOMETRY_NODES: () => kr,
	GameRun: () => og,
	HAIR_BANGS: () => Zt,
	HAIR_BANGS_LABEL: () => cn,
	HAIR_SEGMENTS: () => 6,
	HAIR_STYLE_PRESETS: () => vt,
	HAIR_TAILS: () => x,
	HAIR_TAILS_LABEL: () => Vn,
	KEY_SNAP: () => Xe,
	LABEL_SIDES: () => hr,
	LABEL_SIDE_LABEL: () => Cn,
	LIGHT_KINDS: () => vn,
	LOOKS: () => Wr,
	Lively: () => Ar,
	MADE_WITH: () => Ol,
	MATERIAL_LOOKS: () => v,
	MATERIAL_NODES: () => Di,
	MATERIAL_PRESETS: () => to,
	MATERIAL_SHADERS: () => io,
	MATERIAL_SHADER_LABEL: () => Wa,
	MAX_ACHIEVEMENTS: () => 100,
	MAX_ACTIONS: () => 16,
	MAX_AROUND: () => 64,
	MAX_ASSETS_CHARS: () => pi,
	MAX_ASSET_CHARS: () => kn,
	MAX_BONES: () => se,
	MAX_CHARACTERS: () => 32,
	MAX_CHOICES: () => 6,
	MAX_COPIES: () => 200,
	MAX_EFFECTS: () => 4,
	MAX_ENDINGS: () => 64,
	MAX_EXTRA_LIGHTS: () => 2,
	MAX_FIELDS: () => 16,
	MAX_GRID: () => 20,
	MAX_HEROINES: () => 12,
	MAX_KEYS: () => 120,
	MAX_LABELS: () => 4,
	MAX_LABEL_CHARS: () => Yr,
	MAX_LEVELS: () => 64,
	MAX_LINES: () => 12,
	MAX_MESHES: () => 16,
	MAX_MUSIC_CHARS: () => yt,
	MAX_NODES: () => 24,
	MAX_OPTIONS: () => 4,
	MAX_PICTURES: () => 400,
	MAX_PICTURE_CHARS: () => Er,
	MAX_ROMANCE_PICTURE_CHARS: () => Dl,
	MAX_RULES: () => 96,
	MAX_SCENES: () => 600,
	MAX_SCENE_LINES: () => 400,
	MAX_SHAPES: () => 256,
	MAX_SKELETON_BONES: () => 256,
	MAX_SOUNDS: () => 64,
	MAX_SOUND_CHARS: () => Ql,
	MAX_STRIPS: () => 16,
	MAX_TAKE_CHARS: () => Je,
	MAX_TRACE_MATERIALS: () => 32,
	MAX_TRACE_PICTURES: () => 32,
	MAX_TRIANGLES: () => go,
	MOTION_KINDS: () => Pt,
	MOTION_LABEL: () => _e,
	ModelEditor: () => wo,
	NARRATOR: () => "",
	NEXT_PART: () => Pi,
	NO_COMPOSE: () => Xt,
	OUTLINES: () => li,
	PICTURE_KINDS: () => Cl,
	PICTURE_KIND_LABEL: () => wl,
	PLAYER: () => "me",
	PROFILES: () => fr,
	PYTHON_PRELUDE: () => Ld,
	QUEST_STEPS: () => Mt,
	QUEST_STEP_LABEL: () => he,
	RATINGS: () => xl,
	RATING_LABEL: () => Sl,
	REACTIONS: () => it,
	REACTION_LABEL: () => mt,
	REQUIRED_HUMAN_BONES: () => Yi,
	ROUTINE_WALK: () => nl,
	RomanceRun: () => Hl,
	SHAPE_EVENTS: () => ue,
	SHAPE_KINDS: () => wi,
	SHAPE_LABELS: () => Fn,
	SHAPE_ROLE_LABEL: () => wu,
	SIDE_CODE: () => vi,
	STAGE_PLACES: () => Tl,
	STILL_POSES: () => Nc,
	TALK_SHAPES: () => Wu,
	TEXT_ALIGNS: () => Kn,
	TRACE_LOOK: () => fa,
	TRI_TEXELS: () => 12,
	VIEWS: () => Xr,
	VMD_FACES: () => vd,
	VMD_SKELETON: () => pd,
	actorShape: () => _u,
	addToSelection: () => ga,
	alignMoves: () => Un,
	animate: () => fe,
	animationById: () => Mc,
	animationParams: () => Fc,
	animationTiming: () => Hc,
	applyExpression: () => Sr,
	applyHands: () => Vc,
	area: () => bn,
	armsResting: () => Ju,
	assembleAvatar: () => T,
	assembleKit: () => _r,
	assetFromObject3D: () => ho,
	assetsOf: () => Vr,
	avatarGeometry: () => Qe,
	avatarLayers: () => rt,
	avatarPictures: () => pt,
	bakeAnimation: () => Gc,
	bakeCharacter: () => gu,
	bakeLook: () => ba,
	bakeSprings: () => Hr,
	bareSkeleton: () => Kh,
	beginStroke: () => Va,
	bestAffection: () => Gl,
	blendParts: () => On,
	blendRadius: () => Ut,
	blendSquare: () => so,
	blendWeights: () => uo,
	blinkAt: () => Oi,
	blockAt: () => dl,
	blurByDepth: () => Wo,
	bodyBalls: () => di,
	boneFrames: () => zi,
	boneTail: () => p,
	boneWeights: () => Nt,
	boundsOf: () => g,
	browserCanvas: () => jo,
	browserDecode: () => rr,
	brush: () => gc,
	budget: () => Mr,
	buildAd: () => Hh,
	buildTraceMesh: () => ca,
	bumpNormals: () => Ua,
	cameraAt: () => Tt,
	cameraKeyAt: () => ta,
	cameraMovedFromKeys: () => re,
	cameraTakeAt: () => Ct,
	canDraw: () => lo,
	canLink: () => Rn,
	canMorph: () => Wi,
	castRole: () => Hu,
	chainRig: () => ge,
	channelPicture: () => Na,
	characterDesign: () => Qh,
	characterModel: () => hu,
	characterShapes: () => Zh,
	checkAchievements: () => su,
	checkAssets: () => ir,
	checkAvatarChoice: () => ye,
	checkCameraKeys: () => Wt,
	checkCameraTake: () => $i,
	checkCompose: () => sn,
	checkEffects: () => Ci,
	checkEnvironment: () => Qn,
	checkExtraLights: () => fn,
	checkEyes: () => Dr,
	checkFacePaint: () => ji,
	checkFocus: () => Ai,
	checkForm: () => Gi,
	checkGame: () => lt,
	checkGraph: () => Yn,
	checkHairStyle: () => bi,
	checkKeyBase: () => Ae,
	checkKeys: () => zt,
	checkLabel: () => Pn,
	checkLife: () => zn,
	checkMakeup: () => Ti,
	checkMirror: () => wn,
	checkModel: () => P,
	checkMotion: () => dt,
	checkMusic: () => S,
	checkOutline: () => Et,
	checkPen: () => Ce,
	checkProject: () => au,
	checkRepeat: () => ie,
	checkRevolve: () => Ii,
	checkRig: () => de,
	checkRomance: () => Rl,
	checkSequence: () => Ie,
	checkShape: () => N,
	checkShapeTake: () => te,
	checkSprings: () => mr,
	checkTakes: () => Ht,
	checkTriggers: () => be,
	chibiFace: () => Me,
	circleOf: () => Ho,
	clockText: () => al,
	colourByNodes: () => $r,
	colourName: () => _s,
	composePixels: () => _t,
	computeNormals: () => u,
	copiesDistance: () => ke,
	copiesOf: () => ui,
	copyCentres: () => Rt,
	copyUniforms: () => Jt,
	createModel: () => pe,
	createShape: () => A,
	cutAcross: () => Ia,
	cutDress: () => qe,
	cutMesh: () => nc,
	daylight: () => Jc,
	defaultGame: () => Cr,
	defaultMaterial: () => o,
	deleteElements: () => Sa,
	designFile: () => st,
	designLights: () => Yo,
	designLosses: () => xr,
	designMesh: () => ra,
	detailAvatar: () => In,
	dice: () => Xn,
	drapeCloth: () => Ad,
	drawSize: () => Po,
	drawTouch: () => _a,
	drawingPictures: () => co,
	drawnAs: () => Io,
	drawnAt: () => Pa,
	effectParticles: () => Ur,
	endStroke: () => ya,
	enlargePicture: () => qn,
	eulerOf: () => Tr,
	exportBlockers: () => Jl,
	exportModel: () => sa,
	exportRiggedGlb: () => Hs,
	exportVrm: () => qs,
	extrudeFaces: () => Fa,
	faceNames: () => ei,
	facedParts: () => At,
	facesBack: () => Dn,
	fieldContours: () => gr,
	fieldOf: () => Kr,
	figureRig: () => ut,
	fillElements: () => La,
	filmCamera: () => yl,
	filmSeconds: () => vl,
	findBeat: () => Wn,
	findRoute: () => ll,
	finish: () => m,
	finishPicture: () => Ro,
	fitProject: () => Mu,
	fitsBudget: () => Ze,
	flagName: () => E,
	flatPatch: () => xa,
	flipMesh: () => ec,
	focusFor: () => Bo,
	focusOffsetTo: () => Ko,
	formOf: () => M,
	formedDistance: () => We,
	frameParticles: () => fi,
	freeId: () => fu,
	fromBase64: () => _,
	fromDataUrl: () => Lo,
	geometryPlaces: () => Fr,
	groundMoves: () => pr,
	groupKeyed: () => Yt,
	growHair: () => Ha,
	hairLocks: () => zr,
	hairPicture: () => ci,
	hasMature: () => Bl,
	hasMotion: () => O,
	hasOutline: () => nt,
	headlineLines: () => Rh,
	heightKey: () => va,
	holds: () => Vl,
	humanoidOf: () => Ui,
	idleMove: () => vr,
	idsAt: () => eg,
	instanceCopies: () => sr,
	isFigureRig: () => Rc,
	isHumanoid: () => kt,
	isPerson: () => Oe,
	isPlain: () => b,
	isPosed: () => wr,
	isProject: () => tu,
	join: () => ai,
	joinMeshes: () => ic,
	keyAt: () => Te,
	keyPatch: () => Ge,
	keyedAt: () => oi,
	labelPicture: () => jr,
	labelRect: () => ki,
	labelSample: () => Bn,
	labelUv: () => Zn,
	labelledShapes: () => ti,
	lengthenHair: () => St,
	lifeBones: () => Ir,
	lightDirection: () => Jo,
	lightFlags: () => td,
	linearColor: () => ft,
	lintGameProject: () => xu,
	livePose: () => cr,
	lookedAt: () => br,
	loopCut: () => Ta,
	loudness: () => Si,
	mainColour: () => Oo,
	makeRiggedHair: () => dr,
	makeTake: () => Lt,
	march: () => ze,
	markStroke: () => ka,
	markedSquare: () => Qa,
	materialAt: () => $a,
	materialColour: () => tr,
	mergeElements: () => ro,
	meshAsset: () => s,
	meshBlocks: () => _n,
	meshBvh: () => d,
	meshShapes: () => ve,
	modelAssetFromGlb: () => pu,
	modelFromOutline: () => To,
	modelFromPicture: () => ko,
	modelSpace: () => vc,
	modelToSvg: () => ls,
	modelWithShape: () => dc,
	moveElements: () => wa,
	movePose: () => Bc,
	movePoseOn: () => Wc,
	moveRig: () => Lc,
	movedBy: () => xn,
	movedFromKeys: () => Be,
	mulTurn: () => D,
	needsFinish: () => Fo,
	newId: () => je,
	newNode: () => hn,
	newProject: () => cu,
	noKeys: () => on,
	nodeSpecs: () => Ni,
	normalizeContours: () => hi,
	onLabelReady: () => Lr,
	openDesignFile: () => Ke,
	openProjectFile: () => uu,
	outlineFrom: () => xt,
	outlineFromAlpha: () => Do,
	outlineFromPicture: () => Mo,
	outlineSize: () => Zi,
	ownRig: () => yr,
	packCharacter: () => Xu,
	packWorld: () => nd,
	paintByPlace: () => Zr,
	paintFaceLines: () => Ki,
	paintPattern: () => Qi,
	parseClock: () => ol,
	parsePathData: () => Ts,
	parseVmd: () => ad,
	pathData: () => ss,
	penContours: () => Ve,
	penFromContours: () => ni,
	pickElement: () => za,
	pictureCard: () => Fh,
	pictureLikeness: () => Lu,
	pixelBlock: () => No,
	placeAt: () => Ra,
	placedParts: () => pa,
	planRetarget: () => qt,
	playableGame: () => hl,
	poseAt: () => tt,
	poseAtTime: () => en,
	poseToShape: () => dn,
	posed: () => ot,
	posedBones: () => et,
	posedParts: () => at,
	prepareLabels: () => lr,
	prepareMeshes: () => Fi,
	projectCost: () => Au,
	projectCredits: () => Cu,
	projectFile: () => lu,
	projectLosses: () => du,
	pruneAssets: () => k,
	questFindings: () => _l,
	questObjectives: () => gl,
	questRules: () => ml,
	questStepFlag: () => pl,
	rasterize: () => jn,
	reach: () => ht,
	reachableEndings: () => Kl,
	reactionFor: () => Ne,
	reactionMotion: () => gt,
	readAvatarSkin: () => ee,
	readGltf: () => y,
	readMmdModel: () => Od,
	readModelFile: () => c,
	readyChannel: () => ha,
	readyToDraw: () => Za,
	recolourAvatar: () => Vt,
	recolourPixels: () => De,
	reduceBones: () => ju,
	refit: () => rc,
	regionsOf: () => cs,
	remeshMesh: () => uc,
	renderModelCpu: () => rs,
	resizePicture: () => Da,
	retargetPose: () => we,
	retargetTake: () => Ue,
	riggedAsset: () => Ls,
	romanceFindings: () => ql,
	romanceForRating: () => zl,
	romancePack: () => Zl,
	rotationMatrix: () => an,
	routeGrid: () => cl,
	routeLength: () => ul,
	routineFindings: () => fl,
	sampleClips: () => Gh,
	sampleField: () => Or,
	sampleRomance: () => Xa,
	sampleScene: () => $t,
	sayLines: () => Fu,
	scaleElements: () => Ba,
	sceneDistance: () => un,
	scriptCall: () => Id,
	scriptCalls: () => Fd,
	seedOf: () => nr,
	segmentDistances: () => Ei,
	selectionCentre: () => ja,
	selectionEdges: () => ma,
	sequenceSeconds: () => tn,
	setCameraKey: () => bt,
	setKey: () => w,
	shaderOf: () => oo,
	shapeAt: () => Bt,
	shapeBaseName: () => Eu,
	shapeBody: () => It,
	shapeBox: () => qr,
	shapeById: () => $h,
	shapeDistance: () => C,
	shapeFace: () => Kt,
	shapeLimbs: () => j,
	shapeModel: () => ce,
	shapeRole: () => Tu,
	shapeSprings: () => Sn,
	shapeTakePose: () => ii,
	shapeWithRole: () => Du,
	shapesFromSvg: () => Eo,
	silhouetteOf: () => Ln,
	simplify: () => Jn,
	simplifyMesh: () => $s,
	simulateDrop: () => Nh,
	skeletonOf: () => mo,
	skyPixels: () => el,
	smoothFaceShading: () => He,
	smoothMesh: () => Zs,
	splitDesign: () => ru,
	spreadMoves: () => gi,
	springJoints: () => Jr,
	sprungPose: () => _i,
	spunSilhouette: () => Qr,
	startDrawing: () => Oa,
	startStroke: () => hc,
	startingGraph: () => Ji,
	steps: () => Ee,
	stillPoseOn: () => Pc,
	storyData: () => bl,
	stretchLegs: () => ri,
	strokeModel: () => _c,
	subdivideMesh: () => fc,
	surfaceNets: () => ia,
	svgOutlines: () => Is,
	sweepCut: () => Hn,
	takeFaces: () => Re,
	takeFramePose: () => rn,
	takeFrames: () => Qt,
	takePose: () => ln,
	takesFromThree: () => qh,
	talkExpressions: () => Ku,
	talkingMouth: () => gn,
	tangents: () => oa,
	tapAt: () => Uo,
	textOutline: () => Ao,
	toBase64: () => l,
	toLocal: () => xi,
	toModelAsset: () => po,
	traceContours: () => Pr,
	traceMeshCpu: () => na,
	traceMeshes: () => Xi,
	transposeTurn: () => xe,
	turnBetween: () => Pe,
	turnElements: () => Ka,
	turnFindings: () => Su,
	turnToEuler: () => Ye,
	turnToQuaternion: () => zs,
	turnedAround: () => h,
	undoStroke: () => Aa,
	unionBox: () => Mn,
	unit: () => wt,
	unwrap: () => Ca,
	usedAssets: () => Ft,
	usedTakes: () => Gt,
	valueNoise: () => Br,
	vmdCamera: () => bd,
	vmdToTake: () => yd,
	voiceName: () => Uu,
	vrmMissing: () => Gs,
	vrmSprings: () => Nn,
	walkGrid: () => bu,
	wearUnderwear: () => Le,
	welded: () => ao,
	withBakedPictures: () => Ea,
	withDaylight: () => Yc,
	withLineVoices: () => Iu,
	withShader: () => Ga,
	writeGlb: () => f,
	writeObj: () => aa,
	writeStl: () => ua
});
//#endregion
export { Jl as $, Io as $t, Tu as A, nc as At, tu as B, qs as Bt, wu as C, Pc as Ct, Au as D, vc as Dt, Lu as E, gc as Et, _u as F, uc as Ft, du as G, rs as Gt, cu as H, Is as Ht, gu as I, $s as It, wl as J, zo as Jt, El as K, Yo as Kt, hu as L, Zs as Lt, Su as M, ic as Mt, bu as N, dc as Nt, Cu as O, hc as Ot, Iu as P, rc as Pt, Rl as Q, Po as Qt, au as R, fc as Rt, Ou as S, Lc as St, xu as T, mc as Tt, uu as U, ls as Ut, pu as V, Gs as Vt, lu as W, ss as Wt, Hl as X, Bo as Xt, Sl as Y, Vo as Yt, Tl as Z, Ko as Zt, bd as _, Nc as _t, Lh as a, Eo as an, al as at, nd as b, Hc as bt, Fh as c, ol as ct, Ld as d, bl as dt, Fo as en, Bl as et, Id as f, Jc as ft, ad as g, yc as gt, pd as h, jc as ht, qh as i, wo as in, tl as it, Du as j, ec as jt, Fu as k, _c as kt, Nh as l, _l as lt, Od as m, Yc as mt, og as n, Mo as nn, zl as nt, Ih as o, yl as ot, Ad as p, el as pt, Cl as q, Jo as qt, Qh as r, Ao as rn, Zl as rt, Hh as s, vl as st, cg as t, jo as tn, ql as tt, Rd as u, fl as ut, yd as v, Mc as vt, Mu as w, pc as wt, Uu as x, Gc as xt, Xu as y, Fc as yt, fu as z, Hs as zt };

//# sourceMappingURL=core-AdQZWWr9.js.map