import { n as e } from "./rolldown-runtime-DArdT4gl.js";
import { a as t, c as n, f as r, i, l as a, o, s } from "./mesh-DZeCIO4D.js";
//#region ../scene3d/src/model/facepaint.ts
var c = [
	"soft",
	"bold",
	"cat",
	"droopy",
	"doll"
], l = {
	soft: "Soft",
	bold: "Bold",
	cat: "Cat flick",
	droopy: "Droopy",
	doll: "Doll lashes"
}, u = [
	"soft",
	"straight",
	"arched",
	"thick",
	"short"
], d = {
	soft: "Soft",
	straight: "Straight",
	arched: "Arched",
	thick: "Thick",
	short: "Short"
}, f = (e) => typeof e == "string" && /^#[0-9a-f]{6}$/i.test(e), p = (e, t, n, r) => typeof e == "number" && Number.isFinite(e) ? Math.max(t, Math.min(n, e)) : r;
function m(e) {
	if (!e || typeof e != "object") return;
	let t = e, n = c.includes(t.lines) ? t.lines : void 0, r = u.includes(t.brows) ? t.brows : void 0;
	if (n || r) return {
		...n ? {
			lines: n,
			lashes: p(t.lashes, 0, 1, .5),
			lower: p(t.lower, 0, 1, n === "doll" ? .8 : .3)
		} : {},
		...n && t.crease === !0 ? { crease: !0 } : {},
		...r ? {
			brows: r,
			browWeight: p(t.browWeight, -1, 1, 0)
		} : {},
		...f(t.lineColour) ? { lineColour: t.lineColour } : {},
		...f(t.browColour) ? { browColour: t.browColour } : {}
	};
}
var h = (e) => {
	let t = parseInt(e.slice(1), 16);
	return [
		t >> 16 & 255,
		t >> 8 & 255,
		t & 255
	];
}, g = (e, t, n) => [
	e[0] + (t[0] - e[0]) * n,
	e[1] + (t[1] - e[1]) * n,
	e[2] + (t[2] - e[2]) * n
], _ = (e) => e <= 0 ? 0 : e >= 1 ? 1 : e * e * (3 - 2 * e);
function v(e, t, n, r) {
	let i = 0;
	for (let a = 0; a < n.length - 1; a++) {
		let [o, s, c] = n[a], [l, u, d] = n[a + 1], f = l - o, p = u - s, m = f * f + p * p || 1e-12, h = Math.max(0, Math.min(1, ((e - o) * f + (t - s) * p) / m)), g = Math.hypot(e - (o + f * h), t - (s + p * h)), v = c + (d - c) * h;
		if (!(v <= 0) && (i = Math.max(i, _((v - g) / r + .5)), i >= 1)) return 1;
	}
	return i;
}
var y = (e, t, n, r, i) => Array.from({ length: e + 1 }, (a, o) => {
	let s = t + (n - t) * o / e, [c, l] = r(s);
	return [
		c,
		l,
		Math.max(0, i(s))
	];
});
function b(e, t) {
	if (e.length < 4) return null;
	let n = Infinity, r = -Infinity;
	for (let t of e) n = Math.min(n, t[0]), r = Math.max(r, t[0]);
	let i = (n + r) / 2 > t, a = i ? n : r, o = i ? r : n, s = Array(10).fill(-Infinity), c = Array(10).fill(Infinity);
	for (let [t, n] of e) {
		let e = Math.min(9, Math.max(0, Math.floor((t - a) / (o - a) * 10)));
		s[e] = Math.max(s[e], n), c[e] = Math.min(c[e], n);
	}
	for (let e = 0; e < 10; e++) {
		if (Number.isFinite(s[e])) continue;
		let t = [
			e - 1,
			e + 1,
			e - 2,
			e + 2
		].find((e) => e >= 0 && e < 10 && Number.isFinite(s[e]));
		t !== void 0 && ([s[e], c[e]] = [s[t], c[t]]);
	}
	let l = (e, t) => {
		let n = Math.max(0, Math.min(9, t * 10 - .5)), r = Math.floor(n), i = n - r;
		return e[r] + (e[Math.min(9, r + 1)] - e[r]) * i;
	}, u = s.reduce((e, t) => Math.max(e, t), -Infinity) - c.reduce((e, t) => Math.min(e, t), Infinity);
	return {
		x: (e) => a + (o - a) * e,
		top: (e) => l(s, e),
		bottom: (e) => l(c, e),
		out: Math.sign(o - a),
		width: Math.abs(o - a),
		height: u
	};
}
function x(e, t, n) {
	let r = t.lines, i = t.lashes ?? .5, a = {
		soft: .011,
		bold: .019,
		cat: .017,
		droopy: .015,
		doll: .02
	}[r] * n, o = {
		soft: .6,
		bold: 1,
		cat: 1.1,
		droopy: .8,
		doll: .7
	}[r], s = +(r === "droopy"), c = (t) => e.top(t) + a * .15 - s * e.height * .18 * _((t - .55) / .45), l = (e) => a * (.45 + o * e) * _(e / .1), u = [y(16, .02, 1, (t) => [e.x(t), c(t)], l)], d = {
		soft: 0,
		bold: .025,
		cat: .075,
		droopy: .035,
		doll: .02
	}[r] * n, f = {
		soft: 0,
		bold: .25,
		cat: .5,
		droopy: -.45,
		doll: .1
	}[r];
	if (d) {
		let t = e.x(1), n = c(1), r = l(1);
		u.push(y(6, 0, 1, (r) => [t + e.out * Math.cos(f) * d * r, n + Math.sin(f) * d * r], (e) => r * (1 - e)));
	}
	let p = t.lower ?? 0;
	p > 0 && u.push(y(10, .45, 1, (t) => [e.x(t), e.bottom(t) - a * .3], (e) => a * .28 * p * _((e - .45) / .25))), t.crease && u.push(y(12, .15, .92, (t) => [e.x(t), e.top(t) + e.height * .32 + e.height * .06 * Math.sin(Math.PI * t)], (e) => n * .0022 * Math.sin(Math.PI * ((e - .15) / .77))));
	let m = [], h = {
		soft: 2,
		bold: 3,
		cat: 3,
		droopy: 3,
		doll: 6
	}[r], g = (.02 + .04 * i) * n;
	for (let t = 0; t < h; t++) {
		let i = h === 1 ? 1 : .5 + .5 * t / (h - 1), a = e.x(i), o = c(i) + l(i) * .5, u = s ? .35 - .5 * i : 1.35 - .95 * i + (r === "cat" ? .15 : 0), d = g * (.75 + .35 * i);
		m.push(y(5, 0, 1, (t) => [a + e.out * Math.cos(u - .35 * t) * d * t, o + Math.sin(u - .35 * t) * d * t], (e) => n * .0055 * (1 - e)));
	}
	if (r === "doll" && p > 0) for (let t = 0; t < 3; t++) {
		let r = .6 + .18 * t, i = e.x(r), o = e.bottom(r) - a * .3, s = g * .45 * p;
		m.push(y(3, 0, 1, (t) => [i + e.out * .35 * s * t, o - s * t], (e) => n * .0022 * (1 - e)));
	}
	return {
		lines: u,
		lashes: m
	};
}
function S(e, t, n) {
	let r = e.half, i = 1 + .6 * (t.browWeight ?? 0), a = (t) => e.inner + (e.outer - e.inner) * (.1 + .85 * t), o = {
		soft: {
			y: (e) => .22 * r * Math.sin(Math.PI * e * .9) - .15 * r * e,
			w: (e) => .0045 * n * (1 - .65 * e),
			end: 1
		},
		straight: {
			y: (e) => -.12 * r * e,
			w: (e) => .0065 * n * (1 - .4 * e),
			end: 1
		},
		arched: {
			y: (e) => .42 * r * Math.sin(Math.PI * Math.min(1, e * 1.1) * .85) - .2 * r * e,
			w: (e) => .005 * n * (1 - .7 * e),
			end: 1
		},
		thick: {
			y: (e) => .06 * r * Math.sin(Math.PI * e) - .08 * r * e,
			w: (e) => .0105 * n * (1 - .35 * e),
			end: .85
		},
		short: {
			y: (e) => .05 * r * Math.sin(Math.PI * e),
			w: () => .009 * n,
			end: .5
		}
	}[t.brows];
	return y(16, 0, o.end, (t) => [a(t), e.y + o.y(t)], (e) => o.w(e) * i * _(e / .06 + .4));
}
async function C(e, t, n, r, i, a) {
	if (!t.rest) return;
	let o = t.rest, s = (t) => {
		let n = e.parts[t], r = o.positions[t - o.from];
		return r && r.length === n.positions.length ? {
			...n,
			positions: r
		} : n;
	}, c = t.headSize, l = (e) => t.kinds[e.material], u = e.parts.map((e, t) => s(t)), d = [];
	for (let [n, r] of e.materials.entries()) {
		if (t.kinds[n] !== "white" || r.texture < 0) continue;
		let e = await i.decode(a[r.texture].bytes, a[r.texture].mime);
		ee({
			width: e.width,
			height: e.height,
			data: new Uint8ClampedArray(e.width * e.height * 4)
		}, u.filter((e) => e.material === n && e.uvs), (t, n, r) => (e.data[r * 4 + 3] > 128 && d.push([t[0], t[1]]), null));
	}
	let f = [!0, !1].map((e) => b(d.filter((n) => n[0] > t.middle === e), t.middle)).flatMap((e) => e && n.lines ? [x(e, n, c)] : []), p = f.flatMap((e) => e.lines), m = f.flatMap((e) => e.lashes), _ = u.filter((e) => l(e) === "brow"), y = [];
	if (n.brows) for (let e of [!0, !1]) {
		let r = Infinity, i = -Infinity, a = Infinity, o = -Infinity;
		for (let n of _) for (let s = 0; s < n.positions.length; s += 3) n.positions[s] > t.middle === e && (r = Math.min(r, n.positions[s]), i = Math.max(i, n.positions[s]), a = Math.min(a, n.positions[s + 1]), o = Math.max(o, n.positions[s + 1]));
		if (!(r < i)) continue;
		let [s, l] = e ? [r, i] : [i, r];
		y.push(S({
			inner: s,
			outer: l,
			y: (a + o) / 2 - (o - a) * .08,
			half: (o - a) / 2
		}, n, c));
	}
	let C = h(n.lineColour ?? "#2a1a1e"), w = n.browColour ? h(n.browColour) : r ? g(h(r), C, .45) : h("#4a3229"), T = c * .0018, E = (e, t) => (n) => {
		let r = 0;
		for (let t of e) r = Math.max(r, v(n[0], n[1], t, T));
		return r > .01 ? {
			colour: t,
			alpha: r
		} : null;
	}, D = [];
	n.lines && D.push({
		kind: "eyeline",
		strokes: p,
		colour: C
	}, {
		kind: "eyelash",
		strokes: m,
		colour: C
	}), n.brows && D.push({
		kind: "brow",
		strokes: y,
		colour: w
	});
	let O = /* @__PURE__ */ new Map();
	for (let n of D) {
		let r = E(n.strokes, n.colour);
		e.materials.forEach((e, i) => {
			if (t.kinds[i] !== n.kind || e.texture < 0) return;
			let a = u.filter((e) => e.material === i && e.uvs);
			if (!a.length) return;
			let o = O.get(e.texture) ?? [];
			o.push({
				parts: a,
				paint: r
			}), O.set(e.texture, o);
		});
	}
	for (let [e, t] of O) {
		let n = await i.decode(a[e].bytes, a[e].mime), r = Math.max(2, Math.ceil(1024 / n.width)), o = {
			width: n.width * r,
			height: n.height * r,
			data: new Uint8ClampedArray(n.width * r * n.height * r * 4)
		};
		for (let { parts: e, paint: n } of t) ee(o, e, (e, t, r) => {
			let i = n(e);
			return i && (o.data[r * 4 + 3] = Math.max(o.data[r * 4 + 3], Math.round(i.alpha * 255))), i;
		});
		a[e] = await i.encode(o.width, o.height, o.data);
	}
}
//#endregion
//#region ../scene3d/src/model/avatardetail.ts
var w = (...e) => kt.boxOf(...e), T = (...e) => kt.eyesOf(...e), E = (e) => kt.smooth(e), D = [
	"blush",
	"shadow",
	"under",
	"lips",
	"tears"
], O = {
	blush: "Blush",
	shadow: "Eye shadow",
	under: "Under the eyes",
	lips: "Lip colour",
	tears: "Tears"
}, k = [
	"anime",
	"sparkle",
	"soft",
	"starry",
	"hollow",
	"ringed",
	"shutter"
], A = {
	anime: "Anime (layered)",
	sparkle: "Sparkling",
	soft: "Soft",
	starry: "Starry",
	hollow: "Hollow",
	ringed: "Ringed",
	shutter: "Shutter"
}, j = (e) => typeof e == "string" && /^#[0-9a-f]{6}$/i.test(e), M = (e) => typeof e == "number" && Number.isFinite(e) ? Math.max(0, Math.min(1, e)) : 0;
function N(e) {
	if (!e || typeof e != "object") return;
	let t = e, n = {};
	for (let e of D) M(t[e]) && (n[e] = M(t[e]));
	t.blushLines === !0 && (n.blushLines = !0), (t.mole === "left" || t.mole === "right") && (n.mole = t.mole);
	for (let e of [
		"blushColour",
		"shadowColour",
		"lipColour"
	]) j(t[e]) && (n[e] = t[e]);
	return Object.keys(n).length ? n : void 0;
}
function P(e) {
	if (!e || typeof e != "object") return;
	let t = e;
	if (!k.includes(t.style)) return;
	let n = typeof t.pupil == "number" && Number.isFinite(t.pupil) ? Math.max(-1, Math.min(1, t.pupil)) : 0;
	return {
		style: t.style,
		...n ? { pupil: n } : {},
		...j(t.glow) ? { glow: t.glow } : {},
		...j(t.second) ? { second: t.second } : {},
		...typeof t.lashes == "number" && Number.isFinite(t.lashes) && t.lashes > 0 ? { lashes: Math.min(1, t.lashes) } : {},
		...j(t.lashColour) ? { lashColour: t.lashColour } : {}
	};
}
var F = (e) => {
	let t = parseInt(e.slice(1), 16);
	return [
		t >> 16 & 255,
		t >> 8 & 255,
		t & 255
	];
}, I = (e, t, n) => [
	e[0] + (t[0] - e[0]) * n,
	e[1] + (t[1] - e[1]) * n,
	e[2] + (t[2] - e[2]) * n
];
function L(e, t) {
	let n = e.width * t, r = e.height * t, i = new Uint8ClampedArray(n * r * 4), a = (t, n) => (Math.min(e.height - 1, Math.max(0, n)) * e.width + Math.min(e.width - 1, Math.max(0, t))) * 4;
	for (let o = 0; o < r; o++) {
		let r = (o + .5) / t - .5, s = Math.floor(r), c = r - s;
		for (let r = 0; r < n; r++) {
			let l = (r + .5) / t - .5, u = Math.floor(l), d = l - u, f = [
				a(u, s),
				a(u + 1, s),
				a(u, s + 1),
				a(u + 1, s + 1)
			], p = [
				(1 - d) * (1 - c),
				d * (1 - c),
				(1 - d) * c,
				d * c
			], m = 0, h = [
				0,
				0,
				0
			];
			f.forEach((t, n) => {
				let r = p[n] * e.data[t + 3];
				m += p[n] * e.data[t + 3];
				for (let n = 0; n < 3; n++) h[n] += r * e.data[t + n];
			});
			let g = (o * n + r) * 4;
			for (let e = 0; e < 3; e++) i[g + e] = m > 0 ? h[e] / m : 0;
			i[g + 3] = m;
		}
	}
	return {
		width: n,
		height: r,
		data: i
	};
}
function ee(e, t, n) {
	let { width: r, height: i, data: a } = e, o = new Uint8Array(r * i);
	for (let e of t) {
		let t = e.uvs;
		if (!t) continue;
		let s = e.positions, c = e.normals, l = e.indices;
		for (let e = 0; e < l.length; e += 3) {
			let u = l[e], d = l[e + 1], f = l[e + 2], p = t[u * 2] * r, m = t[u * 2 + 1] * i, h = t[d * 2] * r, g = t[d * 2 + 1] * i, _ = t[f * 2] * r, v = t[f * 2 + 1] * i, y = (h - p) * (v - m) - (_ - p) * (g - m);
			if (Math.abs(y) < 1e-9) continue;
			let b = Math.max(0, Math.floor(Math.min(p, h, _) - 1)), x = Math.min(r - 1, Math.ceil(Math.max(p, h, _) + 1)), S = Math.max(0, Math.floor(Math.min(m, g, v) - 1)), C = Math.min(i - 1, Math.ceil(Math.max(m, g, v) + 1)), w = [
				Math.hypot(_ - h, v - g),
				Math.hypot(p - _, m - v),
				Math.hypot(h - p, g - m)
			];
			for (let e = S; e <= C; e++) for (let t = b; t <= x; t++) {
				let i = t + .5, l = e + .5, b = ((h - i) * (v - l) - (_ - i) * (g - l)) / y, x = ((_ - i) * (m - l) - (p - i) * (v - l)) / y, S = 1 - b - x, C = (e) => w[e] / Math.abs(y) * 1;
				if (b < -C(0) || x < -C(1) || S < -C(2)) continue;
				let T = b >= 0 && x >= 0 && S >= 0, E = e * r + t;
				if (o[E] === 2 || o[E] === 1 && !T) continue;
				let D = Math.max(0, b), O = Math.max(0, x), k = Math.max(0, S), A = D + O + k || 1, j = n([
					0,
					1,
					2
				].map((e) => (s[u * 3 + e] * D + s[d * 3 + e] * O + s[f * 3 + e] * k) / A), [
					0,
					1,
					2
				].map((e) => (c[u * 3 + e] * D + c[d * 3 + e] * O + c[f * 3 + e] * k) / A), E);
				if (o[E] = T ? 2 : 1, !j || j.alpha <= 0) continue;
				let M = Math.min(1, j.alpha);
				for (let e = 0; e < 3; e++) a[E * 4 + e] = a[E * 4 + e] + (j.colour[e] - a[E * 4 + e]) * M;
			}
		}
	}
}
var te = (e, t, n, r) => {
	let i = Math.hypot(e / n, t / r);
	return i >= 1 ? 0 : E(1 - i);
};
function ne(e, t, n) {
	let r = T(t, n.kinds, n.middle);
	if (!r.length) return null;
	let i = w(t.filter((e) => n.kinds[e.material] === "mouth")), a = n.headSize, o = r[0].mid[2] - a * .25, s = F(e.blushColour ?? "#f2788a"), c = I(s, [
		150,
		40,
		60
	], .45), l = F(e.shadowColour ?? "#c45c6a"), u = [
		120,
		70,
		92
	], d = F(e.lipColour ?? "#d9606e"), f = [
		196,
		222,
		245
	], p = [
		70,
		40,
		42
	];
	return (t) => {
		if (t[2] < o) return null;
		let m = null, h = (e, t) => {
			t > .002 && (!m || t > m.alpha) && (m = {
				colour: e,
				alpha: t
			});
		};
		for (let i of r) {
			let r = i.mid[0] > n.middle ? 1 : -1, o = (t[0] - i.mid[0]) * r, d = t[1] - i.mid[1], m = Math.max(i.half[0], a * .04), g = Math.max(i.half[1], a * .04);
			if (e.blush) {
				let t = o - m * .25, n = d + g * 2.1;
				if (h(s, te(t, n, m * 1.35, g * .8) * e.blush * .6), e.blushLines) for (let r = -1; r <= 1; r++) {
					let i = t - r * m * .42, a = i * .45 + n * .89, o = i * .89 - n * .45;
					Math.abs(o) < m * .045 && Math.abs(a) < g * .38 && h(c, .75 * Math.min(1, e.blush * 1.5));
				}
			}
			if (e.shadow && d > -g * .2 && h(l, te(o + m * .05, d - g * .55, m * 1.35, g * 1.15) * e.shadow * .5), e.under && h(u, te(o - m * .05, d + g * 1.12, m * 1.05, g * .38) * e.under * .45), e.tears) {
				let t = -(d + g * .85);
				if (t > 0 && t < g * 3.6) {
					let n = -m * .35 + Math.sin(t / (g * .9)) * m * .06, r = Math.abs(o - n) / (m * .07), i = 1 - t / (g * 3.6);
					r < 1 && h(r < .4 ? [
						244,
						250,
						255
					] : f, (1 - r * r) * i * e.tears * .9);
				}
			}
			e.mole && e.mole === "left" == r > 0 && Math.hypot(o - m * .85, d + g * 1.75) < a * .007 && h(p, .85);
		}
		if (e.lips && i) {
			let n = Math.max(i.half[0], a * .035) * 1.15, r = Math.max(i.half[1], a * .012) * 1.6;
			h(d, te(t[0] - i.mid[0], t[1] - i.mid[1], n, r) * e.lips * .55);
		}
		return m;
	};
}
var re = (e) => {
	let t = Math.sin(e * 127.1) * 43758.5453;
	return t - Math.floor(t);
};
function ie(e, t, n, r, i, a, o) {
	let s = Math.hypot(e, t);
	if (s > 1) return null;
	if (n === "anime") return ae(e, t, r, i, a, o);
	let c = Math.atan2(t, e), l = n === "hollow", u = I(I(r, [
		10,
		6,
		12
	], l ? .72 : .6), r, E((t + .9) / 1.3)), d = E((t - .05) / .75) * E((.95 - s) / .25) * (l ? .25 : .85);
	u = I(u, i, d);
	let f = (re(Math.floor((c + Math.PI) / (2 * Math.PI) * 72)) - .5) * .22 * E((s - .3) / .3);
	u = I(u, f > 0 ? i : [
		0,
		0,
		0
	], Math.abs(f)), u = I(u, [
		16,
		8,
		14
	], E((s - .78) / .2) * .9);
	let p = (l ? .42 : .3) * (1 + a * .35);
	if (n === "shutter") {
		let e = Math.PI / 3, t = ((c + Math.PI / 6) % e + e) % e, n = p / Math.cos(t - e / 2);
		u = I(u, [
			14,
			6,
			12
		], E((n - s) / .05));
		let r = Math.abs(((c + s * 1.4) / e % 1 + 1) % 1 - .5);
		u = I(u, [
			24,
			12,
			18
		], (r > .47 ? .75 : 0) * E((s - n) / .04) * E((.86 - s) / .1));
	} else u = I(u, [
		14,
		6,
		12
	], E((p - Math.hypot(e, t * 1.1)) / .07));
	if (n === "ringed") {
		let e = 1 - Math.min(1, Math.abs(s - .6) / .05);
		u = I(u, I(i, [
			255,
			255,
			255
		], .4), e * .8);
	}
	if (l) {
		let e = (u[0] + u[1] + u[2]) / 3;
		u = I(u, [
			e,
			e,
			e
		], .35), u = I(u, [
			40,
			30,
			38
		], (1 - Math.min(1, Math.abs(s - .52) / .06)) * .5);
	}
	u = I(u, [
		8,
		4,
		10
	], E((-t - .35) / .55) * .55);
	let m = (n, r, i, a) => te(e - n * o, t - r, i, a), h = 0;
	if (n === "sparkle" || n === "ringed" || n === "shutter") h = Math.max(m(-.32, -.38, .26, .2) * 1.6, m(.34, .36, .11, .11) * 1.4);
	else if (n === "soft") h = m(-.3, -.36, .3, .24) * .9;
	else if (n === "starry") {
		let n = e - -.3 * o, r = t - -.32, i = +(Math.abs(n) * Math.abs(r) < .0035 && Math.hypot(n, r) < .32);
		h = Math.max(i, m(-.3, -.32, .09, .09) * 1.5, m(.3, .38, .08, .08) * 1.3, m(.05, -.55, .05, .05) * 1.2);
	}
	return u = I(u, [
		255,
		255,
		255
	], Math.min(1, h)), [u, E((1 - s) / .04)];
}
function ae(e, t, n, r, i, a) {
	let o = Math.hypot(e, t), s = (Math.atan2(t, e) + Math.PI) / (2 * Math.PI), c = I(n, [
		14,
		8,
		32
	], .62), l = I(c, n, E((t + .95) / 1.55));
	l = I(l, r, E((t - .08) / .62) * E((.94 - o) / .22) * .85);
	let u = (re(Math.floor(s * 150)) * .6 + re(Math.floor(s * 47) + 9.3) * .4 - .5) * E((o - .3) / .22) * E((.9 - o) / .16);
	l = I(l, u > 0 ? I(r, [
		255,
		255,
		255
	], .25) : c, Math.abs(u) * .4);
	let d = .25 * (1 + i * .35);
	l = I(l, I(r, [
		255,
		255,
		255
	], .15), Math.max(0, 1 - Math.abs(o - (d + .13)) / .07) * .3), l = I(l, I(c, [
		6,
		3,
		12
	], .7), E((d - Math.hypot(e * 1.18, t * .92)) / .06)), l = I(l, I(c, [
		4,
		2,
		8
	], .5), E((o - .8) / .17) * .85), l = I(l, I(c, [
		4,
		2,
		10
	], .4), E((-t - .12) / .62) * .6), l = I(l, I(r, [
		255,
		255,
		255
	], .3), Math.max(0, 1 - Math.abs(o - .88) / .05) * E((t - .3) / .4) * .6);
	let f = (n, r, i, o) => te(e - n * a, t - r, i, o);
	l = I(l, I(r, [
		255,
		255,
		255
	], .5), Math.min(1, f(.22, -.08, .34, .3) * .22));
	let p = Math.max(f(-.3, -.42, .25, .19) * 1.7, f(.35, .33, .1, .1) * 1.5, f(.06, -.62, .05, .05) * 1.3, f(-.52, .12, .045, .045) * 1.1);
	return l = I(l, [
		255,
		255,
		255
	], Math.min(1, p)), [l, E((1 - o) / .035)];
}
function oe(e, t, n) {
	let { width: r, height: i, data: a } = e, o = new Uint8ClampedArray(a), s = Math.max(1, Math.round(t * Math.max(r, i) / 512 * 1.5));
	for (let e = 0; e < i; e++) for (let t = 0; t < r; t++) {
		let c = 0;
		for (let n = -s; n <= s; n++) for (let o = -s; o <= s; o++) {
			if (o * o + n * n > s * s) continue;
			let l = t + o, u = e + n;
			l < 0 || u < 0 || l >= r || u >= i || (c = Math.max(c, a[(u * r + l) * 4 + 3]));
		}
		let l = (e * r + t) * 4, u = I(a[l + 3] / 255 > 0 ? [
			a[l],
			a[l + 1],
			a[l + 2]
		] : n, n, .65);
		o[l] = u[0], o[l + 1] = u[1], o[l + 2] = u[2], o[l + 3] = Math.max(a[l + 3], c * .92);
	}
	return {
		width: r,
		height: i,
		data: o
	};
}
async function se(e, t, n, r, i, a) {
	let o = e.materials.flatMap((e, n) => t.kinds[n] === "iris" && e.texture >= 0 ? [n] : []);
	for (let s of new Set(o.map((t) => e.materials[t].texture))) {
		let c = e.parts.filter((t) => o.includes(t.material) && e.materials[t.material].texture === s && t.uvs);
		if (!c.length) continue;
		let l = await i.decode(a[s].bytes, a[s].mime), u;
		if (r) u = F(r);
		else {
			let e = [
				0,
				0,
				0
			], t = 0;
			for (let n = 0; n < l.data.length; n += 4) if (l.data[n + 3] > 200) {
				for (let t = 0; t < 3; t++) e[t] += l.data[n + t];
				t++;
			}
			u = t ? e.map((e) => e / t) : [
				120,
				70,
				60
			];
		}
		let d = n.glow ? F(n.glow) : I(u, [
			255,
			236,
			214
		], .55), f = l.width * 4, p = l.height * 4, m = new Uint8ClampedArray(f * p * 4);
		for (let e of [!0, !1]) {
			let r = e && n.second ? F(n.second) : u, i = e && n.second ? I(r, [
				255,
				236,
				214
			], .55) : d, a = Infinity, o = -Infinity, s = Infinity, l = -Infinity;
			for (let n of c) for (let r = 0; r < n.positions.length / 3; r++) {
				if (n.positions[r * 3] > t.middle !== e) continue;
				let i = n.uvs[r * 2], c = n.uvs[r * 2 + 1];
				a = Math.min(a, i), o = Math.max(o, i), s = Math.min(s, c), l = Math.max(l, c);
			}
			if (!(a < o && s < l)) continue;
			let h = (a + o) / 2 * f, g = (s + l) / 2 * p, _ = (o - a) / 2 * f, v = (l - s) / 2 * p;
			for (let e = Math.max(0, Math.floor(g - v)); e < Math.min(p, Math.ceil(g + v)); e++) for (let t = Math.max(0, Math.floor(h - _)); t < Math.min(f, Math.ceil(h + _)); t++) {
				let a = ie((t + .5 - h) / _, (e + .5 - g) / v, n.style, r, i, n.pupil ?? 0, 1);
				if (!a) continue;
				let o = (e * f + t) * 4;
				m[o] = a[0][0], m[o + 1] = a[0][1], m[o + 2] = a[0][2], m[o + 3] = Math.max(m[o + 3], a[1] * 255);
			}
		}
		a[s] = await i.encode(f, p, m);
	}
	if (n.lashes) {
		let r = n.lashColour ? F(n.lashColour) : [
			42,
			20,
			24
		], o = /* @__PURE__ */ new Set();
		for (let [s, c] of e.materials.entries()) {
			if (t.kinds[s] !== "eyelash" && t.kinds[s] !== "eyeline" || c.texture < 0 || o.has(c.texture)) continue;
			o.add(c.texture);
			let e = await i.decode(a[c.texture].bytes, a[c.texture].mime), l = oe(L(e, e.width <= 1024 ? 2 : 1), n.lashes, r);
			a[c.texture] = await i.encode(l.width, l.height, l.data);
		}
	}
	if (n.style === "hollow") for (let [n, r] of e.materials.entries()) {
		if (t.kinds[n] !== "highlight" || r.texture < 0) continue;
		let e = await i.decode(a[r.texture].bytes, a[r.texture].mime);
		for (let t = 3; t < e.data.length; t += 4) e.data[t] = 0;
		a[r.texture] = await i.encode(e.width, e.height, e.data);
	}
}
async function ce(e, t, n, r) {
	let i = N(n.makeup), a = P(n.eyes), s = m(n.facePaint);
	if (!i && !a && !s) return e;
	let c = e.textures.slice();
	if (i) {
		let n = ne(i, e.parts, t), a = e.materials.flatMap((e, n) => t.kinds[n] === "skin" && e.texture >= 0 ? [n] : []);
		if (n) for (let t of new Set(a.map((t) => e.materials[t].texture))) {
			let i = e.parts.filter((n) => a.includes(n.material) && e.materials[n.material].texture === t), o = await r.decode(c[t].bytes, c[t].mime), s = L(o, o.width <= 1024 ? 4 : 2);
			ee(s, i, n), c[t] = await r.encode(s.width, s.height, s.data);
		}
	}
	return s && await C(e, t, s, j(n.hairColour) ? n.hairColour : void 0, r, c), a && await se(e, t, a, j(n.irisColour) ? n.irisColour : void 0, r, c), {
		...e,
		...o(e.parts, e.materials, c)
	};
}
//#endregion
//#region ../scene3d/src/model/png.ts
var le = (() => {
	let e = /* @__PURE__ */ new Uint32Array(256);
	for (let t = 0; t < 256; t++) {
		let n = t;
		for (let e = 0; e < 8; e++) n = n & 1 ? 3988292384 ^ n >>> 1 : n >>> 1;
		e[t] = n >>> 0;
	}
	return e;
})();
function ue(e) {
	let t = 4294967295;
	for (let n of e) t = le[(t ^ n) & 255] ^ t >>> 8;
	return (t ^ 4294967295) >>> 0;
}
function de(e) {
	let t = 1, n = 0;
	for (let r of e) t = (t + r) % 65521, n = (n + t) % 65521;
	return (n << 16 | t) >>> 0;
}
function fe(e, t, n) {
	let r = new Uint8Array(t * (e * 4 + 1));
	for (let i = 0; i < t; i++) r.set(n.subarray(i * e * 4, (i + 1) * e * 4), i * (e * 4 + 1) + 1);
	let i = Math.max(1, Math.ceil(r.length / 65535)), a = new Uint8Array(2 + r.length + i * 5 + 4);
	a[0] = 120, a[1] = 1;
	let o = 2;
	for (let e = 0; e < i; e++) {
		let t = r.subarray(e * 65535, Math.min(r.length, (e + 1) * 65535));
		a[o++] = +(e === i - 1), a[o++] = t.length & 255, a[o++] = t.length >> 8, a[o++] = ~t.length & 255, a[o++] = ~t.length >> 8 & 255, a.set(t, o), o += t.length;
	}
	new DataView(a.buffer).setUint32(o, de(r));
	let s = (e, t) => {
		let n = new Uint8Array(12 + t.length), r = new DataView(n.buffer);
		r.setUint32(0, t.length);
		for (let t = 0; t < 4; t++) n[4 + t] = e.charCodeAt(t);
		return n.set(t, 8), r.setUint32(8 + t.length, ue(n.subarray(4, 8 + t.length))), n;
	}, c = /* @__PURE__ */ new Uint8Array(13), l = new DataView(c.buffer);
	l.setUint32(0, e), l.setUint32(4, t), c.set([
		8,
		6,
		0,
		0,
		0
	], 8);
	let u = [
		Uint8Array.from([
			137,
			80,
			78,
			71,
			13,
			10,
			26,
			10
		]),
		s("IHDR", c),
		s("IDAT", a),
		s("IEND", /* @__PURE__ */ new Uint8Array())
	], d = new Uint8Array(u.reduce((e, t) => e + t.length, 0)), f = 0;
	for (let e of u) d.set(e, f), f += e.length;
	return d;
}
//#endregion
//#region ../scene3d/src/model/animehair.ts
var pe = [
	"blunt",
	"swept",
	"parted",
	"wispy",
	"none"
], me = {
	blunt: "Blunt (straight across)",
	swept: "Swept to the side",
	parted: "Parted in the middle",
	wispy: "Wispy",
	none: "None (forehead bare)"
}, he = [
	"none",
	"pony",
	"twin",
	"side",
	"drills",
	"buns"
], ge = {
	none: "None",
	pony: "Ponytail",
	twin: "Twin tails",
	side: "Side tail",
	drills: "Drill curls",
	buns: "Buns"
}, _e = {
	back: 1,
	sides: .8,
	bangs: "wispy",
	bangLength: .7,
	tails: "none",
	tailLength: 1.6,
	volume: .4,
	wave: 0,
	curl: .2,
	ahoge: !1,
	density: 1,
	seed: 1
}, ve = {
	hime: {
		label: "Princess cut",
		style: {
			back: 3,
			sides: .55,
			bangs: "blunt",
			bangLength: .75,
			volume: .25,
			curl: 0
		}
	},
	long: {
		label: "Long and straight",
		style: {
			back: 2.6,
			sides: 2.2,
			bangs: "wispy",
			bangLength: .7,
			volume: .35,
			curl: .1
		}
	},
	bob: {
		label: "Bob",
		style: {
			back: .35,
			sides: .55,
			bangs: "blunt",
			bangLength: .7,
			volume: .55,
			curl: .8
		}
	},
	short: {
		label: "Short",
		style: {
			back: 0,
			sides: .2,
			bangs: "swept",
			bangLength: .55,
			volume: .45,
			curl: .2
		}
	},
	pony: {
		label: "Ponytail",
		style: {
			back: 0,
			sides: .7,
			bangs: "swept",
			bangLength: .65,
			tails: "pony",
			tailLength: 2,
			volume: .3
		}
	},
	twin: {
		label: "Twin tails",
		style: {
			back: 0,
			sides: .6,
			bangs: "blunt",
			bangLength: .7,
			tails: "twin",
			tailLength: 2.4,
			volume: .35
		}
	},
	side: {
		label: "Side tail",
		style: {
			back: .2,
			sides: .7,
			bangs: "swept",
			bangLength: .65,
			tails: "side",
			tailLength: 1.8,
			volume: .4
		}
	},
	drills: {
		label: "Drill curls",
		style: {
			back: 1.2,
			sides: .7,
			bangs: "parted",
			bangLength: .6,
			tails: "drills",
			tailLength: 2,
			volume: .45
		}
	},
	buns: {
		label: "Buns",
		style: {
			back: .25,
			sides: .6,
			bangs: "blunt",
			bangLength: .7,
			tails: "buns",
			volume: .35,
			curl: .6
		}
	},
	wavy: {
		label: "Long and wavy",
		style: {
			back: 2.4,
			sides: 1.8,
			bangs: "parted",
			bangLength: .6,
			volume: .6,
			wave: .8,
			curl: -.2
		}
	}
};
function ye(e) {
	if (!e || typeof e != "object") return;
	let t = e, n = typeof t.preset == "string" ? ve[t.preset]?.style : void 0, r = {
		..._e,
		...n
	}, i = (e, n, i) => typeof t[e] == "number" && Number.isFinite(t[e]) ? Math.max(n, Math.min(i, t[e])) : r[e];
	return {
		back: i("back", 0, 4),
		sides: i("sides", 0, 3),
		bangs: pe.includes(t.bangs) ? t.bangs : r.bangs,
		bangLength: i("bangLength", 0, 1),
		tails: he.includes(t.tails) ? t.tails : r.tails,
		tailLength: i("tailLength", .3, 4),
		volume: i("volume", 0, 1),
		wave: i("wave", 0, 1),
		curl: i("curl", -1, 1),
		ahoge: typeof t.ahoge == "boolean" ? t.ahoge : r.ahoge,
		density: i("density", .5, 1.5),
		seed: Math.round(i("seed", 0, 1e6))
	};
}
var be = {
	centre: [
		0,
		.44,
		-.02
	],
	radii: [
		.43,
		.48,
		.5
	]
}, R = Math.PI / 180, xe = 1 / 5;
function Se(e) {
	let t = e >>> 0 || 1;
	return () => {
		t = t + 1831565813 >>> 0;
		let e = Math.imul(t ^ t >>> 15, 1 | t);
		return e = e + Math.imul(e ^ e >>> 7, 61 | e) ^ e, ((e ^ e >>> 14) >>> 0) / 4294967296;
	};
}
var z = (e, t) => [
	e[0] + t[0],
	e[1] + t[1],
	e[2] + t[2]
], Ce = (e, t) => [
	e[0] - t[0],
	e[1] - t[1],
	e[2] - t[2]
], B = (e, t) => [
	e[0] * t,
	e[1] * t,
	e[2] * t
], we = (e) => Math.hypot(e[0], e[1], e[2]), V = (e) => B(e, 1 / (we(e) || 1)), Te = (e, t) => [
	e[1] * t[2] - e[2] * t[1],
	e[2] * t[0] - e[0] * t[2],
	e[0] * t[1] - e[1] * t[0]
], H = (e) => e <= 0 ? 0 : e >= 1 ? 1 : e * e * (3 - 2 * e);
function Ee(e, t, n) {
	let r = [
		Math.sin(e) * Math.sin(t),
		Math.cos(e),
		Math.sin(e) * Math.cos(t)
	];
	return [
		0,
		1,
		2
	].map((e) => be.centre[e] + r[e] * (be.radii[e] + n));
}
var De = (e, t) => e * .48 + t;
function Oe(e, t, n, r, i, a, o = 1, s = !1, c = 0) {
	let l = [];
	if (n <= .01) return l;
	let u = (.06 + .12 * r.volume) * o, d = Math.abs(t) < 95 * R, f = V([
		e[0],
		0,
		(e[2] - be.centre[2]) * (s && Math.abs(t) < 80 * R ? .2 : 1)
	]);
	for (let o = 1; o <= a; o++) {
		let p = o / a, m = p * n, h = [
			e[0] + c * m,
			e[1] - m,
			e[2]
		];
		if (s && Math.abs(t) < 80 * R) {
			let e = H(m / .25) * (1 - H((Math.abs(t) - 60 * R) / (20 * R)));
			h[0] += (Math.sign(h[0] || t) * Math.max(Math.abs(h[0]), .5) - h[0]) * e, h[2] += (Math.min(h[2], .2) - h[2]) * e;
		}
		let g = u * Math.min(m, .6) * (1 - .3 * H((m - .6) / 1.5));
		h = z(h, B(f, g)), r.wave && (h = z(h, B(Te(f, [
			0,
			1,
			0
		]), Math.sin(m * 5 + i) * .05 * r.wave * H(m / .4))));
		let _ = H((-.35 - h[1]) / .6);
		_ && (d ? (h[2] += (Math.max(h[2], .5) - h[2]) * _, h[0] += (Math.sign(h[0]) * Math.min(Math.abs(h[0]), .5) - h[0]) * _) : h[2] += (Math.min(h[2], -.5) - h[2]) * _);
		let v = H((p - .7) / .3);
		r.curl && v && (h = z(h, B(f, -r.curl * .1 * v * Math.min(1, n)))), l.push(h);
	}
	return l;
}
function ke(e, t, n, r, i, a, o) {
	let s = o.polarStart ?? .08, c = Math.max(4, Math.ceil((t - s) / .09)), l = [];
	for (let r = 0; r <= c; r++) {
		let i = r / c, a = s + (t - s) * i, u = e + (o.drift ?? 0) * H(i);
		l.push(Ee(a, u, n + ((o.liftEnd ?? n) - n) * i));
	}
	let u = Oe(l[l.length - 1], e, i, a, o.wiggle ?? 0, Math.max(2, Math.ceil(i / .1)), o.flare, o.besideFace, o.slant);
	l.push(...u);
	let d = l.length, f = o.taper ?? .35, p = l.map((e, n) => {
		let i = n <= c ? s + (t - s) * n / c : t, a = Math.max(.25, Math.sin(Math.min(i, Math.PI / 2))), l = 1 - H((n / (d - 1) - (1 - f)) / f) * (o.tip ?? .88);
		return r * a * l;
	}), m = V(Ce(l[c], be.centre)), h = 0;
	return {
		path: l,
		width: p,
		out: l.map((e, t) => {
			if (t <= c) return V(Ce(e, be.centre));
			h += we(Ce(e, l[t - 1]));
			let n = V([
				e[0],
				0,
				e[2] - be.centre[2]
			]), r = H(h / .35);
			return V(z(B(m, 1 - r), B(n, r)));
		}),
		start: s * .48,
		...u.length > 2 ? { hang: c } : {}
	};
}
function Ae(e, t, n, r, i, a) {
	let o = Math.round(10 * n.density), s = [], c = n.tailLength, l = Math.max(8, Math.ceil(c / .08));
	for (let u = 0; u < o; u++) {
		let d = u / o * Math.PI * 2 + r() * .3, f = [], p = [], m = [], h = c * (.85 + r() * .15);
		for (let r = 0; r <= l; r++) {
			let a = r / l, s = a * h, c = z(e, z(B(t, .22 * H(s / .35) + .04 * n.volume), [
				0,
				-s * .97,
				0
			])), g = (.05 + (.13 + .06 * n.volume) * Math.sin(Math.PI * Math.min(1, a * 1.25)) ** .7) * (i ? 1.1 : 1), _ = d + (i ? s * 7 : Math.sin(s * 4 + u) * .15 * n.wave), v = [
				Math.cos(_),
				0,
				Math.sin(_)
			];
			f.push(z(c, B(v, g * (1 - .6 * a * a)))), p.push(v), m.push(2 * Math.PI * g / o * 1.9 * (1 - H((a - .6) / .4) * .97));
		}
		s.push({
			path: f,
			out: p,
			width: m,
			start: .4,
			hang: 1,
			group: a
		});
	}
	return s;
}
function je(e, t, n) {
	let r = Math.round(9 * n.density), i = [];
	for (let n = 0; n < r; n++) {
		let a = n / r * Math.PI * 2, o = [], s = [], c = [];
		for (let n = 0; n <= 12; n++) {
			let i = n / 12, l = .15 + i * 2.8, u = a + i * 1.2, d = [
				Math.sin(l) * Math.cos(u),
				Math.cos(l),
				Math.sin(l) * Math.sin(u)
			];
			o.push(z(e, B(d, t))), s.push(d), c.push(2 * Math.PI * t * Math.max(.3, Math.sin(l)) / r * 1.7);
		}
		i.push({
			path: o,
			out: s,
			width: c,
			start: .4
		});
	}
	return i;
}
var Me = 10, Ne = (e, t) => t.hang === void 0 ? t : {
	...t,
	group: `s${Math.round((e / (2 * Math.PI) % 1 + 1) * Me) % Me}`
};
function Pe(e) {
	let t = Se(e.seed + 7), n = [], r = .055 + .1 * e.volume, i = e.density, a = (e.tails === "pony" || e.tails === "twin" || e.tails === "side" || e.tails === "drills") && e.tails !== "drills" ? 0 : e.back, o = e.sides, s = 58 * R;
	for (let [c, l, u] of [[
		0,
		Math.round(18 * i),
		r * .55
	], [
		1,
		Math.round(22 * i),
		r
	]]) for (let i = 0; i < l; i++) {
		let d = s ? 8 * R : 0, f = 2 * Math.PI - 2 * (s - d), p = s - d + (i + (c ? .5 : 0) + (t() - .5) * .3) / l * f, m = p > Math.PI ? p - 2 * Math.PI : p, h = Math.abs(m), g = H((110 * R - h) / (50 * R)), _ = (o + (a - o) * H((h - 70 * R) / (70 * R))) * (.85 + t() * .3), v = 2.05 + .25 * (1 - g), y = v + (1.72 - v) * H(_ / .7);
		y = Math.min(y, 1.45 + .6 * H((h - 55 * R) / (30 * R)));
		let b = 2 * Math.PI * (be.radii[0] + r) / l * 2.6;
		n.push(Ne(m, ke(m, y, u, b, _, e, {
			wiggle: t() * 6,
			besideFace: !0,
			taper: Math.min(.6, .18 / Math.max(.3, De(y, _))),
			tip: .97
		})));
	}
	if (e.bangs === "none") {
		let t = Math.round(12 * i);
		for (let i = 0; i < t; i++) {
			let a = (i + .5) / t, o = -s + a * 2 * s, c = .95 + .32 * (o / s) ** 2, l = 2 * s * (be.radii[0] + r) / t * 2.2;
			n.push(ke(o, c, r * .8, l, 0, e, {
				taper: .12,
				tip: .5
			}));
		}
	}
	if (e.bangs !== "none") {
		let a = Math.round((e.bangs === "blunt" ? 11 : e.bangs === "swept" ? 13 : 9) * i), o = 1.15, c = .62 - .27 * e.bangLength;
		for (let i = 0; i < a; i++) {
			let l = (i + .5) / a, u = -s + l * 2 * s, d = 0, f = c + (t() - .5) * (e.bangs === "blunt" ? .01 : .06);
			if (e.bangs === "swept") d = 18 * R, f = c - .04 + .1 * l;
			else if (e.bangs === "parted") {
				if (Math.abs(u) < 4 * R) continue;
				d = Math.sign(u) * 22 * R, f = c + .04 - .08 * Math.abs(u / s);
			} else e.bangs === "wispy" && (f += .04 * Math.cos(l * Math.PI * 3));
			f -= .12 * H((Math.abs(l - .5) - .36) / .14), u += (t() - .5) * .04;
			let p = Ee(o, u + d, r * .95)[1], m = e.bangs === "swept", h = 2 * s * (be.radii[0] + r) / a * (e.bangs === "blunt" ? 1.7 : m ? 2.8 : 2.1);
			n.push(ke(u, o, r * .95, h, Math.max(.02, p - f), e, {
				drift: d,
				flare: .35,
				slant: m ? .75 : 0,
				taper: e.bangs === "blunt" ? .06 : m ? .4 : .5,
				tip: e.bangs === "blunt" ? .3 : .97
			}));
		}
	}
	if (o > .15) for (let t of [1, -1]) for (let a = 0; a < Math.round(2 * i); a++) {
		let i = t * (s + (16 + a * 10) * R);
		n.push(Ne(i, ke(i, 1.45, r * 1.25, .22, o * (1.02 + a * .05), e, {
			polarStart: .5,
			wiggle: a * 2,
			besideFace: !0
		})));
	}
	let c = [];
	if (e.tails === "pony" && c.push({
		at: Ee(1.55, Math.PI, r),
		away: [
			0,
			.2,
			-1
		]
	}), e.tails === "twin" || e.tails === "drills") for (let e of [1, -1]) c.push({
		at: Ee(1.05, e * 115 * R, r),
		away: V([
			e,
			.3,
			-.3
		])
	});
	if (e.tails === "side" && c.push({
		at: Ee(1.25, 100 * R, r),
		away: V([
			1,
			.2,
			-.2
		])
	}), c.forEach((r, i) => n.push(...Ae(r.at, V(r.away), e, t, e.tails === "drills", `tail${i}`))), e.tails === "buns") for (let t of [1, -1]) n.push(...je(Ee(.62, t * 70 * R, r + .12), .17, e));
	if (e.ahoge) {
		let e = Ee(.12, 0, r), t = [], i = [], a = [];
		for (let n = 0; n <= 10; n++) {
			let r = n / 10;
			t.push(z(e, [
				Math.sin(r * 2.4) * .05,
				Math.sin(r * Math.PI * .8) * .28,
				r * .16
			])), i.push([
				1,
				0,
				0
			]), a.push(.1 * (1 - r * .9));
		}
		n.push({
			path: t,
			out: i,
			width: a,
			start: 0
		});
	}
	return n;
}
function Fe(e, t) {
	let n = e.path.length, r = new Float32Array(n * 3 * 3), a = new Float32Array(n * 3 * 2), o = e.start;
	for (let t = 0; t < n; t++) {
		let i = e.path[t], s = V(Ce(e.path[Math.min(n - 1, t + 1)], e.path[Math.max(0, t - 1)])), c = e.out[t], l = V(Te(s, c)), u = e.width[t];
		t > 0 && (o += we(Ce(i, e.path[t - 1]))), [
			z(i, B(l, -u / 2)),
			z(i, B(c, u * .22)),
			z(i, B(l, u / 2))
		].forEach((e, n) => {
			r.set(e, (t * 3 + n) * 3), a.set([n / 2, o * xe], (t * 3 + n) * 2);
		});
	}
	let s = [];
	for (let e = 0; e < n - 1; e++) for (let t = 0; t < 2; t++) {
		let n = e * 3 + t, r = n + 1, i = n + 3, a = n + 4;
		s.push(n, i, r, r, i, a);
	}
	let c = Uint32Array.from(s), l = i(r, c), u = 0;
	for (let t = 0; t < n; t++) u += l[(t * 3 + 1) * 3] * e.out[t][0] + l[(t * 3 + 1) * 3 + 1] * e.out[t][1] + l[(t * 3 + 1) * 3 + 2] * e.out[t][2];
	if (u < 0) {
		for (let e = 0; e < s.length; e += 3) [s[e + 1], s[e + 2]] = [s[e + 2], s[e + 1]];
		return l = i(r, Uint32Array.from(s)), {
			positions: r,
			normals: l,
			uvs: a,
			colors: null,
			indices: Uint32Array.from(s),
			material: t
		};
	}
	return {
		positions: r,
		normals: l,
		uvs: a,
		colors: null,
		indices: c,
		material: t
	};
}
function Ie() {
	let e = /* @__PURE__ */ new Uint8Array(65536);
	for (let t = 0; t < 256; t++) for (let n = 0; n < 64; n++) {
		let r = (n + .5) / 64, i = (t + .5) / 256, a = .72;
		a *= 1 - .3 * Math.abs(r - .5) ** 2.2 * 4.6;
		for (let [e, t] of [
			[.17, .1],
			[.33, .07],
			[.46, .05],
			[.61, .08],
			[.79, .1]
		]) a *= 1 - t * Math.exp(-(((r - e) / .018) ** 2));
		a *= .8 + .2 * H(i / .06);
		let o = .006 * Math.abs(r * 4 % 1 - .5) * 4, s = H((1 - Math.abs(i - .14) / (.008 + o)) * 1.6);
		a += (1.12 - a) * s * .8, a *= 1 + .06 * H((i - .6) / .4);
		let c = (t * 64 + n) * 4;
		e[c] = Math.min(255, Math.round(a * 150)), e[c + 1] = Math.min(255, Math.round(a * 108)), e[c + 2] = Math.min(255, Math.round(a * 82)), e[c + 3] = 255;
	}
	return fe(64, 256, e);
}
function Le(e, n, r) {
	let i = Pe(e), a = (e) => [
		n[0] + e[0] * r,
		n[1] + e[1] * r,
		n[2] + e[2] * r
	], s = [{
		name: "J_Bip_C_Head",
		parent: -1,
		head: a([
			0,
			0,
			0
		]),
		tail: a([
			0,
			.5,
			0
		])
	}], c = /* @__PURE__ */ new Map();
	for (let e of i) {
		if (e.hang === void 0 || !e.group || c.has(e.group)) continue;
		let t = i.filter((t) => t.group === e.group && t.hang !== void 0).reduce((e, t) => Re(t) > Re(e) ? t : e), n = Re(t);
		if (n < .05) continue;
		let r = Math.max(1, Math.min(4, Math.round(n / .5))), o = s.length;
		for (let i = 0; i < r; i++) s.push({
			name: `J_Sec_Hair_Made_${e.group}_${i + 1}`,
			parent: i ? s.length - 1 : -1,
			head: a(ze(t, n * i / r)),
			tail: a(ze(t, n * (i + 1) / r))
		});
		c.set(e.group, {
			first: o,
			count: r
		});
	}
	let l = i.map((e) => Fe(e, 0)), u = l.reduce((e, t) => e + t.positions.length / 3, 0), d = new Uint8Array(u * 8), f = 0;
	for (let e of i) {
		let t = e.group ? c.get(e.group) : void 0, n = e.hang === void 0 ? 0 : Re(e), r = 0;
		e.path.forEach((i, a) => {
			e.hang !== void 0 && a > e.hang && (r += we(Ce(i, e.path[a - 1])));
			let o = 0, s = 0, c = 0;
			if (t && e.hang !== void 0 && a >= e.hang && n > 0) {
				let e = Math.min(t.count, r / n * t.count), i = Math.min(t.count - 1, Math.floor(e)), a = e - i;
				o = i ? t.first + i - 1 : 0, s = t.first + i, c = i ? .5 + .5 * Math.min(1, a * 2) : Math.min(1, a * 1.5);
			}
			let l = Math.round(c * 255);
			for (let e = 0; e < 3; e++, f++) d[f * 8] = o, d[f * 8 + 1] = s, d[f * 8 + 4] = 255 - l, d[f * 8 + 5] = l;
		});
	}
	for (let e of l) for (let t = 0; t < e.positions.length; t += 3) for (let i = 0; i < 3; i++) e.positions[t + i] = n[i] + e.positions[t + i] * r;
	let p = {
		...t(),
		name: "Gleamshelf hair",
		texture: 0,
		doubleSided: !0,
		roughness: .55,
		metalness: 0
	};
	return {
		asset: o(l, [p], [{
			mime: "image/png",
			bytes: Ie()
		}]),
		bones: s,
		skin: d
	};
}
function Re(e) {
	let t = 0;
	for (let n = (e.hang ?? e.path.length) + 1; n < e.path.length; n++) t += we(Ce(e.path[n], e.path[n - 1]));
	return t;
}
function ze(e, t) {
	let n = t;
	for (let t = (e.hang ?? 0) + 1; t < e.path.length; t++) {
		let r = we(Ce(e.path[t], e.path[t - 1]));
		if (n <= r && r > 0) return z(e.path[t - 1], B(Ce(e.path[t], e.path[t - 1]), n / r));
		n -= r;
	}
	return e.path[e.path.length - 1];
}
//#endregion
//#region ../scene3d/src/model/avatar.ts
var Be = [
	"eyes",
	"lashes",
	"brows",
	"mouth",
	"makeup"
], Ve = {
	eyes: "Eyes",
	lashes: "Lashes",
	brows: "Brows",
	mouth: "Mouth",
	makeup: "Skin and makeup"
}, He = {
	eyes: [
		"iris",
		"highlight",
		"white",
		"extra",
		"eyeline",
		"eyelash"
	],
	lashes: [],
	brows: ["brow"],
	mouth: ["mouth"],
	makeup: []
}, Ue = {
	eyes: [
		"iris",
		"highlight",
		"white",
		"extra"
	],
	lashes: ["eyeline", "eyelash"],
	brows: ["brow"],
	mouth: ["mouth"],
	makeup: ["skin"]
}, We = [
	"hair",
	"iris",
	"skin",
	"top",
	"bottom",
	"shoes"
], Ge = {
	hair: "Hair",
	iris: "Eyes",
	skin: "Skin",
	top: "Tops",
	bottom: "Bottoms",
	shoes: "Shoes"
};
function Ke(e) {
	let t = new DataView(e).getUint32(0, !0), { bones: n, points: r } = JSON.parse(new TextDecoder().decode(new Uint8Array(e, 4, t))), i = 4 + t + (4 - t % 4) % 4, a = (t) => {
		let n = new Uint8Array(e, i, t * 8);
		return i += t * 8, n;
	};
	return {
		bones: n,
		body: a(r.body),
		face: a(r.face),
		hair: a(r.hair)
	};
}
var qe = {
	neutral: {
		label: "Neutral",
		mix: {}
	},
	smile: {
		label: "Smile",
		mix: { fun: 1 }
	},
	happy: {
		label: "Happy",
		mix: { joy: 1 }
	},
	wink: {
		label: "Wink",
		mix: {
			blink_l: 1,
			fun: .6
		}
	},
	surprised: {
		label: "Surprised",
		mix: { surprised: 1 }
	},
	angry: {
		label: "Angry",
		mix: { angry: 1 }
	},
	sad: {
		label: "Sad",
		mix: { sorrow: 1 }
	},
	sleepy: {
		label: "Sleepy",
		mix: { blink: .65 }
	},
	talking: {
		label: "Talking",
		mix: {
			a: .6,
			fun: .4
		}
	},
	gentle: {
		label: "Gentle smile",
		mix: {
			brow_joy: .25,
			eye_joy: .18,
			mouth_fun: .45
		}
	},
	shy: {
		label: "Shy smile",
		mix: {
			brow_sorrow: .45,
			eye_joy: .3,
			mouth_fun: .3
		}
	},
	tease: {
		label: "Teasing",
		mix: {
			brow_fun: .35,
			eye_joy_l: .55,
			eye_joy_r: .15,
			mouth_fun: .5
		}
	},
	worried: {
		label: "Worried",
		mix: {
			brow_sorrow: .7,
			eye_sorrow: .2,
			mouth_down: .25
		}
	},
	pout: {
		label: "Pouting",
		mix: {
			brow_angry: .3,
			eye_angry: .12,
			mouth_u: .35
		}
	},
	sadsmile: {
		label: "Sad smile",
		mix: {
			brow_sorrow: .6,
			eye_sorrow: .15,
			mouth_fun: .28
		}
	},
	curious: {
		label: "Curious",
		mix: {
			brow_surprised: .45,
			eye_surprised: .2,
			mouth_u: .12
		}
	},
	calm: {
		label: "Calm",
		mix: {
			brow_joy: .1,
			eye_joy: .08,
			mouth_fun: .18
		}
	}
}, Je = [
	"head",
	"eyes",
	"legs",
	"bust",
	"waist",
	"hips",
	"shoulders",
	"neck",
	"thighs"
], Ye = {
	head: "Head size",
	eyes: "Eye size",
	legs: "Leg length",
	bust: "Bust",
	waist: "Waist",
	hips: "Hips",
	shoulders: "Shoulders",
	neck: "Neck length",
	thighs: "Thighs"
}, Xe = {
	chibi: {
		label: "Chibi",
		shape: {
			head: 1,
			eyes: .8,
			legs: -1,
			bust: -.6,
			waist: .3,
			hips: -.3
		}
	},
	cute: {
		label: "Cute",
		shape: {
			head: .35,
			eyes: .45,
			legs: -.3
		}
	},
	made: {
		label: "As made",
		shape: {}
	},
	grown: {
		label: "Grown-up",
		shape: {
			head: -.3,
			eyes: -.25,
			legs: .55,
			bust: .35,
			waist: -.35,
			hips: .35,
			shoulders: .1,
			neck: .4,
			thighs: .2
		}
	},
	glam: {
		label: "Glamorous",
		shape: {
			head: -.45,
			eyes: -.15,
			legs: .75,
			bust: .55,
			waist: -.6,
			hips: .45
		}
	},
	tall: {
		label: "Tall and slim",
		shape: {
			head: -.6,
			eyes: -.2,
			legs: 1,
			bust: -.2,
			waist: -.4,
			hips: -.1
		}
	}
}, Ze = [
	"eyeHeight",
	"eyeSpacing",
	"eyeTilt",
	"eyeWidth",
	"browHeight",
	"browTilt",
	"mouthHeight",
	"mouthWidth",
	"chin",
	"cheeks",
	"eyeOpen",
	"irisSize",
	"jaw"
], Qe = {
	eyeHeight: "Eye height",
	eyeSpacing: "Eye spacing",
	eyeTilt: "Eye tilt",
	eyeWidth: "Eye width",
	browHeight: "Brow height",
	browTilt: "Brow angle",
	mouthHeight: "Mouth height",
	mouthWidth: "Mouth width",
	chin: "Chin length",
	cheeks: "Cheeks",
	eyeOpen: "Eye openness",
	irisSize: "Iris size",
	jaw: "Jaw width"
};
function $e(e) {
	if (!e || typeof e != "object") return null;
	let t = e, n = (e) => typeof e == "string" && /^[\w-]{1,60}$/.test(e) ? e : void 0, r = (e, t) => e && typeof e == "object" ? Object.fromEntries(Object.entries(e).flatMap(([e, r]) => n(r) && (!t || t.includes(e)) && n(e) ? [[e, n(r)]] : [])) : void 0, i = (e) => typeof e == "string" && /^#[0-9a-f]{6}$/i.test(e) ? e : void 0, a = (e, t, n) => typeof e == "number" && Number.isFinite(e) ? Math.max(t, Math.min(n, e)) : void 0, o = n(t.body), s = n(t.face), c = n(t.hair);
	if (!o || !s || !c) return null;
	let l = Object.fromEntries(Je.flatMap((e) => a(t.shape?.[e], -1, 1) === void 0 ? [] : [[e, a(t.shape[e], -1, 1)]])), u = Object.fromEntries(We.flatMap((e) => i(t.colours?.[e]) ? [[e, i(t.colours[e])]] : [])), d = t.wardrobe ?? {}, f = (e, t) => Object.fromEntries(["top", "bottom"].flatMap((n) => {
		let r = t(e?.[n]);
		return r === void 0 ? [] : [[n, r]];
	})), p = {
		...a(d.length, .6, 1.4) === void 0 ? {} : { length: a(d.length, .6, 1.4) },
		...a(d.fullness, .6, 1.5) === void 0 ? {} : { fullness: a(d.fullness, .6, 1.5) },
		patterns: f(d.patterns, (e) => {
			let t = e;
			return t && et.includes(t.pattern) && i(t.colour) ? {
				pattern: t.pattern,
				colour: i(t.colour)
			} : void 0;
		}),
		prints: f(d.prints, i)
	}, h = d.underwear;
	h && i(h.colour) && (p.underwear = {
		colour: i(h.colour),
		...h.style === "shorts" || h.style === "briefs" ? { style: h.style } : {}
	});
	let g = Object.fromEntries(Ze.flatMap((e) => {
		let n = a(t.faceShape?.[e], -1, 1);
		return n ? [[e, n]] : [];
	})), _ = N(t.makeup), v = P(t.eyes), y = Array.isArray(t.hidden) ? Tt.filter((e) => t.hidden.includes(e)) : [];
	return {
		name: typeof t.name == "string" ? t.name.slice(0, 60) : "Character",
		body: o,
		face: s,
		hair: c,
		features: r(t.features, Be),
		expression: n(t.expression) ?? "neutral",
		shape: l,
		colours: u,
		wardrobe: p,
		...Object.keys(g).length ? { faceShape: g } : {},
		..._ ? { makeup: _ } : {},
		...v ? { eyes: v } : {},
		...a(t.hairLength, .3, 2.5) !== void 0 && a(t.hairLength, .3, 2.5) !== 1 ? { hairLength: a(t.hairLength, .3, 2.5) } : {},
		...n(t.kit) ? {
			kit: n(t.kit),
			pieces: r(t.pieces)
		} : {},
		...y.length ? { hidden: y } : {},
		...t.shading === "model" ? { shading: "model" } : {},
		...ye(t.madeHair) ? { madeHair: ye(t.madeHair) } : {},
		...m(t.facePaint) ? { facePaint: m(t.facePaint) } : {}
	};
}
var et = [
	"stripes",
	"check",
	"dots",
	"denim"
], tt = {
	stripes: "Stripes",
	check: "Check",
	dots: "Dots",
	denim: "Denim"
}, U = (e) => Math.max(-1, Math.min(1, Number.isFinite(e) ? e : 0)), nt = (e) => ({
	...e,
	positions: new Float32Array(e.positions),
	normals: new Float32Array(e.normals)
});
function rt(e, t) {
	let n = { ...e };
	for (let [r, i] of Object.entries(e)) /texture$/i.test(r) && typeof i == "number" && i >= 0 && (n[r] = i + t);
	return n;
}
function it(e, t, n, r) {
	let i = qe[r]?.mix ?? {};
	for (let [r, a] of Object.entries(i)) {
		let i = t.face.expressions[r];
		i && a && i.forEach(([t, r], i) => {
			let o = e[i];
			if (!o || !r || t + r * 16 > n.byteLength) return;
			let s = new Uint32Array(n, t, r), c = new Float32Array(n, t + r * 4, r * 3);
			for (let e = 0; e < r; e++) {
				let t = s[e];
				if (!(t * 3 + 2 >= o.positions.length)) for (let n = 0; n < 3; n++) o.positions[t * 3 + n] += c[e * 3 + n] * a;
			}
		});
	}
}
function at(e, t, n, r) {
	let i = n.headSize / Math.max(1e-6, t.headSize) * r, [a, o] = [t.joints.head, n.joints.head];
	for (let t of e) for (let e = 0; e < t.positions.length; e += 3) for (let n = 0; n < 3; n++) t.positions[e + n] = o[n] + (t.positions[e + n] - a[n]) * i;
}
function ot(e, t, n) {
	let r = Math.max(.3, Math.min(2.5, n));
	if (r === 1) return;
	let [i, a, o] = t.joints.head, s = t.headSize, c = a + s * .3;
	for (let t of e) for (let e = 0; e < t.positions.length; e += 3) {
		let n = t.positions[e], a = t.positions[e + 1], l = t.positions[e + 2], u = Math.abs(n - i) < s * .3 && l > o + s * .15, d = c - a;
		d > 0 && !u && (t.positions[e + 1] = c - d * r);
	}
}
var W = (e) => e <= 0 ? 0 : e >= 1 ? 1 : e * e * (3 - 2 * e);
function st(e, t, n) {
	let r = Math.max(.6, Math.min(1.4, n?.length ?? 1)), i = Math.max(.6, Math.min(1.5, n?.fullness ?? 1));
	if (r === 1 && i === 1 || t.body.roles.includes("bottom")) return;
	let a = t.joints.waist, o = t.headSize * 1.5, s = (e) => {
		let n = t.body.roles[e.material];
		return n === "top" || n === "cloth";
	}, c = a[1];
	for (let t of e) if (s(t)) for (let e = 0; e < t.positions.length; e += 3) t.positions[e + 1] < c && Math.hypot(t.positions[e] - a[0], t.positions[e + 2] - a[2]) < o && (c = t.positions[e + 1]);
	let l = a[1] - c;
	if (!(l <= 0)) for (let t of e) {
		if (!s(t)) continue;
		let e = t.positions;
		for (let t = 0; t < e.length; t += 3) {
			let n = a[1] - e[t + 1];
			if (n <= 0 || Math.hypot(e[t] - a[0], e[t + 2] - a[2]) >= o) continue;
			let s = Math.min(1, n / l);
			e[t + 1] = Math.max(.02, a[1] - n * r);
			let c = 1 + (i - 1) * s;
			e[t] = a[0] + (e[t] - a[0]) * c, e[t + 2] = a[2] + (e[t + 2] - a[2]) * c;
		}
	}
}
function ct(e, t, n, r) {
	let { hips: i, waist: a } = t.joints, o = t.headSize, s = n.style === "shorts", c = i[1] + (a[1] - i[1]) * .3, l = i[1] - o * .42, u = 0, d = 0, f = 0;
	for (let n of e) {
		let e = t.body.roles[n.material];
		if (e !== "skin" && e !== "bottom" && e !== "shoes") continue;
		let r = n.positions;
		for (let e = 0; e < r.length; e += 3) {
			let t = r[e + 1];
			if (t < l - o * .15 || t > c) continue;
			let n = Math.abs(r[e] - i[0]), a = Math.abs(r[e + 2] - i[2]);
			n > o * .9 || a > o * .7 || (u = Math.max(u, n), d = Math.max(d, a), f++);
		}
	}
	if (f < 20) return null;
	u = Math.max(u, o * .5) + o * .03, d = Math.max(d, o * .36) + o * .03;
	let p = s ? 0 : o * .55, m = (e) => s ? l - o * .18 : l + p * Math.abs(e) ** 1.6, h = [], g = [], _ = [];
	for (let e = 0; e <= 14; e++) for (let t = 0; t <= 48; t++) {
		let n = t / 48 * Math.PI * 2, r = Math.sin(n), a = Math.cos(n), o = e / 14, l = c + (m(r) - c) * o, f = (s ? 0 : Math.max(0, o - .45) / .55) * (1 - Math.abs(r)), p = i[0] + r * u * (1 - f * .75), _ = i[2] + a * d * (1 - f * .85);
		h.push(p, l, _);
		let v = [
			r / u,
			0,
			a / d
		], y = Math.hypot(...v) || 1;
		g.push(v[0] / y, 0, v[2] / y);
	}
	for (let e = 0; e < 14; e++) for (let t = 0; t < 48; t++) {
		let n = e * 49 + t, r = n + 1, i = n + 48 + 1, a = i + 1;
		_.push(n, i, r, r, i, a);
	}
	let v = new Int32Array(h.length / 3 * 2);
	for (let n = 0; n < h.length / 3; n++) {
		let r = Infinity;
		e.forEach((e, i) => {
			if (t.body.roles[e.material] === "hair") return;
			let a = e.positions;
			for (let e = 0; e < a.length; e += 3) {
				let t = (a[e] - h[n * 3]) ** 2 + (a[e + 1] - h[n * 3 + 1]) ** 2 + (a[e + 2] - h[n * 3 + 2]) ** 2;
				t < r && (r = t, v[n * 2] = i, v[n * 2 + 1] = e / 3);
			}
		});
	}
	let y = e.find((e) => t.body.roles[e.material] === "skin"), b = y ? r[y.material] : void 0, x = (e) => [
		1,
		3,
		5
	].map((t) => {
		let n = parseInt(e.slice(t, t + 2), 16) / 255;
		return n <= .04045 ? n / 12.92 : ((n + .055) / 1.055) ** 2.4;
	}), S = {
		...b ?? {},
		color: x(n.colour),
		texture: -1,
		roughness: .75,
		metalness: 0,
		emissive: [
			0,
			0,
			0
		],
		emissiveTexture: -1,
		doubleSided: !0
	};
	return {
		part: {
			positions: new Float32Array(h),
			normals: new Float32Array(g),
			uvs: null,
			colors: null,
			indices: new Uint32Array(_),
			material: -1
		},
		material: S,
		from: v
	};
}
function lt(e, t, n) {
	let r = U(n.bust), i = U(n.waist), a = U(n.hips), o = t.headSize, s = t.joints.bust ?? [[
		t.joints.chest[0] + o * .38,
		t.joints.chest[1] - o * .1,
		t.joints.chest[2] + o * .35
	], [
		t.joints.chest[0] - o * .38,
		t.joints.chest[1] - o * .1,
		t.joints.chest[2] + o * .35
	]], c = o * .75, l = (e, t, n) => W(1 - Math.abs(e - t) / n);
	for (let n of e) {
		let e = n.positions;
		for (let n = 0; n < e.length; n += 3) {
			let u = e[n], d = e[n + 1], f = e[n + 2];
			if (r) for (let e of s) {
				let n = u - e[0], i = d - e[1], a = f - e[2], s = Math.hypot(n, i, a);
				if (s >= c || f < t.joints.chest[2] - o * .05) continue;
				let l = W(1 - s / c) * r * .55;
				u += n * l, d += i * l * .6, f += Math.max(0, a) * l + o * .12 * l;
			}
			let p = i * .16 * l(d, t.joints.waist[1], o * .55) + a * .2 * l(d, t.joints.hips[1] - o * .15, o * .85);
			p && (u = t.joints.hips[0] + (u - t.joints.hips[0]) * (1 + p), f = t.joints.hips[2] + (f - t.joints.hips[2]) * (1 + p * .7)), e[n] = u, e[n + 1] = d, e[n + 2] = f;
		}
	}
}
function ut(e) {
	return (t, n) => {
		let r = 0;
		for (let i = 0; i < 4; i++) {
			let a = e.body[t * 8 + 4 + i] / 255;
			a && (r += a * n(e.body[t * 8 + i]));
		}
		return r;
	};
}
function dt(e, t) {
	let n = [];
	return e.forEach((e, r) => n[r] = t(e.name) || e.parent >= 0 && e.parent < r && n[e.parent]), n;
}
function ft(e, t, n, r) {
	let i = U(n.shoulders), a = U(n.neck), o = U(n.thighs);
	if (!t || !(i || a || o) || t.body.length !== Nt(e) * 8) return 0;
	let s = t.bones, c = ut(t), l = s.map((e) => /_L_/.test(e.name) ? 1 : /_R_/.test(e.name) ? -1 : 0), u = dt(s, (e) => /J_Bip_[LR]_UpperArm$/.test(e)), d = s.map((e) => /J_Bip_[LR]_Shoulder$/.test(e.name)), f = dt(s, (e) => e === "J_Bip_C_Head"), p = s.findIndex((e) => e.name === "J_Bip_C_Neck"), m = s.map((e, t) => /J_Bip_[LR]_UpperLeg$/.test(e.name) || e.parent >= 0 && /J_Sec/.test(e.name) && /UpperLeg$/.test(s[e.parent].name) && t > 0), h = i * r * .11, g = a * r * .12, [_, v] = p >= 0 ? [s[p].head[1], s[p].tail[1]] : [0, 0], y = 0;
	for (let t of e) {
		let e = t.positions;
		for (let t = 0; t < e.length; t += 3, y++) {
			if (h) {
				let n = c(y, (e) => u[e] ? l[e] : d[e] ? l[e] * .5 : 0);
				n && (e[t] = e[t] + h * n);
			}
			if (g && p >= 0) {
				let n = c(y, (n) => f[n] ? 1 : n === p ? W((e[t + 1] - _) / Math.max(1e-6, v - _)) : 0);
				n && (e[t + 1] = e[t + 1] + g * n);
			}
			if (o) for (let n = 0; n < s.length; n++) {
				if (!m[n] || !/J_Bip/.test(s[n].name)) continue;
				let r = c(y, (e) => e === n || m[e] && s[e].parent === n ? 1 : 0);
				if (!r) continue;
				let { head: i, tail: a } = s[n], l = Math.max(0, Math.min(1, (i[1] - e[t + 1]) / Math.max(1e-6, i[1] - a[1]))), u = i[0] + (a[0] - i[0]) * l, d = i[2] + (a[2] - i[2]) * l, f = 1 + o * .2 * r;
				e[t] = u + (e[t] - u) * f, e[t + 2] = d + (e[t + 2] - d) * f;
			}
		}
	}
	return g;
}
function pt(e, t, n, r) {
	if (r === 1) return;
	let [i, a, o] = n.joints.head, s = n.headSize, c = t && t.body.length === Nt(e) * 8, l = c ? dt(t.bones, (e) => e === "J_Bip_C_Head") : [], u = c ? ut(t) : null, d = 0;
	for (let t of e) {
		let e = t.positions;
		for (let t = 0; t < e.length; t += 3, d++) {
			let n = u ? u(d, (e) => +!!l[e]) : W((e[t + 1] - (a - s * .2)) / (s * .2));
			if (!n) continue;
			let c = 1 + (r - 1) * n;
			e[t] = i + (e[t] - i) * c, e[t + 1] = a + (e[t + 1] - a) * c, e[t + 2] = o + (e[t + 2] - o) * c;
		}
	}
}
function mt(e, t, n, r = 1) {
	let i = gt(e.filter((e) => n[e.material] === "skin"));
	if (!i) return e;
	let a = t.headSize, o = _t(e, n, t.joints.head[0]), s = o.length ? o.reduce((e, t) => e + t.mid[2], 0) / o.length : i.mid[2] + i.half[2], c = o.length ? o.reduce((e, t) => e + t.mid[1], 0) / o.length : i.mid[1], l = [
		Math.max(i.half[0], a * .3),
		Math.max(i.half[1], a * .4),
		a * .42
	], u = [
		t.joints.head[0],
		c - a * .05,
		s - l[2] * .92
	];
	return e.map((e) => {
		if (n[e.material] !== "skin") return e;
		let t = new Float32Array(e.normals), i = e.positions;
		for (let e = 0; e < i.length; e += 3) {
			let n = [
				0,
				1,
				2
			].map((t) => (i[e + t] - u[t]) / l[t]), a = r * W((1.45 - Math.hypot(n[0], n[1], n[2])) / .3) * W((n[2] + .2) / .4);
			if (!a) continue;
			let o = [
				n[0] / l[0],
				n[1] / l[1],
				n[2] / l[2]
			], s = Math.hypot(o[0], o[1], o[2]) || 1, c = [
				0,
				1,
				2
			].map((n) => t[e + n] + (o[n] / s - t[e + n]) * a), d = Math.hypot(c[0], c[1], c[2]) || 1;
			for (let n = 0; n < 3; n++) t[e + n] = c[n] / d;
		}
		return {
			...e,
			normals: t
		};
	});
}
var ht = (e, t) => t.materials.map((t, n) => e.face.kinds?.[n] ?? (e.face.roles[n] === "skin" ? "skin" : e.face.roles[n] === "iris" ? "iris" : void 0));
function gt(e) {
	let t = [
		Infinity,
		Infinity,
		Infinity
	], n = [
		-Infinity,
		-Infinity,
		-Infinity
	];
	for (let r of e) for (let e = 0; e < r.positions.length; e += 3) for (let i = 0; i < 3; i++) t[i] = Math.min(t[i], r.positions[e + i]), n[i] = Math.max(n[i], r.positions[e + i]);
	return t[0] <= n[0] ? {
		mid: [
			0,
			1,
			2
		].map((e) => (t[e] + n[e]) / 2),
		half: [
			0,
			1,
			2
		].map((e) => (n[e] - t[e]) / 2)
	} : null;
}
function _t(e, t, n) {
	let r = e.filter((e) => t[e.material] === "white"), i = r.length ? r : e.filter((e) => t[e.material] === "iris"), a = (e) => gt(i.map((t) => {
		let r = [];
		for (let i = 0; i < t.positions.length; i += 3) t.positions[i] > n === e && r.push(...t.positions.slice(i, i + 3));
		return {
			...t,
			positions: Float32Array.from(r)
		};
	}));
	return [a(!0), a(!1)].filter((e) => !!e);
}
function vt(e, t, n, r, i, a, o) {
	if (n < o) return 0;
	let s = Math.hypot(e - r[0], t - r[1]);
	return s <= i ? 1 : s >= a ? 0 : W(1 - (s - i) / (a - i));
}
function yt(e, t, n) {
	let r = t.asset.materials.slice(), i = t.asset.textures.slice(), a = ht(t.model, t.asset), o = (e, t, n) => e.flatMap((e, r) => t[e.material] === n ? [r] : []), s = t.model.headSize;
	for (let { feature: c, model: l, asset: u } of n) {
		if (l.id === t.model.id) continue;
		let n = u.parts.map(nt);
		at(n, l, t.model, 1);
		let d = ht(l, u);
		for (let t of He[c]) {
			let r = o(n, d, t);
			o(e, a, t).forEach((t, i) => {
				let a = n[r[i] ?? -1];
				a && a.positions.length === e[t].positions.length && (e[t] = {
					...e[t],
					positions: a.positions,
					normals: a.normals
				});
			});
		}
		let f = c === "eyes" ? _t(n, d, t.model.joints.head[0]) : c === "mouth" ? [gt(o(n, d, "mouth").map((e) => n[e]))].filter((e) => !!e) : [];
		if (f.length) {
			let t = o(e, a, "skin"), r = o(n, d, "skin");
			t.forEach((t, i) => {
				let a = n[r[i] ?? -1], o = e[t];
				if (!a || a.positions.length !== o.positions.length) return;
				let c = new Float32Array(o.positions);
				for (let e = 0; e < c.length; e += 3) {
					let t = 0;
					for (let n of f) {
						let r = Math.max(n.half[0], n.half[1]);
						t = Math.max(t, vt(c[e], c[e + 1], c[e + 2], n.mid, r * 1.15, r * 1.15 + s * .12, n.mid[2] - s * .2));
					}
					if (t) for (let n = 0; n < 3; n++) c[e + n] = c[e + n] + (a.positions[e + n] - c[e + n]) * t;
				}
				e[t] = {
					...o,
					positions: c
				};
			});
		}
		let p = /* @__PURE__ */ new Map(), m = (e) => (p.has(e) || p.set(e, i.push(u.textures[e]) - 1), p.get(e));
		for (let e of Ue[c]) {
			let t = r.flatMap((t, n) => a[n] === e ? [n] : []), n = u.materials.flatMap((t, n) => d[n] === e ? [n] : []);
			t.forEach((e, t) => {
				let i = u.materials[n[Math.min(t, n.length - 1)] ?? -1];
				if (!i) return;
				let a = { ...i };
				for (let [e, t] of Object.entries(i)) /texture$/i.test(e) && typeof t == "number" && t >= 0 && (a[e] = m(t));
				r[e] = a;
			});
		}
	}
	return {
		materials: r,
		textures: i
	};
}
function bt(e, t, n, r) {
	if (!r) return;
	let i = t.headSize, a = _t(e, n, t.joints.head[0]);
	for (let t of e) {
		let e = t.positions;
		for (let t = 0; t < e.length; t += 3) for (let n of a) {
			let a = Math.hypot(n.half[0], n.half[1]) * 1.25, o = vt(e[t], e[t + 1], e[t + 2], n.mid, a, a + i * .1, n.mid[2] - i * .2);
			if (!o) continue;
			let s = 1 + .3 * r * o;
			e[t] = n.mid[0] + (e[t] - n.mid[0]) * s, e[t + 1] = n.mid[1] + (e[t + 1] - n.mid[1]) * s;
			break;
		}
	}
}
function xt(e, t, n) {
	let r = t.headSize, i = t.joints.head[0], a = _t(e, n, i), o = gt(e.filter((e) => n[e.material] === "mouth"));
	if (!a.length || !o) return;
	let s = a.reduce((e, t) => e + t.mid[1], 0) / a.length, c = a.reduce((e, t) => e + t.mid[2], 0) / a.length, l = c - r * .22, u = o.mid[1] - (s - o.mid[1]) * .9;
	for (let t of e) {
		let e = t.positions;
		for (let t = 0; t < e.length; t += 3) {
			let n = e[t], a = e[t + 1], d = e[t + 2];
			if (d <= l || a >= s) continue;
			let f = W((s - a) / Math.max(1e-6, s - o.mid[1])), p = W(1 - Math.abs(n - i) / (r * .32));
			d > c - r * .02 && (d = c - r * .02 + (d - (c - r * .02)) * (1 - .6 * f * p));
			let m = Math.max(o.half[0], r * .03) * 1.6, h = vt(n, a, d, o.mid, m, m + r * .07, l);
			if (h && (n += (o.mid[0] + (n - o.mid[0]) * .5 - n) * h, a += (o.mid[1] + (a - o.mid[1]) * .55 - a) * h), a < o.mid[1]) {
				let e = o.mid[1] - a;
				a = o.mid[1] - e * .7;
				let t = W(1 - Math.abs(a - u) / (r * .3));
				n = i + (n - i) * (1 + .02 * t);
			}
			e[t] = n, e[t + 1] = a, e[t + 2] = d;
		}
	}
}
function St(e, t, n, r) {
	if (!r || !Ze.some((e) => r[e])) return;
	let i = (e) => U(r[e]), a = t.headSize, o = t.joints.head[0], s = _t(e, n, o), c = gt(e.filter((e) => n[e.material] === "mouth")), l = e.filter((e) => n[e.material] === "brow"), u = [!0, !1].map((e) => gt(l.map((t) => {
		let n = [];
		for (let r = 0; r < t.positions.length; r += 3) t.positions[r] > o === e && n.push(...t.positions.slice(r, r + 3));
		return {
			...t,
			positions: Float32Array.from(n)
		};
	}))).filter((e) => !!e), d = (s[0]?.mid[2] ?? t.joints.head[2]) - a * .22, f = s.length ? s.reduce((e, t) => e + t.mid[1], 0) / s.length : t.joints.head[1] + a * .45, p = c?.mid[1] ?? t.joints.head[1] + a * .18, m = (e, t, n, r, i) => {
		let a = Math.cos(i), o = Math.sin(i);
		return [n + (e - n) * a - (t - r) * o, r + (e - n) * o + (t - r) * a];
	}, h = i("irisSize") ? _t(e, n.map((e) => e === "iris" ? e : void 0), o) : [], g = p - a * .3;
	e.forEach((e) => {
		let t = n[e.material], r = e.positions;
		for (let e = 0; e < r.length; e += 3) {
			let n = r[e], l = r[e + 1], _ = r[e + 2];
			if ((t === "iris" || t === "highlight") && h.length) {
				let e = h.find((e) => n > o == e.mid[0] > o);
				if (e) {
					let t = 1 + i("irisSize") * .22;
					n = e.mid[0] + (n - e.mid[0]) * t, l = e.mid[1] + (l - e.mid[1]) * t;
				}
			}
			if (t === "brow") {
				let e = u.find((e) => n > o == e.mid[0] > o);
				if (e) {
					let t = e.mid[0] > o ? 1 : -1;
					[n, l] = m(n, l, e.mid[0], e.mid[1], -t * i("browTilt") * .3), n += t * i("eyeSpacing") * a * .045, l += i("browHeight") * a * .05 + i("eyeHeight") * a * .05;
				}
			} else {
				for (let e of s) {
					let t = Math.max(e.half[0], e.half[1]) * 1.3, r = vt(n, l, _, e.mid, t, t + a * .09, d);
					if (!r) continue;
					let s = e.mid[0] > o ? 1 : -1, c = e.mid[0] + (n - e.mid[0]) * (1 + i("eyeWidth") * .2), u = e.mid[1] + (l - e.mid[1]) * (1 + i("eyeOpen") * .28);
					[c, u] = m(c, u, e.mid[0], e.mid[1], s * i("eyeTilt") * .22), c += s * i("eyeSpacing") * a * .045, u += i("eyeHeight") * a * .05, n += (c - n) * r, l += (u - l) * r;
					break;
				}
				if (c) {
					let e = Math.max(c.half[0], a * .03) * 1.25, t = vt(n, l, _, c.mid, e, e + a * .08, d);
					t && (n += (c.mid[0] + (n - c.mid[0]) * (1 + i("mouthWidth") * .3) - n) * t, l += i("mouthHeight") * a * .04 * t);
				}
				if (_ > d) {
					let e = p - l;
					i("chin") && e > 0 && (l -= e * i("chin") * .22 * W(1 - e / (a * .45)));
					let t = W(1 - Math.abs(l - (p + f) / 2) / Math.max(1e-6, (f - p) * 1.1));
					i("cheeks") && t && (n = o + (n - o) * (1 + i("cheeks") * .07 * t));
				}
				if (i("jaw")) {
					let e = W((f - l) / Math.max(1e-6, f - g)), t = W((_ - (d - a * .15)) / (a * .2));
					e && t && (n = o + (n - o) * (1 + i("jaw") * .2 * e * t));
				}
			}
			r[e] = n, r[e + 1] = l;
		}
	});
}
function Ct(e, t, n, r) {
	if (!n) return 0;
	let i = t.joints.hips[1], a = .32 * n, o = 0;
	for (let n of e) {
		let e = n.positions;
		for (let n = 0; n < e.length; n += 3, o++) {
			let s = e[n + 1], c = r && o < r.length ? r[o] / 255 : W((i - s) / (t.headSize * .6));
			e[n + 1] = s + (s * a * c + i * a * (1 - c));
		}
	}
	return i * a;
}
var wt = (e) => {
	let t = U(e);
	return t >= 0 ? 1 + .5 * t : 1 + .2 * t;
}, Tt = [
	"body",
	"face",
	"hair"
], Et = {
	body: "Body and outfit",
	face: "Face",
	hair: "Hair"
};
function Dt(e, t, n) {
	let r = Tt.flatMap((e) => Array(t[e]).fill(e)), i = e.parts.flatMap((e, t) => n.includes(r[t] ?? "body") ? [t] : []), a = i.map((t) => e.parts[t]), s = [...new Set(a.map((e) => e.material))].sort((e, t) => e - t), c = [], l = /* @__PURE__ */ new Map(), u = s.map((t) => {
		let n = { ...e.materials[t] };
		for (let [t, r] of Object.entries(n)) (t === "texture" || t.endsWith("Texture")) && typeof r == "number" && r >= 0 && (l.has(r) || l.set(r, c.push(e.textures[r]) - 1), n[t] = l.get(r));
		return n;
	}), d = {
		...e,
		...o(a.map((e) => ({
			...e,
			material: s.indexOf(e.material)
		})), u, c)
	}, f = e.morphs?.moves.map((e) => i.map((t) => e[t] ?? null));
	return e.morphs && f.some((e) => e.some(Boolean)) ? d.morphs = {
		names: e.morphs.names,
		moves: f
	} : delete d.morphs, d;
}
function Ot(e, t, n) {
	let r = wt(n.shape.head), i = t.body.parts.map(nt);
	lt(i, e.body, n.shape);
	let a = ft(i, t.skins?.body, n.shape, e.body.headSize), s = i.map((e) => e.positions.slice());
	st(i, e.body, n.wardrobe);
	let c = i.map((e, t) => e.positions.map((e, n) => e - s[t][n])), l = Ct(i, e.body, U(n.shape.legs), t.legs), u = t.body, d = e.body.body.roles, f = n.wardrobe?.underwear ? ct(i, e.body, n.wardrobe.underwear, t.body.materials) : null;
	if (f) {
		f.part.material = t.body.materials.length;
		let n = f.part.positions.length / 3, r = new Float32Array(n * 3), a = [], o = 0;
		for (let e of i) a.push(o), o += e.positions.length / 3;
		let s = t.skins ? new Uint8Array(n * 8) : null;
		for (let e = 0; e < n; e++) {
			let n = f.from[e * 2], o = f.from[e * 2 + 1], c = t.body.parts[n].positions;
			for (let t = 0; t < 3; t++) r[e * 3 + t] = f.part.positions[e * 3 + t] - (i[n].positions[o * 3 + t] - c[o * 3 + t]);
			s && s.set(t.skins.body.body.subarray((a[n] + o) * 8, (a[n] + o) * 8 + 8), e * 8);
		}
		i.push(f.part), c.push(new Float32Array(n * 3)), u = {
			materials: [...t.body.materials, f.material],
			textures: t.body.textures
		}, d = [...e.body.body.roles, "cloth"], t = {
			...t,
			body: {
				...t.body,
				parts: [...t.body.parts, {
					...f.part,
					positions: r
				}],
				materials: u.materials
			},
			...t.skins && s ? { skins: {
				...t.skins,
				body: {
					...t.skins.body,
					body: Uint8Array.from([...t.skins.body.body, ...s])
				}
			} } : {}
		};
	}
	let p = {
		...e.body,
		joints: {
			...e.body.joints,
			head: [
				e.body.joints.head[0],
				e.body.joints.head[1] + l + a,
				e.body.joints.head[2]
			]
		}
	};
	pt(i, t.skins?.body, p, r);
	let m = t.face.parts.map(nt), h = Be.flatMap((n) => {
		let r = e.features?.[n], i = t.features?.[n];
		return r && i ? [{
			feature: n,
			model: r,
			asset: i
		}] : [];
	}), g = yt(m, {
		model: e.face,
		asset: t.face
	}, h), _ = m.map(nt);
	at(_, e.face, p, r), it(m, e.face, t.moves, n.expression), bt(m, e.face, ht(e.face, t.face), U(n.shape.eyes)), St(m, e.face, ht(e.face, t.face), n.faceShape), n.chibiFace && xt(m, e.face, ht(e.face, t.face)), n.shading !== "model" && m.splice(0, m.length, ...mt(m, e.face, ht(e.face, t.face))), at(m, e.face, p, r);
	let v = n.madeHair ? Le(n.madeHair, e.face.joints.head, e.face.headSize) : null, y = v?.asset ?? null, b = y ? e.face : e.hair, x = y ?? t.hair, S = x.parts.map(nt);
	y || ot(S, e.hair, n.hairLength ?? 1), at(S, b, p, r);
	let C = [], w = [], T = [], E = [], D = (e, t, n) => {
		let r = w.length, i = T.length;
		for (let e of t) C.push({
			...e,
			material: e.material + r
		});
		e.materials.forEach((e, t) => {
			w.push(rt(e, i)), E.push(n[t] ?? "cloth");
		}), T.push(...e.textures);
	};
	D(u, i, d), D(g, m, e.face.face.roles), D(x, S, y ? ["hair"] : e.hair.hair.roles);
	let O = o(C, w, T), k = {
		body: C.slice(0, i.length),
		face: C.slice(i.length, i.length + m.length),
		hair: C.slice(i.length + m.length)
	}, A = t.skins && v ? {
		...t.skins,
		hair: {
			bones: v.bones,
			body: /* @__PURE__ */ new Uint8Array(),
			face: /* @__PURE__ */ new Uint8Array(),
			hair: v.skin
		}
	} : t.skins, j = A ? Ft({
		...e,
		hair: b
	}, {
		...t,
		skins: A
	}, k, p, r, c) : null, M = Mt(e.face, t.moves, C, i.length, m.length, p.headSize / Math.max(1e-6, e.face.headSize) * r), N = [
		...Array(t.body.materials.length).fill(void 0),
		...ht(e.face, g),
		...Array(x.materials.length).fill(void 0)
	], P = jt(M, At(C.slice(i.length, i.length + m.length), N, p.joints.head[0], p.headSize * r), C.length, i.length);
	if (n.chibiFace && P) {
		let e = C.slice(i.length, i.length + m.length), t = gt(e.filter((e) => N[e.material] === "mouth")), n = _t(e, N, p.joints.head[0]);
		if (t && n.length) {
			let e = p.headSize * r, a = n.reduce((e, t) => e + t.mid[1], 0) / n.length, o = Math.max(t.half[0], e * .04) * 1.8;
			P.moves.forEach((n) => n.forEach((n, r) => {
				if (!n || r < i.length || r >= i.length + m.length) return;
				let s = C[r].positions;
				for (let r = 0; r < n.length / 3; r++) {
					let i = s[r * 3], c = s[r * 3 + 1], l = W((a - c) / Math.max(1e-6, a - t.mid[1])), u = W(1 - Math.abs(i - p.joints.head[0]) / (e * .32));
					n[r * 3 + 2] *= 1 - .7 * l * u, c < t.mid[1] && (n[r * 3 + 1] *= .7);
					let d = W(1 - Math.hypot(i - t.mid[0], c - t.mid[1]) / (o + e * .08));
					if (!d) continue;
					let f = 1 - .6 * d;
					n[r * 3] *= f, n[r * 3 + 1] *= f, n[r * 3 + 2] *= 1 - .8 * d;
				}
			}));
		}
	}
	return {
		asset: {
			...O,
			...j ? { skeleton: j } : {},
			...P ? { morphs: P } : {}
		},
		roles: E,
		layers: {
			body: i.length,
			face: m.length,
			hair: S.length
		},
		look: {
			kinds: N,
			middle: p.joints.head[0],
			headSize: p.headSize * r,
			rest: {
				from: i.length,
				positions: _.map((e) => e.positions)
			}
		}
	};
}
var kt = {
	boxOf: gt,
	eyesOf: _t,
	smooth: W
};
function At(e, t, n, r) {
	let i = _t(e, t, n), a = gt(e.filter((e) => t[e.material] === "mouth")), o = (i[0]?.mid[2] ?? 0) - r * .22, s = {}, c = (n, r) => {
		let i = !1;
		s[n] = e.map((e) => {
			let n = t[e.material], a = new Float32Array(e.positions.length), o = !1;
			for (let t = 0; t < e.positions.length; t += 3) {
				let i = r(e, n, e.positions[t], e.positions[t + 1], e.positions[t + 2]);
				i && (i[0] || i[1] || i[2]) && (a[t] = i[0], a[t + 1] = i[1], a[t + 2] = i[2], o = !0);
			}
			return i ||= o, o ? a : null;
		}), i || delete s[n];
	}, l = (e, t) => (r, a, o) => {
		if (a !== "iris" && a !== "highlight") return null;
		let s = i.find((e) => o > n == e.mid[0] > n);
		return s ? [
			e * s.half[0] * .38,
			t * s.half[1] * .3,
			0
		] : null;
	};
	c("look_l", l(1, 0)), c("look_r", l(-1, 0)), c("look_u", l(0, 1)), c("look_d", l(0, -1));
	let u = (e) => (t, r, i) => r === "brow" ? [
		0,
		e(i, i > n ? 1 : -1),
		0
	] : null;
	if (c("brow_up", u(() => r * .035)), c("brow_down", u((e, t) => -r * .02 - Math.max(0, r * .09 - Math.abs(e - n)) * .25 * t * t)), c("brow_worried", u((e) => Math.max(0, r * .11 - Math.abs(e - n)) * .45)), a) {
		let e = (e) => (t, n, i, s, c) => {
			if (c < o) return null;
			let l = Math.max(a.half[0], r * .03), u = Math.min(1, Math.abs(i - a.mid[0]) / l), d = n === "mouth" ? 1 : Math.max(0, 1 - Math.hypot((i - a.mid[0]) / (l * 1.8), (s - a.mid[1]) / (r * .07)));
			return d ? [
				0,
				e * r * .04 * u * u * d,
				0
			] : null;
		};
		c("mouth_smile", e(1)), c("mouth_frown", e(-1));
	}
	return s;
}
function jt(e, t, n, r) {
	let i = Object.keys(t);
	if (!i.length) return e;
	let a = (e) => Array.from({ length: n }, (t, n) => e[n - r] ?? null);
	return {
		names: [...e?.names ?? [], ...i],
		moves: [...e?.moves ?? [], ...i.map((e) => a(t[e]))]
	};
}
function Mt(e, t, n, r, i, a) {
	let o = Object.keys(e.face.expressions);
	if (o.length) return {
		names: o,
		moves: o.map((o) => n.map((n, s) => {
			let c = s >= r && s < r + i ? e.face.expressions[o][s - r] : void 0;
			if (!c || !c[1] || c[0] + c[1] * 16 > t.byteLength) return null;
			let l = new Uint32Array(t, c[0], c[1]), u = new Float32Array(t, c[0] + c[1] * 4, c[1] * 3), d = new Float32Array(n.positions.length);
			for (let e = 0; e < l.length; e++) for (let t = 0; t < 3; t++) l[e] * 3 + t < d.length && (d[l[e] * 3 + t] = u[e * 3 + t] * a);
			return d;
		}))
	};
}
var Nt = (e) => e.reduce((e, t) => e + t.positions.length / 3, 0);
function Pt(e, t, n) {
	let r = 0;
	for (let i of e) {
		let e = i.positions.length / 3, a = new Uint16Array(e * 4), o = new Float32Array(e * 4);
		for (let i = 0; i < e; i++, r++) for (let e = 0; e < 4; e++) {
			let s = t[r * 8 + 4 + e];
			s && (a[i * 4 + e] = n(t[r * 8 + e]), o[i * 4 + e] = s / 255);
		}
		i.joints = a, i.skinWeights = o;
	}
}
function Ft(e, t, n, r, i, a) {
	let o = t.skins;
	if (o.body.body.length !== Nt(n.body) * 8 || o.face.face.length !== Nt(n.face) * 8 || o.hair.hair.length !== Nt(n.hair) * 8) return null;
	let s = o.body.bones.map((e) => ({
		...e,
		head: [...e.head],
		tail: [...e.tail]
	})), c = new Map(s.map((e, t) => [e.name, t])), l = c.get("J_Bip_C_Head");
	if (l === void 0) return null;
	let u = new Float64Array(s.length * 3), d = new Float64Array(s.length), f = 0;
	n.body.forEach((e, n) => {
		let r = t.body.parts[n].positions;
		for (let t = 0; t < e.positions.length / 3; t++, f++) for (let i = 0; i < 4; i++) {
			let s = o.body.body[f * 8 + 4 + i] / 255;
			if (!s) continue;
			let c = o.body.body[f * 8 + i];
			d[c] += s;
			for (let i = 0; i < 3; i++) u[c * 3 + i] += s * (e.positions[t * 3 + i] - a[n][t * 3 + i] - r[t * 3 + i]);
		}
	});
	let p = [];
	s.forEach((e, t) => {
		p.push(d[t] > .001 ? [
			0,
			1,
			2
		].map((e) => u[t * 3 + e] / d[t]) : e.parent >= 0 ? p[e.parent] : [
			0,
			0,
			0
		]);
	});
	let m = (e) => e === l || s[e].parent >= 0 && m(s[e].parent), h = r.joints.head.map((e, t) => e - o.body.bones[l].head[t]);
	s.forEach((e, t) => {
		let n = m(t) ? h : p[t];
		e.head = e.head.map((e, t) => e + n[t]), e.tail = e.tail.map((e, t) => e + n[t]);
	});
	let g = (e, t, n) => {
		let a = /* @__PURE__ */ new Map(), o = r.headSize / Math.max(1e-6, t.headSize) * i, u = (e) => e.map((e, n) => r.joints.head[n] + (e - t.joints.head[n]) * o), d = (t) => {
			let r = a.get(t);
			if (r !== void 0) return r;
			let i = e.bones[t], o = l;
			if (i && n && /Hair/i.test(i.name) && s.length < 256) {
				let t = i.parent >= 0 && /Hair/i.test(e.bones[i.parent].name) ? d(i.parent) : l;
				o = s.push({
					name: i.name,
					parent: t,
					head: u(i.head),
					tail: u(i.tail)
				}) - 1;
			} else i && (o = c.get(i.name) ?? l);
			return a.set(t, o), o;
		};
		return d;
	};
	return Pt(n.body, o.body.body, (e) => e), Pt(n.face, o.face.face, g(o.face, e.face, !1)), Pt(n.hair, o.hair.hair, g(o.hair, e.hair, !0)), s;
}
function It(e) {
	let t = [], n = [], r = [], i = [];
	for (let { part: a, asset: o } of e) {
		let e = n.length, s = r.length;
		for (let n of o.parts) t.push({
			...n,
			material: n.material + e
		});
		o.materials.forEach((e, t) => {
			n.push(rt(e, s)), i.push(a.roles[t] ?? "cloth");
		}), r.push(...o.textures);
	}
	return {
		asset: o(t, n, r),
		roles: i
	};
}
function Lt(e, t) {
	let n = {};
	return e.materials.forEach((e, r) => {
		let i = t[r];
		if (!i || e.texture < 0 || !We.includes(i)) return;
		let a = n[i] ??= [];
		a.includes(e.texture) || a.push(e.texture);
	}), n;
}
function Rt(e, t, n) {
	let r = parseInt(t.slice(1), 16), i = [
		r >> 16 & 255,
		r >> 8 & 255,
		r & 255
	];
	if (n) {
		let t = parseInt(n.slice(1), 16), r = [
			t >> 16 & 255,
			t >> 8 & 255,
			t & 255
		], a = 255, o = 0;
		for (let t = 0; t < e.length; t += 4) {
			if (e[t + 3] < 16) continue;
			let n = .299 * e[t] + .587 * e[t + 1] + .114 * e[t + 2];
			a = Math.min(a, n), o = Math.max(o, n);
		}
		let s = Math.max(1, o - a);
		for (let t = 0; t < e.length; t += 4) {
			if (e[t + 3] < 16) continue;
			let n = (.299 * e[t] + .587 * e[t + 1] + .114 * e[t + 2] - a) / s;
			for (let a = 0; a < 3; a++) e[t + a] = Math.round(i[a] + (r[a] - i[a]) * n);
		}
		return;
	}
	let a = 0, o = 0;
	for (let t = 0; t < e.length; t += 4) e[t + 3] < 16 || (a += .299 * e[t] + .587 * e[t + 1] + .114 * e[t + 2], o++);
	let s = Math.max(1, o ? a / o : 128);
	for (let t = 0; t < e.length; t += 4) {
		if (e[t + 3] < 16) continue;
		let n = (.299 * e[t] + .587 * e[t + 1] + .114 * e[t + 2]) / s;
		for (let r = 0; r < 3; r++) {
			let a = n <= 1 ? i[r] * n : i[r] + (255 - i[r]) * Math.min(1, (n - 1) * .8);
			e[t + r] = Math.max(0, Math.min(255, Math.round(a)));
		}
	}
}
function zt(e, t, n, r, i) {
	let a = parseInt(i.slice(1), 16), o = [
		a >> 16 & 255,
		a >> 8 & 255,
		a & 255
	], s = Math.max(8, Math.round(Math.max(t, n) / 32)), c = (e, t) => {
		if (r === "stripes") return +(e % (s * 2) < s);
		if (r === "check") return +(e % (s * 2) < s) ^ t % (s * 2) < s ? .75 : 0;
		if (r === "dots") return +(Math.hypot(e % (s * 2) - s, t % (s * 2) - s) < s * .42);
		let n = (e + t) % 4 < 2 ? .55 : .25, i = Math.sin(e * 12.9898 + t * 78.233) * 43758.5453;
		return n + (i - Math.floor(i) - .5) * .2;
	}, l = 0, u = 0;
	for (let t = 0; t < e.length; t += 4) e[t + 3] < 16 || (l += .299 * e[t] + .587 * e[t + 1] + .114 * e[t + 2], u++);
	let d = Math.max(1, u ? l / u : 128);
	for (let r = 0; r < n; r++) for (let n = 0; n < t; n++) {
		let i = (r * t + n) * 4;
		if (e[i + 3] < 16) continue;
		let a = Math.max(0, Math.min(1, c(n, r)));
		if (!a) continue;
		let s = Math.min(1.25, (.299 * e[i] + .587 * e[i + 1] + .114 * e[i + 2]) / d);
		for (let t = 0; t < 3; t++) e[i + t] = Math.max(0, Math.min(255, Math.round(e[i + t] + (o[t] * s - e[i + t]) * a)));
	}
}
var Bt = (e) => {
	let t = parseInt(e.slice(1), 16);
	return [
		16,
		8,
		0
	].map((e) => {
		let n = (t >> e & 255) / 255;
		return n <= .04045 ? n / 12.92 : ((n + .055) / 1.055) ** 2.4;
	});
};
async function Vt(e, t, n, r, i) {
	let a = e.textures.slice(), s = e.materials.slice(), c = Lt(e, t);
	for (let e of We) {
		let o = n?.[e];
		if (o && /^#[0-9a-f]{6}$/i.test(o)) {
			for (let t of c[e] ?? []) {
				let n = await r.decode(a[t].bytes, a[t].mime);
				Rt(n.data, o, e === "top" || e === "bottom" ? i?.prints?.[e] : void 0), a[t] = await r.encode(n.width, n.height, n.data);
			}
			s.forEach((n, r) => {
				t[r] === e && (s[r] = {
					...n,
					color: n.texture < 0 ? Bt(o) : [
						1,
						1,
						1
					],
					emissive: [
						0,
						0,
						0
					],
					emissiveTexture: -1
				});
			});
		}
	}
	for (let e of ["top", "bottom"]) {
		let t = i?.patterns?.[e];
		if (t && et.includes(t.pattern) && /^#[0-9a-f]{6}$/i.test(t.colour)) for (let n of c[e] ?? []) {
			let e = await r.decode(a[n].bytes, a[n].mime);
			zt(e.data, e.width, e.height, t.pattern, t.colour), a[n] = await r.encode(e.width, e.height, e.data);
		}
	}
	return {
		...e,
		...o(e.parts, s, a)
	};
}
function Ht(e) {
	let t = e.flat();
	if (!t.length) return {
		contours: [],
		aspect: 1
	};
	let n = t.map((e) => e[0]), r = t.map((e) => e[1]), [i, a, o, s] = [
		Math.min(...n),
		Math.max(...n),
		Math.min(...r),
		Math.max(...r)
	], c = Math.max(a - i, 1e-6), l = Math.max(s - o, 1e-6);
	return {
		contours: e.map((e) => e.map(([e, t]) => [Ut((e - i) / c - .5), Ut((t - o) / l - .5)])),
		aspect: c / l
	};
}
var Ut = (e) => Math.round(e * 1e4) / 1e4;
function Wt(e, t, n, r) {
	let i = new Uint8Array(t * n), a = [];
	for (let t of e) for (let e = 0; e < t.length; e++) {
		let n = r(t[e]), i = r(t[(e + 1) % t.length]);
		n[1] !== i[1] && a.push([
			n[0],
			n[1],
			i[0],
			i[1]
		]);
	}
	let o = [];
	for (let e = 0; e < n; e++) {
		let n = e + .5;
		o.length = 0;
		for (let [e, t, r, i] of a) (t <= n && i > n || i <= n && t > n) && o.push(e + (n - t) / (i - t) * (r - e));
		o.sort((e, t) => e - t);
		for (let n = 0; n + 1 < o.length; n += 2) {
			let r = Math.max(0, Math.ceil(o[n] - .5)), a = Math.min(t - 1, Math.floor(o[n + 1] - .5));
			for (let n = r; n <= a; n++) i[e * t + n] = 1;
		}
	}
	return i;
}
var Gt = /* @__PURE__ */ new Map(), Kt = /* @__PURE__ */ new WeakMap();
function qt(e, t, n) {
	let r = Kt.get(e);
	if (r && r.sx === t && r.sy === n) return r.field;
	let i = `${t.toFixed(4)}x${n.toFixed(4)}:${JSON.stringify(e)}`, a = Gt.get(i);
	if (a) return Kt.set(e, {
		sx: t,
		sy: n,
		field: a
	}), a;
	let o = Math.max(t, n) / 2 * 1.3, s = 2 * o / 256, c = ([e, r]) => [(e * t + o) / s, (o - r * n) / s], l = Wt(e, 256, 256, c), u = Jt(e.map((e) => e.map(c)), 256, 256, 25), d = /* @__PURE__ */ new Float32Array(65536);
	for (let e = 0; e < d.length; e++) {
		let t = l[e] ? -u[e] : u[e];
		d[e] = Math.min(24, Math.max(-24, t));
	}
	let f = {
		grid: d,
		half: o,
		texel: s
	};
	return Gt.size > 64 && Gt.delete(Gt.keys().next().value), Gt.set(i, f), Kt.set(e, {
		sx: t,
		sy: n,
		field: f
	}), f;
}
function Jt(e, t, n, r) {
	let i = new Float32Array(t * n).fill(r);
	for (let a of e) for (let e = 0; e < a.length; e++) {
		let [o, s] = a[e], [c, l] = a[(e + 1) % a.length], u = c - o, d = l - s, f = u * u + d * d || 1e-12, p = Math.max(0, Math.floor(Math.min(o, c) - r)), m = Math.min(t - 1, Math.ceil(Math.max(o, c) + r)), h = Math.max(0, Math.floor(Math.min(s, l) - r)), g = Math.min(n - 1, Math.ceil(Math.max(s, l) + r));
		for (let e = h; e <= g; e++) {
			let n = e + .5;
			for (let r = p; r <= m; r++) {
				let a = r + .5, c = Math.min(1, Math.max(0, ((a - o) * u + (n - s) * d) / f)), l = a - o - u * c, p = n - s - d * c, m = Math.sqrt(l * l + p * p), h = e * t + r;
				m < i[h] && (i[h] = m);
			}
		}
	}
	return i;
}
function Yt(e, t, n) {
	let r = Math.min(255, Math.max(0, (t + e.half) / e.texel - .5)), i = Math.min(255, Math.max(0, (e.half - n) / e.texel - .5)), a = Math.floor(r), o = Math.floor(i), s = Math.min(255, a + 1), c = Math.min(255, o + 1), l = r - a, u = i - o, d = e.grid, f = ((d[o * 256 + a] * (1 - l) + d[o * 256 + s] * l) * (1 - u) + (d[c * 256 + a] * (1 - l) + d[c * 256 + s] * l) * u) * e.texel, p = Math.max(Math.abs(t) - e.half * .98, 0), m = Math.max(Math.abs(n) - e.half * .98, 0);
	return f + Math.hypot(p, m);
}
function Xt(e, t, n, r) {
	let i = (e, i) => e >= 0 && i >= 0 && e < n && i < r ? t[i * n + e] : 0;
	return e.map(([t, n], r) => {
		let [a, o] = e[(r + 1) % e.length], [s, c] = [a - t, o - n], [l, u] = [(t + a) / 2, (n + o) / 2], [d, f] = [l + c * .5, u - s * .5], [p, m] = [l - c * .5, u + s * .5], h = i(Math.floor(d), Math.floor(f)), g = i(Math.floor(p), Math.floor(m)), _ = h - g > 1e-6 ? Math.min(1, Math.max(0, (h - .5) / (h - g))) : .5;
		return [d + (p - d) * _, f + (m - f) * _];
	});
}
function Zt(e) {
	let t = e;
	for (let e = 0; e < 2; e++) t = t.map(([e, n], r) => {
		let [i, a] = t[(r + t.length - 1) % t.length], [o, s] = t[(r + 1) % t.length];
		return [(i + 2 * e + o) / 4, (a + 2 * n + s) / 4];
	});
	return t;
}
function Qt(e, t, n, r = .75, i) {
	let a = (r, i) => r >= 0 && i >= 0 && r < t && i < n ? e[i * t + r] : 0, o = /* @__PURE__ */ new Map(), s = (e, n) => n * (t + 1) + e, c = (e, t, n, r) => {
		let i = s(e, t), a = o.get(i);
		a ? a.push(s(n, r)) : o.set(i, [s(n, r)]);
	};
	for (let e = 0; e <= n; e++) for (let r = 0; r <= t; r++) {
		if (r < t) {
			let t = a(r, e - 1), n = a(r, e);
			t && !n ? c(r, e, r + 1, e) : n && !t && c(r + 1, e, r, e);
		}
		if (e < n) {
			let t = a(r - 1, e), n = a(r, e);
			n && !t ? c(r, e, r, e + 1) : t && !n && c(r, e + 1, r, e);
		}
	}
	let l = [];
	for (let [e] of o) for (; o.get(e)?.length;) {
		let a = [], s = e;
		for (let r = 0; r < 4 * (t + 1) * (n + 1); r++) {
			a.push([s % (t + 1), Math.floor(s / (t + 1))]);
			let n = o.get(s), r = n.pop();
			if (n.length || o.delete(s), s = r, s === e) break;
		}
		a.length >= 4 && l.push($t(i ? Zt(Xt(a, i, t, n)) : a, r));
	}
	return l.filter((e) => e.length >= 3);
}
function $t(e, t) {
	if (e.length < 8 || t <= 0) return e;
	let n = 0, r = -1;
	for (let t = 1; t < e.length; t++) {
		let i = Math.hypot(e[t][0] - e[0][0], e[t][1] - e[0][1]);
		i > r && (r = i, n = t);
	}
	let i = (e) => {
		if (e.length < 3) return e;
		let [n, r] = [e[0], e[e.length - 1]], a = Math.hypot(r[0] - n[0], r[1] - n[1]) || 1e-9, o = 0, s = 0;
		for (let t = 1; t < e.length - 1; t++) {
			let i = e[t], c = Math.abs((r[0] - n[0]) * (n[1] - i[1]) - (n[0] - i[0]) * (r[1] - n[1])) / a;
			c > o && (o = c, s = t);
		}
		return o <= t ? [n, r] : [...i(e.slice(0, s + 1)).slice(0, -1), ...i(e.slice(s))];
	}, a = i(e.slice(0, n + 1)), o = i([...e.slice(n), e[0]]);
	return [...a.slice(0, -1), ...o.slice(0, -1)];
}
var en = (e) => e.reduce((t, n, r) => t + (n[0] * e[(r + 1) % e.length][1] - e[(r + 1) % e.length][0] * n[1]), 0) / 2, tn = (e, t, n = Math.PI / 2) => Array.from({ length: e }, (r, i) => {
	let a = n + i / e * Math.PI * 2;
	return [Math.cos(a) * t(i), Math.sin(a) * t(i)];
}), nn = {
	star: {
		label: "Star",
		contours: [tn(10, (e) => e % 2 ? .2 : .5)]
	},
	heart: {
		label: "Heart",
		contours: [Array.from({ length: 72 }, (e, t) => {
			let n = t / 72 * Math.PI * 2;
			return [16 * Math.sin(n) ** 3, 13 * Math.cos(n) - 5 * Math.cos(2 * n) - 2 * Math.cos(3 * n) - Math.cos(4 * n)];
		})]
	},
	hexagon: {
		label: "Hexagon",
		contours: [tn(6, () => .5, 0)]
	},
	arrow: {
		label: "Arrow",
		contours: [[
			[-.5, -.12],
			[.1, -.12],
			[.1, -.3],
			[.5, 0],
			[.1, .3],
			[.1, .12],
			[-.5, .12]
		]]
	},
	cross: {
		label: "Plus",
		contours: [[
			[-.15, -.5],
			[.15, -.5],
			[.15, -.15],
			[.5, -.15],
			[.5, .15],
			[.15, .15],
			[.15, .5],
			[-.15, .5],
			[-.15, .15],
			[-.5, .15],
			[-.5, -.15],
			[-.15, -.15]
		]]
	},
	donut: {
		label: "Washer",
		contours: [tn(48, () => .5), tn(48, () => .22)]
	},
	bolt: {
		label: "Bolt",
		contours: [[
			[.1, .5],
			[-.3, -.05],
			[-.02, -.05],
			[-.15, -.5],
			[.3, .08],
			[.02, .08]
		]]
	}
};
function rn(e, t) {
	let n = [], r = (e) => e.map(([e, t]) => [-e, t]);
	for (let i of e) {
		let e = t < 1e-4, a = i.map(([t]) => e && t <= -.48), o = i.map(([e, n], r) => [a[r] ? 0 : (t + (e + .5) * (1 - t)) / 2, n]);
		if (!a.some(Boolean)) {
			n.push(o, r(o).reverse());
			continue;
		}
		let s = i.length;
		for (let e = 0; e < s; e++) {
			if (!a[e] || a[(e + 1) % s]) continue;
			let t = [o[e]], i = (e + 1) % s;
			for (; !a[i];) t.push(o[i]), i = (i + 1) % s;
			t.push(o[i]), t.length >= 3 && n.push([...t, ...r(t).reverse().slice(1, -1)]);
		}
	}
	return n;
}
var an = /* @__PURE__ */ new WeakMap();
function on(e, t) {
	let n = an.get(e);
	n || an.set(e, n = /* @__PURE__ */ new Map());
	let r = n.get(t);
	return r || (n.size > 16 && n.clear(), n.set(t, r = rn(e, t))), r;
}
function sn(e, t, n = 48) {
	let r = [[0, 0]];
	for (let t = 0; t <= n; t++) r.push([Math.max(e(t / n), .02), t / n]);
	if (t) {
		let i = Math.ceil(n * (1 - t.floor));
		for (let n = 0; n <= i; n++) {
			let a = 1 - n / i * (1 - t.floor);
			r.push([Math.max(e(a) - t.wall, .02), a]);
		}
		r.push([0, t.floor]);
	} else r.push([0, 1]);
	return r;
}
var cn = (e, t, n) => e + (t - e) * (.5 - .5 * Math.cos(Math.PI * Math.min(1, Math.max(0, n)))), ln = {
	vase: {
		label: "Vase",
		contours: [sn((e) => .35 + .6 * Math.sin(Math.PI * e) ** 2 + .25 * Math.max(0, (e - .85) / .15) ** 2, {
			floor: .06,
			wall: .07
		})]
	},
	bottle: {
		label: "Bottle",
		contours: [sn((e) => e < .58 ? 1 - .06 * Math.max(0, 1 - e / .05) : e < .8 ? cn(1, .3, (e - .58) / .22) : .3 + (e > .95 ? .05 : 0))]
	},
	bowl: {
		label: "Bowl",
		contours: [sn((e) => .4 + .6 * Math.sin(e * Math.PI / 2), {
			floor: .14,
			wall: .06
		})]
	},
	cup: {
		label: "Cup",
		contours: [sn((e) => .78 + .22 * e, {
			floor: .08,
			wall: .08
		})]
	},
	goblet: {
		label: "Goblet",
		contours: [sn((e) => e < .05 ? .75 : e < .12 ? cn(.75, .1, (e - .05) / .07) : e < .48 ? .1 : .1 + .9 * Math.sin((e - .48) / .52 * (Math.PI / 2)), {
			floor: .6,
			wall: .05
		})]
	},
	stand: {
		label: "Display stand",
		contours: [sn((e) => e < .14 ? 1 : e < .22 ? cn(1, .62, (e - .14) / .08) : e < .8 ? .62 : e < .88 ? cn(.62, 1, (e - .8) / .08) : 1)]
	}
}, un = /* @__PURE__ */ e({
	FINISH: () => jn,
	FINISH_EXTRA: () => Mn,
	blendRadius: () => kn,
	copiesDistance: () => Dn,
	copyCentres: () => On,
	copyUniforms: () => En,
	formOf: () => gn,
	formedDistance: () => _n,
	join: () => An,
	march: () => Ln,
	rotationMatrix: () => G,
	sampleScene: () => Fn,
	sceneDistance: () => In,
	shapeDistance: () => hn,
	sweepCut: () => bn,
	toLocal: () => fn,
	valueNoise: () => yn
}), dn = Math.PI / 180;
function G([e, t, n]) {
	let [r, i, a, o, s, c] = [
		Math.cos(e * dn),
		Math.sin(e * dn),
		Math.cos(t * dn),
		Math.sin(t * dn),
		Math.cos(n * dn),
		Math.sin(n * dn)
	];
	return [
		a * s,
		-a * c,
		o,
		r * c + i * o * s,
		r * s - i * o * c,
		-i * a,
		i * c - r * o * s,
		i * s + r * o * c,
		r * a
	];
}
function fn(e, t) {
	let n = G(e.rotation), r = [
		t[0] - e.position[0],
		t[1] - e.position[1],
		t[2] - e.position[2]
	];
	return [
		n[0] * r[0] + n[3] * r[1] + n[6] * r[2],
		n[1] * r[0] + n[4] * r[1] + n[7] * r[2],
		n[2] * r[0] + n[5] * r[1] + n[8] * r[2]
	];
}
var pn = (e, t) => Math.hypot(e, t), mn = (e, t, n) => Math.hypot(e, t, n), K = (e, t, n) => Math.min(n, Math.max(t, e));
function hn(e, t) {
	let [n, r, i] = [
		e.size[0] / 2,
		e.size[1] / 2,
		e.size[2] / 2
	], a = e.round * Math.min(e.size[0], e.size[1], e.size[2]), [o, s, c] = t;
	switch (e.kind) {
		case "box": {
			let e = Math.abs(o) - n + a, t = Math.abs(s) - r + a, l = Math.abs(c) - i + a;
			return mn(Math.max(e, 0), Math.max(t, 0), Math.max(l, 0)) + Math.min(Math.max(e, t, l), 0) - a;
		}
		case "sphere": {
			let e = mn(o / n, s / r, c / i), t = mn(o / (n * n), s / (r * r), c / (i * i));
			return t > 0 ? e * (e - 1) / t : -Math.min(n, r, i);
		}
		case "cylinder": {
			let e = Math.min(n, i), t = Math.min(a, e, r), l = pn(o * e / n, c * e / i) - e + t, u = Math.abs(s) - r + t;
			return Math.min(Math.max(l, u), 0) + pn(Math.max(l, 0), Math.max(u, 0)) - t;
		}
		case "cone": {
			let e = Math.min(n, i), t = pn(o * e / n, c * e / i), l = s, u = r, d = -e, f = 2 * u, p = t - Math.min(t, l < 0 ? e : 0), m = Math.abs(l) - u, h = K((-t * d + (u - l) * f) / (d * d + f * f), 0, 1), g = t + d * h, _ = l - u + f * h;
			return (g < 0 && m < 0 ? -1 : 1) * Math.sqrt(Math.min(p * p + m * m, g * g + _ * _)) - a * .5;
		}
		case "torus": {
			let t = Math.min(e.thickness * n, r), a = Math.max(n - t, .001);
			return pn(pn(o, c * n / i) - a, s) - t;
		}
		case "capsule": {
			let e = Math.min(n, i), t = Math.max(r - e, 0), a = s - K(s, -t, t);
			return mn(o * e / n, a, c * e / i) - e;
		}
		case "pyramid": {
			let e = Math.min(n, i), t = 2 * r / (2 * e), l = Math.abs(o * e / n) / (2 * e), u = Math.abs(c * e / i) / (2 * e), d = (s + r) / (2 * e);
			u > l && ([l, u] = [u, l]), l -= .5, u -= .5;
			let f = t * t + .25, p = u, m = t * d - .5 * l, h = t * l + .5 * d, g = Math.max(-p, 0), _ = K((m - .5 * u) / (f + .25), 0, 1), v = f * (p + g) * (p + g) + m * m, y = f * (p + .5 * _) * (p + .5 * _) + (m - f * _) * (m - f * _), b = Math.min(m, -p * f - m * .5) > 0 ? 0 : Math.min(v, y);
			return 2 * e * Math.sqrt((b + h * h) / f) * Math.sign(Math.max(h, -d)) - a * .5;
		}
		case "extrude":
		case "text": {
			if (!e.outline) return 1e9;
			let t = Yt(qt(e.outline, e.size[0], e.size[1]), o, s), n = Math.min(a, i * .95), r = t + n, l = Math.abs(c) - i + n;
			return Math.min(Math.max(r, l), 0) + pn(Math.max(r, 0), Math.max(l, 0)) - n;
		}
		case "revolve": {
			if (!e.outline) return 1e9;
			let t = Math.min(n, i), r = pn(o * t / n, c * t / i);
			return bn(Yt(qt(hc(e), ...mc(e)), r, s), o, c, e.revolve?.sweep ?? 360);
		}
		case "group":
		case "mesh": return 1e9;
	}
}
function gn(e) {
	let t = e.form;
	return t ? [
		t.hollow ?? 0,
		(t.twist ?? 0) * Math.PI / 180,
		(t.bend ?? 0) * Math.PI / 180,
		t.taper ?? 0
	] : [
		0,
		0,
		0,
		0
	];
}
function _n(e, t) {
	let [n, r, i, a] = gn(e), o = e.size[0] / 2, s = e.size[1] / 2, c = e.size[2] / 2, [l, u, d] = t;
	if (a !== 0) {
		let e = Math.max(.05, 1 + a * K(u / s, -1, 1));
		l /= e, d /= e;
	}
	if (r !== 0) {
		let e = r * u / (2 * s), t = Math.cos(e), n = Math.sin(e);
		[l, d] = [t * l - n * d, n * l + t * d];
	}
	if (i !== 0) {
		let e = i * l / (2 * o), t = Math.cos(e), n = Math.sin(e);
		[l, u] = [t * l - n * u, n * l + t * u];
	}
	let f = mn(o, s, c), p = 1 + Math.abs(r) * f / (2 * s) + Math.abs(i) * f / (2 * o) + Math.abs(a) * 2, m = e.form?.noise ?? 0, h = e.form?.noiseScale ?? 8, g = hn(e, [
		l,
		u,
		d
	]) / (p + m * h * 1.5);
	return m > 0 && (g += m * yn(t[0] * h, t[1] * h, t[2] * h)), n > 0 && (g = Math.abs(g + n * .5) - n * .5), g;
}
function vn(e, t, n) {
	let r = (Math.imul(e, 73856093) ^ Math.imul(t, 19349663) ^ Math.imul(n, 83492791)) >>> 0;
	return r = Math.imul(r ^ r >>> 13, 1274126177) >>> 0, r = (r ^ r >>> 16) >>> 0, (r & 16777215) / 16777215 * 2 - 1;
}
function yn(e, t, n) {
	let r = Math.floor(e), i = Math.floor(t), a = Math.floor(n), o = e - r, s = t - i, c = n - a, l = (e) => e * e * (3 - 2 * e), [u, d, f] = [
		l(o),
		l(s),
		l(c)
	], p = (e, t, n) => e + (t - e) * n, m = (e, t, n) => vn(r + e, i + t, a + n);
	return p(p(p(m(0, 0, 0), m(1, 0, 0), u), p(m(0, 1, 0), m(1, 1, 0), u), d), p(p(m(0, 0, 1), m(1, 0, 1), u), p(m(0, 1, 1), m(1, 1, 1), u), d), f);
}
function bn(e, t, n, r) {
	if (r >= 360) return e;
	let i = r * dn, a = -n, o = -Math.sin(i) * t + Math.cos(i) * n;
	return Math.max(e, i <= Math.PI ? Math.max(a, o) : Math.min(a, o));
}
var xn = {
	x: [1, 2],
	y: [0, 2],
	z: [0, 1]
};
function Sn(e, t, n) {
	let [r, i] = xn[t], a = Math.cos(n), o = Math.sin(n), s = [
		e[0],
		e[1],
		e[2]
	];
	return s[r] = e[r] * a + e[i] * o, s[i] = -e[r] * o + e[i] * a, s;
}
function Cn(e) {
	let t = e.arc >= 360;
	return {
		full: t,
		step: t ? 2 * Math.PI / e.count : e.arc * dn / (e.count - 1),
		from: t ? -Math.PI : e.arc * dn / 2 - Math.PI
	};
}
function wn(e, t) {
	let n = [
		t[0],
		t[1],
		t[2]
	];
	e.mirror?.x && (n[0] = (e.position[0] < 0 ? -1 : 1) * Math.abs(n[0])), e.mirror?.z && (n[2] = (e.position[2] < 0 ? -1 : 1) * Math.abs(n[2]));
	let r = e.repeat;
	if (r?.kind !== "around") return [n];
	let [i, a] = xn[r.axis], { full: o, step: s, from: c } = Cn(r), l = Math.atan2(e.position[a], e.position[i]), u = c + ((Math.atan2(n[a], n[i]) - l - c) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI), d = (e) => o ? e : K(e, 0, r.count - 1), f = d(Math.round(u / s)), p = d(f + (u > f * s ? 1 : -1));
	return (p === f ? [f] : [f, p]).map((e) => Sn(n, r.axis, e * s));
}
function Tn(e, t) {
	let n = e.repeat;
	if (n?.kind !== "grid") return _n(e, t);
	let r = [
		0,
		1,
		2
	].map((e) => {
		let r = n.count[e], i = n.spacing[e];
		if (r < 2) return [0];
		let a = K(Math.round(t[e] / i), 0, r - 1), o = K(a + (t[e] > a * i ? 1 : -1), 0, r - 1);
		return o === a ? [a] : [a, o];
	}), i = 1e9;
	for (let a of r[0]) for (let o of r[1]) for (let s of r[2]) i = Math.min(i, _n(e, [
		t[0] - a * n.spacing[0],
		t[1] - o * n.spacing[1],
		t[2] - s * n.spacing[2]
	]));
	return i;
}
function En(e) {
	let t = +!!e.mirror?.x + (e.mirror?.z ? 2 : 0), n = e.repeat;
	if (n?.kind === "grid") return {
		a: [1, ...n.count],
		b: [...n.spacing, t]
	};
	if (n?.kind === "around") {
		let { full: r, step: i, from: a } = Cn(n), [o, s] = xn[n.axis], c = n.axis === "x" ? 0 : n.axis === "y" ? 1 : 2;
		return {
			a: [
				2,
				n.count,
				c,
				i
			],
			b: [
				Math.atan2(e.position[s], e.position[o]),
				a,
				+!!r,
				t
			]
		};
	}
	return {
		a: [
			0,
			1,
			1,
			1
		],
		b: [
			1,
			1,
			1,
			t
		]
	};
}
function Dn(e, t) {
	if (!e.mirror && !e.repeat) return _n(e, fn(e, t));
	let n = 1e9;
	for (let r of wn(e, t)) n = Math.min(n, Tn(e, fn(e, r)));
	return n;
}
function On(e) {
	let t = [e.position], n = e.repeat;
	if (n?.kind === "grid") {
		let r = G(e.rotation), i = [];
		for (let t of [0, n.count[0] - 1]) for (let a of [0, n.count[1] - 1]) for (let o of [0, n.count[2] - 1]) {
			let s = [
				t * n.spacing[0],
				a * n.spacing[1],
				o * n.spacing[2]
			];
			i.push([
				0,
				1,
				2
			].map((t) => e.position[t] + r[t * 3] * s[0] + r[t * 3 + 1] * s[1] + r[t * 3 + 2] * s[2]));
		}
		t = i;
	} else if (n?.kind === "around") {
		let { step: r } = Cn(n);
		t = Array.from({ length: n.count }, (t, i) => Sn(e.position, n.axis, -i * r));
	}
	return e.mirror?.x && (t = t.concat(t.map((e) => [
		-e[0],
		e[1],
		e[2]
	]))), e.mirror?.z && (t = t.concat(t.map((e) => [
		e[0],
		e[1],
		-e[2]
	]))), t;
}
var kn = (e) => e.blend * .6;
function An(e, t, n, r) {
	if (n === "add") {
		if (r > 1e-4) {
			let n = K(.5 + .5 * (e - t) / r, 0, 1);
			return {
				d: e * (1 - n) + t * n - r * n * (1 - n),
				h: n
			};
		}
		return t < e ? {
			d: t,
			h: 1
		} : {
			d: e,
			h: 0
		};
	}
	if (n === "subtract") {
		let n = -t;
		if (r > 1e-4) {
			let t = K(.5 + .5 * (n - e) / r, 0, 1);
			return {
				d: e * (1 - t) + n * t + r * t * (1 - t),
				h: t
			};
		}
		return n > e ? {
			d: n,
			h: 1
		} : {
			d: e,
			h: 0
		};
	}
	if (r > 1e-4) {
		let n = K(.5 + .5 * (t - e) / r, 0, 1);
		return {
			d: e * (1 - n) + t * n + r * n * (1 - n),
			h: n
		};
	}
	return t > e ? {
		d: t,
		h: 1
	} : {
		d: e,
		h: 0
	};
}
var jn = {
	matte: [8, 0],
	satin: [32, 0],
	glossy: [140, 0],
	metal: [64, 1],
	glass: [220, 0],
	glow: [8, 0],
	velvet: [4, 0],
	coat: [400, 0]
}, Mn = {
	matte: [0, 0],
	satin: [0, 0],
	glossy: [0, 0],
	metal: [0, 0],
	glass: [0, 1],
	glow: [1, 0],
	velvet: [0, 0],
	coat: [0, 0]
}, Nn = (e) => {
	let t = parseInt(e.slice(1), 16);
	return [
		(t >> 16 & 255) / 255,
		(t >> 8 & 255) / 255,
		(t & 255) / 255
	];
}, Pn = (e, t, n) => [
	e[0] + (t[0] - e[0]) * n,
	e[1] + (t[1] - e[1]) * n,
	e[2] + (t[2] - e[2]) * n
];
function Fn(e, t, n = Mc(e)) {
	let r = {
		d: 1e9,
		color: [
			.8,
			.8,
			.8
		],
		shine: 32,
		metal: 0,
		glow: 0,
		glass: 0,
		owner: null
	}, i = r;
	for (let e of n) {
		if (e.op === "begin") {
			i = r, r = {
				d: 1e9,
				color: [
					.8,
					.8,
					.8
				],
				shine: 32,
				metal: 0,
				glow: 0,
				glass: 0,
				owner: null
			};
			continue;
		}
		let n = e.op === "end" ? e.group : e.shape, a = e.op === "end" ? r.d : Dn(n, t), o = e.op === "end" ? r.color : Nn(n.color), [s, c] = e.op === "end" ? [r.shine, r.metal] : jn[n.finish], [l, u] = e.op === "end" ? [r.glow, r.glass] : Mn[n.finish], d = e.op === "end" ? r.owner : e.path, f = e.op === "end" ? i : r, { d: p, h: m } = An(f.d, a, n.combine, kn(n));
		r = {
			d: p,
			color: Pn(f.color, o, m),
			shine: f.shine + (s - f.shine) * m,
			metal: f.metal + (c - f.metal) * m,
			glow: f.glow + (l - f.glow) * m,
			glass: f.glass + (u - f.glass) * m,
			owner: m > .5 ? d : f.owner
		};
	}
	return r;
}
function In(e, t) {
	let n = Fn(e, t);
	return {
		d: n.d,
		shape: n.owner
	};
}
function Ln(e, t, n, r = 200) {
	let i = Mc(e), a = 0;
	for (let o = 0; o < 256 && a < r; o++) {
		let r = Fn(e, [
			t[0] + n[0] * a,
			t[1] + n[1] * a,
			t[2] + n[2] * a
		], i);
		if (r.d < .001 * Math.max(1, a)) return {
			t: a,
			shape: r.owner
		};
		a += Math.max(r.d * .9, 1e-4);
	}
	return null;
}
//#endregion
//#region ../scene3d/src/model/rig.ts
var Rn = 256, zn = (e, t, n, r) => typeof e == "number" && Number.isFinite(e) ? Math.min(n, Math.max(t, e)) : r, Bn = (e, t, n) => Array.isArray(e) && e.length === 3 ? e.map((e) => zn(e, t, n, 0)) : [
	0,
	0,
	0
];
function Vn(e) {
	if (!e || typeof e != "object") return;
	let t = e;
	if (!Array.isArray(t.bones)) return;
	let n = t.bones.slice(0, Rn).flatMap((e, t) => {
		if (!e || typeof e != "object") return [];
		let n = e, r = Math.round(zn(n.parent, -1, t - 1, -1));
		return [{
			name: typeof n.name == "string" ? n.name.slice(0, 40) : `Bone ${t + 1}`,
			head: Bn(n.head, -1e4, 1e4),
			tail: Bn(n.tail, -1e4, 1e4),
			parent: r
		}];
	});
	if (!n.length) return;
	let r = n.map((e, n) => Array.isArray(t.pose) ? Bn(t.pose[n], -360, 360) : [
		0,
		0,
		0
	]), i = e.root;
	return {
		bones: n,
		pose: r,
		...Array.isArray(i) ? { root: Bn(i, -1e4, 1e4) } : {}
	};
}
var Hn = (e) => e.skeleton?.length ? {
	bones: e.skeleton.map((e) => ({
		...e,
		head: [...e.head],
		tail: [...e.tail]
	})),
	pose: e.skeleton.map(() => [
		0,
		0,
		0
	])
} : void 0, Un = (e, t) => e.skeleton?.length === t.bones.length && e.skeleton.every((e, n) => e.name === t.bones[n].name), q = (e, t, n, r) => [
	e.min[0] + (e.max[0] - e.min[0]) * t,
	e.min[1] + (e.max[1] - e.min[1]) * n,
	e.min[2] + (e.max[2] - e.min[2]) * r
];
function Wn(e) {
	let t = (e, t, n, r) => ({
		name: e,
		head: t,
		tail: n,
		parent: r
	}), n = [
		t("Hips", q(e, .5, .5, .5), q(e, .5, .6, .5), -1),
		t("Spine", q(e, .5, .6, .5), q(e, .5, .72, .5), 0),
		t("Chest", q(e, .5, .72, .5), q(e, .5, .82, .5), 1),
		t("Neck", q(e, .5, .82, .5), q(e, .5, .87, .5), 2),
		t("Head", q(e, .5, .87, .5), q(e, .5, 1, .5), 3),
		t("Upper arm L", q(e, .62, .8, .5), q(e, .78, .68, .5), 2),
		t("Forearm L", q(e, .78, .68, .5), q(e, .92, .55, .5), 5),
		t("Upper arm R", q(e, .38, .8, .5), q(e, .22, .68, .5), 2),
		t("Forearm R", q(e, .22, .68, .5), q(e, .08, .55, .5), 7),
		t("Thigh L", q(e, .58, .5, .5), q(e, .58, .26, .5), 0),
		t("Shin L", q(e, .58, .26, .5), q(e, .58, .02, .5), 9),
		t("Thigh R", q(e, .42, .5, .5), q(e, .42, .26, .5), 0),
		t("Shin R", q(e, .42, .26, .5), q(e, .42, .02, .5), 11),
		t("Hand L", q(e, .92, .55, .5), q(e, 1, .5, .5), 6),
		t("Hand R", q(e, .08, .55, .5), q(e, 0, .5, .5), 8),
		t("Foot L", q(e, .58, .02, .5), q(e, .58, 0, 1), 10),
		t("Foot R", q(e, .42, .02, .5), q(e, .42, 0, 1), 12)
	];
	return {
		bones: n,
		pose: n.map(() => [
			0,
			0,
			0
		])
	};
}
function Gn(e, t = 4) {
	let n = Array.from({ length: t }, (n, r) => ({
		name: `Bone ${r + 1}`,
		head: q(e, .5, r / t, .5),
		tail: q(e, .5, (r + 1) / t, .5),
		parent: r - 1
	}));
	return {
		bones: n,
		pose: n.map(() => [
			0,
			0,
			0
		])
	};
}
var J = (e, t) => [
	0,
	1,
	2
].flatMap((n) => [
	0,
	1,
	2
].map((r) => e[n * 3] * t[r] + e[n * 3 + 1] * t[3 + r] + e[n * 3 + 2] * t[6 + r])), Kn = (e, t) => [
	0,
	1,
	2
].map((n) => e[n * 3] * t[0] + e[n * 3 + 1] * t[1] + e[n * 3 + 2] * t[2]), qn = (e) => [
	e[0],
	e[3],
	e[6],
	e[1],
	e[4],
	e[7],
	e[2],
	e[5],
	e[8]
], Jn = (e, t) => {
	let n = Kn(e.r, t);
	return [
		n[0] + e.t[0],
		n[1] + e.t[1],
		n[2] + e.t[2]
	];
};
function Yn(e, t = e.pose, n = e.root) {
	let r = [];
	return e.bones.forEach((e, i) => {
		let a = G(t[i] ?? [
			0,
			0,
			0
		]), o = Kn(a, e.head), s = {
			r: a,
			t: [
				e.head[0] - o[0],
				e.head[1] - o[1],
				e.head[2] - o[2]
			]
		}, c = e.parent >= 0 ? r[e.parent] : void 0;
		c ? r.push({
			r: J(c.r, s.r),
			t: Jn(c, s.t)
		}) : r.push(n ? {
			r: s.r,
			t: [
				s.t[0] + n[0],
				s.t[1] + n[1],
				s.t[2] + n[2]
			]
		} : s);
	}), r;
}
var Xn = (e, t = e.pose) => Yn(e, t).map((t, n) => ({
	head: Jn(t, e.bones[n].head),
	tail: Jn(t, e.bones[n].tail)
}));
function Zn(e, t) {
	let n = [
		t.tail[0] - t.head[0],
		t.tail[1] - t.head[1],
		t.tail[2] - t.head[2]
	], r = [
		e[0] - t.head[0],
		e[1] - t.head[1],
		e[2] - t.head[2]
	], i = Math.min(1, Math.max(0, (n[0] * r[0] + n[1] * r[1] + n[2] * r[2]) / Math.max(1e-20, n[0] ** 2 + n[1] ** 2 + n[2] ** 2)));
	return (r[0] - n[0] * i) ** 2 + (r[1] - n[1] * i) ** 2 + (r[2] - n[2] * i) ** 2;
}
var Qn = /* @__PURE__ */ new Map();
function $n(e, t, n = "") {
	if (Un(e, t) && e.parts.every((e) => e.joints?.length === e.positions.length / 3 * 4 && e.skinWeights?.length === e.joints.length)) return e.parts.map((e) => ({
		per: 4,
		bones: e.joints,
		weights: e.skinWeights
	}));
	let r = n && `${n}|${JSON.stringify(t.bones)}`, i = r ? Qn.get(r) : void 0;
	if (i) return i;
	let a = e.parts.map((e) => {
		let n = e.positions.length / 3, r = new Uint8Array(n * 2), i = new Float32Array(n * 2);
		for (let a = 0; a < n; a++) {
			let n = [
				e.positions[a * 3],
				e.positions[a * 3 + 1],
				e.positions[a * 3 + 2]
			], o = 0, s = Infinity, c = 0, l = Infinity;
			t.bones.forEach((e, t) => {
				let r = Zn(n, e);
				r < s ? [c, l, o, s] = [
					o,
					s,
					t,
					r
				] : r < l && ([c, l] = [t, r]);
			});
			let u = 1 / (s * s + 1e-12), d = t.bones.length > 1 ? 1 / (l * l + 1e-12) : 0;
			r[a * 2] = o, r[a * 2 + 1] = c, i[a * 2] = u / (u + d), i[a * 2 + 1] = d / (u + d);
		}
		return {
			per: 2,
			bones: r,
			weights: i
		};
	});
	return r && (Qn.size > 8 && Qn.delete(Qn.keys().next().value), Qn.set(r, a)), a;
}
var er = (e) => !!e && (e.pose.some((e) => e[0] || e[1] || e[2]) || !!e.root?.some((e) => e));
function tr(e, t, n = "") {
	let r = Yn(t), i = $n(e, t, n), a = new Float64Array(r.length * 12);
	return r.forEach((e, t) => {
		a.set(e.r, t * 12), a.set(e.t, t * 12 + 9);
	}), e.parts.map((e, t) => {
		let { per: n, bones: r, weights: o } = i[t], s = e.positions.length / 3, c = new Float32Array(s * 3), l = new Float32Array(s * 3), u = e.positions, d = e.normals;
		for (let e = 0; e < s; e++) {
			let t = u[e * 3], i = u[e * 3 + 1], s = u[e * 3 + 2], f = d[e * 3], p = d[e * 3 + 1], m = d[e * 3 + 2], h = 0, g = 0, _ = 0, v = 0, y = 0, b = 0, x = 0;
			for (let c = 0; c < n; c++) {
				let l = o[e * n + c];
				if (!l) continue;
				let u = (r[e * n + c] ?? 0) * 12;
				x += l, h += l * (a[u] * t + a[u + 1] * i + a[u + 2] * s + a[u + 9]), g += l * (a[u + 3] * t + a[u + 4] * i + a[u + 5] * s + a[u + 10]), _ += l * (a[u + 6] * t + a[u + 7] * i + a[u + 8] * s + a[u + 11]), v += l * (a[u] * f + a[u + 1] * p + a[u + 2] * m), y += l * (a[u + 3] * f + a[u + 4] * p + a[u + 5] * m), b += l * (a[u + 6] * f + a[u + 7] * p + a[u + 8] * m);
			}
			x > 0 ? (c[e * 3] = h / x, c[e * 3 + 1] = g / x, c[e * 3 + 2] = _ / x) : (c[e * 3] = t, c[e * 3 + 1] = i, c[e * 3 + 2] = s);
			let S = Math.hypot(v, y, b) || 1;
			l[e * 3] = v / S, l[e * 3 + 1] = y / S, l[e * 3 + 2] = b / S;
		}
		return {
			...e,
			positions: c,
			normals: l
		};
	});
}
function nr(e) {
	let t = Math.asin(Math.min(1, Math.max(-1, e[2]))), n = 180 / Math.PI;
	return Math.abs(e[2]) < .9999999 ? [
		Math.atan2(-e[5], e[8]) * n,
		t * n,
		Math.atan2(-e[1], e[0]) * n
	] : [
		Math.atan2(e[7], e[4]) * n,
		t * n,
		0
	];
}
function rr(e, t) {
	let n = [
		e[1] * t[2] - e[2] * t[1],
		e[2] * t[0] - e[0] * t[2],
		e[0] * t[1] - e[1] * t[0]
	], r = Math.hypot(...n), i = e[0] * t[0] + e[1] * t[1] + e[2] * t[2];
	if (r < 1e-9) return [
		1,
		0,
		0,
		0,
		1,
		0,
		0,
		0,
		1
	];
	let [a, o, s] = n.map((e) => e / r), c = 1 - i;
	return [
		c * a * a + i,
		c * a * o - r * s,
		c * a * s + r * o,
		c * a * o + r * s,
		c * o * o + i,
		c * o * s - r * a,
		c * a * s - r * o,
		c * o * s + r * a,
		c * s * s + i
	];
}
var ir = (e) => {
	let t = Math.hypot(...e) || 1;
	return [
		e[0] / t,
		e[1] / t,
		e[2] / t
	];
};
function ar(e, t, n, r = 2, i = 16) {
	let a = e.pose.map((e) => [...e]), o = [];
	for (let n = t; n >= 0 && o.length < r; n = e.bones[n].parent) o.push(n);
	for (let r = 0; r < i; r++) {
		for (let r of o) {
			let i = Yn(e, a), o = Jn(i[t], e.bones[t].tail), s = Jn(i[r], e.bones[r].head), c = rr(ir([
				o[0] - s[0],
				o[1] - s[1],
				o[2] - s[2]
			]), ir([
				n[0] - s[0],
				n[1] - s[1],
				n[2] - s[2]
			])), l = e.bones[r].parent >= 0 ? i[e.bones[r].parent].r : [
				1,
				0,
				0,
				0,
				1,
				0,
				0,
				0,
				1
			];
			a[r] = nr(J(J(J(qn(l), c), l), G(a[r]))).map((e) => Math.round(e * 100) / 100);
		}
		let r = Jn(Yn(e, a)[t], e.bones[t].tail);
		if (Math.hypot(r[0] - n[0], r[1] - n[1], r[2] - n[2]) < 1e-4) break;
	}
	return a;
}
[...["left", "right"].flatMap((e) => [
	`${e}Shoulder`,
	`${e}UpperArm`,
	`${e}LowerArm`,
	`${e}Hand`,
	`${e}UpperLeg`,
	`${e}LowerLeg`,
	`${e}Foot`,
	`${e}Toes`,
	...[
		"ThumbMetacarpal",
		"ThumbProximal",
		"ThumbDistal"
	].map((t) => `${e}${t}`),
	...[
		"Index",
		"Middle",
		"Ring",
		"Little"
	].flatMap((t) => [
		"Proximal",
		"Intermediate",
		"Distal"
	].map((n) => `${e}${t}${n}`))
])];
var or = [
	"hips",
	"spine",
	"head",
	...["left", "right"].flatMap((e) => [
		`${e}UpperArm`,
		`${e}LowerArm`,
		`${e}Hand`,
		`${e}UpperLeg`,
		`${e}LowerLeg`,
		`${e}Foot`
	])
], sr = /(twist|roll|pole|target|\bik\b|\bend\b|nub|helper|socket|weapon|sec|hair|skirt|bust|breast|tail|cape|eye|tongue|jaw|teeth)/i, cr = {
	下半身: "hips",
	上半身: "spine",
	上半身2: "chest",
	上半身３: "upperChest",
	首: "neck",
	頭: "head",
	肩: "Shoulder",
	腕: "UpperArm",
	ひじ: "LowerArm",
	手首: "Hand",
	足: "UpperLeg",
	ひざ: "LowerLeg",
	足首: "Foot",
	つま先: "Toes"
}, lr = {
	親指: "Thumb",
	人指: "Index",
	人差指: "Index",
	中指: "Middle",
	薬指: "Ring",
	小指: "Little"
}, ur = [
	[/^(shoulder|clavicle|collar|collarbone)\d*$/, "Shoulder"],
	[/^(upperarm|uparm|arm|shldr)\d*$/, "UpperArm"],
	[/^(forearm|lowerarm|elbow)\d*$/, "LowerArm"],
	[/^(hand|wrist)$/, "Hand"],
	[/^(thigh|upleg|upperleg|hipjoint)\d*$/, "UpperLeg"],
	[/^(shin|calf|leg|lowerleg|knee)\d*$/, "LowerLeg"],
	[/^(foot|ankle)$/, "Foot"],
	[/^(toes?|toebase|ball)\d*$/, "Toes"]
], dr = [
	"Proximal",
	"Intermediate",
	"Distal"
], fr = [
	"Metacarpal",
	"Proximal",
	"Distal"
];
function pr(e) {
	if (sr.test(e)) return null;
	let t = /^(左|右)?(.+?)$/.exec(e.replace(/[０-９]/g, (e) => String(e.charCodeAt(0) - 65296)));
	if (t && /[^\x00-\x7f]/.test(t[2])) {
		let e = t[1] === "左" ? "left" : t[1] === "右" ? "right" : "", n = /^(.+?)(\d)$/.exec(t[2]);
		if (n && lr[n[1]] && e) {
			let t = Number(n[2]), r = lr[n[1]];
			return r === "Thumb" ? `${e}Thumb${fr[t]}` : `${e}${r}${dr[t - 1]}`;
		}
		let r = cr[t[2]];
		return r ? e ? `${e}${r}` : r[0] === r[0].toLowerCase() ? r : null : null;
	}
	let n = e.replace(/^.*[:|]/, "").replace(/([a-z0-9])([A-Z])/g, "$1 $2").toLowerCase().split(/[^a-z0-9]+/).filter((e) => e && ![
		"j",
		"bip",
		"bip01",
		"c",
		"def",
		"org",
		"mch",
		"cc",
		"base",
		"mixamorig",
		"bone",
		"armature"
	].includes(e)), r = n.includes("left") || n.includes("l") ? "left" : n.includes("right") || n.includes("r") ? "right" : "", i = n.filter((e) => ![
		"left",
		"right",
		"l",
		"r"
	].includes(e)).join("");
	if (!i) return null;
	let a = /^(?:hand)?(thumb|index|middle|ring|little|pinky|pinkie)(proximal|intermediate|distal|metacarpal)?(\d*)$/.exec(i);
	if (a && r) {
		let e = a[1].replace(/^pink(y|ie)$/, "little").replace(/^./, (e) => e.toUpperCase()), t = e === "Thumb" ? fr : dr;
		if (a[2]) {
			let n = a[2].replace(/^./, (e) => e.toUpperCase());
			return t.includes(n) ? `${r}${e}${n}` : `${r}${e}${n === "Intermediate" ? "Proximal" : "Distal"}`;
		}
		let n = Number(a[3] || 1);
		return `${r}${e}${t[Math.min(2, Math.max(0, /^0$/.test(a[3]) ? 0 : n - 1))]}`;
	}
	if (r) {
		let e = ur.find(([e]) => e.test(i));
		return e ? `${r}${e[1]}` : null;
	}
	return /^(hips?|pelvis)\d*$/.test(i) ? "hips" : /^(spine|abdomen|torso|waist)\d*$/.test(i) ? "spine" : /^upperchest$/.test(i) ? "upperChest" : /^(chest|thorax)\d*$/.test(i) ? "chest" : /^neck\d*$/.test(i) ? "neck" : /^head$/.test(i) ? "head" : null;
}
function mr(e) {
	let t = /* @__PURE__ */ new Map(), n = [];
	e.forEach((e, r) => {
		let i = pr(e.name);
		i && (i === "spine" && !/上半身/.test(e.name) ? n.push(r) : t.has(i) || t.set(i, r));
	});
	let r = [
		"spine",
		"chest",
		"upperChest"
	].filter((e) => !t.has(e));
	return n.slice(0, r.length).forEach((e, n) => t.set(r[n], e)), t;
}
var hr = (e) => [
	"hips",
	"spine",
	"leftUpperArm",
	"rightUpperArm",
	"leftLowerArm",
	"rightLowerArm",
	"leftUpperLeg",
	"rightUpperLeg",
	"leftLowerLeg",
	"rightLowerLeg"
].every((t) => e.has(t)), gr = Object.fromEntries(["left", "right"].flatMap((e) => [
	[`${e}Shoulder`, `${e}UpperArm`],
	[`${e}UpperArm`, `${e}LowerArm`],
	[`${e}LowerArm`, `${e}Hand`],
	[`${e}Hand`, `${e}MiddleProximal`],
	[`${e}UpperLeg`, `${e}LowerLeg`],
	[`${e}LowerLeg`, `${e}Foot`],
	[`${e}Foot`, `${e}Toes`],
	...[
		"Index",
		"Middle",
		"Ring",
		"Little"
	].flatMap((t) => [[`${e}${t}Proximal`, `${e}${t}Intermediate`], [`${e}${t}Intermediate`, `${e}${t}Distal`]]),
	[`${e}ThumbMetacarpal`, `${e}ThumbProximal`],
	[`${e}ThumbProximal`, `${e}ThumbDistal`]
]));
function _r(e, t) {
	let n = t.get("leftUpperArm") ?? t.get("leftUpperLeg"), r = t.get("rightUpperArm") ?? t.get("rightUpperLeg");
	return n !== void 0 && r !== void 0 && e[n].head[0] < e[r].head[0];
}
//#endregion
//#region ../scene3d/src/model/life.ts
function vr(e) {
	if (!e || typeof e != "object") return;
	let t = e, n = typeof t.amount == "number" && Number.isFinite(t.amount) ? Math.min(2, Math.max(0, t.amount)) : void 0, r = {
		...t.off === !0 ? { off: !0 } : {},
		...n === void 0 ? {} : { amount: n }
	};
	return Object.keys(r).length ? r : void 0;
}
var yr = /left|[._]l$|_l_|^l_|\.l\b|左/i, br = /right|[._]r$|_r_|^r_|\.r\b|右/i, xr = /hair|ponytail|bang|fringe|skirt|hood|ribbon|tail|cape|髪|スカート/i, Sr = /* @__PURE__ */ new WeakMap();
function Cr(e) {
	let t = Sr.get(e);
	if (t) return t;
	let n = mr(e), r = (e) => n.get(e) ?? -1, i = (t) => {
		let n = -1;
		return e.forEach((e, r) => {
			/eye|目/i.test(e.name) && !/brow|lid|lash|highlight|end|眉/i.test(e.name) && t.test(e.name) && (n = r);
		}), n;
	}, a = [i(yr), i(br)].filter((e) => e >= 0), o = r("head"), s = o >= 0 ? e[o].head[2] : 0, c = (t) => {
		let n = e[t].name;
		return xr.test(n) && !/_end$|bust|breast|sleeve/i.test(n);
	}, l = [];
	e.forEach((e, t) => {
		if (!c(t)) return;
		let n = e.parent < 0 || !c(e.parent), r = /skirt|スカート/i.test(e.name), i = /hair|bang|fringe|髪/i.test(e.name) && e.head[2] > s + .035, a = (n ? 1 : .45) * (r ? .35 : 1);
		l.push({
			bone: t,
			fore: i ? 0 : a,
			side: a * (i ? .5 : 1)
		});
	});
	let u = {
		spine: r("spine"),
		chest: r("chest"),
		upperChest: r("upperChest") >= 0 ? r("upperChest") : r("chest"),
		neck: r("neck"),
		head: o,
		shoulders: [r("leftShoulder"), r("rightShoulder")],
		eyes: a,
		loose: l
	};
	return Sr.set(e, u), u;
}
var wr = {
	blink: [
		"blink",
		"Blink",
		"まばたき",
		"Fcl_EYE_Close"
	],
	mouth: [
		"aa",
		"a",
		"A",
		"あ",
		"mouth",
		"Fcl_MTH_A"
	],
	happy: [
		"joy",
		"happy",
		"fun",
		"smile",
		"laugh",
		"relaxed",
		"笑い",
		"にこり"
	],
	laugh: ["laugh"],
	sad: [
		"sorrow",
		"sad",
		"tearful",
		"悲しい"
	],
	angry: ["angry", "怒り"],
	surprised: ["surprised", "驚き"],
	worried: ["worried", "困る"],
	shy: ["shy", "照れ"]
}, Tr = (e, t) => t.find((t) => e.includes(t)), Er = (e, t) => Math.max(0, ...t.map((t) => e?.[t] ?? 0));
function Dr(e, t) {
	let r = t.asset ? e.assets?.[t.asset] : void 0;
	if (!r) return [];
	try {
		return n(t.asset, r.data).morphs?.names ?? [];
	} catch {
		return [];
	}
}
function Or(e, t) {
	let n = (Math.imul(e | 0, 668265261) ^ Math.imul(t | 0, 374761393)) >>> 0;
	return n = Math.imul(n ^ n >>> 15, 739982445) >>> 0, n = Math.imul(n ^ n >>> 12, 695872825) >>> 0, ((n ^ n >>> 15) >>> 0) / 4294967296;
}
function kr(e) {
	let t = 2166136261;
	for (let n = 0; n < e.length; n++) t = Math.imul(t ^ e.charCodeAt(n), 16777619);
	return t >>> 0;
}
function Ar(e, t = 0) {
	let n = e * 6.2, r = Math.floor(n);
	return Or(r * 7 + 3, t) < .16 ? 0 : .6 * (.25 + .75 * Or(r, t)) * Math.sin(Math.PI * (n - r)) ** .7;
}
function jr(e, t, n = !1, r = 0) {
	let i = n ? 2 : 4, a = r > 0 ? r / Math.max(1, Math.round(r / i)) : i, o = Math.floor(e / a), s = 0, c = (e) => e < 0 ? 0 : e < .07 ? e / .07 : e < .1 ? 1 : e < .26 ? 1 - Mr((e - .1) / .16) : 0;
	for (let n of [o - 1, o]) {
		let i = r > 0 ? (n % Math.round(r / a) + Math.round(r / a)) % Math.round(r / a) : n, o = n * a + Or(i, t) * Math.max(.1, a - .7);
		s = Math.max(s, c(e - o)), Or(i, t + 7) < .15 && (s = Math.max(s, c(e - o - .3)));
	}
	return s;
}
var Mr = (e) => {
	let t = Math.min(1, Math.max(0, e));
	return t * t * (3 - 2 * t);
};
function Nr(e, t, n, r, i, a, o = {}) {
	let s = a?.amount ?? 1;
	if (a?.off || s <= 0) return {
		pose: e.pose,
		face: n
	};
	let c = Cr(e.bones), l = e.pose.map((e) => [...e]), u = (e, t, n) => {
		e >= 0 && l[e] && (l[e][t] += n * s);
	}, d = o.loop ?? 0, f = d > 0 ? (r % d + d) % d : r, p = i % 997 / 997, m = (e, t) => {
		let n = d > 0 ? Math.max(1, Math.round(e * d)) / d : e;
		return Math.sin(f * n * 2 * Math.PI + t);
	}, h = (e, t) => .5 * m(e * .13, t) + .3 * m(e * .3, t * 2.3) + .2 * m(e * .59, t * 4.1), g = Er(n, wr.happy), _ = Er(n, wr.laugh), v = Er(n, wr.sad), y = Er(n, wr.angry), b = Er(n, wr.surprised), x = Er(n, wr.worried), S = Er(n, wr.shy), C = !!o.moving, w = Math.min(1, Math.max(0, o.winded ?? 0)), T = f * (2 * Math.PI / (3.9 - 2.3 * w)) + p * 6, E = d > 0 ? m(1 / 3.9, p * 6) : Math.sin(T), D = (.7 + 1.8 * w) * (C ? w * .5 : 1);
	u(c.upperChest, 0, -D * E * .8), u(c.head, 0, D * E * .3);
	let O = 7 * v + 4 * x + 3 * S + 2.5 * y - 2 * g - 3 * b, k = 4 * x + 6 * b + 3 * S + 2 * y - 2 * v + D * .5 * Math.max(0, E) + 1.6 * _ * Math.abs(m(9.5 / (2 * Math.PI), 0)), A = 5 * b + 2 * g - 3 * y, j = C ? .5 : 1;
	u(c.spine, 0, O * .35 * j), u(c.upperChest, 0, O * .35 * j + 1.2 * _ * m(9.5 / (2 * Math.PI), 0)), u(c.neck, 0, (O * .2 - A * .4) * j), u(c.head, 0, (O * .4 - A * .6) * j), u(c.shoulders[0], 2, k * j), u(c.shoulders[1], 2, -k * j);
	let M = C ? .4 : 1;
	if (u(c.head, 1, 1.6 * M * h(.7, p * 10)), u(c.head, 0, 1 * M * h(.6, p * 30 + 1)), u(c.spine, 2, .5 * M * h(.5, p * 50 + 2)), !C && !o.seated) {
		let e = m(1 / 9, p * 30);
		u(c.spine, 2, 1.4 * e), u(c.chest, 2, -.6 * e), u(c.neck, 2, -.6 * e);
	}
	let N = o.talking ? Ar(f, i) : 0;
	if (o.talking && (u(c.head, 0, -(N - .2) * 6), u(c.head, 1, 3 * m(.9 / (2 * Math.PI), p * 7))), c.eyes.length) {
		let e = d > 0 ? d / Math.max(1, Math.round(d / 1.3)) : 1.3, t = Math.floor(f / e), n = (t) => {
			let n = d > 0 ? (t % Math.round(d / e) + Math.round(d / e)) % Math.round(d / e) : t;
			return Or(n, i + 11) < .35 ? [0, 0] : [(Or(n, i + 12) * 2 - 1) * 7.5, (Or(n, i + 13) * 2 - 1) * 4.5];
		}, r = n(t - 1), a = n(t), o = Mr((f - t * e) / .06), s = r[0] + (a[0] - r[0]) * o, l = r[1] + (a[1] - r[1]) * o;
		for (let e of c.eyes) u(e, 1, s * .35), u(e, 0, -l * .35);
	}
	if (o.carry) {
		let { lean: e, bank: t, turning: n } = o.carry;
		u(c.spine, 0, e * .55), u(c.chest, 0, e * .3), u(c.head, 0, -e * .5), u(c.spine, 2, -t * .6), u(c.chest, 2, -t * .4), Math.abs(n) > 25 && u(c.head, 1, Math.min(22, Math.max(-22, n * .12)));
	}
	if (o.swing) for (let e of c.loose) u(e.bone, 0, o.swing.fore * e.fore), u(e.bone, 2, o.swing.side * e.side);
	let P = Tr(t, wr.blink), F = Tr(t, wr.mouth), I = n, L = (e, t) => {
		!e || t <= .004 || (I = {
			...I ?? {},
			[e]: Math.min(1, Math.max(I?.[e] ?? 0, t))
		});
	};
	if (P && (n?.[P] ?? 0) < .5) {
		let e = x + b + S > .3, t = Math.max(jr(f, i, e, d), .15 * v);
		t *= 1 - Math.min(1, Er(n, [
			"joy",
			"happy",
			"laugh",
			"笑い"
		])), L(P, t * Math.min(1, s));
	}
	return L(F, N), w > .35 && L(F, (w - .35) * .45 * (.6 + .4 * Math.sin(T))), {
		pose: l,
		face: I
	};
}
var Pr = class {
	state = /* @__PURE__ */ new Map();
	update(e, t, n, r, i) {
		let a = this.state.get(e), o = (e) => ({
			swing: {
				fore: e.sf,
				side: e.ss
			},
			winded: e.winded,
			carry: {
				lean: e.lean,
				bank: e.bank,
				turning: e.yawV
			}
		});
		if (a && r <= 0) return o(a);
		if (!a || Math.hypot(t[0] - a.at[0], t[2] - a.at[2]) > 1.5) return a = {
			at: t,
			vel: [
				0,
				0,
				0
			],
			fore: 0,
			side: 0,
			sf: 0,
			sfv: 0,
			ss: 0,
			ssv: 0,
			winded: a?.winded ?? 0,
			yaw: n,
			yawV: 0,
			lean: 0,
			bank: 0
		}, this.state.set(e, a), o(a);
		let s = 1 - Math.exp(-r / .08), c = [
			a.vel[0] + ((t[0] - a.at[0]) / r - a.vel[0]) * s,
			0,
			a.vel[2] + ((t[2] - a.at[2]) / r - a.vel[2]) * s
		], l = (c[0] - a.vel[0]) / r, u = (c[2] - a.vel[2]) / r, d = n * Math.PI / 180, f = 1 - Math.exp(-r / .1), p = (e, t, n) => Math.min(n, Math.max(t, e));
		a.fore += (p(l * Math.sin(d) + u * Math.cos(d), -12, 12) - a.fore) * f, a.side += (p(l * Math.cos(d) - u * Math.sin(d), -12, 12) - a.side) * f;
		let m = ((n - a.yaw) % 360 + 540) % 360 - 180;
		a.yawV += (m / r - a.yawV) * f, a.yaw = n, a.vel = c, a.at = t;
		let h = Math.hypot(c[0], c[2]);
		a.winded = p(a.winded + (i || h > 2.6 ? r / 9 : -r / 28), 0, 1);
		let g = p(a.fore * 2.2 + h * 1.6, -5, 14), _ = p(-a.side * 2.2 - a.yawV * .03, -8, 8), v = (e, t, n, i, a) => {
			let o = t + (i * i * (n - e) - 2 * a * i * t) * r;
			return [e + o * r, o];
		};
		[a.sf, a.sfv] = v(a.sf, a.sfv, g, 7, .32), [a.ss, a.ssv] = v(a.ss, a.ssv, _, 6.5, .3);
		let y = 1 - Math.exp(-r / .18);
		return a.lean += (p(h * 2.2, 0, 9) + p(-a.fore * .9, 0, 5) - a.lean) * y, a.bank += (p(a.yawV * h * .012, -9, 9) - a.bank) * y, o(a);
	}
	forget(e) {
		this.state.delete(e);
	}
};
//#endregion
//#region ../scene3d/src/model/springs.ts
function Fr(e) {
	if (!e || typeof e != "object") return;
	let t = e, n = (e, t) => typeof e == "number" && Number.isFinite(e) ? Math.min(t, Math.max(0, e)) : void 0, r = {
		...t.off === !0 ? { off: !0 } : {},
		...n(t.stiffness, 3) === void 0 ? {} : { stiffness: n(t.stiffness, 3) },
		...n(t.gravity, 3) === void 0 ? {} : { gravity: n(t.gravity, 3) },
		...n(t.drag, 1) === void 0 ? {} : { drag: n(t.drag, 1) }
	};
	return Object.keys(r).length ? r : void 0;
}
var Ir = [
	{
		kind: "hair",
		match: /hair|ponytail|bang|fringe|髪/i,
		stiffness: .9,
		drag: .45,
		gravity: .25,
		radius: .012
	},
	{
		kind: "skirt",
		match: /skirt|スカート|裾/i,
		stiffness: 1.6,
		drag: .5,
		gravity: .3,
		radius: .015
	},
	{
		kind: "bust",
		match: /bust|breast|胸[^上]/i,
		stiffness: 5,
		drag: .55,
		gravity: 0,
		radius: .01
	},
	{
		kind: "cloth",
		match: /coat|cape|cloak|ribbon|sleeve|scarf|tie|ネクタイ|リボン|袖|マント/i,
		stiffness: 1.2,
		drag: .5,
		gravity: .3,
		radius: .012
	},
	{
		kind: "tail",
		match: /tail|ear|尻尾|耳/i,
		stiffness: 1.5,
		drag: .4,
		gravity: .1,
		radius: .01
	}
], Lr = {
	kind: "cloth",
	match: /^J_Sec_/,
	stiffness: 1.4,
	drag: .5,
	gravity: .25,
	radius: .012
};
function Rr(e) {
	let t = new Set(mr(e).values()), n = [];
	return e.forEach((e, r) => {
		if (t.has(r)) return;
		let i = Ir.find((t) => t.match.test(e.name)) ?? (Lr.match.test(e.name) ? Lr : null);
		if (!i) return;
		let a = Math.hypot(e.tail[0] - e.head[0], e.tail[1] - e.head[1], e.tail[2] - e.head[2]);
		a < 1e-5 || n.push({
			bone: r,
			length: a,
			stiffness: i.stiffness,
			drag: i.drag,
			gravity: i.gravity,
			radius: i.radius
		});
	}), n;
}
var zr = [
	[
		"head",
		.5,
		.075
	],
	[
		"neck",
		.5,
		.04
	],
	[
		"upperChest",
		.5,
		.075
	],
	[
		"chest",
		.5,
		.08
	],
	[
		"spine",
		.5,
		.075
	],
	[
		"hips",
		0,
		.09
	],
	[
		"leftUpperLeg",
		.15,
		.065
	],
	[
		"rightUpperLeg",
		.15,
		.065
	],
	[
		"leftUpperLeg",
		.6,
		.055
	],
	[
		"rightUpperLeg",
		.6,
		.055
	],
	[
		"leftLowerLeg",
		.1,
		.045
	],
	[
		"rightLowerLeg",
		.1,
		.045
	],
	[
		"leftUpperArm",
		.4,
		.035
	],
	[
		"rightUpperArm",
		.4,
		.035
	]
];
function Br(e) {
	let t = mr(e), n = t.get("head"), r = [
		"leftFoot",
		"rightFoot",
		"leftLowerLeg"
	].flatMap((n) => t.has(n) ? [e[t.get(n)].head[1]] : []), i = n === void 0 ? Math.max(...e.map((e) => e.tail[1])) : e[n].tail[1], a = Math.max(.001, i - (r.length ? Math.min(...r) : 0));
	return zr.flatMap(([n, r, i]) => {
		let o = t.get(n);
		if (o === void 0) return [];
		let { head: s, tail: c } = e[o];
		return [{
			bone: o,
			at: [
				0,
				1,
				2
			].map((e) => s[e] + (c[e] - s[e]) * r),
			radius: i * a
		}];
	});
}
var Vr = 30, Hr = 2, Ur = (e, t) => [
	0,
	1,
	2
].map((n) => e[n * 3] * t[0] + e[n * 3 + 1] * t[1] + e[n * 3 + 2] * t[2]), Wr = (e, t) => Ur(e.r, t).map((t, n) => t + e.t[n]), Gr = [
	1,
	0,
	0,
	0,
	1,
	0,
	0,
	0,
	1
];
function Kr(e, t, n, r = {}) {
	let i = Rr(e);
	if (!i.length || r.off) return null;
	let a = Br(e), o = Math.max(2, Math.min(Vr * 600, Math.round(t * Vr))), s = 1 / Vr / Hr, c = new Float32Array(o * i.length * 3), l = i.map((t) => [...e[t.bone].tail]), u = l.map((e) => [...e]), d = r.gravity ?? 1, f = r.stiffness ?? 1, p = r.drag, m = new Map(i.map((e, t) => [e.bone, t])), h = !0;
	for (let t = 0; t < 2; t++) for (let r = 0; r < o; r++) {
		let g = n(r / o), _ = Yn({
			bones: e,
			pose: g.pose
		}, g.pose, g.root), v = a.map((e) => ({
			at: Wr(_[e.bone], e.at).map((e, t) => e + g.travel[t]),
			radius: e.radius
		}));
		for (let n = 0; n < Hr; n++) {
			let a = [], o = [];
			e.forEach((e, _) => {
				let y = G(g.pose[_] ?? [
					0,
					0,
					0
				]), b = e.parent >= 0 ? a[e.parent] : Gr, x = e.parent >= 0 ? o[e.parent] : [
					0,
					1,
					2
				].map((e) => (g.root?.[e] ?? 0) + g.travel[e]), S = J(b, y), C = Ur(b, e.head).map((e, t) => e + x[t]), w = m.get(_);
				if (w === void 0) {
					a.push(S), o.push(C.map((t, n) => t - Ur(S, e.head)[n]));
					return;
				}
				let T = i[w], E = ir(Ur(S, [
					e.tail[0] - e.head[0],
					e.tail[1] - e.head[1],
					e.tail[2] - e.head[2]
				])), D = l[w];
				h && (D[0] = C[0] + E[0] * T.length, D[1] = C[1] + E[1] * T.length, D[2] = C[2] + E[2] * T.length, u[w] = [...D]);
				let O = 1 - (p ?? T.drag), k = T.gravity * d, A = [
					D[0] + (D[0] - u[w][0]) * O + E[0] * T.stiffness * f * s,
					D[1] + (D[1] - u[w][1]) * O + E[1] * T.stiffness * f * s - k * s,
					D[2] + (D[2] - u[w][2]) * O + E[2] * T.stiffness * f * s
				], j = (e) => {
					let t = ir([
						e[0] - C[0],
						e[1] - C[1],
						e[2] - C[2]
					]);
					return [
						C[0] + t[0] * T.length,
						C[1] + t[1] * T.length,
						C[2] + t[2] * T.length
					];
				};
				A = j(A);
				for (let e of v) {
					let t = [
						A[0] - e.at[0],
						A[1] - e.at[1],
						A[2] - e.at[2]
					], n = Math.hypot(...t), r = e.radius + T.radius;
					n < r && n > 1e-6 && (A = j([
						e.at[0] + t[0] / n * r,
						e.at[1] + t[1] / n * r,
						e.at[2] + t[2] / n * r
					]));
				}
				u[w] = D.slice(), l[w] = A;
				let M = J(rr(E, ir([
					A[0] - C[0],
					A[1] - C[1],
					A[2] - C[2]
				])), S);
				if (a.push(M), o.push(C.map((t, n) => t - Ur(M, e.head)[n])), t === 1 && n === 1) {
					let e = nr(J(qn(b), M));
					c.set(e, (r * i.length + w) * 3);
				}
			}), h = !1;
		}
	}
	return {
		bones: i.map((e) => e.bone),
		turns: c,
		frames: o
	};
}
var qr = (e, t, n) => e + (((t - e + 180) % 360 + 360) % 360 - 180) * n;
function Jr(e, t, n) {
	let r = e.slice(), i = (n % 1 + 1) % 1 * t.frames, a = Math.floor(i) % t.frames, o = (a + 1) % t.frames, s = i - Math.floor(i), c = t.bones.length;
	return t.bones.forEach((e, n) => {
		r[e] = [
			0,
			1,
			2
		].map((e) => qr(t.turns[(a * c + n) * 3 + e], t.turns[(o * c + n) * 3 + e], s));
	}), r;
}
var Yr = /* @__PURE__ */ new WeakMap();
function Xr(e, t, n) {
	if (!t.rig || t.springs?.off) return null;
	let r = e.clip ?? 4, i = Yr.get(t);
	if (i && i.clip === r) return i.baked;
	let a = t.asset ? e.assets?.[t.asset] : void 0, o = a ? t.size.map((e, t) => e / Math.max(1e-9, a.size[t])) : [
		1,
		1,
		1
	], s = t.keys?.[0]?.position ?? t.position, c = t.rig, l = Kr(c.bones, r, (e) => {
		let t = n(e);
		return {
			pose: t.rig?.pose ?? c.pose,
			root: t.rig?.root,
			travel: t.position.map((e, t) => (e - s[t]) / (o[t] || 1))
		};
	}, t.springs);
	return Yr.set(t, {
		clip: r,
		baked: l
	}), l;
}
function Zr(e) {
	let t = Rr(e);
	if (!t.length) return null;
	let n = Br(e).map((t) => ({
		node: t.bone + 1,
		shape: { sphere: {
			offset: t.at.map((n, r) => n - e[t.bone].head[r]),
			radius: t.radius
		} }
	})), r = new Map(t.map((e) => [e.bone, e])), i = t.filter((t) => !r.has(e[t.bone].parent)).map((n) => {
		let r = [n.bone];
		for (;;) {
			let n = t.find((t) => e[t.bone].parent === r[r.length - 1]);
			if (!n) break;
			r.push(n.bone);
		}
		return r;
	}).filter((e) => e.length > 1);
	return i.length ? {
		specVersion: "1.0",
		colliders: n,
		colliderGroups: [{
			name: "Body",
			colliders: n.map((e, t) => t)
		}],
		springs: i.map((e, t) => ({
			name: `Spring ${t + 1}`,
			colliderGroups: [0],
			joints: e.map((e) => {
				let t = r.get(e);
				return {
					node: e + 1,
					hitRadius: t.radius,
					stiffness: t.stiffness,
					gravityPower: t.gravity,
					gravityDir: [
						0,
						-1,
						0
					],
					dragForce: t.drag
				};
			})
		}))
	} : null;
}
//#endregion
//#region ../scene3d/src/model/music.ts
var Qr = 4e7;
function $r(e) {
	let t = e;
	if (!(!t || typeof t.data != "string" || !/^data:audio\/[\w.+-]+;base64,/.test(t.data.slice(0, 60)) || t.data.length > 4e7)) return {
		name: typeof t.name == "string" ? t.name.slice(0, 80) : "Music",
		data: t.data,
		...typeof t.from == "number" && Number.isFinite(t.from) && t.from > 0 ? { from: Math.min(3600, t.from) } : {}
	};
}
function ei(e, t) {
	let n = new Float32Array(t), r = e.length / t, i = 1e-6;
	for (let a = 0; a < t; a++) {
		let t = Math.floor(a * r), o = Math.min(e.length, Math.floor((a + 1) * r)), s = 0, c = Math.max(1, Math.floor((o - t) / 256)), l = 0;
		for (let n = t; n < o; n += c, l++) s += e[n] * e[n];
		n[a] = Math.sqrt(s / Math.max(1, l)), i = Math.max(i, n[a]);
	}
	for (let e = 0; e < t; e++) n[e] /= i;
	return n;
}
function ti(e, t) {
	let n = Math.floor(t / 100), r = Math.floor(e.length / n);
	if (r < 400) return null;
	let i = new Float32Array(r);
	for (let t = 0; t < r; t++) {
		let r = 0;
		for (let i = 0; i < n; i += 4) r += e[t * n + i] * e[t * n + i];
		i[t] = Math.log1p(r * 1e3);
	}
	let a = new Float32Array(r);
	for (let e = 1; e < r; e++) a[e] = Math.max(0, i[e] - i[e - 1]);
	let o = 0, s = 0, c = a.reduce((e, t) => e + t, 0) / r, l = (e) => {
		let t = 0;
		for (let n = 0; n + e < r; n++) t += (a[n] - c) * (a[n + e] - c);
		return t / Math.max(1, r - e);
	}, u = l(0);
	for (let e = 33; e <= 100; e++) {
		let t = 6e3 / e, n = Math.exp(-.5 * Math.log2(t / 120) ** 2), r = l(e) * n;
		r > o && (o = r, s = e);
	}
	if (!s || o < u * .08) return null;
	let d = 0, f = -1;
	for (let e = 0; e < s; e++) {
		let t = 0;
		for (let n = e; n < r; n += s) t += a[n];
		t > f && (f = t, d = e);
	}
	return {
		bpm: Math.round(6e3 / s * 10) / 10,
		first: d / 100
	};
}
//#endregion
//#region ../scene3d/src/model/take.ts
var ni = 50, ri = 24e6, ii = 6e7;
function ai(e, t, n, i, a) {
	let o = new Int16Array(i.length * t.length * 3), s = new Float32Array(i.length * 3);
	return i.forEach((e, n) => {
		e.turns.forEach((e, r) => {
			for (let i = 0; i < 3; i++) o[(n * t.length + r) * 3 + i] = Math.round(Math.max(-650, Math.min(650, e[i])) * ni);
		}), s.set(e.root, n * 3);
	}), {
		name: e.slice(0, 80) || "Take",
		seconds: i.length > 1 ? (i.length - 1) / n : 0,
		fps: n,
		bones: t.map((e) => e.slice(0, 40)),
		turns: r(new Uint8Array(o.buffer)),
		root: r(new Uint8Array(s.buffer)),
		...a?.names.length ? { faces: {
			names: a.names.map((e) => e.slice(0, 40)),
			amounts: r(Uint8Array.from(a.amounts.flatMap((e) => e.map((e) => Math.round(Math.max(0, Math.min(1, e)) * 255)))))
		} } : {}
	};
}
var oi = /* @__PURE__ */ new WeakMap();
function si(e, t) {
	let n = e.faces;
	if (!n) return;
	let r = oi.get(e);
	r || oi.set(e, r = s(n.amounts));
	let i = n.names.length, a = Math.floor(r.length / i), o = e.seconds > 0 ? e.seconds : 1, c = Math.min(a - 1, Math.floor((t % o + o) % o * e.fps)), l = {};
	return n.names.forEach((e, t) => {
		let n = r[c * i + t] / 255;
		n > .004 && (l[e] = Math.max(l[e] ?? 0, n));
	}), l;
}
function ci(e, t) {
	let n = s(e.data), r = new Float32Array(n.buffer.slice(n.byteOffset, n.byteOffset + n.byteLength)), i = r.length / 7, a = Math.max(0, Math.min(i - 1, Math.round(t * e.fps)));
	return {
		yaw: r[a * 7],
		pitch: r[a * 7 + 1],
		distance: r[a * 7 + 2],
		target: [
			r[a * 7 + 3],
			r[a * 7 + 4],
			r[a * 7 + 5]
		],
		fov: r[a * 7 + 6]
	};
}
var li = /* @__PURE__ */ new WeakMap();
function ui(e) {
	let t = li.get(e);
	if (!t) {
		let n = (e) => {
			let t = s(e);
			return t.buffer.slice(t.byteOffset, t.byteOffset + t.byteLength);
		}, r = new Int16Array(n(e.turns)), i = new Float32Array(n(e.root));
		t = {
			turns: r,
			root: i,
			frames: Math.min(i.length / 3, e.bones.length ? r.length / (e.bones.length * 3) : 0)
		}, li.set(e, t);
	}
	return t;
}
var di = (e) => ui(e).frames, fi = (e, t, n) => e + (((t - e + 180) % 360 + 360) % 360 - 180) * n;
function pi(e, t, n, r = !1) {
	let { turns: i, root: a, frames: o } = ui(e), s = e.bones.length, c = t.bones.map(() => [
		0,
		0,
		0
	]);
	if (!o) return {
		pose: c,
		root: [
			0,
			0,
			0
		]
	};
	let l = e.seconds > 0 ? e.seconds : 1, u = (n % l + l) % l * e.fps, d = Math.min(o - 1, Math.floor(u)), f = Math.min(o - 1, d + 1), p = u - d;
	hi(e, t).forEach((e, t) => {
		if (e < 0) return;
		let n = c[e];
		for (let e = 0; e < 3; e++) n[e] = fi(i[(d * s + t) * 3 + e] / ni, i[(f * s + t) * 3 + e] / ni, p);
	});
	let m = [
		0,
		1,
		2
	].map((e) => a[d * 3 + e] * (1 - p) + a[f * 3 + e] * p);
	return {
		pose: c,
		root: r ? [
			0,
			m[1],
			0
		] : m
	};
}
var mi = /* @__PURE__ */ new WeakMap();
function hi(e, t) {
	let n = mi.get(e);
	if (n?.bones === t.bones) return n.places;
	let r = new Map(t.bones.map((e, t) => [e.name, t])), i = e.bones.map((e) => r.get(e) ?? -1);
	return mi.set(e, {
		bones: t.bones,
		places: i
	}), i;
}
function gi(e, t, n) {
	let { turns: r, root: i } = ui(e), a = e.bones.length, o = t.bones.map(() => [
		0,
		0,
		0
	]);
	return hi(e, t).forEach((e, t) => {
		e >= 0 && (o[e] = [
			0,
			1,
			2
		].map((e) => r[(n * a + t) * 3 + e] / ni));
	}), {
		pose: o,
		root: [
			i[n * 3],
			i[n * 3 + 1],
			i[n * 3 + 2]
		]
	};
}
var _i = (e, t, n, r, i) => pi(e, t, r * i * (n.speed ?? 1), n.inPlace), vi = (e) => {
	let t = e;
	return !t || !Array.isArray(t.names) || typeof t.amounts != "string" || t.amounts.length > 24e6 ? {} : { faces: {
		names: t.names.filter((e) => typeof e == "string").slice(0, 200),
		amounts: t.amounts
	} };
};
function yi(e) {
	let t = e;
	if (!(!t || typeof t.data != "string" || !t.data || t.data.length > 24e6 || !/^[A-Za-z0-9+/]*={0,2}$/.test(t.data.slice(0, 4e3)))) return {
		fps: typeof t.fps == "number" && t.fps > 0 && t.fps <= 120 ? t.fps : 30,
		data: t.data
	};
}
function bi(e) {
	if (!e || typeof e != "object") return;
	let t = {}, n = 0;
	for (let [r, i] of Object.entries(e)) {
		let e = i ?? {};
		if (!/^[\w-]{1,40}$/.test(r) || typeof e.turns != "string" || typeof e.root != "string" || !Array.isArray(e.bones)) continue;
		let a = e.turns.length + e.root.length;
		if (a > 24e6 || n + a > ii || !/^[A-Za-z0-9+/]*={0,2}$/.test(e.root)) continue;
		let o = (e, t, n, r) => typeof e == "number" && Number.isFinite(e) ? Math.min(n, Math.max(t, e)) : r;
		n += a, t[r] = {
			name: typeof e.name == "string" ? e.name.slice(0, 80) : "Take",
			seconds: o(e.seconds, 0, 3600, 0),
			fps: o(e.fps, 1, 120, 30),
			bones: e.bones.filter((e) => typeof e == "string").slice(0, 256),
			turns: e.turns,
			root: e.root,
			...vi(e.faces)
		};
	}
	return Object.keys(t).length ? t : void 0;
}
function xi(e) {
	let t = e;
	if (t && typeof t.id == "string" && /^[\w-]{1,40}$/.test(t.id)) return {
		id: t.id,
		...typeof t.speed == "number" && Number.isFinite(t.speed) ? { speed: Math.min(4, Math.max(.1, t.speed)) } : {},
		...t.inPlace === !0 ? { inPlace: !0 } : {}
	};
}
var Si = [
	1,
	0,
	0,
	0,
	1,
	0,
	0,
	0,
	1
], Ci = [
	-1,
	0,
	0,
	0,
	1,
	0,
	0,
	0,
	-1
], wi = (e, t) => [
	0,
	1,
	2
].map((n) => e[n * 3] * t[0] + e[n * 3 + 1] * t[1] + e[n * 3 + 2] * t[2]), Ti = (e, t) => {
	let n = t.get("hips");
	if (n === void 0) return 1;
	let r = [
		"leftFoot",
		"rightFoot",
		"leftLowerLeg",
		"rightLowerLeg"
	].flatMap((n) => t.has(n) ? [e[t.get(n)].head[1]] : []);
	return r.length ? Math.max(1e-6, e[n].head[1] - Math.min(...r)) : 1;
}, Ei = (e) => hr(mr(e));
function Di(e, t) {
	let n = mr(e), r = mr(t);
	if (!hr(n) || !hr(r)) return null;
	let i = _r(e, n) ? Ci : Si, a = _r(t, r) ? Ci : Si, o = new Map([...r].map(([e, t]) => [t, e])), s = t.map((e, t) => {
		let r = o.get(t);
		return r && n.has(r) ? n.get(r) : -1;
	}), c = (e, t, n, r) => {
		let i = t.get(n);
		if (i === void 0) return null;
		let a = gr[n] === void 0 ? void 0 : t.get(gr[n]), o = (a === void 0 ? e[i].tail : e[a].head).map((t, n) => t - e[i].head[n]);
		return Math.hypot(...o) < 1e-7 ? null : ir(wi(r, o));
	};
	return {
		source: s,
		correct: t.map((s, l) => {
			let u = o.get(l);
			if (!u || !gr[u] || !n.has(u)) return Si;
			let d = c(t, r, u, a), f = c(e, n, u, i);
			return d && f ? rr(d, f) : Si;
		}),
		from: i,
		to: a,
		hips: [n.get("hips"), r.get("hips")],
		scale: Ti(t, r) / Ti(e, n),
		sourceBones: [...e],
		targetBones: [...t],
		missing: [...r.keys()].filter((e) => !n.has(e))
	};
}
function Oi(e, t, n) {
	let r = Yn({
		bones: e.sourceBones,
		pose: [...t]
	}, t, n), i = [], a = e.targetBones.map((t, n) => {
		let a = t.parent >= 0 ? i[t.parent] : Si, o = e.source[n];
		if (o < 0) return i.push(a), [
			0,
			0,
			0
		];
		let s = J(J(e.from, r[o].r), qn(e.from)), c = J(J(qn(e.to), J(s, e.correct[n])), e.to);
		return i.push(c), nr(J(qn(a), c));
	}), o = e.sourceBones[e.hips[0]].head, s = r[e.hips[0]], c = wi(s.r, o).map((e, t) => e + s.t[t] - o[t]);
	return {
		turns: a,
		root: wi(qn(e.to), wi(e.from, c)).map((t) => t * e.scale)
	};
}
function ki(e, t, n) {
	let r = Di(t, n);
	if (!r) return null;
	let i = [], a = di(e), o = { bones: [...t] };
	for (let t = 0; t < a; t++) {
		let { pose: n, root: a } = gi(e, o, t);
		i.push(Oi(r, n, a));
	}
	let s = n.flatMap((e, t) => i.some((e) => e.turns[t].some((e) => Math.abs(e) > .01)) ? [t] : []), c = ai(e.name, s.map((e) => n[e].name), e.fps, i.map((e) => ({
		turns: s.map((t) => e.turns[t]),
		root: e.root
	})));
	return {
		take: e.faces ? {
			...c,
			faces: e.faces
		} : c,
		missing: r.missing
	};
}
//#endregion
//#region ../scene3d/src/model/triggers.ts
var Ai = {
	spin: "Spin once",
	bounce: "Hop",
	wiggle: "Wiggle",
	pulse: "Pulse",
	sway: "Sway"
}, ji = Object.keys(Ai), Mi = .8;
function Ni(e) {
	if (!e || typeof e != "object") return;
	let t = e, n = (e) => ji.includes(e) ? e : void 0, r = n(t.click), i = n(t.hover);
	if (!r && !i) return;
	let a = typeof t.seconds == "number" && Number.isFinite(t.seconds) ? Math.min(3, Math.max(.3, t.seconds)) : Mi;
	return {
		...r ? { click: r } : {},
		...i ? { hover: i } : {},
		seconds: a
	};
}
function Pi(e, t, n) {
	if (!t) return null;
	let r = e.shapes[t[0]], i = t.length === 2 ? r?.children?.[t[1]] : r;
	for (let e of t.length === 2 ? [i, r] : [i]) {
		let t = e?.triggers?.[n];
		if (e && t) return {
			id: e.id,
			reaction: t,
			seconds: e.triggers.seconds
		};
	}
	return null;
}
//#endregion
//#region ../scene3d/src/model/game.ts
var Fi = [
	"start",
	"use",
	"look",
	"enter",
	"leave",
	"flag",
	"time"
], Ii = {
	start: "The level starts",
	use: "The player uses",
	look: "The player looks at",
	enter: "The player walks into",
	leave: "The player walks out of",
	flag: "A flag is set",
	time: "Seconds after the start"
}, Li = [
	"use",
	"look",
	"enter",
	"leave"
], Ri = [
	"say",
	"ask",
	"set",
	"clear",
	"add",
	"give",
	"take",
	"show",
	"hide",
	"move",
	"walk",
	"react",
	"camera",
	"title",
	"sound",
	"music",
	"wait",
	"tension",
	"achieve",
	"level",
	"end"
], zi = {
	say: "Say lines",
	ask: "Ask (choices)",
	set: "Set a flag",
	clear: "Clear a flag",
	add: "Add to a number",
	give: "Give an item",
	take: "Take an item",
	show: "Show a shape",
	hide: "Hide a shape",
	move: "Move a shape (a door)",
	walk: "Walk a character to",
	react: "Play a reaction",
	camera: "Camera shot",
	title: "Show a title",
	sound: "Play a sound",
	music: "Play music",
	wait: "Wait",
	tension: "Change the tension",
	achieve: "Earn an achievement",
	level: "Go to a level",
	end: "End the game"
}, Bi = [
	">=",
	"<=",
	"=",
	"!=",
	">",
	"<"
];
function Vi(e, t, n) {
	if (!e) return "idle";
	let r = n * 7.31 % 1 * e.every, i = .93 + n * 3.17 % 1 * .14, a = ((t * i + r) % e.every + e.every) % e.every;
	return e.moves.length && a > e.every - e.for ? e.moves[Math.floor((t * i + r) / e.every) % e.moves.length] : e.talk && (t * i + n % 2 * 5) % 10 < 6 ? "talk" : "idle";
}
var Hi = [
	"talk",
	"use",
	"go"
], Ui = {
	talk: "Talk to",
	use: "Use",
	go: "Walk into"
}, Y = (e) => typeof e == "string" && /^[\w-]{1,40}$/.test(e) ? e : void 0, Wi = (e) => typeof e == "string" && e.trim() ? e.trim().replace(/\s+/g, " ").slice(0, 40) : void 0, X = (e, t, n, r) => typeof e == "number" && Number.isFinite(e) ? Math.min(n, Math.max(t, e)) : r, Z = (e, t) => typeof e == "string" ? e.slice(0, t) : "", Gi = (e) => Array.isArray(e) ? [...new Set(e.map(Wi).filter((e) => !!e))].slice(0, 8) : void 0, Ki = (e) => Array.isArray(e) ? [...new Set(e.map(Y).filter((e) => !!e))].slice(0, 64) : void 0, qi = (e, t, n, r) => Array.isArray(e) && e.length === 3 ? [
	X(e[0], t, n, r[0]),
	X(e[1], t, n, r[1]),
	X(e[2], t, n, r[2])
] : r;
function Ji(e) {
	if (!e || typeof e != "object") return null;
	let t = e;
	switch (t.kind) {
		case "say": {
			let e = Array.isArray(t.lines) ? t.lines.map((e) => Z(e, 400).trim()).filter(Boolean).slice(0, 12) : [], n = Y(t.voice);
			return e.length ? {
				kind: "say",
				lines: e,
				...n ? { voice: n } : {}
			} : null;
		}
		case "ask": {
			let e = (Array.isArray(t.options) ? t.options : []).slice(0, 4).map((e) => {
				let t = e && typeof e == "object" ? e : {};
				return {
					text: Z(t.text, 120).trim(),
					flag: Wi(t.flag) ?? ""
				};
			}).filter((e) => e.text && e.flag);
			return e.length ? {
				kind: "ask",
				options: e
			} : null;
		}
		case "set":
		case "clear": {
			let e = Wi(t.flag);
			return e ? {
				kind: t.kind,
				flag: e
			} : null;
		}
		case "add": {
			let e = Wi(t.variable);
			return e ? {
				kind: "add",
				variable: e,
				by: X(t.by, -1e6, 1e6, 1)
			} : null;
		}
		case "give":
		case "take": {
			let e = Wi(t.item);
			return e ? {
				kind: t.kind,
				item: e
			} : null;
		}
		case "show":
		case "hide": {
			let e = Y(t.shape);
			return e ? {
				kind: t.kind,
				shape: e
			} : null;
		}
		case "move": {
			let e = Y(t.shape);
			return e ? {
				kind: "move",
				shape: e,
				by: qi(t.by, -100, 100, [
					0,
					0,
					0
				]),
				seconds: X(t.seconds, 0, 60, 1)
			} : null;
		}
		case "walk": {
			let e = Y(t.shape);
			return e ? {
				kind: "walk",
				shape: e,
				to: qi(t.to, -100, 100, [
					0,
					0,
					0
				]),
				seconds: X(t.seconds, .1, 120, 3)
			} : null;
		}
		case "react": {
			let e = Y(t.shape), n = ji.includes(t.reaction) ? t.reaction : "bounce";
			return e ? {
				kind: "react",
				shape: e,
				reaction: n
			} : null;
		}
		case "camera": return {
			kind: "camera",
			position: qi(t.position, -100, 100, [
				0,
				1.6,
				3
			]),
			target: qi(t.target, -100, 100, [
				0,
				1,
				0
			]),
			seconds: X(t.seconds, .2, 60, 3),
			...Y(t.shot) ? { shot: Y(t.shot) } : {},
			...Y(t.film) ? { film: Y(t.film) } : {}
		};
		case "title": {
			let e = Z(t.text, 120).trim();
			return e ? {
				kind: "title",
				text: e,
				seconds: X(t.seconds, .5, 30, 3)
			} : null;
		}
		case "sound":
		case "music": {
			let e = Y(t.sound) ?? "";
			return e || t.kind === "music" ? {
				kind: t.kind,
				sound: e,
				volume: X(t.volume, 0, 1, 1)
			} : null;
		}
		case "wait": return {
			kind: "wait",
			seconds: X(t.seconds, 0, 120, 1)
		};
		case "tension": return {
			kind: "tension",
			by: X(t.by, -1, 1, .1)
		};
		case "achieve": {
			let e = Y(t.achievement);
			return e ? {
				kind: "achieve",
				achievement: e
			} : null;
		}
		case "level": {
			let e = Z(t.level, 80).trim();
			return e ? {
				kind: "level",
				level: e
			} : null;
		}
		case "end": return {
			kind: "end",
			text: Z(t.text, 400).trim()
		};
	}
	return null;
}
function Yi(e) {
	if (!Array.isArray(e)) return;
	let t = e.slice(0, 8).flatMap((e) => {
		let t = e && typeof e == "object" ? e : {}, n = Wi(t.variable);
		return n ? [{
			variable: n,
			op: Bi.includes(t.op) ? t.op : ">=",
			value: X(t.value, -1e6, 1e6, 1)
		}] : [];
	});
	return t.length ? t : void 0;
}
function Xi(e) {
	if (!Array.isArray(e)) return;
	let t = e.slice(0, 48).flatMap((e) => {
		let t = e && typeof e == "object" ? e : {}, n = Y(t.spot);
		if (!n) return [];
		let r = X(t.days, 0, 31, 31);
		return [{
			from: X(t.from, 0, 1440, 480),
			to: X(t.to, 0, 1440, 540),
			spot: n,
			...r === 31 ? {} : { days: r }
		}];
	});
	return t.length ? t : void 0;
}
function Zi(e) {
	if (!Array.isArray(e)) return;
	let t = e.slice(0, 64).flatMap((e) => {
		let t = e && typeof e == "object" ? e : {}, n = Y(t.id);
		return n ? [{
			id: n,
			name: Z(t.name, 60) || "Shot",
			position: qi(t.position, -500, 500, [
				0,
				1.6,
				3
			]),
			target: qi(t.target, -500, 500, [
				0,
				1,
				0
			])
		}] : [];
	});
	return t.length ? t : void 0;
}
function Qi(e, t) {
	if (!Array.isArray(e) || !t?.length) return;
	let n = new Set(t.map((e) => e.id)), r = e.slice(0, 32).flatMap((e) => {
		let t = e && typeof e == "object" ? e : {}, r = Y(t.id), i = (Array.isArray(t.steps) ? t.steps : []).slice(0, 32).flatMap((e) => {
			let t = e && typeof e == "object" ? e : {}, r = Y(t.shot);
			return r && n.has(r) ? [{
				shot: r,
				seconds: X(t.seconds, 0, 60, 2),
				...t.cut === !0 ? { cut: !0 } : {}
			}] : [];
		});
		return r && i.length ? [{
			id: r,
			name: Z(t.name, 60) || "Film",
			steps: i
		}] : [];
	});
	return r.length ? r : void 0;
}
function $i(e) {
	if (!Array.isArray(e)) return;
	let t = (e, t) => Array.isArray(e) ? e.slice(0, 32).map((e) => Z(e, t)) : [], n = e.slice(0, 200).flatMap((e) => {
		let n = e && typeof e == "object" ? e : {}, r = Y(n.id);
		if (!r) return [];
		let i = (Array.isArray(n.steps) ? n.steps : []).slice(0, 32).flatMap((e) => {
			let n = e && typeof e == "object" ? e : {}, r = Y(n.shape);
			if (!r || !Hi.includes(n.kind)) return [];
			let i = t(n.ja, 400), a = t(n.voices, 40), o = Wi(n.gives);
			return [{
				kind: n.kind,
				shape: r,
				hint: Z(n.hint, 200),
				lines: t(n.lines, 400),
				...i.length ? { ja: i } : {},
				...a.some(Boolean) ? { voices: a } : {},
				...o ? { gives: o } : {}
			}];
		});
		return [{
			id: r,
			title: Z(n.title, 80) || "Quest",
			steps: i
		}];
	});
	return n.length ? n : void 0;
}
function ea(e) {
	if (!e || typeof e != "object") return;
	let t = e, n = Array.isArray(t.moves) ? [...new Set(t.moves.map(Y).filter((e) => !!e))].slice(0, 8) : [];
	if (!n.length && t.talk !== !0) return;
	let r = X(t.every, 4, 120, 30);
	return {
		moves: n,
		every: r,
		for: X(t.for, 1, r - 1, Math.min(8, r / 3)),
		...t.talk === !0 ? { talk: !0 } : {}
	};
}
function ta(e) {
	if (!Array.isArray(e)) return;
	let t = e.slice(0, 16).flatMap((e) => {
		let t = e && typeof e == "object" ? e : {}, n = Y(t.shape), r = Y(t.character);
		return !n || !r ? [] : [{
			shape: n,
			character: r,
			...t.faces === !0 ? { faces: !0 } : {},
			...t.creeps === !0 ? { creeps: !0 } : {},
			...t.follows === !0 ? { follows: !0 } : {},
			...t.wanders === !0 ? { wanders: !0 } : {},
			...X(t.melt, 0, 1, 0) ? { melt: X(t.melt, 0, 1, 0) } : {},
			...Xi(t.routine) ? { routine: Xi(t.routine) } : {},
			...ea(t.idle) ? { idle: ea(t.idle) } : {}
		}];
	});
	return t.length ? t : void 0;
}
function na(e) {
	if (!e || typeof e != "object") return;
	let t = e, n = t.player && typeof t.player == "object" ? t.player : {}, r = {
		position: qi(n.position, -100, 100, [
			0,
			0,
			3
		]),
		yaw: X(n.yaw, -360, 360, 180),
		eye: X(n.eye, .1, 10, 1.55),
		speed: X(n.speed, .2, 20, 2),
		...X(n.jump, 0, 40, 0) ? { jump: X(n.jump, 0, 40, 0) } : {},
		...n.third === !0 ? { third: !0 } : {},
		...Y(n.shape) ? { shape: Y(n.shape) } : {}
	}, i = (Array.isArray(t.rules) ? t.rules : []).slice(0, 96).flatMap((e, t) => {
		if (!e || typeof e != "object") return [];
		let n = e;
		if (!Fi.includes(n.on)) return [];
		let r = n.on, i = Y(n.shape);
		if (Li.includes(r) && !i) return [];
		let a = Wi(n.flag);
		if (r === "flag" && !a) return [];
		let o = (Array.isArray(n.actions) ? n.actions : []).slice(0, 16).map(Ji).filter((e) => !!e), s = Gi(n.if), c = Gi(n.unless), l = Gi(n.has), u = Ki(n.also), d = Yi(n.need);
		return [{
			id: Y(n.id) ?? `rule${t + 1}`,
			on: r,
			...Li.includes(r) ? {
				shape: i,
				...u?.length ? { also: u } : {}
			} : {},
			...r === "flag" ? { flag: a } : {},
			...r === "time" ? { seconds: X(n.seconds, 0, 3600, 5) } : {},
			...s?.length ? { if: s } : {},
			...c?.length ? { unless: c } : {},
			...d ? { need: d } : {},
			...l?.length ? { has: l } : {},
			...n.once === !0 ? { once: !0 } : {},
			actions: o
		}];
	}), a = Ki(t.areas), o = Ki(t.passable), s = ta(t.actors), c = Zi(t.shots), l = Qi(t.films, c), u = $i(t.quests), d = t.clock && typeof t.clock == "object" ? t.clock : null, f = X(t.tension, 0, 1, 0), p = Gi(t.hud);
	return {
		player: r,
		...p?.length ? { hud: p } : {},
		...a?.length ? { areas: a } : {},
		...o?.length ? { passable: o } : {},
		...s ? { actors: s } : {},
		...c ? { shots: c } : {},
		...l ? { films: l } : {},
		...u ? { quests: u } : {},
		...d ? { clock: {
			start: X(d.start, 0, 1440, 480),
			minutesPerSecond: X(d.minutesPerSecond, .01, 60, 4 / 3),
			...d.daylight === !0 ? { daylight: !0 } : {}
		} } : {},
		...f ? { tension: f } : {},
		rules: i
	};
}
function ra(e) {
	let t = e.camera, n = t.yaw * Math.PI / 180, r = t.pitch * Math.PI / 180, i = [
		t.target[0] + Math.sin(n) * Math.cos(r) * t.distance,
		0,
		t.target[2] + Math.cos(n) * Math.cos(r) * t.distance
	], a = (e) => Math.round(e * 100) / 100;
	return {
		player: {
			position: [
				a(i[0]),
				0,
				a(i[2])
			],
			yaw: a((t.yaw + 360) % 360 - 180),
			eye: 1.55,
			speed: 2
		},
		rules: []
	};
}
//#endregion
//#region ../scene3d/src/model/nodes.ts
var Q = (e, t, n, r, i, a) => ({
	key: e,
	label: t,
	kind: "number",
	min: n,
	max: r,
	step: i,
	default: a
}), ia = {
	grid: {
		label: "Grid",
		inputs: [],
		output: "places",
		params: [
			Q("across", "Across", 1, 20, 1, 3),
			Q("deep", "Deep", 1, 20, 1, 3),
			Q("gap", "Gap", .1, 5, .05, 1.2)
		]
	},
	line: {
		label: "Line",
		inputs: [],
		output: "places",
		params: [
			Q("count", "Count", 1, 50, 1, 5),
			Q("length", "Length", .1, 20, .1, 5),
			{
				key: "axis",
				label: "Along",
				kind: "axis",
				default: "x"
			}
		]
	},
	ring: {
		label: "Ring",
		inputs: [],
		output: "places",
		params: [
			Q("count", "Count", 2, 60, 1, 8),
			Q("radius", "Radius", .1, 20, .1, 2),
			Q("face", "Face out", 0, 1, 1, 1)
		]
	},
	scatter: {
		label: "Scatter",
		inputs: [],
		output: "places",
		params: [
			Q("count", "Count", 1, 200, 1, 20),
			Q("width", "Width", .2, 30, .1, 6),
			Q("depth", "Depth", .2, 30, .1, 6),
			Q("seed", "Seed", 0, 999, 1, 1)
		]
	},
	join: {
		label: "Join",
		inputs: [{
			key: "a",
			label: "Places",
			type: "places"
		}, {
			key: "b",
			label: "Places",
			type: "places"
		}],
		output: "places",
		params: []
	},
	shake: {
		label: "Shake up",
		inputs: [{
			key: "in",
			label: "Places",
			type: "places"
		}],
		output: "places",
		params: [
			Q("move", "Move", 0, 5, .05, .2),
			Q("turn", "Turn", 0, 180, 1, 30),
			Q("grow", "Size", 0, 1, .05, .3),
			Q("seed", "Seed", 0, 999, 1, 2)
		]
	},
	lift: {
		label: "Move",
		inputs: [{
			key: "in",
			label: "Places",
			type: "places"
		}],
		output: "places",
		params: [
			Q("x", "Across", -20, 20, .1, 0),
			Q("y", "Up", -20, 20, .1, 0),
			Q("z", "Forward", -20, 20, .1, 0),
			Q("scale", "Size", .1, 5, .05, 1)
		]
	},
	output: {
		label: "Copies of",
		inputs: [{
			key: "in",
			label: "Places",
			type: "places"
		}],
		output: null,
		params: [{
			key: "shape",
			label: "Shape",
			kind: "shape",
			default: ""
		}]
	}
}, aa = {
	gradient: {
		label: "Gradient",
		inputs: [],
		output: "value",
		params: [{
			key: "axis",
			label: "Along",
			kind: "axis",
			default: "y"
		}]
	},
	noise: {
		label: "Noise",
		inputs: [],
		output: "value",
		params: [
			Q("scale", "Scale", .5, 40, .5, 6),
			Q("detail", "Detail", 1, 5, 1, 3),
			Q("seed", "Seed", 0, 999, 1, 0)
		]
	},
	checker: {
		label: "Checks",
		inputs: [],
		output: "value",
		params: [Q("scale", "Scale", 1, 40, 1, 8)]
	},
	waves: {
		label: "Waves",
		inputs: [],
		output: "value",
		params: [Q("scale", "Scale", 1, 60, 1, 12), {
			key: "axis",
			label: "Along",
			kind: "axis",
			default: "y"
		}]
	},
	up: {
		label: "Facing up",
		inputs: [],
		output: "value",
		params: []
	},
	ramp: {
		label: "Colour ramp",
		inputs: [{
			key: "in",
			label: "Value",
			type: "value"
		}],
		output: "colour",
		params: [
			{
				key: "a",
				label: "From",
				kind: "colour",
				default: "#1d2b53"
			},
			{
				key: "b",
				label: "To",
				kind: "colour",
				default: "#ffcc66"
			},
			Q("low", "Starts", 0, 1, .01, 0),
			Q("high", "Ends", 0, 1, .01, 1)
		]
	},
	mix: {
		label: "Mix",
		inputs: [
			{
				key: "a",
				label: "Colour",
				type: "colour"
			},
			{
				key: "b",
				label: "Colour",
				type: "colour"
			},
			{
				key: "f",
				label: "Amount",
				type: "value"
			}
		],
		output: "colour",
		params: [Q("f", "Amount", 0, 1, .01, .5)]
	},
	colour: {
		label: "Colour",
		inputs: [],
		output: "colour",
		params: [{
			key: "c",
			label: "Colour",
			kind: "colour",
			default: "#c0392b"
		}]
	},
	output: {
		label: "Material",
		inputs: [{
			key: "in",
			label: "Colour",
			type: "colour"
		}],
		output: null,
		params: []
	}
}, oa = (e) => e === "geometry" ? ia : aa;
function sa(e, t, n, r, i = `n${Math.random().toString(36).slice(2, 8)}`) {
	let a = oa(e)[t];
	return {
		id: i,
		type: t,
		x: n,
		y: r,
		values: Object.fromEntries(a.params.map((e) => [e.key, e.default]))
	};
}
function ca(e) {
	if (!e || typeof e != "object") return;
	let t = e, n = t.kind === "material" ? "material" : "geometry", r = oa(n);
	if (!Array.isArray(t.nodes)) return;
	let i = t.nodes.slice(0, 24).flatMap((e) => {
		if (!e || typeof e != "object") return [];
		let t = e, n = typeof t.type == "string" ? r[t.type] : void 0;
		if (!n || typeof t.id != "string" || !/^[\w-]{1,24}$/.test(t.id)) return [];
		let i = t.values && typeof t.values == "object" ? t.values : {}, a = Object.fromEntries(n.params.map((e) => {
			let t = i[e.key];
			return e.kind === "number" ? [e.key, typeof t == "number" && Number.isFinite(t) ? Math.min(e.max, Math.max(e.min, t)) : e.default] : e.kind === "colour" ? [e.key, typeof t == "string" && /^#[0-9a-f]{6}$/i.test(t) ? t : e.default] : e.kind === "axis" ? [e.key, t === "x" || t === "y" || t === "z" ? t : e.default] : [e.key, typeof t == "string" && /^[\w-]{0,40}$/.test(t) ? t : ""];
		})), o = (e) => typeof e == "number" && Number.isFinite(e) ? Math.min(4e3, Math.max(-4e3, e)) : 0;
		return [{
			id: t.id,
			type: t.type,
			x: o(t.x),
			y: o(t.y),
			values: a
		}];
	}), a = new Map(i.map((e) => [e.id, e])), o = (Array.isArray(t.links) ? t.links : []).flatMap((e) => {
		if (!e || typeof e != "object") return [];
		let t = e, n = a.get(t.from), i = a.get(t.to);
		if (!n || !i || n === i) return [];
		let o = r[i.type].inputs.find((e) => e.key === t.input);
		return !o || r[n.type].output !== o.type ? [] : [{
			from: n.id,
			to: i.id,
			input: o.key
		}];
	}), s = /* @__PURE__ */ new Set(), c = o.filter((e) => !s.has(`${e.to}|${e.input}`) && s.add(`${e.to}|${e.input}`));
	return i.length ? {
		kind: n,
		nodes: i,
		links: c
	} : void 0;
}
function la(e, t, n, r) {
	let i = oa(e.kind), a = e.nodes.find((e) => e.id === t), o = e.nodes.find((e) => e.id === n);
	if (!a || !o || a === o) return !1;
	let s = i[o.type].inputs.find((e) => e.key === r);
	if (!s || i[a.type].output !== s.type) return !1;
	let c = (t, r = /* @__PURE__ */ new Set()) => t === n || e.links.some((e) => e.to === t && !r.has(e.from) && (r.add(e.from), c(e.from, r)));
	return !c(t);
}
function ua(e, t, n) {
	let r = (Math.imul(e + 7, 73856093) ^ Math.imul(t + 1, 19349663) ^ Math.imul(n + 1, 83492791)) >>> 0;
	return r = Math.imul(r ^ r >>> 13, 1274126177) >>> 0, ((r ^ r >>> 16) >>> 0) / 4294967295;
}
var da = {
	x: 0,
	y: 1,
	z: 2
};
function fa(e, t) {
	let n = /* @__PURE__ */ new Map(), r = (i, a = 0) => {
		if (n.has(i)) return n.get(i);
		let o = e.nodes.find((e) => e.id === i);
		if (!o || a > 24) return;
		let s = t(o, (t) => {
			let n = e.links.find((e) => e.to === i && e.input === t);
			return n ? r(n.from, a + 1) : void 0;
		});
		return n.set(i, s), s;
	};
	return r;
}
function pa(e) {
	let t = e.nodes.find((e) => e.type === "output");
	if (!t) return null;
	let n = fa(e, (e, t) => {
		let n = e.values, r = (e, t = [
			0,
			0,
			0
		], n = 1) => ({
			at: e,
			turn: t,
			scale: n
		});
		switch (e.type) {
			case "grid": {
				let e = [];
				for (let t = 0; t < n.deep; t++) for (let i = 0; i < n.across; i++) e.push(r([
					(i - (n.across - 1) / 2) * n.gap,
					0,
					(t - (n.deep - 1) / 2) * n.gap
				]));
				return e;
			}
			case "line": {
				let e = da[n.axis ?? "x"];
				return Array.from({ length: n.count }, (t, i) => {
					let a = [
						0,
						0,
						0
					];
					return a[e] = n.count > 1 ? (i / (n.count - 1) - .5) * n.length : 0, r(a);
				});
			}
			case "ring": return Array.from({ length: n.count }, (e, t) => {
				let i = t / n.count * Math.PI * 2;
				return r([
					Math.sin(i) * n.radius,
					0,
					Math.cos(i) * n.radius
				], [
					0,
					n.face ? i * 180 / Math.PI : 0,
					0
				]);
			});
			case "scatter": return Array.from({ length: n.count }, (e, t) => r([
				(ua(n.seed, t, 0) - .5) * n.width,
				0,
				(ua(n.seed, t, 1) - .5) * n.depth
			], [
				0,
				ua(n.seed, t, 2) * 360,
				0
			]));
			case "join": return [...t("a") ?? [], ...t("b") ?? []];
			case "shake": return (t("in") ?? []).map((e, t) => ({
				at: e.at.map((e, r) => e + (r === 1 ? 0 : (ua(n.seed, t, r) - .5) * 2 * n.move)),
				turn: [
					e.turn[0],
					e.turn[1] + (ua(n.seed, t, 3) - .5) * 2 * n.turn,
					e.turn[2]
				],
				scale: e.scale * (1 + (ua(n.seed, t, 4) - .5) * 2 * n.grow)
			}));
			case "lift": return (t("in") ?? []).map((e) => ({
				at: [
					e.at[0] * n.scale + n.x,
					e.at[1] * n.scale + n.y,
					e.at[2] * n.scale + n.z
				],
				turn: e.turn,
				scale: e.scale
			}));
			default: return t("in") ?? [];
		}
	})(t.id);
	return n ? {
		places: n.slice(0, 200),
		shape: String(t.values.shape ?? "")
	} : null;
}
function ma(e, t, n) {
	let r = e.min[1], i = e.parts.map((e) => {
		let i = e.positions.length / 3, a = new Float32Array(i * 3 * n.length), o = new Float32Array(i * 3 * n.length), s = new Uint32Array(e.indices.length * n.length), c = e.uvs ? new Float32Array(i * 2 * n.length) : null, l = e.colors ? new Float32Array(i * 3 * n.length) : null;
		return n.forEach((n, u) => {
			let d = G(n.turn);
			for (let s = 0; s < i; s++) {
				let c = [
					0,
					1,
					2
				].map((i) => (e.positions[s * 3 + i] - (i === 1 ? r : t[i])) * n.scale), l = [
					0,
					1,
					2
				].map((t) => e.normals[s * 3 + t]);
				for (let e = 0; e < 3; e++) a[(u * i + s) * 3 + e] = d[e * 3] * c[0] + d[e * 3 + 1] * c[1] + d[e * 3 + 2] * c[2] + (e === 1 ? r : t[e]) + n.at[e], o[(u * i + s) * 3 + e] = d[e * 3] * l[0] + d[e * 3 + 1] * l[1] + d[e * 3 + 2] * l[2];
			}
			c && c.set(e.uvs, u * i * 2), l && l.set(e.colors, u * i * 3);
			for (let t = 0; t < e.indices.length; t++) s[u * e.indices.length + t] = e.indices[t] + u * i;
		}), {
			...e,
			positions: a,
			normals: o,
			uvs: c,
			colors: l,
			indices: s
		};
	});
	return o(i, e.materials, e.textures);
}
var ha = (e) => [
	0,
	2,
	4
].map((t) => (parseInt(e.slice(1 + t, 3 + t), 16) / 255) ** 2.2);
function ga(e) {
	let t = e.nodes.find((e) => e.type === "output");
	return !t || !e.links.some((e) => e.to === t.id) ? null : (n, r) => {
		let i = fa(e, (e, t) => {
			let i = e.values;
			switch (e.type) {
				case "gradient": return n[da[i.axis]];
				case "noise": {
					let e = 0, t = 1, r = 0, a = Number(i.scale);
					for (let o = 0; o < Number(i.detail); o++) e += yn(n[0] * a + Number(i.seed) * 17.1, n[1] * a, n[2] * a) * t, r += t, t *= .5, a *= 2;
					return Math.min(1, Math.max(0, e / r));
				}
				case "checker": {
					let e = Number(i.scale);
					return +((Math.floor(n[0] * e) + Math.floor(n[1] * e) + Math.floor(n[2] * e)) % 2 == 0);
				}
				case "waves": return .5 + .5 * Math.sin(n[da[i.axis]] * Number(i.scale) * Math.PI * 2);
				case "up": return Math.max(0, r[1]);
				case "ramp": {
					let e = Number(t("in") ?? 0), n = Number(i.low), r = Math.max(n + 1e-6, Number(i.high)), a = Math.min(1, Math.max(0, (e - n) / (r - n))), o = ha(i.a), s = ha(i.b);
					return [
						o[0] + (s[0] - o[0]) * a,
						o[1] + (s[1] - o[1]) * a,
						o[2] + (s[2] - o[2]) * a
					];
				}
				case "mix": {
					let e = t("a") ?? [
						0,
						0,
						0
					], n = t("b") ?? [
						1,
						1,
						1
					], r = Math.min(1, Math.max(0, Number(t("f") ?? i.f)));
					return [
						e[0] + (n[0] - e[0]) * r,
						e[1] + (n[1] - e[1]) * r,
						e[2] + (n[2] - e[2]) * r
					];
				}
				case "colour": return ha(i.c);
				default: return t("in") ?? [
					.8,
					.8,
					.8
				];
			}
		})(t.id);
		return Array.isArray(i) ? i : [
			i ?? 0,
			i ?? 0,
			i ?? 0
		];
	};
}
function _a(e, t) {
	let n = ga(t);
	if (!n) throw Error("Wire something into the Material box first.");
	let r = e.max.map((t, n) => Math.max(t - e.min[n], 1e-9)), i = e.parts.map((t) => {
		let i = new Float32Array(t.positions.length);
		for (let a = 0; a < i.length; a += 3) {
			let o = [
				0,
				1,
				2
			].map((n) => (t.positions[a + n] - e.min[n]) / r[n]), s = [
				t.normals[a],
				t.normals[a + 1],
				t.normals[a + 2]
			];
			i.set(n(o, s), a);
		}
		return {
			...t,
			colors: i
		};
	}), a = e.materials.map((e) => ({
		...e,
		color: [
			1,
			1,
			1
		],
		texture: -1
	}));
	return o(i, a, e.textures);
}
function va(e, t = "") {
	return e === "geometry" ? {
		kind: e,
		nodes: [sa("geometry", "grid", 40, 60, "grid"), {
			...sa("geometry", "output", 340, 60, "out"),
			values: { shape: t }
		}],
		links: [{
			from: "grid",
			to: "out",
			input: "in"
		}]
	} : {
		kind: e,
		nodes: [
			sa("material", "noise", 30, 60, "noise"),
			sa("material", "ramp", 250, 60, "ramp"),
			sa("material", "output", 480, 60, "out")
		],
		links: [{
			from: "noise",
			to: "ramp",
			input: "in"
		}, {
			from: "ramp",
			to: "out",
			input: "in"
		}]
	};
}
//#endregion
//#region ../scene3d/src/model/arrange.ts
var ya = /* @__PURE__ */ e({
	alignMoves: () => Ea,
	assetsOf: () => Aa,
	copiesOf: () => ka,
	groundMoves: () => Oa,
	movedBy: () => wa,
	shapeBox: () => ba,
	spreadMoves: () => Da,
	unionBox: () => xa
});
function ba(e) {
	if (e.kind === "group") return xa((e.children ?? []).filter((e) => !e.hidden));
	let t = G(e.rotation), n = [
		0,
		1,
		2
	].map((n) => [
		0,
		1,
		2
	].reduce((r, i) => r + Math.abs(t[n * 3 + i]) * e.size[i] / 2, 0)), r = !!(e.form?.twist || e.form?.bend || e.form?.taper), i = Math.hypot(...e.size) / 2 * (1 + Math.abs(e.form?.taper ?? 0)), a = e.repeat?.kind === "around" || r ? [
		0,
		1,
		2
	].map(() => i) : n, o = On(e);
	return {
		min: [
			0,
			1,
			2
		].map((e) => Math.min(...o.map((t) => t[e])) - a[e]),
		max: [
			0,
			1,
			2
		].map((e) => Math.max(...o.map((t) => t[e])) + a[e])
	};
}
function xa(e) {
	let t = null;
	for (let n of e) {
		let e = ba(n);
		e && (t = t ? {
			min: t.min.map((t, n) => Math.min(t, e.min[n])),
			max: t.max.map((t, n) => Math.max(t, e.max[n]))
		} : e);
	}
	return t;
}
var Sa = (e) => Math.round(e * 1e3) / 1e3, Ca = (e, t) => [
	Sa(e[0] + t[0]),
	Sa(e[1] + t[1]),
	Sa(e[2] + t[2])
];
function wa(e, t) {
	return e.kind === "group" ? { children: (e.children ?? []).map((e) => ({
		...e,
		position: Ca(e.position, t)
	})) } : { position: Ca(e.position, t) };
}
var Ta = () => [
	0,
	0,
	0
];
function Ea(e, t, n) {
	let r = e.map(ba), i = xa(e);
	if (!i) return e.map(Ta);
	let a = (e) => n === "min" ? e.min[t] : n === "max" ? e.max[t] : (e.min[t] + e.max[t]) / 2, o = e.length === 1 ? 0 : a(i);
	return r.map((r) => {
		let i = Ta();
		return r && (i[t] = o - (e.length === 1 && n === "mid" ? (r.min[t] + r.max[t]) / 2 : a(r))), i;
	});
}
function Da(e, t) {
	let n = e.map(Ta), r = e.map(ba), i = e.map((e, t) => t).filter((e) => r[e]).sort((e, n) => r[e].min[t] - r[n].min[t]);
	if (i.length < 3) return n;
	let a = r[i[0]], o = r[i[i.length - 1]], s = i.map((e) => r[e].max[t] - r[e].min[t]), c = (o.max[t] - a.min[t] - s.reduce((e, t) => e + t, 0)) / (i.length - 1), l = a.min[t];
	return i.forEach((e, i) => {
		n[e][t] = l - r[e].min[t], l += s[i] + c;
	}), n;
}
var Oa = (e) => e.map((e) => {
	let t = ba(e);
	return [
		0,
		t && 0 - t.min[1] || 0,
		0
	];
});
function ka(e, t) {
	let n = (e) => ({
		...e,
		id: nc(),
		position: Ca(e.position, t),
		children: e.children?.map(n)
	});
	return e.map((e) => {
		let t = n(e);
		return t.children || delete t.children, t;
	});
}
function Aa(e, t) {
	let n = {}, r = (t) => {
		t.asset && e.assets?.[t.asset] && (n[t.asset] = e.assets[t.asset]), t.children?.forEach(r);
	};
	return t.forEach(r), n;
}
//#endregion
//#region ../scene3d/src/model/keys.ts
var ja = {
	inOut: "Smooth",
	linear: "Steady",
	in: "Speed up",
	out: "Slow down",
	back: "Overshoot",
	bounce: "Bounce"
}, Ma = Object.keys(ja);
function Na(e, t) {
	return {
		position: t.position,
		rotation: t.rotation,
		size: t.size,
		...t.morphAmount !== void 0 && e.morph ? { morph: {
			...e.morph,
			amount: t.morphAmount
		} } : {},
		...t.bonePose && e.rig && t.bonePose.length === e.rig.bones.length ? { rig: {
			...e.rig,
			pose: t.bonePose
		} } : {}
	};
}
var Pa = .005, Fa = {
	linear: (e) => e,
	in: (e) => e * e * e,
	out: (e) => 1 - (1 - e) ** 3,
	inOut: (e) => e < .5 ? 4 * e * e * e : 1 - (-2 * e + 2) ** 3 / 2,
	back: (e) => 1 + 2.70158 * (e - 1) ** 3 + 1.70158 * (e - 1) ** 2,
	bounce: (e) => {
		let t = 7.5625, n = 2.75;
		return e < 1 / n ? t * e * e : e < 2 / n ? t * (e -= 1.5 / n) * e + .75 : e < 2.5 / n ? t * (e -= 2.25 / n) * e + .9375 : t * (e -= 2.625 / n) * e + .984375;
	}
}, Ia = (e, t, n, r) => typeof e == "number" && Number.isFinite(e) ? Math.min(n, Math.max(t, e)) : r, La = (e, t, n, r) => Array.isArray(e) && e.length === 3 ? e.map((e, i) => Ia(e, t, n, r[i])) : r;
function Ra(e) {
	if (!Array.isArray(e)) return;
	let t = [];
	for (let n of e.slice(0, 240)) {
		if (!n || typeof n != "object") continue;
		let e = n;
		typeof e.at == "number" && Number.isFinite(e.at) && t.push({
			at: Ia(e.at, 0, 1, 0),
			position: La(e.position, -100, 100, [
				0,
				.5,
				0
			]),
			rotation: La(e.rotation, -360, 360, [
				0,
				0,
				0
			]),
			size: La(e.size, .01, 100, [
				1,
				1,
				1
			]),
			ease: Ma.includes(e.ease) ? e.ease : "inOut",
			...typeof e.morph == "number" && Number.isFinite(e.morph) ? { morph: Ia(e.morph, 0, 1, 0) } : {},
			...Array.isArray(e.bones) ? { bones: e.bones.slice(0, 256).map((e) => La(e, -360, 360, [
				0,
				0,
				0
			])) } : {}
		});
	}
	t.sort((e, t) => e.at - t.at);
	let n = t.filter((e, n) => n === 0 || e.at - t[n - 1].at >= .005).slice(0, 120);
	return n.length ? n : void 0;
}
var za = (e, t, n) => e.map((e, r) => e + (t[r] - e) * n), Ba = (e) => ({
	position: [...e.position],
	rotation: [...e.rotation],
	size: [...e.size],
	...e.morph === void 0 ? {} : { morphAmount: e.morph },
	...e.bones ? { bonePose: e.bones.map((e) => [...e]) } : {}
});
function Va(e, t, n) {
	let r = e[0], i = e[e.length - 1], a = t <= r.at ? r : t >= i.at ? i : null;
	if (a && !n?.face) return Ba(a);
	let o = Math.min(i.at, Math.max(r.at, t)), s = Math.max(1, e.findIndex((e) => e.at > o) < 0 ? e.length - 1 : e.findIndex((e) => e.at > o)), c = e[s - 1], l = e[s] ?? c, u = l === c ? 0 : Fa[l.ease]((o - c.at) / (l.at - c.at)), d = (t) => n?.curve ? Ha(e[s - 2]?.position ?? c.position, c.position, l.position, e[s + 1]?.position ?? l.position, t) : za(c.position, l.position, t), f = za(c.rotation, l.rotation, u);
	if (n?.face && e.length > 1) {
		let t = (t) => Va(e, Math.min(i.at, Math.max(r.at, t)), { curve: n.curve }).position, a = t(o + .002), s = t(o - .002), c = a.map((e, t) => e - s[t]), l = Math.hypot(...c);
		l > 1e-9 && (f[1] += Math.atan2(c[0], c[2]) * 180 / Math.PI, f[0] += -Math.asin(c[1] / l) * 180 / Math.PI);
	}
	return {
		position: d(u),
		rotation: f,
		size: za(c.size, l.size, u).map((e) => Math.max(.001, e)),
		...c.morph !== void 0 && l.morph !== void 0 ? { morphAmount: Math.min(1, Math.max(0, c.morph + (l.morph - c.morph) * u)) } : {},
		...c.bones && l.bones && c.bones.length === l.bones.length ? { bonePose: c.bones.map((e, t) => za(e, l.bones[t], u)) } : {}
	};
}
function Ha(e, t, n, r, i) {
	let a = i * i, o = a * i;
	return [
		0,
		1,
		2
	].map((s) => .5 * (2 * t[s] + (-e[s] + n[s]) * i + (2 * e[s] - 5 * t[s] + 4 * n[s] - r[s]) * a + (-e[s] + 3 * t[s] - 3 * n[s] + r[s]) * o));
}
var Ua = (e, t) => e?.find((e) => Math.abs(e.at - t) < Pa);
function Wa(e, t, n = "inOut") {
	let r = Ua(e.keys, t), i = e.kind === "group" ? eo(e) : e, a = {
		at: r?.at ?? Math.min(1, Math.max(0, t)),
		position: [...i.position],
		rotation: [...i.rotation],
		size: [...i.size],
		ease: r?.ease ?? n,
		...e.morph ? { morph: e.morph.amount } : {},
		...e.rig ? { bones: e.rig.pose.map((e) => [...e]) } : {}
	};
	return [...(e.keys ?? []).filter((e) => e !== r), a].sort((e, t) => e.at - t.at).slice(0, 120);
}
function Ga(e, t) {
	if (e.kind !== "group") return { keys: Wa(e, t) };
	let n = e.keyBase?.length ? e.keyBase : Xa(e);
	return {
		keyBase: n,
		keys: Wa({
			...e,
			keyBase: n
		}, t)
	};
}
var Ka = (e) => e.kind === "group" ? {
	keys: void 0,
	keyBase: void 0
} : { keys: void 0 };
function qa(e, t) {
	if (!e.keys?.length) return !1;
	let n = Va(e.keys, t, e.keyPath), r = e.kind === "group" ? eo(e) : e, i = (e, t, n) => e.some((e, r) => Math.abs(e - t[r]) > n);
	return i(n.position, r.position, .001) || i(n.rotation, r.rotation, .05) || i(n.size, r.size, .001);
}
function Ja(e, t) {
	let n = [], r = (r, i) => {
		let a = r.take && r.rig ? e.takes?.[r.take.id] : void 0;
		if (!a) return;
		let { pose: o, root: s } = _i(a, r.rig, r.take, t, e.clip ?? 4);
		n.push([i, { rig: {
			...r.rig,
			pose: o,
			root: s
		} }]);
	};
	return e.shapes.forEach((e, i) => {
		r(e, [i]), e.children?.forEach((e, t) => r(e, [i, t])), !(e.keys?.length && (n.push([[i], e.kind === "group" ? { children: to(e, t).children } : Na(e, Va(e.keys, t, e.keyPath))]), e.kind === "group")) && e.children?.forEach((e, r) => {
			e.keys?.length && n.push([[i, r], Na(e, Va(e.keys, t, e.keyPath))]);
		});
	}), n;
}
function Ya(e) {
	if (!Array.isArray(e)) return;
	let t = e.slice(0, 64).flatMap((e) => {
		if (!e || typeof e != "object") return [];
		let t = e;
		return typeof t.id != "string" || !t.id ? [] : [{
			id: t.id.slice(0, 40),
			position: La(t.position, -100, 100, [
				0,
				0,
				0
			]),
			rotation: La(t.rotation, -360, 360, [
				0,
				0,
				0
			]),
			size: La(t.size, .01, 100, [
				1,
				1,
				1
			])
		}];
	});
	return t.length ? t : void 0;
}
var Xa = (e) => (e.children ?? []).map((e) => ({
	id: e.id,
	position: [...e.position],
	rotation: [...e.rotation],
	size: [...e.size]
})), Za = (e) => e.reduce((t, n) => t.map((t, r) => t + n.position[r] / e.length), [
	0,
	0,
	0
]), Qa = (e) => [
	e[0],
	e[3],
	e[6],
	e[1],
	e[4],
	e[7],
	e[2],
	e[5],
	e[8]
], $a = (e, t) => [
	0,
	1,
	2
].flatMap((n) => [
	0,
	1,
	2
].map((r) => e[n * 3] * t[r] + e[n * 3 + 1] * t[3 + r] + e[n * 3 + 2] * t[6 + r]));
function eo(e) {
	let t = e.keyBase ?? [], n = new Map((e.children ?? []).map((e) => [e.id, e])), r = t.filter((e) => n.has(e.id)), i = r[0];
	if (!i) return {
		position: [
			0,
			0,
			0
		],
		rotation: [
			0,
			0,
			0
		],
		size: [
			1,
			1,
			1
		]
	};
	let a = n.get(i.id), o = $a(G(a.rotation), Qa(G(i.rotation))), s = r.reduce((e, t) => e.map((e, i) => e + n.get(t.id).position[i] / r.length), [
		0,
		0,
		0
	]), c = Za(r), l = (e) => Math.round(e * 1e4) / 1e4;
	return {
		position: s.map((e, t) => l(e - c[t])),
		rotation: vo(o).map((e) => e || 0),
		size: a.size.map((e, t) => l(e / i.size[t]))
	};
}
function to(e, t) {
	if (!e.keys?.length || !e.keyBase?.length) return e;
	let n = Va(e.keys, t, e.keyPath), r = new Map(e.keyBase.map((e) => [e.id, e])), i = {
		pivot: Za(e.keyBase.filter((t) => e.children?.some((e) => e.id === t.id))),
		turn: G(n.rotation),
		grow: n.size,
		move: n.position
	};
	return {
		...e,
		children: (e.children ?? []).map((e) => {
			let t = r.get(e.id);
			return t ? wo({
				...e,
				position: t.position,
				rotation: t.rotation,
				size: t.size
			}, i) : e;
		})
	};
}
function no(e) {
	if (!Array.isArray(e)) return;
	let t = [];
	for (let n of e.slice(0, 240)) {
		if (!n || typeof n != "object") continue;
		let e = n;
		typeof e.at == "number" && Number.isFinite(e.at) && t.push({
			at: Ia(e.at, 0, 1, 0),
			yaw: Ia(e.yaw, -360, 360, 30),
			pitch: Ia(e.pitch, -89, 89, 22),
			distance: Ia(e.distance, .5, 200, 5.5),
			target: La(e.target, -100, 100, [
				0,
				.5,
				0
			]),
			fov: Ia(e.fov, 10, 90, 35),
			ease: Ma.includes(e.ease) ? e.ease : "inOut"
		});
	}
	t.sort((e, t) => e.at - t.at);
	let n = t.filter((e, n) => n === 0 || e.at - t[n - 1].at >= .005).slice(0, 120);
	return n.length ? n : void 0;
}
var ro = (e) => ({
	yaw: e.yaw,
	pitch: e.pitch,
	distance: e.distance,
	target: [...e.target],
	fov: e.fov
});
function io(e, t) {
	let n = e[0], r = e[e.length - 1];
	if (t <= n.at) return ro(n);
	if (t >= r.at) return ro(r);
	let i = e.findIndex((e) => e.at > t), a = e[i - 1], o = e[i], s = Fa[o.ease]((t - a.at) / (o.at - a.at)), c = ((o.yaw - a.yaw) % 360 + 540) % 360 - 180;
	return {
		yaw: ((a.yaw + c * s + 180) % 360 + 360) % 360 - 180,
		pitch: Math.min(89, Math.max(-89, a.pitch + (o.pitch - a.pitch) * s)),
		distance: Math.max(.5, a.distance * (o.distance / a.distance) ** s),
		target: za(a.target, o.target, s),
		fov: Math.min(90, Math.max(10, a.fov + (o.fov - a.fov) * s))
	};
}
var ao = (e, t) => e?.find((e) => Math.abs(e.at - t) < Pa);
function oo(e, t, n = "inOut") {
	let r = ao(e.cameraKeys, t), { yaw: i, pitch: a, distance: o, target: s, fov: c } = e.camera, l = {
		at: r?.at ?? Math.min(1, Math.max(0, t)),
		yaw: i,
		pitch: a,
		distance: o,
		target: [...s],
		fov: c,
		ease: r?.ease ?? n
	};
	return [...(e.cameraKeys ?? []).filter((e) => e !== r), l].sort((e, t) => e.at - t.at).slice(0, 120);
}
function so(e, t) {
	if (!e.cameraKeys?.length) return !1;
	let n = io(e.cameraKeys, t), r = e.camera;
	return Math.abs(((n.yaw - r.yaw) % 360 + 540) % 360 - 180) > .1 || Math.abs(n.pitch - r.pitch) > .1 || Math.abs(n.distance - r.distance) > .001 || Math.abs(n.fov - r.fov) > .05 || n.target.some((e, t) => Math.abs(e - r.target[t]) > .001);
}
//#endregion
//#region ../scene3d/src/model/motion.ts
var co = {
	spin: "Spin",
	float: "Float",
	bounce: "Bounce",
	sway: "Sway",
	pulse: "Pulse",
	wiggle: "Wiggle",
	orbit: "Go round",
	pop: "Pop in"
}, lo = Object.keys(co), uo = {
	kind: "spin",
	times: 1,
	amount: .5,
	delay: 0,
	axis: "y",
	reverse: !1
}, fo = (e, t, n, r) => typeof e == "number" && Number.isFinite(e) ? Math.min(n, Math.max(t, e)) : r;
function po(e) {
	if (!e || typeof e != "object") return;
	let t = e;
	if (lo.includes(t.kind)) return {
		kind: t.kind,
		times: Math.round(fo(t.times, 1, 8, 1)),
		amount: fo(t.amount, 0, 1, uo.amount),
		delay: fo(t.delay, 0, 1, 0),
		axis: t.axis === "x" || t.axis === "z" ? t.axis : "y",
		reverse: t.reverse === !0
	};
}
var mo = (e, t) => [
	0,
	1,
	2
].flatMap((n) => [
	0,
	1,
	2
].map((r) => e[n * 3] * t[r] + e[n * 3 + 1] * t[3 + r] + e[n * 3 + 2] * t[6 + r])), ho = (e, t) => [
	0,
	1,
	2
].map((n) => e[n * 3] * t[0] + e[n * 3 + 1] * t[1] + e[n * 3 + 2] * t[2]), go = [
	1,
	0,
	0,
	0,
	1,
	0,
	0,
	0,
	1
], _o = (e, t) => G(e === "x" ? [
	t,
	0,
	0
] : e === "y" ? [
	0,
	t,
	0
] : [
	0,
	0,
	t
]);
function vo(e) {
	let t = Math.min(1, Math.max(-1, e[2])), n = Math.asin(t), r, i;
	Math.abs(t) < .9999999 ? (r = Math.atan2(-e[5], e[8]), i = Math.atan2(-e[1], e[0])) : (r = Math.atan2(e[7], e[4]), i = 0);
	let a = (e) => Math.round(e * 180 / Math.PI * 1e3) / 1e3;
	return [
		a(r),
		a(n),
		a(i)
	];
}
var yo = Math.PI * 2, bo = (e) => e - Math.floor(e), xo = (e) => 1 + 2.70158 * (e - 1) ** 3 + 1.70158 * (e - 1) ** 2;
function So(e, t, n, r) {
	let i = ba(e) ?? {
		min: e.position,
		max: e.position
	}, a = i.min.map((e, t) => (e + i.max[t]) / 2), o = Math.max(.05, i.max[1] - i.min[1]), s = Math.abs(i.min[1]) < .02 ? [
		a[0],
		i.min[1],
		a[2]
	] : a, c = t.times * n + t.delay, l = Math.sin(yo * c), u = {
		pivot: a,
		turn: go,
		grow: [
			1,
			1,
			1
		],
		move: [
			0,
			0,
			0
		]
	}, d = t.reverse ? -1 : 1;
	switch (t.kind) {
		case "spin":
			u.turn = _o(t.axis, d * 360 * bo(c));
			break;
		case "float":
			u.move = [
				0,
				t.amount * o * .5 * l,
				0
			];
			break;
		case "bounce": {
			let e = Math.abs(Math.sin(Math.PI * c)), n = Math.max(0, 1 - e * 5) * .18 * t.amount;
			u.pivot = s, u.grow = [
				1 + n * .5,
				1 - n,
				1 + n * .5
			], u.move = [
				0,
				t.amount * o * e,
				0
			];
			break;
		}
		case "sway":
			u.pivot = s, u.turn = _o(t.axis === "y" ? "z" : t.axis, t.amount * 30 * l);
			break;
		case "pulse": {
			let e = 1 + t.amount * .25 * l;
			u.pivot = s, u.grow = [
				e,
				e,
				e
			];
			break;
		}
		case "wiggle": {
			let e = bo(c), n = e < .4 ? Math.sin(yo * 3 * e / .4) * Math.sin(Math.PI * e / .4) : 0;
			u.pivot = s, u.turn = _o("z", t.amount * 12 * n);
			break;
		}
		case "orbit":
			u.pivot = [
				r[0],
				a[1],
				r[2]
			], u.turn = _o("y", d * 360 * bo(c));
			break;
		case "pop": {
			let e = bo(c), t = e < .3 ? Math.max(.001, xo(e / .3)) : 1;
			u.pivot = s, u.grow = [
				t,
				t,
				t
			];
			break;
		}
	}
	return u;
}
var Co = (e, t) => t ? Math.round(e * 50) / 50 : e;
function wo(e, t) {
	let n = e.position.map((e, n) => (e - t.pivot[n]) * t.grow[n]), r = ho(t.turn, n), i = !!e.outline;
	return {
		...e,
		position: r.map((e, n) => e + t.pivot[n] + t.move[n]),
		rotation: t.turn === go ? e.rotation : vo(mo(t.turn, G(e.rotation))),
		size: e.size.map((e, n) => Math.max(.001, e * Co(t.grow[n], i)))
	};
}
var To = (e) => !!e.motion || !!e.keys?.length || !!e.lookAt || !!e.take, Eo = (e) => !!e.cameraKeys?.length || !!e.cameraTake || !!e.effects?.length || e.shapes.some((e) => To(e) || e.children?.some(To));
function Do(e, t) {
	if (!e.keys?.length) return e;
	if (e.kind === "group") return to(e, t);
	let n = Va(e.keys, t, e.keyPath), r = !!e.outline;
	return {
		...e,
		...Na(e, n),
		size: r ? n.size.map((e) => Math.max(.001, Math.round(e * 50) / 50)) : n.size
	};
}
var Oo = (e) => ({
	...uo,
	kind: e,
	times: 1,
	amount: .5
});
function ko(e, t, n) {
	let r = !!n?.size;
	if (!r && !Eo(e)) return e;
	let i = e.camera.target, a = (e) => {
		let a = e.motion ? [So(e, e.motion, t, i)] : [], o = r ? n.get(e.id) : void 0;
		return o && a.push(So(e, Oo(o.reaction), o.at, i)), a;
	}, o = (n) => {
		let r = n.take && n.rig ? e.takes?.[n.take.id] : void 0;
		if (!r) return n;
		let { pose: i, root: a } = _i(r, n.rig, n.take, t, e.clip ?? 4), o = si(r, t * (e.clip ?? 4) * (n.take.speed ?? 1));
		return {
			...n,
			rig: {
				...n.rig,
				pose: i,
				root: a
			},
			...o ? { face: o } : {}
		};
	}, s = (n, r) => {
		if (!n.rig || !(n.take || n.keys?.length)) return r;
		let i = Xr(e, n, (e) => o(Do(n, e)));
		return i ? {
			...r,
			rig: {
				...r.rig,
				pose: Jr(r.rig.pose, i, t)
			}
		} : r;
	}, c = (n) => {
		if (!n.rig || n.life?.off) return n;
		let r = Dr(e, n), i = e.clip ?? 4, { pose: a, face: o } = Nr(n.rig, r, n.face, t * i, kr(n.id), n.life, { loop: i });
		return {
			...n,
			rig: {
				...n.rig,
				pose: a
			},
			...o ? { face: o } : {}
		};
	}, l = (e) => {
		let n = c(s(e, o(Do(e, t))));
		return a(n).reduce(wo, n);
	};
	return {
		...Ao({
			...e,
			shapes: e.shapes.map((e) => {
				if (e.kind !== "group") return l(e);
				let n = Do(e, t), r = !!n.keys?.length, i = (n.children ?? []).map((e) => r ? a(c(o(e))).reduce(wo, c(o(e))) : l(e)), s = a({
					...n,
					children: i
				});
				return {
					...n,
					children: i.map((e) => s.reduce(wo, e))
				};
			}),
			camera: e.cameraTake ? {
				...e.camera,
				...ci(e.cameraTake, t * (e.clip ?? 4))
			} : e.cameraKeys?.length ? {
				...e.camera,
				...io(e.cameraKeys, t)
			} : e.camera
		}),
		...e.effects?.length ? { now: t } : {}
	};
}
function Ao(e) {
	if (!e.shapes.some((e) => e.lookAt || e.children?.some((e) => e.lookAt))) return e;
	let t = /* @__PURE__ */ new Map();
	for (let n of e.shapes) {
		t.set(n.id, n.position);
		for (let e of n.children ?? []) t.set(e.id, e.position);
	}
	let n = e.camera, r = n.yaw * Math.PI / 180, i = n.pitch * Math.PI / 180, a = [
		n.target[0] + Math.sin(r) * Math.cos(i) * n.distance,
		n.target[1] + Math.sin(i) * n.distance,
		n.target[2] + Math.cos(r) * Math.cos(i) * n.distance
	], o = (e) => {
		let n = e.lookAt === "camera" ? a : e.lookAt ? t.get(e.lookAt) : void 0;
		if (!n || e.lookAt === e.id) return e;
		let r = n.map((t, n) => t - e.position[n]), i = Math.hypot(...r);
		return i < 1e-6 ? e : {
			...e,
			rotation: [
				-Math.asin(r[1] / i) * 180 / Math.PI,
				Math.atan2(r[0], r[2]) * 180 / Math.PI,
				0
			]
		};
	};
	return {
		...e,
		shapes: e.shapes.map((e) => e.children ? {
			...o(e),
			children: e.children.map(o)
		} : o(e))
	};
}
//#endregion
//#region ../scene3d/src/model/morph.ts
function jo(e, t, n) {
	return e.parts.map((e, r) => {
		let i = t.parts[r];
		if (!i || i.positions.length !== e.positions.length || n <= 0) return e;
		let a = new Float32Array(e.positions.length), o = new Float32Array(e.normals.length);
		for (let t = 0; t < a.length; t++) a[t] = e.positions[t] + (i.positions[t] - e.positions[t]) * n, o[t] = e.normals[t] + (i.normals[t] - e.normals[t]) * n;
		for (let e = 0; e < o.length; e += 3) {
			let t = Math.hypot(o[e], o[e + 1], o[e + 2]) || 1;
			o[e] /= t, o[e + 1] /= t, o[e + 2] /= t;
		}
		return {
			...e,
			positions: a,
			normals: o
		};
	});
}
var Mo = (e, t) => e.parts.length === t.parts.length && e.parts.every((e, n) => e.positions.length === t.parts[n].positions.length);
function No(e, t) {
	let n = e.morphs;
	return e.parts.map((e, r) => {
		let i = null;
		return n.names.forEach((a, o) => {
			let s = t[a], c = n.moves[o]?.[r];
			if (s && c) {
				i ??= e.positions.slice();
				for (let e = 0; e < c.length; e++) i[e] += c[e] * s;
			}
		}), i ? {
			...e,
			positions: i
		} : e;
	});
}
var Po = /* @__PURE__ */ new Map();
function Fo(e, t) {
	let r = t.asset ? e.assets?.[t.asset] : void 0;
	if (!r) return null;
	let i = n(t.asset, r.data), a = t.morph, s = a ? e.assets?.[a.asset] : void 0, c = !!a && !!s && a.amount > 0, l = er(t.rig), u = !!i.morphs && !!t.face && Object.keys(t.face).length > 0;
	if (!c && !l && !u) return i;
	let d = `${t.asset}|${c ? `${a.asset}|${Math.round(a.amount * 200)}` : ""}|${l ? JSON.stringify(t.rig) : ""}|${u ? JSON.stringify(t.face) : ""}`, f = Po.get(d);
	if (f) return f;
	let p = i;
	if (c) {
		let e = n(a.asset, s.data);
		Mo(i, e) && (p = o(jo(i, e, a.amount), i.materials, i.textures));
	}
	return u && (p = {
		...p,
		parts: No(p, t.face)
	}), l && (p = o(tr(p, t.rig, t.asset), p.materials, p.textures)), p = {
		...p,
		min: i.min,
		max: i.max
	}, Po.size > 24 && Po.delete(Po.keys().next().value), Po.set(d, p), p;
}
//#endregion
//#region ../scene3d/src/model/meshcpu.ts
var Io = typeof createImageBitmap == "function" && typeof OffscreenCanvas < "u" ? async (e, t) => {
	try {
		let n = await createImageBitmap(new Blob([e], { type: t }), {
			premultiplyAlpha: "none",
			colorSpaceConversion: "none"
		}), r = new OffscreenCanvas(n.width, n.height), i = r.getContext("2d");
		return i.drawImage(n, 0, 0), n.close(), i.getImageData(0, 0, r.width, r.height);
	} catch {
		return null;
	}
} : void 0, Lo = /* @__PURE__ */ new WeakMap();
async function Ro(e, t = Io) {
	let r = [];
	for (let { shape: i, asset: o } of Ac(e)) {
		let s = Fo(e, i) ?? n(i.asset, o.data), c = Lo.get(s);
		c || Lo.set(s, c = /* @__PURE__ */ new Map());
		let l = t ? c.get(t) : void 0;
		l || (l = t ? Promise.all(s.textures.map((e) => t(e.bytes, e.mime))) : Promise.resolve(s.textures.map(() => null)), t && c.set(t, l));
		let u = s.max.map((e, t) => Math.max(e - s.min[t], 1e-9));
		r.push({
			shape: i,
			asset: s,
			bvh: a(s),
			textures: await l,
			rot: G(i.rotation),
			scale: i.size.map((e, t) => e / u[t]),
			centre: s.min.map((e, t) => (e + s.max[t]) / 2),
			position: i.position
		});
	}
	return r;
}
function zo(e, t, n) {
	let r = e.rot, i = [
		t[0] - e.position[0],
		t[1] - e.position[1],
		t[2] - e.position[2]
	];
	return [[
		0,
		1,
		2
	].map((t) => (r[t] * i[0] + r[3 + t] * i[1] + r[6 + t] * i[2]) / e.scale[t] + e.centre[t]), [
		0,
		1,
		2
	].map((t) => (r[t] * n[0] + r[3 + t] * n[1] + r[6 + t] * n[2]) / e.scale[t])];
}
var Bo = (e) => (e / 255) ** 2.2, Vo = (e, t, n) => {
	let r = Math.min(e.width - 1, Math.floor((t - Math.floor(t)) * e.width));
	return (Math.min(e.height - 1, Math.floor((n - Math.floor(n)) * e.height)) * e.width + r) * 4;
}, Ho = (e, t, n) => {
	let r = (t - Math.floor(t)) * e.width - .5, i = (n - Math.floor(n)) * e.height - .5, a = Math.floor(r), o = Math.floor(i), s = r - a, c = i - o, l = (e, t) => (e % t + t) % t, u = [l(a, e.width), l(a + 1, e.width)], d = [l(o, e.height), l(o + 1, e.height)], f = [
		0,
		0,
		0,
		0
	], p = e.data;
	for (let t = 0; t < 2; t++) for (let n = 0; n < 2; n++) {
		let r = (n ? s : 1 - s) * (t ? c : 1 - c);
		if (!r) continue;
		let i = (d[t] * e.width + u[n]) * 4;
		for (let e = 0; e < 4; e++) f[e] = f[e] + p[i + e] * r;
	}
	return f;
}, Uo = (e, t) => {
	let n = [
		t[0] * e.scale[0],
		t[1] * e.scale[1],
		t[2] * e.scale[2]
	], r = e.rot;
	return [
		0,
		1,
		2
	].map((e) => r[e * 3] * n[0] + r[e * 3 + 1] * n[1] + r[e * 3 + 2] * n[2]);
};
function Wo(e, t, n, r, i, a, o, s) {
	let c = (e) => [
		t.positions[e * 3],
		t.positions[e * 3 + 1],
		t.positions[e * 3 + 2]
	], l = (e) => [t.uvs[e * 2], t.uvs[e * 2 + 1]], [u, d, f] = n.map(c), [p, m, h] = n.map(l), g = [
		0,
		1,
		2
	].map((e) => d[e] - u[e]), _ = [
		0,
		1,
		2
	].map((e) => f[e] - u[e]), [v, y, b, x] = [
		m[0] - p[0],
		m[1] - p[1],
		h[0] - p[0],
		h[1] - p[1]
	], S = v * x - b * y;
	if (Math.abs(S) <= 1e-12) return r;
	let C = [
		0,
		1,
		2
	].map((e) => (g[e] * x - _[e] * y) / S), w = [
		0,
		1,
		2
	].map((e) => (_[e] * v - g[e] * b) / S), T = (e) => Go([
		0,
		1,
		2
	].map((t) => e[t] - r[t] * (e[0] * r[0] + e[1] * r[1] + e[2] * r[2]))), E = T(Uo(e, C)), D = T(Uo(e, w)), O = Vo(i, a, o), k = (i.data[O] / 255 * 2 - 1) * s, A = (i.data[O + 1] / 255 * 2 - 1) * s, j = i.data[O + 2] / 255 * 2 - 1;
	return Go([
		0,
		1,
		2
	].map((e) => E[e] * k - D[e] * A + r[e] * j));
}
var Go = (e) => {
	let t = Math.hypot(e[0], e[1], e[2]) || 1;
	return [
		e[0] / t,
		e[1] / t,
		e[2] / t
	];
};
function Ko(e, t, n, r = Infinity) {
	let i = null, a = r;
	for (let r of e) {
		let [e, o] = zo(r, t, n), s = 1e-5;
		for (let t = 0; t < 6; t++) {
			let t = r.bvh.intersect(e, o, s, a);
			if (!t) break;
			let c = r.asset.parts[t.part], l = r.asset.materials[c.material], u = [
				1 - t.u - t.v,
				t.u,
				t.v
			], d = [
				t.a,
				t.b,
				t.c
			], f = (e, t, n) => d.reduce((r, i, a) => r + e[i * t + n] * u[a], 0), p = [...l.color], m = l.opacity, [h, g] = c.uvs ? [f(c.uvs, 2, 0), f(c.uvs, 2, 1)] : [0, 0], _ = l.texture >= 0 && c.uvs ? r.textures[l.texture] : null;
			if (_) {
				let e = l.unlit ? [..._.data.subarray(Vo(_, h, g), Vo(_, h, g) + 4)] : Ho(_, h, g);
				p = [
					p[0] * Bo(e[0]),
					p[1] * Bo(e[1]),
					p[2] * Bo(e[2])
				], m *= e[3] / 255;
			}
			let v = l.unlit && r.shape.ownColors !== !1 && [
				0,
				1,
				2
			].reduce((e, t) => e + f(c.normals, 3, t) * o[t], 0) > 0;
			if (l.cutout && m < .5 || v) {
				s = t.t + 1e-5;
				continue;
			}
			c.colors && (p = [
				p[0] * f(c.colors, 3, 0),
				p[1] * f(c.colors, 3, 1),
				p[2] * f(c.colors, 3, 2)
			]);
			let y = [
				0,
				1,
				2
			].map((e) => f(c.normals, 3, e) / r.scale[e]), b = r.rot, x = Go([
				0,
				1,
				2
			].map((e) => b[e * 3] * y[0] + b[e * 3 + 1] * y[1] + b[e * 3 + 2] * y[2])), S = x, C = l.normalTexture >= 0 && c.uvs ? r.textures[l.normalTexture] : null;
			C && (x = Wo(r, c, d, x, C, h, g, l.normalScale)), x[0] * n[0] + x[1] * n[1] + x[2] * n[2] > 0 && (x = x.map((e) => -e));
			let w = r.shape.ownColors !== !1, [T, E] = [l.roughness, l.metalness], D = w && l.roughnessTexture >= 0 && c.uvs ? r.textures[l.roughnessTexture] : null;
			if (D) {
				let e = Vo(D, h, g);
				T *= D.data[e + 1] / 255, E *= D.data[e + 2] / 255;
			}
			let [O, k] = w ? [6 + (1 - T) ** 2 * 134, E] : jn[r.shape.finish], A = l.occlusionTexture >= 0 && c.uvs ? r.textures[l.occlusionTexture] : null, j = A ? 1 + l.occlusionStrength * (A.data[Vo(A, h, g)] / 255 - 1) : 1, M = w ? [...l.emissive] : [
				0,
				0,
				0
			], N = w && l.emissiveTexture >= 0 && c.uvs ? r.textures[l.emissiveTexture] : null;
			if (N && Math.max(...M) > 0) {
				let e = Vo(N, h, g);
				M = [
					M[0] * Bo(N.data[e]),
					M[1] * Bo(N.data[e + 1]),
					M[2] * Bo(N.data[e + 2])
				];
			}
			if (!w) {
				let e = parseInt(r.shape.color.slice(1), 16);
				p = [
					(e >> 16 & 255) / 255,
					(e >> 8 & 255) / 255,
					(e & 255) / 255
				].map((e) => e ** 2.2);
			}
			a = t.t;
			let P = (e) => w && e >= 0 && c.uvs ? r.textures[e] : null, F = (e, t, n = 1) => {
				let r = P(e);
				return r ? r.data[Vo(r, h, g) + t] / 255 : n;
			}, I = S, L = S, ee = P(l.clearcoatNormalTexture);
			ee && (L = Wo(r, c, d, S, ee, h, g, l.clearcoatNormalScale));
			let te = (e) => e[0] * n[0] + e[1] * n[1] + e[2] * n[2] > 0 ? e.map((e) => -e) : e;
			I = te(I), L = te(L);
			let ne = P(l.sheenColorTexture), re = w ? [...l.sheenColor] : [
				0,
				0,
				0
			];
			if (ne) {
				let e = Vo(ne, h, g);
				for (let t = 0; t < 3; t++) re[t] = re[t] * Bo(ne.data[e + t]);
			}
			i = {
				t: t.t,
				unlit: w && l.unlit === !0,
				normal: x,
				color: p,
				shine: O,
				metal: k,
				occ: j,
				emissive: M,
				shapeNormal: I,
				clearcoat: w ? l.clearcoat * F(l.clearcoatTexture, 0) : 0,
				clearcoatRoughness: l.clearcoatRoughness * F(l.clearcoatRoughnessTexture, 1),
				coatNormal: L,
				sheen: re,
				sheenRoughness: l.sheenRoughness * F(l.sheenRoughnessTexture, 3),
				transmission: w ? l.transmission * F(l.transmissionTexture, 0) : 0,
				ior: l.ior,
				...w && l.look ? {
					look: l.look,
					...l.bands ? { bands: l.bands } : {}
				} : {}
			};
			break;
		}
	}
	return i;
}
function qo(e, t, n, r = Infinity) {
	for (let i of e) {
		let [e, a] = zo(i, t, n), o = i.shape.ownColors !== !1, s = 1e-4;
		for (let t = 0; t < 6; t++) {
			let t = i.bvh.intersect(e, a, s, r);
			if (!t) break;
			let n = i.asset.parts[t.part], c = i.asset.materials[n.material];
			if (o && c.transmission > .5) {
				s = t.t + 1e-5;
				continue;
			}
			let l = c.cutout && c.texture >= 0 && n.uvs ? i.textures[c.texture] : null;
			if (l) {
				let e = [
					1 - t.u - t.v,
					t.u,
					t.v
				], r = [
					t.a,
					t.b,
					t.c
				], i = [0, 1].map((t) => r.reduce((r, i, a) => r + n.uvs[i * 2 + t] * e[a], 0));
				if (l.data[Vo(l, i[0], i[1]) + 3] / 255 * c.opacity < .5) {
					s = t.t + 1e-5;
					continue;
				}
			}
			return !0;
		}
	}
	return !1;
}
//#endregion
//#region ../scene3d/src/model/labels.ts
var Jo = [
	"front",
	"back",
	"top",
	"around"
], Yo = {
	front: "Front",
	back: "Back",
	top: "Top",
	around: "Around"
}, Xo = 4e6, Zo = (e, t, n, r) => typeof e == "number" && Number.isFinite(e) ? Math.min(n, Math.max(t, e)) : r;
function Qo(e) {
	if (!e || typeof e != "object") return;
	let t = e, n = t.picture;
	if (!(typeof n != "string" || n.length > 4e6 || !/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+=*$/.test(n))) return {
		picture: n,
		side: Jo.includes(t.side) ? t.side : "front",
		width: Zo(t.width, .05, 1, .6),
		x: Zo(t.x, -.5, .5, 0),
		y: Zo(t.y, -.5, .5, 0)
	};
}
var $o = {
	front: 0,
	back: 1,
	top: 2,
	around: 3
};
function es(e, t, n) {
	let [r, i, a] = e.size, o = t.side === "top" ? [r, a] : t.side === "around" ? [Math.PI * r, i] : [r, i], s = t.width * o[0];
	return [
		s,
		s / Math.max(n, .01),
		t.x * o[0],
		t.y * o[1]
	];
}
function ts(e, t, n, r, i, a = .02) {
	let o = e.size.map((e) => e / 2 + a);
	if (Math.abs(r[0]) > o[0] || Math.abs(r[1]) > o[1] || Math.abs(r[2]) > o[2]) return null;
	let s;
	if (t.side === "front") {
		if (i[2] < .2) return null;
		s = [r[0], r[1]];
	} else if (t.side === "back") {
		if (i[2] > -.2) return null;
		s = [-r[0], r[1]];
	} else if (t.side === "top") {
		if (i[1] < .2) return null;
		s = [r[0], -r[2]];
	} else {
		if (Math.abs(i[1]) > .7) return null;
		s = [Math.atan2(r[0], r[2]) * (e.size[0] / 2), r[1]];
	}
	let [c, l, u, d] = es(e, t, n), f = (s[0] - u) / c + .5, p = (s[1] - d) / l + .5;
	return f >= 0 && f <= 1 && p >= 0 && p <= 1 ? [f, p] : null;
}
function ns(e) {
	let t = [];
	return e.shapes.forEach((e, n) => {
		e.hidden || (e.label && e.kind !== "group" && e.kind !== "mesh" && t.push({
			path: [n],
			shape: e,
			label: e.label
		}), e.children?.forEach((e, r) => {
			!e.hidden && e.label && e.kind !== "mesh" && t.push({
				path: [n, r],
				shape: e,
				label: e.label
			});
		}));
	}), t.slice(0, 4);
}
var rs = /* @__PURE__ */ new Map(), is = /* @__PURE__ */ new Map(), as = /* @__PURE__ */ new Set();
function os(e) {
	return as.add(e), () => as.delete(e);
}
function ss(e, t) {
	let n = is.get(e);
	if (n) return n;
	let r = /^data:(image\/[a-z]+);base64,(.*)$/.exec(e), i = (async () => {
		if (!r || !t) return null;
		let e = atob(r[2]);
		return t(Uint8Array.from(e, (e) => e.charCodeAt(0)), r[1]).catch(() => null);
	})().then((t) => (rs.set(e, t), as.forEach((e) => e()), t));
	return is.set(e, i), i;
}
function cs(e) {
	let t = rs.get(e);
	return t === void 0 ? (ss(e, Io), null) : t;
}
async function ls(e, t = Io) {
	await Promise.all(ns(e).map(({ label: e }) => rs.has(e.picture) ? null : ss(e.picture, t)));
}
function us(e, t, n) {
	let r = Math.min(e.width - 1, Math.max(0, Math.floor(t * e.width))), i = (Math.min(e.height - 1, Math.max(0, Math.floor((1 - n) * e.height))) * e.width + r) * 4;
	return [
		e.data[i] / 255,
		e.data[i + 1] / 255,
		e.data[i + 2] / 255,
		e.data[i + 3] / 255
	];
}
//#endregion
//#region ../scene3d/src/model/effects.ts
var ds = [
	"confetti",
	"sparkles",
	"smoke",
	"flame",
	"pour"
], fs = [
	"#ff5c8a",
	"#ffd166",
	"#06d6a0",
	"#4cc9f0",
	"#a78bfa",
	"#ff9f1c"
], ps = (e, t, n, r) => typeof e == "number" && Number.isFinite(e) ? Math.min(n, Math.max(t, e)) : r;
function ms(e) {
	if (!Array.isArray(e)) return;
	let t = e.slice(0, 4).flatMap((e) => {
		if (!e || typeof e != "object") return [];
		let t = e;
		if (!ds.includes(t.kind)) return [];
		let n = Array.isArray(t.at) && t.at.length === 3 ? t.at.map((e) => ps(e, -100, 100, 0)) : [
			0,
			1,
			0
		];
		return [{
			kind: t.kind,
			at: n,
			amount: Math.round(ps(t.amount, 10, 400, 120)),
			start: ps(t.start, 0, 1, 0),
			spread: ps(t.spread, .2, 5, 1.5),
			...typeof t.color == "string" && /^#[0-9a-f]{6}$/i.test(t.color) ? { color: t.color.toLowerCase() } : {}
		}];
	});
	return t.length ? t : void 0;
}
function hs(e, t, n) {
	let r = (Math.imul(e + 1, 73856093) ^ Math.imul(t + 1, 19349663) ^ Math.imul(n + 1, 83492791)) >>> 0;
	return r = Math.imul(r ^ r >>> 13, 1274126177) >>> 0, ((r ^ r >>> 16) >>> 0) / 4294967295;
}
function gs(e, t, n) {
	let r = [];
	return (e ?? []).forEach((e, i) => {
		let a = (t - e.start) * n;
		if (!(a < 0)) for (let t = 0; t < e.amount; t++) {
			let n = (e) => hs(i, t, e);
			if (e.kind === "confetti") {
				if (a > 3.5) continue;
				let t = 2 * Math.PI * n(0), i = (.4 + n(1)) * e.spread, o = 3 + 3 * n(2), s = 1.2, c = (o + s) / 6, l = a < c ? o * a - 3 * a * a : o * c - 3 * c * c - s * (a - c), u = (1 - Math.exp(-1.5 * a)) / 1.5, d = Math.sin(a * 4 + n(3) * 6.28) * .08, f = e.at[1] + l <= 0;
				r.push({
					at: [
						e.at[0] + Math.cos(t) * i * u + d,
						Math.max(.01, e.at[1] + l),
						e.at[2] + Math.sin(t) * i * u
					],
					size: .05 + .05 * n(4),
					color: fs[Math.floor(n(5) * fs.length)],
					turn: f ? n(6) * 6.28 : a * (4 + 6 * n(6)),
					alpha: Math.min(1, (3.5 - a) / .6),
					look: "card"
				});
			} else if (e.kind === "smoke" || e.kind === "flame") {
				let t = e.kind === "flame", i = t ? .9 : 3.2, o = n(0) * i;
				if (a < o) continue;
				let s = (a - o) % i / i, c = (t ? 1.1 : .45) * e.spread * s * i, l = Math.sin((a + n(1) * 9) * (t ? 7 : 1.3)) * e.spread * (t ? .05 : .18) * s, u = 2 * Math.PI * n(2), d = e.spread * (t ? .12 : .15) * Math.sqrt(n(3));
				r.push({
					at: [
						e.at[0] + Math.cos(u) * d * (1 - s * .5) + l,
						e.at[1] + c,
						e.at[2] + Math.sin(u) * d * (1 - s * .5)
					],
					size: t ? e.spread * (.3 - .26 * s) : e.spread * (.15 + .6 * s),
					color: t ? s < .25 ? "#fff3b0" : s < .55 ? "#ffb347" : "#ff5a36" : e.color ?? "#9a9a9a",
					turn: n(4) * 6.28,
					alpha: t ? (1 - s) * .8 : Math.min(1, s * 6) * (1 - s) ** 1.5 * .45,
					look: t ? "flame" : "puff"
				});
			} else if (e.kind === "pour") {
				let t = 9.8, i = Math.sqrt(2 * Math.max(.05, e.at[1]) / t), o = i + 1.1, s = n(0) * o;
				if (a < s) continue;
				let c = (a - s) % o, l = .02 * e.spread, u, d = 1;
				if (c < i) u = [
					e.at[0] + (n(1) - .5) * l,
					e.at[1] - .5 * t * c * c,
					e.at[2] + (n(2) - .5) * l
				];
				else {
					let r = c - i, a = 2 * Math.PI * n(3), o = (.3 + .9 * n(4)) * e.spread * .6 * (1 - Math.exp(-3 * r)) / 3, s = 1.4 * n(5);
					u = [
						e.at[0] + Math.cos(a) * o,
						Math.max(.005, s * r - .5 * t * r * r),
						e.at[2] + Math.sin(a) * o
					], d = Math.max(0, 1 - r / 1.1);
				}
				r.push({
					at: u,
					size: .03 * e.spread + .02 * n(6),
					color: e.color ?? "#3fa9f5",
					turn: 0,
					alpha: d,
					look: "drop"
				});
			} else {
				let t = 2 * Math.PI * n(0), i = Math.acos(2 * n(1) - 1), o = e.spread * (.3 + .7 * Math.cbrt(n(2))), s = Math.max(0, Math.sin(2 * Math.PI * (a * (.6 + n(3)) + n(4)))) ** 3;
				if (s < .02) continue;
				r.push({
					at: [
						e.at[0] + o * Math.sin(i) * Math.cos(t),
						e.at[1] + o * Math.cos(i) * .6 + .08 * a,
						e.at[2] + o * Math.sin(i) * Math.sin(t)
					],
					size: .05 + .08 * n(5),
					color: n(6) > .5 ? "#fff6c8" : "#ffffff",
					turn: a * .5,
					alpha: s,
					look: "star"
				});
			}
		}
	}), r;
}
var _s = (e) => e.now === void 0 ? [] : gs(e.effects, e.now, e.clip ?? 4), vs = {
	exposure: 0,
	warmth: 0,
	contrast: 0,
	saturation: 1,
	glare: 0,
	fringe: 0,
	vignette: 0,
	grain: 0,
	sharpen: 0
}, ys = {
	exposure: [-2, 2],
	warmth: [-1, 1],
	contrast: [-1, 1],
	saturation: [0, 2],
	glare: [0, 1],
	fringe: [0, 1],
	vignette: [0, 1],
	grain: [0, 1],
	sharpen: [0, 1]
};
function bs(e) {
	if (!e || typeof e != "object") return;
	let t = e, n = { ...vs };
	for (let e of Object.keys(ys)) {
		let r = t[e];
		typeof r == "number" && Number.isFinite(r) && (n[e] = Math.min(ys[e][1], Math.max(ys[e][0], r)));
	}
	return xs(n) ? void 0 : n;
}
var xs = (e) => !e || Object.keys(vs).every((t) => e[t] === vs[t]), Ss = (/* @__PURE__ */ new Float32Array(256)).map((e, t) => (t / 255) ** 2.2), Cs = (e) => Math.round(Math.min(1, Math.max(0, e)) ** (1 / 2.2) * 255);
function ws(e, t, n, r) {
	let i = e.slice(), a = new Float32Array(e.length), o = (e, i, a) => {
		let [o, s] = a ? [t, n] : [n, t];
		for (let n = 0; n < s; n++) {
			let s = 0, c = (e) => a ? n * t + Math.min(o - 1, Math.max(0, e)) : Math.min(o - 1, Math.max(0, e)) * t + n;
			for (let t = -r; t <= r; t++) s += e[c(t)];
			for (let l = 0; l < o; l++) i[a ? n * t + l : l * t + n] = s / (2 * r + 1), s += e[c(l + r + 1)] - e[c(l - r)];
		}
	};
	for (let e = 0; e < 3; e++) o(i, a, !0), o(a, i, !1);
	return i;
}
function Ts(e, t, n, r, i = 1) {
	if (xs(r)) return;
	let a = t * n, o = [
		new Float32Array(a),
		new Float32Array(a),
		new Float32Array(a)
	];
	for (let t = 0; t < a; t++) for (let n = 0; n < 3; n++) o[n][t] = Ss[e[t * 4 + n]];
	let s = 2 ** r.exposure, c = [
		1 + .12 * r.warmth,
		1,
		1 - .12 * r.warmth
	];
	for (let e = 0; e < a; e++) for (let t = 0; t < 3; t++) o[t][e] = o[t][e] * s * c[t];
	if (r.glare > 0) {
		let e = Math.max(2, Math.round(Math.max(t, n) * .012));
		for (let i = 0; i < 3; i++) {
			let s = ws(o[i].map((e) => Math.max(0, e - .7)), t, n, e);
			for (let e = 0; e < a; e++) o[i][e] = o[i][e] + s[e] * r.glare * 3;
		}
	}
	if (r.sharpen > 0) for (let e = 0; e < 3; e++) {
		let i = ws(o[e], t, n, 1);
		for (let t = 0; t < a; t++) o[e][t] = o[e][t] + (o[e][t] - i[t]) * r.sharpen * 1.5;
	}
	let l = (t - 1) / 2, u = (n - 1) / 2, d = Math.hypot(l, u) || 1, f = r.fringe * Math.max(t, n) * .006, p = (e, r, i) => e[Math.min(n - 1, Math.max(0, Math.round(i))) * t + Math.min(t - 1, Math.max(0, Math.round(r)))], m = i * 2654435761 >>> 0;
	for (let i = 0; i < n; i++) for (let n = 0; n < t; n++) {
		let a = i * t + n, s = (n - l) / d, c = (i - u) / d, h = o[0][a], g = o[1][a], _ = o[2][a];
		f > 0 && (h = p(o[0], n + s * f, i + c * f), _ = p(o[2], n - s * f, i - c * f));
		let v = [
			h,
			g,
			_
		].map((e) => {
			let t = Math.min(1, Math.max(0, e)) ** (1 / 2.2);
			return Math.max(0, .5 + (t - .5) * (1 + r.contrast)) ** 2.2;
		}), y = .2126 * v[0] + .7152 * v[1] + .0722 * v[2];
		v = v.map((e) => y + (e - y) * r.saturation);
		let b = 1 - r.vignette * .75 * Math.min(1, (s * s + c * c) * 1.2) ** 1.5, x = 0;
		r.grain > 0 && (m = Math.imul(m ^ m >>> 15, 2246822507) + 2654435769 >>> 0, x = ((m >>> 8) / 16777216 - .5) * r.grain * .12);
		for (let t = 0; t < 3; t++) e[a * 4 + t] = Cs(v[t] * b + x);
	}
}
//#endregion
//#region ../scene3d/src/model/strips.ts
var Es = [
	"still",
	"turntable",
	"bounce",
	"light"
], Ds = 6e6, Os = (e, t, n, r) => typeof e == "number" && Number.isFinite(e) ? Math.min(n, Math.max(t, e)) : r, ks = (e, t) => typeof e == "string" && /^#[0-9a-f]{6}$/i.test(e) ? e.toLowerCase() : t;
function As(e) {
	if (!e || typeof e != "object") return;
	let t = e;
	if (!Array.isArray(t.strips)) return;
	let n = t.strips.slice(0, 16).flatMap((e) => {
		if (!e || typeof e != "object") return [];
		let t = e, n = Os(t.seconds, .5, 30, 3);
		if (t.kind === "clip") {
			let e = Os(t.from, 0, 1, 0);
			return [{
				kind: "clip",
				camera: Es.includes(t.camera) ? t.camera : "still",
				seconds: n,
				from: e,
				to: Os(t.to, e, 1, 1)
			}];
		}
		return t.kind === "title" ? [{
			kind: "title",
			text: typeof t.text == "string" ? t.text.slice(0, 200) : "",
			seconds: n,
			background: ks(t.background, "#111111"),
			color: ks(t.color, "#ffffff")
		}] : t.kind === "picture" && typeof t.picture == "string" && /^data:image\/(png|jpeg|webp);base64,/.test(t.picture) && t.picture.length <= Ds ? [{
			kind: "picture",
			picture: t.picture,
			seconds: n
		}] : [];
	});
	return n.length ? {
		strips: n,
		fade: Os(t.fade, 0, 1.5, .5)
	} : void 0;
}
var js = (e) => e.strips.reduce((e, t) => e + t.seconds, 0);
//#endregion
//#region ../scene3d/src/model/pen.ts
function Ms(e, t, n) {
	let [r, i, a, o] = [
		e.p,
		e.out ?? e.p,
		t.in ?? t.p,
		t.p
	];
	if (!e.out && !t.in) return [o];
	let s = [];
	for (let e = 1; e <= n; e++) {
		let t = e / n, c = 1 - t;
		s.push([c * c * c * r[0] + 3 * c * c * t * i[0] + 3 * c * t * t * a[0] + t * t * t * o[0], c * c * c * r[1] + 3 * c * c * t * i[1] + 3 * c * t * t * a[1] + t * t * t * o[1]]);
	}
	return s;
}
function Ns(e, t = 24) {
	let n = [];
	for (let r of e) {
		let e = r.nodes;
		if (e.length < 2) continue;
		let i = [e[0].p];
		for (let n = 1; n < e.length; n++) i.push(...Ms(e[n - 1], e[n], t));
		let a = Ms(e[e.length - 1], e[0], t);
		i.push(...a.slice(0, -1)), i.length >= 3 && n.push(i);
	}
	return n;
}
function Ps(e) {
	if (!Array.isArray(e)) return;
	let t = (e) => Array.isArray(e) && Number.isFinite(e[0]) && Number.isFinite(e[1]) ? [Math.min(1, Math.max(-1, e[0])), Math.min(1, Math.max(-1, e[1]))] : void 0, n = e.slice(0, 16).filter((e) => !!e && typeof e == "object").map((e) => ({
		closed: e.closed !== !1,
		nodes: (Array.isArray(e.nodes) ? e.nodes : []).slice(0, 400).map((e) => {
			let n = e && typeof e == "object" ? e : {}, r = t(n.p);
			if (!r) return null;
			let i = { p: r }, [a, o] = [t(n.in), t(n.out)];
			return a && (i.in = a), o && (i.out = o), i;
		}).filter((e) => !!e)
	})).filter((e) => e.nodes.length >= 2);
	return n.length ? n : void 0;
}
var Fs = (e) => e.map((e) => ({
	closed: !0,
	nodes: e.map((e) => ({ p: [e[0], e[1]] }))
})), Is = /* @__PURE__ */ e({
	ALL_KINDS: () => Rs,
	AXES: () => Hs,
	COMBINE: () => zs,
	FINISHES: () => Bs,
	LIGHT_KINDS: () => Us,
	LOOKS: () => Vs,
	MAX_AROUND: () => 64,
	MAX_ASSETS_CHARS: () => Zs,
	MAX_ASSET_CHARS: () => Xs,
	MAX_EXTRA_LIGHTS: () => 2,
	MAX_FIELDS: () => 16,
	MAX_GRID: () => 20,
	MAX_MESHES: () => 16,
	MAX_PICTURE_CHARS: () => Nc,
	MAX_SHAPES: () => 256,
	SHAPE_KINDS: () => Ls,
	SHAPE_LABELS: () => Qs,
	TEXT_ALIGNS: () => Ks,
	VIEWS: () => Ic,
	budget: () => dc,
	checkAssets: () => Cc,
	checkEnvironment: () => Ws,
	checkExtraLights: () => Js,
	checkFocus: () => Ys,
	checkForm: () => Gs,
	checkMirror: () => _c,
	checkModel: () => Fc,
	checkOutline: () => lc,
	checkRepeat: () => vc,
	checkRevolve: () => gc,
	checkShape: () => yc,
	createModel: () => ic,
	createShape: () => rc,
	designFile: () => Dc,
	designLosses: () => Oc,
	fieldContours: () => hc,
	fitsBudget: () => fc,
	hasOutline: () => pc,
	linearColor: () => ac,
	meshShapes: () => Ac,
	newId: () => nc,
	openDesignFile: () => kc,
	outlineFrom: () => uc,
	outlineSize: () => mc,
	pruneAssets: () => Ec,
	shapeAt: () => jc,
	steps: () => Mc,
	usedAssets: () => wc,
	usedTakes: () => Tc
}), Ls = [
	"box",
	"sphere",
	"cylinder",
	"cone",
	"torus",
	"capsule",
	"pyramid"
], Rs = [
	...Ls,
	"extrude",
	"text",
	"revolve",
	"mesh",
	"group"
], zs = [
	"add",
	"subtract",
	"intersect"
], Bs = [
	"matte",
	"satin",
	"glossy",
	"metal",
	"glass",
	"glow",
	"velvet",
	"coat"
], Vs = [
	"soft",
	"toon",
	"flat",
	"clay",
	"pixel"
], Hs = [
	"x",
	"y",
	"z"
], Us = [
	"sun",
	"point",
	"spot",
	"area"
];
function Ws(e) {
	if (!e || typeof e != "object") return;
	let t = e, n = Pc(t.picture);
	if (n) return {
		picture: n,
		strength: $(t.strength, 0, 4, 1),
		turn: $(t.turn, -180, 180, 0),
		show: t.show === !0
	};
}
function Gs(e) {
	if (!e || typeof e != "object") return;
	let t = e, n = (e, t, n) => typeof e == "number" && Number.isFinite(e) && e !== 0 ? Math.min(n, Math.max(t, e)) : void 0, r = {
		...n(t.hollow, 0, 5) ? { hollow: n(t.hollow, 0, 5) } : {},
		...n(t.twist, -720, 720) ? { twist: n(t.twist, -720, 720) } : {},
		...n(t.bend, -180, 180) ? { bend: n(t.bend, -180, 180) } : {},
		...n(t.taper, -.9, .9) ? { taper: n(t.taper, -.9, .9) } : {},
		...n(t.noise, 0, .3) ? {
			noise: n(t.noise, 0, .3),
			noiseScale: n(t.noiseScale, 1, 40) ?? 8
		} : {}
	};
	return Object.keys(r).length ? r : void 0;
}
var Ks = [
	"left",
	"center",
	"right"
], qs = (e, t) => t === void 0 ? {} : { [e]: t };
function Js(e) {
	if (!Array.isArray(e)) return;
	let t = e.slice(0, 2).map((e) => {
		let t = e && typeof e == "object" ? e : {};
		return {
			azimuth: $(t.azimuth, -180, 180, 140),
			elevation: $(t.elevation, 0, 90, 30),
			intensity: $(t.intensity, 0, 3, .8),
			color: oc(t.color, "#ffffff"),
			shadows: t.shadows === !0,
			...t.kind === "point" || t.kind === "spot" || t.kind === "area" ? {
				kind: t.kind,
				distance: $(t.distance, 1, 50, 5),
				...t.kind === "area" ? { size: $(t.size, .05, 5, .8) } : {},
				...t.kind === "spot" ? { cone: $(t.cone, 5, 170, 50) } : {}
			} : {}
		};
	});
	return t.length ? t : void 0;
}
function Ys(e) {
	if (!e || typeof e != "object") return;
	let t = e, n = $(t.blur, 0, 1, 0);
	return n > 0 ? {
		blur: n,
		offset: $(t.offset, -100, 100, 0)
	} : void 0;
}
var Xs = 64e6, Zs = 128e6, Qs = {
	box: "Box",
	sphere: "Sphere",
	cylinder: "Cylinder",
	cone: "Cone",
	torus: "Ring",
	capsule: "Capsule",
	pyramid: "Pyramid",
	extrude: "Outline",
	text: "Text",
	revolve: "Revolve",
	mesh: "Model",
	group: "Group"
}, $s = {
	box: [
		1,
		1,
		1
	],
	sphere: [
		1,
		1,
		1
	],
	cylinder: [
		.8,
		1.2,
		.8
	],
	cone: [
		1,
		1.2,
		1
	],
	torus: [
		1.2,
		.36,
		1.2
	],
	capsule: [
		.6,
		1.4,
		.6
	],
	pyramid: [
		1,
		1,
		1
	],
	extrude: [
		1,
		1,
		.35
	],
	text: [
		2,
		.6,
		.3
	],
	revolve: [
		.9,
		1.3,
		.9
	],
	mesh: [
		1,
		1,
		1
	],
	group: [
		1,
		1,
		1
	]
}, ec = [
	"#ff7ab6",
	"#a78bfa",
	"#67e8f9",
	"#fbbf24",
	"#34d399",
	"#f87171",
	"#60a5fa"
], tc = 0, nc = () => `s${Date.now().toString(36)}${(tc++).toString(36)}`;
function rc(e, t = 0, n = {}) {
	let r = $s[e];
	return {
		id: nc(),
		name: Qs[e],
		kind: e,
		position: [
			0,
			r[1] / 2,
			0
		],
		rotation: [
			0,
			0,
			0
		],
		size: [...r],
		round: e === "box" || e === "pyramid" ? .08 : e === "extrude" || e === "text" ? .05 : 0,
		thickness: .3,
		combine: "add",
		blend: 0,
		color: ec[t % ec.length],
		finish: "satin",
		hidden: !1,
		...n
	};
}
function ic() {
	return {
		version: 1,
		shapes: [rc("box", 0, { position: [
			0,
			.5,
			0
		] })],
		light: {
			azimuth: -40,
			elevation: 50,
			intensity: 1.4,
			ambient: .35,
			color: "#ffffff",
			shadows: !0
		},
		style: {
			look: "soft",
			outline: 0,
			outlineColor: "#1b1530",
			bands: 3,
			pixel: 10
		},
		background: {
			transparent: !0,
			color: "#f4f1fb",
			picture: ""
		},
		ground: {
			on: !0,
			shadow: .35
		},
		camera: {
			yaw: 30,
			pitch: 22,
			distance: 5.5,
			target: [
				0,
				.5,
				0
			],
			fov: 35,
			projection: "perspective"
		}
	};
}
var $ = (e, t, n, r) => Math.min(n, Math.max(t, typeof e == "number" && Number.isFinite(e) ? e : r)), ac = (e) => {
	let t = parseInt(e.slice(1), 16);
	return [
		((t >> 16 & 255) / 255) ** 2.2,
		((t >> 8 & 255) / 255) ** 2.2,
		((t & 255) / 255) ** 2.2
	];
}, oc = (e, t) => typeof e == "string" && /^#[0-9a-f]{6}$/i.test(e) ? e.toLowerCase() : t, sc = (e, t, n, r) => Array.isArray(e) && e.length === 3 ? [
	$(e[0], t, n, r[0]),
	$(e[1], t, n, r[1]),
	$(e[2], t, n, r[2])
] : r, cc = (e, t, n) => t.includes(e) ? e : n;
function lc(e) {
	if (!Array.isArray(e)) return;
	let t = e.slice(0, 64).filter(Array.isArray).map((e) => e.slice(0, 2e3).filter((e) => Array.isArray(e) && Number.isFinite(e[0]) && Number.isFinite(e[1])).map(([e, t]) => [Math.min(.5, Math.max(-.5, e)), Math.min(.5, Math.max(-.5, t))])).filter((e) => e.length >= 3);
	return t.length ? t : void 0;
}
function uc(e) {
	let t = Ht(e);
	return {
		outline: t.contours,
		aspect: t.aspect
	};
}
function dc(e) {
	let t = 0, n = 0, r = 0, i = (e) => {
		e.kind === "mesh" ? r += 1 : (t += 1, n += +!!e.outline);
	};
	for (let n of e) n.kind === "group" ? (t += 2, (n.children ?? []).forEach(i)) : i(n);
	return {
		slots: t,
		fields: n,
		meshes: r
	};
}
var fc = (e) => {
	let t = dc(e);
	return t.slots <= 256 && t.fields <= 16 && t.meshes <= 16;
}, pc = (e) => e === "extrude" || e === "text" || e === "revolve";
function mc(e) {
	return e.kind === "revolve" ? [Math.min(e.size[0], e.size[2]), e.size[1]] : [e.size[0], e.size[1]];
}
function hc(e) {
	return e.kind === "revolve" ? on(e.outline ?? [], e.revolve?.offset ?? 0) : e.outline ?? [];
}
function gc(e) {
	let t = e && typeof e == "object" ? e : {};
	return {
		offset: $(t.offset, 0, .9, 0),
		sweep: $(t.sweep, 10, 360, 360)
	};
}
function _c(e) {
	let t = e && typeof e == "object" ? e : {}, n = {};
	return t.x === !0 && (n.x = !0), t.z === !0 && (n.z = !0), n.x || n.z ? n : void 0;
}
function vc(e) {
	let t = e && typeof e == "object" ? e : {}, n = (e, t, n) => Math.round($(e, 1, t, n));
	if (t.kind === "grid") {
		let e = Array.isArray(t.count) ? t.count : [], r = [
			n(e[0], 20, 1),
			n(e[1], 20, 1),
			n(e[2], 20, 1)
		];
		return r.every((e) => e === 1) ? void 0 : {
			kind: "grid",
			count: r,
			spacing: sc(t.spacing, .01, 50, [
				1.2,
				1.2,
				1.2
			])
		};
	}
	if (t.kind === "around") {
		let e = n(t.count, 64, 6);
		return e < 2 ? void 0 : {
			kind: "around",
			count: e,
			axis: cc(t.axis, Hs, "y"),
			arc: $(t.arc, 10, 360, 360)
		};
	}
}
function yc(e, t = 0, n = !1) {
	let r = e && typeof e == "object" ? e : {}, i = n ? Rs.filter((e) => e !== "group") : Rs, a = cc(r.kind, i, "box"), o = lc(r.outline);
	pc(a) && !o && (a = "box");
	let s = typeof r.asset == "string" && /^[\w-]{1,40}$/.test(r.asset) ? r.asset : void 0;
	a === "mesh" && !s && (a = "box");
	let c = rc(a, t), l = r.text ?? {}, u = {};
	if (pc(a) && (u.outline = o), a === "revolve" && (u.revolve = gc(r.revolve)), a !== "group" && a !== "mesh") {
		let e = _c(r.mirror), t = vc(r.repeat);
		e && (u.mirror = e), t && (u.repeat = t);
	}
	if (a === "text" && (u.text = {
		value: typeof l.value == "string" ? l.value.slice(0, 200).split("\n").slice(0, 8).join("\n") : "Text",
		font: typeof l.font == "string" && l.font.trim() ? l.font.slice(0, 80) : "Arial",
		weight: Math.round($(l.weight, 100, 900, 700) / 100) * 100
	}, l.align !== void 0 && (u.text.align = cc(l.align, Ks, "center")), l.lineHeight !== void 0 && (u.text.lineHeight = $(l.lineHeight, .6, 3, 1.15)), l.spacing !== void 0 && (u.text.spacing = $(l.spacing, -.3, 1, 0))), a === "extrude" || a === "revolve") {
		let e = Ps(r.pen);
		e && (u.pen = e);
	}
	return a === "group" && (u.children = Array.isArray(r.children) ? r.children.slice(0, 256).map((e, n) => yc(e, t + n, !0)) : []), a === "mesh" && (u.asset = s, u.ownColors = r.ownColors !== !1), {
		id: typeof r.id == "string" && r.id ? r.id.slice(0, 40) : c.id,
		name: typeof r.name == "string" && r.name.trim() ? r.name.slice(0, 60) : c.name,
		kind: a,
		position: sc(r.position, -100, 100, c.position),
		rotation: sc(r.rotation, -360, 360, c.rotation),
		size: sc(r.size, .01, 100, c.size),
		round: $(r.round, 0, .5, c.round),
		thickness: $(r.thickness, .05, .5, c.thickness),
		combine: cc(r.combine, zs, "add"),
		blend: $(r.blend, 0, 1, 0),
		color: oc(r.color, c.color),
		finish: cc(r.finish, Bs, "satin"),
		hidden: r.hidden === !0,
		...r.locked === !0 ? { locked: !0 } : {},
		...po(r.motion) ? { motion: po(r.motion) } : {},
		...Ra(r.keys) && (a !== "group" || Ya(r.keyBase)) ? { keys: Ra(r.keys) } : {},
		...a === "group" && Ra(r.keys) && Ya(r.keyBase) ? { keyBase: Ya(r.keyBase) } : {},
		...Ni(r.triggers) ? { triggers: Ni(r.triggers) } : {},
		...a === "mesh" && r.morph && typeof r.morph == "object" && typeof r.morph.asset == "string" && /^[\w-]{1,40}$/.test(r.morph.asset) ? { morph: {
			asset: r.morph.asset,
			amount: $(r.morph.amount, 0, 1, 0)
		} } : {},
		...a === "mesh" && Vn(r.rig) ? { rig: Vn(r.rig) } : {},
		...a === "mesh" && Vn(r.rig) && xi(r.take) ? { take: xi(r.take) } : {},
		...a === "mesh" && Vn(r.rig) && Fr(r.springs) ? { springs: Fr(r.springs) } : {},
		...a === "mesh" && Vn(r.rig) && vr(r.life) ? { life: vr(r.life) } : {},
		...a === "mesh" && ca(r.nodes)?.kind === "geometry" ? { nodes: ca(r.nodes) } : {},
		...typeof r.lookAt == "string" && /^[\w-]{1,40}$/.test(r.lookAt) ? { lookAt: r.lookAt } : {},
		...r.keyPath && typeof r.keyPath == "object" && (r.keyPath.curve === !0 || r.keyPath.face === !0) ? { keyPath: {
			...r.keyPath.curve === !0 ? { curve: !0 } : {},
			...r.keyPath.face === !0 ? { face: !0 } : {}
		} } : {},
		...a !== "group" && a !== "mesh" && Gs(r.form) ? { form: Gs(r.form) } : {},
		...a !== "group" && a !== "mesh" && Qo(r.label) ? { label: Qo(r.label) } : {},
		...u
	};
}
function bc(e) {
	let t = [...e];
	for (; t.length && !fc(t);) t.pop();
	return t;
}
var xc = /* @__PURE__ */ new Set();
function Sc(e) {
	return xc.has(e) ? !0 : /^[A-Za-z0-9+/]+={0,2}$/.test(e) ? (xc.add(e), xc.size > 16 && xc.delete(xc.values().next().value), !0) : !1;
}
function Cc(e) {
	let t = {};
	if (!e || typeof e != "object") return t;
	let n = 0;
	for (let [r, i] of Object.entries(e)) {
		let e = i ?? {};
		if (!/^[\w-]{1,40}$/.test(r) || typeof e.data != "string" || !e.data || e.data.length > 64e6 || n + e.data.length > 128e6 || !Sc(e.data)) continue;
		n += e.data.length, t[r] = {
			name: typeof e.name == "string" && e.name.trim() ? e.name.slice(0, 80) : "Model",
			data: e.data,
			triangles: Math.max(0, Math.round($(e.triangles, 0, 1e8, 0))),
			size: sc(e.size, 0, 1e6, [
				1,
				1,
				1
			]),
			centre: sc(e.centre, -1e6, 1e6, [
				0,
				0,
				0
			])
		};
		let a = $e(e.character);
		a && (t[r].character = a);
	}
	return t;
}
function wc(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e) for (let e of n.kind === "group" ? n.children ?? [] : [n]) e.kind === "mesh" && e.asset && t.add(e.asset), e.kind === "mesh" && e.morph && t.add(e.morph.asset);
	return t;
}
function Tc(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e) for (let e of n.kind === "group" ? n.children ?? [] : [n]) e.take && t.add(e.take.id);
	return t;
}
function Ec(e) {
	if (!e.assets) return e;
	let t = wc(e.shapes), n = Object.fromEntries(Object.entries(e.assets).filter(([e]) => t.has(e))), r = Tc(e.shapes), i = Object.fromEntries(Object.entries(e.takes ?? {}).filter(([e]) => r.has(e))), { assets: a, takes: o, ...s } = e;
	return {
		...s,
		...Object.keys(n).length ? { assets: n } : {},
		...Object.keys(i).length ? { takes: i } : {}
	};
}
var Dc = (e) => JSON.stringify(Ec(e), null, 2) + "\n";
function Oc(e) {
	let t = e?.shapes;
	if (!Array.isArray(t)) return null;
	let n = Fc(e).shapes.length;
	return n >= t.length ? null : `This design has ${t.length} shapes and ${n} came in: a design holds 256 shapes and 16 placed models, and a model needs its file. Saving now would lose the rest, so split it into levels in the Game tab or keep the file as it is.`;
}
function kc(e) {
	let t;
	try {
		t = JSON.parse(e);
	} catch {
		throw Error("That file is not a 3D design (it is not JSON).");
	}
	if (!t || typeof t != "object" || !Array.isArray(t.shapes)) throw Error("That .json is not a 3D design (it has no shapes).");
	return Fc(t);
}
function Ac(e) {
	let t = [];
	return e.shapes.forEach((n, r) => {
		if (n.hidden) return;
		let i = n.kind === "group" ? (n.children ?? []).map((e, t) => [e, [r, t]]) : [[n, [r]]];
		for (let [n, r] of i) {
			let i = n.kind === "mesh" && !n.hidden && n.asset ? e.assets?.[n.asset] : void 0;
			i && t.push({
				shape: n,
				path: r,
				asset: i
			});
		}
	}), t;
}
function jc(e, t) {
	if (!t) return;
	let n = e.shapes[t[0]];
	return t.length === 1 ? n : n?.children?.[t[1]];
}
function Mc(e) {
	let t = [];
	return e.shapes.forEach((e, n) => {
		if (e.hidden || e.kind === "mesh") return;
		if (e.kind !== "group") return void t.push({
			op: "shape",
			shape: e,
			path: [n]
		});
		let r = (e.children ?? []).map((e, t) => ({
			c: e,
			j: t
		})).filter(({ c: e }) => !e.hidden && e.kind !== "mesh");
		if (r.length) {
			t.push({
				op: "begin",
				group: e,
				path: [n]
			});
			for (let { c: e, j: i } of r) t.push({
				op: "shape",
				shape: e,
				path: [n, i]
			});
			t.push({
				op: "end",
				group: e,
				path: [n]
			});
		}
	}), t;
}
var Nc = 12e6, Pc = (e) => typeof e == "string" && e.length <= 12e6 && /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+=*$/.test(e) ? e : "";
function Fc(e) {
	let t = ic(), n = e && typeof e == "object" ? e : {}, r = n.light ?? {}, i = n.style ?? {}, a = n.background ?? {}, o = n.ground ?? {}, s = n.camera ?? {}, c = Cc(n.assets), l = (e) => e.kind !== "mesh" || e.asset !== void 0 && e.asset in c, u = Array.isArray(n.shapes) ? bc(n.shapes.slice(0, 256).map((e, t) => yc(e, t)).filter(l).map((e) => e.kind === "group" ? {
		...e,
		children: (e.children ?? []).filter(l)
	} : e)) : t.shapes, d = wc(u), f = Object.fromEntries(Object.entries(c).filter(([e]) => d.has(e))), p = bi(n.takes);
	return {
		version: 1,
		shapes: u,
		...Object.keys(f).length ? { assets: f } : {},
		...p ? { takes: p } : {},
		...yi(n.cameraTake) ? { cameraTake: yi(n.cameraTake) } : {},
		...$r(n.music) ? { music: $r(n.music) } : {},
		light: {
			azimuth: $(r.azimuth, -180, 180, t.light.azimuth),
			elevation: $(r.elevation, 0, 90, t.light.elevation),
			intensity: $(r.intensity, 0, 3, t.light.intensity),
			ambient: $(r.ambient, 0, 1, t.light.ambient),
			color: oc(r.color, t.light.color),
			shadows: r.shadows !== !1,
			...qs("extra", Js(r.extra))
		},
		style: {
			look: cc(i.look, Vs, t.style.look),
			outline: $(i.outline, 0, 12, t.style.outline),
			outlineColor: oc(i.outlineColor, t.style.outlineColor),
			bands: Math.round($(i.bands, 2, 6, t.style.bands)),
			pixel: Math.round($(i.pixel, 3, 40, t.style.pixel))
		},
		background: {
			transparent: a.transparent !== !1,
			color: oc(a.color, t.background.color),
			picture: Pc(a.picture)
		},
		ground: {
			on: o.on !== !1,
			shadow: $(o.shadow, 0, 1, t.ground.shadow)
		},
		camera: {
			yaw: $(s.yaw, -360, 360, t.camera.yaw),
			pitch: $(s.pitch, -89, 89, t.camera.pitch),
			distance: $(s.distance, .5, 200, t.camera.distance),
			target: sc(s.target, -100, 100, t.camera.target),
			fov: $(s.fov, 10, 90, t.camera.fov),
			projection: cc(s.projection, ["perspective", "orthographic"], "perspective"),
			...qs("focus", Ys(s.focus))
		},
		...no(n.cameraKeys) ? { cameraKeys: no(n.cameraKeys) } : {},
		...typeof n.clip == "number" && Number.isFinite(n.clip) ? { clip: Math.min(600, Math.max(1, n.clip)) } : {},
		...Ws(n.environment) ? { environment: Ws(n.environment) } : {},
		...ms(n.effects) ? { effects: ms(n.effects) } : {},
		...bs(n.compose) ? { compose: bs(n.compose) } : {},
		...As(n.sequence) ? { sequence: As(n.sequence) } : {},
		...na(n.game) ? { game: na(n.game) } : {}
	};
}
var Ic = {
	front: {
		yaw: 0,
		pitch: 0,
		projection: "orthographic"
	},
	side: {
		yaw: 90,
		pitch: 0,
		projection: "orthographic"
	},
	left: {
		yaw: -90,
		pitch: 0,
		projection: "orthographic"
	},
	back: {
		yaw: 180,
		pitch: 0,
		projection: "orthographic"
	},
	top: {
		yaw: 0,
		pitch: 89,
		projection: "orthographic"
	},
	bottom: {
		yaw: 0,
		pitch: -89,
		projection: "orthographic"
	},
	isometric: {
		yaw: 45,
		pitch: 35.264,
		projection: "orthographic"
	},
	"isometric-left": {
		yaw: -45,
		pitch: 35.264,
		projection: "orthographic"
	},
	"isometric-below": {
		yaw: 45,
		pitch: -35.264,
		projection: "orthographic"
	},
	"isometric-below-left": {
		yaw: -45,
		pitch: -35.264,
		projection: "orthographic"
	},
	perspective: {
		yaw: 30,
		pitch: 22,
		projection: "perspective"
	}
};
//#endregion
export { xs as $, he as $i, $r as $n, hn as $r, Wa as $t, Is as A, Ot as Ai, Wi as An, J as Ar, Eo as At, Ec as B, Ke as Bi, xi as Bn, Mn as Br, so as Bt, vc as C, Et as Ci, Fi as Cn, Rn as Cr, Fo as Ct, rc as D, Ye as Di, Li as Dn, Vn as Dr, ko as Dt, ic as E, Je as Ei, Ui as En, Gn as Er, co as Et, Ac as F, $e as Fi, Ni as Fn, qn as Fr, Ma as Ft, Ps as G, ft as Gi, Oi as Gn, gn as Gr, Ua as Gt, Mc as H, Rt as Hi, Ei as Hn, Dn as Hr, Ya as Ht, nc as I, xt as Ii, Pi as In, rr as Ir, ja as It, As as J, ct as Ji, si as Jn, Ln as Jr, qa as Jt, Ns as K, mt as Ki, ki as Kn, _n as Kr, Ga as Kt, kc as L, st as Li, ri as Ln, nr as Lr, Pa as Lt, fc as M, kt as Mi, Mi as Mn, Xn as Mr, So as Mt, pc as N, Dt as Ni, ji as Nn, tr as Nr, wo as Nt, Dc as O, Xe as Oi, na as On, Wn as Or, po as Ot, ac as P, Lt as Pi, Ai as Pn, ar as Pr, Oo as Pt, Ts as Q, ve as Qi, Qr as Qn, un as Qr, oo as Qt, uc as R, ot as Ri, ci as Rn, ir as Rr, io as Rt, lc as S, Tt as Si, zi as Sn, hr as Sr, No as St, yc as T, tt as Ti, Hi as Tn, $n as Tr, lo as Tt, wc as U, lt as Ui, ai as Un, On as Ur, Ra as Ut, jc as V, Vt as Vi, bi as Vn, kn as Vr, no as Vt, Tc as W, St as Wi, Di as Wn, En as Wr, to as Wt, vs as X, pe as Xi, di as Xn, Fn as Xr, Ja as Xt, js as Y, _e as Yi, gi as Yn, G as Yr, Ka as Yt, bs as Z, me as Zi, pi as Zn, In as Zr, Na as Zt, Js as _, l as _a, qe as _i, sa as _n, Ar as _r, qo as _t, Us as a, k as aa, en as ai, wa as an, Xr as ar, Yo as at, _c as b, Be as bi, Bi as bn, _r as br, jo as bt, Xs as c, O as ca, Wt as ci, xa as cn, Zr as cr, Qo as ct, Qs as d, ce as da, on as di, la as dn, vr as dr, us as dt, ge as ea, bn as ei, Ea as en, ti as er, ds as et, Ks as f, L as fa, $t as fi, ca as fn, Or as fr, ts as ft, Ws as g, c as ga, Ge as gi, ga as gn, kr as gr, Io as gt, Cc as h, d as ha, We as hi, ma as hn, Nr as hr, ls as ht, Bs as i, Le as ia, ln as ii, Oa as in, Fr as ir, Jo as it, hc as j, It as ji, Vi as jn, Hn as jr, Ao as jt, Oc as k, it as ki, ra as kn, er as kr, vo as kt, Nc as l, P as la, Yt as li, ia as ln, Pr as lr, cs as lt, dc as m, u as ma, Qt as mi, pa as mn, Cr as mr, os as mt, Hs as n, Pe as na, yn as ni, Aa as nn, Kr as nr, gs as nt, Vs as o, A as oa, qt as oi, ba as on, Rr as or, Xo as ot, Ic as p, ee as pa, rn as pi, _a as pn, Dr as pr, ns as pt, Fs as q, Ct as qi, _i as qn, An as qr, Va as qt, zs as r, Ie as ra, nn as ri, ka as rn, Br as rr, _s as rt, Zs as s, D as sa, Ht as si, Da as sn, Jr as sr, $o as st, Rs as t, ye as ta, fn as ti, ya as tn, ei as tr, ms as tt, Ls as u, N as ua, Jt as ui, aa as un, jr as ur, es as ut, Ys as v, m as va, Ze as vi, oa as vn, gr as vr, Ro as vt, gc as w, et as wi, Ii as wn, Yn as wr, uo as wt, Fc as x, Ve as xi, Ri as xn, mr as xr, Mo as xt, Gs as y, C as ya, Qe as yi, va as yn, or as yr, Ko as yt, mc as z, zt as zi, yi as zn, jn as zr, ao as zt };

//# sourceMappingURL=document-CNMOilB9.js.map