import { n as e } from "./rolldown-runtime-DArdT4gl.js";
//#region ../../node_modules/three/examples/jsm/libs/fflate.module.js
var t = /* @__PURE__ */ e({
	AsyncCompress: () => Ne,
	AsyncDecompress: () => Ye,
	AsyncDeflate: () => Ee,
	AsyncGunzip: () => Le,
	AsyncGzip: () => Ne,
	AsyncInflate: () => ke,
	AsyncUnzipInflate: () => St,
	AsyncUnzlib: () => Ge,
	AsyncZipDeflate: () => gt,
	AsyncZlib: () => Ve,
	Compress: () => Me,
	DecodeUTF8: () => rt,
	Decompress: () => Je,
	Deflate: () => Te,
	EncodeUTF8: () => it,
	FlateErrorCode: () => D,
	Gunzip: () => Ie,
	Gzip: () => Me,
	Inflate: () => $,
	Unzip: () => Ct,
	UnzipInflate: () => xt,
	UnzipPassThrough: () => bt,
	Unzlib: () => We,
	Zip: () => _t,
	ZipDeflate: () => ht,
	ZipPassThrough: () => mt,
	Zlib: () => Be,
	compress: () => Pe,
	compressSync: () => Fe,
	decompress: () => Xe,
	decompressSync: () => Ze,
	deflate: () => De,
	deflateSync: () => Oe,
	gunzip: () => Re,
	gunzipSync: () => ze,
	gzip: () => Pe,
	gzipSync: () => Fe,
	inflate: () => Ae,
	inflateSync: () => je,
	strFromU8: () => ot,
	strToU8: () => at,
	unzip: () => Tt,
	unzipSync: () => Et,
	unzlib: () => Ke,
	unzlibSync: () => qe,
	zip: () => vt,
	zipSync: () => yt,
	zlib: () => He,
	zlibSync: () => Ue
}), n = {}, r = (function(e, t, r, i, a) {
	var o = new Worker(n[t] || (n[t] = URL.createObjectURL(new Blob([e + ";addEventListener(\"error\",function(e){e=e.error;postMessage({$e$:[e.message,e.code,e.stack]})})"], { type: "text/javascript" }))));
	return o.onmessage = function(e) {
		var t = e.data, n = t.$e$;
		if (n) {
			var r = Error(n[0]);
			r.code = n[1], r.stack = n[2], a(r, null);
		} else a(null, t);
	}, o.postMessage(r, i), o;
}), i = Uint8Array, a = Uint16Array, o = Int32Array, s = new i([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0,
	0,
	0,
	0
]), c = new i([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13,
	0,
	0
]), l = new i([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]), u = function(e, t) {
	for (var n = new a(31), r = 0; r < 31; ++r) n[r] = t += 1 << e[r - 1];
	for (var i = new o(n[30]), r = 1; r < 30; ++r) for (var s = n[r]; s < n[r + 1]; ++s) i[s] = s - n[r] << 5 | r;
	return {
		b: n,
		r: i
	};
}, d = u(s, 2), f = d.b, p = d.r;
f[28] = 258, p[258] = 28;
for (var m = u(c, 0), h = m.b, g = m.r, _ = new a(32768), v = 0; v < 32768; ++v) {
	var y = (v & 43690) >> 1 | (v & 21845) << 1;
	y = (y & 52428) >> 2 | (y & 13107) << 2, y = (y & 61680) >> 4 | (y & 3855) << 4, _[v] = ((y & 65280) >> 8 | (y & 255) << 8) >> 1;
}
for (var b = (function(e, t, n) {
	for (var r = e.length, i = 0, o = new a(t); i < r; ++i) e[i] && ++o[e[i] - 1];
	var s = new a(t);
	for (i = 1; i < t; ++i) s[i] = s[i - 1] + o[i - 1] << 1;
	var c;
	if (n) {
		c = new a(1 << t);
		var l = 15 - t;
		for (i = 0; i < r; ++i) if (e[i]) for (var u = i << 4 | e[i], d = t - e[i], f = s[e[i] - 1]++ << d, p = f | (1 << d) - 1; f <= p; ++f) c[_[f] >> l] = u;
	} else for (c = new a(r), i = 0; i < r; ++i) e[i] && (c[i] = _[s[e[i] - 1]++] >> 15 - e[i]);
	return c;
}), x = new i(288), v = 0; v < 144; ++v) x[v] = 8;
for (var v = 144; v < 256; ++v) x[v] = 9;
for (var v = 256; v < 280; ++v) x[v] = 7;
for (var v = 280; v < 288; ++v) x[v] = 8;
for (var S = new i(32), v = 0; v < 32; ++v) S[v] = 5;
var C = /*#__PURE__*/ b(x, 9, 0), w = /*#__PURE__*/ b(x, 9, 1), ee = /*#__PURE__*/ b(S, 5, 0), te = /*#__PURE__*/ b(S, 5, 1), ne = function(e) {
	for (var t = e[0], n = 1; n < e.length; ++n) e[n] > t && (t = e[n]);
	return t;
}, T = function(e, t, n) {
	var r = t / 8 | 0;
	return (e[r] | e[r + 1] << 8) >> (t & 7) & n;
}, re = function(e, t) {
	var n = t / 8 | 0;
	return (e[n] | e[n + 1] << 8 | e[n + 2] << 16) >> (t & 7);
}, ie = function(e) {
	return (e + 7) / 8 | 0;
}, E = function(e, t, n) {
	return (t == null || t < 0) && (t = 0), (n == null || n > e.length) && (n = e.length), new i(e.subarray(t, n));
}, D = {
	UnexpectedEOF: 0,
	InvalidBlockType: 1,
	InvalidLengthLiteral: 2,
	InvalidDistance: 3,
	StreamFinished: 4,
	NoStreamHandler: 5,
	InvalidHeader: 6,
	NoCallback: 7,
	InvalidUTF8: 8,
	ExtraFieldTooLong: 9,
	InvalidDate: 10,
	FilenameTooLong: 11,
	StreamFinishing: 12,
	InvalidZipData: 13,
	UnknownCompressionMethod: 14
}, O = [
	"unexpected EOF",
	"invalid block type",
	"invalid length/literal",
	"invalid distance",
	"stream finished",
	"no stream handler",
	,
	"no callback",
	"invalid UTF-8 data",
	"extra field too long",
	"date not in range 1980-2099",
	"filename too long",
	"stream finishing",
	"invalid zip data"
], k = function(e, t, n) {
	var r = Error(t || O[e]);
	if (r.code = e, Error.captureStackTrace && Error.captureStackTrace(r, k), !n) throw r;
	return r;
}, A = function(e, t, n, r) {
	var a = e.length, o = r ? r.length : 0;
	if (!a || t.f && !t.l) return n || new i(0);
	var u = !n, d = u || t.i != 2, p = t.i;
	u && (n = new i(a * 3));
	var m = function(e) {
		var t = n.length;
		if (e > t) {
			var r = new i(Math.max(t * 2, e));
			r.set(n), n = r;
		}
	}, g = t.f || 0, _ = t.p || 0, v = t.b || 0, y = t.l, x = t.d, S = t.m, C = t.n, ee = a * 8;
	do {
		if (!y) {
			g = T(e, _, 1);
			var D = T(e, _ + 1, 3);
			if (_ += 3, !D) {
				var O = ie(_) + 4, A = e[O - 4] | e[O - 3] << 8, j = O + A;
				if (j > a) {
					p && k(0);
					break;
				}
				d && m(v + A), n.set(e.subarray(O, j), v), t.b = v += A, t.p = _ = j * 8, t.f = g;
				continue;
			}
			if (D == 1) y = w, x = te, S = 9, C = 5;
			else if (D == 2) {
				var M = T(e, _, 31) + 257, ae = T(e, _ + 10, 15) + 4, N = M + T(e, _ + 5, 31) + 1;
				_ += 14;
				for (var P = new i(N), F = new i(19), I = 0; I < ae; ++I) F[l[I]] = T(e, _ + I * 3, 7);
				_ += ae * 3;
				for (var L = ne(F), oe = (1 << L) - 1, R = b(F, L, 1), I = 0; I < N;) {
					var z = R[T(e, _, oe)];
					_ += z & 15;
					var O = z >> 4;
					if (O < 16) P[I++] = O;
					else {
						var B = 0, V = 0;
						for (O == 16 ? (V = 3 + T(e, _, 3), _ += 2, B = P[I - 1]) : O == 17 ? (V = 3 + T(e, _, 7), _ += 3) : O == 18 && (V = 11 + T(e, _, 127), _ += 7); V--;) P[I++] = B;
					}
				}
				var H = P.subarray(0, M), U = P.subarray(M);
				S = ne(H), C = ne(U), y = b(H, S, 1), x = b(U, C, 1);
			} else k(1);
			if (_ > ee) {
				p && k(0);
				break;
			}
		}
		d && m(v + 131072);
		for (var se = (1 << S) - 1, ce = (1 << C) - 1, W = _;; W = _) {
			var B = y[re(e, _) & se], G = B >> 4;
			if (_ += B & 15, _ > ee) {
				p && k(0);
				break;
			}
			if (B || k(2), G < 256) n[v++] = G;
			else if (G == 256) {
				W = _, y = null;
				break;
			} else {
				var K = G - 254;
				if (G > 264) {
					var I = G - 257, q = s[I];
					K = T(e, _, (1 << q) - 1) + f[I], _ += q;
				}
				var J = x[re(e, _) & ce], le = J >> 4;
				J || k(3), _ += J & 15;
				var U = h[le];
				if (le > 3) {
					var q = c[le];
					U += re(e, _) & (1 << q) - 1, _ += q;
				}
				if (_ > ee) {
					p && k(0);
					break;
				}
				d && m(v + 131072);
				var ue = v + K;
				if (v < U) {
					var de = o - U, fe = Math.min(U, ue);
					for (de + v < 0 && k(3); v < fe; ++v) n[v] = r[de + v];
				}
				for (; v < ue; ++v) n[v] = n[v - U];
			}
		}
		t.l = y, t.p = W, t.b = v, t.f = g, y && (g = 1, t.m = S, t.d = x, t.n = C);
	} while (!g);
	return v != n.length && u ? E(n, 0, v) : n.subarray(0, v);
}, j = function(e, t, n) {
	n <<= t & 7;
	var r = t / 8 | 0;
	e[r] |= n, e[r + 1] |= n >> 8;
}, M = function(e, t, n) {
	n <<= t & 7;
	var r = t / 8 | 0;
	e[r] |= n, e[r + 1] |= n >> 8, e[r + 2] |= n >> 16;
}, ae = function(e, t) {
	for (var n = [], r = 0; r < e.length; ++r) e[r] && n.push({
		s: r,
		f: e[r]
	});
	var o = n.length, s = n.slice();
	if (!o) return {
		t: R,
		l: 0
	};
	if (o == 1) {
		var c = new i(n[0].s + 1);
		return c[n[0].s] = 1, {
			t: c,
			l: 1
		};
	}
	n.sort(function(e, t) {
		return e.f - t.f;
	}), n.push({
		s: -1,
		f: 25001
	});
	var l = n[0], u = n[1], d = 0, f = 1, p = 2;
	for (n[0] = {
		s: -1,
		f: l.f + u.f,
		l,
		r: u
	}; f != o - 1;) l = n[n[d].f < n[p].f ? d++ : p++], u = n[d != f && n[d].f < n[p].f ? d++ : p++], n[f++] = {
		s: -1,
		f: l.f + u.f,
		l,
		r: u
	};
	for (var m = s[0].s, r = 1; r < o; ++r) s[r].s > m && (m = s[r].s);
	var h = new a(m + 1), g = N(n[f - 1], h, 0);
	if (g > t) {
		var r = 0, _ = 0, v = g - t, y = 1 << v;
		for (s.sort(function(e, t) {
			return h[t.s] - h[e.s] || e.f - t.f;
		}); r < o; ++r) {
			var b = s[r].s;
			if (h[b] > t) _ += y - (1 << g - h[b]), h[b] = t;
			else break;
		}
		for (_ >>= v; _ > 0;) {
			var x = s[r].s;
			h[x] < t ? _ -= 1 << t - h[x]++ - 1 : ++r;
		}
		for (; r >= 0 && _; --r) {
			var S = s[r].s;
			h[S] == t && (--h[S], ++_);
		}
		g = t;
	}
	return {
		t: new i(h),
		l: g
	};
}, N = function(e, t, n) {
	return e.s == -1 ? Math.max(N(e.l, t, n + 1), N(e.r, t, n + 1)) : t[e.s] = n;
}, P = function(e) {
	for (var t = e.length; t && !e[--t];);
	for (var n = new a(++t), r = 0, i = e[0], o = 1, s = function(e) {
		n[r++] = e;
	}, c = 1; c <= t; ++c) if (e[c] == i && c != t) ++o;
	else {
		if (!i && o > 2) {
			for (; o > 138; o -= 138) s(32754);
			o > 2 && (s(o > 10 ? o - 11 << 5 | 28690 : o - 3 << 5 | 12305), o = 0);
		} else if (o > 3) {
			for (s(i), --o; o > 6; o -= 6) s(8304);
			o > 2 && (s(o - 3 << 5 | 8208), o = 0);
		}
		for (; o--;) s(i);
		o = 1, i = e[c];
	}
	return {
		c: n.subarray(0, r),
		n: t
	};
}, F = function(e, t) {
	for (var n = 0, r = 0; r < t.length; ++r) n += e[r] * t[r];
	return n;
}, I = function(e, t, n) {
	var r = n.length, i = ie(t + 2);
	e[i] = r & 255, e[i + 1] = r >> 8, e[i + 2] = e[i] ^ 255, e[i + 3] = e[i + 1] ^ 255;
	for (var a = 0; a < r; ++a) e[i + a + 4] = n[a];
	return (i + 4 + r) * 8;
}, L = function(e, t, n, r, i, o, u, d, f, p, m) {
	j(t, m++, n), ++i[256];
	for (var h = ae(i, 15), g = h.t, _ = h.l, v = ae(o, 15), y = v.t, w = v.l, te = P(g), ne = te.c, T = te.n, re = P(y), ie = re.c, E = re.n, D = new a(19), O = 0; O < ne.length; ++O) ++D[ne[O] & 31];
	for (var O = 0; O < ie.length; ++O) ++D[ie[O] & 31];
	for (var k = ae(D, 7), A = k.t, N = k.l, L = 19; L > 4 && !A[l[L - 1]]; --L);
	var oe = p + 5 << 3, R = F(i, x) + F(o, S) + u, z = F(i, g) + F(o, y) + u + 14 + 3 * L + F(D, A) + 2 * D[16] + 3 * D[17] + 7 * D[18];
	if (f >= 0 && oe <= R && oe <= z) return I(t, m, e.subarray(f, f + p));
	var B, V, H, U;
	if (j(t, m, 1 + (z < R)), m += 2, z < R) {
		B = b(g, _, 0), V = g, H = b(y, w, 0), U = y;
		var se = b(A, N, 0);
		j(t, m, T - 257), j(t, m + 5, E - 1), j(t, m + 10, L - 4), m += 14;
		for (var O = 0; O < L; ++O) j(t, m + 3 * O, A[l[O]]);
		m += 3 * L;
		for (var ce = [ne, ie], W = 0; W < 2; ++W) for (var G = ce[W], O = 0; O < G.length; ++O) {
			var K = G[O] & 31;
			j(t, m, se[K]), m += A[K], K > 15 && (j(t, m, G[O] >> 5 & 127), m += G[O] >> 12);
		}
	} else B = C, V = x, H = ee, U = S;
	for (var O = 0; O < d; ++O) {
		var q = r[O];
		if (q > 255) {
			var K = q >> 18 & 31;
			M(t, m, B[K + 257]), m += V[K + 257], K > 7 && (j(t, m, q >> 23 & 31), m += s[K]);
			var J = q & 31;
			M(t, m, H[J]), m += U[J], J > 3 && (M(t, m, q >> 5 & 8191), m += c[J]);
		} else M(t, m, B[q]), m += V[q];
	}
	return M(t, m, B[256]), m + V[256];
}, oe = /*#__PURE__*/ new o([
	65540,
	131080,
	131088,
	131104,
	262176,
	1048704,
	1048832,
	2114560,
	2117632
]), R = /*#__PURE__*/ new i(0), z = function(e, t, n, r, l, u) {
	var d = u.z || e.length, f = new i(r + d + 5 * (1 + Math.ceil(d / 7e3)) + l), m = f.subarray(r, f.length - l), h = u.l, _ = (u.r || 0) & 7;
	if (t) {
		_ && (m[0] = u.r >> 3);
		for (var v = oe[t - 1], y = v >> 13, b = v & 8191, x = (1 << n) - 1, S = u.p || new a(32768), C = u.h || new a(x + 1), w = Math.ceil(n / 3), ee = 2 * w, te = function(t) {
			return (e[t] ^ e[t + 1] << w ^ e[t + 2] << ee) & x;
		}, ne = new o(25e3), T = new a(288), re = new a(32), D = 0, O = 0, k = u.i || 0, A = 0, j = u.w || 0, M = 0; k + 2 < d; ++k) {
			var ae = te(k), N = k & 32767, P = C[ae];
			if (S[N] = P, C[ae] = N, j <= k) {
				var F = d - k;
				if ((D > 7e3 || A > 24576) && (F > 423 || !h)) {
					_ = L(e, m, 0, ne, T, re, O, A, M, k - M, _), A = D = O = 0, M = k;
					for (var R = 0; R < 286; ++R) T[R] = 0;
					for (var R = 0; R < 30; ++R) re[R] = 0;
				}
				var z = 2, B = 0, V = b, H = N - P & 32767;
				if (F > 2 && ae == te(k - H)) for (var U = Math.min(y, F) - 1, se = Math.min(32767, k), ce = Math.min(258, F); H <= se && --V && N != P;) {
					if (e[k + z] == e[k + z - H]) {
						for (var W = 0; W < ce && e[k + W] == e[k + W - H]; ++W);
						if (W > z) {
							if (z = W, B = H, W > U) break;
							for (var G = Math.min(H, W - 2), K = 0, R = 0; R < G; ++R) {
								var q = k - H + R & 32767, J = q - S[q] & 32767;
								J > K && (K = J, P = q);
							}
						}
					}
					N = P, P = S[N], H += N - P & 32767;
				}
				if (B) {
					ne[A++] = 268435456 | p[z] << 18 | g[B];
					var le = p[z] & 31, ue = g[B] & 31;
					O += s[le] + c[ue], ++T[257 + le], ++re[ue], j = k + z, ++D;
				} else ne[A++] = e[k], ++T[e[k]];
			}
		}
		for (k = Math.max(k, j); k < d; ++k) ne[A++] = e[k], ++T[e[k]];
		_ = L(e, m, h, ne, T, re, O, A, M, k - M, _), h || (u.r = _ & 7 | m[_ / 8 | 0] << 3, _ -= 7, u.h = C, u.p = S, u.i = k, u.w = j);
	} else {
		for (var k = u.w || 0; k < d + h; k += 65535) {
			var de = k + 65535;
			de >= d && (m[_ / 8 | 0] = h, de = d), _ = I(m, _ + 1, e.subarray(k, de));
		}
		u.i = d;
	}
	return E(f, 0, r + ie(_) + l);
}, B = /*#__PURE__*/ (function() {
	for (var e = /* @__PURE__ */ new Int32Array(256), t = 0; t < 256; ++t) {
		for (var n = t, r = 9; --r;) n = (n & 1 && -306674912) ^ n >>> 1;
		e[t] = n;
	}
	return e;
})(), V = function() {
	var e = -1;
	return {
		p: function(t) {
			for (var n = e, r = 0; r < t.length; ++r) n = B[n & 255 ^ t[r]] ^ n >>> 8;
			e = n;
		},
		d: function() {
			return ~e;
		}
	};
}, H = function() {
	var e = 1, t = 0;
	return {
		p: function(n) {
			for (var r = e, i = t, a = n.length | 0, o = 0; o != a;) {
				for (var s = Math.min(o + 2655, a); o < s; ++o) i += r += n[o];
				r = (r & 65535) + 15 * (r >> 16), i = (i & 65535) + 15 * (i >> 16);
			}
			e = r, t = i;
		},
		d: function() {
			return e %= 65521, t %= 65521, (e & 255) << 24 | (e & 65280) << 8 | (t & 255) << 8 | t >> 8;
		}
	};
}, U = function(e, t, n, r, a) {
	if (!a && (a = { l: 1 }, t.dictionary)) {
		var o = t.dictionary.subarray(-32768), s = new i(o.length + e.length);
		s.set(o), s.set(e, o.length), e = s, a.w = o.length;
	}
	return z(e, t.level == null ? 6 : t.level, t.mem == null ? a.l ? Math.ceil(Math.max(8, Math.min(13, Math.log(e.length))) * 1.5) : 20 : 12 + t.mem, n, r, a);
}, se = function(e, t) {
	var n = {};
	for (var r in e) n[r] = e[r];
	for (var r in t) n[r] = t[r];
	return n;
}, ce = function(e, t, n) {
	for (var r = e(), i = e.toString(), a = i.slice(i.indexOf("[") + 1, i.lastIndexOf("]")).replace(/\s+/g, "").split(","), o = 0; o < r.length; ++o) {
		var s = r[o], c = a[o];
		if (typeof s == "function") {
			t += ";" + c + "=";
			var l = s.toString();
			if (s.prototype) {
				if (l.indexOf("[native code]") != -1) {
					var u = l.indexOf(" ", 8) + 1;
					t += l.slice(u, l.indexOf("(", u));
				} else for (var d in t += l, s.prototype) t += ";" + c + ".prototype." + d + "=" + s.prototype[d].toString();
			} else t += l;
		} else n[c] = s;
	}
	return t;
}, W = [], G = function(e) {
	var t = [];
	for (var n in e) e[n].buffer && t.push((e[n] = new e[n].constructor(e[n])).buffer);
	return t;
}, K = function(e, t, n, i) {
	if (!W[n]) {
		for (var a = "", o = {}, s = e.length - 1, c = 0; c < s; ++c) a = ce(e[c], a, o);
		W[n] = {
			c: ce(e[s], a, o),
			e: o
		};
	}
	var l = se({}, W[n].e);
	return r(W[n].c + ";onmessage=function(e){for(var k in e.data)self[k]=e.data[k];onmessage=" + t.toString() + "}", n, l, G(l), i);
}, q = function() {
	return [
		i,
		a,
		o,
		s,
		c,
		l,
		f,
		h,
		w,
		te,
		_,
		O,
		b,
		ne,
		T,
		re,
		ie,
		E,
		k,
		A,
		je,
		pe,
		me
	];
}, J = function() {
	return [
		i,
		a,
		o,
		s,
		c,
		l,
		p,
		g,
		C,
		x,
		ee,
		S,
		_,
		oe,
		R,
		b,
		j,
		M,
		ae,
		N,
		P,
		F,
		I,
		L,
		ie,
		E,
		z,
		U,
		Oe,
		pe
	];
}, le = function() {
	return [
		ve,
		xe,
		Q,
		V,
		B
	];
}, ue = function() {
	return [ye, be];
}, de = function() {
	return [
		Se,
		Q,
		H
	];
}, fe = function() {
	return [Ce];
}, pe = function(e) {
	return postMessage(e, [e.buffer]);
}, me = function(e) {
	return e && {
		out: e.size && new i(e.size),
		dictionary: e.dictionary
	};
}, he = function(e, t, n, r, i, a) {
	var o = K(n, r, i, function(e, t) {
		o.terminate(), a(e, t);
	});
	return o.postMessage([e, t], t.consume ? [e.buffer] : []), function() {
		o.terminate();
	};
}, Y = function(e) {
	return e.ondata = function(e, t) {
		return postMessage([e, t], [e.buffer]);
	}, function(t) {
		t.data.length ? (e.push(t.data[0], t.data[1]), postMessage([t.data[0].length])) : e.flush();
	};
}, ge = function(e, t, n, r, i, a, o) {
	var s, c = K(e, r, i, function(e, n) {
		e ? (c.terminate(), t.ondata.call(t, e)) : Array.isArray(n) ? n.length == 1 ? (t.queuedSize -= n[0], t.ondrain && t.ondrain(n[0])) : (n[1] && c.terminate(), t.ondata.call(t, e, n[0], n[1])) : o(n);
	});
	c.postMessage(n), t.queuedSize = 0, t.push = function(e, n) {
		t.ondata || k(5), s && t.ondata(k(4, 0, 1), null, !!n), t.queuedSize += e.length, c.postMessage([e, s = n], [e.buffer]);
	}, t.terminate = function() {
		c.terminate();
	}, a && (t.flush = function() {
		c.postMessage([]);
	});
}, X = function(e, t) {
	return e[t] | e[t + 1] << 8;
}, Z = function(e, t) {
	return (e[t] | e[t + 1] << 8 | e[t + 2] << 16 | e[t + 3] << 24) >>> 0;
}, _e = function(e, t) {
	return Z(e, t) + Z(e, t + 4) * 4294967296;
}, Q = function(e, t, n) {
	for (; n; ++t) e[t] = n, n >>>= 8;
}, ve = function(e, t) {
	var n = t.filename;
	if (e[0] = 31, e[1] = 139, e[2] = 8, e[8] = t.level < 2 ? 4 : t.level == 9 ? 2 : 0, e[9] = 3, t.mtime != 0 && Q(e, 4, Math.floor(new Date(t.mtime || Date.now()) / 1e3)), n) {
		e[3] = 8;
		for (var r = 0; r <= n.length; ++r) e[r + 10] = n.charCodeAt(r);
	}
}, ye = function(e) {
	(e[0] != 31 || e[1] != 139 || e[2] != 8) && k(6, "invalid gzip data");
	var t = e[3], n = 10;
	t & 4 && (n += (e[10] | e[11] << 8) + 2);
	for (var r = (t >> 3 & 1) + (t >> 4 & 1); r > 0; r -= !e[n++]);
	return n + (t & 2);
}, be = function(e) {
	var t = e.length;
	return (e[t - 4] | e[t - 3] << 8 | e[t - 2] << 16 | e[t - 1] << 24) >>> 0;
}, xe = function(e) {
	return 10 + (e.filename ? e.filename.length + 1 : 0);
}, Se = function(e, t) {
	var n = t.level, r = n == 0 ? 0 : n < 6 ? 1 : n == 9 ? 3 : 2;
	if (e[0] = 120, e[1] = r << 6 | (t.dictionary && 32), e[1] |= 31 - (e[0] << 8 | e[1]) % 31, t.dictionary) {
		var i = H();
		i.p(t.dictionary), Q(e, 2, i.d());
	}
}, Ce = function(e, t) {
	return ((e[0] & 15) != 8 || e[0] >> 4 > 7 || (e[0] << 8 | e[1]) % 31) && k(6, "invalid zlib data"), (e[1] >> 5 & 1) == +!t && k(6, "invalid zlib data: " + (e[1] & 32 ? "need" : "unexpected") + " dictionary"), (e[1] >> 3 & 4) + 2;
};
function we(e, t) {
	return typeof e == "function" && (t = e, e = {}), this.ondata = t, e;
}
var Te = /* @__PURE__ */ function() {
	function e(e, t) {
		if (typeof e == "function" && (t = e, e = {}), this.ondata = t, this.o = e || {}, this.s = {
			l: 0,
			i: 32768,
			w: 32768,
			z: 32768
		}, this.b = new i(98304), this.o.dictionary) {
			var n = this.o.dictionary.subarray(-32768);
			this.b.set(n, 32768 - n.length), this.s.i = 32768 - n.length;
		}
	}
	return e.prototype.p = function(e, t) {
		this.ondata(U(e, this.o, 0, 0, this.s), t);
	}, e.prototype.push = function(e, t) {
		this.ondata || k(5), this.s.l && k(4);
		var n = e.length + this.s.z;
		if (n > this.b.length) {
			if (n > 2 * this.b.length - 32768) {
				var r = new i(n & -32768);
				r.set(this.b.subarray(0, this.s.z)), this.b = r;
			}
			var a = this.b.length - this.s.z;
			this.b.set(e.subarray(0, a), this.s.z), this.s.z = this.b.length, this.p(this.b, !1), this.b.set(this.b.subarray(-32768)), this.b.set(e.subarray(a), 32768), this.s.z = e.length - a + 32768, this.s.i = 32766, this.s.w = 32768;
		} else this.b.set(e, this.s.z), this.s.z += e.length;
		this.s.l = t & 1, (this.s.z > this.s.w + 8191 || t) && (this.p(this.b, t || !1), this.s.w = this.s.i, this.s.i -= 2);
	}, e.prototype.flush = function() {
		this.ondata || k(5), this.s.l && k(4), this.p(this.b, !1), this.s.w = this.s.i, this.s.i -= 2;
	}, e;
}(), Ee = /* @__PURE__ */ function() {
	function e(e, t) {
		ge([J, function() {
			return [Y, Te];
		}], this, we.call(this, e, t), function(e) {
			onmessage = Y(new Te(e.data));
		}, 6, 1);
	}
	return e;
}();
function De(e, t, n) {
	return n || (n = t, t = {}), typeof n != "function" && k(7), he(e, t, [J], function(e) {
		return pe(Oe(e.data[0], e.data[1]));
	}, 0, n);
}
function Oe(e, t) {
	return U(e, t || {}, 0, 0);
}
var $ = /* @__PURE__ */ function() {
	function e(e, t) {
		typeof e == "function" && (t = e, e = {}), this.ondata = t;
		var n = e && e.dictionary && e.dictionary.subarray(-32768);
		this.s = {
			i: 0,
			b: n ? n.length : 0
		}, this.o = new i(32768), this.p = new i(0), n && this.o.set(n);
	}
	return e.prototype.e = function(e) {
		if (this.ondata || k(5), this.d && k(4), !this.p.length) this.p = e;
		else if (e.length) {
			var t = new i(this.p.length + e.length);
			t.set(this.p), t.set(e, this.p.length), this.p = t;
		}
	}, e.prototype.c = function(e) {
		this.s.i = +(this.d = e || !1);
		var t = this.s.b, n = A(this.p, this.s, this.o);
		this.ondata(E(n, t, this.s.b), this.d), this.o = E(n, this.s.b - 32768), this.s.b = this.o.length, this.p = E(this.p, this.s.p / 8 | 0), this.s.p &= 7;
	}, e.prototype.push = function(e, t) {
		this.e(e), this.c(t);
	}, e;
}(), ke = /* @__PURE__ */ function() {
	function e(e, t) {
		ge([q, function() {
			return [Y, $];
		}], this, we.call(this, e, t), function(e) {
			onmessage = Y(new $(e.data));
		}, 7, 0);
	}
	return e;
}();
function Ae(e, t, n) {
	return n || (n = t, t = {}), typeof n != "function" && k(7), he(e, t, [q], function(e) {
		return pe(je(e.data[0], me(e.data[1])));
	}, 1, n);
}
function je(e, t) {
	return A(e, { i: 2 }, t && t.out, t && t.dictionary);
}
var Me = /* @__PURE__ */ function() {
	function e(e, t) {
		this.c = V(), this.l = 0, this.v = 1, Te.call(this, e, t);
	}
	return e.prototype.push = function(e, t) {
		this.c.p(e), this.l += e.length, Te.prototype.push.call(this, e, t);
	}, e.prototype.p = function(e, t) {
		var n = U(e, this.o, this.v && xe(this.o), t && 8, this.s);
		this.v &&= (ve(n, this.o), 0), t && (Q(n, n.length - 8, this.c.d()), Q(n, n.length - 4, this.l)), this.ondata(n, t);
	}, e.prototype.flush = function() {
		Te.prototype.flush.call(this);
	}, e;
}(), Ne = /* @__PURE__ */ function() {
	function e(e, t) {
		ge([
			J,
			le,
			function() {
				return [
					Y,
					Te,
					Me
				];
			}
		], this, we.call(this, e, t), function(e) {
			onmessage = Y(new Me(e.data));
		}, 8, 1);
	}
	return e;
}();
function Pe(e, t, n) {
	return n || (n = t, t = {}), typeof n != "function" && k(7), he(e, t, [
		J,
		le,
		function() {
			return [Fe];
		}
	], function(e) {
		return pe(Fe(e.data[0], e.data[1]));
	}, 2, n);
}
function Fe(e, t) {
	t ||= {};
	var n = V(), r = e.length;
	n.p(e);
	var i = U(e, t, xe(t), 8), a = i.length;
	return ve(i, t), Q(i, a - 8, n.d()), Q(i, a - 4, r), i;
}
var Ie = /* @__PURE__ */ function() {
	function e(e, t) {
		this.v = 1, this.r = 0, $.call(this, e, t);
	}
	return e.prototype.push = function(e, t) {
		if ($.prototype.e.call(this, e), this.r += e.length, this.v) {
			var n = this.p.subarray(this.v - 1), r = n.length > 3 ? ye(n) : 4;
			if (r > n.length) {
				if (!t) return;
			} else this.v > 1 && this.onmember && this.onmember(this.r - n.length);
			this.p = n.subarray(r), this.v = 0;
		}
		$.prototype.c.call(this, t), this.s.f && !this.s.l && !t && (this.v = ie(this.s.p) + 9, this.s = { i: 0 }, this.o = new i(0), this.push(new i(0), t));
	}, e;
}(), Le = /* @__PURE__ */ function() {
	function e(e, t) {
		var n = this;
		ge([
			q,
			ue,
			function() {
				return [
					Y,
					$,
					Ie
				];
			}
		], this, we.call(this, e, t), function(e) {
			var t = new Ie(e.data);
			t.onmember = function(e) {
				return postMessage(e);
			}, onmessage = Y(t);
		}, 9, 0, function(e) {
			return n.onmember && n.onmember(e);
		});
	}
	return e;
}();
function Re(e, t, n) {
	return n || (n = t, t = {}), typeof n != "function" && k(7), he(e, t, [
		q,
		ue,
		function() {
			return [ze];
		}
	], function(e) {
		return pe(ze(e.data[0], e.data[1]));
	}, 3, n);
}
function ze(e, t) {
	var n = ye(e);
	return n + 8 > e.length && k(6, "invalid gzip data"), A(e.subarray(n, -8), { i: 2 }, t && t.out || new i(be(e)), t && t.dictionary);
}
var Be = /* @__PURE__ */ function() {
	function e(e, t) {
		this.c = H(), this.v = 1, Te.call(this, e, t);
	}
	return e.prototype.push = function(e, t) {
		this.c.p(e), Te.prototype.push.call(this, e, t);
	}, e.prototype.p = function(e, t) {
		var n = U(e, this.o, this.v && (this.o.dictionary ? 6 : 2), t && 4, this.s);
		this.v &&= (Se(n, this.o), 0), t && Q(n, n.length - 4, this.c.d()), this.ondata(n, t);
	}, e.prototype.flush = function() {
		Te.prototype.flush.call(this);
	}, e;
}(), Ve = /* @__PURE__ */ function() {
	function e(e, t) {
		ge([
			J,
			de,
			function() {
				return [
					Y,
					Te,
					Be
				];
			}
		], this, we.call(this, e, t), function(e) {
			onmessage = Y(new Be(e.data));
		}, 10, 1);
	}
	return e;
}();
function He(e, t, n) {
	return n || (n = t, t = {}), typeof n != "function" && k(7), he(e, t, [
		J,
		de,
		function() {
			return [Ue];
		}
	], function(e) {
		return pe(Ue(e.data[0], e.data[1]));
	}, 4, n);
}
function Ue(e, t) {
	t ||= {};
	var n = H();
	n.p(e);
	var r = U(e, t, t.dictionary ? 6 : 2, 4);
	return Se(r, t), Q(r, r.length - 4, n.d()), r;
}
var We = /* @__PURE__ */ function() {
	function e(e, t) {
		$.call(this, e, t), this.v = e && e.dictionary ? 2 : 1;
	}
	return e.prototype.push = function(e, t) {
		if ($.prototype.e.call(this, e), this.v) {
			if (this.p.length < 6 && !t) return;
			this.p = this.p.subarray(Ce(this.p, this.v - 1)), this.v = 0;
		}
		t && (this.p.length < 4 && k(6, "invalid zlib data"), this.p = this.p.subarray(0, -4)), $.prototype.c.call(this, t);
	}, e;
}(), Ge = /* @__PURE__ */ function() {
	function e(e, t) {
		ge([
			q,
			fe,
			function() {
				return [
					Y,
					$,
					We
				];
			}
		], this, we.call(this, e, t), function(e) {
			onmessage = Y(new We(e.data));
		}, 11, 0);
	}
	return e;
}();
function Ke(e, t, n) {
	return n || (n = t, t = {}), typeof n != "function" && k(7), he(e, t, [
		q,
		fe,
		function() {
			return [qe];
		}
	], function(e) {
		return pe(qe(e.data[0], me(e.data[1])));
	}, 5, n);
}
function qe(e, t) {
	return A(e.subarray(Ce(e, t && t.dictionary), -4), { i: 2 }, t && t.out, t && t.dictionary);
}
var Je = /* @__PURE__ */ function() {
	function e(e, t) {
		this.o = we.call(this, e, t) || {}, this.G = Ie, this.I = $, this.Z = We;
	}
	return e.prototype.i = function() {
		var e = this;
		this.s.ondata = function(t, n) {
			e.ondata(t, n);
		};
	}, e.prototype.push = function(e, t) {
		if (this.ondata || k(5), this.s) this.s.push(e, t);
		else {
			if (this.p && this.p.length) {
				var n = new i(this.p.length + e.length);
				n.set(this.p), n.set(e, this.p.length);
			} else this.p = e;
			this.p.length > 2 && (this.s = this.p[0] == 31 && this.p[1] == 139 && this.p[2] == 8 ? new this.G(this.o) : (this.p[0] & 15) != 8 || this.p[0] >> 4 > 7 || (this.p[0] << 8 | this.p[1]) % 31 ? new this.I(this.o) : new this.Z(this.o), this.i(), this.s.push(this.p, t), this.p = null);
		}
	}, e;
}(), Ye = /* @__PURE__ */ function() {
	function e(e, t) {
		Je.call(this, e, t), this.queuedSize = 0, this.G = Le, this.I = ke, this.Z = Ge;
	}
	return e.prototype.i = function() {
		var e = this;
		this.s.ondata = function(t, n, r) {
			e.ondata(t, n, r);
		}, this.s.ondrain = function(t) {
			e.queuedSize -= t, e.ondrain && e.ondrain(t);
		};
	}, e.prototype.push = function(e, t) {
		this.queuedSize += e.length, Je.prototype.push.call(this, e, t);
	}, e;
}();
function Xe(e, t, n) {
	return n || (n = t, t = {}), typeof n != "function" && k(7), e[0] == 31 && e[1] == 139 && e[2] == 8 ? Re(e, t, n) : (e[0] & 15) != 8 || e[0] >> 4 > 7 || (e[0] << 8 | e[1]) % 31 ? Ae(e, t, n) : Ke(e, t, n);
}
function Ze(e, t) {
	return e[0] == 31 && e[1] == 139 && e[2] == 8 ? ze(e, t) : (e[0] & 15) != 8 || e[0] >> 4 > 7 || (e[0] << 8 | e[1]) % 31 ? je(e, t) : qe(e, t);
}
var Qe = function(e, t, n, r) {
	for (var a in e) {
		var o = e[a], s = t + a, c = r;
		Array.isArray(o) && (c = se(r, o[1]), o = o[0]), o instanceof i ? n[s] = [o, c] : (n[s += "/"] = [new i(0), c], Qe(o, s, n, r));
	}
}, $e = typeof TextEncoder < "u" && /*#__PURE__*/ new TextEncoder(), et = typeof TextDecoder < "u" && /*#__PURE__*/ new TextDecoder(), tt = 0;
try {
	et.decode(R, { stream: !0 }), tt = 1;
} catch {}
var nt = function(e) {
	for (var t = "", n = 0;;) {
		var r = e[n++], i = (r > 127) + (r > 223) + (r > 239);
		if (n + i > e.length) return {
			s: t,
			r: E(e, n - 1)
		};
		i ? i == 3 ? (r = ((r & 15) << 18 | (e[n++] & 63) << 12 | (e[n++] & 63) << 6 | e[n++] & 63) - 65536, t += String.fromCharCode(55296 | r >> 10, 56320 | r & 1023)) : i & 1 ? t += String.fromCharCode((r & 31) << 6 | e[n++] & 63) : t += String.fromCharCode((r & 15) << 12 | (e[n++] & 63) << 6 | e[n++] & 63) : t += String.fromCharCode(r);
	}
}, rt = /* @__PURE__ */ function() {
	function e(e) {
		this.ondata = e, tt ? this.t = new TextDecoder() : this.p = R;
	}
	return e.prototype.push = function(e, t) {
		if (this.ondata || k(5), t = !!t, this.t) this.ondata(this.t.decode(e, { stream: !0 }), t), t && (this.t.decode().length && k(8), this.t = null);
		else {
			this.p || k(4);
			var n = new i(this.p.length + e.length);
			n.set(this.p), n.set(e, this.p.length);
			var r = nt(n), a = r.s, o = r.r;
			t ? (o.length && k(8), this.p = null) : this.p = o, this.ondata(a, t);
		}
	}, e;
}(), it = /* @__PURE__ */ function() {
	function e(e) {
		this.ondata = e;
	}
	return e.prototype.push = function(e, t) {
		this.ondata || k(5), this.d && k(4), this.ondata(at(e), this.d = t || !1);
	}, e;
}();
function at(e, t) {
	if (t) {
		for (var n = new i(e.length), r = 0; r < e.length; ++r) n[r] = e.charCodeAt(r);
		return n;
	}
	if ($e) return $e.encode(e);
	for (var a = e.length, o = new i(e.length + (e.length >> 1)), s = 0, c = function(e) {
		o[s++] = e;
	}, r = 0; r < a; ++r) {
		if (s + 5 > o.length) {
			var l = new i(s + 8 + (a - r << 1));
			l.set(o), o = l;
		}
		var u = e.charCodeAt(r);
		u < 128 || t ? c(u) : u < 2048 ? (c(192 | u >> 6), c(128 | u & 63)) : u > 55295 && u < 57344 ? (u = 65536 + (u & 1047552) | e.charCodeAt(++r) & 1023, c(240 | u >> 18), c(128 | u >> 12 & 63), c(128 | u >> 6 & 63), c(128 | u & 63)) : (c(224 | u >> 12), c(128 | u >> 6 & 63), c(128 | u & 63));
	}
	return E(o, 0, s);
}
function ot(e, t) {
	if (t) {
		for (var n = "", r = 0; r < e.length; r += 16384) n += String.fromCharCode.apply(null, e.subarray(r, r + 16384));
		return n;
	}
	if (et) return et.decode(e);
	var i = nt(e), a = i.s, n = i.r;
	return n.length && k(8), a;
}
var st = function(e) {
	return e == 1 ? 3 : e < 6 ? 2 : +(e == 9);
}, ct = function(e, t) {
	return t + 30 + X(e, t + 26) + X(e, t + 28);
}, lt = function(e, t, n) {
	var r = X(e, t + 28), i = ot(e.subarray(t + 46, t + 46 + r), !(X(e, t + 8) & 2048)), a = t + 46 + r, o = Z(e, t + 20), s = n && o == 4294967295 ? ut(e, a) : [
		o,
		Z(e, t + 24),
		Z(e, t + 42)
	], c = s[0], l = s[1], u = s[2];
	return [
		X(e, t + 10),
		c,
		l,
		i,
		a + X(e, t + 30) + X(e, t + 32),
		u
	];
}, ut = function(e, t) {
	for (; X(e, t) != 1; t += 4 + X(e, t + 2));
	return [
		_e(e, t + 12),
		_e(e, t + 4),
		_e(e, t + 20)
	];
}, dt = function(e) {
	var t = 0;
	if (e) for (var n in e) {
		var r = e[n].length;
		r > 65535 && k(9), t += r + 4;
	}
	return t;
}, ft = function(e, t, n, r, i, a, o, s) {
	var c = r.length, l = n.extra, u = s && s.length, d = dt(l);
	Q(e, t, o == null ? 67324752 : 33639248), t += 4, o != null && (e[t++] = 20, e[t++] = n.os), e[t] = 20, t += 2, e[t++] = n.flag << 1 | (a < 0 && 8), e[t++] = i && 8, e[t++] = n.compression & 255, e[t++] = n.compression >> 8;
	var f = new Date(n.mtime == null ? Date.now() : n.mtime), p = f.getFullYear() - 1980;
	if ((p < 0 || p > 119) && k(10), Q(e, t, p << 25 | f.getMonth() + 1 << 21 | f.getDate() << 16 | f.getHours() << 11 | f.getMinutes() << 5 | f.getSeconds() >> 1), t += 4, a != -1 && (Q(e, t, n.crc), Q(e, t + 4, a < 0 ? -a - 2 : a), Q(e, t + 8, n.size)), Q(e, t + 12, c), Q(e, t + 14, d), t += 16, o != null && (Q(e, t, u), Q(e, t + 6, n.attrs), Q(e, t + 10, o), t += 14), e.set(r, t), t += c, d) for (var m in l) {
		var h = l[m], g = h.length;
		Q(e, t, +m), Q(e, t + 2, g), e.set(h, t + 4), t += 4 + g;
	}
	return u && (e.set(s, t), t += u), t;
}, pt = function(e, t, n, r, i) {
	Q(e, t, 101010256), Q(e, t + 8, n), Q(e, t + 10, n), Q(e, t + 12, r), Q(e, t + 16, i);
}, mt = /* @__PURE__ */ function() {
	function e(e) {
		this.filename = e, this.c = V(), this.size = 0, this.compression = 0;
	}
	return e.prototype.process = function(e, t) {
		this.ondata(null, e, t);
	}, e.prototype.push = function(e, t) {
		this.ondata || k(5), this.c.p(e), this.size += e.length, t && (this.crc = this.c.d()), this.process(e, t || !1);
	}, e;
}(), ht = /* @__PURE__ */ function() {
	function e(e, t) {
		var n = this;
		t ||= {}, mt.call(this, e), this.d = new Te(t, function(e, t) {
			n.ondata(null, e, t);
		}), this.compression = 8, this.flag = st(t.level);
	}
	return e.prototype.process = function(e, t) {
		try {
			this.d.push(e, t);
		} catch (e) {
			this.ondata(e, null, t);
		}
	}, e.prototype.push = function(e, t) {
		mt.prototype.push.call(this, e, t);
	}, e;
}(), gt = /* @__PURE__ */ function() {
	function e(e, t) {
		var n = this;
		t ||= {}, mt.call(this, e), this.d = new Ee(t, function(e, t, r) {
			n.ondata(e, t, r);
		}), this.compression = 8, this.flag = st(t.level), this.terminate = this.d.terminate;
	}
	return e.prototype.process = function(e, t) {
		this.d.push(e, t);
	}, e.prototype.push = function(e, t) {
		mt.prototype.push.call(this, e, t);
	}, e;
}(), _t = /* @__PURE__ */ function() {
	function e(e) {
		this.ondata = e, this.u = [], this.d = 1;
	}
	return e.prototype.add = function(e) {
		var t = this;
		if (this.ondata || k(5), this.d & 2) this.ondata(k(4 + (this.d & 1) * 8, 0, 1), null, !1);
		else {
			var n = at(e.filename), r = n.length, a = e.comment, o = a && at(a), s = r != e.filename.length || o && a.length != o.length, c = r + dt(e.extra) + 30;
			r > 65535 && this.ondata(k(11, 0, 1), null, !1);
			var l = new i(c);
			ft(l, 0, e, n, s, -1);
			var u = [l], d = function() {
				for (var e = 0, n = u; e < n.length; e++) {
					var r = n[e];
					t.ondata(null, r, !1);
				}
				u = [];
			}, f = this.d;
			this.d = 0;
			var p = this.u.length, m = se(e, {
				f: n,
				u: s,
				o,
				t: function() {
					e.terminate && e.terminate();
				},
				r: function() {
					if (d(), f) {
						var e = t.u[p + 1];
						e ? e.r() : t.d = 1;
					}
					f = 1;
				}
			}), h = 0;
			e.ondata = function(n, r, a) {
				if (n) t.ondata(n, r, a), t.terminate();
				else if (h += r.length, u.push(r), a) {
					var o = new i(16);
					Q(o, 0, 134695760), Q(o, 4, e.crc), Q(o, 8, h), Q(o, 12, e.size), u.push(o), m.c = h, m.b = c + h + 16, m.crc = e.crc, m.size = e.size, f && m.r(), f = 1;
				} else f && d();
			}, this.u.push(m);
		}
	}, e.prototype.end = function() {
		var e = this;
		this.d & 2 ? this.ondata(k(4 + (this.d & 1) * 8, 0, 1), null, !0) : (this.d ? this.e() : this.u.push({
			r: function() {
				e.d & 1 && (e.u.splice(-1, 1), e.e());
			},
			t: function() {}
		}), this.d = 3);
	}, e.prototype.e = function() {
		for (var e = 0, t = 0, n = 0, r = 0, a = this.u; r < a.length; r++) {
			var o = a[r];
			n += 46 + o.f.length + dt(o.extra) + (o.o ? o.o.length : 0);
		}
		for (var s = new i(n + 22), c = 0, l = this.u; c < l.length; c++) {
			var o = l[c];
			ft(s, e, o, o.f, o.u, -o.c - 2, t, o.o), e += 46 + o.f.length + dt(o.extra) + (o.o ? o.o.length : 0), t += o.b;
		}
		pt(s, e, this.u.length, n, t), this.ondata(null, s, !0), this.d = 2;
	}, e.prototype.terminate = function() {
		for (var e = 0, t = this.u; e < t.length; e++) t[e].t();
		this.d = 2;
	}, e;
}();
function vt(e, t, n) {
	n || (n = t, t = {}), typeof n != "function" && k(7);
	var r = {};
	Qe(e, "", r, t);
	var a = Object.keys(r), o = a.length, s = 0, c = 0, l = o, u = Array(o), d = [], f = function() {
		for (var e = 0; e < d.length; ++e) d[e]();
	}, p = function(e, t) {
		wt(function() {
			n(e, t);
		});
	};
	wt(function() {
		p = n;
	});
	var m = function() {
		var e = new i(c + 22), t = s, n = c - s;
		c = 0;
		for (var r = 0; r < l; ++r) {
			var a = u[r];
			try {
				var o = a.c.length;
				ft(e, c, a, a.f, a.u, o);
				var d = 30 + a.f.length + dt(a.extra), f = c + d;
				e.set(a.c, f), ft(e, s, a, a.f, a.u, o, c, a.m), s += 16 + d + (a.m ? a.m.length : 0), c = f + o;
			} catch (e) {
				return p(e, null);
			}
		}
		pt(e, s, u.length, n, t), p(null, e);
	};
	o || m();
	for (var h = function(e) {
		var t = a[e], n = r[t], i = n[0], l = n[1], h = V(), g = i.length;
		h.p(i);
		var _ = at(t), v = _.length, y = l.comment, b = y && at(y), x = b && b.length, S = dt(l.extra), C = l.level == 0 ? 0 : 8, w = function(n, r) {
			if (n) f(), p(n, null);
			else {
				var i = r.length;
				u[e] = se(l, {
					size: g,
					crc: h.d(),
					c: r,
					f: _,
					m: b,
					u: v != t.length || b && y.length != x,
					compression: C
				}), s += 30 + v + S + i, c += 76 + 2 * (v + S) + (x || 0) + i, --o || m();
			}
		};
		if (v > 65535 && w(k(11, 0, 1), null), !C) w(null, i);
		else if (g < 16e4) try {
			w(null, Oe(i, l));
		} catch (e) {
			w(e, null);
		}
		else d.push(De(i, l, w));
	}, g = 0; g < l; ++g) h(g);
	return f;
}
function yt(e, t) {
	t ||= {};
	var n = {}, r = [];
	Qe(e, "", n, t);
	var a = 0, o = 0;
	for (var s in n) {
		var c = n[s], l = c[0], u = c[1], d = u.level == 0 ? 0 : 8, f = at(s), p = f.length, m = u.comment, h = m && at(m), g = h && h.length, _ = dt(u.extra);
		p > 65535 && k(11);
		var v = d ? Oe(l, u) : l, y = v.length, b = V();
		b.p(l), r.push(se(u, {
			size: l.length,
			crc: b.d(),
			c: v,
			f,
			m: h,
			u: p != s.length || h && m.length != g,
			o: a,
			compression: d
		})), a += 30 + p + _ + y, o += 76 + 2 * (p + _) + (g || 0) + y;
	}
	for (var x = new i(o + 22), S = a, C = o - a, w = 0; w < r.length; ++w) {
		var f = r[w];
		ft(x, f.o, f, f.f, f.u, f.c.length);
		var ee = 30 + f.f.length + dt(f.extra);
		x.set(f.c, f.o + ee), ft(x, a, f, f.f, f.u, f.c.length, f.o, f.m), a += 16 + ee + (f.m ? f.m.length : 0);
	}
	return pt(x, a, r.length, C, S), x;
}
var bt = /* @__PURE__ */ function() {
	function e() {}
	return e.prototype.push = function(e, t) {
		this.ondata(null, e, t);
	}, e.compression = 0, e;
}(), xt = /* @__PURE__ */ function() {
	function e() {
		var e = this;
		this.i = new $(function(t, n) {
			e.ondata(null, t, n);
		});
	}
	return e.prototype.push = function(e, t) {
		try {
			this.i.push(e, t);
		} catch (e) {
			this.ondata(e, null, t);
		}
	}, e.compression = 8, e;
}(), St = /* @__PURE__ */ function() {
	function e(e, t) {
		var n = this;
		t < 32e4 ? this.i = new $(function(e, t) {
			n.ondata(null, e, t);
		}) : (this.i = new ke(function(e, t, r) {
			n.ondata(e, t, r);
		}), this.terminate = this.i.terminate);
	}
	return e.prototype.push = function(e, t) {
		this.i.terminate && (e = E(e, 0)), this.i.push(e, t);
	}, e.compression = 8, e;
}(), Ct = /* @__PURE__ */ function() {
	function e(e) {
		this.onfile = e, this.k = [], this.o = { 0: bt }, this.p = R;
	}
	return e.prototype.push = function(e, t) {
		var n = this;
		if (this.onfile || k(5), this.p || k(4), this.c > 0) {
			var r = Math.min(this.c, e.length), a = e.subarray(0, r);
			if (this.c -= r, this.d ? this.d.push(a, !this.c) : this.k[0].push(a), e = e.subarray(r), e.length) return this.push(e, t);
		} else {
			var o = 0, s = 0, c = void 0, l = void 0;
			this.p.length ? e.length ? (l = new i(this.p.length + e.length), l.set(this.p), l.set(e, this.p.length)) : l = this.p : l = e;
			for (var u = l.length, d = this.c, f = d && this.d, p = function() {
				var e, t = Z(l, s);
				if (t == 67324752) {
					o = 1, c = s, m.d = null, m.c = 0;
					var r = X(l, s + 6), i = X(l, s + 8), a = r & 2048, f = r & 8, p = X(l, s + 26), h = X(l, s + 28);
					if (u > s + 30 + p + h) {
						var g = [];
						m.k.unshift(g), o = 2;
						var _ = Z(l, s + 18), v = Z(l, s + 22), y = ot(l.subarray(s + 30, s += 30 + p), !a);
						_ == 4294967295 ? (e = f ? [-2] : ut(l, s), _ = e[0], v = e[1]) : f && (_ = -1), s += h, m.c = _;
						var b, x = {
							name: y,
							compression: i,
							start: function() {
								if (x.ondata || k(5), !_) x.ondata(null, R, !0);
								else {
									var e = n.o[i];
									e || x.ondata(k(14, "unknown compression type " + i, 1), null, !1), b = _ < 0 ? new e(y) : new e(y, _, v), b.ondata = function(e, t, n) {
										x.ondata(e, t, n);
									};
									for (var t = 0, r = g; t < r.length; t++) {
										var a = r[t];
										b.push(a, !1);
									}
									n.k[0] == g && n.c ? n.d = b : b.push(R, !0);
								}
							},
							terminate: function() {
								b && b.terminate && b.terminate();
							}
						};
						_ >= 0 && (x.size = _, x.originalSize = v), m.onfile(x);
					}
					return "break";
				}
				if (d) {
					if (t == 134695760) return c = s += 12 + (d == -2 && 8), o = 3, m.c = 0, "break";
					if (t == 33639248) return c = s -= 4, o = 3, m.c = 0, "break";
				}
			}, m = this; s < u - 4 && p() !== "break"; ++s);
			if (this.p = R, d < 0) {
				var h = o ? l.subarray(0, c - 12 - (d == -2 && 8) - (Z(l, c - 16) == 134695760 && 4)) : l.subarray(0, s);
				f ? f.push(h, !!o) : this.k[+(o == 2)].push(h);
			}
			if (o & 2) return this.push(l.subarray(s), t);
			this.p = l.subarray(s);
		}
		t && (this.c && k(13), this.p = null);
	}, e.prototype.register = function(e) {
		this.o[e.compression] = e;
	}, e;
}(), wt = typeof queueMicrotask == "function" ? queueMicrotask : typeof setTimeout == "function" ? setTimeout : function(e) {
	e();
};
function Tt(e, t, n) {
	n || (n = t, t = {}), typeof n != "function" && k(7);
	var r = [], a = function() {
		for (var e = 0; e < r.length; ++e) r[e]();
	}, o = {}, s = function(e, t) {
		wt(function() {
			n(e, t);
		});
	};
	wt(function() {
		s = n;
	});
	for (var c = e.length - 22; Z(e, c) != 101010256; --c) if (!c || e.length - c > 65558) return s(k(13, 0, 1), null), a;
	var l = X(e, c + 8);
	if (l) {
		var u = l, d = Z(e, c + 16), f = d == 4294967295 || u == 65535;
		if (f) {
			var p = Z(e, c - 12);
			f = Z(e, p) == 101075792, f && (u = l = Z(e, p + 32), d = Z(e, p + 48));
		}
		for (var m = t && t.filter, h = function(t) {
			var n = lt(e, d, f), c = n[0], u = n[1], p = n[2], h = n[3], g = n[4], _ = n[5], v = ct(e, _);
			d = g;
			var y = function(e, t) {
				e ? (a(), s(e, null)) : (t && (o[h] = t), --l || s(null, o));
			};
			if (!m || m({
				name: h,
				size: u,
				originalSize: p,
				compression: c
			})) {
				if (!c) y(null, E(e, v, v + u));
				else if (c == 8) {
					var b = e.subarray(v, v + u);
					if (p < 524288 || u > .8 * p) try {
						y(null, je(b, { out: new i(p) }));
					} catch (e) {
						y(e, null);
					}
					else r.push(Ae(b, { size: p }, y));
				} else y(k(14, "unknown compression type " + c, 1), null);
			} else y(null, null);
		}, g = 0; g < u; ++g) h(g);
	} else s(null, {});
	return a;
}
function Et(e, t) {
	for (var n = {}, r = e.length - 22; Z(e, r) != 101010256; --r) (!r || e.length - r > 65558) && k(13);
	var a = X(e, r + 8);
	if (!a) return {};
	var o = Z(e, r + 16), s = o == 4294967295 || a == 65535;
	if (s) {
		var c = Z(e, r - 12);
		s = Z(e, c) == 101075792, s && (a = Z(e, c + 32), o = Z(e, c + 48));
	}
	for (var l = t && t.filter, u = 0; u < a; ++u) {
		var d = lt(e, o, s), f = d[0], p = d[1], m = d[2], h = d[3], g = d[4], _ = d[5], v = ct(e, _);
		o = g, (!l || l({
			name: h,
			size: p,
			originalSize: m,
			compression: f
		})) && (f ? f == 8 ? n[h] = je(e.subarray(v, v + p), { out: new i(m) }) : k(14, "unknown compression type " + f) : n[h] = E(e, v, v + p));
	}
	return n;
}
//#endregion
export { yt as a, qe as i, at as n, Et as r, t };

//# sourceMappingURL=fflate.module-CAsKaJ_w.js.map