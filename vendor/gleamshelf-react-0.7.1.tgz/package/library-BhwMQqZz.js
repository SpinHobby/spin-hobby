import "./GleamEditor-BwL_fApV.js";
import "./src-B9VqgbK-.js";
import { x as e } from "./document-CNMOilB9.js";
import { V as t } from "./core-AdQZWWr9.js";
//#region src/i18n/translate.ts
var n = (e) => e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
function r(e) {
	let t = /* @__PURE__ */ new Map(), r = [];
	for (let [i, a] of Object.entries(e)) {
		let e = i.replace(/\s+/g, " ").trim();
		e.includes("{}") ? r.push({
			re: RegExp(`^${e.split("{}").map(n).join("(.+?)")}$`),
			to: a,
			bare: !/[A-Za-z]/.test(e.replaceAll("{}", ""))
		}) : t.set(e, a);
	}
	return r.sort((e, t) => t.re.source.length - e.re.source.length), {
		exact: t,
		patterns: r
	};
}
function i(e, t) {
	let n = t.replace(/\s+/g, " ").trim();
	if (!n) return null;
	let r = e.exact.get(n);
	if (r === void 0) for (let t of e.patterns) {
		let i = t.re.exec(n);
		if (!i || t.bare && !i.slice(1).some((t) => e.exact.has(t))) continue;
		let a = i.slice(1).map((t) => e.exact.get(t) ?? t), o = 0;
		r = t.to.replace(/\{(\d*)\}/g, (e, t) => a[t ? Number(t) - 1 : o++] ?? "");
		break;
	}
	if (r === void 0 && n.includes(" › ")) {
		let t = n.split(" › ");
		t.some((t) => e.exact.has(t)) && (r = t.map((t) => e.exact.get(t) ?? t).join(" › "));
	}
	if (r === void 0) return null;
	let i = /^\s*/.exec(t)[0], a = /\s*$/.exec(t)[0];
	return i + r + a;
}
var a = [
	"title",
	"aria-label",
	"placeholder",
	"alt"
], o = "script, style, textarea, code, pre, [translate=\"no\"], [contenteditable=\"true\"]", s = "script, style, [translate=\"no\"]", c = /* @__PURE__ */ new WeakMap(), l = /* @__PURE__ */ new WeakMap(), u = /* @__PURE__ */ new WeakMap(), d = /* @__PURE__ */ new WeakMap(), f = null;
function p(e, t) {
	if (e.parentElement?.closest(o)) return;
	l.get(e) !== e.data && c.set(e, e.data);
	let n = c.get(e);
	if (n === void 0) return;
	let r = t ? i(t, n) ?? n : n;
	e.data !== r && (e.data = r), l.set(e, r);
}
function m(e, t) {
	if (!e.closest(s)) for (let n of a) {
		let r = e.getAttribute(n);
		if (r === null) continue;
		let a = u.get(e), o = d.get(e);
		a || u.set(e, a = /* @__PURE__ */ new Map()), o || d.set(e, o = /* @__PURE__ */ new Map()), o.get(n) !== r && a.set(n, r);
		let s = a.get(n), c = t ? i(t, s) ?? s : s;
		r !== c && e.setAttribute(n, c), o.set(n, c);
	}
}
var h = (e) => l.get(e) === e.data ? c.get(e) ?? e.data : e.data;
function g(e) {
	if (e.nodeType === Node.TEXT_NODE) return h(e);
	let t = "";
	return e.childNodes.forEach((e) => {
		(e.nodeType === Node.TEXT_NODE || e.nodeType === Node.ELEMENT_NODE) && (t += g(e));
	}), t;
}
function _(e, t) {
	let n = e.getAttribute(t);
	return n === null ? null : d.get(e)?.get(t) === n ? u.get(e)?.get(t) ?? n : n;
}
function v(e, t) {
	if (e.nodeType === Node.TEXT_NODE) return p(e, t);
	if (e.nodeType !== Node.ELEMENT_NODE) return;
	m(e, t);
	let n = document.createTreeWalker(e, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
	for (let e = n.nextNode(); e; e = n.nextNode()) e.nodeType === Node.TEXT_NODE ? p(e, t) : m(e, t);
}
var y = {};
async function b(e, t = document.body) {
	if (f?.observer.disconnect(), e === "en") {
		f && v(f.root, null), f = null;
		return;
	}
	y.ja ??= import("./ja-CWE1mPgA.js").then((e) => r(e.JA));
	let n = await y.ja, i = new MutationObserver((e) => {
		for (let t of e) t.type === "characterData" ? p(t.target, n) : t.type === "attributes" ? m(t.target, n) : t.addedNodes.forEach((e) => v(e, n));
	});
	f = {
		compiled: n,
		root: t,
		observer: i
	}, v(t, n), i.observe(t, {
		subtree: !0,
		childList: !0,
		characterData: !0,
		attributes: !0,
		attributeFilter: [...a]
	});
}
//#endregion
//#region src/model3d/library.ts
var x;
function S(e) {
	x = e;
}
function C(e, t) {
	return e || x || (t.ready ? `${(t.url || "http://127.0.0.1:47321").replace(/\/$/, "")}/library/` : void 0);
}
async function w(n, r, i, a) {
	let o = /* @__PURE__ */ new Set(), s = (e) => {
		e.kind === "mesh" && e.asset && o.add(e.asset), e.children?.forEach(s);
	};
	n.design.shapes.forEach(s);
	let c = [...o].map((e) => {
		let t = r.find((t) => t.id === e);
		if (!t) throw Error(`${e} is not in the library`);
		return {
			id: e,
			item: t,
			bytes: i(t.model)
		};
	}), l = {};
	for (let [e, { id: n, item: r, bytes: i }] of c.entries()) l[n] = t(`${r.name} by ${r.author}`, await i), a?.(e + 1, c.length), await new Promise((e) => setTimeout(e, 0));
	return e({
		...n.design,
		assets: l
	});
}
//#endregion
export { g as a, _ as i, w as n, b as o, S as r, C as t };

//# sourceMappingURL=library-BhwMQqZz.js.map