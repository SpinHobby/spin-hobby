import { At as e, Cr as t, G as n, Jt as r, Kn as i, Mt as a, Nt as o, Pt as s, R as c, S as l, Tt as u, _t as d, d as f, ft as p, h as m, m as h, nr as g, pt as _, sr as v, u as y, wt as b, z as x, zn as S } from "./three.core-BCwsimN9.js";
import { t as C } from "./BufferGeometryUtils-BvBWdh2_.js";
import { r as w } from "./fflate.module-CAsKaJ_w.js";
//#region ../../node_modules/three/examples/jsm/loaders/3MFLoader.js
var T = i, E = "http://schemas.microsoft.com/3dmanufacturing/beamlattice/2017/02", D = "http://schemas.microsoft.com/3dmanufacturing/beamlattice/balls/2020/07", O = class extends d {
	constructor(e) {
		super(e), this.availableExtensions = [];
	}
	load(e, t, n, r) {
		let i = this, a = new c(i.manager);
		a.setPath(i.path), a.setResponseType("arraybuffer"), a.setRequestHeader(i.requestHeader), a.setWithCredentials(i.withCredentials), a.load(e, function(n) {
			try {
				t(i.parse(n));
			} catch (t) {
				r ? r(t) : console.error(t), i.manager.itemError(e);
			}
		}, n, r);
	}
	parse(i) {
		let c = this, O = new v(this.manager);
		function k(e) {
			let t = null, n = null, r, i, a = [], o = [], s, c = {}, l = {}, u = {}, d = new TextDecoder();
			try {
				t = w(new Uint8Array(e));
			} catch (e) {
				if (e instanceof ReferenceError) return console.error("THREE.3MFLoader: fflate missing and file is compressed."), null;
			}
			let f = null;
			for (n in t) n.match(/\_rels\/.rels$/) ? r = n : n.match(/3D\/_rels\/.*\.model\.rels$/) ? i = n : n.match(/^3D\/[^\/]*\.model$/) ? f = n : n.match(/^3D\/.*\/.*\.model$/) ? a.push(n) : n.match(/^3D\/Textures?\/.*/) && o.push(n);
			if (a.push(f), r === void 0) throw Error("THREE.ThreeMFLoader: Cannot find relationship file `rels` in 3MF archive.");
			let p = t[r], m = A(d.decode(p));
			if (i) {
				let e = t[i];
				s = A(d.decode(e));
			}
			for (let e = 0; e < a.length; e++) {
				let n = a[e], r = t[n], i = d.decode(r), o = new DOMParser().parseFromString(i, "application/xml");
				o.documentElement.nodeName.toLowerCase() !== "model" && console.error("THREE.3MFLoader: Error loading 3MF - no 3MF document found: ", n);
				let s = o.querySelector("model"), l = {};
				for (let e = 0; e < s.attributes.length; e++) {
					let t = s.attributes[e];
					t.name.match(/^xmlns:(.+)$/) && (l[t.value] = RegExp.$1);
				}
				let u = W(s);
				u.xml = s, 0 < Object.keys(l).length && (u.extensions = l), c[n] = u;
			}
			for (let e = 0; e < o.length; e++) {
				let n = o[e];
				u[n] = t[n].buffer;
			}
			return {
				rels: m,
				modelRels: s,
				model: c,
				printTicket: l,
				texture: u
			};
		}
		function A(e) {
			let t = [], n = new DOMParser().parseFromString(e, "application/xml").querySelectorAll("Relationship");
			for (let e = 0; e < n.length; e++) {
				let r = n[e], i = {
					target: r.getAttribute("Target"),
					id: r.getAttribute("Id"),
					type: r.getAttribute("Type")
				};
				t.push(i);
			}
			return t;
		}
		function j(e) {
			let t = {};
			for (let n = 0; n < e.length; n++) {
				let r = e[n], i = r.getAttribute("name");
				0 <= [
					"Title",
					"Designer",
					"Description",
					"Copyright",
					"LicenseTerms",
					"Rating",
					"CreationDate",
					"ModificationDate"
				].indexOf(i) && (t[i] = r.textContent);
			}
			return t;
		}
		function ee(e) {
			let t = {
				id: e.getAttribute("id"),
				basematerials: []
			}, n = e.querySelectorAll("base");
			for (let e = 0; e < n.length; e++) {
				let r = n[e], i = F(r);
				i.index = e, t.basematerials.push(i);
			}
			return t;
		}
		function te(e) {
			return {
				id: e.getAttribute("id"),
				path: e.getAttribute("path"),
				contenttype: e.getAttribute("contenttype"),
				tilestyleu: e.getAttribute("tilestyleu"),
				tilestylev: e.getAttribute("tilestylev"),
				filter: e.getAttribute("filter")
			};
		}
		function ne(e) {
			let t = {
				id: e.getAttribute("id"),
				texid: e.getAttribute("texid"),
				displaypropertiesid: e.getAttribute("displaypropertiesid")
			}, n = e.querySelectorAll("tex2coord"), r = [];
			for (let e = 0; e < n.length; e++) {
				let t = n[e], i = t.getAttribute("u"), a = t.getAttribute("v");
				r.push(parseFloat(i), parseFloat(a));
			}
			return t.uvs = new Float32Array(r), t;
		}
		function re(e) {
			let t = {
				id: e.getAttribute("id"),
				displaypropertiesid: e.getAttribute("displaypropertiesid")
			}, n = e.querySelectorAll("color"), r = [], i = new m();
			for (let e = 0; e < n.length; e++) {
				let t = n[e].getAttribute("color");
				i.setStyle(t.substring(0, 7), T), r.push(i.r, i.g, i.b);
			}
			return t.colors = new Float32Array(r), t;
		}
		function M(e) {
			let t = e.children, n = {};
			for (let e = 0; e < t.length; e++) {
				let r = { type: t[e].nodeName.substring(2) };
				for (let n = 0; n < t[e].attributes.length; n++) {
					let i = t[e].attributes[n];
					i.specified && (r[i.name] = i.value);
				}
				n[t[e].getAttribute("identifier")] = r;
			}
			return n;
		}
		function N(e) {
			let t = {
				id: e.getAttribute("id"),
				displayname: e.getAttribute("displayname")
			}, n = e.children, r = {};
			for (let e = 0; e < n.length; e++) {
				let t = n[e];
				if (t.nodeName === "i:in" || t.nodeName === "i:out") r[t.nodeName === "i:in" ? "inputs" : "outputs"] = M(t);
				else {
					let e = t.children, n = {
						op: t.nodeName.substring(2),
						identifier: t.getAttribute("identifier")
					};
					for (let t = 0; t < e.length; t++) n[e[t].nodeName.substring(2)] = M(e[t]);
					r[n.identifier] = n;
				}
			}
			return t.operations = r, t;
		}
		function P(e) {
			let t = { id: e.getAttribute("id") }, n = e.querySelectorAll("pbmetallic"), r = [];
			for (let e = 0; e < n.length; e++) {
				let t = n[e];
				r.push({
					name: t.getAttribute("name"),
					metallicness: parseFloat(t.getAttribute("metallicness")),
					roughness: parseFloat(t.getAttribute("roughness"))
				});
			}
			return t.data = r, t;
		}
		function F(e) {
			let t = {};
			return t.name = e.getAttribute("name"), t.displaycolor = e.getAttribute("displaycolor"), t.displaypropertiesid = e.getAttribute("displaypropertiesid"), t;
		}
		function I(e) {
			let t = {}, n = [], r = e.querySelectorAll("vertices vertex");
			for (let e = 0; e < r.length; e++) {
				let t = r[e], i = t.getAttribute("x"), a = t.getAttribute("y"), o = t.getAttribute("z");
				n.push(parseFloat(i), parseFloat(a), parseFloat(o));
			}
			t.vertices = new Float32Array(n);
			let i = [], a = [], o = e.querySelectorAll("triangles triangle");
			for (let e = 0; e < o.length; e++) {
				let t = o[e], n = t.getAttribute("v1"), r = t.getAttribute("v2"), s = t.getAttribute("v3"), c = t.getAttribute("p1"), l = t.getAttribute("p2"), u = t.getAttribute("p3"), d = t.getAttribute("pid"), f = {};
				f.v1 = parseInt(n, 10), f.v2 = parseInt(r, 10), f.v3 = parseInt(s, 10), a.push(f.v1, f.v2, f.v3), c && (f.p1 = parseInt(c, 10)), l && (f.p2 = parseInt(l, 10)), u && (f.p3 = parseInt(u, 10)), d && (f.pid = d), 0 < Object.keys(f).length && i.push(f);
			}
			t.triangleProperties = i, t.triangles = new Uint32Array(a);
			let s = e.getElementsByTagNameNS(E, "beamlattice")[0];
			return s !== void 0 && (t.beamlattice = L(s)), t;
		}
		function L(e) {
			let t = {
				radius: parseFloat(e.getAttribute("radius")),
				minLength: parseFloat(e.getAttribute("minlength")),
				cap: e.getAttribute("cap") || "sphere",
				ballMode: e.getAttributeNS(D, "ballmode") || "none",
				ballRadius: parseFloat(e.getAttributeNS(D, "ballradius")),
				beams: [],
				balls: []
			}, n = e.getAttribute("clippingmode") || e.getAttribute("clipping");
			n !== null && n !== "none" && console.warn("THREE.3MFLoader: Beam lattice clipping is not supported. The lattice is rendered unclipped.");
			let r = e.getElementsByTagNameNS(E, "beam");
			for (let e = 0; e < r.length; e++) {
				let n = r[e], i = {
					v1: parseInt(n.getAttribute("v1"), 10),
					v2: parseInt(n.getAttribute("v2"), 10)
				}, a = n.getAttribute("r1"), o = n.getAttribute("r2");
				a !== null && (i.r1 = parseFloat(a)), o !== null && (i.r2 = parseFloat(o)), t.beams.push(i);
			}
			let i = e.getElementsByTagNameNS(D, "ball");
			for (let e = 0; e < i.length; e++) {
				let n = i[e], r = { vindex: parseInt(n.getAttribute("vindex"), 10) }, a = n.getAttribute("r");
				a !== null && (r.r = parseFloat(a)), t.balls.push(r);
			}
			return t;
		}
		function R(e) {
			let t = [], n = e.querySelectorAll("component");
			for (let e = 0; e < n.length; e++) {
				let r = n[e], i = z(r);
				t.push(i);
			}
			return t;
		}
		function z(e) {
			let t = {};
			t.objectId = e.getAttribute("objectid");
			let n = e.getAttribute("transform");
			return n && (t.transform = B(n)), t;
		}
		function B(e) {
			let t = [];
			e.split(" ").forEach(function(e) {
				t.push(parseFloat(e));
			});
			let n = new b();
			return n.set(t[0], t[3], t[6], t[9], t[1], t[4], t[7], t[10], t[2], t[5], t[8], t[11], 0, 0, 0, 1), n;
		}
		function V(e) {
			let t = { type: e.getAttribute("type") }, n = e.getAttribute("id");
			n && (t.id = n);
			let r = e.getAttribute("pid");
			r && (t.pid = r);
			let i = e.getAttribute("pindex");
			i && (t.pindex = i);
			let a = e.getAttribute("thumbnail");
			a && (t.thumbnail = a);
			let o = e.getAttribute("partnumber");
			o && (t.partnumber = o);
			let s = e.getAttribute("name");
			s && (t.name = s);
			let c = e.querySelector("mesh");
			c && (t.mesh = I(c));
			let l = e.querySelector("components");
			return l && (t.components = R(l)), t;
		}
		function H(e) {
			let t = {};
			t.basematerials = {};
			let n = e.querySelectorAll("basematerials");
			for (let e = 0; e < n.length; e++) {
				let r = n[e], i = ee(r);
				t.basematerials[i.id] = i;
			}
			t.texture2d = {};
			let r = e.querySelectorAll("texture2d");
			for (let e = 0; e < r.length; e++) {
				let n = r[e], i = te(n);
				t.texture2d[i.id] = i;
			}
			t.colorgroup = {};
			let i = e.querySelectorAll("colorgroup");
			for (let e = 0; e < i.length; e++) {
				let n = i[e], r = re(n);
				t.colorgroup[r.id] = r;
			}
			let a = e.querySelectorAll("implicitfunction");
			a.length > 0 && (t.implicitfunction = {});
			for (let e = 0; e < a.length; e++) {
				let n = a[e], r = N(n);
				t.implicitfunction[r.id] = r;
			}
			t.pbmetallicdisplayproperties = {};
			let o = e.querySelectorAll("pbmetallicdisplayproperties");
			for (let e = 0; e < o.length; e++) {
				let n = o[e], r = P(n);
				t.pbmetallicdisplayproperties[r.id] = r;
			}
			t.texture2dgroup = {};
			let s = e.querySelectorAll("texture2dgroup");
			for (let e = 0; e < s.length; e++) {
				let n = s[e], r = ne(n);
				t.texture2dgroup[r.id] = r;
			}
			t.object = {};
			let c = e.querySelectorAll("object");
			for (let e = 0; e < c.length; e++) {
				let n = c[e], r = V(n);
				t.object[r.id] = r;
			}
			return t;
		}
		function U(e) {
			let t = [], n = e.querySelectorAll("item");
			for (let e = 0; e < n.length; e++) {
				let r = n[e], i = { objectId: r.getAttribute("objectid") }, a = r.getAttribute("transform");
				a && (i.transform = B(a)), t.push(i);
			}
			return t;
		}
		function W(e) {
			let t = { unit: e.getAttribute("unit") || "millimeter" }, n = e.querySelectorAll("metadata");
			n && (t.metadata = j(n));
			let r = e.querySelector("resources");
			r && (t.resources = H(r));
			let i = e.querySelector("build");
			return i && (t.build = U(i)), t;
		}
		function G(e, t, n, r) {
			let i = e.texid, a = n.resources.texture2d[i];
			if (a) {
				let e = r[a.path], t = a.contenttype, n = new Blob([e], { type: t }), i = URL.createObjectURL(n), c = O.load(i, function() {
					URL.revokeObjectURL(i);
				});
				switch (c.colorSpace = T, a.tilestyleu) {
					case "wrap":
						c.wrapS = S;
						break;
					case "mirror":
						c.wrapS = o;
						break;
					case "none":
					case "clamp":
						c.wrapS = h;
						break;
					default: c.wrapS = S;
				}
				switch (a.tilestylev) {
					case "wrap":
						c.wrapT = S;
						break;
					case "mirror":
						c.wrapT = o;
						break;
					case "none":
					case "clamp":
						c.wrapT = h;
						break;
					default: c.wrapT = S;
				}
				switch (a.filter) {
					case "auto":
						c.magFilter = p, c.minFilter = _;
						break;
					case "linear":
						c.magFilter = p, c.minFilter = p, c.generateMipmaps = !1;
						break;
					case "nearest":
						c.magFilter = s, c.minFilter = s, c.generateMipmaps = !1;
						break;
					default: c.magFilter = p, c.minFilter = _;
				}
				return c;
			}
			return null;
		}
		function K(e, t, n, r, i, a, o) {
			let s = o.pindex, c = {};
			for (let e = 0, n = t.length; e < n; e++) {
				let n = t[e], r = n.p1 === void 0 ? s : n.p1;
				c[r] === void 0 && (c[r] = []), c[r].push(n);
			}
			let l = Object.keys(c), d = [];
			for (let t = 0, s = l.length; t < s; t++) {
				let s = l[t], p = c[s], m = e.basematerials[s], h = X(m, r, i, a, o, Z), g = new f(), _ = [], v = n.vertices;
				for (let e = 0, t = p.length; e < t; e++) {
					let t = p[e];
					_.push(v[t.v1 * 3 + 0]), _.push(v[t.v1 * 3 + 1]), _.push(v[t.v1 * 3 + 2]), _.push(v[t.v2 * 3 + 0]), _.push(v[t.v2 * 3 + 1]), _.push(v[t.v2 * 3 + 2]), _.push(v[t.v3 * 3 + 0]), _.push(v[t.v3 * 3 + 1]), _.push(v[t.v3 * 3 + 2]);
				}
				g.setAttribute("position", new x(_, 3));
				let y = new u(g, h);
				d.push(y);
			}
			return d;
		}
		function ie(t, n, r, i, a, o, s) {
			let c = new f(), l = [], d = [], p = r.vertices, m = t.uvs;
			for (let e = 0, t = n.length; e < t; e++) {
				let t = n[e];
				l.push(p[t.v1 * 3 + 0]), l.push(p[t.v1 * 3 + 1]), l.push(p[t.v1 * 3 + 2]), l.push(p[t.v2 * 3 + 0]), l.push(p[t.v2 * 3 + 1]), l.push(p[t.v2 * 3 + 2]), l.push(p[t.v3 * 3 + 0]), l.push(p[t.v3 * 3 + 1]), l.push(p[t.v3 * 3 + 2]), d.push(m[t.p1 * 2 + 0]), d.push(m[t.p1 * 2 + 1]), d.push(m[t.p2 * 2 + 0]), d.push(m[t.p2 * 2 + 1]), d.push(m[t.p3 * 2 + 0]), d.push(m[t.p3 * 2 + 1]);
			}
			c.setAttribute("position", new x(l, 3)), c.setAttribute("uv", new x(d, 2));
			let h = X(t, i, a, o, s, G), g = new e({
				map: h,
				flatShading: !0
			});
			return new u(c, g);
		}
		function q(t, n, r, i) {
			let a = new f(), o = [], s = [], c = r.vertices, l = t.colors;
			for (let e = 0, t = n.length; e < t; e++) {
				let t = n[e], r = t.v1, a = t.v2, u = t.v3;
				o.push(c[r * 3 + 0]), o.push(c[r * 3 + 1]), o.push(c[r * 3 + 2]), o.push(c[a * 3 + 0]), o.push(c[a * 3 + 1]), o.push(c[a * 3 + 2]), o.push(c[u * 3 + 0]), o.push(c[u * 3 + 1]), o.push(c[u * 3 + 2]);
				let d = t.p1 === void 0 ? i.pindex : t.p1, f = t.p2 === void 0 ? d : t.p2, p = t.p3 === void 0 ? d : t.p3;
				s.push(l[d * 3 + 0]), s.push(l[d * 3 + 1]), s.push(l[d * 3 + 2]), s.push(l[f * 3 + 0]), s.push(l[f * 3 + 1]), s.push(l[f * 3 + 2]), s.push(l[p * 3 + 0]), s.push(l[p * 3 + 1]), s.push(l[p * 3 + 2]);
			}
			a.setAttribute("position", new x(o, 3)), a.setAttribute("color", new x(s, 3));
			let d = new e({
				vertexColors: !0,
				flatShading: !0
			});
			return new u(a, d);
		}
		function J(t) {
			let n = new f();
			n.setIndex(new y(t.triangles, 1)), n.setAttribute("position", new y(t.vertices, 3));
			let r = new e({
				name: d.DEFAULT_MATERIAL_NAME,
				color: 16777215,
				flatShading: !0
			});
			return new u(n, r);
		}
		function Y(n) {
			let i = n.beamlattice, a = n.vertices, o = [], s = new t(), c = new t(), f = new t(), p = new t(0, 1, 0), m = new r(), h = new b(), _ = i.beams, v = i.cap !== "butt", y = /* @__PURE__ */ new Map();
			for (let e = 0; e < _.length; e++) {
				let t = _[e];
				s.fromArray(a, t.v1 * 3), c.fromArray(a, t.v2 * 3);
				let n = s.distanceTo(c);
				if (n < i.minLength) continue;
				let r = t.r1 === void 0 ? i.radius : t.r1, u = t.r2 === void 0 ? r : t.r2, d = new l(u, r, n, 8, 1, v);
				f.subVectors(c, s).divideScalar(n), m.setFromUnitVectors(p, f), h.makeRotationFromQuaternion(m), h.setPosition(s.add(c).multiplyScalar(.5)), d.applyMatrix4(h), o.push(d), v && (y.set(t.v1, Math.max(r, y.get(t.v1) || 0)), y.set(t.v2, Math.max(u, y.get(t.v2) || 0))), i.ballMode === "all" && (y.set(t.v1, Math.max(i.ballRadius, y.get(t.v1) || 0)), y.set(t.v2, Math.max(i.ballRadius, y.get(t.v2) || 0)));
			}
			let x = i.balls;
			for (let e = 0; e < x.length; e++) {
				let t = x[e], n = t.r === void 0 ? i.ballRadius : t.r;
				y.set(t.vindex, Math.max(n, y.get(t.vindex) || 0));
			}
			for (let [e, t] of y) {
				let n = new g(t, 8, 6);
				s.fromArray(a, e * 3), n.translate(s.x, s.y, s.z), o.push(n);
			}
			let S = C(o), w = new e({
				name: d.DEFAULT_MATERIAL_NAME,
				color: 16777215
			});
			return new u(S, w);
		}
		function ae(e, t, n, r, i, a) {
			let o = Object.keys(e), s = [];
			for (let c = 0, l = o.length; c < l; c++) {
				let l = o[c], u = e[l];
				switch (oe(l, r)) {
					case "material":
						let e = r.resources.basematerials[l], o = K(e, u, t, n, r, i, a);
						for (let e = 0, t = o.length; e < t; e++) s.push(o[e]);
						break;
					case "texture":
						let c = r.resources.texture2dgroup[l];
						s.push(ie(c, u, t, n, r, i, a));
						break;
					case "vertexColors":
						let d = r.resources.colorgroup[l];
						s.push(q(d, u, t, a));
						break;
					case "default":
						s.push(J(t));
						break;
					default: console.error("THREE.3MFLoader: Unsupported resource type.");
				}
			}
			if (a.name) for (let e = 0; e < s.length; e++) s[e].name = a.name;
			return s;
		}
		function oe(e, t) {
			if (t.resources.texture2dgroup[e] !== void 0) return "texture";
			if (t.resources.basematerials[e] !== void 0) return "material";
			if (t.resources.colorgroup[e] !== void 0) return "vertexColors";
			if (e === "default") return "default";
		}
		function se(e, t) {
			let n = {}, r = e.triangleProperties, i = t.pid;
			for (let e = 0, t = r.length; e < t; e++) {
				let t = r[e], a = t.pid === void 0 ? i : t.pid;
				a === void 0 && (a = "default"), n[a] === void 0 && (n[a] = []), n[a].push(t);
			}
			return n;
		}
		function ce(e, t, r, i, a) {
			let o = new n(), s = ae(se(e, a), e, t, r, i, a);
			if (e.beamlattice !== void 0) {
				let t = Y(e);
				a.name && (t.name = a.name), s.push(t);
			}
			for (let e = 0, t = s.length; e < t; e++) o.add(s[e]);
			return o;
		}
		function le(e, t, n) {
			if (!e) return;
			let r = [], i = Object.keys(e);
			for (let e = 0; e < i.length; e++) {
				let t = i[e];
				for (let e = 0; e < c.availableExtensions.length; e++) {
					let n = c.availableExtensions[e];
					n.ns === t && r.push(n);
				}
			}
			for (let i = 0; i < r.length; i++) {
				let a = r[i];
				a.apply(n, e[a.ns], t);
			}
		}
		function X(e, t, n, r, i, a) {
			return e.build === void 0 && (e.build = a(e, t, n, r, i)), e.build;
		}
		function Z(t, n, r) {
			let i, o = t.displaypropertiesid, s = r.resources.pbmetallicdisplayproperties;
			if (o !== null && s[o] !== void 0) {
				let e = s[o].data[t.index];
				i = new a({
					flatShading: !0,
					roughness: e.roughness,
					metalness: e.metallicness
				});
			} else i = new e({ flatShading: !0 });
			i.name = t.name;
			let c = t.displaycolor, l = c.substring(0, 7);
			return i.color.setStyle(l, T), c.length === 9 && (i.opacity = parseInt(c.charAt(7) + c.charAt(8), 16) / 255), i;
		}
		function ue(e, t, r, i) {
			let a = new n();
			for (let n = 0; n < e.length; n++) {
				let o = e[n], s = t[o.objectId];
				s === void 0 && (Q(o.objectId, t, r, i), s = t[o.objectId]);
				let c = s.clone(), l = o.transform;
				l && c.applyMatrix4(l), a.add(c);
			}
			return a;
		}
		function Q(e, t, n, r) {
			let i = n.resources.object[e];
			if (i.mesh) {
				let e = i.mesh, a = n.extensions, o = n.xml;
				le(a, e, o), t[i.id] = X(e, t, n, r, i, ce);
			} else {
				let e = i.components;
				t[i.id] = X(e, t, n, r, i, ue);
			}
			i.name && (t[i.id].name = i.name), n.resources.implicitfunction && console.warn("THREE.ThreeMFLoader: Implicit Functions are implemented in data-only.", n.resources.implicitfunction);
		}
		function de(e) {
			let t = e.model, n = e.modelRels, r = {}, i = Object.keys(t), a = {};
			if (n) for (let t = 0, r = n.length; t < r; t++) {
				let r = n[t], i = r.target.substring(1);
				e.texture[i] && (a[r.target] = e.texture[i]);
			}
			for (let e = 0; e < i.length; e++) {
				let n = t[i[e]], o = Object.keys(n.resources.object);
				for (let e = 0; e < o.length; e++) {
					let t = o[e];
					Q(t, r, n, a);
				}
			}
			return r;
		}
		function fe(e) {
			for (let t = 0; t < e.length; t++) {
				let n = e[t];
				if (n.target.split(".").pop().toLowerCase() === "model") return n;
			}
		}
		function pe(e, t) {
			let r = new n(), i = fe(t.rels), a = t.model[i.target.substring(1)].build;
			for (let t = 0; t < a.length; t++) {
				let n = a[t], i = e[n.objectId].clone(), o = n.transform;
				o && i.applyMatrix4(o), r.add(i);
			}
			return r;
		}
		let $ = k(i);
		return pe(de($), $);
	}
	addExtension(e) {
		this.availableExtensions.push(e);
	}
};
//#endregion
export { O as ThreeMFLoader };

//# sourceMappingURL=3MFLoader-Br3zolgJ.js.map