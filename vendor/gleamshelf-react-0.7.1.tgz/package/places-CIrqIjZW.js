//#region src/model3d/places.ts
var e = [
	"",
	"light",
	"game",
	"learn",
	"library",
	"scenes",
	"character",
	"render",
	"voice"
], t = (t) => e.includes(t) ? t : "";
//#endregion
export { t as n, e as t };

//# sourceMappingURL=places-CIrqIjZW.js.map