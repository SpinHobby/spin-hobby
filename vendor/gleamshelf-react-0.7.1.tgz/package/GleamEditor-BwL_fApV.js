import { i as e } from "./rolldown-runtime-DArdT4gl.js";
import { A as t, B as n, C as r, D as i, E as a, H as o, L as s, M as c, O as l, R as u, S as d, T as f, U as p, V as m, _ as h, a as g, b as _, f as v, g as y, h as b, i as x, k as S, m as C, n as w, o as ee, p as te, r as ne, t as re, v as ie, w as ae, x as oe, y as T, z as se } from "./src-Dp2bJp0u.js";
import { a as E, c as ce, l as D, n as O, s as le, t as ue, u as de } from "./src-BRmeDFgO.js";
import { Suspense as fe, lazy as k, useCallback as pe, useEffect as A, useLayoutEffect as me, useMemo as he, useRef as j, useState as M, useSyncExternalStore as ge } from "react";
import { Fragment as N, jsx as P, jsxs as F } from "react/jsx-runtime";
//#region ../core/src/recolour.ts
var I = (e) => [
	parseInt(e.slice(1, 3), 16) / 255,
	parseInt(e.slice(3, 5), 16) / 255,
	parseInt(e.slice(5, 7), 16) / 255
], _e = (e, t, n) => String.fromCharCode(...e.subarray(t, n)), ve = /* @__PURE__ */ new Set([
	"heic",
	"heix",
	"hevc",
	"hevx",
	"heim",
	"heis"
]);
function ye(e) {
	if (e.length < 16 || _e(e, 4, 8) !== "ftyp") return !1;
	let t = Math.min(e.length, new DataView(e.buffer, e.byteOffset, e.byteLength).getUint32(0), 256), n = [_e(e, 8, 12)];
	for (let r = 16; r + 4 <= t; r += 4) n.push(_e(e, r, r + 4));
	return n.includes("avif") || n.includes("avis") ? !1 : n.some((e) => ve.has(e));
}
var be = (e, t) => {
	let n = Array(9).fill(0);
	for (let r = 0; r < 3; r++) for (let i = 0; i < 3; i++) for (let a = 0; a < 3; a++) n[r * 3 + i] += e[r * 3 + a] * t[a * 3 + i];
	return n;
}, xe = [
	3.1338561,
	-1.6168667,
	-.4906146,
	-.9787684,
	1.9161415,
	.033454,
	.0719453,
	-.2289914,
	1.4052427
], Se = [
	1.2249402,
	-.2249402,
	0,
	-.0420569,
	1.0420569,
	0,
	-.0196376,
	-.0786361,
	1.0982737
], Ce = 65536;
function we(e, t, n) {
	if (n - t < 132) return null;
	let r = new DataView(e.buffer, e.byteOffset, e.byteLength), i = r.getUint32(t + 128), a = (a) => {
		for (let o = 0; o < i && t + 144 + o * 12 <= n; o++) {
			let i = t + 132 + o * 12;
			if (_e(e, i, i + 4) !== a) continue;
			let s = t + r.getUint32(i + 4);
			return s + 20 > n ? null : [
				r.getInt32(s + 8) / Ce,
				r.getInt32(s + 12) / Ce,
				r.getInt32(s + 16) / Ce
			];
		}
		return null;
	}, o = a("rXYZ"), s = a("gXYZ"), c = a("bXYZ");
	return !o || !s || !c ? null : be(xe, [
		o[0],
		s[0],
		c[0],
		o[1],
		s[1],
		c[1],
		o[2],
		s[2],
		c[2]
	]);
}
function Te(e) {
	let t = new DataView(e.buffer, e.byteOffset, e.byteLength), n = Math.min(e.length, 1 << 20) - 12;
	for (let r = 4; r < n; r++) {
		if (e[r] !== 99 || e[r + 1] !== 111 || e[r + 2] !== 108 || e[r + 3] !== 114) continue;
		let n = t.getUint32(r - 4);
		if (n < 12 || r - 4 + n > e.length) continue;
		let i = _e(e, r + 4, r + 8), a = i === "prof" || i === "rICC" ? we(e, r + 8, r - 4 + n) : i === "nclx" && t.getUint16(r + 8) === 12 ? Se : null;
		if (i !== "prof" && i !== "rICC" && i !== "nclx") continue;
		if (!a) return null;
		let o = [
			1,
			0,
			0,
			0,
			1,
			0,
			0,
			0,
			1
		];
		return a.every((e, t) => Math.abs(e - o[t]) < .01) ? null : a;
	}
	return null;
}
var Ee = (e) => e <= .04045 ? e / 12.92 : ((e + .055) / 1.055) ** 2.4, De = (e) => e <= .0031308 ? e * 12.92 : 1.055 * e ** (1 / 2.4) - .055;
function Oe(e, t) {
	let n = Float32Array.from({ length: 256 }, (e, t) => Ee(t / 255)), r = 4096, i = Uint8ClampedArray.from({ length: 4097 }, (e, t) => Math.round(De(t / r) * 255)), a = (e) => i[Math.round(Math.min(1, Math.max(0, e)) * r)];
	for (let r = 0; r < e.length; r += 4) {
		let i = n[e[r]], o = n[e[r + 1]], s = n[e[r + 2]];
		e[r] = a(t[0] * i + t[1] * o + t[2] * s), e[r + 1] = a(t[3] * i + t[4] * o + t[5] * s), e[r + 2] = a(t[6] * i + t[7] * o + t[8] * s);
	}
}
async function ke(t) {
	let { default: n } = await import("./heic-decode-BYdIj7Hj.js").then((t) => /* @__PURE__ */ e(t.default, 1)), { width: r, height: i, data: a } = await n({ buffer: t }), o = a instanceof Uint8ClampedArray ? a : new Uint8ClampedArray(a.buffer, a.byteOffset, a.byteLength), s = Te(t);
	return s && Oe(o, s), {
		width: r,
		height: i,
		data: o
	};
}
//#endregion
//#region src/images.ts
var Ae;
function L() {
	if (Ae === void 0) {
		let e = document.createElement("canvas").getContext("webgl2");
		Ae = e ? e.getParameter(e.MAX_TEXTURE_SIZE) : 4096, e?.getExtension("WEBGL_lose_context")?.loseContext();
	}
	return Ae;
}
var je = 2048;
async function Me(e) {
	let t = URL.createObjectURL(e);
	try {
		let n = new Image();
		n.src = t, await n.decode();
		let r = n.naturalWidth || je, i = n.naturalHeight || je;
		if (e.type === "image/svg+xml") {
			let e = je / Math.max(r, i);
			r = Math.round(r * e), i = Math.round(i * e);
		}
		let a = document.createElement("canvas");
		return a.width = r, a.height = i, a.getContext("2d").drawImage(n, 0, 0, r, i), await createImageBitmap(a);
	} catch {
		throw Error("This file couldn't be opened as an image. Try a JPEG, PNG, WebP or HEIC.");
	} finally {
		URL.revokeObjectURL(t);
	}
}
async function Ne(e) {
	if (!ye(new Uint8Array(await e.slice(0, 512).arrayBuffer()))) return null;
	let { width: t, height: n, data: r } = await ke(new Uint8Array(await e.arrayBuffer()));
	return createImageBitmap(new ImageData(new Uint8ClampedArray(r), t, n));
}
async function Pe(e, t = L()) {
	let n;
	try {
		n = await createImageBitmap(e, { imageOrientation: "from-image" });
	} catch {
		n = await Ne(e).catch(() => null) ?? await Me(e);
	}
	let r = Math.max(n.width, n.height);
	if (r <= t) return n;
	let i = t / r, a = await createImageBitmap(n, {
		resizeWidth: Math.floor(n.width * i),
		resizeHeight: Math.floor(n.height * i),
		resizeQuality: "high"
	});
	return n.close(), a;
}
async function Fe(e) {
	let t = Math.min(1, 512 / Math.max(e.width, e.height)), n = Math.max(1, Math.round(e.width * t)), r = Math.max(1, Math.round(e.height * t)), i = document.createElement("canvas");
	i.width = n, i.height = r;
	let a = i.getContext("2d", { willReadFrequently: !0 });
	a.drawImage(e, 0, 0, n, r);
	let o = a.getImageData(0, 0, n, r).data, s = n, c = -1, l = r, u = -1;
	for (let e = 0; e < r; e++) for (let t = 0; t < n; t++) o[(e * n + t) * 4 + 3] > 16 && (t < s && (s = t), t > c && (c = t), e < l && (l = e), e > u && (u = e));
	if (c < 0 || s === 0 && l === 0 && c === n - 1 && u === r - 1) return e;
	let d = Math.max(0, Math.floor((s - 1) / t)), f = Math.max(0, Math.floor((l - 1) / t)), p = Math.min(e.width, Math.ceil((c + 2) / t)), m = Math.min(e.height, Math.ceil((u + 2) / t));
	return createImageBitmap(e, d, f, p - d, m - f);
}
async function R(e, t) {
	let n;
	try {
		n = await fetch(e, {
			mode: "cors",
			signal: t
		});
	} catch (e) {
		throw t?.aborted ? e : Error("The photo couldn't be downloaded. Its server may not allow other sites to read it (CORS).");
	}
	if (!n.ok) throw Error(`The photo couldn't be downloaded (${n.status}).`);
	return n.blob();
}
async function Ie(e) {
	let t = document.createElement("canvas");
	t.width = e.width, t.height = e.height;
	let n = new Uint8ClampedArray(e.width * e.height * 4);
	for (let t = 0; t < e.alpha.length; t++) n.set([
		e.alpha[t],
		e.alpha[t],
		e.alpha[t],
		255
	], t * 4);
	return t.getContext("2d").putImageData(new ImageData(n, e.width, e.height), 0, 0), new Promise((e, n) => t.toBlob((t) => t ? e(t) : n(/* @__PURE__ */ Error("The mask could not be saved.")), "image/png"));
}
async function Le(e) {
	let t = await createImageBitmap(e, { colorSpaceConversion: "none" }), n = document.createElement("canvas");
	n.width = t.width, n.height = t.height;
	let r = n.getContext("2d", { willReadFrequently: !0 });
	r.drawImage(t, 0, 0);
	let { data: i } = r.getImageData(0, 0, t.width, t.height), a = new Uint8Array(t.width * t.height);
	for (let e = 0; e < a.length; e++) a[e] = i[e * 4];
	let o = {
		alpha: a,
		width: t.width,
		height: t.height
	};
	return t.close(), o;
}
async function Re(e, t = 1536) {
	let n = Math.min(1, t / Math.max(e.width, e.height)), r = document.createElement("canvas");
	return r.width = Math.max(1, Math.round(e.width * n)), r.height = Math.max(1, Math.round(e.height * n)), r.getContext("2d").drawImage(e, 0, 0, r.width, r.height), new Promise((e, t) => r.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The photo could not be prepared.")), "image/jpeg", .92));
}
async function ze(e, t, n = 1536) {
	let r = {
		...t,
		recipe: {
			...t.recipe,
			ops: {
				...t.recipe.ops,
				canvas: {
					...t.recipe.ops.canvas,
					square: !1,
					margin: 0
				}
			}
		}
	}, { width: i, height: a } = T(r, n), o = h(_(r));
	if (!o) throw Error("This crop cannot be used.");
	let s = document.createElement("canvas");
	s.width = i, s.height = a;
	let c = s.getContext("2d");
	return c.fillStyle = "#ffffff", c.fillRect(0, 0, i, a), c.setTransform(i * o.a / e.width, a * o.b / e.width, i * o.c / e.height, a * o.d / e.height, i * o.e, a * o.f), c.drawImage(e, 0, 0), new Promise((e, t) => s.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The crop could not be prepared.")), "image/jpeg", .92));
}
var Be = {
	id: "birefnet-general-fp16",
	name: "BiRefNet (whole box, larger)",
	task: "cutout",
	summary: "Cuts a whole box or product out of any background. Four times the size of the compact model, and it was never fooled by artwork on a cover (the compact one took a girl on the cover for the object on one box in ten).",
	recommended: !1,
	license: {
		name: "MIT",
		commercialUse: "allowed",
		url: "https://huggingface.co/ZhengPeng7/BiRefNet"
	},
	sizeMb: 489.7,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/ZhengPeng7/BiRefNet",
		download: "https://huggingface.co/onnx-community/BiRefNet-ONNX/resolve/main/onnx/model_fp16.onnx"
	},
	file: {
		name: "birefnet-general-fp16.onnx",
		bytes: 489666272
	},
	input: {
		size: 1024,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "logits-mask"
}, Ve = {
	id: "birefnet-lite-fp16",
	name: "BiRefNet lite (compact)",
	task: "cutout",
	summary: "Separates the product from any background, with clean edges. The compact version: half the download, nearly the same quality.",
	recommended: !0,
	license: {
		name: "MIT",
		commercialUse: "allowed",
		url: "https://huggingface.co/ZhengPeng7/BiRefNet_lite"
	},
	sizeMb: 114.5,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/ZhengPeng7/BiRefNet_lite",
		download: "https://huggingface.co/onnx-community/BiRefNet_lite-ONNX/resolve/main/onnx/model_fp16.onnx"
	},
	file: {
		name: "birefnet-lite-fp16.onnx",
		bytes: 114538221
	},
	input: {
		size: 1024,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "logits-mask"
}, He = {
	id: "birefnet-lite",
	name: "BiRefNet lite (full precision)",
	task: "cutout",
	summary: "The same cut-out model at full precision. A bigger download for slightly finer edges.",
	recommended: !1,
	license: {
		name: "MIT",
		commercialUse: "allowed",
		url: "https://huggingface.co/ZhengPeng7/BiRefNet_lite"
	},
	sizeMb: 224,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/ZhengPeng7/BiRefNet_lite",
		download: "https://huggingface.co/onnx-community/BiRefNet_lite-ONNX/resolve/main/onnx/model.onnx"
	},
	file: {
		name: "birefnet-lite.onnx",
		bytes: 224005088
	},
	input: {
		size: 1024,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "logits-mask"
}, Ue = {
	id: "flux2-klein-4b",
	name: "Clean product photo (FLUX.2 klein 4B)",
	task: "clean-photo",
	summary: "Turns a photo of a figure's box into a clean picture of the figure alone, with no lettering, logos, stickers or box edges, on a studio backdrop. Runs on this computer (about 2-3 minutes on a 16 GB Mac). It draws the figure again from the photo, so check small details against the real figure.",
	recommended: !0,
	license: {
		name: "Apache 2.0",
		commercialUse: "allowed",
		url: "https://huggingface.co/black-forest-labs/FLUX.2-klein-4B"
	},
	sizeMb: 15970,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/black-forest-labs/FLUX.2-klein-4B",
		download: "https://huggingface.co/black-forest-labs/FLUX.2-klein-4B"
	},
	file: {
		name: "flux2-klein-4b/transformer/diffusion_pytorch_model.safetensors",
		bytes: 7751109744
	},
	input: {
		size: 1024,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image"
}, We = {
	id: "lama-fp32",
	name: "LaMa fill (removes marks and lettering)",
	task: "inpaint",
	summary: "Paints over what you mask (printed words, stickers, marks) with realistic detail from around it. Much cleaner than the free fill on hair and fabric. Takes a few seconds per patch on a laptop.",
	recommended: !0,
	license: {
		name: "Apache-2.0",
		commercialUse: "allowed",
		url: "https://huggingface.co/Carve/LaMa-ONNX"
	},
	sizeMb: 208,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/Carve/LaMa-ONNX",
		download: "https://huggingface.co/Carve/LaMa-ONNX/resolve/main/lama_fp32.onnx"
	},
	file: {
		name: "lama-fp32.onnx",
		bytes: 208044816
	},
	input: {
		size: 512,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image"
}, z = {
	id: "ppocr-det-v4",
	name: "Text finder (PaddleOCR v4, compact)",
	task: "text-detect",
	summary: "Finds where printed text is on a picture (any colour, many languages including Japanese), so it can be filled in. Tiny and quick.",
	recommended: !0,
	license: {
		name: "Apache-2.0",
		commercialUse: "allowed",
		url: "https://huggingface.co/SWHL/RapidOCR"
	},
	sizeMb: 4.7,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/SWHL/RapidOCR",
		download: "https://huggingface.co/SWHL/RapidOCR/resolve/main/PP-OCRv4/ch_PP-OCRv4_det_infer.onnx"
	},
	file: {
		name: "ppocr-det-v4.onnx",
		bytes: 4745517
	},
	input: {
		size: 960,
		mean: [
			.485,
			.456,
			.406
		],
		std: [
			.229,
			.224,
			.225
		]
	},
	output: "probability-map"
}, Ge = {
	id: "ppocr-rec-v4",
	name: "Text reader (PaddleOCR v4, compact)",
	task: "text-read",
	summary: "Reads what printed text says (numbers, prices, English, Chinese, Japanese kana), so a shop's price sticker can be told apart from the box's own printing. Used together with the text finder.",
	recommended: !0,
	license: {
		name: "Apache-2.0",
		commercialUse: "allowed",
		url: "https://huggingface.co/SWHL/RapidOCR"
	},
	sizeMb: 10.9,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/SWHL/RapidOCR",
		download: "https://huggingface.co/SWHL/RapidOCR/resolve/main/PP-OCRv4/ch_PP-OCRv4_rec_infer.onnx"
	},
	file: {
		name: "ppocr-rec-v4.onnx",
		bytes: 10857958
	},
	input: {
		size: 48,
		mean: [
			.5,
			.5,
			.5
		],
		std: [
			.5,
			.5,
			.5
		]
	},
	output: "probability-map"
}, B = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realesr-general-x4",
	name: "Sharpen & enlarge (fast, small)",
	recommended: !1,
	summary: "Makes a picture 4 times larger and clearly sharper, adding believable fine detail. The small, quick one (about a quarter of a second for a face-sized area). Best first choice for photos of figures and boxes. In the benchmark it over-sharpened (1.13 times the original's edge detail) and lost some structure, so the x4plus model is the default.",
	sizeMb: 4.95,
	license: {
		name: "BSD-3-Clause (Real-ESRGAN)",
		commercialUse: "check",
		url: "https://github.com/xinntao/Real-ESRGAN/blob/master/LICENSE"
	},
	links: {
		modelCard: "https://huggingface.co/baker76/upscale-models",
		download: "https://huggingface.co/baker76/upscale-models/resolve/main/RealESR_General_x4.onnx"
	},
	file: {
		name: "realesr-general-x4.onnx",
		bytes: 4954907
	}
}, Ke = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realesrgan-anime-x4",
	name: "Sharpen & enlarge (illustrations)",
	recommended: !1,
	summary: "Tuned for drawn art: very clean lines and flat colour, but it smooths skin and plastic texture, so it suits flat box illustrations more than photos of figures.",
	sizeMb: 18.7,
	license: {
		name: "BSD-3-Clause (Real-ESRGAN)",
		commercialUse: "check",
		url: "https://github.com/xinntao/Real-ESRGAN/blob/master/LICENSE"
	},
	links: {
		modelCard: "https://huggingface.co/baker76/upscale-models",
		download: "https://huggingface.co/baker76/upscale-models/resolve/main/RealESRGAN_anime_x4.onnx"
	},
	file: {
		name: "realesrgan-anime-x4.onnx",
		bytes: 18688425
	}
}, V = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realesrgan-x4plus",
	name: "Sharpen & enlarge (best photo quality)",
	recommended: !1,
	summary: "Sharpens and enlarges 4x with the larger photo model. On a benchmark (half-size, compressed crops restored and compared with the originals) it was the most faithful and best balanced of the Real-ESRGAN models: highest SSIM and sharpness closest to the original. Slower (a few seconds for a face-sized area).",
	sizeMb: 69.9,
	license: {
		name: "BSD-3-Clause (Real-ESRGAN)",
		commercialUse: "check",
		url: "https://github.com/xinntao/Real-ESRGAN/blob/master/LICENSE"
	},
	links: {
		modelCard: "https://huggingface.co/baker76/upscale-models",
		download: "https://huggingface.co/baker76/upscale-models/resolve/main/RealESRGAN_x4plus.onnx"
	},
	file: {
		name: "realesrgan-x4plus.onnx",
		bytes: 69879921
	}
}, qe = {
	task: "upscale",
	runsOn: ["local-server"],
	input: {
		size: 256,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image",
	id: "realplksr-x4",
	name: "Photo restore 4x (RealPLKSR, small and fast)",
	recommended: !0,
	summary: "A small 4x restoration model from darktable (MIT), trained for photographs. Best of every enlarging method on ten real product photos (bench/enlarge): sharper and truer than Real-ESRGAN, and it keeps printed text readable.",
	sizeMb: 29.7,
	license: {
		name: "MIT (darktable RealPLKSR)",
		commercialUse: "yes",
		url: "https://huggingface.co/darktable-org/upscale-realplksr-onnx"
	},
	links: {
		modelCard: "https://huggingface.co/darktable-org/upscale-realplksr-onnx",
		download: "https://huggingface.co/darktable-org/upscale-realplksr-onnx/resolve/main/onnx/model_x4.onnx"
	},
	file: {
		name: "realplksr-x4.onnx",
		bytes: 29711010
	}
}, Je = {
	id: "sdxl-inpaint",
	name: "Redraw (Stable Diffusion XL inpainting)",
	task: "redraw",
	summary: "Redraws part of a picture with a believable continuation: a missing antenna, an edge that was cut off. Runs on this computer's GPU (about 30 seconds). It invents what it draws, so use it where the picture really is missing a part.",
	recommended: !0,
	license: {
		name: "OpenRAIL++-M (commercial use of the pictures is allowed; see the licence for its use restrictions)",
		commercialUse: "check",
		url: "https://huggingface.co/diffusers/stable-diffusion-xl-1.0-inpainting-0.1"
	},
	sizeMb: 6940,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/diffusers/stable-diffusion-xl-1.0-inpainting-0.1",
		download: "https://huggingface.co/diffusers/stable-diffusion-xl-1.0-inpainting-0.1"
	},
	file: {
		name: "sdxl-inpaint/unet/diffusion_pytorch_model.fp16.safetensors",
		bytes: 5135178560
	},
	input: {
		size: 1024,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image"
}, Ye = {
	id: "sdxl-tile",
	name: "Sharpen with detail (SDXL tile ControlNet)",
	task: "enhance",
	summary: "Makes a picture crisper and cleaner while every shape stays where it was: hair strands, fabric folds, edges. The original colours are kept. Runs on this computer's GPU (about half a minute to a minute for a 1024 pixel picture once the models are loaded). Works together with the redraw model.",
	recommended: !0,
	license: {
		name: "Apache-2.0 (used with SDXL, OpenRAIL++-M)",
		commercialUse: "allowed",
		url: "https://huggingface.co/xinsir/controlnet-tile-sdxl-1.0"
	},
	sizeMb: 2502,
	runsOn: ["local-server"],
	links: {
		modelCard: "https://huggingface.co/xinsir/controlnet-tile-sdxl-1.0",
		download: "https://huggingface.co/xinsir/controlnet-tile-sdxl-1.0"
	},
	file: {
		name: "sdxl-tile/diffusion_pytorch_model.safetensors",
		bytes: 2502139104
	},
	input: {
		size: 1024,
		mean: [
			0,
			0,
			0
		],
		std: [
			1,
			1,
			1
		]
	},
	output: "image"
}, Xe = (e) => {
	let t = e;
	return !!t && typeof t.id == "string" && /^[a-z0-9][a-z0-9-]*$/.test(t.id) && typeof t.name == "string" && (t.task === "cutout" || t.task === "inpaint" || t.task === "text-detect" || t.task === "text-read" || t.task === "upscale" || t.task === "redraw" || t.task === "enhance" || t.task === "clean-photo") && typeof t.file?.name == "string" && typeof t.links?.download == "string" && typeof t.input?.size == "number";
};
function Ze(e) {
	return [...e].filter(Xe).sort((e, t) => Number(t.recommended) - Number(e.recommended) || e.name.localeCompare(t.name));
}
function Qe(e) {
	return {
		MODELS: e,
		findModel: (t) => e.find((e) => e.id === t),
		modelsFor: (t) => e.filter((e) => e.task === t)
	};
}
var { MODELS: $e, findModel: et, modelsFor: tt } = Qe(Ze(Object.values(/* @__PURE__ */ Object.assign({
	"../registry/birefnet-general-fp16.json": Be,
	"../registry/birefnet-lite-fp16.json": Ve,
	"../registry/birefnet-lite.json": He,
	"../registry/flux2-klein-4b.json": Ue,
	"../registry/lama-fp32.json": We,
	"../registry/ppocr-det-v4.json": z,
	"../registry/ppocr-rec-v4.json": Ge,
	"../registry/realesr-general-x4.json": B,
	"../registry/realesrgan-anime-x4.json": Ke,
	"../registry/realesrgan-x4plus.json": V,
	"../registry/realplksr-x4.json": qe,
	"../registry/sdxl-inpaint.json": Je,
	"../registry/sdxl-tile.json": Ye
})))), nt = {
	strength: .5,
	control: .6,
	guidance: 6,
	keepColour: !1,
	seed: 7,
	prompt: "professional studio product photograph of a collectible, clean even soft lighting, glossy finish, crisp detail, true to the original colours, e-commerce pack shot",
	negativePrompt: "blurry, low quality, noise, artifacts, deformed, extra parts, changed design, text, watermark, logo"
}, H = class extends Error {
	status;
	constructor(e, t) {
		super(t), this.status = e;
	}
}, rt = "http://127.0.0.1:47321", it = {
	start: "npm run local:start",
	token: "npm run local:token",
	models: "npm run models",
	redrawSetup: "npm run redraw:setup",
	cleanPhotoSetup: "npm run clean-photo:setup",
	install: (e) => e && e !== "birefnet-lite-fp16" ? `npm run models:install -- ${e}` : "npm run models:install"
}, at = [
	{
		id: "af_heart",
		label: "Heart",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_bella",
		label: "Bella",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_nicole",
		label: "Nicole (soft)",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_sarah",
		label: "Sarah",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_sky",
		label: "Sky",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_nova",
		label: "Nova",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_river",
		label: "River",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_aoede",
		label: "Aoede",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_kore",
		label: "Kore",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_jessica",
		label: "Jessica",
		accent: "American",
		kind: "female"
	},
	{
		id: "af_alloy",
		label: "Alloy",
		accent: "American",
		kind: "female"
	},
	{
		id: "am_michael",
		label: "Michael",
		accent: "American",
		kind: "male"
	},
	{
		id: "am_adam",
		label: "Adam",
		accent: "American",
		kind: "male"
	},
	{
		id: "am_eric",
		label: "Eric",
		accent: "American",
		kind: "male"
	},
	{
		id: "am_liam",
		label: "Liam",
		accent: "American",
		kind: "male"
	},
	{
		id: "am_puck",
		label: "Puck",
		accent: "American",
		kind: "male"
	},
	{
		id: "am_echo",
		label: "Echo",
		accent: "American",
		kind: "male"
	},
	{
		id: "am_fenrir",
		label: "Fenrir",
		accent: "American",
		kind: "male"
	},
	{
		id: "am_onyx",
		label: "Onyx (deep)",
		accent: "American",
		kind: "male"
	},
	{
		id: "bf_emma",
		label: "Emma",
		accent: "British",
		kind: "female"
	},
	{
		id: "bf_isabella",
		label: "Isabella",
		accent: "British",
		kind: "female"
	},
	{
		id: "bf_alice",
		label: "Alice",
		accent: "British",
		kind: "female"
	},
	{
		id: "bf_lily",
		label: "Lily",
		accent: "British",
		kind: "female"
	},
	{
		id: "bm_george",
		label: "George",
		accent: "British",
		kind: "male"
	},
	{
		id: "bm_fable",
		label: "Fable",
		accent: "British",
		kind: "male"
	},
	{
		id: "bm_lewis",
		label: "Lewis",
		accent: "British",
		kind: "male"
	},
	{
		id: "bm_daniel",
		label: "Daniel",
		accent: "British",
		kind: "male"
	},
	{
		id: "jf_alpha",
		label: "Alpha",
		accent: "Japanese",
		kind: "female"
	},
	{
		id: "jf_gongitsune",
		label: "Gongitsune",
		accent: "Japanese",
		kind: "female"
	},
	{
		id: "jf_nezumi",
		label: "Nezumi",
		accent: "Japanese",
		kind: "female"
	},
	{
		id: "jf_tebukuro",
		label: "Tebukuro",
		accent: "Japanese",
		kind: "female"
	},
	{
		id: "jm_kumo",
		label: "Kumo",
		accent: "Japanese",
		kind: "male"
	}
];
at.filter((e) => e.accent === "Japanese");
var ot = (e) => e.startsWith("jf_") || e.startsWith("jm_") ? "ja" : "en";
async function st(e) {
	let t = new Uint8Array(await e.arrayBuffer()), n = "";
	for (let e = 0; e < t.length; e += 32768) n += String.fromCharCode(...t.subarray(e, e + 32768));
	return btoa(n);
}
var ct = class {
	options;
	base;
	doFetch;
	constructor(e = {}) {
		this.options = e, this.base = (e.url ?? "http://127.0.0.1:47321").replace(/\/$/, "");
		let t = e.fetch;
		this.doFetch = (e, n) => (t ?? fetch)(e, n);
	}
	headers(e = {}) {
		return this.options.token ? {
			Authorization: `Bearer ${this.options.token}`,
			...e
		} : e;
	}
	async probe() {
		if (await this.health()) return "ok";
		try {
			return await this.doFetch(`${this.base}/health`, {
				mode: "no-cors",
				signal: AbortSignal.timeout(2500)
			}), "blocked";
		} catch {
			return "offline";
		}
	}
	async health() {
		try {
			let e = await this.doFetch(`${this.base}/health`, { signal: AbortSignal.timeout(2500) });
			if (!e.ok) return null;
			let t = await e.json();
			return t.app === "gleamshelf-local" ? t : null;
		} catch {
			return null;
		}
	}
	async inpaint(e, t, n) {
		let r = await this.doFetch(`${this.base}/inpaint?model=${encodeURIComponent(t)}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "image/png" }),
			body: e,
			signal: n
		});
		if (!r.ok) throw new H(r.status, await U(r));
		return new Blob([await r.arrayBuffer()], { type: "image/png" });
	}
	async upscale(e, t, n) {
		let r = await this.doFetch(`${this.base}/upscale?model=${encodeURIComponent(t)}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!r.ok) throw new H(r.status, await U(r));
		return new Blob([await r.arrayBuffer()], { type: "image/png" });
	}
	async redraw(e, t, n) {
		let r = new URLSearchParams({ prompt: t.prompt });
		t.stacked && r.set("stacked", "true"), t.clamp === !1 && r.set("clamp", "false"), t.box && r.set("box", t.box.join(",")), t.negative && r.set("negative", t.negative);
		for (let e of [
			"strength",
			"steps",
			"guidance",
			"candidates",
			"seed"
		]) t[e] !== void 0 && r.set(e, String(t[e]));
		let i = await this.doFetch(`${this.base}/redraw?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "image/png" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new H(i.status, await U(i));
		return new Blob([await i.arrayBuffer()], { type: "image/png" });
	}
	async cleanPhoto(e, t = {}, n) {
		let r = new URLSearchParams({ backdrop: t.backdrop ?? "artwork" });
		t.seed !== void 0 && r.set("seed", String(t.seed));
		let i = await this.doFetch(`${this.base}/clean-photo?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new H(i.status, await U(i));
		return new Blob([await i.arrayBuffer()], { type: "image/png" });
	}
	async enhance(e, t = {}, n) {
		let r = new URLSearchParams();
		t.prompt && r.set("prompt", t.prompt), t.negativePrompt && r.set("negativePrompt", t.negativePrompt);
		for (let e of [
			"strength",
			"seed",
			"control",
			"guidance"
		]) t[e] !== void 0 && r.set(e, String(t[e]));
		t.keepColour === !1 && r.set("keepColour", "false");
		let i = await this.doFetch(`${this.base}/enhance?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "image/png" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new H(i.status, await U(i));
		return new Blob([await i.arrayBuffer()], { type: "image/png" });
	}
	gloss(e, t) {
		return this.enhance(e, nt, t);
	}
	async readText(e, t) {
		let n = await this.doFetch(`${this.base}/read-text`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: t
		});
		if (!n.ok) throw new H(n.status, await U(n));
		return (await n.json()).boxes;
	}
	async detectText(e, t, n) {
		let r = await this.doFetch(`${this.base}/detect-text?model=${encodeURIComponent(t)}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!r.ok) throw new H(r.status, await U(r));
		return (await r.json()).boxes;
	}
	async voiceStatus(e) {
		let t = await this.doFetch(`${this.base}/voice`, {
			headers: this.headers(),
			signal: e
		});
		if (t.status === 404 || t.status === 501) return null;
		if (!t.ok) throw new H(t.status, await U(t));
		return await t.json();
	}
	async listen(e, t = {}, n) {
		let r = new URLSearchParams();
		t.language && r.set("language", t.language), t.words?.length && r.set("words", t.words.join(","));
		let i = await this.doFetch(`${this.base}/voice/listen?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "audio/wav" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new H(i.status, await U(i));
		return await i.json();
	}
	async fixWording(e, t = {}, n) {
		let r = await this.doFetch(`${this.base}/voice/fix`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify({
				text: e,
				...t
			}),
			signal: n
		});
		if (!r.ok) throw new H(r.status, await U(r));
		return (await r.json()).text;
	}
	async translate(e, t, n) {
		let r = await this.doFetch(`${this.base}/voice/translate`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify({
				text: e,
				...t
			}),
			signal: n
		});
		if (!r.ok) throw new H(r.status, await U(r));
		return (await r.json()).text;
	}
	async speak(e, t = {}, n) {
		let r = await this.doFetch(`${this.base}/voice/speak`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify({
				text: e,
				...t
			}),
			signal: n
		});
		if (!r.ok) throw new H(r.status, await U(r));
		return new Blob([await r.arrayBuffer()], { type: "audio/wav" });
	}
	async market(e, t, n) {
		let r = await this.doFetch(`${this.base}/market/${e}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify(t),
			signal: n
		});
		if (!r.ok) throw new H(r.status, await U(r));
		return await r.json();
	}
	async marketRules(e) {
		let t = await this.doFetch(`${this.base}/market/rules`, {
			headers: this.headers(),
			signal: e
		});
		if (t.status === 404) return null;
		if (!t.ok) throw new H(t.status, await U(t));
		return await t.json();
	}
	async bootlegCheck(e, t, n = {}, r) {
		let i = JSON.stringify({
			photo: await st(e),
			official: await st(t),
			...n
		}), a = await this.doFetch(`${this.base}/market/bootleg`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: i,
			signal: r
		});
		if (!a.ok) throw new H(a.status, await U(a));
		return await a.json();
	}
	async shapeModels(e) {
		let t = await this.doFetch(`${this.base}/shape3d`, {
			headers: this.headers(),
			signal: e
		});
		if (t.status === 404 || t.status === 501) return null;
		if (!t.ok) throw new H(t.status, await U(t));
		return (await t.json()).models;
	}
	async findShapePictures(e, t, n) {
		let r = t ? await st(t) : void 0, i = await this.doFetch(`${this.base}/shape3d/find`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify({
				identity: e,
				picture: r
			}),
			signal: n
		});
		if (!i.ok) throw new H(i.status, await U(i));
		return (await i.json()).pictures;
	}
	async shapePicture(e, t) {
		let n = await this.doFetch(`${this.base}/shape3d/picture?id=${encodeURIComponent(e)}`, {
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new H(n.status, await U(n));
		return n.blob();
	}
	async makeShapeModel(e, t, n) {
		let r = await Promise.all(t.map(async (e) => e instanceof Blob ? { data: await st(e) } : e)), i = await this.doFetch(`${this.base}/shape3d/make`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify({
				model: e,
				pictures: r
			}),
			signal: n
		});
		if (!i.ok) throw new H(i.status, await U(i));
		return await i.json();
	}
	async shapeModelFile(e, t) {
		let n = await this.doFetch(`${this.base}/shape3d/model?id=${encodeURIComponent(e)}`, {
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new H(n.status, await U(n));
		return new Blob([await n.arrayBuffer()], { type: "model/gltf-binary" });
	}
	async agentStatus(e) {
		let t = await this.doFetch(`${this.base}/agent`, {
			headers: this.headers(),
			signal: e
		});
		if (t.status === 404 || t.status === 501) return null;
		if (!t.ok) throw new H(t.status, await U(t));
		return await t.json();
	}
	async askAgent(e, t = {}, n) {
		let r = await this.doFetch(`${this.base}/agent/ask`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify({
				question: e,
				...t
			}),
			signal: n
		});
		if (!r.ok) throw new H(r.status, await U(r));
		return await r.json();
	}
	async helpStatus(e) {
		let t = await this.doFetch(`${this.base}/help`, {
			headers: this.headers(),
			signal: e
		});
		if (t.status === 404 || t.status === 501) return null;
		if (!t.ok) throw new H(t.status, await U(t));
		return await t.json();
	}
	async askHelp(e, t) {
		let n = await this.doFetch(`${this.base}/help/ask`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify(e),
			signal: t
		});
		if (!n.ok) throw new H(n.status, await U(n));
		return await n.json();
	}
	async shopProducts(e = "", t) {
		let n = await this.doFetch(`${this.base}/agent/products?q=${encodeURIComponent(e)}`, {
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new H(n.status, await U(n));
		return await n.json();
	}
	async shopImage(e, t) {
		let n = await this.doFetch(`${this.base}/agent/image?url=${encodeURIComponent(e)}`, {
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new H(n.status, await U(n));
		return n.blob();
	}
	async writeScript(e, t = 20, n, r = "en") {
		let i = await this.doFetch(`${this.base}/agent/script`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify({
				id: e,
				seconds: t,
				language: r
			}),
			signal: n
		});
		if (!i.ok) throw new H(i.status, await U(i));
		return (await i.json()).script;
	}
	async websiteStatus(e) {
		let t = await this.doFetch(`${this.base}/agent/website`, {
			headers: this.headers(),
			signal: e
		});
		if (t.status === 404 || t.status === 501) return null;
		if (!t.ok) throw new H(t.status, await U(t));
		return await t.json();
	}
	async setWebsite(e, t) {
		let n = await this.doFetch(`${this.base}/agent/website`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify(e),
			signal: t
		});
		if (!n.ok) throw new H(n.status, await U(n));
		return await n.json();
	}
	async setWebsitePortrait(e, t) {
		let n = await this.doFetch(`${this.base}/agent/website/portrait`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "image/jpeg" }),
			body: e,
			signal: t
		});
		if (!n.ok) throw new H(n.status, await U(n));
	}
	async stageLink(e) {
		let t = await this.doFetch(`${this.base}/stage/link`, {
			headers: this.headers(),
			signal: e
		});
		if (t.status === 404 || t.status === 501) return null;
		if (!t.ok) throw new H(t.status, await U(t));
		return await t.json();
	}
	async newStageLink(e) {
		let t = await this.doFetch(`${this.base}/stage/key`, {
			method: "POST",
			headers: this.headers(),
			signal: e
		});
		if (!t.ok) throw new H(t.status, await U(t));
		return (await t.json()).url;
	}
	async setStageAvatar(e, t) {
		let n = await this.doFetch(`${this.base}/stage/avatar`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "model/gltf-binary" }),
			body: e,
			signal: t
		});
		if (!n.ok) throw new H(n.status, await U(n));
		return (await n.json()).version;
	}
	get stageSocket() {
		return `${this.base.replace(/^http/, "ws")}/stage/live`;
	}
	get pairingToken() {
		return this.options.token ?? "";
	}
	async changeVoice(e, t, n) {
		let r = await this.doFetch(`${this.base}/voice/live/change?voice=${t}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "audio/wav" }),
			body: e,
			signal: n
		});
		if (!r.ok) throw new H(r.status, await U(r));
		return new Blob([await r.arrayBuffer()], { type: "audio/wav" });
	}
	async buildLiveVoice(e, t) {
		let n = await this.doFetch(`${this.base}/voice/live/build?voice=${e}`, {
			method: "POST",
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new H(n.status, await U(n));
		return await n.json();
	}
	async convertLive(e, t, n) {
		let r = new URLSearchParams({
			voice: t.voice,
			session: t.session
		});
		t.reset && r.set("reset", "1");
		let i = await this.doFetch(`${this.base}/voice/live?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "audio/wav" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new H(i.status, await U(i));
		return new Blob([await i.arrayBuffer()], { type: "audio/wav" });
	}
	async startProcess(e, t = {}, n) {
		let r = new URLSearchParams();
		t.mode && r.set("mode", t.mode), t.vivid !== void 0 && r.set("vivid", String(t.vivid));
		for (let e of [
			"find",
			"listing",
			"enlarge",
			"stickers",
			"lettering",
			"thinParts",
			"colour",
			"look",
			"gloss",
			"review"
		]) t[e] !== void 0 && r.set(e, t[e] ? "1" : "0");
		let i = await this.doFetch(`${this.base}/process?${r}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new H(i.status, await U(i));
		return (await i.json()).id;
	}
	async processStatus(e, t) {
		let n = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}`, {
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new H(n.status, await U(n));
		return await n.json();
	}
	async foundPicture(e, t, n) {
		let r = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/found/${t}.jpg`, {
			headers: this.headers(),
			signal: n
		});
		if (!r.ok) throw new H(r.status, await U(r));
		return new Blob([await r.arrayBuffer()], { type: "image/jpeg" });
	}
	async chooseReferences(e, t, n) {
		let r = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/choose`, {
			method: "POST",
			headers: this.headers({ "Content-Type": "application/json" }),
			body: JSON.stringify({ use: t }),
			signal: n
		});
		if (!r.ok) throw new H(r.status, await U(r));
	}
	async cancelProcess(e, t) {
		let n = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/cancel`, {
			method: "POST",
			headers: this.headers(),
			signal: t
		});
		if (!n.ok && n.status !== 404) throw new H(n.status, await U(n));
	}
	async processPicture(e, t = "cutout", n) {
		let r = t === "cutout" ? "cutout.png" : t === "changes" ? "changes.png" : t === "promo" ? "promo.jpg" : "studio.jpg", i = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/${r}`, {
			headers: this.headers(),
			signal: n
		});
		if (!i.ok) throw new H(i.status, await U(i));
		return new Blob([await i.arrayBuffer()], { type: t === "studio" || t === "promo" ? "image/jpeg" : "image/png" });
	}
	async recentRuns(e) {
		let t = await this.doFetch(`${this.base}/process/recent`, {
			headers: this.headers(),
			signal: e
		});
		if (!t.ok) throw new H(t.status, await U(t));
		return (await t.json()).runs;
	}
	async shopStatus(e) {
		let t = await this.doFetch(`${this.base}/shop`, {
			headers: this.headers(),
			signal: e
		});
		if (!t.ok) throw new H(t.status, await U(t));
		return await t.json();
	}
	async shopConnect(e, t, n) {
		let r = await this.doFetch(`${this.base}/shop/connect`, {
			method: "POST",
			headers: {
				...this.headers(),
				"Content-Type": "application/json"
			},
			body: JSON.stringify({
				address: e,
				code: t
			}),
			signal: n
		});
		if (!r.ok) throw new H(r.status, await U(r));
		return await r.json();
	}
	async sendRun(e, t) {
		let n = await this.doFetch(`${this.base}/process/${encodeURIComponent(e)}/send`, {
			method: "POST",
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new H(n.status, await U(n));
		return await n.json();
	}
	async phoneStart(e) {
		let t = await this.doFetch(`${this.base}/phone/start`, {
			method: "POST",
			headers: this.headers(),
			signal: e
		});
		if (!t.ok) throw new H(t.status, await U(t));
		return await t.json();
	}
	async phonePhotos(e) {
		let t = await this.doFetch(`${this.base}/phone/photos`, {
			headers: this.headers(),
			signal: e
		});
		if (!t.ok) throw new H(t.status, await U(t));
		return (await t.json()).photos;
	}
	async phonePhoto(e, t) {
		let n = await this.doFetch(`${this.base}/phone/photos/${encodeURIComponent(e)}`, {
			headers: this.headers(),
			signal: t
		});
		if (!n.ok) throw new H(n.status, await U(n));
		return new Blob([await n.arrayBuffer()], { type: n.headers.get("Content-Type") ?? "image/jpeg" });
	}
	async models() {
		let e = await this.doFetch(`${this.base}/models`, { headers: this.headers() });
		if (!e.ok) throw new H(e.status, await U(e));
		return (await e.json()).models;
	}
	async cutout(e, t, n, r = {}) {
		let i = await this.doFetch(`${this.base}/cutout?model=${encodeURIComponent(t)}${r.thinParts ? "&refine=thin" : ""}`, {
			method: "POST",
			headers: this.headers({ "Content-Type": e.type || "application/octet-stream" }),
			body: e,
			signal: n
		});
		if (!i.ok) throw new H(i.status, await U(i));
		let a = Number(i.headers.get("X-Mask-Width")), o = Number(i.headers.get("X-Mask-Height")), s = new Uint8Array(await i.arrayBuffer());
		if (!(a > 0 && o > 0) || s.length !== a * o) throw new H(502, "The companion app sent a mask in a format this editor does not understand.");
		return {
			alpha: s,
			width: a,
			height: o,
			...i.headers.get("X-Mask-Parts") === "kept" ? { partsKept: !0 } : {}
		};
	}
};
async function U(e) {
	let t = await e.json().catch(() => null);
	return e.status === 401 ? "The companion app did not accept the pairing token. Copy it again from the app and paste it in." : t?.error ?? `The companion app answered ${e.status}.`;
}
//#endregion
//#region src/useLocalApp.ts
var W = "gleamshelf:local-app";
function lt() {
	try {
		let e = /(?:^#|&)pair=([A-Za-z0-9_-]{16,128})/.exec(window.location.hash);
		return e ? (window.history.replaceState(null, "", window.location.pathname + window.location.search), e[1]) : null;
	} catch {
		return null;
	}
}
function ut() {
	let e = lt();
	if (!e) return null;
	let t = rt;
	try {
		let e = JSON.parse(localStorage.getItem(W) ?? "{}");
		typeof e.url == "string" && (t = e.url);
	} catch {}
	return ft({
		url: t,
		token: e
	}), {
		url: t,
		token: e
	};
}
function dt() {
	let e = ut();
	if (e) return e;
	try {
		let e = JSON.parse(localStorage.getItem(W) ?? "{}");
		return {
			url: typeof e.url == "string" ? e.url : rt,
			token: typeof e.token == "string" ? e.token : ""
		};
	} catch {
		return {
			url: rt,
			token: ""
		};
	}
}
function ft(e) {
	try {
		localStorage.setItem(W, JSON.stringify(e));
	} catch {}
}
var pt = !0, mt = /* @__PURE__ */ new Set();
function ht(e) {
	pt !== e && (pt = e, mt.forEach((e) => e()));
}
var gt = null;
function _t(e) {
	gt !== e && (gt = e, mt.forEach((e) => e()));
}
function vt() {
	return ge(yt, () => gt);
}
var yt = (e) => (mt.add(e), () => mt.delete(e));
function bt(e) {
	let [t, n] = M(() => ({
		...dt(),
		...e?.url ? { url: e.url } : {},
		...e?.token ? { token: e.token } : {}
	})), r = ge(yt, () => pt) || !!t.token, [i, a] = M(r ? "checking" : "offline"), [o, s] = M(null), [c, l] = M(null), [u, d] = M([]), f = he(() => new ct({
		url: t.url,
		token: t.token
	}), [t]), p = pe(async () => {
		l(null);
		let e = await f.probe();
		if (e === "ok" && d((await f.health())?.features ?? []), e !== "ok") a(e === "blocked" ? "blocked" : "offline"), s(null);
		else if (!t.token) a("needs-token"), s(null);
		else try {
			s(await f.models()), a("ready");
		} catch (e) {
			s(null), l(e instanceof Error ? e.message : "The companion app did not answer."), e instanceof H && e.status === 401 ? (n((e) => ({
				...e,
				token: ""
			})), a("needs-token")) : a("offline");
		}
	}, [f, t.token]);
	A(() => {
		r && p();
	}, [p, r]), A(() => {
		if (!r || i !== "offline" && i !== "blocked") return;
		let e = setInterval(() => void p(), 3e3);
		return () => clearInterval(e);
	}, [i, p]);
	let m = (e) => {
		let r = {
			...t,
			token: e.trim()
		};
		ft(r), n(r);
	}, h = (e) => o?.filter((t) => t.task === e && t.installed) ?? [], g = u.includes("process"), _ = u.includes("phone"), v = u.includes("shop"), y = u.includes("market");
	return {
		state: i,
		saved: t,
		client: f,
		models: o,
		installed: h,
		problem: c,
		setProblem: l,
		check: pe(async () => {
			ht(!0), await p();
		}, [p]),
		connect: m,
		canProcess: g,
		canPhone: _,
		canShop: v,
		canMarket: y,
		looking: r
	};
}
typeof window < "u" && ut();
//#endregion
//#region src/NoCloudAi.tsx
function xt({ app: e, feature: t, compact: n = !1 }) {
	let r = vt();
	return r ? /* @__PURE__ */ F("div", {
		className: `gs-nocloud ${n ? "gs-nocloud--compact" : ""}`,
		role: "note",
		children: [/* @__PURE__ */ F("p", { children: [
			/* @__PURE__ */ P("strong", { children: "Cloud AI isn't available yet." }),
			" ",
			t,
			" runs free on your own computer with the Gleamshelf app. Your photos never leave it."
		] }), /* @__PURE__ */ F("div", {
			className: "gs-nocloud__actions",
			children: [/* @__PURE__ */ P("a", {
				className: "gs-button",
				href: r,
				target: "_blank",
				rel: "noreferrer",
				children: "Run it on your computer: step by step"
			}), /* @__PURE__ */ P("button", {
				type: "button",
				className: "gs-button",
				onClick: () => void e.check(),
				children: e.looking ? "Check again" : "Already running it? Look for the app"
			})]
		})]
	}) : null;
}
//#endregion
//#region src/zip.ts
var St = (() => {
	let e = /* @__PURE__ */ new Uint32Array(256);
	for (let t = 0; t < 256; t++) {
		let n = t;
		for (let e = 0; e < 8; e++) n = n & 1 ? 3988292384 ^ n >>> 1 : n >>> 1;
		e[t] = n >>> 0;
	}
	return e;
})();
function Ct(e) {
	let t = 4294967295;
	for (let n = 0; n < e.length; n++) t = St[(t ^ e[n]) & 255] ^ t >>> 8;
	return (t ^ 4294967295) >>> 0;
}
function wt(e) {
	let t = new TextEncoder(), n = [], r = [], i = 0, a = 23585;
	for (let o of e) {
		let e = t.encode(o.name), s = Ct(o.bytes), c = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(30));
		c.setUint32(0, 67324752, !0), c.setUint16(4, 20, !0), c.setUint16(6, 2048, !0), c.setUint16(8, 0, !0), c.setUint16(10, 0, !0), c.setUint16(12, a, !0), c.setUint32(14, s, !0), c.setUint32(18, o.bytes.length, !0), c.setUint32(22, o.bytes.length, !0), c.setUint16(26, e.length, !0), n.push(new Uint8Array(c.buffer), e, o.bytes);
		let l = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(46));
		l.setUint32(0, 33639248, !0), l.setUint16(4, 20, !0), l.setUint16(6, 20, !0), l.setUint16(8, 2048, !0), l.setUint16(10, 0, !0), l.setUint16(12, 0, !0), l.setUint16(14, a, !0), l.setUint32(16, s, !0), l.setUint32(20, o.bytes.length, !0), l.setUint32(24, o.bytes.length, !0), l.setUint16(28, e.length, !0), l.setUint32(42, i, !0), r.push(new Uint8Array(l.buffer), e), i += 30 + e.length + o.bytes.length;
	}
	let o = r.reduce((e, t) => e + t.length, 0), s = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(22));
	s.setUint32(0, 101010256, !0), s.setUint16(8, e.length, !0), s.setUint16(10, e.length, !0), s.setUint32(12, o, !0), s.setUint32(16, i, !0);
	let c = [
		...n,
		...r,
		new Uint8Array(s.buffer)
	], l = new Uint8Array(c.reduce((e, t) => e + t.length, 0)), u = 0;
	for (let e of c) l.set(e, u), u += e.length;
	return l;
}
//#endregion
//#region src/ShaderControls.tsx
function Tt(e, t, n) {
	let r = t < .1 ? 2 : +(t < 1);
	return `${e.toFixed(r)}${n ?? ""}`;
}
function Et({ spec: e, value: t, onChange: n, onBegin: r, onCommit: i }) {
	if (e.kind === "number") {
		let a = Number(t);
		return /* @__PURE__ */ F("label", {
			className: "gs-control",
			children: [/* @__PURE__ */ F("span", {
				className: "gs-control__row",
				children: [/* @__PURE__ */ P("span", { children: e.label }), /* @__PURE__ */ P("output", {
					className: a === e.default ? "" : "is-changed",
					children: Tt(a, e.step, e.unit)
				})]
			}), /* @__PURE__ */ P("input", {
				type: "range",
				style: Wt(a, e.min, e.max),
				min: e.min,
				max: e.max,
				step: e.step,
				value: a,
				onPointerDown: r,
				onPointerUp: i,
				onLostPointerCapture: i,
				onChange: (e) => n(Number(e.target.value)),
				onDoubleClick: () => n(e.default)
			})]
		});
	}
	return e.kind === "boolean" ? /* @__PURE__ */ F("label", {
		className: "gs-control gs-control--inline",
		children: [/* @__PURE__ */ P("input", {
			type: "checkbox",
			checked: t === !0,
			onChange: (e) => n(e.target.checked)
		}), e.label]
	}) : e.kind === "color" ? /* @__PURE__ */ F("label", {
		className: "gs-control gs-control--inline",
		children: [/* @__PURE__ */ P("input", {
			type: "color",
			value: String(t),
			"aria-label": e.label,
			onFocus: r,
			onBlur: i,
			onChange: (e) => n(e.target.value)
		}), e.label]
	}) : /* @__PURE__ */ F("label", {
		className: "gs-control",
		children: [/* @__PURE__ */ P("span", {
			className: "gs-control__row",
			children: /* @__PURE__ */ P("span", { children: e.label })
		}), /* @__PURE__ */ P("select", {
			value: String(t),
			onChange: (e) => n(e.target.value),
			children: e.options.map((e) => /* @__PURE__ */ P("option", {
				value: e,
				children: e
			}, e))
		})]
	});
}
function G({ steps: e, catalog: t, known: n, title: r, empty: i, onAdd: a, onRemove: o, onMove: s, onParam: c, onBegin: l, onCommit: u }) {
	return /* @__PURE__ */ F("section", { children: [
		/* @__PURE__ */ P("h2", { children: r }),
		e.length === 0 && /* @__PURE__ */ P("p", {
			className: "gs-hint",
			children: i
		}),
		e.map((t, r) => {
			let i = n(t.id), a = i ? D(i, t.params) : t.params;
			return /* @__PURE__ */ F("div", {
				className: "gs-effect",
				children: [
					/* @__PURE__ */ F("div", {
						className: "gs-effect__head",
						children: [/* @__PURE__ */ P("strong", {
							title: i?.description,
							children: i?.name ?? t.id
						}), /* @__PURE__ */ F("span", {
							className: "gs-effect__buttons",
							children: [
								/* @__PURE__ */ P("button", {
									type: "button",
									className: "gs-button gs-button--small",
									disabled: r === 0,
									onClick: () => s(r, -1),
									"aria-label": "Move up",
									title: "Move up (it runs earlier)",
									children: "↑"
								}),
								/* @__PURE__ */ P("button", {
									type: "button",
									className: "gs-button gs-button--small",
									disabled: r === e.length - 1,
									onClick: () => s(r, 1),
									"aria-label": "Move down",
									title: "Move down (it runs later)",
									children: "↓"
								}),
								/* @__PURE__ */ P("button", {
									type: "button",
									className: "gs-button gs-button--small",
									onClick: () => o(r),
									"aria-label": `Remove ${i?.name ?? t.id}`,
									title: "Remove",
									children: "✕"
								})
							]
						})]
					}),
					!i && /* @__PURE__ */ P("p", {
						className: "gs-hint",
						children: "This effect's shader file is not installed, so it is skipped."
					}),
					i?.params.map((e) => /* @__PURE__ */ P(Et, {
						spec: e.spec,
						value: a[e.key] ?? e.spec.default,
						onChange: (t) => c(r, e.key, t, `${i.name}: ${e.spec.label}`),
						onBegin: () => l(`${i.name}: ${e.spec.label}`),
						onCommit: u
					}, e.key))
				]
			}, `${t.id}-${r}`);
		}),
		e.length < 12 && t.length > 0 && /* @__PURE__ */ F("select", {
			className: "gs-effect__add",
			"aria-label": `Add to ${r.toLowerCase()}`,
			value: "",
			onChange: (e) => {
				let n = t.find((t) => t.id === e.target.value);
				n && a(n), e.currentTarget.blur();
			},
			children: [/* @__PURE__ */ P("option", {
				value: "",
				children: "+ Add…"
			}), t.map((e) => /* @__PURE__ */ P("option", {
				value: e.id,
				title: e.description,
				children: e.name
			}, e.id))]
		})
	] });
}
//#endregion
//#region src/instructions.ts
var Dt = [
	"Top bar",
	"One click",
	"Cut out",
	"Clean up",
	"Adjust",
	"Edit mode",
	"Photo lab",
	"3D mode",
	"Avatar mode",
	"Market"
], Ot = {
	undo: {
		group: "Top bar",
		name: "Undo and redo",
		user: "Steps back one change at a time (Ctrl+Z); Ctrl+Shift+Z steps forward again.",
		dev: "editor.undo()/redo() over the recipe history: packages/core/src/history.ts. A slider drag is one step (editor.begin/commit)."
	},
	ask: {
		group: "Top bar",
		name: "Ask",
		user: "Ask (top bar): type where something is or how to do it, in English or Japanese. What to press lights up; Read aloud says it.",
		dev: "packages/react/src/AskPanel.tsx with ask.ts (rankHelp over HELP, screenControls/rankControls, answerParts). With the app and the vision model: POST /help/ask (apps/local/src/help.ts, the controls named [c12]); otherwise the best guide line. Answers in the language of the question (questionLang); Read aloud in askVoice.ts: Kokoro when the app voice is set up (English; Japanese with npm run voice:setup -- --japanese, jf_alpha), else speechSynthesis with a voice that runs on the computer (never an online one)."
	},
	compare: {
		group: "Top bar",
		name: "Compare",
		user: "Hold it (or hold \\) to see the photo as it was; let go to see your changes.",
		dev: "While held, GleamEditor draws createDocument(doc.source) instead of the edited document; nothing is changed."
	},
	reset: {
		group: "Top bar",
		name: "Reset",
		user: "Takes every change off and shows the photo as it was. Undo brings them back.",
		dev: "editor.reset() sets the default recipe as one undo step: packages/core/src/editor.ts."
	},
	editMode: {
		group: "Top bar",
		name: "Edit mode",
		user: "Opens the picture with layers, brushes, selections, shapes and text (E). Done brings it back here.",
		dev: "packages/react/src/edit/EditMode.tsx over @gleamshelf/canvas (CanvasDocument, COMMANDS). The same commands run headless: npm run mcp, docs/MCP.md."
	},
	photoLab: {
		group: "Top bar",
		name: "Photo lab",
		user: "Opens the photo for hand editing: develop sliders, looks, retouching, every filter and adjustment, layers (L).",
		dev: "packages/react/src/photolab/PhotoLab.tsx over @gleamshelf/craft (PhotoCraft engine + LightCraft develop in WebAssembly, in a worker)."
	},
	phone: {
		group: "Top bar",
		name: "From phone",
		user: "Scan the code with a phone on the same Wi-Fi, take photos, and click one here to edit it. Photos stay on your network.",
		dev: "startPhoneCapture (apps/local/src/phone.ts): a LAN page with a random code; /phone routes on 127.0.0.1; PhoneCapture.tsx polls phonePhotos. A host start screen uses PhoneStart (same panel, before a photo is open)."
	},
	done: {
		group: "Top bar",
		name: "Done",
		user: "Saves the finished picture and closes the editor.",
		dev: "Renders the recipe at full size (packages/render2d) and calls onDone(blob, recipe); export options come from GleamEditorProps.exportOptions."
	},
	guide: {
		group: "Top bar",
		name: "Guide",
		user: "Lists every feature with how to use it. Tick \"Developer notes\" to see how each one works.",
		dev: "Built from HELP in packages/react/src/instructions.ts; the switch is stored in localStorage \"gleamshelf:dev-notes\"."
	},
	lookForApp: {
		group: "Top bar",
		name: "Look for the app",
		user: "On the free website, the AI tools look for the Gleamshelf app on this computer only after you click Look for the app.",
		dev: "apps/web/src/main.tsx calls setLookForLocalApp(false) (packages/react/src/useLocalApp.ts): no request to 127.0.0.1 until a click or a saved pairing token."
	},
	handTools: {
		group: "Top bar",
		name: "Hand tools only",
		user: "On the free website every hand tool works here. AI tools link to a guide for running the free app on your computer.",
		dev: "GleamEditorProps.handToolsOnly (set by apps/web/src/App.tsx): without the app (PanelProps.appReady) Panel shows appNotice in place of One click and stickers; the AI slots stay and their LocalAppHelp shows NoCloudAi. The guide link is setLocalAppGuide in apps/web/src/main.tsx (/run-locally, apps/web/src/RunLocally.tsx)."
	},
	noCloudAi: {
		group: "Top bar",
		name: "Cloud AI not available yet",
		user: "No cloud AI yet: follow the step-by-step guide to run the app on your computer, or look for it if it is running.",
		dev: "packages/react/src/NoCloudAi.tsx, shown only when setLocalAppGuide(url) is set (apps/web/src/main.tsx) and the app is not reached: LocalAppHelp (photo editor, Market), PhotosDialog, DrawSection, VoiceDialog, ScenePanel, Panel.appNotice."
	},
	autoRun: {
		group: "One click",
		name: "Make it listing-ready",
		user: "Pick what to keep, untick any step you do not want (under Steps), then press the button. It takes a few minutes.",
		dev: "Steps fold under one summary line; the running step also shows as a badge on the picture (GleamEditor). POST /process on the companion app (startProcess, polled with processStatus) runs processPhoto in apps/local/src/chain.ts, the same as `npm run batch -- <dir> --out <dir>`."
	},
	autoMode: {
		group: "One click",
		name: "Whole box, Character on cover, Auto",
		user: "Whole box keeps the box; Character on cover keeps only the character; Auto picks for each photo.",
		dev: "ChainOptions.mode = product | character | auto (batch --mode). Auto uses classifyBoxView in packages/pipeline/src/view.ts."
	},
	foundPhotos: {
		group: "One click",
		name: "Found online",
		user: "Untick any picture that isn't your product, then Use. With no choice in 20 s it goes on with the ones that line up.",
		dev: "The run waits (status \"waiting\", found: FoundOnline) after lookUp in chain.ts; POST /process/:id/choose {use} lets it go on; FOUND_WAIT_SECONDS countdown in Panel.tsx."
	},
	autoReport: {
		group: "One click",
		name: "What the run found",
		user: "Check the score, anything marked, and the listing before you list. Copy takes the text; Every marketplace saves the pictures.",
		dev: "ProcessStatus.report: notes (folded under What the run did), flags, lookup and listing from processPhoto; the panel scrolls to it when it arrives; the batch writes the same to reports/<name>.json and needs-review.txt."
	},
	sendToShop: {
		group: "One click",
		name: "Send to the shop",
		user: "Sends the photo and listing to the shop’s Imports as a draft; nothing is published until someone there adds it.",
		dev: "ShopSend (Panel.tsx) → POST /process/<id>/send and /shop/connect on the companion app (apps/local/src/shoplink.ts): draftFrom + pushDraft, the same as npm run push."
	},
	makeAd: {
		group: "One click",
		name: "3D ad",
		user: "Opens 3D mode with this product’s cut-out, name and series ready for an ad; type the price, pick a layout, then save a video.",
		dev: "GleamEditor makeAd: processPicture(runId, cutout) and the report’s identity and listing into ModelMode’s ad (AdDialog, buildAd)."
	},
	make3d: {
		group: "One click",
		name: "3D model",
		user: "Opens 3D mode with this cut-out to make a 3D model of the figure; add photos from other angles or find the maker's.",
		dev: "GleamEditor make3d: processPicture(runId, cutout) and the report identity into ModelMode photos (PhotosDialog, /shape3d)."
	},
	autoBack: {
		group: "One click",
		name: "Back to the original photo",
		user: "Closes the finished picture and opens your photo as it was.",
		dev: "full.goBack in GleamEditor: reloads `source` and drops the processPicture result."
	},
	"step.stickers": {
		group: "One click",
		name: "Remove price stickers",
		user: "Paints out the shop’s price stickers so the photo stays right when the price changes.",
		dev: "findPriceStickers in chain.ts (text reader + prices.ts), then LaMa inpaint. Batch: --no-stickers turns it off."
	},
	"step.lettering": {
		group: "One click",
		name: "Repaint lettering",
		user: "For a character on a cover: paints out the title and printed text before cutting out.",
		dev: "cleanPicture in chain.ts (text finder, titleInk/thinStrokes in packages/pipeline/src/printed.ts, LaMa). Batch: --no-lettering."
	},
	"step.find": {
		group: "One click",
		name: "Look the product up",
		user: "Searches the web first, with words read from the box (never the photo), and shows you what it found before using any.",
		dev: "identifyProduct (identify.ts, local VLM) then findReferenceFiles (refs.ts, SearXNG) and findOfficialPhoto (official.ts). Batch: --offline turns it off."
	},
	"step.thinParts": {
		group: "One click",
		name: "Complete what the box hides",
		user: "Finds thin parts the cut-out missed and fills parts hidden by printing from a matching official photo. Check them.",
		dev: "completeFromReferences + fillFromReference in apps/local/src/reference.ts (register.py: SIFT + RANSAC). Batch: --no-thin-parts."
	},
	"step.colour": {
		group: "One click",
		name: "Match colours",
		user: "Brings the colours to the product’s official picture. Needs the web lookup.",
		dev: "colourFromReferences in reference.ts (Lab transfer from registered references). Batch: --no-colour."
	},
	"step.vivid": {
		group: "One click",
		name: "Punchier colours",
		user: "Makes the matched colours 40% stronger. Untick to keep the softer published colours.",
		dev: "Chroma gain after colour matching; batch --vivid <1-2> (default 1.4, 1 is off)."
	},
	"step.look": {
		group: "One click",
		name: "Brighten and sharpen",
		user: "Gives the finished picture a little more light, colour and sharpness.",
		dev: "The \"Bright & sharp\" look (packages/core/src/looks.ts) via enhance() in packages/pipeline/src/enhance.ts. Batch: --no-look."
	},
	"step.gloss": {
		group: "One click",
		name: "Studio gloss",
		user: "Redraws the product as a glossy studio shot. It changes the product, so it is off unless you tick it.",
		dev: "client.gloss → POST /enhance with STUDIO_GLOSS (SDXL tile, apps/modelserver); printed text pasted back. Batch: --gloss; setup: npm run redraw:setup."
	},
	"step.enlarge": {
		group: "One click",
		name: "Enlarge",
		user: "Makes the picture bigger with more detail; printed text is enlarged plainly so it is not rewritten.",
		dev: "POST /upscale (RealPLKSR / Real-ESRGAN, apps/local/src/enlarge.ts). Batch: --no-enlarge; --size sets the output."
	},
	"step.listing": {
		group: "One click",
		name: "Write a title and description",
		user: "Writes the listing only from facts that were found. Check any numbers it marks.",
		dev: "apps/local/src/listing.ts (factList, local VLM, withoutSellerTalk filters). Batch: --write-listing; needs npm run vlm:setup."
	},
	green: {
		group: "Cut out",
		name: "Remove green backdrop",
		user: "For photos on a green cloth: press it and the green goes. Free and instant.",
		dev: "editor.removeGreenBackdrop() adds a \"green\" mask op; keyOutGreen in packages/pipeline/src/key.ts."
	},
	cutManual: {
		group: "Cut out",
		name: "Cut out by hand",
		user: "Press Cut out product, then tap the background or paint with Erase and Restore. Press Done when it looks right.",
		dev: "CutoutOverlay.tsx appends \"fill\" and \"brush\" ops to recipe.mask (packages/core/src/mask.ts); the renderer turns them into alpha."
	},
	"cut.tap": {
		group: "Cut out",
		name: "Tap",
		user: "Click the background to remove everything of a similar colour around it. Tolerance sets how similar.",
		dev: "A FillOp {x, y, tolerance} in recipe.mask: the connected region of similar colour (packages/core/src/mask.ts)."
	},
	"cut.erase": {
		group: "Cut out",
		name: "Erase",
		user: "Paint over anything that should go. Brush size sets the width.",
		dev: "A BrushOp {mode: \"remove\", radius, points} in recipe.mask (packages/core/src/mask.ts); radius is a share of the long side."
	},
	"cut.restore": {
		group: "Cut out",
		name: "Restore",
		user: "Paint over anything that should come back.",
		dev: "A BrushOp with mode \"keep\" in recipe.mask (packages/core/src/mask.ts): later ops win over earlier ones."
	},
	fade: {
		group: "Cut out",
		name: "Fade bottom",
		user: "Softens a hard bottom edge, such as a figure cut off at the waist.",
		dev: "editor.fadeBottom(0.1): a FadeOp {edge: \"bottom\", size} in recipe.mask (packages/core/src/mask.ts)."
	},
	clearMask: {
		group: "Cut out",
		name: "Clear",
		user: "Brings back the whole photo, background and all.",
		dev: "editor.clearMask() empties recipe.mask as one undo step."
	},
	aiCutout: {
		group: "Cut out",
		name: "AI cut-out",
		user: "Choose Whole product or Character on cover, then press the cut-out button. For a character, crop to the artwork first.",
		dev: "client.cutout → POST /cutout (BiRefNet; SAM 3.1 with thinParts for characters). The mask lands as a \"model\" op: AiCutout.tsx."
	},
	promoPicture: {
		group: "Cut out",
		name: "Promo picture",
		user: "Your real product, never redrawn, on a backdrop in its own colours. For ads and your own pages; marketplaces get the white one.",
		dev: "promoShot in packages/pipeline/src/promo.ts (boxLean, backdropColours); processPhoto result.promo; batch writes name.promo.jpg (--no-promo); jobs keeps promo.jpg; PromoPicture in Panel.tsx."
	},
	cleanPhoto: {
		group: "Cut out",
		name: "Clean product photo",
		user: "After a run on a box photo: pick a backdrop, press Make a clean photo. AI redraws the figure, so check it against the real one.",
		dev: "CleanPhoto in panel/AutoSection.tsx → client.cleanPhoto → POST /clean-photo (apps/local/src/server.ts) → model server job clean-photo (jobs.py) → apps/local/python/cleanphoto.py: green-key box crop to ~1 MP, FLUX.2 klein 4B edit (4 steps), text encoder and transformer in separate processes. Workspace keeps each run's photo (runPhotos). Setup: npm run clean-photo:setup."
	},
	studio: {
		group: "Cut out",
		name: "Studio photo",
		user: "After cutting out: one press gives a white, square picture with a soft shadow.",
		dev: "studioPhoto in GleamEditor: white backdrop, editor.fitSquareToProduct(box, 0.07) and a \"drop-shadow\" effect, as one undo step."
	},
	recentRuns: {
		group: "One click",
		name: "Recent results",
		user: "Every finished run is kept on this computer: open one again instantly, with its picture and listing, no waiting.",
		dev: "ProcessJobs keeps runs in ~/.gleamshelf/runs/<id> (apps/local/src/jobs.ts); /process/recent lists them; opening one reuses openFinishedRun in GleamEditor."
	},
	fidelityGuard: {
		group: "One click",
		name: "Fidelity guard",
		user: "Where enlarging made detail up, the plain picture goes back. \"Show what is not as photographed\" tints what was changed.",
		dev: "guardChanges after the enlarge step in processPhoto; fidelityOverlay (packages/pipeline/src/quality.ts) as /process/<id>/changes.png."
	},
	flatten: {
		group: "Cut out",
		name: "Flatten card or box front",
		user: "After cutting out a card or a box front shot at an angle: one press pulls its corners straight, only its own pixels.",
		dev: "quadFromMask and flattenCutout (packages/pipeline/src/flatten.ts): largest four-cornered shape in the hull, then a perspective warp."
	},
	listingHealth: {
		group: "One click",
		name: "Listing health",
		user: "After a run: a score out of 100, how sure the cut-out is, how much is as photographed, and the top three fixes.",
		dev: "listingHealth (apps/local/src/health.ts) over the listing; cutoutConfidence and fidelityCheck (packages/pipeline/src/quality.ts) in processPhoto."
	},
	ground: {
		group: "Cut out",
		name: "Shadow and reflection",
		user: "Soft shadow, Contact shadow and Reflection make the product stand on a surface; fine-tune each under Look.",
		dev: "Effects drop-shadow, contact-shadow and reflection (packages/shaders/fragment/*.frag.glsl, scope product): each finds the base per column."
	},
	listingSet: {
		group: "Cut out",
		name: "Listing set",
		user: "Tick the marketplaces and save: one picture each, in that site's size and framing, all in one zip.",
		dev: "MARKETPLACE_PRESETS and presetDocument (packages/core/src/presets.ts) give each variant; renderer.export per preset; zipFiles (packages/react/src/zip.ts). Also under a finished one-click run (AutoSection)."
	},
	backdrop: {
		group: "Cut out",
		name: "Behind the product",
		user: "Choose None (transparent), a Colour, or your own Photo to go behind the cut-out.",
		dev: "The \"backdrop\" op (mode, color) in packages/core/src/ops.ts; a photo is passed to the renderer as `background`."
	},
	square: {
		group: "Cut out",
		name: "Square picture",
		user: "Fit square to product centres the product on a square; Space around sets the margin.",
		dev: "editor.fitSquareToProduct(maskBounds(...)); the \"canvas\" op (square, margin %) in packages/core/src/ops.ts."
	},
	stickers: {
		group: "Clean up",
		name: "Remove price stickers",
		user: "Press it and the shop’s price stickers are found and painted out.",
		dev: "client.readText → POST /read-text, prices told from printing (apps/local/src/prices.ts), then POST /inpaint (LaMa)."
	},
	stickerClick: {
		group: "Clean up",
		name: "Click a sticker",
		user: "If one was missed, press this and click the sticker on the picture.",
		dev: "PickOverlay.tsx → tightenStickerBox (packages/pipeline/src/stickers.ts) → inpaint."
	},
	textClick: {
		group: "Clean up",
		name: "Click printed text",
		user: "For a big title left behind: click one letter and the rest of that text is painted out.",
		dev: "colourKeyedStrokes in packages/pipeline/src/printed.ts from the clicked colour, inside the detectText box; then inpaint."
	},
	lettering: {
		group: "Clean up",
		name: "Remove white lettering",
		user: "Press it to paint out white words across the picture. Cut out first to keep it to the product.",
		dev: "editor.setWords(true): findWhiteWords / removeWhiteWords in packages/pipeline/src/words.ts."
	},
	letteringSliders: {
		group: "Clean up",
		name: "Lettering settings",
		user: "Lower How white if lettering is missed; Thickest stroke and Shortest piece leave bows and glints alone.",
		dev: "WordsOptions lightness, maxWidth, minLength (packages/pipeline/src/words.ts); each drag is one undo step."
	},
	aiFill: {
		group: "Clean up",
		name: "AI fill",
		user: "Press Fill with AI to repaint the lettering cleanly instead of the soft free fill.",
		dev: "AiFill.tsx: client.inpaint → POST /inpaint (LaMa), optionally with detectText boxes for other printed text."
	},
	finish: {
		group: "Clean up",
		name: "Finishing touches",
		user: "Type what the area should be, press Choose the area, and drag over it. Check the result before listing.",
		dev: "AiFinish.tsx + AreaOverlay.tsx: client.redraw → POST /redraw (SDXL inpaint, box). Set up with npm run redraw:setup."
	},
	rotate: {
		group: "Adjust",
		name: "Rotate and flip",
		user: "Turn the picture a quarter at a time, or mirror it.",
		dev: "editor.rotate(±1) / flip(axis): the \"orient\" op; rotate also turns the crop (packages/core/src/editor.ts)."
	},
	crop: {
		group: "Adjust",
		name: "Crop",
		user: "Press Crop (C), drag the corners, then press Done or Enter. Pick a shape from the list first if you need one.",
		dev: "CropOverlay.tsx edits the \"crop\" op; editor.setCropAspect(aspect) with CROP_ASPECTS from packages/core."
	},
	straighten: {
		group: "Adjust",
		name: "Straighten",
		user: "Drag until the box stands straight. Double-click the slider to reset.",
		dev: "The \"straighten\" op (angle, ±45°), applied by the renderer in packages/render2d."
	},
	looks: {
		group: "Adjust",
		name: "Looks",
		user: "Press a look for livelier colour and detail; Natural takes it off.",
		dev: "LOOKS in packages/core/src/looks.ts set light, colour and a sharpen effect; editor.applyLook / clearLook."
	},
	autoLook: {
		group: "Adjust",
		name: "Brighter and sharper after an AI step",
		user: "Leave it ticked to brighten and sharpen automatically after AI cut-outs and fills.",
		dev: "onAutoEnhance in GleamEditor: applies the \"bright\" look after an AI op unless the person set their own."
	},
	enlarge: {
		group: "Adjust",
		name: "Sharpen and enlarge",
		user: "Choose a model and press Sharpen & enlarge to make the picture bigger and crisper.",
		dev: "AiEnlarge.tsx: client.upscale → POST /upscale; the optional extra detail is POST /enhance (SDXL tile)."
	},
	light: {
		group: "Adjust",
		name: "Light",
		user: "Drag a slider to change brightness, contrast, highlights or shadows. Double-click one to reset it.",
		dev: "The \"light\" op in packages/core/src/ops.ts, drawn by the WebGL shader in packages/render2d."
	},
	color: {
		group: "Adjust",
		name: "Colour",
		user: "Drag a slider to warm, cool or strengthen the colour. Double-click one to reset it.",
		dev: "The \"color\" op in packages/core/src/ops.ts (temperature, tint, vibrance, saturation), drawn in packages/render2d."
	},
	recolour: {
		group: "Adjust",
		name: "Colour swap",
		user: "Tick it, pick the colour to change and the new colour. Use it only for a colour version you really sell.",
		dev: "The \"recolour\" op (from, to, range) in packages/core/src/recolour.ts; off by default because it changes the product."
	},
	effects: {
		group: "Adjust",
		name: "Effects",
		user: "Choose an effect to add it, then set it with its sliders. Arrows change the order.",
		dev: "recipe.effects: shader steps from packages/shaders (listEffects, defaultParams); editor.addEffect / moveEffect."
	},
	avAvatar: {
		group: "Avatar mode",
		name: "Avatar",
		user: "Start from the shop avatar or import your own VRM (make one free in VRoid Studio). Its licence shows if it allows business use.",
		dev: "AvatarStage.load (packages/avatar/src/stage.ts, three-vrm); the file is kept in IndexedDB (react/src/avatar/store.ts)."
	},
	avColours: {
		group: "Avatar mode",
		name: "Colours",
		user: "Recolour the hair, eyes, skin and clothes. The colours are kept for this avatar on this computer.",
		dev: "AvatarStage.recolour: MToon colour and shade by VRoid material names (PARTS in stage.ts); kept by avatar name in localStorage."
	},
	avMood: {
		group: "Avatar mode",
		name: "Mood",
		user: "Hold a mood with a button or a key (Q to Y). The face still blinks and talks over it.",
		dev: "AvatarDriver.hold (packages/avatar/src/driver.ts): replaces the tracked moods; blinks and mouth shapes stay."
	},
	avGestures: {
		group: "Avatar mode",
		name: "Gestures",
		user: "Press a gesture (or its number key) to play it over your own moves: wave, nod, thumbs up, heart hands and more.",
		dev: "gestureAt (packages/avatar/src/motion.ts): arm directions and hand shapes, blended in and out over the tracked pose."
	},
	avCamera: {
		group: "Avatar mode",
		name: "Camera",
		user: "Camera on: the avatar follows your face, head, upper body and hands. Nothing leaves this computer.",
		dev: "Tracker (MediaPipe face, pose and hand landmarkers, models cached once) to solveFrame (rig.ts), smoothed in AvatarDriver."
	},
	avMic: {
		group: "Avatar mode",
		name: "Mic",
		user: "Mic on: the mouth moves with your voice, even with the camera off. Your voice is only listened to, never sent.",
		dev: "An AnalyserNode on the mic (never played back) to visemes (motion.ts), mixed into the mouth by AvatarDriver.speak."
	},
	avBackdrop: {
		group: "Avatar mode",
		name: "Backdrop",
		user: "See-through for a picture, green screen to key out in streaming software, a colour, or the last scene painted in 3D mode.",
		dev: "AvatarStage.setBackdrop: a clear canvas, a colour (chroma green #00b140) or a picture texture fitted to the view."
	},
	avPopout: {
		group: "Avatar mode",
		name: "Pop out for streaming",
		user: "Puts the avatar in its own window: add it to OBS as a window capture, with a colour key on the green screen.",
		dev: "AvatarStage.attach moves the canvas into the pop-up and draws on its clock; closing the pop-up brings it back."
	},
	avVoice: {
		group: "Avatar mode",
		name: "Voice",
		user: "My own: viewers hear you. Clear: it says your words again, clearly. Live: your voice changed into its voice as you talk.",
		dev: "VoiceDesk (avatar/voice.ts) owns the playback AudioContext; its analyser drives the lips while it talks, else the mic does."
	},
	avClear: {
		group: "Avatar mode",
		name: "Clear voice",
		user: "Hold Space (or talk hands-free), let go, and the avatar says it clearly with the grammar fixed, 2 to 4 seconds later. Free.",
		dev: "sayAgain: /voice/listen (Whisper) -> /voice/fix (vision model, text only) -> /voice/speak (Kokoro) in the local app; SpeechGate cuts hands-free."
	},
	avTranslate: {
		group: "Avatar mode",
		name: "Speak another language",
		user: "Talk in your own language: the avatar says it in its voice’s language, English or Japanese, translated here. Say it is AI.",
		dev: "sayAgain: listen with the language as a hint, then /voice/translate to voiceLanguage(voice) (en, or ja for jf_/jm_ voices) instead of /voice/fix. Say it: inVoiceLanguage. The assistant and video scripts are written in that language too (agentPrompt, scriptPrompt)."
	},
	avCaptions: {
		group: "Avatar mode",
		name: "Captions in your language",
		user: "In a call, the extension shows what the others say in your language, on your screen only. 2 to 4 seconds behind.",
		dev: "extension captions.ts: remote WebRTC audio, SpeechGate, WAV -> worker -> /stage/caption (stage key) -> listen + translate -> overlay."
	},
	avAgent: {
		group: "Avatar mode",
		name: "AI assistant",
		user: "Type or paste a viewer’s question. Away, the avatar answers out loud; otherwise you get a draft to say or skip.",
		dev: "agent.ts in the app: findProducts over the shop’s /products/feed, one askText call with only those facts; replies marked AI."
	},
	avVideo: {
		group: "Avatar mode",
		name: "Product video",
		user: "Pick a product (or a picture or video, like a 3D ad), get a script, and the avatar presents it in an MP4 to post.",
		dev: "productvideo.ts: each sentence spoken by Kokoro, lips from byteSpectrum, a manual AvatarStage, frames drawn and encoded by Mediabunny."
	},
	avWebsite: {
		group: "Avatar mode",
		name: "On the shop website",
		user: "Visitors to the shop’s website can ask the avatar; this computer answers with its voice while it is on and awake.",
		dev: "website.ts in the app long-polls the shop (POST /gleamshelf/assistant/claim) and answers with agentRunner and Kokoro; profile every 2 min."
	},
	avCalls: {
		group: "Avatar mode",
		name: "In video calls",
		user: "Be the avatar in Meet, Zoom or Teams: OBS turns the stage link into a camera, a free audio cable turns its voice into a mic.",
		dev: "CallsGuide.tsx: OBS Virtual Camera over the /stage Browser source; voice through OBS monitoring to BlackHole (Mac) or VB-Cable."
	},
	avStage: {
		group: "Avatar mode",
		name: "Stream to OBS",
		user: "Turn it on, copy the link, add it to OBS as a Browser source: the avatar shows see-through, with its voice.",
		dev: "StageLink (stage-link.ts) feeds the app's StageHub over /stage/live; the page is apps/local/stage, its link has a view-only key."
	},
	avLive: {
		group: "Avatar mode",
		name: "Live voice",
		user: "Talk and viewers hear the avatar's voice instead of yours, about half a second behind. Your accent stays. Free, offline.",
		dev: "kNN-VC (livevoice.py): 160 ms chunks to /voice/live, WavLM-Large + vocoder; the voice is Kokoro reading SCRIPT. VoiceDesk.playLive."
	},
	avShopWords: {
		group: "Avatar mode",
		name: "Shop words",
		user: "One name a line, so it is heard right. Add \"= how it sounds\" to teach the voice, e.g. Gunpla = GUN plah.",
		dev: "parseShopWords: names go to Whisper as its prompt, sounds to the Pronouncer in modelserver/voice.py (capitals = stress)."
	},
	avSay: {
		group: "Avatar mode",
		name: "Say it",
		user: "Type something and the avatar says it in its voice, lips moving. Good for scripted lines on a stream.",
		dev: "LocalModelClient.speak (Kokoro through the model server), played by VoiceDesk.play in turn."
	},
	m3dAdd: {
		group: "3D mode",
		name: "Add a shape",
		user: "Click a shape to add it, or Outline, Text or SVG logo to push one out. It lands on the ground; drag its arrows to place it.",
		dev: "ModelEditor.addShape in packages/scene3d/src/model/editor.ts; kinds, sizes and defaults in packages/scene3d/src/model/document.ts."
	},
	m3dOutlineShape: {
		group: "3D mode",
		name: "Outlines",
		user: "Pick a ready-made outline or draw one with the pen; it is pushed out into a solid. Depth and Bevel shape its sides.",
		dev: "kind extrude: Shape3D.outline (unit-box contours) as a 2D distance field (fieldOf, packages/scene3d/src/model/outline.ts) pushed out along z."
	},
	m3dRevolve: {
		group: "3D mode",
		name: "Revolve",
		user: "Pick a vase, bottle, cup or stand, or draw the right half: it spins into a solid. Round by opens a slice; Hole makes a ring.",
		dev: "kind revolve: Shape3D.outline spun round local y (shapeDistance in scene3d sdf.ts, kind 8 in glsl.ts); Shape3D.revolve {offset, sweep}; outlineSize sizes its field; PROFILES in outline.ts."
	},
	m3dMirror: {
		group: "3D mode",
		name: "Mirror",
		user: "A twin on the other side of the middle, left and right or front and back: ears, wings, wheels. Change one and both change.",
		dev: "Shape3D.mirror {x, z}: the point folded across x = 0 or z = 0 to the shape’s own side (foldWorld in scene3d sdf.ts, copyDist in glsl.ts). No y: the ground is y = 0."
	},
	m3dRepeat: {
		group: "3D mode",
		name: "Repeat",
		user: "Copies of the shape in a grid (studs, a fence) or round the middle (petals, gear teeth), all the way round or over an arc.",
		dev: "Shape3D.repeat (grid or around): domain folding with the next copy checked for overlap (gridDistance and foldWorld in scene3d sdf.ts, gridDist and copyDist in glsl.ts); copyCentres gives boxes and framing."
	},
	m3dText: {
		group: "3D mode",
		name: "3D text",
		user: "Type one or more lines and pick a font: standard, online, this computer’s or your own file. The letters become solid 3D text.",
		dev: "textOutline (scene3d/src/model/text.ts) draws the lines on a canvas and traces them; fonts and loading in react/src/model3d/fonts.ts (TextSpec)."
	},
	m3dMulti: {
		group: "3D mode",
		name: "Several shapes",
		user: "Shift-click shapes in the view or the list to pick several (Ctrl A: all). Drag the arrows to move them together, or set them here.",
		dev: "ModelViewport.selectSeveral (scene3d renderer.ts) and ModelEditor.updateShapesAt; the panel is react/src/model3d/MultiPanel.tsx."
	},
	m3dAlign: {
		group: "3D mode",
		name: "Line up",
		user: "Line the picked shapes up by their sides or middles, spread three or more evenly, or put them on the ground.",
		dev: "alignMoves, spreadMoves and groundMoves (scene3d/src/model/arrange.ts) by turned boxes; ModelEditor.align, spread, toGround."
	},
	m3dLookCopy: {
		group: "3D mode",
		name: "Copy a look",
		user: "Copy look takes a shape’s colour and finish; Paste look gives it to the picked shapes (Ctrl Alt C and Ctrl Alt V).",
		dev: "copyLook and copiedLook in react/src/model3d/clipboard.ts; pasted with ModelEditor.updateShapesAt (models switch to one colour)."
	},
	m3dLock: {
		group: "3D mode",
		name: "Lock",
		user: "A locked shape cannot be clicked or dragged in the view, so it stays put while you work on others. Its settings still change.",
		dev: "Shape3D.locked (kept only when true): ModelViewport skips it when picking and shows no gizmo (scene3d/src/model/renderer.ts)."
	},
	m3dCopy: {
		group: "3D mode",
		name: "Copy and paste",
		user: "Ctrl C, X and V copy, cut and paste shapes, into this design or another. Paste an SVG copied from a drawing app to make a logo.",
		dev: "copyShapes in react/src/model3d/clipboard.ts with assetsOf; ModelEditor.pasteShapes; an SVG pasted as text goes to svgOutlines."
	},
	m3dPen: {
		group: "3D mode",
		name: "Pen",
		user: "Click for a corner, drag for a curve, click the first point to close. Drag points or handles to reshape them.",
		dev: "PenPad (react/src/model3d/PenPad.tsx) edits Shape3D.pen; penContours (scene3d/src/model/pen.ts) flattens it into the outline."
	},
	m3dSvgImport: {
		group: "3D mode",
		name: "SVG logo",
		user: "SVG logo (or drop an .svg): each colour becomes its own 3D piece, placed as in the logo. Outline any text in the file first.",
		dev: "svgOutlines (scene3d/src/model/svg.ts) reads paths and fills, paints them in order, traces each colour; shapesFromSvg + ModelEditor.addShapes."
	},
	m3dGroup: {
		group: "3D mode",
		name: "Groups",
		user: "Shift-click shapes in the list and press Group (Ctrl G). A cut inside a group only cuts that group; move it all at once.",
		dev: "kind group with children, one level: steps() in document.ts marks begin and end; map() in glsl.ts joins the children, then the group."
	},
	m3dSvg: {
		group: "3D mode",
		name: "Save as vectors",
		user: "Save, then Vectors (SVG): the design in flat steps of light, each region a shape you can edit in a vector app.",
		dev: "modelToSvg (packages/scene3d/src/model/vector.ts): renderModelCpu with tones, regions by colour traced by traceContours, cropped when see-through."
	},
	m3dVideo: {
		group: "3D mode",
		name: "Video",
		user: "Save, then Video: the shapes move as set, with the camera still, turning round or swaying, or the light sweeping. Saved as MP4.",
		dev: "recordClip (scene3d/src/model/video.ts): clipFrame = animate (motion.ts) plus the camera; frames encoded with WebCodecs via Mediabunny."
	},
	m3dAd: {
		group: "3D mode",
		name: "3D ad",
		user: "The product photo on a stage with a 3D headline, price badge and logo. The photo stays as photographed; change anything after.",
		dev: "buildAd (scene3d ad.ts) with pictureCard (card.ts); AdDialog.tsx keeps the logo, look and last scene (scene.ts lastScene) in localStorage."
	},
	m3dPhotos: {
		group: "3D mode",
		name: "3D model from photos",
		user: "Makes a 3D model of the figure from photos, on this computer. From one photo the back is guessed; it is marked as generated.",
		dev: "PhotosDialog.tsx -> /shape3d (apps/local/src/shape3d.ts) -> model server shape3d.py: TripoSR, TRELLIS.2, TRELLIS multi-photo; npm run 3d:setup."
	},
	m3dScene: {
		group: "3D mode",
		name: "Scene behind",
		user: "Paint a scene behind the design with the image model on this computer (free), or use a picture. The design itself is not redrawn.",
		dev: "makeScene (react/src/model3d/scene.ts): the redraw model paints a blank picture; kept as background.picture, laid under the design by finish.ts."
	},
	m3dMotion: {
		group: "3D mode",
		name: "Motion",
		user: "Pick how it moves: spin, float, bounce, sway, pulse, wiggle, go round or pop in. Play shows it; Stagger makes several follow on.",
		dev: "Shape3D.motion (Motion in scene3d/src/model/motion.ts): poseAt per body, animate per frame; ModelViewport.showFrame plays it."
	},
	m3dKeys: {
		group: "3D mode",
		name: "Keyframes",
		user: "Pick a time, place the shape (or a whole group) and press Add key; do it again at another time. Play moves it between keys.",
		dev: "Shape3D.keys (packages/scene3d/src/model/keys.ts): keyedAt per frame inside animate, poseAtTime when the time changes; packages/react/src/model3d/KeysSection.tsx."
	},
	m3dTriggers: {
		group: "3D mode",
		name: "Click and hover",
		user: "Pick what a shape does when clicked or pointed at (spin, hop, wiggle, pulse, sway). Press Play, then click or point at it.",
		dev: "Shape3D.triggers (packages/scene3d/src/model/triggers.ts); useTriggers runs them while playing (ModelViewport.shapeAt), animate plays them."
	},
	m3dForm: {
		group: "3D mode",
		name: "Form",
		user: "Hollow leaves a shell, Twist turns it towards the top, Bend curves it, Taper narrows or widens the top.",
		dev: "Shape3D.form: formedDistance in packages/scene3d/src/model/sdf.ts and formedDist in glsl.ts (in the spare slots of uF, uCol, uMat)."
	},
	m3dMeshEdit: {
		group: "3D mode",
		name: "Edit the model",
		user: "For an imported model: Smooth, Simplify, Flip inside out, or cut it flat at a height keeping one side. Pick several to join them.",
		dev: "packages/scene3d/src/model/meshedit.ts (smoothMesh, simplifyMesh, cutMesh, flipMesh, joinMeshes, refit); MeshEditSection.tsx."
	},
	m3dRoom: {
		group: "3D mode",
		name: "View in your room",
		user: "On a phone, see the design in your room at its real size (iPhone: Quick Look; Android: tap a surface). Save it as USDZ too.",
		dev: "packages/react/src/model3d/ar.ts: designUsdz (three USDZExporter, colours as materials), quickLook, placeInRoom (WebXR hit-test)."
	},
	m3dDrop: {
		group: "3D mode",
		name: "Drop and stack",
		user: "Lift the shapes up, then Drop: they fall onto the floor and the other shapes, bouncing as set, kept as keys.",
		dev: "simulateDrop in packages/scene3d/src/model/physics.ts (cannon-es, sampled at 30 per second, fewest keys kept); PhysicsSection.tsx."
	},
	m3dEffects: {
		group: "3D mode",
		name: "Effects",
		user: "Confetti, sparkles, smoke, a flame or a pouring liquid at the picked shape while it plays, in videos and in the viewer.",
		dev: "ModelDocument.effects; effectParticles in packages/scene3d/src/model/effects.ts (seeded by the moment), drawEffects in renderer.ts."
	},
	m3dLearn: {
		group: "3D mode",
		name: "Learn (tutorials)",
		user: "Learn: tutorials from a dancing character in 30 seconds to pro materials and voices. Each points at what to press next.",
		dev: "LearnPanel.tsx (list and coach card); steps in model3d/tutorials.ts (target by text or CSS, done when shown or hidden). Its own address in the apps: /3d/learn (ModelMode place, model3d/places.ts)."
	},
	m3dVoice: {
		group: "3D mode",
		name: "Voice studio",
		user: "Type or say a line, pick a voice and an effect: narration and characters speak with no voice actors. Free, on this computer.",
		dev: "VoiceDialog.tsx; voicefx.ts (pitch, robot, radio, cave…); client.speak (Kokoro) and changeVoice (/voice/live/change, kNN-VC clip_convert). On its own at /3d/voice (ModelMode place)."
	},
	m3dModelMaterial: {
		group: "3D mode",
		name: "Material",
		user: "Material (a model picked): pick a material, give it a shader (toon, flat, clay, unlit) or a ready-made one, set its look.",
		dev: "scene3d matedit.ts (withShader, MATERIAL_PRESETS, materialAt); MeshMaterial.look/bands (GLB extras); MESH_FRAGMENT gLook; previewMaterial."
	},
	m3dDraw: {
		group: "3D mode",
		name: "Draw on a model",
		user: "Draw on the model, pixel-fine: colour, roughness, metal, glow, bumps, clear coat or holes. Optional free AI details on colour.",
		dev: "scene3d texpaint.ts (drawTouch, readyChannel, bumpNormals; markStroke/blendSquare for AI); DrawSection.tsx (client.redraw); previewPicture."
	},
	m3dDrawTouch: {
		group: "3D mode",
		name: "Draw on a model with a finger",
		user: "On a touch screen one finger draws; put a second finger down to turn, pinch and pan the view instead.",
		dev: "DrawSection.tsx handOver: the first stroke is taken back and both fingers replayed to OrbitControls (renderer.ts setOrbit)."
	},
	m3dBrush: {
		group: "3D mode",
		name: "Brush (sculpt and paint)",
		user: "For an imported model: pick Draw, Inflate, Smooth, Grab or Paint, turn the brush on and drag on the model.",
		dev: "packages/scene3d/src/model/brush.ts (startStroke, brush, strokeModel, modelSpace); BrushSection.tsx; ModelViewport.modelHitAt and previewModel."
	},
	m3dElements: {
		group: "3D mode",
		name: "Points, edges and faces",
		user: "Pick Points, Edges or Faces, turn picking on and click the model; then move, grow, turn, extrude, inset, delete, merge or cut.",
		dev: "packages/scene3d/src/model/elements.ts (pickElement, moveElements, extrudeFaces, cutAcross, ...); ElementsSection.tsx; ModelViewport.setMarks."
	},
	m3dUnwrap: {
		group: "3D mode",
		name: "Unwrap and the texture map",
		user: "For an imported model: Unwrap lays its surface flat into one new picture a part (it looks the same); Texture map shows the layout.",
		dev: "packages/scene3d/src/model/uvmap.ts (unwrap, bakeLook, withBakedPictures); model3d/uvbake.ts decodes and encodes; UvMap in MeshEditSection.tsx."
	},
	m3dRig: {
		group: "3D mode",
		name: "Rig (bones and posing)",
		user: "Rigged models keep their bones; others add a figure rig or chain. Turn a bone, or Reach and drag its tip. Keys keep poses.",
		dev: "packages/scene3d/src/model/rig.ts (figureRig, chainRig, ownRig, boneWeights, posedParts, reach); skeleton and skin in the design GLB (mesh.ts writeGlb, readGltf, skeletonOf in meshFromThree.ts); Shape3D.rig, Key.bones; shapeModel poses; RigSection.tsx. Spring bones: springs.ts (bakeSprings kept per shape, animate lays them over; vrmSprings for a VRM). Creator bones: characters.ts writes skin.bin, avatar.ts characterSkeleton."
	},
	m3dLife: {
		group: "3D mode",
		name: "Life (blinks, breath, glances)",
		user: "Characters blink, breathe, glance about, shift their weight and stand as they feel while they play. Turn it down in Rig.",
		dev: "packages/scene3d/src/model/life.ts (livePose: blinkAt, talkingMouth, eyes, breath, posture from the face, weight shift; Lively: swing and out of breath from real movement). motion.ts animate applies it looped to the clip; gamerun.ts live() applies it with Play game cues (talking when the line is \"Name: ...\" with its name or its idle move is talk, moving, seated) and turns it off for animate. Shape3D.life (checkLife). Shelved draws the same in Renderer.mm Motion."
	},
	m3dCloth: {
		group: "3D mode",
		name: "Cloth",
		user: "In Light and look: set its size and colour and Drape a cloth: it falls over the shapes and the floor and stays as a model.",
		dev: "packages/scene3d/src/model/cloth.ts (drapeCloth: Verlet springs, pushed out by sceneDistance); ClothSection in PhysicsSection.tsx; added with ModelEditor.addModel."
	},
	m3dHair: {
		group: "3D mode",
		name: "Hair and fur",
		user: "For an imported model: set the strands, length, hang and curl, everywhere or on top, then Grow hair (one undo step).",
		dev: "packages/scene3d/src/model/hair.ts (growHair: strands as thin tubes in a new part and material); HairSection.tsx."
	},
	m3dNodes: {
		group: "3D mode",
		name: "Nodes",
		user: "Copies with nodes puts copies of a shape on a grid, line, ring or scatter; Colour with nodes colours a model. Wire right to left.",
		dev: "packages/scene3d/src/model/nodes.ts (GEOMETRY_NODES, MATERIAL_NODES, geometryPlaces, instanceCopies, colourByNodes); Shape3D.nodes; NodeEditor.tsx."
	},
	m3dCompose: {
		group: "3D mode",
		name: "Compositor",
		user: "In Light and look: exposure, warmth, colour, glare, vignette, grain and more for renders, pictures and videos; Preview shows it.",
		dev: "packages/scene3d/src/model/compose.ts (composePixels on RGBA); ModelDocument.compose; used by video.ts, sequence.ts, finish.ts (pictures, RenderDialog)."
	},
	m3dSequence: {
		group: "3D mode",
		name: "Video editor",
		user: "Save… › Video editor: clips, titles and pictures in a row, faded into each other, with music, wide, square or tall.",
		dev: "packages/scene3d/src/model/strips.ts (Sequence3D, checkSequence), sequence.ts (recordSequence, Mediabunny with an AudioBufferSource); SequenceDialog.tsx."
	},
	m3dScript: {
		group: "3D mode",
		name: "Script (Python)",
		user: "Script (top bar) runs Python on the design: import gleamshelf. One undo step a run; the first run fetches Python (about 10 MB).",
		dev: "packages/scene3d/src/model/script.ts (scriptCall, PYTHON_PRELUDE); ScriptDialog.tsx loads Pyodide 0.27.7 from jsDelivr and registers the gleamshelf_bridge module."
	},
	m3dLibrary: {
		group: "3D mode",
		name: "3D library",
		user: "Library (Add a shape): ready-made anime characters, people, animals, furniture and props, free for any use. Click one to add.",
		dev: "LibraryDialog.tsx reads <library>/index.json: the library prop, setModelLibrary (the website: /library/), or the local app /library/ route (apps/local/src/library.ts)."
	},
	m3dAvatar: {
		group: "3D mode",
		name: "Character creator",
		user: "Character (Add a shape): pick a style, then outfit, face, eyes, mouth, hair, shape and colours. Drag the preview to turn.",
		dev: "AvatarDialog.tsx, the only character maker (Character, its route and the Game tab all open it; with no library it says where the parts come from, NO_LIBRARY); parts in public/library/characters (scripts characters.ts for anime, kits.ts for low-poly and realistic); avatar.ts in scene3d. characterShapes in character.ts still builds the old shape-made figures for tests."
	},
	m3dLayers: {
		group: "3D mode",
		name: "Character layers",
		user: "Pick a character you made: Layers lists hair, eyes, mouth, face and body. The dot hides or shows one; Edit changes just that one.",
		dev: "LayersSection.tsx: the recipe is ModelAsset.character (checkAvatarChoice), hidden layers in AvatarChoice.hidden; characterBuilder.ts rebuilds (avatarLayers in avatar.ts keeps the shown parts, skeleton whole) and editor.replaceModelAt swaps it in, feet and pose kept. Edit opens AvatarDialog with start/startTab. Painting or editing points makes it a plain model, and Layers goes."
	},
	m3dLooks: {
		group: "3D mode",
		name: "Kept looks",
		user: "Character creator › Keep this look: the whole character by its name, to wear again later (kept on this computer).",
		dev: "AvatarDialog.tsx keepLook/wearLook/dropLook: SavedLook (name, AvatarChoice, a small preview picture) in localStorage gleamshelf:looks; wearing one checks its parts are in this library first."
	},
	m3dPoses: {
		group: "3D mode",
		name: "Poses",
		user: "Poses (a figure picked): a click holds it still in a pose. Keep this pose saves your own by name, on this computer.",
		dev: "PoseSection.tsx; STILL_POSES and stillPoseOn (animations.ts) hold a moment of a move via movePoseOn, retargeted to any person; saved poses (name, bones) in localStorage gleamshelf:poses, struck only on a rig with as many bones."
	},
	m3dSticker: {
		group: "3D mode",
		name: "Sticker",
		user: "Draw › Sticker from a picture: click the model to stamp it. Its see-through parts leave the model alone.",
		dev: "DrawSection.tsx arms DrawTouch.image (the pixels, a u/v plane upright to the view, half a width); drawTouch (texpaint.ts) stamps by the picture’s own see-through, no soft edge; size and turn sliders, each click one undo step."
	},
	m3dAnimations: {
		group: "3D mode",
		name: "Animations",
		user: "Animations (a model picked): pick a move and it plays. Animation from a file puts a Mixamo FBX, GLB or BVH on the figure.",
		dev: "AnimationSection.tsx; moves in animations.ts (bakeAnimation to Key[], retargeted for a real skeleton via moveRig). Files: importTakeFiles (importer.ts), takesFromThree (clips.ts), retargetTake and BoneTake in take.ts, humanoid.ts names the bones; doc.takes, Shape3D.take, animate plays them."
	},
	m3dWebGame: {
		group: "3D mode",
		name: "Web game",
		user: "Game tab › Save as a web game: a zip that plays in any browser. Put it on itch.io or any web host; a disk will not run it.",
		dev: "webgame.ts zips apps/web/public/play (built by npm run web:player, from apps/web/play) with game.json; GameOnly.tsx plays it. Needs the website built."
	},
	m3dRoutine: {
		group: "3D mode",
		name: "Routines",
		user: "Give a character a day: at each time they walk to a spot, going round walls. Warnings appear if they can not make it.",
		dev: "GameActor.routine and GameSetup.clock (game.ts); walked in GameRun.walkRoutine by findRoute (gamestory.ts); checked by routineFindings; exported in story.json."
	},
	m3dShots: {
		group: "3D mode",
		name: "Camera shots",
		user: "Frame the view, then save it as a shot. Rules can use it by name, so changing the shot changes every rule that uses it.",
		dev: "GameSetup.shots (game.ts); a camera action with `shot` reads it when it plays (gamerun.ts); exported in story.json."
	},
	m3dDaylight: {
		group: "3D mode",
		name: "Time of day",
		user: "Slide to a time of day and light the level as it will look then. Tick the box to move the sun with the clock in play.",
		dev: "daylight(minute) and withDaylight (daylight.ts), the sky picture from skyPixels; GameClock.daylight lets Play game relight each frame; story.json carries the table for engines (Shelved's Renderer::setDaylight is the same numbers)."
	},
	m3dFilms: {
		group: "3D mode",
		name: "Films",
		user: "Saved shots one after another, each a glide or a cut. Preview plays it here; a Camera shot action plays it in the game.",
		dev: "GameSetup.films (game.ts), filmCamera and filmSeconds (gamestory.ts); a camera action's `film` plays it in GameRun; story.json gives each step its shot's place."
	},
	m3dIdle: {
		group: "3D mode",
		name: "Standing about",
		user: "What a character does standing still: now and then a move (a phone, a look round), or taking turns in a conversation.",
		dev: "GameActor.idle (game.ts) played by idleMove in GameRun; exported in story.json for engines."
	},
	m3dTestPlay: {
		group: "3D mode",
		name: "Test play",
		user: "Paused in play: jump to a time of day, hide the screen's words for a clean picture, or copy who is where for a bug report.",
		dev: "GameRun.jumpTo and snapshot (gamerun.ts); simulate in apps/local/src/gametools.ts (simulateLevel, compareLogs)."
	},
	m3dAchievements: {
		group: "3D mode",
		name: "Achievements",
		user: "The game's achievements in English and Japanese. A rule's Earn an achievement action earns one; store sheets come from this list.",
		dev: "GameProject.achievements (project.ts), checked by checkAchievements; the achieve action in GameRun (takeAchievements, carried between levels); npm run game -- achievements writes the Game Center and Google Play sheets, achievements.json and badges."
	},
	m3dRomance: {
		group: "3D mode",
		name: "Romance",
		user: "A dating sim: choices raise affection, open routes and endings. For a town to walk in, start and end events in the world.",
		dev: "GameProject.romance (romance.ts: checkRomance, RomanceRun, romanceFindings, romanceForRating, romancePack; sample in romancesample.ts). RomanceSection/RomancePlay in packages/react/src/model3d. npm run game -- romance | romance-starter (apps/local/src/gametools.ts). Mature exports refuse any heroine not stated 18+. Pocket Hearts (spin/pocket-hearts, C++/SDL3) reads romance.json. Open-world events: RomanceScene.entry starts from the world (findings and reachableEndings walk from every entry), next {kind:'return'} ends back in the world (state.returned), RomanceRun.play(id) starts one."
	},
	m3dQuests: {
		group: "3D mode",
		name: "Quests",
		user: "Steps done in order: talk to, use or walk into a shape. Write the hint and what is said; play shows what to do next.",
		dev: "GameSetup.quests (game.ts); questRules (gamestory.ts) turns them into rules at play, checked by questFindings, exported in story.json. ja is carried, not played yet."
	},
	m3dFaceLines: {
		group: "3D mode",
		name: "Eye lines and brows",
		user: "Draw the eyes and brows anew: pick a line style (soft, bold, cat flick, droopy, doll), lashes and a brow shape.",
		dev: "AvatarChoice.facePaint: paintFaceLines in facepaint.ts clears the eye line, lash and brow pictures and draws strokes by place on the face as made (look.rest), the eye shape read from the eye white picture, so sliders and expressions move them. Headless: facePaint on a cast member."
	},
	m3dMadeHair: {
		group: "3D mode",
		name: "Hair made by Gleamshelf",
		user: "Pick a hairstyle, then set the bangs, lengths, tails, volume and waves. Gleamshelf builds the hair to fit the face.",
		dev: "AvatarChoice.madeHair (MadeHairStyle): makeHair in animehair.ts builds ribbon locks over a fitted skull (SKULL), shaded by hairPicture (png.ts); assembleAvatar uses it instead of the hair model, every point on the head bone. Headless: madeHair on a cast member."
	},
	m3dFaceShape: {
		group: "3D mode",
		name: "Face shape",
		user: "Move, tilt and widen the eyes, raise or angle the brows, move the mouth, lengthen the chin and fill out the cheeks.",
		dev: "AvatarChoice.faceShape: shapeFace in avatar.ts moves the face points (eyes, brows, mouth areas) before the face is seated. Headless: faceShape on a cast member in cast.json."
	},
	m3dEyeStyle: {
		group: "3D mode",
		name: "Eye style",
		user: "Redraw the eyes sharp: sparkling, soft, starry, hollow, ringed or shutter; pupil size, glow and odd eyes.",
		dev: "AvatarChoice.eyes: paintEyes in avatardetail.ts paints a new iris picture at 4x inside each iris's UV bounds; hollow clears the highlight picture. Headless: eyes on a cast member."
	},
	m3dMakeup: {
		group: "3D mode",
		name: "Makeup",
		user: "Paint blush (with anime blush lines), eye shadow, shadows under the eyes, lip colour, tears and a beauty mark on the face.",
		dev: "AvatarChoice.makeup: detailAvatar in avatardetail.ts enlarges the face skin picture 4x and paints it by 3D place (paintByPlace draws each skin triangle through its UVs). Headless: makeup on a cast member."
	},
	m3dWardrobe: {
		group: "3D mode",
		name: "Wardrobe",
		user: "Change a dress length and fullness, add a pattern, or recolour a printed outfit in two colours.",
		dev: "AvatarChoice.wardrobe: cutDress and paintPattern in avatar.ts, a second colour in recolourPixels. Headless: wardrobe on a cast member in cast.json."
	},
	m3dShapeRole: {
		group: "3D mode",
		name: "What this shape is",
		user: "Pick a shape and say what it is: walls and solid things block walking, and a named spot is a hidden place people go.",
		dev: "shapeRole and shapeWithRole in gamecheck.ts, kept in the shape name (wall..., solid..., spot:name), which packWorld and walkGrid read. UI: GamePackSection.tsx."
	},
	m3dGameCheck: {
		group: "3D mode",
		name: "Check the game",
		user: "Finds flickering floors, places nobody can reach, spots inside walls and rooms with no ceiling, and says what to do.",
		dev: "lintGameProject and turnFindings in gamecheck.ts. Headless: npm run game -- check project.json --start spot --placed a,b (exits 1 on findings)."
	},
	m3dWalkMap: {
		group: "3D mode",
		name: "Walk map",
		user: "The game from above: where people can walk, the walls, and the spots. A red dot is a spot nobody can reach.",
		dev: "walkGrid in gamecheck.ts, a 0.5 m grid flood-filled from the start spot; drawn by WalkMap in GamePackSection.tsx."
	},
	m3dGameBudget: {
		group: "3D mode",
		name: "Will it run?",
		user: "Pick a device to see what it can carry. Make it fit lightens models that are too heavy. The limits are estimates.",
		dev: "GAME_TARGETS, projectCost, fitProject, simplifyMesh and reduceBones in gamecheck.ts. Limits are estimates, not measured on devices. Headless: budget in cast.json, --max-triangles for a world."
	},
	m3dGameSurfaces: {
		group: "3D mode",
		name: "Surfaces",
		user: "Give boxes a repeating picture in the game pack, by the start of their name. Kept until you close this page.",
		dev: "PackMaterial in gamepack.ts, passed to packWorld. Headless: --materials materials.json."
	},
	m3dGameVoices: {
		group: "3D mode",
		name: "Voices for every line",
		user: "Pick a voice for each speaker, then Speak the lines. Runs on your computer, free, and needs the local app.",
		dev: "sayLines and withLineVoices in gamecheck.ts; local.client.speak (Kokoro, made-up voices only). Headless: npm run game -- voices voices.json lines.json --out dir."
	},
	m3dCastSheet: {
		group: "3D mode",
		name: "Cast sheet",
		user: "Every character side by side, to see who looks too alike. It warns about any two that are very close.",
		dev: "renderModelCpu and pictureLikeness (gamecheck.ts) in GamePackSection.tsx. Headless: npm run game -- sheet cast.json --out sheet.png."
	},
	m3dGamePack: {
		group: "3D mode",
		name: "Game pack",
		user: "Saves small files any game engine can read: the world, the characters with moves and faces, and the voices.",
		dev: "packWorld and packCharacter in gamepack.ts, layout in docs/game-pack.md. Characters need a skeleton. Headless: npm run game -- cast and world."
	},
	m3dGameCredits: {
		group: "3D mode",
		name: "Fill in the credits",
		user: "Credits who made each library model this game uses, with its licence. Check any model you brought yourself.",
		dev: "projectCredits in gamecheck.ts against the library index.json. Headless: npm run game -- credits project.json --cast cast.json --out CREDITS.md."
	},
	m3dArmsDown: {
		group: "3D mode",
		name: "Arms down",
		user: "For a model made with its arms out: brings them down this far in every move.",
		dev: "AnimationSettings.armsDown in bakeAnimation (animations.ts), on the humanoid upper arms; packCharacter passes it too."
	},
	m3dMusic: {
		group: "3D mode",
		name: "Music",
		user: "Timeline › Music…: a song plays with the clip and goes in videos. Its beats show there; keys dragged near one land on it.",
		dev: "doc.music (music.ts: checkMusic, loudness, findBeat); MusicLane in Timeline.tsx; the preview loop in ModelMode.tsx keeps an Audio in step; recordClip takes an AudioBuffer."
	},
	m3dDance: {
		group: "3D mode",
		name: "MikuMikuDance",
		user: "Import reads a PMX or PMD model (pick its whole folder). Animation from a file puts a VMD dance on any figure.",
		dev: "pmx.ts readMmdModel (bones, skin, vertex morphs; D bones given to what they copy); vmd.ts parseVmd, vmdToTake (played on VMD_SKELETON, Miku proportions, legs by analytic IK), vmdCamera; retargetTake; doc.cameraTake."
	},
	m3dScenes: {
		group: "3D mode",
		name: "Scenes",
		user: "Scenes (Add a shape): start from a ready-made scene of library models. It replaces this design; Undo brings it back.",
		dev: "ScenesDialog (LibraryDialog.tsx): index.json's scenes, made by apps/web/scripts/library.ts; openLibraryScene (library.ts) fetches each model by id."
	},
	m3dCurves: {
		group: "3D mode",
		name: "Curves",
		user: "In the timeline, Curves shows how one number of the picked shape changes over the clip; drag a key’s dot to change it.",
		dev: "packages/react/src/model3d/Curves.tsx: keyedAt sampled for the line, keys dragged in value and time (one undo step)."
	},
	m3dLookAt: {
		group: "3D mode",
		name: "Looks at",
		user: "While it plays, the shape keeps turning to face another shape or the camera.",
		dev: "Shape3D.lookAt; lookedAt in packages/scene3d/src/model/motion.ts, run by animate."
	},
	m3dMorph: {
		group: "3D mode",
		name: "Morph",
		user: "Tick Edits make a morph, then Smooth: the model blends towards the smoothed version by the Morph amount, which keys can change.",
		dev: "Shape3D.morph and Key.morph; shapeModel and blendParts in packages/scene3d/src/model/morph.ts."
	},
	m3dTimeline: {
		group: "3D mode",
		name: "Timeline",
		user: "Timeline (top bar) shows every key of the shapes and the camera: click the top to go to a moment, drag a key to move it in time.",
		dev: "packages/react/src/model3d/Timeline.tsx: rows from Shape3D.keys and ModelDocument.cameraKeys; showMoment (KeysSection.tsx) to go to a moment."
	},
	m3dLabel: {
		group: "3D mode",
		name: "Label",
		user: "Add a picture to a shape: a sticker on its front, back or top, or a label wrapped round it like a bottle’s.",
		dev: "Shape3D.label: labelUv in packages/scene3d/src/model/labels.ts and labelled in glsl.ts (uLabels, 4 at most); cpu.ts paints them too."
	},
	m3dEnvironment: {
		group: "3D mode",
		name: "Environment",
		user: "A photo all round the design (a room, a street, a studio) that lights the photo-real render and shows in its reflections.",
		dev: "ModelDocument.environment (equirectangular, data URL); envAt in the tracer (glsl.ts TRACE_LIB); EnvironmentSection.tsx."
	},
	m3dRender: {
		group: "3D mode",
		name: "Photo-real render",
		user: "Save… › Photo-real render: traced light (real glass, reflections); a see-through background saves clear, up to 4096 px.",
		dev: "PhotoRender (renderer.ts) runs TRACE_FRAGMENT (glsl.ts; toon/flat via drawnLight, uLook and uTMatD) into a float RGBA target (alpha = coverage; uKeepClear leaves first-ray misses clear and makes the floor a shadow catcher); RenderDialog.tsx."
	},
	m3dExport: {
		group: "3D mode",
		name: "3D model (GLB, OBJ, STL, VRM)",
		user: "Save… › 3D model: GLB for 3D apps and AR, STL to print. A rigged model also saves with its animation (Bones) or as VRM.",
		dev: "exportModel in packages/scene3d/src/model/exportmesh.ts: surface nets over sampleScene (skipping empty blocks), colours per point, imported models added. MikuMikuDance is import only. Bones and VRM: exportRiggedGlb and exportVrm in exportrig.ts (VRM 1.0, T-posed, on the ground, expressions as morph targets)."
	},
	m3dViewer: {
		group: "3D mode",
		name: "Viewer and share link",
		user: "On the website, View shows the design as others will see it, playing and clickable; Copy link shares it without uploading.",
		dev: "ModelPlayer (packages/react/src/model3d/ModelPlayer.tsx); apps/web/src/share.ts puts the deflated design after #view= (never sent to a server)."
	},
	m3dCameraKeys: {
		group: "3D mode",
		name: "Camera moves",
		user: "Turn the view, pick a time and press Add camera key; do it again at another time. Play and videos fly the camera between them.",
		dev: "ModelDocument.cameraKeys (packages/scene3d/src/model/keys.ts): cameraAt inside animate (yaw the short way); KeysSection with a camera target."
	},
	m3dShapes: {
		group: "3D mode",
		name: "Shapes, top to bottom",
		user: "Shapes are joined in order: each one adds to, cuts or intersects everything above it. The arrows change the order.",
		dev: "doc.shapes order is the join order of map() in packages/scene3d/src/model/glsl.ts and sceneDistance in packages/scene3d/src/model/sdf.ts."
	},
	m3dGizmo: {
		group: "3D mode",
		name: "Move, turn and resize",
		user: "Pick a shape, then drag the arrows, rings or boxes on it. M moves, T turns, R resizes; Delete removes it.",
		dev: "Three.js TransformControls on a proxy object in ModelViewport (packages/scene3d/src/model/renderer.ts); one undo step per drag."
	},
	m3dPerf: {
		group: "3D mode",
		name: "Performance gauge",
		user: "P (or View) shows frames a second, the resolution drawn, this computer’s speed and the graphics card. P again hides it.",
		dev: "PerfGauge.tsx reads ModelViewport.stats() (renderer.ts) four times a second; on/off in localStorage gleamshelf:perf-gauge. Baked field: DistanceVolume (renderer.ts), the whole field in a 3D texture the march reads far from surfaces; off with localStorage gleamshelf:3d-field=off. Tile lists: TileLists (renderer.ts), the shapes each 32-pixel tile can see, for the march; off with gleamshelf:3d-tiles=off."
	},
	m3dView: {
		group: "3D mode",
		name: "Views",
		user: "Drag to orbit, right-drag to pan, scroll to zoom. WASD fly the view, Q down, E up, Shift faster. Fit all (F); 5 front, 8 top.",
		dev: "OrbitControls write doc.camera (yaw, pitch, distance, target) in renderer.ts; WASD/QE is ModelViewport.fly; VIEWS in document.ts; Fit all is ModelEditor.frameAll (box corners)."
	},
	m3dImport: {
		group: "3D mode",
		name: "Import a model",
		user: "Import (or drop a file on the view): GLB, glTF, FBX, OBJ, STL, PLY or 3MF. Pick a .gltf or .obj with its .bin, .mtl and pictures.",
		dev: "importModelFiles (packages/scene3d/src/model/importer.ts) to a plain GLB in doc.assets (PBR maps, clearcoat, sheen, glass); kind mesh: MeshLayer in renderer.ts, meshcpu.ts on the CPU."
	},
	m3dGrid: {
		group: "3D mode",
		name: "Grid",
		user: "Grid (G) shows lines on the ground; type the cell size beside it. Snap moves shapes in whole cells and turns in 15° steps.",
		dev: "uGrid in gridAt() of packages/scene3d/src/model/glsl.ts, set by ModelViewport.setGrid (renderer.ts), viewport only; kept in localStorage."
	},
	m3dCombine: {
		group: "3D mode",
		name: "Combine and blend",
		user: "Add joins the shape on, Cut carves it out, Intersect keeps only the overlap. Blend melts the join into one smooth form.",
		dev: "Polynomial smooth min/max per shape in map() (packages/scene3d/src/model/glsl.ts); the blend radius is blend x 0.6 scene units."
	},
	m3dSize: {
		group: "3D mode",
		name: "Size, place and rounding",
		user: "Type exact sizes, places and turns, or round the edges. A ring also has a tube thickness.",
		dev: "Shape3D.size, position, rotation (degrees, XYZ), round and thickness; distance functions in shapeDist (glsl.ts) and sdf.ts."
	},
	m3dMaterial: {
		group: "3D mode",
		name: "Colour and finish",
		user: "Pick a colour and how the surface shines: matte, satin, glossy or metal.",
		dev: "Shape3D.color and finish become uCol and uMat (shininess, metal) in fillUniforms, packages/scene3d/src/model/renderer.ts."
	},
	m3dLook: {
		group: "3D mode",
		name: "Look",
		user: "Soft looks lifelike, Toon is drawn in steps of light, Flat is plain colour, Clay is matte white, Pixel is chunky pixel art.",
		dev: "style.look becomes uLook in shade() (scene3d glsl.ts); pixel: drawn small as toon, enlarged with hard edges (finish.ts, style.pixel)."
	},
	m3dOutline: {
		group: "3D mode",
		name: "Outline",
		user: "Give the design an inked outline, in any width and colour.",
		dev: "style.outline in pixels per 1000: the silhouette from the ray’s closest approach, plus edges turning away, in render() of glsl.ts."
	},
	m3dLight: {
		group: "3D mode",
		name: "Light",
		user: "Light and look tab: swing the light around and up; set its brightness, Light colour and how much soft fill reaches shadows.",
		dev: "light.azimuth and elevation become uLightDir; soft shadows and ambient occlusion are marched in packages/scene3d/src/model/glsl.ts."
	},
	m3dLights: {
		group: "3D mode",
		name: "More lights",
		user: "Up to two more lights: a rim from behind lifts the edges off the background, a fill from the side opens the shadows.",
		dev: "light.extra (up to MAX_EXTRA_LIGHTS): designLights in scene3d lights.ts; lightsAt traces every shadow in one loop (glsl.ts, cpu.ts)."
	},
	m3dFocus: {
		group: "3D mode",
		name: "Depth of field",
		user: "Blurs what is nearer and further than the focus, as a camera lens does. Pick a shape and press Sharp on it to focus there.",
		dev: "camera.focus (blur, offset): blurByDepth in scene3d focus.ts on the CPU, FocusPass with FOCUS_FRAGMENT over colour and depth on the GPU."
	},
	m3dFloor: {
		group: "3D mode",
		name: "Floor and background",
		user: "A floor that only shows the shadows, and a see-through or coloured background.",
		dev: "ground.on and shadow (the plane y = 0, shadow only) and background in render() of packages/scene3d/src/model/glsl.ts."
	},
	m3dUse: {
		group: "3D mode",
		name: "Use in design",
		user: "Places the 3D picture as a layer. To change it later, pick that layer and choose Edit 3D layer in the Layer menu.",
		dev: "renderModel (renderer.ts) draws in tiles, four samples a pixel; the design rides on the layer as RasterLayer.model3d (packages/canvas/src/document.ts)."
	},
	m3dMake: {
		group: "3D mode",
		name: "Make 3D from a layer",
		user: "In Edit mode, pick a layer and choose Make 3D in the Layer menu: its shape becomes a solid in its own colour.",
		dev: "layerPicture in packages/react/src/edit/EditMode.tsx, then modelFromPicture (packages/scene3d/src/model/text.ts); MCP model_from_layer does the same."
	},
	m3dProject: {
		group: "3D mode",
		name: "Game project",
		user: "A game of several levels and characters, kept in one file: open each to change it, pick the start, then Save project.",
		dev: "GameProject in packages/scene3d/src/model/project.ts (checkProject, projectFile); packages/react/src/model3d/useGameProject.ts keeps it while editing."
	},
	m3dActors: {
		group: "3D mode",
		name: "Characters in levels",
		user: "New character opens the character creator; open a level and press Place here. It stands there as a model the game moves.",
		dev: "bakeCharacter (a creator character is its model, characterModel) and actorShape in scene3d project.ts; doc.game.actors; GameRun moves them."
	},
	m3dGame: {
		group: "3D mode",
		name: "Play game",
		user: "Play game walks you through the design: WASD walk, the mouse looks, E uses things. Its rules run as you play.",
		dev: "GameRun in packages/scene3d/src/model/gamerun.ts (rules, walls, areas); GamePlay.tsx shows GameRun.frame, whose camera is the player's eyes."
	},
	m3dPlayerStart: {
		group: "3D mode",
		name: "Player start",
		user: "Turn the view to where the player should stand and press Start where the view is. Set the eye height and speed.",
		dev: "doc.game.player (packages/scene3d/src/model/game.ts); defaultGame puts it where the design's camera is."
	},
	m3dGameAreas: {
		group: "3D mode",
		name: "Walls and trigger areas",
		user: "Shapes are walls. Make one Walk through, or a Trigger area: unseen while playing, walking in sets off rules.",
		dev: "doc.game.passable and doc.game.areas (shape ids); GameRun.walk pushes out of the rest, GameRun.tick fires enter and leave."
	},
	m3dGameRules: {
		group: "3D mode",
		name: "Game rules",
		user: "A rule: when something happens, if flags are set, do actions: say lines, ask a choice, show or hide a shape, end.",
		dev: "doc.game.rules: checkGame in packages/scene3d/src/model/game.ts, run by GameRun.fire and pump in gamerun.ts; Shelf Life plays them too."
	},
	m3dDesignFile: {
		group: "3D mode",
		name: "Save and open a design",
		user: "Save > Design (.json) keeps the design to change later. Import it, or drop it on the view, to open it again.",
		dev: "designFile and openDesignFile in packages/scene3d/src/model/document.ts (checkModel on open); the same file as MCP model_save and model_open."
	},
	m3dSave: {
		group: "3D mode",
		name: "Save a picture",
		user: "Saves a PNG of the design, see-through wherever there is nothing.",
		dev: "renderModel(doc, width, height) in packages/scene3d/src/model/renderer.ts, saved through a download link."
	},
	labDevelop: {
		group: "Photo lab",
		name: "Develop",
		user: "Drag the sliders to change light, colour, detail and lens faults across the photo. Apply keeps the result.",
		dev: "LightCraft develop pipeline: develop.render on the active layer (DevelopSource in packages/craft/rust/src/lib.rs), applied with replace_active_rgba."
	},
	labLooks: {
		group: "Photo lab",
		name: "Looks",
		user: "Click a look to try it on the photo; Strength sets how much. Apply keeps it.",
		dev: "LightCraft's built-in presets (develop_presets) applied with develop_apply_preset at the chosen amount, then rendered like Develop."
	},
	labTools: {
		group: "Photo lab",
		name: "Tools",
		user: "Pick a tool and use it on the photo: select, remove marks, heal, copy, lighten, paint.",
		dev: "packages/react/src/photolab/tools.ts; gestureCommand (photolab/gestures.ts) turns a drag, stroke or click into one engine command."
	},
	labSelect: {
		group: "Photo lab",
		name: "Selection buttons",
		user: "Main thing and Sky select for you; Refine edge softens a selection round hair and fur.",
		dev: "select.subject, select.sky, select.focusArea, select.refineEdge, select.inverse, select.deselect, edit.contentAwareFill through Craft.execute."
	},
	labEverything: {
		group: "Photo lab",
		name: "Everything",
		user: "Every filter, adjustment, layer and selection command. Search, click one, set it and press Apply.",
		dev: "Craft.commands() (PhotoCraft's command.list); forms come from each command's parameter text via parseParams (packages/craft/src/params.ts)."
	},
	labLayers: {
		group: "Photo lab",
		name: "Layers",
		user: "Click a layer to work on it; the eye hides it. Opacity and blend apply to the picked layer.",
		dev: "layer.list, layer.select, layer.setProps, layer.new.layer, layer.duplicate, layer.delete, layer.mergeDown, layer.flattenImage."
	},
	labHistory: {
		group: "Photo lab",
		name: "History",
		user: "Every change so far. Click one to go back to it; Redo steps forward again until you change something.",
		dev: "document.inspect's history list; a click runs history.selectState {state}."
	},
	labFiles: {
		group: "Photo lab",
		name: "Open and save files",
		user: "Open a layered file (PSD) or any photo; Save a copy as PSD with layers, or PNG, JPEG, WebP or TIFF.",
		dev: "Craft.openFile / Craft.export (photocraft-io import and export, PSD and PSB included) in packages/craft/src/index.ts."
	},
	market: {
		group: "Market",
		name: "Market mode",
		user: "What a product sells for and where: sold comps, prices by country, landed cost, translation and a bootleg check.",
		dev: "packages/react/src/market/MarketMode.tsx over the app's /market routes (apps/local/src/market.ts). Entry: @gleamshelf/react/market."
	},
	marketComps: {
		group: "Market",
		name: "Sold comps",
		user: "Choose a sales file (a Terapeak export or an Amazon order report). You see what this product sold for, by condition.",
		dev: "apps/local/src/comps.ts (salesFromCsv, matchSales, soldComps, suggestPrice); eBay sold prices by ebaySoldSearch once eBay approves Marketplace Insights."
	},
	marketRegions: {
		group: "Market",
		name: "Prices by country",
		user: "Compares new-item asking prices in Japan and on eBay abroad, and what buying there and selling here would leave you.",
		dev: "apps/local/src/regions.ts: Japanese shops by web search (schema.org JPY prices), other countries by ebaySearchIn (Browse API, production keys); opportunities()."
	},
	marketLanded: {
		group: "Market",
		name: "Landed cost",
		user: "Enter a price, where it is bought and where it lands. You get shipping, duty, tax and fees (Amazon FBA too) line by line.",
		dev: "apps/local/src/landed.ts: DEFAULT_RULES (dated estimates, Amazon referral minimum and Individual-plan fee) under ~/.gleamshelf/landed.json; landedCost, saleNet, margin."
	},
	marketLocalise: {
		group: "Market",
		name: "Translate listing",
		user: "Translates the listing for another marketplace; for Amazon also bullet points and search terms, checked against its rules.",
		dev: "apps/local/src/localise.ts: namesFor, localisePrompt (Amazon JSON with bullets, searchTerms), TITLE_LIMITS, amazonRules, fitBytes, number checks as flags."
	},
	marketBootleg: {
		group: "Market",
		name: "Bootleg check",
		user: "Compares a photo with the maker’s official one and outlines what differs. It never says fake or genuine: you decide.",
		dev: "apps/local/src/bootleg.ts: registerReferences places the official photo, compareCells (8x8, like sameFigure), the vision model side by side."
	},
	marketSellMore: {
		group: "Market",
		name: "Sell more",
		user: "Choose an orders file (and a stock file). You see what sells together, best sellers, badges, deals and what to reorder.",
		dev: "apps/local/src/insights.ts (boughtTogether, bestSellers, badges, deals, reorders); the same without the screen: npm run market -- sell, apps/local/src/market-cli.ts."
	},
	marketReviews: {
		group: "Market",
		name: "Customers say",
		user: "Choose a reviews file. The stars are counted, and the summary quotes only words customers really wrote.",
		dev: "apps/local/src/reviews.ts: reviewsFromCsv, reviewStats, summaryPrompt to the local text model, checkSummary drops quotes found in no review."
	},
	marketSynonyms: {
		group: "Market",
		name: "Search synonyms",
		user: "Paste product titles. You get every name of each series (English, Japanese, short names) for your site search.",
		dev: "apps/local/src/synonyms.ts: synonymGroups over series.json, shopifySynonyms writes Search & Discovery groups."
	},
	marketPlan: {
		group: "Market",
		name: "What to import",
		user: "Weighs anime trends, your sales and stock, makers’ announced figures and a supplier list with margins. Each pick shows why.",
		dev: "apps/local/src/plan.ts (seriesPicks, productPicks, buyingBrief) over apps/local/src/trends.ts (AniList) and apps/local/src/announcements.ts (makers’ sites)."
	}
}, kt = [
	{
		name: "Arrange",
		tools: [
			{
				id: "move",
				label: "Move and transform",
				key: "v",
				hint: "Drag a layer to move it. Corners resize (Shift keeps the shape), the round handle turns it. Arrow keys nudge.",
				dev: "Changes layer.transform (x, y, scaleX, scaleY, rotation): packages/canvas/src/geometry.ts. Command: set_layer."
			},
			{
				id: "crop",
				label: "Crop canvas",
				key: "c",
				hint: "Drag the area to keep, then press Enter. Esc cancels.",
				dev: "resizeCanvas in packages/canvas/src/document.ts moves every layer. Command: crop."
			},
			{
				id: "hand",
				label: "Pan",
				key: "h",
				hint: "Drag to move around. Hold Space with any tool to pan. On a touch screen, two fingers pinch and pan with any tool.",
				dev: "View only (pan offset in EditMode state); the document is not changed. Two fingers: TwoFingers in packages/react/src/pinch.ts."
			},
			{
				id: "zoom",
				label: "Zoom",
				key: "z",
				hint: "Click to zoom in, Alt-click to zoom out. Ctrl or Cmd with the wheel zooms anywhere.",
				dev: "View only (zoom in EditMode state); the document is not changed."
			}
		]
	},
	{
		name: "Select",
		tools: [
			{
				id: "box",
				label: "Box selection",
				key: "m",
				hint: "Drag a box. Shift adds, Alt takes away, both keep the overlap.",
				dev: "selectRect + combine in packages/canvas/src/selection.ts (a bitmap the size of the canvas). Command: select_rect."
			},
			{
				id: "oval",
				label: "Oval selection",
				key: "m",
				shift: !0,
				hint: "Drag an oval. Shift adds, Alt takes away.",
				dev: "selectEllipse + combine in packages/canvas/src/selection.ts. Command: select_ellipse."
			},
			{
				id: "lasso",
				label: "Lasso",
				key: "l",
				hint: "Draw round what you want. Shift adds, Alt takes away.",
				dev: "selectPolygon + combine in packages/canvas/src/selection.ts. Command: select_polygon."
			},
			{
				id: "wand",
				label: "Magic wand",
				key: "w",
				hint: "Click a colour to select it. Tolerance sets how alike colours must be.",
				dev: "magicWand(picture, at, tolerance, contiguous) in packages/canvas/src/selection.ts. Command: magic_wand."
			}
		]
	},
	{
		name: "Paint",
		tools: [
			{
				id: "brush",
				label: "Brush",
				key: "b",
				hint: "Paint on a picture layer. [ and ] change the size. Stabiliser steadies your hand. On a mask it shows the layer.",
				dev: "strokeTo / dab in packages/canvas/src/paint.ts, clipped to the selection, through stabilise() in packages/canvas/src/ink.ts; on a mask it paints the mask. Command: brush_stroke."
			},
			{
				id: "eraser",
				label: "Eraser",
				key: "e",
				hint: "Rub out to transparency. On a mask it hides the layer.",
				dev: "strokeTo with erase in packages/canvas/src/paint.ts (alpha to 0, or hides through a mask). Command: brush_stroke with erase."
			},
			{
				id: "clone",
				label: "Clone",
				key: "s",
				hint: "Alt-click where to copy from, then paint where to copy to.",
				dev: "cloneDab in packages/canvas/src/paint.ts, copying from the Alt-clicked offset."
			},
			{
				id: "heal",
				label: "Heal",
				key: "j",
				hint: "Paint over a mark — dust, glare, a scratch — and it melts into what surrounds it when you let go.",
				dev: "coverDab + healPixels in packages/react/src/edit/heal.ts: the free inpaint from packages/pipeline on a crop round the stroke, blended back by its cover."
			},
			{
				id: "bucket",
				label: "Fill",
				key: "g",
				hint: "Click to fill a patch of similar colour. Inside the ink lines colours your line art.",
				dev: "floodFill(target, at, colour, tolerance) in packages/canvas/src/paint.ts. Inside the ink lines: insideLines in packages/canvas/src/ink.ts. Commands: flood_fill, fill_inside_lines."
			},
			{
				id: "gradient",
				label: "Gradient",
				key: "g",
				shift: !0,
				hint: "Drag from where the main colour starts to where the second colour ends.",
				dev: "linearGradient in packages/canvas/src/paint.ts, clipped to the selection. Command: gradient."
			},
			{
				id: "dropper",
				label: "Pick colour",
				key: "i",
				hint: "Click to take a colour as the main colour; Alt-click for the second colour.",
				dev: "sample(picture, at) in packages/canvas/src/paint.ts on the flattened picture. Command: set_colours."
			}
		]
	},
	{
		name: "Draw",
		tools: [
			{
				id: "rect",
				label: "Rectangle",
				key: "r",
				hint: "Drag a rectangle (Shift for a square). It stays an editable shape.",
				dev: "Adds a shape layer {shape: \"rect\"} drawn by packages/canvas/src/render.ts. Command: add_shape."
			},
			{
				id: "ellipse",
				label: "Ellipse",
				key: "o",
				hint: "Drag an ellipse (Shift for a circle).",
				dev: "Adds a shape layer {shape: \"ellipse\"}. Command: add_shape."
			},
			{
				id: "line",
				label: "Line",
				key: "n",
				hint: "Drag a line (Shift snaps the angle).",
				dev: "Adds a shape layer {shape: \"line\"}. Command: add_shape."
			},
			{
				id: "pen",
				label: "Pen",
				key: "p",
				hint: "Click for corners, drag for curves. Click the first point to close; Enter finishes an open path.",
				dev: "Builds PathData (pathD in packages/canvas/src/geometry.ts) as a path layer. Command: add_path."
			},
			{
				id: "ink",
				label: "Ink",
				key: "k",
				hint: "Draw line art. Lines taper and stay sharp at any size, on an ink layer.",
				dev: "addInkPoint / finishInk / stabilise in packages/canvas/src/ink.ts: an ink shape layer (shape.type \"ink\", strokes of points with widths), drawn by inkD with the nonzero rule. Command: ink_stroke."
			},
			{
				id: "text",
				label: "Text",
				key: "t",
				hint: "Click to type. Click existing text to change it.",
				dev: "A text layer drawn with measureText/drawLayer in packages/canvas/src/render.ts. Command: add_text."
			}
		]
	}
], At = kt.flatMap((e) => e.tools), jt = (e) => At.find((t) => t.id === e), Mt = [
	"size",
	"hardness",
	"opacity",
	"flow"
], Nt = [
	{
		id: "hand",
		label: "Move around",
		group: "View",
		gesture: "pan",
		options: [],
		hint: "Drag to move around the photo; the wheel or a two-finger pinch zooms. Hold Space with any tool to move around.",
		dev: "View only (zoom and pan in PhotoLab state); nothing is sent to the engine. Two fingers: TwoFingers in packages/react/src/pinch.ts."
	},
	{
		id: "crop",
		label: "Crop",
		group: "View",
		gesture: "box",
		command: "image.crop",
		options: [],
		hint: "Drag the part of the photo to keep. The canvas is cut to it (undo brings it back).",
		dev: "image.crop {x, y, width, height} through Craft.execute (packages/craft/src/index.ts)."
	},
	{
		id: "dropper",
		label: "Pick a colour",
		group: "View",
		gesture: "click",
		command: "document.pixel",
		options: ["colors"],
		hint: "Click the photo to make that colour the paint colour.",
		dev: "document.pixel {x, y} reads the composite; the result becomes the paint colour (tools.setColors)."
	},
	{
		id: "box",
		label: "Box selection",
		group: "Select",
		gesture: "box",
		command: "select.rect",
		options: ["mode"],
		hint: "Drag a box to select. Shift adds to the selection, Alt takes away.",
		dev: "select.rect {x, y, width, height, mode}. The selection is read back with Craft.selection() and drawn as a tint."
	},
	{
		id: "oval",
		label: "Oval selection",
		group: "Select",
		gesture: "box",
		command: "select.rect",
		options: ["mode"],
		hint: "Drag an oval to select. Shift adds, Alt takes away.",
		dev: "select.rect with ellipse: true."
	},
	{
		id: "lasso",
		label: "Lasso",
		group: "Select",
		gesture: "lasso",
		command: "select.lasso",
		options: ["mode"],
		hint: "Draw round what you want to select. Shift adds, Alt takes away.",
		dev: "select.lasso {points, mode}."
	},
	{
		id: "quick",
		label: "Smart brush selection",
		group: "Select",
		gesture: "stroke",
		command: "select.quick",
		options: ["size", "mode"],
		hint: "Paint over a thing and the selection spreads to its edges. Alt paints to take away.",
		dev: "select.quick {points, size, mode}: a graph cut on colour (crates/algo/src/segment in PhotoCraft)."
	},
	{
		id: "object",
		label: "Object selection",
		group: "Select",
		gesture: "box",
		command: "select.object",
		options: ["mode"],
		hint: "Drag a loose box round one thing and it is selected to its outline.",
		dev: "select.object {rect: [x, y, w, h], mode}: GrabCut inside the box."
	},
	{
		id: "wand",
		label: "Colour selection",
		group: "Select",
		gesture: "click",
		command: "select.magicWand",
		options: ["tolerance", "mode"],
		hint: "Click a colour to select it and the touching pixels like it. Tolerance sets how alike.",
		dev: "select.magicWand {x, y, tolerance, mode}."
	},
	{
		id: "remove",
		label: "Remove",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.remove",
		options: ["size"],
		hint: "Paint over a speck, sticker or stand to remove it; drawing round a thing removes what is inside.",
		dev: "paint.remove {points, size}: patch-based completion from the surroundings (no AI, nothing leaves the computer)."
	},
	{
		id: "spot",
		label: "Spot fix",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.spotHealing",
		options: Mt,
		hint: "Dab dust and small marks away: the texture around them fills in.",
		dev: "paint.spotHealing {points, size, hardness, opacity, flow}."
	},
	{
		id: "heal",
		label: "Heal",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.healingBrush",
		options: Mt,
		source: !0,
		hint: "Alt-click a clean area, then paint over the mark: the clean texture blends into its light and colour.",
		dev: "paint.healingBrush {points, source: [x, y]}; the Alt-click point is kept in PhotoLab state."
	},
	{
		id: "clone",
		label: "Copy paint",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.cloneStamp",
		options: Mt,
		source: !0,
		hint: "Alt-click where to copy from, then paint where to copy to.",
		dev: "paint.cloneStamp {points, source: [x, y], aligned: true}."
	},
	{
		id: "redEye",
		label: "Red eye",
		group: "Retouch",
		gesture: "click",
		command: "paint.redEye",
		options: [],
		hint: "Click a red pupil to darken it back to natural.",
		dev: "paint.redEye {x, y}: finds the red pupil round the click and darkens it."
	},
	{
		id: "dodge",
		label: "Lighten by hand",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.dodge",
		options: Mt,
		hint: "Paint to lighten just those areas.",
		dev: "paint.dodge {points, size, ...}."
	},
	{
		id: "burn",
		label: "Darken by hand",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.burn",
		options: Mt,
		hint: "Paint to darken just those areas.",
		dev: "paint.burn {points, size, ...}."
	},
	{
		id: "sponge",
		label: "Colour strength",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.sponge",
		options: Mt,
		hint: "Paint to make colours richer where you paint.",
		dev: "paint.sponge {points, size, ...}."
	},
	{
		id: "soften",
		label: "Soften by hand",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.blur",
		options: Mt,
		hint: "Paint to soften detail, such as a busy edge.",
		dev: "paint.blur {points, size, ...}."
	},
	{
		id: "crisp",
		label: "Crisp by hand",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.sharpen",
		options: Mt,
		hint: "Paint to bring out detail where you paint.",
		dev: "paint.sharpen {points, size, ...}."
	},
	{
		id: "smudge",
		label: "Smudge",
		group: "Retouch",
		gesture: "stroke",
		command: "paint.smudge",
		options: Mt,
		hint: "Drag to push paint along, like a finger in wet paint.",
		dev: "paint.smudge {points, size, ...}."
	},
	{
		id: "shift",
		label: "Move a thing",
		group: "Retouch",
		gesture: "line",
		command: "paint.contentAwareMove",
		options: [],
		needsSelection: !0,
		hint: "Select a thing first, then drag it somewhere else: the gap it leaves fills in.",
		dev: "paint.contentAwareMove {offset: [dx, dy]} on the current selection."
	},
	{
		id: "patch",
		label: "Patch",
		group: "Retouch",
		gesture: "line",
		command: "paint.patch",
		options: [],
		needsSelection: !0,
		hint: "Select a mark first, then drag to a clean area: the selection is repaired from there.",
		dev: "paint.patch {offset: [dx, dy], mode: \"source\"} on the current selection."
	},
	{
		id: "brush",
		label: "Brush",
		group: "Paint",
		gesture: "stroke",
		command: "paint.stroke",
		options: [...Mt, "colors"],
		hint: "Paint with the paint colour. [ and ] change the size.",
		dev: "paint.stroke {points, size, hardness, opacity, flow, color}."
	},
	{
		id: "pencil",
		label: "Pencil",
		group: "Paint",
		gesture: "stroke",
		command: "paint.pencil",
		options: [
			"size",
			"opacity",
			"colors"
		],
		hint: "Hard-edged lines, pixel exact.",
		dev: "paint.pencil {points, size, opacity, color}."
	},
	{
		id: "eraser",
		label: "Eraser",
		group: "Paint",
		gesture: "stroke",
		command: "paint.stroke",
		options: Mt,
		hint: "Rub out to see-through.",
		dev: "paint.stroke with erase: true."
	},
	{
		id: "bgEraser",
		label: "Background eraser",
		group: "Paint",
		gesture: "stroke",
		command: "paint.backgroundEraser",
		options: [
			"size",
			"hardness",
			"tolerance"
		],
		hint: "Paint along an edge: the colour under the centre is rubbed out, the thing beside it stays.",
		dev: "paint.backgroundEraser {points, size, hardness, tolerance}."
	},
	{
		id: "magicEraser",
		label: "Erase a colour",
		group: "Paint",
		gesture: "click",
		command: "paint.magicEraser",
		options: ["tolerance"],
		hint: "Click a plain background to rub out that colour in one go.",
		dev: "paint.magicEraser {x, y, tolerance}."
	},
	{
		id: "bucket",
		label: "Fill",
		group: "Paint",
		gesture: "click",
		command: "paint.bucket",
		options: ["tolerance", "colors"],
		hint: "Click to fill a patch of similar colour with the paint colour.",
		dev: "paint.bucket {x, y, tolerance, color}."
	},
	{
		id: "gradient",
		label: "Gradient",
		group: "Paint",
		gesture: "line",
		command: "paint.gradient",
		options: ["colors"],
		hint: "Drag from where the paint colour starts to where the second colour ends.",
		dev: "paint.gradient {from, to, colors: [paint, second]}."
	},
	{
		id: "mixer",
		label: "Wet paint",
		group: "Paint",
		gesture: "stroke",
		command: "paint.mixerBrush",
		options: ["size", "colors"],
		hint: "Paint that mixes with the colours already there.",
		dev: "paint.mixerBrush {points, size, color}."
	},
	{
		id: "recolour",
		label: "Recolour",
		group: "Paint",
		gesture: "stroke",
		command: "paint.colorReplacement",
		options: [
			"size",
			"tolerance",
			"colors"
		],
		hint: "Paint over a colour to swap it for the paint colour, keeping its shading.",
		dev: "paint.colorReplacement {points, size, tolerance, color}."
	}
], Pt = [
	"View",
	"Select",
	"Retouch",
	"Paint"
], Ft = [
	{
		id: "replace",
		label: "New"
	},
	{
		id: "add",
		label: "Add (Shift)"
	},
	{
		id: "subtract",
		label: "Take away (Alt)"
	},
	{
		id: "intersect",
		label: "Overlap"
	}
], It = "gleamshelf:dev-notes", Lt = /* @__PURE__ */ new Set(), Rt = (() => {
	try {
		return localStorage.getItem(It) === "1";
	} catch {
		return !1;
	}
})();
function zt(e) {
	Rt = e;
	try {
		localStorage.setItem(It, e ? "1" : "0");
	} catch {}
	for (let e of Lt) e();
}
function Bt() {
	return ge((e) => (Lt.add(e), () => Lt.delete(e)), () => Rt, () => !1);
}
function Vt({ text: e }) {
	return Bt() ? /* @__PURE__ */ P("span", {
		className: "gs-devnote",
		children: e
	}) : null;
}
function K({ id: e, inline: t }) {
	let n = Bt(), r = Ot[e];
	return t ? /* @__PURE__ */ F("span", {
		className: "gs-help",
		children: [/* @__PURE__ */ P("span", {
			className: "gs-howto",
			children: r.user
		}), n && /* @__PURE__ */ P("span", {
			className: "gs-devnote",
			children: r.dev
		})]
	}) : /* @__PURE__ */ F("div", {
		className: "gs-help",
		children: [/* @__PURE__ */ P("p", {
			className: "gs-howto",
			children: r.user
		}), n && /* @__PURE__ */ P("p", {
			className: "gs-devnote",
			children: r.dev
		})]
	});
}
function Ht() {
	let e = Bt();
	return /* @__PURE__ */ F("label", {
		className: "gs-control gs-control--inline gs-devswitch",
		children: [/* @__PURE__ */ P("input", {
			type: "checkbox",
			checked: e,
			onChange: (e) => zt(e.target.checked)
		}), "Developer notes"]
	});
}
function Ut({ onClose: e }) {
	let t = Bt();
	A(() => {
		let t = (t) => {
			t.key === "Escape" && (t.stopPropagation(), e());
		};
		return window.addEventListener("keydown", t, !0), () => window.removeEventListener("keydown", t, !0);
	}, [e]);
	let n = Object.values(Ot);
	return /* @__PURE__ */ P("div", {
		className: "gs-guide",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Guide",
		onClick: e,
		children: /* @__PURE__ */ F("div", {
			className: "gs-guide__sheet",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ F("header", {
				className: "gs-guide__head",
				children: [
					/* @__PURE__ */ P("h2", { children: "Guide" }),
					/* @__PURE__ */ P(Ht, {}),
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-icon-button",
						onClick: e,
						"aria-label": "Close the guide",
						children: /* @__PURE__ */ P(Kt, { name: "close" })
					})
				]
			}), /* @__PURE__ */ P("div", {
				className: "gs-guide__body",
				children: Dt.map((e) => /* @__PURE__ */ F("section", { children: [
					/* @__PURE__ */ P("h3", { children: e }),
					/* @__PURE__ */ P("dl", { children: n.filter((t) => t.group === e).map((e) => /* @__PURE__ */ F("div", {
						className: "gs-guide__item",
						children: [
							/* @__PURE__ */ P("dt", { children: e.name }),
							/* @__PURE__ */ P("dd", { children: e.user }),
							t && /* @__PURE__ */ P("dd", {
								className: "gs-devnote",
								children: e.dev
							})
						]
					}, e.name)) }),
					e === "Photo lab" && /* @__PURE__ */ P("dl", { children: Nt.map((e) => /* @__PURE__ */ F("div", {
						className: "gs-guide__item",
						children: [
							/* @__PURE__ */ P("dt", { children: e.label }),
							/* @__PURE__ */ P("dd", { children: e.hint }),
							t && /* @__PURE__ */ P("dd", {
								className: "gs-devnote",
								children: e.dev
							})
						]
					}, e.id)) }),
					e === "Edit mode" && /* @__PURE__ */ P("dl", { children: At.map((e) => /* @__PURE__ */ F("div", {
						className: "gs-guide__item",
						children: [
							/* @__PURE__ */ F("dt", { children: [
								e.label,
								" ",
								/* @__PURE__ */ P("kbd", { children: e.shift ? `Shift+${e.key.toUpperCase()}` : e.key.toUpperCase() })
							] }),
							/* @__PURE__ */ P("dd", { children: e.hint }),
							t && /* @__PURE__ */ P("dd", {
								className: "gs-devnote",
								children: e.dev
							})
						]
					}, e.id)) })
				] }, e))
			})]
		})
	});
}
//#endregion
//#region src/glyphs.tsx
var Wt = (e, t, n) => ({ "--fill": `${Math.max(0, Math.min(100, (e - t) / (n - t || 1) * 100))}%` }), Gt = {
	undo: /* @__PURE__ */ P("path", { d: "M9 14L4 9l5-5M4 9h10a6 6 0 010 12h-3" }),
	redo: /* @__PURE__ */ P("path", { d: "M15 14l5-5-5-5M20 9H10a6 6 0 000 12h3" }),
	compare: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("rect", {
		x: "3",
		y: "5",
		width: "18",
		height: "14",
		rx: "3"
	}), /* @__PURE__ */ P("path", { d: "M12 5v14" })] }),
	reset: /* @__PURE__ */ P("path", { d: "M4 12a8 8 0 102.3-5.7M4 4v4h4" }),
	layers: /* @__PURE__ */ P("path", { d: "M12 3l9 5-9 5-9-5 9-5zM3 13l9 5 9-5" }),
	close: /* @__PURE__ */ P("path", { d: "M6 6l12 12M18 6L6 18" }),
	spark: /* @__PURE__ */ P("path", { d: "M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z" }),
	scissors: /* @__PURE__ */ F(N, { children: [
		/* @__PURE__ */ P("circle", {
			cx: "6",
			cy: "7",
			r: "3"
		}),
		/* @__PURE__ */ P("circle", {
			cx: "6",
			cy: "17",
			r: "3"
		}),
		/* @__PURE__ */ P("path", { d: "M8.5 8.5L20 19M8.5 15.5L20 5" })
	] }),
	brush: /* @__PURE__ */ P("path", { d: "M14 4l6 6-8 8-6-6zM6 12c-2 1-2.5 4-3 8 4-.5 7-1 8-3" }),
	sliders: /* @__PURE__ */ P("path", { d: "M4 7h10M18 7h2M4 17h4M12 17h8M14 4v6M8 14v6" }),
	help: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("circle", {
		cx: "12",
		cy: "12",
		r: "9"
	}), /* @__PURE__ */ P("path", { d: "M9.5 9.5a2.5 2.5 0 114 2c-1 .6-1.5 1.2-1.5 2.3M12 17h.01" })] })
};
function Kt({ name: e, size: t = 16 }) {
	return /* @__PURE__ */ P("svg", {
		width: t,
		height: t,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: 1.8,
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: Gt[e]
	});
}
//#endregion
//#region src/CutoutOverlay.tsx
var qt = .002;
function Jt({ editor: e, doc: t, settings: n, width: r, height: i }) {
	let a = j(null), [o, s] = M(null), c = (t) => {
		let n = t.currentTarget.getBoundingClientRect(), [r, i] = te(_(e.document), (t.clientX - n.left) / n.width, (t.clientY - n.top) / n.height);
		return [Math.min(1, Math.max(0, r)), Math.min(1, Math.max(0, i))];
	}, l = (e) => ({
		kind: "brush",
		mode: n.tool === "erase" ? "remove" : "keep",
		radius: n.brush,
		points: e
	}), u = (t) => {
		t.preventDefault();
		let [r, i] = c(t);
		n.tool === "tap" ? e.addMaskOp({
			kind: "fill",
			mode: "remove",
			x: r,
			y: i,
			tolerance: n.tolerance
		}) : (t.currentTarget.setPointerCapture(t.pointerId), a.current = [r, i], e.begin(n.tool === "erase" ? "Erase" : "Restore"), e.addMaskOp(l(a.current)));
	}, d = (t) => {
		let n = t.currentTarget.getBoundingClientRect();
		s({
			x: t.clientX - n.left,
			y: t.clientY - n.top
		});
		let r = a.current;
		if (!r) return;
		let [i, o] = c(t);
		Math.hypot(i - r[r.length - 2], o - r[r.length - 1]) < qt || (r.push(i, o), e.updateLastMaskOp(l([...r])));
	}, f = () => {
		a.current && (a.current = null, e.commit());
	}, p = T(t), m = n.brush * Math.max(t.source.width, t.source.height) * (r / p.width);
	return /* @__PURE__ */ P("div", {
		className: `gs-cutout gs-cutout--${n.tool}`,
		style: {
			width: r,
			height: i
		},
		onPointerDown: u,
		onPointerMove: d,
		onPointerUp: f,
		onPointerCancel: f,
		onPointerLeave: () => s(null),
		children: o && n.tool !== "tap" && /* @__PURE__ */ P("div", {
			className: "gs-cutout__brush",
			style: {
				left: o.x - m,
				top: o.y - m,
				width: m * 2,
				height: m * 2
			}
		})
	});
}
//#endregion
//#region src/panel/CutoutSection.tsx
var Yt = [
	{
		tool: "tap",
		label: "Tap",
		title: "Tap the background to remove everything of a similar colour around that point"
	},
	{
		tool: "erase",
		label: "Erase",
		title: "Paint over what should be removed"
	},
	{
		tool: "restore",
		label: "Restore",
		title: "Paint over what should come back"
	}
];
function Xt({ editor: e, doc: t, cutout: n, onToggleCutout: r, cutSettings: i, onCutSettings: a, aiCutout: o, flatten: s }) {
	let c = t.recipe.mask.length > 0, l = t.recipe.mask.some((e) => e.kind === "green");
	return /* @__PURE__ */ F("section", { children: [
		/* @__PURE__ */ P("h2", { children: "Background" }),
		/* @__PURE__ */ P("div", {
			className: "gs-crop-tools",
			children: /* @__PURE__ */ P("button", {
				type: "button",
				className: "gs-button",
				disabled: l,
				onClick: () => e.removeGreenBackdrop(),
				title: "For photos shot on a green cloth or screen: makes the green transparent in one click. Free.",
				children: l ? "Green removed" : "Remove green backdrop"
			})
		}),
		/* @__PURE__ */ P(K, { id: "green" }),
		/* @__PURE__ */ F("div", {
			className: "gs-crop-tools",
			children: [/* @__PURE__ */ P("button", {
				type: "button",
				className: `gs-button ${n ? "gs-button--primary" : ""}`,
				onClick: r,
				children: n ? "Done" : c ? "Edit cut-out" : "Cut out product"
			}), c && /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("button", {
				type: "button",
				className: "gs-button",
				onClick: () => e.fadeBottom(.1),
				title: "Fade the bottom edge of the cut-out out softly, instead of ending in a hard line (good for a figure cut off at the waist)",
				children: "Fade bottom"
			}), /* @__PURE__ */ P("button", {
				type: "button",
				className: "gs-button",
				onClick: () => e.clearMask(),
				title: "Bring back the whole photo",
				children: "Clear"
			})] })]
		}),
		!n && /* @__PURE__ */ P(K, { id: "cutManual" }),
		!n && c && /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P(K, { id: "fade" }), /* @__PURE__ */ P(K, { id: "clearMask" })] }),
		n && /* @__PURE__ */ F(N, { children: [
			/* @__PURE__ */ P("div", {
				className: "gs-segmented",
				role: "group",
				"aria-label": "Cut-out tool",
				children: Yt.map(({ tool: e, label: t, title: n }) => /* @__PURE__ */ P("button", {
					type: "button",
					className: `gs-button ${i.tool === e ? "is-active" : ""}`,
					"aria-pressed": i.tool === e,
					title: n,
					onClick: () => a({ tool: e }),
					children: t
				}, e))
			}),
			/* @__PURE__ */ P(K, { id: `cut.${i.tool}` }),
			i.tool === "tap" ? /* @__PURE__ */ F("label", {
				className: "gs-control",
				children: [/* @__PURE__ */ F("span", {
					className: "gs-control__row",
					children: [/* @__PURE__ */ P("span", { children: "Tolerance" }), /* @__PURE__ */ P("output", { children: i.tolerance })]
				}), /* @__PURE__ */ P("input", {
					type: "range",
					style: Wt(i.tolerance, 1, 100),
					min: 1,
					max: 100,
					step: 1,
					value: i.tolerance,
					onChange: (e) => a({ tolerance: Number(e.target.value) })
				})]
			}) : /* @__PURE__ */ F("label", {
				className: "gs-control",
				children: [/* @__PURE__ */ F("span", {
					className: "gs-control__row",
					children: [/* @__PURE__ */ P("span", { children: "Brush size" }), /* @__PURE__ */ F("output", { children: [Math.round(i.brush * 1e3) / 10, "%"] })]
				}), /* @__PURE__ */ P("input", {
					type: "range",
					style: Wt(i.brush, .003, .08),
					min: .003,
					max: .08,
					step: .001,
					value: i.brush,
					onChange: (e) => a({ brush: Number(e.target.value) })
				})]
			})
		] }),
		o,
		s && c && !n && /* @__PURE__ */ F("div", {
			className: "gs-control",
			children: [
				/* @__PURE__ */ P("button", {
					type: "button",
					className: "gs-button",
					disabled: s.busy,
					onClick: s.run,
					title: "For a trading card, a box's front or a print photographed at an angle: pulls its four corners straight",
					children: s.busy ? "Straightening…" : "Flatten card or box front"
				}),
				s.note && /* @__PURE__ */ P("p", {
					className: "gs-hint",
					children: s.note
				}),
				/* @__PURE__ */ P(K, { id: "flatten" })
			]
		})
	] });
}
//#endregion
//#region src/panel/ShopSend.tsx
var Zt = (e) => e?.scrollIntoView({ block: "nearest" }), Qt = (e) => {
	try {
		return new URL(e).host;
	} catch {
		return e;
	}
};
function $t({ make: e }) {
	let [t, n] = M(!1), [r, i] = M(null);
	return /* @__PURE__ */ F("div", {
		className: "gs-listing",
		children: [
			/* @__PURE__ */ P("h3", { children: "3D ad" }),
			/* @__PURE__ */ P("p", {
				className: "gs-hint",
				children: "The product on a stage with its name, the price and your logo, moving: for posts, banners and short videos."
			}),
			/* @__PURE__ */ P("div", {
				className: "gs-button-row",
				children: /* @__PURE__ */ P("button", {
					type: "button",
					className: "gs-button",
					disabled: t,
					onClick: () => {
						n(!0), i(null), e().catch((e) => i(e instanceof Error ? e.message : "The ad maker could not open.")).finally(() => n(!1));
					},
					children: t ? "Opening…" : "Make a 3D ad"
				})
			}),
			r && /* @__PURE__ */ P("p", {
				ref: Zt,
				className: "gs-hint",
				children: r
			}, r),
			/* @__PURE__ */ P(K, { id: "makeAd" })
		]
	});
}
function en({ make: e }) {
	let [t, n] = M(!1), [r, i] = M(null);
	return /* @__PURE__ */ F("div", {
		className: "gs-listing",
		children: [
			/* @__PURE__ */ P("h3", { children: "3D model" }),
			/* @__PURE__ */ P("p", {
				className: "gs-hint",
				children: "A 3D model of the figure from this photo, or from more angles: to turn round in 3D mode and in ads."
			}),
			/* @__PURE__ */ P("div", {
				className: "gs-button-row",
				children: /* @__PURE__ */ P("button", {
					type: "button",
					className: "gs-button",
					disabled: t,
					onClick: () => {
						n(!0), i(null), e().catch((e) => i(e instanceof Error ? e.message : "3D mode could not open.")).finally(() => n(!1));
					},
					children: t ? "Opening…" : "Make a 3D model"
				})
			}),
			r && /* @__PURE__ */ P("p", {
				ref: Zt,
				className: "gs-hint",
				children: r
			}, r),
			/* @__PURE__ */ P(K, { id: "make3d" })
		]
	});
}
function tn({ shop: e, runId: t }) {
	let [n, r] = M(null), [i, a] = M(""), [o, s] = M(""), [c, l] = M(!1), [u, d] = M(null);
	A(() => {
		let t = !1;
		return e.status().then((e) => !t && r(e), () => !t && r({ connected: !1 })), () => {
			t = !0;
		};
	}, [e]), A(() => d(null), [t]);
	let f = (e) => d({
		ok: !1,
		text: e instanceof Error ? e.message : "That did not work."
	}), p = async () => {
		l(!0), d(null);
		try {
			let t = await e.connect(i, o);
			r({
				connected: !0,
				url: t.url,
				label: t.label,
				answering: !0
			}), s("");
		} catch (e) {
			f(e);
		} finally {
			l(!1);
		}
	}, m = async () => {
		l(!0), d(null);
		try {
			let n = await e.send(t);
			d({
				ok: !0,
				text: n.sent === "new" ? `Sent: it waits in ${Qt(n.shop)} › Imports for a price and stock.` : n.sent === "replaced" ? "Sent again: its earlier draft in Imports was replaced." : `The shop already has this photo (${n.status}), so it was left as it is.`
			});
		} catch (e) {
			f(e);
		} finally {
			l(!1);
		}
	};
	return /* @__PURE__ */ F("div", {
		className: "gs-listing gs-shop",
		children: [
			/* @__PURE__ */ P("h3", { children: "Send to the shop" }),
			n ? n.connected ? /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ F("p", {
				className: "gs-hint",
				children: [
					"Connected to ",
					Qt(n.url),
					n.answering ? "" : ": not answering, or the shop removed this computer"
				]
			}), /* @__PURE__ */ F("div", {
				className: "gs-button-row",
				children: [/* @__PURE__ */ P("button", {
					type: "button",
					className: "gs-button gs-button--primary",
					disabled: c,
					onClick: () => void m(),
					children: c ? "Sending…" : "Send as a draft"
				}), /* @__PURE__ */ P("button", {
					type: "button",
					className: "gs-link",
					disabled: c,
					onClick: () => {
						a(n.url), r({ connected: !1 });
					},
					children: "Connect again"
				})]
			})] }) : /* @__PURE__ */ F("form", {
				className: "gs-shop__connect",
				onSubmit: (e) => {
					e.preventDefault(), p();
				},
				children: [
					/* @__PURE__ */ P("p", {
						className: "gs-hint",
						children: "Connect once: the shop’s Imports page › Connect the app shows the address and a code."
					}),
					/* @__PURE__ */ P("input", {
						className: "gs-input",
						value: i,
						onChange: (e) => a(e.target.value),
						placeholder: "Shop address",
						"aria-label": "Shop address",
						autoComplete: "off"
					}),
					/* @__PURE__ */ P("input", {
						className: "gs-input",
						value: o,
						onChange: (e) => s(e.target.value),
						placeholder: "Code",
						"aria-label": "Code from the shop",
						inputMode: "numeric",
						autoComplete: "off"
					}),
					/* @__PURE__ */ P("button", {
						type: "submit",
						className: "gs-button",
						disabled: c || !i.trim() || !o.trim(),
						children: c ? "Connecting…" : "Connect"
					})
				]
			}) : /* @__PURE__ */ P("p", {
				className: "gs-hint",
				children: "Checking the shop…"
			}),
			u && /* @__PURE__ */ P("p", {
				className: u.ok ? "gs-hint gs-shop__ok" : "gs-error",
				children: u.text
			}),
			/* @__PURE__ */ P(K, { id: "sendToShop" })
		]
	});
}
function nn({ health: e, quality: t, changesUrl: n }) {
	return /* @__PURE__ */ F("div", {
		className: `gs-score gs-score--${e?.level ?? "fair"}`,
		children: [
			e && /* @__PURE__ */ F("div", {
				className: "gs-score__head",
				children: [/* @__PURE__ */ P("span", {
					className: "gs-score__score",
					"aria-label": `Listing health ${e.score} out of 100`,
					children: e.score
				}), /* @__PURE__ */ F("span", { children: [/* @__PURE__ */ P("strong", { children: "Listing health" }), /* @__PURE__ */ F("span", {
					className: "gs-hint",
					children: [" ", e.level === "good" ? "ready to list" : e.level === "fair" ? "a few things to fix" : "needs work"]
				})] })]
			}),
			t && /* @__PURE__ */ F("div", {
				className: "gs-score__badges",
				children: [/* @__PURE__ */ F("span", {
					className: `gs-badge ${t.cutout.score >= .8 ? "is-ok" : "is-warn"}`,
					title: t.cutout.reasons.join("; ") || "Nothing doubtful seen",
					children: [
						"Cut-out ",
						Math.round(t.cutout.score * 100),
						"% sure"
					]
				}), /* @__PURE__ */ F("span", {
					className: `gs-badge ${t.fidelity.original >= .9 ? "is-ok" : "is-warn"}`,
					title: "Share of the product that is still the photo's own detail; colour and light changes do not count",
					children: [Math.round(t.fidelity.original * 100), "% as photographed"]
				})]
			}),
			n && /* @__PURE__ */ F("details", {
				className: "gs-score__changes",
				children: [
					/* @__PURE__ */ P("summary", { children: "Show what is not as photographed" }),
					/* @__PURE__ */ P("img", {
						src: n,
						alt: "The product with the parts that were repainted, completed or redrawn tinted pink"
					}),
					/* @__PURE__ */ P("p", {
						className: "gs-hint",
						children: "Tinted: repainted (a sticker, a title), completed from an official picture, or redrawn. Compare these with the real item."
					})
				]
			}),
			e && e.fixes.length > 0 && /* @__PURE__ */ P("ol", {
				className: "gs-score__fixes",
				"aria-label": "Top fixes",
				children: e.fixes.map((e) => /* @__PURE__ */ P("li", { children: e }, e))
			}),
			e && /* @__PURE__ */ F("details", { children: [/* @__PURE__ */ P("summary", { children: "Every check" }), /* @__PURE__ */ P("ul", {
				className: "gs-score__checks",
				children: e.checks.map((e) => /* @__PURE__ */ F("li", {
					className: e.ok ? "is-ok" : "is-warn",
					children: [
						e.ok ? "✓" : "•",
						" ",
						e.label
					]
				}, e.id))
			})] }),
			/* @__PURE__ */ P(K, { id: "listingHealth" })
		]
	});
}
//#endregion
//#region src/panel/ListingSet.tsx
var rn = "gleamshelf:listing-set";
function an({ run: e, busy: t, note: n, hasCutout: r }) {
	let [i, a] = M(() => {
		try {
			let e = JSON.parse(localStorage.getItem(rn) ?? "null");
			if (Array.isArray(e)) return e.filter((e) => typeof e == "string" && !!w(e));
		} catch {}
		return re.map((e) => e.id);
	}), o = (e, t) => {
		let n = re.map((e) => e.id).filter((n) => n === e ? t : i.includes(n));
		a(n);
		try {
			localStorage.setItem(rn, JSON.stringify(n));
		} catch {}
	};
	return /* @__PURE__ */ F("div", {
		className: "gs-listing-set",
		children: [
			/* @__PURE__ */ P("div", {
				className: "gs-listing-set__presets",
				role: "group",
				"aria-label": "Marketplaces",
				children: re.map((e) => /* @__PURE__ */ F("label", {
					className: "gs-control gs-control--inline",
					title: e.rule,
					children: [
						/* @__PURE__ */ P("input", {
							type: "checkbox",
							checked: i.includes(e.id),
							onChange: (t) => o(e.id, t.target.checked)
						}),
						e.name,
						" ",
						/* @__PURE__ */ F("span", {
							className: "gs-hint",
							children: [e.size, "px"]
						})
					]
				}, e.id))
			}),
			/* @__PURE__ */ P("button", {
				type: "button",
				className: "gs-button",
				disabled: !r || t || !i.length,
				onClick: () => e(i),
				title: r ? "Saves one picture per ticked marketplace, each in its own size and framing, in one zip" : "Cut the product out first",
				children: t ? "Making the set…" : `Save the listing set (${i.length})`
			}),
			n && /* @__PURE__ */ P("p", {
				className: "gs-hint",
				children: n
			}),
			/* @__PURE__ */ P(K, { id: "listingSet" })
		]
	});
}
//#endregion
//#region src/panel/AutoSection.tsx
function on({ lookup: e }) {
	let t = {
		found: "✓ Product found online",
		"no-match": "✗ Product not found online",
		"no-pictures": "✗ Product not found online",
		off: "– Web lookup not used"
	}[e.state];
	return /* @__PURE__ */ F("div", {
		className: `gs-lookup is-${e.state}`,
		role: "status",
		children: [
			/* @__PURE__ */ P("strong", { children: t }),
			e.read && /* @__PURE__ */ F("span", {
				className: "gs-hint",
				children: [" · the cover reads: ", e.read]
			}),
			/* @__PURE__ */ P("p", {
				className: "gs-hint",
				children: e.detail
			}),
			e.state === "no-match" || e.state === "no-pictures" ? /* @__PURE__ */ P("p", {
				className: "gs-hint",
				children: "The picture was finished without it. For this product you can give the batch command official pictures with --ref-dir."
			}) : null
		]
	});
}
var sn = (e) => {
	try {
		return e ? new URL(e).hostname.replace(/^www\./, "") : null;
	} catch {
		return null;
	}
}, cn = 20;
function ln({ found: e }) {
	let t = e.photos.filter((e) => e.linesUp), n = e.photos.filter((e) => !e.linesUp), [r, i] = M(cn), a = j(e);
	a.current = e;
	let o = e.waiting;
	A(() => {
		if (!o || r === null) return;
		if (r <= 0) {
			let e = a.current;
			e.photos.some((e) => e.linesUp) && e.ticked.length ? e.use() : e.skip();
			return;
		}
		let e = setTimeout(() => i((e) => e === null ? null : e - 1), 1e3);
		return () => clearTimeout(e);
	}, [o, r]);
	let s = j(null);
	A(() => {
		o && s.current?.scrollIntoView({
			behavior: "smooth",
			block: "start"
		});
	}, [o]);
	let c = e.identity ? [
		e.identity.character,
		e.identity.printedTitle,
		e.identity.variant
	].filter(Boolean).join(" · ") : null, l = (t) => {
		let n = sn(t.page), r = e.ticked.includes(t.index);
		return /* @__PURE__ */ F("li", {
			className: `gs-found__card ${r ? "is-on" : ""} ${t.linesUp ? "" : "is-off"}`,
			children: [/* @__PURE__ */ F("label", { children: [t.thumb ? /* @__PURE__ */ P("img", {
				src: t.thumb,
				alt: t.title ?? "A picture found online"
			}) : /* @__PURE__ */ P("span", {
				className: "gs-found__blank",
				"aria-hidden": "true"
			}), /* @__PURE__ */ F("span", {
				className: "gs-found__meta",
				children: [t.linesUp ? /* @__PURE__ */ P("input", {
					type: "checkbox",
					checked: r,
					disabled: !e.waiting,
					onChange: () => {
						i(null), e.toggle(t.index);
					},
					"aria-label": `Use this picture${t.title ? `: ${t.title}` : ""}`
				}) : null, /* @__PURE__ */ P("span", {
					className: `gs-found__badge ${t.linesUp ? "is-match" : ""}`,
					children: t.linesUp ? t.shows === "figure" ? "The figure: fills what the print hides" : "The box: for colours" : "Doesn't line up"
				})]
			})] }), n && /* @__PURE__ */ P("a", {
				href: t.page,
				target: "_blank",
				rel: "noreferrer",
				className: "gs-found__source",
				title: t.title ?? t.page,
				children: n
			})]
		}, t.index);
	};
	return /* @__PURE__ */ F("div", {
		className: "gs-found",
		role: "region",
		"aria-label": "Pictures found online",
		ref: s,
		children: [
			/* @__PURE__ */ F("div", {
				className: "gs-found__head",
				children: [/* @__PURE__ */ P("strong", { children: e.waiting ? "Found online" : `Using ${e.ticked.length} of ${t.length} found online` }), c && /* @__PURE__ */ P("span", {
					className: "gs-hint",
					children: c
				})]
			}),
			e.waiting && /* @__PURE__ */ P(K, { id: "foundPhotos" }),
			t.length ? /* @__PURE__ */ P("ul", {
				className: "gs-found__grid",
				children: t.map(l)
			}) : /* @__PURE__ */ P("p", {
				className: "gs-hint",
				children: "None of these lines up with your photo, so none can be used to finish it."
			}),
			n.length > 0 && /* @__PURE__ */ F("details", {
				className: "gs-found__more",
				children: [/* @__PURE__ */ F("summary", { children: [
					n.length,
					" more ",
					n.length === 1 ? "doesn't" : "don't",
					" line up with your photo"
				] }), /* @__PURE__ */ P("ul", {
					className: "gs-found__grid",
					children: n.slice(0, 12).map(l)
				})]
			}),
			e.waiting && r !== null && /* @__PURE__ */ F("p", {
				className: "gs-found__countdown",
				role: "status",
				children: [
					t.length && e.ticked.length ? `Going on with the ${e.ticked.length} that line up in ${r} s.` : `Going on without them in ${r} s.`,
					" ",
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-link",
						onClick: () => i(null),
						children: "Let me choose"
					})
				]
			}),
			e.waiting && /* @__PURE__ */ F("div", {
				className: "gs-found__actions",
				children: [/* @__PURE__ */ F("button", {
					type: "button",
					className: "gs-button gs-button--primary",
					onClick: e.use,
					disabled: !t.length || !e.ticked.length,
					children: [
						"Use ",
						e.ticked.length,
						" ",
						e.ticked.length === 1 ? "picture" : "pictures",
						" and continue"
					]
				}), /* @__PURE__ */ P("button", {
					type: "button",
					className: "gs-button",
					onClick: e.skip,
					children: "Continue without them"
				})]
			})
		]
	});
}
var un = (e) => {
	let t = Math.max(0, Math.round(e));
	return t < 60 ? `${t}s` : `${Math.floor(t / 60)}:${String(t % 60).padStart(2, "0")}`;
};
function dn(e) {
	let t = (e) => {
		try {
			return new URL(e).hostname.replace(/^www\./, "");
		} catch {
			return "a page";
		}
	}, n = (e) => e.length > 60 ? `${e.slice(0, 60)}…` : e, r = /^(search|picture search|page|picture): (.*)$/.exec(e);
	if (!r) return `Looking it up: ${n(e)}`;
	let [, i, a] = r;
	return i === "search" ? a.startsWith("(") ? "Found before: no web requests needed" : `Searching the web for “${n(a)}”` : i === "picture search" ? `Searching for pictures of “${n(a)}”` : i === "page" ? `Reading a page on ${t(a)}` : `Checking a picture from ${t(a.split(" ")[0])}`;
}
var fn = (e) => e < 1.5 ? `${Math.round(e * 100)}% of a processor core` : `${e.toFixed(1).replace(/\.0$/, "")} processor cores busy`, pn = (e) => e.health ? e.health.now + (Date.now() - e.receivedAt) : Date.now(), mn = {
	slow: 25,
	stuck: 75
}, hn = {
	slow: 60,
	stuck: 180
}, gn = {
	slow: 120,
	stuck: 750
};
function _n({ watch: e }) {
	let [, t] = M(0);
	A(() => {
		let e = setInterval(() => t((e) => e + 1), 1e3);
		return () => clearInterval(e);
	}, []);
	let n = e.health, r = "ok", i;
	if (e.unanswered >= 2) r = "stuck", i = `The Gleamshelf app is not answering (${e.unanswered} tries). Is it still running? If it was closed, start it again with npm run local:start.`;
	else if (e.queued || !n) i = e.queued ? "Waiting for the app to finish another job first" : "Starting";
	else {
		let t = (pn(e) - n.lastActivity) / 1e3, a = n.models === "working" ? n.modelJob === "redraw" || n.modelJob === "enhance" ? gn : hn : mn, o = n.modelJob ? Sn[n.modelJob] ?? n.modelJob : "an AI model";
		t >= a.stuck ? (r = "stuck", i = n.models === "working" ? `Nothing has happened for ${un(t)}: ${o} looks stuck. Stop it and try again; if it happens again, restart the Gleamshelf app.` : `Nothing has happened for ${un(t)}: the run looks stuck. Stop it and try again; if it happens again, restart the Gleamshelf app.`) : t >= a.slow ? (r = "slow", i = `No sign of work for ${un(t)}${n.models === "working" ? ` (${o} may be thinking on the GPU)` : ""}. Still waiting.`) : i = n.models === "starting" ? "Loading the AI models into memory (the first run after a while can take a minute)" : n.models === "working" ? `${o[0].toUpperCase()}${o.slice(1)} is at work${n.cpu.models === null ? "" : ` · ${fn(n.cpu.models)}`}` : n.detail ? dn(n.detail) : n.cpu.app > .1 ? `Working on this computer · ${fn(n.cpu.app)}` : "Working";
	}
	return /* @__PURE__ */ F("div", {
		className: `gs-health gs-health--${r}`,
		role: "status",
		"aria-live": "polite",
		children: [
			/* @__PURE__ */ P("span", {
				className: "gs-health__dot",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ F("span", {
				className: "gs-health__text",
				children: [i, n && /* @__PURE__ */ F("span", {
					className: "gs-health__total",
					children: [
						" · ",
						un((pn(e) - n.startedAt) / 1e3),
						" in all"
					]
				})]
			}),
			/* @__PURE__ */ P("button", {
				type: "button",
				className: "gs-button gs-health__stop",
				onClick: e.stop,
				title: "Stop this run (nothing is changed)",
				children: "Stop"
			})
		]
	});
}
function vn(e) {
	return /not answering|stopped answering|fetch|network|ECONNREFUSED/i.test(e) ? "The Gleamshelf app on this computer is not running or was closed. Start it with npm run local:start, then try again." : /not installed|install/i.test(e) ? "A model it needs is missing: npm run models lists them and how to install each." : /took over|too long|timed? ?out/i.test(e) ? "The computer may have been busy with something else. Close other heavy apps and try again." : /model server|python/i.test(e) ? "The AI model process had a problem. Try again; if it keeps happening, restart the Gleamshelf app." : "Try again. If it keeps failing, restart the Gleamshelf app; the error above says what went wrong.";
}
function yn({ url: e }) {
	return /* @__PURE__ */ F("div", {
		className: "gs-promo",
		children: [
			/* @__PURE__ */ P("img", {
				src: e,
				alt: "The product on a studio backdrop with a reflection under it"
			}),
			/* @__PURE__ */ P("a", {
				href: e,
				download: "promo.jpg",
				children: "Save the promo picture"
			}),
			/* @__PURE__ */ P(K, { id: "promoPicture" })
		]
	});
}
var bn = [
	[
		"artwork",
		"Box art colours",
		"A soft blurred backdrop in the colours of the box art"
	],
	[
		"dark",
		"Dark spotlight",
		"Near-black, a spotlight from above and a floor reflection"
	],
	[
		"white",
		"White",
		"Plain white with a soft shadow"
	]
];
function xn({ clean: e }) {
	let [t, n] = M("artwork"), [r, i] = M(!1), [a, o] = M(null), [s, c] = M(null);
	A(() => () => void (s && URL.revokeObjectURL(s.url)), [s]);
	let l = async (n) => {
		i(!0), o(null);
		try {
			let r = await e.make(t, n);
			c({
				url: URL.createObjectURL(r),
				seed: n
			});
		} catch (e) {
			o(e instanceof Error ? e.message : "The clean product photo could not be made.");
		} finally {
			i(!1);
		}
	};
	return /* @__PURE__ */ F("div", {
		className: "gs-clean",
		children: [
			/* @__PURE__ */ P("h3", { children: "Clean product photo" }),
			e.ready ? /* @__PURE__ */ F(N, { children: [
				/* @__PURE__ */ P("div", {
					className: "gs-segmented",
					role: "group",
					"aria-label": "Backdrop",
					children: bn.map(([e, i, a]) => /* @__PURE__ */ P("button", {
						type: "button",
						className: `gs-button ${t === e ? "is-active" : ""}`,
						"aria-pressed": t === e,
						disabled: r,
						onClick: () => n(e),
						title: a,
						children: i
					}, e))
				}),
				/* @__PURE__ */ P("button", {
					type: "button",
					className: "gs-button gs-button--primary",
					disabled: r,
					onClick: () => void l(s ? s.seed + 12 : 11),
					children: r ? "Drawing… (2-3 minutes)" : s ? "Draw another take" : "Make a clean photo (about 2-3 minutes, free)"
				}),
				a && /* @__PURE__ */ P("p", {
					className: "gs-clean__error",
					role: "alert",
					children: a
				}),
				s && /* @__PURE__ */ F("div", {
					className: "gs-promo",
					children: [
						/* @__PURE__ */ P("img", {
							src: s.url,
							alt: "The figure alone on a studio backdrop, drawn from the photo by the local model"
						}),
						/* @__PURE__ */ P("p", {
							className: "gs-hint",
							children: "Drawn again by AI from your photo: check the face, colours and small parts against the real figure."
						}),
						/* @__PURE__ */ P("a", {
							href: s.url,
							download: "clean-photo.png",
							children: "Save the clean photo"
						})
					]
				})
			] }) : /* @__PURE__ */ F("p", {
				className: "gs-hint",
				children: [
					"The figure alone, with no lettering, logos or stickers, made on this computer. Set it up once (about 16 GB, free):",
					" ",
					/* @__PURE__ */ P("code", { children: e.setup })
				]
			}),
			/* @__PURE__ */ P(K, { id: "cleanPhoto" })
		]
	});
}
var Sn = {
	ask: "the vision model",
	figure: "SAM (finding the figure)",
	redraw: "Stable Diffusion",
	enhance: "Stable Diffusion",
	"clean-photo": "FLUX.2 klein (clean product photo)"
};
function Cn({ auto: e, listingSet: t, hasCutout: n }) {
	let r = {
		todo: "·",
		running: "…",
		done: "✓",
		skipped: "–"
	}, i = e.full, [a, o] = M(!1), s = j(null), c = i?.report;
	A(() => {
		c && s.current?.scrollIntoView({
			behavior: "smooth",
			block: "start"
		});
	}, [c]);
	let l = i?.report?.listing ? `${i.report.listing.title}\n\nCategory: ${i.report.listing.category}\nSeries: ${i.report.listing.series ?? "(not found)"}\n\n${i.report.listing.description}${i.report.listing.highlights.length ? `\n\n${i.report.listing.highlights.map((e) => `- ${e}`).join("\n")}` : ""}` : "";
	return /* @__PURE__ */ F("section", { children: [
		/* @__PURE__ */ P("h2", { children: "One click" }),
		/* @__PURE__ */ P("button", {
			type: "button",
			className: "gs-button gs-button--primary gs-auto__button",
			disabled: e.busy || !!i && !i.available,
			onClick: e.run,
			title: "Cut out, remove lettering, brighten and sharpen, enlarge, and finish as a white square photo",
			children: e.busy ? "Working…" : "Make it listing-ready"
		}),
		/* @__PURE__ */ P(K, { id: "autoRun" }),
		/* @__PURE__ */ F("div", {
			className: "gs-segmented",
			role: "group",
			"aria-label": "What to cut out",
			children: [
				/* @__PURE__ */ P("button", {
					type: "button",
					className: `gs-button ${e.mode === "product" ? "is-active" : ""}`,
					"aria-pressed": e.mode === "product",
					disabled: e.busy,
					onClick: () => e.setMode("product"),
					title: "Keep the whole box or product",
					children: "Whole box"
				}),
				/* @__PURE__ */ P("button", {
					type: "button",
					className: `gs-button ${e.mode === "character" ? "is-active" : ""}`,
					"aria-pressed": e.mode === "character",
					disabled: e.busy,
					onClick: () => e.setMode("character"),
					title: "Keep only the character in the artwork on the cover",
					children: "Character on cover"
				}),
				i && /* @__PURE__ */ P("button", {
					type: "button",
					className: `gs-button ${e.mode === "auto" ? "is-active" : ""}`,
					"aria-pressed": e.mode === "auto",
					disabled: e.busy,
					onClick: () => e.setMode("auto"),
					title: "The character for a flat front cover, the whole box for a box seen at an angle",
					children: "Auto"
				})
			]
		}),
		/* @__PURE__ */ P(K, { id: "autoMode" }),
		i && /* @__PURE__ */ F("details", {
			className: "gs-steps-box",
			children: [/* @__PURE__ */ F("summary", { children: [
				"Steps: ",
				i.steps.filter((e) => e.on && !e.disabled).length,
				" of ",
				i.steps.length,
				" on (untick to skip)"
			] }), /* @__PURE__ */ P("fieldset", {
				className: "gs-steps",
				disabled: e.busy,
				children: i.steps.map((t) => /* @__PURE__ */ F("label", {
					className: "gs-control gs-control--inline",
					title: t.title,
					children: [/* @__PURE__ */ P("input", {
						type: "checkbox",
						checked: t.on && !t.disabled,
						disabled: e.busy || t.disabled,
						onChange: (e) => i.setStep(t.key, e.target.checked)
					}), /* @__PURE__ */ F("span", { children: [t.label, /* @__PURE__ */ P(K, {
						id: `step.${t.key}`,
						inline: !0
					})] })]
				}, t.key))
			})]
		}),
		e.detail?.available && !i && /* @__PURE__ */ F("label", {
			className: "gs-control gs-control--inline",
			title: "Re-draws the picture slightly with Stable Diffusion, pinned to the original shapes, so hair, fabric and edges come back crisper. Free, on your computer, about a minute. Colours are kept.",
			children: [/* @__PURE__ */ P("input", {
				type: "checkbox",
				checked: e.detail.on,
				disabled: e.busy,
				onChange: (t) => e.detail.set(t.target.checked)
			}), "Extra detail (slower, about 1 more minute)"]
		}),
		e.gloss?.available && !i && /* @__PURE__ */ F("label", {
			className: "gs-control gs-control--inline",
			title: "Redraws the product as a glossy studio pack shot with Stable Diffusion, free, on your computer, about a minute. It changes the product itself: finish, small details and printed text may no longer match the real item.",
			children: [/* @__PURE__ */ P("input", {
				type: "checkbox",
				checked: e.gloss.on,
				disabled: e.busy,
				onChange: (t) => e.gloss.set(t.target.checked)
			}), "Studio gloss (changes the product; off unless ticked)"]
		}),
		/* @__PURE__ */ F("p", {
			className: "gs-hint",
			children: [i ? "Runs on this computer; the finished picture opens here. " : e.greenBackdrop ? "Green backdrop found: it is removed for free. " : e.appReady ? "" : "For anything but a green backdrop, start the Gleamshelf app first (see AI cut-out in the Cut out tab). ", !i && "Every step stays adjustable in the other tabs, and Undo steps back one at a time."]
		}),
		e.steps && /* @__PURE__ */ P("ul", {
			className: "gs-auto__steps",
			children: e.steps.map((t) => /* @__PURE__ */ F("li", {
				className: `is-${t.state}`,
				children: [
					/* @__PURE__ */ P("span", {
						"aria-hidden": "true",
						children: t.state === "running" && e.watch ? /* @__PURE__ */ P("span", { className: "gs-spin" }) : r[t.state]
					}),
					" ",
					t.label.charAt(0).toUpperCase() + t.label.slice(1),
					t.state === "done" && t.seconds !== void 0 && /* @__PURE__ */ P("span", {
						className: "gs-auto__time",
						children: un(t.seconds)
					}),
					t.state === "running" && e.watch?.health && t.startedAt !== void 0 && /* @__PURE__ */ P("span", {
						className: "gs-auto__time",
						children: un((pn(e.watch) - t.startedAt) / 1e3)
					}),
					t.note && /* @__PURE__ */ F("span", {
						className: "gs-hint",
						children: [" · ", t.note]
					})
				]
			}, t.label))
		}),
		i?.found && /* @__PURE__ */ P(ln, { found: i.found }),
		e.busy && e.watch && !i?.found?.waiting && /* @__PURE__ */ P(_n, { watch: e.watch }),
		!e.busy && e.end && /* @__PURE__ */ F("div", {
			className: `gs-runend gs-runend--${e.end.kind}`,
			role: e.end.kind === "failed" ? "alert" : "status",
			children: [
				/* @__PURE__ */ P("strong", { children: e.end.kind === "failed" ? "This run did not finish" : "Stopped" }),
				/* @__PURE__ */ P("p", { children: e.end.message.charAt(0).toUpperCase() + e.end.message.slice(1) }),
				e.end.kind === "failed" && !/npm run/.test(e.end.message) && /* @__PURE__ */ P("p", {
					className: "gs-hint",
					children: vn(e.end.message)
				}),
				/* @__PURE__ */ F("div", {
					className: "gs-runend__actions",
					children: [/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-button gs-button--primary",
						onClick: e.run,
						children: "Try again"
					}), e.dismissEnd && /* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-button",
						onClick: e.dismissEnd,
						children: "Dismiss"
					})]
				})
			]
		}),
		i?.report && /* @__PURE__ */ F("div", {
			className: "gs-auto__report",
			ref: s,
			children: [
				/* @__PURE__ */ P(K, { id: "autoReport" }),
				i.report.lookup && /* @__PURE__ */ P(on, { lookup: i.report.lookup }),
				i.report.promoUrl && /* @__PURE__ */ P(yn, { url: i.report.promoUrl }),
				i.cleanPhoto && /* @__PURE__ */ P(xn, { clean: i.cleanPhoto }, i.report.runId),
				(i.report.health || i.report.quality) && /* @__PURE__ */ P(nn, {
					health: i.report.health,
					quality: i.report.quality,
					changesUrl: i.report.changesUrl
				}),
				i.report.flags.length > 0 && /* @__PURE__ */ P("ul", {
					className: "gs-auto__flags",
					"aria-label": "Worth a look",
					children: i.report.flags.map((e) => /* @__PURE__ */ P("li", { children: e }, e))
				}),
				i.report.listing && /* @__PURE__ */ F("div", {
					className: "gs-listing",
					children: [
						/* @__PURE__ */ P("h3", { children: "Listing" }),
						/* @__PURE__ */ P("strong", {
							className: "gs-listing__title",
							children: i.report.listing.title
						}),
						/* @__PURE__ */ F("p", {
							className: "gs-hint",
							children: [i.report.listing.category, i.report.listing.series ? ` · ${i.report.listing.series}` : ""]
						}),
						/* @__PURE__ */ P("p", {
							className: "gs-listing__description",
							children: i.report.listing.description
						}),
						i.report.listing.highlights.length > 0 && /* @__PURE__ */ P("ul", {
							className: "gs-listing__highlights",
							children: i.report.listing.highlights.map((e) => /* @__PURE__ */ P("li", { children: e }, e))
						}),
						i.report.listing.unsupported.length > 0 && /* @__PURE__ */ F("p", {
							className: "gs-hint",
							children: ["Not found, add by hand: ", i.report.listing.unsupported.join("; ")]
						}),
						i.report.listing.unverifiedNumbers.length > 0 && /* @__PURE__ */ F("p", {
							className: "gs-hint gs-auto__flags",
							children: ["Check these numbers, no source gave them: ", i.report.listing.unverifiedNumbers.join(", ")]
						}),
						/* @__PURE__ */ P("button", {
							type: "button",
							className: "gs-button",
							onClick: () => void navigator.clipboard.writeText(`${i.report.listing.title}\n\n${l.split("\n\n").slice(1).join("\n\n")}`).then(() => o(!0), () => o(!1)),
							children: a ? "Copied" : "Copy title and description"
						})
					]
				}),
				t && /* @__PURE__ */ F("div", {
					className: "gs-listing",
					children: [/* @__PURE__ */ P("h3", { children: "Every marketplace" }), /* @__PURE__ */ P(an, {
						...t,
						hasCutout: n
					})]
				}),
				i.shop && i.report.runId && /* @__PURE__ */ P(tn, {
					shop: i.shop,
					runId: i.report.runId
				}),
				i.makeAd && /* @__PURE__ */ P($t, { make: i.makeAd }),
				i.make3d && /* @__PURE__ */ P(en, { make: i.make3d }),
				i.report.notes.length > 0 && /* @__PURE__ */ F("details", {
					className: "gs-auto__notes",
					children: [/* @__PURE__ */ F("summary", { children: [
						"What the run did (",
						i.report.notes.length,
						" notes)"
					] }), i.report.notes.map((e) => /* @__PURE__ */ P("p", {
						className: "gs-hint",
						children: e.charAt(0).toUpperCase() + e.slice(1)
					}, e))]
				})
			]
		}),
		i?.goBack && /* @__PURE__ */ P("button", {
			type: "button",
			className: "gs-button",
			onClick: i.goBack,
			title: "Close this picture and open the photo as it was",
			children: "Back to the original photo"
		}),
		i?.goBack && /* @__PURE__ */ P(K, { id: "autoBack" }),
		i?.recent && i.recent.runs.length > 0 && !e.busy && /* @__PURE__ */ F("details", {
			className: "gs-recent",
			children: [
				/* @__PURE__ */ F("summary", { children: [
					"Recent results (",
					i.recent.runs.length,
					")"
				] }),
				/* @__PURE__ */ P("ul", { children: i.recent.runs.map((e) => /* @__PURE__ */ P("li", { children: /* @__PURE__ */ F("button", {
					type: "button",
					onClick: () => i.recent.open(e.id),
					title: "Open this finished picture and its listing again, instantly",
					children: [
						e.thumb ? /* @__PURE__ */ P("img", {
							src: e.thumb,
							alt: ""
						}) : /* @__PURE__ */ P("span", { className: "gs-recent__blank" }),
						/* @__PURE__ */ P("span", {
							className: "gs-recent__title",
							children: e.title
						}),
						/* @__PURE__ */ F("span", {
							className: "gs-hint",
							children: [e.health === null ? "" : `${e.health}/100 · `, new Date(e.finishedAt).toLocaleString([], {
								month: "short",
								day: "numeric",
								hour: "2-digit",
								minute: "2-digit"
							})]
						})
					]
				}) }, e.id)) }),
				/* @__PURE__ */ P(K, { id: "recentRuns" })
			]
		})
	] });
}
//#endregion
//#region src/panel/StickerSection.tsx
function wn({ stickers: e }) {
	return /* @__PURE__ */ F("section", { children: [
		/* @__PURE__ */ P("h2", { children: "Price stickers and printed text" }),
		/* @__PURE__ */ P("button", {
			type: "button",
			className: "gs-button",
			disabled: e.busy,
			onClick: e.run,
			title: "Reads the prices on the photo and paints the shop's price stickers out. Free; needs the Gleamshelf app with the text finder, the text reader and the AI fill.",
			children: e.busy ? "Working…" : "Remove price stickers"
		}),
		/* @__PURE__ */ P("button", {
			type: "button",
			className: `gs-button ${e.picking && !e.pickingText ? "is-active" : ""}`,
			disabled: e.busy,
			onClick: () => e.setPicking(!(e.picking && !e.pickingText)),
			title: "If a sticker was missed, click it on the picture and it is painted out",
			children: e.picking && !e.pickingText ? "Cancel" : "Click a sticker"
		}),
		e.setPickingText && /* @__PURE__ */ P("button", {
			type: "button",
			className: `gs-button ${e.pickingText ? "is-active" : ""}`,
			disabled: e.busy,
			onClick: () => e.setPickingText(!e.pickingText),
			title: "For printed text the automatic search left, such as a big title: click one letter and every letter of that colour in the same text is painted out",
			children: e.pickingText ? "Cancel" : "Click printed text"
		}),
		/* @__PURE__ */ P(K, { id: "stickers" }),
		/* @__PURE__ */ P(K, { id: "stickerClick" }),
		e.setPickingText && /* @__PURE__ */ P(K, { id: "textClick" }),
		e.note && /* @__PURE__ */ P("p", {
			className: "gs-hint",
			children: e.note
		})
	] });
}
//#endregion
//#region src/panel/LetteringSection.tsx
var Tn = [
	{
		key: "lightness",
		label: "How white",
		min: 150,
		max: 255,
		step: 1,
		help: "Lower catches creamier lettering. Too low starts to catch light parts of the picture."
	},
	{
		key: "maxWidth",
		label: "Thickest stroke",
		min: 4,
		max: 80,
		step: 1,
		help: "Fatter white shapes (a bow, a pompom) are left alone."
	},
	{
		key: "minLength",
		label: "Shortest piece",
		min: 5,
		max: 200,
		step: 1,
		help: "Smaller white specks (a glint in an eye) are left alone."
	}
];
function En({ editor: e, doc: t, hasCutout: n, lettering: r, aiFill: i, onRemoveLettering: a }) {
	let o = t.recipe.words;
	return /* @__PURE__ */ F("section", { children: [/* @__PURE__ */ P("h2", { children: "Printed lettering" }), o ? /* @__PURE__ */ F(N, { children: [
		/* @__PURE__ */ F("div", {
			className: "gs-crop-tools",
			children: [/* @__PURE__ */ P("button", {
				type: "button",
				className: "gs-button",
				onClick: () => e.setWords(!1),
				children: "Put lettering back"
			}), /* @__PURE__ */ P("span", {
				className: "gs-hint",
				children: r?.busy ? "Working…" : r && r.filled === 0 ? "No lettering found: try a lower \"How white\"." : r?.filled === -1 ? "Filled with AI." : r?.aiReady ? "Free fill shown; AI fill is ready below." : "Soft free fill. For a clean result set up the AI fill below."
			})]
		}),
		/* @__PURE__ */ P(K, { id: "letteringSliders" }),
		Tn.map(({ key: t, label: n, min: r, max: i, step: a, help: s }) => /* @__PURE__ */ F("label", {
			className: "gs-control",
			title: s,
			children: [/* @__PURE__ */ F("span", {
				className: "gs-control__row",
				children: [/* @__PURE__ */ P("span", { children: n }), /* @__PURE__ */ P("output", { children: o[t] })]
			}), /* @__PURE__ */ P("input", {
				type: "range",
				style: Wt(o[t], r, i),
				min: r,
				max: i,
				step: a,
				value: o[t],
				onPointerDown: () => e.begin(`Lettering: ${n}`),
				onPointerUp: () => e.commit(),
				onLostPointerCapture: () => e.commit(),
				onChange: (r) => e.setWordsParam(t, Number(r.target.value), `Lettering: ${n}`)
			})]
		}, t)),
		i
	] }) : /* @__PURE__ */ F(N, { children: [
		/* @__PURE__ */ P("button", {
			type: "button",
			className: "gs-button",
			onClick: () => a ? a() : e.setWords(!0),
			title: "Paints over white lettering, such as a title written across the picture",
			children: "Remove white lettering"
		}),
		/* @__PURE__ */ P(K, { id: "lettering" }),
		/* @__PURE__ */ F("p", {
			className: "gs-hint",
			children: [
				"Free. ",
				n ? "Only the cut-out is touched." : "With no cut-out, the whole picture is searched.",
				i && " Cleanest with the AI fill, offered once this is on."
			]
		})
	] })] });
}
//#endregion
//#region src/panel/Controls.tsx
var Dn = {
	free: "Free",
	original: "Original",
	"1:1": "Square 1:1",
	"4:5": "Portrait 4:5",
	"3:4": "Portrait 3:4",
	"2:3": "Portrait 2:3",
	"16:9": "Wide 16:9"
};
function On(e, t) {
	let n = t.step < .1 ? 2 : +(t.step < 1);
	return `${e > 0 && t.min < 0 ? "+" : ""}${e.toFixed(n)}${t.unit ?? ""}`;
}
function kn({ editor: e, path: t, spec: n, value: r }) {
	return /* @__PURE__ */ F("label", {
		className: "gs-control",
		children: [/* @__PURE__ */ F("span", {
			className: "gs-control__row",
			children: [/* @__PURE__ */ P("span", { children: n.label }), /* @__PURE__ */ P("output", {
				className: r === n.default ? "" : "is-changed",
				children: On(r, n)
			})]
		}), /* @__PURE__ */ P("input", {
			type: "range",
			style: Wt(r, n.min, n.max),
			min: n.min,
			max: n.max,
			step: n.step,
			value: r,
			onPointerDown: () => e.begin(n.label),
			onPointerUp: () => e.commit(),
			onLostPointerCapture: () => e.commit(),
			onChange: (n) => e.set(t, Number(n.target.value)),
			onDoubleClick: () => e.set(t, n.default, `Reset ${n.label}`)
		})]
	});
}
function An({ editor: e, type: t, name: n, spec: r, value: i }) {
	let a = `recipe/ops/${t}/${n}`;
	if (r.kind === "number") return /* @__PURE__ */ P(kn, {
		editor: e,
		path: a,
		spec: r,
		value: typeof i == "number" ? i : r.default
	});
	if (r.kind === "boolean") return /* @__PURE__ */ F("label", {
		className: "gs-control gs-control--inline",
		children: [/* @__PURE__ */ P("input", {
			type: "checkbox",
			checked: i === !0,
			onChange: (t) => e.set(a, t.target.checked)
		}), r.label]
	});
	if (r.kind === "color") {
		let t = typeof i == "string" ? i : r.default;
		return /* @__PURE__ */ F("label", {
			className: "gs-control gs-control--inline",
			children: [/* @__PURE__ */ P("input", {
				type: "color",
				value: t,
				"aria-label": r.label,
				onChange: (t) => e.set(a, t.target.value, r.label)
			}), r.label]
		});
	}
	return null;
}
//#endregion
//#region src/panel/GroundEffects.tsx
var jn = [
	{
		id: "drop-shadow",
		label: "Soft shadow",
		title: "A soft shadow cast behind and under the product"
	},
	{
		id: "contact-shadow",
		label: "Contact shadow",
		title: "The dark line where the product meets the floor, so it stands instead of floating"
	},
	{
		id: "reflection",
		label: "Reflection",
		title: "The product mirrored on a glossy surface under it"
	}
];
function Mn({ editor: e }) {
	let t = (t) => e.effects.findIndex((e) => e.id === t);
	return /* @__PURE__ */ F("div", {
		className: "gs-control",
		children: [/* @__PURE__ */ P("div", {
			className: "gs-segmented gs-segmented--wrap",
			role: "group",
			"aria-label": "Shadow and reflection",
			children: jn.map(({ id: n, label: r, title: i }) => {
				let o = t(n);
				return /* @__PURE__ */ P("button", {
					type: "button",
					className: `gs-button ${o >= 0 ? "is-active" : ""}`,
					"aria-pressed": o >= 0,
					title: i,
					onClick: () => {
						if (o >= 0) e.removeEffect(o, `Remove ${r.toLowerCase()}`);
						else {
							let t = O(n);
							t && e.addEffect(n, ce(t), `Add ${r.toLowerCase()}`), n === "reflection" && a(e.document.recipe, "canvas", "square") && l(e.document.recipe, "canvas", "margin") < 14 && e.set("recipe/ops/canvas/margin", 14, "Room for the reflection");
						}
					},
					children: r
				}, n);
			})
		}), /* @__PURE__ */ P(K, { id: "ground" })]
	});
}
//#endregion
//#region src/panel/BackdropSection.tsx
var Nn = [
	{
		mode: "transparent",
		label: "None",
		title: "Keep the cut-out transparent (saves as PNG or WebP)"
	},
	{
		mode: "color",
		label: "Colour",
		title: "A flat colour behind the product"
	},
	{
		mode: "image",
		label: "Photo",
		title: "Your own background photo"
	}
];
function Pn({ editor: e, doc: t, onFitProduct: n, onStudio: r, listingSet: o, onBackgroundPhoto: s, hasBackgroundPhoto: l, backgroundName: u }) {
	let d = i(t.recipe, "backdrop", "mode"), f = i(t.recipe, "backdrop", "color") || "#ffffff", p = t.recipe.mask.length > 0, m = a(t.recipe, "canvas", "square");
	return /* @__PURE__ */ F("section", { children: [
		/* @__PURE__ */ P("h2", { children: "Behind the product" }),
		r && /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("button", {
			type: "button",
			className: "gs-button gs-button--primary",
			disabled: !p,
			onClick: r,
			title: p ? "White background, the product centred on a square, and a soft shadow" : "Cut the product out first",
			children: "Studio photo: white and square"
		}), /* @__PURE__ */ P(K, { id: "studio" })] }),
		p && /* @__PURE__ */ P(Mn, { editor: e }),
		o && /* @__PURE__ */ P(an, {
			...o,
			hasCutout: p
		}),
		/* @__PURE__ */ P(K, { id: "backdrop" }),
		/* @__PURE__ */ P("div", {
			className: "gs-segmented",
			role: "group",
			"aria-label": "What is behind the product",
			children: Nn.map(({ mode: t, label: n, title: r }) => /* @__PURE__ */ P("button", {
				type: "button",
				className: `gs-button ${d === t ? "is-active" : ""}`,
				"aria-pressed": d === t,
				title: r,
				onClick: () => e.set("recipe/ops/backdrop/mode", t, `Backdrop: ${n}`),
				children: n
			}, t))
		}),
		d === "color" && /* @__PURE__ */ F("label", {
			className: "gs-control gs-control--inline",
			children: [/* @__PURE__ */ P("input", {
				type: "color",
				value: f,
				"aria-label": "Backdrop colour",
				onChange: (t) => e.set("recipe/ops/backdrop/color", t.target.value, "Backdrop colour")
			}), f]
		}),
		d === "image" && /* @__PURE__ */ F("div", {
			className: "gs-control",
			children: [/* @__PURE__ */ F("label", {
				className: "gs-button gs-file",
				children: [l ? "Choose another photo" : "Choose background photo", /* @__PURE__ */ P("input", {
					type: "file",
					accept: "image/*,.heic,.heif",
					onChange: (e) => {
						let t = e.target.files?.[0];
						e.target.value = "", t && s(t);
					}
				})]
			}), /* @__PURE__ */ P("span", {
				className: "gs-hint",
				children: l ? u ?? "Background photo" : "The photo fills the whole picture behind the product."
			})]
		}),
		d !== "transparent" && !p && /* @__PURE__ */ P("p", {
			className: "gs-hint",
			children: "Cut the product out above first, or the photo will cover it."
		}),
		/* @__PURE__ */ F("div", {
			className: "gs-control",
			children: [
				/* @__PURE__ */ P("span", {
					className: "gs-control__row",
					children: /* @__PURE__ */ P("span", { children: "Square picture" })
				}),
				/* @__PURE__ */ F("div", {
					className: "gs-crop-tools",
					children: [/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-button",
						disabled: !p,
						onClick: n,
						title: p ? "Crop to the product and centre it on a square, with space around it" : "Cut the product out first",
						children: "Fit square to product"
					}), /* @__PURE__ */ F("label", {
						className: "gs-control gs-control--inline",
						children: [/* @__PURE__ */ P("input", {
							type: "checkbox",
							checked: m,
							onChange: (t) => e.set("recipe/ops/canvas/square", t.target.checked, "Square canvas")
						}), "Square"]
					})]
				}),
				/* @__PURE__ */ P(K, { id: "square" })
			]
		}),
		m && /* @__PURE__ */ P(An, {
			editor: e,
			type: "canvas",
			name: "margin",
			spec: c("canvas", "margin"),
			value: t.recipe.ops.canvas?.margin
		})
	] });
}
//#endregion
//#region src/Panel.tsx
var Fn = [
	{
		id: "quick",
		label: "One click",
		icon: "spark",
		title: "Make it listing-ready in one click"
	},
	{
		id: "cutout",
		label: "Cut out",
		icon: "scissors",
		title: "Take the background away, and choose what goes behind the product"
	},
	{
		id: "clean",
		label: "Clean up",
		icon: "brush",
		title: "Price stickers, printed lettering, finishing touches"
	},
	{
		id: "adjust",
		label: "Adjust",
		icon: "sliders",
		title: "Rotate and crop, look, light, colour, effects"
	}
], In = {
	light: "light",
	color: "color",
	recolour: "recolour"
};
function Ln(e) {
	let n = !!e.handToolsOnly && !e.appReady, r = n ? {
		...e,
		auto: void 0,
		stickers: void 0,
		onAutoEnhance: void 0
	} : e, { editor: a, doc: o, cropping: s, onToggleCrop: l, autoEnhance: u, onAutoEnhance: d, aiEnlarge: f } = r, p = i(o.recipe, "crop", "aspect"), m = Fn.filter((e) => e.id !== "quick" || r.auto || n), [h, g] = M(n ? "cutout" : m[0].id), _ = j(!1), y = (e) => {
		_.current = !0, g(e);
	}, b = !!r.auto;
	return A(() => {
		b && !_.current && g("quick");
	}, [b]), A(() => {
		s && g("adjust");
	}, [s]), /* @__PURE__ */ F("div", {
		className: "gs-panel",
		children: [
			/* @__PURE__ */ P("nav", {
				className: "gs-tabs",
				role: "tablist",
				"aria-label": "Tools",
				children: m.map((e) => /* @__PURE__ */ F("button", {
					type: "button",
					role: "tab",
					"aria-selected": h === e.id,
					className: `gs-tab ${h === e.id ? "is-active" : ""}`,
					title: e.title,
					onClick: () => y(e.id),
					children: [
						/* @__PURE__ */ P(Kt, { name: e.icon }),
						/* @__PURE__ */ P("span", { children: e.label }),
						e.id === "quick" && r.auto?.busy && /* @__PURE__ */ P("span", {
							className: "gs-tab__live",
							"aria-label": "running"
						})
					]
				}, e.id))
			}),
			/* @__PURE__ */ F("div", {
				className: "gs-tabpanel",
				role: "tabpanel",
				children: [
					h === "quick" && n && /* @__PURE__ */ F("section", { children: [/* @__PURE__ */ P("h2", { children: "One click" }), r.appNotice?.("One click (cut-out, clean-up, listing text and a price from real listings)")] }),
					h === "quick" && r.auto && /* @__PURE__ */ P(Cn, {
						auto: r.auto,
						listingSet: r.listingSet,
						hasCutout: r.doc.recipe.mask.length > 0
					}),
					h === "cutout" && /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P(Xt, { ...r }), /* @__PURE__ */ P(Pn, { ...r })] }),
					h === "clean" && /* @__PURE__ */ F(N, { children: [
						r.stickers && /* @__PURE__ */ P(wn, { stickers: r.stickers }),
						n && /* @__PURE__ */ F("section", { children: [/* @__PURE__ */ P("h2", { children: "Price stickers and printed text" }), r.appNotice?.("Removing price stickers")] }),
						/* @__PURE__ */ P(En, { ...r }),
						r.aiFinish && /* @__PURE__ */ F("section", { children: [/* @__PURE__ */ P("h2", { children: "Finishing touches" }), r.aiFinish] })
					] }),
					h === "adjust" && /* @__PURE__ */ F(N, { children: [
						/* @__PURE__ */ F("section", { children: [
							/* @__PURE__ */ P("h2", { children: "Geometry" }),
							/* @__PURE__ */ F("div", {
								className: "gs-button-row",
								children: [
									/* @__PURE__ */ P("button", {
										type: "button",
										className: "gs-button",
										onClick: () => a.rotate(-1),
										title: "Rotate left",
										children: "⟲ Left"
									}),
									/* @__PURE__ */ P("button", {
										type: "button",
										className: "gs-button",
										onClick: () => a.rotate(1),
										title: "Rotate right",
										children: "⟳ Right"
									}),
									/* @__PURE__ */ P("button", {
										type: "button",
										className: "gs-button",
										onClick: () => a.flip("horizontal"),
										children: "Flip ↔"
									}),
									/* @__PURE__ */ P("button", {
										type: "button",
										className: "gs-button",
										onClick: () => a.flip("vertical"),
										children: "Flip ↕"
									})
								]
							}),
							/* @__PURE__ */ P(K, { id: "rotate" }),
							/* @__PURE__ */ F("div", {
								className: "gs-control",
								children: [
									/* @__PURE__ */ P("span", {
										className: "gs-control__row",
										children: /* @__PURE__ */ P("span", { children: "Crop" })
									}),
									/* @__PURE__ */ F("div", {
										className: "gs-crop-tools",
										children: [/* @__PURE__ */ P("button", {
											type: "button",
											className: `gs-button ${s ? "gs-button--primary" : ""}`,
											onClick: l,
											title: "Crop (C)",
											children: s ? "Done" : "Crop"
										}), /* @__PURE__ */ P("select", {
											"aria-label": "Aspect ratio",
											value: p,
											onChange: (e) => {
												a.setCropAspect(e.target.value), e.currentTarget.blur();
											},
											children: S.map((e) => /* @__PURE__ */ P("option", {
												value: e,
												children: Dn[e]
											}, e))
										})]
									}),
									/* @__PURE__ */ P(K, { id: "crop" })
								]
							}),
							/* @__PURE__ */ P(An, {
								editor: a,
								type: "straighten",
								name: "angle",
								spec: c("straighten", "angle"),
								value: o.recipe.ops.straighten?.angle
							}),
							/* @__PURE__ */ P(K, { id: "straighten" })
						] }),
						/* @__PURE__ */ F("section", { children: [
							/* @__PURE__ */ P("h2", { children: "Look" }),
							/* @__PURE__ */ F("div", {
								className: "gs-segmented",
								role: "group",
								"aria-label": "Look",
								children: [/* @__PURE__ */ P("button", {
									type: "button",
									className: "gs-button",
									title: "Back to the photo's own light and colour",
									onClick: () => a.clearLook(),
									children: "Natural"
								}), v.map((e) => /* @__PURE__ */ P("button", {
									type: "button",
									className: "gs-button",
									title: e.description,
									onClick: () => a.applyLook(e.id),
									children: e.label
								}, e.id))]
							}),
							/* @__PURE__ */ P(K, { id: "looks" }),
							d && /* @__PURE__ */ F("label", {
								className: "gs-control gs-control--inline",
								title: "After an AI cut-out or fill, apply the Bright & sharp look, unless you have already set your own",
								children: [/* @__PURE__ */ P("input", {
									type: "checkbox",
									checked: !!u,
									onChange: (e) => d(e.target.checked)
								}), "Brighter and sharper after an AI step"]
							}),
							d && /* @__PURE__ */ P(K, { id: "autoLook" }),
							f
						] }),
						t.filter((e) => e.group !== "geometry" && Object.values(e.params).some((e) => !e.hidden)).map((e) => /* @__PURE__ */ F("section", { children: [
							/* @__PURE__ */ P("h2", { children: e.label }),
							In[e.type] && /* @__PURE__ */ P(K, { id: In[e.type] }),
							Object.entries(e.params).filter(([t, n]) => !n.hidden && (t === "on" || !("on" in e.params) || o.recipe.ops[e.type]?.on === !0)).map(([t, n]) => /* @__PURE__ */ P(An, {
								editor: a,
								type: e.type,
								name: t,
								spec: n,
								value: o.recipe.ops[e.type]?.[t]
							}, t)),
							e.hint && /* @__PURE__ */ P("p", {
								className: "gs-hint",
								children: e.hint
							})
						] }, e.type)),
						/* @__PURE__ */ P(K, { id: "effects" }),
						/* @__PURE__ */ P(G, {
							title: "Effects",
							empty: "Add a look from the shaders folder: sharpen, shadow, glow, grain and more.",
							steps: o.recipe.effects,
							catalog: E(),
							known: O,
							onAdd: (e) => a.addEffect(e.id, ce(e), `Add ${e.name}`),
							onRemove: (e) => a.removeEffect(e),
							onMove: (e, t) => a.moveEffect(e, t),
							onParam: (e, t, n, r) => a.setEffectParam(e, t, n, r),
							onBegin: (e) => a.begin(e),
							onCommit: () => a.commit()
						})
					] })
				]
			}, h),
			/* @__PURE__ */ F("footer", {
				className: "gs-panel__foot",
				children: [r.onOpenGuide && /* @__PURE__ */ P("button", {
					type: "button",
					className: "gs-link",
					onClick: r.onOpenGuide,
					children: "Guide to every feature"
				}), /* @__PURE__ */ P(Ht, {})]
			})
		]
	});
}
//#endregion
//#region src/PhoneCapture.tsx
function Rn({ client: e, onOpen: t, onClose: n }) {
	let [r, i] = M(null), [a, o] = M(null), [s, c] = M([]), l = j(/* @__PURE__ */ new Map()), u = j(!1);
	A(() => {
		let t = !1;
		return e.phoneStart().then((e) => !t && i({
			url: e.url,
			qr: `data:image/svg+xml;charset=utf-8,${encodeURIComponent(e.qrSvg)}`
		})).catch((e) => !t && o(e instanceof Error ? e.message : "Phone capture could not start.")), () => {
			t = !0;
		};
	}, [e]), A(() => {
		if (!r) return;
		let t = !1, n = async () => {
			try {
				let n = await e.phonePhotos();
				for (let t of n.slice(0, 12)) if (!l.current.has(t.id) && !/\.hei[cf]$/i.test(t.name)) {
					l.current.set(t.id, "");
					let n = await e.phonePhoto(t.id);
					l.current.set(t.id, URL.createObjectURL(n));
				}
				t || c(n.map((e) => ({
					...e,
					thumb: l.current.get(e.id) || void 0
				})));
			} catch {}
		};
		n();
		let i = setInterval(() => void n(), 1500);
		return () => {
			t = !0, clearInterval(i);
		};
	}, [e, r]), A(() => () => l.current.forEach((e) => e && URL.revokeObjectURL(e)), []), A(() => {
		let e = (e) => {
			e.key === "Escape" && (e.stopPropagation(), n());
		};
		return window.addEventListener("keydown", e, !0), () => window.removeEventListener("keydown", e, !0);
	}, [n]);
	let d = async (n) => {
		if (!u.current) {
			u.current = !0;
			try {
				t(await e.phonePhoto(n.id), n.name);
			} catch (e) {
				o(e instanceof Error ? e.message : "That photo could not be opened.");
			} finally {
				u.current = !1;
			}
		}
	};
	return /* @__PURE__ */ P("div", {
		className: "gs-guide",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Photos from your phone",
		onClick: n,
		children: /* @__PURE__ */ F("div", {
			className: "gs-guide__sheet gs-phone",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ F("header", {
				className: "gs-guide__head",
				children: [/* @__PURE__ */ P("h2", { children: "Photos from your phone" }), /* @__PURE__ */ P("button", {
					type: "button",
					className: "gs-icon-button",
					onClick: n,
					"aria-label": "Close",
					children: /* @__PURE__ */ P(Kt, { name: "close" })
				})]
			}), /* @__PURE__ */ F("div", {
				className: "gs-phone__body",
				children: [/* @__PURE__ */ F("div", {
					className: "gs-phone__qr",
					children: [
						r ? /* @__PURE__ */ P("img", {
							src: r.qr,
							alt: "QR code to scan with your phone",
							width: 220,
							height: 220
						}) : /* @__PURE__ */ P("div", {
							className: "gs-phone__wait",
							children: a ?? "Starting…"
						}),
						/* @__PURE__ */ P(K, { id: "phone" }),
						/* @__PURE__ */ F("details", {
							className: "gs-phone__trouble",
							children: [/* @__PURE__ */ P("summary", { children: "Phone cannot open the page?" }), /* @__PURE__ */ F("ul", { children: [
								/* @__PURE__ */ P("li", { children: "The phone and this computer must be on the same Wi-Fi. Guest networks usually keep devices apart: use the main one." }),
								/* @__PURE__ */ P("li", { children: "On a Mac, if it asked whether to accept incoming connections for “node”, choose Allow (System Settings › Network › Firewall)." }),
								/* @__PURE__ */ F("li", { children: ["If the camera will not read the code, type this address into the phone’s browser:", r && /* @__PURE__ */ P("code", {
									className: "gs-phone__url",
									children: r.url
								})] })
							] })]
						})
					]
				}), /* @__PURE__ */ F("div", {
					className: "gs-phone__list",
					children: [
						/* @__PURE__ */ F("h3", { children: ["Arrived ", s.length ? `(${s.length})` : ""] }),
						!s.length && /* @__PURE__ */ P("p", {
							className: "gs-hint",
							children: "Photos you take or pick on the phone appear here as they arrive."
						}),
						/* @__PURE__ */ P("ul", { children: s.map((e) => /* @__PURE__ */ P("li", { children: /* @__PURE__ */ F("button", {
							type: "button",
							onClick: () => void d(e),
							title: `Open ${e.name} here`,
							children: [e.thumb ? /* @__PURE__ */ P("img", {
								src: e.thumb,
								alt: ""
							}) : /* @__PURE__ */ P("span", {
								className: "gs-phone__name",
								children: e.name
							}), /* @__PURE__ */ P("span", {
								className: "gs-phone__when",
								children: new Date(e.at).toLocaleTimeString([], {
									hour: "2-digit",
									minute: "2-digit"
								})
							})]
						}) }, e.id)) }),
						a && r && /* @__PURE__ */ P("p", {
							className: "gs-hint",
							children: a
						})
					]
				})]
			})]
		})
	});
}
//#endregion
//#region ../pipeline/src/image.ts
var zn = (e, t, n = [
	0,
	0,
	0,
	0
]) => {
	let r = new Uint8ClampedArray(e * t * 4);
	if (n.some((e) => e !== 0)) for (let e = 0; e < r.length; e += 4) r.set(n, e);
	return {
		width: e,
		height: t,
		data: r
	};
}, Bn = (e) => ({
	width: e.width,
	height: e.height,
	data: new Uint8ClampedArray(e.data)
});
//#endregion
//#region ../pipeline/src/flatten.ts
function Vn(e, t) {
	let n = e.reduce((e, t) => e + t.x, 0) / 4, r = e.reduce((e, t) => e + t.y, 0) / 4;
	return e.map((e) => ({
		x: e.x + (n - e.x) * t,
		y: e.y + (r - e.y) * t
	}));
}
function Hn(e, t, n) {
	let r = e.map((e) => ({
		x: e.x * t,
		y: e.y * n
	})), i = (e, t) => Math.hypot(e.x - t.x, e.y - t.y);
	return (i(r[0], r[1]) + i(r[3], r[2])) / 2 / ((i(r[0], r[3]) + i(r[1], r[2])) / 2);
}
function Un(e) {
	let [t, n, r, i] = e, a = n.x - r.x, o = i.x - r.x, s = t.x - n.x + r.x - i.x, c = n.y - r.y, l = i.y - r.y, u = t.y - n.y + r.y - i.y, d = 0, f = 0;
	if (Math.abs(s) > 1e-9 || Math.abs(u) > 1e-9) {
		let e = a * l - o * c;
		d = (s * l - o * u) / e, f = (a * u - s * c) / e;
	}
	return {
		a: n.x - t.x + d * n.x,
		b: i.x - t.x + f * i.x,
		c: t.x,
		d: n.y - t.y + d * n.y,
		e: i.y - t.y + f * i.y,
		f: t.y,
		g: d,
		h: f
	};
}
function Wn(e, t, n, r) {
	let i = Un(t.map((t) => ({
		x: t.x * e.width,
		y: t.y * e.height
	}))), a = zn(n, r), { width: o, height: s, data: c } = e;
	for (let e = 0; e < r; e++) for (let t = 0; t < n; t++) {
		let l = (t + .5) / n, u = (e + .5) / r, d = i.g * l + i.h * u + 1, f = (i.a * l + i.b * u + i.c) / d - .5, p = (i.d * l + i.e * u + i.f) / d - .5, m = Math.max(0, Math.min(o - 2, Math.floor(f))), h = Math.max(0, Math.min(s - 2, Math.floor(p))), g = Math.max(0, Math.min(1, f - m)), _ = Math.max(0, Math.min(1, p - h)), v = (e * n + t) * 4;
		for (let e = 0; e < 4; e++) {
			let t = (t, n) => c[(n * o + t) * 4 + e];
			a.data[v + e] = (t(m, h) * (1 - g) + t(m + 1, h) * g) * (1 - _) + (t(m, h + 1) * (1 - g) + t(m + 1, h + 1) * g) * _;
		}
	}
	return a;
}
var Gn = (e, t, n) => (t.x - e.x) * (n.y - e.y) - (t.y - e.y) * (n.x - e.x), Kn = (e) => {
	let t = 0;
	for (let n = 0; n < e.length; n++) {
		let r = e[n], i = e[(n + 1) % e.length];
		t += r.x * i.y - i.x * r.y;
	}
	return Math.abs(t) / 2;
};
function qn(e, t, n) {
	let r = [];
	for (let i = 0; i < n; i++) {
		let n = -1, a = -1;
		for (let r = 0; r < t; r++) e[i * t + r] >= 128 && (n < 0 && (n = r), a = r);
		n >= 0 && r.push({
			x: n,
			y: i
		}, {
			x: a + 1,
			y: i
		}, {
			x: n,
			y: i + 1
		}, {
			x: a + 1,
			y: i + 1
		});
	}
	if (r.length < 3) return r;
	r.sort((e, t) => e.x - t.x || e.y - t.y);
	let i = [];
	for (let e of r) {
		for (; i.length >= 2 && Gn(i[i.length - 2], i[i.length - 1], e) <= 0;) i.pop();
		i.push(e);
	}
	let a = [];
	for (let e = r.length - 1; e >= 0; e--) {
		let t = r[e];
		for (; a.length >= 2 && Gn(a[a.length - 2], a[a.length - 1], t) <= 0;) a.pop();
		a.push(t);
	}
	return [...i.slice(0, -1), ...a.slice(0, -1)];
}
function Jn(e, t, n) {
	let r = qn(e, t, n);
	if (r.length < 4) return null;
	let i = r.length, a = (e) => r.reduce((t, n, i) => e(n) > e(r[t]) ? i : t, 0), o = [
		a((e) => -e.x - e.y),
		a((e) => e.x - e.y),
		a((e) => e.x + e.y),
		a((e) => -e.x + e.y)
	], s = (e) => Kn(e.map((e) => r[e]));
	for (let e = 0; e < 50; e++) {
		let e = !1;
		for (let t = 0; t < 4; t++) for (let n of [1, -1]) for (;;) {
			let r = [...o];
			if (r[t] = (o[t] + n + i) % i, r[t] === o[(t + 1) % 4] || r[t] === o[(t + 3) % 4] || s(r) <= s(o) + 1e-9) break;
			o[t] = r[t], e = !0;
		}
		if (!e) break;
	}
	let c = o.map((e) => r[e]), l = c.reduce((e, t) => e + t.x, 0) / 4, u = c.reduce((e, t) => e + t.y, 0) / 4;
	c.sort((e, t) => Math.atan2(e.y - u, e.x - l) - Math.atan2(t.y - u, t.x - l));
	let d = c.reduce((e, t, n) => t.x + t.y < c[e].x + c[e].y ? n : e, 0), f = [...c.slice(d), ...c.slice(0, d)], p = 0, m = 0, h = 0, g = (e, t) => {
		for (let n = 0; n < 4; n++) if (Gn(f[n], f[(n + 1) % 4], {
			x: e,
			y: t
		}) < 0) return !1;
		return !0;
	}, _ = Math.max(1, Math.floor(Math.max(t, n) / 300));
	for (let r = 0; r < n; r += _) for (let n = 0; n < t; n += _) {
		let i = e[r * t + n] >= 128, a = g(n + .5, r + .5);
		i && p++, a && m++, i && a && h++;
	}
	let v = p ? h / p : 0, y = m ? h / m : 0;
	return {
		quad: f.map((e) => ({
			x: e.x / t,
			y: e.y / n
		})),
		covers: v,
		fills: y,
		flat: v > .97 && y > .95
	};
}
function Yn(e, t, n, r) {
	let i = Jn(t, n, r);
	if (!i || !i.flat) return null;
	let a = Hn(i.quad, e.width, e.height), o = i.quad.map((t) => ({
		x: t.x * e.width,
		y: t.y * e.height
	})), s = (e, t) => Math.hypot(e.x - t.x, e.y - t.y), c = Math.max(s(o[0], o[1]), s(o[3], o[2]), s(o[0], o[3]), s(o[1], o[2])), l = Math.max(8, Math.round(a >= 1 ? c : c * a)), u = Math.max(8, Math.round(a >= 1 ? c / a : c)), d = Wn(e, Vn(i.quad, .004), l, u);
	for (let e = 3; e < d.data.length; e += 4) d.data[e] = 255;
	return {
		image: d,
		quad: i.quad
	};
}
//#endregion
//#region ../pipeline/src/inpaint.ts
function Xn(e, t, n, r = 0, i = r) {
	let a = new Uint8Array(e * t);
	for (let o of n) {
		let n = Math.max(0, Math.floor((o.x - r) * e)), s = Math.max(0, Math.floor((o.y - i) * t)), c = Math.min(e, Math.ceil((o.x + o.width + r) * e)), l = Math.min(t, Math.ceil((o.y + o.height + i) * t));
		for (let t = s; t < l; t++) for (let r = n; r < c; r++) a[t * e + r] = 1;
	}
	return a;
}
function Zn(e, t, n, r) {
	let i = new Uint8Array(e.length);
	for (let t = 0; t < e.length; t++) e[t] && (i[t] = 1);
	let a = (e, t, n) => {
		let a = new Uint8Array(t);
		for (let o = 0; o < e; o++) {
			for (let e = 0; e < t; e++) a[e] = i[n(o, e)];
			let e = -1;
			for (let s = 0; s < t; s++) a[s] && (e = s + r), s <= e && (i[n(o, s)] = 1);
			e = t;
			for (let s = t - 1; s >= 0; s--) a[s] && (e = s - r), s >= e && (i[n(o, s)] = 1);
		}
	};
	return a(n, t, (e, n) => e * t + n), a(t, n, (e, n) => n * t + e), i;
}
var Qn = (...e) => {
	let t = new Uint8Array(e[0].length);
	for (let n of e) for (let e = 0; e < t.length; e++) n[e] && (t[e] = 1);
	return t;
};
function $n(e, t) {
	let { width: n, height: r, data: i } = e, a = null, o = 0, s = 0;
	for (let e of [
		8,
		4,
		2,
		1
	]) {
		let c = Math.max(2, Math.floor(n / e)), l = Math.max(2, Math.floor(r / e)), u = new Float32Array(c * l * 3), d = new Uint8Array(c * l);
		for (let e = 0; e < l; e++) for (let f = 0; f < c; f++) {
			let p = Math.floor(f * n / c), m = Math.floor(e * r / l), h = Math.max(p + 1, Math.floor((f + 1) * n / c)), g = Math.max(m + 1, Math.floor((e + 1) * r / l)), _ = 0, v = 0, y = 0, b = 0, x = 0;
			for (let e = m; e < g; e++) for (let r = p; r < h; r++) if (v++, !t[e * n + r]) {
				_++;
				let t = (e * n + r) * 4;
				y += i[t], b += i[t + 1], x += i[t + 2];
			}
			let S = e * c + f;
			if (_ === v) u[S * 3] = y / _, u[S * 3 + 1] = b / _, u[S * 3 + 2] = x / _;
			else if (d[S] = 1, a) {
				let t = (Math.min(s - 1, Math.floor(e * s / l)) * o + Math.min(o - 1, Math.floor(f * o / c))) * 3;
				u[S * 3] = a[t], u[S * 3 + 1] = a[t + 1], u[S * 3 + 2] = a[t + 2];
			} else _ ? (u[S * 3] = y / _, u[S * 3 + 1] = b / _, u[S * 3 + 2] = x / _) : u[S * 3] = u[S * 3 + 1] = u[S * 3 + 2] = 128;
		}
		let f = e === 1 ? 60 : 250;
		for (let e = 0; e < f; e++) for (let e = 0; e < l; e++) for (let t = 0; t < c; t++) {
			let n = e * c + t;
			if (!d[n]) continue;
			let r = t > 0 ? n - 1 : n, i = t < c - 1 ? n + 1 : n, a = e > 0 ? n - c : n, o = e < l - 1 ? n + c : n;
			for (let e = 0; e < 3; e++) u[n * 3 + e] = (u[r * 3 + e] + u[i * 3 + e] + u[a * 3 + e] + u[o * 3 + e]) / 4;
		}
		a = u, o = c, s = l;
	}
	let c = Bn(e);
	if (a) {
		for (let e = 0; e < n * r; e++) if (t[e]) for (let t = 0; t < 3; t++) c.data[e * 4 + t] = a[e * 3 + t] + e * (7 + 4 * t) % 5 - 2;
	}
	return c;
}
//#endregion
//#region ../pipeline/src/stickers.ts
var er = (e) => Math.min(1, Math.max(0, e));
function tr(e, t) {
	let { width: n, height: r, data: i } = e, a = t.width * 1, o = t.height * 1, s = Math.max(0, Math.floor((t.x - a) * n)), c = Math.max(0, Math.floor((t.y - o) * r)), l = Math.min(n, Math.ceil((t.x + t.width + a) * n)), u = Math.min(r, Math.ceil((t.y + t.height + o) * r)), d = l - s, f = u - c;
	if (d < 4 || f < 4) return t;
	let p = (e, t) => {
		let r = (t * n + e) * 4, a = Math.min(i[r], i[r + 1], i[r + 2]);
		return a >= 150 && Math.max(i[r], i[r + 1], i[r + 2]) - a <= 26;
	}, m = (e, i) => e >= t.x * n && e < (t.x + t.width) * n && i >= t.y * r && i < (t.y + t.height) * r, h = new Uint8Array(d * f), g = null, _ = [];
	for (let e = 0; e < f; e++) for (let t = 0; t < d; t++) {
		if (h[e * d + t] || !p(s + t, c + e)) continue;
		let n = 0, r = t, i = t, a = e, o = e;
		for (h[e * d + t] = 1, _.push(e * d + t); _.length;) {
			let e = _.pop(), t = e % d, l = (e - t) / d;
			m(s + t, c + l) && n++, t < r && (r = t), t > i && (i = t), l < a && (a = l), l > o && (o = l);
			for (let [e, n] of [
				[1, 0],
				[-1, 0],
				[0, 1],
				[0, -1]
			]) {
				let r = t + e, i = l + n;
				r < 0 || i < 0 || r >= d || i >= f || h[i * d + r] || !p(s + r, c + i) || (h[i * d + r] = 1, _.push(i * d + r));
			}
		}
		(!g || n > g.overlap) && (g = {
			overlap: n,
			minX: r,
			maxX: i,
			minY: a,
			maxY: o
		});
	}
	let v = t.width * n * t.height * r;
	if (!g || g.overlap < v * .2 || g.minX === 0 || g.minY === 0 || g.maxX === d - 1 || g.maxY === f - 1 || g.maxX - g.minX + 1 > t.width * n * 2 || g.maxY - g.minY + 1 > t.height * r * 2.5) return t;
	let y = Math.max(3, (g.maxX - g.minX) * .02), b = Math.max(3, (g.maxY - g.minY) * .04), x = er((s + g.minX - y) / n), S = er((c + g.minY - b) / r);
	return {
		x,
		y: S,
		width: er((s + g.maxX + 1 + y) / n) - x,
		height: er((c + g.maxY + 1 + b) / r) - S
	};
}
//#endregion
//#region ../pipeline/src/words.ts
var nr = {
	lightness: 225,
	maxWidth: 30,
	minLength: 35
};
function rr(e, t) {
	let { width: n, height: r, data: i } = e, a = new Uint8Array(n * r);
	for (let e = 0; e < n * r; e++) {
		if (i[e * 4 + 3] < 128) continue;
		let n = i[e * 4], r = i[e * 4 + 1], o = i[e * 4 + 2], s = Math.min(n, r, o);
		s >= t && Math.max(n, r, o) - s <= 34 && (a[e] = 1);
	}
	return a;
}
function ir(e, t, n, r, i) {
	let a = (e, a) => {
		let o = new Uint8Array(e.length), s = a ? t : n, c = a ? n : t;
		for (let n = 0; n < c; n++) for (let c = 0; c < s; c++) {
			let l = +!i;
			for (let o = -r; o <= r; o++) {
				let r = c + o, u = r < 0 || r >= s ? 0 : e[a ? n * t + r : r * t + n];
				if (i ? u : !u) {
					l = +!!i;
					break;
				}
			}
			o[a ? n * t + c : c * t + n] = l;
		}
		return o;
	};
	return a(a(e, !0), !1);
}
function ar(e, t = nr, n) {
	let { width: r, height: i } = e, a = Math.max(r, i), o = rr(e, t.lightness), s = Math.max(1, Math.round(t.maxWidth / 1e3 * a * .5)), c = ir(ir(o, r, i, s, !1), r, i, s, !0), l = t.minLength / 1e3 * a, u = new Uint8Array(r * i), d = new Uint8Array(r * i), f = [], p = [];
	for (let e = 0; e < o.length; e++) {
		if (!o[e] || u[e] || n && !n[e]) continue;
		let t = [], a = r, s = 0, m = i, h = 0, g = 0;
		for (u[e] = 1, f.push(e); f.length;) {
			let e = f.pop();
			t.push(e), c[e] && g++;
			let i = e % r, l = (e - i) / r;
			i < a && (a = i), i > s && (s = i), l < m && (m = l), l > h && (h = l);
			for (let t of [
				e - 1,
				e + 1,
				e - r,
				e + r,
				e - r - 1,
				e - r + 1,
				e + r - 1,
				e + r + 1
			]) {
				if (t < 0 || t >= o.length || !o[t] || u[t] || n && !n[t]) continue;
				let e = t % r;
				Math.abs(e - i) > 1 || (u[t] = 1, f.push(t));
			}
		}
		let _ = Math.hypot(s - a, h - m);
		if (_ >= l && g / t.length < .5) for (let e of t) d[e] = 1;
		else _ >= l * .4 && p.push({
			members: t,
			thickShare: g / t.length
		});
	}
	let m = ir(d, r, i, Math.max(2, Math.round(a * .03)), !0);
	for (let e of p) if (e.thickShare < .85 && e.members.some((e) => m[e])) for (let t of e.members) d[t] = 1;
	let h = rr(e, Math.max(150, t.lightness - 40)), g = d;
	for (let e = 0; e < 4; e++) {
		let e = new Uint8Array(g);
		for (let t = 0; t < e.length; t++) {
			if (e[t] || !h[t] || n && !n[t]) continue;
			let i = t % r;
			(i > 0 && g[t - 1] || i < r - 1 && g[t + 1] || t >= r && g[t - r] || t + r < e.length && g[t + r]) && (e[t] = 1);
		}
		g = e;
	}
	return Zn(g, r, i, Math.max(2, Math.round(a * .0045)));
}
function or(e, t = nr, n, r, i = !0) {
	let a = i ? ar(e, t, n) : new Uint8Array(e.width * e.height);
	r && (a = a.map((e, t) => e || r[t] ? 1 : 0));
	let o = 0;
	for (let e of a) o += e;
	return {
		image: o ? $n(e, a) : Bn(e),
		filled: o
	};
}
//#endregion
//#region ../pipeline/src/printed.ts
var sr = (e) => {
	let t = [...e].sort((e, t) => e - t);
	return t[Math.floor(t.length / 2)] ?? 0;
};
function cr(e, t, n = 40) {
	let { width: r, height: i, data: a } = e, o = new Uint8Array(r * i), s = Math.max(0, Math.floor(t.x * r)), c = Math.max(0, Math.floor(t.y * i)), l = Math.min(r, Math.ceil((t.x + t.width) * r)), u = Math.min(i, Math.ceil((t.y + t.height) * i));
	if (l - s < 2 || u - c < 2) return o;
	let d = Math.max(2, Math.round(Math.min(l - s, u - c) * .25)), f = [], p = [], m = [], h = (e, t) => {
		let n = (t * r + e) * 4;
		f.push(a[n]), p.push(a[n + 1]), m.push(a[n + 2]);
	};
	for (let e = Math.max(0, c - d); e < Math.min(i, u + d); e++) for (let t = Math.max(0, s - d); t < Math.min(r, l + d); t++) (t < s || t >= l || e < c || e >= u) && h(t, e);
	if (f.length < 8) {
		for (let e = s; e < l; e++) h(e, c), h(e, u - 1);
		for (let e = c; e < u; e++) h(s, e), h(l - 1, e);
	}
	let g = [
		sr(f),
		sr(p),
		sr(m)
	];
	if ([
		f,
		p,
		m
	].reduce((e, t, n) => e + sr(t.map((e) => Math.abs(e - g[n]))), 0) / 3 > 18) return lr(e, s, c, l, u);
	for (let e of [n, n * 1.8]) {
		let t = 0;
		o.fill(0);
		for (let n = c; n < u; n++) for (let i = s; i < l; i++) {
			let s = (n * r + i) * 4;
			(Math.abs(a[s] - g[0]) + Math.abs(a[s + 1] - g[1]) + Math.abs(a[s + 2] - g[2])) / 3 > e && (o[n * r + i] = 1, t++);
		}
		if (t <= (l - s) * (u - c) * .6) return o;
	}
	return lr(e, s, c, l, u);
}
function lr(e, t, n, r, i, a = 70) {
	let { width: o, height: s, data: c } = e, l = r - t, u = i - n, d = new Uint8Array(o * s), f = new Float32Array(l * u);
	for (let e = 0; e < u; e++) for (let r = 0; r < l; r++) {
		let i = ((n + e) * o + t + r) * 4;
		f[e * l + r] = .299 * c[i] + .587 * c[i + 1] + .114 * c[i + 2];
	}
	let p = Math.max(2, Math.round(u * .09)), m = (e, t) => {
		let n = (e, n) => {
			let r = new Float32Array(e.length), i = n ? l : u, a = n ? u : l;
			for (let o = 0; o < a; o++) for (let a = 0; a < i; a++) {
				let s = t ? -Infinity : Infinity;
				for (let r = Math.max(0, a - p); r <= Math.min(i - 1, a + p); r++) {
					let i = e[n ? o * l + r : r * l + o];
					(t ? i > s : i < s) && (s = i);
				}
				r[n ? o * l + a : a * l + o] = s;
			}
			return r;
		};
		return n(n(e, !0), !1);
	}, h = m(m(f, !0), !1), g = m(m(f, !1), !0), _ = 0, v = new Uint8Array(l * u);
	for (let e = 0; e < f.length; e++) (h[e] - f[e] > a || f[e] - g[e] > a) && (v[e] = 1, _++);
	if (_ > l * u * .4) return d;
	for (let e = 0; e < u; e++) for (let r = 0; r < l; r++) v[e * l + r] && (d[(n + e) * o + t + r] = 1);
	return d;
}
function ur(e, t, n, r = 48) {
	let { width: i, height: a, data: o } = e, s = (e, t) => {
		let n = (Math.min(a - 1, Math.max(0, t)) * i + Math.min(i - 1, Math.max(0, e))) * 4;
		return [
			o[n],
			o[n + 1],
			o[n + 2]
		];
	}, c = (e, t) => (Math.abs(e[0] - t[0]) + Math.abs(e[1] - t[1]) + Math.abs(e[2] - t[2])) / 3, l = Math.round(n.x), u = Math.round(n.y), d = Math.min(44, Math.max(14, Math.round((t.y1 - t.y0) * .2))), f = [], p = [], m = [];
	for (let e = -d - 2; e <= d + 2; e++) for (let t = -d - 2; t <= d + 2; t++) {
		if (Math.max(Math.abs(t), Math.abs(e)) < d) continue;
		let [n, r, i] = s(l + t, u + e);
		f.push(n), p.push(r), m.push(i);
	}
	let h = (e) => [...e].sort((e, t) => e - t)[Math.floor(e.length / 2)], g = [
		h(f),
		h(p),
		h(m)
	], _ = Math.min(22, Math.max(8, Math.round(d * .5))), v = null, y = 0;
	for (let e = 0; e <= _ && !v; e++) {
		for (let t = -e; t <= e; t++) for (let n = -e; n <= e; n++) {
			if (Math.max(Math.abs(n), Math.abs(t)) !== e) continue;
			let r = s(l + n, u + t), i = c(r, g);
			i >= 60 && i > y && (y = i, v = r);
		}
		if (v) for (let t = -(e + 2); t <= e + 2; t++) for (let n = -(e + 2); n <= e + 2; n++) {
			let e = s(l + n, u + t), r = c(e, g);
			r > y && (y = r, v = e);
		}
	}
	if (!v) return { problem: "no-print" };
	let b = new Uint8Array(i * a), x = 0, S = Math.max(0, Math.round(t.x0)), C = Math.max(0, Math.round(t.y0)), w = Math.min(i, Math.round(t.x1)), ee = Math.min(a, Math.round(t.y1));
	for (let e = C; e < ee; e++) for (let t = S; t < w; t++) {
		let n = (e * i + t) * 4;
		(Math.abs(o[n] - v[0]) + Math.abs(o[n + 1] - v[1]) + Math.abs(o[n + 2] - v[2])) / 3 < r && (b[e * i + t] = 1, x++);
	}
	return x < 12 ? { problem: "no-print" } : x > (w - S) * (ee - C) * .45 ? { problem: "too-much" } : {
		mask: b,
		color: v
	};
}
//#endregion
//#region ../pipeline/src/reconstruct.ts
function dr(e, t, n) {
	let r = (e) => {
		let t = e / 255;
		return t <= .04045 ? t / 12.92 : ((t + .055) / 1.055) ** 2.4;
	}, i = r(e), a = r(t), o = r(n), s = (e) => e > .008856 ? Math.cbrt(e) : 7.787 * e + 16 / 116, c = s((.4124 * i + .3576 * a + .1805 * o) / .95047), l = s(.2126 * i + .7152 * a + .0722 * o), u = s((.0193 * i + .1192 * a + .9505 * o) / 1.08883);
	return [
		116 * l - 16,
		500 * (c - l),
		200 * (l - u)
	];
}
function fr(e, t) {
	let n = /* @__PURE__ */ new Float64Array(128);
	for (let r of e) n[Math.min(127, Math.floor(r / t * 128))]++;
	let r = e.length, i = 0;
	for (let e = 0; e < 128; e++) i += e * n[e];
	let a = 0, o = 0, s = 0, c = 0;
	for (let e = 0; e < 128; e++) {
		if (a += n[e], !a) continue;
		let t = r - a;
		if (!t) break;
		o += e * n[e];
		let l = a * t * (o / a - (i - o) / t) ** 2;
		l > s && (s = l, c = e);
	}
	return (c + 1) / 128 * t;
}
function pr(e, t, n, r) {
	let i = new Uint8Array(t * n), a = new Uint8Array(t * n), o = [];
	for (let s = 0; s < t * n; s++) {
		if (!e[s] || a[s]) continue;
		let c = [];
		for (a[s] = 1, o.push(s); o.length;) {
			let r = o.pop();
			c.push(r);
			let i = r % t;
			for (let s of [
				i > 0 ? r - 1 : -1,
				i < t - 1 ? r + 1 : -1,
				r - t,
				r + t
			]) s < 0 || s >= t * n || !e[s] || a[s] || (a[s] = 1, o.push(s));
		}
		if (c.length >= r) for (let e of c) i[e] = 1;
	}
	return i;
}
function mr(e, t, n, r = {}) {
	let { width: i, height: a } = e, { grow: o = 2, minPiece: s = 14, floor: c = 8 } = r, l = new Float32Array(i * a), u = [];
	for (let r = 0; r < i * a; r++) {
		if (!n[r]) continue;
		let i = dr(e.data[r * 4], e.data[r * 4 + 1], e.data[r * 4 + 2]), a = dr(t.data[r * 4], t.data[r * 4 + 1], t.data[r * 4 + 2]);
		l[r] = Math.hypot(i[0] - a[0], i[1] - a[1], i[2] - a[2]), u.push(l[r]);
	}
	if (!u.length) return new Uint8Array(i * a);
	let d = new Float32Array(i * a);
	for (let e = 0; e < a; e++) for (let t = 0; t < i; t++) {
		let n = 0, r = 0;
		for (let o = -1; o <= 1; o++) for (let s = -1; s <= 1; s++) {
			let c = t + s, u = e + o;
			if (c < 0 || u < 0 || c >= i || u >= a) continue;
			let d = (2 - Math.abs(s)) * (2 - Math.abs(o));
			n += l[u * i + c] * d, r += d;
		}
		d[e * i + t] = n / r;
	}
	l.set(d);
	let f = [];
	for (let e = 0; e < i * a; e++) n[e] && f.push(l[e]);
	let p = f.reduce((e, t) => Math.max(e, t), 0), m = Math.max(c, fr(f, Math.max(p, 1)) * .6), h = new Uint8Array(i * a);
	for (let e = 0; e < i * a; e++) n[e] && l[e] > m && (h[e] = 1);
	h = pr(h, i, a, s);
	let g = Zn(h, i, a, o);
	for (let e = 0; e < g.length; e++) n[e] || (g[e] = 0);
	return g;
}
//#endregion
//#region ../render2d/src/shaders.ts
var hr = "#version 300 es\nvoid main() {\n  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));\n  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);\n}", gr = "#version 300 es\nprecision highp float;\n\nuniform sampler2D uSource;\nuniform sampler2D uMask;   // cut-out alpha, same coordinates as the source\nuniform bool uHasMask;\nuniform vec2 uMaskTexel;   // size of one mask pixel in source coordinates\nuniform bool uDespill;     // pull green spill off the product's cut edge\nuniform sampler2D uBackground;\nuniform int uBgMode;       // 0 transparent, 1 colour, 2 photo\nuniform vec3 uBgColor;\nuniform vec4 uBgTransform; // output uv -> photo uv: scale.xy, offset.xy (\"cover\")\nuniform mat3 uOutputToSource;\nuniform vec2 uOutputSize;\nuniform bool uFlipY;\n\nuniform float uExposure;   // stops\nuniform float uContrast;   // -1..1\nuniform float uHighlights; // -1..1\nuniform float uShadows;    // -1..1\nuniform vec3 uWhiteBalance; // per-channel gains, luminance-neutral\nuniform float uVibrance;   // -1..1\nuniform float uSaturation; // -1..1\nuniform float uVignette;   // -1..1\nuniform bool uRecolour;    // off by default: it changes the product's own colour (core/recolour.ts is the reference)\nuniform vec3 uRecolourFrom;\nuniform vec3 uRecolourTo;\nuniform float uRecolourRange; // degrees of hue\n\nout vec4 outColor;\n\nvec3 toLinear(vec3 c) {\n  return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), step(0.04045, c));\n}\n\nvec3 toDisplay(vec3 c) {\n  c = max(c, 0.0);\n  return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c));\n}\n\nfloat luma(vec3 c) {\n  return dot(c, vec3(0.2126, 0.7152, 0.0722));\n}\n\n// hue in degrees, saturation, value\nvec3 rgbToHsv(vec3 c) {\n  float mx = max(c.r, max(c.g, c.b));\n  float mn = min(c.r, min(c.g, c.b));\n  float d = mx - mn;\n  float h = 0.0;\n  if (d > 0.0) {\n    if (mx == c.r) h = mod((c.g - c.b) / d, 6.0);\n    else if (mx == c.g) h = (c.b - c.r) / d + 2.0;\n    else h = (c.r - c.g) / d + 4.0;\n    h *= 60.0;\n  }\n  return vec3(h, mx > 0.0 ? d / mx : 0.0, mx);\n}\n\nvec3 hsvToRgb(vec3 hsv) {\n  vec3 k = mod(vec3(5.0, 3.0, 1.0) + mod(hsv.x, 360.0) / 60.0, 6.0);\n  return hsv.z - hsv.z * hsv.y * clamp(min(k, 4.0 - k), 0.0, 1.0);\n}\n\nvec3 recolour(vec3 c) {\n  vec3 p = rgbToHsv(c);\n  vec3 f = rgbToHsv(uRecolourFrom);\n  vec3 t = rgbToHsv(uRecolourTo);\n  float d = abs(mod(p.x - f.x + 540.0, 360.0) - 180.0);\n  float w = smoothstep(0.06, 0.18, p.y) * (1.0 - smoothstep(uRecolourRange * 0.6, uRecolourRange, d));\n  vec3 changed = hsvToRgb(vec3(p.x + (t.x - f.x), min(1.0, p.y * t.y / max(f.y, 0.05)), min(1.0, p.z * t.z / max(f.z, 0.05))));\n  return mix(c, changed, w);\n}\n\nvoid main() {\n  vec2 uv = gl_FragCoord.xy / uOutputSize;\n  if (uFlipY) uv.y = 1.0 - uv.y;\n\n  // The product, if this output pixel falls inside the photo (a square canvas can reach past its edges).\n  vec4 product = vec4(0.0);\n  vec2 src = (uOutputToSource * vec3(uv, 1.0)).xy;\n  if (!(any(lessThan(src, vec2(0.0))) || any(greaterThan(src, vec2(1.0))))) {\n    vec4 texel = texture(uSource, src);\n    float maskAlpha = uHasMask ? texture(uMask, src).r : 1.0;\n\n    if (uDespill && uHasMask) {\n      // Only where the cut edge is close: elsewhere a green pixel is the product's own colour.\n      vec2 d = uMaskTexel * 3.0;\n      float nearest = min(min(texture(uMask, src + vec2(d.x, 0.0)).r, texture(uMask, src - vec2(d.x, 0.0)).r),\n                          min(texture(uMask, src + vec2(0.0, d.y)).r, texture(uMask, src - vec2(0.0, d.y)).r));\n      float dom = texel.g - max(texel.r, texel.b);\n      if (nearest < 0.99 && dom > 0.0) texel.g = max(texel.r, texel.b) + dom * 0.15;\n    }\n\n    if (uRecolour) texel.rgb = recolour(texel.rgb);\n\n    vec3 linear = toLinear(texel.rgb) * exp2(uExposure) * uWhiteBalance;\n    vec3 c = toDisplay(linear);\n\n    float y = luma(c);\n    c *= 1.0 + uShadows * 0.6 * (1.0 - smoothstep(0.0, 0.55, y));\n    c *= 1.0 + uHighlights * 0.5 * smoothstep(0.45, 1.0, y);\n    c = (c - 0.5) * (1.0 + uContrast * 0.8) + 0.5;\n\n    y = luma(c);\n    float chroma = max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b));\n    c = mix(vec3(y), c, 1.0 + uVibrance * (1.0 - clamp(chroma, 0.0, 1.0)));\n    c = mix(vec3(y), c, 1.0 + uSaturation);\n\n    float edge = smoothstep(0.35, 1.0, length(uv - 0.5) * 1.41421);\n    c *= 1.0 + uVignette * edge;\n\n    product = vec4(clamp(c, 0.0, 1.0), texel.a * maskAlpha);\n  }\n\n  // Put the product over whatever is behind it.\n  vec3 behind = vec3(0.0);\n  float behindAlpha = 0.0;\n  if (uBgMode == 1) {\n    behind = uBgColor;\n    behindAlpha = 1.0;\n  } else if (uBgMode == 2) {\n    behind = texture(uBackground, uv * uBgTransform.xy + uBgTransform.zw).rgb;\n    behindAlpha = 1.0;\n  }\n  float a = product.a + behindAlpha * (1.0 - product.a);\n  vec3 rgb = a > 0.0 ? (product.rgb * product.a + behind * behindAlpha * (1.0 - product.a)) / a : vec3(0.0);\n  outColor = vec4(rgb, a);\n}", _r = [
	"uSource",
	"uMask",
	"uHasMask",
	"uMaskTexel",
	"uDespill",
	"uBackground",
	"uBgMode",
	"uBgColor",
	"uBgTransform",
	"uOutputToSource",
	"uOutputSize",
	"uFlipY",
	"uExposure",
	"uContrast",
	"uHighlights",
	"uShadows",
	"uWhiteBalance",
	"uVibrance",
	"uSaturation",
	"uVignette",
	"uRecolour",
	"uRecolourFrom",
	"uRecolourTo",
	"uRecolourRange"
], vr = "#version 300 es\nprecision highp float;\nuniform sampler2D uProduct;\nuniform sampler2D uBackground;\nuniform vec2 uResolution;\nuniform bool uFlipY;\nuniform int uBgMode;\nuniform vec3 uBgColor;\nuniform vec4 uBgTransform;\nout vec4 outColor;\nvoid main() {\n  vec2 uv = gl_FragCoord.xy / uResolution;\n  if (uFlipY) uv.y = 1.0 - uv.y;\n  vec4 product = texture(uProduct, uv);\n  vec3 behind = vec3(0.0);\n  float behindAlpha = 0.0;\n  if (uBgMode == 1) { behind = uBgColor; behindAlpha = 1.0; }\n  else if (uBgMode == 2) { behind = texture(uBackground, uv * uBgTransform.xy + uBgTransform.zw).rgb; behindAlpha = 1.0; }\n  float a = product.a + behindAlpha * (1.0 - product.a);\n  vec3 rgb = a > 0.0 ? (product.rgb * product.a + behind * behindAlpha * (1.0 - product.a)) / a : vec3(0.0);\n  outColor = vec4(rgb, a);\n}";
function yr(e, t, n) {
	let r = e.createShader(t);
	if (e.shaderSource(r, n), e.compileShader(r), !e.getShaderParameter(r, e.COMPILE_STATUS)) {
		let t = e.getShaderInfoLog(r);
		throw e.deleteShader(r), Error(`Shader failed to compile: ${t}`);
	}
	return r;
}
function br(e, t) {
	let n = e / 100, r = t / 100, i = [
		1 + .25 * n,
		1 - .2 * r,
		1 - .25 * n
	], a = .2126 * i[0] + .7152 * i[1] + .0722 * i[2];
	return i.map((e) => e / a);
}
function xr(e, t, n) {
	return new Promise((r, i) => e.toBlob((e) => e ? r(e) : i(/* @__PURE__ */ Error("This browser could not encode the image.")), t, n));
}
var Sr = class {
	canvas;
	maxTextureSize;
	gl;
	program;
	vao;
	uniforms;
	source = null;
	mask = null;
	maskTexel = [0, 0];
	despill = !1;
	background = null;
	backgroundSize = [1, 1];
	effectPrograms = /* @__PURE__ */ new Map();
	composite = null;
	scratch = null;
	noMask;
	constructor(e) {
		this.canvas = e;
		let t = e.getContext("webgl2", {
			alpha: !0,
			premultipliedAlpha: !1,
			antialias: !1
		});
		if (!t) throw Error("This browser does not support WebGL2, which the editor needs.");
		this.gl = t, this.maxTextureSize = t.getParameter(t.MAX_TEXTURE_SIZE);
		let n = t.createProgram();
		if (t.attachShader(n, yr(t, t.VERTEX_SHADER, hr)), t.attachShader(n, yr(t, t.FRAGMENT_SHADER, gr)), t.linkProgram(n), !t.getProgramParameter(n, t.LINK_STATUS)) throw Error(`Shader failed to link: ${t.getProgramInfoLog(n)}`);
		this.program = n, this.vao = t.createVertexArray(), this.noMask = t.createTexture(), t.bindTexture(t.TEXTURE_2D, this.noMask), t.texImage2D(t.TEXTURE_2D, 0, t.R8, 1, 1, 0, t.RED, t.UNSIGNED_BYTE, new Uint8Array([255])), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MIN_FILTER, t.NEAREST), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MAG_FILTER, t.NEAREST), this.uniforms = Object.fromEntries(_r.map((e) => [e, t.getUniformLocation(n, e)]));
	}
	setSource(e) {
		let t = this.gl;
		this.source && t.deleteTexture(this.source), this.source = t.createTexture(), t.bindTexture(t.TEXTURE_2D, this.source), t.pixelStorei(t.UNPACK_FLIP_Y_WEBGL, !1), t.pixelStorei(t.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !1), t.texImage2D(t.TEXTURE_2D, 0, t.RGBA8, t.RGBA, t.UNSIGNED_BYTE, e), t.generateMipmap(t.TEXTURE_2D), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MIN_FILTER, t.LINEAR_MIPMAP_LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MAG_FILTER, t.LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_S, t.CLAMP_TO_EDGE), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_T, t.CLAMP_TO_EDGE);
	}
	setMask(e, t = 0, n = 0, r = {}) {
		let i = this.gl;
		this.mask && i.deleteTexture(this.mask), this.mask = null, this.despill = !1, e && (this.despill = r.despill === !0, this.maskTexel = [1 / t, 1 / n], this.mask = i.createTexture(), i.bindTexture(i.TEXTURE_2D, this.mask), i.pixelStorei(i.UNPACK_ALIGNMENT, 1), i.texImage2D(i.TEXTURE_2D, 0, i.R8, t, n, 0, i.RED, i.UNSIGNED_BYTE, e), i.pixelStorei(i.UNPACK_ALIGNMENT, 4), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_MIN_FILTER, i.LINEAR), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_MAG_FILTER, i.LINEAR), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_WRAP_S, i.CLAMP_TO_EDGE), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_WRAP_T, i.CLAMP_TO_EDGE));
	}
	setBackground(e) {
		let t = this.gl;
		this.background && t.deleteTexture(this.background), this.background = null, e && (this.backgroundSize = [e.width, e.height], this.background = t.createTexture(), t.bindTexture(t.TEXTURE_2D, this.background), t.pixelStorei(t.UNPACK_FLIP_Y_WEBGL, !1), t.pixelStorei(t.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !1), t.texImage2D(t.TEXTURE_2D, 0, t.RGBA8, t.RGBA, t.UNSIGNED_BYTE, e), t.generateMipmap(t.TEXTURE_2D), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MIN_FILTER, t.LINEAR_MIPMAP_LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MAG_FILTER, t.LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_S, t.CLAMP_TO_EDGE), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_T, t.CLAMP_TO_EDGE));
	}
	draw(e, t, n) {
		this.canvas.width !== t && (this.canvas.width = t), this.canvas.height !== n && (this.canvas.height = n), this.render(e, t, n, !0, null);
	}
	async export(e, t = {}) {
		let n = this.gl, r = Math.min(this.maxTextureSize, n.getParameter(n.MAX_RENDERBUFFER_SIZE)), { width: i, height: a } = T(e, Math.min(t.maxSize ?? Infinity, r));
		if (t.size) {
			let e = Math.min(t.size, r) / Math.max(i, a);
			i = Math.max(1, Math.round(i * e)), a = Math.max(1, Math.round(a * e));
		}
		let o = n.createTexture();
		n.bindTexture(n.TEXTURE_2D, o), n.texStorage2D(n.TEXTURE_2D, 1, n.RGBA8, i, a);
		let s = n.createFramebuffer();
		n.bindFramebuffer(n.FRAMEBUFFER, s), n.framebufferTexture2D(n.FRAMEBUFFER, n.COLOR_ATTACHMENT0, n.TEXTURE_2D, o, 0);
		let c = new Uint8ClampedArray(i * a * 4);
		try {
			this.render(e, i, a, !1, s), n.readPixels(0, 0, i, a, n.RGBA, n.UNSIGNED_BYTE, c);
		} finally {
			n.bindFramebuffer(n.FRAMEBUFFER, null), n.deleteFramebuffer(s), n.deleteTexture(o);
		}
		let l = t.type ?? "image/webp", u = document.createElement("canvas");
		u.width = i, u.height = a, u.getContext("2d").putImageData(new ImageData(c, i, a), 0, 0);
		let d = async (e, n) => {
			if (e !== "image/jpeg") return xr(u, e, n);
			let r = document.createElement("canvas");
			r.width = i, r.height = a;
			let o = r.getContext("2d");
			return o.fillStyle = t.background ?? "#ffffff", o.fillRect(0, 0, i, a), o.drawImage(u, 0, 0), xr(r, e, n);
		}, f = t.quality ?? .88, p = await d(l, f), m = p.type === l ? l : l === "image/webp" ? "image/jpeg" : p.type;
		if (m !== p.type && (p = await d(m, f)), t.maxBytes && m !== "image/png") for (; p.size > t.maxBytes && f > .4;) f -= .08, p = await d(m, f);
		return {
			blob: p,
			width: i,
			height: a,
			type: p.type
		};
	}
	dispose() {
		let e = this.gl;
		this.source && e.deleteTexture(this.source), this.mask && e.deleteTexture(this.mask), this.background && e.deleteTexture(this.background), e.deleteTexture(this.noMask), this.freeScratch();
		for (let t of this.effectPrograms.values()) typeof t != "string" && e.deleteProgram(t.program);
		this.effectPrograms.clear(), this.composite && e.deleteProgram(this.composite.program), e.deleteProgram(this.program), e.deleteVertexArray(this.vao), this.source = null;
	}
	compileEffect(e) {
		let t = this.effectProgram(e);
		return typeof t == "string" ? t : null;
	}
	effectProgram(e) {
		let t = `${e.id}:${e.source.length}:${e.source.slice(-40)}`, n = this.effectPrograms.get(t);
		if (n) return n;
		let r = this.gl, i;
		try {
			let t = r.createProgram();
			if (r.attachShader(t, yr(r, r.VERTEX_SHADER, ue)), r.attachShader(t, yr(r, r.FRAGMENT_SHADER, le(e))), r.linkProgram(t), !r.getProgramParameter(t, r.LINK_STATUS)) throw Error(`Shader failed to link: ${r.getProgramInfoLog(t)}`);
			i = {
				program: t,
				inputs: {
					uInput: r.getUniformLocation(t, "uInput"),
					uResolution: r.getUniformLocation(t, "uResolution"),
					uTime: r.getUniformLocation(t, "uTime"),
					uFlipY: r.getUniformLocation(t, "uFlipY"),
					uInputFlipped: r.getUniformLocation(t, "uInputFlipped")
				},
				params: new Map(e.params.map((e) => [e.uniform, r.getUniformLocation(t, e.uniform)]))
			};
		} catch (t) {
			i = `${e.id}: ${t instanceof Error ? t.message : String(t)}`, console.warn(`The "${e.name}" effect was skipped. ${i}`);
		}
		return this.effectPrograms.set(t, i), i;
	}
	freeScratch() {
		if (this.scratch) {
			for (let e of this.scratch.targets) this.gl.deleteFramebuffer(e.framebuffer), this.gl.deleteTexture(e.texture);
			this.scratch = null;
		}
	}
	scratchTargets(e, t) {
		let n = this.gl;
		if (this.scratch && this.scratch.width === e && this.scratch.height === t) return this.scratch.targets;
		this.freeScratch();
		let r = () => {
			let r = n.createTexture();
			n.bindTexture(n.TEXTURE_2D, r), n.texStorage2D(n.TEXTURE_2D, 1, n.RGBA8, e, t), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MIN_FILTER, n.LINEAR), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MAG_FILTER, n.LINEAR), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_S, n.CLAMP_TO_EDGE), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_T, n.CLAMP_TO_EDGE);
			let i = n.createFramebuffer();
			return n.bindFramebuffer(n.FRAMEBUFFER, i), n.framebufferTexture2D(n.FRAMEBUFFER, n.COLOR_ATTACHMENT0, n.TEXTURE_2D, r, 0), {
				texture: r,
				framebuffer: i
			};
		}, i = [r(), r()];
		return this.scratch = {
			width: e,
			height: t,
			targets: i
		}, i;
	}
	runEffect(e, t, n, r, i, a, o, s) {
		let c = this.gl;
		c.bindFramebuffer(c.FRAMEBUFFER, i), c.viewport(0, 0, a, o), c.useProgram(e.program), c.bindVertexArray(this.vao), c.activeTexture(c.TEXTURE0), c.bindTexture(c.TEXTURE_2D, r), c.uniform1i(e.inputs.uInput, 0), c.uniform2f(e.inputs.uResolution, a, o), c.uniform1f(e.inputs.uTime, 0), c.uniform1i(e.inputs.uFlipY, +!!s), c.uniform1i(e.inputs.uInputFlipped, 0);
		for (let r of t.params) {
			let t = e.params.get(r.uniform);
			if (!t) continue;
			let i = de(r, n[r.key]);
			Array.isArray(i) ? c.uniform3f(t, i[0], i[1], i[2]) : r.glslType === "float" ? c.uniform1f(t, i) : c.uniform1i(t, i);
		}
		c.drawArrays(c.TRIANGLES, 0, 3);
	}
	runComposite(e, t, n, r, a, o) {
		let s = this.gl;
		if (!this.composite) {
			let e = s.createProgram();
			if (s.attachShader(e, yr(s, s.VERTEX_SHADER, hr)), s.attachShader(e, yr(s, s.FRAGMENT_SHADER, vr)), s.linkProgram(e), !s.getProgramParameter(e, s.LINK_STATUS)) throw Error(`Shader failed to link: ${s.getProgramInfoLog(e)}`);
			let t = [
				"uProduct",
				"uBackground",
				"uResolution",
				"uFlipY",
				"uBgMode",
				"uBgColor",
				"uBgTransform"
			];
			this.composite = {
				program: e,
				uniforms: Object.fromEntries(t.map((t) => [t, s.getUniformLocation(e, t)]))
			};
		}
		let c = this.composite.uniforms;
		s.bindFramebuffer(s.FRAMEBUFFER, n), s.viewport(0, 0, r, a), s.useProgram(this.composite.program), s.bindVertexArray(this.vao), s.activeTexture(s.TEXTURE0), s.bindTexture(s.TEXTURE_2D, t), s.uniform1i(c.uProduct, 0);
		let l = i(e.recipe, "backdrop", "mode") === "image" && this.background;
		s.activeTexture(s.TEXTURE1), s.bindTexture(s.TEXTURE_2D, l ? this.background : this.noMask), s.uniform1i(c.uBackground, 1), s.uniform2f(c.uResolution, r, a), s.uniform1i(c.uFlipY, +!!o), this.setBackdropUniforms(e, r, a, c.uBgMode, c.uBgColor, c.uBgTransform), s.activeTexture(s.TEXTURE0), s.drawArrays(s.TRIANGLES, 0, 3);
	}
	setBackdropUniforms(e, t, n, r, a, o) {
		let s = this.gl, c = e.recipe, l = i(c, "backdrop", "mode"), u = l === "image" && this.background;
		s.uniform1i(r, u ? 2 : +(l === "color"));
		let d = i(c, "backdrop", "color") || "#ffffff";
		s.uniform3f(a, parseInt(d.slice(1, 3), 16) / 255, parseInt(d.slice(3, 5), 16) / 255, parseInt(d.slice(5, 7), 16) / 255);
		let f = t / n, p = this.backgroundSize[0] / this.backgroundSize[1], m = p > f ? f / p : 1, h = p > f ? 1 : p / f;
		s.uniform4f(o, m, h, (1 - m) / 2, (1 - h) / 2);
	}
	render(e, t, n, r, i) {
		let a = e.recipe.effects.map((e) => ({
			step: e,
			def: O(e.id)
		})).filter((e) => !!e.def).map((e) => ({
			...e,
			program: this.effectProgram(e.def)
		})).filter((e) => typeof e.program != "string");
		if (!a.length) {
			this.gl.bindFramebuffer(this.gl.FRAMEBUFFER, i), this.drawPhoto(e, t, n, r, !0);
			return;
		}
		let [o, s] = this.scratchTargets(t, n);
		this.gl.bindFramebuffer(this.gl.FRAMEBUFFER, o.framebuffer), this.drawPhoto(e, t, n, !1, !1);
		let c = o, l = s, u = () => {
			[c, l] = [l, c];
		}, d = a.filter((e) => e.def.scope === "product"), f = a.filter((e) => e.def.scope !== "product");
		for (let e of d) this.runEffect(e.program, e.def, D(e.def, e.step.params), c.texture, l.framebuffer, t, n, !1), u();
		this.runComposite(e, c.texture, f.length ? l.framebuffer : i, t, n, !f.length && r), f.length && (u(), f.forEach((e, a) => {
			let o = a === f.length - 1;
			this.runEffect(e.program, e.def, D(e.def, e.step.params), c.texture, o ? i : l.framebuffer, t, n, o ? r : !1), u();
		}));
	}
	drawPhoto(e, t, n, r, o) {
		let s = this.gl, c = this.uniforms, u = e.recipe, d = _(e);
		if (s.viewport(0, 0, t, n), s.clearColor(0, 0, 0, 0), s.clear(s.COLOR_BUFFER_BIT), !this.source) return;
		s.useProgram(this.program), s.bindVertexArray(this.vao), s.activeTexture(s.TEXTURE0), s.bindTexture(s.TEXTURE_2D, this.source), s.uniform1i(c.uSource, 0), s.activeTexture(s.TEXTURE1), s.bindTexture(s.TEXTURE_2D, this.mask ?? this.noMask), s.uniform1i(c.uMask, 1), s.uniform1i(c.uHasMask, +!!this.mask), s.uniform2f(c.uMaskTexel, this.maskTexel[0], this.maskTexel[1]), s.uniform1i(c.uDespill, +!!this.despill);
		let f = o && i(u, "backdrop", "mode") === "image" && this.background;
		s.activeTexture(s.TEXTURE2), s.bindTexture(s.TEXTURE_2D, f ? this.background : this.noMask), s.uniform1i(c.uBackground, 2), o ? this.setBackdropUniforms(e, t, n, c.uBgMode, c.uBgColor, c.uBgTransform) : s.uniform1i(c.uBgMode, 0), s.activeTexture(s.TEXTURE0), s.uniformMatrix3fv(c.uOutputToSource, !1, [
			d.a,
			d.b,
			0,
			d.c,
			d.d,
			0,
			d.e,
			d.f,
			1
		]), s.uniform2f(c.uOutputSize, t, n), s.uniform1i(c.uFlipY, +!!r), s.uniform1f(c.uExposure, l(u, "light", "exposure")), s.uniform1f(c.uContrast, l(u, "light", "contrast") / 100), s.uniform1f(c.uHighlights, l(u, "light", "highlights") / 100), s.uniform1f(c.uShadows, l(u, "light", "shadows") / 100), s.uniform3fv(c.uWhiteBalance, br(l(u, "color", "temperature"), l(u, "color", "tint"))), s.uniform1f(c.uVibrance, l(u, "color", "vibrance") / 100), s.uniform1f(c.uSaturation, l(u, "color", "saturation") / 100), s.uniform1f(c.uVignette, l(u, "effects", "vignette") / 100), s.uniform1i(c.uRecolour, +!!a(u, "recolour", "on")), s.uniform3fv(c.uRecolourFrom, I(i(u, "recolour", "from") || "#d23c3c")), s.uniform3fv(c.uRecolourTo, I(i(u, "recolour", "to") || "#3c64d2")), s.uniform1f(c.uRecolourRange, l(u, "recolour", "range") || 30), s.drawArrays(s.TRIANGLES, 0, 3);
	}
}, Cr = [
	"nw",
	"n",
	"ne",
	"e",
	"se",
	"s",
	"sw",
	"w"
], wr = (e) => `${e * 100}%`;
function Tr({ editor: e, doc: t, width: n, height: r }) {
	let i = j(null), a = C(t), o = (t) => (n) => {
		n.preventDefault(), n.stopPropagation(), n.currentTarget.setPointerCapture(n.pointerId), i.current = {
			handle: t,
			start: C(e.document),
			x: n.clientX,
			y: n.clientY
		}, e.begin(t === "move" ? "Move crop" : "Resize crop");
	}, s = (t) => {
		let a = i.current;
		if (!a) return;
		let o = e.document;
		e.setCrop(b(a.start, a.handle, (t.clientX - a.x) / n, (t.clientY - a.y) / r, y(o), ie(o)));
	}, c = () => {
		i.current && (i.current = null, e.commit());
	};
	return /* @__PURE__ */ P("div", {
		className: "gs-crop",
		style: {
			width: n,
			height: r
		},
		onPointerMove: s,
		onPointerUp: c,
		onPointerCancel: c,
		children: /* @__PURE__ */ F("div", {
			className: "gs-crop__box",
			style: {
				left: wr(a.x),
				top: wr(a.y),
				width: wr(a.width),
				height: wr(a.height)
			},
			onPointerDown: o("move"),
			children: [/* @__PURE__ */ P("div", { className: "gs-crop__thirds" }), Cr.map((e) => /* @__PURE__ */ P("div", {
				className: `gs-crop__handle gs-crop__handle--${e}`,
				onPointerDown: o(e)
			}, e))]
		})
	});
}
//#endregion
//#region src/AiCutout.tsx
function Er({ app: e, what: t }) {
	let [n, r] = M("");
	return vt() && e.state === "offline" ? /* @__PURE__ */ P(xt, {
		app: e,
		feature: t.feature ?? "This AI tool"
	}) : e.state === "checking" ? /* @__PURE__ */ P("p", {
		className: "gs-hint",
		children: "Looking for the Gleamshelf app on this computer…"
	}) : e.state === "blocked" ? /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ F("p", {
		className: "gs-error",
		children: [
			"The Gleamshelf app is running at ",
			e.saved.url,
			", but this browser will not let the page talk to it. Safari does this. Open the editor in Chrome or Edge, or serve it from ",
			/* @__PURE__ */ P("code", { children: "http://localhost" }),
			"."
		]
	}), /* @__PURE__ */ P("button", {
		type: "button",
		className: "gs-button",
		onClick: () => void e.check(),
		children: "Check again"
	})] }) : e.state === "offline" && !e.looking ? /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ F("p", {
		className: "gs-hint",
		children: [t.intro, " It needs the small Gleamshelf app running on this computer (your photos never leave it). This page has not looked for it yet."]
	}), /* @__PURE__ */ P("button", {
		type: "button",
		className: "gs-button",
		onClick: () => void e.check(),
		children: "Look for the app"
	})] }) : e.state === "offline" ? /* @__PURE__ */ F(N, { children: [
		/* @__PURE__ */ F("p", {
			className: "gs-hint",
			children: [
				t.intro,
				" It needs the small Gleamshelf app running on this computer (your photos never leave it). Nothing answered at",
				" ",
				/* @__PURE__ */ P("code", { children: e.saved.url }),
				". This page keeps looking, so it will notice as soon as the app starts."
			]
		}),
		/* @__PURE__ */ F("ol", {
			className: "gs-steps",
			children: [/* @__PURE__ */ F("li", { children: [
				"Open a terminal in the Gleamshelf folder and run ",
				/* @__PURE__ */ P("code", { children: it.start }),
				". ",
				/* @__PURE__ */ P("strong", { children: "Leave it running" }),
				" while you edit."
			] }), /* @__PURE__ */ F("li", { children: [
				"Once, if you have not yet: ",
				/* @__PURE__ */ P("code", { children: t.install }),
				" (it says \"Already installed\" when the model is there; that is fine, the app still has to be started)."
			] })]
		}),
		/* @__PURE__ */ P("button", {
			type: "button",
			className: "gs-button",
			onClick: () => void e.check(),
			children: "Check now"
		})
	] }) : e.state === "needs-token" ? /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ F("p", {
		className: "gs-hint",
		children: [
			"The app is running. Paste its pairing token to connect. The token is a 32-character code. It is printed when you start the app, and again by ",
			/* @__PURE__ */ P("code", { children: it.token }),
			" (it is the last line of the output)."
		]
	}), /* @__PURE__ */ F("div", {
		className: "gs-crop-tools",
		children: [/* @__PURE__ */ P("input", {
			type: "password",
			className: "gs-input",
			"aria-label": "Pairing token",
			placeholder: "Pairing token",
			value: n,
			onChange: (e) => r(e.target.value)
		}), /* @__PURE__ */ P("button", {
			type: "button",
			className: "gs-button",
			disabled: !n.trim(),
			onClick: () => {
				e.connect(n), r("");
			},
			children: "Connect"
		})]
	})] }) : null;
}
function Dr({ getPhoto: e, onMask: t, greenBackdrop: n, app: r }) {
	let [i, a] = M(""), [o, s] = M(!1), [c, l] = M("product"), u = tt("cutout"), d = r.installed("cutout"), f = i && d.some((e) => e.id === i) ? i : d[0]?.id ?? "", p = et(f), m = async () => {
		s(!0), r.setProblem(null);
		try {
			t(f, await r.client.cutout(await e(c), f, void 0, { thinParts: c === "character" }), c);
		} catch (e) {
			r.setProblem(e instanceof Error ? e.message : "The cut-out did not work.");
		} finally {
			s(!1);
		}
	};
	return /* @__PURE__ */ F("div", {
		className: "gs-ai",
		children: [
			/* @__PURE__ */ F("div", {
				className: "gs-ai__title",
				children: [/* @__PURE__ */ P("strong", { children: "AI cut-out" }), /* @__PURE__ */ P("span", {
					className: "gs-badge gs-badge--free",
					title: "The model runs on your computer. Nothing is sent anywhere and nothing is charged.",
					children: "free · on your computer"
				})]
			}),
			/* @__PURE__ */ P(K, { id: "aiCutout" }),
			/* @__PURE__ */ P(Er, {
				app: r,
				what: {
					feature: "The AI cut-out",
					intro: "Works for any background, not just green.",
					install: it.install(u.find((e) => e.recommended)?.id)
				}
			}),
			r.state === "ready" && /* @__PURE__ */ F(N, { children: [d.length === 0 ? /* @__PURE__ */ F("p", {
				className: "gs-hint",
				children: [
					"No cut-out model is installed yet. Run ",
					/* @__PURE__ */ P("code", { children: it.install(u.find((e) => e.recommended)?.id) }),
					", then",
					" ",
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-link",
						onClick: () => void r.check(),
						children: "check again"
					}),
					"."
				]
			}) : /* @__PURE__ */ F(N, { children: [
				/* @__PURE__ */ F("label", {
					className: "gs-control",
					children: [/* @__PURE__ */ P("span", {
						className: "gs-control__row",
						children: /* @__PURE__ */ P("span", { children: "Model" })
					}), /* @__PURE__ */ P("select", {
						value: f,
						onChange: (e) => a(e.target.value),
						children: d.map((e) => /* @__PURE__ */ P("option", {
							value: e.id,
							children: e.name
						}, e.id))
					})]
				}),
				/* @__PURE__ */ F("div", {
					className: "gs-segmented",
					role: "group",
					"aria-label": "What to cut out",
					children: [/* @__PURE__ */ P("button", {
						type: "button",
						className: `gs-button ${c === "product" ? "is-active" : ""}`,
						"aria-pressed": c === "product",
						onClick: () => l("product"),
						title: "The whole box or product, without its background",
						children: "Whole product"
					}), /* @__PURE__ */ P("button", {
						type: "button",
						className: `gs-button ${c === "character" ? "is-active" : ""}`,
						"aria-pressed": c === "character",
						onClick: () => l("character"),
						title: "Only the character in the artwork on a box cover",
						children: "Character on cover"
					})]
				}),
				c === "product" && n && /* @__PURE__ */ F("p", {
					className: "gs-hint",
					children: [
						/* @__PURE__ */ P("strong", { children: "This photo has a green backdrop." }),
						" The free ",
						/* @__PURE__ */ P("em", { children: "Remove green backdrop" }),
						" button above does the same job instantly, so AI is not needed here. AI is for photos on any other background, or for picking out the character on a box cover."
					]
				}),
				c === "character" && /* @__PURE__ */ F("p", {
					className: "gs-hint",
					children: [
						"Use ",
						/* @__PURE__ */ P("strong", { children: "Crop" }),
						" first to frame just the artwork (leave out the logos, price tags and title text), then cut out. The character is found inside the crop. Printed words that cross the character stay with it; remove them with",
						" ",
						/* @__PURE__ */ P("strong", { children: "Printed lettering" }),
						" in the Clean up tab."
					]
				}),
				p && /* @__PURE__ */ F("p", {
					className: "gs-hint",
					children: [
						p.summary,
						" ",
						/* @__PURE__ */ P("a", {
							href: p.links.modelCard,
							target: "_blank",
							rel: "noreferrer",
							children: "About this model"
						}),
						" ",
						"· ",
						p.license.name,
						" licence, commercial use ",
						p.license.commercialUse
					]
				}),
				/* @__PURE__ */ P("button", {
					type: "button",
					className: "gs-button gs-button--primary",
					disabled: o || !f,
					onClick: () => void m(),
					children: o ? c === "character" ? "Working… also looking for thin parts, about 30 seconds" : "Working… the first run loads the model" : c === "character" ? "Cut out the character" : "Cut out with AI"
				})
			] }), u.some((e) => !r.models?.find((t) => t.id === e.id)?.installed) && /* @__PURE__ */ F("details", {
				className: "gs-hint",
				children: [/* @__PURE__ */ P("summary", { children: "More models" }), /* @__PURE__ */ P("ul", {
					className: "gs-models",
					children: u.filter((e) => !r.models?.find((t) => t.id === e.id)?.installed).map((e) => /* @__PURE__ */ F("li", { children: [
						/* @__PURE__ */ P("strong", { children: e.name }),
						" · ",
						e.sizeMb,
						" MB · ",
						e.license.name,
						/* @__PURE__ */ P("br", {}),
						e.summary,
						" ",
						/* @__PURE__ */ P("a", {
							href: e.links.modelCard,
							target: "_blank",
							rel: "noreferrer",
							children: "Read about it"
						}),
						/* @__PURE__ */ P("br", {}),
						/* @__PURE__ */ P("code", { children: it.install(e.id) })
					] }, e.id))
				})]
			})] }),
			r.problem && /* @__PURE__ */ P("p", {
				className: "gs-error",
				children: r.problem
			})
		]
	});
}
//#endregion
//#region src/AiEnlarge.tsx
function Or({ getPicture: e, onEnlarged: t, onRemove: n, applied: r, app: i, sharpen: a }) {
	let [o, s] = M(!1), [c, l] = M(!1), [u, d] = M(""), f = tt("upscale"), p = i.installed("upscale"), m = u && p.some((e) => e.id === u) ? u : p[0]?.id ?? "", h = et(m), g = f.find((e) => e.recommended), _ = async () => {
		s(!0), i.setProblem(null);
		try {
			let n = await e();
			c && a && (n = await a(n)), t(m, await i.client.upscale(n, m));
		} catch (e) {
			i.setProblem(e instanceof Error ? e.message : "The enlarging did not work.");
		} finally {
			s(!1);
		}
	};
	return /* @__PURE__ */ F("div", {
		className: "gs-ai",
		children: [
			/* @__PURE__ */ F("div", {
				className: "gs-ai__title",
				children: [/* @__PURE__ */ P("strong", { children: "Sharpen & enlarge" }), /* @__PURE__ */ P("span", {
					className: "gs-badge gs-badge--free",
					title: "The model runs on your computer. Nothing is sent anywhere and nothing is charged.",
					children: "free · on your computer"
				})]
			}),
			/* @__PURE__ */ P(K, { id: "enlarge" }),
			/* @__PURE__ */ P(Er, {
				app: i,
				what: {
					feature: "AI enlarging",
					intro: "Rebuilds fine detail so the picture is clearly sharper and can be saved larger.",
					install: it.install(g?.id)
				}
			}),
			i.state === "ready" && (p.length === 0 ? /* @__PURE__ */ F("p", {
				className: "gs-hint",
				children: [
					"No enlarging model is installed yet. Run ",
					/* @__PURE__ */ P("code", { children: it.install(g?.id) }),
					" (",
					g?.sizeMb,
					" MB), then",
					" ",
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-link",
						onClick: () => void i.check(),
						children: "check again"
					}),
					"."
				]
			}) : /* @__PURE__ */ F(N, { children: [
				/* @__PURE__ */ F("label", {
					className: "gs-control",
					children: [/* @__PURE__ */ P("span", {
						className: "gs-control__row",
						children: /* @__PURE__ */ P("span", { children: "Model" })
					}), /* @__PURE__ */ P("select", {
						value: m,
						onChange: (e) => d(e.target.value),
						children: p.map((e) => /* @__PURE__ */ P("option", {
							value: e.id,
							children: e.name
						}, e.id))
					})]
				}),
				h && /* @__PURE__ */ F("p", {
					className: "gs-hint",
					children: [
						h.summary,
						" ",
						/* @__PURE__ */ P("a", {
							href: h.links.modelCard,
							target: "_blank",
							rel: "noreferrer",
							children: "About this model"
						}),
						" ",
						"· ",
						h.license.name,
						"; check it allows your use. It adds believable detail that was not in the photo."
					]
				}),
				a && /* @__PURE__ */ F("label", {
					className: "gs-control gs-control--inline",
					title: "Re-draws the picture slightly with Stable Diffusion, pinned to the original shapes, so hair, fabric and edges come back crisper. Colours are kept. Free, on your computer.",
					children: [/* @__PURE__ */ P("input", {
						type: "checkbox",
						checked: c,
						onChange: (e) => l(e.target.checked)
					}), "Add detail first (slower, about a minute). Not for a box with small print: it redraws small text as gibberish."]
				}),
				/* @__PURE__ */ F("div", {
					className: "gs-crop-tools",
					children: [/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-button gs-button--primary",
						disabled: o || !m,
						onClick: () => void _(),
						children: o ? c && a ? "Sharpening… about a minute" : "Enlarging… a few seconds" : r ? "Enlarge again" : "Sharpen & enlarge"
					}), r && /* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-button",
						onClick: n,
						children: "Remove"
					})]
				}),
				r && /* @__PURE__ */ F("p", {
					className: "gs-hint",
					children: [
						"Applied: the saved picture is ",
						r.factor,
						" times larger than the original photo. Do the lettering first: changing it later removes this."
					]
				})
			] })),
			i.problem && /* @__PURE__ */ P("p", {
				className: "gs-error",
				children: i.problem
			})
		]
	});
}
//#endregion
//#region src/PickOverlay.tsx
function kr({ editor: e, width: t, height: n, onPick: r }) {
	return /* @__PURE__ */ P("div", {
		className: "gs-pick",
		style: {
			width: t,
			height: n
		},
		onPointerDown: (t) => {
			t.preventDefault();
			let n = t.currentTarget.getBoundingClientRect(), [i, a] = te(_(e.document), (t.clientX - n.left) / n.width, (t.clientY - n.top) / n.height);
			r(Math.min(1, Math.max(0, i)), Math.min(1, Math.max(0, a)));
		}
	});
}
//#endregion
//#region src/AiFill.tsx
function Ar({ buildInput: e, onFilled: t, applied: n, app: r, busyOutside: i }) {
	let [a, o] = M(!1), s = a || !!i, [c, l] = M(!0), u = tt("inpaint"), d = tt("text-detect"), f = r.installed("inpaint")[0], p = r.installed("text-detect")[0], m = et(f?.id ?? u[0]?.id ?? ""), h = u.find((e) => e.recommended), g = async () => {
		if (f) {
			o(!0), r.setProblem(null);
			try {
				let n = await e({
					otherText: c && !!p,
					textModel: p?.id,
					client: r.client
				});
				n ? t(f.id, await r.client.inpaint(n.picture, f.id), n.cutAway) : r.setProblem("Nothing to fill: no lettering or printed text was found. Try a lower \"How white\" above.");
			} catch (e) {
				r.setProblem(e instanceof Error ? e.message : "The fill did not work.");
			} finally {
				o(!1);
			}
		}
	};
	return /* @__PURE__ */ F("div", {
		className: "gs-ai",
		children: [
			/* @__PURE__ */ F("div", {
				className: "gs-ai__title",
				children: [/* @__PURE__ */ P("strong", { children: "AI fill" }), /* @__PURE__ */ P("span", {
					className: "gs-badge gs-badge--free",
					title: "The model runs on your computer. Nothing is sent anywhere and nothing is charged.",
					children: "free · on your computer"
				})]
			}),
			/* @__PURE__ */ P(K, { id: "aiFill" }),
			/* @__PURE__ */ P(Er, {
				app: r,
				what: {
					feature: "The AI fill",
					intro: "A cleaner fill than the free one: it repaints hair, fabric and skin where the words were.",
					install: it.install(h?.id)
				}
			}),
			r.state === "ready" && /* @__PURE__ */ P(N, { children: f ? /* @__PURE__ */ F(N, { children: [
				/* @__PURE__ */ F("p", {
					className: "gs-hint",
					children: [
						m?.summary,
						" ",
						/* @__PURE__ */ P("a", {
							href: m?.links.modelCard,
							target: "_blank",
							rel: "noreferrer",
							children: "About this model"
						}),
						" ",
						"· ",
						m?.license.name,
						" licence. It invents the part hidden under the words, so look closely at the result."
					]
				}),
				/* @__PURE__ */ F("label", {
					className: "gs-control gs-control--inline",
					title: p ? "Finds other printed text (any colour) and fills it in too" : `Needs the text finder: ${it.install(d[0]?.id)}`,
					children: [
						/* @__PURE__ */ P("input", {
							type: "checkbox",
							checked: c && !!p,
							disabled: !p,
							onChange: (e) => l(e.target.checked)
						}),
						"Also fill other printed text",
						p ? "" : " (needs the text finder)"
					]
				}),
				!p && d[0] && /* @__PURE__ */ F("p", {
					className: "gs-hint",
					children: [
						"Text finder: ",
						d[0].name,
						", ",
						d[0].sizeMb,
						" MB, ",
						d[0].license.name,
						".",
						" ",
						/* @__PURE__ */ P("code", { children: it.install(d[0].id) })
					]
				}),
				/* @__PURE__ */ P("button", {
					type: "button",
					className: "gs-button gs-button--primary",
					disabled: s,
					onClick: () => void g(),
					children: s ? "Filling… a few seconds" : n ? "Fill again with AI" : "Fill with AI"
				})
			] }) : /* @__PURE__ */ F("p", {
				className: "gs-hint",
				children: [
					"No fill model is installed yet (",
					m ? `${m.name}, ${m.sizeMb} MB, ${m.license.name}` : "LaMa",
					"). Run",
					" ",
					/* @__PURE__ */ P("code", { children: it.install(h?.id) }),
					", then",
					" ",
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-link",
						onClick: () => void r.check(),
						children: "check again"
					}),
					"."
				]
			}) }),
			r.problem && /* @__PURE__ */ P("p", {
				className: "gs-error",
				children: r.problem
			})
		]
	});
}
//#endregion
//#region src/AiFinish.tsx
function jr({ app: e, applied: t, onRedrawArea: n, onCancelArea: r, picking: i, onRemove: a, note: o, busyOutside: s }) {
	let [c, l] = M(!1), u = c || s, [d, f] = M(""), [p, m] = M(!0), h = e.state === "ready" && e.installed("redraw").length > 0;
	return /* @__PURE__ */ F("div", {
		className: "gs-ai",
		children: [
			/* @__PURE__ */ F("div", {
				className: "gs-ai__title",
				children: [/* @__PURE__ */ P("strong", { children: "Finishing touches (AI redraw)" }), /* @__PURE__ */ P("span", {
					className: "gs-badge gs-badge--free",
					title: "The model runs on your computer. Nothing is sent anywhere and nothing is charged.",
					children: "free · on your computer · about 30 s"
				})]
			}),
			/* @__PURE__ */ P(K, { id: "finish" }),
			/* @__PURE__ */ P(Er, {
				app: e,
				what: {
					feature: "Finishing touches",
					intro: "Redraws an area you choose, for a part the photo cuts off or something the fill missed. Nothing is invented elsewhere.",
					install: it.redrawSetup
				}
			}),
			e.state === "ready" && !h && /* @__PURE__ */ F("p", {
				className: "gs-hint",
				children: [
					"The redraw model is not set up yet. Run ",
					/* @__PURE__ */ P("code", { children: it.redrawSetup }),
					" once (about 7 GB; it asks first), then",
					" ",
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-link",
						onClick: () => void e.check(),
						children: "check again"
					}),
					"."
				]
			}),
			h && /* @__PURE__ */ F(N, { children: [
				/* @__PURE__ */ F("label", {
					className: "gs-control",
					children: [/* @__PURE__ */ P("span", {
						className: "gs-control__row",
						children: /* @__PURE__ */ P("span", { children: "Redraw an area as…" })
					}), /* @__PURE__ */ P("input", {
						className: "gs-input",
						value: d,
						maxLength: 400,
						placeholder: "e.g. smooth blue plastic hair",
						onChange: (e) => f(e.target.value)
					})]
				}),
				/* @__PURE__ */ F("label", {
					className: "gs-control gs-control--inline",
					children: [/* @__PURE__ */ P("input", {
						type: "checkbox",
						checked: p,
						onChange: (e) => m(e.target.checked)
					}), "Keep what is there as a guide (less change)"]
				}),
				/* @__PURE__ */ F("div", {
					className: "gs-crop-tools",
					children: [/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-button",
						disabled: u || t || !d.trim(),
						onClick: () => i ? r() : n(d.trim(), p),
						children: i ? "Cancel" : "Choose the area…"
					}), t && /* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-button",
						disabled: u,
						onClick: a,
						children: "Remove"
					})]
				}),
				t && /* @__PURE__ */ P("p", {
					className: "gs-hint",
					children: "Applied. This is the last step: changing anything else in the editor takes it off (Undo brings it back)."
				}),
				/* @__PURE__ */ P("p", {
					className: "gs-hint",
					children: "The model draws new pixels, so it can differ from the real item. Check the result before listing, and do not use it where a buyer needs to see the actual condition."
				})
			] }),
			o && /* @__PURE__ */ P("p", {
				className: "gs-hint",
				children: o
			}),
			e.problem && /* @__PURE__ */ P("p", {
				className: "gs-error",
				children: e.problem
			})
		]
	});
}
//#endregion
//#region src/AreaOverlay.tsx
function Mr({ width: e, height: t, onArea: n }) {
	let r = j(null), [i, a] = M(null), o = (e) => {
		let t = e.currentTarget.getBoundingClientRect();
		return {
			x: Math.min(1, Math.max(0, (e.clientX - t.left) / t.width)),
			y: Math.min(1, Math.max(0, (e.clientY - t.top) / t.height))
		};
	}, s = (e, t) => ({
		x: Math.min(e.x, t.x),
		y: Math.min(e.y, t.y),
		width: Math.abs(e.x - t.x),
		height: Math.abs(e.y - t.y)
	});
	return /* @__PURE__ */ P("div", {
		className: "gs-pick",
		style: {
			width: e,
			height: t
		},
		onPointerDown: (e) => {
			e.preventDefault(), e.currentTarget.setPointerCapture(e.pointerId), r.current = o(e), a(null);
		},
		onPointerMove: (e) => r.current && a(s(r.current, o(e))),
		onPointerUp: (e) => {
			if (!r.current) return;
			let t = s(r.current, o(e));
			r.current = null, a(null), t.width > .02 && t.height > .02 && n([
				t.x,
				t.y,
				t.width,
				t.height
			]);
		},
		children: i && /* @__PURE__ */ P("div", {
			className: "gs-area",
			style: {
				left: `${i.x * 100}%`,
				top: `${i.y * 100}%`,
				width: `${i.width * 100}%`,
				height: `${i.height * 100}%`
			}
		})
	});
}
//#endregion
//#region src/ask.ts
var Nr = new Set("a an the and or of to in on for at by with from is are be it its this that these those i me my you your we our how do does can could where what which who why when there here find get make want use using button buttons please show tell".split(" "));
function Pr(e) {
	let t = [];
	for (let n of e.toLowerCase().match(/[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}ー]+|[\p{L}\p{N}]+/gu) ?? []) if (/[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}]/u.test(n)) {
		n.length === 1 && t.push(n);
		for (let e = 0; e + 1 < n.length; e++) t.push(n.slice(e, e + 2));
	} else Nr.has(n) || n.length < 2 || t.push(n.replace(/(?<=\w{3})(?<!s)s$/, "").replace(/(?<=\w{3})(ing|ed)$/, "").replace(/(?<=\w{3})e$/, ""));
	return t;
}
function Fr(e, t) {
	let n = 0;
	for (let r of new Set(Pr(t))) e.has(r) && (n += Math.min(3, .5 + r.length / 4));
	return n;
}
function Ir(e, t, { prefer: n = [], also: r, max: i = 6 } = {}) {
	let a = new Set(Pr(e));
	return a.size ? Object.entries(t).map(([e, t]) => {
		let i = 2 * Fr(a, t.name) + Fr(a, t.user) + (r ? Fr(a, r(t)) : 0);
		return {
			id: e,
			entry: t,
			score: i && n.includes(t.group) ? i * 1.8 : i
		};
	}).filter((e) => e.score > 0).sort((e, t) => t.score - e.score).slice(0, i) : [];
}
var Lr = "button, [role=tab], [role=menuitem], select, summary, a[href], label:has(> input[type=checkbox]), label:has(> input[type=radio]), label:has(> input[type=color])";
function Rr(e, t = 150) {
	let n = [], r = /* @__PURE__ */ new Set();
	for (let i of document.querySelectorAll(Lr)) {
		if (e?.contains(i) || i.disabled) continue;
		let a = i.getBoundingClientRect();
		if (a.width < 4 || a.height < 4 || a.bottom < 0 || a.right < 0 || a.top > innerHeight || a.left > innerWidth) continue;
		let o = getComputedStyle(i);
		if (o.visibility === "hidden" || o.opacity === "0") continue;
		let s = (i.getAttribute("aria-label") || i.innerText || "").replace(/\s+/g, " ").trim().slice(0, 80), c = (i.getAttribute("title") || "").replace(/\s+/g, " ").trim().slice(0, 160);
		if (!s && !c) continue;
		let l = `${s}|${c}`;
		if (!r.has(l) && (r.add(l), n.push({
			id: `c${n.length + 1}`,
			label: s || c.slice(0, 40),
			title: c,
			el: i
		}), n.length >= t)) break;
	}
	return n;
}
function zr(e, t, n, r = 30) {
	let i = new Set(Pr(e)), a = new Set(n.slice(0, 2).flatMap((e) => Pr(`${e.entry.name} ${e.entry.user.split(":")[0]}`)));
	return t.map((e) => ({
		c: e,
		s: 2 * Fr(i, e.label) + Fr(i, e.title) + .6 * Fr(a, e.label)
	})).filter((e) => e.s > 0).sort((e, t) => t.s - e.s).slice(0, r).map((e) => e.c);
}
function Br(e, t) {
	let n = new Map(t.map((e) => [e.id, e])), r = (e) => e.toLowerCase().replace(/[…."'“”‘’:]+$/g, "").trim(), i = [], a = 0;
	for (let t of e.matchAll(/\s*\[(c\d{1,3})\]/g)) {
		let o = e.slice(a, t.index), s = n.get(t[1]);
		if (s) {
			let e = s.label ? r(s.label) : "", t = r(o);
			if (e && t.endsWith(e)) {
				let t = o.toLowerCase().lastIndexOf(e);
				o = o.slice(0, t).replace(/["“‘]$/, "");
			}
		}
		o && i.push(o), s && i.push({ control: s.id }), a = t.index + t[0].length;
	}
	return a < e.length && i.push(e.slice(a)), i;
}
//#endregion
//#region src/askVoice.ts
var Vr = (e) => /[\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Han}]/u.test(e) ? "ja" : "en";
function Hr(e, t = []) {
	let n = "";
	for (let r of Br(e, t)) {
		if (typeof r == "string") {
			n += r;
			continue;
		}
		let e = t.find((e) => e.id === r.control).label.replace(/…$/, "");
		n.slice(-60).toLowerCase().includes(e.toLowerCase()) || (n += ` ${e} `);
	}
	return n.replace(/\s+([、。,.!?！？])/g, "$1").replace(/\s+/g, " ").trim();
}
var Ur = {
	ja: /^(Kyoko|O-ren|Otoya|Hattori|Microsoft (Nanami|Haruka|Ayumi|Keita))/i,
	en: /^(Samantha|Ava|Allison|Daniel|Karen|Microsoft (Aria|Jenny|Guy|Zira|David))/i
};
function Wr(e, t) {
	let n = t.filter((t) => t.localService && t.lang.toLowerCase().startsWith(e));
	return n.find((t) => Ur[e].test(t.name)) ?? n.find((e) => e.default) ?? n[0] ?? null;
}
async function Gr() {
	if (typeof speechSynthesis > "u") return [];
	let e = speechSynthesis.getVoices();
	return e.length ? e : new Promise((e) => {
		let t = window.setTimeout(() => e(speechSynthesis.getVoices()), 1500);
		speechSynthesis.addEventListener("voiceschanged", () => {
			window.clearTimeout(t), e(speechSynthesis.getVoices());
		}, { once: !0 });
	});
}
var Kr = null;
function qr() {
	Kr?.pause(), Kr = null, typeof speechSynthesis < "u" && speechSynthesis.cancel();
}
async function Jr(e, t, n) {
	if (qr(), !e) return !0;
	if (n?.langs.includes(t)) try {
		let r = await n.client.speak(e, t === "ja" ? { voice: "jf_alpha" } : {}), i = new Audio(URL.createObjectURL(r));
		return i.addEventListener("ended", () => URL.revokeObjectURL(i.src), { once: !0 }), Kr = i, await i.play(), !0;
	} catch {}
	let r = Wr(t, await Gr());
	if (!r) return !1;
	let i = new SpeechSynthesisUtterance(e);
	return i.voice = r, i.lang = r.lang, speechSynthesis.speak(i), !0;
}
//#endregion
//#region src/AskPanel.tsx
var Yr = "gleamshelf:ask-aloud", Xr = () => {
	try {
		return localStorage.getItem(Yr) === "1";
	} catch {
		return !1;
	}
}, Zr = "This computer has no voice of its own for that language: add one in its speech settings (on a Mac: Accessibility, Spoken Content, System voice).", Qr = "That is not in the guide as asked. Try other words (the name of a button, or what you want to make), or open the Guide.";
function $r({ open: e, onClose: t, prefer: n = [] }) {
	let r = bt(), [i, a] = M("checking"), [o, s] = M([]), [c, l] = M(""), [u, d] = M(!1), [f, p] = M(null), [m, h] = M(null), g = j(null), _ = j(null), v = j(null), [y, b] = M(Xr), [x, S] = M([]), [C, w] = M(null);
	A(() => {
		if (!e) return;
		if (r.state !== "ready") {
			a(r.state === "checking" ? "checking" : "guide");
			return;
		}
		let t = !0;
		return r.client.helpStatus().then((e) => {
			t && a(e?.ok ? "ai" : "guide");
		}).catch(() => {
			t && a("guide");
		}), () => {
			t = !1;
		};
	}, [
		e,
		r.state,
		r.client
	]), A(() => {
		if (!e || r.state !== "ready") {
			S([]);
			return;
		}
		let t = !0;
		return r.client.voiceStatus().then((e) => {
			t && S(e?.ok ? e.japanese ? ["en", "ja"] : ["en"] : []);
		}).catch(() => {
			t && S([]);
		}), () => {
			t = !1;
		};
	}, [
		e,
		r.state,
		r.client
	]), A(() => () => qr(), []);
	let ee = (e) => void Jr(Hr(e.answer, e.controls), e.lang, x.length ? {
		client: r.client,
		langs: x
	} : null).then((e) => w(e ? null : Zr)), te = () => {
		let e = !y;
		b(e), e || qr();
		try {
			localStorage.setItem(Yr, e ? "1" : "0");
		} catch {}
	};
	A(() => {
		if (!f) {
			h(null);
			return;
		}
		f.scrollIntoView({
			block: "nearest",
			inline: "nearest"
		});
		let e = () => {
			f.isConnected ? h(f.getBoundingClientRect()) : p(null);
		};
		e();
		let t = window.setInterval(e, 250), n = (e) => {
			f.contains(e.target) && p(null);
		};
		return document.addEventListener("pointerdown", n, !0), () => {
			window.clearInterval(t), document.removeEventListener("pointerdown", n, !0);
		};
	}, [f]), A(() => {
		e || (p(null), qr());
	}, [e]), A(() => {
		_.current?.scrollTo({ top: _.current.scrollHeight });
	}, [o, u]);
	let ne = async () => {
		let e = c.trim();
		if (!e || u) return;
		l(""), d(!0);
		let t = Vr(e);
		t === "ja" && !v.current && (v.current = (await import("./ja-CWE1mPgA.js")).JA);
		let a = t === "ja" ? v.current : null, f = Ir(e, Ot, {
			prefer: n,
			also: a ? (e) => `${a[e.name] ?? ""} ${a[e.user] ?? ""}` : void 0
		}), m = Rr(g.current), h = zr(e, m, f), _ = () => ({
			question: e,
			answer: f[0] ? a ? `${a[f[0].entry.name] ?? f[0].entry.name}：${a[f[0].entry.user] ?? f[0].entry.user}` : `${f[0].entry.name}: ${f[0].entry.user}` : a?.[Qr] ?? Qr,
			controls: h.slice(0, 3),
			by: "guide",
			lang: t
		}), b;
		if (i === "ai") {
			let n = [...h, ...m.filter((e) => !h.includes(e))].slice(0, 60);
			try {
				let { answer: i } = await r.client.askHelp({
					question: e,
					lang: t,
					facts: f.map((e) => ({
						name: e.entry.name,
						text: e.entry.user
					})),
					controls: n.map(({ id: e, label: t, title: n }) => ({
						id: e,
						label: t,
						title: n
					})),
					history: o.slice(-3).map((e) => ({
						question: e.question,
						answer: e.answer
					}))
				}), a = Br(i, n).flatMap((e) => typeof e == "string" ? [] : n.filter((t) => t.id === e.control));
				b = {
					question: e,
					answer: i,
					controls: [...new Set(a)],
					by: "ai",
					lang: t
				};
			} catch {
				b = _();
			}
		} else b = _();
		s((e) => [...e, b]), p(b.controls[0]?.el ?? null), d(!1), y && ee(b);
	};
	if (!e) return ei(m);
	let re = !!m && m.right > window.innerWidth - 400 && m.bottom > window.innerHeight - 460;
	return /* @__PURE__ */ F(N, { children: [ei(m), /* @__PURE__ */ F("div", {
		ref: g,
		className: `gs-ask${re ? " gs-ask--left" : ""}`,
		role: "dialog",
		"aria-label": "Ask",
		children: [
			/* @__PURE__ */ F("div", {
				className: "gs-ask__head",
				children: [
					/* @__PURE__ */ P("strong", { children: "Ask" }),
					/* @__PURE__ */ P("span", { className: "gs-ask__spacer" }),
					/* @__PURE__ */ P("button", {
						type: "button",
						className: `gs-ask__aloud${y ? " is-on" : ""}`,
						"aria-pressed": y,
						onClick: te,
						title: "Says each answer aloud, with a voice on this computer",
						children: "🔊 Read aloud"
					}),
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-ask__x",
						"aria-label": "Close Ask",
						onClick: t,
						children: "✕"
					})
				]
			}),
			/* @__PURE__ */ P("p", {
				className: "gs-ask__who",
				children: i === "ai" ? "Answers written by the AI model in the Gleamshelf app: free, on this computer; nothing is sent anywhere." : i === "checking" ? "Looking for the Gleamshelf app…" : "Answers from the Guide (no AI). For written answers, start the Gleamshelf app with its vision model (free, on this computer)."
			}),
			/* @__PURE__ */ F("div", {
				ref: _,
				className: "gs-ask__log",
				children: [
					!o.length && /* @__PURE__ */ P("p", {
						className: "gs-ask__hint",
						children: "Ask where something is or how to do it, e.g. \"Where do I make a character?\""
					}),
					o.map((e, t) => /* @__PURE__ */ F("div", {
						className: "gs-ask__turn",
						children: [
							/* @__PURE__ */ P("p", {
								className: "gs-ask__q",
								translate: "no",
								children: e.question
							}),
							/* @__PURE__ */ F("p", {
								className: "gs-ask__a",
								translate: "no",
								children: [e.by === "ai" ? Br(e.answer, e.controls).map((t, n) => typeof t == "string" ? /* @__PURE__ */ P("span", { children: t }, n) : /* @__PURE__ */ P(ti, {
									control: e.controls.find((e) => e.id === t.control),
									onShow: p
								}, n)) : e.answer, /* @__PURE__ */ P("button", {
									type: "button",
									className: "gs-ask__say",
									"aria-label": "Say it",
									title: "Say it",
									onClick: () => ee(e),
									children: "▶"
								})]
							}),
							e.by === "guide" && e.controls.length > 0 && /* @__PURE__ */ P("div", {
								className: "gs-ask__chips",
								children: e.controls.map((e) => /* @__PURE__ */ P(ti, {
									control: e,
									onShow: p
								}, e.id))
							})
						]
					}, t)),
					C && /* @__PURE__ */ P("p", {
						className: "gs-ask__hint",
						children: C
					}),
					u && /* @__PURE__ */ P("p", {
						className: "gs-ask__hint",
						children: i === "ai" ? "Writing an answer…" : "Looking…"
					})
				]
			}),
			/* @__PURE__ */ F("form", {
				className: "gs-ask__form",
				onSubmit: (e) => {
					e.preventDefault(), ne();
				},
				children: [/* @__PURE__ */ P("input", {
					value: c,
					onChange: (e) => l(e.target.value),
					onKeyDown: (e) => {
						e.stopPropagation(), e.key === "Escape" && t();
					},
					maxLength: 500,
					placeholder: "Where is…? How do I…?",
					"aria-label": "Your question",
					autoFocus: !0
				}), /* @__PURE__ */ P("button", {
					type: "submit",
					className: "gs-ask__send",
					disabled: u || !c.trim(),
					children: "Ask"
				})]
			}),
			/* @__PURE__ */ P(K, { id: "ask" })
		]
	})] });
}
var ei = (e) => e && /* @__PURE__ */ P("div", {
	className: "gs-ask__ring",
	"aria-hidden": "true",
	style: {
		left: e.left - 6,
		top: e.top - 6,
		width: e.width + 12,
		height: e.height + 12
	}
});
function ti({ control: e, onShow: t }) {
	return /* @__PURE__ */ P("button", {
		type: "button",
		className: "gs-ask__chip",
		title: "Show me where it is",
		onClick: () => t(e.el),
		children: e.label
	});
}
//#endregion
//#region ../canvas/src/document.ts
var ni = [
	{
		id: "normal",
		label: "Normal"
	},
	{
		id: "multiply",
		label: "Multiply (darker)"
	},
	{
		id: "darken",
		label: "Keep darker"
	},
	{
		id: "color-burn",
		label: "Burn"
	},
	{
		id: "screen",
		label: "Screen (lighter)"
	},
	{
		id: "lighten",
		label: "Keep lighter"
	},
	{
		id: "color-dodge",
		label: "Dodge"
	},
	{
		id: "overlay",
		label: "Overlay"
	},
	{
		id: "soft-light",
		label: "Soft light"
	},
	{
		id: "hard-light",
		label: "Hard light"
	},
	{
		id: "difference",
		label: "Difference"
	},
	{
		id: "exclusion",
		label: "Exclusion"
	},
	{
		id: "hue",
		label: "Hue only"
	},
	{
		id: "saturation",
		label: "Saturation only"
	},
	{
		id: "color",
		label: "Colour only"
	},
	{
		id: "luminosity",
		label: "Brightness only"
	}
], ri = {
	x: 0,
	y: 0,
	scaleX: 1,
	scaleY: 1,
	rotation: 0
}, ii = 0, ai = (e) => `${e}-${Date.now().toString(36)}-${(ii++).toString(36)}`, oi = (e, t) => ({
	width: e,
	height: t,
	data: new Uint8ClampedArray(e * t * 4)
}), si = (e) => ({
	width: e.width,
	height: e.height,
	data: new Uint8ClampedArray(e.data)
}), ci = class {
	map = /* @__PURE__ */ new Map();
	get(e) {
		return this.map.get(e);
	}
	add(e, t = "px") {
		let n = ai(t);
		return this.map.set(n, e), n;
	}
	set(e, t) {
		this.map.set(e, t);
	}
	get size() {
		return this.map.size;
	}
	keepOnly(e) {
		let t = /* @__PURE__ */ new Set();
		for (let n of e) for (let e of li(n)) t.add(e);
		for (let e of [...this.map.keys()]) t.has(e) || this.map.delete(e);
	}
};
function li(e) {
	let t = [];
	for (let n of e.layers) n.kind === "raster" && t.push(n.pixels), n.mask && t.push(n.mask);
	return t;
}
function ui(e, t, n = "#ffffff") {
	if (!(e >= 1 && t >= 1 && e <= 16384 && t <= 16384)) throw Error("A canvas must be 1 to 16384 pixels on each side.");
	return {
		width: Math.round(e),
		height: Math.round(t),
		background: n,
		layers: []
	};
}
var di = (e, t) => ({
	id: ai(t),
	name: e,
	visible: !0,
	locked: !1,
	opacity: 1,
	blend: "normal",
	transform: { ...ri }
}), fi = (e, t, n = {}) => ({
	...di(e, "raster"),
	kind: "raster",
	pixels: t,
	transform: {
		...ri,
		...n
	}
}), pi = (e, t, n = {}, r = {}) => ({
	...di(e, "shape"),
	kind: "shape",
	shape: t,
	fill: "#e46a9b",
	stroke: null,
	strokeWidth: 4,
	...n,
	transform: {
		...ri,
		...r
	}
}), mi = (e, t = {}, n = {}) => ({
	...di(e.split("\n")[0].slice(0, 24) || "Text", "text"),
	kind: "text",
	text: e,
	font: "system-ui, sans-serif",
	size: 64,
	weight: 700,
	italic: !1,
	color: "#1a1a1a",
	align: "left",
	lineHeight: 1.2,
	box: {
		width: 0,
		height: 0
	},
	...t,
	transform: {
		...ri,
		...n
	}
}), hi = (e, t) => e.layers.find((e) => e.id === t);
function gi(e, t, n) {
	let r = [...e.layers], i = n ? r.findIndex((e) => e.id === n) : -1;
	return r.splice(i >= 0 ? i + 1 : r.length, 0, t), {
		...e,
		layers: r
	};
}
function q(e, t, n) {
	return {
		...e,
		layers: e.layers.map((e) => e.id === t ? {
			...e,
			...n
		} : e)
	};
}
var _i = (e, t) => ({
	...e,
	layers: e.layers.filter((e) => e.id !== t)
});
function vi(e, t, n) {
	let r = [...e.layers], i = r.findIndex((e) => e.id === t);
	if (i < 0) return e;
	let a = Math.max(0, Math.min(r.length - 1, n === Infinity ? r.length - 1 : n === -Infinity ? 0 : i + n));
	if (a === i) return e;
	let [o] = r.splice(i, 1);
	return r.splice(a, 0, o), {
		...e,
		layers: r
	};
}
function yi(e, t, n) {
	let r = hi(e, n);
	if (!r) return {
		doc: e,
		id: n
	};
	let i = {
		...r,
		id: ai(r.kind),
		name: `${r.name} copy`
	};
	return i.kind === "raster" && (i.pixels = t.add(si(t.get(i.pixels)))), i.mask &&= t.add(si(t.get(i.mask)), "mask"), {
		doc: gi(e, i, n),
		id: i.id
	};
}
//#endregion
//#region ../canvas/src/ink.ts
var bi = (e) => ({
	radius: Math.max(0, e),
	at: null
}), xi = (e, t) => e <= 0 ? 0 : e * (2 + t * .08);
function Si(e, t) {
	if (!e.at) return e.at = { ...t };
	let n = t.x - e.at.x, r = t.y - e.at.y, i = Math.hypot(n, r);
	if (i <= e.radius) return null;
	let a = (i - e.radius) / i;
	return e.at = {
		x: e.at.x + n * a,
		y: e.at.y + r * a
	}, { ...e.at };
}
function Ci(e, t, n = 2) {
	if (!e.at) return [{ ...t }];
	let r = Math.hypot(t.x - e.at.x, t.y - e.at.y);
	if (r < .5) return [];
	let i = Math.max(1, Math.ceil(r / n)), a = e.at;
	return e.at = { ...t }, Array.from({ length: i }, (e, n) => ({
		x: a.x + (t.x - a.x) * (n + 1) / i,
		y: a.y + (t.y - a.y) * (n + 1) / i
	}));
}
var wi = {
	size: 6,
	taper: 24,
	speed: .4
};
function Ti(e, t, n, r = 1) {
	let i = e.points, a = i[i.length - 1];
	if (a && Math.hypot(t.x - a.x, t.y - a.y) < .75) return;
	let o = a ? Math.hypot(t.x - a.x, t.y - a.y) : 0, s = Math.min(1, o / Math.max(4, n.size * 3)), c = n.size * (1 - n.speed * s) * Math.max(.05, Math.min(1, r));
	a && (c = (Di.get(a) ?? a.w) * .6 + c * .4), i.push({
		x: t.x,
		y: t.y,
		w: c
	}), Oi(e, n.taper, !1);
}
function Ei(e, t) {
	return e.points.length === 1 ? e.points[0].w = t.size : Oi(e, t.taper, !0), e;
}
var Di = /* @__PURE__ */ new WeakMap();
function Oi(e, t, n) {
	let r = e.points;
	if (r.length < 2 || t <= 0) return;
	let i = [0];
	for (let e = 1; e < r.length; e++) i.push(i[e - 1] + Math.hypot(r[e].x - r[e - 1].x, r[e].y - r[e - 1].y));
	let a = i[i.length - 1], o = Math.min(t, a / 2.5);
	r.forEach((e, t) => {
		Di.has(e) || Di.set(e, e.w);
		let r = Di.get(e), s = (e) => {
			let t = Math.max(0, Math.min(1, e));
			return .15 + .85 * (t * (2 - t));
		}, c = o > 0 ? s(i[t] / o) : 1;
		n && o > 0 && (c = Math.min(c, s((a - i[t]) / o))), e.w = r * c;
	});
}
var ki = (e) => Math.round(e * 100) / 100, Ai = (e, t, n) => `M${ki(e - n)} ${ki(t)}A${ki(n)} ${ki(n)} 0 1 1 ${ki(e + n)} ${ki(t)}A${ki(n)} ${ki(n)} 0 1 1 ${ki(e - n)} ${ki(t)}Z`;
function ji(e) {
	let t = [];
	for (let n of e) {
		let e = n.points;
		for (let n = 0; n < e.length; n++) {
			let r = e[n];
			r.w > .05 && t.push(Ai(r.x, r.y, r.w / 2));
			let i = e[n + 1];
			if (!i) continue;
			let a = i.x - r.x, o = i.y - r.y, s = Math.hypot(a, o);
			if (s < 1e-6) continue;
			let c = -o / s, l = a / s, u = r.w / 2, d = i.w / 2, f = [
				[r.x + c * u, r.y + l * u],
				[i.x + c * d, i.y + l * d],
				[i.x - c * d, i.y - l * d],
				[r.x - c * u, r.y - l * u]
			], p = 0;
			for (let e = 0; e < 4; e++) {
				let [t, n] = f[e], [r, i] = f[(e + 1) % 4];
				p += t * i - r * n;
			}
			p < 0 && (f = f.reverse()), t.push(`M${f.map(([e, t]) => `${ki(e)} ${ki(t)}`).join("L")}Z`);
		}
	}
	return t.join("");
}
function Mi(e) {
	let t = Infinity, n = Infinity, r = -Infinity, i = -Infinity;
	for (let a of e) for (let e of a.points) {
		let a = e.w / 2;
		t = Math.min(t, e.x - a), n = Math.min(n, e.y - a), r = Math.max(r, e.x + a), i = Math.max(i, e.y + a);
	}
	return r < t ? {
		x: 0,
		y: 0,
		width: 0,
		height: 0
	} : {
		x: t,
		y: n,
		width: r - t,
		height: i - n
	};
}
function Ni(e, t, n = 2, r = 0) {
	let { width: i, height: a, data: o } = e, s = new Uint8Array(i * a), c = Math.floor(t.x), l = Math.floor(t.y), u = {
		width: i,
		height: a,
		mask: s
	};
	if (c < 0 || l < 0 || c >= i || l >= a) return u;
	let d = new Uint8Array(i * a);
	for (let e = 0; e < i * a; e++) d[e] = +(o[e * 4 + 3] > 127);
	let f = Math.max(0, Math.round(r / 2));
	if (f && (d = Pi(d, i, a, f)), d[l * i + c]) return u;
	let p = [l * i + c];
	for (s[l * i + c] = 255; p.length;) {
		let e = p.pop(), t = e % i, n = (e - t) / i;
		for (let r of [
			t > 0 ? e - 1 : -1,
			t < i - 1 ? e + 1 : -1,
			n > 0 ? e - i : -1,
			n < a - 1 ? e + i : -1
		]) r >= 0 && !s[r] && !d[r] && (s[r] = 255, p.push(r));
	}
	let m = f + Math.max(0, Math.round(n));
	if (m) {
		let e = Pi(s, i, a, m);
		for (let t = 0; t < i * a; t++) s[t] = e[t] ? 255 : 0;
	}
	return u;
}
function Pi(e, t, n, r) {
	let i = new Uint8Array(t * n);
	for (let a = 0; a < n; a++) {
		let n = -Infinity;
		for (let o = 0; o < t; o++) e[a * t + o] && (n = o), o - n <= r && (i[a * t + o] = 1);
		n = Infinity;
		for (let o = t - 1; o >= 0; o--) e[a * t + o] && (n = o), n - o <= r && (i[a * t + o] = 1);
	}
	let a = new Uint8Array(t * n);
	for (let e = 0; e < t; e++) {
		let o = -Infinity;
		for (let s = 0; s < n; s++) i[s * t + e] && (o = s), s - o <= r && (a[s * t + e] = 1);
		o = Infinity;
		for (let s = n - 1; s >= 0; s--) i[s * t + e] && (o = s), o - s <= r && (a[s * t + e] = 1);
	}
	return a;
}
//#endregion
//#region ../canvas/src/geometry.ts
function Fi(e) {
	let t = Math.cos(e.rotation), n = Math.sin(e.rotation);
	return {
		a: t * e.scaleX,
		b: n * e.scaleX,
		c: -n * e.scaleY,
		d: t * e.scaleY,
		e: e.x,
		f: e.y
	};
}
function Ii(e) {
	let t = e.a * e.d - e.b * e.c;
	return t ? {
		a: e.d / t,
		b: -e.b / t,
		c: -e.c / t,
		d: e.a / t,
		e: (e.c * e.f - e.d * e.e) / t,
		f: (e.b * e.e - e.a * e.f) / t
	} : {
		a: 1,
		b: 0,
		c: 0,
		d: 1,
		e: -e.e,
		f: -e.f
	};
}
var Li = (e, t) => ({
	x: e.a * t.x + e.c * t.y + e.e,
	y: e.b * t.x + e.d * t.y + e.f
}), Ri = (e, t) => Li(Ii(Fi(e.transform)), t);
function zi(e, t) {
	switch (e.kind) {
		case "raster": {
			let n = t?.get(e.pixels);
			return {
				x: 0,
				y: 0,
				width: n?.width ?? 0,
				height: n?.height ?? 0
			};
		}
		case "text": return {
			x: e.align === "center" ? -e.box.width / 2 : e.align === "right" ? -e.box.width : 0,
			y: 0,
			...e.box
		};
		case "shape": {
			let t = e.shape, n = e.stroke ? e.strokeWidth / 2 : 0, r;
			return r = t.type === "rect" || t.type === "ellipse" ? {
				x: 0,
				y: 0,
				width: t.width,
				height: t.height
			} : t.type === "line" ? {
				x: Math.min(0, t.x2),
				y: Math.min(0, t.y2),
				width: Math.abs(t.x2),
				height: Math.abs(t.y2)
			} : t.type === "ink" ? Mi(t.strokes) : Hi(t.path), {
				x: r.x - n,
				y: r.y - n,
				width: r.width + n * 2,
				height: r.height + n * 2
			};
		}
	}
}
function Bi(e, t) {
	let n = zi(e, t), r = Fi(e.transform);
	return [
		{
			x: n.x,
			y: n.y
		},
		{
			x: n.x + n.width,
			y: n.y
		},
		{
			x: n.x + n.width,
			y: n.y + n.height
		},
		{
			x: n.x,
			y: n.y + n.height
		}
	].map((e) => Li(r, e));
}
function Vi(e, t, n) {
	for (let r = e.layers.length - 1; r >= 0; r--) {
		let i = e.layers[r];
		if (!i.visible || i.locked) continue;
		let a = Ri(i, n), o = zi(i, t);
		if (!(a.x < o.x || a.y < o.y || a.x >= o.x + o.width || a.y >= o.y + o.height)) {
			if (i.kind === "raster") {
				let e = t.get(i.pixels);
				if (e.data[(Math.floor(a.y) * e.width + Math.floor(a.x)) * 4 + 3] < 10) continue;
			}
			return i;
		}
	}
}
function Hi(e) {
	if (!e.points.length) return {
		x: 0,
		y: 0,
		width: 0,
		height: 0
	};
	let t = [], n = [];
	for (let r of e.points) t.push(r.x, r.x + (r.in?.x ?? 0), r.x + (r.out?.x ?? 0)), n.push(r.y, r.y + (r.in?.y ?? 0), r.y + (r.out?.y ?? 0));
	let r = Math.min(...t), i = Math.min(...n);
	return {
		x: r,
		y: i,
		width: Math.max(...t) - r,
		height: Math.max(...n) - i
	};
}
var J = (e) => Math.round(e * 100) / 100;
function Ui(e) {
	let t = e.points;
	if (!t.length) return "";
	let n = [`M${J(t[0].x)} ${J(t[0].y)}`], r = (e, t) => {
		if (!e.out && !t.in) return `L${J(t.x)} ${J(t.y)}`;
		let n = {
			x: e.x + (e.out?.x ?? 0),
			y: e.y + (e.out?.y ?? 0)
		}, r = {
			x: t.x + (t.in?.x ?? 0),
			y: t.y + (t.in?.y ?? 0)
		};
		return `C${J(n.x)} ${J(n.y)} ${J(r.x)} ${J(r.y)} ${J(t.x)} ${J(t.y)}`;
	};
	for (let e = 1; e < t.length; e++) n.push(r(t[e - 1], t[e]));
	if (e.closed && t.length > 2) {
		let e = t[t.length - 1], i = t[0];
		(e.out || i.in) && n.push(r(e, i)), n.push("Z");
	}
	return n.join(" ");
}
function Wi(e) {
	switch (e.type) {
		case "rect": {
			let { width: t, height: n } = e, r = Math.max(0, Math.min(e.radius, t / 2, n / 2));
			return r ? `M${J(r)} 0 H${J(t - r)} A${J(r)} ${J(r)} 0 0 1 ${J(t)} ${J(r)} V${J(n - r)} A${J(r)} ${J(r)} 0 0 1 ${J(t - r)} ${J(n)} H${J(r)} A${J(r)} ${J(r)} 0 0 1 0 ${J(n - r)} V${J(r)} A${J(r)} ${J(r)} 0 0 1 ${J(r)} 0 Z` : `M0 0 H${J(t)} V${J(n)} H0 Z`;
		}
		case "ellipse": {
			let t = e.width / 2, n = e.height / 2;
			return `M0 ${J(n)} A${J(t)} ${J(n)} 0 1 0 ${J(e.width)} ${J(n)} A${J(t)} ${J(n)} 0 1 0 0 ${J(n)} Z`;
		}
		case "line": return `M0 0 L${J(e.x2)} ${J(e.y2)}`;
		case "path": return Ui(e.path);
		case "ink": return ji(e.strokes);
	}
}
var Gi = (e, t = Math.PI / 12) => Math.round(e / t) * t, Ki = class {
	store;
	limit;
	past = [];
	future = [];
	current;
	constructor(e, t, n = 60) {
		this.store = t, this.limit = n, this.current = {
			doc: e,
			label: "Opened"
		};
	}
	get doc() {
		return this.current.doc;
	}
	get canUndo() {
		return this.past.length > 0;
	}
	get canRedo() {
		return this.future.length > 0;
	}
	list() {
		return {
			steps: [
				...this.past,
				this.current,
				...[...this.future].reverse()
			],
			at: this.past.length
		};
	}
	push(e, t) {
		e !== this.current.doc && (this.past.push(this.current), this.current = {
			doc: e,
			label: t
		}, this.future = [], this.past.length > this.limit && this.past.shift(), this.store.keepOnly([this.current.doc, ...this.past.map((e) => e.doc)]));
	}
	replace(e) {
		this.current = {
			...this.current,
			doc: e
		};
	}
	undo() {
		let e = this.past.pop();
		return e && (this.future.push(this.current), this.current = e), this.current.doc;
	}
	redo() {
		let e = this.future.pop();
		return e && (this.past.push(this.current), this.current = e), this.current.doc;
	}
	goTo(e) {
		for (; this.past.length > e && this.canUndo;) this.undo();
		for (; this.past.length < e && this.canRedo;) this.redo();
		return this.current.doc;
	}
}, qi = (e, t) => ({
	width: e,
	height: t,
	mask: new Uint8Array(e * t)
});
function Ji(e, t) {
	let n = qi(e, t);
	return n.mask.fill(255), n;
}
function Yi(e, t, n) {
	let r = qi(e, t), i = Math.max(0, Math.round(Math.min(n.x, n.x + n.width))), a = Math.min(e, Math.round(Math.max(n.x, n.x + n.width))), o = Math.max(0, Math.round(Math.min(n.y, n.y + n.height))), s = Math.min(t, Math.round(Math.max(n.y, n.y + n.height)));
	for (let t = o; t < s; t++) r.mask.fill(255, t * e + i, t * e + a);
	return r;
}
function Xi(e, t, n) {
	let r = qi(e, t), i = n.x + n.width / 2, a = n.y + n.height / 2, o = Math.abs(n.width / 2), s = Math.abs(n.height / 2);
	if (o < .5 || s < .5) return r;
	let c = Math.max(0, Math.floor(a - s)), l = Math.min(t, Math.ceil(a + s)), u = Math.max(0, Math.floor(i - o)), d = Math.min(e, Math.ceil(i + o));
	for (let t = c; t < l; t++) for (let n = u; n < d; n++) {
		let c = (n + .5 - i) / o, l = (t + .5 - a) / s, u = (1 - Math.sqrt(c * c + l * l)) * Math.min(o, s);
		u > 0 && (r.mask[t * e + n] = Math.round(255 * Math.min(1, u + .5)));
	}
	return r;
}
function Zi(e, t, n) {
	let r = qi(e, t);
	if (n.length < 3) return r;
	let i = n.map((e) => e.y), a = Math.max(0, Math.floor(Math.min(...i))), o = Math.min(t, Math.ceil(Math.max(...i))), s = [];
	for (let t = a; t < o; t++) {
		let i = t + .5;
		s.length = 0;
		for (let e = 0; e < n.length; e++) {
			let t = n[e], r = n[(e + 1) % n.length];
			t.y <= i != r.y <= i && s.push(t.x + (i - t.y) / (r.y - t.y) * (r.x - t.x));
		}
		s.sort((e, t) => e - t);
		for (let n = 0; n + 1 < s.length; n += 2) {
			let i = Math.max(0, Math.round(s[n])), a = Math.min(e, Math.round(s[n + 1]));
			a > i && r.mask.fill(255, t * e + i, t * e + a);
		}
	}
	return r;
}
function Qi(e, t, n) {
	if (!e || n === "replace") return t;
	let r = qi(t.width, t.height);
	for (let i = 0; i < r.mask.length; i++) {
		let a = e.mask[i], o = t.mask[i];
		r.mask[i] = n === "add" ? Math.max(a, o) : n === "subtract" ? Math.max(0, a - o) : Math.min(a, o);
	}
	return r;
}
function $i(e) {
	let t = qi(e.width, e.height);
	for (let n = 0; n < t.mask.length; n++) t.mask[n] = 255 - e.mask[n];
	return t;
}
function ea(e) {
	let t = e.width, n = e.height, r = -1, i = -1;
	for (let a = 0; a < e.height; a++) for (let o = 0; o < e.width; o++) e.mask[a * e.width + o] > 0 && (o < t && (t = o), o > r && (r = o), a < n && (n = a), a > i && (i = a));
	return r < 0 ? null : {
		x: t,
		y: n,
		width: r - t + 1,
		height: i - n + 1
	};
}
function ta(e, t) {
	let n = Math.round(t);
	if (n < 1) return e;
	let r = Float32Array.from(e.mask), i = new Float32Array(r.length), { width: a, height: o } = e;
	for (let e = 0; e < 3; e++) {
		for (let e = 0; e < o; e++) {
			let t = 0;
			for (let i = -n; i <= n; i++) t += r[e * a + Math.min(a - 1, Math.max(0, i))];
			for (let o = 0; o < a; o++) i[e * a + o] = t / (2 * n + 1), t += r[e * a + Math.min(a - 1, o + n + 1)] - r[e * a + Math.max(0, o - n)];
		}
		[r, i] = [i, r];
		for (let e = 0; e < a; e++) {
			let t = 0;
			for (let i = -n; i <= n; i++) t += r[Math.min(o - 1, Math.max(0, i)) * a + e];
			for (let s = 0; s < o; s++) i[s * a + e] = t / (2 * n + 1), t += r[Math.min(o - 1, s + n + 1) * a + e] - r[Math.max(0, s - n) * a + e];
		}
		[r, i] = [i, r];
	}
	let s = qi(a, o);
	for (let e = 0; e < s.mask.length; e++) s.mask[e] = Math.round(r[e]);
	return s;
}
function na(e, t, n, r = !0) {
	let { width: i, height: a, data: o } = e, s = qi(i, a), c = Math.floor(t.x), l = Math.floor(t.y);
	if (c < 0 || l < 0 || c >= i || l >= a) return s;
	let u = (l * i + c) * 4, d = [
		o[u],
		o[u + 1],
		o[u + 2],
		o[u + 3]
	], f = (e) => {
		let t = e * 4;
		return Math.max(Math.abs(o[t] - d[0]), Math.abs(o[t + 1] - d[1]), Math.abs(o[t + 2] - d[2]), Math.abs(o[t + 3] - d[3])) <= n;
	};
	if (!r) {
		for (let e = 0; e < i * a; e++) f(e) && (s.mask[e] = 255);
		return s;
	}
	let p = [l * i + c];
	for (s.mask[l * i + c] = 255; p.length;) {
		let e = p.pop(), t = e % i, n = (e - t) / i;
		for (let r of [
			t > 0 ? e - 1 : -1,
			t < i - 1 ? e + 1 : -1,
			n > 0 ? e - i : -1,
			n < a - 1 ? e + i : -1
		]) r >= 0 && !s.mask[r] && f(r) && (s.mask[r] = 255, p.push(r));
	}
	return s;
}
function ra(e) {
	let { width: t, height: n, mask: r } = e, i = new Uint8Array(t * n);
	for (let e = 0; e < n; e++) for (let a = 0; a < t; a++) {
		let o = e * t + a;
		r[o] < 128 || (a === 0 || e === 0 || a === t - 1 || e === n - 1 || r[o - 1] < 128 || r[o + 1] < 128 || r[o - t] < 128 || r[o + t] < 128) && (i[o] = 1);
	}
	return i;
}
//#endregion
//#region ../canvas/src/paint.ts
var ia = (e) => [
	parseInt(e.slice(1, 3), 16),
	parseInt(e.slice(3, 5), 16),
	parseInt(e.slice(5, 7), 16)
], aa = ([e, t, n]) => `#${[
	e,
	t,
	n
].map((e) => Math.round(Math.min(255, Math.max(0, e))).toString(16).padStart(2, "0")).join("")}`;
function oa(e, t, n, r) {
	let i = Math.max(.5, n.size / 2), a = Math.max(0, Math.floor(t.x - i)), o = Math.min(e.width, Math.ceil(t.x + i)), s = Math.max(0, Math.floor(t.y - i)), c = Math.min(e.height, Math.ceil(t.y + i));
	if (o <= a || c <= s) return null;
	let l = i * Math.min(.999, Math.max(0, n.hardness)), u = e.data;
	for (let d = s; d < c; d++) for (let s = a; s < o; s++) {
		let a = Math.hypot(s + .5 - t.x, d + .5 - t.y);
		if (a >= i) continue;
		let o = a <= l ? 1 : 1 - (a - l) / (i - l);
		if (o = o * o * (3 - 2 * o) * n.flow, r && (o *= r(s, d)), o <= 0) continue;
		let c = (d * e.width + s) * 4, f = u[c + 3] / 255;
		if (n.mode === "erase" || n.mode === "hide") u[c + 3] = f * (1 - o) * 255;
		else if (n.mode === "reveal") u[c + 3] = (f + (1 - f) * o) * 255;
		else {
			let e = o + f * (1 - o);
			for (let t = 0; t < 3; t++) u[c + t] = (n.color[t] * o + u[c + t] * f * (1 - o)) / e;
			u[c + 3] = e * 255;
		}
	}
	return {
		x: a,
		y: s,
		width: o - a,
		height: c - s
	};
}
var sa = () => ({
	last: null,
	carry: 0
}), ca = (e, t) => {
	if (!e) return t;
	if (!t) return e;
	let n = Math.min(e.x, t.x), r = Math.min(e.y, t.y);
	return {
		x: n,
		y: r,
		width: Math.max(e.x + e.width, t.x + t.width) - n,
		height: Math.max(e.y + e.height, t.y + t.height) - r
	};
};
function la(e, t, n, r) {
	if (!e.last) return e.last = t, e.carry = 0, r(t);
	let i = e.last, a = Math.hypot(t.x - i.x, t.y - i.y), o = null, s = n - e.carry;
	for (; s <= a;) o = ca(o, r({
		x: i.x + (t.x - i.x) * s / a,
		y: i.y + (t.y - i.y) * s / a
	})), s += n;
	return e.carry = a - (s - n), e.last = t, o;
}
var ua = (e) => Math.max(1, e * .12);
function da(e, t, n, r, i) {
	return la(t, n, ua(r.size), (t) => oa(e, t, r, i));
}
function fa(e, t, n, r, i = !0, a) {
	let { width: o, height: s, data: c } = e, l = Math.floor(t.x), u = Math.floor(t.y);
	if (l < 0 || u < 0 || l >= o || u >= s) return null;
	let d = (u * o + l) * 4, f = [
		c[d],
		c[d + 1],
		c[d + 2],
		c[d + 3]
	], p = (e) => {
		let t = e * 4;
		return Math.max(Math.abs(c[t] - f[0]), Math.abs(c[t + 1] - f[1]), Math.abs(c[t + 2] - f[2]), Math.abs(c[t + 3] - f[3])) <= r;
	}, m = new Uint8Array(o * s);
	if (i) {
		let e = [u * o + l];
		for (m[u * o + l] = 1; e.length;) {
			let t = e.pop(), n = t % o, r = (t - n) / o;
			for (let i of [
				n > 0 ? t - 1 : -1,
				n < o - 1 ? t + 1 : -1,
				r > 0 ? t - o : -1,
				r < s - 1 ? t + o : -1
			]) i >= 0 && !m[i] && p(i) && (m[i] = 1, e.push(i));
		}
	} else for (let e = 0; e < o * s; e++) p(e) && (m[e] = 1);
	let h = o, g = s, _ = -1, v = -1;
	for (let e = 0; e < o * s; e++) {
		if (!m[e]) continue;
		let t = e % o, r = (e - t) / o, i = a ? a(t, r) : 1;
		i <= 0 || (pa(c, e * 4, n, i), t < h && (h = t), t > _ && (_ = t), r < g && (g = r), r > v && (v = r));
	}
	return _ < 0 ? null : {
		x: h,
		y: g,
		width: _ - h + 1,
		height: v - g + 1
	};
}
function pa(e, t, n, r) {
	let i = e[t + 3] / 255, a = r + i * (1 - r);
	for (let o = 0; o < 3; o++) e[t + o] = (n[o] * r + e[t + o] * i * (1 - r)) / a;
	e[t + 3] = a * 255;
}
function ma(e, t, n) {
	for (let r = 0; r < e.height; r++) for (let i = 0; i < e.width; i++) {
		let a = n ? n(i, r) : 1;
		a > 0 && pa(e.data, (r * e.width + i) * 4, t, a);
	}
}
function ha(e, t) {
	for (let n = 0; n < e.height; n++) for (let r = 0; r < e.width; r++) {
		let i = t ? t(r, n) : 1, a = (n * e.width + r) * 4 + 3;
		i > 0 && (e.data[a] = e.data[a] * (1 - i));
	}
}
function ga(e, t) {
	let n = {
		width: e.width,
		height: e.height,
		data: new Uint8ClampedArray(e.data)
	};
	if (t) for (let r = 0; r < e.height; r++) for (let i = 0; i < e.width; i++) {
		let a = (r * e.width + i) * 4 + 3;
		n.data[a] = n.data[a] * t(i, r);
	}
	return n;
}
function _a(e, t, n, r, i, a) {
	let o = n.x - t.x, s = n.y - t.y, c = o * o + s * s || 1;
	for (let n = 0; n < e.height; n++) for (let l = 0; l < e.width; l++) {
		let u = a ? a(l, n) : 1;
		if (u <= 0) continue;
		let d = Math.min(1, Math.max(0, ((l + .5 - t.x) * o + (n + .5 - t.y) * s) / c));
		pa(e.data, (n * e.width + l) * 4, [
			r[0] + (i[0] - r[0]) * d,
			r[1] + (i[1] - r[1]) * d,
			r[2] + (i[2] - r[2]) * d
		], u);
	}
}
function va(e, t) {
	let n = Math.floor(t.x), r = Math.floor(t.y);
	if (n < 0 || r < 0 || n >= e.width || r >= e.height) return null;
	let i = (r * e.width + n) * 4;
	return [
		e.data[i],
		e.data[i + 1],
		e.data[i + 2]
	];
}
function ya(e, t, n, r, i, a) {
	let o = Math.max(.5, i.size / 2), s = Math.max(0, Math.floor(n.x - o)), c = Math.min(e.width, Math.ceil(n.x + o)), l = Math.max(0, Math.floor(n.y - o)), u = Math.min(e.height, Math.ceil(n.y + o));
	if (c <= s || u <= l) return null;
	let d = o * Math.min(.999, Math.max(0, i.hardness));
	for (let f = l; f < u; f++) for (let l = s; l < c; l++) {
		let s = Math.floor(l + r.x), c = Math.floor(f + r.y);
		if (s < 0 || c < 0 || s >= t.width || c >= t.height) continue;
		let u = Math.hypot(l + .5 - n.x, f + .5 - n.y);
		if (u >= o) continue;
		let p = u <= d ? 1 : 1 - (u - d) / (o - d);
		p = p * p * (3 - 2 * p) * i.flow * (a ? a(l, f) : 1);
		let m = (c * t.width + s) * 4, h = t.data[m + 3] / 255 * p;
		h <= 0 || pa(e.data, (f * e.width + l) * 4, [
			t.data[m],
			t.data[m + 1],
			t.data[m + 2]
		], h);
	}
	return {
		x: s,
		y: l,
		width: c - s,
		height: u - l
	};
}
//#endregion
//#region ../canvas/src/adjust.ts
function ba(e, t, n) {
	let r = {
		width: e.width,
		height: e.height,
		data: new Uint8ClampedArray(e.data)
	}, i = r.data;
	for (let r = 0; r < e.height; r++) for (let a = 0; a < e.width; a++) {
		let o = (r * e.width + a) * 4;
		if (!i[o + 3]) continue;
		let s = t ? t(a, r) : 1;
		if (s <= 0) continue;
		let [c, l, u] = n(i[o], i[o + 1], i[o + 2]);
		i[o] = i[o] + (c - i[o]) * s, i[o + 1] = i[o + 1] + (l - i[o + 1]) * s, i[o + 2] = i[o + 2] + (u - i[o + 2]) * s;
	}
	return r;
}
var xa = (e, t) => ba(e, t, (e, t, n) => [
	255 - e,
	255 - t,
	255 - n
]), Sa = (e, t) => ba(e, t, (e, t, n) => {
	let r = .2126 * e + .7152 * t + .0722 * n;
	return [
		r,
		r,
		r
	];
});
function Ca(e, t, n, r) {
	let i = Math.tan((Math.max(-99, Math.min(99, n)) / 100 + 1) * Math.PI / 4), a = t * 1.28;
	return ba(e, r, (e, t, n) => [
		e,
		t,
		n
	].map((e) => (e + a - 128) * i + 128));
}
function wa(e, t, n, r, i) {
	return ba(e, i, (e, i, a) => {
		let [o, s, c] = Pa(e, i, a);
		return o = (o + t + 360) % 360, s = Math.min(1, Math.max(0, s * (1 + n / 100))), c = r >= 0 ? c + (1 - c) * (r / 100) : c * (1 + r / 100), Fa(o, s, c);
	});
}
var Ta = (e, t, n) => ba(e, n, (e, n, r) => [
	t[e],
	t[n],
	t[r]
]);
function Ea(e, t, n, r, i, a, o) {
	let s = Math.min(t, n - 1), c = Math.max(n, s + 1), l = /* @__PURE__ */ new Uint8ClampedArray(256);
	for (let e = 0; e < 256; e++) {
		let t = Math.min(1, Math.max(0, (e - s) / (c - s)));
		l[e] = i + (a - i) * t ** (1 / Math.max(.01, r));
	}
	return Ta(e, l, o);
}
function Da(e, t, n, r, i) {
	let a = [
		0,
		64,
		128,
		192,
		255
	], o = [
		0,
		64 + t * .64,
		128 + n * .64,
		192 + r * .64,
		255
	].map((e) => Math.min(255, Math.max(0, e)));
	for (let e = 1; e < o.length; e++) o[e] = Math.max(o[e], o[e - 1]);
	let s = a.length, c = a.slice(1).map((e, t) => e - a[t]), l = o.slice(1).map((e, t) => (e - o[t]) / c[t]), u = a.map((e, t) => t === 0 ? l[0] : t === s - 1 ? l[s - 2] : l[t - 1] * l[t] <= 0 ? 0 : (l[t - 1] + l[t]) / 2);
	for (let e = 0; e < s - 1; e++) {
		if (l[e] === 0) {
			u[e] = u[e + 1] = 0;
			continue;
		}
		let t = u[e] / l[e], n = u[e + 1] / l[e], r = Math.hypot(t, n);
		r > 3 && (u[e] = 3 * t * l[e] / r, u[e + 1] = 3 * n * l[e] / r);
	}
	let d = /* @__PURE__ */ new Uint8ClampedArray(256);
	for (let e = 0; e < 256; e++) {
		let t = 0;
		for (; t < s - 2 && e > a[t + 1];) t++;
		let n = (e - a[t]) / c[t], r = 2 * n ** 3 - 3 * n ** 2 + 1, i = n ** 3 - 2 * n ** 2 + n, l = -2 * n ** 3 + 3 * n ** 2, f = n ** 3 - n ** 2;
		d[e] = r * o[t] + i * c[t] * u[t] + l * o[t + 1] + f * c[t] * u[t + 1];
	}
	return Ta(e, d, i);
}
function Oa(e, t, n) {
	let r = t / 100;
	return ba(e, n, (e, t, n) => {
		let i = Math.max(e, t, n), a = (e + t + n) / 3, o = i ? (i - Math.min(e, t, n)) / i : 0, s = 1 + r * (1 - o) * 1.5;
		return [
			a + (e - a) * s,
			a + (t - a) * s,
			a + (n - a) * s
		];
	});
}
function ka(e, t, n, r) {
	let i = t * .3, a = n * .3;
	return ba(e, r, (e, t, n) => [
		e + i + a * .5,
		t - a,
		n - i + a * .5
	]);
}
function Aa(e, t, n) {
	let r = Math.max(2, Math.round(t)), i = /* @__PURE__ */ new Uint8ClampedArray(256);
	for (let e = 0; e < 256; e++) i[e] = Math.round(e / 255 * (r - 1)) / (r - 1) * 255;
	return Ta(e, i, n);
}
function ja(e, t, n) {
	return ba(e, n, (e, n, r) => {
		let i = .2126 * e + .7152 * n + .0722 * r >= t ? 255 : 0;
		return [
			i,
			i,
			i
		];
	});
}
function Ma(e, t, n) {
	let r = Math.round(t);
	if (r < 1) return {
		...e,
		data: new Uint8ClampedArray(e.data)
	};
	let { width: i, height: a } = e, o = new Float32Array(i * a * 4);
	for (let t = 0; t < i * a; t++) {
		let n = e.data[t * 4 + 3] / 255;
		o[t * 4] = e.data[t * 4] * n, o[t * 4 + 1] = e.data[t * 4 + 1] * n, o[t * 4 + 2] = e.data[t * 4 + 2] * n, o[t * 4 + 3] = e.data[t * 4 + 3];
	}
	let s = new Float32Array(o.length), c = 2 * r + 1;
	for (let e = 0; e < 3; e++) {
		for (let e = 0; e < a; e++) for (let t = 0; t < 4; t++) {
			let n = 0;
			for (let a = -r; a <= r; a++) n += o[(e * i + Math.min(i - 1, Math.max(0, a))) * 4 + t];
			for (let a = 0; a < i; a++) s[(e * i + a) * 4 + t] = n / c, n += o[(e * i + Math.min(i - 1, a + r + 1)) * 4 + t] - o[(e * i + Math.max(0, a - r)) * 4 + t];
		}
		[o, s] = [s, o];
		for (let e = 0; e < i; e++) for (let t = 0; t < 4; t++) {
			let n = 0;
			for (let s = -r; s <= r; s++) n += o[(Math.min(a - 1, Math.max(0, s)) * i + e) * 4 + t];
			for (let l = 0; l < a; l++) s[(l * i + e) * 4 + t] = n / c, n += o[(Math.min(a - 1, l + r + 1) * i + e) * 4 + t] - o[(Math.max(0, l - r) * i + e) * 4 + t];
		}
		[o, s] = [s, o];
	}
	let l = {
		width: i,
		height: a,
		data: new Uint8ClampedArray(e.data)
	};
	for (let t = 0; t < a; t++) for (let r = 0; r < i; r++) {
		let a = n ? n(r, t) : 1;
		if (a <= 0) continue;
		let s = (t * i + r) * 4, c = o[s + 3], u = c > 0 ? 255 / c : 0;
		for (let t = 0; t < 3; t++) l.data[s + t] = e.data[s + t] + (o[s + t] * u - e.data[s + t]) * a;
		l.data[s + 3] = e.data[s + 3] + (c - e.data[s + 3]) * a;
	}
	return l;
}
function Na(e, t, n = 1, r) {
	let i = Ma(e, n), a = {
		width: e.width,
		height: e.height,
		data: new Uint8ClampedArray(e.data)
	};
	for (let n = 0; n < e.height; n++) for (let o = 0; o < e.width; o++) {
		let s = r ? r(o, n) : 1;
		if (s <= 0) continue;
		let c = (n * e.width + o) * 4;
		for (let n = 0; n < 3; n++) a.data[c + n] = e.data[c + n] + (e.data[c + n] - i.data[c + n]) * t * s;
	}
	return a;
}
function Pa(e, t, n) {
	e /= 255, t /= 255, n /= 255;
	let r = Math.max(e, t, n), i = Math.min(e, t, n), a = (r + i) / 2;
	if (r === i) return [
		0,
		0,
		a
	];
	let o = r - i, s = a > .5 ? o / (2 - r - i) : o / (r + i);
	return [
		r === e ? ((t - n) / o + (t < n ? 6 : 0)) * 60 : r === t ? ((n - e) / o + 2) * 60 : ((e - t) / o + 4) * 60,
		s,
		a
	];
}
function Fa(e, t, n) {
	let r = (1 - Math.abs(2 * n - 1)) * t, i = e / 60, a = r * (1 - Math.abs(i % 2 - 1)), [o, s, c] = i < 1 ? [
		r,
		a,
		0
	] : i < 2 ? [
		a,
		r,
		0
	] : i < 3 ? [
		0,
		r,
		a
	] : i < 4 ? [
		0,
		a,
		r
	] : i < 5 ? [
		a,
		0,
		r
	] : [
		r,
		0,
		a
	], l = n - r / 2;
	return [
		(o + l) * 255,
		(s + l) * 255,
		(c + l) * 255
	];
}
//#endregion
//#region ../canvas/src/render.ts
var Ia = (e) => `${e.italic ? "italic " : ""}${e.weight} ${e.size}px ${e.font}`;
function La(e, t) {
	e.font = Ia(t);
	let n = t.text.split("\n");
	return {
		width: Math.ceil(Math.max(1, ...n.map((t) => e.measureText(t).width))),
		height: Math.ceil(n.length * t.size * t.lineHeight)
	};
}
function Ra(e, t, n) {
	if (t.kind === "raster") {
		let r = n.image(t.pixels);
		r && e.drawImage(r, 0, 0);
		return;
	}
	if (t.kind === "text") {
		e.font = Ia(t), e.fillStyle = t.color, e.textAlign = t.align, e.textBaseline = "top";
		let n = t.size * t.lineHeight, r = (n - t.size) / 2;
		t.text.split("\n").forEach((t, i) => e.fillText(t, 0, i * n + r));
		return;
	}
	let r = n.path(Wi(t.shape));
	t.fill && t.shape.type !== "line" && (e.fillStyle = t.fill, e.fill(r, t.shape.type === "ink" ? "nonzero" : "evenodd")), t.stroke && t.strokeWidth > 0 && (e.strokeStyle = t.stroke, e.lineWidth = t.strokeWidth, e.lineJoin = "round", e.lineCap = "round", e.stroke(r));
}
var za = (e, t) => {
	let n = Fi(t.transform);
	e.transform(n.a, n.b, n.c, n.d, n.e, n.f);
}, Ba = (e) => !!(e && (e.shadow || e.glow || e.stroke)), Va = (e, t) => {
	let n = parseInt(e.slice(1), 16);
	return `rgba(${n >> 16 & 255}, ${n >> 8 & 255}, ${n & 255}, ${Math.max(0, Math.min(1, t))})`;
};
function Ha(e, t, n, r, i) {
	let a = (e, n) => {
		let a = i.surface(r.width, r.height, 2);
		return a.ctx.drawImage(t, 0, 0), a.ctx.globalCompositeOperation = "source-in", a.ctx.fillStyle = Va(e, n), a.ctx.fillRect(0, 0, r.width, r.height), a.ctx.globalCompositeOperation = "source-over", a.canvas;
	}, o = (t, n, r, i) => {
		e.save(), n > 0 && (e.filter = `blur(${n / 2}px)`), e.drawImage(t, r, i), e.restore();
	};
	if (n.shadow && n.shadow.opacity > 0) {
		let e = n.shadow.angle * Math.PI / 180;
		o(a(n.shadow.color, n.shadow.opacity), n.shadow.blur, -Math.cos(e) * n.shadow.distance, Math.sin(e) * n.shadow.distance);
	}
	if (n.glow && n.glow.opacity > 0 && n.glow.size > 0) {
		let e = a(n.glow.color, n.glow.opacity);
		for (let t = 0; t < 2; t++) o(e, n.glow.size, 0, 0);
	}
	if (n.stroke && n.stroke.width > 0) {
		let t = a(n.stroke.color, 1), r = n.stroke.width;
		for (let n = Math.min(1, r); n <= r; n += Math.max(1, r / 4)) {
			let r = Math.max(8, Math.ceil(n * 3));
			for (let i = 0; i < r; i++) e.drawImage(t, Math.cos(i / r * 2 * Math.PI) * n, Math.sin(i / r * 2 * Math.PI) * n);
		}
	}
}
function Ua(e, t, n, r) {
	let i = n.mask && !n.maskOff ? r.image(n.mask) : void 0, a = Ba(n.style) ? n.style : void 0;
	if (e.save(), e.globalAlpha = n.opacity, e.globalCompositeOperation = n.blend === "normal" ? "source-over" : n.blend, !i && !a) za(e, n), Ra(e, n, r);
	else {
		let o = r.surface(t.width, t.height, 0);
		if (o.ctx.save(), za(o.ctx, n), Ra(o.ctx, n, r), o.ctx.restore(), i && (o.ctx.globalCompositeOperation = "destination-in", o.ctx.drawImage(i, 0, 0), o.ctx.globalCompositeOperation = "source-over"), !a) e.drawImage(o.canvas, 0, 0);
		else {
			let n = r.surface(t.width, t.height, 1);
			Ha(n.ctx, o.canvas, a, t, r), n.ctx.drawImage(o.canvas, 0, 0), e.drawImage(n.canvas, 0, 0);
		}
	}
	e.restore();
}
function Wa(e, t, n, r = {}) {
	r.background !== !1 && t.background && (e.save(), e.fillStyle = t.background, e.fillRect(0, 0, t.width, t.height), e.restore());
	for (let i of t.layers) i.visible && !r.hide?.has(i.id) && Ua(e, t, i, n);
}
//#endregion
//#region ../canvas/src/files.ts
var Ga = (e) => e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"), Ka = (e) => String(Math.round(e * 1e3) / 1e3);
function qa(e, t) {
	let n = [], r = [];
	e.background && r.push(`<rect width="${e.width}" height="${e.height}" fill="${e.background}"/>`);
	for (let i of e.layers) {
		if (!i.visible) continue;
		let a = Fi(i.transform), o = [
			`transform="matrix(${[
				a.a,
				a.b,
				a.c,
				a.d,
				a.e,
				a.f
			].map(Ka).join(" ")})"`,
			i.opacity < 1 ? `opacity="${Ka(i.opacity)}"` : "",
			i.blend === "normal" ? "" : `style="mix-blend-mode:${i.blend}"`
		], s = "";
		if (i.mask && !i.maskOff) {
			let r = `m-${n.length}`;
			n.push(`<mask id="${r}" maskUnits="userSpaceOnUse" x="0" y="0" width="${e.width}" height="${e.height}" style="mask-type:alpha"><image href="${t(i.mask)}" width="${e.width}" height="${e.height}"/></mask>`), s = ` mask="url(#${r})"`;
		}
		let c = "";
		if (i.style && (i.style.shadow || i.style.glow || i.style.stroke)) {
			let e = `f-${n.length}`;
			n.push(Ja(e, i.style)), c = ` filter="url(#${e})"`;
		}
		r.push(`<g${s}${c}><g ${o.filter(Boolean).join(" ")}>${Ya(i, t)}</g></g>`);
	}
	return `<svg xmlns="http://www.w3.org/2000/svg" width="${e.width}" height="${e.height}" viewBox="0 0 ${e.width} ${e.height}">${n.length ? `<defs>${n.join("")}</defs>` : ""}${r.join("")}</svg>`;
}
function Ja(e, t) {
	let n = [], r = [];
	if (t.shadow && t.shadow.opacity > 0) {
		let e = t.shadow.angle * Math.PI / 180;
		n.push(`<feGaussianBlur in="SourceAlpha" stdDeviation="${Ka(t.shadow.blur / 2)}" result="sb"/><feOffset in="sb" dx="${Ka(-Math.cos(e) * t.shadow.distance)}" dy="${Ka(Math.sin(e) * t.shadow.distance)}" result="so"/><feFlood flood-color="${t.shadow.color}" flood-opacity="${Ka(t.shadow.opacity)}"/><feComposite in2="so" operator="in" result="shadow"/>`), r.push("shadow");
	}
	return t.glow && t.glow.opacity > 0 && (n.push(`<feGaussianBlur in="SourceAlpha" stdDeviation="${Ka(t.glow.size / 2)}" result="gb"/><feFlood flood-color="${t.glow.color}" flood-opacity="${Ka(Math.min(1, t.glow.opacity * 1.6))}"/><feComposite in2="gb" operator="in" result="glow"/>`), r.push("glow")), t.stroke && t.stroke.width > 0 && (n.push(`<feMorphology in="SourceAlpha" operator="dilate" radius="${Ka(t.stroke.width)}" result="sd"/><feFlood flood-color="${t.stroke.color}"/><feComposite in2="sd" operator="in" result="stroke"/>`), r.push("stroke")), `<filter id="${e}" x="-50%" y="-50%" width="200%" height="200%" color-interpolation-filters="sRGB">${n.join("")}<feMerge>${r.map((e) => `<feMergeNode in="${e}"/>`).join("")}<feMergeNode in="SourceGraphic"/></feMerge></filter>`;
}
function Ya(e, t) {
	if (e.kind === "raster") return `<image href="${t(e.pixels)}"/>`;
	if (e.kind === "text") {
		let t = e.align === "center" ? "middle" : e.align === "right" ? "end" : "start", n = e.size * e.lineHeight, r = Ga(Ia(e));
		return e.text.split("\n").map((i, a) => `<text x="0" y="${Ka(a * n + (n - e.size) / 2 + e.size * .8)}" style="font:${r}" fill="${e.color}" text-anchor="${t}" xml:space="preserve">${Ga(i)}</text>`).join("");
	}
	let n = e.fill && e.shape.type !== "line" ? e.fill : "none", r = e.stroke && e.strokeWidth > 0 ? ` stroke="${e.stroke}" stroke-width="${Ka(e.strokeWidth)}" stroke-linejoin="round" stroke-linecap="round"` : "";
	return `<path d="${Wi(e.shape)}" fill="${n}" fill-rule="${e.shape.type === "ink" ? "nonzero" : "evenodd"}"${r}/>`;
}
function Xa(e, t) {
	let n = {};
	for (let r of li(e)) n[r] = t(r);
	return {
		format: "gleamshelf-canvas",
		version: 1,
		doc: e,
		pixels: n
	};
}
async function Za(e, t) {
	let n = e;
	if (!n || n.format !== "gleamshelf-canvas" || n.version !== 1 || !n.doc || !Array.isArray(n.doc.layers)) throw Error("That is not a Gleamshelf design file.");
	let r = new ci();
	for (let e of li(n.doc)) {
		let i = n.pixels?.[e];
		if (typeof i != "string") throw Error("The design file is missing one of its pictures.");
		r.set(e, await t(i));
	}
	return {
		doc: n.doc,
		store: r
	};
}
//#endregion
//#region ../canvas/src/psd.ts
var Qa = {
	normal: "norm",
	multiply: "mul ",
	screen: "scrn",
	overlay: "over",
	darken: "dark",
	lighten: "lite",
	"color-dodge": "div ",
	"color-burn": "idiv",
	"hard-light": "hLit",
	"soft-light": "sLit",
	difference: "diff",
	exclusion: "smud",
	hue: "hue ",
	saturation: "sat ",
	color: "colr",
	luminosity: "lum "
}, $a = class {
	buf = /* @__PURE__ */ new Uint8Array(65536);
	length = 0;
	room(e) {
		if (this.length + e <= this.buf.length) return;
		let t = this.buf.length * 2;
		for (; t < this.length + e;) t *= 2;
		let n = new Uint8Array(t);
		n.set(this.buf.subarray(0, this.length)), this.buf = n;
	}
	u8(e) {
		this.room(1), this.buf[this.length++] = e & 255;
	}
	u16(e) {
		this.u8(e >>> 8), this.u8(e);
	}
	u32(e) {
		this.u16(e >>> 16), this.u16(e);
	}
	ascii(e) {
		for (let t = 0; t < e.length; t++) this.u8(e.charCodeAt(t));
	}
	bytes(e) {
		this.room(e.length), this.buf.set(e, this.length), this.length += e.length;
	}
	mark() {
		let e = this.length;
		return this.u32(0), () => {
			let t = this.length - e - 4;
			this.buf.set([
				t >>> 24,
				t >>> 16 & 255,
				t >>> 8 & 255,
				t & 255
			], e);
		};
	}
	done() {
		return this.buf.slice(0, this.length);
	}
};
function eo(e) {
	let t = [], n = 0;
	for (; n < e.length;) {
		let r = 1;
		for (; n + r < e.length && r < 128 && e[n + r] === e[n];) r++;
		if (r > 1) {
			t.push(257 - r, e[n]), n += r;
			continue;
		}
		let i = n;
		for (; n < e.length && n - i < 128 && !(n + 1 < e.length && e[n + 1] === e[n]);) n++;
		n === i && n++, t.push(n - i - 1);
		for (let r = i; r < n; r++) t.push(e[r]);
	}
	return Uint8Array.from(t);
}
function to(e, t, n, r, i, a) {
	let o = [], s = new Uint8Array(i);
	for (let c = r; c < r + a; c++) {
		for (let r = 0; r < i; r++) s[r] = e.data[(c * e.width + n + r << 2) + t];
		o.push(eo(s));
	}
	return o;
}
function no(e) {
	let [t, n, r, i] = [
		e.width,
		e.height,
		-1,
		-1
	];
	for (let a = 0; a < e.height; a++) for (let o = 0; o < e.width; o++) e.data[(a * e.width + o << 2) + 3] > 0 && (o < t && (t = o), o > r && (r = o), a < n && (n = a), a > i && (i = a));
	return r < 0 ? null : {
		x: t,
		y: n,
		w: r - t + 1,
		h: i - n + 1
	};
}
function ro(e) {
	let t = new $a();
	t.u16(1);
	for (let n of e) t.u16(n.length);
	for (let n of e) t.bytes(n);
	return t.done();
}
function io(e, t, n, r) {
	let i = new $a();
	i.ascii("8BPS"), i.u16(1);
	for (let e = 0; e < 6; e++) i.u8(0);
	i.u16(4), i.u32(t), i.u32(e), i.u16(8), i.u16(3), i.u32(0), i.u32(0);
	let a = i.mark(), o = i.mark();
	i.u16(-n.length & 65535);
	let s = [];
	for (let e of n) {
		let t = no(e.pixels), n = [
			3,
			0,
			1,
			2
		].map((n) => ro(t ? to(e.pixels, n, t.x, t.y, t.w, t.h) : []));
		s.push(n), i.u32(t ? t.y : 0), i.u32(t ? t.x : 0), i.u32(t ? t.y + t.h : 0), i.u32(t ? t.x + t.w : 0), i.u16(4), [
			-1,
			0,
			1,
			2
		].forEach((e, t) => {
			i.u16(e & 65535), i.u32(n[t].length);
		}), i.ascii("8BIM"), i.ascii(Qa[e.blend] ?? "norm"), i.u8(Math.round(Math.max(0, Math.min(1, e.opacity)) * 255)), i.u8(0), i.u8(e.hidden ? 2 : 0), i.u8(0);
		let r = i.mark();
		i.u32(0), i.u32(0);
		let a = [...e.name.slice(0, 255)].map((e) => e.charCodeAt(0) < 256 ? e : "?").join("");
		i.u8(a.length), i.ascii(a);
		for (let e = a.length + 1; e % 4; e++) i.u8(0);
		i.ascii("8BIMluni");
		let o = e.name, c = 4 + o.length * 2, l = c + (4 - c % 4) % 4;
		i.u32(l), i.u32(o.length);
		for (let e = 0; e < o.length; e++) i.u16(o.charCodeAt(e));
		for (let e = c; e < l; e++) i.u8(0);
		r();
	}
	for (let e of s) for (let t of e) i.bytes(t);
	i.length % 2 && i.u8(0), o(), i.u32(0), a(), i.u16(1);
	let c = [
		0,
		1,
		2,
		3
	].map((n) => to(r, n, 0, 0, e, t));
	for (let e of c) for (let t of e) i.u16(t.length);
	for (let e of c) for (let t of e) i.bytes(t);
	return i.done();
}
//#endregion
//#region ../canvas/src/commands.ts
var ao = class {
	backend;
	history;
	store;
	selection = null;
	selectedId = null;
	colours = {
		main: "#1a1a1a",
		second: "#ffffff"
	};
	clipboard = null;
	dry = !1;
	preview = null;
	constructor(e, t, n = new ci()) {
		this.backend = e, this.store = n, this.history = new Ki(t, n), this.selectedId = t.layers[t.layers.length - 1]?.id ?? null;
	}
	get doc() {
		return this.preview ?? this.history.doc;
	}
	get selected() {
		return this.selectedId ? hi(this.doc, this.selectedId) : void 0;
	}
	commit(e, t) {
		this.dry ? this.preview = e : this.history.push(e, t);
	}
	replace(e, t = new ci()) {
		this.store = t, this.history = new Ki(e, t), this.selection = null, this.selectedId = e.layers[e.layers.length - 1]?.id ?? null, this.clipboard = null, this.preview = null;
	}
	host() {
		return {
			image: (e) => {
				let t = this.store.get(e);
				return t ? this.backend.image(e, t) : void 0;
			},
			surface: (e, t) => {
				let n = this.backend.surface(e, t);
				return {
					ctx: n.ctx,
					canvas: n.canvas
				};
			},
			path: (e) => this.backend.path(e)
		};
	}
	flatten(e = this.doc, t = !0) {
		let n = this.backend.surface(e.width, e.height);
		return Wa(n.ctx, e, this.host(), { background: t }), n.read();
	}
}, Y = class extends Error {};
function oo(e) {
	if (typeof e != "string") {
		if (e && typeof e == "object") return e;
		throw new Y("The 3D design is missing.");
	}
	try {
		let t = JSON.parse(e);
		if (!t || typeof t != "object" || !Array.isArray(t.shapes)) throw new Y("That is not a 3D design (it has no shapes).");
		return t;
	} catch (e) {
		throw e instanceof Y ? e : new Y("The 3D design is not valid JSON.");
	}
}
var X = {
	name: "layer",
	type: "string",
	label: "Layer",
	description: "The layer, by id or name (the picked layer when left out).",
	optional: !0
}, so = {
	name: "mode",
	type: "enum",
	label: "Combine",
	options: [
		"replace",
		"add",
		"subtract",
		"intersect"
	],
	default: "replace",
	description: "How the new selection combines with the current one."
};
function Z(e, t) {
	let n = e.doc;
	if (t) {
		let e = hi(n, t) ?? [...n.layers].reverse().find((e) => e.name === t);
		if (!e) throw new Y(`There is no layer called "${t}".`);
		return e;
	}
	let r = e.selected;
	if (!r) throw new Y("Pick a layer first.");
	return r;
}
var co = (e) => {
	if (e.locked) throw new Y(`"${e.name}" is locked.`);
	return e;
}, lo = (e) => {
	if (e.kind !== "raster") throw new Y(`"${e.name}" is a ${e.kind} layer. Rasterize it first to change its pixels.`);
	return co(e);
};
function uo(e, t) {
	let n = e.selection;
	if (!n) return;
	let { width: r, height: i, mask: a } = n;
	if (!t) return (e, t) => e >= 0 && t >= 0 && e < r && t < i ? a[t * r + e] / 255 : 0;
	let o = Fi(t.transform);
	return (e, t) => {
		let n = Li(o, {
			x: e + .5,
			y: t + .5
		}), s = Math.floor(n.x), c = Math.floor(n.y);
		return s >= 0 && c >= 0 && s < r && c < i ? a[c * r + s] / 255 : 0;
	};
}
function fo(e, t) {
	let n = t ? Z(e, t) : e.selected;
	if (n?.kind === "raster") return {
		doc: e.doc,
		layer: lo(n)
	};
	let r = fi("Paint", e.store.add(oi(e.doc.width, e.doc.height)));
	return e.selectedId = r.id, {
		doc: gi(e.doc, r, n?.id),
		layer: r
	};
}
function po(e, t, n) {
	let r = si(e.store.get(n.pixels)), i = e.store.add(r);
	return {
		doc: q(t, n.id, { pixels: i }),
		working: r,
		layer: {
			...n,
			pixels: i
		}
	};
}
var mo = (e, t) => (e.selection = ea(t) ? t : null, { message: e.selection ? void 0 : "Nothing is selected." });
function ho(e, t) {
	let n = e.backend.surface(e.doc.width, e.doc.height);
	return Ua(n.ctx, e.doc, {
		...t,
		opacity: 1,
		blend: "normal",
		mask: void 0
	}, e.host()), n.read();
}
function go(e) {
	let t = e.doc.layers.filter((e) => e.visible && e.kind === "shape" && e.shape.type === "ink");
	if (!t.length) return null;
	let n = e.backend.surface(e.doc.width, e.doc.height);
	for (let r of t) Ua(n.ctx, e.doc, {
		...r,
		opacity: 1,
		blend: "normal",
		mask: void 0
	}, e.host());
	return n.read();
}
function _o(e) {
	return pi("Ink", {
		type: "ink",
		strokes: []
	}, {
		fill: e,
		stroke: null,
		strokeWidth: 0
	});
}
var vo = (e, t) => La(e.backend.surface(1, 1).ctx, {
	...t,
	text: t.text || " "
}), yo = (e, t, n) => {
	let r = Li(Fi(e), n), i = Li(Fi({
		...t,
		x: 0,
		y: 0
	}), n);
	return {
		...t,
		x: r.x - i.x,
		y: r.y - i.y
	};
}, bo = (e) => e.map((e) => Array.isArray(e) ? {
	x: Number(e[0]),
	y: Number(e[1])
} : {
	x: Number(e.x),
	y: Number(e.y)
});
function xo(e) {
	let t = e.doc, n = e.selection ? ea(e.selection) : null;
	return {
		width: t.width,
		height: t.height,
		background: t.background,
		picked: e.selectedId,
		selection: n,
		colours: e.colours,
		canUndo: e.history.canUndo,
		canRedo: e.history.canRedo,
		layers: [...t.layers].reverse().map((t) => {
			let n = zi(t, e.store), r = {
				id: t.id,
				name: t.name,
				kind: t.kind,
				visible: t.visible,
				locked: t.locked,
				opacity: t.opacity,
				blend: t.blend,
				x: Math.round(t.transform.x * 10) / 10,
				y: Math.round(t.transform.y * 10) / 10,
				width: Math.round(n.width * Math.abs(t.transform.scaleX)),
				height: Math.round(n.height * Math.abs(t.transform.scaleY)),
				rotation: Math.round(t.transform.rotation * 180 / Math.PI * 10) / 10,
				mask: t.mask ? t.maskOff ? "off" : "on" : null
			};
			return t.kind === "text" ? {
				...r,
				text: t.text,
				font: t.font,
				size: t.size,
				color: t.color
			} : t.kind === "shape" ? {
				...r,
				shape: t.shape.type,
				fill: t.fill,
				stroke: t.stroke,
				strokeWidth: t.strokeWidth
			} : r;
		})
	};
}
var Q = (e, t, n, r, i, a = {}) => ({
	name: t,
	label: e,
	type: "number",
	min: n,
	max: r,
	default: i,
	...a
}), $ = (e, t, n, r = {}) => ({
	name: t,
	label: e,
	type: "color",
	default: n,
	...r
}), So = (e) => e.colours.main, Co = [
	{
		id: "undo",
		label: "Undo",
		menu: "Edit",
		keys: "Ctrl Z",
		description: "Undo the last change.",
		blocked: (e) => e.history.canUndo ? null : "Nothing to undo.",
		run: (e) => void e.history.undo()
	},
	{
		id: "redo",
		label: "Redo",
		menu: "Edit",
		keys: "Ctrl Shift Z",
		description: "Redo what was undone.",
		blocked: (e) => e.history.canRedo ? null : "Nothing to redo.",
		run: (e) => void e.history.redo()
	},
	{
		id: "new_canvas",
		label: "New canvas…",
		menu: "File",
		description: "Start a new, empty design (replaces the open one).",
		params: [
			Q("Width", "width", 1, 16384, 2e3, {
				type: "integer",
				unit: "px"
			}),
			Q("Height", "height", 1, 16384, 2e3, {
				type: "integer",
				unit: "px"
			}),
			$("Canvas colour", "background", "#ffffff", {
				nullable: !0,
				description: "null for transparent."
			})
		],
		run: (e, t) => e.replace(ui(t.width, t.height, t.background))
	},
	{
		id: "save_design",
		label: "Save design (.gleam)",
		menu: "File",
		keys: "Ctrl S",
		description: "The design as a .gleam file (one JSON file with its pictures), to open and keep editing later.",
		run: async (e) => {
			let t = Xa(e.doc, () => "");
			for (let n of Object.keys(t.pixels)) t.pixels[n] = await Eo(e, n);
			return { file: {
				name: "design.gleam",
				type: "application/json",
				data: new TextEncoder().encode(JSON.stringify(t))
			} };
		}
	},
	{
		id: "export",
		label: "Export…",
		menu: "File",
		description: "The finished picture as PNG or JPEG, as SVG with shapes and text kept as vectors, or as PSD with every layer for Photoshop.",
		params: [{
			name: "format",
			type: "enum",
			label: "Format",
			options: [
				"png",
				"jpeg",
				"svg",
				"psd"
			],
			default: "png"
		}, Q("Quality (JPEG)", "quality", .1, 1, .92, { step: .01 })],
		run: async (e, t) => {
			if (t.format === "svg") {
				let t = /* @__PURE__ */ new Map();
				for (let n of e.doc.layers) n.kind === "raster" && t.set(n.pixels, await Eo(e, n.pixels)), n.mask && t.set(n.mask, await Eo(e, n.mask));
				return { file: {
					name: "design.svg",
					type: "image/svg+xml",
					data: new TextEncoder().encode(qa(e.doc, (e) => t.get(e)))
				} };
			}
			if (t.format === "psd") {
				let t = e.doc.layers.map((t) => {
					let n = e.backend.surface(e.doc.width, e.doc.height);
					return Ua(n.ctx, e.doc, {
						...t,
						opacity: 1,
						blend: "normal",
						visible: !0
					}, e.host()), {
						name: t.name,
						pixels: n.read(),
						opacity: t.opacity,
						blend: t.blend,
						hidden: !t.visible
					};
				});
				if (e.doc.background) {
					let n = e.backend.surface(e.doc.width, e.doc.height);
					n.ctx.fillStyle = e.doc.background, n.ctx.fillRect(0, 0, e.doc.width, e.doc.height), t.unshift({
						name: "Canvas colour",
						pixels: n.read(),
						opacity: 1,
						blend: "normal",
						hidden: !1
					});
				}
				return { file: {
					name: "design.psd",
					type: "image/vnd.adobe.photoshop",
					data: io(e.doc.width, e.doc.height, t, e.flatten())
				} };
			}
			let n = t.format === "jpeg" && !e.doc.background ? {
				...e.doc,
				background: "#ffffff"
			} : e.doc, r = await e.backend.encode(e.flatten(n), t.format, t.quality);
			return { file: {
				name: `design.${t.format === "jpeg" ? "jpg" : "png"}`,
				type: `image/${t.format}`,
				data: r
			} };
		}
	},
	{
		id: "place_image",
		label: "Place a picture…",
		menu: "File",
		description: "Put a picture on a new layer, fitted inside the canvas and centred unless x and y are given.",
		params: [
			{
				name: "image",
				type: "image",
				label: "Picture",
				description: "The picture (a file path from the command line or MCP)."
			},
			{
				name: "name",
				type: "string",
				label: "Layer name",
				default: "Picture"
			},
			Q("X", "x", -1e5, 1e5, void 0, { optional: !0 }),
			Q("Y", "y", -1e5, 1e5, void 0, { optional: !0 }),
			Q("Scale", "scale", .001, 100, void 0, {
				optional: !0,
				description: "Size as a fraction (1 = the picture’s own pixels); fits the canvas when left out."
			})
		],
		run: (e, t) => {
			let n = t.image, r = e.doc, i = t.scale ?? Math.min(1, r.width / n.width, r.height / n.height), a = fi(t.name, e.store.add(n), {
				x: t.x ?? (r.width - n.width * i) / 2,
				y: t.y ?? (r.height - n.height * i) / 2,
				scaleX: i,
				scaleY: i
			});
			return e.commit(gi(r, a, e.selectedId ?? void 0), "Place picture"), e.selectedId = a.id, { data: { id: a.id } };
		}
	},
	{
		id: "place_model",
		label: "Place a 3D picture",
		description: "Put a picture drawn in 3D mode on a new layer, with the 3D design it came from (JSON), so the layer can be opened in 3D mode and drawn again.",
		params: [
			{
				name: "image",
				type: "image",
				label: "Picture",
				description: "The picture 3D mode drew (a file path from the command line or MCP)."
			},
			{
				name: "model",
				type: "string",
				label: "3D design",
				description: "The 3D design as JSON."
			},
			{
				name: "name",
				type: "string",
				label: "Layer name",
				default: "3D object"
			}
		],
		run: (e, t) => {
			let n = oo(t.model), r = t.image, i = e.doc, a = Math.min(1, i.width / r.width, i.height / r.height), o = {
				...fi(t.name, e.store.add(r), {
					x: (i.width - r.width * a) / 2,
					y: (i.height - r.height * a) / 2,
					scaleX: a,
					scaleY: a
				}),
				model3d: n
			};
			return e.commit(gi(i, o, e.selectedId ?? void 0), "Place 3D object"), e.selectedId = o.id, { data: { id: o.id } };
		}
	},
	{
		id: "redraw_model",
		label: "Redraw a 3D layer",
		description: "Give a 3D layer its new picture and design after a change in 3D mode. The layer keeps its place, size on the canvas, mask and settings.",
		params: [
			X,
			{
				name: "image",
				type: "image",
				label: "Picture",
				description: "The new picture from 3D mode."
			},
			{
				name: "model",
				type: "string",
				label: "3D design",
				description: "The changed 3D design as JSON."
			}
		],
		run: (e, t) => {
			let n = Z(e, t.layer);
			if (n.kind !== "raster" || n.model3d === void 0) throw new Y(`"${n.name}" is not a 3D layer.`);
			let r = oo(t.model), i = t.image, a = e.store.get(n.pixels), o = a ? a.width * n.transform.scaleX / i.width : 1;
			e.commit(q(e.doc, n.id, {
				pixels: e.store.add(i),
				model3d: r,
				transform: {
					...n.transform,
					scaleX: o,
					scaleY: o * (n.transform.scaleY / n.transform.scaleX)
				}
			}), "Redraw 3D object");
		}
	},
	{
		id: "describe",
		label: "Describe the design",
		description: "The canvas size, selection, colours and every layer (top first) with its id, kind, position and settings.",
		run: (e) => ({ data: xo(e) })
	},
	{
		id: "add_layer",
		label: "New picture layer",
		menu: "Layer",
		keys: "Ctrl Shift N",
		description: "An empty picture layer the size of the canvas, above the picked layer.",
		params: [{
			name: "name",
			type: "string",
			label: "Name",
			default: "Layer"
		}],
		run: (e, t) => {
			let n = fi(t.name, e.store.add(oi(e.doc.width, e.doc.height)));
			return e.commit(gi(e.doc, n, e.selectedId ?? void 0), "New layer"), e.selectedId = n.id, { data: { id: n.id } };
		}
	},
	{
		id: "add_text",
		label: "Add text",
		description: "A text layer. x and y are its top-left corner (or its centre or right edge, by alignment).",
		params: [
			{
				name: "text",
				type: "string",
				label: "Text"
			},
			Q("X", "x", -1e5, 1e5, 0),
			Q("Y", "y", -1e5, 1e5, 0),
			Q("Size", "size", 1, 2e3, 72, { unit: "px" }),
			{
				name: "font",
				type: "string",
				label: "Font",
				default: "system-ui, sans-serif",
				description: "A CSS font family list."
			},
			Q("Weight", "weight", 100, 900, 700, { type: "integer" }),
			$("Colour", "color", So),
			{
				name: "align",
				type: "enum",
				label: "Align",
				options: [
					"left",
					"center",
					"right"
				],
				default: "left"
			},
			{
				name: "italic",
				type: "boolean",
				label: "Italic",
				default: !1
			}
		],
		run: (e, t) => {
			let n = mi(t.text, {
				size: t.size,
				font: t.font,
				weight: t.weight,
				color: t.color,
				align: t.align,
				italic: t.italic
			}, {
				x: t.x,
				y: t.y
			}), r = {
				...n,
				box: vo(e, n)
			};
			return e.commit(gi(e.doc, r, e.selectedId ?? void 0), "Add text"), e.selectedId = r.id, { data: { id: r.id } };
		}
	},
	{
		id: "add_shape",
		label: "Add shape",
		description: "A rectangle, ellipse or line layer that stays an editable shape. For a line, width and height are how far it runs.",
		params: [
			{
				name: "shape",
				type: "enum",
				label: "Shape",
				options: [
					"rect",
					"ellipse",
					"line"
				],
				default: "rect"
			},
			Q("X", "x", -1e5, 1e5, 0),
			Q("Y", "y", -1e5, 1e5, 0),
			Q("Width", "width", -1e5, 1e5, 400),
			Q("Height", "height", -1e5, 1e5, 300),
			Q("Corner radius", "radius", 0, 1e5, 0),
			$("Fill", "fill", So, { nullable: !0 }),
			$("Outline", "stroke", null, { nullable: !0 }),
			Q("Outline width", "strokeWidth", 0, 1e3, 4)
		],
		run: (e, t) => {
			let n = t.shape === "line" ? {
				type: "line",
				x2: t.width,
				y2: t.height
			} : t.shape === "ellipse" ? {
				type: "ellipse",
				width: Math.abs(t.width),
				height: Math.abs(t.height)
			} : {
				type: "rect",
				width: Math.abs(t.width),
				height: Math.abs(t.height),
				radius: t.radius
			}, r = t.shape === "line" ? {
				fill: null,
				stroke: t.stroke ?? t.fill ?? e.colours.main,
				strokeWidth: t.strokeWidth || 4
			} : {
				fill: t.fill,
				stroke: t.stroke,
				strokeWidth: t.strokeWidth
			}, i = t.shape === "rect" ? "Rectangle" : t.shape === "ellipse" ? "Ellipse" : "Line", a = pi(i, n, r, {
				x: t.x,
				y: t.y
			});
			return e.commit(gi(e.doc, a, e.selectedId ?? void 0), `Draw ${i.toLowerCase()}`), e.selectedId = a.id, { data: { id: a.id } };
		}
	},
	{
		id: "add_path",
		label: "Add path",
		description: "A path through points ([[x, y], ...] in canvas pixels), straight between them, open or closed.",
		params: [
			{
				name: "points",
				type: "points",
				label: "Points"
			},
			{
				name: "closed",
				type: "boolean",
				label: "Closed",
				default: !0
			},
			$("Fill", "fill", So, { nullable: !0 }),
			$("Outline", "stroke", null, { nullable: !0 }),
			Q("Outline width", "strokeWidth", 0, 1e3, 4)
		],
		run: (e, t) => {
			let n = bo(t.points);
			if (n.length < 2) throw new Y("A path needs at least two points.");
			let r = pi("Path", {
				type: "path",
				path: {
					points: n,
					closed: t.closed
				}
			}, t.closed ? {
				fill: t.fill,
				stroke: t.stroke,
				strokeWidth: t.strokeWidth
			} : {
				fill: null,
				stroke: t.stroke ?? t.fill ?? e.colours.main,
				strokeWidth: t.strokeWidth || 4
			});
			return e.commit(gi(e.doc, r, e.selectedId ?? void 0), "Draw path"), e.selectedId = r.id, { data: { id: r.id } };
		}
	},
	{
		id: "pick_layer",
		label: "Pick a layer",
		description: "Make a layer the one later commands act on.",
		params: [{
			...X,
			optional: !1
		}],
		run: (e, t) => {
			e.selectedId = Z(e, t.layer).id;
		}
	},
	{
		id: "drop_shadow",
		label: "Drop shadow…",
		menu: "Layer",
		description: "A soft shadow under the layer, cast away from a light at the given angle; it follows the layer as it changes. Opacity 0 removes it.",
		preview: !0,
		params: [
			Q("Opacity", "opacity", 0, 100, (e) => Math.round((e.selected?.style?.shadow?.opacity ?? .5) * 100), {
				type: "integer",
				unit: "%"
			}),
			Q("Angle", "angle", -180, 180, (e) => e.selected?.style?.shadow?.angle ?? 120, {
				type: "integer",
				unit: "°"
			}),
			Q("Distance", "distance", 0, 500, (e) => e.selected?.style?.shadow?.distance ?? 12, {
				type: "integer",
				unit: "px"
			}),
			Q("Softness", "blur", 0, 250, (e) => e.selected?.style?.shadow?.blur ?? 18, {
				type: "integer",
				unit: "px"
			}),
			$("Colour", "color", (e) => e.selected?.style?.shadow?.color ?? "#000000"),
			X
		],
		blocked: (e) => e.selected ? null : "Pick a layer.",
		run: (e, t) => {
			let n = Z(e, t.layer), r = t.opacity > 0 ? {
				color: t.color,
				opacity: t.opacity / 100,
				angle: t.angle,
				distance: t.distance,
				blur: t.blur
			} : void 0;
			e.commit(q(e.doc, n.id, { style: {
				...n.style,
				shadow: r
			} }), r ? "Drop shadow" : "Remove drop shadow");
		}
	},
	{
		id: "outer_glow",
		label: "Outer glow…",
		menu: "Layer",
		description: "A soft halo all round the layer, in the main colour unless one is given. Opacity 0 removes it.",
		preview: !0,
		params: [
			Q("Opacity", "opacity", 0, 100, (e) => Math.round((e.selected?.style?.glow?.opacity ?? .75) * 100), {
				type: "integer",
				unit: "%"
			}),
			Q("Size", "size", 1, 250, (e) => e.selected?.style?.glow?.size ?? 24, {
				type: "integer",
				unit: "px"
			}),
			$("Colour", "color", (e) => e.selected?.style?.glow?.color ?? e.colours.main),
			X
		],
		blocked: (e) => e.selected ? null : "Pick a layer.",
		run: (e, t) => {
			let n = Z(e, t.layer), r = t.opacity > 0 ? {
				color: t.color,
				opacity: t.opacity / 100,
				size: t.size
			} : void 0;
			e.commit(q(e.doc, n.id, { style: {
				...n.style,
				glow: r
			} }), r ? "Outer glow" : "Remove outer glow");
		}
	},
	{
		id: "stroke_outline",
		label: "Stroke…",
		menu: "Layer",
		description: "A line round the outside of the layer’s shape (its see-through edge), in the main colour unless one is given. Width 0 removes it.",
		preview: !0,
		params: [
			Q("Width", "width", 0, 100, (e) => e.selected?.style?.stroke?.width ?? 6, {
				type: "integer",
				unit: "px"
			}),
			$("Colour", "color", (e) => e.selected?.style?.stroke?.color ?? e.colours.main),
			X
		],
		blocked: (e) => e.selected ? null : "Pick a layer.",
		run: (e, t) => {
			let n = Z(e, t.layer), r = t.width > 0 ? {
				color: t.color,
				width: t.width
			} : void 0;
			e.commit(q(e.doc, n.id, { style: {
				...n.style,
				stroke: r
			} }), r ? "Stroke" : "Remove stroke");
		}
	},
	{
		id: "clear_style",
		label: "Clear layer style",
		menu: "Layer",
		description: "Take the drop shadow, glow and stroke off the layer.",
		blocked: (e) => e.selected?.style ? null : "The picked layer has no style.",
		params: [X],
		run: (e, t) => {
			let n = Z(e, t.layer);
			e.commit(q(e.doc, n.id, { style: void 0 }), "Clear layer style");
		}
	},
	{
		id: "set_layer",
		label: "Change a layer",
		description: "Change any of a layer’s settings: name, visible, locked, opacity (0-1), blend, x, y, scaleX, scaleY, rotation (degrees); fill, stroke, strokeWidth, radius (shapes); text, size, font, weight, color, align, italic (text).",
		params: [
			X,
			{
				name: "name",
				type: "string",
				label: "Name",
				optional: !0
			},
			{
				name: "visible",
				type: "boolean",
				label: "Visible",
				optional: !0
			},
			{
				name: "locked",
				type: "boolean",
				label: "Locked",
				optional: !0
			},
			Q("Opacity", "opacity", 0, 1, void 0, {
				optional: !0,
				step: .01
			}),
			{
				name: "blend",
				type: "enum",
				label: "Blend",
				options: ni.map((e) => e.id),
				optional: !0
			},
			Q("X", "x", -1e5, 1e5, void 0, { optional: !0 }),
			Q("Y", "y", -1e5, 1e5, void 0, { optional: !0 }),
			Q("Scale across", "scaleX", -100, 100, void 0, { optional: !0 }),
			Q("Scale down", "scaleY", -100, 100, void 0, { optional: !0 }),
			Q("Turn", "rotation", -3600, 3600, void 0, {
				optional: !0,
				unit: "°"
			}),
			$("Fill", "fill", void 0, {
				optional: !0,
				nullable: !0
			}),
			$("Outline", "stroke", void 0, {
				optional: !0,
				nullable: !0
			}),
			Q("Outline width", "strokeWidth", 0, 1e3, void 0, { optional: !0 }),
			Q("Corner radius", "radius", 0, 1e5, void 0, { optional: !0 }),
			{
				name: "text",
				type: "string",
				label: "Text",
				optional: !0
			},
			Q("Size", "size", 1, 2e3, void 0, { optional: !0 }),
			{
				name: "font",
				type: "string",
				label: "Font",
				optional: !0
			},
			Q("Weight", "weight", 100, 900, void 0, {
				optional: !0,
				type: "integer"
			}),
			$("Text colour", "color", void 0, { optional: !0 }),
			{
				name: "align",
				type: "enum",
				label: "Align",
				options: [
					"left",
					"center",
					"right"
				],
				optional: !0
			},
			{
				name: "italic",
				type: "boolean",
				label: "Italic",
				optional: !0
			}
		],
		run: (e, t) => {
			let n = Z(e, t.layer);
			if (n.locked && t.locked !== !1) throw new Y(`"${n.name}" is locked.`);
			let r = {};
			for (let e of [
				"name",
				"visible",
				"locked",
				"opacity",
				"blend"
			]) t[e] !== void 0 && (r[e] = t[e]);
			let i = { ...n.transform };
			if (t.x !== void 0 && (i.x = t.x), t.y !== void 0 && (i.y = t.y), t.scaleX !== void 0 && (i.scaleX = t.scaleX || .001), t.scaleY !== void 0 && (i.scaleY = t.scaleY || .001), t.rotation !== void 0 && (i.rotation = t.rotation * Math.PI / 180), r.transform = i, n.kind === "shape") {
				for (let e of [
					"fill",
					"stroke",
					"strokeWidth"
				]) t[e] !== void 0 && (r[e] = t[e]);
				t.radius !== void 0 && n.shape.type === "rect" && (r.shape = {
					...n.shape,
					radius: t.radius
				});
			}
			if (n.kind === "text") {
				for (let e of [
					"text",
					"size",
					"font",
					"weight",
					"color",
					"align",
					"italic"
				]) t[e] !== void 0 && (r[e] = t[e]);
				r.box = vo(e, {
					...n,
					...r
				});
			}
			e.commit(q(e.doc, n.id, r), "Change layer");
		}
	},
	{
		id: "duplicate_layer",
		label: "Duplicate layer",
		menu: "Layer",
		keys: "Ctrl J",
		description: "A copy of the layer just above it.",
		params: [X],
		blocked: (e) => e.selected ? null : "Pick a layer first.",
		run: (e, t) => {
			let n = yi(e.doc, e.store, Z(e, t.layer).id);
			return e.commit(n.doc, "Duplicate"), e.selectedId = n.id, { data: { id: n.id } };
		}
	},
	{
		id: "delete_layer",
		label: "Delete layer",
		menu: "Layer",
		description: "Remove the layer.",
		params: [X],
		blocked: (e) => e.selected ? null : "Pick a layer first.",
		run: (e, t) => {
			let n = Z(e, t.layer), r = e.doc.layers.indexOf(n), i = _i(e.doc, n.id);
			e.commit(i, "Delete layer"), e.selectedId === n.id && (e.selectedId = i.layers[Math.max(0, r - 1)]?.id ?? null);
		}
	},
	{
		id: "arrange_layer",
		label: "Arrange layer",
		description: "Move the layer in the stack: front, forward, backward or back.",
		params: [X, {
			name: "to",
			type: "enum",
			label: "To",
			options: [
				"front",
				"forward",
				"backward",
				"back"
			],
			default: "forward"
		}],
		run: (e, t) => {
			let n = {
				front: Infinity,
				forward: 1,
				backward: -1,
				back: -Infinity
			}[t.to];
			e.commit(vi(e.doc, Z(e, t.layer).id, n), "Arrange");
		}
	},
	...[
		[
			"front",
			"Bring to front",
			"Ctrl Shift ]"
		],
		[
			"forward",
			"Bring forward",
			"Ctrl ]"
		],
		[
			"backward",
			"Send backward",
			"Ctrl ["
		],
		[
			"back",
			"Send to back",
			"Ctrl Shift ["
		]
	].map(([e, t, n]) => ({
		id: `arrange_${e}`,
		label: t,
		menu: "Layer",
		keys: n,
		description: `${t} (the picked layer).`,
		blocked: (e) => e.selected ? null : "Pick a layer first.",
		run: (n) => void n.commit(vi(n.doc, n.selectedId, {
			front: Infinity,
			forward: 1,
			backward: -1,
			back: -Infinity
		}[e]), t)
	})),
	{
		id: "merge_down",
		label: "Merge down",
		menu: "Layer",
		keys: "Ctrl E",
		description: "Combine the layer with the one under it into one picture layer.",
		params: [X],
		blocked: (e) => e.selected && e.doc.layers.indexOf(e.selected) > 0 ? null : "Pick a layer that has one under it.",
		run: (e, t) => {
			let n = Z(e, t.layer), r = e.doc.layers.indexOf(n);
			if (r < 1) throw new Y("There is no layer under it to merge with.");
			let i = e.doc.layers[r - 1], a = e.backend.surface(e.doc.width, e.doc.height);
			Ua(a.ctx, e.doc, i, e.host()), Ua(a.ctx, e.doc, n, e.host());
			let o = fi(i.name, e.store.add(a.read())), s = _i(e.doc, n.id);
			e.commit({
				...s,
				layers: s.layers.map((e) => e.id === i.id ? o : e)
			}, "Merge down"), e.selectedId = o.id;
		}
	},
	{
		id: "flatten",
		label: "Flatten into one layer",
		menu: "Layer",
		description: "Every layer drawn into one picture layer (the canvas colour stays separate).",
		blocked: (e) => e.doc.layers.length > 1 ? null : "There is only one layer.",
		run: (e) => {
			let t = fi("Flattened", e.store.add(e.flatten(e.doc, !1)));
			e.commit({
				...e.doc,
				layers: [t]
			}, "Flatten"), e.selectedId = t.id;
		}
	},
	{
		id: "rasterize",
		label: "Rasterize (turn into pixels)",
		menu: "Layer",
		description: "Turn a shape or text layer into a picture layer, to paint on it.",
		params: [X],
		blocked: (e) => e.selected && e.selected.kind !== "raster" ? null : "Pick a shape or text layer.",
		run: (e, t) => {
			let n = Z(e, t.layer);
			if (n.kind === "raster") return { message: "It is already a picture layer." };
			let r = {
				...fi(n.name, e.store.add(ho(e, n))),
				opacity: n.opacity,
				blend: n.blend,
				mask: n.mask,
				visible: n.visible
			};
			e.commit({
				...e.doc,
				layers: e.doc.layers.map((e) => e.id === n.id ? r : e)
			}, "Rasterize"), e.selectedId = r.id;
		}
	},
	{
		id: "flip_layer",
		label: "Flip layer",
		description: "Mirror the layer left to right (across) or upside down (down), about its centre.",
		params: [X, {
			name: "axis",
			type: "enum",
			label: "Axis",
			options: ["across", "down"],
			default: "across"
		}],
		run: (e, t) => {
			let n = co(Z(e, t.layer)), r = zi(n, e.store), i = n.transform, a = t.axis === "across" ? {
				...i,
				scaleX: -i.scaleX
			} : {
				...i,
				scaleY: -i.scaleY
			};
			e.commit(q(e.doc, n.id, { transform: yo(i, a, {
				x: r.x + r.width / 2,
				y: r.y + r.height / 2
			}) }), "Flip");
		}
	},
	...[["across", "Flip layer left to right"], ["down", "Flip layer upside down"]].map(([e, t]) => ({
		id: `flip_${e}`,
		label: t,
		menu: "Layer",
		description: `${t} (the picked layer).`,
		blocked: (e) => e.selected ? null : "Pick a layer first.",
		run: (t) => Oo(t, "flip_layer", { axis: e })
	})),
	{
		id: "add_mask",
		label: "Add mask",
		menu: "Layer",
		description: "A mask on the layer: it shows what is selected (or everything when nothing is). Paint on it to hide and show parts.",
		params: [X],
		blocked: (e) => e.selected && !e.selected.mask ? null : e.selected ? "It already has a mask." : "Pick a layer first.",
		run: (e, t) => {
			let n = Z(e, t.layer);
			if (n.mask) throw new Y(`"${n.name}" already has a mask.`);
			let r = oi(e.doc.width, e.doc.height);
			for (let t = 0; t < e.doc.width * e.doc.height; t++) r.data[t * 4 + 3] = e.selection ? e.selection.mask[t] : 255;
			e.commit(q(e.doc, n.id, {
				mask: e.store.add(r, "mask"),
				maskOff: !1
			}), "Add mask");
		}
	},
	{
		id: "toggle_mask",
		label: "Switch mask off/on",
		menu: "Layer",
		description: "See the layer without its mask, or with it again.",
		params: [X],
		blocked: (e) => e.selected?.mask ? null : "The layer has no mask.",
		run: (e, t) => {
			let n = Z(e, t.layer);
			if (!n.mask) throw new Y(`"${n.name}" has no mask.`);
			e.commit(q(e.doc, n.id, { maskOff: !n.maskOff }), "Switch mask");
		}
	},
	{
		id: "apply_mask",
		label: "Apply mask to pixels",
		menu: "Layer",
		description: "Make what the mask hides transparent for good, and remove the mask.",
		params: [X],
		blocked: (e) => e.selected?.kind === "raster" && e.selected.mask ? null : "Pick a picture layer with a mask.",
		run: (e, t) => {
			let n = lo(Z(e, t.layer));
			if (!n.mask) throw new Y(`"${n.name}" has no mask.`);
			let r = e.backend.surface(e.doc.width, e.doc.height);
			Ua(r.ctx, e.doc, {
				...n,
				opacity: 1,
				blend: "normal"
			}, e.host());
			let i = {
				...n,
				pixels: e.store.add(r.read()),
				mask: void 0,
				transform: {
					x: 0,
					y: 0,
					scaleX: 1,
					scaleY: 1,
					rotation: 0
				}
			};
			e.commit({
				...e.doc,
				layers: e.doc.layers.map((e) => e.id === n.id ? i : e)
			}, "Apply mask");
		}
	},
	{
		id: "delete_mask",
		label: "Delete mask",
		menu: "Layer",
		description: "Remove the layer’s mask (the layer shows fully again).",
		params: [X],
		blocked: (e) => e.selected?.mask ? null : "The layer has no mask.",
		run: (e, t) => void e.commit(q(e.doc, Z(e, t.layer).id, { mask: void 0 }), "Delete mask")
	},
	{
		id: "select_all",
		label: "Select all",
		menu: "Select",
		keys: "Ctrl A",
		description: "Select the whole canvas.",
		run: (e) => void (e.selection = Ji(e.doc.width, e.doc.height))
	},
	{
		id: "deselect",
		label: "Deselect",
		menu: "Select",
		keys: "Ctrl D",
		description: "Select nothing.",
		run: (e) => void (e.selection = null)
	},
	{
		id: "invert_selection",
		label: "Invert selection",
		menu: "Select",
		keys: "Ctrl Shift I",
		description: "Select what is not selected.",
		run: (e) => mo(e, $i(e.selection ?? {
			width: e.doc.width,
			height: e.doc.height,
			mask: new Uint8Array(e.doc.width * e.doc.height)
		}))
	},
	{
		id: "select_rect",
		label: "Select a box",
		description: "Select a rectangle of the canvas.",
		params: [
			Q("X", "x", -1e5, 1e5, 0),
			Q("Y", "y", -1e5, 1e5, 0),
			Q("Width", "width", 0, 1e5, 100),
			Q("Height", "height", 0, 1e5, 100),
			so
		],
		run: (e, t) => mo(e, Qi(e.selection, Yi(e.doc.width, e.doc.height, t), t.mode))
	},
	{
		id: "select_ellipse",
		label: "Select an oval",
		description: "Select the oval inside a box.",
		params: [
			Q("X", "x", -1e5, 1e5, 0),
			Q("Y", "y", -1e5, 1e5, 0),
			Q("Width", "width", 0, 1e5, 100),
			Q("Height", "height", 0, 1e5, 100),
			so
		],
		run: (e, t) => mo(e, Qi(e.selection, Xi(e.doc.width, e.doc.height, t), t.mode))
	},
	{
		id: "select_polygon",
		label: "Select an outline",
		description: "Select inside an outline through points ([[x, y], ...]).",
		params: [{
			name: "points",
			type: "points",
			label: "Points"
		}, so],
		run: (e, t) => mo(e, Qi(e.selection, Zi(e.doc.width, e.doc.height, bo(t.points)), t.mode))
	},
	{
		id: "magic_wand",
		label: "Select by colour",
		description: "Select the colour at a point, as the canvas looks: the touching patch, or every pixel of that colour.",
		params: [
			Q("X", "x", 0, 1e5, 0),
			Q("Y", "y", 0, 1e5, 0),
			Q("Tolerance", "tolerance", 0, 255, 32, { type: "integer" }),
			{
				name: "contiguous",
				type: "boolean",
				label: "Only touching pixels",
				default: !0
			},
			so
		],
		run: (e, t) => mo(e, Qi(e.selection, na(e.flatten(), t, t.tolerance, t.contiguous), t.mode))
	},
	{
		id: "feather_selection",
		label: "Soften selection edge…",
		menu: "Select",
		description: "Blur the selection’s edge so edits fade out.",
		params: [Q("Softness", "radius", 1, 200, 8, {
			unit: "px",
			type: "integer"
		})],
		blocked: (e) => e.selection ? null : "Nothing is selected.",
		run: (e, t) => void (e.selection = ta(e.selection, t.radius))
	},
	{
		id: "select_layer_pixels",
		label: "Select the layer’s pixels",
		menu: "Select",
		description: "Select what the layer covers (its non-transparent pixels).",
		params: [X],
		blocked: (e) => e.selected ? null : "Pick a layer first.",
		run: (e, t) => {
			let n = ho(e, Z(e, t.layer)), r = new Uint8Array(e.doc.width * e.doc.height);
			for (let e = 0; e < r.length; e++) r[e] = n.data[e * 4 + 3];
			return mo(e, {
				width: e.doc.width,
				height: e.doc.height,
				mask: r
			});
		}
	},
	{
		id: "fill",
		label: "Fill with main colour",
		menu: "Edit",
		keys: "Alt Delete",
		description: "Fill the selection (or the whole layer) of a picture layer with a colour.",
		params: [$("Colour", "color", So), X],
		run: (e, t) => {
			let n = fo(e, t.layer), r = po(e, n.doc, n.layer);
			ma(r.working, ia(t.color), uo(e, r.layer)), e.commit(r.doc, "Fill");
		}
	},
	{
		id: "clear",
		label: "Clear selected pixels",
		menu: "Edit",
		keys: "Delete",
		description: "Make the selected pixels of a picture layer transparent.",
		params: [X],
		blocked: (e) => e.selection ? e.selected?.kind === "raster" ? null : "Pick a picture layer." : "Select something first.",
		run: (e, t) => {
			if (!e.selection) throw new Y("Select something first.");
			let n = lo(Z(e, t.layer)), r = po(e, e.doc, n);
			ha(r.working, uo(e, r.layer)), e.commit(r.doc, "Clear");
		}
	},
	{
		id: "copy",
		label: "Copy",
		menu: "Edit",
		keys: "Ctrl C",
		description: "Copy the selected pixels of a picture layer (Paste puts them on a new layer).",
		params: [X],
		blocked: (e) => e.selected?.kind === "raster" ? null : "Pick a picture layer.",
		run: (e, t) => {
			let n = lo(Z(e, t.layer));
			return e.clipboard = {
				pixels: ga(e.store.get(n.pixels), uo(e, n)),
				transform: n.transform
			}, { message: "Copied. Paste puts it on a new layer." };
		}
	},
	{
		id: "cut",
		label: "Cut",
		menu: "Edit",
		keys: "Ctrl X",
		description: "Copy the selected pixels and clear them.",
		params: [X],
		blocked: (e) => e.selected?.kind === "raster" ? null : "Pick a picture layer.",
		run: (e, t) => {
			let n = lo(Z(e, t.layer)), r = uo(e, n);
			e.clipboard = {
				pixels: ga(e.store.get(n.pixels), r),
				transform: n.transform
			};
			let i = po(e, e.doc, n);
			return ha(i.working, r), e.commit(i.doc, "Cut"), { message: "Cut. Paste puts it on a new layer." };
		}
	},
	{
		id: "paste",
		label: "Paste as new layer",
		menu: "Edit",
		keys: "Ctrl V",
		description: "What was copied, on a new layer where it came from.",
		blocked: (e) => e.clipboard ? null : "Nothing has been copied.",
		run: (e) => {
			if (!e.clipboard) throw new Y("Nothing has been copied.");
			let t = fi("Pasted", e.store.add(si(e.clipboard.pixels)), e.clipboard.transform);
			e.commit(gi(e.doc, t, e.selectedId ?? void 0), "Paste"), e.selectedId = t.id;
		}
	},
	{
		id: "brush_stroke",
		label: "Paint a stroke",
		description: "Paint (or erase) along points ([[x, y], ...] in canvas pixels) on a picture layer, inside the selection.",
		params: [
			{
				name: "points",
				type: "points",
				label: "Points"
			},
			Q("Size", "size", 1, 2e3, 24, { unit: "px" }),
			Q("Hardness", "hardness", 0, 1, .6, { step: .01 }),
			Q("Flow", "flow", .01, 1, 1, { step: .01 }),
			$("Colour", "color", So),
			{
				name: "erase",
				type: "boolean",
				label: "Erase",
				default: !1
			},
			X
		],
		run: (e, t) => {
			let n = fo(e, t.layer), r = po(e, n.doc, n.layer), i = uo(e, r.layer), a = sa(), o = (e) => {
				let t = Fi(r.layer.transform), n = t.a * t.d - t.b * t.c || 1, i = e.x - t.e, a = e.y - t.f;
				return {
					x: (t.d * i - t.c * a) / n,
					y: (-t.b * i + t.a * a) / n
				};
			};
			for (let e of bo(t.points)) da(r.working, a, o(e), {
				size: t.size,
				hardness: t.hardness,
				flow: t.flow,
				color: ia(t.color),
				mode: t.erase ? "erase" : "paint"
			}, i);
			e.commit(r.doc, t.erase ? "Erase" : "Brush");
		}
	},
	{
		id: "ink_stroke",
		label: "Draw an ink line",
		description: "Draw a line by hand on an ink layer (lines kept as vectors: crisp at any size, thinning at their ends and where the hand moves fast), through points ([[x, y], ...] in canvas pixels, in the order drawn), steadied by the stabiliser. Adds to the picked ink layer, or makes a new one.",
		params: [
			{
				name: "points",
				type: "points",
				label: "Points"
			},
			Q("Size", "size", .5, 400, wi.size, { unit: "px" }),
			Q("Taper", "taper", 0, 1e3, wi.taper, {
				unit: "px",
				description: "How far the line takes to swell from a point and thin back to one."
			}),
			Q("Speed thins", "speed", 0, 1, wi.speed, {
				step: .05,
				description: "How much a fast hand thins the line."
			}),
			Q("Stabiliser", "stabiliser", 0, 10, 0, {
				type: "integer",
				description: "How much a shaky hand is steadied, 0 (off) to 10."
			}),
			$("Colour", "color", So),
			X
		],
		run: (e, t) => {
			let n = bo(t.points);
			if (!n.length) throw new Y("An ink line needs at least one point.");
			let r = e.doc, i = t.layer ? Z(e, t.layer) : e.selected;
			if (i?.kind !== "shape" || i.shape.type !== "ink") {
				if (t.layer) throw new Y("That is not an ink layer.");
				let e = _o(t.color);
				r = gi(r, e, i?.id), i = e;
			}
			let a = i, o = Fi(a.transform), s = o.a * o.d - o.b * o.c || 1, c = (e) => {
				let t = e.x - o.e, n = e.y - o.f;
				return {
					x: (o.d * t - o.c * n) / s,
					y: (-o.b * t + o.a * n) / s
				};
			}, l = {
				size: t.size,
				taper: t.taper,
				speed: t.speed
			}, u = bi(xi(t.stabiliser, t.size)), d = { points: [] };
			for (let e of n) {
				let t = Si(u, c(e));
				t && Ti(d, t, l);
			}
			for (let e of Ci(u, c(n[n.length - 1]))) Ti(d, e, l);
			return Ei(d, l), r = q(r, a.id, { shape: {
				type: "ink",
				strokes: [...a.shape.strokes, d]
			} }), e.commit(r, "Ink"), e.selectedId = a.id, { data: {
				id: a.id,
				points: d.points.length
			} };
		}
	},
	{
		id: "fill_inside_lines",
		label: "Fill inside the lines",
		description: "Colour the space inside the ink layers' lines round a point, onto a picture layer (the picked one, or a new \"Colour\" layer under the picked ink layer), tucked a little under the lines so no gap shows.",
		params: [
			Q("X", "x", -1e5, 1e5, 0),
			Q("Y", "y", -1e5, 1e5, 0),
			$("Colour", "color", So),
			Q("Under the lines", "under", 0, 20, 2, {
				unit: "px",
				type: "integer"
			}),
			Q("Close gaps", "gap", 0, 40, 0, {
				unit: "px",
				type: "integer",
				description: "Lines that nearly meet, up to this far apart, count as closed."
			}),
			X
		],
		run: (e, t) => {
			let n = go(e);
			if (!n) throw new Y("There are no ink lines to fill inside. Draw some with the ink tool first.");
			let r = Ni(n, {
				x: t.x,
				y: t.y
			}, t.under, t.gap);
			if (!r.mask.some((e) => e)) throw new Y("That point is on a line. Pick a point inside the lines.");
			let i = e.doc, a = t.layer ? Z(e, t.layer) : e.selected;
			if (a?.kind !== "raster") {
				if (t.layer) throw new Y("Fill inside the lines colours a picture layer.");
				let n = fi("Colour", e.store.add(oi(e.doc.width, e.doc.height)));
				i = gi(i, n, a?.id), a && (i = vi(i, n.id, -1)), a = n;
			}
			let o = po(e, i, lo(a)), s = e.selection, c = Fi(o.layer.transform), { width: l, height: u, mask: d } = r;
			return ma(o.working, ia(t.color), (e, t) => {
				let n = Li(c, {
					x: e + .5,
					y: t + .5
				}), r = Math.floor(n.x), i = Math.floor(n.y);
				return r < 0 || i < 0 || r >= l || i >= u ? 0 : d[i * l + r] / 255 * (s ? s.mask[i * l + r] / 255 : 1);
			}), e.commit(o.doc, "Fill inside lines"), e.selectedId = o.layer.id, { data: { id: o.layer.id } };
		}
	},
	{
		id: "flood_fill",
		label: "Fill a patch",
		description: "Fill the patch of similar colour around a point of a picture layer (paint bucket).",
		params: [
			Q("X", "x", -1e5, 1e5, 0),
			Q("Y", "y", -1e5, 1e5, 0),
			$("Colour", "color", So),
			Q("Tolerance", "tolerance", 0, 255, 32, { type: "integer" }),
			{
				name: "contiguous",
				type: "boolean",
				label: "Only touching pixels",
				default: !0
			},
			X
		],
		run: (e, t) => {
			let n = fo(e, t.layer), r = po(e, n.doc, n.layer), i = Fi(r.layer.transform), a = i.a * i.d - i.b * i.c || 1, o = t.x - i.e, s = t.y - i.f;
			fa(r.working, {
				x: (i.d * o - i.c * s) / a,
				y: (-i.b * o + i.a * s) / a
			}, ia(t.color), t.tolerance, t.contiguous, uo(e, r.layer)), e.commit(r.doc, "Fill");
		}
	},
	{
		id: "gradient",
		label: "Gradient",
		description: "A straight gradient on a picture layer from one point and colour to another, inside the selection.",
		params: [
			Q("From X", "x1", -1e5, 1e5, 0),
			Q("From Y", "y1", -1e5, 1e5, 0),
			Q("To X", "x2", -1e5, 1e5, (e) => e.doc.width),
			Q("To Y", "y2", -1e5, 1e5, 0),
			$("From colour", "from", So),
			$("To colour", "to", (e) => e.colours.second),
			X
		],
		run: (e, t) => {
			let n = fo(e, t.layer), r = po(e, n.doc, n.layer), i = Fi(r.layer.transform), a = i.a * i.d - i.b * i.c || 1, o = (e, t) => ({
				x: (i.d * (e - i.e) - i.c * (t - i.f)) / a,
				y: (-i.b * (e - i.e) + i.a * (t - i.f)) / a
			});
			_a(r.working, o(t.x1, t.y1), o(t.x2, t.y2), ia(t.from), ia(t.to), uo(e, r.layer)), e.commit(r.doc, "Gradient");
		}
	},
	...[
		[
			"brightness_contrast",
			"Brightness and contrast…",
			[Q("Brightness", "brightness", -100, 100, 0, { type: "integer" }), Q("Contrast", "contrast", -100, 100, 0, { type: "integer" })],
			(e, t, n) => Ca(e, t.brightness, t.contrast, n)
		],
		[
			"hue_saturation",
			"Hue and saturation…",
			[
				Q("Hue", "hue", -180, 180, 0, {
					type: "integer",
					unit: "°"
				}),
				Q("Saturation", "saturation", -100, 100, 0, { type: "integer" }),
				Q("Lightness", "lightness", -100, 100, 0, { type: "integer" })
			],
			(e, t, n) => wa(e, t.hue, t.saturation, t.lightness, n)
		],
		[
			"blur",
			"Blur…",
			[Q("Radius", "radius", 1, 100, 4, {
				type: "integer",
				unit: "px"
			})],
			(e, t, n) => Ma(e, t.radius, n)
		],
		[
			"sharpen",
			"Sharpen…",
			[Q("Amount", "amount", 0, 3, .8, { step: .05 }), Q("Radius", "radius", 1, 8, 1, {
				type: "integer",
				unit: "px"
			})],
			(e, t, n) => Na(e, t.amount, t.radius, n)
		],
		[
			"levels",
			"Levels…",
			[
				Q("Input black", "inBlack", 0, 254, 0, { type: "integer" }),
				Q("Input white", "inWhite", 1, 255, 255, { type: "integer" }),
				Q("Midtones", "gamma", .1, 4, 1, { step: .01 }),
				Q("Output black", "outBlack", 0, 255, 0, { type: "integer" }),
				Q("Output white", "outWhite", 0, 255, 255, { type: "integer" })
			],
			(e, t, n) => Ea(e, t.inBlack, t.inWhite, t.gamma, t.outBlack, t.outWhite, n)
		],
		[
			"curves",
			"Curves…",
			[
				Q("Shadows", "shadows", -100, 100, 0, { type: "integer" }),
				Q("Midtones", "midtones", -100, 100, 0, { type: "integer" }),
				Q("Highlights", "highlights", -100, 100, 0, { type: "integer" })
			],
			(e, t, n) => Da(e, t.shadows, t.midtones, t.highlights, n)
		],
		[
			"vibrance",
			"Vibrance…",
			[Q("Vibrance", "vibrance", -100, 100, 0, { type: "integer" })],
			(e, t, n) => Oa(e, t.vibrance, n)
		],
		[
			"colour_balance",
			"Colour balance…",
			[Q("Warmth", "warmth", -100, 100, 0, { type: "integer" }), Q("Tint", "tint", -100, 100, 0, { type: "integer" })],
			(e, t, n) => ka(e, t.warmth, t.tint, n)
		],
		[
			"posterize",
			"Posterize…",
			[Q("Levels", "steps", 2, 32, 6, { type: "integer" })],
			(e, t, n) => Aa(e, t.steps, n)
		],
		[
			"threshold",
			"Threshold…",
			[Q("Level", "level", 0, 255, 128, { type: "integer" })],
			(e, t, n) => ja(e, t.level, n)
		],
		[
			"black_and_white",
			"Black and white",
			[],
			(e, t, n) => Sa(e, n)
		],
		[
			"invert_colours",
			"Invert colours",
			[],
			(e, t, n) => xa(e, n)
		]
	].map(([e, t, n, r]) => ({
		id: e,
		label: t,
		menu: "Adjust",
		keys: e === "invert_colours" ? "Ctrl I" : void 0,
		description: `${t.replace("…", "")} on a picture layer, inside the selection.`,
		params: [...n, X],
		preview: n.length > 0,
		blocked: (e) => e.selected?.kind === "raster" ? null : "Pick a picture layer.",
		run: (e, n) => {
			let i = lo(Z(e, n.layer));
			e.commit(q(e.doc, i.id, { pixels: e.store.add(r(e.store.get(i.pixels), n, uo(e, i))) }), t.replace("…", ""));
		}
	})),
	{
		id: "canvas_size",
		label: "Canvas size…",
		menu: "Canvas",
		description: "Make the canvas a new size; layers stay centred.",
		params: [Q("Width", "width", 1, 16384, (e) => e.doc.width, {
			type: "integer",
			unit: "px"
		}), Q("Height", "height", 1, 16384, (e) => e.doc.height, {
			type: "integer",
			unit: "px"
		})],
		run: (e, t) => {
			let n = (t.width - e.doc.width) / 2, r = (t.height - e.doc.height) / 2;
			e.commit({
				...e.doc,
				width: t.width,
				height: t.height,
				layers: e.doc.layers.map((e) => ({
					...e,
					mask: void 0,
					transform: {
						...e.transform,
						x: e.transform.x + n,
						y: e.transform.y + r
					}
				}))
			}, "Canvas size"), e.selection = null;
		}
	},
	{
		id: "crop",
		label: "Crop canvas",
		description: "Keep only a box of the canvas.",
		params: [
			Q("X", "x", -1e5, 1e5, 0, { type: "integer" }),
			Q("Y", "y", -1e5, 1e5, 0, { type: "integer" }),
			Q("Width", "width", 1, 16384, 100, { type: "integer" }),
			Q("Height", "height", 1, 16384, 100, { type: "integer" })
		],
		run: (e, t) => {
			let n = {
				x: t.x,
				y: t.y,
				width: t.width,
				height: t.height
			}, r = e.doc.layers.map((t) => {
				let r = t.mask;
				if (r) {
					let t = e.store.get(r), i = oi(n.width, n.height);
					for (let e = 0; e < n.height; e++) for (let r = 0; r < n.width; r++) {
						let a = r + n.x, o = e + n.y;
						i.data[(e * n.width + r) * 4 + 3] = a >= 0 && o >= 0 && a < t.width && o < t.height ? t.data[(o * t.width + a) * 4 + 3] : 0;
					}
					r = e.store.add(i, "mask");
				}
				return {
					...t,
					mask: r,
					transform: {
						...t.transform,
						x: t.transform.x - n.x,
						y: t.transform.y - n.y
					}
				};
			});
			e.commit({
				...e.doc,
				width: n.width,
				height: n.height,
				layers: r
			}, "Crop"), e.selection = null;
		}
	},
	{
		id: "canvas_colour",
		label: "Canvas colour",
		description: "The colour under every layer, or null for transparent.",
		params: [$("Colour", "color", "#ffffff", { nullable: !0 })],
		run: (e, t) => void e.commit({
			...e.doc,
			background: t.color
		}, "Canvas colour")
	},
	{
		id: "set_colours",
		label: "Set colours",
		description: "The main and second colours used by painting, shapes and text when no colour is given.",
		params: [$("Main colour", "main", void 0, { optional: !0 }), $("Second colour", "second", void 0, { optional: !0 })],
		run: (e, t) => {
			t.main && (e.colours = {
				...e.colours,
				main: t.main
			}), t.second && (e.colours = {
				...e.colours,
				second: t.second
			});
		}
	}
], wo = new Map(Co.map((e) => [e.id, e])), To = (e) => wo.get(e);
async function Eo(e, t) {
	let n = await e.backend.encode(e.store.get(t), "png"), r = "";
	for (let e = 0; e < n.length; e += 32768) r += String.fromCharCode(...n.subarray(e, e + 32768));
	return `data:image/png;base64,${btoa(r)}`;
}
async function Do(e, t, n = {}) {
	let r = {}, i = new Set((t.params ?? []).map((e) => e.name));
	for (let e of Object.keys(n)) if (!i.has(e)) throw new Y(`"${t.id}" has no setting called "${e}".`);
	for (let i of t.params ?? []) {
		let a = n[i.name];
		if (a === void 0 && (a = typeof i.default == "function" ? i.default(e) : i.default), a === void 0) {
			if (i.optional) continue;
			throw new Y(`"${t.id}" needs ${i.label.toLowerCase()} (${i.name}).`);
		}
		switch (i.type) {
			case "number":
			case "integer": {
				let e = typeof a == "string" ? Number(a) : a;
				if (typeof e != "number" || !Number.isFinite(e)) throw new Y(`${i.name} must be a number.`);
				let t = Math.min(i.max ?? Infinity, Math.max(i.min ?? -Infinity, e));
				i.type === "integer" && (t = Math.round(t)), a = t;
				break;
			}
			case "boolean":
				if ((a === "true" || a === "false") && (a = a === "true"), typeof a != "boolean") throw new Y(`${i.name} must be true or false.`);
				break;
			case "string":
				a = String(a);
				break;
			case "enum":
				if (!i.options.includes(String(a))) throw new Y(`${i.name} must be one of: ${i.options.join(", ")}.`);
				break;
			case "color":
				if (a === null || a === "null" || a === "none") {
					if (!i.nullable) throw new Y(`${i.name} needs a colour.`);
					a = null;
				} else if (typeof a != "string" || !/^#[0-9a-f]{6}$/i.test(a)) throw new Y(`${i.name} must be a colour like #ff8800.`);
				else a = a.toLowerCase();
				break;
			case "points": {
				let e = typeof a == "string" ? JSON.parse(a) : a;
				if (!Array.isArray(e) || !e.length) throw new Y(`${i.name} must be a list of points like [[10, 20], [30, 40]].`);
				a = e;
				break;
			}
			case "image": if (a instanceof Uint8Array && (a = await e.backend.decode(a)), !a || typeof a != "object" || !("data" in a)) throw new Y(`${i.name} must be a picture.`);
		}
		r[i.name] = a;
	}
	return r;
}
async function Oo(e, t, n = {}) {
	let r = To(t);
	if (!r) throw new Y(`There is no command "${t}". The command "describe" lists the design; the list of commands says what each does.`);
	let i = r.params?.some((e) => e.name === "layer") && n.layer ? null : r.blocked?.(e) ?? null;
	if (i) throw new Y(i);
	return r.run(e, await Do(e, r, n));
}
//#endregion
//#region src/edit/icons.tsx
var ko = {
	move: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("path", { d: "M12 3v18M3 12h18" }), /* @__PURE__ */ P("path", { d: "M12 3l-3 3M12 3l3 3M12 21l-3-3M12 21l3-3M3 12l3-3M3 12l3 3M21 12l-3-3M21 12l-3 3" })] }),
	box: /* @__PURE__ */ P("rect", {
		x: "4",
		y: "5",
		width: "16",
		height: "14",
		rx: "1",
		strokeDasharray: "3 2.5"
	}),
	oval: /* @__PURE__ */ P("ellipse", {
		cx: "12",
		cy: "12",
		rx: "8.5",
		ry: "7",
		strokeDasharray: "3 2.5"
	}),
	lasso: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("path", {
		d: "M7 16c-3-2-3.5-6 0-8.5S17 5 19 8s0 7-5 7.5c-2.5.3-5 0-7 .5",
		strokeDasharray: "3 2.5"
	}), /* @__PURE__ */ P("path", { d: "M7 16c-1 1.5 0 3.5 2 3" })] }),
	wand: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("path", { d: "M5 19L15 9" }), /* @__PURE__ */ P("path", { d: "M16 3v3M19.5 4.5l-2 2M21 8h-3M17 11.5l-1.5-1.5" })] }),
	brush: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("path", { d: "M14 4l6 6-8 8-6-6z" }), /* @__PURE__ */ P("path", { d: "M6 12c-2 1-2.5 4-3 8 4-.5 7-1 8-3" })] }),
	eraser: /* @__PURE__ */ F(N, { children: [
		/* @__PURE__ */ P("path", { d: "M8 20h12" }),
		/* @__PURE__ */ P("path", { d: "M4 15l9-9 6 6-8 8H8z" }),
		/* @__PURE__ */ P("path", { d: "M9 10l6 6" })
	] }),
	clone: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("rect", {
		x: "4",
		y: "4",
		width: "10",
		height: "10",
		rx: "1"
	}), /* @__PURE__ */ P("rect", {
		x: "10",
		y: "10",
		width: "10",
		height: "10",
		rx: "1",
		strokeDasharray: "3 2"
	})] }),
	heal: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("rect", {
		x: "3",
		y: "9",
		width: "18",
		height: "6",
		rx: "3",
		transform: "rotate(-45 12 12)"
	}), /* @__PURE__ */ P("path", { d: "M10.5 10.5h3v3h-3z" })] }),
	bucket: /* @__PURE__ */ F(N, { children: [
		/* @__PURE__ */ P("path", { d: "M5 11l6-6 8 8-6 6z" }),
		/* @__PURE__ */ P("path", { d: "M5 11h14" }),
		/* @__PURE__ */ P("path", { d: "M20 16c0 1.5.8 2.5 0 3.5s-2-.5-1.5-1.5z" })
	] }),
	gradient: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("rect", {
		x: "3",
		y: "5",
		width: "18",
		height: "14",
		rx: "2"
	}), /* @__PURE__ */ P("path", {
		d: "M7 5v14M11 5v14M15 5v14",
		opacity: ".5"
	})] }),
	dropper: /* @__PURE__ */ F(N, { children: [
		/* @__PURE__ */ P("path", { d: "M14 6l4 4" }),
		/* @__PURE__ */ P("path", { d: "M16 4a2.1 2.1 0 013 3l-2 2-3-3z" }),
		/* @__PURE__ */ P("path", { d: "M15 9l-8 8-3 1 1-3 8-8" })
	] }),
	ink: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("path", { d: "M4 20c3-1 4-4 6-7s4-6 6-7" }), /* @__PURE__ */ P("path", { d: "M16 6l3-3 2 2-3 3z" })] }),
	rect: /* @__PURE__ */ P("rect", {
		x: "4",
		y: "5",
		width: "16",
		height: "14",
		rx: "2"
	}),
	ellipse: /* @__PURE__ */ P("ellipse", {
		cx: "12",
		cy: "12",
		rx: "8.5",
		ry: "7"
	}),
	line: /* @__PURE__ */ P("path", { d: "M5 19L19 5" }),
	pen: /* @__PURE__ */ F(N, { children: [
		/* @__PURE__ */ P("path", { d: "M12 3l5 9-5 9-5-9z" }),
		/* @__PURE__ */ P("circle", {
			cx: "12",
			cy: "12",
			r: "1.5"
		}),
		/* @__PURE__ */ P("path", { d: "M12 21v-7.5" })
	] }),
	text: /* @__PURE__ */ P(N, { children: /* @__PURE__ */ P("path", { d: "M5 6V4h14v2M12 4v16M9 20h6" }) }),
	crop: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("path", { d: "M7 3v14h14" }), /* @__PURE__ */ P("path", { d: "M3 7h14v14" })] }),
	hand: /* @__PURE__ */ P("path", { d: "M8 13V6.5a1.5 1.5 0 013 0V12m0-6.5a1.5 1.5 0 013 0V12m0-5a1.5 1.5 0 013 0v7c0 4-2.5 7-6 7s-5-2-7-5l-1.5-2.5a1.5 1.5 0 012.5-1.5L8 14" }),
	zoom: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("circle", {
		cx: "10.5",
		cy: "10.5",
		r: "6.5"
	}), /* @__PURE__ */ P("path", { d: "M15.5 15.5L20 20M8 10.5h5M10.5 8v5" })] }),
	eye: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("path", { d: "M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z" }), /* @__PURE__ */ P("circle", {
		cx: "12",
		cy: "12",
		r: "3"
	})] }),
	eyeOff: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("path", {
		d: "M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z",
		opacity: ".35"
	}), /* @__PURE__ */ P("path", { d: "M4 20L20 4" })] }),
	lock: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("rect", {
		x: "5",
		y: "11",
		width: "14",
		height: "9",
		rx: "2"
	}), /* @__PURE__ */ P("path", { d: "M8 11V8a4 4 0 018 0v3" })] }),
	unlock: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("rect", {
		x: "5",
		y: "11",
		width: "14",
		height: "9",
		rx: "2"
	}), /* @__PURE__ */ P("path", { d: "M8 11V8a4 4 0 017.5-2" })] }),
	plus: /* @__PURE__ */ P("path", { d: "M12 5v14M5 12h14" }),
	copy: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("rect", {
		x: "8",
		y: "8",
		width: "12",
		height: "12",
		rx: "2"
	}), /* @__PURE__ */ P("path", { d: "M16 8V5a1 1 0 00-1-1H5a1 1 0 00-1 1v10a1 1 0 001 1h3" })] }),
	trash: /* @__PURE__ */ P(N, { children: /* @__PURE__ */ P("path", { d: "M4 7h16M10 7V4h4v3M6 7l1 13h10l1-13" }) }),
	up: /* @__PURE__ */ P("path", { d: "M12 19V5M6 11l6-6 6 6" }),
	down: /* @__PURE__ */ P("path", { d: "M12 5v14M6 13l6 6 6-6" }),
	merge: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("path", { d: "M7 4v5a5 5 0 005 5 5 5 0 005-5V4" }), /* @__PURE__ */ P("path", { d: "M12 14v6M9 17l3 3 3-3" })] }),
	mask: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("rect", {
		x: "3",
		y: "5",
		width: "18",
		height: "14",
		rx: "2"
	}), /* @__PURE__ */ P("circle", {
		cx: "12",
		cy: "12",
		r: "4",
		fill: "currentColor",
		stroke: "none"
	})] }),
	undo: /* @__PURE__ */ P("path", {
		d: "M9 7L4 12l5 5M4 12h10a6 6 0 010 12",
		transform: "translate(0 -3)"
	}),
	redo: /* @__PURE__ */ P("path", {
		d: "M15 7l5 5-5 5M20 12H10a6 6 0 000 12",
		transform: "translate(0 -3)"
	}),
	swap: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("path", { d: "M7 4L4 7l3 3M4 7h11a4 4 0 014 4" }), /* @__PURE__ */ P("path", { d: "M17 20l3-3-3-3M20 17H9a4 4 0 01-4-4" })] }),
	search: /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("circle", {
		cx: "11",
		cy: "11",
		r: "6"
	}), /* @__PURE__ */ P("path", { d: "M16 16l4 4" })] })
};
function Ao({ name: e, size: t = 18, title: n }) {
	return /* @__PURE__ */ F("svg", {
		width: t,
		height: t,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: 1.7,
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": !n || void 0,
		role: n ? "img" : void 0,
		children: [n && /* @__PURE__ */ P("title", { children: n }), ko[e]]
	});
}
//#endregion
//#region src/edit/heal.ts
function jo(e, t, n, r, i, a, o) {
	let s = Math.max(.5, i / 2), c = Math.max(0, Math.floor(r.x - s)), l = Math.min(t, Math.ceil(r.x + s)), u = Math.max(0, Math.floor(r.y - s)), d = Math.min(n, Math.ceil(r.y + s));
	if (l <= c || d <= u) return null;
	let f = s * Math.min(.999, Math.max(0, a));
	for (let n = u; n < d; n++) for (let i = c; i < l; i++) {
		let a = Math.hypot(i + .5 - r.x, n + .5 - r.y);
		if (a >= s) continue;
		let c = a <= f ? 1 : 1 - (a - f) / (s - f);
		c = c * c * (3 - 2 * c), o && (c *= o(i, n));
		let l = n * t + i;
		c > e[l] && (e[l] = c);
	}
	return {
		x: c,
		y: u,
		width: l - c,
		height: d - u
	};
}
function Mo(e, t, n) {
	let { width: r, height: i } = e, a = r, o = i, s = -1, c = -1;
	for (let e = 0; e < i; e++) for (let t = 0; t < r; t++) n[e * r + t] > .004 && (t < a && (a = t), t > s && (s = t), e < o && (o = e), e > c && (c = e));
	if (s < 0) return null;
	let l = Math.max(24, s - a + 1, c - o + 1), u = Math.max(0, a - l), d = Math.max(0, o - l), f = Math.min(r, s + 1 + l), p = Math.min(i, c + 1 + l), m = f - u, h = p - d, g = new Uint8ClampedArray(m * h * 4), _ = new Uint8ClampedArray(m * h * 4), v = new Uint8Array(m * h);
	for (let e = 0; e < h; e++) for (let i = 0; i < m; i++) {
		let a = ((d + e) * r + u + i) * 4, o = (e * m + i) * 4, s = t.data[a + 3];
		g[o] = t.data[a] * s / 255, g[o + 1] = t.data[a + 1] * s / 255, g[o + 2] = t.data[a + 2] * s / 255, g[o + 3] = 255, _[o] = _[o + 1] = _[o + 2] = s, _[o + 3] = 255, n[(d + e) * r + u + i] > .02 && (v[e * m + i] = 1);
	}
	for (let e = 0; e < 3; e++) {
		let e = new Uint8Array(v);
		for (let t = 0; t < h; t++) for (let n = 0; n < m; n++) !v[t * m + n] && (n > 0 && v[t * m + n - 1] || n < m - 1 && v[t * m + n + 1] || t > 0 && v[(t - 1) * m + n] || t < h - 1 && v[(t + 1) * m + n]) && (e[t * m + n] = 1);
		v = e;
	}
	let y = $n({
		width: m,
		height: h,
		data: g
	}, v), b = $n({
		width: m,
		height: h,
		data: _
	}, v);
	for (let i = 0; i < h; i++) for (let a = 0; a < m; a++) {
		let o = (d + i) * r + u + a, s = v[i * m + a] ? Math.min(1, n[o] / .25) : 0, c = o * 4, l = (i * m + a) * 4, f = b.data[l], p = t.data[c + 3] * (1 - s) + f * s;
		for (let n = 0; n < 3; n++) {
			let r = f > 2 ? Math.min(255, y.data[l + n] * 255 / f) : t.data[c + n];
			e.data[c + n] = t.data[c + n] * (1 - s) + r * s;
		}
		e.data[c + 3] = p;
	}
	return {
		x: u,
		y: d,
		width: m,
		height: h
	};
}
//#endregion
//#region src/pinch.ts
function No(e, t, n, r, i, a, o) {
	let s = Math.hypot(n.x - t.x, n.y - t.y), c = Math.hypot(i.x - r.x, i.y - r.y), l = Math.min(o, Math.max(a, s > 0 ? e.zoom * c / s : e.zoom)), u = {
		x: (t.x + n.x) / 2,
		y: (t.y + n.y) / 2
	}, d = {
		x: (r.x + i.x) / 2,
		y: (r.y + i.y) / 2
	}, f = (u.x - e.x) / e.zoom, p = (u.y - e.y) / e.zoom;
	return {
		zoom: l,
		x: d.x - f * l,
		y: d.y - p * l
	};
}
var Po = class {
	min;
	max;
	fingers = /* @__PURE__ */ new Map();
	from = null;
	held = !1;
	last = null;
	constructor(e, t) {
		this.min = e, this.max = t;
	}
	get steering() {
		return this.held;
	}
	down(e, t, n) {
		return e.pointerType === "touch" ? (this.fingers.set(e.pointerId, t), this.held ? (this.restart(n), "steer") : this.fingers.size < 2 ? "free" : (this.held = !0, this.restart(n), "begin")) : this.held ? "steer" : "free";
	}
	move(e, t) {
		if (e.pointerType !== "touch" || !this.fingers.has(e.pointerId) || (this.fingers.set(e.pointerId, t), !this.held || !this.from || this.fingers.size < 2)) return null;
		let [n, r] = this.pair();
		return this.last = No(this.from.view, this.from.a, this.from.b, n, r, this.min, this.max), this.last;
	}
	up(e, t) {
		let n = this.held;
		return e.pointerType === "touch" && this.fingers.delete(e.pointerId), this.fingers.size === 0 ? (this.held = !1, this.from = null, this.last = null) : this.held && this.restart(t), n;
	}
	pair() {
		let e = this.fingers.values();
		return [e.next().value, e.next().value];
	}
	restart(e) {
		if (this.fingers.size < 2) {
			this.from = null;
			return;
		}
		let [t, n] = this.pair();
		this.from = {
			view: this.last ?? e,
			a: t,
			b: n
		};
	}
}, Fo = {
	bg: "#0b0c12",
	tint: "#ffffff",
	shade: "#000000",
	accent3: "#67e8f9",
	focus: "#b38bff",
	select: "#7cc4ff",
	handle: "#ffffff",
	checkerA: "#22232b",
	checkerB: "#1b1c22",
	pageCheckerA: "#ffffff",
	pageCheckerB: "#e4e4ea",
	text: "#f2f1f8",
	muted: "#a0a3b6",
	accent: "#ff7ab6",
	onAccent: "#14091c",
	stage: "#191a24"
}, Io = {
	bg: "--gs-bg",
	tint: "--gs-tint",
	shade: "--gs-shade",
	accent3: "--gs-accent-3",
	focus: "--gs-focus",
	select: "--gs-select",
	handle: "--gs-handle",
	checkerA: "--gs-checker-a",
	checkerB: "--gs-checker-b",
	pageCheckerA: "--gs-page-checker-a",
	pageCheckerB: "--gs-page-checker-b",
	text: "--gs-text",
	muted: "--gs-muted",
	accent: "--gs-accent",
	onAccent: "--gs-on-accent",
	stage: "--gs-stage"
};
function Lo(e) {
	if (typeof document > "u") return Fo;
	let t = getComputedStyle(e ?? document.documentElement), n = { ...Fo };
	for (let e of Object.keys(Io)) n[e] = t.getPropertyValue(Io[e]).trim() || Fo[e];
	return n;
}
function Ro(e, t) {
	let n = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(e.trim());
	if (!n) return e;
	let r = n[1].length === 3 ? [...n[1]].map((e) => e + e).join("") : n[1], [i, a, o] = [
		0,
		2,
		4
	].map((e) => parseInt(r.slice(e, e + 2), 16));
	return `rgba(${i},${a},${o},${t})`;
}
//#endregion
//#region src/edit/EditMode.tsx
var zo = k(() => import("./ModelMode-D8KMyCwU.js").then((e) => e.n).then((e) => ({ default: e.ModelMode })));
function Bo(e) {
	let t = document.createElement("canvas");
	t.width = e.width, t.height = e.height;
	let n = t.getContext("2d", { willReadFrequently: !0 });
	n.drawImage(e, 0, 0);
	let r = n.getImageData(0, 0, t.width, t.height);
	return {
		width: r.width,
		height: r.height,
		data: r.data
	};
}
function Vo(e, t, n, r = 640) {
	let i = document.createElement("canvas");
	i.width = e.width, i.height = e.height;
	let a = i.getContext("2d", { willReadFrequently: !0 });
	Ua(a, e, {
		...t,
		opacity: 1,
		blend: "normal",
		visible: !0,
		style: void 0
	}, n);
	let o = a.getImageData(0, 0, e.width, e.height).data, [s, c, l, u] = [
		e.width,
		e.height,
		-1,
		-1
	];
	for (let t = 0; t < e.height; t++) for (let n = 0; n < e.width; n++) o[(t * e.width + n) * 4 + 3] >= 128 && ([s, c, l, u] = [
		Math.min(s, n),
		Math.min(c, t),
		Math.max(l, n),
		Math.max(u, t)
	]);
	if (l < 0) return null;
	let d = Math.min(1, r / Math.max(l - s + 1, u - c + 1)), [f, p] = [Math.round((l - s + 1) * d) + 8, Math.round((u - c + 1) * d) + 8], m = document.createElement("canvas");
	m.width = f, m.height = p;
	let h = m.getContext("2d", { willReadFrequently: !0 });
	return h.drawImage(i, s, c, l - s + 1, u - c + 1, 4, 4, f - 8, p - 8), {
		rgba: h.getImageData(0, 0, f, p).data,
		width: f,
		height: p
	};
}
function Ho(e) {
	let t = document.createElement("canvas");
	return t.width = e.width, t.height = e.height, t.getContext("2d").putImageData(new ImageData(e.data, e.width, e.height), 0, 0), t;
}
var Uo = (e, t = "image/png", n) => new Promise((r, i) => e.toBlob((e) => e ? r(e) : i(/* @__PURE__ */ Error("The picture could not be made.")), t, n));
function Wo(e, t) {
	let n = URL.createObjectURL(e), r = document.createElement("a");
	r.href = n, r.download = t, r.click(), setTimeout(() => URL.revokeObjectURL(n), 1e3);
}
function Go(e) {
	return new Promise((t) => {
		let n = document.createElement("input");
		n.type = "file", n.accept = e, n.onchange = () => t(n.files?.[0] ?? null), n.click();
	});
}
async function Ko(e) {
	let t = new Image();
	return t.src = e, await t.decode(), Bo(t);
}
var qo = null, Jo = (e) => La(qo ??= document.createElement("canvas").getContext("2d"), e), Yo = [
	"system-ui, sans-serif",
	"Georgia, serif",
	"\"Trebuchet MS\", sans-serif",
	"Impact, sans-serif",
	"\"Courier New\", monospace",
	"\"Brush Script MT\", cursive"
], Xo = [
	"File",
	"Edit",
	"Select",
	"Layer",
	"Adjust",
	"Canvas",
	"View"
], Zo = (e) => `Command ${e} in packages/canvas/src/commands.ts; headless: npm run design, or the MCP tool design_run with command "${e}" (docs/MCP.md).`, Qo = new ci();
function $o(e) {
	return {
		surface: (e, t) => {
			let n = document.createElement("canvas");
			n.width = e, n.height = t;
			let r = n.getContext("2d", { willReadFrequently: !0 });
			return {
				ctx: r,
				canvas: n,
				read: () => ({
					width: e,
					height: t,
					data: r.getImageData(0, 0, e, t).data
				})
			};
		},
		image(t, n) {
			let r = e.get(t);
			return r || (r = Ho(n), e.set(t, r)), r;
		},
		path: (e) => new Path2D(e),
		async encode(e, t, n) {
			let r = await Uo(Ho(e), `image/${t}`, n);
			return new Uint8Array(await r.arrayBuffer());
		},
		async decode(e) {
			let t = await createImageBitmap(new Blob([e])), n = Bo(t);
			return t.close(), n;
		}
	};
}
var es = (e, t, n = !1) => {
	let r = t.x - e.x, i = t.y - e.y;
	if (n) {
		let e = Math.max(Math.abs(r), Math.abs(i));
		r = Math.sign(r || 1) * e, i = Math.sign(i || 1) * e;
	}
	return {
		x: Math.min(e.x, e.x + r),
		y: Math.min(e.y, e.y + i),
		width: Math.abs(r),
		height: Math.abs(i)
	};
}, ts = (e) => e.shiftKey && e.altKey ? "intersect" : e.shiftKey ? "add" : e.altKey ? "subtract" : "replace";
function ns({ open: e, title: t = "Design", onDone: n, doneLabel: r = "Done", onClose: i }) {
	let a = j(null), [o, s] = M(null), [c, l] = M(null), [u, d] = M(null), [f, p] = M("move"), [m, h] = M({
		main: "#1a1a1a",
		second: "#ffffff"
	}), [g, _] = M({
		size: 24,
		hardness: .6,
		flow: 1,
		steady: 0
	}), [v, y] = M({
		...wi,
		steady: 3
	}), [b, x] = M({
		on: !1,
		under: 2,
		gap: 4
	}), [S, C] = M({
		tolerance: 32,
		contiguous: !0
	}), [w, ee] = M({
		fill: "#e46a9b",
		stroke: null,
		strokeWidth: 4,
		radius: 0
	}), [te, ne] = M({
		font: Yo[0],
		size: 72,
		weight: 700
	}), [re, ie] = M(null), [ae, oe] = M(!1), [T, se] = M({
		zoom: 1,
		x: 0,
		y: 0
	}), [E, ce] = M(null), [D, O] = M(null), [le, ue] = M(null), [de, k] = M(null), [pe, ge] = M(null), [I, _e] = M(null), [ve, ye] = M(null), [be, xe] = M(null), [Se, Ce] = M(null), [we, Te] = M("layers"), [Ee, De] = M(null), [Oe, ke] = M(null), [Ae, L] = M(null), [je, Me] = M(!1), Ne = j(null), Pe = j(null), Fe = j(null), R = j(null), Ie = j(new Po(.05, 32)), Le = j(!1), Re = j(null), ze = j(null), Be = j(/* @__PURE__ */ new Map()), Ve = j([]), [He, Ue] = M({
		width: 0,
		height: 0
	}), We = he(() => $o(Be.current), []), z = () => a.current, Ge = a.current?.store ?? Qo, B = o && u ? hi(o, u) : void 0;
	A(() => {
		let t = !1;
		return (async () => {
			try {
				let n, r = new ci();
				if (e.kind === "project") {
					let t = await Za(e.file, Ko);
					r = t.store, n = t.doc;
				} else if (n = ui(e.width, e.height, e.background === void 0 ? "#ffffff" : e.background), e.kind === "pictures") for (let t of e.layers) n = gi(n, fi(t.name, r.add(Bo(t.picture)), {
					x: t.x ?? 0,
					y: t.y ?? 0
				}));
				if (t) return;
				a.current = new ao(We, n, r), s(n), d(n.layers[n.layers.length - 1]?.id ?? null);
			} catch (e) {
				t || l(e instanceof Error ? e.message : "This could not be opened.");
			}
		})(), () => {
			t = !0;
		};
	}, []);
	let Ke = () => {
		for (let e of [...Be.current.keys()]) z().store.get(e) || Be.current.delete(e);
	}, V = (e, t) => {
		z().commit(e, t), s(e), Ke();
	}, qe = () => {
		z().history.canUndo && s(z().history.undo());
	}, Je = () => {
		z().history.canRedo && s(z().history.redo());
	}, Ye = () => s(z().history.doc), Xe = (e) => {
		let t = Be.current.get(e);
		if (!t) {
			let n = z().store.get(e);
			if (!n) return;
			t = Ho(n), Be.current.set(e, t);
		}
		return t;
	}, Ze = {
		image: Xe,
		surface(e, t, n = 0) {
			let r = Ve.current[n] ??= document.createElement("canvas");
			(r.width !== e || r.height !== t) && (r.width = e, r.height = t);
			let i = r.getContext("2d");
			return i.setTransform(1, 0, 0, 1, 0, 0), i.globalCompositeOperation = "source-over", i.clearRect(0, 0, e, t), {
				ctx: i,
				canvas: r
			};
		},
		path: (e) => new Path2D(e)
	}, Qe = (e, t = !0) => {
		let n = document.createElement("canvas");
		return n.width = e.width, n.height = e.height, Wa(n.getContext("2d"), e, Ze, { background: t }), n;
	}, $e = (e) => {
		let t = Qe(e), n = t.getContext("2d", { willReadFrequently: !0 }).getImageData(0, 0, t.width, t.height);
		return {
			width: n.width,
			height: n.height,
			data: n.data
		};
	}, et = (e) => {
		if (!re) return;
		let { width: t, height: n, mask: r } = re;
		if (!e) return (e, i) => e >= 0 && i >= 0 && e < t && i < n ? r[i * t + e] / 255 : 0;
		let i = Fi(e.transform);
		return (e, a) => {
			let o = Li(i, {
				x: e + .5,
				y: a + .5
			}), s = Math.floor(o.x), c = Math.floor(o.y);
			return s >= 0 && c >= 0 && s < t && c < n ? r[c * t + s] / 255 : 0;
		};
	}, tt = (e = o) => {
		if (!e || !He.width) return;
		let t = Math.min(1, (He.width - 64) / e.width, (He.height - 150) / e.height);
		se({
			zoom: t,
			x: (He.width - e.width * t) / 2,
			y: (He.height - 90 - e.height * t) / 2 + 10
		});
	}, nt = (e, t = {
		x: He.width / 2,
		y: He.height / 2
	}) => se((n) => {
		let r = Math.min(32, Math.max(.05, n.zoom * e));
		return {
			zoom: r,
			x: t.x - (t.x - n.x) * r / n.zoom,
			y: t.y - (t.y - n.y) * r / n.zoom
		};
	});
	me(() => {
		let e = Ne.current;
		if (!e) return;
		let t = new ResizeObserver(() => Ue({
			width: e.clientWidth,
			height: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, [o === null]);
	let H = j(!1);
	A(() => {
		o && He.width && !H.current && (H.current = !0, tt(o));
	}, [o, He.width]);
	let rt = (e) => {
		let t = Pe.current.getBoundingClientRect();
		return {
			x: (e.clientX - t.left - T.x) / T.zoom,
			y: (e.clientY - t.top - T.y) / T.zoom
		};
	}, it = he(() => {
		if (!re) return null;
		let e = ra(re), t = document.createElement("canvas");
		t.width = re.width, t.height = re.height;
		let n = t.getContext("2d"), r = n.createImageData(t.width, t.height);
		for (let n = 0; n < e.length; n++) {
			if (!e[n]) continue;
			let i = n % t.width, a = i + (n - i) / t.width >> 2 & 1 ? 255 : 0;
			r.data.set([
				a,
				a,
				a,
				255
			], n * 4);
		}
		return n.putImageData(r, 0, 0), t;
	}, [re]), at = he(() => {
		let e = document.createElement("canvas");
		e.width = e.height = 16;
		let t = e.getContext("2d"), n = Lo();
		return t.fillStyle = n.pageCheckerA, t.fillRect(0, 0, 16, 16), t.fillStyle = n.pageCheckerB, t.fillRect(0, 0, 8, 8), t.fillRect(8, 8, 8, 8), e;
	}, []), ot = () => E?.kind === "line" && f === "line" ? pi("", {
		type: "line",
		x2: E.to.x - E.from.x,
		y2: E.to.y - E.from.y
	}, {
		fill: null,
		stroke: w.stroke ?? m.main,
		strokeWidth: w.strokeWidth
	}, {
		x: E.from.x,
		y: E.from.y
	}) : E?.kind === "rect" && (f === "rect" || f === "ellipse") ? pi("", f === "rect" ? {
		type: "rect",
		width: E.rect.width,
		height: E.rect.height,
		radius: w.radius
	} : {
		type: "ellipse",
		width: E.rect.width,
		height: E.rect.height
	}, w, {
		x: E.rect.x,
		y: E.rect.y
	}) : D && D.length ? pi("", {
		type: "path",
		path: {
			points: D,
			closed: !1
		}
	}, {
		fill: null,
		stroke: w.stroke ?? m.main,
		strokeWidth: Math.max(1, w.strokeWidth)
	}) : null, st = () => {
		let e = Pe.current;
		if (!e || !o) return;
		let t = Lo(e), n = window.devicePixelRatio || 1, r = Math.round(He.width * n), i = Math.round(He.height * n);
		(e.width !== r || e.height !== i) && (e.width = r, e.height = i);
		let a = e.getContext("2d");
		a.setTransform(1, 0, 0, 1, 0, 0), a.clearRect(0, 0, r, i);
		let s = T.zoom;
		a.setTransform(n * s, 0, 0, n * s, n * T.x, n * T.y), a.save(), a.shadowColor = Ro(t.shade, .5), a.shadowBlur = 30 * n;
		let c = a.createPattern(at, "repeat");
		c.setTransform(new DOMMatrix().scale(1 / s)), a.fillStyle = c, a.fillRect(0, 0, o.width, o.height), a.restore(), a.save(), a.beginPath(), a.rect(0, 0, o.width, o.height), a.clip(), a.imageSmoothingEnabled = s < 2;
		let l = ot();
		Wa(a, l ? {
			...o,
			layers: [...o.layers, l]
		} : o, Ze, { hide: de ? /* @__PURE__ */ new Set([de.id]) : void 0 }), a.restore();
		let u = 1 / s;
		if (it && (a.imageSmoothingEnabled = !1, a.drawImage(it, 0, 0)), a.lineWidth = u * 1.5, f === "move" && B && B.visible && !de) {
			let e = Bi(B, Ge);
			if (a.strokeStyle = t.select, a.beginPath(), e.forEach((e, t) => t ? a.lineTo(e.x, e.y) : a.moveTo(e.x, e.y)), a.closePath(), a.stroke(), !B.locked) {
				a.fillStyle = t.handle;
				for (let t of e) a.fillRect(t.x - 4 * u, t.y - 4 * u, 8 * u, 8 * u), a.strokeRect(t.x - 4 * u, t.y - 4 * u, 8 * u, 8 * u);
				let n = lt(B);
				a.beginPath(), a.moveTo((e[0].x + e[1].x) / 2, (e[0].y + e[1].y) / 2), a.lineTo(n.x, n.y), a.stroke(), a.beginPath(), a.arc(n.x, n.y, 5 * u, 0, Math.PI * 2), a.fill(), a.stroke();
			}
		}
		if (a.setLineDash([5 * u, 4 * u]), a.strokeStyle = t.handle, E?.kind === "rect" && (f === "box" || f === "oval")) {
			let e = E.rect;
			a.beginPath(), E.oval ? a.ellipse(e.x + e.width / 2, e.y + e.height / 2, e.width / 2, e.height / 2, 0, 0, Math.PI * 2) : a.rect(e.x, e.y, e.width, e.height), a.stroke();
		}
		if (E?.kind === "lasso" && (a.beginPath(), E.points.forEach((e, t) => t ? a.lineTo(e.x, e.y) : a.moveTo(e.x, e.y)), a.stroke()), E?.kind === "line" && f === "gradient") {
			a.setLineDash([]), a.strokeStyle = t.handle, a.beginPath(), a.moveTo(E.from.x, E.from.y), a.lineTo(E.to.x, E.to.y), a.stroke();
			for (let [e, t] of [[E.from, m.main], [E.to, m.second]]) a.fillStyle = t, a.beginPath(), a.arc(e.x, e.y, 6 * u, 0, Math.PI * 2), a.fill(), a.stroke();
		}
		let d = E?.kind === "crop" ? E.rect : le;
		if (d && f === "crop") {
			a.setLineDash([]), a.fillStyle = Ro(t.bg, .6), a.beginPath(), a.rect(-1e5, -1e5, 2e5, 2e5), a.rect(d.x, d.y, d.width, d.height), a.fill("evenodd"), a.strokeStyle = t.handle, a.strokeRect(d.x, d.y, d.width, d.height), a.strokeStyle = Ro(t.handle, .35);
			for (let e of [1 / 3, 2 / 3]) a.beginPath(), a.moveTo(d.x + d.width * e, d.y), a.lineTo(d.x + d.width * e, d.y + d.height), a.moveTo(d.x, d.y + d.height * e), a.lineTo(d.x + d.width, d.y + d.height * e), a.stroke();
		}
		if (a.setLineDash([]), D?.length && (a.strokeStyle = t.select, a.fillStyle = t.handle, D.forEach((e, n) => {
			for (let t of [e.in, e.out]) t && (a.beginPath(), a.moveTo(e.x, e.y), a.lineTo(e.x + t.x, e.y + t.y), a.stroke(), a.beginPath(), a.arc(e.x + t.x, e.y + t.y, 3 * u, 0, Math.PI * 2), a.fill());
			a.fillStyle = n === 0 ? t.select : t.handle, a.fillRect(e.x - 3.5 * u, e.y - 3.5 * u, 7 * u, 7 * u), a.strokeRect(e.x - 3.5 * u, e.y - 3.5 * u, 7 * u, 7 * u), a.fillStyle = t.handle;
		})), Ee && (f === "brush" || f === "eraser" || f === "clone" || f === "heal") && (a.strokeStyle = Ro(t.handle, .9), a.beginPath(), a.arc(Ee.x, Ee.y, g.size / 2, 0, Math.PI * 2), a.stroke(), a.strokeStyle = Ro(t.shade, .6), a.beginPath(), a.arc(Ee.x, Ee.y, g.size / 2 + u, 0, Math.PI * 2), a.stroke()), f === "clone" && Re.current) {
			let e = Re.current;
			a.strokeStyle = t.select, a.beginPath(), a.moveTo(e.x - 8 * u, e.y), a.lineTo(e.x + 8 * u, e.y), a.moveTo(e.x, e.y - 8 * u), a.lineTo(e.x, e.y + 8 * u), a.stroke();
		}
	}, ct = j(st);
	ct.current = st;
	let U = j(0), W = () => {
		U.current ||= requestAnimationFrame(() => {
			U.current = 0, ct.current();
		});
	};
	A(W);
	function lt(e) {
		let t = Bi(e, Ge), n = {
			x: (t[0].x + t[1].x) / 2,
			y: (t[0].y + t[1].y) / 2
		}, r = {
			x: (t[0].x + t[2].x) / 2,
			y: (t[0].y + t[2].y) / 2
		}, i = n.x - r.x, a = n.y - r.y, o = Math.hypot(i, a) || 1;
		return {
			x: n.x + i / o * (26 / T.zoom),
			y: n.y + a / o * (26 / T.zoom)
		};
	}
	let ut = (e, t) => {
		let n = 9 / T.zoom, r = lt(e);
		if (Math.hypot(t.x - r.x, t.y - r.y) < n) return "rotate";
		let i = Bi(e, Ge);
		for (let e = 0; e < 4; e++) if (Math.hypot(t.x - i[e].x, t.y - i[e].y) < n) return e;
		return null;
	}, dt = (e, t, n) => {
		let r = Li(Fi(e), n), i = Li(Fi({
			...t,
			x: 0,
			y: 0
		}), n);
		return {
			...t,
			x: r.x - i.x,
			y: r.y - i.y
		};
	}, ft = (e) => {
		let t = u ? hi(e, u) : void 0;
		if (t?.locked) return ke("That layer is locked. Unlock it in the layers list to paint on it."), null;
		if (t && ae && t.mask) return {
			doc: e,
			layer: t,
			field: "mask"
		};
		if (t?.kind === "raster") return {
			doc: e,
			layer: t,
			field: "pixels"
		};
		let n = fi("Paint", Ge.add(oi(e.width, e.height)));
		return d(n.id), {
			doc: gi(e, n, t?.id),
			layer: n,
			field: "pixels"
		};
	}, pt = (e, t, n) => {
		let r = n === "mask" ? t.mask : t.pixels, i = si(Ge.get(r)), a = Ge.add(i, n === "mask" ? "mask" : "px");
		return {
			next: q(e, t.id, { [n]: a }),
			working: i,
			id: a
		};
	}, mt = (e, t, n) => {
		if (!n) return;
		let r = Xe(e);
		r && (r.getContext("2d").putImageData(new ImageData(t.data, t.width, t.height), 0, 0, n.x, n.y, n.width, n.height), W());
	}, ht = (e) => {
		if (!o || de) return;
		e.preventDefault(), (!Fe.current?.contains(document.activeElement) || document.activeElement === document.body) && Fe.current?.focus({ preventScroll: !0 }), e.target.setPointerCapture(e.pointerId);
		let t = Ie.current.down(e, xt(e), T);
		if (t === "begin") return void St();
		if (t === "steer") return;
		_e(null), ke(null);
		let n = rt(e);
		if (Le.current || f === "hand" || e.button === 1) R.current = {
			kind: "pan",
			start: {
				x: e.clientX,
				y: e.clientY
			},
			view0: T
		};
		else switch (f) {
			case "move": {
				if (B && !B.locked && B.visible) {
					let e = ut(B, n);
					if (e === "rotate") return void (R.current = {
						kind: "rotate",
						start: n,
						doc0: o,
						layer0: B
					});
					if (e !== null) return void (R.current = {
						kind: "scale",
						corner: e,
						doc0: o,
						layer0: B
					});
				}
				let e = Vi(o, Ge, n) ?? (B && !B.locked && gt(B, n) ? B : void 0);
				e && (d(e.id), R.current = {
					kind: "move",
					start: n,
					doc0: o,
					layer0: e
				});
				return;
			}
			case "box":
			case "oval":
				R.current = {
					kind: "marquee",
					start: n,
					how: ts(e),
					oval: f === "oval"
				};
				return;
			case "lasso":
				R.current = {
					kind: "lasso",
					points: [n],
					how: ts(e)
				};
				return;
			case "wand": {
				let t = na($e(o), n, S.tolerance, S.contiguous), r = Qi(re, t, ts(e));
				ie(ea(r) ? r : null);
				return;
			}
			case "dropper": {
				let t = va($e(o), n);
				t && h((n) => e.altKey ? {
					...n,
					second: aa(t)
				} : {
					...n,
					main: aa(t)
				});
				return;
			}
			case "brush":
			case "eraser":
			case "clone":
			case "heal": {
				if (f === "clone" && e.altKey) {
					Re.current = n, W();
					return;
				}
				if (f === "clone" && !Re.current) {
					ke("Alt-click where to copy from first.");
					return;
				}
				let t = ft(o);
				if (!t) return;
				if (f === "heal" && t.field === "mask") {
					ke("Heal works on the picture, not on a mask.");
					return;
				}
				let { next: r, working: i, id: a } = pt(t.doc, t.layer, t.field), c = hi(r, t.layer.id), l = t.field === "mask" ? n : Ri(c, n), u = {
					kind: "paint",
					layerId: c.id,
					layer: c,
					field: t.field,
					working: i,
					id: a,
					stroke: sa(),
					steady: bi(f === "brush" || f === "eraser" ? xi(g.steady, g.size) : 0),
					clip: et(t.field === "mask" ? null : c)
				};
				if (f === "clone") {
					let e = t.field === "mask" ? Re.current : Ri(c, Re.current);
					u.clone = {
						snapshot: si(i),
						offset: {
							x: e.x - l.x,
							y: e.y - l.y
						}
					};
				}
				f === "heal" && (u.heal = {
					snapshot: si(i),
					cover: new Float32Array(i.width * i.height)
				}), R.current = u, s(r), vt(u, l);
				return;
			}
			case "ink": {
				let e = u ? hi(o, u) : void 0;
				if (e?.locked) return void ke("That layer is locked. Unlock it in the layers list to draw on it.");
				let t = o, r = e;
				(r?.kind !== "shape" || r.shape.type !== "ink") && (r = _o(m.main), t = gi(o, r, u ?? void 0), d(r.id));
				let i = r.shape.strokes, a = {
					kind: "ink",
					layerId: r.id,
					doc0: t,
					strokes0: i,
					stroke: { points: [] },
					steady: bi(xi(v.steady, v.size))
				};
				R.current = a, _t(a, Ri(r, n));
				return;
			}
			case "bucket":
			case "gradient": {
				if (f === "gradient") return void (R.current = {
					kind: "gradient",
					start: n
				});
				if (b.on) return void Ft("fill_inside_lines", {
					x: n.x,
					y: n.y,
					color: m.main,
					under: b.under,
					gap: b.gap
				});
				let e = ft(o);
				if (!e) return;
				let { next: t, working: r, id: i } = pt(e.doc, e.layer, e.field), a = hi(t, e.layer.id);
				fa(r, e.field === "mask" ? n : Ri(a, n), ia(m.main), S.tolerance, S.contiguous, et(e.field === "mask" ? null : a)) && (Xe(i), mt(i, r, {
					x: 0,
					y: 0,
					width: r.width,
					height: r.height
				}), V(t, "Fill"));
				return;
			}
			case "rect":
			case "ellipse":
			case "line":
				R.current = {
					kind: "shape",
					start: n,
					type: f
				};
				return;
			case "pen": {
				let e = D ?? [];
				if (e.length > 2 && Math.hypot(n.x - e[0].x, n.y - e[0].y) < 8 / T.zoom) {
					Tt(!0);
					return;
				}
				let t = [...e, {
					x: n.x,
					y: n.y
				}];
				O(t), R.current = {
					kind: "pen",
					index: t.length - 1
				};
				return;
			}
			case "text": {
				let e = [...o.layers].reverse().find((e) => e.kind === "text" && e.visible && !e.locked && gt(e, n));
				if (e) {
					d(e.id), k({
						id: e.id,
						fresh: !1
					});
					return;
				}
				let t = mi("", {
					font: te.font,
					size: te.size,
					weight: te.weight,
					color: m.main
				}, {
					x: n.x,
					y: n.y - te.size * .6
				}), r = {
					...t,
					box: Jo({
						...t,
						text: " "
					})
				};
				s(gi(o, r, u ?? void 0)), d(t.id), k({
					id: t.id,
					fresh: !0
				});
				return;
			}
			case "crop":
				ue(null), R.current = {
					kind: "crop",
					start: n
				};
				return;
			case "zoom":
				nt(e.altKey ? 1 / 1.6 : 1.6, {
					x: n.x * T.zoom + T.x,
					y: n.y * T.zoom + T.y
				});
				return;
		}
	}, gt = (e, t) => {
		let n = Ri(e, t), r = zi(e, Ge);
		return n.x >= r.x && n.y >= r.y && n.x <= r.x + r.width && n.y <= r.y + r.height;
	}, _t = (e, t, n = !1) => {
		let r = {
			size: v.size,
			taper: v.taper,
			speed: v.speed
		}, i = Si(e.steady, t);
		if (i && Ti(e.stroke, i, r), n) {
			for (let n of Ci(e.steady, t)) Ti(e.stroke, n, r);
			Ei(e.stroke, r);
		}
		let a = { points: e.stroke.points.map((e) => ({ ...e })) };
		s(q(e.doc0, e.layerId, { shape: {
			type: "ink",
			strokes: [...e.strokes0, a]
		} }));
	}, vt = (e, t, n = !1) => {
		if (e.steady.radius > 0) {
			let r = n ? Ci(e.steady, t) : [Si(e.steady, t)].filter((e) => !!e);
			for (let t of r) yt(e, t);
		} else n || yt(e, t);
	}, yt = (e, t) => {
		let n;
		if (e.heal) {
			let { cover: r } = e.heal;
			n = la(e.stroke, t, ua(g.size), (t) => (jo(r, e.working.width, e.working.height, t, g.size, g.hardness, e.clip), oa(e.working, t, {
				size: g.size,
				hardness: g.hardness,
				flow: .3,
				color: [
					96,
					96,
					96
				],
				mode: "paint"
			}, e.clip)));
		} else if (e.clone) {
			let { snapshot: r, offset: i } = e.clone;
			n = la(e.stroke, t, ua(g.size), (t) => ya(e.working, r, t, i, g, e.clip));
		} else {
			let r = e.field === "mask" ? f === "eraser" ? "hide" : "reveal" : f === "eraser" ? "erase" : "paint";
			n = da(e.working, e.stroke, t, {
				...g,
				color: ia(m.main),
				mode: r
			}, e.clip);
		}
		mt(e.id, e.working, n);
	}, bt = (e) => {
		if (!o) return;
		if (e.pointerType === "touch") {
			let t = Ie.current.move(e, xt(e));
			if (Ie.current.steering) return void (t && se(t));
		}
		let t = rt(e);
		(f === "brush" || f === "eraser" || f === "clone" || f === "heal") && De(t);
		let n = R.current;
		if (!n) D?.length && f === "pen" && W();
		else switch (n.kind) {
			case "pan":
				se({
					...n.view0,
					x: n.view0.x + e.clientX - n.start.x,
					y: n.view0.y + e.clientY - n.start.y
				});
				return;
			case "move": {
				let r = t.x - n.start.x, i = t.y - n.start.y;
				e.shiftKey && (Math.abs(r) > Math.abs(i) ? i = 0 : r = 0);
				let a = n.layer0.transform;
				s(q(n.doc0, n.layer0.id, { transform: {
					...a,
					x: a.x + r,
					y: a.y + i
				} }));
				return;
			}
			case "scale": {
				let r = zi(n.layer0, Ge), i = [
					{
						x: r.x,
						y: r.y
					},
					{
						x: r.x + r.width,
						y: r.y
					},
					{
						x: r.x + r.width,
						y: r.y + r.height
					},
					{
						x: r.x,
						y: r.y + r.height
					}
				], a = i[n.corner], o = i[(n.corner + 2) % 4], c = n.layer0.transform, l = Li(Ii(Fi(c)), t), u = (l.x - o.x) / (a.x - o.x || 1), d = (l.y - o.y) / (a.y - o.y || 1);
				if (e.shiftKey || n.layer0.kind === "text") {
					let e = Math.max(Math.abs(u), Math.abs(d));
					u = Math.sign(u || 1) * e, d = Math.sign(d || 1) * e;
				}
				let f = dt(c, {
					...c,
					scaleX: c.scaleX * (Math.abs(u) < .01 ? .01 : u),
					scaleY: c.scaleY * (Math.abs(d) < .01 ? .01 : d)
				}, o);
				s(q(n.doc0, n.layer0.id, { transform: f }));
				return;
			}
			case "rotate": {
				let r = zi(n.layer0, Ge), i = {
					x: r.x + r.width / 2,
					y: r.y + r.height / 2
				}, a = n.layer0.transform, o = Li(Fi(a), i), c = a.rotation + Math.atan2(t.y - o.y, t.x - o.x) - Math.atan2(n.start.y - o.y, n.start.x - o.x);
				e.shiftKey && (c = Gi(c)), s(q(n.doc0, n.layer0.id, { transform: dt(a, {
					...a,
					rotation: c
				}, i) }));
				return;
			}
			case "marquee":
				ce({
					kind: "rect",
					rect: es(n.start, t, e.shiftKey && n.how === "replace"),
					oval: n.oval
				});
				return;
			case "lasso":
				n.points.push(t), ce({
					kind: "lasso",
					points: [...n.points]
				});
				return;
			case "paint":
				vt(n, n.field === "mask" ? t : Ri(n.layer, t));
				return;
			case "ink": {
				let e = hi(n.doc0, n.layerId);
				e && _t(n, Ri(e, t));
				return;
			}
			case "gradient":
				ce({
					kind: "line",
					from: n.start,
					to: t
				});
				return;
			case "shape":
				if (n.type === "line") {
					let r = t;
					if (e.shiftKey) {
						let e = Gi(Math.atan2(t.y - n.start.y, t.x - n.start.x), Math.PI / 4), i = Math.hypot(t.x - n.start.x, t.y - n.start.y);
						r = {
							x: n.start.x + Math.cos(e) * i,
							y: n.start.y + Math.sin(e) * i
						};
					}
					ce({
						kind: "line",
						from: n.start,
						to: r
					});
				} else ce({
					kind: "rect",
					rect: es(n.start, t, e.shiftKey),
					oval: n.type === "ellipse"
				});
				return;
			case "pen": {
				if (!D) return;
				let e = D[n.index], r = {
					x: t.x - e.x,
					y: t.y - e.y
				};
				if (Math.hypot(r.x, r.y) < 3 / T.zoom) return;
				let i = [...D];
				i[n.index] = {
					...e,
					out: r,
					in: {
						x: -r.x,
						y: -r.y
					}
				}, O(i);
				return;
			}
			case "crop":
				ce({
					kind: "crop",
					rect: es(n.start, t, e.shiftKey)
				});
				return;
		}
	}, xt = (e) => {
		let t = Pe.current.getBoundingClientRect();
		return {
			x: e.clientX - t.left,
			y: e.clientY - t.top
		};
	}, St = () => {
		let e = R.current;
		R.current = null, ce(null), De(null), e && (e.kind === "pen" ? O((e) => e && e.length > 1 ? e.slice(0, -1) : null) : (e.kind === "move" || e.kind === "scale" || e.kind === "rotate" || e.kind === "paint") && Ye());
	}, Ct = (e) => {
		if (Ie.current.up(e, T)) return;
		let t = R.current;
		if (R.current = null, !t || !o) return;
		let n = rt(e);
		switch (t.kind) {
			case "move":
			case "scale":
			case "rotate":
				o !== t.doc0 && V(o, t.kind === "move" ? "Move" : t.kind === "scale" ? "Resize" : "Turn");
				return;
			case "marquee": {
				let r = es(t.start, n, e.shiftKey && t.how === "replace");
				if (ce(null), r.width < 2 && r.height < 2) {
					t.how === "replace" && ie(null);
					return;
				}
				let i = Qi(re, (t.oval ? Xi : Yi)(o.width, o.height, r), t.how);
				ie(ea(i) ? i : null);
				return;
			}
			case "lasso": {
				if (ce(null), t.points.length < 3) return;
				let e = Qi(re, Zi(o.width, o.height, t.points), t.how);
				ie(ea(e) ? e : null);
				return;
			}
			case "ink": {
				let e = hi(t.doc0, t.layerId);
				e && _t(t, Ri(e, n), !0);
				let r = { points: t.stroke.points.map((e) => ({ ...e })) };
				V(q(t.doc0, t.layerId, { shape: {
					type: "ink",
					strokes: [...t.strokes0, r]
				} }), "Ink");
				return;
			}
			case "paint":
				if (vt(t, t.field === "mask" ? n : Ri(t.layer, n), !0), t.heal) {
					let e = Mo(t.working, t.heal.snapshot, t.heal.cover);
					mt(t.id, t.working, e), V(o, "Heal");
					return;
				}
				V(o, f === "eraser" ? "Erase" : f === "clone" ? "Clone" : t.field === "mask" ? "Paint mask" : "Brush");
				return;
			case "gradient": {
				if (ce(null), Math.hypot(n.x - t.start.x, n.y - t.start.y) < 2) return;
				let e = ft(o);
				if (!e) return;
				let { next: r, working: i, id: a } = pt(e.doc, e.layer, e.field), s = hi(r, e.layer.id), c = (t) => e.field === "mask" ? t : Ri(s, t);
				_a(i, c(t.start), c(n), ia(m.main), ia(m.second), et(e.field === "mask" ? null : s)), Xe(a), mt(a, i, {
					x: 0,
					y: 0,
					width: i.width,
					height: i.height
				}), V(r, "Gradient");
				return;
			}
			case "shape": {
				let e = E;
				ce(null);
				let n = ot();
				if (!n || !e || !(e.kind === "line" ? Math.hypot(e.to.x - e.from.x, e.to.y - e.from.y) > 2 : e.kind === "rect" && e.rect.width > 2 && e.rect.height > 2)) return;
				let r = {
					...n,
					name: t.type === "rect" ? "Rectangle" : t.type === "ellipse" ? "Ellipse" : "Line"
				};
				V(gi(o, r, u ?? void 0), `Draw ${r.name.toLowerCase()}`), d(r.id);
				return;
			}
			case "crop": {
				let r = es(t.start, n, e.shiftKey);
				ce(null), ue(r.width > 4 && r.height > 4 ? r : null);
				return;
			}
			default: return;
		}
	}, wt = (e) => {
		if (!o) return;
		let t = Pe.current.getBoundingClientRect();
		e.ctrlKey || e.metaKey ? nt(Math.exp(-e.deltaY * .01), {
			x: e.clientX - t.left,
			y: e.clientY - t.top
		}) : se((t) => ({
			...t,
			x: t.x - e.deltaX,
			y: t.y - e.deltaY
		}));
	};
	A(() => {
		let e = Pe.current;
		if (!e) return;
		let t = (e) => e.preventDefault();
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, [o === null]);
	let Tt = (e) => {
		if (!o || !D || D.length < 2) {
			O(null);
			return;
		}
		let t = pi("Path", {
			type: "path",
			path: {
				points: D,
				closed: e
			}
		}, e ? {
			fill: w.fill,
			stroke: w.stroke,
			strokeWidth: w.strokeWidth
		} : {
			fill: null,
			stroke: w.stroke ?? m.main,
			strokeWidth: Math.max(1, w.strokeWidth)
		});
		V(gi(o, t, u ?? void 0), "Draw path"), d(t.id), O(null);
	}, Et = async () => {
		if (!o || !le) return;
		let e = le;
		ue(null), await Ft("crop", {
			x: e.x,
			y: e.y,
			width: e.width,
			height: e.height
		});
	}, G = de && o ? hi(o, de.id) : void 0, Dt = (e) => {
		if (!o || !G) return;
		let t = {
			...G,
			...e
		};
		s(q(o, G.id, {
			...e,
			box: Jo({
				...t,
				text: t.text || " "
			}),
			name: t.text.split("\n")[0].slice(0, 24) || "Text"
		}));
	}, Ot = () => {
		if (!o || !de) return;
		let e = hi(o, de.id);
		if (k(null), Fe.current?.focus({ preventScroll: !0 }), e) {
			if (e.text.trim()) V(o, de.fresh ? "Add text" : "Edit text");
			else {
				let t = _i(o, e.id);
				de.fresh ? s(z().history.doc) : V(t, "Delete text");
			}
		}
	}, Mt = async () => {
		if (!o || !B) return;
		let e = Vo(o, B, Ze), { modelFromPicture: t } = await import("./core-AdQZWWr9.js").then((e) => e.t), n = e && t(e.rgba, e.width, e.height, {
			name: B.name,
			viewAspect: .75
		});
		n ? ye({ design: n }) : ke("This layer has nothing solid to push out.");
	}, Nt = () => {
		let e = z();
		return e.selection = re, e.selectedId = u, e.colours = m, e.clipboard = ze.current, e;
	}, Pt = (e) => {
		s(e.doc), ie(e.selection), d(e.selectedId), h(e.colours), ze.current = e.clipboard, Ke();
	}, Ft = async (e, n = {}) => {
		let r = Nt();
		Me(!0);
		try {
			let i = await Oo(r, e, n);
			Pt(r), L(null), i?.file && Wo(new Blob([i.file.data], { type: i.file.type }), i.file.name.replace(/^design/, t)), ke(i?.message ?? null), (e === "new_canvas" || e === "crop" || e === "canvas_size") && setTimeout(() => tt(r.doc));
		} catch (e) {
			Pt(r), L(e instanceof Error ? e.message : String(e));
		} finally {
			Me(!1);
		}
	}, It = (e) => {
		let t = Nt(), n = e.blocked?.(t);
		if (n) return ke(n);
		let r = (e.params ?? []).filter((e) => e.type === "number" || e.type === "integer");
		if (!r.length) return void Ft(e.id);
		let i = r.map((e) => ({
			key: e.name,
			label: e.label,
			min: e.min ?? 0,
			max: e.max ?? 100,
			step: e.step ?? (e.type === "integer" ? 1 : .01),
			unit: e.unit,
			value: Number(typeof e.default == "function" ? e.default(t) : e.default ?? e.min ?? 0)
		})), a = 0;
		ge({
			title: e.label.replace("…", ""),
			fields: i,
			preview: e.preview ? (t) => {
				clearTimeout(a), a = window.setTimeout(async () => {
					let n = Nt();
					n.dry = !0;
					try {
						await Oo(n, e.id, t), s(n.doc);
					} catch {} finally {
						n.dry = !1, n.preview = null;
					}
				}, 120);
			} : void 0,
			apply: (t) => {
				clearTimeout(a), Ft(e.id, t);
			}
		});
	}, Lt = async (e, t) => {
		try {
			let n = await createImageBitmap(e), r = Bo(n);
			n.close(), await Ft("place_image", {
				image: r,
				name: t
			}), p("move");
		} catch {
			L("That file is not a picture this browser can open.");
		}
	};
	async function Rt() {
		let e = await Go(".gleam,application/json");
		if (e) try {
			let t = await Za(JSON.parse(await e.text()), Ko);
			Be.current.clear(), z().replace(t.doc, t.store), Pt(z()), setTimeout(() => tt(t.doc));
		} catch (e) {
			L(e instanceof Error ? e.message : "That file could not be opened.");
		}
	}
	let zt = o ? [
		{
			id: "open",
			menu: "File",
			label: "Open design…",
			keys: "Ctrl O",
			help: "Opens a saved .gleam design, with all its layers.",
			dev: "fromProject in packages/canvas (the .gleam JSON), then session().replace. MCP: design_open.",
			run: () => void Rt()
		},
		{
			id: "place",
			menu: "File",
			label: "Place a picture…",
			help: "Adds a picture from your computer as a new layer.",
			dev: Zo("place_image"),
			run: () => void Go("image/*").then((e) => e && Lt(e, e.name.replace(/\.[^.]+$/, "")))
		},
		{
			id: "new-3d",
			menu: "File",
			label: "New 3D object…",
			help: "Builds a 3D object from shapes in 3D mode and places it on a new layer.",
			dev: "ModelMode (packages/react/src/model3d/ModelMode.tsx), then the place_model command with the picture and its design.",
			run: () => ye({})
		},
		...[
			"png",
			"jpeg",
			"svg",
			"psd"
		].map((e) => ({
			id: `export-${e}`,
			menu: "File",
			label: e === "svg" ? "Export SVG (shapes and text stay vectors)" : e === "psd" ? "Export PSD (every layer, for Photoshop)" : `Export ${e.toUpperCase()}`,
			help: e === "svg" ? "Saves an SVG file; shapes and text stay sharp at any size." : e === "psd" ? "Saves a Photoshop file: each layer stays a layer with its name, opacity and blend; text and shapes become pixels." : `Saves the picture as a ${e.toUpperCase()} file.`,
			dev: e === "psd" ? `${Zo("export")} With format "psd": toPsd in packages/canvas/src/psd.ts (masks and styles baked in, PackBits).` : `${Zo("export")} With format "${e}".`,
			run: () => void Ft("export", { format: e })
		})),
		...Co.filter((e) => e.menu && e.id !== "export" && e.id !== "place_image").map((e) => ({
			id: e.id,
			menu: e.menu,
			label: e.label,
			keys: e.keys,
			help: e.description,
			dev: Zo(e.id),
			run: () => It(e),
			enabled: () => !e.blocked?.(Nt())
		})),
		{
			id: "edit-3d",
			menu: "Layer",
			label: "Edit 3D layer…",
			help: "Opens the picked 3D layer in 3D mode; when you finish, the layer is drawn again in place.",
			dev: "RasterLayer.model3d reopened in ModelMode; redraw_model gives the layer its new picture and keeps its size on the canvas.",
			enabled: () => B?.kind === "raster" && B.model3d !== void 0,
			run: () => B?.kind === "raster" && ye({
				layerId: B.id,
				design: B.model3d
			})
		},
		{
			id: "make-3d",
			menu: "Layer",
			label: "Make 3D (push out)…",
			help: "Pushes the picked layer’s shape (a logo, text, a cut-out) out into a solid in 3D mode; when you finish, it is placed as a new 3D layer.",
			dev: "layerPicture (the layer drawn alone) → modelFromPicture (scene3d: one extrude shape in its main colour) → ModelMode → place_model.",
			enabled: () => !!B && (B.kind !== "raster" || B.model3d === void 0),
			run: () => void Mt()
		},
		{
			id: "mask-edit",
			menu: "Layer",
			label: "Paint on mask (on/off)",
			help: "While on, the brush and eraser paint the layer’s mask: brush shows the layer, eraser hides it.",
			dev: "maskEdit state in EditMode.tsx: strokes go to layer.mask instead of the layer pixels (packages/canvas/src/paint.ts).",
			enabled: () => !!B?.mask,
			run: () => oe((e) => !e)
		},
		...[
			[
				"zoom-in",
				"Zoom in",
				"Ctrl +",
				"Shows the picture bigger.",
				() => nt(1.25)
			],
			[
				"zoom-out",
				"Zoom out",
				"Ctrl −",
				"Shows the picture smaller.",
				() => nt(.8)
			],
			[
				"fit",
				"Fit on screen",
				"Ctrl 0",
				"Shows the whole picture.",
				() => tt()
			],
			[
				"actual",
				"Actual pixels",
				"Ctrl 1",
				"Shows one picture pixel per screen pixel.",
				() => nt(1 / T.zoom)
			]
		].map(([e, t, n, r, i]) => ({
			id: e,
			menu: "View",
			label: t,
			keys: n,
			help: r,
			dev: "View only (view.zoom in EditMode.tsx); the document is not changed.",
			run: i
		}))
	] : [], Bt = () => void Ft("delete_layer"), K = (e) => {
		let t = zt.find((t) => t.id === e);
		t && (!t.enabled || t.enabled()) && t.run(), _e(null), Ce(null);
	}, Ht = (e) => {
		e.stopPropagation();
		let t = e.target, n = t.tagName === "TEXTAREA" || t.tagName === "INPUT" && ![
			"range",
			"checkbox",
			"color"
		].includes(t.type) || t.tagName === "SELECT";
		if (e.type === "keyup") {
			e.key === " " && (Le.current = !1);
			return;
		}
		if (n) {
			e.key === "Escape" && t.blur();
			return;
		}
		let r = e.ctrlKey || e.metaKey, i = e.key.toLowerCase(), a = r ? e.shiftKey ? {
			z: "redo",
			i: "invert_selection",
			n: "add_layer",
			"]": "arrange_front",
			"[": "arrange_back",
			"}": "arrange_front",
			"{": "arrange_back"
		} : {
			z: "undo",
			y: "redo",
			x: "cut",
			c: "copy",
			v: "paste",
			a: "select_all",
			d: "deselect",
			j: "duplicate_layer",
			e: "merge_down",
			i: "invert_colours",
			s: "save_design",
			o: "open",
			"]": "arrange_forward",
			"[": "arrange_backward",
			0: "fit",
			1: "actual",
			"=": "zoom-in",
			"+": "zoom-in",
			"-": "zoom-out"
		} : {};
		if (r && i === "k") {
			e.preventDefault(), Ce("");
			return;
		}
		if (r && a[i]) {
			e.preventDefault(), K(a[i]);
			return;
		}
		if (e.key === " ") {
			Le.current = !0, e.preventDefault();
			return;
		}
		if (e.key === "Escape") {
			Se === null ? pe ? (Ye(), ge(null)) : D ? O(null) : le ? ue(null) : re && ie(null) : Ce(null);
			return;
		}
		if (e.key === "Enter") {
			D ? Tt(!1) : le && Et();
			return;
		}
		if (e.key === "Delete" || e.key === "Backspace") {
			e.preventDefault(), e.altKey ? K("fill") : re && B?.kind === "raster" ? K("clear") : Bt();
			return;
		}
		if (e.key.startsWith("Arrow") && B && !B.locked && o) {
			e.preventDefault();
			let t = e.shiftKey ? 10 : 1, n = e.key === "ArrowLeft" ? -t : e.key === "ArrowRight" ? t : 0, r = e.key === "ArrowUp" ? -t : e.key === "ArrowDown" ? t : 0;
			V(q(o, B.id, { transform: {
				...B.transform,
				x: B.transform.x + n,
				y: B.transform.y + r
			} }), "Nudge");
			return;
		}
		if (e.key === "[" || e.key === "]") {
			let t = e.key === "]" ? 1.2 : 1 / 1.2;
			f === "ink" ? y((e) => ({
				...e,
				size: Math.max(.5, Math.min(400, Math.round(e.size * t * 10) / 10))
			})) : _((e) => ({
				...e,
				size: Math.max(1, Math.min(1e3, Math.round(e.size * t)))
			}));
			return;
		}
		if (i === "x") return void h((e) => ({
			main: e.second,
			second: e.main
		}));
		if (i === "d") return void h({
			main: "#1a1a1a",
			second: "#ffffff"
		});
		let s = At.find((t) => t.key === i && !!t.shift === e.shiftKey) ?? At.find((e) => e.key === i);
		s && Ut(s.id);
	}, Ut = (e) => {
		D && e !== "pen" && Tt(!1), e !== "crop" && ue(null), p(e), ke(null);
	};
	A(() => {
		let e = (e) => {
			let t = [...e.clipboardData?.files ?? []].find((e) => e.type.startsWith("image/"));
			t && (e.preventDefault(), Lt(t, "Pasted picture"));
		};
		return window.addEventListener("paste", e), () => window.removeEventListener("paste", e);
	}), A(() => {
		o && !pe && Se === null && !I && !de && (!Fe.current?.contains(document.activeElement) || document.activeElement === document.body) && Fe.current?.focus({ preventScroll: !0 });
	}, [
		o === null,
		pe,
		Se,
		I,
		de
	]);
	let Wt = async () => {
		if (o && n) {
			Me(!0);
			try {
				n(await Uo(Qe(o)));
			} finally {
				Me(!1);
			}
		}
	};
	if (c) return /* @__PURE__ */ F("div", {
		className: "gs-edit gs-edit--message",
		children: [/* @__PURE__ */ P("p", { children: c }), /* @__PURE__ */ P("button", {
			type: "button",
			className: "gs-edit__btn",
			onClick: i,
			children: "Close"
		})]
	});
	if (!o) return /* @__PURE__ */ P("div", {
		className: "gs-edit gs-edit--message",
		children: "Opening…"
	});
	let Gt = jt(f), Kt = z().history.list(), qt = ae && !!B?.mask, Jt = Se === null ? [] : zt.filter((e) => e.label.toLowerCase().includes(Se.toLowerCase())).slice(0, 12), Yt = G && (() => {
		let e = G.transform, t = zi(G);
		return {
			left: T.x + (e.x + t.x * e.scaleX) * T.zoom,
			top: T.y + e.y * T.zoom,
			fontSize: G.size * T.zoom * e.scaleY,
			width: Math.max(80, (G.box.width + G.size) * T.zoom * e.scaleX),
			rotation: e.rotation
		};
	})();
	return /* @__PURE__ */ F("div", {
		className: "gs-edit",
		ref: Fe,
		tabIndex: -1,
		onKeyDown: Ht,
		onKeyUp: Ht,
		children: [
			/* @__PURE__ */ F("header", {
				className: "gs-edit__top",
				children: [
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-edit__btn gs-edit__btn--ghost",
						onClick: i,
						title: "Leave Edit mode without keeping changes",
						children: "← Back"
					}),
					/* @__PURE__ */ P("strong", {
						className: "gs-edit__title",
						children: t
					}),
					/* @__PURE__ */ P("nav", {
						className: "gs-edit__menus",
						"aria-label": "Menus",
						children: Xo.map((e) => /* @__PURE__ */ F("div", {
							className: "gs-edit__menu",
							children: [/* @__PURE__ */ P("button", {
								type: "button",
								className: `gs-edit__menubtn ${I === e ? "is-open" : ""}`,
								onClick: () => _e(I === e ? null : e),
								onMouseEnter: () => I && _e(e),
								children: e
							}), I === e && /* @__PURE__ */ F("ul", {
								className: "gs-edit__dropdown",
								role: "menu",
								children: [zt.filter((t) => t.menu === e).map((e) => /* @__PURE__ */ P("li", {
									onMouseEnter: () => xe(e.id),
									children: /* @__PURE__ */ F("button", {
										type: "button",
										role: "menuitem",
										disabled: e.enabled ? !e.enabled() : !1,
										onClick: () => K(e.id),
										onFocus: () => xe(e.id),
										children: [/* @__PURE__ */ P("span", { children: e.label }), e.keys && /* @__PURE__ */ P("kbd", { children: e.keys })]
									})
								}, e.id)), /* @__PURE__ */ P("li", {
									className: "gs-edit__menuhelp",
									role: "none",
									children: (() => {
										let t = zt.find((t) => t.id === be && t.menu === e);
										return t ? /* @__PURE__ */ F(N, { children: [t.help, /* @__PURE__ */ P(Vt, { text: t.dev })] }) : "Point at an item to see what it does.";
									})()
								})]
							})]
						}, e))
					}),
					/* @__PURE__ */ F("button", {
						type: "button",
						className: "gs-edit__search",
						onClick: () => Ce(""),
						title: "Find any command (Ctrl K)",
						children: [
							/* @__PURE__ */ P(Ao, {
								name: "search",
								size: 15
							}),
							" Find a command ",
							/* @__PURE__ */ P("kbd", { children: "Ctrl K" })
						]
					}),
					/* @__PURE__ */ P("span", { className: "gs-edit__spacer" }),
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-edit__icon",
						onClick: qe,
						disabled: !z().history.canUndo,
						title: "Undo (Ctrl Z)",
						children: /* @__PURE__ */ P(Ao, { name: "undo" })
					}),
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-edit__icon",
						onClick: Je,
						disabled: !z().history.canRedo,
						title: "Redo (Ctrl Shift Z)",
						children: /* @__PURE__ */ P(Ao, { name: "redo" })
					}),
					/* @__PURE__ */ F("button", {
						type: "button",
						className: "gs-edit__zoom",
						onClick: () => tt(),
						title: "Fit on screen (Ctrl 0)",
						children: [Math.round(T.zoom * 100), "%"]
					}),
					n && /* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-edit__btn gs-edit__btn--primary",
						onClick: () => void Wt(),
						disabled: je,
						children: r
					})
				]
			}),
			/* @__PURE__ */ F("div", {
				className: "gs-edit__body",
				children: [/* @__PURE__ */ F("div", {
					className: "gs-edit__stage",
					ref: Ne,
					children: [
						/* @__PURE__ */ P("canvas", {
							ref: Pe,
							className: `gs-edit__canvas gs-edit__canvas--${Le.current || f === "hand" ? "hand" : f}`,
							onPointerDown: ht,
							onPointerMove: bt,
							onPointerUp: Ct,
							onPointerCancel: (e) => !Ie.current.up(e, T) && St(),
							onPointerLeave: () => De(null),
							onWheel: wt,
							onDoubleClick: () => f === "pen" && D && Tt(!1)
						}),
						G && Yt && /* @__PURE__ */ P("textarea", {
							className: "gs-edit__textedit",
							autoFocus: !0,
							value: G.text,
							placeholder: "Type here",
							onChange: (e) => Dt({ text: e.target.value }),
							onBlur: Ot,
							onKeyDown: (e) => {
								(e.key === "Escape" || e.key === "Enter" && (e.metaKey || e.ctrlKey)) && (e.preventDefault(), e.target.blur());
							},
							style: {
								left: Yt.left,
								top: Yt.top,
								width: Yt.width,
								font: Ia({
									...G,
									size: Yt.fontSize
								}),
								lineHeight: G.lineHeight,
								color: G.color,
								textAlign: G.align,
								transform: `rotate(${Yt.rotation}rad)`,
								height: (G.text.split("\n").length * G.lineHeight + .4) * Yt.fontSize
							}
						}),
						Ae && /* @__PURE__ */ F("div", {
							className: "gs-edit__problem",
							role: "alert",
							children: [
								/* @__PURE__ */ P("strong", { children: "Could not do that." }),
								" ",
								/* @__PURE__ */ P("span", { children: Ae }),
								/* @__PURE__ */ P("button", {
									type: "button",
									"aria-label": "Dismiss",
									onClick: () => L(null),
									children: "×"
								})
							]
						}),
						/* @__PURE__ */ F("div", {
							className: "gs-edit__options",
							role: "toolbar",
							"aria-label": `${Gt.label} options`,
							children: [
								/* @__PURE__ */ P("span", {
									className: "gs-edit__optname",
									children: qt && (f === "brush" || f === "eraser") ? `${Gt.label} on mask` : Gt.label
								}),
								/* @__PURE__ */ P(as, {
									tool: f,
									brush: g,
									setBrush: _,
									ink: v,
									setInk: y,
									fillLines: b,
									setFillLines: x,
									wand: S,
									setWand: C,
									shapeStyle: w,
									setShapeStyle: ee,
									textStyle: te,
									setTextStyle: ne,
									pen: D,
									finishPen: Tt,
									cropRect: le,
									applyCrop: Et,
									cancelCrop: () => ue(null)
								}),
								/* @__PURE__ */ F("span", {
									className: "gs-edit__hint",
									children: [Oe ?? Gt.hint, !Oe && /* @__PURE__ */ P(Vt, { text: Gt.dev })]
								})
							]
						}),
						/* @__PURE__ */ F("div", {
							className: "gs-edit__dock",
							role: "toolbar",
							"aria-label": "Tools",
							children: [/* @__PURE__ */ F("div", {
								className: "gs-edit__colors",
								title: "Main and second colour (X swaps, D resets)",
								children: [
									/* @__PURE__ */ P("label", {
										className: "gs-edit__swatch gs-edit__swatch--main",
										style: { background: m.main },
										children: /* @__PURE__ */ P("input", {
											type: "color",
											"aria-label": "Main colour",
											value: m.main,
											onChange: (e) => h((t) => ({
												...t,
												main: e.target.value
											}))
										})
									}),
									/* @__PURE__ */ P("label", {
										className: "gs-edit__swatch gs-edit__swatch--second",
										style: { background: m.second },
										children: /* @__PURE__ */ P("input", {
											type: "color",
											"aria-label": "Second colour",
											value: m.second,
											onChange: (e) => h((t) => ({
												...t,
												second: e.target.value
											}))
										})
									}),
									/* @__PURE__ */ P("button", {
										type: "button",
										className: "gs-edit__swap",
										onClick: () => h((e) => ({
											main: e.second,
											second: e.main
										})),
										title: "Swap colours (X)",
										children: /* @__PURE__ */ P(Ao, {
											name: "swap",
											size: 13
										})
									})
								]
							}), kt.map((e) => /* @__PURE__ */ P("div", {
								className: "gs-edit__group",
								"aria-label": e.name,
								children: e.tools.map((e) => /* @__PURE__ */ P("button", {
									type: "button",
									className: `gs-edit__tool ${f === e.id ? "is-active" : ""}`,
									"aria-pressed": f === e.id,
									title: `${e.label} (${e.shift ? "Shift " : ""}${e.key.toUpperCase()})`,
									onClick: () => Ut(e.id),
									children: /* @__PURE__ */ P(Ao, { name: e.id })
								}, e.id))
							}, e.name))]
						})
					]
				}), /* @__PURE__ */ F("aside", {
					className: "gs-edit__side",
					children: [/* @__PURE__ */ F("div", {
						className: "gs-edit__tabs",
						role: "tablist",
						children: [/* @__PURE__ */ P("button", {
							type: "button",
							role: "tab",
							"aria-selected": we === "layers",
							className: we === "layers" ? "is-active" : "",
							onClick: () => Te("layers"),
							children: "Layers"
						}), /* @__PURE__ */ P("button", {
							type: "button",
							role: "tab",
							"aria-selected": we === "history",
							className: we === "history" ? "is-active" : "",
							onClick: () => Te("history"),
							children: "History"
						})]
					}), we === "layers" ? /* @__PURE__ */ F(N, { children: [
						/* @__PURE__ */ P(ss, {
							doc: o,
							host: Ze,
							selectedId: u,
							maskEdit: ae,
							onSelect: (e) => {
								d(e), oe(!1);
							},
							onMaskSelect: (e) => {
								d(e), oe(!0);
							},
							onChange: (e, t, n) => V(q(o, e, t), n),
							onReorder: (e, t) => {
								let n = o.layers.findIndex((t) => t.id === e);
								V(vi(o, e, t - n), "Reorder");
							}
						}),
						/* @__PURE__ */ F("div", {
							className: "gs-edit__layerbar",
							children: [
								/* @__PURE__ */ P("button", {
									type: "button",
									className: "gs-edit__icon",
									title: "New picture layer",
									onClick: () => K("new-layer"),
									children: /* @__PURE__ */ P(Ao, { name: "plus" })
								}),
								/* @__PURE__ */ P("button", {
									type: "button",
									className: "gs-edit__icon",
									title: "Duplicate (Ctrl J)",
									disabled: !B,
									onClick: () => K("duplicate"),
									children: /* @__PURE__ */ P(Ao, { name: "copy" })
								}),
								/* @__PURE__ */ P("button", {
									type: "button",
									className: "gs-edit__icon",
									title: "Add mask",
									disabled: !B || !!B.mask,
									onClick: () => K("mask-add"),
									children: /* @__PURE__ */ P(Ao, { name: "mask" })
								}),
								/* @__PURE__ */ P("button", {
									type: "button",
									className: "gs-edit__icon",
									title: "Merge down (Ctrl E)",
									disabled: !B || o.layers.indexOf(B) === 0,
									onClick: () => K("merge"),
									children: /* @__PURE__ */ P(Ao, { name: "merge" })
								}),
								/* @__PURE__ */ P("button", {
									type: "button",
									className: "gs-edit__icon",
									title: "Delete layer",
									disabled: !B,
									onClick: Bt,
									children: /* @__PURE__ */ P(Ao, { name: "trash" })
								})
							]
						}),
						B && /* @__PURE__ */ P(ls, {
							layer: B,
							live: (e) => s(q(o, B.id, e)),
							commit: (e, t) => V(q(o, B.id, e), t),
							commitLive: (e) => V(o, e),
							measure: Jo
						}, B.id),
						/* @__PURE__ */ F("div", {
							className: "gs-edit__canvasprops",
							children: [
								/* @__PURE__ */ P("span", { children: "Canvas" }),
								/* @__PURE__ */ F("span", {
									className: "gs-edit__muted",
									children: [
										o.width,
										" × ",
										o.height
									]
								}),
								/* @__PURE__ */ F("label", {
									className: "gs-edit__inline",
									children: [/* @__PURE__ */ P("input", {
										type: "checkbox",
										checked: !o.background,
										onChange: (e) => V({
											...o,
											background: e.target.checked ? null : "#ffffff"
										}, "Canvas colour")
									}), "Transparent"]
								}),
								o.background && /* @__PURE__ */ P("input", {
									type: "color",
									"aria-label": "Canvas colour",
									value: o.background,
									onChange: (e) => V({
										...o,
										background: e.target.value
									}, "Canvas colour")
								})
							]
						})
					] }) : /* @__PURE__ */ P("ol", {
						className: "gs-edit__history",
						children: Kt.steps.map((e, t) => /* @__PURE__ */ P("li", { children: /* @__PURE__ */ P("button", {
							type: "button",
							className: t === Kt.at ? "is-active" : t > Kt.at ? "is-future" : "",
							onClick: () => s(z().history.goTo(t)),
							children: e.label
						}) }, t))
					})]
				})]
			}),
			ve && /* @__PURE__ */ P("div", {
				className: "gs-edit__model3d",
				children: /* @__PURE__ */ P(fe, {
					fallback: /* @__PURE__ */ P("div", {
						className: "gs-edit--message",
						children: "Loading 3D mode…"
					}),
					children: /* @__PURE__ */ P(zo, {
						open: ve.design,
						title: ve.layerId ? B?.name ?? "3D object" : "New 3D object",
						doneLabel: ve.layerId ? "Update the layer" : "Place in design",
						onClose: () => ye(null),
						onDone: (e, t) => {
							let n = ve.layerId;
							ye(null), (async () => {
								let r = await createImageBitmap(e), i = Bo(r);
								r.close(), n ? await Ft("redraw_model", {
									layer: n,
									image: i,
									model: JSON.stringify(t)
								}) : (await Ft("place_model", {
									image: i,
									model: JSON.stringify(t),
									name: "3D object"
								}), p("move"));
							})();
						}
					})
				})
			}),
			pe && /* @__PURE__ */ P(ds, {
				spec: pe,
				onCancel: () => {
					Ye(), ge(null);
				},
				onApply: (e) => {
					pe.apply(e), ge(null);
				}
			}),
			Se !== null && /* @__PURE__ */ P("div", {
				className: "gs-edit__scrim",
				onPointerDown: () => Ce(null),
				children: /* @__PURE__ */ F("div", {
					className: "gs-edit__palette",
					onPointerDown: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ P("input", {
						autoFocus: !0,
						placeholder: "What do you want to do?",
						value: Se,
						onChange: (e) => Ce(e.target.value),
						onKeyDown: (e) => {
							e.key === "Enter" && Jt[0] && (e.preventDefault(), K(Jt[0].id)), e.key === "Escape" && Ce(null);
						}
					}), /* @__PURE__ */ F("ul", { children: [Jt.map((e) => /* @__PURE__ */ P("li", { children: /* @__PURE__ */ F("button", {
						type: "button",
						disabled: e.enabled ? !e.enabled() : !1,
						onClick: () => K(e.id),
						children: [/* @__PURE__ */ F("span", {
							className: "gs-edit__palitem",
							children: [
								/* @__PURE__ */ F("span", { children: [
									/* @__PURE__ */ P("span", {
										className: "gs-edit__muted",
										children: e.menu
									}),
									" ",
									e.label
								] }),
								/* @__PURE__ */ P("span", {
									className: "gs-edit__palhelp",
									children: e.help
								}),
								/* @__PURE__ */ P(Vt, { text: e.dev })
							]
						}), e.keys && /* @__PURE__ */ P("kbd", { children: e.keys })]
					}) }, e.id)), !Jt.length && /* @__PURE__ */ P("li", {
						className: "gs-edit__muted",
						children: "Nothing matches."
					})] })]
				})
			})
		]
	});
}
function rs({ label: e, value: t, min: n, max: r, step: i, unit: a, onChange: o }) {
	return /* @__PURE__ */ F("label", {
		className: "gs-edit__slider",
		children: [
			/* @__PURE__ */ P("span", { children: e }),
			/* @__PURE__ */ P("input", {
				type: "range",
				min: n,
				max: r,
				step: i,
				value: t,
				onChange: (e) => o(Number(e.target.value))
			}),
			/* @__PURE__ */ F("output", { children: [Math.round(t * 100) / 100, a] })
		]
	});
}
function is({ label: e, value: t, onChange: n }) {
	return /* @__PURE__ */ F("span", {
		className: "gs-edit__colorpick",
		children: [
			/* @__PURE__ */ P("span", { children: e }),
			/* @__PURE__ */ P("input", {
				type: "checkbox",
				"aria-label": `${e} on`,
				checked: t !== null,
				onChange: (e) => n(e.target.checked ? "#1a1a1a" : null)
			}),
			t !== null && /* @__PURE__ */ P("input", {
				type: "color",
				"aria-label": e,
				value: t,
				onChange: (e) => n(e.target.value)
			})
		]
	});
}
function as(e) {
	switch (e.tool) {
		case "brush":
		case "eraser":
		case "clone": return /* @__PURE__ */ F(N, { children: [
			/* @__PURE__ */ P(rs, {
				label: "Size",
				min: 1,
				max: 500,
				step: 1,
				unit: "px",
				value: e.brush.size,
				onChange: (t) => e.setBrush((e) => ({
					...e,
					size: t
				}))
			}),
			/* @__PURE__ */ P(rs, {
				label: "Hardness",
				min: 0,
				max: 1,
				step: .01,
				value: e.brush.hardness,
				onChange: (t) => e.setBrush((e) => ({
					...e,
					hardness: t
				}))
			}),
			/* @__PURE__ */ P(rs, {
				label: "Flow",
				min: .02,
				max: 1,
				step: .01,
				value: e.brush.flow,
				onChange: (t) => e.setBrush((e) => ({
					...e,
					flow: t
				}))
			}),
			e.tool !== "clone" && /* @__PURE__ */ P(rs, {
				label: "Stabiliser",
				min: 0,
				max: 10,
				step: 1,
				value: e.brush.steady,
				onChange: (t) => e.setBrush((e) => ({
					...e,
					steady: t
				}))
			})
		] });
		case "ink": return /* @__PURE__ */ F(N, { children: [
			/* @__PURE__ */ P(rs, {
				label: "Size",
				min: .5,
				max: 60,
				step: .5,
				unit: "px",
				value: e.ink.size,
				onChange: (t) => e.setInk((e) => ({
					...e,
					size: t
				}))
			}),
			/* @__PURE__ */ P(rs, {
				label: "Taper",
				min: 0,
				max: 200,
				step: 1,
				unit: "px",
				value: e.ink.taper,
				onChange: (t) => e.setInk((e) => ({
					...e,
					taper: t
				}))
			}),
			/* @__PURE__ */ P(rs, {
				label: "Speed thins",
				min: 0,
				max: 1,
				step: .05,
				value: e.ink.speed,
				onChange: (t) => e.setInk((e) => ({
					...e,
					speed: t
				}))
			}),
			/* @__PURE__ */ P(rs, {
				label: "Stabiliser",
				min: 0,
				max: 10,
				step: 1,
				value: e.ink.steady,
				onChange: (t) => e.setInk((e) => ({
					...e,
					steady: t
				}))
			})
		] });
		case "wand":
		case "bucket": return /* @__PURE__ */ F(N, { children: [
			/* @__PURE__ */ P(rs, {
				label: "Tolerance",
				min: 0,
				max: 255,
				step: 1,
				value: e.wand.tolerance,
				onChange: (t) => e.setWand((e) => ({
					...e,
					tolerance: t
				}))
			}),
			/* @__PURE__ */ F("label", {
				className: "gs-edit__inline",
				children: [/* @__PURE__ */ P("input", {
					type: "checkbox",
					checked: e.wand.contiguous,
					onChange: (t) => e.setWand((e) => ({
						...e,
						contiguous: t.target.checked
					}))
				}), "Only touching pixels"]
			}),
			e.tool === "bucket" && /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ F("label", {
				className: "gs-edit__inline",
				children: [/* @__PURE__ */ P("input", {
					type: "checkbox",
					checked: e.fillLines.on,
					onChange: (t) => e.setFillLines((e) => ({
						...e,
						on: t.target.checked
					}))
				}), "Inside the ink lines"]
			}), e.fillLines.on && /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P(rs, {
				label: "Under the lines",
				min: 0,
				max: 10,
				step: 1,
				unit: "px",
				value: e.fillLines.under,
				onChange: (t) => e.setFillLines((e) => ({
					...e,
					under: t
				}))
			}), /* @__PURE__ */ P(rs, {
				label: "Close gaps",
				min: 0,
				max: 30,
				step: 1,
				unit: "px",
				value: e.fillLines.gap,
				onChange: (t) => e.setFillLines((e) => ({
					...e,
					gap: t
				}))
			})] })] })
		] });
		case "rect":
		case "ellipse":
		case "line":
		case "pen": return /* @__PURE__ */ F(N, { children: [
			e.tool !== "line" && /* @__PURE__ */ P(is, {
				label: "Fill",
				value: e.shapeStyle.fill,
				onChange: (t) => e.setShapeStyle((e) => ({
					...e,
					fill: t
				}))
			}),
			/* @__PURE__ */ P(is, {
				label: "Outline",
				value: e.shapeStyle.stroke,
				onChange: (t) => e.setShapeStyle((e) => ({
					...e,
					stroke: t
				}))
			}),
			/* @__PURE__ */ P(rs, {
				label: "Width",
				min: 0,
				max: 100,
				step: 1,
				unit: "px",
				value: e.shapeStyle.strokeWidth,
				onChange: (t) => e.setShapeStyle((e) => ({
					...e,
					strokeWidth: t
				}))
			}),
			e.tool === "rect" && /* @__PURE__ */ P(rs, {
				label: "Corners",
				min: 0,
				max: 300,
				step: 1,
				unit: "px",
				value: e.shapeStyle.radius,
				onChange: (t) => e.setShapeStyle((e) => ({
					...e,
					radius: t
				}))
			}),
			e.tool === "pen" && e.pen && e.pen.length > 1 && /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("button", {
				type: "button",
				className: "gs-edit__btn",
				onClick: () => e.finishPen(!1),
				children: "Finish open"
			}), /* @__PURE__ */ P("button", {
				type: "button",
				className: "gs-edit__btn",
				onClick: () => e.finishPen(!0),
				children: "Close shape"
			})] })
		] });
		case "text": return /* @__PURE__ */ F(N, { children: [
			/* @__PURE__ */ P("select", {
				"aria-label": "Font",
				value: e.textStyle.font,
				onChange: (t) => e.setTextStyle((e) => ({
					...e,
					font: t.target.value
				})),
				children: Yo.map((e) => /* @__PURE__ */ P("option", {
					value: e,
					children: e.split(",")[0].replace(/"/g, "")
				}, e))
			}),
			/* @__PURE__ */ P(rs, {
				label: "Size",
				min: 8,
				max: 400,
				step: 1,
				unit: "px",
				value: e.textStyle.size,
				onChange: (t) => e.setTextStyle((e) => ({
					...e,
					size: t
				}))
			}),
			/* @__PURE__ */ F("select", {
				"aria-label": "Weight",
				value: e.textStyle.weight,
				onChange: (t) => e.setTextStyle((e) => ({
					...e,
					weight: Number(t.target.value)
				})),
				children: [
					/* @__PURE__ */ P("option", {
						value: 400,
						children: "Regular"
					}),
					/* @__PURE__ */ P("option", {
						value: 700,
						children: "Bold"
					}),
					/* @__PURE__ */ P("option", {
						value: 900,
						children: "Heavy"
					})
				]
			})
		] });
		case "crop": return e.cropRect ? /* @__PURE__ */ F(N, { children: [
			/* @__PURE__ */ F("span", {
				className: "gs-edit__muted",
				children: [
					Math.round(e.cropRect.width),
					" × ",
					Math.round(e.cropRect.height)
				]
			}),
			/* @__PURE__ */ P("button", {
				type: "button",
				className: "gs-edit__btn gs-edit__btn--primary",
				onClick: e.applyCrop,
				children: "Crop"
			}),
			/* @__PURE__ */ P("button", {
				type: "button",
				className: "gs-edit__btn",
				onClick: e.cancelCrop,
				children: "Cancel"
			})
		] }) : null;
		default: return null;
	}
}
function os({ doc: e, layer: t, host: n, mask: r }) {
	let i = j(null);
	return A(() => {
		let a = i.current;
		if (!a) return;
		let o = Math.min(44 / e.width, 44 / e.height);
		a.width = Math.max(1, Math.round(e.width * o)), a.height = Math.max(1, Math.round(e.height * o));
		let s = a.getContext("2d");
		if (s.clearRect(0, 0, a.width, a.height), s.save(), s.scale(o, o), r && t.mask) {
			s.fillStyle = "#000", s.fillRect(0, 0, e.width, e.height);
			let r = n.image(t.mask);
			if (r) {
				let t = n.surface(e.width, e.height);
				t.ctx.fillStyle = "#fff", t.ctx.fillRect(0, 0, e.width, e.height), t.ctx.globalCompositeOperation = "destination-in", t.ctx.drawImage(r, 0, 0), s.drawImage(t.canvas, 0, 0);
			}
		} else Ua(s, e, {
			...t,
			opacity: 1,
			blend: "normal",
			mask: void 0,
			maskOff: !0
		}, n);
		s.restore();
	}), /* @__PURE__ */ P("canvas", {
		ref: i,
		className: "gs-edit__thumb"
	});
}
function ss({ doc: e, host: t, selectedId: n, maskEdit: r, onSelect: i, onMaskSelect: a, onChange: o, onReorder: s }) {
	let [c, l] = M(null), [u, d] = M(null);
	return e.layers.length ? /* @__PURE__ */ P("ul", {
		className: "gs-edit__layers",
		children: [...e.layers].reverse().map((f) => {
			let p = e.layers.indexOf(f);
			return /* @__PURE__ */ F("li", {
				className: `gs-edit__layer ${f.id === n ? "is-active" : ""} ${f.visible ? "" : "is-hidden"} ${u === f.id ? "is-dragging" : ""}`,
				draggable: c !== f.id,
				onDragStart: (e) => {
					d(f.id), e.dataTransfer.effectAllowed = "move";
				},
				onDragEnd: () => d(null),
				onDragOver: (e) => e.preventDefault(),
				onDrop: (e) => {
					e.preventDefault(), u && u !== f.id && s(u, p), d(null);
				},
				onClick: () => i(f.id),
				children: [
					/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-edit__icon gs-edit__icon--sm",
						title: f.visible ? "Hide" : "Show",
						onClick: (e) => (e.stopPropagation(), o(f.id, { visible: !f.visible }, f.visible ? "Hide layer" : "Show layer")),
						children: /* @__PURE__ */ P(Ao, {
							name: f.visible ? "eye" : "eyeOff",
							size: 16
						})
					}),
					/* @__PURE__ */ P("span", {
						className: `gs-edit__thumbwrap ${f.id === n && !r ? "is-target" : ""}`,
						children: /* @__PURE__ */ P(os, {
							doc: e,
							layer: f,
							host: t
						})
					}),
					f.mask && /* @__PURE__ */ P("span", {
						className: `gs-edit__thumbwrap ${f.id === n && r ? "is-target" : ""} ${f.maskOff ? "is-off" : ""}`,
						title: "Mask: click to paint on it",
						onClick: (e) => (e.stopPropagation(), a(f.id)),
						children: /* @__PURE__ */ P(os, {
							doc: e,
							layer: f,
							host: t,
							mask: !0
						})
					}),
					c === f.id ? /* @__PURE__ */ P("input", {
						className: "gs-edit__rename",
						autoFocus: !0,
						defaultValue: f.name,
						onClick: (e) => e.stopPropagation(),
						onBlur: (e) => {
							l(null), e.target.value.trim() && e.target.value !== f.name && o(f.id, { name: e.target.value.trim() }, "Rename");
						},
						onKeyDown: (e) => {
							e.key === "Enter" && e.target.blur(), e.key === "Escape" && l(null);
						}
					}) : /* @__PURE__ */ F("span", {
						className: "gs-edit__layername",
						onDoubleClick: () => l(f.id),
						title: "Double-click to rename",
						children: [f.name, /* @__PURE__ */ P("small", { children: f.kind === "raster" ? "picture" : f.kind === "text" ? "text" : f.shape.type === "path" ? "path" : f.shape.type === "ink" ? "ink" : "shape" })]
					}),
					/* @__PURE__ */ P("button", {
						type: "button",
						className: `gs-edit__icon gs-edit__icon--sm ${f.locked ? "is-on" : ""}`,
						title: f.locked ? "Unlock" : "Lock",
						onClick: (e) => (e.stopPropagation(), o(f.id, { locked: !f.locked }, f.locked ? "Unlock" : "Lock")),
						children: /* @__PURE__ */ P(Ao, {
							name: f.locked ? "lock" : "unlock",
							size: 15
						})
					})
				]
			}, f.id);
		})
	}) : /* @__PURE__ */ P("p", {
		className: "gs-edit__empty",
		children: "No layers yet. Draw, type, paint, or place a picture."
	});
}
var cs = (e) => Math.round(e * 180 / Math.PI * 10) / 10;
function ls({ layer: e, live: t, commit: n, commitLive: r, measure: i }) {
	let a = e.transform, o = (e, t, r, i = "") => /* @__PURE__ */ F("label", {
		className: "gs-edit__num",
		children: [
			/* @__PURE__ */ P("span", { children: e }),
			/* @__PURE__ */ P("input", {
				type: "number",
				value: Math.round(t * 10) / 10,
				onChange: (t) => {
					let i = Number(t.target.value);
					Number.isFinite(i) && n(r(i), `Set ${e.toLowerCase()}`);
				}
			}),
			i && /* @__PURE__ */ P("em", { children: i })
		]
	}), s = (t, r) => {
		let a = {
			...e,
			...t
		};
		n({
			...t,
			box: i({
				...a,
				text: a.text || " "
			})
		}, r);
	};
	return /* @__PURE__ */ F("section", {
		className: "gs-edit__props",
		children: [
			/* @__PURE__ */ F("label", {
				className: "gs-edit__slider",
				children: [
					/* @__PURE__ */ P("span", { children: "Opacity" }),
					/* @__PURE__ */ P("input", {
						type: "range",
						min: 0,
						max: 1,
						step: .01,
						value: e.opacity,
						onChange: (e) => t({ opacity: Number(e.target.value) }),
						onPointerUp: () => r("Opacity"),
						onKeyUp: () => r("Opacity")
					}),
					/* @__PURE__ */ F("output", { children: [Math.round(e.opacity * 100), "%"] })
				]
			}),
			/* @__PURE__ */ F("label", {
				className: "gs-edit__field",
				children: [/* @__PURE__ */ P("span", { children: "Mix" }), /* @__PURE__ */ P("select", {
					value: e.blend,
					onChange: (e) => n({ blend: e.target.value }, "Blend mode"),
					children: ni.map((e) => /* @__PURE__ */ P("option", {
						value: e.id,
						children: e.label
					}, e.id))
				})]
			}),
			/* @__PURE__ */ F("div", {
				className: "gs-edit__grid",
				children: [
					o("X", a.x, (e) => ({ transform: {
						...a,
						x: e
					} })),
					o("Y", a.y, (e) => ({ transform: {
						...a,
						y: e
					} })),
					o("Width", a.scaleX * 100, (e) => ({ transform: {
						...a,
						scaleX: e / 100 || .01
					} }), "%"),
					o("Height", a.scaleY * 100, (e) => ({ transform: {
						...a,
						scaleY: e / 100 || .01
					} }), "%"),
					o("Turn", cs(a.rotation), (e) => ({ transform: {
						...a,
						rotation: e * Math.PI / 180
					} }), "°")
				]
			}),
			e.kind === "shape" && /* @__PURE__ */ P(us, {
				layer: e,
				commit: n
			}),
			e.kind === "text" && /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ P("textarea", {
				className: "gs-edit__textprop",
				value: e.text,
				onChange: (e) => s({
					text: e.target.value,
					name: e.target.value.split("\n")[0].slice(0, 24) || "Text"
				}, "Edit text"),
				rows: 2
			}), /* @__PURE__ */ F("div", {
				className: "gs-edit__grid",
				children: [
					/* @__PURE__ */ F("label", {
						className: "gs-edit__field gs-edit__field--wide",
						children: [/* @__PURE__ */ P("span", { children: "Font" }), /* @__PURE__ */ P("select", {
							value: e.font,
							onChange: (e) => s({ font: e.target.value }, "Font"),
							children: Yo.map((e) => /* @__PURE__ */ P("option", {
								value: e,
								children: e.split(",")[0].replace(/"/g, "")
							}, e))
						})]
					}),
					o("Size", e.size, (t) => ({
						size: Math.max(1, t),
						box: i({
							...e,
							size: Math.max(1, t)
						})
					}), "px"),
					/* @__PURE__ */ F("label", {
						className: "gs-edit__field",
						children: [/* @__PURE__ */ P("span", { children: "Weight" }), /* @__PURE__ */ F("select", {
							value: e.weight,
							onChange: (e) => s({ weight: Number(e.target.value) }, "Weight"),
							children: [
								/* @__PURE__ */ P("option", {
									value: 400,
									children: "Regular"
								}),
								/* @__PURE__ */ P("option", {
									value: 700,
									children: "Bold"
								}),
								/* @__PURE__ */ P("option", {
									value: 900,
									children: "Heavy"
								})
							]
						})]
					}),
					/* @__PURE__ */ F("label", {
						className: "gs-edit__field",
						children: [/* @__PURE__ */ P("span", { children: "Colour" }), /* @__PURE__ */ P("input", {
							type: "color",
							value: e.color,
							onChange: (e) => n({ color: e.target.value }, "Text colour")
						})]
					}),
					/* @__PURE__ */ F("label", {
						className: "gs-edit__field",
						children: [/* @__PURE__ */ P("span", { children: "Align" }), /* @__PURE__ */ F("select", {
							value: e.align,
							onChange: (e) => s({ align: e.target.value }, "Align"),
							children: [
								/* @__PURE__ */ P("option", {
									value: "left",
									children: "Left"
								}),
								/* @__PURE__ */ P("option", {
									value: "center",
									children: "Centre"
								}),
								/* @__PURE__ */ P("option", {
									value: "right",
									children: "Right"
								})
							]
						})]
					}),
					/* @__PURE__ */ F("label", {
						className: "gs-edit__inline",
						children: [/* @__PURE__ */ P("input", {
							type: "checkbox",
							checked: e.italic,
							onChange: (e) => s({ italic: e.target.checked }, "Italic")
						}), "Italic"]
					})
				]
			})] })
		]
	});
}
function us({ layer: e, commit: t }) {
	return /* @__PURE__ */ F("div", {
		className: "gs-edit__grid",
		children: [
			e.shape.type === "ink" && /* @__PURE__ */ P(is, {
				label: "Ink",
				value: e.fill,
				onChange: (e) => t({ fill: e }, "Ink colour")
			}),
			e.shape.type !== "line" && e.shape.type !== "ink" && /* @__PURE__ */ P(is, {
				label: "Fill",
				value: e.fill,
				onChange: (e) => t({ fill: e }, "Fill colour")
			}),
			/* @__PURE__ */ P(is, {
				label: "Outline",
				value: e.stroke,
				onChange: (e) => t({ stroke: e }, "Outline colour")
			}),
			/* @__PURE__ */ F("label", {
				className: "gs-edit__num",
				children: [
					/* @__PURE__ */ P("span", { children: "Outline" }),
					/* @__PURE__ */ P("input", {
						type: "number",
						min: 0,
						value: e.strokeWidth,
						onChange: (e) => t({ strokeWidth: Math.max(0, Number(e.target.value) || 0) }, "Outline width")
					}),
					/* @__PURE__ */ P("em", { children: "px" })
				]
			}),
			e.shape.type === "rect" && /* @__PURE__ */ F("label", {
				className: "gs-edit__num",
				children: [
					/* @__PURE__ */ P("span", { children: "Corners" }),
					/* @__PURE__ */ P("input", {
						type: "number",
						min: 0,
						value: e.shape.radius,
						onChange: (n) => t({ shape: {
							...e.shape,
							radius: Math.max(0, Number(n.target.value) || 0)
						} }, "Corners")
					}),
					/* @__PURE__ */ P("em", { children: "px" })
				]
			})
		]
	});
}
function ds({ spec: e, onCancel: t, onApply: n }) {
	let [r, i] = M(() => Object.fromEntries(e.fields.map((e) => [e.key, e.value]))), a = (t, n) => {
		let a = {
			...r,
			[t]: n
		};
		i(a), e.preview?.(a);
	};
	return /* @__PURE__ */ P("div", {
		className: "gs-edit__scrim",
		children: /* @__PURE__ */ F("form", {
			className: "gs-edit__dialog",
			onSubmit: (e) => {
				e.preventDefault(), n(r);
			},
			children: [
				/* @__PURE__ */ P("h3", { children: e.title }),
				e.fields.map((e) => e.max - e.min > 1e3 ? /* @__PURE__ */ F("label", {
					className: "gs-edit__num gs-edit__num--wide",
					children: [
						/* @__PURE__ */ P("span", { children: e.label }),
						/* @__PURE__ */ P("input", {
							type: "number",
							min: e.min,
							max: e.max,
							step: e.step,
							value: r[e.key],
							onChange: (t) => a(e.key, Math.min(e.max, Math.max(e.min, Number(t.target.value) || e.min)))
						}),
						e.unit && /* @__PURE__ */ P("em", { children: e.unit })
					]
				}, e.key) : /* @__PURE__ */ P(rs, {
					label: e.label,
					min: e.min,
					max: e.max,
					step: e.step,
					unit: e.unit,
					value: r[e.key],
					onChange: (t) => a(e.key, t)
				}, e.key)),
				/* @__PURE__ */ F("div", {
					className: "gs-edit__dialogbar",
					children: [/* @__PURE__ */ P("button", {
						type: "button",
						className: "gs-edit__btn",
						onClick: t,
						children: "Cancel"
					}), /* @__PURE__ */ P("button", {
						type: "submit",
						className: "gs-edit__btn gs-edit__btn--primary",
						autoFocus: !0,
						children: "Apply"
					})]
				})
			]
		})
	});
}
//#endregion
//#region src/Workspace.tsx
var fs = k(() => import("./PhotoLab-CAAOzhnO.js").then((e) => e.n).then((e) => ({ default: e.PhotoLab }))), ps = k(() => import("./ModelMode-D8KMyCwU.js").then((e) => e.n).then((e) => ({ default: e.ModelMode }))), ms = (e) => e.ops.backdrop?.mode, hs = 32, gs = "the same photograph, the surface continued smoothly with the same material, colour and lighting as right around it, nothing new added, sharp focus", _s = "text, letters, words, logo, writing, new objects, pom pom, ball, flower, jewelry, pattern, stain, blotch, blurry, smudge", vs = (e) => Array.from({ length: Math.floor((e?.length ?? 0) / 4) }, (t, n) => ({
	x: e[n * 4],
	y: e[n * 4 + 1],
	width: e[n * 4 + 2],
	height: e[n * 4 + 3]
})), ys = [
	{
		key: "stickers",
		label: "Remove price stickers",
		title: "Reads the prices on the photo and paints the shop's price stickers out, so the photo stays right when the price changes."
	},
	{
		key: "lettering",
		label: "Repaint lettering and printed text",
		title: "For a character on a cover: paints the title and printed text out from the rest of the picture before the character is cut out. Does nothing for a whole box."
	},
	{
		key: "find",
		label: "Look the product up on the web (free; sends search words, not the photo)",
		title: "Reads the cover with a local model, searches the web (DuckDuckGo) with those words and uses the official pictures it finds. Free. The search words leave this computer; your photo never does."
	},
	{
		key: "thinParts",
		label: "Complete what the box hides, from official pictures",
		title: "Looks again along the character's outline for thin or detached parts (an antenna), and, when an official photo of this figure is found and lines up with the cover, finishes the parts the box's printing hides (a title band over the tail) from it, in this photo's colours. Those parts are flagged for you to check."
	},
	{
		key: "colour",
		label: "Match colours to the official picture",
		title: "Brings the box's colours to the product's own published picture. Needs the web lookup to find it.",
		needs: "find"
	},
	{
		key: "vivid",
		label: "Punchier colours",
		title: "After colours are matched to an official picture, make them 40% stronger: the punchy look of a ChatGPT redraw. Off keeps the published, softer colours.",
		needs: "colour"
	},
	{
		key: "look",
		label: "Brighten and sharpen",
		title: "The colour and sharpness look applied at the end."
	},
	{
		key: "gloss",
		label: "Studio gloss (changes the product; off unless ticked)",
		title: "Redraws the product as a glossy studio pack shot with Stable Diffusion, free, on this computer, about a minute. It changes the product itself: finish, small details and printed text may no longer match the real item, so the result is flagged for review. Needs npm run redraw:setup.",
		optIn: !0
	},
	{
		key: "enlarge",
		label: "Enlarge",
		title: "Makes the picture bigger with a local model. Printed text is enlarged the plain way, so the model cannot rewrite it; everything else gets its extra detail."
	},
	{
		key: "listing",
		label: "Write a title and description",
		title: "Writes a title and description with a local model, only from what was found. Needs the web lookup and the vision model (npm run vlm:setup).",
		needs: "find"
	}
], bs = /* @__PURE__ */ new Map();
function xs(e, t) {
	for (bs.set(e, t); bs.size > 4;) bs.delete(bs.keys().next().value);
}
function Ss({ editor: e, image: t, initialBackground: a, initialMasks: c, initialRepairs: l, initialEnlargements: h, initialFinishes: _, localApp: v, sourceBlob: y, startFrom: b, fullReport: S, onOpenProcessed: C, onBackToOriginal: ee, onEdited: te, exportOptions: re, onDone: ie, onCancel: ae, doneLabel: E, handToolsOnly: ce }) {
	let D = ge(e.subscribe, e.getSnapshot), { doc: O } = D, le = j(null), ue = j(null), de = j(null), [k, pe] = M(null), [me, N] = M({
		width: 0,
		height: 0
	}), [I, _e] = M(!1), [ve, ye] = M(!1), [be, xe] = M(!1), [Se, Ce] = M(!1), [we, Te] = M(!1), [Ee, De] = M({
		tool: "tap",
		brush: .02,
		tolerance: 25
	}), [Oe, ke] = M(!1), [Ae, L] = M(null), [je, Me] = M(null), [Ne, Fe] = M(null), [Be, Ve] = M(() => /* @__PURE__ */ new Map()), He = O.recipe.finish, Ue = He ? Be.get(He.ref)?.bitmap : void 0, We = he(() => Ue ? r({
		width: Ue.width,
		height: Ue.height
	}) : null, [Ue]), z = () => {
		Se || e.clearFinish(), Te(!1), Ce((e) => !e);
	}, Ge = () => {
		we || e.clearFinish(), Ce(!1), Te((e) => !e);
	}, B = he(() => {
		let { width: e, height: n } = o(t.width, t.height), r = document.createElement("canvas");
		r.width = e, r.height = n;
		let i = r.getContext("2d", { willReadFrequently: !0 });
		return i.drawImage(t, 0, 0, e, n), {
			pixels: i.getImageData(0, 0, e, n).data,
			width: e,
			height: n
		};
	}, [t]);
	A(() => {
		try {
			let e = new Sr(de.current);
			return e.setSource(t), pe(e), () => e.dispose();
		} catch (e) {
			L(e instanceof Error ? e.message : "The preview could not start.");
		}
	}, [t]), A(() => {
		let e = new ResizeObserver(([e]) => {
			let { width: t, height: n } = e.contentRect;
			N({
				width: t,
				height: n
			});
		});
		return e.observe(ue.current), le.current?.focus({ preventScroll: !0 }), () => e.disconnect();
	}, []);
	let Ke = he(() => I ? r(O.source) : We ?? (Se ? d(O) : O), [
		I,
		Se,
		O,
		We
	]), V = T(Ke), qe = T(We ?? O, re.maxSize), Je = Math.min((me.width - hs) / V.width, (me.height - hs) / V.height, 1), Ye = Math.max(1, Math.floor(V.width * Je)), Xe = Math.max(1, Math.floor(V.height * Je)), Ze = O.recipe.mask, Qe = he(() => u(B.pixels, B.width, B.height) > .5, [B]), [$e, et] = M(() => /* @__PURE__ */ new Map()), tt = j(/* @__PURE__ */ new Map()), nt = (e, t) => {
		tt.current.set(e, t), et((n) => new Map(n).set(e, t));
	}, H = () => {
		let t = e.document.recipe.mask;
		return t.length ? s(B.pixels, B.width, B.height, t, tt.current) : null;
	}, rt = he(() => Ze.length ? s(B.pixels, B.width, B.height, Ze, $e) : null, [
		Ze,
		B,
		$e
	]), at = p(Ze, $e).length;
	A(() => {
		if (!c) return;
		let e = !1;
		return (async () => {
			for (let [t, n] of Object.entries(c)) try {
				let r = await Le(typeof n == "string" ? await R(n) : n);
				e || nt(t, r);
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [c]);
	let ot = (t, r, i, a = !0) => {
		let o = i === "character" ? g(e.document, r.partsKept ? r : n(r)) : r, s = Array.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(6)), (e) => e.toString(16).padStart(2, "0")).join("");
		nt(s, o), e.addModelCutout(t, s, { replace: i === "character" }), a && ft();
	};
	A(() => {
		k && (I || !rt || Ue ? k.setMask(null) : k.setMask(rt, B.width, B.height, { despill: se(Ze) }));
	}, [
		k,
		rt,
		Ze,
		I,
		B,
		Ue
	]);
	let st = async (e, t) => {
		let n = await Pe(e, Math.min(4096, k?.maxTextureSize ?? 4096));
		Fe((r) => (r?.bitmap.close(), {
			bitmap: n,
			blob: e,
			name: t
		}));
	}, ct = (t) => {
		L(null), st(t, t.name).then(() => e.set("recipe/ops/backdrop/mode", "image", "Backdrop: Photo"), (e) => L(e instanceof Error ? e.message : "That background photo couldn't be opened."));
	};
	A(() => {
		if (!a) return;
		let e = !1;
		return (async () => {
			try {
				let t = typeof a == "string" ? await R(a) : a;
				e || await st(t, t instanceof File ? t.name : void 0);
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [a, k]), A(() => {
		k?.setBackground(Ne?.bitmap ?? null);
	}, [k, Ne]), A(() => () => Ne?.bitmap.close(), [Ne]);
	let U = O.recipe.words, W = bt(v), [lt, ut] = M(() => {
		try {
			return localStorage.getItem("gleamshelf:auto-enhance") !== "off";
		} catch {
			return !0;
		}
	}), dt = (e) => {
		ut(e);
		try {
			localStorage.setItem("gleamshelf:auto-enhance", e ? "on" : "off");
		} catch {}
	}, ft = () => {
		let t = e.document.recipe, n = t.ops.light?.exposure === 0 && t.ops.color?.vibrance === 0 && !t.effects.some((e) => e.id === "sharpen");
		lt && n && e.applyLook("bright-sharp");
	}, [pt, mt] = M(!1), [ht, gt] = M(() => /* @__PURE__ */ new Map()), _t = j(/* @__PURE__ */ new Map()), vt = (e, t) => {
		_t.current.set(e, t), gt((n) => new Map(n).set(e, t));
	}, [yt, St] = M(null), [Ct, Tt] = M(!1);
	A(() => {
		if (!l) return;
		let e = !1;
		return (async () => {
			for (let [t, n] of Object.entries(l)) try {
				let r = typeof n == "string" ? await R(n) : n, i = await createImageBitmap(r);
				e || vt(t, {
					bitmap: i,
					blob: r
				});
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [l]);
	let Et = (e = t) => {
		let n = Math.min(1, 2048 / Math.max(e.width, e.height)), r = Math.max(1, Math.round(e.width * n)), i = Math.max(1, Math.round(e.height * n)), a = document.createElement("canvas");
		a.width = r, a.height = i;
		let o = a.getContext("2d", { willReadFrequently: !0 });
		o.drawImage(e, 0, 0, r, i);
		let s = o.getImageData(0, 0, r, i), c = H(), l = new Uint8Array(r * i).fill(+!c);
		if (c) for (let e = 0; e < i; e++) {
			let t = Math.min(B.height - 1, Math.floor(e / i * B.height));
			for (let n = 0; n < r; n++) l[e * r + n] = +(c[t * B.width + Math.min(B.width - 1, Math.floor(n / r * B.width))] > 140);
		}
		return {
			w: r,
			h: i,
			pixels: s,
			inside: l
		};
	}, G = () => W.state === "ready" ? W.installed("inpaint")[0] ?? W.installed("redraw")[0] : void 0, Dt = (e, t) => e.task === "redraw" ? W.client.redraw(t.picture, {
		prompt: gs,
		negative: _s,
		strength: .99,
		steps: 24,
		guidance: 5,
		candidates: 3,
		seed: 5,
		stacked: !!t.region
	}) : W.client.inpaint(t.picture, e.id), Ot = async (e, n, r = t) => {
		let i = document.createElement("canvas");
		i.width = n.fullWidth, i.height = n.fullHeight;
		let a = i.getContext("2d");
		a.drawImage(r, 0, 0, n.fullWidth, n.fullHeight);
		let o = await createImageBitmap(e);
		return a.drawImage(o, n.x, n.y), o.close(), new Promise((e, t) => i.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be saved.")), "image/png"));
	}, kt = () => {
		let n = e.document.recipe.words?.ai;
		return n && _t.current.get(n.ref)?.bitmap || t;
	}, At = U?.ai ? ht.get(U.ai.ref)?.bitmap : void 0;
	A(() => {
		if (!U) {
			St((e) => e && (e.owned && e.bitmap.close(), null));
			return;
		}
		if (At) {
			St((e) => (e?.owned && e.bitmap.close(), {
				bitmap: At,
				filled: -1,
				owned: !1
			})), Tt(!1);
			return;
		}
		let e = !1;
		Tt(!0);
		let t = setTimeout(async () => {
			let { w: t, h: n, pixels: r, inside: i } = Et(), a = vs(U.stickers), o = a.length ? Xn(t, n, a, .003) : void 0, { image: s, filled: c } = or({
				width: t,
				height: n,
				data: r.data
			}, U, i, o, U.lettering !== !1), l = await createImageBitmap(new ImageData(new Uint8ClampedArray(s.data), t, n));
			if (e) return l.close();
			St((e) => (e?.owned && e.bitmap.close(), {
				bitmap: l,
				filled: c,
				owned: !0
			})), Tt(!1);
		}, 60);
		return () => {
			e = !0, clearTimeout(t);
		};
	}, [
		U,
		rt,
		t,
		B,
		At
	]), A(() => () => void (yt?.owned && yt.bitmap.close()), [yt]);
	let [jt, Mt] = M(() => /* @__PURE__ */ new Map());
	A(() => {
		if (!h) return;
		let e = !1;
		return (async () => {
			for (let [t, n] of Object.entries(h)) try {
				let r = typeof n == "string" ? await R(n) : n, i = await createImageBitmap(r);
				e || Mt((e) => new Map(e).set(t, {
					bitmap: i,
					blob: r
				}));
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [h]);
	let Nt = O.recipe.upscale, Pt = Nt ? jt.get(Nt.ref)?.bitmap : void 0;
	A(() => {
		if (!k) return;
		let e = Ue ?? Pt ?? yt?.bitmap ?? t;
		k.setSource(I ? t : e);
	}, [
		k,
		yt,
		Pt,
		I,
		t,
		Ue
	]), A(() => {
		if (!_) return;
		let e = !1;
		return (async () => {
			for (let [t, n] of Object.entries(_)) try {
				let r = typeof n == "string" ? await R(n) : n, i = await createImageBitmap(r);
				e || Ve((e) => new Map(e).set(t, {
					bitmap: i,
					blob: r
				}));
			} catch {}
		})(), () => {
			e = !0;
		};
	}, [_]);
	let [Ft, It] = M(!1), [Lt, Rt] = M(null), [zt, Bt] = M(null), Vt = async () => {
		if (!k) throw Error("The preview is not ready yet.");
		return (await k.export(e.document, {
			type: "image/png",
			maxSize: 1024
		})).blob;
	}, K = async (t, n) => {
		let r = W.state === "ready" ? W.installed("upscale")[0] : void 0, i = n;
		if (r) try {
			i = await W.client.upscale(n, r.id);
		} catch {}
		let a = await createImageBitmap(i), o = Math.min(2048, k?.maxTextureSize ?? 2048);
		if (Math.max(a.width, a.height) > o) {
			let e = o / Math.max(a.width, a.height), t = await createImageBitmap(a, {
				resizeWidth: Math.floor(a.width * e),
				resizeHeight: Math.floor(a.height * e),
				resizeQuality: "high"
			});
			a.close(), a = t;
			let n = document.createElement("canvas");
			n.width = a.width, n.height = a.height, n.getContext("2d").drawImage(a, 0, 0), i = await new Promise((e, t) => n.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be saved.")), "image/png"));
		}
		let s = Array.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(6)), (e) => e.toString(16).padStart(2, "0")).join("");
		Ve((e) => new Map(e).set(s, {
			bitmap: a,
			blob: i
		})), e.setFinish(t, s);
	}, Ht = () => {
		let e = W.state === "ready" ? W.installed("redraw")[0] : void 0;
		if (!e) throw Error("The redraw model is not ready: start the Gleamshelf app and set it up first.");
		return e;
	}, Wt = async (t) => {
		let n = zt;
		if (Bt(null), n) {
			It(!0), Rt(null), L(null);
			try {
				let r = Ht();
				e.commit();
				let i = await W.client.redraw(await Vt(), {
					prompt: n.prompt,
					strength: n.keepShape ? .6 : .99,
					steps: 25,
					box: t
				});
				await K(r.id, i), Rt("The area was redrawn. Compare it with the real item before listing.");
			} catch (e) {
				L(e instanceof Error ? `The redraw did not work: ${e.message}` : "The redraw did not work.");
			} finally {
				It(!1);
			}
		}
	}, Gt = async () => {
		let n = e.document.recipe.words?.ai, r = n && _t.current.get(n.ref)?.bitmap || yt?.bitmap || t, i = Math.min(1, 1024 / Math.max(r.width, r.height)), a = document.createElement("canvas");
		return a.width = Math.max(1, Math.round(r.width * i)), a.height = Math.max(1, Math.round(r.height * i)), a.getContext("2d").drawImage(r, 0, 0, a.width, a.height), new Promise((e, t) => a.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png"));
	}, qt = async (t, n) => {
		let r = await createImageBitmap(n), i = k?.maxTextureSize ?? 4096;
		if (Math.max(r.width, r.height) > i) {
			let e = i / Math.max(r.width, r.height), t = await createImageBitmap(r, {
				resizeWidth: Math.floor(r.width * e),
				resizeHeight: Math.floor(r.height * e),
				resizeQuality: "high"
			});
			r.close(), r = t;
		}
		let a = Array.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(6)), (e) => e.toString(16).padStart(2, "0")).join("");
		Mt((e) => new Map(e).set(a, {
			bitmap: r,
			blob: n
		})), e.setUpscale(t, a);
	}, Yt = async (e, { otherText: n, textModel: r, client: i, rebuild: a = !1, from: o = t, smoothOnly: s = !1, body: c, extra: l }) => {
		let u = Et(o), { w: d, h: f, pixels: p } = u, h = Math.max(d, f), g = a ? Zn(u.inside, d, f, Math.max(4, Math.round(h * .06))) : u.inside, _ = e.lettering === !1 ? new Uint8Array(d * f) : ar({
			width: d,
			height: f,
			data: p.data
		}, e, g), v = vs(e.stickers);
		v.length && (_ = Qn(_, Xn(d, f, v, .003)));
		let y = [], b = new Uint8Array(d * f), x = new Uint8Array(d * f), S = 0;
		if (n && r) {
			let e = await i.detectText(await Re(o), r), t = new Uint8Array(d * f);
			for (let n of e) {
				if (n.width * n.height > (a ? .2 : .05)) continue;
				let e = Math.max(0, Math.floor(n.x * d)), r = Math.min(d, Math.ceil((n.x + n.width) * d)), i = Math.max(0, Math.floor(n.y * f)), o = Math.min(f, Math.ceil((n.y + n.height) * f)), s = 0, l = 0;
				for (let t = i; t < o; t++) for (let n = e; n < r; n++) s++, g[t * d + n] || l++;
				if (s) {
					if (a && c) {
						let t = 0, n = 0;
						for (let a = i; a < o; a += 2) for (let i = e; i < r; i += 2) {
							let e = Math.min(c.width - 1, Math.floor(i / d * c.width)), r = Math.min(c.height - 1, Math.floor(a / f * c.height));
							n++, c.alpha[r * c.width + e] > 140 && t++;
						}
						if (n && t / n < .35) {
							let t = Math.max(2, Math.round(h * .004));
							y.push({
								x: Math.max(0, (e - t) / d),
								y: Math.max(0, (i - t) / f),
								width: Math.min(1, (r - e + 2 * t) / d),
								height: Math.min(1, (o - i + 2 * t) / f)
							});
							continue;
						}
					}
					if (l / s >= .2 && !a) {
						let t = Math.max(2, Math.round(h * .004));
						y.push({
							x: Math.max(0, (e - t) / d),
							y: Math.max(0, (i - t) / f),
							width: Math.min(1, (r - e + 2 * t) / d),
							height: Math.min(1, (o - i + 2 * t) / f)
						});
					} else if (a) {
						let e = cr({
							width: d,
							height: f,
							data: p.data
						}, n), r = 0;
						for (let t = 0; t < e.length; t++) r += +!!e[t];
						if (r === 0 && n.width * n.height > .004 && S++, r > n.width * d * n.height * f * .4) {
							S++;
							continue;
						}
						let i = n.height < .02 ? x : t;
						for (let t = 0; t < e.length; t++) e[t] && (i[t] = 1);
					} else for (let n = i; n < o; n++) for (let i = e; i < r; i++) g[n * d + i] && (t[n * d + i] = 1);
				}
			}
			a ? b = t : _ = Qn(_, t);
		}
		if (s) {
			for (let e = 0; e < _.length; e++) (_[e] || b[e]) && (x[e] = 1);
			_ = new Uint8Array(d * f), b = new Uint8Array(d * f);
		}
		if (l) {
			if (a) for (let e = 0; e < l.length; e++) b[e] ||= l[e];
			else _ = Qn(_, l);
		}
		let C = x.some(Boolean), w = S;
		if (!_.some(Boolean) && !b.some(Boolean) && !C && y.length === 0) return null;
		_ = Zn(_, d, f, Math.max(2, Math.round(h * (a ? .0015 : .005)))), b.some(Boolean) && (_ = Qn(_, Zn(b, d, f, Math.max(3, Math.round(h * .006)))));
		let ee = C ? Qn(_, Zn(x, d, f, Math.max(3, Math.round(h * .009)))) : _;
		if (a) {
			let e = (() => {
				let e = H();
				return e ? m(e, B.width, B.height) : null;
			})(), t = .05, n = e ? Math.max(0, Math.floor((e.x - t) * d)) : 0, r = e ? Math.max(0, Math.floor((e.y - t) * f)) : 0, i = e ? Math.min(d, Math.ceil((e.x + e.width + t) * d)) : d, a = e ? Math.min(f, Math.ceil((e.y + e.height + t) * f)) : f, o = i - n, s = a - r, c = $n({
				width: d,
				height: f,
				data: p.data
			}, ee).data, l = new Uint8ClampedArray(o * s * 2 * 4);
			for (let e = 0; e < s; e++) for (let t = 0; t < o; t++) {
				let i = ((r + e) * d + n + t) * 4, a = (e * o + t) * 4;
				l[a] = c[i], l[a + 1] = c[i + 1], l[a + 2] = c[i + 2], l[a + 3] = 255;
				let u = ((s + e) * o + t) * 4, f = _[(r + e) * d + n + t] ? 255 : 0;
				l[u] = l[u + 1] = l[u + 2] = f, l[u + 3] = 255;
			}
			let u = 0;
			for (let e = 0; e < ee.length; e++) u += +!!ee[e];
			if (!_.some(Boolean)) {
				let e = document.createElement("canvas");
				return e.width = o, e.height = s, e.getContext("2d").putImageData(new ImageData(l.slice(0, o * s * 4), o, s), 0, 0), {
					picture: await new Promise((t, n) => e.toBlob((e) => e ? t(e) : n(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png")),
					cutAway: y,
					region: {
						x: n,
						y: r,
						width: o,
						height: s,
						fullWidth: d,
						fullHeight: f
					},
					share: u / ee.length,
					skipped: w,
					done: !0
				};
			}
			let h = document.createElement("canvas");
			return h.width = o, h.height = s * 2, h.getContext("2d").putImageData(new ImageData(l, o, s * 2), 0, 0), {
				picture: await new Promise((e, t) => h.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png")),
				cutAway: y,
				region: {
					x: n,
					y: r,
					width: o,
					height: s,
					fullWidth: d,
					fullHeight: f
				},
				share: u / ee.length,
				skipped: w
			};
		}
		let te = new Uint8ClampedArray(p.data);
		for (let e = 0; e < d * f; e++) te[e * 4 + 3] = _[e] ? 0 : 255;
		let ne = document.createElement("canvas");
		return ne.width = d, ne.height = f, ne.getContext("2d").putImageData(new ImageData(te, d, f), 0, 0), {
			picture: await new Promise((e, t) => ne.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png")),
			cutAway: y,
			share: 0
		};
	}, Xt = async () => {
		let e = W.installed("text-detect")[0], n = W.installed("text-read")[0];
		if (!e || !n) throw Error("Reading prices needs the text finder and the text reader: install both with the commands in the AI panel.");
		let r = await W.client.readText(await Re(t)), i = /[$＄¥￥]\s*\d|\d\s*[$＄]|\d+\s*円/, { w: a, h: o, pixels: s } = Et(), c = {
			width: a,
			height: o,
			data: s.data
		}, l = [];
		for (let e of r) {
			if (!i.test(e.text) || e.score < .5) continue;
			let t = {
				x: Math.max(0, e.x - e.width * .6),
				y: Math.max(0, e.y - e.height * 1),
				width: Math.min(1, e.width * 2.6),
				height: Math.min(1, e.height * 3.2)
			}, n = tr(c, t);
			(n.width * n.height > .06 || n.x === t.x && n.y === t.y && n.width === t.width) && (n = {
				x: Math.max(0, e.x - e.width * .25),
				y: Math.max(0, e.y - e.height * .5),
				width: Math.min(1, e.width * 1.5),
				height: Math.min(1, e.height * 2)
			}), l.length < 28 && l.push(n.x, n.y, Math.min(n.width, 1 - n.x), Math.min(n.height, 1 - n.y));
		}
		return l;
	}, Zt = async (e, { lettering: t, stickerBoxes: n, body: r }) => {
		let i = kt(), { w: a, h: o, pixels: s, inside: c } = Et(i), l = Math.max(a, o), u = s.data, d = (e) => {
			let t = document.createElement("canvas");
			return t.width = a, t.height = o, t.getContext("2d").putImageData(new ImageData(new Uint8ClampedArray(e), a, o), 0, 0), new Promise((e, n) => t.toBlob((t) => t ? e(t) : n(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png"));
		}, p = async (t) => {
			let n = new Uint8ClampedArray(u);
			for (let e = 0; e < a * o; e++) t[e] && (n[e * 4 + 3] = 0);
			let r = await createImageBitmap(await W.client.inpaint(await d(n), e.id)), i = document.createElement("canvas");
			i.width = a, i.height = o;
			let s = i.getContext("2d", { willReadFrequently: !0 });
			s.drawImage(r, 0, 0, a, o), r.close();
			let c = s.getImageData(0, 0, a, o).data, l = new Uint8ClampedArray(u);
			for (let e = 0; e < a * o; e++) if (t[e]) for (let t = 0; t < 3; t++) l[e * 4 + t] = c[e * 4 + t];
			return l;
		}, m = () => new Uint8Array(a * o), h = m();
		if (t) {
			let e = Zn(c, a, o, Math.max(4, Math.round(l * .06)));
			h = Zn(ar({
				width: a,
				height: o,
				data: u
			}, { ...f }, e), a, o, Math.max(1, Math.round(l * .001)));
		}
		let g = n.length ? Xn(a, o, vs(n), .003) : m(), _ = [], v = 0, y = m(), b = W.installed("text-detect")[0];
		if (t && b) {
			let e = m();
			for (let t of await W.client.detectText(await Re(i), b.id)) {
				if (t.width * t.height > .05) {
					v++;
					continue;
				}
				let n = Math.max(0, Math.floor(t.x * a)), i = Math.min(a, Math.ceil((t.x + t.width) * a)), s = Math.max(0, Math.floor(t.y * o)), c = Math.min(o, Math.ceil((t.y + t.height) * o));
				if (r) {
					let e = 0, t = 0;
					for (let l = s; l < c; l += 2) for (let s = n; s < i; s += 2) {
						let n = Math.min(r.width - 1, Math.floor(s / a * r.width)), i = Math.min(r.height - 1, Math.floor(l / o * r.height));
						t++, r.alpha[i * r.width + n] > 140 && e++;
					}
					if (t && e / t < .35) {
						let e = Math.max(2, Math.round(l * .004));
						_.push({
							x: Math.max(0, (n - e) / a),
							y: Math.max(0, (s - e) / o),
							width: Math.min(1, (i - n + 2 * e) / a),
							height: Math.min(1, (c - s + 2 * e) / o)
						});
						continue;
					}
				}
				let u = Math.max(4, Math.round(l * .005));
				for (let t = Math.max(0, s - u); t < Math.min(o, c + u); t++) for (let r = Math.max(0, n - u); r < Math.min(a, i + u); r++) e[t * a + r] = 1;
			}
			e.some(Boolean) && (y = mr({
				width: a,
				height: o,
				data: u
			}, {
				width: a,
				height: o,
				data: await p(e)
			}, e));
		}
		let x = Qn(Qn(h, g), y);
		return x.some(Boolean) ? {
			picture: await d(await p(x)),
			cutAway: _,
			skipped: v
		} : {
			picture: null,
			cutAway: _,
			skipped: v
		};
	}, Qt = async ({ lettering: t, stickers: n, add: r = [], body: i }) => {
		let a = G();
		if (!a) return {
			result: "no-ai",
			stickersFound: 0
		};
		let o = W.installed("text-detect")[0], s = [...e.document.recipe.words?.stickers ?? []], c;
		if (n) {
			s = [];
			try {
				s = await Xt();
			} catch (e) {
				c = e instanceof Error ? e.message : "Price stickers could not be searched for.";
			}
		}
		if (s = [...s, ...r].slice(0, 28), a.task === "inpaint") {
			let n = await Zt(a, {
				lettering: t,
				stickerBoxes: s,
				body: i
			});
			return n.picture ? (e.setWords(!0, {
				lettering: t,
				stickers: s
			}), await dn(a.id, n.picture, n.cutAway, !1), {
				result: "filled",
				stickersFound: s.length / 4,
				stickerNote: c,
				skipped: n.skipped
			}) : {
				result: "nothing",
				stickersFound: 0,
				stickerNote: c,
				skipped: n.skipped
			};
		}
		let l = {
			...f,
			...t ? {} : { lettering: !1 },
			...s.length ? { stickers: s } : {}
		}, u = await Yt(l, {
			otherText: t && !!o,
			textModel: o?.id,
			client: W.client,
			rebuild: a.task === "redraw",
			body: i
		});
		if (!u) return {
			result: "nothing",
			stickersFound: 0,
			stickerNote: c
		};
		let d = u.skipped ?? 0;
		e.setWords(!0, {
			lettering: t,
			stickers: s
		});
		let p = u.done ? u.picture : await Dt(a, u);
		if (await dn(a.id, u.region ? await Ot(p, u.region) : p, u.cutAway, a.task !== "redraw"), a.task === "redraw" && t) try {
			let e = await Yt({ ...f }, {
				otherText: !!o,
				textModel: o?.id,
				client: W.client,
				rebuild: !0,
				from: kt(),
				smoothOnly: !0
			});
			if (e?.region && e.share > 0 && e.share < u.share * .5) {
				let t = kt(), n = e.done ? e.picture : await Dt(a, e);
				await dn(a.id, await Ot(n, e.region, t), []);
			}
		} catch {}
		return {
			result: "filled",
			stickersFound: s.length / 4,
			stickerNote: c,
			skipped: d
		};
	}, $t = async () => {
		if (!G()) return void e.setWords(!0);
		mt(!0);
		try {
			(await Qt({
				lettering: !0,
				stickers: !!W.installed("text-read")[0]
			})).result === "nothing" && e.setWords(!0);
		} catch (e) {
			L(e instanceof Error ? `The AI fill did not work: ${e.message}` : "The AI fill did not work.");
		} finally {
			mt(!1);
		}
	}, [en, tn] = M(!1), [nn, rn] = M("sticker"), an = async (t, n) => {
		tn(!1), cn(null), mt(!0);
		try {
			let { w: r, h: i, pixels: a } = Et(), o = {
				x: Math.max(0, t - .06),
				y: Math.max(0, n - .035),
				width: .12,
				height: .07
			}, s = tr({
				width: r,
				height: i,
				data: a.data
			}, o);
			s.width * s.height > .05 && (s = {
				x: Math.max(0, t - .03),
				y: Math.max(0, n - .02),
				width: .06,
				height: .04
			});
			let c = e.document.recipe.words ? e.document.recipe.words.lettering !== !1 : !1, { result: l } = await Qt({
				lettering: c,
				stickers: !1,
				add: [
					s.x,
					s.y,
					Math.min(s.width, 1 - s.x),
					Math.min(s.height, 1 - s.y)
				]
			});
			cn(l === "no-ai" ? "Needs an AI fill: start the Gleamshelf app and set up the redraw model (or install LaMa)." : "Removed the sticker you pointed at.");
		} catch (e) {
			cn(e instanceof Error ? e.message : "The sticker could not be removed.");
		} finally {
			mt(!1);
		}
	}, on = async (t, n) => {
		tn(!1), cn(null), mt(!0);
		try {
			let r = G();
			if (!r) return void cn("Needs an AI fill: start the Gleamshelf app and set up the redraw model (or install LaMa).");
			let i = kt(), { w: a, h: o, pixels: s } = Et(i), c = {
				x: t * a,
				y: n * o
			}, l = {
				x0: c.x - a * .3,
				y0: c.y - o * .08,
				x1: c.x + a * .3,
				y1: c.y + o * .08
			}, u = W.installed("text-detect")[0];
			if (u) {
				let e = await W.client.detectText(await Re(i), u.id), r = (e, r) => t >= e.x - r && t <= e.x + e.width + r && n >= e.y - r && n <= e.y + e.height + r, s = (e) => Math.hypot(t - (e.x + e.width / 2), n - (e.y + e.height / 2)), c = e.filter((e) => r(e, 0)).sort((e, t) => e.width * e.height - t.width * t.height)[0] ?? e.filter((e) => r(e, .015)).sort((e, t) => s(e) - s(t))[0], d = .012;
				c && (l = {
					x0: (c.x - d) * a,
					y0: (c.y - d) * o,
					x1: (c.x + c.width + d) * a,
					y1: (c.y + c.height + d) * o
				});
			}
			let d = ur({
				width: a,
				height: o,
				data: s.data
			}, l, c);
			if (!("mask" in d)) return void cn(d.problem === "too-much" ? "That colour covers too much of the area to be sure it is print, so nothing was taken off. Click a letter of the text itself, not the picture behind it." : "No printed text was found at that point. Click right on a letter (a second click takes off a second colour).");
			let p = e.document.recipe.words, m = {
				...p ?? f,
				lettering: !1,
				stickers: void 0,
				ai: void 0
			}, h = await Yt(m, {
				otherText: !1,
				client: W.client,
				rebuild: r.task === "redraw",
				from: i,
				extra: d.mask
			});
			if (!h) return void cn("Nothing to take off there.");
			let g = !!e.document.recipe.upscale;
			p || e.setWords(!0, { lettering: !1 });
			let _ = h.done ? h.picture : await Dt(r, h);
			await dn(r.id, h.region ? await Ot(_, h.region, i) : _, [], r.task !== "redraw"), cn(`Took off the printed text you pointed at${g ? " (the enlarging was reset: run Sharpen & enlarge again)" : ""}.`);
		} catch (e) {
			cn(e instanceof Error ? e.message : "The printed text could not be removed.");
		} finally {
			mt(!1);
		}
	}, [sn, cn] = M(null), ln = async () => {
		cn(null), mt(!0);
		try {
			let t = e.document.recipe.words ? e.document.recipe.words.lettering !== !1 : !1, { result: n, stickersFound: r, stickerNote: i } = await Qt({
				lettering: t,
				stickers: !0
			});
			cn(n === "no-ai" ? "Needs an AI fill: start the Gleamshelf app and set up the redraw model (or install LaMa)." : i ?? (r ? `Removed ${r} price sticker${r === 1 ? "" : "s"}.` : "No price sticker found. A sticker with no clear price on it can be painted out with the cut-out brush."));
		} catch (e) {
			cn(e instanceof Error ? e.message : "The price stickers could not be removed.");
		} finally {
			mt(!1);
		}
	}, un = (e) => {
		let t = H(), n = t && m(t, B.width, B.height);
		if (!n) return e;
		let r = e.filter((e) => e.y >= n.y + n.height * .65);
		if (!r.length) return e;
		let i = Math.max(n.y, Math.min(...r.map((e) => e.y)) - .004);
		return [...e.filter((e) => !r.includes(e)), {
			x: 0,
			y: i,
			width: 1,
			height: 1 - i
		}];
	}, dn = async (t, n, r = [], i = !0) => {
		let a = await createImageBitmap(n), o = Array.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(6)), (e) => e.toString(16).padStart(2, "0")).join("");
		vt(o, {
			bitmap: a,
			blob: n
		}), r.length && e.eraseBoxes(i ? un(r) : r), e.setWordsAi(t, o), ft();
	}, fn = (t) => {
		let n = H(), r = n && m(n, B.width, B.height);
		return r ? (e.begin("Studio photo"), e.set("recipe/ops/backdrop/mode", "color"), e.set("recipe/ops/backdrop/color", "#ffffff"), e.fitSquareToProduct(r, .07), t?.shadow !== !1 && !e.effects.some((e) => e.id === "drop-shadow") && e.addEffect("drop-shadow", {
			opacity: .22,
			blur: 16,
			offsetX: 0,
			offsetY: 20,
			color: "#000000"
		}), e.commit(), !0) : !1;
	}, [pn, mn] = M(!1), [hn, gn] = M(null), _n = async () => {
		let e = H();
		if (!e) return gn("Cut the product out first.");
		mn(!0), gn(null);
		try {
			let n = document.createElement("canvas");
			n.width = t.width, n.height = t.height;
			let r = n.getContext("2d", { willReadFrequently: !0 });
			r.drawImage(t, 0, 0);
			let i = r.getImageData(0, 0, t.width, t.height), a = Yn({
				width: i.width,
				height: i.height,
				data: i.data
			}, e, B.width, B.height);
			if (!a) {
				gn("This is not a flat four-cornered product (a card, a box front, a print), so it was left as it is.");
				return;
			}
			let o = document.createElement("canvas");
			o.width = a.image.width, o.height = a.image.height, o.getContext("2d").putImageData(new ImageData(new Uint8ClampedArray(a.image.data), a.image.width, a.image.height), 0, 0), await C(await new Promise((e, t) => o.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("Could not save it.")), "image/png")), !0, null);
		} catch (e) {
			gn(e instanceof Error ? e.message : "It could not be straightened.");
		} finally {
			mn(!1);
		}
	}, [vn, yn] = M(!1), [bn, xn] = M(null), Sn = async (t) => {
		if (!k || vn) return;
		let n = H(), r = n && m(n, B.width, B.height);
		if (!r) return xn("Cut the product out first.");
		yn(!0), xn(null);
		try {
			e.commit();
			let n = e.document, i = n.source.name || "photo", a = [], o = Infinity;
			for (let e of t) {
				let t = w(e);
				if (!t) continue;
				let s = ne(n, r, t), c = T(s);
				o = Math.min(o, Math.max(c.width, c.height));
				let l = await k.export(s, {
					size: t.size,
					type: t.type,
					maxBytes: t.maxBytes,
					background: "#ffffff"
				});
				a.push({
					name: x(i, t),
					bytes: new Uint8Array(await l.blob.arrayBuffer())
				});
			}
			let s = new Blob([wt(a)], { type: "application/zip" }), c = URL.createObjectURL(s), l = document.createElement("a");
			l.href = c, l.download = `${i.replace(/\.[^.]+$/, "") || "photo"}-listing-set.zip`, l.click(), setTimeout(() => URL.revokeObjectURL(c), 1e4), xn(`Saved ${a.length} picture${a.length === 1 ? "" : "s"}: ${a.map((e) => e.name.replace(/^.*-/, "")).join(", ")}.` + (o < 1e3 ? ` The photo has about ${Math.round(o)} px across the product, so the larger sizes are stretched: use Sharpen and enlarge (Adjust) first for crisp zoom.` : "") + (e.finish ? " The finishing touches are not in the set: they were drawn for this framing only." : ""));
		} catch (e) {
			xn(e instanceof Error ? e.message : "The listing set could not be made.");
		} finally {
			yn(!1);
		}
	}, Cn = async (e, t) => {
		let n = await W.client.processPicture(e, "cutout"), r = t?.quality && t.quality.fidelity.original < 1 ? await W.client.processPicture(e, "changes").then((e) => URL.createObjectURL(e), () => void 0) : void 0, i = await W.client.processPicture(e, "promo").then((e) => URL.createObjectURL(e), () => void 0);
		await C(n, t?.modeUsed !== "character", t ? {
			...t,
			changesUrl: r,
			promoUrl: i,
			runId: e
		} : null);
	}, wn = W.client, Tn = he(() => ({
		status: () => wn.shopStatus(),
		connect: (e, t) => wn.shopConnect(e, t),
		send: (e) => wn.sendRun(e)
	}), [wn]), [En, Dn] = M([]), On = j(/* @__PURE__ */ new Map()), kn = async () => {
		try {
			let e = await W.client.recentRuns();
			for (let t of e.slice(0, 8)) if (!On.current.has(t.id)) {
				let e = await W.client.processPicture(t.id, "studio").catch(() => null);
				e && On.current.set(t.id, URL.createObjectURL(e));
			}
			nr.current && Dn(e.map((e) => ({
				...e,
				thumb: On.current.get(e.id)
			})));
		} catch {}
	};
	A(() => {
		W.state === "ready" && W.canProcess && kn();
	}, [W.state, W.canProcess]);
	let An = async (e) => {
		try {
			let t = await W.client.processStatus(e);
			await Cn(e, t.report);
		} catch (e) {
			L(e instanceof Error ? e.message : "That result could not be opened.");
		}
	}, [jn, Mn] = M(() => {
		try {
			let e = localStorage.getItem("gleamshelf:auto-mode");
			return e === "character" || e === "auto" ? e : "product";
		} catch {
			return "product";
		}
	}), Nn = (e) => {
		Mn(e);
		try {
			localStorage.setItem("gleamshelf:auto-mode", e);
		} catch {}
	}, [Pn, Fn] = M(null), [In, zn] = M(null), [Bn, Vn] = M(!1), [Hn, Un] = M(null), Wn = () => Un((e) => {
		if (e) for (let t of Object.values(e.thumbs)) URL.revokeObjectURL(t);
		return null;
	});
	A(() => () => Wn(), []);
	let Gn = async (e) => {
		if (Hn && !Hn.sent) {
			Un({
				...Hn,
				sent: !0
			});
			try {
				await W.client.chooseReferences(Hn.job, e), Un((t) => t && {
					...t,
					ticked: e ?? t.online.photos.filter((e) => e.linesUp).map((e) => e.index)
				});
			} catch (e) {
				Un((e) => e && {
					...e,
					sent: !1
				}), L(e instanceof Error ? e.message : "The app did not take the choice.");
			}
		}
	}, Kn = (e, t) => {
		try {
			let n = localStorage.getItem(e);
			return n === null ? t : n === "on";
		} catch {
			return t;
		}
	}, [qn, Jn] = M(() => Object.fromEntries(ys.map((e) => [e.key, !e.optIn && Kn(`gleamshelf:full-${e.key}`, !0)]))), er = (e, t) => {
		if (Jn((n) => ({
			...n,
			[e]: t
		})), !ys.find((t) => t.key === e)?.optIn) try {
			localStorage.setItem(`gleamshelf:full-${e}`, t ? "on" : "off");
		} catch {}
	}, nr = j(!0);
	A(() => (nr.current = !0, () => {
		nr.current = !1;
	}), []);
	let rr = j(!1);
	A(() => {
		b && !rr.current && (rr.current = !0, ot("pipeline", b.mask, "product", !1), fn({ shadow: b.shadow }));
	}, []);
	let ir = async () => {
		if (Bn || !y) return;
		e.commit(), L(null), Vn(!0), Wn();
		let t = (e) => Fn(e.map((e) => ({
			label: e.name,
			state: e.state,
			startedAt: e.startedAt,
			seconds: e.seconds
		}))), n = null, r = !1, i = () => {
			r = !0, n && W.client.cancelProcess(n).catch(() => {});
		};
		try {
			t([{
				name: "Sending the photo to the Gleamshelf app (it stays on this computer)",
				state: "running"
			}]);
			let e = qn.find, a = e && qn.colour, o = await W.client.startProcess(y, {
				mode: jn,
				find: e,
				listing: e && qn.listing,
				colour: a,
				vivid: a && qn.vivid ? 1.4 : 1,
				stickers: qn.stickers,
				lettering: qn.lettering,
				thinParts: qn.thinParts,
				look: qn.look,
				enlarge: qn.enlarge,
				gloss: qn.gloss,
				review: e
			});
			n = o, xs(o, y);
			let s, c = 0, l = !1;
			for (zn({
				health: null,
				receivedAt: Date.now(),
				queued: !0,
				unanswered: 0,
				stop: i
			});;) {
				if (await new Promise((e) => setTimeout(e, 1e3)), !nr.current) return;
				if (r) throw Error("Stopped.");
				try {
					s = await W.client.processStatus(o), c = 0;
				} catch (e) {
					if (c++, zn((e) => e && {
						...e,
						unanswered: c
					}), c >= 15) throw Error(`the Gleamshelf app stopped answering (${e instanceof Error ? e.message : "no answer"}). Is it still running? Start it again with: npm run local:start`);
					continue;
				}
				if (zn({
					health: s.health ?? null,
					receivedAt: Date.now(),
					queued: s.status === "queued",
					unanswered: 0,
					stop: i
				}), t(s.steps.length ? s.steps : [{
					name: s.status === "queued" ? "Waiting for the app to finish another job" : "Starting",
					state: "running"
				}]), s.found && s.status === "waiting") {
					let e = s.found;
					if (Un((t) => t && t.job === o ? t : {
						job: o,
						online: e,
						thumbs: {},
						ticked: e.photos.filter((e) => e.linesUp).map((e) => e.index),
						sent: !1
					}), !l) {
						l = !0;
						for (let t of e.photos.slice(0, 24)) W.client.foundPicture(o, t.index).then((e) => {
							let n = URL.createObjectURL(e);
							if (!nr.current) return URL.revokeObjectURL(n);
							Un((e) => e && e.job === o ? {
								...e,
								thumbs: {
									...e.thumbs,
									[t.index]: n
								}
							} : (URL.revokeObjectURL(n), e));
						}).catch(() => {});
					}
				}
				if (s.status === "done" || s.status === "failed") break;
			}
			if (s.status === "failed") throw Error(s.error === "Stopped." ? "Stopped." : s.error ?? "The app could not finish.");
			await Cn(o, s.report), kn();
		} catch (e) {
			let t = e instanceof Error && e.message === "Stopped.";
			Fn((e) => e?.map((e) => e.state === "running" ? {
				...e,
				state: "skipped",
				note: t ? "stopped" : "did not finish"
			} : e) ?? null), Me(t ? {
				kind: "stopped",
				message: "Stopped. Nothing was changed."
			} : {
				kind: "failed",
				message: e instanceof Error ? e.message : "The app could not finish."
			});
		} finally {
			nr.current && (Vn(!1), zn(null));
		}
	}, [sr, lr] = M(() => {
		try {
			return localStorage.getItem("gleamshelf:auto-detail") === "on";
		} catch {
			return !1;
		}
	}), dr = (e) => {
		lr(e);
		try {
			localStorage.setItem("gleamshelf:auto-detail", e ? "on" : "off");
		} catch {}
	}, [fr, pr] = M(!1), hr = W.state === "ready" && !!W.installed("enhance")[0] && !!W.installed("redraw")[0], gr = async () => {
		if (Bn) return;
		if (W.canProcess && W.state === "ready" && y) return ir();
		e.commit(), L(null), Vn(!0);
		let r = jn === "character", i = sr && hr && r, a = fr && hr, o = [
			r ? "Cut out the box and crop to it" : "Cut out the product",
			r ? "Repaint lettering, printed text and price stickers" : "Remove price stickers",
			...r ? ["Cut out the character"] : [],
			"Brighter and sharper",
			a ? "Studio gloss (changes the product), then enlarge (about 2 minutes)" : i ? "Sharpen with detail, then enlarge (about 2 minutes)" : "Sharpen and enlarge",
			r ? "Studio photo (white, square, no shadow)" : "Studio photo (white, square)"
		], s = o.map((e) => ({
			label: e,
			state: "todo"
		})), [c, l, ...u] = [
			0,
			1,
			...o.slice(2).map((e, t) => t + 2)
		], d = r ? u.shift() : -1, [f, p, h] = u, _ = (e, t, n) => {
			s[e] = {
				...s[e],
				state: t,
				note: n
			}, Fn([...s]);
		}, v = async (e, t) => {
			_(e, "running");
			try {
				let n = await t();
				s[e].state === "running" && _(e, "done", n || void 0);
			} catch (t) {
				_(e, "skipped", t instanceof Error ? t.message : "This step did not work.");
			}
		}, b = (e, t) => _(e, "skipped", t), x = W.state === "ready", S = x ? W.installed("cutout")[0] : void 0, C = (e, t) => {
			throw _(e, "skipped", t), Error(t);
		};
		Fn([...s]);
		try {
			if (await v(c, async () => {
				let n = "";
				if (e.document.recipe.mask.length === 0) {
					if (Qe) e.removeGreenBackdrop(), n = "green backdrop removed (free)";
					else if (S) ot(S.id, await W.client.cutout(await Re(t), S.id), "product"), n = "AI cut-out";
					else return C(c, "No green backdrop, and the AI cut-out is not available: start the Gleamshelf app and install a cut-out model.");
				} else n = "already cut out";
				if (r) {
					if (!S) return C(c, "Finding the character needs the AI cut-out: start the Gleamshelf app.");
					let t = H(), r = t && m(t, B.width, B.height);
					if (r) {
						let t = .06, n = Math.max(0, r.x - r.width * t), i = Math.max(0, r.y - r.height * t);
						e.setCrop(oe(e.document, {
							x: n,
							y: i,
							width: Math.min(1, r.x + r.width * 1.06) - n,
							height: Math.min(1, r.y + r.height * 1.06) - i
						}));
					}
					n += ", cropped to the box";
				}
				return n;
			}), !H()) {
				for (let e = 1; e < s.length; e++) b(e, "Needs a cut-out first.");
				return;
			}
			await v(l, async () => {
				let i;
				if (r && S) try {
					i = g(e.document, n(await W.client.cutout(await ze(t, e.document), S.id)));
				} catch {}
				let { result: a, stickersFound: o, stickerNote: s, skipped: c = 0 } = await Qt({
					lettering: r,
					stickers: !0,
					body: i
				});
				return a === "no-ai" ? C(l, "Needs an AI fill: start the Gleamshelf app and set up the redraw model (or install LaMa).") : a === "nothing" ? s ?? (r ? "nothing to remove" : "no price sticker found") : `${r ? "lettering and printed text" : ""}${r && o ? " and " : ""}${o ? `${o} price sticker${o === 1 ? "" : "s"}` : ""} repainted${s ? ` (${s})` : ""}${c ? `; ${c} printed line${c === 1 ? "" : "s"} left, too tangled with the picture to take off safely (take them off with "Click printed text", or crop them out)` : ""}`;
			}), r && await v(d, async () => S ? (ot(S.id, await W.client.cutout(await ze(kt(), e.document), S.id, void 0, { thinParts: !0 }), "character"), "cut out of the repainted cover") : C(d, "Finding the character needs the AI cut-out: start the Gleamshelf app.")), await v(f, async () => {
				let t = e.document.recipe;
				return ft(), t === e.document.recipe ? "already set" : void 0;
			}), await v(p, async () => {
				let e = x ? W.installed("upscale")[0] : void 0;
				if (!e) return C(p, "Needs an enlarging model: start the Gleamshelf app and install one.");
				let t = await Gt(), n = !1;
				if (a) try {
					t = await W.client.gloss(t), n = !0;
				} catch (e) {
					L(e instanceof Error ? `Studio gloss did not work, so the product was left as photographed: ${e.message}` : "Studio gloss did not work, so the product was left as photographed.");
				}
				else if (i) try {
					t = await W.client.enhance(t, { strength: .25 });
				} catch (e) {
					L(e instanceof Error ? `The detail sharpening did not work, so the plain enlarge was used: ${e.message}` : "The detail sharpening did not work, so the plain enlarge was used.");
				}
				return await qt(e.id, await W.client.upscale(t, e.id)), n ? `glossed by AI, so compare it with the real item before listing; ${e.name}, saved 2 times larger` : `${e.name}, saved 2 times larger`;
			}), await v(h, async () => {
				if (r && e.fadeBottom(.15), !fn({ shadow: !r })) return C(h, "Nothing is cut out.");
			});
		} finally {
			Vn(!1);
		}
	}, _r = () => {
		let t = H(), n = t && m(t, B.width, B.height);
		n && e.fitSquareToProduct(n);
	};
	A(() => {
		if (!k || me.width <= 0) return;
		let e = window.devicePixelRatio || 1, t = requestAnimationFrame(() => k.draw(Ke, Math.round(Ye * e), Math.round(Xe * e)));
		return () => cancelAnimationFrame(t);
	}, [
		k,
		Ke,
		Ye,
		Xe,
		me.width,
		Ne,
		yt,
		I
	]);
	let vr = (t) => {
		let n = t.target;
		if (n.tagName === "SELECT" || n.tagName === "INPUT" && n.type !== "range") return;
		let r = t.type === "keydown", i = t.ctrlKey || t.metaKey, a = t.key.toLowerCase();
		r && i && a === "z" ? (t.preventDefault(), t.shiftKey ? e.redo() : e.undo()) : r && i && a === "y" ? (t.preventDefault(), e.redo()) : t.key === "\\" ? _e(r) : r && !i && a === "c" ? z() : r && !i && a === "e" && !yr ? xr() : r && !i && a === "l" && !Cr ? Br() : r && !i && t.key === "?" ? ye(!0) : r && t.key === "Escape" && (en || zt) ? (tn(!1), Bt(null)) : r && (t.key === "Enter" || t.key === "Escape") && (Se || we) && (t.preventDefault(), Ce(!1), Te(!1));
	}, [yr, br] = M(null), xr = async () => {
		if (k && !Oe) {
			ke(!0), L(null);
			try {
				e.commit();
				let t = We ?? e.document, n = ms(t.recipe), r = t.recipe.ops, a = n === "image" ? t : {
					...t,
					recipe: {
						...t.recipe,
						ops: {
							...r,
							backdrop: {
								...r.backdrop,
								mode: "transparent"
							}
						}
					}
				}, { blob: o } = await k.export(a, { type: "image/png" }), s = await createImageBitmap(o, { premultiplyAlpha: "none" });
				br({
					kind: "pictures",
					width: s.width,
					height: s.height,
					background: n === "color" ? i(t.recipe, "backdrop", "color") || "#ffffff" : n === "image" ? "#ffffff" : null,
					layers: [{
						name: t.recipe.mask.length ? "Product" : "Photo",
						picture: s
					}]
				});
			} catch (e) {
				L(e instanceof Error ? e.message : "Edit mode could not open this picture.");
			} finally {
				ke(!1);
			}
		}
	}, [Cr, wr] = M(null), [Er, Nr] = M(null), Pr = async () => {
		let e = S;
		if (!e?.runId || W.state !== "ready") throw Error("The Gleamshelf app is not answering on this computer.");
		let t = await W.client.processPicture(e.runId, "cutout").catch(() => {
			throw Error("This run kept no cut-out to put in an ad.");
		});
		Nr({
			picture: t,
			headline: e.listing?.title.replace(/\s*\([^)]*\)\s*$/, "").trim() || e.identity?.character || "",
			tagline: e.listing?.series ?? e.identity?.franchise ?? "New arrival"
		});
	}, [Fr, Ir] = M(null), Lr = async () => {
		let e = S;
		if (!e?.runId || W.state !== "ready") throw Error("The Gleamshelf app is not answering on this computer.");
		let t = await W.client.processPicture(e.runId, "cutout").catch(() => {
			throw Error("This run kept no cut-out to make a model from.");
		});
		Ir({
			cutout: t,
			identity: e.identity ?? null,
			name: e.identity?.character || e.listing?.title || "Figure"
		});
	}, [Rr, zr] = M(!1), Br = async () => {
		if (k && !Oe) {
			ke(!0), L(null);
			try {
				e.commit();
				let { blob: t } = await k.export(We ?? e.document, { type: "image/png" });
				wr(t);
			} catch (e) {
				L(e instanceof Error ? e.message : "Photo lab could not open this picture.");
			} finally {
				ke(!1);
			}
		}
	}, Vr = () => {
		wr(null), le.current?.focus();
	}, Hr = () => {
		if (yr?.kind === "pictures") for (let e of yr.layers) e.picture.close?.();
		br(null), le.current?.focus();
	}, Ur = async () => {
		if (k && !Oe) {
			ke(!0), L(null);
			try {
				e.commit();
				let t = await k.export(We ?? e.document, re), n = e.document.recipe.upscale?.ref, r = n && jt.get(n) ? { [n]: jt.get(n).blob } : void 0, i = e.document.recipe.words?.ai?.ref, a = i && ht.get(i) ? { [i]: ht.get(i).blob } : void 0, o = ms(e.document.recipe) === "image" && Ne, s = {};
				for (let t of e.document.recipe.mask) {
					let e = t.kind === "model" ? $e.get(t.ref) : void 0;
					t.kind === "model" && e && (s[t.ref] = await Ie(e));
				}
				let c = e.document.recipe.finish?.ref, l = c && Be.get(c) ? { [c]: Be.get(c).blob } : void 0;
				ie({
					...t,
					finishes: l,
					recipe: e.document.recipe,
					source: e.document.source,
					backgroundPhoto: o ? Ne.blob : void 0,
					cutoutMasks: Object.keys(s).length ? s : void 0,
					repairs: a,
					enlargements: r
				});
			} catch (e) {
				L(e instanceof Error ? e.message : "The image could not be saved.");
			} finally {
				ke(!1);
			}
		}
	};
	return /* @__PURE__ */ F("div", {
		className: "gs-editor",
		ref: le,
		tabIndex: -1,
		onKeyDown: vr,
		onKeyUp: vr,
		children: [
			/* @__PURE__ */ F("header", {
				className: "gs-toolbar",
				children: [
					/* @__PURE__ */ F("div", {
						className: "gs-toolbar__group",
						children: [ae && /* @__PURE__ */ F("button", {
							type: "button",
							className: "gs-button gs-button--ghost",
							onClick: ae,
							title: "Close without saving",
							children: [/* @__PURE__ */ P(Kt, { name: "close" }), " Cancel"]
						}), /* @__PURE__ */ F("span", {
							className: "gs-brand",
							"aria-hidden": "true",
							children: [/* @__PURE__ */ P("span", { className: "gs-brand__mark" }), "Gleamshelf"]
						})]
					}),
					/* @__PURE__ */ F("div", {
						className: "gs-toolbar__group gs-toolbar__group--center",
						children: [
							/* @__PURE__ */ P("button", {
								type: "button",
								className: "gs-icon-button",
								disabled: !D.canUndo,
								onClick: () => e.undo(),
								title: D.undoLabel ? `Undo ${D.undoLabel} (Ctrl+Z)` : "Undo",
								"aria-label": "Undo",
								children: /* @__PURE__ */ P(Kt, { name: "undo" })
							}),
							/* @__PURE__ */ P("button", {
								type: "button",
								className: "gs-icon-button",
								disabled: !D.canRedo,
								onClick: () => e.redo(),
								title: D.redoLabel ? `Redo ${D.redoLabel} (Ctrl+Shift+Z)` : "Redo",
								"aria-label": "Redo",
								children: /* @__PURE__ */ P(Kt, { name: "redo" })
							}),
							/* @__PURE__ */ P("span", { className: "gs-toolbar__divider" }),
							/* @__PURE__ */ F("button", {
								type: "button",
								className: `gs-button gs-button--ghost ${I ? "is-active" : ""}`,
								onPointerDown: () => _e(!0),
								onPointerUp: () => _e(!1),
								onPointerLeave: () => _e(!1),
								title: "Hold to see the original (or hold \\)",
								children: [/* @__PURE__ */ P(Kt, { name: "compare" }), " Compare"]
							}),
							/* @__PURE__ */ F("button", {
								type: "button",
								className: "gs-button gs-button--ghost",
								onClick: () => e.reset(),
								title: "Back to the photo as it was",
								children: [/* @__PURE__ */ P(Kt, { name: "reset" }), " Reset"]
							})
						]
					}),
					/* @__PURE__ */ F("div", {
						className: "gs-toolbar__group gs-toolbar__group--end",
						children: [
							/* @__PURE__ */ F("span", {
								className: "gs-toolbar__meta",
								children: [
									qe.width,
									" × ",
									qe.height
								]
							}),
							!ce && W.state === "ready" && W.canPhone && /* @__PURE__ */ F("button", {
								type: "button",
								className: "gs-button gs-button--ghost",
								onClick: () => zr(!0),
								title: "Take photos on a phone and edit them here",
								children: [/* @__PURE__ */ P(Kt, { name: "spark" }), " From phone"]
							}),
							/* @__PURE__ */ F("button", {
								type: "button",
								className: "gs-button gs-button--ghost",
								onClick: () => ye(!0),
								title: "How to use every feature (?)",
								children: [/* @__PURE__ */ P(Kt, { name: "help" }), " Guide"]
							}),
							/* @__PURE__ */ F("button", {
								type: "button",
								className: "gs-button gs-button--ghost",
								onClick: () => xe((e) => !e),
								title: "Ask where a button is or how to do something: the answer lights up what to press",
								"aria-label": "Ask",
								children: [
									/* @__PURE__ */ P(Kt, { name: "spark" }),
									" ",
									/* @__PURE__ */ P("span", {
										className: "gs-ask-label",
										children: "Ask"
									})
								]
							}),
							/* @__PURE__ */ F("button", {
								type: "button",
								className: "gs-button gs-button--edit",
								disabled: !k || Oe,
								onClick: () => void xr(),
								title: "Layers, brushes, selections, shapes and text on this picture (E)",
								children: [/* @__PURE__ */ P(Kt, { name: "layers" }), " Edit mode"]
							}),
							/* @__PURE__ */ F("button", {
								type: "button",
								className: "gs-button gs-button--edit",
								disabled: !k || Oe,
								onClick: () => void Br(),
								title: "Develop, looks, retouching and every filter, by hand (L)",
								children: [/* @__PURE__ */ P(Kt, { name: "sliders" }), " Photo lab"]
							}),
							/* @__PURE__ */ P("button", {
								type: "button",
								className: "gs-button gs-button--primary",
								disabled: !k || Oe,
								onClick: () => void Ur(),
								children: Oe ? "Saving…" : E
							})
						]
					})
				]
			}),
			/* @__PURE__ */ F("main", {
				className: "gs-stage",
				ref: ue,
				children: [
					/* @__PURE__ */ F("div", {
						className: "gs-stage__frame",
						children: [
							/* @__PURE__ */ P("canvas", {
								ref: de,
								className: "gs-stage__canvas",
								style: {
									width: Ye,
									height: Xe
								}
							}),
							Se && !I && /* @__PURE__ */ P(Tr, {
								editor: e,
								doc: O,
								width: Ye,
								height: Xe
							}),
							zt && !I && !Ue && /* @__PURE__ */ P(Mr, {
								width: Ye,
								height: Xe,
								onArea: (e) => void Wt(e)
							}),
							en && !I && /* @__PURE__ */ P(kr, {
								editor: e,
								width: Ye,
								height: Xe,
								onPick: (e, t) => void (nn === "text" ? on(e, t) : an(e, t))
							}),
							we && !I && /* @__PURE__ */ P(Jt, {
								editor: e,
								doc: O,
								settings: Ee,
								width: Ye,
								height: Xe
							})
						]
					}),
					I && /* @__PURE__ */ P("span", {
						className: "gs-stage__badge",
						children: "Original"
					}),
					Bn && !I && (() => {
						let e = Pn?.findIndex((e) => e.state === "running") ?? -1, t = e >= 0 ? Pn[e] : null;
						return /* @__PURE__ */ F("span", {
							className: "gs-stage__badge",
							role: "status",
							children: [
								/* @__PURE__ */ P("span", {
									className: "gs-spin",
									"aria-hidden": "true"
								}),
								" ",
								t ? `${t.label.charAt(0).toUpperCase()}${t.label.slice(1)}` : "Starting"
							]
						});
					})(),
					we && !I && /* @__PURE__ */ F("span", {
						className: "gs-stage__badge",
						children: [
							Ee.tool === "tap" ? "Tap the background to remove it" : Ee.tool === "erase" ? "Paint to erase" : "Paint to bring back",
							" ",
							"· Enter when done"
						]
					}),
					Se && !I && /* @__PURE__ */ P("span", {
						className: "gs-stage__badge",
						children: "Cropping · Enter when done"
					}),
					zt && !I && /* @__PURE__ */ P("span", {
						className: "gs-stage__badge",
						children: "Drag a rectangle around the area to redraw · Esc to cancel"
					}),
					en && !I && /* @__PURE__ */ P("span", {
						className: "gs-stage__badge",
						children: nn === "text" ? "Click a letter of the printed text to remove · Esc to cancel" : "Click the sticker to remove · Esc to cancel"
					}),
					Ae && /* @__PURE__ */ F("div", {
						className: "gs-alert",
						role: "alert",
						children: [
							/* @__PURE__ */ P("span", {
								className: "gs-alert__icon",
								"aria-hidden": "true",
								children: "!"
							}),
							/* @__PURE__ */ P("p", { children: Ae }),
							/* @__PURE__ */ P("button", {
								type: "button",
								className: "gs-alert__close",
								"aria-label": "Dismiss",
								onClick: () => L(null),
								children: "×"
							})
						]
					}),
					!Ae && at > 0 && /* @__PURE__ */ P("p", {
						className: "gs-error gs-stage__error",
						children: "This edit used an AI cut-out whose mask was not supplied, so it is not applied. Run the AI cut-out again."
					})
				]
			}),
			/* @__PURE__ */ P("aside", {
				className: "gs-sidebar",
				children: /* @__PURE__ */ P(Ln, {
					handToolsOnly: ce,
					appReady: W.state === "ready",
					appNotice: (e) => /* @__PURE__ */ P(xt, {
						app: W,
						feature: e
					}),
					editor: e,
					doc: O,
					onOpenGuide: () => ye(!0),
					cropping: Se,
					onToggleCrop: z,
					cutout: we,
					onToggleCutout: Ge,
					cutSettings: Ee,
					onCutSettings: (e) => De((t) => ({
						...t,
						...e
					})),
					onFitProduct: _r,
					onStudio: fn,
					listingSet: {
						run: (e) => void Sn(e),
						busy: vn,
						note: bn
					},
					flatten: {
						run: () => void _n(),
						busy: pn,
						note: hn
					},
					onBackgroundPhoto: ct,
					hasBackgroundPhoto: !!Ne,
					backgroundName: Ne?.name,
					hasCutout: Ze.length > 0,
					lettering: {
						busy: Ct || pt,
						filled: yt?.filled ?? 0,
						aiReady: !!G()
					},
					onRemoveLettering: () => void $t(),
					stickers: {
						run: () => void ln(),
						busy: pt,
						note: sn,
						picking: en,
						setPicking: (e) => (rn("sticker"), tn(e)),
						pickingText: en && nn === "text",
						setPickingText: (e) => (rn("text"), tn(e))
					},
					auto: {
						run: () => {
							Me(null), gr();
						},
						end: je,
						dismissEnd: () => Me(null),
						busy: Bn,
						mode: jn,
						setMode: Nn,
						steps: Pn,
						watch: In,
						appReady: W.state === "ready",
						greenBackdrop: Qe,
						full: W.canProcess && W.state === "ready" ? {
							available: !!y,
							steps: ys.map((e) => ({
								...e,
								on: qn[e.key],
								disabled: e.needs === "find" && !qn.find || e.needs === "colour" && !(qn.find && qn.colour)
							})),
							setStep: er,
							report: S,
							recent: {
								runs: En,
								open: (e) => void An(e)
							},
							shop: W.canShop ? Tn : void 0,
							makeAd: S?.runId ? Pr : void 0,
							make3d: S?.runId ? Lr : void 0,
							cleanPhoto: (() => {
								let e = S?.runId ? bs.get(S.runId) : void 0;
								return e ? {
									ready: !!W.installed("clean-photo")[0],
									setup: it.cleanPhotoSetup,
									make: (t, n) => W.client.cleanPhoto(e, {
										backdrop: t,
										seed: n
									})
								} : void 0;
							})(),
							found: Hn && {
								identity: Hn.online.identity,
								photos: Hn.online.photos.map((e) => ({
									...e,
									thumb: Hn.thumbs[e.index]
								})),
								ticked: Hn.ticked,
								waiting: !Hn.sent,
								toggle: (e) => Un((t) => t && !t.sent ? {
									...t,
									ticked: t.ticked.includes(e) ? t.ticked.filter((t) => t !== e) : [...t.ticked, e]
								} : t),
								use: () => void Gn(Hn.ticked),
								skip: () => void Gn([])
							},
							goBack: ee
						} : void 0,
						detail: {
							available: hr && jn === "character",
							on: sr,
							set: dr
						},
						gloss: {
							available: hr,
							on: fr,
							set: pr
						}
					},
					aiEnlarge: /* @__PURE__ */ P(Or, {
						app: W,
						sharpen: hr ? (e) => W.client.enhance(e, { strength: .25 }) : null,
						getPicture: Gt,
						onEnlarged: (e, t) => void qt(e, t),
						onRemove: () => e.clearUpscale(),
						applied: Nt && Pt ? { factor: Nt.factor } : null
					}),
					aiFinish: /* @__PURE__ */ P(jr, {
						app: W,
						applied: !!Ue,
						onRedrawArea: (e, t) => (Rt(null), Bt({
							prompt: e,
							keepShape: t
						})),
						onCancelArea: () => Bt(null),
						picking: !!zt,
						onRemove: () => e.clearFinish(),
						note: Lt,
						busyOutside: Ft
					}),
					autoEnhance: lt,
					onAutoEnhance: dt,
					aiFill: /* @__PURE__ */ P(Ar, {
						app: W,
						buildInput: (t) => Yt(e.document.recipe.words ?? U ?? f, t),
						onFilled: (e, t, n) => void dn(e, t, n),
						applied: !!At,
						busyOutside: pt
					}),
					aiCutout: /* @__PURE__ */ P(Dr, {
						app: W,
						getPhoto: (t) => t === "character" ? ze(kt(), e.document) : Re(kt()),
						onMask: ot,
						greenBackdrop: Qe
					})
				})
			}),
			yr && /* @__PURE__ */ P("div", {
				className: "gs-edit-overlay",
				children: /* @__PURE__ */ P(ns, {
					open: yr,
					title: e.document.source.name?.replace(/\.[^.]+$/, "") || "Design",
					doneLabel: "Use this picture",
					onClose: Hr,
					onDone: (e) => {
						Hr(), te(e);
					}
				})
			}),
			Er && /* @__PURE__ */ P("div", {
				className: "gs-edit-overlay",
				children: /* @__PURE__ */ P(fe, {
					fallback: null,
					children: /* @__PURE__ */ P(ps, {
						title: `${Er.headline || "Product"} ad`,
						ad: Er,
						onClose: () => Nr(null)
					})
				})
			}),
			Fr && /* @__PURE__ */ P("div", {
				className: "gs-edit-overlay",
				children: /* @__PURE__ */ P(fe, {
					fallback: null,
					children: /* @__PURE__ */ P(ps, {
						title: `${Fr.name} 3D`,
						photos: Fr,
						onClose: () => Ir(null)
					})
				})
			}),
			Cr && /* @__PURE__ */ P("div", {
				className: "gs-edit-overlay",
				children: /* @__PURE__ */ P(fe, {
					fallback: null,
					children: /* @__PURE__ */ P(fs, {
						picture: Cr,
						title: e.document.source.name?.replace(/\.[^.]+$/, "") || "Photo",
						doneLabel: "Use this picture",
						onClose: Vr,
						onDone: (e) => {
							Vr(), te(e);
						}
					})
				})
			}),
			Rr && /* @__PURE__ */ P(Rn, {
				client: W.client,
				onClose: () => zr(!1),
				onOpen: (e) => {
					zr(!1), te(e);
				}
			}),
			ve && /* @__PURE__ */ P(Ut, { onClose: () => ye(!1) }),
			/* @__PURE__ */ P($r, {
				open: be,
				onClose: () => xe(!1),
				prefer: [
					"Top bar",
					"One click",
					"Cut out",
					"Clean up",
					"Adjust"
				]
			})
		]
	});
}
//#endregion
//#region src/GleamEditor.tsx
var Cs = {
	maxSize: 2048,
	type: "image/webp",
	quality: .88
};
function ws({ source: e, name: t, recipe: n, background: r, masks: i, repairs: a, enlargements: o, finishes: s, localApp: c, exportOptions: l, onDone: u, onCancel: d, doneLabel: f = "Done", handToolsOnly: p = !1 }) {
	let [m, h] = M(null), [g, _] = M(null), [v, y] = M(e), [b, x] = M(null), [S, C] = M(null);
	A(() => {
		y(e), x(null), C(null);
	}, [e]);
	let w = j(n);
	return A(() => {
		let n = new AbortController(), r = null;
		return h(null), _(null), (async () => {
			try {
				let i = typeof v == "string" ? await R(v, n.signal) : v;
				if (r = await Pe(i), n.signal.aborted) return;
				let a = t ?? (e instanceof File ? e.name : typeof e == "string" ? e.split("/").pop()?.split("?")[0] : void 0), o = ae({
					width: r.width,
					height: r.height,
					name: a
				}, w.current);
				h({
					image: r,
					editor: new ee(o),
					blob: i
				});
			} catch (e) {
				n.signal.aborted || _(e instanceof Error ? e.message : "This photo couldn't be opened.");
			}
		})(), () => {
			n.abort(), r?.close();
		};
	}, [v, t]), g ? /* @__PURE__ */ F("div", {
		className: "gs-editor gs-editor--message",
		children: [/* @__PURE__ */ P("p", {
			className: "gs-error",
			children: g
		}), d && /* @__PURE__ */ P("button", {
			type: "button",
			className: "gs-button",
			onClick: d,
			children: "Close"
		})]
	}) : m ? /* @__PURE__ */ P(Ss, {
		editor: m.editor,
		image: m.image,
		initialBackground: r,
		initialMasks: i,
		initialRepairs: a,
		initialEnlargements: o,
		initialFinishes: s,
		localApp: c,
		sourceBlob: b ? null : m.blob,
		startFrom: b,
		fullReport: S,
		onOpenProcessed: async (e, t, n) => {
			let r = await createImageBitmap(e, { premultiplyAlpha: "none" }), i = document.createElement("canvas");
			i.width = r.width, i.height = r.height;
			let a = i.getContext("2d", { willReadFrequently: !0 });
			a.drawImage(r, 0, 0);
			let o = a.getImageData(0, 0, i.width, i.height).data, s = new Uint8Array(i.width * i.height);
			for (let e = 0; e < s.length; e++) s[e] = o[e * 4 + 3];
			a.globalCompositeOperation = "destination-over", a.fillStyle = "#ffffff", a.fillRect(0, 0, i.width, i.height);
			let c = await new Promise((e, t) => i.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be prepared.")), "image/png")), l = {
				alpha: s,
				width: i.width,
				height: i.height
			};
			r.close(), x({
				mask: l,
				shadow: t
			}), C(n), y(c);
		},
		onBackToOriginal: b ? () => (x(null), C(null), y(e)) : void 0,
		onEdited: (e) => {
			w.current = void 0, x(null), C(null), y(e);
		},
		exportOptions: {
			...Cs,
			...l
		},
		onDone: u,
		onCancel: d,
		doneLabel: f,
		handToolsOnly: p
	}) : /* @__PURE__ */ P("div", {
		className: "gs-editor gs-editor--message",
		children: "Opening photo…"
	});
}
//#endregion
export { R as A, bt as C, it as D, rt as E, Fe as M, ot as O, ht as S, at as T, Ft as _, Po as a, xt as b, Er as c, Wt as d, Vt as f, Pt as g, Nt as h, Ro as i, L as j, Pe as k, Rn as l, K as m, ns as n, $r as o, Ht as p, Lo as r, Vr as s, ws as t, Kt as u, Et as v, vt as w, _t as x, G as y };

//# sourceMappingURL=GleamEditor-BwL_fApV.js.map