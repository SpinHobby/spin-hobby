import { j as e } from "./src-Dp2bJp0u.js";
//#region ../shaders/src/parse.ts
var t = class extends Error {
	constructor(e, t, n) {
		super(`${e}${n ? `:${n}` : ""}: ${t}`);
	}
}, n = [
	"uInput",
	"uResolution",
	"uTime",
	"uFlipY"
], r = /^\s*uniform\s+(\w+)\s+(\w+)\s*;\s*(?:\/\/\s*@param\b(.*))?$/, i = /^#[0-9a-fA-F]{6}$/, a = (e) => e.slice(1, 2).toLowerCase() + e.slice(2);
function o(e) {
	let t = /^\s*"([^"]*)"/.exec(e)?.[1], n = {};
	for (let [, t, r] of e.matchAll(/(\w+)=("[^"]*"|\S+)/g)) n[t] = r.replace(/^"|"$/g, "");
	return {
		label: t,
		values: n
	};
}
function s(e, n, r, i, a = !0) {
	let o = r[i];
	if (o === void 0) {
		if (a) throw new t(e, `this slider needs ${i}=… (for example min=0 max=1 step=0.01 default=0.5)`, n);
		return;
	}
	let s = Number(o);
	if (!Number.isFinite(s)) throw new t(e, `${i}=${o} is not a number`, n);
	return s;
}
function c(e, n, r, c, l) {
	if (!/^u[A-Z]\w*$/.test(c)) throw new t(e, `uniform "${c}" should start with u and a capital letter, like uAmount`, n);
	let { label: u = c.slice(1), values: d } = o(l), f;
	if (r === "float" || r === "int") {
		if (d.options !== void 0) {
			if (r !== "int") throw new t(e, "a list of options goes on an int uniform (the chosen position)", n);
			let i = d.options.split("|").map((e) => e.trim()).filter(Boolean);
			if (i.length < 2) throw new t(e, "options=… needs at least two choices separated by |", n);
			let a = d.default ?? i[0];
			if (!i.includes(a)) throw new t(e, `default=${a} is not one of the options`, n);
			f = {
				kind: "choice",
				label: u,
				options: i,
				default: a
			};
		} else {
			let i = s(e, n, d, "min"), a = s(e, n, d, "max"), o = s(e, n, d, "step", !1) ?? (r === "int" ? 1 : (a - i) / 100), c = s(e, n, d, "default");
			if (!(i < a)) throw new t(e, "min must be smaller than max", n);
			if (!(o > 0)) throw new t(e, "step must be above 0", n);
			if (c < i || c > a) throw new t(e, `default=${c} is outside min=${i} max=${a}`, n);
			if (r === "int" && !(Number.isInteger(i) && Number.isInteger(a) && Number.isInteger(c) && Number.isInteger(o))) throw new t(e, "an int slider needs whole numbers for min, max, step and default", n);
			f = {
				kind: "number",
				label: u,
				min: i,
				max: a,
				step: o,
				default: c,
				...d.unit ? { unit: d.unit } : {}
			};
		}
	} else if (r === "bool") {
		if (d.default !== "true" && d.default !== "false") throw new t(e, "a bool needs default=true or default=false", n);
		f = {
			kind: "boolean",
			label: u,
			default: d.default === "true"
		};
	} else if (r === "vec3") {
		if (!i.test(d.default ?? "")) throw new t(e, "a vec3 is a colour and needs default=#rrggbb", n);
		f = {
			kind: "color",
			label: u,
			default: d.default.toLowerCase()
		};
	} else throw new t(e, `uniforms of type ${r} are not supported (use float, int, bool or vec3)`, n);
	return {
		uniform: c,
		key: a(c),
		glslType: r,
		spec: f
	};
}
function l(e, i, a) {
	let o = `${e}.${i === "fragment" ? "frag" : "vert"}.glsl`, s = a.split(/\r?\n/), l = {}, u = [], d = /* @__PURE__ */ new Set();
	s.forEach((e, a) => {
		let s = a + 1, f = /^\s*\/\/\s*@(shader|description|scope|contract|animated)\b\s*(.*)$/.exec(e);
		if (f) {
			l[f[1]] = f[2].trim();
			return;
		}
		if (/^\s*#\s*version\b/.test(e) && (i !== "vertex" || a !== 0)) throw new t(o, "leave out #version: it is added for you", s);
		let p = r.exec(e);
		if (!p) {
			if (/^\s*uniform\b/.test(e)) throw new t(o, "write each uniform on its own line like: uniform float uAmount; // @param \"Amount\" min=0 max=1 default=0.5", s);
			return;
		}
		let [, m, h, g] = p;
		if (n.includes(h)) throw new t(o, `${h} is provided for you; remove this line`, s);
		if (g === void 0) throw new t(o, `uniform ${h} has no slider. Add // @param "Label" min=… max=… default=… (or remove the uniform)`, s);
		let _ = c(o, s, m, h, g);
		if (d.has(_.key)) throw new t(o, `two uniforms would both be called "${_.key}"`, s);
		d.add(_.key), u.push(_);
	});
	let f = i === "fragment" ? "effect" : l.contract === "fullscreen" || /\bvoid\s+main\s*\(/.test(a) ? "fullscreen" : "displace";
	if (f === "effect" && !/\bvec4\s+effect\s*\(\s*vec2\s+\w+\s*,\s*vec4\s+\w+\s*\)/.test(a)) throw new t(o, "write a function vec4 effect(vec2 uv, vec4 color) that returns the new colour");
	if (f === "displace" && !/\bvec3\s+displace\s*\(\s*vec3\s+\w+\s*,\s*vec3\s+\w+\s*,\s*vec2\s+\w+\s*\)/.test(a)) throw new t(o, "write a function vec3 displace(vec3 position, vec3 normal, vec2 uv) that returns the new position");
	let p = l.scope === "product" ? "product" : "image";
	if (l.scope && l.scope !== "image" && l.scope !== "product") throw new t(o, "@scope must be image or product");
	return {
		id: e,
		kind: i,
		name: l.shader || e,
		description: l.description ?? "",
		contract: f,
		scope: p,
		animated: "animated" in l,
		params: u,
		source: a
	};
}
function u(e) {
	return Object.fromEntries(e.params.map((e) => [e.key, e.spec.default]));
}
function d(t, n) {
	return Object.fromEntries(t.params.map((t) => [t.key, e(t.spec, n?.[t.key]) ?? t.spec.default]));
}
function f(t, n) {
	let r = t.spec, i = e(r, n) ?? r.default;
	if (r.kind === "boolean") return +!!i;
	if (r.kind === "choice") return Math.max(0, r.options.indexOf(String(i)));
	if (r.kind === "color") {
		let e = String(i);
		return [
			parseInt(e.slice(1, 3), 16) / 255,
			parseInt(e.slice(3, 5), 16) / 255,
			parseInt(e.slice(5, 7), 16) / 255
		];
	}
	return Number(i);
}
//#endregion
//#region ../shaders/src/compose.ts
var p = "#version 300 es\nprecision highp float;\nuniform sampler2D uInput;\nuniform vec2 uResolution;\nuniform float uTime;\nuniform bool uFlipY;\nuniform bool uInputFlipped;\nout vec4 outColor;\nvec4 sampleInput(vec2 uv) { return texture(uInput, uInputFlipped ? vec2(uv.x, 1.0 - uv.y) : uv); }\nvec2 perMille(float v) { return v * 0.001 * max(uResolution.x, uResolution.y) / uResolution; }\n", m = "\nvoid main() {\n  vec2 uv = gl_FragCoord.xy / uResolution;\n  if (uFlipY) uv.y = 1.0 - uv.y;\n  outColor = effect(uv, sampleInput(uv));\n}\n";
function h(e) {
	return p + e.source + m;
}
function g(e) {
	return {
		declarations: `uniform float uTime;\n${e.source}\n`,
		call: "vec3 transformed = displace(position, normal, uv);"
	};
}
//#endregion
//#region ../shaders/fragment/chromatic-aberration.frag.glsl?raw
var _ = "// @shader Colour fringe\n// @description Splits red and blue slightly towards the edges, like a vintage lens.\n// @scope image\n\nuniform float uAmount; // @param \"Amount\" min=0 max=12 step=0.1 default=2.5\n\nvec4 effect(vec2 uv, vec4 color) {\n  vec2 away = (uv - 0.5) * uAmount * 0.003;\n  vec4 r = sampleInput(uv + away);\n  vec4 b = sampleInput(uv - away);\n  return vec4(r.r, color.g, b.b, max(color.a, max(r.a, b.a)));\n}\n", v = "// @shader Contact shadow\n// @description The dark, soft shadow right where the product meets the floor, so it stands on the surface instead of floating. Works on the product, before the background is added.\n// @scope product\n\nuniform float uOpacity;  // @param \"Darkness\" min=0 max=1 step=0.01 default=0.45\nuniform float uSize;     // @param \"Depth\" min=2 max=80 step=0.5 default=14\nuniform float uSpread;   // @param \"Spread\" min=0 max=60 step=0.5 default=10\nuniform vec3 uColor;     // @param \"Colour\" default=#000000\n\nconst int STEPS = 24;\n\n// true when the product is beside this point (left or right, on its own row) closer than `d`: the point is next to a slanted side, not under the base\nbool besideProduct(vec2 uv, float d) {\n  float dx = d * uResolution.y / uResolution.x;\n  for (int k = 1; k <= 4; k++) {\n    float o = dx * float(k) / 4.0;\n    if (sampleInput(vec2(uv.x - o, uv.y)).a > 0.5 || sampleInput(vec2(uv.x + o, uv.y)).a > 0.5) return true;\n  }\n  return false;\n}\n\nvec4 effect(vec2 uv, vec4 color) {\n  if (color.a > 0.995) return color;\n  float reach = perMille(uSize * 3.0).y;\n  float shade = 0.0;\n  // a few columns either side soften the shadow's ends; in each, how close the product's base is above this pixel\n  for (int k = -3; k <= 3; k++) {\n    float x = uv.x + perMille(uSpread).x * float(k) / 3.0;\n    for (int i = 1; i <= STEPS; i++) {\n      float d = reach * float(i) / float(STEPS);\n      float y = uv.y - d;\n      if (y < 0.0) break;\n      if (sampleInput(vec2(x, y)).a > 0.5) {\n        if (besideProduct(vec2(x, uv.y), d)) break;\n        float near = exp(-d / perMille(uSize).y);\n        float side = 1.0 - abs(float(k)) / 4.0;\n        shade = max(shade, near * side);\n        break;\n      }\n    }\n  }\n  float s = shade * uOpacity;\n  float alpha = color.a + s * (1.0 - color.a);\n  vec3 rgb = alpha > 0.0 ? (color.rgb * color.a + uColor * s * (1.0 - color.a)) / alpha : vec3(0.0);\n  return vec4(rgb, alpha);\n}\n", y = "// @shader Drop shadow\n// @description A soft shadow cast by the product onto whatever is behind it. Works on the product, before the background is added.\n// @scope product\n\nuniform float uOpacity;  // @param \"Darkness\" min=0 max=1 step=0.01 default=0.35\nuniform float uBlur;     // @param \"Softness\" min=1 max=80 step=0.5 default=18\nuniform float uOffsetX;  // @param \"Across\" min=-60 max=60 step=0.5 default=0\nuniform float uOffsetY;  // @param \"Down\" min=-60 max=60 step=0.5 default=22\nuniform vec3 uColor;     // @param \"Colour\" default=#000000\n\nvec4 effect(vec2 uv, vec4 color) {\n  vec2 origin = uv - perMille(1.0) * vec2(uOffsetX, uOffsetY);\n  float seen = 0.0;\n  for (int i = 0; i < 28; i++) {\n    float angle = float(i) * 2.39996;\n    float dist = sqrt((float(i) + 0.5) / 28.0) * uBlur;\n    seen += sampleInput(origin + perMille(dist) * vec2(cos(angle), sin(angle))).a;\n  }\n  float shadow = seen / 28.0 * uOpacity;\n  float alpha = color.a + shadow * (1.0 - color.a);\n  vec3 rgb = alpha > 0.0 ? (color.rgb * color.a + uColor * shadow * (1.0 - color.a)) / alpha : vec3(0.0);\n  return vec4(rgb, alpha);\n}\n", b = "// @shader Duotone\n// @description Repaints the picture with two colours: one for the darks, one for the lights.\n// @scope image\n\nuniform vec3 uShadow;     // @param \"Darks\" default=#1b1b3a\nuniform vec3 uHighlight;  // @param \"Lights\" default=#ffd6a5\nuniform float uStrength;  // @param \"Strength\" min=0 max=1 step=0.01 default=1\n\nvec4 effect(vec2 uv, vec4 color) {\n  float luma = dot(color.rgb, vec3(0.2126, 0.7152, 0.0722));\n  vec3 toned = mix(uShadow, uHighlight, luma);\n  return vec4(mix(color.rgb, toned, uStrength), color.a);\n}\n", x = "// @shader Film grain\n// @description Fine speckle like photographic film. It also hides banding in smooth areas.\n// @scope image\n// @animated\n\nuniform float uAmount; // @param \"Amount\" min=0 max=0.5 step=0.005 default=0.08\nuniform float uSize;   // @param \"Grain size\" min=0.5 max=6 step=0.1 default=1.2\nuniform bool uMono;    // @param \"Black and white grain\" default=true\n\nfloat hash(vec2 p) {\n  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);\n}\n\nvec4 effect(vec2 uv, vec4 color) {\n  float cell = max(1.0, uSize * max(uResolution.x, uResolution.y) * 0.001);\n  vec2 id = floor(uv * uResolution / cell) + floor(uTime * 24.0);\n  vec3 n = uMono ? vec3(hash(id) - 0.5) : vec3(hash(id) - 0.5, hash(id + 17.0) - 0.5, hash(id + 41.0) - 0.5);\n  // Most visible in the midtones, like real film.\n  float luma = dot(color.rgb, vec3(0.2126, 0.7152, 0.0722));\n  float weight = 1.0 - abs(luma - 0.5) * 1.4;\n  return vec4(clamp(color.rgb + n * uAmount * weight, 0.0, 1.0), color.a);\n}\n", S = "// @shader Pixelate\n// @description Chunky square pixels, like an old video game.\n// @scope image\n\nuniform int uCells; // @param \"Pixels across\" min=16 max=400 step=1 default=96\n\nvec4 effect(vec2 uv, vec4 color) {\n  vec2 grid = uResolution / max(uResolution.x, uResolution.y) * float(uCells);\n  return sampleInput((floor(uv * grid) + 0.5) / grid);\n}\n", C = "// @shader Reflection\n// @description The product mirrored on a glossy surface under it, fading away. Works on the product, before the background is added.\n// @scope product\n\nuniform float uOpacity;  // @param \"Strength\" min=0 max=1 step=0.01 default=0.28\nuniform float uLength;   // @param \"Length\" min=20 max=400 step=1 default=140\nuniform float uGap;      // @param \"Gap\" min=0 max=40 step=0.5 default=1\nuniform float uBlur;     // @param \"Blur\" min=0 max=30 step=0.5 default=3\n\nconst int STEPS = 64;\n\n// true when the product is beside this point (left or right, on its own row) closer than `d`: the point is next to a slanted side, not under the base\nbool besideProduct(vec2 uv, float d) {\n  float dx = d * uResolution.y / uResolution.x;\n  for (int k = 1; k <= 4; k++) {\n    float o = dx * float(k) / 4.0;\n    if (sampleInput(vec2(uv.x - o, uv.y)).a > 0.5 || sampleInput(vec2(uv.x + o, uv.y)).a > 0.5) return true;\n  }\n  return false;\n}\n\nvec4 effect(vec2 uv, vec4 color) {\n  if (color.a > 0.995) return color;\n  // the product's base in this column: the first solid pixel going up from here, within the reflection's length\n  float reach = perMille(uLength).y;\n  float base = -1.0;\n  for (int i = 1; i <= STEPS; i++) {\n    float y = uv.y - reach * float(i) / float(STEPS);\n    if (y < 0.0) break;\n    if (sampleInput(vec2(uv.x, y)).a > 0.5) {\n      base = y;\n      break;\n    }\n  }\n  if (base < 0.0 || besideProduct(uv, uv.y - base)) return color;\n  float gap = perMille(uGap).y;\n  float d = uv.y - base - gap;\n  if (d <= 0.0) return color;\n  float fade = 1.0 - d / reach;\n  fade = fade * fade * uOpacity;\n  // mirrored about the base, a little blurred across so it reads as a surface, not a copy\n  vec2 mirror = vec2(uv.x, base - d);\n  vec4 refl = vec4(0.0);\n  for (int k = -2; k <= 2; k++) {\n    vec4 s = sampleInput(mirror + vec2(perMille(uBlur).x * float(k) * 0.5, 0.0));\n    refl += vec4(s.rgb * s.a, s.a);\n  }\n  refl /= 5.0;\n  float ra = refl.a * fade;\n  vec3 rrgb = refl.a > 0.0 ? refl.rgb / refl.a : vec3(0.0);\n  float alpha = color.a + ra * (1.0 - color.a);\n  vec3 rgb = alpha > 0.0 ? (color.rgb * color.a + rrgb * ra * (1.0 - color.a)) / alpha : vec3(0.0);\n  return vec4(rgb, alpha);\n}\n", w = "// @shader Sharpen\n// @description Crisper fine detail, like the print on a box. Gentle amounts look best.\n// @scope image\n\nuniform float uAmount; // @param \"Amount\" min=0 max=2 step=0.01 default=0.6\nuniform float uRadius; // @param \"Radius\" min=0.5 max=4 step=0.1 default=1.2\n\n// `uv` is where we are in the picture (0,0 top-left to 1,1 bottom-right); `color` is what is there now.\n// Return the new colour (red, green, blue, alpha, each 0 to 1).\nvec4 effect(vec2 uv, vec4 color) {\n  vec2 r = perMille(uRadius);\n  vec3 blur = (sampleInput(uv + vec2(r.x, 0.0)).rgb + sampleInput(uv - vec2(r.x, 0.0)).rgb +\n               sampleInput(uv + vec2(0.0, r.y)).rgb + sampleInput(uv - vec2(0.0, r.y)).rgb) * 0.25;\n  return vec4(clamp(color.rgb + (color.rgb - blur) * uAmount * 2.0, 0.0, 1.0), color.a);\n}\n", T = "// @shader Soft glow\n// @description Bright areas bloom softly, for a dreamy, polished look.\n// @scope image\n\nuniform float uThreshold; // @param \"Only brighter than\" min=0 max=0.95 step=0.01 default=0.7\nuniform float uStrength;  // @param \"Strength\" min=0 max=2 step=0.01 default=0.5\nuniform float uRadius;    // @param \"Spread\" min=1 max=40 step=0.5 default=10\n\nvec4 effect(vec2 uv, vec4 color) {\n  vec3 glow = vec3(0.0);\n  // 20 samples spread over a disc (the golden angle keeps them evenly scattered).\n  for (int i = 0; i < 20; i++) {\n    float angle = float(i) * 2.39996;\n    float dist = sqrt((float(i) + 0.5) / 20.0) * uRadius;\n    vec3 s = sampleInput(uv + perMille(dist) * vec2(cos(angle), sin(angle))).rgb;\n    glow += max(s - uThreshold, 0.0) / (1.0 - uThreshold + 0.001);\n  }\n  glow /= 20.0;\n  vec3 screen = 1.0 - (1.0 - color.rgb) * (1.0 - clamp(glow * uStrength, 0.0, 1.0));\n  return vec4(screen, color.a);\n}\n", E = "// @shader Bulge\n// @description Puffs the middle of the product towards the viewer, like a pillow. Shows in the 3D scene.\n// @contract displace\n\nuniform float uAmount; // @param \"Puff\" min=-0.2 max=0.3 step=0.005 default=0.08\nuniform float uSpread; // @param \"Spread\" min=0.1 max=1 step=0.01 default=0.55\n\nvec3 displace(vec3 position, vec3 normal, vec2 uv) {\n  float centre = 1.0 - smoothstep(0.0, uSpread, length(position.xy));\n  position.z += uAmount * centre;\n  return position;\n}\n", D = "#version 300 es\n// @shader Fullscreen triangle\n// @description Used by every effect to cover the whole picture. A system shader: it is not offered as an effect.\n// @contract fullscreen\n\n// One triangle that covers the viewport; no vertex buffers needed.\nvoid main() {\n  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));\n  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);\n}\n", O = "// @shader Sway\n// @description The product leans gently from side to side, as if in a breeze. Shows in the 3D scene.\n// @contract displace\n// @animated\n\nuniform float uAmount; // @param \"Lean\" min=0 max=0.2 step=0.002 default=0.04\nuniform float uSpeed;  // @param \"Speed\" min=0.1 max=4 step=0.05 default=1\n\n// Called for every vertex of the product. Returns where it should be. `position` is where it normally sits.\nvec3 displace(vec3 position, vec3 normal, vec2 uv) {\n  float height = position.y + 0.5;                         // 0 at the bottom, 1 at the top\n  position.x += sin(uTime * uSpeed) * uAmount * height;    // the top moves most, the base stays put\n  return position;\n}\n", k = "// @shader Ripple\n// @description A soft wave runs across the product, like a flag or a poster in a draught. Shows in the 3D scene.\n// @contract displace\n// @animated\n\nuniform float uAmount;    // @param \"Height\" min=0 max=0.15 step=0.002 default=0.025\nuniform float uFrequency; // @param \"Waves\" min=1 max=16 step=0.1 default=6\nuniform float uSpeed;     // @param \"Speed\" min=0 max=6 step=0.05 default=1.5\n\nvec3 displace(vec3 position, vec3 normal, vec2 uv) {\n  position.z += sin(position.x * uFrequency + uTime * uSpeed) * uAmount;\n  return position;\n}\n", A = (e, t) => e.slice(e.lastIndexOf("/") + 1).replace(t, "");
function j(e) {
	let n = {
		fragment: [],
		vertex: [],
		errors: []
	};
	for (let [r, i] of Object.entries(e)) {
		let e = r.endsWith(".frag.glsl") ? "fragment" : r.endsWith(".vert.glsl") ? "vertex" : null;
		if (!e) continue;
		let a = A(r, e === "fragment" ? ".frag.glsl" : ".vert.glsl");
		try {
			n[e].push(l(a, e, i));
		} catch (e) {
			n.errors.push(e instanceof t ? e.message : `${r}: ${String(e)}`);
		}
	}
	for (let e of [n.fragment, n.vertex]) e.sort((e, t) => e.name.localeCompare(t.name));
	return n;
}
var M = j(/* @__PURE__ */ Object.assign({
	"../fragment/chromatic-aberration.frag.glsl": _,
	"../fragment/contact-shadow.frag.glsl": v,
	"../fragment/drop-shadow.frag.glsl": y,
	"../fragment/duotone.frag.glsl": b,
	"../fragment/film-grain.frag.glsl": x,
	"../fragment/pixelate.frag.glsl": S,
	"../fragment/reflection.frag.glsl": C,
	"../fragment/sharpen.frag.glsl": w,
	"../fragment/soft-glow.frag.glsl": T,
	"../vertex/bulge.vert.glsl": E,
	"../vertex/fullscreen.vert.glsl": D,
	"../vertex/sway.vert.glsl": O,
	"../vertex/wave.vert.glsl": k
}));
M.errors.length && console.warn(`Some shaders were skipped:\n${M.errors.join("\n")}`);
var N = (e) => M.fragment.find((t) => t.id === e), P = (e) => M.vertex.find((t) => t.id === e && t.contract === "displace");
function F(e = ["image", "product"]) {
	return M.fragment.filter((t) => e.includes(t.scope));
}
function I() {
	return M.vertex.filter((e) => e.contract === "displace");
}
var L = (M.vertex.find((e) => e.id === "fullscreen")?.source ?? "").replace(/^\s*\/\/.*\n/gm, "");
//#endregion
export { F as a, u as c, I as i, d as l, N as n, g as o, P as r, h as s, L as t, f as u };

//# sourceMappingURL=src-BRmeDFgO.js.map