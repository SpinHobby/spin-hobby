import { Cr as e, Jt as t, Qn as n, R as r, Tr as i, Yt as a, _t as o, r as s, s as c } from "./three.core-BCwsimN9.js";
//#region ../../node_modules/three/examples/jsm/loaders/BVHLoader.js
var l = class extends o {
	constructor(e) {
		super(e), this.animateBonePositions = !0, this.animateBoneRotations = !0;
	}
	load(e, t, n, i) {
		let a = this, o = new r(a.manager);
		o.setPath(a.path), o.setRequestHeader(a.requestHeader), o.setWithCredentials(a.withCredentials), o.load(e, function(n) {
			try {
				t(a.parse(n));
			} catch (t) {
				i ? i(t) : console.error(t), a.manager.itemError(e);
			}
		}, n, i);
	}
	parse(r) {
		function o(e) {
			p(e) !== "HIERARCHY" && console.error("THREE.BVHLoader: HIERARCHY expected.");
			let t = [], n = u(e, p(e), t);
			p(e) !== "MOTION" && console.error("THREE.BVHLoader: MOTION expected.");
			let r = p(e).split(/[\s]+/), i = parseInt(r[1]);
			isNaN(i) && console.error("THREE.BVHLoader: Failed to read number of frames."), r = p(e).split(/[\s]+/);
			let a = parseFloat(r[2]);
			isNaN(a) && console.error("THREE.BVHLoader: Failed to read frame time.");
			for (let t = 0; t < i; t++) r = p(e).split(/[\s]+/), l(r, t * a, n);
			return t;
		}
		function l(n, r, i) {
			if (i.type === "ENDSITE") return;
			let a = {
				time: r,
				position: new e(),
				rotation: new t()
			};
			i.frames.push(a);
			let o = new t(), s = new e(1, 0, 0), c = new e(0, 1, 0), u = new e(0, 0, 1);
			for (let e = 0; e < i.channels.length; e++) switch (i.channels[e]) {
				case "Xposition":
					a.position.x = parseFloat(n.shift().trim());
					break;
				case "Yposition":
					a.position.y = parseFloat(n.shift().trim());
					break;
				case "Zposition":
					a.position.z = parseFloat(n.shift().trim());
					break;
				case "Xrotation":
					o.setFromAxisAngle(s, parseFloat(n.shift().trim()) * Math.PI / 180), a.rotation.multiply(o);
					break;
				case "Yrotation":
					o.setFromAxisAngle(c, parseFloat(n.shift().trim()) * Math.PI / 180), a.rotation.multiply(o);
					break;
				case "Zrotation":
					o.setFromAxisAngle(u, parseFloat(n.shift().trim()) * Math.PI / 180), a.rotation.multiply(o);
					break;
				default: console.warn("THREE.BVHLoader: Invalid channel type.");
			}
			for (let e = 0; e < i.children.length; e++) l(n, r, i.children[e]);
		}
		function u(t, n, r) {
			let i = {
				name: "",
				type: "",
				frames: []
			};
			r.push(i);
			let a = n.split(/[\s]+/);
			a[0].toUpperCase() === "END" && a[1].toUpperCase() === "SITE" ? (i.type = "ENDSITE", i.name = "ENDSITE") : (i.name = a[1], i.type = a[0].toUpperCase()), p(t) !== "{" && console.error("THREE.BVHLoader: Expected opening { after type & name"), a = p(t).split(/[\s]+/), a[0] !== "OFFSET" && console.error("THREE.BVHLoader: Expected OFFSET but got: " + a[0]), a.length !== 4 && console.error("THREE.BVHLoader: Invalid number of values for OFFSET.");
			let o = new e(parseFloat(a[1]), parseFloat(a[2]), parseFloat(a[3]));
			if ((isNaN(o.x) || isNaN(o.y) || isNaN(o.z)) && console.error("THREE.BVHLoader: Invalid values of OFFSET."), i.offset = o, i.type !== "ENDSITE") {
				a = p(t).split(/[\s]+/), a[0] !== "CHANNELS" && console.error("THREE.BVHLoader: Expected CHANNELS definition.");
				let e = parseInt(a[1]);
				i.channels = a.splice(2, e), i.children = [];
			}
			for (;;) {
				let e = p(t);
				if (e === "}") return i;
				i.children.push(u(t, e, r));
			}
		}
		function d(e, t) {
			let n = new c();
			if (t.push(n), n.position.add(e.offset), n.name = e.name, e.type !== "ENDSITE") for (let r = 0; r < e.children.length; r++) n.add(d(e.children[r], t));
			return n;
		}
		function f(e) {
			let t = [];
			for (let n = 0; n < e.length; n++) {
				let r = e[n];
				if (r.type === "ENDSITE") continue;
				let o = [], s = [], c = [];
				for (let e = 0; e < r.frames.length; e++) {
					let t = r.frames[e];
					o.push(t.time), s.push(t.position.x + r.offset.x), s.push(t.position.y + r.offset.y), s.push(t.position.z + r.offset.z), c.push(t.rotation.x), c.push(t.rotation.y), c.push(t.rotation.z), c.push(t.rotation.w);
				}
				m.animateBonePositions && t.push(new i(r.name + ".position", o, s)), m.animateBoneRotations && t.push(new a(r.name + ".quaternion", o, c));
			}
			return new s("animation", -1, t);
		}
		function p(e) {
			let t;
			for (; (t = e.shift().trim()).length === 0;);
			return t;
		}
		let m = this, h = o(r.split(/[\r\n]+/g)), g = [];
		d(h[0], g);
		let _ = f(h);
		return {
			skeleton: new n(g),
			clip: _
		};
	}
};
//#endregion
export { l as BVHLoader };

//# sourceMappingURL=BVHLoader-DS0mprkY.js.map