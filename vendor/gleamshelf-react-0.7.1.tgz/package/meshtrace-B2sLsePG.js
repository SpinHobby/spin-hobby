import { n as e } from "./rolldown-runtime-DArdT4gl.js";
import { a as t, c as n, m as r, o as i } from "./mesh-DZeCIO4D.js";
import { Br as a, Ct as o, F as s, H as c, Xr as l, Yr as u, cn as d, zr as f } from "./document-CNMOilB9.js";
//#region ../scene3d/src/model/exportmesh.ts
var p = {
	glb: "GLB (3D apps, AR, the web)",
	obj: "OBJ (3D apps)",
	stl: "STL (3D printing)"
}, m = {
	draft: 80,
	good: 140,
	fine: 220
}, h = (e) => e <= .04045 ? e / 12.92 : ((e + .055) / 1.055) ** 2.4;
async function g(e, r = {}) {
	let a = Math.max(16, Math.min(400, Math.round(r.cells ?? m.good))), u = c(e), f = [], p = d(e.shapes.filter((e) => !e.hidden && e.kind !== "mesh"));
	if (u.length && p) {
		let t = Math.max(...p.max.map((e, t) => e - p.min[t]), .001) / a, n = p.min.map((e) => e - 2 * t), i = p.max.map((e, r) => Math.ceil((e - n[r]) / t) + 3), [o, s, c] = i, d = (e, r, i) => [
			n[0] + e * t,
			n[1] + r * t,
			n[2] + i * t
		], m = (t) => l(e, t, u).d, g = new Float32Array(o * s * c).fill(NaN), _ = (e, t, n) => (n * s + t) * o + e, v = i.map((e) => Math.ceil(e / 8)), y = 0;
		for (let e = 0; e < v[2]; e++) {
			for (let n = 0; n < v[1]; n++) for (let r = 0; r < v[0]; r++) {
				let i = r * 8, a = n * 8, l = e * 8, u = Math.min(o - 1, i + 8), f = Math.min(s - 1, a + 8), p = Math.min(c - 1, l + 8), h = d((i + u) / 2, (a + f) / 2, (l + p) / 2), v = Math.hypot(u - i, f - a, p - l) / 2 * t;
				if (!(Math.abs(m(h)) > v * 1.6 + t)) for (let e = l; e <= p; e++) for (let t = a; t <= f; t++) for (let n = i; n <= u; n++) g[_(n, t, e)] = m(d(n, t, e));
			}
			y++, await r.onProgress?.(.8 * y / v[2]);
		}
		let { positions: b, indices: x } = S(g, [
			o,
			s,
			c
		], n, t), C = b.length / 3, w = new Float32Array(C * 3), T = new Float32Array(C * 3), E = t * .5;
		for (let t = 0; t < C; t++) {
			let n = [
				b[t * 3],
				b[t * 3 + 1],
				b[t * 3 + 2]
			], i = [
				0,
				1,
				2
			].map((e) => {
				let t = [...n], r = [...n];
				return t[e] += E, r[e] -= E, m(t) - m(r);
			}), a = Math.hypot(i[0], i[1], i[2]) || 1;
			w.set([
				i[0] / a,
				i[1] / a,
				i[2] / a
			], t * 3);
			let o = l(e, n, u).color;
			T.set([
				h(o[0]),
				h(o[1]),
				h(o[2])
			], t * 3), t % 4096 == 0 && await r.onProgress?.(.8 + .2 * t / C);
		}
		x.length && f.push({
			positions: new Float32Array(b),
			normals: w,
			uvs: null,
			colors: T,
			indices: new Uint32Array(x),
			material: 0
		});
	}
	let g = [{
		...t(),
		color: [
			1,
			1,
			1
		],
		roughness: .55
	}], _ = [];
	for (let { shape: t, asset: r } of s(e)) {
		if (t.hidden) continue;
		let i = o(e, t) ?? n(t.asset, r.data), a = g.length, s = _.length;
		for (let e of i.materials) {
			let t = { ...e };
			for (let [n, r] of Object.entries(e)) n.endsWith("Texture") && typeof r == "number" && r >= 0 && (t[n] = r + s);
			g.push(t);
		}
		_.push(...i.textures);
		for (let e of x(t, i)) f.push({
			...e,
			material: a + e.material
		});
	}
	return i(f, g, _);
}
function _(e, t, n) {
	let r = t / Math.max(e.max[1] - e.min[1], 1e-6) * n, a = e.parts.map((e) => ({
		...e,
		positions: e.positions.map((e) => e * r)
	}));
	return i(a, e.materials, e.textures);
}
async function v(e, t, n = {}) {
	let i = await g(e, n);
	if (!i.triangles) throw Error("There is nothing to export: the design has no visible shapes.");
	let a = Math.max(1, n.heightMm ?? 100);
	if (t === "glb") return r(_(i, a, .001));
	let o = _(i, a, 1);
	return t === "obj" ? y(o) : b(o);
}
function y(e) {
	let t = ["# Made with Gleamshelf 3D mode (millimetres, y up)"], n = 1, r = (e) => (e <= .0031308 ? e * 12.92 : 1.055 * e ** (1 / 2.4) - .055).toFixed(4);
	for (let i of e.parts) {
		let e = i.positions.length / 3;
		for (let n = 0; n < e; n++) {
			let [e, a, o] = [
				i.positions[n * 3],
				i.positions[n * 3 + 1],
				i.positions[n * 3 + 2]
			].map((e) => e.toFixed(4));
			t.push(i.colors ? `v ${e} ${a} ${o} ${r(i.colors[n * 3])} ${r(i.colors[n * 3 + 1])} ${r(i.colors[n * 3 + 2])}` : `v ${e} ${a} ${o}`);
		}
		for (let n = 0; n < e; n++) t.push(`vn ${i.normals[n * 3].toFixed(4)} ${i.normals[n * 3 + 1].toFixed(4)} ${i.normals[n * 3 + 2].toFixed(4)}`);
		for (let e = 0; e < i.indices.length; e += 3) {
			let [r, a, o] = [
				i.indices[e] + n,
				i.indices[e + 1] + n,
				i.indices[e + 2] + n
			];
			t.push(`f ${r}//${r} ${a}//${a} ${o}//${o}`);
		}
		n += e;
	}
	return new TextEncoder().encode(t.join("\n") + "\n");
}
function b(e) {
	let t = new Uint8Array(84 + e.triangles * 50), n = new DataView(t.buffer);
	new TextEncoder().encodeInto("Gleamshelf 3D mode, millimetres", t.subarray(0, 80)), n.setUint32(80, e.triangles, !0);
	let r = 84;
	for (let t of e.parts) for (let e = 0; e < t.indices.length; e += 3) {
		let i = [
			t.indices[e],
			t.indices[e + 1],
			t.indices[e + 2]
		].map((e) => [
			t.positions[e * 3],
			t.positions[e * 3 + 1],
			t.positions[e * 3 + 2]
		]), a = [
			0,
			1,
			2
		].map((e) => i[1][e] - i[0][e]), o = [
			0,
			1,
			2
		].map((e) => i[2][e] - i[0][e]), s = [
			a[1] * o[2] - a[2] * o[1],
			a[2] * o[0] - a[0] * o[2],
			a[0] * o[1] - a[1] * o[0]
		], c = Math.hypot(...s) || 1;
		for (let e of s) n.setFloat32(r, e / c, !0), r += 4;
		for (let e of i) for (let t of e) n.setFloat32(r, t, !0), r += 4;
		r += 2;
	}
	return t;
}
function x(e, t) {
	let n = t.max.map((e, n) => Math.max(e - t.min[n], 1e-9)), r = e.size.map((e, t) => e / n[t]), i = t.min.map((e, n) => (e + t.max[n]) / 2), a = u(e.rotation), o = (e, t, n) => [
		a[0] * e + a[1] * t + a[2] * n,
		a[3] * e + a[4] * t + a[5] * n,
		a[6] * e + a[7] * t + a[8] * n
	];
	return t.parts.map((t) => {
		let n = new Float32Array(t.positions.length), a = new Float32Array(t.normals.length);
		for (let s = 0; s < n.length; s += 3) {
			let c = o((t.positions[s] - i[0]) * r[0], (t.positions[s + 1] - i[1]) * r[1], (t.positions[s + 2] - i[2]) * r[2]);
			n.set([
				c[0] + e.position[0],
				c[1] + e.position[1],
				c[2] + e.position[2]
			], s);
			let l = o(t.normals[s] / r[0], t.normals[s + 1] / r[1], t.normals[s + 2] / r[2]), u = Math.hypot(...l) || 1;
			a.set([
				l[0] / u,
				l[1] / u,
				l[2] / u
			], s);
		}
		return {
			...t,
			positions: n,
			normals: a
		};
	});
}
function S(e, [t, n, r], i, a) {
	let o = (e, r, i) => (i * n + r) * t + e, s = new Int32Array((t - 1) * (n - 1) * (r - 1)).fill(-1), c = (e, r, i) => (i * (n - 1) + r) * (t - 1) + e, l = [], u = [];
	for (let e = 0; e < 2; e++) for (let t = 0; t < 2; t++) for (let n = 0; n < 2; n++) u.push([
		n,
		t,
		e
	]);
	let d = [
		[0, 1],
		[2, 3],
		[4, 5],
		[6, 7],
		[0, 2],
		[1, 3],
		[4, 6],
		[5, 7],
		[0, 4],
		[1, 5],
		[2, 6],
		[3, 7]
	];
	for (let f = 0; f < r - 1; f++) for (let r = 0; r < n - 1; r++) for (let n = 0; n < t - 1; n++) {
		let t = u.map(([t, i, a]) => e[o(n + t, r + i, f + a)]);
		if (t.some(Number.isNaN)) continue;
		let p = t.map((e) => e < 0);
		if (p.every((e) => e) || p.every((e) => !e)) continue;
		let m = 0, h = 0, g = 0, _ = 0;
		for (let [e, n] of d) {
			if (p[e] === p[n]) continue;
			let r = t[e] / (t[e] - t[n]), i = u[e], a = u[n];
			m += i[0] + (a[0] - i[0]) * r, h += i[1] + (a[1] - i[1]) * r, g += i[2] + (a[2] - i[2]) * r, _++;
		}
		s[c(n, r, f)] = l.length / 3, l.push(i[0] + (n + m / _) * a, i[1] + (r + h / _) * a, i[2] + (f + g / _) * a);
	}
	let f = [], p = (e, t, n, r, i) => {
		e < 0 || t < 0 || n < 0 || r < 0 || (i ? f.push(e, t, n, e, n, r) : f.push(e, n, t, e, r, n));
	};
	for (let i = 1; i < r - 1; i++) for (let r = 1; r < n - 1; r++) for (let n = 1; n < t - 1; n++) {
		let t = e[o(n, r, i)];
		if (Number.isNaN(t)) continue;
		let a = t < 0, l = e[o(n + 1, r, i)];
		!Number.isNaN(l) && l < 0 !== a && p(s[c(n, r - 1, i - 1)], s[c(n, r, i - 1)], s[c(n, r, i)], s[c(n, r - 1, i)], a);
		let u = e[o(n, r + 1, i)];
		!Number.isNaN(u) && u < 0 !== a && p(s[c(n - 1, r, i - 1)], s[c(n - 1, r, i)], s[c(n, r, i)], s[c(n, r, i - 1)], a);
		let d = e[o(n, r, i + 1)];
		!Number.isNaN(d) && d < 0 !== a && p(s[c(n - 1, r - 1, i)], s[c(n, r - 1, i)], s[c(n, r, i)], s[c(n - 1, r, i)], a);
	}
	return {
		positions: l,
		indices: f
	};
}
//#endregion
//#region ../scene3d/src/model/meshtrace.ts
var C = /* @__PURE__ */ e({
	MAX_TRACE_MATERIALS: () => 32,
	MAX_TRACE_PICTURES: () => 32,
	TRACE_LOOK: () => T,
	TRI_TEXELS: () => 12,
	buildTraceMesh: () => D,
	tangents: () => k,
	traceMeshCpu: () => O
}), w = 4, T = {
	soft: 0,
	toon: 1,
	flat: 2,
	clay: 3,
	unlit: 4
}, E = (e) => {
	let t = parseInt(e.slice(1), 16);
	return [
		(t >> 16 & 255) / 255,
		(t >> 8 & 255) / 255,
		(t & 255) / 255
	].map((e) => e ** 2.2);
};
async function D(e, t) {
	let r = [], i = [], c = [];
	for (let { shape: l, asset: u } of s(e)) {
		if (l.hidden) continue;
		let s = o(e, l) ?? n(l.asset, u.data), d = l.ownColors !== !1, p = /* @__PURE__ */ new Map(), m = (e) => (r.length >= 32 || r.push(e), r.length - 1), h = /* @__PURE__ */ new Map(), g = async (e) => {
			if (e < 0 || !t) return -1;
			if (h.has(e)) return h.get(e);
			let n = -1;
			if (i.length < 32) {
				let r = s.textures[e], a = r ? await t(r.bytes, r.mime).catch(() => null) : null;
				a && (n = i.push(a) - 1);
			}
			return h.set(e, n), n;
		};
		if (d) for (let [e, t] of s.materials.entries()) p.set(e, m({
			color: t.color,
			picture: await g(t.texture),
			metal: t.metalness,
			rough: t.roughness,
			glass: t.transmission,
			glow: t.emissive,
			...Math.max(...t.emissive) > 0 && t.emissiveTexture >= 0 ? { glowPicture: await g(t.emissiveTexture) } : {},
			normalPicture: await g(t.normalTexture),
			normalScale: t.normalScale,
			...t.unlit ? { look: T.unlit } : t.look ? {
				look: T[t.look],
				...t.bands ? { bands: t.bands } : {}
			} : {}
		}));
		else {
			let [e, t] = f[l.finish], [n, r] = a[l.finish], i = E(l.color), o = m({
				color: i,
				picture: -1,
				metal: t,
				rough: 1 - Math.sqrt(Math.max(0, (e - 6) / 134)),
				glass: r,
				glow: i.map((e) => e * n),
				normalPicture: -1,
				normalScale: 1
			});
			s.materials.forEach((e, t) => p.set(t, o));
		}
		for (let e of x(l, s)) {
			let t = p.get(e.material) ?? 0;
			for (let n = 0; n < e.indices.length; n += 3) {
				let r = [
					e.indices[n],
					e.indices[n + 1],
					e.indices[n + 2]
				], i = r.map((t) => [
					e.positions[t * 3],
					e.positions[t * 3 + 1],
					e.positions[t * 3 + 2]
				]), a = r.map((t) => [
					e.normals[t * 3],
					e.normals[t * 3 + 1],
					e.normals[t * 3 + 2]
				]), o = r.map((t) => e.uvs ? [e.uvs[t * 2], e.uvs[t * 2 + 1]] : [0, 0]), s = r.map((t) => d && e.colors ? [
					e.colors[t * 3],
					e.colors[t * 3 + 1],
					e.colors[t * 3 + 2]
				] : [
					1,
					1,
					1
				]), l = k(i, o);
				c.push(...i[0], t, ...i[1], 0, ...i[2], 0, ...a[0], o[0][0], ...a[1], o[0][1], ...a[2], o[1][0], o[1][1], o[2][0], o[2][1], 0, ...s[0], 0, ...s[1], 0, ...s[2], 0, ...l[0], 0, ...l[1], 0);
			}
		}
	}
	let l = c.length / 48;
	if (!l) return null;
	let u = (e, t, n) => c[e * 12 * 4 + t * 4 + n], d = (e, t) => Math.min(u(e, 0, t), u(e, 1, t), u(e, 2, t)), p = (e, t) => Math.max(u(e, 0, t), u(e, 1, t), u(e, 2, t)), m = (e, t) => (d(e, t) + p(e, t)) / 2, h = Array.from({ length: l }, (e, t) => t), g = [], _ = (e, t, n) => {
		let r = [
			Infinity,
			Infinity,
			Infinity,
			-Infinity,
			-Infinity,
			-Infinity
		], i = [
			Infinity,
			Infinity,
			Infinity,
			-Infinity,
			-Infinity,
			-Infinity
		];
		for (let e = t; e < n; e++) for (let t = 0; t < 3; t++) {
			let n = h[e];
			r[t] = Math.min(r[t], d(n, t)), r[t + 3] = Math.max(r[t + 3], p(n, t)), i[t] = Math.min(i[t], m(n, t)), i[t + 3] = Math.max(i[t + 3], m(n, t));
		}
		let a = (t, n) => {
			g[e * 8] = r[0], g[e * 8 + 1] = r[1], g[e * 8 + 2] = r[2], g[e * 8 + 3] = t, g[e * 8 + 4] = r[3], g[e * 8 + 5] = r[4], g[e * 8 + 6] = r[5], g[e * 8 + 7] = n;
		};
		if (n - t <= w) return a(t, n - t);
		let o = [
			0,
			1,
			2
		].map((e) => i[e + 3] - i[e]), s = o.indexOf(Math.max(...o)), c = (i[s] + i[s + 3]) / 2, l = t;
		for (let e = t; e < n; e++) m(h[e], s) < c && ([h[e], h[l]] = [h[l], h[e]], l++);
		if (l === t || l === n) {
			let e = h.slice(t, n).sort((e, t) => m(e, s) - m(t, s));
			h.splice(t, n - t, ...e), l = t + n >> 1;
		}
		let u = g.length / 8;
		g.push(...Array(16).fill(0)), a(u, 0), _(u, t, l), _(u + 1, l, n);
	};
	g.push(...Array(8).fill(0)), _(0, 0, l);
	let v = new Float32Array(l * 12 * 4);
	return h.forEach((e, t) => v.set(c.slice(e * 12 * 4, (e + 1) * 12 * 4), t * 12 * 4)), {
		nodes: new Float32Array(g),
		tris: v,
		nodeCount: g.length / 8,
		triCount: l,
		materials: r,
		pictures: i
	};
}
function O(e, t, n, r = Infinity) {
	let i = n.map((e) => 1 / e), a = [0], o = r, s = null;
	for (; a.length;) {
		let r = a.pop(), c = e.nodes.subarray(r * 8, r * 8 + 8), l = 0, u = o;
		for (let e = 0; e < 3; e++) {
			let n = (c[e] - t[e]) * i[e], r = (c[e + 4] - t[e]) * i[e];
			l = Math.max(l, Math.min(n, r)), u = Math.min(u, Math.max(n, r));
		}
		if (l > u) continue;
		let d = c[7], f = c[3];
		if (!d) a.push(f, f + 1);
		else for (let r = f; r < f + d; r++) {
			let i = e.tris.subarray(r * 12 * 4), a = [
				i[0],
				i[1],
				i[2]
			], c = [
				i[4] - a[0],
				i[5] - a[1],
				i[6] - a[2]
			], l = [
				i[8] - a[0],
				i[9] - a[1],
				i[10] - a[2]
			], u = [
				n[1] * l[2] - n[2] * l[1],
				n[2] * l[0] - n[0] * l[2],
				n[0] * l[1] - n[1] * l[0]
			], d = c[0] * u[0] + c[1] * u[1] + c[2] * u[2];
			if (Math.abs(d) < 1e-12) continue;
			let f = 1 / d, p = [
				t[0] - a[0],
				t[1] - a[1],
				t[2] - a[2]
			], m = f * (p[0] * u[0] + p[1] * u[1] + p[2] * u[2]);
			if (m < 0 || m > 1) continue;
			let h = [
				p[1] * c[2] - p[2] * c[1],
				p[2] * c[0] - p[0] * c[2],
				p[0] * c[1] - p[1] * c[0]
			], g = f * (n[0] * h[0] + n[1] * h[1] + n[2] * h[2]);
			if (g < 0 || m + g > 1) continue;
			let _ = f * (l[0] * h[0] + l[1] * h[1] + l[2] * h[2]);
			_ > 1e-4 && _ < o && (o = _, s = {
				t: _,
				tri: r,
				u: m,
				v: g
			});
		}
	}
	return s;
}
function k(e, t) {
	let n = [
		0,
		1,
		2
	].map((t) => e[1][t] - e[0][t]), r = [
		0,
		1,
		2
	].map((t) => e[2][t] - e[0][t]), i = t[1][0] - t[0][0], a = t[1][1] - t[0][1], o = t[2][0] - t[0][0], s = t[2][1] - t[0][1], c = i * s - a * o;
	if (Math.abs(c) < 1e-12) return [[
		0,
		0,
		0
	], [
		0,
		0,
		0
	]];
	let l = 1 / c;
	return [[
		0,
		1,
		2
	].map((e) => (n[e] * s - r[e] * a) * l), [
		0,
		1,
		2
	].map((e) => (r[e] * i - n[e] * o) * l)];
}
//#endregion
export { O as a, g as c, S as d, y as f, k as i, v as l, D as n, m as o, b as p, C as r, p as s, T as t, x as u };

//# sourceMappingURL=meshtrace-B2sLsePG.js.map