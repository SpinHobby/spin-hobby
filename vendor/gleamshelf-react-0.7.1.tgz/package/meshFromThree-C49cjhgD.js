import { n as e } from "./rolldown-runtime-DArdT4gl.js";
import { Cr as t, Ct as n, Sr as r, h as i, wt as a } from "./three.core-BCwsimN9.js";
import { a as o, f as s, i as c, m as l, n as u, o as d } from "./mesh-DZeCIO4D.js";
//#region ../scene3d/src/model/meshFromThree.ts
var f = /* @__PURE__ */ e({
	MAX_TRIANGLES: () => _,
	assetFromObject3D: () => v,
	skeletonOf: () => m,
	toModelAsset: () => y
}), p = (e) => {
	let t = e;
	return t?.map ?? t?.normalMap ?? t?.roughnessMap ?? t?.metalnessMap ?? t?.aoMap ?? t?.emissiveMap ?? null;
};
function m(e) {
	e.updateMatrixWorld(!0);
	let n = /* @__PURE__ */ new Set();
	if (e.traverse((e) => {
		let t = e;
		t.isSkinnedMesh && t.skeleton && t.skeleton.bones.forEach((e) => e && n.add(e));
	}), !n.size) return null;
	let r = /* @__PURE__ */ new Map();
	for (let e of [...n]) {
		let t = e.children.find((t) => n.has(t) && t.name === e.name);
		t && (r.set(e, t), n.delete(e));
	}
	let i = (e) => {
		for (let t = e.parent; t; t = t.parent) if (n.has(t)) return t;
		return null;
	}, a = (e) => {
		let t = i(e);
		return t ? a(t) + 1 : 0;
	}, o = [...n], s = new Map(o.map((e, t) => [e, t])), c = o.sort((e, t) => a(e) - a(t) || s.get(e) - s.get(t)).slice(0, 256), l = new Map(c.map((e, t) => [e, t])), d = new t(), f = c.map((e, t) => {
		let n = i(e);
		d.setFromMatrixPosition(e.matrixWorld);
		let r = [
			d.x,
			d.y,
			d.z
		];
		return {
			name: (e.name || `Bone ${t + 1}`).slice(0, 40),
			parent: n ? l.get(n) ?? -1 : -1,
			head: r,
			tail: r
		};
	});
	f.forEach((e, t) => e.tail = u(f, t));
	let p = (e) => {
		let t = e;
		for (; r.has(t);) t = r.get(t);
		for (let e = t; e; e = e.parent) if (l.has(e)) return l.get(e);
		return -1;
	}, m = c.map((e) => e.matrixWorld.clone().invert());
	return {
		bones: f,
		indexOf: p,
		order: c,
		fromBind: (e) => m[e]
	};
}
var h = Array(16).fill(0), g = 24e6, _ = 15e5;
async function v(e, s, l) {
	e.updateMatrixWorld(!0);
	let u = [], f = [], v = [], y = /* @__PURE__ */ new Set(), b = /* @__PURE__ */ new Map(), x = /* @__PURE__ */ new Map(), S = [], C = (e, t) => {
		let n = x.get(e);
		return n || (n = t().then((e) => e ? v.push(e) - 1 : (s && y.add("Some textures could not be read (compressed GPU textures); those parts do without them."), -1)), x.set(e, n)), n;
	}, w = (e, t) => C(`${e.uuid}:${t}`, () => s ? s(e, t) : Promise.resolve(null)), T = (e) => {
		if (!e) return f.push(o()) - 1;
		let t = b.get(e);
		if (t !== void 0) return t;
		let n = e, r = n.color ?? new i(1, 1, 1), a = (e) => e && e.channel !== 0 ? (y.add("Some maps use a second set of texture coordinates and were left out."), null) : e ?? null;
		for (let e of [
			"map",
			"normalMap",
			"roughnessMap",
			"metalnessMap",
			"aoMap",
			"emissiveMap",
			"clearcoatMap",
			"clearcoatRoughnessMap",
			"clearcoatNormalMap",
			"sheenColorMap",
			"sheenRoughnessMap",
			"transmissionMap"
		]) n[e] = a(n[e]);
		let s = (n.sheenColor ?? new i(0, 0, 0)).clone().multiplyScalar(n.sheen ?? 0), c = (n.emissive ?? new i(0, 0, 0)).clone().multiplyScalar(n.emissiveIntensity ?? 1), u = n.roughness ?? (n.shininess === void 0 ? .6 : 1 - Math.min(1, Math.sqrt(n.shininess / 100))), d = {
			color: [
				r.r,
				r.g,
				r.b
			],
			opacity: e.opacity ?? 1,
			metalness: n.metalness ?? 0,
			roughness: u,
			texture: -1,
			normalTexture: -1,
			normalScale: Math.abs(n.normalScale?.x ?? 1) || 1,
			roughnessTexture: -1,
			occlusionTexture: -1,
			occlusionStrength: n.aoMapIntensity ?? 1,
			emissive: [
				c.r,
				c.g,
				c.b
			],
			emissiveTexture: -1,
			clearcoat: n.clearcoat ?? 0,
			clearcoatTexture: -1,
			clearcoatRoughness: n.clearcoatRoughness ?? 0,
			clearcoatRoughnessTexture: -1,
			clearcoatNormalTexture: -1,
			clearcoatNormalScale: Math.abs(n.clearcoatNormalScale?.x ?? 1) || 1,
			sheenColor: [
				s.r,
				s.g,
				s.b
			],
			sheenColorTexture: -1,
			sheenRoughness: n.sheenRoughness ?? 0,
			sheenRoughnessTexture: -1,
			transmission: n.transmission ?? 0,
			transmissionTexture: -1,
			ior: Math.min(3, Math.max(1, n.ior ?? 1.5)),
			cutout: e.alphaTest > 0 || e.transparent,
			doubleSided: e.side === 2
		}, p = f.push(d) - 1;
		b.set(e, p), n.map && S.push(w(n.map, "color").then((e) => void (d.texture = e))), n.normalMap && S.push(w(n.normalMap, "data").then((e) => void (d.normalTexture = e))), n.aoMap && S.push(w(n.aoMap, "data").then((e) => void (d.occlusionTexture = e))), n.emissiveMap && S.push(w(n.emissiveMap, "color").then((e) => void (d.emissiveTexture = e)));
		let m = [
			[
				n.clearcoatMap,
				"data",
				(e) => d.clearcoatTexture = e
			],
			[
				n.clearcoatRoughnessMap,
				"data",
				(e) => d.clearcoatRoughnessTexture = e
			],
			[
				n.clearcoatNormalMap,
				"data",
				(e) => d.clearcoatNormalTexture = e
			],
			[
				n.sheenColorMap,
				"color",
				(e) => d.sheenColorTexture = e
			],
			[
				n.sheenRoughnessMap,
				"data",
				(e) => d.sheenRoughnessTexture = e
			],
			[
				n.transmissionMap,
				"data",
				(e) => d.transmissionTexture = e
			]
		];
		for (let [e, t, n] of m) e && S.push(w(e, t).then(n));
		let h = n.roughnessMap ?? null, g = n.metalnessMap ?? null;
		if (h || g) {
			let e = h && h === g ? h : null;
			S.push((e ? w(e, "data") : C(`${h?.uuid}+${g?.uuid}`, () => l ? l(h, g) : Promise.resolve(null))).then((e) => void (d.roughnessTexture = e)));
		}
		return p;
	}, E = m(e), D = /* @__PURE__ */ new Map(), O = 0, k = new a(), A = new a(), j = new n(), M = 0;
	if (e.traverse((e) => {
		let i = e;
		if (!i.isMesh || !i.visible) return;
		let o = i.geometry, s = o.getAttribute("position");
		if (!s) return;
		let l = o.getIndex(), d = o.getAttribute("normal"), f = o.getAttribute("uv"), m = o.getAttribute("color"), v = Array.isArray(i.material) ? i.material : [i.material], y = o.groups.length ? o.groups : [{
			start: 0,
			count: l ? l.count : s.count,
			materialIndex: 0
		}], b = i.isSkinnedMesh ? i : null, x = i.isInstancedMesh ? i : null, S = [];
		if (x) for (let e = 0; e < x.count; e++) {
			let t = new a();
			x.getMatrixAt(e, t), S.push(i.matrixWorld.clone().multiply(t));
		}
		else S.push(b ? b.bindMatrix : i.matrixWorld);
		let C = b ? o.getAttribute("skinIndex") : null, w = b ? o.getAttribute("skinWeight") : null, N = E && !b ? E.indexOf(i) : -1;
		for (let e of S) {
			let a = new n().getNormalMatrix(e), x = e.determinant() < 0;
			for (let S of y) {
				let y = v[S.materialIndex ?? 0] ?? v[0], P = T(y), F = !!m && y?.vertexColors === !0, I = p(y);
				I && I.updateMatrix();
				let L = Math.min(S.start + S.count, l ? l.count : s.count), R = /* @__PURE__ */ new Map(), z = [];
				for (let e = S.start; e + 2 < L; e += 3) {
					let t = [
						0,
						1,
						2
					].map((t) => l ? l.getX(e + t) : e + t);
					x && ([t[1], t[2]] = [t[2], t[1]]);
					for (let e of t) R.has(e) || R.set(e, R.size), z.push(R.get(e));
				}
				if (!z.length) continue;
				let B = R.size, V = new Float32Array(B * 3), H = d ? new Float32Array(B * 3) : null, U = f ? new Float32Array(B * 2) : null, W = F ? new Float32Array(B * 3) : null, G = E ? new Uint16Array(B * 4) : null, K = E ? new Float32Array(B * 4) : null, q = new t(), J = new r();
				for (let [t, n] of R) {
					if (b && C && w) {
						k.fromArray(h);
						for (let e = 0; e < 4; e++) {
							let n = w.getComponent(t, e), r = C.getComponent(t, e), i = b.skeleton.bones[r];
							if (n && i) {
								A.multiplyMatrices(i.matrixWorld, b.skeleton.boneInverses[r]);
								for (let e = 0; e < 16; e++) k.elements[e] += A.elements[e] * n;
							}
						}
						k.multiply(b.bindMatrix), q.fromBufferAttribute(s, t).applyMatrix4(k), V.set([
							q.x,
							q.y,
							q.z
						], n * 3), H && (q.fromBufferAttribute(d, t).applyMatrix3(j.setFromMatrix4(k)).normalize(), H.set([
							q.x,
							q.y,
							q.z
						], n * 3));
					} else q.fromBufferAttribute(s, t).applyMatrix4(e), V.set([
						q.x,
						q.y,
						q.z
					], n * 3), H && (q.fromBufferAttribute(d, t).applyMatrix3(a).normalize(), H.set([
						q.x,
						q.y,
						q.z
					], n * 3));
					if (U && (J.set(f.getX(t), f.getY(t)), I && (J.applyMatrix3(I.matrix), I.flipY && (J.y = 1 - J.y)), U.set([J.x, J.y], n * 2)), W && W.set([
						m.getX(t),
						m.getY(t),
						m.getZ(t)
					], n * 3), G && K) {
						if (b && C && w) for (let e = 0; e < 4; e++) {
							let r = b.skeleton.bones[C.getComponent(t, e)];
							G[n * 4 + e] = r ? Math.max(0, E.indexOf(r)) : 0, K[n * 4 + e] = w.getComponent(t, e);
						}
						else G[n * 4] = Math.max(0, N), K[n * 4] = 1;
					}
				}
				let Y = i.morphTargetDictionary, X = o.morphAttributes.position;
				if (Y && X?.length && O < g) {
					let r = o.morphTargetsRelative, i = new n().setFromMatrix4(e);
					for (let [e, n] of Object.entries(Y)) {
						let a = X[n];
						if (!a) continue;
						let o = new Float32Array(B * 3), c = !1;
						for (let [e, n] of R) q.fromBufferAttribute(a, e), r || q.sub(new t().fromBufferAttribute(s, e)), (q.x || q.y || q.z) && (c = !0, q.applyMatrix3(i), o.set([
							q.x,
							q.y,
							q.z
						], n * 3));
						c && (O += o.byteLength, D.has(e) || D.set(e, /* @__PURE__ */ new Map()), D.get(e).set(u.length, o));
					}
				}
				let Z = Uint32Array.from(z);
				if (M += Z.length / 3, M > 15e5) throw Error(`This model has more than ${_.toLocaleString("en")} triangles; simplify it first (Blender's Decimate does it).`);
				let Q = !!H;
				for (let e = 0; Q && e < B; e++) Math.hypot(H[e * 3], H[e * 3 + 1], H[e * 3 + 2]) > 1e-4 || (Q = !1);
				u.push({
					positions: V,
					normals: Q ? H : c(V, Z),
					uvs: U,
					colors: W,
					indices: Z,
					material: P,
					...G ? {
						joints: G,
						skinWeights: K
					} : {}
				});
			}
		}
	}), await Promise.all(S), !u.length) throw Error("There is nothing to draw in that file (no triangles).");
	let N = [...D.keys()];
	return {
		asset: {
			...d(u, f, v),
			...E ? { skeleton: E.bones } : {},
			...N.length ? { morphs: {
				names: N,
				moves: N.map((e) => u.map((t, n) => D.get(e).get(n) ?? null))
			} } : {}
		},
		warnings: [...y]
	};
}
function y(e, t) {
	return {
		name: t.slice(0, 80) || "Model",
		data: s(l(e)),
		triangles: e.triangles,
		size: e.max.map((t, n) => t - e.min[n]),
		centre: e.min.map((t, n) => (t + e.max[n]) / 2)
	};
}
//#endregion
export { y as a, m as i, v as n, f as r, _ as t };

//# sourceMappingURL=meshFromThree-C49cjhgD.js.map