import { n as e } from "./rolldown-runtime-DArdT4gl.js";
import { C as t, M as n, O as r, T as i, b as a, m as o, o as s, p as c, w as l } from "./GleamEditor-BwL_fApV.js";
import { a as u, i as d, n as f, t as p } from "./library-BhwMQqZz.js";
import { a as m, c as h, d as g, f as _, i as v, l as y, n as b, o as x, p as S, r as C, s as w, t as T, u as E } from "./src-B9VqgbK-.js";
import { a as D, c as O, d as k, i as A, m as j, o as M, r as ee, s as te } from "./mesh-DZeCIO4D.js";
import { $ as ne, $i as N, Ai as P, At as re, B as F, Bi as I, Bt as ie, Ci as ae, Cn as oe, D as L, Di as se, Dn as ce, Dt as le, E as ue, Ei as de, Er as fe, Et as pe, F as me, Ft as he, Hn as ge, I as _e, In as ve, It as ye, Jt as be, K as xe, Kn as Se, Kt as R, L as Ce, Lt as z, Mn as we, Mr as Te, Ni as Ee, Nn as De, O as Oe, Oi as B, On as ke, Or as Ae, Pn as je, Pr as Me, Q as Ne, Qi as Pe, Qt as Fe, R as Ie, Rt as Le, Si as Re, Sn as ze, Ti as Be, Tt as Ve, V as He, Vi as Ue, X as We, Xi as Ge, Xn as Ke, Xt as qe, Y as Je, Yi as Ye, Yr as Xe, Yt as Ze, Zi as Qe, _a as $e, _i as V, _n as et, a as tt, aa as nt, at as rt, bn as it, ca as at, d as ot, da as st, dn as ct, ea as lt, er as ut, et as dt, ga as ft, gi as pt, ha as mt, hi as ht, hn as gt, i as _t, ii as vt, it as yt, ji as bt, jr as xt, k as St, kn as Ct, m as wt, ma as Tt, mn as Et, n as Dt, nn as Ot, o as kt, oa as At, on as jt, or as Mt, pn as Nt, pt as Pt, q as Ft, qt as It, r as Lt, ri as Rt, sa as zt, tr as Bt, u as Vt, vi as Ht, vn as Ut, wi as Wt, wn as Gt, wt as Kt, xi as qt, xn as H, yi as Jt, yn as Yt } from "./document-CNMOilB9.js";
import { $ as Xt, A as Zt, At as Qt, B as $t, Bt as en, C as tn, Ct as nn, D as rn, Dt as an, E as on, Et as sn, F as cn, Ft as ln, G as un, Gt as dn, H as fn, Ht as pn, I as mn, It as hn, J as gn, K as _n, L as vn, Lt as yn, M as bn, Mt as xn, N as Sn, Nt as Cn, O as wn, Ot as Tn, P as En, Pt as Dn, Q as On, Rt as kn, S as An, St as jn, T as Mn, Tt as Nn, U as Pn, Ut as Fn, V as In, Vt as Ln, W as Rn, Wt as zn, X as Bn, Y as Vn, Z as Hn, Zt as Un, _ as Wn, _t as Gn, a as Kn, an as qn, b as Jn, bt as Yn, c as Xn, d as Zn, dt as Qn, et as $n, f as er, gt as tr, ht as nr, in as rr, j as ir, jt as ar, k as or, kt as sr, l as cr, nn as lr, nt as ur, o as dr, p as fr, q as pr, r as mr, rn as hr, rt as gr, s as _r, tn as vr, tt as yr, u as br, vt as xr, w as Sr, wt as Cr, x as wr, xt as Tr, y as Er, yt as Dr, z as Or, zt as kr } from "./core-AdQZWWr9.js";
import { c as Ar, l as jr, o as Mr, s as Nr } from "./meshtrace-B2sLsePG.js";
import { a as Pr } from "./meshFromThree-C49cjhgD.js";
import { a as Fr, c as U, i as Ir, l as Lr, n as Rr, o as W, r as zr, s as Br, t as Vr } from "./scene-BPfcQvQO.js";
import { a as Hr, i as Ur, n as Wr, o as Gr, r as Kr, s as qr, t as Jr } from "./GamePlay-0VCcvge3.js";
/* empty css                 */
import { useCallback as Yr, useEffect as G, useMemo as Xr, useRef as K, useState as q, useSyncExternalStore as Zr } from "react";
import { Fragment as J, jsx as Y, jsxs as X } from "react/jsx-runtime";
//#region ../scene3d/src/model/elements.ts
var Qr = [
	"vertex",
	"edge",
	"face"
], $r = {
	vertex: "Points",
	edge: "Edges",
	face: "Faces"
}, ei = /* @__PURE__ */ new WeakMap();
function ti(e) {
	let t = ei.get(e);
	if (t) return t;
	let n = e.length / 3, r = new Uint32Array(n), i = /* @__PURE__ */ new Map(), a = [];
	for (let t = 0; t < n; t++) {
		let n = `${Math.round(e[t * 3] * 1e5)},${Math.round(e[t * 3 + 1] * 1e5)},${Math.round(e[t * 3 + 2] * 1e5)}`, o = i.get(n);
		o === void 0 && (i.set(n, o = a.length), a.push([])), r[t] = o, a[o].push(t);
	}
	let o = {
		place: r,
		points: a
	};
	return ei.set(e, o), o;
}
var Z = (e, t) => [
	e[0] - t[0],
	e[1] - t[1],
	e[2] - t[2]
], ni = (e, t) => e[0] * t[0] + e[1] * t[1] + e[2] * t[2], ri = (e, t) => [
	e[1] * t[2] - e[2] * t[1],
	e[2] * t[0] - e[0] * t[2],
	e[0] * t[1] - e[1] * t[0]
], ii = (e) => {
	let t = Math.hypot(...e) || 1;
	return [
		e[0] / t,
		e[1] / t,
		e[2] / t
	];
}, ai = (e, t) => [
	e[t * 3],
	e[t * 3 + 1],
	e[t * 3 + 2]
];
function oi(e, t, n) {
	let r = Z(n, t);
	return Math.min(1, Math.max(0, ni(Z(e, t), r) / Math.max(ni(r, r), 1e-20)));
}
function si(e, t, n, r) {
	let i = Z(n, t), a = Z(r, t), o = Z(e, t), s = ni(i, o), c = ni(a, o), l;
	if (s <= 0 && c <= 0) l = t;
	else {
		let o = Z(e, n), u = ni(i, o), d = ni(a, o), f = Z(e, r), p = ni(i, f), m = ni(a, f), h = s * d - u * c, g = p * c - s * m, _ = u * m - p * d;
		if (u >= 0 && d <= u) l = n;
		else if (m >= 0 && p <= m) l = r;
		else if (h <= 0 && s >= 0 && u <= 0) {
			let e = s / (s - u);
			l = [
				t[0] + i[0] * e,
				t[1] + i[1] * e,
				t[2] + i[2] * e
			];
		} else if (g <= 0 && c >= 0 && m <= 0) {
			let e = c / (c - m);
			l = [
				t[0] + a[0] * e,
				t[1] + a[1] * e,
				t[2] + a[2] * e
			];
		} else if (_ <= 0 && d - u >= 0 && p - m >= 0) {
			let e = (d - u) / (d - u + (p - m));
			l = [
				n[0] + (r[0] - n[0]) * e,
				n[1] + (r[1] - n[1]) * e,
				n[2] + (r[2] - n[2]) * e
			];
		} else {
			let e = 1 / (_ + g + h), n = g * e, r = h * e;
			l = [
				t[0] + i[0] * n + a[0] * r,
				t[1] + i[1] * n + a[1] * r,
				t[2] + i[2] * n + a[2] * r
			];
		}
	}
	let u = Z(e, l);
	return ni(u, u);
}
var ci = (e, t, n) => ii(ri(Z(ai(e, t[n * 3 + 1]), ai(e, t[n * 3])), Z(ai(e, t[n * 3 + 2]), ai(e, t[n * 3]))));
function li(e, t) {
	let n = /* @__PURE__ */ new Map(), r = e.indices;
	for (let e = 0; e < r.length / 3; e++) for (let i = 0; i < 3; i++) {
		let a = t.place[r[e * 3 + i]], o = t.place[r[e * 3 + (i + 1) % 3]], s = a < o ? `${a},${o}` : `${o},${a}`, c = n.get(s);
		c ? c.push(e) : n.set(s, [e]);
	}
	return n;
}
function ui(e, t) {
	let n = ti(e.positions), r = li(e, n), i = e.indices, a = ci(e.positions, i, t), o = /* @__PURE__ */ new Set([t]), s = [t];
	for (; s.length;) {
		let t = s.pop();
		for (let c = 0; c < 3; c++) {
			let l = n.place[i[t * 3 + c]], u = n.place[i[t * 3 + (c + 1) % 3]];
			for (let t of r.get(l < u ? `${l},${u}` : `${u},${l}`) ?? []) !o.has(t) && ni(ci(e.positions, i, t), a) > Math.cos(2 * Math.PI / 180) && (o.add(t), s.push(t));
		}
	}
	return [...o].sort((e, t) => e - t);
}
function di(e, t, n) {
	let r = Infinity, i = -1, a = -1;
	if (e.parts.forEach((e, n) => {
		let o = e.positions, s = e.indices;
		for (let e = 0; e < s.length / 3; e++) {
			let c = si(t, ai(o, s[e * 3]), ai(o, s[e * 3 + 1]), ai(o, s[e * 3 + 2]));
			c < r && ([r, i, a] = [
				c,
				n,
				e
			]);
		}
	}), i < 0) return null;
	let o = e.parts[i], s = ti(o.positions), c = [
		0,
		1,
		2
	].map((e) => o.indices[a * 3 + e]);
	if (n === "face") {
		let e = ui(o, a), t = /* @__PURE__ */ new Set();
		for (let n of e) for (let e = 0; e < 3; e++) t.add(s.place[o.indices[n * 3 + e]]);
		return {
			part: i,
			mode: n,
			places: [...t],
			triangles: e
		};
	}
	if (n === "vertex") {
		let e = c.reduce((e, n) => ni(Z(ai(o.positions, n), t), Z(ai(o.positions, n), t)) < ni(Z(ai(o.positions, e), t), Z(ai(o.positions, e), t)) ? n : e);
		return {
			part: i,
			mode: n,
			places: [s.place[e]],
			triangles: []
		};
	}
	let l = [c[0], c[1]], u = Infinity;
	for (let e = 0; e < 3; e++) {
		let n = ai(o.positions, c[e]), r = ai(o.positions, c[(e + 1) % 3]), i = oi(t, n, r), a = Z(t, [
			n[0] + (r[0] - n[0]) * i,
			n[1] + (r[1] - n[1]) * i,
			n[2] + (r[2] - n[2]) * i
		]);
		ni(a, a) < u && ([u, l] = [ni(a, a), [c[e], c[(e + 1) % 3]]]);
	}
	return {
		part: i,
		mode: n,
		places: [s.place[l[0]], s.place[l[1]]],
		triangles: []
	};
}
function fi(e, t) {
	return !e || e.part !== t.part || e.mode !== t.mode ? t : t.mode === "vertex" && e.places.includes(t.places[0]) ? {
		...e,
		places: e.places.filter((e) => e !== t.places[0])
	} : {
		...e,
		places: [.../* @__PURE__ */ new Set([...e.places, ...t.places])],
		triangles: [.../* @__PURE__ */ new Set([...e.triangles, ...t.triangles])].sort((e, t) => e - t)
	};
}
function pi(e, t) {
	let n = e.parts[t.part];
	if (!n) return [];
	if (t.mode === "edge") return t.places.flatMap((e, n) => n % 2 ? [[t.places[n - 1], e]] : []);
	if (t.mode === "vertex") return [];
	let r = ti(n.positions), i = /* @__PURE__ */ new Map();
	for (let e of t.triangles) for (let t = 0; t < 3; t++) {
		let a = r.place[n.indices[e * 3 + t]], o = r.place[n.indices[e * 3 + (t + 1) % 3]];
		i.set(a < o ? `${a},${o}` : `${o},${a}`, [a, o]);
	}
	return [...i.values()];
}
var mi = (e, t, n) => {
	let r = e.parts[t];
	return ai(r.positions, ti(r.positions).points[n][0]);
};
function hi(e, t) {
	let n = [
		0,
		0,
		0
	];
	for (let r of t.places) {
		let i = mi(e, t.part, r);
		for (let e = 0; e < 3; e++) n[e] += i[e] / t.places.length;
	}
	return n;
}
function gi(e, t, n) {
	let r = e.parts.map((e, r) => r === t ? {
		...e,
		...n,
		normals: A(n.positions, n.indices)
	} : e);
	return M(r, e.materials, e.textures);
}
function _i(e, t, n) {
	let r = e.parts[t.part], i = ti(r.positions), a = new Float32Array(r.positions);
	for (let e of t.places) {
		let t = n(ai(r.positions, i.points[e][0]));
		for (let n of i.points[e]) a.set(t, n * 3);
	}
	return gi(e, t.part, {
		...r,
		positions: a
	});
}
var vi = (e, t, n) => _i(e, t, (e) => [
	e[0] + n[0],
	e[1] + n[1],
	e[2] + n[2]
]);
function yi(e, t, n) {
	let r = hi(e, t);
	return _i(e, t, (e) => [
		r[0] + (e[0] - r[0]) * n,
		r[1] + (e[1] - r[1]) * n,
		r[2] + (e[2] - r[2]) * n
	]);
}
function bi(e, t, n, r) {
	let i = hi(e, t), [a, o] = [Math.cos(r * Math.PI / 180), Math.sin(r * Math.PI / 180)], [s, c] = n === 0 ? [1, 2] : n === 1 ? [2, 0] : [0, 1];
	return _i(e, t, (e) => {
		let t = Z(e, i), n = [...t];
		return n[s] = t[s] * a - t[c] * o, n[c] = t[s] * o + t[c] * a, [
			n[0] + i[0],
			n[1] + i[1],
			n[2] + i[2]
		];
	});
}
function xi(e, t) {
	let n = [];
	for (let r = 0; r < e.indices.length / 3; r++) t(r) && n.push(r);
	let r = /* @__PURE__ */ new Map(), i = new Uint32Array(n.length * 3);
	n.forEach((t, n) => {
		for (let a = 0; a < 3; a++) {
			let o = e.indices[t * 3 + a], s = r.get(o);
			s === void 0 && r.set(o, s = r.size), i[n * 3 + a] = s;
		}
	});
	let a = (e, t) => {
		if (!e) return null;
		let n = new Float32Array(r.size * t);
		for (let [i, a] of r) for (let r = 0; r < t; r++) n[a * t + r] = e[i * t + r];
		return n;
	};
	return {
		positions: a(e.positions, 3),
		uvs: a(e.uvs, 2),
		colors: a(e.colors, 3),
		indices: i,
		material: e.material
	};
}
function Si(e, t) {
	let n = e.parts[t.part], r = ti(n.positions), i = new Set(t.places), a = new Set(t.triangles), o = new Set(pi(e, t).map(([e, t]) => e < t ? `${e},${t}` : `${t},${e}`)), s = (e) => {
		if (t.mode === "face") return a.has(e);
		let s = [
			0,
			1,
			2
		].map((t) => r.place[n.indices[e * 3 + t]]);
		return t.mode === "vertex" ? s.some((e) => i.has(e)) : [
			0,
			1,
			2
		].some((e) => {
			let [t, n] = [s[e], s[(e + 1) % 3]];
			return o.has(t < n ? `${t},${n}` : `${n},${t}`);
		});
	};
	return gi(e, t.part, xi(n, (e) => !s(e)));
}
function Ci(e, t) {
	let n = hi(e, t), r = _i(e, t, () => n), i = r.parts[t.part], a = ti(e.parts[t.part].positions), o = new Set(t.places), s = xi(i, (e) => [
		0,
		1,
		2
	].filter((t) => o.has(a.place[i.indices[e * 3 + t]])).length < 2);
	return gi(r, t.part, s);
}
function wi(e, t) {
	if (t.places.length < 3 || t.places.length > 4) throw Error("Pick 3 or 4 points to fill between.");
	let n = e.parts[t.part], r = ti(n.positions), i = t.places.map((n) => ({
		v: r.points[n][0],
		p: mi(e, t.part, n)
	})), a = hi(e, t), o = ii(ri(Z(i[1].p, i[0].p), Z(i[2].p, i[0].p))), s = ii(Z(i[0].p, a)), c = ri(o, s);
	i.sort((e, t) => Math.atan2(ni(Z(e.p, a), c), ni(Z(e.p, a), s)) - Math.atan2(ni(Z(t.p, a), c), ni(Z(t.p, a), s))), o = ii(ri(Z(i[1].p, i[0].p), Z(i[2].p, i[0].p)));
	let l = e.min.map((t, n) => (t + e.max[n]) / 2);
	ni(o, Z(a, l)) < 0 && i.reverse();
	let u = i.length === 3 ? [
		0,
		1,
		2
	] : [
		0,
		1,
		2,
		0,
		2,
		3
	], d = new Uint32Array(n.indices.length + u.length);
	return d.set(n.indices), u.forEach((e, t) => d[n.indices.length + t] = i[e].v), gi(e, t.part, {
		...n,
		indices: d
	});
}
function Ti(e, t) {
	let n = e.positions.length / 3, r = new Map(t.map((e, t) => [e, n + t])), i = (e, r) => {
		if (!e) return null;
		let i = new Float32Array((n + t.length) * r);
		return i.set(e), t.forEach((t, a) => i.set(e.subarray(t * r, t * r + r), (n + a) * r)), i;
	};
	return {
		part: {
			...e,
			positions: i(e.positions, 3),
			uvs: i(e.uvs, 2),
			colors: i(e.colors, 3)
		},
		to: r
	};
}
function Ei(e, t, n, r = 0) {
	if (t.mode !== "face" || !t.triangles.length) throw Error("Pick faces to push out.");
	let i = e.parts[t.part], a = ti(i.positions), o = i.indices, s = new Set(t.triangles), c = [
		0,
		0,
		0
	];
	for (let e of s) {
		let t = ci(i.positions, o, e);
		for (let e = 0; e < 3; e++) c[e] += t[e];
	}
	let l = ii(c), u = [...new Set(t.triangles.flatMap((e) => [
		o[e * 3],
		o[e * 3 + 1],
		o[e * 3 + 2]
	]))], { part: d, to: f } = Ti(i, u), p = hi(e, t);
	for (let e of u) {
		let t = f.get(e) * 3;
		for (let e = 0; e < 3; e++) {
			let i = d.positions[t + e];
			d.positions[t + e] = p[e] + (i - p[e]) * (1 - r) + l[e] * n;
		}
	}
	let m = /* @__PURE__ */ new Map();
	for (let e of s) for (let t = 0; t < 3; t++) {
		let n = a.place[o[e * 3 + t]], r = a.place[o[e * 3 + (t + 1) % 3]], i = n < r ? `${n},${r}` : `${r},${n}`;
		m.set(i, (m.get(i) ?? 0) + 1);
	}
	let h = [], g = new Uint32Array(o);
	for (let e of s) for (let t = 0; t < 3; t++) {
		let n = o[e * 3 + t], r = o[e * 3 + (t + 1) % 3], i = a.place[n], s = a.place[r];
		m.get(i < s ? `${i},${s}` : `${s},${i}`) === 1 && h.push(n, r, f.get(r), n, f.get(r), f.get(n));
	}
	for (let e of s) for (let t = 0; t < 3; t++) g[e * 3 + t] = f.get(o[e * 3 + t]);
	let _ = new Uint32Array(g.length + h.length);
	return _.set(g), _.set(h, g.length), gi(e, t.part, {
		...d,
		indices: _
	});
}
function Di(e, t, n) {
	let r = ii(n), i = e.parts.map((e) => {
		let n = e.positions, i = (e) => ni(Z(ai(n, e), t), r), a = [...n], o = e.uvs ? [...e.uvs] : null, s = e.colors ? [...e.colors] : null, c = /* @__PURE__ */ new Map(), l = (t, r) => {
			let l = t < r ? `${t},${r}` : `${r},${t}`, u = c.get(l);
			if (u !== void 0) return u;
			let d = i(t), f = d / (d - i(r)), p = a.length / 3;
			for (let e = 0; e < 3; e++) a.push(n[t * 3 + e] + (n[r * 3 + e] - n[t * 3 + e]) * f);
			if (o && e.uvs) for (let n = 0; n < 2; n++) o.push(e.uvs[t * 2 + n] + (e.uvs[r * 2 + n] - e.uvs[t * 2 + n]) * f);
			if (s && e.colors) for (let n = 0; n < 3; n++) s.push(e.colors[t * 3 + n] + (e.colors[r * 3 + n] - e.colors[t * 3 + n]) * f);
			return c.set(l, p), p;
		}, u = [], d = e.indices;
		for (let e = 0; e < d.length; e += 3) {
			let t = [
				d[e],
				d[e + 1],
				d[e + 2]
			], n = t.map((e) => i(e) >= 0), r = n.findIndex((e, t) => e !== n[(t + 1) % 3] && e !== n[(t + 2) % 3]);
			if (r < 0) {
				u.push(...t);
				continue;
			}
			let a = t[r], o = t[(r + 1) % 3], s = t[(r + 2) % 3], c = l(a, o), f = l(a, s);
			u.push(a, c, f, c, o, s, c, s, f);
		}
		let f = {
			...e,
			positions: new Float32Array(a),
			uvs: o && new Float32Array(o),
			colors: s && new Float32Array(s),
			indices: new Uint32Array(u)
		};
		return {
			...f,
			normals: A(f.positions, f.indices)
		};
	});
	return M(i, e.materials, e.textures);
}
function Oi(e, t) {
	if (t.places.length < 2) throw Error("Pick an edge to cut across.");
	let n = mi(e, t.part, t.places[0]), r = mi(e, t.part, t.places[1]);
	return Di(e, [
		(n[0] + r[0]) / 2,
		(n[1] + r[1]) / 2,
		(n[2] + r[2]) / 2
	], Z(r, n));
}
//#endregion
//#region ../scene3d/src/model/uvmap.ts
function ki(e, t = .01) {
	let n = [], r = e.parts.map((e) => {
		let r = e.positions, i = e.indices, a = i.length / 3, o = ti(r), s = new Uint8Array(a);
		for (let e = 0; e < a; e++) {
			let [t, n, a] = [
				i[e * 3] * 3,
				i[e * 3 + 1] * 3,
				i[e * 3 + 2] * 3
			], o = [
				r[n] - r[t],
				r[n + 1] - r[t + 1],
				r[n + 2] - r[t + 2]
			], c = [
				r[a] - r[t],
				r[a + 1] - r[t + 1],
				r[a + 2] - r[t + 2]
			], l = [
				o[1] * c[2] - o[2] * c[1],
				o[2] * c[0] - o[0] * c[2],
				o[0] * c[1] - o[1] * c[0]
			], u = [
				0,
				1,
				2
			].reduce((e, t) => Math.abs(l[t]) > Math.abs(l[e]) ? t : e, 0);
			s[e] = u * 2 + +(l[u] < 0);
		}
		let c = /* @__PURE__ */ new Map();
		for (let e = 0; e < a; e++) for (let t = 0; t < 3; t++) {
			let n = o.place[i[e * 3 + t]], r = o.place[i[e * 3 + (t + 1) % 3]], a = n < r ? `${n},${r}` : `${r},${n}`, s = c.get(a);
			s ? s.push(e) : c.set(a, [e]);
		}
		let l = new Int32Array(a).fill(-1), u = [];
		for (let e = 0; e < a; e++) {
			if (l[e] >= 0) continue;
			let t = {
				tris: [],
				axis: s[e],
				min: [Infinity, Infinity],
				max: [-Infinity, -Infinity],
				place: [0, 0]
			};
			l[e] = u.length;
			let n = [e];
			for (; n.length;) {
				let e = n.pop();
				t.tris.push(e);
				for (let r = 0; r < 3; r++) {
					let a = o.place[i[e * 3 + r]], d = o.place[i[e * 3 + (r + 1) % 3]];
					for (let e of c.get(a < d ? `${a},${d}` : `${d},${a}`) ?? []) l[e] < 0 && s[e] === t.axis && (l[e] = u.length, n.push(e));
				}
			}
			u.push(t);
		}
		let d = (e, t) => {
			let n = t >> 1, i = t & 1, [a, o] = n === 0 ? [2, 1] : n === 1 ? [0, 2] : [0, 1], s = r[e * 3 + a], c = r[e * 3 + o];
			return [n === 0 ? i ? s : -s : i ? -s : s, n === 1 && i ? c : -c];
		};
		for (let e of u) for (let t of e.tris) for (let n = 0; n < 3; n++) {
			let [r, a] = d(i[t * 3 + n], e.axis);
			e.min = [Math.min(e.min[0], r), Math.min(e.min[1], a)], e.max = [Math.max(e.max[0], r), Math.max(e.max[1], a)];
		}
		let f = u.reduce((e, n) => e + (n.max[0] - n.min[0] + t) * (n.max[1] - n.min[1] + t), 0), p = u.map((e, t) => t).sort((e, t) => u[t].max[1] - u[t].min[1] - (u[e].max[1] - u[e].min[1])), m = Math.sqrt(f) || 1;
		for (let e = 0; e < 40; e++) {
			let e = 0, n = 0, r = 0, i = !0;
			for (let a of p) {
				let o = u[a], s = o.max[0] - o.min[0] + t, c = o.max[1] - o.min[1] + t;
				e + s > m && e > 0 && (e = 0, n += r, r = 0), o.place = [e, n], e += s, r = Math.max(r, c), s > m && (i = !1);
			}
			if (i && n + r <= m) break;
			m *= 1.08;
		}
		let h = /* @__PURE__ */ new Map(), g = [], _ = [], v = new Uint32Array(i.length);
		u.forEach((e, n) => {
			for (let r of e.tris) for (let a = 0; a < 3; a++) {
				let o = i[r * 3 + a], s = `${n},${o}`, c = h.get(s);
				if (c === void 0) {
					h.set(s, c = g.length), g.push(o);
					let [n, r] = d(o, e.axis);
					_.push((n - e.min[0] + e.place[0] + t / 2) / m, (r - e.min[1] + e.place[1] + t / 2) / m);
				}
				v[r * 3 + a] = c;
			}
		});
		let y = new Uint32Array(g);
		n.push(y);
		let b = (e, t) => {
			if (!e) return null;
			let n = new Float32Array(y.length * t);
			return y.forEach((r, i) => n.set(e.subarray(r * t, r * t + t), i * t)), n;
		}, x = b(r, 3);
		return {
			...e,
			positions: x,
			normals: b(e.normals, 3) ?? A(x, v),
			uvs: new Float32Array(_),
			colors: b(e.colors, 3),
			indices: v
		};
	});
	return {
		asset: M(r, e.materials, e.textures),
		from: n
	};
}
var Ai = (e) => (e / 255) ** 2.2, ji = (e) => Math.round(Math.min(1, Math.max(0, e)) ** (1 / 2.2) * 255);
function Mi(e, t, n, r) {
	return t.asset.parts.map((i, a) => {
		let o = e.parts[a], s = t.from[a], c = e.materials[o.material], l = new Uint8ClampedArray(n * n * 4), u = new Uint8Array(n * n), d = i.uvs, f = i.indices;
		for (let e = 0; e < f.length; e += 3) {
			let t = [
				f[e],
				f[e + 1],
				f[e + 2]
			], [i, a, p] = t.map((e) => [d[e * 2] * n - .5, d[e * 2 + 1] * n - .5]), m = (a[1] - p[1]) * (i[0] - p[0]) + (p[0] - a[0]) * (i[1] - p[1]);
			if (Math.abs(m) < 1e-12) continue;
			let h = Math.max(0, Math.floor(Math.min(i[0], a[0], p[0]))), g = Math.min(n - 1, Math.ceil(Math.max(i[0], a[0], p[0]))), _ = Math.max(0, Math.floor(Math.min(i[1], a[1], p[1]))), v = Math.min(n - 1, Math.ceil(Math.max(i[1], a[1], p[1])));
			for (let e = _; e <= v; e++) for (let d = h; d <= g; d++) {
				let f = ((a[1] - p[1]) * (d - p[0]) + (p[0] - a[0]) * (e - p[1])) / m, h = ((p[1] - i[1]) * (d - p[0]) + (i[0] - p[0]) * (e - p[1])) / m, g = 1 - f - h;
				if (f < -.02 || h < -.02 || g < -.02) continue;
				[f, h, g] = [
					Math.max(0, f),
					Math.max(0, h),
					Math.max(0, g)
				];
				let _ = f + h + g, v = [
					f / _,
					h / _,
					g / _
				], y = t.map((e) => s[e]), b = c ? [...c.color] : [
					.8,
					.8,
					.8
				], x = 1;
				if (c && c.texture >= 0 && o.uvs) {
					let e = v.reduce((e, t, n) => e + t * o.uvs[y[n] * 2], 0), t = v.reduce((e, t, n) => e + t * o.uvs[y[n] * 2 + 1], 0), n = r(c.texture, e, t);
					n && (b = [
						b[0] * Ai(n[0]),
						b[1] * Ai(n[1]),
						b[2] * Ai(n[2])
					], x *= n[3] / 255);
				}
				if (o.colors) {
					let e = [
						0,
						1,
						2
					].map((e) => v.reduce((t, n, r) => t + n * o.colors[y[r] * 3 + e], 0));
					b = [
						b[0] * e[0],
						b[1] * e[1],
						b[2] * e[2]
					];
				}
				let S = (e * n + d) * 4;
				l[S] = ji(b[0]), l[S + 1] = ji(b[1]), l[S + 2] = ji(b[2]), l[S + 3] = Math.round(x * 255), u[e * n + d] = 1;
			}
		}
		for (let e = 0; e < 4; e++) {
			let e = u.slice();
			for (let t = 0; t < n; t++) for (let r = 0; r < n; r++) if (!u[t * n + r]) for (let [i, a] of [
				[1, 0],
				[-1, 0],
				[0, 1],
				[0, -1]
			]) {
				let o = r + i, s = t + a;
				if (!(o < 0 || s < 0 || o >= n || s >= n || !u[s * n + o])) {
					l.copyWithin((t * n + r) * 4, (s * n + o) * 4, (s * n + o) * 4 + 4), e[t * n + r] = 1;
					break;
				}
			}
			u.set(e);
		}
		return l;
	});
}
function Ni(e, t) {
	let { asset: n } = e, r = [], i = n.parts.map((e, t) => {
		let i = n.materials[e.material];
		return r.push({
			...i,
			color: [
				1,
				1,
				1
			],
			texture: t,
			normalTexture: -1,
			roughnessTexture: -1,
			occlusionTexture: -1,
			emissiveTexture: -1,
			clearcoatTexture: -1,
			clearcoatRoughnessTexture: -1,
			clearcoatNormalTexture: -1,
			sheenColorTexture: -1,
			sheenRoughnessTexture: -1,
			transmissionTexture: -1
		}), {
			...e,
			colors: null,
			material: t
		};
	});
	return M(i, r, t);
}
//#endregion
//#region ../scene3d/src/model/texpaint.ts
var Pi = [
	"color",
	"rough",
	"metal",
	"glow",
	"bump",
	"coat",
	"holes"
], Fi = {
	color: "Colour",
	rough: "Roughness",
	metal: "Metal",
	glow: "Glow",
	bump: "Bumps",
	coat: "Clear coat",
	holes: "Holes"
}, Ii = {
	color: [
		!0,
		!0,
		!0,
		!1
	],
	rough: [
		!1,
		!0,
		!1,
		!1
	],
	metal: [
		!1,
		!1,
		!0,
		!1
	],
	glow: [
		!0,
		!0,
		!0,
		!1
	],
	bump: [
		!0,
		!0,
		!0,
		!1
	],
	coat: [
		!0,
		!1,
		!1,
		!1
	],
	holes: [
		!1,
		!1,
		!1,
		!0
	]
}, Li = (e) => 1e6 + e;
function Ri(e, t) {
	return t === "color" || t === "holes" ? e.texture : t === "rough" || t === "metal" ? e.roughnessTexture : t === "glow" ? e.emissiveTexture : t === "coat" ? e.clearcoatTexture : e.normalTexture;
}
var zi = [
	"pen",
	"erase",
	"soften"
], Bi = {
	pen: "Pen",
	erase: "Eraser",
	soften: "Soften"
};
function Vi(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e.parts) {
		let r = e.materials[n.material]?.texture ?? -1;
		n.uvs && r >= 0 && t.add(r);
	}
	return [...t];
}
var Hi = (e) => e.parts.some((e) => e.uvs && e.indices.length), Ui = (e) => Math.round(255 * Math.min(1, Math.max(0, e <= .0031308 ? e * 12.92 : 1.055 * e ** (1 / 2.4) - .055)));
function Wi(e, t, n) {
	let r = new Uint8ClampedArray(t * n * 4);
	for (let i = 0; i < n; i++) {
		let a = Math.min(e.height - 1, Math.max(0, (i + .5) * e.height / n - .5)), o = Math.floor(a), s = Math.min(e.height - 1, o + 1), c = a - o;
		for (let n = 0; n < t; n++) {
			let a = Math.min(e.width - 1, Math.max(0, (n + .5) * e.width / t - .5)), l = Math.floor(a), u = Math.min(e.width - 1, l + 1), d = a - l;
			for (let a = 0; a < 4; a++) {
				let f = e.data[(o * e.width + l) * 4 + a] * (1 - d) + e.data[(o * e.width + u) * 4 + a] * d, p = e.data[(s * e.width + l) * 4 + a] * (1 - d) + e.data[(s * e.width + u) * 4 + a] * d;
				r[(i * t + n) * 4 + a] = f * (1 - c) + p * c;
			}
		}
	}
	return {
		width: t,
		height: n,
		data: r
	};
}
function Gi(e, t, n) {
	let r = e.materials.map((e) => ({ ...e })), i = e.textures.slice(), a = new Map(t), o = /* @__PURE__ */ new Set(), s = !1;
	r.forEach((t, c) => {
		if (!e.parts.filter((e) => e.material === c && e.uvs).length) return;
		if (t.texture < 0) {
			let e = Math.max(64, n), l = new Uint8ClampedArray(e * e * 4), u = t.color.map(Ui);
			for (let e = 0; e < l.length; e += 4) l.set([
				u[0],
				u[1],
				u[2],
				255
			], e);
			let d = i.push({
				mime: "image/png",
				bytes: /* @__PURE__ */ new Uint8Array()
			}) - 1;
			a.set(d, {
				width: e,
				height: e,
				data: l
			}), r[c] = {
				...t,
				texture: d,
				color: [
					1,
					1,
					1
				]
			}, o.add(d), s = !0;
			return;
		}
		let l = t.color, u = r.filter((e) => e.texture === t.texture), d = u.every((e) => e.color.every((e, t) => Math.abs(e - l[t]) < .001)), f = a.get(t.texture);
		if (!f || !d || l.every((e) => Math.abs(e - 1) < .001)) return;
		let p = l.map((e) => Ui(e) / 255), m = new Uint8ClampedArray(f.data);
		for (let e = 0; e < m.length; e += 4) for (let t = 0; t < 3; t++) m[e + t] = m[e + t] * p[t];
		a.set(t.texture, {
			...f,
			data: m
		});
		for (let e of u) r[r.indexOf(e)] = {
			...e,
			color: [
				1,
				1,
				1
			]
		};
		o.add(t.texture), s = !0;
	});
	let c = [];
	for (let [e, t] of a) {
		let r = Math.max(t.width, t.height);
		if (r >= n) continue;
		let i = n / r;
		a.set(e, Wi(t, Math.round(t.width * i), Math.round(t.height * i))), o.has(e) || c.push(e);
	}
	return {
		asset: M(e.parts, r, i),
		pictures: a,
		changed: [...o],
		enlarged: c,
		remade: s
	};
}
function Ki(e, t, n = "color", r) {
	let i = [];
	e.parts.forEach((r, a) => {
		let o = e.materials[r.material] ? Ri(e.materials[r.material], n) : -1, s = n === "bump" && o >= 0 ? Li(o) : o;
		if (!(!r.uvs || s < 0 || !t.has(s))) for (let e = 0; e < r.indices.length; e += 3) i.push({
			part: a,
			a: r.indices[e],
			b: r.indices[e + 1],
			c: r.indices[e + 2],
			picture: s
		});
	});
	let a = [...e.min], o = Math.max(...e.max.map((e, t) => e - a[t]), 1e-6), s = o / 48, c = [
		0,
		1,
		2
	].map((t) => Math.max(1, Math.ceil((e.max[t] - a[t]) / s) + 1)), l = /* @__PURE__ */ new Map(), u = (e, t) => Math.max(0, Math.min(c[t] - 1, Math.floor((e - a[t]) / s)));
	i.forEach((t, n) => {
		let r = e.parts[t.part].positions, i = [
			0,
			1,
			2
		].map((e) => Math.min(r[t.a * 3 + e], r[t.b * 3 + e], r[t.c * 3 + e])), a = [
			0,
			1,
			2
		].map((e) => Math.max(r[t.a * 3 + e], r[t.b * 3 + e], r[t.c * 3 + e]));
		for (let e = u(i[0], 0); e <= u(a[0], 0); e++) for (let t = u(i[1], 1); t <= u(a[1], 1); t++) for (let r = u(i[2], 2); r <= u(a[2], 2); r++) {
			let i = (e * c[1] + t) * c[2] + r, a = l.get(i);
			a ? a.push(n) : l.set(i, [n]);
		}
	});
	let d = /* @__PURE__ */ new Set(), f = /* @__PURE__ */ new Map();
	for (let t of i) {
		if (d.has(t.picture)) continue;
		let n = e.parts[t.part], r = [
			t.a,
			t.b,
			t.c
		].reduce((e, t) => [e[0] + n.uvs[t * 2] / 3, e[1] + n.uvs[t * 2 + 1] / 3], [0, 0]), i = [
			0,
			1,
			2
		].map((e) => (n.positions[t.a * 3 + e] + n.positions[t.b * 3 + e] + n.positions[t.c * 3 + e]) / 3), a = `${t.picture}:${Math.floor((r[0] - Math.floor(r[0])) * 128)},${Math.floor((r[1] - Math.floor(r[1])) * 128)}`, s = f.get(a);
		s ? Math.hypot(i[0] - s[0], i[1] - s[1], i[2] - s[2]) > o * .03 && d.add(t.picture) : f.set(a, i);
	}
	return {
		asset: e,
		pictures: t,
		repeats: d,
		originals: new Map([...t].map(([e, t]) => [e, r?.get(e) ?? new Uint8ClampedArray(t.data)])),
		tris: i,
		grid: l,
		cell: s,
		min: a,
		dims: c
	};
}
function qi(e, t, n) {
	let r = /* @__PURE__ */ new Set(), i = t.map((t, r) => Math.max(0, Math.floor((t - n - e.min[r]) / e.cell))), a = t.map((t, r) => Math.min(e.dims[r] - 1, Math.floor((t + n - e.min[r]) / e.cell)));
	for (let t = i[0]; t <= a[0]; t++) for (let n = i[1]; n <= a[1]; n++) for (let o = i[2]; o <= a[2]; o++) for (let i of e.grid.get((t * e.dims[1] + n) * e.dims[2] + o) ?? []) r.add(i);
	return [...r];
}
var Ji = () => ({
	start: /* @__PURE__ */ new Map(),
	cover: /* @__PURE__ */ new Map(),
	box: /* @__PURE__ */ new Map()
});
function Yi(e, t, n) {
	let r = /* @__PURE__ */ new Set(), { at: i, radius: a } = n, o = Math.min(.99, Math.max(0, n.hardness)), s = n.tool === "pen" ? n.image : void 0, c = s ? [
		s.u[1] * s.v[2] - s.u[2] * s.v[1],
		s.u[2] * s.v[0] - s.u[0] * s.v[2],
		s.u[0] * s.v[1] - s.u[1] * s.v[0]
	] : null;
	for (let l of qi(e, i, a)) {
		let u = e.tris[l];
		if (n.part !== void 0 && u.part !== n.part) continue;
		let d = e.asset.parts[u.part], f = d.positions, p = d.uvs, m = [
			u.a,
			u.b,
			u.c
		].map((e) => [
			f[e * 3],
			f[e * 3 + 1],
			f[e * 3 + 2]
		]);
		if (n.facing && !e.asset.materials[d.material]?.doubleSided) {
			let e = [
				0,
				1,
				2
			].map((e) => m[1][e] - m[0][e]), t = [
				0,
				1,
				2
			].map((e) => m[2][e] - m[0][e]), r = [
				e[1] * t[2] - e[2] * t[1],
				e[2] * t[0] - e[0] * t[2],
				e[0] * t[1] - e[1] * t[0]
			];
			if (r[0] * n.facing[0] + r[1] * n.facing[1] + r[2] * n.facing[2] > 0) continue;
		}
		let h = !1;
		for (let e = 0; e < 3 && !h; e++) {
			let t = Math.min(m[0][e], m[1][e], m[2][e]), n = Math.max(m[0][e], m[1][e], m[2][e]);
			h = i[e] < t - a || i[e] > n + a;
		}
		if (h) continue;
		let g = e.pictures.get(u.picture), { width: _, height: v } = g, y = [
			u.a,
			u.b,
			u.c
		].map((e) => [p[e * 2], p[e * 2 + 1]]), b = [Math.floor(Math.min(y[0][0], y[1][0], y[2][0])), Math.floor(Math.min(y[0][1], y[1][1], y[2][1]))], x = y.map(([e, t]) => [(e - b[0]) * _ - .5, (t - b[1]) * v - .5]), S = (x[1][0] - x[0][0]) * (x[2][1] - x[0][1]) - (x[2][0] - x[0][0]) * (x[1][1] - x[0][1]);
		if (Math.abs(S) < 1e-9) continue;
		let C = (e, t) => Math.hypot(x[t][0] - x[e][0], x[t][1] - x[e][1]), w = [
			C(1, 2),
			C(2, 0),
			C(0, 1)
		].map((e) => e / Math.abs(S) * .75), T = Qi(i, m[0], m[1], m[2]), E = [0, 1].map((e) => T[0] * x[0][e] + T[1] * x[1][e] + T[2] * x[2][e]), D = a * Math.max(...[
			[0, 1],
			[1, 2],
			[2, 0]
		].map(([e, t]) => C(e, t) / Math.max(1e-9, Math.hypot(...[
			0,
			1,
			2
		].map((n) => m[t][n] - m[e][n]))))) * 1.5 + 2, O = Math.max(0, Math.floor(Math.max(Math.min(x[0][0], x[1][0], x[2][0]), E[0] - D)) - 1), k = Math.min(_ - 1, Math.ceil(Math.min(Math.max(x[0][0], x[1][0], x[2][0]), E[0] + D)) + 1), A = Math.max(0, Math.floor(Math.max(Math.min(x[0][1], x[1][1], x[2][1]), E[1] - D)) - 1), j = Math.min(v - 1, Math.ceil(Math.min(Math.max(x[0][1], x[1][1], x[2][1]), E[1] + D)) + 1), M = t.start.get(u.picture), ee = t.cover.get(u.picture);
		for (let l = A; l <= j; l++) for (let d = O; d <= k; d++) {
			let f = ((x[1][0] - d) * (x[2][1] - l) - (x[2][0] - d) * (x[1][1] - l)) / S, p = ((x[2][0] - d) * (x[0][1] - l) - (x[0][0] - d) * (x[2][1] - l)) / S, h = 1 - f - p;
			if (f < -w[0] || p < -w[1] || h < -w[2]) continue;
			let y = Math.max(0, f), b = Math.max(0, p), C = Math.max(0, h), T = y + b + C || 1, E = (y * m[0][0] + b * m[1][0] + C * m[2][0]) / T - i[0], D = (y * m[0][1] + b * m[1][1] + C * m[2][1]) / T - i[1], O = (y * m[0][2] + b * m[1][2] + C * m[2][2]) / T - i[2], k = Math.hypot(E, D, O);
			if (k >= a) continue;
			let A, j = null;
			if (s && c) {
				if (Math.abs(E * c[0] + D * c[1] + O * c[2]) > s.half) continue;
				let e = (E * s.u[0] + D * s.u[1] + O * s.u[2]) / s.half, t = (E * s.v[0] + D * s.v[1] + O * s.v[2]) / s.half;
				if (e < -1 || e > 1 || t < -1 || t > 1) continue;
				let r = (e + 1) / 2 * (s.width - 1), i = (1 - t) / 2 * (s.height - 1), a = Math.floor(r), o = Math.floor(i), l = r - a, u = i - o, d = Math.min(s.width - 1, a + 1), f = Math.min(s.height - 1, o + 1), p = (e, t, n) => s.data[(t * s.width + e) * 4 + n], m = (e) => (p(a, o, e) * (1 - l) + p(d, o, e) * l) * (1 - u) + (p(a, f, e) * (1 - l) + p(d, f, e) * l) * u, h = m(3);
				if (h < 3) continue;
				j = [
					m(0),
					m(1),
					m(2)
				], A = Math.min(1, h / 255 * n.opacity);
			} else {
				let e = k / a, t = e <= o ? 1 : 1 - (e - o) / (1 - o);
				A = Math.min(1, t * t * (3 - 2 * t) * n.opacity);
			}
			M || (t.start.set(u.picture, M = new Uint8ClampedArray(g.data)), t.cover.set(u.picture, ee = new Float32Array(_ * v)));
			let te = l * _ + d;
			if (A <= ee[te]) continue;
			ee[te] = A;
			let ne = te * 4, N;
			if (j) N = [
				j[0],
				j[1],
				j[2],
				n.alpha ?? M[ne + 3]
			];
			else if (n.tool === "pen") N = [
				n.color[0],
				n.color[1],
				n.color[2],
				n.alpha ?? M[ne + 3]
			];
			else if (n.tool === "erase") {
				let t = e.originals.get(u.picture);
				N = [
					t[ne],
					t[ne + 1],
					t[ne + 2],
					t[ne + 3]
				];
			} else {
				N = [
					0,
					0,
					0,
					0
				];
				let e = 0;
				for (let t = -2; t <= 2; t++) for (let n = -2; n <= 2; n++) {
					let r = Math.min(_ - 1, Math.max(0, d + n)), i = Math.min(v - 1, Math.max(0, l + t));
					for (let e = 0; e < 4; e++) N[e] += M[(i * _ + r) * 4 + e];
					e++;
				}
				N = N.map((t) => t / e);
			}
			let P = n.write ?? Ii.color;
			for (let e = 0; e < 4; e++) P[e] && (g.data[ne + e] = M[ne + e] + (N[e] - M[ne + e]) * A);
			let re = t.box.get(u.picture);
			re ? t.box.set(u.picture, [
				Math.min(re[0], d),
				Math.min(re[1], l),
				Math.max(re[2], d),
				Math.max(re[3], l)
			]) : t.box.set(u.picture, [
				d,
				l,
				d,
				l
			]), r.add(u.picture);
		}
	}
	return r;
}
function Xi(e, t) {
	let n = [];
	for (let [r, [i, a, o, s]] of t.box) {
		let c = e.pictures.get(r).width, l = o - i + 1, u = s - a + 1, d = t.start.get(r), f = new Uint8ClampedArray(l * u * 4);
		for (let e = 0; e < u; e++) f.set(d.subarray(((a + e) * c + i) * 4, ((a + e) * c + i + l) * 4), e * l * 4);
		n.push({
			picture: r,
			x: i,
			y: a,
			w: l,
			h: u,
			pixels: f
		});
	}
	return { pieces: n };
}
function Zi(e, t) {
	for (let { picture: n, x: r, y: i, w: a, h: o, pixels: s } of t.pieces) {
		let t = e.pictures.get(n);
		for (let e = 0; e < o; e++) t.data.set(s.subarray(e * a * 4, (e + 1) * a * 4), ((i + e) * t.width + r) * 4);
	}
	return new Set(t.pieces.map((e) => e.picture));
}
function Qi(e, t, n, r) {
	let i = [
		0,
		1,
		2
	].map((e) => n[e] - t[e]), a = [
		0,
		1,
		2
	].map((e) => r[e] - t[e]), o = [
		0,
		1,
		2
	].map((n) => e[n] - t[n]), s = (e, t) => e[0] * t[0] + e[1] * t[1] + e[2] * t[2], c = s(i, i), l = s(i, a), u = s(a, a), d = s(o, i), f = s(o, a), p = c * u - l * l || 1e-12, m = (u * d - l * f) / p, h = (c * f - l * d) / p;
	return [
		1 - m - h,
		m,
		h
	];
}
function $i(e, t, n, r) {
	let i = (e, t) => [
		e[0] - t[0],
		e[1] - t[1],
		e[2] - t[2]
	], a = (e, t) => e[0] * t[0] + e[1] * t[1] + e[2] * t[2], o = i(n, t), s = i(r, t), c = i(e, t), l = a(o, c), u = a(s, c);
	if (l <= 0 && u <= 0) return [
		1,
		0,
		0
	];
	let d = i(e, n), f = a(o, d), p = a(s, d);
	if (f >= 0 && p <= f) return [
		0,
		1,
		0
	];
	let m = l * p - f * u;
	if (m <= 0 && l >= 0 && f <= 0) {
		let e = l / (l - f);
		return [
			1 - e,
			e,
			0
		];
	}
	let h = i(e, r), g = a(o, h), _ = a(s, h);
	if (_ >= 0 && g <= _) return [
		0,
		0,
		1
	];
	let v = g * u - l * _;
	if (v <= 0 && u >= 0 && _ <= 0) {
		let e = u / (u - _);
		return [
			1 - e,
			0,
			e
		];
	}
	let y = f * _ - g * p;
	if (y <= 0 && p - f >= 0 && g - _ >= 0) {
		let e = (p - f) / (p - f + (g - _));
		return [
			0,
			1 - e,
			e
		];
	}
	let b = 1 / (y + v + m), x = v * b, S = m * b;
	return [
		1 - x - S,
		x,
		S
	];
}
function ea(e, t, n) {
	let r = null;
	for (let i of qi(e, t, n)) {
		let a = e.tris[i], o = e.asset.parts[a.part], s = o.positions, c = o.uvs, l = [
			a.a,
			a.b,
			a.c
		].map((e) => [
			s[e * 3],
			s[e * 3 + 1],
			s[e * 3 + 2]
		]), u = $i(t, l[0], l[1], l[2]), d = [
			0,
			1,
			2
		].map((e) => u[0] * l[0][e] + u[1] * l[1][e] + u[2] * l[2][e]), f = Math.hypot(d[0] - t[0], d[1] - t[1], d[2] - t[2]);
		if (f > n || r && f >= r.d) continue;
		let p = u[0] * c[a.a * 2] + u[1] * c[a.b * 2] + u[2] * c[a.c * 2], m = u[0] * c[a.a * 2 + 1] + u[1] * c[a.b * 2 + 1] + u[2] * c[a.c * 2 + 1], h = e.pictures.get(a.picture), g = Math.min(h.width - 1, Math.max(0, Math.floor((p - Math.floor(p)) * h.width))), _ = (Math.min(h.height - 1, Math.max(0, Math.floor((m - Math.floor(m)) * h.height))) * h.width + g) * 4;
		r = {
			d: f,
			part: a.part,
			color: [
				h.data[_],
				h.data[_ + 1],
				h.data[_ + 2]
			]
		};
	}
	return r && {
		part: r.part,
		color: r.color
	};
}
function ta(e, t, n) {
	for (let [r, [i, a, o, s]] of n.box) {
		let c = e.pictures.get(r), l = n.cover.get(r), u = t.get(r);
		u || t.set(r, u = new Uint8Array(c.width * c.height));
		for (let e = a; e <= s; e++) for (let t = i; t <= o; t++) {
			let n = e * c.width + t;
			l[n] > .02 && (u[n] = 1);
		}
	}
}
function na(e, t, n, r = 256) {
	let i = t, a = n, o = -1, s = -1;
	for (let r = 0; r < n; r++) for (let n = 0; n < t; n++) e[r * t + n] && (n < i && (i = n), n > o && (o = n), r < a && (a = r), r > s && (s = r));
	if (o < 0) return null;
	let c = Math.min(Math.max(t, n), Math.max(r, Math.round(Math.max(o - i + 1, s - a + 1) * 1.5))), l = (i + o + 1) / 2, u = (a + s + 1) / 2;
	return [
		Math.max(0, Math.min(t - Math.min(c, t), Math.round(l - c / 2))),
		Math.max(0, Math.min(n - Math.min(c, n), Math.round(u - c / 2))),
		Math.min(c, t, n)
	];
}
function ra(e, t, n, r) {
	let [i, a, o] = n, s = r * 2, c = new Float32Array(o * o).fill(1e9);
	for (let n = 0; n < o; n++) for (let r = 0; r < o; r++) e[(a + n) * t + i + r] && (c[n * o + r] = 0);
	for (let e = 0; e < o; e++) for (let t = 0; t < o; t++) {
		let n = c[e * o + t];
		t > 0 && (n = Math.min(n, c[e * o + t - 1] + 1)), e > 0 && (n = Math.min(n, c[(e - 1) * o + t] + 1)), t > 0 && e > 0 && (n = Math.min(n, c[(e - 1) * o + t - 1] + 1.414)), t < o - 1 && e > 0 && (n = Math.min(n, c[(e - 1) * o + t + 1] + 1.414)), c[e * o + t] = n;
	}
	for (let e = o - 1; e >= 0; e--) for (let t = o - 1; t >= 0; t--) {
		let n = c[e * o + t];
		t < o - 1 && (n = Math.min(n, c[e * o + t + 1] + 1)), e < o - 1 && (n = Math.min(n, c[(e + 1) * o + t] + 1)), t < o - 1 && e < o - 1 && (n = Math.min(n, c[(e + 1) * o + t + 1] + 1.414)), t > 0 && e < o - 1 && (n = Math.min(n, c[(e + 1) * o + t - 1] + 1.414)), c[e * o + t] = n;
	}
	let l = new Uint8Array(o * o);
	for (let e = 0; e < l.length; e++) {
		let t = c[e];
		l[e] = t <= r ? 255 : t >= s ? 0 : Math.round(255 * (1 - (t - r) / (s - r)));
	}
	return l;
}
function ia(e, t, n, r, i) {
	let a = e.pictures.get(t), [o, s, c] = n, l = new Uint8ClampedArray(c * c * 4);
	for (let e = 0; e < c; e++) l.set(a.data.subarray(((s + e) * a.width + o) * 4, ((s + e) * a.width + o + c) * 4), e * c * 4);
	for (let e = 0; e < c; e++) for (let t = 0; t < c; t++) {
		let n = i[e * c + t] / 255;
		if (!n) continue;
		let l = ((s + e) * a.width + o + t) * 4, u = (e * c + t) * 4;
		for (let e = 0; e < 3; e++) a.data[l + e] = a.data[l + e] + (r[u + e] - a.data[l + e]) * n;
	}
	return { pieces: [{
		picture: t,
		x: o,
		y: s,
		w: c,
		h: c,
		pixels: l
	}] };
}
var aa = (e, t, n) => {
	let r = new Uint8ClampedArray(e * t * 4);
	for (let e = 0; e < r.length; e += 4) r.set(n, e);
	return {
		width: e,
		height: t,
		data: r
	};
};
function oa(e, t, n) {
	let r = e.materials.map((e) => ({ ...e })), i = e.textures.slice(), a = new Map(t), o = [];
	r.forEach((t, s) => {
		if (!e.parts.some((e) => e.material === s && e.uvs) || t.texture < 0) return;
		let c = a.get(t.texture);
		if (!c) return;
		let l = (e) => {
			let t = i.push({
				mime: "image/png",
				bytes: /* @__PURE__ */ new Uint8Array()
			}) - 1;
			return a.set(t, aa(c.width, c.height, e)), o.push(t), t;
		};
		if ((n === "rough" || n === "metal") && t.roughnessTexture < 0) r[s] = {
			...t,
			roughnessTexture: l([
				255,
				Math.round(t.roughness * 255),
				Math.round(t.metalness * 255),
				255
			]),
			roughness: 1,
			metalness: 1
		};
		else if (n === "glow" && t.emissiveTexture < 0) {
			let e = Math.max(...t.emissive);
			r[s] = {
				...t,
				emissiveTexture: l([
					0,
					0,
					0,
					255
				]),
				emissive: e > 0 ? t.emissive : [
					1,
					1,
					1
				]
			};
		} else n === "coat" && t.clearcoatTexture < 0 ? r[s] = {
			...t,
			clearcoatTexture: l([
				0,
				0,
				0,
				255
			]),
			clearcoat: 1,
			clearcoatRoughness: t.clearcoat ? t.clearcoatRoughness : .05
		} : n === "glow" && Math.max(...t.emissive) <= 0 ? r[s] = {
			...t,
			emissive: [
				1,
				1,
				1
			]
		} : n === "coat" && t.clearcoat <= 0 ? r[s] = {
			...t,
			clearcoat: 1,
			clearcoatRoughness: .05
		} : n === "bump" && t.normalTexture < 0 ? r[s] = {
			...t,
			normalTexture: l([
				128,
				128,
				255,
				255
			]),
			normalScale: 1
		} : n === "holes" && !t.cutout && (r[s] = {
			...t,
			cutout: !0
		});
	});
	let s = o.length > 0 || r.some((t, n) => {
		let r = e.materials[n];
		return t.cutout !== r.cutout || t.clearcoat !== r.clearcoat || t.emissive.some((e, t) => e !== r.emissive[t]);
	});
	if (n === "bump") for (let e of r) {
		let t = a.get(e.normalTexture);
		t && !a.has(Li(e.normalTexture)) && a.set(Li(e.normalTexture), aa(t.width, t.height, [
			128,
			128,
			128,
			255
		]));
	}
	return {
		asset: s ? M(e.parts, r, i) : e,
		pictures: a,
		changed: o,
		remade: s
	};
}
function sa(e, t, n, r, i = [
	0,
	0,
	e.width - 1,
	e.height - 1
]) {
	let { width: a, height: o } = e, s = (t, n) => e.data[(Math.min(o - 1, Math.max(0, n)) * a + Math.min(a - 1, Math.max(0, t))) * 4] / 255;
	for (let e = Math.max(0, i[1] - 1); e <= Math.min(o - 1, i[3] + 1); e++) for (let o = Math.max(0, i[0] - 1); o <= Math.min(a - 1, i[2] + 1); o++) {
		let i = (e * a + o) * 4, c = (s(o + 1, e) - s(o - 1, e)) * r, l = (s(o, e + 1) - s(o, e - 1)) * r, u = t[i] / 127.5 - 1, d = t[i + 1] / 127.5 - 1, f = t[i + 2] / 127.5 - 1, p = u - c, m = d + l, h = Math.max(.05, f), g = Math.hypot(p, m, h) || 1;
		n.data[i] = (p / g + 1) * 127.5, n.data[i + 1] = (m / g + 1) * 127.5, n.data[i + 2] = (h / g + 1) * 127.5;
	}
}
//#endregion
//#region ../scene3d/src/model/matedit.ts
var ca = [
	"physical",
	"toon",
	"flat",
	"clay",
	"unlit"
], la = {
	physical: "Physical",
	toon: "Toon",
	flat: "Flat",
	clay: "Clay",
	unlit: "Unlit"
};
function ua(e) {
	return e.unlit ? "unlit" : e.look && e.look !== "soft" ? e.look : "physical";
}
function da(e, t) {
	let { look: n, bands: r, unlit: i, ...a } = e;
	return t === "unlit" ? {
		...a,
		unlit: !0
	} : t === "physical" ? {
		...a,
		look: "soft"
	} : {
		...a,
		look: t,
		...t === "toon" && e.bands ? { bands: e.bands } : {}
	};
}
var fa = (e) => {
	let t = parseInt(e.slice(1), 16);
	return [
		16,
		8,
		0
	].map((e) => {
		let n = (t >> e & 255) / 255;
		return n <= .04045 ? n / 12.92 : ((n + .055) / 1.055) ** 2.4;
	});
}, pa = (e) => ({
	...da(e, "physical"),
	clearcoat: 0,
	clearcoatRoughness: 0,
	sheenColor: [
		0,
		0,
		0
	],
	sheenRoughness: 0,
	transmission: 0,
	ior: 1.5,
	emissive: e.emissiveTexture >= 0 ? e.emissive : [
		0,
		0,
		0
	]
}), ma = [
	{
		id: "matte",
		label: "Matte",
		make: (e) => ({
			...pa(e),
			roughness: .9,
			metalness: 0
		})
	},
	{
		id: "plastic",
		label: "Glossy plastic",
		make: (e) => ({
			...pa(e),
			roughness: .25,
			metalness: 0,
			clearcoat: .4
		})
	},
	{
		id: "rubber",
		label: "Rubber",
		make: (e) => ({
			...pa(e),
			roughness: .75,
			metalness: 0,
			sheenColor: [
				.04,
				.04,
				.04
			],
			sheenRoughness: .8
		})
	},
	{
		id: "metal",
		label: "Brushed metal",
		make: (e) => ({
			...pa(e),
			roughness: .4,
			metalness: 1
		})
	},
	{
		id: "chrome",
		label: "Chrome",
		make: (e) => ({
			...pa(e),
			color: fa("#e8e8ec"),
			roughness: .05,
			metalness: 1
		})
	},
	{
		id: "gold",
		label: "Gold",
		make: (e) => ({
			...pa(e),
			color: fa("#ffd27a"),
			roughness: .2,
			metalness: 1
		})
	},
	{
		id: "carpaint",
		label: "Car paint",
		make: (e) => ({
			...pa(e),
			roughness: .45,
			metalness: .6,
			clearcoat: 1,
			clearcoatRoughness: .03
		})
	},
	{
		id: "velvet",
		label: "Velvet",
		make: (e) => ({
			...pa(e),
			roughness: .95,
			metalness: 0,
			sheenColor: [
				.6,
				.6,
				.6
			],
			sheenRoughness: .4
		})
	},
	{
		id: "satin",
		label: "Satin",
		make: (e) => ({
			...pa(e),
			roughness: .35,
			metalness: 0,
			sheenColor: [
				.35,
				.35,
				.35
			],
			sheenRoughness: .25
		})
	},
	{
		id: "skin",
		label: "Skin",
		make: (e) => ({
			...pa(e),
			roughness: .55,
			metalness: 0,
			sheenColor: [
				.25,
				.12,
				.1
			],
			sheenRoughness: .6
		})
	},
	{
		id: "glass",
		label: "Glass",
		make: (e) => ({
			...pa(e),
			roughness: .02,
			metalness: 0,
			transmission: 1,
			ior: 1.5
		})
	},
	{
		id: "gem",
		label: "Gem",
		make: (e) => ({
			...pa(e),
			roughness: .01,
			metalness: 0,
			transmission: .9,
			ior: 2.4,
			clearcoat: 1
		})
	},
	{
		id: "neon",
		label: "Neon glow",
		make: (e) => ({
			...pa(e),
			roughness: .4,
			emissive: e.color.map((e) => e * 4)
		})
	},
	{
		id: "anime",
		label: "Anime (toon)",
		make: (e) => ({
			...da(e, "toon"),
			bands: 2
		})
	}
];
function ha(e, t) {
	let n = Infinity, r = -1;
	for (let i of e.parts) {
		let e = i.positions;
		for (let a = 0; a < i.indices.length; a += 3) {
			let o = 0;
			for (let n = 0; n < 3; n++) {
				let r = (e[i.indices[a] * 3 + n] + e[i.indices[a + 1] * 3 + n] + e[i.indices[a + 2] * 3 + n]) / 3;
				o += (r - t[n]) ** 2;
			}
			o < n && (n = o, r = i.material);
		}
	}
	return r;
}
function ga(e) {
	let t = e >>> 0;
	return () => {
		t = t + 1831565813 >>> 0;
		let e = Math.imul(t ^ t >>> 15, 1 | t);
		return e = e + Math.imul(e ^ e >>> 7, 61 | e) ^ e, ((e ^ e >>> 14) >>> 0) / 4294967296;
	};
}
var _a = (e) => {
	let t = Math.hypot(...e) || 1;
	return [
		e[0] / t,
		e[1] / t,
		e[2] / t
	];
}, va = (e, t) => [
	e[1] * t[2] - e[2] * t[1],
	e[2] * t[0] - e[0] * t[2],
	e[0] * t[1] - e[1] * t[0]
];
function ya(e, t) {
	let n = ga(t.seed ?? 7), r = Math.max(...e.max.map((t, n) => t - e.min[n])) * Math.min(.6, Math.max(.01, t.length)), i = r * Math.min(.1, Math.max(.005, t.thickness ?? .02)), a = Math.round(Math.min(5e3, Math.max(10, t.count))), o = e.min.map((t, n) => (t + e.max[n]) / 2), s = [];
	for (let n of e.parts) {
		let e = n.positions;
		for (let r = 0; r < n.indices.length; r += 3) {
			let [i, a, o] = [
				0,
				1,
				2
			].map((t) => {
				let i = n.indices[r + t] * 3;
				return [
					e[i],
					e[i + 1],
					e[i + 2]
				];
			}), c = va([
				a[0] - i[0],
				a[1] - i[1],
				a[2] - i[2]
			], [
				o[0] - i[0],
				o[1] - i[1],
				o[2] - i[2]
			]), l = Math.hypot(...c) / 2, u = _a(c);
			l > 0 && (t.where !== "top" || u[1] > .3) && s.push({
				a: i,
				b: a,
				c: o,
				n: u,
				area: l
			});
		}
	}
	if (!s.length) throw Error("There is no surface for hair to grow on (try Everywhere).");
	let c = [], l = 0;
	for (let e of s) c.push(l += e.area);
	let u = new Float32Array(a * 7 * 3 * 3), d = new Uint32Array(a * 6 * 6 * 3), f = 0, p = 0;
	for (let e = 0; e < a; e++) {
		let e = n() * l, a = 0, m = c.length - 1;
		for (; a < m;) {
			let t = a + m >> 1;
			c[t] < e ? a = t + 1 : m = t;
		}
		let h = s[a], g = n(), _ = n();
		g + _ > 1 && ([g, _] = [1 - g, 1 - _]);
		let v = [
			0,
			1,
			2
		].map((e) => h.a[e] + (h.b[e] - h.a[e]) * g + (h.c[e] - h.a[e]) * _), y = h.n, b = _a(va(y, Math.abs(y[1]) < .9 ? [
			0,
			1,
			0
		] : [
			1,
			0,
			0
		])), x = [
			v[0] - o[0],
			0,
			v[2] - o[2]
		], S = Math.hypot(...x) > 1e-6 ? _a(x) : b, C = n() * Math.PI * 2, w = r / 6, T = f / 3;
		for (let e = 0; e <= 6; e++) {
			if (e > 0) {
				y = _a([
					y[0] + S[0] * t.droop * .25,
					y[1] - t.droop * .45,
					y[2] + S[2] * t.droop * .25
				]);
				let n = t.curl * .9, r = _a(va(y, b)), i = va(y, r), a = C + e * 1.3, o = [
					0,
					1,
					2
				].map((e) => y[e] * w + (r[e] * Math.cos(a) + i[e] * Math.sin(a)) * w * n);
				v = [
					v[0] + o[0],
					v[1] + o[1],
					v[2] + o[2]
				];
			}
			let n = i * (1 - e / 6 * .9), r = _a(va(y, b)), a = va(y, r);
			for (let e = 0; e < 3; e++) {
				let t = e * 2 * Math.PI / 3;
				for (let e = 0; e < 3; e++) u[f++] = v[e] + (r[e] * Math.cos(t) + a[e] * Math.sin(t)) * n;
			}
		}
		for (let e = 0; e < 6; e++) for (let t = 0; t < 3; t++) {
			let n = T + e * 3 + t, r = T + e * 3 + (t + 1) % 3;
			d.set([
				n,
				r,
				r + 3,
				n,
				r + 3,
				n + 3
			], p), p += 6;
		}
	}
	let m = e.materials.length, h = t.color ?? [
		.12,
		.07,
		.04
	];
	return M([...e.parts, {
		positions: u,
		normals: A(u, d),
		uvs: null,
		colors: null,
		indices: d,
		material: m
	}], [...e.materials, {
		...D(),
		color: h,
		roughness: .45,
		sheenColor: h.map((e) => e * .6 + .15),
		sheenRoughness: .4,
		doubleSided: !0
	}], e.textures);
}
//#endregion
//#region ../scene3d/src/model/romancesample.ts
var ba = (e, t, n, r = {}) => ({
	who: e,
	text: t,
	textJa: n,
	...r
}), xa = (e, t, n = {}) => ba("", e, t, n), Sa = (e, t) => ba("me", e, t);
function Ca() {
	return On({
		start: "prologue",
		heroines: [
			{
				id: "hana",
				name: "Hana Aoyama",
				nameJa: "青山 花",
				age: 23,
				colour: "#e58fae",
				profile: "A photographer who shoots figures for shops. Shy until the camera is in her hands.",
				profileJa: "ショップのフィギュアを撮るカメラマン。カメラを持つまでは人見知り。",
				faces: {},
				routeAt: 6
			},
			{
				id: "rei",
				name: "Rei Kirishima",
				nameJa: "霧島 玲",
				age: 25,
				colour: "#7fa7d9",
				profile: "A sculptor who paints garage kits by hand. Blunt, exact, secretly soft.",
				profileJa: "ガレージキットを手で塗る原型師。率直で几帳面、実は優しい。",
				faces: {},
				routeAt: 6
			},
			{
				id: "mio",
				name: "Mio Natsukawa",
				nameJa: "夏川 澪",
				age: 21,
				colour: "#f0b44c",
				profile: "A university student and cosplayer who sews every costume herself.",
				profileJa: "衣装を全部自分で縫う大学生コスプレイヤー。",
				faces: {},
				routeAt: 6
			},
			{
				id: "sayaka",
				name: "Sayaka Mori",
				nameJa: "森 沙耶香",
				age: 28,
				colour: "#9ccf8f",
				profile: "She runs the café next door and has opinions about your shop.",
				profileJa: "隣のカフェの店主。あなたの店に一言ある。",
				faces: {},
				routeAt: 6
			}
		],
		scenes: [
			{
				id: "prologue",
				title: "Prologue: the shop",
				lines: [
					xa("Grandpa's hobby shop sits at the end of a quiet shopping street: three shelves, one till, and a lot of dust.", "祖父のホビーショップは、静かな商店街の端にある。棚が三つ、レジがひとつ、そしてほこりがたくさん。"),
					xa("He left it to me. The letter says the rent is paid until the end of summer.", "店は僕に遺された。手紙によれば、家賃は夏の終わりまで払ってあるらしい。"),
					Sa("One summer to make this place worth keeping.", "この店を残す価値のある場所にするまで、ひと夏。")
				],
				next: {
					kind: "go",
					go: "day1"
				}
			},
			{
				id: "day1",
				title: "Day 1: visitors",
				stage: [{
					heroine: "hana",
					at: "left"
				}, {
					heroine: "sayaka",
					at: "right"
				}],
				lines: [
					ba("sayaka", "So you're the grandson. You look like you haven't slept.", "あなたがお孫さんね。寝てない顔してる。", { face: "smile" }),
					ba("hana", "I, um, used to photograph the figures here. Your grandfather's listings were mine.", "あの……ここのフィギュア、私が撮ってたんです。お祖父さんの出品写真。", { face: "shy" }),
					xa("The bell rings again. A woman with paint on her fingers and a girl carrying a sewing box come in arguing.", "またベルが鳴る。指に塗料をつけた女性と、裁縫箱を抱えた女の子が言い合いながら入ってきた。"),
					ba("rei", "This shelf is lit wrong. Nobody can see the sculpt.", "この棚、照明が悪い。造形が見えない。"),
					ba("mio", "And nobody can see the costumes either! Hi, I'm Mio. Can we do a shoot here?", "衣装も見えないよ！澪です。ここで撮影してもいい？"),
					Sa("Four people, one morning, and the shop's never been this loud.", "一朝で四人。店がこんなに賑やかなのは初めてだ。")
				],
				next: {
					kind: "choose",
					choices: [
						{
							text: "Ask Hana to reshoot the shelf.",
							textJa: "花に棚の撮り直しを頼む。",
							affection: { hana: 3 },
							set: ["photos"],
							go: "day2"
						},
						{
							text: "Ask Rei to fix the lighting.",
							textJa: "玲に照明を直してもらう。",
							affection: { rei: 3 },
							set: ["lights"],
							go: "day2"
						},
						{
							text: "Say yes to Mio’s shoot.",
							textJa: "澪の撮影をOKする。",
							affection: { mio: 3 },
							set: ["shoot"],
							go: "day2"
						},
						{
							text: "Go next door for coffee with Sayaka.",
							textJa: "沙耶香のカフェでコーヒーを飲む。",
							affection: { sayaka: 3 },
							go: "day2"
						}
					]
				}
			},
			{
				id: "day2",
				title: "Day 2: the first sale",
				lines: [xa("Someone buys a figure online, the first sale in a month. The photo did it, or the light, or the noise outside.", "ネットでフィギュアが一体売れた。一か月ぶりの売上だ。写真のおかげか、照明か、外の賑わいか。"), Sa("Whoever it was, I owe them dinner.", "誰のおかげでも、夕飯をおごらなきゃ。")],
				next: {
					kind: "choose",
					choices: [
						{
							text: "Invite Hana.",
							textJa: "花を誘う。",
							affection: { hana: 3 },
							go: "routes"
						},
						{
							text: "Invite Rei.",
							textJa: "玲を誘う。",
							affection: { rei: 3 },
							go: "routes"
						},
						{
							text: "Invite Mio.",
							textJa: "澪を誘う。",
							affection: { mio: 3 },
							go: "routes"
						},
						{
							text: "Invite Sayaka.",
							textJa: "沙耶香を誘う。",
							affection: { sayaka: 3 },
							go: "routes"
						},
						{
							text: "Eat alone and work late.",
							textJa: "一人で食べて残業する。",
							go: "routes"
						}
					]
				}
			},
			{
				id: "routes",
				title: "Whose summer",
				lines: [],
				next: {
					kind: "branch",
					ways: [
						{
							if: {
								kind: "route",
								heroine: "hana"
							},
							go: "hana1"
						},
						{
							if: {
								kind: "route",
								heroine: "rei"
							},
							go: "rei1"
						},
						{
							if: {
								kind: "route",
								heroine: "mio"
							},
							go: "mio1"
						},
						{
							if: {
								kind: "route",
								heroine: "sayaka"
							},
							go: "sayaka1"
						}
					],
					else: "alone"
				}
			},
			{
				id: "hana1",
				title: "Hana: the darkroom",
				stage: [{
					heroine: "hana",
					at: "centre"
				}],
				lines: [
					ba("hana", "Hold the reflector a little higher. There. See how the face lights up?", "レフ板、もう少し上に。そこ。顔が明るくなったでしょう？", { face: "smile" }),
					Sa("I'm looking at the wrong face.", "見てる顔が違うかも。"),
					ba("hana", "…Then hold it steady while you do.", "……じゃあ、そのまま持っていてください。", { face: "shy" })
				],
				next: {
					kind: "go",
					go: "hana2"
				}
			},
			{
				id: "hana2",
				title: "Hana: after closing",
				rating: "mature",
				stage: [{
					heroine: "hana",
					at: "centre"
				}],
				lines: [xa("The shutters come down. Neither of us reaches for the light switch.", "シャッターが下りる。どちらも電気のスイッチに手を伸ばさない。", { rating: "mature" }), ba("hana", "Stay. Just tonight, stay.", "行かないで。今夜だけは。", {
					face: "shy",
					rating: "mature"
				})],
				safe: [xa("We talk until the last train has gone.", "終電がなくなるまで、二人で話した。")],
				next: {
					kind: "end",
					ending: "hana-good"
				}
			},
			{
				id: "rei1",
				title: "Rei: primer and patience",
				stage: [{
					heroine: "rei",
					at: "centre"
				}],
				lines: [
					ba("rei", "You sand like you're apologising to it. Press harder.", "謝るみたいに削るのね。もっと強く。"),
					Sa("Like this?", "こう？"),
					ba("rei", "…Better. Your hands aren’t useless after all.", "……まあまあ。手は使えるみたい。", { face: "smile" })
				],
				next: {
					kind: "end",
					ending: "rei-good"
				}
			},
			{
				id: "mio1",
				title: "Mio: the convention",
				stage: [{
					heroine: "mio",
					at: "centre"
				}],
				lines: [
					ba("mio", "The shop’s name on my banner! Everyone asked where the props came from!", "私のバナーにお店の名前！小道具どこのって、みんなに聞かれた！", { face: "smile" }),
					Sa("You did all the work.", "全部君のおかげだよ。"),
					ba("mio", "Then next year, we do it together. Promise.", "じゃあ来年は一緒にやろう。約束ね。")
				],
				next: {
					kind: "end",
					ending: "mio-good"
				}
			},
			{
				id: "sayaka1",
				title: "Sayaka: closing time",
				stage: [{
					heroine: "sayaka",
					at: "centre"
				}],
				lines: [
					ba("sayaka", "You know the café door and your shop door are twelve steps apart. I counted.", "カフェのドアとあなたの店のドア、十二歩なの。数えた。", { face: "smile" }),
					Sa("Why count?", "なんで数えたの？"),
					ba("sayaka", "To know how long I have to think of an excuse.", "言い訳を考える時間を知りたくて。", { face: "shy" })
				],
				next: {
					kind: "end",
					ending: "sayaka-good"
				}
			},
			{
				id: "alone",
				title: "Alone with the shelves",
				lines: [xa("The summer ends with the shop still open, and a little quieter than it could have been.", "夏が終わっても店は続いている。もう少し賑やかにもなれたはずだけれど。")],
				next: {
					kind: "end",
					ending: "normal"
				}
			}
		],
		endings: [
			{
				id: "hana-good",
				title: "Developing",
				titleJa: "現像",
				heroine: "hana",
				kind: "good"
			},
			{
				id: "rei-good",
				title: "Primer Coat",
				titleJa: "下地",
				heroine: "rei",
				kind: "good"
			},
			{
				id: "mio-good",
				title: "Next Year’s Banner",
				titleJa: "来年のバナー",
				heroine: "mio",
				kind: "good"
			},
			{
				id: "sayaka-good",
				title: "Twelve Steps",
				titleJa: "十二歩",
				heroine: "sayaka",
				kind: "good"
			},
			{
				id: "normal",
				title: "The Shop Stays Open",
				titleJa: "店は続く",
				kind: "normal"
			}
		]
	});
}
//#endregion
//#region src/model3d/CopiesSection.tsx
var wa = [
	"none",
	"grid",
	"around"
], Ta = {
	none: "None",
	grid: "Grid",
	around: "Round the middle"
}, Ea = {
	x: "X",
	y: "Upright (Y)",
	z: "Z"
}, Da = (e, t) => t === "x" ? Math.hypot(e[1], e[2]) : t === "y" ? Math.hypot(e[0], e[2]) : Math.hypot(e[0], e[1]);
function Oa({ shape: e, update: t, gesture: n, end: r }) {
	let i = e.mirror ?? {}, a = e.repeat, s = Math.max(...e.size), c = (e) => {
		let n = {
			...i,
			[e]: !i[e] || void 0
		};
		t({ mirror: n.x || n.z ? n : void 0 }, e === "x" ? "Mirror left and right" : "Mirror front and back");
	}, l = (n) => {
		if (n === "none") return t({ repeat: void 0 }, "No copies");
		if (n === "grid") return t({ repeat: {
			kind: "grid",
			count: [
				3,
				1,
				1
			],
			spacing: e.size.map((e) => Math.round(e * 1.25 * 100) / 100)
		} }, "Copies in a grid");
		let r = { repeat: {
			kind: "around",
			count: 6,
			axis: "y",
			arc: 360
		} };
		Da(e.position, "y") < .05 && (r.position = [
			Math.round((s + .5) * 100) / 100,
			e.position[1],
			e.position[2]
		]), t(r, "Copies round the middle");
	}, u = (e) => t({ repeat: e }), d = (t) => Math.abs(e.position[t === "x" ? 0 : 2]) < .02;
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Mirror and repeat" }),
		/* @__PURE__ */ X("div", {
			className: "gs-m3d__row",
			role: "group",
			"aria-label": "Mirror",
			children: [/* @__PURE__ */ Y("button", {
				type: "button",
				className: `gs-m3d__btn ${i.x ? "is-on" : ""}`,
				"aria-pressed": !!i.x,
				title: "A twin on the other side of the middle, left and right",
				onClick: () => c("x"),
				children: "Mirror left ↔ right"
			}), /* @__PURE__ */ Y("button", {
				type: "button",
				className: `gs-m3d__btn ${i.z ? "is-on" : ""}`,
				"aria-pressed": !!i.z,
				title: "A twin on the other side of the middle, front and back",
				onClick: () => c("z"),
				children: "Mirror front ↔ back"
			})]
		}),
		(i.x && d("x") || i.z && d("z")) && /* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: "It sits on the middle, so its twin is inside it: move it to one side to see both."
		}),
		/* @__PURE__ */ Y(o, { id: "m3dMirror" }),
		/* @__PURE__ */ Y(W, {
			label: "Repeat",
			value: a?.kind ?? "none",
			options: wa,
			labels: Ta,
			onChange: l
		}),
		a?.kind === "grid" && /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ Y(Lr, {
			label: "Copies",
			value: a.count,
			step: 1,
			min: 1,
			onChange: (e) => u({
				...a,
				count: e.map((e) => Math.min(20, Math.max(1, Math.round(e))))
			})
		}), /* @__PURE__ */ Y(Lr, {
			label: "Spacing",
			value: a.spacing,
			step: .05,
			min: .01,
			onChange: (e) => u({
				...a,
				spacing: e
			})
		})] }),
		a?.kind === "around" && /* @__PURE__ */ X(J, { children: [
			/* @__PURE__ */ Y(U, {
				label: "Copies",
				value: a.count,
				min: 2,
				max: 64,
				step: 1,
				onBegin: n("Copies"),
				onChange: (e) => u({
					...a,
					count: e
				}),
				onEnd: r
			}),
			/* @__PURE__ */ Y(U, {
				label: "Over",
				value: a.arc,
				min: 10,
				max: 360,
				step: 5,
				format: (e) => e >= 360 ? "A whole ring" : `${Math.round(e)}°`,
				onBegin: n("Arc"),
				onChange: (e) => u({
					...a,
					arc: e
				}),
				onEnd: r
			}),
			/* @__PURE__ */ Y(W, {
				label: "Round",
				value: a.axis,
				options: Dt,
				labels: Ea,
				onChange: (e) => u({
					...a,
					axis: e
				})
			}),
			Da(e.position, a.axis) < .05 && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: "It sits on the axis, so its copies are all in one place: move it away from the middle."
			})
		] }),
		/* @__PURE__ */ Y(o, { id: "m3dRepeat" })
	] });
}
//#endregion
//#region src/model3d/FocusSection.tsx
function ka({ editor: e, camera: t, shape: n, gesture: r, end: i }) {
	let a = t.focus, s = Math.max(1, t.distance), c = (t, n) => e.setSetting("camera", "focus", t, n);
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Depth of field" }),
		/* @__PURE__ */ X("label", {
			className: "gs-m3d__check",
			children: [
				/* @__PURE__ */ Y("input", {
					type: "checkbox",
					checked: !!a,
					onChange: (e) => c(e.target.checked ? {
						blur: .35,
						offset: 0
					} : void 0, e.target.checked ? "Depth of field" : "No depth of field")
				}),
				" ",
				"Blur what is nearer and further"
			]
		}),
		a && /* @__PURE__ */ X(J, { children: [
			/* @__PURE__ */ Y(U, {
				label: "Blur",
				value: a.blur,
				min: .05,
				max: 1,
				step: .01,
				format: (e) => `${Math.round(e * 100)}%`,
				onBegin: r("Blur"),
				onChange: (e) => c({
					...a,
					blur: e
				}),
				onEnd: i
			}),
			/* @__PURE__ */ Y(U, {
				label: "Sharp at",
				value: a.offset,
				min: Math.round((.1 - s) * 100) / 100,
				max: Math.round(s * 100) / 100,
				step: .01,
				format: (e) => Math.abs(e) < .005 ? "The middle of the view" : e < 0 ? `${(-e).toFixed(2)} nearer` : `${e.toFixed(2)} further`,
				onBegin: r("Focus"),
				onChange: (e) => c({
					...a,
					offset: e
				}),
				onEnd: i
			}),
			n && /* @__PURE__ */ X("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => c({
					...a,
					offset: Un(t, n.position)
				}, "Focus on shape"),
				children: ["Sharp on ", n.name || "the picked shape"]
			})
		] }),
		/* @__PURE__ */ Y(o, { id: "m3dFocus" })
	] });
}
//#endregion
//#region src/model3d/MoreLights.tsx
var Aa = {
	sun: "Sun",
	point: "Point",
	spot: "Spot",
	area: "Panel"
}, ja = (e) => ((e + 180) % 360 + 360) % 360 - 180;
function Ma(e, t) {
	return t === 0 ? {
		azimuth: ja(e.azimuth + 180),
		elevation: 35,
		intensity: .9,
		color: "#dfe8ff",
		shadows: !1
	} : {
		azimuth: ja(e.azimuth + 90),
		elevation: 20,
		intensity: .5,
		color: "#ffe9d6",
		shadows: !1
	};
}
function Na({ editor: e, light: t, gesture: n, end: r }) {
	let i = t.extra ?? [], a = (t, n) => e.setSetting("light", "extra", t.length ? t : void 0, n), s = (e, t, n) => a(i.map((n, r) => r === e ? {
		...n,
		...t
	} : n), n);
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "More lights" }),
		i.map((e, t) => /* @__PURE__ */ X("div", {
			className: "gs-m3d__card",
			role: "group",
			"aria-label": `Light ${t + 2}`,
			children: [
				/* @__PURE__ */ X("div", {
					className: "gs-m3d__row",
					children: [/* @__PURE__ */ X("strong", { children: ["Light ", t + 2] }), /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => a(i.filter((e, n) => n !== t), "Remove light"),
						children: "Remove"
					})]
				}),
				/* @__PURE__ */ Y(U, {
					label: "Around",
					value: e.azimuth,
					min: -180,
					max: 180,
					step: 1,
					format: (e) => `${e}°`,
					onBegin: n("Light around"),
					onChange: (e) => s(t, { azimuth: e }),
					onEnd: r
				}),
				/* @__PURE__ */ Y(U, {
					label: "Height",
					value: e.elevation,
					min: 0,
					max: 90,
					step: 1,
					format: (e) => `${e}°`,
					onBegin: n("Light height"),
					onChange: (e) => s(t, { elevation: e }),
					onEnd: r
				}),
				/* @__PURE__ */ Y(U, {
					label: "Brightness",
					value: e.intensity,
					min: 0,
					max: 3,
					step: .05,
					onBegin: n("Brightness"),
					onChange: (e) => s(t, { intensity: e }),
					onEnd: r
				}),
				/* @__PURE__ */ Y(W, {
					label: "Kind",
					value: e.kind ?? "sun",
					options: tt,
					labels: Aa,
					onChange: (n) => s(t, n === "sun" ? { kind: void 0 } : {
						kind: n,
						distance: e.distance ?? 5,
						size: e.size ?? .8,
						cone: e.cone ?? 50
					}, "Light kind")
				}),
				e.kind && e.kind !== "sun" && /* @__PURE__ */ Y(U, {
					label: "Distance",
					value: e.distance ?? 5,
					min: 1,
					max: 20,
					step: .1,
					onBegin: n("Light distance"),
					onChange: (e) => s(t, { distance: e }),
					onEnd: r
				}),
				e.kind === "spot" && /* @__PURE__ */ Y(U, {
					label: "Cone",
					value: e.cone ?? 50,
					min: 5,
					max: 170,
					step: 1,
					format: (e) => `${e}°`,
					onBegin: n("Spot cone"),
					onChange: (e) => s(t, { cone: e }),
					onEnd: r
				}),
				e.kind === "area" && /* @__PURE__ */ Y(U, {
					label: "Panel size",
					value: e.size ?? .8,
					min: .05,
					max: 5,
					step: .05,
					onBegin: n("Panel size"),
					onChange: (e) => s(t, { size: e }),
					onEnd: r
				}),
				e.kind && e.kind !== "sun" && /* @__PURE__ */ Y("p", {
					className: "gs-m3d__note",
					children: "Placed and softened in the photo-real render; the view lights from its direction."
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__check",
					children: [/* @__PURE__ */ Y("input", {
						type: "checkbox",
						checked: e.shadows,
						onChange: (e) => s(t, { shadows: e.target.checked }, "Shadows")
					}), " Shadows"]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__colour",
					children: [/* @__PURE__ */ Y("input", {
						type: "color",
						value: e.color,
						onChange: (e) => s(t, { color: e.target.value }, "Light colour")
					}), " Light colour"]
				})
			]
		}, t)),
		i.length < 2 && /* @__PURE__ */ Y("button", {
			type: "button",
			className: "gs-m3d__btn",
			onClick: () => a([...i, Ma(t, i.length)], "Add light"),
			children: i.length ? "Add a fill light" : "Add a rim light"
		}),
		/* @__PURE__ */ Y(o, { id: "m3dLights" })
	] });
}
//#endregion
//#region src/model3d/fonts.ts
var Pa = [
	100,
	200,
	300,
	400,
	500,
	600,
	700,
	800,
	900
], Fa = (e, t) => Pa.filter((n) => n >= e && n <= t), Ia = [
	"Arial",
	"Helvetica",
	"Georgia",
	"Times New Roman",
	"Verdana",
	"Trebuchet MS",
	"Impact",
	"Courier New",
	"Comic Sans MS"
].map((e) => ({
	family: e,
	source: "standard",
	weights: [400, 700]
})), La = [
	[
		"Bebas Neue",
		[400],
		"tall headline"
	],
	[
		"Anton",
		[400],
		"bold headline"
	],
	[
		"Archivo Black",
		[400],
		"heavy"
	],
	[
		"Montserrat",
		Fa(100, 900),
		"clean"
	],
	[
		"Poppins",
		Fa(100, 900),
		"round, clean"
	],
	[
		"Oswald",
		Fa(200, 700),
		"narrow"
	],
	[
		"Rubik",
		Fa(300, 900),
		"soft corners"
	],
	[
		"Fredoka",
		Fa(300, 700),
		"round, friendly"
	],
	[
		"Baloo 2",
		Fa(400, 800),
		"chunky, friendly"
	],
	[
		"Lilita One",
		[400],
		"chunky"
	],
	[
		"Titan One",
		[400],
		"chunky"
	],
	[
		"Luckiest Guy",
		[400],
		"comic"
	],
	[
		"Bangers",
		[400],
		"comic"
	],
	[
		"Bungee",
		[400],
		"signs"
	],
	[
		"Russo One",
		[400],
		"sporty"
	],
	[
		"Black Ops One",
		[400],
		"stencil"
	],
	[
		"Righteous",
		[400],
		"retro"
	],
	[
		"Monoton",
		[400],
		"neon lines"
	],
	[
		"Press Start 2P",
		[400],
		"pixel"
	],
	[
		"Permanent Marker",
		[400],
		"marker"
	],
	[
		"Pacifico",
		[400],
		"script"
	],
	[
		"Lobster",
		[400],
		"script"
	],
	[
		"Dancing Script",
		Fa(400, 700),
		"script"
	],
	[
		"Great Vibes",
		[400],
		"elegant script"
	],
	[
		"Playfair Display",
		Fa(400, 900),
		"elegant"
	],
	[
		"Abril Fatface",
		[400],
		"fashion"
	],
	[
		"Shrikhand",
		[400],
		"bold italic"
	],
	[
		"Comfortaa",
		Fa(300, 700),
		"rounded"
	],
	[
		"Noto Sans JP",
		Fa(100, 900),
		"Japanese, clean"
	],
	[
		"M PLUS Rounded 1c",
		[
			100,
			300,
			400,
			500,
			700,
			800,
			900
		],
		"Japanese, rounded"
	],
	[
		"Zen Maru Gothic",
		[
			300,
			400,
			500,
			700,
			900
		],
		"Japanese, soft"
	],
	[
		"Kosugi Maru",
		[400],
		"Japanese, rounded"
	],
	[
		"Dela Gothic One",
		[400],
		"Japanese, heavy"
	],
	[
		"Mochiy Pop One",
		[400],
		"Japanese, pop"
	],
	[
		"Reggae One",
		[400],
		"Japanese, bold"
	],
	[
		"RocknRoll One",
		[400],
		"Japanese, playful"
	],
	[
		"Yusei Magic",
		[400],
		"Japanese, marker"
	],
	[
		"DotGothic16",
		[400],
		"Japanese, pixel"
	]
].map(([e, t, n]) => ({
	family: e,
	source: "online",
	weights: [...t],
	note: n
})), Ra = (e) => `family=${encodeURIComponent(e.family).replace(/%20/g, "+")}${e.weights.length > 1 ? `:wght@${e.weights.join(";")}` : ""}`, za = /* @__PURE__ */ new Set();
function Ba(e) {
	return za.has(e) ? Promise.resolve() : (za.add(e), new Promise((t, n) => {
		let r = document.createElement("link");
		r.rel = "stylesheet", r.href = e, r.onload = () => t(), r.onerror = () => {
			za.delete(e), r.remove(), n(/* @__PURE__ */ Error("The online font could not be loaded (no internet?)."));
		}, document.head.appendChild(r);
	}));
}
async function Va(e, t, n) {
	await Ba(`https://fonts.googleapis.com/css2?${Ra(e)}&display=block`), await document.fonts.load(`${t} 48px "${e.family}"`, n || e.family);
}
function Ha(e) {
	let t = [...new Set(e.map((e) => e.family).join(""))].join("");
	return Ba(`https://fonts.googleapis.com/css2?${e.map((e) => `family=${encodeURIComponent(e.family).replace(/%20/g, "+")}`).join("&")}&text=${encodeURIComponent(t)}&display=swap`).catch(() => void 0);
}
var Ua = () => typeof window < "u" && typeof window.queryLocalFonts == "function", Wa = [
	[/thin|hairline/i, 100],
	[/extra ?light|ultra ?light/i, 200],
	[/light/i, 300],
	[/medium/i, 500],
	[/semi ?bold|demi ?bold/i, 600],
	[/extra ?bold|ultra ?bold/i, 800],
	[/black|heavy/i, 900],
	[/bold/i, 700]
];
async function Ga() {
	if (!window.queryLocalFonts) return [];
	let e = await window.queryLocalFonts(), t = /* @__PURE__ */ new Map();
	for (let n of e) {
		let e = Wa.find(([e]) => e.test(n.style))?.[1] ?? 400, r = t.get(n.family) ?? /* @__PURE__ */ new Set();
		r.add(e), t.set(n.family, r);
	}
	return [...t].sort(([e], [t]) => e.localeCompare(t)).map(([e, t]) => ({
		family: e,
		source: "computer",
		weights: [...t].sort((e, t) => e - t)
	}));
}
var Ka = /* @__PURE__ */ new Map(), qa = () => [...Ka.values()];
async function Ja(e) {
	let t = e.name.replace(/\.(ttf|otf|woff2?)$/i, "").replace(/[^\w -]+/g, " ").trim().slice(0, 60) || "My font", n = new FontFace(t, await e.arrayBuffer(), { weight: "100 900" });
	try {
		await n.load();
	} catch {
		throw Error("That file is not a font this browser can read (TTF, OTF, WOFF or WOFF2).");
	}
	document.fonts.add(n);
	let r = {
		family: t,
		source: "file",
		weights: [400]
	};
	return Ka.set(t, r), r;
}
function Ya(e) {
	if (Ia.some((t) => t.family === e)) return !0;
	let t = document.createElement("canvas").getContext("2d");
	if (!t) return !0;
	let n = "mmmmmmmmmmlli WQ@#";
	return ["monospace", "serif"].some((r) => {
		t.font = `72px ${r}`;
		let i = t.measureText(n).width;
		return t.font = `72px "${e}", ${r}`, t.measureText(n).width !== i;
	});
}
async function Xa(e, t, n) {
	let r = La.find((t) => t.family === e);
	if (r) return Va(r, t, n);
	if (await document.fonts.load(`${t} 48px "${e}"`, n).catch(() => void 0), !Ya(e)) throw Error(`“${e}” is not on this computer: pick another font, or load its font file.`);
}
//#endregion
//#region src/model3d/PenPad.tsx
var Za = 300, Qa = 15, $a = ([e, t]) => [(e + .5) * Za, (.5 - t) * Za], eo = ([e, t]) => [Math.round((e / Za - .5) * 1e4) / 1e4, Math.round((.5 - t / Za) * 1e4) / 1e4], to = (e) => e.map((e) => ({
	closed: e.closed,
	nodes: e.nodes.map((e) => ({
		p: $a(e.p),
		...e.in ? { in: $a(e.in) } : {},
		...e.out ? { out: $a(e.out) } : {}
	}))
})), no = (e) => e.map((e) => ({
	closed: e.closed,
	nodes: e.nodes.map((e) => ({
		p: eo(e.p),
		...e.in ? { in: eo(e.in) } : {},
		...e.out ? { out: eo(e.out) } : {}
	}))
})), ro = (e, t) => [e[0] - t[0], e[1] - t[1]], io = (e, t) => [e[0] + t[0], e[1] + t[1]], ao = (e) => Math.hypot(e[0], e[1]), oo = (e) => e.map((e) => ({
	closed: e.closed,
	nodes: e.nodes.map((e) => ({ ...e }))
}));
function so(e, t = e.closed) {
	let n = e.nodes;
	if (!n.length) return "";
	let r = (e, t) => e.out || t.in ? `C${(e.out ?? e.p).join(" ")} ${(t.in ?? t.p).join(" ")} ${t.p.join(" ")}` : `L${t.p.join(" ")}`, i = `M${n[0].p.join(" ")}`;
	for (let e = 1; e < n.length; e++) i += r(n[e - 1], n[e]);
	return t && n.length > 1 && (i += `${r(n[n.length - 1], n[0])}Z`), i;
}
function co(e, t) {
	let n = e.nodes, r = n[t];
	if (r.in || r.out) {
		delete r.in, delete r.out;
		return;
	}
	let i = n[(t - 1 + n.length) % n.length].p, a = n[(t + 1) % n.length].p, o = ro(a, i), s = ao(o) || 1, c = Math.min(ao(ro(a, r.p)), ao(ro(r.p, i))) / 3 || 20, l = [o[0] / s * c, o[1] / s * c];
	r.in = ro(r.p, l), r.out = io(r.p, l);
}
function lo({ initial: e, onPaths: t }) {
	let [n, r] = q(() => to(e ?? [])), [i, a] = q(null), [o, s] = q(null), [c, l] = q(null), [u, d] = q(!1), f = K([]), p = K(null), m = K(null), h = K({
		paths: n,
		active: i
	});
	h.current = {
		paths: n,
		active: i
	}, G(() => t(no(n)), [n, t]);
	let g = () => {
		f.current.push(oo(h.current.paths)), f.current.length > 100 && f.current.shift();
	}, _ = () => {
		let e = f.current.pop();
		e && (r(e), a(null), s(null));
	}, v = () => {
		let { paths: e, active: t } = h.current;
		if (t === null) return;
		let n = e[t], i = oo(e);
		n.nodes.length < 2 ? i.splice(t, 1) : i[t].closed = !0, r(i), a(null);
	}, y = () => {
		if (!o) return;
		g();
		let e = oo(n);
		e[o[0]].nodes.splice(o[1], 1), e[o[0]].nodes.length < 2 && i !== o[0] && e.splice(o[0], 1), r(e.filter((e) => e.nodes.length)), s(null), i !== null && !e[i]?.nodes.length && a(null);
	};
	G(() => {
		let e = (e) => {
			e.key === "Escape" && h.current.active !== null && (e.stopImmediatePropagation(), v());
		};
		return window.addEventListener("keydown", e, !0), () => window.removeEventListener("keydown", e, !0);
	}, []);
	let b = (e, t, n = !1) => {
		let r = m.current.getBoundingClientRect(), i = [(e.clientX - r.left) / r.width * Za, (e.clientY - r.top) / r.height * Za];
		if (n && t) {
			let e = ro(i, t), n = Math.round(Math.atan2(e[1], e[0]) / (Math.PI / 4)) * (Math.PI / 4), r = ao(e);
			i = [t[0] + Math.cos(n) * r, t[1] + Math.sin(n) * r];
		}
		return u && (i = [Math.round(i[0] / Qa) * Qa, Math.round(i[1] / Qa) * Qa]), [Math.min(Za, Math.max(0, i[0])), Math.min(Za, Math.max(0, i[1]))];
	}, x = () => i === null ? null : n[i]?.nodes.at(-1)?.p ?? null, S = (e) => {
		if (e.button !== 0) return;
		m.current.setPointerCapture(e.pointerId), m.current.focus();
		let t = b(e, x(), e.shiftKey);
		g();
		let o = oo(n), c = i;
		(c === null || !o[c]) && (o.push({
			closed: !1,
			nodes: []
		}), c = o.length - 1, a(c)), o[c].nodes.push({ p: t }), r(o);
		let l = o[c].nodes.length - 1;
		s([c, l]), p.current = {
			kind: "new",
			path: c,
			node: l,
			from: t,
			moved: !1
		};
	}, C = (e, t, o) => {
		if (e.button !== 0) return;
		e.stopPropagation(), m.current.setPointerCapture(e.pointerId), m.current.focus(), g();
		let c = oo(n);
		i === t && o === 0 && c[t].nodes.length >= 2 ? (c[t].closed = !0, r(c), a(null), s([t, 0]), p.current = {
			kind: "new",
			path: t,
			node: 0,
			from: c[t].nodes[0].p,
			moved: !1
		}) : e.altKey ? (co(c[t], o), r(c), s([t, o])) : (s([t, o]), p.current = {
			kind: "node",
			path: t,
			node: o,
			from: b(e),
			moved: !1
		});
	}, w = (e, t, n, r) => {
		e.button === 0 && (e.stopPropagation(), m.current.setPointerCapture(e.pointerId), g(), p.current = {
			kind: "handle",
			path: t,
			node: n,
			side: r,
			moved: !1
		});
	}, T = (e) => {
		let t = p.current;
		if (!t) {
			l(i === null ? null : b(e, x(), e.shiftKey));
			return;
		}
		let n = oo(h.current.paths), a = n[t.path]?.nodes[t.node];
		if (a) {
			if (t.kind === "new") {
				let n = b(e);
				if (!t.moved && ao(ro(n, t.from)) < 3) return;
				t.moved = !0, a.out = n, a.in = ro(a.p, ro(n, a.p));
			} else if (t.kind === "node") {
				let n = b(e), r = ro(n, t.from);
				if (!t.moved && ao(r) < 1) return;
				t.moved = !0, t.from = n, a.p = io(a.p, r), a.in &&= io(a.in, r), a.out &&= io(a.out, r);
			} else {
				let n = b(e);
				t.moved = !0, a[t.side] = n;
				let r = t.side === "in" ? "out" : "in", i = a[r];
				if (i && !e.altKey) {
					let e = ro(a.p, n), t = ao(e) || 1, o = ao(ro(i, a.p));
					a[r] = io(a.p, [e[0] / t * o, e[1] / t * o]);
				}
			}
			r(n);
		}
	}, E = () => {
		let e = p.current;
		p.current = null, e && e.kind !== "new" && !e.moved && f.current.pop();
	}, D = (e) => {
		(e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "z" ? (e.preventDefault(), e.stopPropagation(), _()) : e.key === "Delete" || e.key === "Backspace" ? (e.preventDefault(), e.stopPropagation(), y()) : e.key === "Enter" && (e.preventDefault(), v());
	}, O = (e, t) => {
		g();
		let i = oo(n);
		co(i[e], t), r(i);
	}, k = n.map((e, t) => e.closed || t === i && e.nodes.length >= 3 ? so(e, !0) : "").filter(Boolean).join(""), A = i === null ? void 0 : n[i], j = A?.nodes.at(-1), M = (e, t) => o?.[0] === e && o[1] === t || e === i && t === (A?.nodes.length ?? 0) - 1;
	return /* @__PURE__ */ X("div", {
		className: "gs-pen",
		children: [/* @__PURE__ */ X("svg", {
			ref: m,
			className: "gs-m3d__pad gs-pen__pad",
			viewBox: `0 0 ${Za} ${Za}`,
			tabIndex: 0,
			"aria-label": "Pen: click for a corner, drag for a curve, click the first point to close",
			onPointerDown: S,
			onPointerMove: T,
			onPointerUp: E,
			onPointerLeave: () => l(null),
			onKeyDown: D,
			children: [
				/* @__PURE__ */ Y("defs", { children: /* @__PURE__ */ Y("pattern", {
					id: "gs-pen-grid",
					width: 30,
					height: 30,
					patternUnits: "userSpaceOnUse",
					children: /* @__PURE__ */ Y("path", {
						className: "gs-pen__gridline",
						d: "M30 0H0V30"
					})
				}) }),
				/* @__PURE__ */ Y("rect", {
					width: Za,
					height: Za,
					fill: "url(#gs-pen-grid)"
				}),
				k && /* @__PURE__ */ Y("path", {
					className: "gs-pen__fill",
					d: k,
					fillRule: "evenodd"
				}),
				n.map((e, t) => /* @__PURE__ */ Y("path", {
					className: "gs-pen__line",
					d: so(e),
					strokeWidth: 2
				}, t)),
				j && c && /* @__PURE__ */ Y("path", {
					d: `M${j.p.join(" ")}${j.out ? `C${j.out.join(" ")} ${c.join(" ")} ${c.join(" ")}` : `L${c.join(" ")}`}`,
					className: "gs-pen__line",
					strokeDasharray: "4 4",
					strokeWidth: 1.5,
					pointerEvents: "none"
				}),
				n.map((e, t) => e.nodes.map((e, n) => M(t, n) ? /* @__PURE__ */ Y("g", { children: ["in", "out"].map((r) => e[r] ? /* @__PURE__ */ X("g", { children: [/* @__PURE__ */ Y("line", {
					x1: e.p[0],
					y1: e.p[1],
					x2: e[r][0],
					y2: e[r][1],
					className: "gs-pen__arm",
					strokeWidth: 1,
					pointerEvents: "none"
				}), /* @__PURE__ */ Y("circle", {
					className: "gs-pen__handle",
					cx: e[r][0],
					cy: e[r][1],
					r: 4.5,
					onPointerDown: (e) => w(e, t, n, r)
				})] }, r) : null) }, `h${t}-${n}`) : null)),
				n.map((e, t) => e.nodes.map((n, r) => {
					let a = o?.[0] === t && o[1] === r, s = t === i && r === 0 && e.nodes.length >= 2, c = !!(n.in || n.out), l = {
						className: `gs-pen__node${a ? " is-on" : ""}${s ? " is-first" : ""}`,
						onPointerDown: (e) => C(e, t, r),
						onDoubleClick: () => O(t, r)
					};
					return c ? /* @__PURE__ */ Y("circle", {
						cx: n.p[0],
						cy: n.p[1],
						r: s ? 7 : 5,
						...l
					}, `n${t}-${r}`) : /* @__PURE__ */ Y("rect", {
						x: n.p[0] - (s ? 6 : 4.5),
						y: n.p[1] - (s ? 6 : 4.5),
						width: s ? 12 : 9,
						height: s ? 12 : 9,
						...l
					}, `n${t}-${r}`);
				}))
			]
		}), /* @__PURE__ */ X("div", {
			className: "gs-m3d__actions",
			children: [
				/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					disabled: !f.current.length && !n.length,
					onClick: _,
					title: "Undo (Ctrl Z)",
					children: "Undo"
				}),
				/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					disabled: !o,
					onClick: y,
					title: "Delete the picked point (Delete)",
					children: "Delete point"
				}),
				/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					disabled: !n.length,
					onClick: () => {
						g(), r([]), a(null), s(null);
					},
					children: "Clear"
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__check",
					children: [/* @__PURE__ */ Y("input", {
						type: "checkbox",
						checked: u,
						onChange: (e) => d(e.target.checked)
					}), " Snap to grid"]
				})
			]
		})]
	});
}
//#endregion
//#region src/model3d/dialogs.tsx
function uo({ title: e, onClose: t, children: n }) {
	return G(() => {
		let e = (e) => {
			e.key === "Escape" && (e.stopPropagation(), t());
		};
		return window.addEventListener("keydown", e, !0), () => window.removeEventListener("keydown", e, !0);
	}, [t]), /* @__PURE__ */ Y("div", {
		className: "gs-m3d__scrim",
		onPointerDown: t,
		children: /* @__PURE__ */ X("div", {
			className: "gs-m3d__dialog",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": e,
			onPointerDown: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ Y("h3", { children: e }), n]
		})
	});
}
var fo = (e) => zn(e.map((e) => e.map(([e, t]) => [50 + e * 90, 50 - t * 90]))), po = (e) => zn(e.flatMap((e) => [e.map(([e, t]) => [50 + (e + .5) * 45, 50 - t * 90]), e.map(([e, t]) => [50 - (e + .5) * 45, 50 - t * 90])])), mo = 24;
function ho({ initial: e, onPick: t, onClose: n, revolve: r = !1 }) {
	let [i, a] = q(e ?? []), s = xe(i);
	return /* @__PURE__ */ X(uo, {
		title: r ? e ? "Change the profile" : "Spin an outline round" : e ? "Change the outline" : "Push out an outline",
		onClose: n,
		children: [
			!e && /* @__PURE__ */ Y(o, { id: r ? "m3dRevolve" : "m3dOutlineShape" }),
			!e && /* @__PURE__ */ Y("div", {
				className: "gs-m3d__presets",
				children: Object.entries(r ? vt : Rt).map(([e, n]) => /* @__PURE__ */ X("button", {
					type: "button",
					onClick: () => {
						let e = Ie(n.contours), r = e.outline.reduce((e, t) => e + t.length, 0);
						t(e.outline, e.aspect, n.label, r <= mo ? Ft(e.outline.map((e) => e.map(([e, t]) => [e * .8, t * .8]))) : void 0);
					},
					children: [/* @__PURE__ */ Y("svg", {
						viewBox: "0 0 100 100",
						width: "48",
						height: "48",
						"aria-hidden": "true",
						children: /* @__PURE__ */ Y("path", {
							d: (r ? po : fo)(Ie(n.contours).outline),
							fill: "currentColor",
							fillRule: r ? "nonzero" : "evenodd"
						})
					}), /* @__PURE__ */ Y("span", { children: n.label })]
				}, e))
			}),
			!e && /* @__PURE__ */ Y("h4", { children: r ? "Or draw the right half with the pen" : "Or draw one with the pen" }),
			r && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: "It spins round its left edge, so draw from the middle outwards."
			}),
			/* @__PURE__ */ Y(o, { id: "m3dPen" }),
			/* @__PURE__ */ Y(lo, {
				initial: e,
				onPaths: a
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ Y("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: n,
						children: "Cancel"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: !s.length,
						onClick: () => {
							if (!s.length) return;
							let e = Ie(s);
							t(e.outline, e.aspect, r ? "Spun shape" : "Drawn outline", i);
						},
						children: e ? "Change" : r ? "Spin it round" : "Use outline"
					})
				]
			})
		]
	});
}
var go = {
	100: "Thin",
	200: "Extra light",
	300: "Light",
	400: "Regular",
	500: "Medium",
	600: "Semi-bold",
	700: "Bold",
	800: "Extra bold",
	900: "Black"
}, _o = {
	left: "Left",
	center: "Middle",
	right: "Right"
};
function vo({ initial: e, onDone: t, onClose: n }) {
	let [r, i] = q(e?.value ?? "Sale"), [a, s] = q(() => yo(e?.font ?? "Arial")), [c, l] = q(e?.weight ?? 800), [u, d] = q(e?.align ?? "center"), [f, p] = q(e?.lineHeight ?? 1.15), [m, h] = q(e?.spacing ?? 0), [g, _] = q(null), v = e && !Ya(e.font) && !La.some((t) => t.family === e.font) && a.family === e.font, y = r.split("\n").length, b = a.source === "online" || a.source === "file" ? a.weights : [
		400,
		500,
		600,
		700,
		800,
		900
	], x = b.includes(c) ? c : b.reduce((e, t) => Math.abs(t - c) < Math.abs(e - c) ? t : e), S = () => {
		let n = r.replace(/\s+$/, "").replace(/^\s*\n/, "");
		n.trim() && t({
			value: n,
			font: a.family,
			weight: x,
			...y > 1 || e?.align ? {
				align: u,
				lineHeight: f
			} : {},
			...m || e?.spacing ? { spacing: m } : {}
		});
	};
	return /* @__PURE__ */ X(uo, {
		title: e ? "Change the text" : "3D text",
		onClose: n,
		children: [
			/* @__PURE__ */ Y(o, { id: "m3dText" }),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field gs-m3d__field--top",
				children: [/* @__PURE__ */ Y("span", { children: "Text" }), /* @__PURE__ */ Y("textarea", {
					autoFocus: !0,
					rows: Math.min(5, Math.max(2, y)),
					value: r,
					maxLength: 200,
					onChange: (e) => i(e.target.value.split("\n").slice(0, 8).join("\n")),
					onKeyDown: (e) => {
						e.key === "Enter" && (e.metaKey || e.ctrlKey) && S();
					}
				})]
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__field gs-m3d__field--top",
				children: [/* @__PURE__ */ Y("span", { children: "Font" }), /* @__PURE__ */ Y(So, {
					value: a,
					onPick: (e) => {
						if (s(e), e.source !== "online") return _(null);
						_("Loading the font…"), Va(e, e.weights.includes(c) ? c : e.weights[0], r).then(() => _(null)).catch((e) => _(e instanceof Error ? e.message : "The font could not be loaded."));
					}
				})]
			}),
			v && /* @__PURE__ */ X("p", {
				className: "gs-m3d__note",
				children: [
					"“",
					e.font,
					"” is not on this computer: pick a font, or load its file under Font file."
				]
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Weight" }), /* @__PURE__ */ Y("select", {
					value: x,
					onChange: (e) => l(Number(e.target.value)),
					children: b.map((e) => /* @__PURE__ */ Y("option", {
						value: e,
						children: go[e] ?? e
					}, e))
				})]
			}),
			y > 1 && /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ X("div", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Lines" }), /* @__PURE__ */ Y("div", {
					className: "gs-m3d__segments",
					role: "group",
					"aria-label": "Line up",
					children: [
						"left",
						"center",
						"right"
					].map((e) => /* @__PURE__ */ Y("button", {
						type: "button",
						className: u === e ? "is-on" : "",
						onClick: () => d(e),
						children: _o[e]
					}, e))
				})]
			}), /* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Line gap" }), /* @__PURE__ */ Y("input", {
					type: "range",
					min: .7,
					max: 2,
					step: .05,
					value: f,
					onChange: (e) => p(Number(e.target.value))
				})]
			})] }),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Spacing" }), /* @__PURE__ */ Y("input", {
					type: "range",
					min: -.1,
					max: .6,
					step: .01,
					value: m,
					onChange: (e) => h(Number(e.target.value))
				})]
			}),
			/* @__PURE__ */ Y("p", {
				className: "gs-m3d__textpreview",
				style: {
					fontFamily: `"${a.family}", sans-serif`,
					fontWeight: x,
					textAlign: u,
					lineHeight: f,
					letterSpacing: `${m}em`,
					whiteSpace: "pre"
				},
				children: r || " "
			}),
			g && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: g
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ Y("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: n,
						children: "Cancel"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: !r.trim(),
						onClick: S,
						children: e ? "Change" : "Add text"
					})
				]
			})
		]
	});
}
function yo(e) {
	return [
		...Ia,
		...La,
		...qa()
	].find((t) => t.family === e) ?? {
		family: e,
		source: "computer",
		weights: [400, 700]
	};
}
var bo = {
	standard: "Standard",
	online: "Online",
	computer: "This computer",
	file: "Font file"
}, xo = null;
function So({ value: e, onPick: t }) {
	let [n, r] = q(e.source), [i, a] = q(""), [o, s] = q(xo), [c, l] = q(null), [u, d] = q(""), [, f] = q(0), p = K(null);
	G(() => {
		n === "online" && Ha(La);
	}, [n]);
	let m = n === "standard" ? Ia : n === "online" ? La : n === "computer" ? o ?? [] : qa(), h = i.trim().toLowerCase(), g = h ? m.filter((e) => e.family.toLowerCase().includes(h) || e.note?.toLowerCase().includes(h)) : m;
	return /* @__PURE__ */ X("div", {
		className: "gs-fonts",
		children: [
			/* @__PURE__ */ Y("div", {
				className: "gs-m3d__segments",
				role: "group",
				"aria-label": "Fonts from",
				children: Object.keys(bo).map((e) => /* @__PURE__ */ Y("button", {
					type: "button",
					className: n === e ? "is-on" : "",
					onClick: () => r(e),
					children: bo[e]
				}, e))
			}),
			n === "online" && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: "Free fonts from Google Fonts: each loads from the internet when picked."
			}),
			n === "computer" && /* @__PURE__ */ X("div", {
				className: "gs-fonts__ask",
				children: [o?.length ? null : Ua() ? /* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => {
						l(null), Ga().then((e) => {
							xo = e, s(e), e.length || l("The browser shared no fonts (it may have been told not to). Type a font’s name instead.");
						}).catch(() => l("The browser did not share this computer’s fonts."));
					},
					children: "Show this computer’s fonts"
				}) : /* @__PURE__ */ Y("p", {
					className: "gs-m3d__note",
					children: "This browser cannot list fonts."
				}), /* @__PURE__ */ X("form", {
					className: "gs-fonts__typed",
					onSubmit: (e) => {
						e.preventDefault();
						let n = u.trim();
						if (n) {
							if (!Ya(n)) return l(`“${n}” is not on this computer.`);
							l(null), t({
								family: n,
								source: "computer",
								weights: [400, 700]
							});
						}
					},
					children: [/* @__PURE__ */ Y("input", {
						value: u,
						placeholder: "Or type an installed font’s name",
						"aria-label": "Font name",
						onChange: (e) => d(e.target.value)
					}), /* @__PURE__ */ Y("button", {
						type: "submit",
						className: "gs-m3d__btn",
						children: "Use"
					})]
				})]
			}),
			n === "file" && /* @__PURE__ */ X(J, { children: [
				/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => p.current?.click(),
					children: "Load a font file…"
				}),
				/* @__PURE__ */ Y("input", {
					ref: p,
					type: "file",
					accept: ".ttf,.otf,.woff,.woff2",
					hidden: !0,
					onChange: (e) => {
						let n = e.target.files?.[0];
						e.target.value = "", n && (l(null), Ja(n).then((e) => {
							f((e) => e + 1), t(e);
						}).catch((e) => l(e instanceof Error ? e.message : "That font file could not be read.")));
					}
				}),
				/* @__PURE__ */ Y("p", {
					className: "gs-m3d__note",
					children: "Kept until the page closes; the letters stay in the design after that."
				})
			] }),
			m.length > 8 && /* @__PURE__ */ Y("input", {
				className: "gs-fonts__search",
				value: i,
				placeholder: "Search fonts",
				"aria-label": "Search fonts",
				onChange: (e) => a(e.target.value)
			}),
			g.length > 0 && /* @__PURE__ */ Y("ul", {
				className: "gs-fonts__list",
				role: "listbox",
				"aria-label": "Fonts",
				children: g.slice(0, 400).map((n) => /* @__PURE__ */ Y("li", { children: /* @__PURE__ */ X("button", {
					type: "button",
					role: "option",
					"aria-selected": e.family === n.family,
					className: e.family === n.family ? "is-on" : "",
					onClick: () => t(n),
					children: [/* @__PURE__ */ Y("span", {
						style: { fontFamily: `"${n.family}", sans-serif` },
						children: n.family
					}), n.note && /* @__PURE__ */ Y("small", { children: n.note })]
				}) }, `${n.source}-${n.family}`))
			}),
			c && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: c
			})
		]
	});
}
function Co({ initialKind: e = "turntable", initialSeconds: t = 4, moving: n = !1, onMake: r, onClose: i }) {
	let [a, s] = q(e), [c, l] = q(t), [u, d] = q(1080);
	return /* @__PURE__ */ X(uo, {
		title: "Make a video",
		onClose: i,
		children: [
			/* @__PURE__ */ Y(o, { id: "m3dVideo" }),
			n && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: "The shapes move as their Motion says, fitted to the clip’s length; pick what the camera does too."
			}),
			/* @__PURE__ */ Y("div", {
				className: "gs-m3d__segments",
				role: "group",
				"aria-label": "Clip",
				children: Object.keys(w).map((e) => /* @__PURE__ */ Y("button", {
					type: "button",
					className: a === e ? "is-on" : "",
					onClick: () => s(e),
					children: w[e]
				}, e))
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Length" }), /* @__PURE__ */ Y("select", {
					value: c,
					onChange: (e) => l(Number(e.target.value)),
					children: [
						2,
						4,
						6,
						8,
						12
					].map((e) => /* @__PURE__ */ X("option", {
						value: e,
						children: [e, " seconds"]
					}, e))
				})]
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Size" }), /* @__PURE__ */ X("select", {
					value: u,
					onChange: (e) => d(Number(e.target.value)),
					children: [
						/* @__PURE__ */ Y("option", {
							value: 720,
							children: "720 px"
						}),
						/* @__PURE__ */ Y("option", {
							value: 1080,
							children: "1080 px"
						}),
						/* @__PURE__ */ Y("option", {
							value: 1440,
							children: "1440 px"
						})
					]
				})]
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ Y("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: i,
						children: "Cancel"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						onClick: () => r(a, c, u),
						children: "Make video"
					})
				]
			})
		]
	});
}
//#endregion
//#region src/model3d/AdDialog.tsx
var wo = "gleamshelf.shop.logo";
function To() {
	try {
		let e = JSON.parse(localStorage.getItem(wo) ?? "null");
		return e && typeof e.svg == "string" && typeof e.name == "string" ? {
			name: e.name,
			svg: e.svg
		} : null;
	} catch {
		return null;
	}
}
function Eo(e) {
	try {
		e ? localStorage.setItem(wo, JSON.stringify(e)) : localStorage.removeItem(wo);
	} catch {}
}
var Do = "gleamshelf.ad.look";
function Oo() {
	let e = {
		style: "podium",
		palette: "blossom",
		font: "Arial"
	};
	try {
		let t = JSON.parse(localStorage.getItem(Do) ?? "null");
		return {
			style: t?.style && t.style in dr ? t.style : e.style,
			palette: t?.palette && t.palette in Kn ? t.palette : e.palette,
			font: typeof t?.font == "string" && t.font ? t.font : e.font
		};
	} catch {
		return e;
	}
}
function ko(e) {
	try {
		localStorage.setItem(Do, JSON.stringify(e));
	} catch {}
}
function Ao({ start: e, onMake: t, onClose: n }) {
	let [r, i] = q(e?.picture ?? null), [a, s] = q(null), [c, l] = q(e?.headline ?? ""), [u, d] = q(e?.tagline ?? "New arrival"), [f, p] = q(e?.price ?? ""), [m, h] = q(To), [g, _] = q(() => Oo().style), [v, y] = q(() => Oo().palette), [b, x] = q(() => yo(Oo().font)), [S, C] = q(!0), [w] = q(Rr), [T, E] = q(!!w), [D, O] = q(null), k = K(null), A = K(null);
	G(() => {
		if (!r) return s(null);
		let e = URL.createObjectURL(r);
		return s(e), () => URL.revokeObjectURL(e);
	}, [r]);
	let j = !!(r || c.trim() || f.trim());
	return /* @__PURE__ */ X(uo, {
		title: "Make a 3D ad",
		onClose: n,
		children: [
			/* @__PURE__ */ Y(o, { id: "m3dAd" }),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Product" }), /* @__PURE__ */ X("div", {
					className: "gs-ad__picture",
					children: [
						a ? /* @__PURE__ */ Y("img", {
							src: a,
							alt: "The product"
						}) : /* @__PURE__ */ Y("span", {
							className: "gs-m3d__note",
							children: "No picture"
						}),
						/* @__PURE__ */ Y("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: () => k.current?.click(),
							children: r ? "Change…" : "Choose a picture…"
						}),
						/* @__PURE__ */ Y("input", {
							ref: k,
							type: "file",
							accept: "image/png,image/webp,image/jpeg",
							hidden: !0,
							onChange: (e) => {
								let t = e.target.files?.[0];
								e.target.value = "", t && i(t);
							}
						})
					]
				})]
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Headline" }), /* @__PURE__ */ Y("input", {
					value: c,
					maxLength: 60,
					placeholder: "What it is",
					onChange: (e) => l(e.target.value)
				})]
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Small line" }), /* @__PURE__ */ Y("input", {
					value: u,
					maxLength: 40,
					placeholder: "New arrival",
					onChange: (e) => d(e.target.value)
				})]
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Price" }), /* @__PURE__ */ Y("input", {
					value: f,
					maxLength: 14,
					placeholder: "$45 (none: no badge)",
					onChange: (e) => p(e.target.value)
				})]
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Logo" }), /* @__PURE__ */ X("div", {
					className: "gs-ad__picture",
					children: [
						/* @__PURE__ */ Y("span", {
							className: "gs-m3d__note",
							children: m ? m.name : "None"
						}),
						/* @__PURE__ */ Y("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: () => A.current?.click(),
							children: m ? "Change…" : "Choose an SVG…"
						}),
						m && /* @__PURE__ */ Y("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: () => {
								h(null), Eo(null);
							},
							children: "No logo"
						}),
						/* @__PURE__ */ Y("input", {
							ref: A,
							type: "file",
							accept: ".svg,image/svg+xml",
							hidden: !0,
							onChange: (e) => {
								let t = e.target.files?.[0];
								if (e.target.value = "", t) {
									if (t.size > 4e5) return O("That SVG is very large; a logo is usually a few kilobytes.");
									t.text().then((e) => {
										let n = {
											name: t.name.replace(/\.svg$/i, ""),
											svg: e
										};
										h(n), Eo(n), O(null);
									});
								}
							}
						})
					]
				})]
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Layout" }), /* @__PURE__ */ Y("div", {
					className: "gs-m3d__segments",
					role: "group",
					"aria-label": "Layout",
					children: Object.keys(dr).map((e) => /* @__PURE__ */ Y("button", {
						type: "button",
						className: g === e ? "is-on" : "",
						onClick: () => _(e),
						children: dr[e]
					}, e))
				})]
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Colours" }), /* @__PURE__ */ Y("div", {
					className: "gs-ad__palettes",
					role: "group",
					"aria-label": "Colours",
					children: Object.entries(Kn).map(([e, t]) => /* @__PURE__ */ Y("button", {
						type: "button",
						className: v === e ? "is-on" : "",
						title: t.label,
						"aria-label": t.label,
						onClick: () => y(e),
						children: [
							t.colours.background,
							t.colours.main,
							t.colours.accent,
							t.colours.text
						].map((e, t) => /* @__PURE__ */ Y("span", { style: { background: e } }, t))
					}, e))
				})]
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__field gs-m3d__field--top",
				children: [/* @__PURE__ */ Y("span", { children: "Font" }), /* @__PURE__ */ Y(So, {
					value: b,
					onPick: x
				})]
			}),
			w && /* @__PURE__ */ X("div", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Scene" }), /* @__PURE__ */ X("label", {
					className: "gs-m3d__check gs-ad__scene",
					children: [
						/* @__PURE__ */ Y("input", {
							type: "checkbox",
							checked: T,
							onChange: (e) => E(e.target.checked)
						}),
						/* @__PURE__ */ Y("img", {
							src: w,
							alt: "The last scene"
						}),
						" Use the last scene behind it"
					]
				})]
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__check",
				children: [/* @__PURE__ */ Y("input", {
					type: "checkbox",
					checked: S,
					onChange: (e) => C(e.target.checked)
				}), " Make it move (the product floats, the words pop in, the price pulses)"]
			}),
			D && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: D
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ Y("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: n,
						children: "Cancel"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: !j,
						onClick: () => {
							ko({
								style: g,
								palette: v,
								font: b.family
							}), t({
								picture: r,
								headline: c,
								tagline: u,
								price: f,
								logo: m,
								style: g,
								colours: Kn[v].colours,
								font: b,
								moving: S,
								scene: T ? w : null
							});
						},
						children: "Make the ad"
					})
				]
			})
		]
	});
}
//#endregion
//#region src/model3d/PhotosDialog.tsx
var jo = 0, Mo = (e, t, n, r) => ({
	key: `p${jo++}`,
	blob: e,
	thumb: URL.createObjectURL(e),
	label: t,
	chosen: n,
	found: r
});
function No({ start: e, onMade: n, onClose: r }) {
	let i = t(), s = i.state === "ready" ? i.client : null, c = l(), [u, d] = q(() => e?.cutout ? [Mo(e.cutout, "Your photo", !0)] : []), [f, p] = q(null), [m, h] = q(null), [g, _] = q(null), [v, y] = q(null), [b, x] = q(!1), S = K(null), C = K(u);
	C.current = u, G(() => () => C.current.forEach((e) => URL.revokeObjectURL(e.thumb)), []), G(() => {
		if (!s) return;
		let e = !1;
		return s.shapeModels().then((t) => {
			e || (p(t ?? []), h((e) => e ?? t?.find((e) => e.ready)?.id ?? null));
		}).catch((t) => !e && y(t instanceof Error ? t.message : "The 3D models could not be listed.")), () => {
			e = !0;
		};
	}, [s]);
	let w = u.filter((e) => e.chosen), T = f?.find((e) => e.id === m) ?? null, E = T && w.length > T.photos ? w.length - T.photos : 0, D = async () => {
		if (s && e?.identity) {
			_("Looking for the maker's photos and others online…"), y(null);
			try {
				let t = await s.findShapePictures(e.identity, e.cutout ?? null), n = (await Promise.all(t.map(async (e) => {
					let t = await s.shapePicture(e.id).catch(() => null);
					return t && Mo(t, e.source === "official" ? `Maker · ${e.site}` : `Online · ${e.site}`, !1, e);
				}))).filter((e) => !!e && !u.some((t) => t.found?.id === e.found?.id));
				d((e) => [...e, ...n]), x(!0), n.length || y("Nothing new was found for this figure. Add your own photos from other angles instead.");
			} catch (e) {
				y(e instanceof Error ? e.message : "The search did not work.");
			} finally {
				_(null);
			}
		}
	}, O = async () => {
		if (s && T && w.length) {
			_(T.id === "triposr" ? "Making the model (a few seconds)…" : "Making the model (a minute or two)…"), y(null);
			try {
				let t = await s.makeShapeModel(T.id, w.slice(0, T.photos).map((e) => e.found ? { found: e.found.id } : e.blob)), r = await s.shapeModelFile(t.id), i = `${e?.name?.trim() || "Figure"} (generated)`.replace(/[\\/:*?"<>|]/g, " ");
				n(new File([r], `${i}.glb`, { type: "model/gltf-binary" }), t, T);
			} catch (e) {
				y(e instanceof Error ? e.message : "The model could not be made.");
			} finally {
				_(null);
			}
		}
	};
	return /* @__PURE__ */ X(uo, {
		title: "3D model from photos",
		onClose: r,
		children: [
			/* @__PURE__ */ Y(o, { id: "m3dPhotos" }),
			!s && c && i.state !== "ready" && /* @__PURE__ */ Y(a, {
				app: i,
				feature: "Making a 3D model from photos"
			}),
			!s && !(c && i.state !== "ready") && /* @__PURE__ */ X("p", {
				className: "gs-m3d__note",
				children: [
					"This needs the Gleamshelf app running on this computer.",
					" ",
					!i.looking && /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => void i.check(),
						children: "Look for the app"
					})
				]
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__field gs-m3d__field--top",
				children: [/* @__PURE__ */ Y("span", { children: "Photos" }), /* @__PURE__ */ X("div", {
					className: "gs-shape__pictures",
					role: "group",
					"aria-label": "Photos to make the model from",
					children: [u.map((e) => /* @__PURE__ */ X("button", {
						type: "button",
						className: `gs-shape__picture${e.chosen ? " is-on" : ""}`,
						"aria-pressed": e.chosen,
						title: e.found?.page ? `${e.label}: ${e.found.page}` : e.label,
						onClick: () => d((t) => t.map((t) => t.key === e.key ? {
							...t,
							chosen: !t.chosen
						} : t)),
						children: [/* @__PURE__ */ Y("img", {
							src: e.thumb,
							alt: ""
						}), /* @__PURE__ */ Y("small", { children: e.label })]
					}, e.key)), !u.length && /* @__PURE__ */ Y("span", {
						className: "gs-m3d__note",
						children: "No photos yet."
					})]
				})]
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						disabled: !!g,
						onClick: () => S.current?.click(),
						children: "Add photos…"
					}),
					e?.identity && /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						disabled: !s || !!g || b,
						onClick: () => void D(),
						children: "Find the maker's photos"
					}),
					/* @__PURE__ */ Y("input", {
						ref: S,
						type: "file",
						multiple: !0,
						accept: "image/png,image/webp,image/jpeg",
						hidden: !0,
						onChange: (e) => {
							let t = [...e.target.files ?? []];
							e.target.value = "", d((e) => [...e, ...t.map((e) => Mo(e, "Your photo", !0))]);
						}
					})
				]
			}),
			u.some((e) => e.found?.source === "web") && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: "Photos found online are not checked: choose only ones of this exact figure."
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__field gs-m3d__field--top",
				children: [/* @__PURE__ */ Y("span", { children: "Model" }), /* @__PURE__ */ X("div", {
					className: "gs-shape__models",
					role: "radiogroup",
					"aria-label": "Which model makes it",
					children: [f === null && s && /* @__PURE__ */ Y("span", {
						className: "gs-m3d__note",
						children: "Checking this computer…"
					}), f?.map((e) => /* @__PURE__ */ X("label", {
						className: `gs-shape__model${e.ready ? "" : " is-off"}`,
						children: [/* @__PURE__ */ Y("input", {
							type: "radio",
							name: "shape-model",
							checked: m === e.id,
							disabled: !e.ready,
							onChange: () => h(e.id)
						}), /* @__PURE__ */ X("span", { children: [
							/* @__PURE__ */ Y("b", { children: e.name }),
							" ",
							e.about,
							!e.ready && e.why && /* @__PURE__ */ X("small", { children: [
								" ",
								"Here: ",
								e.why,
								e.why === "not set up yet" ? `, set it up with ${e.setup}` : "",
								"."
							] })
						] })]
					}, e.id))]
				})]
			}),
			E > 0 && /* @__PURE__ */ X("p", {
				className: "gs-m3d__note",
				children: [
					T.name,
					" uses ",
					T.photos === 1 ? "only the first photo" : `the first ${T.photos}`,
					"; ",
					E,
					" chosen will not be used."
				]
			}),
			/* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: "The back and sides are the model's guess: it is marked as generated, not as photographed."
			}),
			(g || v) && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: g ?? v
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ Y("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: r,
						children: "Cancel"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: !s || !T?.ready || !w.length || !!g,
						onClick: () => void O(),
						children: "Make the 3D model"
					})
				]
			})
		]
	});
}
//#endregion
//#region src/model3d/clipboard.ts
var Po = null, Fo = null;
function Io(e, t) {
	Po = {
		shapes: structuredClone(t),
		assets: Ot(e, t),
		pastes: 0
	};
}
var Lo = () => Po;
function Ro() {
	let e = Po ? ++Po.pastes : 1;
	return [
		.5 * e,
		0,
		.5 * e
	];
}
function zo(e) {
	Fo = {
		color: e.color,
		finish: e.finish
	};
}
var Bo = () => Fo;
async function Vo(e) {
	if (!navigator.clipboard?.write || typeof ClipboardItem > "u") throw Error("This browser cannot put pictures on the clipboard.");
	await navigator.clipboard.write([new ClipboardItem({ "image/png": e })]).catch(Ho);
}
function Ho(e) {
	throw e instanceof Error && /denied|not allowed|permission|focus/i.test(e.message) ? Error("The browser did not allow copying here. Use Save instead, or allow the clipboard for this page.") : e;
}
async function Uo(e) {
	let t = e.then((e) => new Blob([e], { type: "text/plain" }));
	if (navigator.clipboard?.write && typeof ClipboardItem < "u") {
		let n = ClipboardItem.supports?.("image/svg+xml"), r = { "text/plain": t };
		n && (r["image/svg+xml"] = e.then((e) => new Blob([e], { type: "image/svg+xml" }))), await navigator.clipboard.write([new ClipboardItem(r)]).catch(Ho);
	} else await navigator.clipboard.writeText(await e).catch(Ho);
}
//#endregion
//#region src/model3d/voicefx.ts
var Wo = [
	"none",
	"cute",
	"deep",
	"monster",
	"robot",
	"radio",
	"cave",
	"ghost"
], Go = {
	none: "As it is",
	cute: "Higher (cute)",
	deep: "Deeper",
	monster: "Monster",
	robot: "Robot voice",
	radio: "Radio",
	cave: "Cave",
	ghost: "Ghost"
};
function Ko(e) {
	let t = new DataView(e);
	if (t.getUint32(0, !1) !== 1380533830) throw Error("That is not a WAV file.");
	let n = 12, r = 1, i = 1, a = 16e3, o = 16;
	for (; n + 8 <= t.byteLength;) {
		let e = t.getUint32(n, !1), s = t.getUint32(n + 4, !0);
		if (e === 1718449184) r = t.getUint16(n + 8, !0), i = t.getUint16(n + 10, !0), a = t.getUint32(n + 12, !0), o = t.getUint16(n + 22, !0);
		else if (e === 1684108385) {
			let e = o / 8, c = Math.min(t.byteLength, n + 8 + s), l = Math.floor((c - n - 8) / (e * i)), u = new Float32Array(l);
			for (let a = 0; a < l; a++) {
				let s = 0;
				for (let c = 0; c < i; c++) {
					let l = n + 8 + (a * i + c) * e;
					s += r === 3 && o === 32 ? t.getFloat32(l, !0) : t.getInt16(l, !0) / 32768;
				}
				u[a] = s / i;
			}
			return {
				samples: u,
				rate: a
			};
		}
		n += 8 + s + s % 2;
	}
	throw Error("The WAV file has no sound in it.");
}
function qo({ samples: e, rate: t }) {
	let n = /* @__PURE__ */ new ArrayBuffer(44 + e.length * 2), r = new DataView(n), i = (e, t) => [...t].forEach((t, n) => r.setUint8(e + n, t.charCodeAt(0)));
	i(0, "RIFF"), r.setUint32(4, 36 + e.length * 2, !0), i(8, "WAVE"), i(12, "fmt "), r.setUint32(16, 16, !0), r.setUint16(20, 1, !0), r.setUint16(22, 1, !0), r.setUint32(24, t, !0), r.setUint32(28, t * 2, !0), r.setUint16(32, 2, !0), r.setUint16(34, 16, !0), i(36, "data"), r.setUint32(40, e.length * 2, !0);
	for (let t = 0; t < e.length; t++) r.setInt16(44 + t * 2, Math.round(Math.max(-1, Math.min(1, e[t])) * 32767), !0);
	return n;
}
function Jo(e, t, n) {
	if (Math.abs(n - 1) < .001) return e.slice();
	let r = Math.max(256, Math.round(t * .04) & -2), i = r / 2, a = i / n, o = Float32Array.from({ length: r }, (e, t) => .5 - .5 * Math.cos(2 * Math.PI * t / r)), s = Math.round(e.length * n), c = new Float32Array(s + r), l = new Float32Array(s + r), u = Math.round(t * .008), d = Math.min(256, r / 2), f = 0;
	for (let t = 0; t * i < s; t++) {
		let n = Math.round(t * a);
		if (t > 0) {
			let t = f + i, r = -Infinity, a = n;
			for (let i = -u; i <= u; i += 4) {
				let o = n + i;
				if (o < 0 || o + d >= e.length || t + d >= e.length) continue;
				let s = 0;
				for (let n = 0; n < d; n += 2) s += e[o + n] * e[t + n];
				s > r && (r = s, a = o);
			}
			n = a;
		}
		f = n;
		let s = t * i;
		for (let t = 0; t < r; t++) {
			let r = e[n + t] ?? 0;
			c[s + t] += r * o[t], l[s + t] += o[t];
		}
	}
	let p = new Float32Array(s);
	for (let e = 0; e < s; e++) p[e] = l[e] > .001 ? c[e] / l[e] : 0;
	return p;
}
function Yo(e, t) {
	let n = new Float32Array(t), r = (e.length - 1) / Math.max(1, t - 1);
	for (let i = 0; i < t; i++) {
		let t = i * r, a = Math.floor(t);
		n[i] = (e[a] ?? 0) + ((e[a + 1] ?? e[a] ?? 0) - (e[a] ?? 0)) * (t - a);
	}
	return n;
}
function Xo(e, t) {
	return e.rate === t ? e : {
		samples: Yo(t < e.rate ? Qo(e.samples, e.rate, "low", t * .45) : e.samples, Math.max(1, Math.round(e.samples.length * t / e.rate))),
		rate: t
	};
}
function Zo(e, t, n) {
	return n ? Yo(Jo(e, t, 2 ** (n / 12)), e.length) : e.slice();
}
function Qo(e, t, n, r, i = .707) {
	let a = 2 * Math.PI * r / t, o = Math.cos(a), s = Math.sin(a) / (2 * i), c, l, u;
	n === "low" ? (c = (1 - o) / 2, l = 1 - o, u = (1 - o) / 2) : n === "high" ? (c = (1 + o) / 2, l = -(1 + o), u = (1 + o) / 2) : (c = s, l = 0, u = -s);
	let d = 1 + s, f = -2 * o, p = 1 - s, m = new Float32Array(e.length), h = 0, g = 0, _ = 0, v = 0;
	for (let t = 0; t < e.length; t++) {
		let n = (c * e[t] + l * h + u * g - f * _ - p * v) / d;
		g = h, h = e[t], v = _, _ = n, m[t] = n;
	}
	return m;
}
function $o(e, t, n, r, i = 1, a = 1.2) {
	let o = new Float32Array(e.length + Math.round(t * a));
	for (let t = 0; t < e.length; t++) o[t] = e[t] * i;
	for (let i of n) {
		let a = Math.max(1, Math.round(t * i)), s = new Float32Array(o.length);
		for (let t = 0; t < o.length; t++) s[t] = (e[t] ?? 0) + (t >= a ? s[t - a] * r : 0);
		for (let e = 0; e < o.length; e++) o[e] += (e >= a ? s[e - a] : 0) * (r / n.length);
	}
	return o;
}
function es(e) {
	let t = 0;
	for (let n of e) t = Math.max(t, Math.abs(n));
	if (t < 1e-6) return e;
	let n = .89 / t;
	return e.map((e) => e * n);
}
var ts = {
	cute: 4,
	deep: -4,
	monster: -7
};
function ns({ samples: e, rate: t }, n, r = 0) {
	let i = r + (ts[n] ?? 0), a = i ? Zo(e, t, i) : e.slice();
	return n === "monster" ? (a = a.map((e, n) => e * (.7 + .3 * Math.sin(2 * Math.PI * 30 * n / t))), a = Qo(a, t, "low", 2800)) : n === "robot" ? a = $o(a.map((e, n) => e * Math.sin(2 * Math.PI * 55 * n / t)).map((e, t) => .6 * e + .4 * a[t]), t, [.006], .55, 1, .1).subarray(0, a.length) : n === "radio" ? a = Qo(Qo(a, t, "high", 450), t, "low", 3200).map((e) => Math.tanh(e * 2.2) / 1.6) : n === "cave" ? a = $o(a, t, [
		.19,
		.29,
		.41
	], .45, 1, 1.6) : n === "ghost" && (a = Zo(a, t, 1), a = a.map((e, n) => e * (.75 + .25 * Math.sin(2 * Math.PI * 5 * n / t))), a = $o(Qo(a, t, "high", 300), t, [.11, .23], .5, .8, 1.4)), {
		samples: es(a),
		rate: t
	};
}
//#endregion
//#region src/model3d/VoiceDialog.tsx
var rs = {
	type: "Type it",
	say: "Speak it"
}, is = ["type", "say"], as = {
	own: "Keep my voice",
	change: "Change my voice"
}, os = (e) => `${e.label} (${e.accent}, ${e.kind})`;
async function ss(e) {
	let t = new AudioContext();
	try {
		let n = await t.decodeAudioData(await e.arrayBuffer()), r = new Float32Array(n.length);
		for (let e = 0; e < n.numberOfChannels; e++) n.getChannelData(e).forEach((e, t) => r[t] += e / n.numberOfChannels);
		return {
			samples: r,
			rate: n.sampleRate
		};
	} finally {
		t.close();
	}
}
var cs = (e) => new Blob([qo(e)], { type: "audio/wav" });
function ls({ initialText: e = "", title: n = "Voice studio", onMake: s, onClose: c }) {
	let u = t(), [d, f] = q(null), [p, m] = q("type"), [h, g] = q(e), [_, v] = q("af_heart"), [y, b] = q(1), [x, S] = q("change"), [C, w] = q("none"), [T, E] = q(0), [D, O] = q(!1), [k, A] = q(null), [j, M] = q(null), [ee, te] = q(null), [ne, N] = q(null), P = K(null), re = K(null);
	G(() => {
		if (u.state !== "ready") return;
		let e = !0;
		return u.client.voiceStatus().then((t) => e && f(t)).catch(() => e && f(null)), () => {
			e = !1;
		};
	}, [u.state, u.client]), G(() => () => j ? URL.revokeObjectURL(j.url) : void 0, [j]);
	let F = u.state === "ready" && !!d?.ok, I = l(), ie = F && !!d?.live?.ok, ae = async () => {
		if (N(null), D) P.current?.stop();
		else try {
			let e = await navigator.mediaDevices.getUserMedia({ audio: {
				echoCancellation: !0,
				noiseSuppression: !0
			} }), t = new MediaRecorder(e), n = [];
			t.ondataavailable = (e) => n.push(e.data), t.onstop = () => {
				e.getTracks().forEach((e) => e.stop()), O(!1), ss(new Blob(n, { type: t.mimeType })).then((e) => A(Xo(e, 24e3))).catch(() => N("The recording could not be read: try again."));
			}, P.current = t, t.start(), O(!0), A(null);
		} catch {
			N("The microphone could not be used: allow it for this page, then try again.");
		}
	}, oe = async () => {
		let e = p === "type" ? `type|${h}|${_}|${y}` : `say|${x}|${_}|${k?.samples.length}`;
		if (re.current?.key === e) return re.current.sound;
		let t;
		if (p === "type") {
			if (!h.trim()) throw Error("Type the line first.");
			te("Speaking the line…"), t = Ko(await (await u.client.speak(h.trim(), {
				voice: _,
				speed: y
			})).arrayBuffer());
		} else {
			if (!k) throw Error("Record the line first.");
			x === "own" ? t = k : (te(d?.live?.voices.includes(_) ? "Changing the voice…" : "Making this voice (about a minute, the first time)…"), t = Ko(await (await u.client.changeVoice(cs(k), _)).arrayBuffer()));
		}
		return re.current = {
			key: e,
			sound: t
		}, t;
	}, L = async () => {
		N(null);
		try {
			let e = await oe();
			te("Adding the effect…"), await new Promise((e) => setTimeout(e, 20));
			let t = cs(ns(e, C, T));
			M({
				url: URL.createObjectURL(t),
				blob: t
			});
		} catch (e) {
			N(e instanceof Error ? e.message : "The line could not be made.");
		} finally {
			te(null);
		}
	}, se = async () => {
		if (k) {
			N(null), te("Writing down what you said…");
			try {
				let e = await u.client.listen(cs(k));
				g(e.text), m("type");
			} catch (e) {
				N(e instanceof Error ? e.message : "What you said could not be written down.");
			} finally {
				te(null);
			}
		}
	}, ce = (h.trim() || "Voice line").split(/\s+/).slice(0, 6).join(" ").replace(/[^\w '-]+/g, ""), le = /* @__PURE__ */ X("label", {
		className: "gs-m3d__field",
		children: [
			/* @__PURE__ */ Y("span", { children: "Voice" }),
			/* @__PURE__ */ Y("select", {
				value: _,
				onChange: (e) => v(e.target.value),
				children: i.map((e) => /* @__PURE__ */ Y("option", {
					value: e.id,
					disabled: e.accent === "Japanese" && !!d?.ok && !d.japanese,
					children: os(e)
				}, e.id))
			}),
			r(_) === "ja" && /* @__PURE__ */ Y("span", {
				className: "gs-m3d__meta",
				children: d?.ok && !d.japanese ? "The Japanese voices need setting up once: npm run voice:setup -- --japanese (free, on this computer)." : "A Japanese voice reads Japanese: write the line in Japanese."
			})
		]
	});
	return /* @__PURE__ */ X(uo, {
		title: n,
		onClose: c,
		children: [
			/* @__PURE__ */ X("div", {
				className: "gs-voice",
				children: [
					I && u.state !== "ready" && /* @__PURE__ */ Y(a, {
						app: u,
						feature: "Voices"
					}),
					/* @__PURE__ */ X("p", {
						className: "gs-m3d__note",
						hidden: !!I && u.state !== "ready",
						children: [
							F ? "Free: the voices run on this computer and nothing is sent anywhere. They are made-up voices, so any use is fine, selling included." : u.state === "ready" ? `Voices need setting up once (free, on this computer): ${d?.setup ?? "npm run voice:setup"}` : "Voices need the Gleamshelf app running on this computer (free; nothing is sent anywhere).",
							" ",
							u.state !== "ready" && !u.looking && /* @__PURE__ */ Y("button", {
								type: "button",
								className: "gs-m3d__btn",
								onClick: () => void u.check(),
								children: "Look for the app"
							})
						]
					}),
					/* @__PURE__ */ Y(W, {
						label: "How",
						value: p,
						options: is,
						labels: rs,
						onChange: m
					}),
					p === "type" ? /* @__PURE__ */ X(J, { children: [
						/* @__PURE__ */ X("label", {
							className: "gs-m3d__field gs-m3d__field--top",
							children: [/* @__PURE__ */ Y("span", { children: "The line" }), /* @__PURE__ */ Y("textarea", {
								rows: 3,
								maxLength: 1500,
								value: h,
								placeholder: "e.g. Welcome to the shop! Mind the shelves, they bite.",
								onChange: (e) => g(e.target.value)
							})]
						}),
						le,
						/* @__PURE__ */ Y(U, {
							label: "Speed",
							value: y,
							min: .7,
							max: 1.4,
							step: .05,
							format: (e) => `${e.toFixed(2)}x`,
							onBegin: () => void 0,
							onChange: b,
							onEnd: () => void 0
						})
					] }) : /* @__PURE__ */ X(J, { children: [
						/* @__PURE__ */ X("div", {
							className: "gs-m3d__row",
							children: [
								/* @__PURE__ */ Y("button", {
									type: "button",
									className: `gs-m3d__btn${D ? " is-on" : ""}`,
									onClick: () => void ae(),
									children: D ? "■ Stop recording" : k ? "● Record again" : "● Record the line"
								}),
								k && !D && /* @__PURE__ */ X("span", {
									className: "gs-m3d__meta",
									children: [(k.samples.length / k.rate).toFixed(1), " s recorded"]
								}),
								k && !D && F && /* @__PURE__ */ Y("button", {
									type: "button",
									className: "gs-m3d__btn",
									disabled: !!ee,
									onClick: () => void se(),
									children: "Write down what I said"
								})
							]
						}),
						/* @__PURE__ */ Y(W, {
							label: "Voice",
							value: x,
							options: ["own", "change"],
							labels: as,
							onChange: S
						}),
						x === "change" && le,
						x === "change" && F && !ie && /* @__PURE__ */ X("p", {
							className: "gs-m3d__note",
							children: ["Changing your voice needs one more setup: ", d?.live?.setup ?? "npm run voice:setup -- --live"]
						})
					] }),
					/* @__PURE__ */ Y(W, {
						label: "Effect",
						value: C,
						options: Wo,
						labels: Go,
						onChange: w
					}),
					/* @__PURE__ */ Y(U, {
						label: "Pitch",
						value: T,
						min: -8,
						max: 8,
						step: 1,
						format: (e) => e ? `${e > 0 ? "+" : ""}${e} semitones` : "As it is",
						onBegin: () => void 0,
						onChange: E,
						onEnd: () => void 0
					}),
					/* @__PURE__ */ Y("div", {
						className: "gs-m3d__row",
						children: /* @__PURE__ */ Y("button", {
							type: "button",
							className: "gs-m3d__btn",
							disabled: !!ee || (p === "type" ? !F : !k || x === "change" && !ie),
							onClick: () => void L(),
							children: ee ?? (j ? "Make it again" : "Make the line")
						})
					}),
					j && /* @__PURE__ */ Y("audio", {
						className: "gs-voice__play",
						src: j.url,
						controls: !0,
						autoPlay: !0
					}),
					ne && /* @__PURE__ */ Y("p", {
						className: "gs-m3d__note",
						children: ne
					})
				]
			}),
			/* @__PURE__ */ Y(o, { id: "m3dVoice" }),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						disabled: !j,
						onClick: () => {
							if (!j) return;
							let e = document.createElement("a");
							e.href = j.url, e.download = `${ce}.wav`, e.click();
						},
						children: "Save the WAV"
					}),
					/* @__PURE__ */ Y("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: !j,
						onClick: () => j && s(new File([j.blob], `${ce}.wav`, { type: "audio/wav" })),
						children: "Use this line"
					})
				]
			})
		]
	});
}
//#endregion
//#region src/model3d/GameSection.tsx
var Q = () => {}, us = [
	"solid",
	"through",
	"area"
], ds = {
	solid: "Solid",
	through: "Walk through",
	area: "Trigger area"
};
function fs(e) {
	return e.shapes.flatMap((e) => [{
		id: e.id,
		label: e.name
	}, ...(e.children ?? []).map((t) => ({
		id: t.id,
		label: `${e.name} › ${t.name}`
	}))]);
}
var ps = (e) => e.split(",").map((e) => e.trim()).filter(Boolean), ms = (e) => Math.round(e * 100) / 100;
function hs(e, t, n) {
	let { position: r, target: i } = _(n.camera);
	switch (e) {
		case "say": return {
			kind: e,
			lines: ["…"]
		};
		case "ask": return {
			kind: e,
			options: [{
				text: "Yes",
				flag: "said yes"
			}, {
				text: "No",
				flag: "said no"
			}]
		};
		case "set":
		case "clear": return {
			kind: e,
			flag: "flag"
		};
		case "add": return {
			kind: e,
			variable: "coins",
			by: 1
		};
		case "give":
		case "take": return {
			kind: e,
			item: "key"
		};
		case "show":
		case "hide": return {
			kind: e,
			shape: t
		};
		case "move": return {
			kind: e,
			shape: t,
			by: [
				0,
				2.2,
				0
			],
			seconds: 1
		};
		case "walk": return {
			kind: e,
			shape: t,
			to: [
				0,
				0,
				0
			],
			seconds: 3
		};
		case "react": return {
			kind: e,
			shape: t,
			reaction: "bounce"
		};
		case "camera": return {
			kind: e,
			position: r.toArray().map(ms),
			target: i.toArray().map(ms),
			seconds: 3
		};
		case "title": return {
			kind: e,
			text: "Chapter 1",
			seconds: 3
		};
		case "sound":
		case "music": return {
			kind: e,
			sound: "",
			volume: e === "music" ? .6 : 1
		};
		case "wait": return {
			kind: e,
			seconds: 1
		};
		case "tension": return {
			kind: e,
			by: .2
		};
		case "achieve": return {
			kind: e,
			achievement: "first"
		};
		case "level": return {
			kind: e,
			level: "level 2"
		};
		case "end": return {
			kind: e,
			text: "The end."
		};
	}
}
function gs({ value: e, onChange: t, label: n }) {
	return /* @__PURE__ */ Y("div", {
		className: "gs-m3d__game-triple",
		role: "group",
		"aria-label": n,
		children: [
			"x",
			"y",
			"z"
		].map((r, i) => /* @__PURE__ */ Y("input", {
			type: "number",
			step: .1,
			"aria-label": `${n} ${r}`,
			value: e[i],
			onChange: (n) => t(e.map((e, t) => t === i ? Number(n.target.value) || 0 : e))
		}, r))
	});
}
function _s({ editor: e, doc: t, selected: n, onPlay: r, project: i, projectPanel: a }) {
	let s = t.game ?? Ct(t), c = (t, n) => e.set("game", t, n), [l, u] = q(null), [d, f] = q(null), p = fs(t), m = n?.id ?? p[0]?.id ?? "", h = n ? s.actors?.find((e) => e.shape === n.id) : void 0, g = n ? s.areas?.includes(n.id) ? "area" : s.passable?.includes(n.id) ? "through" : "solid" : null, v = (e) => {
		if (!n) return;
		let t = (e) => (e ?? []).filter((e) => e !== n.id);
		c({
			...s,
			areas: e === "area" ? [...t(s.areas), n.id] : t(s.areas),
			passable: e === "through" ? [...t(s.passable), n.id] : t(s.passable)
		}, ds[e]);
	}, y = (e) => c({
		...s,
		actors: (s.actors ?? []).map((t) => t.shape === h?.shape ? {
			...t,
			...e
		} : t)
	}, "Character"), b = (e, t, n = "Change rule") => c({
		...s,
		rules: s.rules.map((n, r) => r === e ? t : n)
	}, n), x = (e, t, n) => {
		let r = s.rules[e];
		b(e, {
			...r,
			actions: r.actions.map((e, r) => r === t ? n : e)
		}, "Change action");
	}, S = (e, t, n) => /* @__PURE__ */ X("select", {
		"aria-label": n,
		value: e ?? "",
		onChange: (e) => t(e.target.value),
		children: [!p.some((t) => t.id === e) && /* @__PURE__ */ Y("option", {
			value: e ?? "",
			children: "(a shape no longer here)"
		}), p.map((e) => /* @__PURE__ */ Y("option", {
			value: e.id,
			children: e.label
		}, e.id))]
	}), C = i ? Object.entries(i.project.sounds) : [], w = (e, t, n, r) => i ? /* @__PURE__ */ X("select", {
		"aria-label": n,
		value: e,
		onChange: (e) => t(e.target.value),
		children: [/* @__PURE__ */ Y("option", {
			value: "",
			children: r
		}), C.map(([e, t]) => /* @__PURE__ */ Y("option", {
			value: e,
			children: t.name
		}, e))]
	}) : /* @__PURE__ */ Y("input", {
		"aria-label": n,
		placeholder: "a sound's name in the project",
		value: e,
		onChange: (e) => t(e.target.value)
	}), T = (e, n, r) => {
		switch (r.kind) {
			case "say": return /* @__PURE__ */ X(J, { children: [
				/* @__PURE__ */ Y("textarea", {
					rows: Math.min(5, Math.max(2, r.lines.length)),
					"aria-label": "Lines, one a line",
					value: r.lines.join("\n"),
					onChange: (t) => x(e, n, {
						...r,
						lines: t.target.value.split("\n").slice(0, 12)
					})
				}),
				w(r.voice ?? "", (t) => {
					let { voice: i, ...a } = r;
					x(e, n, t ? {
						...a,
						voice: t
					} : a);
				}, "Voice", "No voice"),
				i && /* @__PURE__ */ Y("button", {
					type: "button",
					title: "Type or say the line and pick a voice: no voice actor needed",
					onClick: () => u([e, n]),
					children: "Make the voice…"
				}),
				i && l?.[0] === e && l[1] === n && /* @__PURE__ */ Y(ls, {
					initialText: r.lines.join(" "),
					title: "Voice for these lines",
					onClose: () => u(null),
					onMake: (t) => {
						u(null), i.addSound(t).then((t) => x(e, n, {
							...r,
							voice: t
						})).catch((e) => f(e instanceof Error ? e.message : "The voice could not be added."));
					}
				}),
				d && /* @__PURE__ */ Y("span", {
					className: "gs-m3d__note",
					children: d
				})
			] });
			case "ask": return /* @__PURE__ */ X("div", {
				className: "gs-m3d__game-options",
				children: [r.options.map((t, i) => /* @__PURE__ */ X("div", { children: [/* @__PURE__ */ Y("input", {
					"aria-label": "Choice",
					value: t.text,
					onChange: (t) => x(e, n, {
						...r,
						options: r.options.map((e, n) => n === i ? {
							...e,
							text: t.target.value
						} : e)
					})
				}), /* @__PURE__ */ Y("input", {
					"aria-label": "Sets the flag",
					value: t.flag,
					onChange: (t) => x(e, n, {
						...r,
						options: r.options.map((e, n) => n === i ? {
							...e,
							flag: t.target.value
						} : e)
					})
				})] }, i)), r.options.length < 4 && /* @__PURE__ */ Y("button", {
					type: "button",
					onClick: () => x(e, n, {
						...r,
						options: [...r.options, {
							text: "Maybe",
							flag: "said maybe"
						}]
					}),
					children: "+ Choice"
				})]
			});
			case "set":
			case "clear": return /* @__PURE__ */ Y("input", {
				"aria-label": "Flag",
				value: r.flag,
				onChange: (t) => x(e, n, {
					...r,
					flag: t.target.value
				})
			});
			case "add": return /* @__PURE__ */ Y("div", {
				className: "gs-m3d__game-options",
				children: /* @__PURE__ */ X("div", { children: [/* @__PURE__ */ Y("input", {
					"aria-label": "Number",
					value: r.variable,
					onChange: (t) => x(e, n, {
						...r,
						variable: t.target.value
					})
				}), /* @__PURE__ */ Y("input", {
					type: "number",
					"aria-label": "By",
					value: r.by,
					onChange: (t) => x(e, n, {
						...r,
						by: Number(t.target.value) || 0
					})
				})] })
			});
			case "give":
			case "take": return /* @__PURE__ */ Y("input", {
				"aria-label": "Item",
				value: r.item,
				onChange: (t) => x(e, n, {
					...r,
					item: t.target.value
				})
			});
			case "show":
			case "hide": return S(r.shape, (t) => x(e, n, {
				...r,
				shape: t
			}), "Shape");
			case "move": return /* @__PURE__ */ X(J, { children: [
				S(r.shape, (t) => x(e, n, {
					...r,
					shape: t
				}), "Shape"),
				/* @__PURE__ */ Y(gs, {
					label: "By",
					value: r.by,
					onChange: (t) => x(e, n, {
						...r,
						by: t
					})
				}),
				/* @__PURE__ */ Y(U, {
					onBegin: Q,
					onEnd: Q,
					label: "Seconds",
					value: r.seconds,
					min: 0,
					max: 10,
					step: .1,
					onChange: (t) => x(e, n, {
						...r,
						seconds: t
					})
				})
			] });
			case "walk": return /* @__PURE__ */ X(J, { children: [
				S(r.shape, (t) => x(e, n, {
					...r,
					shape: t
				}), "Character"),
				/* @__PURE__ */ Y(gs, {
					label: "To",
					value: r.to,
					onChange: (t) => x(e, n, {
						...r,
						to: t
					})
				}),
				/* @__PURE__ */ Y(U, {
					onBegin: Q,
					onEnd: Q,
					label: "Seconds",
					value: r.seconds,
					min: .1,
					max: 30,
					step: .1,
					onChange: (t) => x(e, n, {
						...r,
						seconds: t
					})
				})
			] });
			case "react": return /* @__PURE__ */ X(J, { children: [S(r.shape, (t) => x(e, n, {
				...r,
				shape: t
			}), "Shape"), /* @__PURE__ */ Y("select", {
				"aria-label": "Reaction",
				value: r.reaction,
				onChange: (t) => x(e, n, {
					...r,
					reaction: t.target.value
				}),
				children: De.map((e) => /* @__PURE__ */ Y("option", {
					value: e,
					children: je[e]
				}, e))
			})] });
			case "camera": return /* @__PURE__ */ X(J, { children: [
				!!s.shots?.length && /* @__PURE__ */ X("select", {
					"aria-label": "Named shot",
					value: r.shot ?? "",
					onChange: (t) => x(e, n, {
						...r,
						shot: t.target.value || void 0
					}),
					children: [/* @__PURE__ */ Y("option", {
						value: "",
						children: "This view only"
					}), s.shots.map((e) => /* @__PURE__ */ Y("option", {
						value: e.id,
						children: e.name
					}, e.id))]
				}),
				/* @__PURE__ */ Y(gs, {
					label: "From",
					value: r.position,
					onChange: (t) => x(e, n, {
						...r,
						position: t
					})
				}),
				/* @__PURE__ */ Y(gs, {
					label: "Looking at",
					value: r.target,
					onChange: (t) => x(e, n, {
						...r,
						target: t
					})
				}),
				/* @__PURE__ */ Y("button", {
					type: "button",
					onClick: () => {
						let { position: i, target: a } = _(t.camera);
						x(e, n, {
							...r,
							position: i.toArray().map(ms),
							target: a.toArray().map(ms)
						});
					},
					children: "Use the view as it is now"
				}),
				/* @__PURE__ */ Y(U, {
					onBegin: Q,
					onEnd: Q,
					label: "Seconds",
					value: r.seconds,
					min: .2,
					max: 20,
					step: .1,
					onChange: (t) => x(e, n, {
						...r,
						seconds: t
					})
				})
			] });
			case "title": return /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ Y("input", {
				"aria-label": "Title",
				value: r.text,
				onChange: (t) => x(e, n, {
					...r,
					text: t.target.value
				})
			}), /* @__PURE__ */ Y(U, {
				onBegin: Q,
				onEnd: Q,
				label: "Seconds",
				value: r.seconds,
				min: .5,
				max: 15,
				step: .5,
				onChange: (t) => x(e, n, {
					...r,
					seconds: t
				})
			})] });
			case "sound":
			case "music": return /* @__PURE__ */ X(J, { children: [w(r.sound, (t) => x(e, n, {
				...r,
				sound: t
			}), "Sound", r.kind === "music" ? "Stop the music" : "Pick a sound"), /* @__PURE__ */ Y(U, {
				onBegin: Q,
				onEnd: Q,
				label: "Volume",
				value: r.volume,
				min: 0,
				max: 1,
				step: .05,
				onChange: (t) => x(e, n, {
					...r,
					volume: t
				})
			})] });
			case "wait": return /* @__PURE__ */ Y(U, {
				onBegin: Q,
				onEnd: Q,
				label: "Seconds",
				value: r.seconds,
				min: 0,
				max: 30,
				step: .1,
				onChange: (t) => x(e, n, {
					...r,
					seconds: t
				})
			});
			case "tension": return /* @__PURE__ */ Y(U, {
				onBegin: Q,
				onEnd: Q,
				label: "By",
				value: r.by,
				min: -1,
				max: 1,
				step: .05,
				onChange: (t) => x(e, n, {
					...r,
					by: t
				})
			});
			case "achieve": {
				let t = i?.project.achievements ?? [];
				return t.length ? /* @__PURE__ */ X("select", {
					"aria-label": "Achievement",
					value: r.achievement,
					onChange: (t) => x(e, n, {
						...r,
						achievement: t.target.value
					}),
					children: [!t.some((e) => e.id === r.achievement) && /* @__PURE__ */ Y("option", {
						value: r.achievement,
						children: "(pick one)"
					}), t.map((e) => /* @__PURE__ */ Y("option", {
						value: e.id,
						children: e.title
					}, e.id))]
				}) : /* @__PURE__ */ Y("input", {
					"aria-label": "Achievement's id",
					title: "Add achievements under Game project, then pick one here",
					value: r.achievement,
					onChange: (t) => x(e, n, {
						...r,
						achievement: t.target.value.replace(/[^\w-]/g, "")
					})
				});
			}
			case "level": return i ? /* @__PURE__ */ X("select", {
				"aria-label": "Level",
				value: r.level,
				onChange: (t) => x(e, n, {
					...r,
					level: t.target.value
				}),
				children: [!i.project.levels.some((e) => e.id === r.level) && /* @__PURE__ */ Y("option", {
					value: r.level,
					children: "(pick a level)"
				}), i.project.levels.map((e) => /* @__PURE__ */ Y("option", {
					value: e.id,
					children: e.name
				}, e.id))]
			}) : /* @__PURE__ */ Y("input", {
				"aria-label": "Level",
				value: r.level,
				onChange: (t) => x(e, n, {
					...r,
					level: t.target.value
				})
			});
			case "end": return /* @__PURE__ */ Y("input", {
				"aria-label": "Last words",
				value: r.text,
				onChange: (t) => x(e, n, {
					...r,
					text: t.target.value
				})
			});
		}
	};
	return /* @__PURE__ */ X("div", {
		className: "gs-m3d__panel",
		children: [
			/* @__PURE__ */ X("section", { children: [
				/* @__PURE__ */ Y("h4", { children: "Play" }),
				/* @__PURE__ */ Y(o, { id: "m3dGame" }),
				/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn gs-m3d__btn--primary",
					onClick: r,
					children: "▶ Play game"
				})
			] }),
			a,
			/* @__PURE__ */ Y(Hr, {
				game: s,
				put: c,
				shapes: p,
				spots: p.filter((e) => t.shapes.some((t) => t.id === e.id && t.name.startsWith("spot:"))).map((e) => ({
					...e,
					label: e.label.replace(/^spot:/, "")
				}))
			}),
			/* @__PURE__ */ Y(Wr, {
				game: s,
				put: c,
				doc: t,
				editor: e
			}),
			/* @__PURE__ */ Y(Gr, {
				game: s,
				put: c,
				doc: t,
				editor: e
			}),
			/* @__PURE__ */ Y(Kr, {
				game: s,
				put: c,
				editor: e
			}),
			/* @__PURE__ */ Y(Ur, {
				game: s,
				put: c,
				shapes: p
			}),
			/* @__PURE__ */ Y(qr, {
				doc: t,
				game: s
			}),
			/* @__PURE__ */ X("section", { children: [
				/* @__PURE__ */ Y("h4", { children: "Player start" }),
				/* @__PURE__ */ X("p", {
					className: "gs-m3d__note",
					children: [
						"Feet at ",
						s.player.position.map((e) => e.toFixed(1)).join(", "),
						", facing ",
						Math.round(s.player.yaw),
						"°."
					]
				}),
				/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => c({
						...s,
						player: {
							...s.player,
							...Ct(t).player,
							eye: s.player.eye,
							speed: s.player.speed
						}
					}, "Player start"),
					children: "Start where the view is"
				}),
				/* @__PURE__ */ Y(U, {
					onBegin: Q,
					onEnd: Q,
					label: "Eye height",
					value: s.player.eye,
					min: .3,
					max: 3,
					step: .05,
					onChange: (e) => c({
						...s,
						player: {
							...s.player,
							eye: e
						}
					}, "Eye height")
				}),
				/* @__PURE__ */ Y(U, {
					onBegin: Q,
					onEnd: Q,
					label: "Speed",
					value: s.player.speed,
					min: .5,
					max: 6,
					step: .1,
					onChange: (e) => c({
						...s,
						player: {
							...s.player,
							speed: e
						}
					}, "Speed")
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__check",
					children: [
						/* @__PURE__ */ Y("input", {
							type: "checkbox",
							checked: !!s.player.jump,
							onChange: (e) => {
								let { jump: t, ...n } = s.player;
								c({
									...s,
									player: e.target.checked ? {
										...n,
										jump: Math.round(s.player.eye * 40) / 10
									} : n
								}, "Jumping");
							}
						}),
						" ",
						"Jumping and falling"
					]
				}),
				!!s.player.jump && /* @__PURE__ */ Y(U, {
					onBegin: Q,
					onEnd: Q,
					label: "Jump",
					value: s.player.jump,
					min: 1,
					max: 16,
					step: .1,
					format: (e) => e.toFixed(1),
					onChange: (e) => c({
						...s,
						player: {
							...s.player,
							jump: e
						}
					}, "Jump")
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__check",
					children: [
						/* @__PURE__ */ Y("input", {
							type: "checkbox",
							checked: !!s.player.third,
							onChange: (e) => {
								let { third: t, ...n } = s.player;
								c({
									...s,
									player: e.target.checked ? {
										...n,
										third: !0
									} : n
								}, "View");
							}
						}),
						" ",
						"Seen from behind (third person)"
					]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: "Who you play" }), /* @__PURE__ */ X("select", {
						value: s.player.shape ?? "",
						onChange: (e) => {
							let { shape: t, ...n } = s.player;
							c({
								...s,
								player: e.target.value ? {
									...n,
									shape: e.target.value
								} : n
							}, "Who you play");
						},
						children: [/* @__PURE__ */ Y("option", {
							value: "",
							children: "Nobody seen"
						}), t.shapes.map((e) => /* @__PURE__ */ Y("option", {
							value: e.id,
							children: e.name
						}, e.id))]
					})]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: "Numbers on screen" }), /* @__PURE__ */ Y("input", {
						value: (s.hud ?? []).join(", "),
						placeholder: "coins, lives",
						onChange: (e) => {
							let t = e.target.value.split(",").map((e) => e.trim()), { hud: n, ...r } = s;
							c(t.some(Boolean) ? {
								...r,
								hud: t.filter(Boolean)
							} : r, "Numbers on screen");
						}
					})]
				}),
				/* @__PURE__ */ Y(U, {
					onBegin: Q,
					onEnd: Q,
					label: "Tension at the start",
					value: s.tension ?? 0,
					min: 0,
					max: 1,
					step: .05,
					onChange: (e) => c({
						...s,
						tension: e
					}, "Tension")
				}),
				/* @__PURE__ */ Y(o, { id: "m3dPlayerStart" })
			] }),
			/* @__PURE__ */ X("section", { children: [
				/* @__PURE__ */ Y("h4", { children: "The picked shape, to the player" }),
				n && g ? /* @__PURE__ */ Y(W, {
					label: "To the player",
					value: g,
					options: us,
					labels: ds,
					onChange: v
				}) : /* @__PURE__ */ Y("p", {
					className: "gs-m3d__note",
					children: "Pick a shape to make it something the player walks through, or an invisible area that sets off rules."
				}),
				/* @__PURE__ */ Y(o, { id: "m3dGameAreas" }),
				h && /* @__PURE__ */ X(J, { children: [
					/* @__PURE__ */ X("p", {
						className: "gs-m3d__note",
						children: [
							"A placed character: ",
							i?.project.characters.find((e) => e.id === h.character)?.name ?? h.character,
							"."
						]
					}),
					/* @__PURE__ */ X("label", {
						className: "gs-m3d__check",
						children: [/* @__PURE__ */ Y("input", {
							type: "checkbox",
							checked: !!h.faces,
							onChange: (e) => y({ faces: e.target.checked || void 0 })
						}), "Turns to face the player"]
					}),
					/* @__PURE__ */ X("label", {
						className: "gs-m3d__check",
						children: [/* @__PURE__ */ Y("input", {
							type: "checkbox",
							checked: !!h.creeps,
							onChange: (e) => y({ creeps: e.target.checked || void 0 })
						}), "Comes closer while not looked at"]
					}),
					/* @__PURE__ */ X("label", {
						className: "gs-m3d__check",
						children: [/* @__PURE__ */ Y("input", {
							type: "checkbox",
							checked: !!h.follows,
							onChange: (e) => y({ follows: e.target.checked || void 0 })
						}), "Follows the player"]
					}),
					/* @__PURE__ */ X("label", {
						className: "gs-m3d__check",
						children: [/* @__PURE__ */ Y("input", {
							type: "checkbox",
							checked: !!h.wanders,
							onChange: (e) => y({ wanders: e.target.checked || void 0 })
						}), "Wanders about"]
					}),
					/* @__PURE__ */ Y(ys, {
						idle: h.idle,
						onChange: (e) => y({ idle: e })
					}),
					/* @__PURE__ */ Y(U, {
						onBegin: Q,
						onEnd: Q,
						label: "Melts with the tension",
						value: h.melt ?? 0,
						min: 0,
						max: .5,
						step: .01,
						onChange: (e) => y({ melt: e || void 0 })
					})
				] })
			] }),
			/* @__PURE__ */ X("section", { children: [
				/* @__PURE__ */ Y("h4", { children: "Rules" }),
				/* @__PURE__ */ Y(o, { id: "m3dGameRules" }),
				s.rules.map((e, n) => /* @__PURE__ */ X("div", {
					className: "gs-m3d__game-rule",
					children: [
						/* @__PURE__ */ X("div", {
							className: "gs-m3d__field",
							children: [/* @__PURE__ */ Y("span", { children: "When" }), /* @__PURE__ */ Y("select", {
								"aria-label": "When",
								value: e.on,
								onChange: (t) => {
									let r = t.target.value, { shape: i, also: a, seconds: o, flag: s, ...c } = e;
									b(n, {
										...c,
										on: r,
										...ce.includes(r) ? { shape: e.shape ?? m } : {},
										...r === "time" ? { seconds: 5 } : {},
										...r === "flag" ? { flag: "said yes" } : {}
									});
								},
								children: oe.map((e) => /* @__PURE__ */ Y("option", {
									value: e,
									children: Gt[e]
								}, e))
							})]
						}),
						ce.includes(e.on) && /* @__PURE__ */ X("div", {
							className: "gs-m3d__field",
							children: [S(e.shape, (t) => b(n, {
								...e,
								shape: t
							}), "Shape"), !!e.also?.length && /* @__PURE__ */ X("span", {
								className: "gs-m3d__note",
								children: [
									"and ",
									e.also.length,
									" more of its name"
								]
							})]
						}),
						e.on === "flag" && /* @__PURE__ */ X("label", {
							className: "gs-m3d__field",
							children: [/* @__PURE__ */ Y("span", { children: "Flag" }), /* @__PURE__ */ Y("input", {
								value: e.flag ?? "",
								onChange: (t) => b(n, {
									...e,
									flag: t.target.value
								})
							})]
						}),
						e.on === "time" && /* @__PURE__ */ Y(U, {
							onBegin: Q,
							onEnd: Q,
							label: "Seconds",
							value: e.seconds ?? 5,
							min: 0,
							max: 120,
							step: 1,
							onChange: (t) => b(n, {
								...e,
								seconds: t
							})
						}),
						/* @__PURE__ */ X("label", {
							className: "gs-m3d__field",
							children: [/* @__PURE__ */ Y("span", { children: "If" }), /* @__PURE__ */ Y("input", {
								placeholder: "flags it needs, with commas",
								value: (e.if ?? []).join(", "),
								onChange: (t) => b(n, {
									...e,
									if: ps(t.target.value)
								})
							})]
						}),
						/* @__PURE__ */ X("label", {
							className: "gs-m3d__field",
							children: [/* @__PURE__ */ Y("span", { children: "Unless" }), /* @__PURE__ */ Y("input", {
								placeholder: "flags that stop it",
								value: (e.unless ?? []).join(", "),
								onChange: (t) => b(n, {
									...e,
									unless: ps(t.target.value)
								})
							})]
						}),
						/* @__PURE__ */ X("label", {
							className: "gs-m3d__field",
							children: [/* @__PURE__ */ Y("span", { children: "Has" }), /* @__PURE__ */ Y("input", {
								placeholder: "items the player carries",
								value: (e.has ?? []).join(", "),
								onChange: (t) => b(n, {
									...e,
									has: ps(t.target.value)
								})
							})]
						}),
						(e.need ?? []).map((t, r) => /* @__PURE__ */ Y("div", {
							className: "gs-m3d__game-options",
							children: /* @__PURE__ */ X("div", { children: [/* @__PURE__ */ Y("input", {
								"aria-label": "Number",
								value: t.variable,
								onChange: (t) => b(n, {
									...e,
									need: e.need.map((e, n) => n === r ? {
										...e,
										variable: t.target.value
									} : e)
								})
							}), /* @__PURE__ */ X("span", {
								className: "gs-m3d__game-need",
								children: [
									/* @__PURE__ */ Y("select", {
										"aria-label": "Is",
										value: t.op,
										onChange: (t) => b(n, {
											...e,
											need: e.need.map((e, n) => n === r ? {
												...e,
												op: t.target.value
											} : e)
										}),
										children: it.map((e) => /* @__PURE__ */ Y("option", {
											value: e,
											children: e
										}, e))
									}),
									/* @__PURE__ */ Y("input", {
										type: "number",
										"aria-label": "Value",
										value: t.value,
										onChange: (t) => b(n, {
											...e,
											need: e.need.map((e, n) => n === r ? {
												...e,
												value: Number(t.target.value) || 0
											} : e)
										})
									}),
									/* @__PURE__ */ Y("button", {
										type: "button",
										"aria-label": "Remove the need",
										onClick: () => b(n, {
											...e,
											need: e.need.filter((e, t) => t !== r)
										}),
										children: "✕"
									})
								]
							})] })
						}, r)),
						/* @__PURE__ */ Y("button", {
							type: "button",
							onClick: () => b(n, {
								...e,
								need: [...e.need ?? [], {
									variable: "coins",
									op: ">=",
									value: 1
								}]
							}),
							children: "+ Needs a number"
						}),
						/* @__PURE__ */ X("label", {
							className: "gs-m3d__check",
							children: [/* @__PURE__ */ Y("input", {
								type: "checkbox",
								checked: !!e.once,
								onChange: (t) => b(n, {
									...e,
									once: t.target.checked || void 0
								})
							}), "Only the first time"]
						}),
						/* @__PURE__ */ Y("ol", {
							className: "gs-m3d__game-actions",
							children: e.actions.map((t, r) => /* @__PURE__ */ X("li", { children: [/* @__PURE__ */ X("div", {
								className: "gs-m3d__game-actionhead",
								children: [/* @__PURE__ */ Y("span", { children: ze[t.kind] }), /* @__PURE__ */ Y("button", {
									type: "button",
									"aria-label": "Remove the action",
									onClick: () => b(n, {
										...e,
										actions: e.actions.filter((e, t) => t !== r)
									}, "Remove action"),
									children: "✕"
								})]
							}), T(n, r, t)] }, r))
						}),
						/* @__PURE__ */ X("div", {
							className: "gs-m3d__game-ruletools",
							children: [/* @__PURE__ */ X("select", {
								"aria-label": "Add an action",
								value: "",
								onChange: (r) => {
									let i = r.target.value;
									i && b(n, {
										...e,
										actions: [...e.actions, hs(i, e.shape ?? m, t)]
									}, "Add action");
								},
								children: [/* @__PURE__ */ Y("option", {
									value: "",
									children: "+ Action…"
								}), H.map((e) => /* @__PURE__ */ Y("option", {
									value: e,
									children: ze[e]
								}, e))]
							}), /* @__PURE__ */ Y("button", {
								type: "button",
								onClick: () => c({
									...s,
									rules: s.rules.filter((e, t) => t !== n)
								}, "Remove rule"),
								children: "Remove rule"
							})]
						})
					]
				}, e.id)),
				/* @__PURE__ */ X("button", {
					type: "button",
					className: "gs-m3d__btn",
					disabled: !p.length,
					onClick: () => c({
						...s,
						rules: [...s.rules, {
							id: `rule${Date.now().toString(36)}`,
							on: "use",
							shape: m,
							actions: [{
								kind: "say",
								lines: [`${p.find((e) => e.id === m)?.label ?? "It"}: Hello.`]
							}]
						}]
					}, "New rule"),
					children: ["+ New rule", n ? `: using “${n.name}”` : ""]
				})
			] })
		]
	});
}
var vs = () => nr.map((e) => e.id);
function ys({ idle: e, onChange: t }) {
	let [n, r] = q((e?.moves ?? []).join(", ")), i = (n) => {
		let r = {
			moves: [],
			every: 30,
			for: 8,
			...e,
			...n
		};
		t(r.moves.length || r.talk ? r : void 0);
	};
	return /* @__PURE__ */ X("div", {
		className: "gs-m3d__panel",
		children: [
			/* @__PURE__ */ Y("strong", { children: "Standing about" }),
			/* @__PURE__ */ Y(o, { id: "m3dIdle" }),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [
					/* @__PURE__ */ Y("span", { children: "Now and then" }),
					/* @__PURE__ */ Y("input", {
						list: "gs-idle-moves",
						"aria-label": "Moves it does now and then, by name, with commas",
						placeholder: "phone, look, think",
						value: n,
						onChange: (e) => {
							r(e.target.value), i({ moves: e.target.value.split(",").map((e) => e.trim()).filter((e) => vs().includes(e)) });
						}
					}),
					/* @__PURE__ */ Y("datalist", {
						id: "gs-idle-moves",
						children: vs().map((e) => /* @__PURE__ */ Y("option", { value: e }, e))
					})
				]
			}),
			/* @__PURE__ */ Y(U, {
				onBegin: Q,
				onEnd: Q,
				label: "Every (seconds)",
				value: e?.every ?? 30,
				min: 4,
				max: 120,
				step: 1,
				onChange: (t) => i({
					every: t,
					for: Math.min(e?.for ?? 8, t - 1)
				})
			}),
			/* @__PURE__ */ Y(U, {
				onBegin: Q,
				onEnd: Q,
				label: "For (seconds)",
				value: e?.for ?? 8,
				min: 1,
				max: Math.max(2, (e?.every ?? 30) - 1),
				step: .5,
				onChange: (e) => i({ for: e })
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__check",
				children: [/* @__PURE__ */ Y("input", {
					type: "checkbox",
					checked: !!e?.talk,
					onChange: (e) => i({ talk: e.target.checked || void 0 })
				}), "Takes turns in a conversation"]
			})
		]
	});
}
//#endregion
//#region src/model3d/characterBuilder.ts
var bs = {
	decode: async (e, t) => {
		let n = await createImageBitmap(new Blob([e], { type: t })), r = document.createElement("canvas");
		r.width = n.width, r.height = n.height;
		let i = r.getContext("2d", { willReadFrequently: !0 });
		return i.drawImage(n, 0, 0), n.close(), {
			width: r.width,
			height: r.height,
			data: i.getImageData(0, 0, r.width, r.height).data
		};
	},
	encode: async (e, t, n) => {
		let r = document.createElement("canvas");
		r.width = e, r.height = t, r.getContext("2d").putImageData(new ImageData(new Uint8ClampedArray(n), e, t), 0, 0);
		let i = await new Promise((e, t) => r.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be made.")), "image/png"));
		return {
			bytes: new Uint8Array(await i.arrayBuffer()),
			mime: "image/png"
		};
	}
}, xs = (e, t) => e.models.find((e) => e.id === t) ?? e.models[0];
function Ss(e) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map(), r = null, i = (t) => fetch(`${e}${t}`).then((e) => {
		if (!e.ok) throw Error(`${t}: ${e.status}`);
		return e.arrayBuffer();
	}), a = (e) => (t.has(e) || t.set(e, i(e).then((e) => k(new Uint8Array(e)))), t.get(e)), o = (e) => (n.has(e) || n.set(e, i(e)), n.get(e));
	return {
		index() {
			return r ??= Promise.all([fetch(`${e}index.json`).then((e) => {
				if (!e.ok) throw Error(String(e.status));
				return e.json();
			}), fetch(`${e}own.json`).then((e) => e.ok && /json/.test(e.headers.get("content-type") ?? "") ? e.json() : null).catch(() => null)]).then(([e, t]) => t?.models?.length ? {
				...e,
				models: [...e.models, ...t.models]
			} : e), r;
		},
		async build(e) {
			let t = await this.index(), n = e.kit ? t.kits?.find((t) => t.id === e.kit && t.models.length) : void 0;
			if (n) {
				let t = n.slots.flatMap((t) => {
					let r = xs(n, e.pieces?.[t])?.pieces[t];
					return r ? [r] : [];
				}), r = await Promise.all(t.map((e) => a(e.file))), { asset: i, roles: o } = bt(t.map((e, t) => ({
					part: e,
					asset: r[t]
				}))), s = await Ue(i, o, e.colours, bs), { min: c, max: l } = ee(s.parts);
				return {
					glb: j(s),
					headSize: (l[1] - c[1] || 1.7) / 7.5
				};
			}
			let r = new Map(t.models.map((e) => [e.id, e])), i = Object.fromEntries(Object.entries(e.features ?? {}).flatMap(([t, n]) => n && r.has(n) && n !== e.face ? [[t, r.get(n)]] : [])), s = {
				body: r.get(e.body),
				face: r.get(e.face),
				hair: r.get(e.hair),
				features: i
			};
			if (!s.body || !s.face || !s.hair) throw Error("This character uses parts the library no longer has.");
			let c = (e) => e.skin ? o(e.skin.file).then(I) : Promise.resolve(null), [l, u, d] = await Promise.all([
				c(s.body),
				c(s.face),
				c(s.hair)
			]), [f, p, m, h, g, ..._] = await Promise.all([
				a(s.body.body.file),
				a(s.face.face.file),
				a(s.hair.hair.file),
				o(s.face.face.moves),
				s.body.body.legs ? o(s.body.body.legs) : Promise.resolve(null),
				...Object.values(i).map((e) => a(e.face.file))
			]), v = Object.fromEntries(Object.keys(i).map((e, t) => [e, _[t]])), { asset: y, roles: b, layers: x, look: S } = P(s, {
				body: f,
				face: p,
				hair: m,
				moves: h,
				legs: g ? new Uint8Array(g) : void 0,
				features: v,
				...l && u && d ? { skins: {
					body: l,
					face: u,
					hair: d
				} } : {}
			}, e), C = await st(await Ue(y, b, e.colours, bs, e.wardrobe), S, {
				makeup: e.makeup,
				eyes: e.eyes,
				irisColour: e.colours.iris,
				facePaint: e.facePaint,
				hairColour: e.colours.hair
			}, bs), w = e.hidden?.length ? Ee(C, x, Re.filter((t) => !e.hidden.includes(t))) : C, T = 1 + (e.shape.head ?? 0) * ((e.shape.head ?? 0) >= 0 ? .5 : .2);
			return {
				glb: j(w),
				headSize: s.body.headSize * T
			};
		}
	};
}
var Cs = /* @__PURE__ */ new Map();
function ws(e) {
	let t = `${e.endsWith("/") ? e : `${e}/`}characters/`;
	return Cs.has(t) || Cs.set(t, Ss(t)), Cs.get(t);
}
//#endregion
//#region src/model3d/AvatarDialog.tsx
var Ts = ["character", "made"], Es = {
	character: "A character's",
	made: "Made by Gleamshelf"
}, Ds = {
	body: "Outfit",
	face: "Face",
	eyes: "Eyes",
	mouth: "Mouth",
	hair: "Hair",
	shape: "Shape",
	details: "Makeup",
	colours: "Colours"
}, Os = Object.keys(Ds), ks = Object.keys(V), As = Object.fromEntries(ks.map((e) => [e, V[e].label])), js = Object.keys(B), Ms = [
	"eyes",
	"lashes",
	"brows"
], Ns = ["mouth", "makeup"], Ps = {
	head: "Head",
	top: "Top",
	legs: "Legs",
	feet: "Shoes",
	body: "Body"
}, Fs = {
	eyes: "eyes",
	lashes: "eyes",
	brows: "eyes",
	mouth: "mouth",
	makeup: "face"
}, Is = [
	"#2a1d1a",
	"#5b3428",
	"#f29ac0",
	"#7fd1b9",
	"#e8e4f2",
	"#f0a24a",
	"#2b3550",
	"#c94f5f",
	"#f3d36b",
	"#8b6fd1"
], Ls = [
	"#b4553a",
	"#2e8a72",
	"#c23b4e",
	"#3f7fd9",
	"#7b6fd6",
	"#c0571e",
	"#4a8f3a",
	"#e0688f"
], Rs = [
	"#f4f1ea",
	"#3c5a8c",
	"#c23b4e",
	"#2d2a40",
	"#f2c14e",
	"#4f8f7a",
	"#e8a0b4",
	"#3b3b44"
], zs = (e) => e[Math.floor(Math.random() * e.length)];
function Bs(e, t, n, r) {
	let i = In("Character", e), a = ue(), o = i.size[1];
	return {
		...a,
		shapes: [L("mesh", 0, {
			asset: "m",
			ownColors: !0,
			size: i.size,
			position: [
				i.centre[0],
				i.size[1] / 2,
				i.centre[2]
			]
		})],
		assets: { m: i },
		light: {
			...a.light,
			azimuth: -25,
			elevation: 35,
			intensity: 1.3,
			ambient: .6,
			color: "#fff8f2"
		},
		background: {
			transparent: !1,
			color: "#f6f1ec",
			picture: ""
		},
		ground: {
			on: !0,
			shadow: .25
		},
		camera: n ? {
			...a.camera,
			yaw: t,
			pitch: 2,
			target: [
				0,
				o - r * .62,
				0
			],
			distance: r * 3.8,
			fov: 35
		} : {
			...a.camera,
			yaw: t,
			pitch: 4,
			target: [
				0,
				o * .5,
				0
			],
			distance: o * 2.1,
			fov: 35
		}
	};
}
var Vs = "The characters come with the 3D library: start the Gleamshelf app on this computer (it brings the library), or open 3D mode on the Gleamshelf website.", Hs = "gleamshelf:looks", Us = () => {
	try {
		let e = JSON.parse(localStorage.getItem(Hs) ?? "[]");
		return Array.isArray(e) ? e.filter((e) => typeof e?.name == "string" && e.choice) : [];
	} catch {
		return [];
	}
}, Ws = (e) => {
	try {
		localStorage.setItem(Hs, JSON.stringify(e));
	} catch {}
};
function Gs(e, t) {
	let n = xs(e, t);
	return Object.fromEntries(e.slots.map((t) => [t, n.pieces[t] ? n.id : e.models.find((e) => e.build === n.build && e.pieces[t])?.id ?? n.id]));
}
function Ks({ base: e, forGame: t = !1, start: n, startTab: r, onMake: i, onClose: a }) {
	let s = e ? `${e.endsWith("/") ? e : `${e}/`}characters/` : "", [c, l] = q(null), [u, d] = q(null), [f, p] = q(r ?? "body"), [m, h] = q("eyes"), [g, _] = q("mouth"), [v, b] = q(null), [x, S] = q(Us), [C, w] = q(null), [T, E] = q(15), [D, O] = q(!1), [k, A] = q(!1), j = K(null), M = K(null), ee = Xr(() => ws(e ?? ""), [e]), te = K(null);
	G(() => {
		if (!s) return;
		let e = !0;
		return ee.index().then((t) => {
			if (!e) return;
			l(t);
			let r = t.models[0];
			b(n ?? {
				name: "My character",
				body: r.id,
				face: r.id,
				hair: r.id,
				expression: "smile",
				shape: {},
				colours: {}
			});
		}).catch(() => e && d("The characters could not be opened here.")), () => {
			e = !1;
		};
	}, [ee]), G(() => () => M.current?.dispose(), []);
	let ne = Xr(() => new Map((c?.models ?? []).map((e) => [e.id, e])), [c]), P = Xr(() => new Map((c?.kits ?? []).filter((e) => e.models.length).map((e) => [e.id, e])), [c]), re = (e) => ee.build(e);
	if (G(() => {
		if (!v || !c) return;
		let e = !0, t = window.setTimeout(async () => {
			try {
				let { glb: t, headSize: n } = await re(v);
				if (!e) return;
				let r = j.current;
				if (!r) return;
				M.current ??= new y();
				let i = await M.current.paint(Bs(t, T, D, n), r.width, r.height);
				e && r.getContext("2d").drawImage(i, 0, 0, r.width, r.height);
			} catch {
				e && d("The preview could not be drawn.");
			}
		}, 120);
		return () => {
			e = !1, window.clearTimeout(t);
		};
	}, [
		v,
		c,
		T,
		D
	]), !c || !v) return /* @__PURE__ */ Y(uo, {
		title: "Character creator",
		onClose: a,
		children: /* @__PURE__ */ Y("p", {
			className: "gs-m3d__meta",
			children: (s ? u : Vs) ?? "Opening the characters…"
		})
	});
	let F = (e) => b((t) => t && {
		...t,
		...e
	}), I = v.kit ? P.get(v.kit) : void 0, ie = ["anime", ...P.keys()], ae = {
		anime: "Anime",
		...Object.fromEntries([...P.values()].map((e) => [e.id, e.label]))
	}, oe = !I || I.models.some((e) => Object.values(e.pieces).some((e) => e.roles.some((e) => ht.includes(e)))), L = I ? [...I.slots, ...oe ? ["colours"] : []] : Os, ce = I ? {
		...Ds,
		...Ps
	} : Ds, le = L.includes(f) ? f : L[0], ue = (e) => {
		if (e === (I?.id ?? "anime")) return;
		let t = P.get(e);
		p(t ? t.slots[0] : "body"), F(t ? {
			kit: t.id,
			pieces: Gs(t, v.pieces?.[t.slots[0]] ?? t.models[0].id),
			colours: {}
		} : {
			kit: void 0,
			pieces: void 0,
			colours: {}
		});
	}, fe = () => {
		let e = v.name.trim() || `Look ${x.length + 1}`, t;
		try {
			let e = j.current;
			if (e) {
				let n = document.createElement("canvas");
				n.width = 60, n.height = 84, n.getContext("2d").drawImage(e, 0, 0, 60, 84), t = n.toDataURL("image/jpeg", .7);
			}
		} catch {}
		let n = [...x.filter((t) => t.name !== e), {
			name: e,
			choice: structuredClone(v),
			thumb: t
		}];
		S(n), Ws(n), w(null);
	}, pe = (e) => {
		let t = e.choice, n = [
			t.body,
			t.face,
			t.hair,
			...Object.values(t.features ?? {})
		].filter(Boolean);
		(t.kit ? !P.has(t.kit) : n.some((e) => !ne.has(e))) ? w("That look uses parts this library does not have.") : (b(structuredClone(t)), p(t.kit ? P.get(t.kit)?.slots[0] ?? "body" : "body"), w(null));
	}, me = (e) => {
		let t = x.filter((t) => t.name !== e);
		S(t), Ws(t);
	}, he = () => {
		if (I) {
			let e = zs(I.models), t = I.models.filter((t) => t.build === e.build), n = Object.fromEntries(I.slots.map((n) => {
				let r = t.filter((e) => e.pieces[n]);
				return [n, (r.length ? zs(r) : e).id];
			}));
			b({
				...v,
				pieces: n,
				colours: Math.random() < .6 ? {
					top: zs(Rs),
					hair: zs(Is)
				} : {}
			});
			return;
		}
		let e = () => zs(c.models).id, t = B[zs([
			"chibi",
			"cute",
			"cute",
			"made",
			"glam",
			"tall"
		])].shape;
		b({
			name: v.name,
			body: e(),
			face: e(),
			hair: e(),
			features: Object.fromEntries([
				"eyes",
				"lashes",
				"brows",
				"mouth",
				"makeup"
			].flatMap((t) => Math.random() < .4 ? [[t, e()]] : [])),
			expression: zs(ks),
			shape: Object.fromEntries(de.map((e) => [e, Math.max(-1, Math.min(1, Math.round(((t[e] ?? 0) + Math.random() * .3 - .15) * 20) / 20))])),
			colours: {
				hair: zs(Is),
				iris: zs(Ls),
				...Math.random() < .5 ? { top: zs(Rs) } : {}
			}
		});
	}, ge = async (e) => {
		A(!0);
		try {
			let { glb: t } = await re(v), n = v.name.trim() || "Character", r;
			if (I) {
				let e = [...new Set(I.slots.map((e) => xs(I, v.pieces?.[e])))];
				r = `${e.map((e) => e.name).join(", ")} (${e[0].author}, ${e[0].licence})`;
			} else {
				let e = [
					v.body,
					v.face,
					v.hair,
					...Object.values(v.features ?? {})
				].filter((e) => !!e);
				r = `${[...new Set(e.map((e) => ne.get(e)?.name ?? e))].join(", ")} (VRoid samples by pixiv Inc., CC0)`;
			}
			i(new File([t], `${n}.glb`, { type: "model/gltf-binary" }), e, `${n}: made from ${r}. Animations can make it move.`, v);
		} catch {
			d("The character could not be made.");
		} finally {
			A(!1);
		}
	}, _e = (e) => /* @__PURE__ */ Y("div", {
		className: "gs-avatar__grid",
		children: c.models.map((t) => /* @__PURE__ */ X("button", {
			type: "button",
			className: `gs-library__item${v[e] === t.id ? " is-on" : ""}`,
			onClick: () => F({ [e]: t.id }),
			title: t.name,
			children: [/* @__PURE__ */ Y("img", {
				src: `${s}${t.thumbs[e]}`,
				alt: "",
				loading: "lazy"
			}), /* @__PURE__ */ Y("span", { children: t.name })]
		}, t.id))
	}), ve = (e) => {
		let t = (t) => {
			let n = {
				...e,
				...t
			};
			F({ facePaint: n.lines || n.brows ? n : void 0 });
		}, n = (e, t, n, r, i) => /* @__PURE__ */ X("div", {
			className: "gs-anim__moves",
			role: "group",
			"aria-label": e,
			children: [/* @__PURE__ */ Y("button", {
				type: "button",
				className: `gs-m3d__btn${t ? "" : " is-on"}`,
				onClick: () => i(void 0),
				children: "As drawn"
			}), n.map((e) => /* @__PURE__ */ Y("button", {
				type: "button",
				className: `gs-m3d__btn${t === e ? " is-on" : ""}`,
				onClick: () => i(e),
				children: r[e]
			}, e))]
		});
		return /* @__PURE__ */ X(J, { children: [
			/* @__PURE__ */ Y("h5", {
				className: "gs-m3d__subhead",
				children: "Eye lines and brows"
			}),
			/* @__PURE__ */ Y(o, { id: "m3dFaceLines" }),
			n("Eye lines", e.lines, ft, $e, (e) => t({ lines: e })),
			e.lines && /* @__PURE__ */ X(J, { children: [
				/* @__PURE__ */ Y(U, {
					label: "Lashes",
					value: e.lashes ?? .5,
					min: 0,
					max: 1,
					step: .05,
					onBegin: () => void 0,
					onEnd: () => void 0,
					onChange: (e) => t({ lashes: e })
				}),
				/* @__PURE__ */ Y(U, {
					label: "Lower lashes",
					value: e.lower ?? .3,
					min: 0,
					max: 1,
					step: .05,
					onBegin: () => void 0,
					onEnd: () => void 0,
					onChange: (e) => t({ lower: e })
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__check",
					children: [/* @__PURE__ */ Y("input", {
						type: "checkbox",
						checked: e.crease === !0,
						onChange: (e) => t({ crease: e.target.checked || void 0 })
					}), " Double lid crease"]
				})
			] }),
			n("Brows", e.brows, Tt, mt, (e) => t({ brows: e })),
			e.brows && /* @__PURE__ */ Y(U, {
				label: "Brow weight",
				value: e.browWeight ?? 0,
				min: -1,
				max: 1,
				step: .05,
				onBegin: () => void 0,
				onEnd: () => void 0,
				onChange: (e) => t({ browWeight: e })
			})
		] });
	}, ye = (e) => {
		let t = (t) => F({ madeHair: {
			...e,
			...t
		} }), n = (n, r, i, a) => /* @__PURE__ */ Y(U, {
			label: r,
			value: e[n],
			min: i,
			max: a,
			step: .05,
			onBegin: () => void 0,
			onChange: (e) => t({ [n]: e }),
			onEnd: () => void 0
		}, n);
		return /* @__PURE__ */ X(J, { children: [
			/* @__PURE__ */ Y(o, { id: "m3dMadeHair" }),
			/* @__PURE__ */ Y("div", {
				className: "gs-anim__moves",
				role: "group",
				"aria-label": "Hairstyle",
				children: Object.entries(Pe).map(([n, r]) => /* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => t({
						...Ye,
						...r.style,
						seed: e.seed
					}),
					children: r.label
				}, n))
			}),
			/* @__PURE__ */ Y(W, {
				label: "Bangs",
				value: e.bangs,
				options: Ge,
				labels: Qe,
				onChange: (e) => t({ bangs: e })
			}),
			e.bangs !== "none" && n("bangLength", "Bangs length", 0, 1),
			n("back", "Back length", 0, 4),
			n("sides", "Side length", 0, 3),
			/* @__PURE__ */ Y(W, {
				label: "Tails",
				value: e.tails,
				options: N,
				labels: lt,
				onChange: (e) => t({ tails: e })
			}),
			e.tails !== "none" && e.tails !== "buns" && n("tailLength", "Tail length", .3, 4),
			n("volume", "Volume", 0, 1),
			n("wave", "Waves", 0, 1),
			n("curl", "Tips curl in", -1, 1),
			n("density", "Locks", .5, 1.5),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__check",
				children: [/* @__PURE__ */ Y("input", {
					type: "checkbox",
					checked: e.ahoge,
					onChange: (e) => t({ ahoge: e.target.checked })
				}), " Ahoge (a lock standing up)"]
			}),
			/* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => t({ seed: Math.floor(Math.random() * 1e6) }),
				children: "Shuffle the locks"
			})
		] });
	}, be = (e) => {
		let t = v.features?.[e] ?? v.face, n = (t) => F({ features: {
			...v.features,
			[e]: t === v.face ? void 0 : t
		} });
		return /* @__PURE__ */ Y("div", {
			className: "gs-avatar__grid gs-avatar__grid--wide",
			children: c.models.map((r) => /* @__PURE__ */ X("button", {
				type: "button",
				className: `gs-library__item${t === r.id ? " is-on" : ""}`,
				onClick: () => n(r.id),
				title: r.name,
				children: [/* @__PURE__ */ Y("img", {
					src: `${s}${r.thumbs[Fs[e]] ?? r.thumbs.face}`,
					alt: "",
					loading: "lazy"
				}), /* @__PURE__ */ Y("span", { children: r.id === v.face ? `${r.name} (its own)` : r.name })]
			}, r.id))
		});
	};
	return /* @__PURE__ */ X(uo, {
		title: "Character creator",
		onClose: a,
		children: [
			/* @__PURE__ */ X("div", {
				className: "gs-avatar",
				children: [/* @__PURE__ */ X("div", {
					className: "gs-avatar__stage",
					children: [/* @__PURE__ */ Y("canvas", {
						ref: j,
						width: 300,
						height: 420,
						className: "gs-avatar__preview",
						"aria-label": "The character, turned by dragging",
						onPointerDown: (e) => {
							te.current = e.clientX, e.currentTarget.setPointerCapture(e.pointerId);
						},
						onPointerUp: (e) => {
							let t = te.current;
							t !== null && E((n) => n + (e.clientX - t) * .8), te.current = null;
						}
					}), /* @__PURE__ */ X("div", {
						className: "gs-m3d__row",
						children: [/* @__PURE__ */ Y("button", {
							type: "button",
							className: `gs-m3d__btn${D ? "" : " is-on"}`,
							onClick: () => O(!1),
							children: "Whole body"
						}), /* @__PURE__ */ Y("button", {
							type: "button",
							className: `gs-m3d__btn${D ? " is-on" : ""}`,
							onClick: () => O(!0),
							children: "Face"
						})]
					})]
				}), /* @__PURE__ */ X("div", {
					className: "gs-avatar__controls",
					children: [
						/* @__PURE__ */ X("label", {
							className: "gs-m3d__field",
							children: [/* @__PURE__ */ Y("span", { children: "Name" }), /* @__PURE__ */ Y("input", {
								type: "text",
								value: v.name,
								maxLength: 60,
								onChange: (e) => F({ name: e.target.value })
							})]
						}),
						ie.length > 1 && /* @__PURE__ */ Y(W, {
							label: "Style",
							value: I?.id ?? "anime",
							options: ie,
							labels: ae,
							onChange: ue
						}),
						/* @__PURE__ */ Y(W, {
							label: "Part",
							value: le,
							options: L,
							labels: ce,
							onChange: p
						}),
						I && le !== "colours" && ((e, t) => {
							let n = xs(e, v.pieces?.[e.slots[0]]).build, r = t === e.slots[0];
							return /* @__PURE__ */ Y("div", {
								className: "gs-avatar__grid",
								children: e.models.filter((e) => e.pieces[t] && (r || e.build === n)).map((i) => /* @__PURE__ */ X("button", {
									type: "button",
									className: `gs-library__item${v.pieces?.[t] === i.id ? " is-on" : ""}`,
									onClick: () => F({ pieces: r && i.build !== n ? Gs(e, i.id) : {
										...v.pieces,
										[t]: i.id
									} }),
									title: i.name,
									children: [/* @__PURE__ */ Y("img", {
										src: `${s}${i.thumb}`,
										alt: "",
										loading: "lazy"
									}), /* @__PURE__ */ Y("span", { children: i.name })]
								}, i.id))
							});
						})(I, le),
						!I && le === "body" && _e("body"),
						!I && le === "face" && /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ Y("div", {
							className: "gs-anim__moves",
							role: "group",
							"aria-label": "Expression",
							children: ks.map((e) => /* @__PURE__ */ Y("button", {
								type: "button",
								className: `gs-m3d__btn${v.expression === e ? " is-on" : ""}`,
								onClick: () => F({ expression: e }),
								children: As[e]
							}, e))
						}), _e("face")] }),
						!I && le === "eyes" && /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ Y(W, {
							label: "Eye part",
							value: m,
							options: Ms,
							labels: qt,
							onChange: h
						}), be(m)] }),
						!I && le === "mouth" && /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ Y(W, {
							label: "Mouth part",
							value: g,
							options: Ns,
							labels: qt,
							onChange: _
						}), be(g)] }),
						!I && le === "hair" && /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ Y(W, {
							label: "Hair from",
							value: v.madeHair ? "made" : "character",
							options: Ts,
							labels: Es,
							onChange: (e) => F({ madeHair: e === "made" ? {
								...Ye,
								...Pe.long.style
							} : void 0 })
						}), v.madeHair ? ye(v.madeHair) : _e("hair")] }),
						!I && le === "shape" && /* @__PURE__ */ X(J, { children: [
							/* @__PURE__ */ Y("div", {
								className: "gs-anim__moves",
								role: "group",
								"aria-label": "Proportions",
								children: js.map((e) => /* @__PURE__ */ Y("button", {
									type: "button",
									className: "gs-m3d__btn",
									onClick: () => F({ shape: { ...B[e].shape } }),
									children: B[e].label
								}, e))
							}),
							de.map((e) => /* @__PURE__ */ Y(U, {
								label: se[e],
								value: v.shape[e] ?? 0,
								min: -1,
								max: 1,
								step: .05,
								format: (e) => e === 0 ? "As made" : `${e > 0 ? "+" : ""}${Math.round(e * 100)}%`,
								onBegin: () => void 0,
								onChange: (t) => F({ shape: {
									...v.shape,
									[e]: t
								} }),
								onEnd: () => void 0
							}, e)),
							/* @__PURE__ */ Y("h5", {
								className: "gs-m3d__subhead",
								children: "Face shape"
							}),
							/* @__PURE__ */ Y(o, { id: "m3dFaceShape" }),
							Ht.map((e) => /* @__PURE__ */ Y(U, {
								label: Jt[e],
								value: v.faceShape?.[e] ?? 0,
								min: -1,
								max: 1,
								step: .05,
								format: (e) => e === 0 ? "As made" : `${e > 0 ? "+" : ""}${Math.round(e * 100)}%`,
								onBegin: () => void 0,
								onChange: (t) => F({ faceShape: {
									...v.faceShape,
									[e]: t
								} }),
								onEnd: () => void 0
							}, e))
						] }),
						!I && le === "details" && /* @__PURE__ */ X(J, { children: [
							ve(v.facePaint ?? {}),
							/* @__PURE__ */ Y("h5", {
								className: "gs-m3d__subhead",
								children: "Eyes"
							}),
							/* @__PURE__ */ Y(o, { id: "m3dEyeStyle" }),
							/* @__PURE__ */ X("div", {
								className: "gs-anim__moves",
								role: "group",
								"aria-label": "Eye style",
								children: [/* @__PURE__ */ Y("button", {
									type: "button",
									className: `gs-m3d__btn${v.eyes ? "" : " is-on"}`,
									onClick: () => F({ eyes: void 0 }),
									children: "As drawn"
								}), nt.map((e) => /* @__PURE__ */ Y("button", {
									type: "button",
									className: `gs-m3d__btn${v.eyes?.style === e ? " is-on" : ""}`,
									onClick: () => F({ eyes: {
										...v.eyes,
										style: e
									} }),
									children: At[e]
								}, e))]
							}),
							v.eyes && /* @__PURE__ */ X(J, { children: [
								/* @__PURE__ */ Y(U, {
									label: "Pupil size",
									value: v.eyes.pupil ?? 0,
									min: -1,
									max: 1,
									step: .05,
									onBegin: () => void 0,
									onEnd: () => void 0,
									onChange: (e) => F({ eyes: {
										...v.eyes,
										pupil: e
									} })
								}),
								/* @__PURE__ */ X("label", {
									className: "gs-m3d__colour",
									children: [
										/* @__PURE__ */ Y("input", {
											type: "color",
											value: v.eyes.glow ?? "#f0c0a0",
											onChange: (e) => F({ eyes: {
												...v.eyes,
												glow: e.target.value
											} })
										}),
										" ",
										"Eye glow"
									]
								}),
								/* @__PURE__ */ X("label", {
									className: "gs-m3d__colour",
									children: [
										/* @__PURE__ */ Y("input", {
											type: "checkbox",
											checked: !!v.eyes.second,
											onChange: (e) => F({ eyes: {
												...v.eyes,
												second: e.target.checked ? "#c9a05a" : void 0
											} })
										}),
										" ",
										"Odd eyes"
									]
								}),
								v.eyes.second && /* @__PURE__ */ X("label", {
									className: "gs-m3d__colour",
									children: [
										/* @__PURE__ */ Y("input", {
											type: "color",
											value: v.eyes.second,
											onChange: (e) => F({ eyes: {
												...v.eyes,
												second: e.target.value
											} })
										}),
										" ",
										"Left eye colour"
									]
								})
							] }),
							/* @__PURE__ */ Y("h5", {
								className: "gs-m3d__subhead",
								children: "Makeup"
							}),
							/* @__PURE__ */ Y(o, { id: "m3dMakeup" }),
							zt.map((e) => /* @__PURE__ */ Y(U, {
								label: at[e],
								value: v.makeup?.[e] ?? 0,
								min: 0,
								max: 1,
								step: .05,
								format: (e) => e === 0 ? "None" : `${Math.round(e * 100)}%`,
								onBegin: () => void 0,
								onChange: (t) => F({ makeup: {
									...v.makeup,
									[e]: t
								} }),
								onEnd: () => void 0
							}, e)),
							/* @__PURE__ */ X("label", {
								className: "gs-m3d__colour",
								children: [
									/* @__PURE__ */ Y("input", {
										type: "checkbox",
										checked: !!v.makeup?.blushLines,
										onChange: (e) => F({ makeup: {
											...v.makeup,
											blushLines: e.target.checked
										} })
									}),
									" ",
									"Blush lines"
								]
							}),
							/* @__PURE__ */ X("label", {
								className: "gs-m3d__colour",
								children: [
									/* @__PURE__ */ Y("input", {
										type: "color",
										value: v.makeup?.blushColour ?? "#f2788a",
										onChange: (e) => F({ makeup: {
											...v.makeup,
											blushColour: e.target.value
										} })
									}),
									" ",
									"Blush colour"
								]
							}),
							/* @__PURE__ */ X("label", {
								className: "gs-m3d__colour",
								children: [
									/* @__PURE__ */ Y("input", {
										type: "color",
										value: v.makeup?.shadowColour ?? "#c45c6a",
										onChange: (e) => F({ makeup: {
											...v.makeup,
											shadowColour: e.target.value
										} })
									}),
									" ",
									"Eye shadow colour"
								]
							}),
							/* @__PURE__ */ X("label", {
								className: "gs-m3d__colour",
								children: [
									/* @__PURE__ */ Y("input", {
										type: "color",
										value: v.makeup?.lipColour ?? "#d9606e",
										onChange: (e) => F({ makeup: {
											...v.makeup,
											lipColour: e.target.value
										} })
									}),
									" ",
									"Lip colour"
								]
							}),
							/* @__PURE__ */ X("label", {
								className: "gs-m3d__field",
								children: [/* @__PURE__ */ Y("span", { children: "Beauty mark" }), /* @__PURE__ */ X("select", {
									value: v.makeup?.mole ?? "",
									onChange: (e) => F({ makeup: {
										...v.makeup,
										mole: e.target.value || void 0
									} }),
									children: [
										/* @__PURE__ */ Y("option", {
											value: "",
											children: "None"
										}),
										/* @__PURE__ */ Y("option", {
											value: "left",
											children: "Under the left eye"
										}),
										/* @__PURE__ */ Y("option", {
											value: "right",
											children: "Under the right eye"
										})
									]
								})]
							})
						] }),
						le === "colours" && /* @__PURE__ */ X("div", {
							className: "gs-avatar__colours",
							children: [ht.map((e) => /* @__PURE__ */ X("label", {
								className: "gs-m3d__colour",
								children: [
									/* @__PURE__ */ Y("input", {
										type: "color",
										value: v.colours[e] ?? "#888888",
										onChange: (t) => F({ colours: {
											...v.colours,
											[e]: t.target.value
										} })
									}),
									" ",
									pt[e],
									v.colours[e] && /* @__PURE__ */ Y("button", {
										type: "button",
										className: "gs-m3d__btn",
										onClick: () => {
											let { [e]: t, ...n } = v.colours;
											F({ colours: n });
										},
										children: "As drawn"
									})
								]
							}, e)), !I && /* @__PURE__ */ X("div", {
								className: "gs-avatar__wardrobe",
								children: [
									/* @__PURE__ */ Y("h5", {
										className: "gs-m3d__subhead",
										children: "Wardrobe"
									}),
									/* @__PURE__ */ Y(o, { id: "m3dWardrobe" }),
									/* @__PURE__ */ Y(U, {
										label: "Dress length",
										value: v.wardrobe?.length ?? 1,
										min: .6,
										max: 1.4,
										step: .05,
										onBegin: () => void 0,
										onEnd: () => void 0,
										onChange: (e) => F({ wardrobe: {
											...v.wardrobe,
											length: e
										} })
									}),
									/* @__PURE__ */ Y(U, {
										label: "Dress fullness",
										value: v.wardrobe?.fullness ?? 1,
										min: .6,
										max: 1.5,
										step: .05,
										onBegin: () => void 0,
										onEnd: () => void 0,
										onChange: (e) => F({ wardrobe: {
											...v.wardrobe,
											fullness: e
										} })
									}),
									["top", "bottom"].map((e) => {
										let t = v.wardrobe?.patterns?.[e], n = v.wardrobe?.prints?.[e], r = (t) => {
											let { [e]: n, ...r } = v.wardrobe?.patterns ?? {};
											F({ wardrobe: {
												...v.wardrobe,
												patterns: t ? {
													...r,
													[e]: t
												} : r
											} });
										};
										return /* @__PURE__ */ X("div", {
											className: "gs-m3d__game-ruletools",
											children: [
												/* @__PURE__ */ X("select", {
													"aria-label": `${pt[e]} pattern`,
													value: t?.pattern ?? "",
													onChange: (e) => r(e.target.value ? {
														pattern: e.target.value,
														colour: t?.colour ?? "#f4efe6"
													} : void 0),
													children: [/* @__PURE__ */ X("option", {
														value: "",
														children: [pt[e], ": no pattern"]
													}), Wt.map((t) => /* @__PURE__ */ X("option", {
														value: t,
														children: [
															pt[e],
															": ",
															Be[t]
														]
													}, t))]
												}),
												t && /* @__PURE__ */ Y("input", {
													type: "color",
													"aria-label": "Pattern colour",
													value: t.colour,
													onChange: (e) => r({
														...t,
														colour: e.target.value
													})
												}),
												/* @__PURE__ */ X("label", {
													className: "gs-m3d__colour",
													children: [
														/* @__PURE__ */ Y("input", {
															type: "checkbox",
															checked: !!n,
															onChange: (t) => {
																let { [e]: n, ...r } = v.wardrobe?.prints ?? {};
																F({ wardrobe: {
																	...v.wardrobe,
																	prints: t.target.checked ? {
																		...r,
																		[e]: "#f4efe6"
																	} : r
																} });
															}
														}),
														" ",
														"Two-colour print"
													]
												}),
												n && /* @__PURE__ */ Y("input", {
													type: "color",
													"aria-label": "Print's second colour",
													value: n,
													onChange: (t) => F({ wardrobe: {
														...v.wardrobe,
														prints: {
															...v.wardrobe?.prints,
															[e]: t.target.value
														}
													} })
												})
											]
										}, e);
									})
								]
							})]
						}),
						u && /* @__PURE__ */ Y("p", {
							className: "gs-m3d__note",
							children: u
						})
					]
				})]
			}),
			/* @__PURE__ */ Y("p", {
				className: "gs-m3d__meta",
				children: I ? I.credit : "Parts from pixiv's VRoid sample characters, CC0: free for any use, selling included."
			}),
			/* @__PURE__ */ Y(o, { id: "m3dAvatar" }),
			x.length > 0 && /* @__PURE__ */ Y("div", {
				className: "gs-avatar__looks",
				role: "group",
				"aria-label": "Kept looks",
				children: x.map((e) => /* @__PURE__ */ X("span", {
					className: "gs-m3d__chip",
					children: [/* @__PURE__ */ X("button", {
						type: "button",
						className: "gs-m3d__btn",
						title: `Wear ${e.name}`,
						onClick: () => pe(e),
						children: [e.thumb && /* @__PURE__ */ Y("img", {
							src: e.thumb,
							alt: ""
						}), e.name]
					}), /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						"aria-label": `Forget ${e.name}`,
						title: "Forget this look",
						onClick: () => me(e.name),
						children: "×"
					})]
				}, e.name))
			}),
			C && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: C
			}),
			x.length > 0 && /* @__PURE__ */ Y(o, { id: "m3dLooks" }),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: he,
						children: "Surprise me"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						title: "Keeps the whole character (parts, shape, colours) under its name, on this computer",
						onClick: fe,
						children: "Keep this look"
					}),
					/* @__PURE__ */ Y("span", { className: "gs-m3d__spacer" }),
					n ? /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: k,
						onClick: () => void ge("replace"),
						children: k ? "Making…" : "Update character"
					}) : t ? /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: k,
						onClick: () => void ge("new"),
						children: k ? "Making…" : "Add to the game"
					}) : /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						disabled: k,
						onClick: () => void ge("design"),
						children: "Add to this design"
					}), /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: k,
						onClick: () => void ge("new"),
						children: k ? "Making…" : "New design of it"
					})] })
				]
			})
		]
	});
}
//#endregion
//#region src/model3d/webgame.ts
async function qs() {
	let e = new URL("play/", new URL("/", location.href)), t = await fetch(new URL("index.html", e));
	if (!t.ok || !/text\/html/.test(t.headers.get("content-type") ?? "") || !(await t.text()).includes("gleamshelf-game-player")) throw Error("The game player is not built here: run npm run web:player, then try again.");
	let n = await fetch(new URL("files.json", e));
	if (!n.ok) throw Error("The game player is not built here: run npm run web:player, then try again.");
	let r = {};
	for (let t of await n.json()) {
		if (t === "files.json") continue;
		let n = await fetch(new URL(t, e));
		if (!n.ok) throw Error(`The game player's ${t} is missing.`);
		r[t] = new Uint8Array(await n.arrayBuffer());
	}
	return r;
}
async function Js(e) {
	let [{ zipSync: t, strToU8: n }, r] = await Promise.all([import("./fflate.module-CAsKaJ_w.js").then((e) => e.t), qs()]), i = t({
		...r,
		"game.json": n(Rn(e))
	}, { level: 6 }), a = document.createElement("a");
	a.href = URL.createObjectURL(new Blob([i], { type: "application/zip" })), a.download = `${e.title.replace(/[^\w -]+/g, "").trim() || "game"}.zip`, a.click(), setTimeout(() => URL.revokeObjectURL(a.href), 6e4);
}
//#endregion
//#region src/model3d/GamePackSection.tsx
var Ys = [
	"scenery",
	"wall",
	"solid",
	"spot"
], Xs = [
	"idle",
	"walk",
	"run",
	"sneak",
	"sit",
	"sit-talk",
	"talk",
	"think",
	"look",
	"wave",
	"shake",
	"sad",
	"cheer",
	"shrug",
	"point",
	"bow"
], Zs = {
	smile: { fun: 1 },
	happy: { joy: 1 },
	angry: { angry: 1 },
	sad: { sorrow: 1 },
	surprised: { surprised: 1 },
	mouth: { a: 1 },
	blink: { blink: 1 }
}, Qs = (e) => async (t) => {
	let n = await createImageBitmap(new Blob([t.bytes], { type: t.mime })), r = Math.min(1, e / Math.max(n.width, n.height)), i = new OffscreenCanvas(Math.max(1, Math.round(n.width * r)), Math.max(1, Math.round(n.height * r))), a = i.getContext("2d");
	a.drawImage(n, 0, 0, i.width, i.height);
	let o = a.getImageData(0, 0, i.width, i.height).data, s = !1;
	for (let e = 3; e < o.length; e += 4) if (o[e] < 255) {
		s = !0;
		break;
	}
	let c = await i.convertToBlob(s ? { type: "image/png" } : {
		type: "image/jpeg",
		quality: .85
	});
	return new Uint8Array(await c.arrayBuffer());
}, $s = (e, t, n) => {
	let r = document.createElement("a");
	r.href = URL.createObjectURL(new Blob([e], { type: n })), r.download = t, r.click(), setTimeout(() => URL.revokeObjectURL(r.href), 6e4);
}, ec = (e) => e.replace(/[^\w -]+/g, "").trim() || "game", tc = (e) => getComputedStyle(document.documentElement).getPropertyValue(e).trim();
function nc({ grid: e }) {
	let t = K(null), n = Math.max(2, Math.min(5, Math.floor(280 / e.width)));
	return G(() => {
		let r = t.current?.getContext("2d");
		if (!r) return;
		let i = t.current, a = getComputedStyle(i), o = [
			a.getPropertyValue("--m-panel"),
			a.getPropertyValue("--m-line"),
			a.getPropertyValue("--m-raise")
		];
		r.fillStyle = o[0], r.fillRect(0, 0, i.width, i.height);
		for (let t = 0; t < e.height; t++) for (let i = 0; i < e.width; i++) {
			let a = e.cells[t * e.width + i];
			a !== 0 && (r.fillStyle = o[a === 1 ? 1 : 2], r.fillRect(i * n, t * n, n, n));
		}
		for (let t of e.spots) r.fillStyle = t.reached ? a.getPropertyValue("--m-accent") : a.getPropertyValue("--gs-danger"), r.beginPath(), r.arc((t.x - e.x0) / e.cell * n, (t.z - e.z0) / e.cell * n, 2.5, 0, Math.PI * 2), r.fill();
	}, [e, n]), /* @__PURE__ */ Y("canvas", {
		ref: t,
		className: "gs-m3d__walkmap",
		width: e.width * n,
		height: e.height * n,
		"aria-label": "Where people can walk, from above"
	});
}
function rc({ api: e, editor: n, selected: r, shape: a, libraryUrl: s, run: c }) {
	let l = t(), [u, d] = q(null), [f, p] = q(null), [m, h] = q(""), [g, _] = q([]), [v, y] = q("phone"), [b, x] = q(30), [S, C] = q(null), [w, T] = q(null), [E, D] = q([]), [O, A] = q("floor"), [j, M] = q(3), [ee, ne] = q({}), N = K(null), P = e.project, re = Xr(() => P.levels.flatMap((e) => e.design.shapes.filter((e) => e.name.startsWith("spot:")).map((e) => e.name.slice(5))), [P.levels]), F = Xr(() => {
		try {
			return rn(e.synced(), v);
		} catch {
			return null;
		}
	}, [
		e,
		v,
		n.document
	]), I = Xr(() => or(e.synced()), [e, n.document]), ie = Xr(() => [...new Set(I.map((e) => e.speaker))], [I]), ae = (t = g) => {
		let n = e.synced(), r = {
			start: m || void 0,
			placed: t
		};
		d([...Mn(n, r), ...bn(n)]), p(Sn(n, r));
	}, oe = () => c(`Fitting the game to a ${An[v].label.toLowerCase()}…`, async () => {
		let { project: t, lightened: n } = Sr(e.synced(), v);
		e.adopt(t), C(n ? `${n} models made lighter. Bones are trimmed when you save the pack. Open the project's saved copy to go back.` : "Nothing needed lightening.");
	}), L = async (e) => {
		D((t) => [...t.filter((e) => e.match !== O), {
			match: O,
			metres: j,
			file: e.name,
			image: /* @__PURE__ */ new Uint8Array()
		}]);
		let t = await Qs(1024)({
			mime: e.type,
			bytes: new Uint8Array(await e.arrayBuffer())
		});
		D((e) => e.map((e) => e.match === O ? {
			...e,
			image: t
		} : e));
	}, se = () => c("Packing the game…", async () => {
		let t = e.synced(), { zipSync: n, strToU8: r } = await import("./fflate.module-CAsKaJ_w.js").then((e) => e.t), i = An[v], a = {}, o = [], s = await Jn(t, Qs(512), { triangles: i.levelTriangles * Math.max(1, t.levels.length) }, E);
		a["world.world"] = s.bytes, o.push(...s.warnings);
		for (let e of t.characters) {
			let t = vn(e), n = t?.asset ? e.design.assets?.[t.asset] : void 0;
			if (!n) {
				o.push(`${e.name} is built from shapes, so it has no model to pack.`);
				continue;
			}
			let r = k(te(n.data));
			if (!r.skeleton?.length) {
				o.push(`${e.name} has no skeleton: make it with the character creator, or import a rigged model.`);
				continue;
			}
			let s = r.morphs?.names ?? [], c = Object.fromEntries(Object.entries(Zs).filter(([, e]) => Object.keys(e).every((e) => s.includes(e)))), l = await Er(r, {
				name: e.name,
				height: t.size[1],
				moves: Xs,
				expressions: c,
				armsDown: b,
				budget: {
					triangles: i.characterTriangles,
					bones: i.bones
				}
			}, Qs(512));
			a[`cast/${e.id}.cast`] = l.bytes, o.push(...l.warnings.map((t) => `${e.name}: ${t}`));
		}
		let c = or(t).filter((e) => e.voice && t.sounds[e.voice]);
		for (let e of c) {
			let n = t.sounds[e.voice].data;
			a[`voices/${wr(e.speaker, e.text)}.${/audio\/wav/.test(n) ? "wav" : "audio"}`] = te(n.slice(n.indexOf(",") + 1));
		}
		a["lines.json"] = r(JSON.stringify(c.map((e) => ({
			speaker: e.speaker,
			text: e.text,
			file: wr(e.speaker, e.text)
		})), null, 1)), a["story.json"] = r(JSON.stringify(t.levels.map(Qn), null, 1)), t.credits && (a["CREDITS.txt"] = r(t.credits)), $s(n(a, { level: 6 }), `${ec(t.title)}-pack.zip`, "application/zip"), C(o.length ? o.join(" ") : `Packed for a ${i.label.toLowerCase()}: nothing over budget.`);
	}), ce = () => c("Working out the credits…", async () => {
		let t = e.synced(), n = s ? `${s.replace(/\/$/, "")}/` : null;
		if (!n) throw Error("The credits come from the 3D library, which is not available here.");
		let r = await (await fetch(`${n}index.json`)).json(), i = [...t.levels, ...t.characters].flatMap((e) => Object.keys(e.design.assets ?? {})), { credits: a, own: o } = wn(i, r.items), c = /* @__PURE__ */ new Map();
		for (let e of a) c.set(`${e.author} (${e.licence})`, [...c.get(`${e.author} (${e.licence})`) ?? [], e.name]);
		let l = [...c].map(([e, t]) => `${e}: ${t.join(", ")}.`), u = (P.credits ?? "").split("\n").filter((e) => e && !l.includes(e));
		e.setCredits([...u, ...l].join("\n")), C(`${a.length} library models credited. ${o.length} of the models aren't from the library: credit those yourself if someone else made them.`);
	}), le = () => c("Drawing the cast…", async () => {
		let t = e.synced(), n = Math.min(6, t.characters.length || 1), r = Math.ceil(t.characters.length / n), i = document.createElement("canvas");
		i.width = n * 170, i.height = r * 302;
		let a = i.getContext("2d");
		a.fillStyle = tc("--m-panel") || tc("--gs-bg-2"), a.fillRect(0, 0, i.width, i.height);
		let o = [];
		for (let [e, r] of t.characters.entries()) {
			let t = vn(r)?.size[1] ?? 1.7, i = {
				...r.design,
				camera: {
					...r.design.camera,
					target: [
						0,
						t / 2,
						0
					],
					distance: t * 2,
					yaw: 0,
					pitch: 4
				}
			}, s = await dn(i, {
				width: 170,
				height: 280
			});
			o.push({
				name: r.name,
				pic: s
			});
			let c = e % n * 170, l = Math.floor(e / n) * 302;
			a.putImageData(new ImageData(new Uint8ClampedArray(s.data), s.width, s.height), c, l), a.fillStyle = tc("--gs-text"), a.font = "12px sans-serif", a.textAlign = "center", a.fillText(r.name, c + 85, l + 280 + 15);
		}
		let s = [];
		for (let e = 0; e < o.length; e++) for (let t = e + 1; t < o.length; t++) on(o[e].pic, o[t].pic) > .94 && s.push(`${o[e].name} and ${o[t].name}`);
		T({
			url: i.toDataURL("image/png"),
			alike: s
		});
	}), ue = () => c("Speaking the lines…", async () => {
		if (l.state !== "ready") throw Error("Voices need the local app: start it and pair it, then try again.");
		let t = {}, n = 0;
		for (let r of I) {
			if (r.voice) continue;
			let i = ee[r.speaker] ?? "af_heart", a = await l.client.speak(r.text.replace(/[()]/g, ""), {
				voice: i,
				speed: 1
			}), o = `${r.speaker} ${wr(r.speaker, r.text)}`;
			t[r.line] = await e.addSound(new File([a], `${o}.wav`, { type: "audio/wav" })), n++;
		}
		e.adopt(En(e.synced(), t)), C(n ? `${n} lines spoken.` : "Every line already has a voice.");
	}), de = a ? Zt(a.name) : null, fe = f?.spots.filter((e) => !e.reached && !g.includes(e.name)) ?? [];
	return /* @__PURE__ */ X(J, { children: [
		/* @__PURE__ */ X("section", { children: [
			/* @__PURE__ */ Y("h4", { children: "What this shape is" }),
			/* @__PURE__ */ Y(o, { id: "m3dShapeRole" }),
			a && r && de ? /* @__PURE__ */ Y("div", {
				className: "gs-m3d__game-ruletools",
				role: "group",
				"aria-label": "What this shape is to the game",
				children: Ys.map((e) => /* @__PURE__ */ Y("button", {
					type: "button",
					className: e === de ? "is-on" : "",
					onClick: () => n.updateShapeAt(r, ir(a, e), tn[e]),
					children: tn[e]
				}, e))
			}) : /* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: "Pick a shape first."
			})
		] }),
		/* @__PURE__ */ X("section", { children: [
			/* @__PURE__ */ Y("h4", { children: "Check the game" }),
			/* @__PURE__ */ Y(o, { id: "m3dGameCheck" }),
			re.length > 0 && /* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Start at" }), /* @__PURE__ */ X("select", {
					value: m,
					onChange: (e) => h(e.target.value),
					children: [/* @__PURE__ */ Y("option", {
						value: "",
						children: "First spot"
					}), [...new Set(re)].map((e) => /* @__PURE__ */ Y("option", { children: e }, e))]
				})]
			}),
			/* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => ae(),
				children: "Check the game"
			}),
			u && (u.length ? /* @__PURE__ */ Y("ul", {
				className: "gs-m3d__findings",
				children: u.map((e, t) => /* @__PURE__ */ X("li", { children: [
					/* @__PURE__ */ Y("strong", { children: e.level }),
					" ",
					e.message
				] }, t))
			}) : /* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: "Nothing to fix."
			})),
			f && /* @__PURE__ */ X(J, { children: [
				/* @__PURE__ */ Y("h5", {
					className: "gs-m3d__subhead",
					children: "Where people can walk"
				}),
				/* @__PURE__ */ Y(nc, { grid: f }),
				/* @__PURE__ */ Y(o, { id: "m3dWalkMap" }),
				fe.map((e) => /* @__PURE__ */ X("button", {
					type: "button",
					title: "For a place the game moves people to itself, like a cutscene room",
					onClick: () => {
						let t = [...g, e.name];
						_(t), ae(t);
					},
					children: [e.name, ": the game moves people there"]
				}, e.name))
			] })
		] }),
		/* @__PURE__ */ X("section", { children: [
			/* @__PURE__ */ Y("h4", { children: "Will it run?" }),
			/* @__PURE__ */ Y(o, { id: "m3dGameBudget" }),
			/* @__PURE__ */ Y("div", {
				className: "gs-m3d__game-ruletools",
				role: "group",
				"aria-label": "Device",
				children: Object.keys(An).map((e) => /* @__PURE__ */ Y("button", {
					type: "button",
					className: e === v ? "is-on" : "",
					onClick: () => y(e),
					children: An[e].label
				}, e))
			}),
			F && /* @__PURE__ */ Y("ul", {
				className: "gs-m3d__budget",
				children: F.lines.map((e) => {
					let t = Math.min(1, e.triangles / e.limit);
					return /* @__PURE__ */ X("li", {
						className: e.triangles > e.limit || (e.bones ?? 0) > (e.boneLimit ?? Infinity) ? "is-over" : "",
						children: [
							/* @__PURE__ */ Y("span", { children: e.name }),
							/* @__PURE__ */ X("span", {
								className: "gs-m3d__meta",
								children: [
									e.triangles.toLocaleString("en"),
									" triangles",
									e.bones ? `, ${e.bones} bones` : ""
								]
							}),
							/* @__PURE__ */ Y("i", { style: { width: `${t * 100}%` } })
						]
					}, `${e.kind}-${e.id}`);
				})
			}),
			F && /* @__PURE__ */ X("p", {
				className: "gs-m3d__meta",
				children: [
					"Models: ",
					F.megabytes.toFixed(0),
					" of ",
					F.megabyteLimit,
					" MB"
				]
			}),
			F && F.over.length > 0 && /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => void oe(),
				children: "Make it fit"
			})
		] }),
		/* @__PURE__ */ X("section", { children: [
			/* @__PURE__ */ Y("h4", { children: "Surfaces" }),
			/* @__PURE__ */ Y(o, { id: "m3dGameSurfaces" }),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Boxes named" }), /* @__PURE__ */ Y("input", {
					value: O,
					onChange: (e) => A(e.target.value),
					"aria-label": "Boxes whose name starts with"
				})]
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Repeats every" }), /* @__PURE__ */ Y("input", {
					type: "number",
					min: .1,
					max: 50,
					step: .1,
					value: j,
					onChange: (e) => M(Number(e.target.value) || 1),
					"aria-label": "Metres"
				})]
			}),
			/* @__PURE__ */ Y("button", {
				type: "button",
				onClick: () => N.current?.click(),
				children: "Choose a picture…"
			}),
			/* @__PURE__ */ Y("input", {
				ref: N,
				type: "file",
				accept: "image/*",
				hidden: !0,
				onChange: (e) => {
					let t = e.target.files?.[0];
					e.target.value = "", t && c("Reading the picture…", () => L(t));
				}
			}),
			/* @__PURE__ */ Y("ul", {
				className: "gs-m3d__game-entries",
				children: E.map((e) => /* @__PURE__ */ X("li", { children: [/* @__PURE__ */ X("span", { children: [
					e.match,
					": ",
					e.file,
					", ",
					e.metres,
					" m"
				] }), /* @__PURE__ */ Y("button", {
					type: "button",
					"aria-label": `Remove ${e.match}`,
					onClick: () => D((t) => t.filter((t) => t.match !== e.match)),
					children: "✕"
				})] }, e.match))
			})
		] }),
		/* @__PURE__ */ X("section", { children: [
			/* @__PURE__ */ Y("h4", { children: "Voices for every line" }),
			/* @__PURE__ */ Y(o, { id: "m3dGameVoices" }),
			I.length === 0 ? /* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: "No lines yet. Add a Say lines action to a rule, written like \"Mio: Hello.\""
			}) : /* @__PURE__ */ X(J, { children: [
				ie.map((e) => /* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: e }), /* @__PURE__ */ Y("select", {
						value: ee[e] ?? "af_heart",
						onChange: (t) => ne((n) => ({
							...n,
							[e]: t.target.value
						})),
						children: i.map((e) => /* @__PURE__ */ X("option", {
							value: e.id,
							children: [
								e.label,
								" (",
								e.accent,
								", ",
								e.kind,
								")"
							]
						}, e.id))
					})]
				}, e)),
				/* @__PURE__ */ X("p", {
					className: "gs-m3d__meta",
					children: [
						I.filter((e) => e.voice).length,
						" of ",
						I.length,
						" lines have a voice."
					]
				}),
				/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => void ue(),
					children: "Speak the lines"
				})
			] })
		] }),
		/* @__PURE__ */ X("section", { children: [
			/* @__PURE__ */ Y("h4", { children: "The cast" }),
			/* @__PURE__ */ Y(o, { id: "m3dCastSheet" }),
			/* @__PURE__ */ Y("button", {
				type: "button",
				disabled: !P.characters.length,
				onClick: () => void le(),
				children: "Draw the cast sheet"
			}),
			w && /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ Y("img", {
				className: "gs-m3d__castsheet",
				src: w.url,
				alt: "Every character side by side"
			}), w.alike.map((e) => /* @__PURE__ */ X("p", {
				className: "gs-m3d__note",
				children: [e, " look very alike: players may mix them up."]
			}, e))] })
		] }),
		/* @__PURE__ */ X("section", { children: [
			/* @__PURE__ */ Y("h4", { children: "Export for a game engine" }),
			/* @__PURE__ */ Y(o, { id: "m3dGamePack" }),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Arms down" }), /* @__PURE__ */ Y("input", {
					type: "number",
					min: 0,
					max: 90,
					value: b,
					onChange: (e) => x(Number(e.target.value) || 0),
					"aria-label": "Degrees the arms come down"
				})]
			}),
			/* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => void se(),
				children: "Save the game pack (.zip)"
			}),
			/* @__PURE__ */ Y("button", {
				type: "button",
				onClick: () => void ce(),
				children: "Fill in the credits"
			}),
			/* @__PURE__ */ Y(o, { id: "m3dGameCredits" }),
			S && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: S
			})
		] })
	] });
}
//#endregion
//#region src/model3d/RomancePlay.tsx
function ic({ story: e, sounds: t, onClose: n }) {
	let [r, i] = q("all"), [a, o] = q(!1), [s, c] = q(!1), l = Xr(() => ur(e, r), [e, r]), [u, d] = q(() => new Bn(l)), [, f] = q(0);
	G(() => d(new Bn(l)), [l]);
	let p = (e) => e ? l.pictures.find((t) => t.id === e)?.data : void 0, m = u.view(a), h = () => u.next() && f((e) => e + 1), g = (e) => u.choose(e) && f((e) => e + 1), _ = K(null);
	G(() => _.current?.focus(), []);
	let v = (e) => {
		if (e.stopPropagation(), e.key === "Escape") n();
		else if (e.key === " " || e.key === "Enter") e.preventDefault(), h();
		else if (/^[1-6]$/.test(e.key) && m.choices) {
			let t = m.choices[Number(e.key) - 1];
			t && g(t.index);
		}
	}, y = m.music ? t[m.music]?.data : void 0;
	G(() => {
		if (!y) return;
		let e = new Audio(y);
		return e.loop = !0, e.volume = .5, e.play().catch(() => {}), () => e.pause();
	}, [y]);
	let b = m.line?.voice ? t[m.line.voice]?.data : void 0;
	G(() => {
		if (!b) return;
		let e = new Audio(b);
		return e.play().catch(() => {}), () => e.pause();
	}, [b]);
	let x = p(m.background), S = p(m.cg);
	return /* @__PURE__ */ X("div", {
		ref: _,
		className: "gs-vn",
		role: "dialog",
		"aria-label": "Play the romance",
		tabIndex: -1,
		onKeyDown: v,
		onKeyUp: (e) => e.stopPropagation(),
		onMouseDown: (e) => e.target.closest("button") && e.preventDefault(),
		children: [/* @__PURE__ */ X("div", {
			className: "gs-vn__screen",
			onClick: () => !m.choices && h(),
			children: [
				x ? /* @__PURE__ */ Y("img", {
					className: "gs-vn__bg",
					src: x,
					alt: ""
				}) : /* @__PURE__ */ Y("div", { className: "gs-vn__bg gs-vn__bg--none" }),
				!S && !m.ending && m.stage.map((e) => /* @__PURE__ */ Y("div", {
					className: `gs-vn__stand gs-vn__stand--${e.at}${e.speaking ? " is-speaking" : ""}`,
					children: e.picture && p(e.picture) ? /* @__PURE__ */ Y("img", {
						src: p(e.picture),
						alt: e.heroine.name
					}) : /* @__PURE__ */ Y("div", {
						className: "gs-vn__silhouette",
						style: { borderColor: e.heroine.colour },
						children: a && e.heroine.nameJa || e.heroine.name
					})
				}, e.heroine.id)),
				S && /* @__PURE__ */ Y("img", {
					className: "gs-vn__cg",
					src: S,
					alt: ""
				}),
				m.ending ? /* @__PURE__ */ X("div", {
					className: "gs-vn__ending",
					children: [
						/* @__PURE__ */ Y("p", {
							className: "gs-vn__ending-kind",
							children: m.ending.kind === "bad" ? "Bad end" : m.ending.kind === "normal" ? "Ending" : `${m.ending.kind[0].toUpperCase()}${m.ending.kind.slice(1)} end`
						}),
						/* @__PURE__ */ Y("h2", { children: a && m.ending.titleJa || m.ending.title }),
						/* @__PURE__ */ Y("p", {
							className: "gs-vn__made",
							children: l.madeWith
						}),
						/* @__PURE__ */ Y("button", {
							type: "button",
							onClick: () => d(new Bn(l)),
							children: "Play again"
						})
					]
				}) : m.line && /* @__PURE__ */ X("div", {
					className: "gs-vn__box",
					children: [m.speaker && /* @__PURE__ */ Y("span", {
						className: "gs-vn__name",
						style: m.speaker.colour ? { color: m.speaker.colour } : void 0,
						children: m.speaker.name
					}), /* @__PURE__ */ Y("p", {
						className: m.speaker ? "" : "gs-vn__narration",
						children: m.line.text
					})]
				}),
				m.choices && /* @__PURE__ */ Y("div", {
					className: "gs-vn__choices",
					children: m.choices.map((e, t) => /* @__PURE__ */ X("button", {
						type: "button",
						onClick: (t) => {
							t.stopPropagation(), g(e.index);
						},
						children: [
							/* @__PURE__ */ Y("kbd", { children: t + 1 }),
							" ",
							e.text
						]
					}, e.index))
				}),
				s && /* @__PURE__ */ X("ul", {
					className: "gs-vn__meters",
					"aria-label": "Affection",
					children: [l.heroines.map((e) => /* @__PURE__ */ X("li", { children: [
						/* @__PURE__ */ Y("span", {
							style: { color: e.colour },
							children: e.name.split(" ")[0]
						}),
						" ",
						u.state.affection[e.id] ?? 0,
						" / ",
						e.routeAt
					] }, e.id)), u.state.flags.length > 0 && /* @__PURE__ */ X("li", { children: ["Flags: ", u.state.flags.join(", ")] })]
				})
			]
		}), /* @__PURE__ */ X("div", {
			className: "gs-vn__bar",
			children: [
				/* @__PURE__ */ Y("button", {
					type: "button",
					onClick: () => o(!a),
					children: a ? "English" : "日本語"
				}),
				/* @__PURE__ */ Y("button", {
					type: "button",
					onClick: () => i(r === "all" ? "mature" : "all"),
					title: "Which export to play",
					children: r === "all" ? "Playing: all ages" : "Playing: mature"
				}),
				/* @__PURE__ */ Y("button", {
					type: "button",
					"aria-pressed": s,
					onClick: () => c(!s),
					children: "Affection"
				}),
				/* @__PURE__ */ Y("span", {
					className: "gs-vn__where",
					children: m.scene.title
				}),
				/* @__PURE__ */ Y("button", {
					type: "button",
					onClick: n,
					children: "Close"
				})
			]
		})]
	});
}
//#endregion
//#region src/model3d/RomanceSection.tsx
var ac = [
	"heroines",
	"pictures",
	"scenes",
	"endings",
	"check"
], oc = {
	heroines: "Heroines",
	pictures: "Pictures",
	scenes: "Scenes",
	endings: "Endings",
	check: "Check"
}, sc = [
	"go",
	"choose",
	"branch",
	"end",
	"return"
], cc = {
	go: "Go on",
	choose: "Choice",
	branch: "Branch",
	end: "Ending",
	return: "Back to the world"
}, lc = [
	"normal",
	"smile",
	"shy",
	"sad",
	"angry",
	"surprised"
], uc = (e, t) => {
	let n = new Set(e), r = t.toLowerCase().replace(/[^\w]+/g, "-").replace(/^-|-$/g, "").slice(0, 30) || "item", i = r, a = 2;
	for (; n.has(i);) i = `${r}-${a++}`;
	return i;
};
async function dc(e, t) {
	let n = await createImageBitmap(e), r = Math.min(1, 1920 / Math.max(n.width, n.height)), i = document.createElement("canvas");
	return i.width = Math.max(1, Math.round(n.width * r)), i.height = Math.max(1, Math.round(n.height * r)), i.getContext("2d").drawImage(n, 0, 0, i.width, i.height), n.close(), t === "portrait" ? i.toDataURL("image/png") : i.toDataURL("image/jpeg", .9);
}
var fc = (e, t, n) => {
	let r = document.createElement("a");
	r.href = URL.createObjectURL(new Blob([e], { type: n })), r.download = t, r.click(), setTimeout(() => URL.revokeObjectURL(r.href), 6e4);
};
function pc({ story: e, onChange: t, title: n, characters: r, achievements: i, sounds: a, takePicture: s, run: c }) {
	let [l, u] = q("scenes"), [d, f] = q(!1), [p, m] = q("all");
	if (!e) return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Romance" }),
		/* @__PURE__ */ Y(o, { id: "m3dRomance" }),
		/* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: "A dating sim or visual novel: heroines, scenes, choices that open routes, and endings."
		}),
		/* @__PURE__ */ Y("button", {
			type: "button",
			onClick: () => t(Ca()),
			children: "Start from Pocket Hearts' opening"
		}),
		/* @__PURE__ */ Y("button", {
			type: "button",
			onClick: () => t(On({
				scenes: [{
					id: "start",
					title: "Start",
					lines: [{ text: "It begins here." }],
					next: {
						kind: "end",
						ending: "end"
					}
				}],
				endings: [{
					id: "end",
					title: "The end"
				}]
			})),
			children: "Start an empty story"
		})
	] });
	let h = (n) => t({
		...e,
		...n
	}), g = yr(e).filter((e) => e.level === "error").length;
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Romance" }),
		/* @__PURE__ */ Y(o, { id: "m3dRomance" }),
		/* @__PURE__ */ Y(W, {
			label: "Romance part",
			value: l,
			options: ac,
			labels: {
				...oc,
				check: g ? `Check (${g})` : "Check"
			},
			onChange: u
		}),
		l === "heroines" && /* @__PURE__ */ Y(mc, {
			story: e,
			put: h,
			characters: r
		}),
		l === "pictures" && /* @__PURE__ */ Y(hc, {
			story: e,
			put: h,
			takePicture: s,
			run: c
		}),
		l === "scenes" && /* @__PURE__ */ Y(gc, {
			story: e,
			put: h,
			sounds: a
		}),
		l === "endings" && /* @__PURE__ */ Y(xc, {
			story: e,
			put: h,
			achievements: i
		}),
		l === "check" && /* @__PURE__ */ Y(Sc, { story: e }),
		/* @__PURE__ */ Y("div", {
			className: "gs-m3d__row",
			children: /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__primary",
				onClick: () => f(!0),
				children: "▶ Play the story"
			})
		}),
		/* @__PURE__ */ X("label", {
			className: "gs-m3d__field",
			children: [/* @__PURE__ */ Y("span", { children: "Export rating" }), /* @__PURE__ */ X("select", {
				value: p,
				onChange: (e) => m(e.target.value),
				children: [/* @__PURE__ */ Y("option", {
					value: "all",
					children: Vn.all
				}), /* @__PURE__ */ Y("option", {
					value: "mature",
					children: Vn.mature
				})]
			})]
		}),
		p === "mature" && !$n(e) && /* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: "Nothing is marked mature: both exports are the same."
		}),
		Xt(e, p).map((e) => /* @__PURE__ */ Y("p", {
			className: "gs-m3d__note gs-m3d__note--bad",
			children: e
		}, e)),
		/* @__PURE__ */ Y("button", {
			type: "button",
			disabled: Xt(e, p).length > 0,
			onClick: () => void c("Packing the story…", async () => {
				let { zipSync: t } = await import("./fflate.module-CAsKaJ_w.js").then((e) => e.t), r = {};
				for (let t of gr(e, p, n)) r[t.path] = t.bytes;
				let i = `${n.replace(/[^\w -]+/g, "").trim() || "romance"}-${p}.zip`;
				fc(t(r, { level: 6 }), i, "application/zip");
			}),
			children: "Save the romance pack (.zip)"
		}),
		/* @__PURE__ */ Y("button", {
			type: "button",
			onClick: () => confirm("Remove the whole romance story from the project?") && t(void 0),
			children: "Remove the story"
		}),
		d && /* @__PURE__ */ Y(ic, {
			story: e,
			sounds: a,
			onClose: () => f(!1)
		})
	] });
}
function mc({ story: e, put: t, characters: n }) {
	let [r, i] = q(e.heroines[0]?.id ?? null), a = e.heroines.find((e) => e.id === r), o = (n) => t({ heroines: e.heroines.map((e) => e.id === r ? {
		...e,
		...n
	} : e) }), s = e.pictures.filter((e) => e.kind === "portrait" && (!e.heroine || e.heroine === r));
	return /* @__PURE__ */ X(J, { children: [
		/* @__PURE__ */ Y("ul", {
			className: "gs-m3d__game-entries",
			children: e.heroines.map((n) => /* @__PURE__ */ X("li", { children: [/* @__PURE__ */ X("button", {
				type: "button",
				"aria-expanded": r === n.id,
				onClick: () => i(n.id),
				children: [
					/* @__PURE__ */ Y("span", {
						style: { color: n.colour },
						children: "●"
					}),
					" ",
					n.name,
					n.age === void 0 ? " (no age)" : ` (${n.age})`
				]
			}), /* @__PURE__ */ Y("button", {
				type: "button",
				"aria-label": `Remove ${n.name}`,
				onClick: () => t({ heroines: e.heroines.filter((e) => e.id !== n.id) }),
				children: "✕"
			})] }, n.id))
		}),
		/* @__PURE__ */ Y("button", {
			type: "button",
			onClick: () => {
				let n = uc([...e.heroines.map((e) => e.id), "me"], "heroine");
				t({ heroines: [...e.heroines, {
					id: n,
					name: "New heroine",
					colour: "#d98aa4",
					faces: {},
					routeAt: 30
				}] }), i(n);
			},
			children: "+ Heroine"
		}),
		a && /* @__PURE__ */ X("div", {
			className: "gs-m3d__panel",
			children: [
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: "Name" }), /* @__PURE__ */ Y("input", {
						value: a.name,
						maxLength: 40,
						onChange: (e) => o({ name: e.target.value })
					})]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: "Name (日本語)" }), /* @__PURE__ */ Y("input", {
						value: a.nameJa ?? "",
						maxLength: 40,
						onChange: (e) => o({ nameJa: e.target.value || void 0 })
					})]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: "Age" }), /* @__PURE__ */ Y("input", {
						type: "number",
						min: 0,
						max: 999,
						value: a.age ?? "",
						onChange: (e) => o({ age: e.target.value === "" ? void 0 : Math.max(0, Math.round(Number(e.target.value))) })
					})]
				}),
				/* @__PURE__ */ Y("p", {
					className: "gs-m3d__note",
					children: "Her stated age. Any mature scene, line or picture with her needs 18 or over, or it won't export."
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: "Name colour" }), /* @__PURE__ */ Y("input", {
						type: "color",
						value: a.colour,
						onChange: (e) => o({ colour: e.target.value })
					})]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("input", {
						type: "checkbox",
						checked: !!a.side,
						onChange: (e) => o({ side: e.target.checked || void 0 })
					}), /* @__PURE__ */ Y("span", { children: "Side character (speaks, no route or endings: a rival, a friend)" })]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: "Route opens at" }), /* @__PURE__ */ Y("input", {
						type: "number",
						min: 0,
						max: 999,
						value: a.routeAt,
						onChange: (e) => o({ routeAt: Math.max(0, Math.round(Number(e.target.value) || 0)) })
					})]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field gs-m3d__field--top",
					children: [/* @__PURE__ */ Y("span", { children: "Profile" }), /* @__PURE__ */ Y("textarea", {
						rows: 2,
						maxLength: 400,
						value: a.profile ?? "",
						onChange: (e) => o({ profile: e.target.value || void 0 })
					})]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field gs-m3d__field--top",
					children: [/* @__PURE__ */ Y("span", { children: "Profile (日本語)" }), /* @__PURE__ */ Y("textarea", {
						rows: 2,
						maxLength: 400,
						value: a.profileJa ?? "",
						onChange: (e) => o({ profileJa: e.target.value || void 0 })
					})]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: "3D character" }), /* @__PURE__ */ X("select", {
						value: a.character ?? "",
						onChange: (e) => o({ character: e.target.value || void 0 }),
						children: [/* @__PURE__ */ Y("option", {
							value: "",
							children: "None"
						}), n.map((e) => /* @__PURE__ */ Y("option", {
							value: e.id,
							children: e.name
						}, e.id))]
					})]
				}),
				/* @__PURE__ */ Y("h5", { children: "Faces" }),
				/* @__PURE__ */ Y("p", {
					className: "gs-m3d__note",
					children: "A portrait for each expression. Pose her in 3D mode, then Pictures → Take the 3D view as a portrait."
				}),
				[.../* @__PURE__ */ new Set([...lc, ...Object.keys(a.faces)])].map((e) => /* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: e }), /* @__PURE__ */ X("select", {
						value: a.faces[e] ?? "",
						onChange: (t) => {
							let n = { ...a.faces };
							t.target.value ? n[e] = t.target.value : delete n[e], o({ faces: n });
						},
						children: [/* @__PURE__ */ Y("option", {
							value: "",
							children: "None"
						}), s.map((e) => /* @__PURE__ */ Y("option", {
							value: e.id,
							children: e.name
						}, e.id))]
					})]
				}, e))
			]
		})
	] });
}
function hc({ story: e, put: t, takePicture: n, run: r }) {
	let [i, a] = q("portrait"), [o, s] = q("all"), c = K(null), l = (n, r) => {
		let a = uc(e.pictures.map((e) => e.id), r);
		t({ pictures: [...e.pictures, {
			id: a,
			name: r.slice(0, 60),
			kind: i,
			data: n,
			rating: o
		}] });
	}, u = (n, r) => t({ pictures: e.pictures.map((e) => e.id === n ? {
		...e,
		...r
	} : e) });
	return /* @__PURE__ */ X(J, { children: [
		/* @__PURE__ */ Y(W, {
			label: "New picture is",
			value: i,
			options: pr,
			labels: gn,
			onChange: a
		}),
		/* @__PURE__ */ Y(W, {
			label: "Rated",
			value: o,
			options: ["all", "mature"],
			labels: Vn,
			onChange: s
		}),
		/* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: "A portrait wants a see-through background (Scene → Background). A background or illustration is the view as framed."
		}),
		/* @__PURE__ */ X("div", {
			className: "gs-m3d__row",
			children: [/* @__PURE__ */ Y("button", {
				type: "button",
				onClick: () => void r("Taking the view…", async () => l(await dc(await n(), i), `${i} ${e.pictures.length + 1}`)),
				children: "Take the 3D view"
			}), /* @__PURE__ */ Y("button", {
				type: "button",
				onClick: () => c.current?.click(),
				children: "From a file…"
			})]
		}),
		/* @__PURE__ */ Y("input", {
			ref: c,
			type: "file",
			accept: "image/png,image/jpeg,image/webp",
			hidden: !0,
			onChange: (e) => {
				let t = e.target.files?.[0];
				e.target.value = "", t && r("Adding the picture…", async () => l(await dc(t, i), t.name.replace(/\.[^.]+$/, "")));
			}
		}),
		/* @__PURE__ */ Y("ul", {
			className: "gs-vn-pictures",
			children: e.pictures.map((n) => /* @__PURE__ */ X("li", { children: [
				/* @__PURE__ */ Y("img", {
					src: n.data,
					alt: ""
				}),
				/* @__PURE__ */ Y("input", {
					"aria-label": "Picture name",
					value: n.name,
					maxLength: 60,
					onChange: (e) => u(n.id, { name: e.target.value })
				}),
				/* @__PURE__ */ Y("select", {
					"aria-label": "Kind",
					value: n.kind,
					onChange: (e) => u(n.id, { kind: e.target.value }),
					children: pr.map((e) => /* @__PURE__ */ Y("option", {
						value: e,
						children: gn[e]
					}, e))
				}),
				/* @__PURE__ */ X("select", {
					"aria-label": "Whose",
					value: n.heroine ?? "",
					onChange: (e) => u(n.id, { heroine: e.target.value || void 0 }),
					children: [/* @__PURE__ */ Y("option", {
						value: "",
						children: "Nobody's"
					}), e.heroines.map((e) => /* @__PURE__ */ Y("option", {
						value: e.id,
						children: e.name
					}, e.id))]
				}),
				/* @__PURE__ */ X("label", { children: [
					/* @__PURE__ */ Y("input", {
						type: "checkbox",
						checked: n.rating === "mature",
						onChange: (e) => u(n.id, { rating: e.target.checked ? "mature" : "all" })
					}),
					" ",
					"Mature"
				] }),
				/* @__PURE__ */ Y("button", {
					type: "button",
					"aria-label": `Remove ${n.name}`,
					onClick: () => t({ pictures: e.pictures.filter((e) => e.id !== n.id) }),
					children: "✕"
				})
			] }, n.id))
		})
	] });
}
function gc({ story: e, put: t, sounds: n }) {
	let [r, i] = q(e.start), a = e.scenes.find((e) => e.id === r) ?? e.scenes[0], o = (n) => t({ scenes: e.scenes.map((e) => e.id === a.id ? {
		...e,
		...n
	} : e) }), s = (n) => {
		let r = uc(e.scenes.map((e) => e.id), n);
		return t({ scenes: [...e.scenes, {
			id: r,
			title: n,
			stage: [],
			lines: [],
			next: {
				kind: "end",
				ending: e.endings[0]?.id ?? "end"
			}
		}] }), r;
	}, c = e.pictures.filter((e) => e.kind === "background");
	return /* @__PURE__ */ X(J, { children: [
		/* @__PURE__ */ X("label", {
			className: "gs-m3d__field",
			children: [/* @__PURE__ */ Y("span", { children: "Scene" }), /* @__PURE__ */ Y("select", {
				value: a.id,
				onChange: (e) => i(e.target.value),
				children: e.scenes.map((t) => /* @__PURE__ */ X("option", {
					value: t.id,
					children: [
						t.id === e.start ? "★ " : "",
						t.title,
						t.rating === "mature" ? " (mature)" : ""
					]
				}, t.id))
			})]
		}),
		/* @__PURE__ */ X("div", {
			className: "gs-m3d__row",
			children: [
				/* @__PURE__ */ Y("button", {
					type: "button",
					onClick: () => i(s("New scene")),
					children: "+ Scene"
				}),
				/* @__PURE__ */ Y("button", {
					type: "button",
					disabled: a.id === e.start,
					onClick: () => t({ start: a.id }),
					children: "Start here"
				}),
				/* @__PURE__ */ Y("button", {
					type: "button",
					disabled: e.scenes.length < 2,
					onClick: () => {
						let n = e.scenes.filter((e) => e.id !== a.id);
						t({
							scenes: n,
							start: e.start === a.id ? n[0].id : e.start
						}), i(n[0].id);
					},
					children: "Remove scene"
				})
			]
		}),
		/* @__PURE__ */ X("div", {
			className: "gs-m3d__panel",
			children: [
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: "Title" }), /* @__PURE__ */ Y("input", {
						value: a.title,
						maxLength: 60,
						onChange: (e) => o({ title: e.target.value })
					})]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: "Background" }), /* @__PURE__ */ X("select", {
						value: a.background ?? "",
						onChange: (e) => o({ background: e.target.value || void 0 }),
						children: [/* @__PURE__ */ Y("option", {
							value: "",
							children: "None"
						}), c.map((e) => /* @__PURE__ */ Y("option", {
							value: e.id,
							children: e.name
						}, e.id))]
					})]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: "Music" }), /* @__PURE__ */ X("select", {
						value: a.music ?? "",
						onChange: (e) => o({ music: e.target.value || void 0 }),
						children: [/* @__PURE__ */ Y("option", {
							value: "",
							children: "None"
						}), Object.entries(n).map(([e, t]) => /* @__PURE__ */ Y("option", {
							value: e,
							children: t.name
						}, e))]
					})]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("input", {
						type: "checkbox",
						checked: a.rating === "mature",
						onChange: (e) => o({ rating: e.target.checked ? "mature" : void 0 })
					}), /* @__PURE__ */ Y("span", { children: "Mature scene (adults only export)" })]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("input", {
						type: "checkbox",
						checked: !!a.entry,
						onChange: (e) => o({ entry: e.target.checked || void 0 })
					}), /* @__PURE__ */ Y("span", { children: "Starts from the world (an event: talking to her in town, visiting her room)" })]
				}),
				/* @__PURE__ */ Y("h5", { children: "On stage" }),
				Hn.map((t) => /* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: t }), /* @__PURE__ */ X("select", {
						value: a.stage.find((e) => e.at === t)?.heroine ?? "",
						onChange: (e) => o({ stage: [...a.stage.filter((e) => e.at !== t), ...e.target.value ? [{
							heroine: e.target.value,
							at: t
						}] : []] }),
						children: [/* @__PURE__ */ Y("option", {
							value: "",
							children: "Nobody"
						}), e.heroines.map((e) => /* @__PURE__ */ Y("option", {
							value: e.id,
							children: e.name
						}, e.id))]
					})]
				}, t)),
				/* @__PURE__ */ Y("h5", { children: "Lines" }),
				/* @__PURE__ */ Y(_c, {
					story: e,
					lines: a.lines,
					onChange: (e) => o({ lines: e })
				}),
				a.rating === "mature" && /* @__PURE__ */ X(J, { children: [
					/* @__PURE__ */ Y("h5", { children: "All-ages lines in its place" }),
					/* @__PURE__ */ Y("p", {
						className: "gs-m3d__note",
						children: "What the all-ages game plays instead: a fade, a knock at the door. Left empty, it skips ahead."
					}),
					/* @__PURE__ */ Y(_c, {
						story: e,
						lines: a.safe ?? [],
						onChange: (e) => o({ safe: e.length ? e : void 0 })
					})
				] }),
				/* @__PURE__ */ Y("h5", { children: "Then" }),
				/* @__PURE__ */ Y(bc, {
					story: e,
					next: a.next,
					onChange: (e) => o({ next: e }),
					onNewScene: s
				})
			]
		})
	] });
}
function _c({ story: e, lines: t, onChange: n }) {
	let r = (e, r) => n(t.map((t, n) => n === e ? {
		...t,
		...r
	} : t)), i = e.pictures.filter((e) => e.kind === "cg");
	return /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ Y("ol", {
		className: "gs-vn-lines",
		children: t.map((a, o) => {
			let s = e.heroines.find((e) => e.id === a.who);
			return /* @__PURE__ */ X("li", { children: [
				/* @__PURE__ */ X("div", {
					className: "gs-m3d__row",
					children: [
						/* @__PURE__ */ X("select", {
							"aria-label": "Who says it",
							value: a.who,
							onChange: (e) => r(o, { who: e.target.value }),
							children: [
								/* @__PURE__ */ Y("option", {
									value: "",
									children: "Narrator"
								}),
								/* @__PURE__ */ Y("option", {
									value: "me",
									children: "Me (the player)"
								}),
								e.heroines.map((e) => /* @__PURE__ */ Y("option", {
									value: e.id,
									children: e.name
								}, e.id))
							]
						}),
						s && /* @__PURE__ */ X("select", {
							"aria-label": "Face",
							value: a.face ?? "",
							onChange: (e) => r(o, { face: e.target.value || void 0 }),
							children: [/* @__PURE__ */ Y("option", {
								value: "",
								children: "Same face"
							}), [.../* @__PURE__ */ new Set([...lc, ...Object.keys(s.faces)])].map((e) => /* @__PURE__ */ Y("option", {
								value: e,
								children: e
							}, e))]
						}),
						/* @__PURE__ */ X("select", {
							"aria-label": "Illustration",
							value: a.cg === null ? "-" : a.cg ?? "",
							onChange: (e) => r(o, { cg: e.target.value === "" ? void 0 : e.target.value === "-" ? null : e.target.value }),
							children: [
								/* @__PURE__ */ Y("option", {
									value: "",
									children: "No change"
								}),
								/* @__PURE__ */ Y("option", {
									value: "-",
									children: "Hide illustration"
								}),
								i.map((e) => /* @__PURE__ */ X("option", {
									value: e.id,
									children: ["Show ", e.name]
								}, e.id))
							]
						}),
						/* @__PURE__ */ X("label", { children: [
							/* @__PURE__ */ Y("input", {
								type: "checkbox",
								checked: a.rating === "mature",
								onChange: (e) => r(o, { rating: e.target.checked ? "mature" : void 0 })
							}),
							" ",
							"Mature"
						] }),
						/* @__PURE__ */ Y("button", {
							type: "button",
							"aria-label": "Move up",
							disabled: !o,
							onClick: () => n(t.map((e, n) => n === o - 1 ? t[o] : n === o ? t[o - 1] : e)),
							children: "↑"
						}),
						/* @__PURE__ */ Y("button", {
							type: "button",
							"aria-label": "Remove line",
							onClick: () => n(t.filter((e, t) => t !== o)),
							children: "✕"
						})
					]
				}),
				/* @__PURE__ */ Y("textarea", {
					"aria-label": "Line",
					rows: 2,
					maxLength: 1e3,
					value: a.text,
					onChange: (e) => r(o, { text: e.target.value })
				}),
				/* @__PURE__ */ Y("textarea", {
					"aria-label": "Line in Japanese",
					placeholder: "日本語",
					rows: 2,
					maxLength: 1e3,
					value: a.textJa ?? "",
					onChange: (e) => r(o, { textJa: e.target.value || void 0 })
				})
			] }, o);
		})
	}), /* @__PURE__ */ Y("button", {
		type: "button",
		onClick: () => n([...t, {
			who: t.at(-1)?.who ?? "",
			text: "…"
		}]),
		children: "+ Line"
	})] });
}
function vc({ story: e, value: t, onChange: n, onNewScene: r, label: i }) {
	return /* @__PURE__ */ X("select", {
		"aria-label": i,
		value: t,
		onChange: (e) => n(e.target.value === "+" ? r("New scene") : e.target.value),
		children: [
			!e.scenes.some((e) => e.id === t) && /* @__PURE__ */ X("option", {
				value: t,
				children: [t, " (missing)"]
			}),
			e.scenes.map((e) => /* @__PURE__ */ Y("option", {
				value: e.id,
				children: e.title
			}, e.id)),
			/* @__PURE__ */ Y("option", {
				value: "+",
				children: "+ A new scene"
			})
		]
	});
}
function yc({ story: e, value: t, onChange: n }) {
	let r = e.heroines[0]?.id ?? "";
	return /* @__PURE__ */ X("span", {
		className: "gs-m3d__row",
		children: [
			/* @__PURE__ */ X("select", {
				"aria-label": "If",
				value: t.kind,
				onChange: (e) => {
					let t = e.target.value;
					n(t === "flag" ? {
						kind: t,
						flag: "flag",
						is: !0
					} : t === "route" ? {
						kind: t,
						heroine: r
					} : {
						kind: t,
						heroine: r,
						atLeast: 10
					});
				},
				children: [
					/* @__PURE__ */ Y("option", {
						value: "route",
						children: "On her route"
					}),
					/* @__PURE__ */ Y("option", {
						value: "affection",
						children: "Affection at least"
					}),
					/* @__PURE__ */ Y("option", {
						value: "flag",
						children: "Flag"
					})
				]
			}),
			t.kind !== "flag" && /* @__PURE__ */ Y("select", {
				"aria-label": "Heroine",
				value: t.heroine,
				onChange: (e) => n({
					...t,
					heroine: e.target.value
				}),
				children: e.heroines.map((e) => /* @__PURE__ */ Y("option", {
					value: e.id,
					children: e.name
				}, e.id))
			}),
			t.kind === "affection" && /* @__PURE__ */ Y("input", {
				"aria-label": "At least",
				type: "number",
				value: t.atLeast,
				onChange: (e) => n({
					...t,
					atLeast: Math.round(Number(e.target.value) || 0)
				})
			}),
			t.kind === "flag" && /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ Y("input", {
				"aria-label": "Flag",
				value: t.flag,
				maxLength: 40,
				onChange: (e) => n({
					...t,
					flag: e.target.value
				})
			}), /* @__PURE__ */ X("select", {
				"aria-label": "Is",
				value: t.is ? "set" : "unset",
				onChange: (e) => n({
					...t,
					is: e.target.value === "set"
				}),
				children: [/* @__PURE__ */ Y("option", {
					value: "set",
					children: "is set"
				}), /* @__PURE__ */ Y("option", {
					value: "unset",
					children: "is not set"
				})]
			})] })
		]
	});
}
function bc({ story: e, next: t, onChange: n, onNewScene: r }) {
	let i = t.kind === "go" ? t.go : t.kind === "branch" ? t.else : e.scenes[0].id;
	return /* @__PURE__ */ X(J, { children: [
		/* @__PURE__ */ Y(W, {
			label: "Then",
			value: t.kind,
			options: sc,
			labels: cc,
			onChange: (t) => n(t === "go" ? {
				kind: t,
				go: i
			} : t === "choose" ? {
				kind: t,
				choices: [{
					text: "A choice",
					go: i
				}]
			} : t === "branch" ? {
				kind: t,
				ways: [],
				else: i
			} : t === "return" ? { kind: t } : {
				kind: t,
				ending: e.endings[0]?.id ?? "end"
			})
		}),
		t.kind === "go" && /* @__PURE__ */ Y(vc, {
			story: e,
			label: "Go to",
			value: t.go,
			onChange: (e) => n({
				kind: "go",
				go: e
			}),
			onNewScene: r
		}),
		t.kind === "choose" && /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ Y("ol", {
			className: "gs-vn-lines",
			children: t.choices.map((i, a) => {
				if (t.kind !== "choose") return null;
				let o = (e) => n({
					kind: "choose",
					choices: t.choices.map((t, n) => n === a ? {
						...t,
						...e
					} : t)
				});
				return /* @__PURE__ */ X("li", {
					className: "gs-m3d__panel",
					children: [
						/* @__PURE__ */ Y("input", {
							"aria-label": "Choice",
							value: i.text,
							maxLength: 200,
							onChange: (e) => o({ text: e.target.value })
						}),
						/* @__PURE__ */ Y("input", {
							"aria-label": "Choice in Japanese",
							placeholder: "日本語",
							value: i.textJa ?? "",
							maxLength: 200,
							onChange: (e) => o({ textJa: e.target.value || void 0 })
						}),
						/* @__PURE__ */ Y("div", {
							className: "gs-m3d__row",
							children: e.heroines.map((e) => /* @__PURE__ */ X("label", {
								title: `Affection for ${e.name}`,
								children: [
									/* @__PURE__ */ Y("span", {
										style: { color: e.colour },
										children: e.name.split(" ")[0]
									}),
									" ",
									/* @__PURE__ */ Y("input", {
										type: "number",
										className: "gs-vn-num",
										value: i.affection?.[e.id] ?? 0,
										onChange: (t) => {
											let n = {
												...i.affection,
												[e.id]: Math.round(Number(t.target.value) || 0)
											};
											n[e.id] || delete n[e.id], o({ affection: Object.keys(n).length ? n : void 0 });
										}
									})
								]
							}, e.id))
						}),
						/* @__PURE__ */ X("label", {
							className: "gs-m3d__field",
							children: [/* @__PURE__ */ Y("span", { children: "Sets flags" }), /* @__PURE__ */ Y("input", {
								value: (i.set ?? []).join(", "),
								onChange: (e) => {
									let t = e.target.value.split(",").map((e) => e.trim()).filter(Boolean);
									o({ set: t.length ? t : void 0 });
								}
							})]
						}),
						/* @__PURE__ */ X("label", {
							className: "gs-m3d__field",
							children: [/* @__PURE__ */ Y("input", {
								type: "checkbox",
								checked: !!i.when,
								onChange: (e) => o({ when: e.target.checked ? {
									kind: "flag",
									flag: "flag",
									is: !0
								} : void 0 })
							}), /* @__PURE__ */ Y("span", { children: "Only shown when…" })]
						}),
						i.when && /* @__PURE__ */ Y(yc, {
							story: e,
							value: i.when,
							onChange: (e) => o({ when: e })
						}),
						/* @__PURE__ */ X("div", {
							className: "gs-m3d__row",
							children: [
								/* @__PURE__ */ Y("span", { children: "Goes to" }),
								/* @__PURE__ */ Y(vc, {
									story: e,
									label: "Goes to",
									value: i.go,
									onChange: (e) => o({ go: e }),
									onNewScene: r
								}),
								/* @__PURE__ */ Y("button", {
									type: "button",
									"aria-label": "Remove choice",
									onClick: () => n({
										kind: "choose",
										choices: t.choices.filter((e, t) => t !== a)
									}),
									children: "✕"
								})
							]
						})
					]
				}, a);
			})
		}), t.choices.length < 6 && /* @__PURE__ */ Y("button", {
			type: "button",
			onClick: () => n({
				kind: "choose",
				choices: [...t.choices, {
					text: "Another choice",
					go: i
				}]
			}),
			children: "+ Choice"
		})] }),
		t.kind === "branch" && /* @__PURE__ */ X(J, { children: [
			/* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: "The first that holds wins. \"On her route\" means her affection has reached her route and is the most of anyone."
			}),
			/* @__PURE__ */ Y("ol", {
				className: "gs-vn-lines",
				children: t.ways.map((i, a) => /* @__PURE__ */ X("li", { children: [/* @__PURE__ */ Y(yc, {
					story: e,
					value: i.if,
					onChange: (e) => n({
						...t,
						ways: t.ways.map((t, n) => n === a ? {
							...t,
							if: e
						} : t)
					})
				}), /* @__PURE__ */ X("div", {
					className: "gs-m3d__row",
					children: [
						/* @__PURE__ */ Y("span", { children: "Go to" }),
						/* @__PURE__ */ Y(vc, {
							story: e,
							label: "Go to",
							value: i.go,
							onChange: (e) => n({
								...t,
								ways: t.ways.map((t, n) => n === a ? {
									...t,
									go: e
								} : t)
							}),
							onNewScene: r
						}),
						/* @__PURE__ */ Y("button", {
							type: "button",
							"aria-label": "Remove way",
							onClick: () => n({
								...t,
								ways: t.ways.filter((e, t) => t !== a)
							}),
							children: "✕"
						})
					]
				})] }, a))
			}),
			/* @__PURE__ */ Y("button", {
				type: "button",
				disabled: !e.heroines.length,
				onClick: () => n({
					...t,
					ways: [...t.ways, {
						if: {
							kind: "route",
							heroine: e.heroines[0].id
						},
						go: i
					}]
				}),
				children: "+ Way"
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__row",
				children: [/* @__PURE__ */ Y("span", { children: "Otherwise" }), /* @__PURE__ */ Y(vc, {
					story: e,
					label: "Otherwise",
					value: t.else,
					onChange: (e) => n({
						...t,
						else: e
					}),
					onNewScene: r
				})]
			})
		] }),
		t.kind === "return" && /* @__PURE__ */ Y("p", {
			className: "gs-m3d__hint",
			children: "The scene is over and the player is back in the game's world (its town or map) to walk to the next event."
		}),
		t.kind === "end" && /* @__PURE__ */ X("select", {
			"aria-label": "Ending",
			value: t.ending,
			onChange: (e) => n({
				kind: "end",
				ending: e.target.value
			}),
			children: [!e.endings.some((e) => e.id === t.ending) && /* @__PURE__ */ X("option", {
				value: t.ending,
				children: [t.ending, " (missing)"]
			}), e.endings.map((e) => /* @__PURE__ */ Y("option", {
				value: e.id,
				children: e.title
			}, e.id))]
		})
	] });
}
function xc({ story: e, put: t, achievements: n }) {
	let r = (n, r) => t({ endings: e.endings.map((e) => e.id === n ? {
		...e,
		...r
	} : e) }), i = e.pictures.filter((e) => e.kind === "cg");
	return /* @__PURE__ */ X(J, { children: [e.endings.map((a) => /* @__PURE__ */ X("div", {
		className: "gs-m3d__panel",
		children: [
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Title" }), /* @__PURE__ */ Y("input", {
					value: a.title,
					maxLength: 60,
					onChange: (e) => r(a.id, { title: e.target.value })
				})]
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Title (日本語)" }), /* @__PURE__ */ Y("input", {
					value: a.titleJa ?? "",
					maxLength: 60,
					onChange: (e) => r(a.id, { titleJa: e.target.value || void 0 })
				})]
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Kind" }), /* @__PURE__ */ Y("select", {
					value: a.kind,
					onChange: (e) => r(a.id, { kind: e.target.value }),
					children: _n.map((e) => /* @__PURE__ */ Y("option", {
						value: e,
						children: e
					}, e))
				})]
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Heroine" }), /* @__PURE__ */ X("select", {
					value: a.heroine ?? "",
					onChange: (e) => r(a.id, { heroine: e.target.value || void 0 }),
					children: [/* @__PURE__ */ Y("option", {
						value: "",
						children: "Nobody's"
					}), e.heroines.map((e) => /* @__PURE__ */ Y("option", {
						value: e.id,
						children: e.name
					}, e.id))]
				})]
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Illustration" }), /* @__PURE__ */ X("select", {
					value: a.cg ?? "",
					onChange: (e) => r(a.id, { cg: e.target.value || void 0 }),
					children: [/* @__PURE__ */ Y("option", {
						value: "",
						children: "None"
					}), i.map((e) => /* @__PURE__ */ Y("option", {
						value: e.id,
						children: e.name
					}, e.id))]
				})]
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Achievement" }), /* @__PURE__ */ X("select", {
					value: a.achievement ?? "",
					onChange: (e) => r(a.id, { achievement: e.target.value || void 0 }),
					children: [/* @__PURE__ */ Y("option", {
						value: "",
						children: "None"
					}), n.map((e) => /* @__PURE__ */ Y("option", {
						value: e.id,
						children: e.title
					}, e.id))]
				})]
			}),
			/* @__PURE__ */ X("button", {
				type: "button",
				onClick: () => t({ endings: e.endings.filter((e) => e.id !== a.id) }),
				children: ["Remove ", a.title]
			})
		]
	}, a.id)), /* @__PURE__ */ Y("button", {
		type: "button",
		onClick: () => t({ endings: [...e.endings, {
			id: uc(e.endings.map((e) => e.id), "ending"),
			title: "New ending",
			kind: "normal"
		}] }),
		children: "+ Ending"
	})] });
}
function Sc({ story: e }) {
	let t = Xr(() => yr(e), [e]), n = Xr(() => {
		try {
			return gr(e, "mature", "x").reduce((e, t) => e + t.bytes.length, 0) / 1e6;
		} catch {
			return null;
		}
	}, [e]);
	return /* @__PURE__ */ X(J, { children: [t.length ? /* @__PURE__ */ Y("ul", {
		className: "gs-m3d__findings",
		children: t.map((e, t) => /* @__PURE__ */ Y("li", {
			className: e.level === "error" ? "is-bad" : "",
			children: e.text
		}, t))
	}) : /* @__PURE__ */ Y("p", {
		className: "gs-m3d__note",
		children: "Nothing to fix: every scene is reached, every route can open, every ending can be reached."
	}), n !== null && /* @__PURE__ */ X("p", {
		className: "gs-m3d__note",
		children: [
			"The pack is about ",
			n.toFixed(1),
			" MB",
			n > 40 ? ": big for a browser demo. Smaller pictures, or fewer in the demo, help." : "."
		]
	})] });
}
//#endregion
//#region src/model3d/ProjectSection.tsx
function Cc({ api: e, libraryUrl: t, onStart: n, onOpen: r, run: i, editor: a, selected: s, shape: c, takePicture: l }) {
	let [u, d] = q("My game"), [f, p] = q(null), [m, h] = q(!1), g = K(null), _ = K(null), v = /* @__PURE__ */ Y("input", {
		ref: g,
		type: "file",
		accept: ".json,application/json",
		hidden: !0,
		onChange: (e) => {
			let t = e.target.files?.[0];
			e.target.value = "", t && r(t);
		}
	});
	if (!e) return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Game project" }),
		/* @__PURE__ */ Y(o, { id: "m3dProject" }),
		/* @__PURE__ */ X("label", {
			className: "gs-m3d__field",
			children: [/* @__PURE__ */ Y("span", { children: "Title" }), /* @__PURE__ */ Y("input", {
				value: u,
				maxLength: 60,
				onChange: (e) => d(e.target.value)
			})]
		}),
		/* @__PURE__ */ X("div", {
			className: "gs-m3d__game-ruletools",
			children: [/* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => n(u),
				children: "Make this design a game's first level"
			}), /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => g.current?.click(),
				children: "Open a project…"
			})]
		}),
		v
	] });
	let { project: y, current: b } = e, x = (t, n) => {
		let r = b.kind === t && b.id === n.id;
		return /* @__PURE__ */ X("li", {
			className: r ? "is-on" : "",
			children: [
				/* @__PURE__ */ Y("input", {
					"aria-label": "Name",
					value: n.name,
					onChange: (r) => e.rename(t, n.id, r.target.value)
				}),
				r ? /* @__PURE__ */ Y("span", {
					className: "gs-m3d__note",
					children: "editing"
				}) : /* @__PURE__ */ Y("button", {
					type: "button",
					onClick: () => e.open(t, n.id),
					children: "Open"
				}),
				t === "level" && /* @__PURE__ */ Y("button", {
					type: "button",
					className: y.start === n.id ? "is-on" : "",
					title: "The level the game starts with",
					onClick: () => e.setStart(n.id),
					children: y.start === n.id ? "★ Start" : "Start"
				}),
				t === "character" && b.kind === "level" && /* @__PURE__ */ Y("button", {
					type: "button",
					title: "Put it in the level being edited",
					onClick: () => void i(`Placing ${n.name}…`, () => e.place(n.id)),
					children: "Place here"
				}),
				!r && /* @__PURE__ */ Y("button", {
					type: "button",
					"aria-label": `Remove ${n.name}`,
					onClick: () => e.remove(t, n.id),
					children: "✕"
				})
			]
		}, n.id);
	};
	return /* @__PURE__ */ X(J, { children: [
		/* @__PURE__ */ X("section", { children: [
			/* @__PURE__ */ Y("h4", { children: "Game project" }),
			/* @__PURE__ */ Y(o, { id: "m3dProject" }),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Title" }), /* @__PURE__ */ Y("input", {
					value: y.title,
					maxLength: 60,
					onChange: (t) => e.setTitle(t.target.value)
				})]
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__game-ruletools",
				children: [
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						onClick: e.save,
						children: "Save project"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => g.current?.click(),
						children: "Open…"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: e.close,
						title: "Stop working on the project (save it first)",
						children: "Close"
					})
				]
			}),
			v
		] }),
		/* @__PURE__ */ X("section", { children: [
			/* @__PURE__ */ Y("h4", { children: "Levels" }),
			/* @__PURE__ */ Y("ul", {
				className: "gs-m3d__game-entries",
				children: y.levels.map((e) => x("level", e))
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__game-ruletools",
				children: [/* @__PURE__ */ Y("button", {
					type: "button",
					onClick: () => e.addLevel(!1),
					children: "+ Empty level"
				}), /* @__PURE__ */ Y("button", {
					type: "button",
					onClick: () => e.addLevel(!0),
					children: "+ Copy of this one"
				})]
			})
		] }),
		/* @__PURE__ */ X("section", { children: [
			/* @__PURE__ */ Y("h4", { children: "Characters" }),
			/* @__PURE__ */ Y(o, { id: "m3dActors" }),
			/* @__PURE__ */ Y("ul", {
				className: "gs-m3d__game-entries",
				children: y.characters.map((e) => x("character", e))
			}),
			/* @__PURE__ */ Y("button", {
				type: "button",
				onClick: () => p("creator"),
				children: "+ New character"
			}),
			f === "creator" && /* @__PURE__ */ Y(Ks, {
				base: t ?? void 0,
				forGame: !0,
				onClose: () => p(null),
				onMake: (t, n, r) => {
					p(null);
					let a = r.replace(/ Animations can make it move\.$/, "");
					e.setCredits([y.credits, a].filter(Boolean).join("\n")), i("Adding the character…", () => e.addCharacterModel(t.name.replace(/\.glb$/i, ""), t));
				}
			})
		] }),
		/* @__PURE__ */ X("section", { children: [
			/* @__PURE__ */ Y("h4", { children: "Share the game" }),
			/* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => void i("Making the web game…", () => Js(e.synced())),
				children: "Save as a web game (.zip)"
			}),
			/* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: "A folder of files that plays in any browser: put it on itch.io, Netlify or any web host."
			}),
			/* @__PURE__ */ Y(o, { id: "m3dWebGame" })
		] }),
		/* @__PURE__ */ Y(rc, {
			api: e,
			editor: a,
			selected: s,
			shape: c,
			libraryUrl: t,
			run: i
		}),
		/* @__PURE__ */ X("section", { children: [
			/* @__PURE__ */ Y("h4", { children: "Sounds and music" }),
			/* @__PURE__ */ Y("ul", {
				className: "gs-m3d__game-entries",
				children: Object.entries(y.sounds).map(([t, n]) => /* @__PURE__ */ X("li", { children: [
					/* @__PURE__ */ Y("span", { children: n.name }),
					/* @__PURE__ */ Y("button", {
						type: "button",
						onClick: () => void new Audio(n.data).play(),
						children: "▶"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						"aria-label": `Remove ${n.name}`,
						onClick: () => e.removeSound(t),
						children: "✕"
					})
				] }, t))
			}),
			/* @__PURE__ */ Y("button", {
				type: "button",
				onClick: () => _.current?.click(),
				children: "+ Sound or music…"
			}),
			/* @__PURE__ */ Y("button", {
				type: "button",
				title: "Narration or a character's line: type or say it, pick a voice",
				onClick: () => h(!0),
				children: "+ Voice line…"
			}),
			m && /* @__PURE__ */ Y(ls, {
				onClose: () => h(!1),
				onMake: (t) => {
					h(!1), i("Adding the voice line…", async () => void await e.addSound(t));
				}
			}),
			/* @__PURE__ */ Y("input", {
				ref: _,
				type: "file",
				accept: "audio/*",
				hidden: !0,
				onChange: (t) => {
					let n = t.target.files?.[0];
					t.target.value = "", n && i("Adding the sound…", async () => void await e.addSound(n));
				}
			})
		] }),
		/* @__PURE__ */ Y(wc, {
			list: y.achievements ?? [],
			onChange: e.setAchievements
		}),
		/* @__PURE__ */ Y(pc, {
			story: y.romance,
			onChange: e.setRomance,
			title: y.title,
			characters: y.characters,
			achievements: y.achievements ?? [],
			sounds: y.sounds,
			takePicture: l,
			run: i
		}),
		/* @__PURE__ */ X("section", { children: [/* @__PURE__ */ Y("h4", { children: "Credits" }), /* @__PURE__ */ Y("textarea", {
			rows: 3,
			"aria-label": "Credits",
			value: y.credits ?? "",
			onChange: (t) => e.setCredits(t.target.value)
		})] })
	] });
}
function wc({ list: e, onChange: t }) {
	let [n, r] = q(null), i = (r) => t(e.map((e) => e.id === n ? r : e)), a = e.reduce((e, t) => e + (t.points ?? 0), 0), s = e.find((e) => e.id === n);
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Achievements" }),
		/* @__PURE__ */ Y(o, { id: "m3dAchievements" }),
		/* @__PURE__ */ Y("ul", {
			className: "gs-m3d__game-entries",
			children: e.map((i) => /* @__PURE__ */ X("li", { children: [/* @__PURE__ */ X("button", {
				type: "button",
				"aria-expanded": n === i.id,
				onClick: () => r(n === i.id ? null : i.id),
				children: [i.hidden ? "🔒 " : "", i.title]
			}), /* @__PURE__ */ Y("button", {
				type: "button",
				"aria-label": `Remove ${i.title}`,
				onClick: () => t(e.filter((e) => e.id !== i.id)),
				children: "✕"
			})] }, i.id))
		}),
		s && /* @__PURE__ */ X("div", {
			className: "gs-m3d__panel",
			children: [
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: "Id" }), /* @__PURE__ */ Y("input", {
						value: s.id,
						maxLength: 40,
						onChange: (t) => {
							let n = t.target.value.replace(/[^\w-]/g, "");
							n && !e.some((e) => e.id === n && e !== s) && (i({
								...s,
								id: n
							}), r(n));
						}
					})]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: "Title" }), /* @__PURE__ */ Y("input", {
						value: s.title,
						maxLength: 60,
						onChange: (e) => i({
							...s,
							title: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: "How to earn it" }), /* @__PURE__ */ Y("input", {
						value: s.how,
						maxLength: 200,
						onChange: (e) => i({
							...s,
							how: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: "Title (日本語)" }), /* @__PURE__ */ Y("input", {
						value: s.titleJa ?? "",
						maxLength: 60,
						onChange: (e) => i({
							...s,
							titleJa: e.target.value || void 0
						})
					})]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: "How (日本語)" }), /* @__PURE__ */ Y("input", {
						value: s.howJa ?? "",
						maxLength: 200,
						onChange: (e) => i({
							...s,
							howJa: e.target.value || void 0
						})
					})]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: "Points" }), /* @__PURE__ */ Y("input", {
						type: "number",
						min: 0,
						max: 100,
						value: s.points ?? 0,
						onChange: (e) => i({
							...s,
							points: Math.max(0, Math.min(100, Math.round(Number(e.target.value) || 0)))
						})
					})]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("input", {
						type: "checkbox",
						checked: !!s.hidden,
						onChange: (e) => i({
							...s,
							hidden: e.target.checked || void 0
						})
					}), /* @__PURE__ */ Y("span", { children: "A secret until it's earned" })]
				})
			]
		}),
		/* @__PURE__ */ Y("button", {
			type: "button",
			onClick: () => {
				let n = e.length + 1;
				for (; e.some((e) => e.id === `achievement${n}`);) n++;
				let i = {
					id: `achievement${n}`,
					title: `Achievement ${n}`,
					how: "What to do to earn it.",
					points: 10
				};
				t([...e, i]), r(i.id);
			},
			children: "+ Achievement"
		}),
		!!e.length && /* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: a > 1e3 ? `${a} points: Game Center takes 1000 at most.` : `${a} of Game Center's 1000 points.`
		})
	] });
}
//#endregion
//#region src/model3d/useGameProject.ts
var Tc = (e, t) => {
	let n = document.createElement("a");
	n.href = URL.createObjectURL(new Blob([e], { type: "application/json" })), n.download = t, n.click(), setTimeout(() => URL.revokeObjectURL(n.href), 4e3);
}, Ec = (e) => new Promise((t, n) => {
	let r = new FileReader();
	r.onload = () => t(String(r.result)), r.onerror = () => n(/* @__PURE__ */ Error("The sound could not be read.")), r.readAsDataURL(e);
});
function Dc(e, t) {
	let [n, r] = q(null), i = K(n);
	i.current = n;
	let a = Yr(() => {
		let t = i.current, n = t.current.kind === "level" ? "levels" : "characters", r = F(e.document);
		return {
			...t.project,
			[n]: t.project[n].map((e) => e.id === t.current.id ? {
				...e,
				design: r
			} : e)
		};
	}, [e]), o = (e, t = i.current.current) => {
		i.current = {
			project: e,
			current: t
		}, r(i.current);
	}, s = (t, n, r) => {
		let i = (n === "level" ? t.levels : t.characters).find((e) => e.id === r);
		i && (o(t, {
			kind: n,
			id: r
		}), e.replaceDesign(i.design, `Open ${i.name}`));
	};
	return {
		api: n && {
			project: n.project,
			current: n.current,
			synced: a,
			open: (e, t) => s(a(), e, t),
			addLevel: (t) => {
				let n = a(), r = Or(n, `Level ${n.levels.length + 1}`), i = t ? F(e.document) : {
					...ue(),
					shapes: []
				};
				s({
					...n,
					levels: [...n.levels, {
						id: r,
						name: `Level ${n.levels.length + 1}`,
						design: i
					}]
				}, "level", r);
			},
			addCharacter: (e) => {
				let t = a(), n = Or(t, e.name);
				s({
					...t,
					characters: [...t.characters, {
						id: n,
						name: e.name,
						design: mr(e)
					}]
				}, "character", n);
			},
			addCharacterModel: async (t, n) => {
				let { asset: r } = await v([n]), i = a(), o = Or(i, t);
				s({
					...i,
					characters: [...i.characters, {
						id: o,
						name: t.slice(0, 60),
						design: {
							...ue(),
							shapes: []
						}
					}]
				}, "character", o), e.addModel(r, { position: [
					0,
					r.size[1] / 2,
					0
				] }, Math.max(...r.size)), e.frameAll(1);
			},
			rename: (e, t, n) => {
				let r = i.current.project, a = e === "level" ? "levels" : "characters";
				o({
					...r,
					[a]: r[a].map((e) => e.id === t ? {
						...e,
						name: n.slice(0, 60)
					} : e)
				});
			},
			remove: (e, n) => {
				let r = a(), s = i.current.current;
				if (s.kind === e && s.id === n) return t("Open another level or character first: this one is being edited.");
				if (e === "level" && r.levels.length < 2) return;
				let c = e === "level" ? "levels" : "characters", l = {
					...r,
					[c]: r[c].filter((e) => e.id !== n)
				};
				o({
					...l,
					start: l.levels.some((e) => e.id === l.start) ? l.start : l.levels[0].id
				});
			},
			setStart: (e) => o({
				...i.current.project,
				start: e
			}),
			setTitle: (e) => o({
				...i.current.project,
				title: e.slice(0, 60)
			}),
			setCredits: (e) => o({
				...i.current.project,
				credits: e.slice(0, 4e3) || void 0
			}),
			setAchievements: (e) => o({
				...i.current.project,
				achievements: e.length ? e : void 0
			}),
			setRomance: (e) => o({
				...i.current.project,
				romance: e
			}),
			addSound: async (e) => {
				if (!/^audio\//.test(e.type)) throw Error("That is not a sound: pick a .wav, .ogg or .mp3.");
				let t = await Ec(e);
				if (t.length > 8e6) throw Error("That sound is too long: keep each under about a minute (6 MB).");
				let n = i.current.project, r = e.name.replace(/\.[^.]+$/, ""), a = r.toLowerCase().replace(/[^\w]+/g, "-").replace(/^-|-$/g, "").slice(0, 30) || "sound";
				for (let e = 2; n.sounds[a]; e++) a = `${a.replace(/-\d+$/, "")}-${e}`;
				return o({
					...n,
					sounds: {
						...n.sounds,
						[a]: {
							name: r.slice(0, 60),
							data: t
						}
					}
				}), a;
			},
			adopt: (e) => {
				let { kind: t, id: n } = i.current.current;
				s(e, t, n);
			},
			removeSound: (e) => {
				let t = i.current.project, { [e]: n, ...r } = t.sounds;
				o({
					...t,
					sounds: r
				});
			},
			place: async (n) => {
				let r = i.current;
				if (r.current.kind !== "level") return t("Open a level to place a character in it.");
				let a = r.project.characters.find((e) => e.id === n);
				if (!a) return;
				let { asset: o, height: s } = await mn(a), c = _e(), l = e.document.camera.target, u = cn(a, c, o, s, [
					l[0],
					0,
					l[2]
				]), d = vn(a)?.rig;
				d && (u.rig = d);
				let f = e.document, p = f.game ?? Ct(f);
				e.replaceDesign({
					...f,
					assets: {
						...f.assets ?? {},
						[c]: o
					},
					shapes: [...f.shapes, u],
					game: ke({
						...p,
						actors: [...p.actors ?? [], {
							shape: u.id,
							character: a.id,
							faces: !0
						}]
					})
				}, `Place ${a.name}`);
			},
			save: () => {
				let e = a();
				o(e), Tc(Rn(e), `${e.title.replace(/[^\w -]+/g, "").trim() || "game"}.json`);
			},
			close: () => {
				i.current = null, r(null);
			}
		},
		start: (t) => o(fn(F(e.document), t), {
			kind: "level",
			id: "level1"
		}),
		load: (e) => {
			let n = Pn(e);
			s(n, "level", n.start);
			let r = un(e);
			r && t(r);
		}
	};
}
//#endregion
//#region src/model3d/PerfGauge.tsx
var Oc = "gleamshelf:perf-gauge";
function kc() {
	try {
		return localStorage.getItem(Oc) === "on";
	} catch {
		return !1;
	}
}
function Ac(e) {
	try {
		localStorage.setItem(Oc, e ? "on" : "off");
	} catch {}
}
var jc = 50, Mc = 25;
function Nc({ viewport: e }) {
	let [t, n] = q(null);
	if (G(() => {
		let t = () => n(e()?.stats() ?? null);
		t();
		let r = window.setInterval(t, 250);
		return () => window.clearInterval(r);
	}, [e]), !t) return null;
	let r = t.fps ? t.fps >= jc ? "smooth" : t.fps >= Mc ? "ok" : "slow" : "still";
	return /* @__PURE__ */ Y("div", {
		className: "gs-perf",
		role: "status",
		"aria-label": "Performance",
		children: /* @__PURE__ */ X("dl", { children: [
			/* @__PURE__ */ Y("dt", { children: "Frames a second" }),
			/* @__PURE__ */ Y("dd", {
				className: `gs-perf__fps gs-perf__fps--${r}`,
				children: t.fps ? t.fps : "–"
			}),
			/* @__PURE__ */ Y("dt", { children: "Frame" }),
			/* @__PURE__ */ Y("dd", { children: t.frameMs ? `${t.frameMs.toFixed(1)} ms` : "Still" }),
			/* @__PURE__ */ Y("dt", { children: "Page thread" }),
			/* @__PURE__ */ Y("dd", { children: t.cpuMs ? `${t.cpuMs.toFixed(1)} ms` : "–" }),
			/* @__PURE__ */ Y("dt", { children: "Drawn" }),
			/* @__PURE__ */ Y("dd", { children: `${t.width}×${t.height} (${Math.round(t.share * 100)}%${t.moving ? ", moving" : ""})` }),
			/* @__PURE__ */ Y("dt", { children: "This computer" }),
			/* @__PURE__ */ Y("dd", { children: t.rate ? `${(t.rate / 1e3).toFixed(1)} Mpx/s` : "Learning…" }),
			/* @__PURE__ */ Y("dt", { children: "Shapes" }),
			/* @__PURE__ */ Y("dd", { children: t.shapes }),
			/* @__PURE__ */ Y("dt", { children: "Models" }),
			/* @__PURE__ */ Y("dd", { children: t.models }),
			/* @__PURE__ */ Y("dt", { children: "Draw calls" }),
			/* @__PURE__ */ Y("dd", { children: t.calls }),
			/* @__PURE__ */ Y("dt", { children: "Triangles" }),
			/* @__PURE__ */ Y("dd", { children: t.triangles.toLocaleString() }),
			/* @__PURE__ */ Y("dt", { children: "Tile lists" }),
			/* @__PURE__ */ Y("dd", { children: t.tileEntries ? t.tileEntries.toLocaleString() : "Off" }),
			/* @__PURE__ */ Y("dt", { children: "Textures" }),
			/* @__PURE__ */ Y("dd", { children: `${t.textureMB} of ${t.textureBudgetMB} MB` }),
			/* @__PURE__ */ Y("dt", { children: "Baked field" }),
			/* @__PURE__ */ Y("dd", { children: t.field ? t.field.join("×") : "Off" }),
			t.gpu && /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ Y("dt", { children: "Graphics" }), /* @__PURE__ */ Y("dd", { children: t.gpu })] })
		] })
	});
}
//#endregion
//#region src/model3d/MotionSection.tsx
var Pc = {
	spin: "turns",
	float: "rises",
	bounce: "hops",
	sway: "sways",
	pulse: "pulses",
	wiggle: "wiggles",
	orbit: "times round",
	pop: "pops"
}, Fc = [
	"float",
	"bounce",
	"sway",
	"pulse",
	"wiggle"
];
function Ic({ editor: e, items: t, playing: n, onPlay: r }) {
	let i = t.find((e) => e.shape.motion)?.shape.motion, a = t.some((e) => e.shape.motion?.kind !== i?.kind), s = (n, r) => e.updateShapesAt(t.map(({ ref: e, shape: t }) => [e, { motion: n === null ? void 0 : {
		...Kt,
		...t.motion ?? i ?? {},
		...n
	} }]), r), c = (n, r, a) => i && /* @__PURE__ */ Y(U, {
		label: n,
		value: i[r],
		min: 0,
		max: 1,
		step: .01,
		format: a,
		onBegin: () => e.begin(n),
		onChange: (n) => e.updateShapesAt(t.map(({ ref: e, shape: t }) => [e, { motion: {
			...Kt,
			...t.motion ?? i,
			[r]: n
		} }])),
		onEnd: () => e.commit()
	});
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Motion" }),
		/* @__PURE__ */ X("label", {
			className: "gs-m3d__field",
			children: [/* @__PURE__ */ Y("span", { children: "Moves" }), /* @__PURE__ */ X("select", {
				value: a ? "" : i?.kind ?? "none",
				onChange: (e) => {
					let t = e.target.value;
					t === "none" ? s(null, "No motion") : t && s({ kind: t }, pe[t]);
				},
				children: [
					a && /* @__PURE__ */ Y("option", {
						value: "",
						children: "Different ones"
					}),
					/* @__PURE__ */ Y("option", {
						value: "none",
						children: "Does not move"
					}),
					Ve.map((e) => /* @__PURE__ */ Y("option", {
						value: e,
						children: pe[e]
					}, e))
				]
			})]
		}),
		i && !a && /* @__PURE__ */ X(J, { children: [
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Times" }), /* @__PURE__ */ Y("select", {
					value: i.times,
					onChange: (e) => s({ times: Number(e.target.value) }, "Motion times"),
					children: [
						1,
						2,
						3,
						4,
						6,
						8
					].map((e) => /* @__PURE__ */ X("option", {
						value: e,
						children: [
							e,
							" ",
							Pc[i.kind],
							" a clip"
						]
					}, e))
				})]
			}),
			Fc.includes(i.kind) && c("How far", "amount", (e) => `${Math.round(e * 100)}%`),
			i.kind === "spin" && /* @__PURE__ */ Y(W, {
				label: "About",
				value: i.axis,
				options: [
					"y",
					"x",
					"z"
				],
				labels: {
					y: "Upright",
					x: "Tumble",
					z: "Roll"
				},
				onChange: (e) => s({ axis: e }, "Spin axis")
			}),
			i.kind === "sway" && /* @__PURE__ */ Y(W, {
				label: "Sways",
				value: i.axis === "x" ? "x" : "z",
				options: ["z", "x"],
				labels: {
					z: "Side to side",
					x: "Front to back"
				},
				onChange: (e) => s({ axis: e }, "Sway direction")
			}),
			(i.kind === "spin" || i.kind === "orbit") && /* @__PURE__ */ X("label", {
				className: "gs-m3d__check",
				children: [/* @__PURE__ */ Y("input", {
					type: "checkbox",
					checked: i.reverse,
					onChange: (e) => s({ reverse: e.target.checked }, "Motion direction")
				}), " The other way"]
			}),
			c("Start later", "delay", (e) => `${Math.round(e * 100)}%`)
		] }),
		/* @__PURE__ */ X("div", {
			className: "gs-m3d__row",
			children: [/* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: r,
				title: "Space",
				children: n ? "Stop" : "Play"
			}), t.length > 1 && i && /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				title: "Each one starts a little after the one before, in the list's order",
				onClick: () => e.updateShapesAt([...t].sort((e, t) => e.ref[0] - t.ref[0]).map(({ ref: e, shape: n }, r) => [e, { motion: {
					...Kt,
					...n.motion ?? i,
					delay: r / t.length / 2
				} }]), "Stagger"),
				children: "Stagger"
			})]
		}),
		/* @__PURE__ */ Y(o, { id: "m3dMotion" })
	] });
}
//#endregion
//#region src/model3d/KeysSection.tsx
var Lc = [
	2,
	3,
	4,
	6,
	8,
	10,
	15
];
function Rc(e, t) {
	let n = e.document;
	e.updateShapesAt(qe(n, t)), n.cameraKeys?.length && e.setCamera(Le(n.cameraKeys, t));
}
function zc({ editor: e, target: t, seconds: n, onSeconds: r, time: i, onTime: a, playing: s, onPlay: c }) {
	let l = t.kind === "camera", u = (l ? t.doc.cameraKeys : t.shape.keys) ?? [], d = u.find((e) => Math.abs(e.at - i) < z), f = l ? ie(t.doc, i) : be(t.shape, i), p = (e) => `${(e * n).toFixed(1)} s`, m = l ? "camera key" : "key", h = (t) => {
		a(t), e.begin(`Go to ${p(t)}`), Rc(e, t), e.commit();
	}, g = (n, r) => {
		let i = n?.length ? n : void 0;
		t.kind === "camera" ? e.set("cameraKeys", i, r) : e.updateShapeAt(t.at, i ? { keys: i } : Ze(t.shape), r);
	}, _ = () => {
		let n = d ? `Update the ${m} at ${p(i)}` : `${l ? "Camera key" : "Key"} at ${p(i)}`;
		t.kind === "camera" ? g(Fe(e.document, i), n) : e.updateShapeAt(t.at, R(t.shape, i), n);
	}, v = t.kind === "shape" && t.at.length === 2 && !!e.document.shapes[t.at[0]]?.keys?.length;
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: l ? "Camera moves" : "Keyframes" }),
		v && /* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: "Its group has keys, which place it; keys on the group move all its shapes as one."
		}),
		/* @__PURE__ */ X("label", {
			className: "gs-m3d__field",
			children: [/* @__PURE__ */ Y("span", { children: "Clip" }), /* @__PURE__ */ Y("select", {
				value: n,
				onChange: (e) => r(Number(e.target.value)),
				children: (Lc.includes(n) ? Lc : [...Lc, n].sort((e, t) => e - t)).map((e) => /* @__PURE__ */ X("option", {
					value: e,
					children: [e, " seconds"]
				}, e))
			})]
		}),
		/* @__PURE__ */ Y(U, {
			label: "Time",
			value: i,
			min: 0,
			max: 1,
			step: 1 / (n * 20),
			format: (e) => `${p(e)} of ${n} s`,
			onBegin: () => e.begin("Go to a moment"),
			onChange: (t) => {
				a(t), Rc(e, t);
			},
			onEnd: () => e.commit()
		}),
		/* @__PURE__ */ X("div", {
			className: "gs-keys",
			role: "group",
			"aria-label": l ? "Camera keys on the clip" : "Keys on the clip",
			children: [/* @__PURE__ */ Y("span", {
				className: "gs-keys__now",
				style: { left: `${i * 100}%` },
				"aria-hidden": "true"
			}), u.map((e) => /* @__PURE__ */ Y("button", {
				type: "button",
				className: `gs-keys__key${e === d ? " is-on" : ""}`,
				style: { left: `${e.at * 100}%` },
				title: `Go to the ${m} at ${p(e.at)}`,
				"aria-label": `${l ? "Camera key" : "Key"} at ${p(e.at)}`,
				onClick: () => h(e.at)
			}, e.at))]
		}),
		/* @__PURE__ */ X("div", {
			className: "gs-m3d__row",
			children: [/* @__PURE__ */ Y("button", {
				type: "button",
				className: `gs-m3d__btn${f || !u.length ? " gs-m3d__btn--primary" : ""}`,
				onClick: _,
				children: d ? `Update ${m} at ${p(i)}` : `Add ${m} at ${p(i)}`
			}), d && /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => g(u.filter((e) => e !== d), `Remove a ${m}`),
				children: "Remove"
			})]
		}),
		d && u.indexOf(d) > 0 && /* @__PURE__ */ X("label", {
			className: "gs-m3d__field",
			children: [/* @__PURE__ */ Y("span", { children: "Arrives" }), /* @__PURE__ */ Y("select", {
				value: d.ease,
				onChange: (e) => g(u.map((t) => t === d ? {
					...t,
					ease: e.target.value
				} : t), `${l ? "Camera key" : "Key"} ease`),
				children: he.map((e) => /* @__PURE__ */ Y("option", {
					value: e,
					children: ye[e]
				}, e))
			})]
		}),
		t.kind === "shape" && u.length > 1 && /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ Y(W, {
			label: "Path",
			value: t.shape.keyPath?.curve ? "curve" : "straight",
			options: ["straight", "curve"],
			labels: {
				straight: "Straight",
				curve: "Curved"
			},
			onChange: (n) => e.updateShapeAt(t.at, { keyPath: {
				...t.shape.keyPath,
				curve: n === "curve" || void 0
			} }, "Key path")
		}), /* @__PURE__ */ X("label", {
			className: "gs-m3d__check",
			children: [
				/* @__PURE__ */ Y("input", {
					type: "checkbox",
					checked: !!t.shape.keyPath?.face,
					onChange: (n) => e.updateShapeAt(t.at, { keyPath: {
						...t.shape.keyPath,
						face: n.target.checked || void 0
					} }, "Face the way")
				}),
				" ",
				"Turn to face the way it goes"
			]
		})] }),
		f && /* @__PURE__ */ X("p", {
			className: "gs-m3d__note",
			children: [
				l ? "The view was turned since its keys" : "Moved since its keys",
				": press ",
				d ? "Update" : "Add",
				" ",
				m,
				" to keep it, or it goes back when the time changes."
			]
		}),
		/* @__PURE__ */ X("div", {
			className: "gs-m3d__row",
			children: [/* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: c,
				title: "Space",
				children: s ? "Stop" : "Play"
			}), u.length > 0 && /* @__PURE__ */ X("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => g(void 0, `Remove all ${m}s`),
				children: [
					"Remove all ",
					m,
					"s"
				]
			})]
		}),
		/* @__PURE__ */ Y(o, { id: l ? "m3dCameraKeys" : "m3dKeys" })
	] });
}
//#endregion
//#region src/model3d/Curves.tsx
var Bc = [
	{
		id: "px",
		label: "Position x",
		get: (e) => e.position[0],
		set: (e, t) => ({
			...e,
			position: [
				t,
				e.position[1],
				e.position[2]
			]
		})
	},
	{
		id: "py",
		label: "Position y",
		get: (e) => e.position[1],
		set: (e, t) => ({
			...e,
			position: [
				e.position[0],
				t,
				e.position[2]
			]
		})
	},
	{
		id: "pz",
		label: "Position z",
		get: (e) => e.position[2],
		set: (e, t) => ({
			...e,
			position: [
				e.position[0],
				e.position[1],
				t
			]
		})
	},
	{
		id: "rx",
		label: "Turn x",
		get: (e) => e.rotation[0],
		set: (e, t) => ({
			...e,
			rotation: [
				t,
				e.rotation[1],
				e.rotation[2]
			]
		})
	},
	{
		id: "ry",
		label: "Turn y",
		get: (e) => e.rotation[1],
		set: (e, t) => ({
			...e,
			rotation: [
				e.rotation[0],
				t,
				e.rotation[2]
			]
		})
	},
	{
		id: "rz",
		label: "Turn z",
		get: (e) => e.rotation[2],
		set: (e, t) => ({
			...e,
			rotation: [
				e.rotation[0],
				e.rotation[1],
				t
			]
		})
	},
	{
		id: "sx",
		label: "Size x",
		get: (e) => e.size[0],
		set: (e, t) => ({
			...e,
			size: [
				Math.max(.01, t),
				e.size[1],
				e.size[2]
			]
		})
	},
	{
		id: "sy",
		label: "Size y",
		get: (e) => e.size[1],
		set: (e, t) => ({
			...e,
			size: [
				e.size[0],
				Math.max(.01, t),
				e.size[2]
			]
		})
	},
	{
		id: "sz",
		label: "Size z",
		get: (e) => e.size[2],
		set: (e, t) => ({
			...e,
			size: [
				e.size[0],
				e.size[1],
				Math.max(.01, t)
			]
		})
	},
	{
		id: "m",
		label: "Morph",
		get: (e) => e.morph ?? 0,
		set: (e, t) => ({
			...e,
			morph: Math.min(1, Math.max(0, t))
		})
	}
], Vc = 600, Hc = 140, Uc = 10;
function Wc({ editor: e, doc: t, at: n, seconds: r, time: i }) {
	let [a, o] = q(Bc[1]), [s, c] = q(null), l = K(null), u = n ? He(t, n) : void 0, d = u?.keys;
	if (!n || !u || !d?.length || u.kind === "group") return /* @__PURE__ */ Y("p", {
		className: "gs-timeline__empty",
		children: "Pick a shape with keys to see its curves."
	});
	let f = (e) => {
		let t = It(d, e, u.keyPath), n = {
			at: e,
			position: t.position,
			rotation: t.rotation,
			size: t.size,
			ease: "linear",
			morph: t.morphAmount
		};
		return a.get(n);
	}, p = Array.from({ length: 121 }, (e, t) => [t / 120, f(t / 120)]), m = [...p.map((e) => e[1]), ...d.map((e) => a.get(e))], h = Math.min(...m), g = Math.max(...m);
	g - h < .001 && (h -= .5, g += .5);
	let _ = (g - h) * .12;
	h -= _, g += _;
	let v = (e) => Uc + e * 580, y = (e) => 130 - (e - h) / (g - h) * 120, b = (e, t) => {
		let n = l.current.getBoundingClientRect(), i = Math.min(1, Math.max(0, (e - n.left) / n.width * (Vc / 580) - Uc / 580)), a = h + (130 - (t - n.top) / n.height * Hc) / 120 * (g - h);
		return {
			t: Math.round(i * r * 20) / (r * 20),
			v: a
		};
	};
	return /* @__PURE__ */ X("div", {
		className: "gs-curves",
		children: [/* @__PURE__ */ Y("label", {
			className: "gs-curves__channel",
			children: /* @__PURE__ */ Y("select", {
				value: a.id,
				onChange: (e) => o(Bc.find((t) => t.id === e.target.value) ?? Bc[1]),
				children: Bc.map((e) => /* @__PURE__ */ Y("option", {
					value: e.id,
					children: e.label
				}, e.id))
			})
		}), /* @__PURE__ */ X("svg", {
			ref: l,
			className: "gs-curves__plot",
			viewBox: `0 0 ${Vc} ${Hc}`,
			preserveAspectRatio: "none",
			role: "img",
			"aria-label": `${a.label} over the clip`,
			children: [
				/* @__PURE__ */ Y("line", {
					className: "gs-curves__now",
					x1: v(i),
					x2: v(i),
					y1: 0,
					y2: Hc
				}),
				/* @__PURE__ */ Y("polyline", {
					className: "gs-curves__line",
					points: p.map(([e, t]) => `${v(e)},${y(t)}`).join(" ")
				}),
				d.map((t, i) => /* @__PURE__ */ Y("circle", {
					className: `gs-curves__key${s === i ? " is-on" : ""}`,
					cx: v(t.at),
					cy: y(a.get(t)),
					r: 6,
					onPointerDown: (t) => {
						t.target.setPointerCapture(t.pointerId), e.begin(`Curve: ${a.label}`), c(i);
					},
					onPointerMove: (t) => {
						if (s !== i) return;
						let { t: r, v: o } = b(t.clientX, t.clientY), c = d.map((e, t) => t === i ? {
							...a.set(e, o),
							at: r
						} : e).sort((e, t) => e.at - t.at);
						e.updateShapeAt(n, { keys: c });
					},
					onPointerUp: () => {
						e.commit(), c(null);
					},
					children: /* @__PURE__ */ Y("title", { children: `${(t.at * r).toFixed(2)} s: ${a.get(t).toFixed(2)}` })
				}, i))
			]
		})]
	});
}
//#endregion
//#region src/model3d/Timeline.tsx
function Gc(e) {
	let t = [];
	return e.cameraKeys?.length && t.push({
		id: "camera",
		name: "Camera",
		ref: null,
		keys: e.cameraKeys
	}), e.shapes.forEach((e, n) => {
		e.keys?.length && t.push({
			id: e.id,
			name: e.name,
			ref: [n],
			keys: e.keys
		}), e.children?.forEach((r, i) => {
			r.keys?.length && t.push({
				id: r.id,
				name: `${e.name} › ${r.name}`,
				ref: [n, i],
				keys: r.keys
			});
		});
	}), t;
}
var Kc = /* @__PURE__ */ new Map();
function qc(e) {
	let t = Kc.get(e);
	return t || (t = (async () => {
		let t = await (await fetch(e)).arrayBuffer(), n = await new OfflineAudioContext(1, 1, 22050).decodeAudioData(t), r = n.getChannelData(0);
		return {
			seconds: n.duration,
			wave: Bt(r, 800),
			beat: ut(r, n.sampleRate)
		};
	})(), Kc.size > 2 && Kc.clear(), Kc.set(e, t)), t;
}
function Jc({ music: e, seconds: t, time: n, onHeard: r }) {
	let i = K(null), [a, o] = q(null);
	return G(() => {
		let t = !0;
		return qc(e.data).then((e) => {
			t && (o(e), r(e));
		}), () => {
			t = !1;
		};
	}, [e.data, r]), G(() => {
		let n = i.current;
		if (!n || !a) return;
		let r = n.width = n.clientWidth * devicePixelRatio, o = n.height = n.clientHeight * devicePixelRatio, s = n.getContext("2d"), c = getComputedStyle(n);
		s.clearRect(0, 0, r, o);
		let l = e.from ?? 0;
		s.fillStyle = c.getPropertyValue("--gs-focus-soft") || c.color;
		for (let e = 0; e < r; e++) {
			let n = l + e / r * t;
			if (n >= a.seconds) break;
			let i = a.wave[Math.floor(n / a.seconds * a.wave.length)] ?? 0;
			s.fillRect(e, (o - i * o) / 2, 1, Math.max(1, i * o));
		}
		if (a.beat) {
			s.fillStyle = c.getPropertyValue("--gs-border") || c.color;
			let e = 60 / a.beat.bpm;
			if (e / t * r > 5) for (let n = a.beat.first; n < l + t; n += e) n >= l && s.fillRect((n - l) / t * r, 0, 1, o);
		}
	}, [
		a,
		e.from,
		t
	]), /* @__PURE__ */ X("div", {
		className: "gs-timeline__row",
		children: [/* @__PURE__ */ Y("span", {
			className: "gs-timeline__name",
			title: e.name,
			children: a?.beat ? `${Math.round(a.beat.bpm)} BPM` : "Music"
		}), /* @__PURE__ */ X("div", {
			className: "gs-timeline__lane",
			children: [/* @__PURE__ */ Y("canvas", {
				ref: i,
				className: "gs-timeline__wave",
				"aria-label": `The music: ${e.name}`
			}), /* @__PURE__ */ Y("span", {
				className: "gs-timeline__now",
				style: { left: `${n * 100}%` }
			})]
		})]
	});
}
function Yc({ editor: e, doc: t, seconds: n, time: r, onTime: i, onPick: a, selected: o = null, onSeconds: s }) {
	let c = K(null), l = K(null), [u, d] = q(null), [f, p] = q(null), m = (t) => {
		let n = t.target.files?.[0];
		if (t.target.value = "", !n) return;
		if (n.size > 3e7) {
			p("That sound file is over 30 MB; use a smaller one.");
			return;
		}
		p(null);
		let r = new FileReader();
		r.onload = () => {
			let t = /\.(mp3|wav|ogg|m4a|aac|flac|opus)$/i.exec(n.name)?.[1]?.toLowerCase(), i = String(r.result).replace(/^data:(?!audio\/)[^;,]*(;[^,]*)?,/, `data:audio/${t === "mp3" ? "mpeg" : t ?? "mpeg"};base64,`);
			e.set("music", {
				name: n.name,
				data: i
			}, "Music");
		}, r.readAsDataURL(n);
	}, [h, g] = q(null), [_, v] = q(!1), y = Gc(t), b = (e) => {
		let t = c.current.getBoundingClientRect();
		return Math.min(1, Math.max(0, (e - t.left) / t.width));
	}, x = (t) => {
		i(t), Rc(e, t);
	}, S = (t) => {
		t.target.setPointerCapture(t.pointerId), e.begin("Go to a moment"), x(b(t.clientX));
	}, C = (t, n) => {
		let r = [...n].sort((e, t) => e.at - t.at);
		t.ref ? e.updateShapeAt(t.ref, { keys: r }) : e.set("cameraKeys", r);
	}, w = n > 300 ? 60 : n > 60 ? 10 : n > 30 ? 5 : 1, T = Array.from({ length: Math.floor(n / w) + 1 }, (e, t) => t * w);
	return /* @__PURE__ */ X("div", {
		className: "gs-timeline",
		"aria-label": "Timeline",
		children: [
			/* @__PURE__ */ X("div", {
				className: "gs-timeline__head",
				children: [/* @__PURE__ */ Y("span", {
					className: "gs-timeline__name",
					children: `${(r * n).toFixed(1)} s`
				}), /* @__PURE__ */ X("div", {
					className: "gs-timeline__ruler",
					ref: c,
					onPointerDown: S,
					onPointerMove: (e) => e.buttons === 1 && !h && x(b(e.clientX)),
					onPointerUp: () => e.commit(),
					children: [T.map((e) => /* @__PURE__ */ Y("span", {
						className: "gs-timeline__tick",
						style: { left: `${e / n * 100}%` },
						children: e
					}, e)), /* @__PURE__ */ Y("span", {
						className: "gs-timeline__now",
						style: { left: `${r * 100}%` }
					})]
				})]
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__row gs-timeline__music",
				children: [
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => l.current?.click(),
						children: t.music ? "Change the music…" : "Music…"
					}),
					/* @__PURE__ */ Y("input", {
						ref: l,
						type: "file",
						hidden: !0,
						accept: "audio/*",
						onChange: m
					}),
					t.music && /* @__PURE__ */ X(J, { children: [
						/* @__PURE__ */ Y("span", {
							className: "gs-m3d__meta",
							children: t.music.name
						}),
						u && Math.abs(u.seconds - n) > .5 && /* @__PURE__ */ Y("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: () => s(Math.min(600, Math.max(1, Math.round(u.seconds * 100) / 100))),
							children: "Make the clip as long as the music"
						}),
						/* @__PURE__ */ Y("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: () => e.set("music", void 0, "No music"),
							children: "Remove the music"
						})
					] }),
					f && /* @__PURE__ */ Y("span", {
						className: "gs-m3d__meta",
						children: f
					})
				]
			}),
			t.music && /* @__PURE__ */ Y(Jc, {
				music: t.music,
				seconds: n,
				time: r,
				onHeard: d
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__check gs-timeline__toggle",
				children: [/* @__PURE__ */ Y("input", {
					type: "checkbox",
					checked: _,
					onChange: (e) => v(e.target.checked)
				}), " Curves of the picked shape"]
			}),
			_ && /* @__PURE__ */ Y(Wc, {
				editor: e,
				doc: t,
				at: o,
				seconds: n,
				time: r
			}),
			y.length === 0 && /* @__PURE__ */ Y("p", {
				className: "gs-timeline__empty",
				children: "No keys yet: add them in a shape’s Keyframes or in Camera moves."
			}),
			y.map((i) => /* @__PURE__ */ X("div", {
				className: "gs-timeline__row",
				children: [/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-timeline__name",
					title: i.ref ? "Pick it" : "The camera",
					onClick: () => i.ref && a(i.ref),
					children: i.name
				}), /* @__PURE__ */ X("div", {
					className: "gs-timeline__lane",
					children: [/* @__PURE__ */ Y("span", {
						className: "gs-timeline__now",
						style: { left: `${r * 100}%` }
					}), i.keys.map((o, s) => /* @__PURE__ */ Y("button", {
						type: "button",
						className: `gs-timeline__key${Math.abs(o.at - r) < .005 ? " is-on" : ""}`,
						style: { left: `${o.at * 100}%` },
						title: `${(o.at * n).toFixed(2)} s: drag to move it in time`,
						onPointerDown: (t) => {
							t.stopPropagation(), t.target.setPointerCapture(t.pointerId), e.begin("Move a key in time"), g({
								row: i.id,
								at: s
							});
						},
						onPointerMove: (e) => {
							if (h?.row !== i.id || h.at !== s) return;
							let r = Math.round(b(e.clientX) * n * 20) / (n * 20), a = r;
							if (u?.beat) {
								let e = 60 / u.beat.bpm, i = t.music?.from ?? 0, o = (Math.round((r * n + i - u.beat.first) / e) * e + u.beat.first - i) / n;
								Math.abs(o - r) * n < e / 4 && (a = Math.min(1, Math.max(0, o)));
							}
							C(i, i.keys.map((e, t) => t === s ? {
								...e,
								at: a
							} : e));
						},
						onPointerUp: (t) => {
							e.commit(), g(null), Math.abs(b(t.clientX) - o.at) < .01 && (x(o.at), i.ref && a(i.ref));
						}
					}, `${s}-${o.at}`))]
				})]
			}, i.id))
		]
	});
}
//#endregion
//#region src/model3d/FormSection.tsx
function Xc({ editor: e, at: t, shape: n }) {
	let r = n.form ?? {}, i = (n, i) => {
		let a = {
			...r,
			[n]: i,
			...n === "noise" && i && !r.noiseScale ? { noiseScale: 8 } : {}
		}, o = Object.values(a).some((e) => e) ? a : void 0;
		e.updateShapeAt(t, { form: o });
	}, a = (t, n, a, o, s, c) => /* @__PURE__ */ Y(U, {
		label: n,
		value: r[t] ?? 0,
		min: a,
		max: o,
		step: s,
		format: c,
		onBegin: () => e.begin(n),
		onChange: (e) => i(t, e),
		onEnd: () => e.commit()
	}), s = Math.min(...n.size) / 2;
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Form" }),
		a("hollow", "Hollow (wall)", 0, Math.max(.02, Math.round(s * 100) / 100), .01, (e) => e ? e.toFixed(2) : "Solid"),
		a("twist", "Twist", -360, 360, 5, (e) => `${Math.round(e)}°`),
		a("bend", "Bend", -180, 180, 5, (e) => `${Math.round(e)}°`),
		a("taper", "Taper", -.9, .9, .05, (e) => e ? `${e > 0 ? "wider" : "narrower"} ${Math.round(Math.abs(e) * 100)}%` : "None"),
		a("noise", "Bumps", 0, .2, .005, (e) => e ? e.toFixed(3) : "Smooth"),
		(r.noise ?? 0) > 0 && a("noiseScale", "Bump size", 1, 40, .5, (e) => e < 6 ? "large" : e < 16 ? "medium" : "fine"),
		n.form && /* @__PURE__ */ Y("button", {
			type: "button",
			className: "gs-m3d__btn",
			onClick: () => e.updateShapeAt(t, { form: void 0 }, "Plain form"),
			children: "Back to plain"
		}),
		/* @__PURE__ */ Y(o, { id: "m3dForm" })
	] });
}
//#endregion
//#region src/model3d/uvbake.ts
async function Zc(e) {
	try {
		let t = await createImageBitmap(new Blob([e.bytes], { type: e.mime })), n = new OffscreenCanvas(t.width, t.height).getContext("2d");
		return n.drawImage(t, 0, 0), n.getImageData(0, 0, t.width, t.height);
	} catch {
		return null;
	}
}
async function Qc(e, t = 1024) {
	let n = await Promise.all(e.textures.map(Zc)), r = (e, t, r) => {
		let i = n[e];
		if (!i) return null;
		let a = Math.min(i.width - 1, Math.floor((t - Math.floor(t)) * i.width)), o = (Math.min(i.height - 1, Math.floor((r - Math.floor(r)) * i.height)) * i.width + a) * 4;
		return [
			i.data[o],
			i.data[o + 1],
			i.data[o + 2],
			i.data[o + 3]
		];
	}, i = ki(e), a = Mi(e, i, t, r);
	return Ni(i, await Promise.all(a.map(async (e) => {
		let n = new OffscreenCanvas(t, t);
		n.getContext("2d").putImageData(new ImageData(e, t, t), 0, 0);
		let r = await n.convertToBlob({ type: "image/png" });
		return {
			mime: "image/png",
			bytes: new Uint8Array(await r.arrayBuffer())
		};
	})));
}
//#endregion
//#region src/model3d/MeshEditSection.tsx
var $c = () => `m${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
function el(e, t, n, r, i, a, o) {
	let s = $c();
	e.begin(o), e.set("assets", {
		...e.document.assets ?? {},
		[s]: Pr(i, a)
	}), e.updateShapeAt(t, {
		asset: s,
		...Dn(n, r, i)
	}), e.commit();
}
function tl({ editor: e, doc: t, at: n, shape: r, run: i }) {
	let [a, s] = q(.5), [c, l] = q(!1), [u, d] = q(!1), f = r.asset ? t.assets?.[r.asset] : void 0;
	if (!f || !r.asset) return null;
	let p = (t, a) => void i(`${t}…`, async () => {
		let i = O(r.asset, f.data), o = await a(i);
		if (!c) return el(e, n, r, i, o, f.name, t);
		let s = $c();
		e.begin(`${t} (morph)`), e.set("assets", {
			...e.document.assets ?? {},
			[s]: Pr(o, `${f.name} (morph)`)
		}), e.updateShapeAt(n, { morph: {
			asset: s,
			amount: 1
		} }), e.commit();
	});
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Edit the model" }),
		/* @__PURE__ */ X("div", {
			className: "gs-m3d__row",
			children: [
				/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => p("Smooth", (e) => yn(e, 2)),
					title: "Softens bumps and jagged facets",
					children: "Smooth"
				}),
				/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => p("Simplify", (e) => hn(e, .5)),
					title: "About half the triangles: a smaller file, quicker to draw",
					children: "Simplify"
				}),
				/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => p("Inside out", ar),
					title: "For a model whose faces point inwards",
					children: "Flip inside out"
				}),
				/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => p("Subdivide", kn),
					title: "Four triangles for each, smoothed: rounder and finer",
					children: "Subdivide"
				}),
				/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => p("Remesh", (e) => ln(e, 96)),
					title: "Rebuilt as one even, closed surface (good before printing); its pictures go, its colour stays",
					children: "Remesh"
				}),
				/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => p("Unwrap", (e) => Qc(e)),
					title: "New texture places, islands laid flat side by side, its look painted into one new picture a part",
					children: "Unwrap"
				}),
				/* @__PURE__ */ Y("button", {
					type: "button",
					className: `gs-m3d__btn${u ? " is-on" : ""}`,
					onClick: () => d((e) => !e),
					children: "Texture map"
				})
			]
		}),
		u && /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ Y(nl, { model: O(r.asset, f.data) }), /* @__PURE__ */ Y(o, { id: "m3dUnwrap" })] }),
		/* @__PURE__ */ X("label", {
			className: "gs-m3d__check",
			children: [/* @__PURE__ */ Y("input", {
				type: "checkbox",
				checked: c,
				onChange: (e) => l(e.target.checked)
			}), " Edits make a morph (Smooth; the model stays as it is)"]
		}),
		r.morph && /* @__PURE__ */ X(J, { children: [
			/* @__PURE__ */ Y(U, {
				label: "Morph",
				value: r.morph.amount,
				min: 0,
				max: 1,
				step: .01,
				format: (e) => `${Math.round(e * 100)}%`,
				onBegin: () => e.begin("Morph"),
				onChange: (t) => e.updateShapeAt(n, { morph: {
					...r.morph,
					amount: t
				} }),
				onEnd: () => e.commit()
			}),
			/* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => e.updateShapeAt(n, { morph: void 0 }, "Remove morph"),
				children: "Remove the morph"
			}),
			/* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: "Keys keep the morph's amount too, so it can change over the clip."
			})
		] }),
		/* @__PURE__ */ Y(U, {
			label: "Cut at",
			value: a,
			min: .02,
			max: .98,
			step: .01,
			format: (e) => `${Math.round(e * 100)}% up`,
			onBegin: () => void 0,
			onChange: s,
			onEnd: () => void 0
		}),
		/* @__PURE__ */ X("div", {
			className: "gs-m3d__row",
			children: [/* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => p("Cut, keep above", (e) => Qt(e, a, "above")),
				children: "Keep above"
			}), /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => p("Cut, keep below", (e) => Qt(e, a, "below")),
				children: "Keep below"
			})]
		}),
		/* @__PURE__ */ Y(o, { id: "m3dMeshEdit" })
	] });
}
function nl({ model: e }) {
	let t = e.parts.find((e) => e.uvs), n = t ? e.textures[e.materials[t.material]?.texture ?? -1] : void 0, r = Xr(() => n ? URL.createObjectURL(new Blob([n.bytes], { type: n.mime })) : "", [n]);
	G(() => () => URL.revokeObjectURL(r), [r]);
	let i = Xr(() => {
		if (!t?.uvs) return "";
		let e = t.uvs, n = t.indices, r = Math.max(1, Math.ceil(n.length / 3 / 2e4)), i = "", a = (t) => `${(e[t * 2] * 256).toFixed(1)} ${(e[t * 2 + 1] * 256).toFixed(1)}`;
		for (let e = 0; e < n.length; e += 3 * r) i += `M${a(n[e])}L${a(n[e + 1])}L${a(n[e + 2])}Z`;
		return i;
	}, [t]);
	return t ? /* @__PURE__ */ X("svg", {
		className: "gs-m3d__uvmap",
		viewBox: "0 0 256 256",
		role: "img",
		"aria-label": "Texture map",
		children: [r && /* @__PURE__ */ Y("image", {
			href: r,
			width: "256",
			height: "256",
			preserveAspectRatio: "none"
		}), /* @__PURE__ */ Y("path", {
			d: i,
			fill: "none",
			stroke: "var(--gs-focus)",
			strokeWidth: "0.4"
		})]
	}) : /* @__PURE__ */ Y("p", {
		className: "gs-m3d__meta",
		children: "This model has no texture places yet: Unwrap gives it some."
	});
}
//#endregion
//#region src/model3d/BrushSection.tsx
var rl = (e) => {
	let t = parseInt(e.slice(1), 16);
	return [
		(t >> 16 & 255) / 255,
		(t >> 8 & 255) / 255,
		(t & 255) / 255
	].map((e) => e ** 2.2);
};
function il({ editor: e, doc: t, at: n, shape: r, viewRef: i, stageRef: a }) {
	let [s, c] = q(!1), [l, u] = q("draw"), [d, f] = q(.12), [p, m] = q(.5), [h, g] = q("#e03a5a"), [_, v] = q(!1), y = K({
		kind: l,
		size: d,
		strength: p,
		color: h,
		asMorph: _
	});
	y.current = {
		kind: l,
		size: d,
		strength: p,
		color: h,
		asMorph: _
	};
	let b = r.asset ? t.assets?.[r.asset] : void 0;
	return G(() => {
		let t = a.current, o = i.current;
		if (!s || !t || !o || !b || !r.asset) return;
		let c = O(r.asset, b.data), l = an(r, c), u = Math.max(...r.size), d = null, f = null, p = null, m = 0, h = (e) => e.length === n.length && e.every((e, t) => e === n[t]), g = () => {
			m = 0, d && o.previewModel(r.asset, d.parts);
		}, _ = (e, t) => {
			let n = y.current, r = o.modelHitAt(e.clientX, e.clientY), i = r && h(r.ref) ? r.point : null;
			if (n.kind === "grab" && !t && p) {
				let { origin: t, dir: n } = o.rayAt(e.clientX, e.clientY), r = n[0] * p.normal[0] + n[1] * p.normal[1] + n[2] * p.normal[2];
				if (Math.abs(r) > 1e-6) {
					let e = ((p.point[0] - t[0]) * p.normal[0] + (p.point[1] - t[1]) * p.normal[1] + (p.point[2] - t[2]) * p.normal[2]) / r;
					i = [
						t[0] + n[0] * e,
						t[1] + n[1] * e,
						t[2] + n[2] * e
					];
				}
			}
			if (!i || !d) return;
			let a = f ? i.map((e, t) => e - f[t]) : void 0;
			sn(d, c, {
				kind: n.kind,
				at: l.point(n.kind === "grab" && f ? f : i),
				normal: l.normal(r?.normal ?? [
					0,
					1,
					0
				]),
				radius: l.units(n.size * u),
				strength: n.strength,
				color: rl(n.color),
				move: a && l.move(a)
			}), f = i, m ||= requestAnimationFrame(g);
		}, v = (e) => {
			let n = o.modelHitAt(e.clientX, e.clientY);
			if (!n || !h(n.ref)) return;
			e.stopPropagation(), o.setOrbit(!1), t.setPointerCapture(e.pointerId), d = Tn(c), f = null;
			let { dir: r } = o.rayAt(e.clientX, e.clientY);
			p = {
				point: n.point,
				normal: r
			}, _(e, !0);
		}, x = (e) => {
			d && (e.stopPropagation(), _(e, !1));
		}, S = (t) => {
			if (!d) return;
			t.stopPropagation();
			let i = sr(d, c);
			d = null, o.setOrbit(!0);
			let a = `${Nn[y.current.kind]} stroke`;
			if (y.current.asMorph) {
				let t = $c();
				e.begin(`${a} (morph)`), e.set("assets", {
					...e.document.assets ?? {},
					[t]: Pr(i, `${b.name} (morph)`)
				}), e.updateShapeAt(n, { morph: {
					asset: t,
					amount: 1
				} }), e.commit();
			} else el(e, n, r, c, i, b.name, a);
		};
		return t.addEventListener("pointerdown", v, !0), t.addEventListener("pointermove", x, !0), t.addEventListener("pointerup", S, !0), t.style.cursor = "crosshair", () => {
			t.removeEventListener("pointerdown", v, !0), t.removeEventListener("pointermove", x, !0), t.removeEventListener("pointerup", S, !0), t.style.cursor = "", cancelAnimationFrame(m), o.setOrbit(!0);
		};
	}, [
		s,
		r,
		b,
		n,
		e,
		i,
		a
	]), b ? /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Brush" }),
		/* @__PURE__ */ Y(W, {
			label: "Brush",
			value: l,
			options: Cr,
			labels: Nn,
			onChange: u
		}),
		/* @__PURE__ */ Y(U, {
			label: "Size",
			value: d,
			min: .02,
			max: .5,
			step: .01,
			format: (e) => `${Math.round(e * 100)}%`,
			onBegin: () => void 0,
			onChange: f,
			onEnd: () => void 0
		}),
		/* @__PURE__ */ Y(U, {
			label: "Strength",
			value: p,
			min: .05,
			max: 1,
			step: .05,
			format: (e) => `${Math.round(e * 100)}%`,
			onBegin: () => void 0,
			onChange: m,
			onEnd: () => void 0
		}),
		l === "paint" && /* @__PURE__ */ X("label", {
			className: "gs-m3d__colour",
			children: [/* @__PURE__ */ Y("input", {
				type: "color",
				value: h,
				onChange: (e) => g(e.target.value)
			}), " Paint colour"]
		}),
		/* @__PURE__ */ X("label", {
			className: "gs-m3d__check",
			children: [/* @__PURE__ */ Y("input", {
				type: "checkbox",
				checked: _,
				onChange: (e) => v(e.target.checked)
			}), " As a morph (the model stays as it is)"]
		}),
		/* @__PURE__ */ Y("button", {
			type: "button",
			className: `gs-m3d__btn${s ? " is-on" : ""}`,
			onClick: () => c((e) => !e),
			children: s ? "Brush on: drag on the model (click to turn the view again)" : "Brush on"
		}),
		/* @__PURE__ */ Y(o, { id: "m3dBrush" })
	] }) : null;
}
//#endregion
//#region src/model3d/DrawSection.tsx
var al = [
	"0",
	"1024",
	"2048"
], ol = {
	0: "As it is",
	1024: "1024 px",
	2048: "2048 px"
}, sl = (e) => .0015 * 60 ** e, cl = (e, t) => e[0] * t[0] + e[1] * t[1] + e[2] * t[2], ll = (e, t) => [
	e[1] * t[2] - e[2] * t[1],
	e[2] * t[0] - e[0] * t[2],
	e[0] * t[1] - e[1] * t[0]
], ul = (e) => {
	let t = Math.hypot(e[0], e[1], e[2]) || 1;
	return [
		e[0] / t,
		e[1] / t,
		e[2] / t
	];
}, dl = (e) => `#${e.map((e) => Math.round(e).toString(16).padStart(2, "0")).join("")}`, fl = (e) => {
	let t = parseInt(e.slice(1), 16);
	return [
		t >> 16 & 255,
		t >> 8 & 255,
		t & 255
	];
}, pl = "blurry, low quality, smudged, deformed, extra eyes, bad anatomy, text, watermark, signature";
function ml(e, [t, n, r], i) {
	let a = document.createElement("canvas");
	a.width = a.height = i;
	let o = a.getContext("2d");
	return o.imageSmoothingQuality = "high", o.drawImage(e, t, n, r, r, 0, 0, i, i), a;
}
async function hl(e, t, n = {}) {
	let r = e instanceof Blob ? await createImageBitmap(e) : e, i = n.topHalf && r.height >= r.width * 1.9 ? r.width : r.height, a = 0, o = 0, s = r.width, c = i;
	if (n.cover) {
		let e = Math.min(s, c);
		a = (s - e) / 2, o = (c - e) / 2, s = c = e;
	}
	let l = document.createElement("canvas");
	l.width = l.height = t;
	let u = l.getContext("2d", { willReadFrequently: !0 });
	return u.imageSmoothingQuality = "high", u.drawImage(r, a, o, s, c, 0, 0, t, t), u.getImageData(0, 0, t, t).data;
}
async function gl(e, t, n) {
	let r = new Blob([e], { type: t }), i = {
		premultiplyAlpha: "none",
		colorSpaceConversion: "none"
	}, a = await createImageBitmap(r, i), o = n / Math.max(a.width, a.height);
	if (o > 1) {
		let [e, t] = [Math.round(a.width * o), Math.round(a.height * o)];
		a.close(), a = await createImageBitmap(r, {
			...i,
			resizeWidth: e,
			resizeHeight: t,
			resizeQuality: "high"
		});
	}
	let s = document.createElement("canvas");
	s.width = a.width, s.height = a.height;
	let c = s.getContext("2d", { willReadFrequently: !0 });
	return c.drawImage(a, 0, 0), a.close(), {
		width: s.width,
		height: s.height,
		data: c.getImageData(0, 0, s.width, s.height).data
	};
}
async function _l(e, t) {
	let n = !1;
	for (let e = 3; e < t.data.length && !n; e += 4) n = t.data[e] < 255;
	let r = n ? "image/png" : "image/jpeg", i = await new Promise((t, n) => e.toBlob((e) => e ? t(e) : n(/* @__PURE__ */ Error("The picture could not be kept.")), r, .92));
	return {
		bytes: new Uint8Array(await i.arrayBuffer()),
		mime: r
	};
}
function vl(e) {
	let t = document.createElement("canvas");
	t.width = e.width, t.height = e.height;
	let n = new ImageData(e.data, e.width, e.height);
	return t.getContext("2d").putImageData(n, 0, 0), {
		canvas: t,
		image: n
	};
}
async function yl(e, t) {
	let n = e.surface.asset, r = n.textures.slice();
	for (let n of t ?? e.dirty) {
		let t = e.canvases.get(n);
		t && (r[n] = await _l(t.canvas, e.surface.pictures.get(n)));
	}
	return M(n.parts, n.materials, r);
}
function bl({ editor: e, doc: n, at: r, shape: i, viewRef: s, stageRef: c }) {
	let [u, d] = q("off"), [f, p] = q("pen"), [m, h] = q("color"), [g, _] = q(.2), [v, y] = q(.6), [b, x] = q(!1), [S, C] = q("#3a2430"), [w, T] = q([]), [E, D] = q(.35), [k, A] = q(.9), [j, M] = q(.6), [ee, te] = q(!1), [ne, N] = q(!0), [P, re] = q("1024"), [F, I] = q(!1), [ie, ae] = q(0), [oe, L] = q(null), [se, ce] = q(!1), le = t(), ue = le.state === "ready" ? le.installed("redraw")[0] : void 0, de = l(), [fe, pe] = q(!1), [me, he] = q(""), [ge, _e] = q(pl), [ve, ye] = q(.8), [be, xe] = q(null), Se = K(null), [R, Ce] = q(null), [z, we] = q(.3), [Te, Ee] = q(0), De = K(null), Oe = K(null), B = K({
		tool: f,
		color: S,
		size: E,
		opacity: k,
		hardness: j,
		mirror: ee,
		onePart: ne,
		picking: F,
		channel: m,
		value: g,
		bump: v,
		fill: b,
		sticker: R,
		stickerSize: z,
		stickerTurn: Te
	});
	B.current = {
		tool: f,
		color: S,
		size: E,
		opacity: k,
		hardness: j,
		mirror: ee,
		onePart: ne,
		picking: F,
		channel: m,
		value: g,
		bump: v,
		fill: b,
		sticker: R,
		stickerSize: z,
		stickerTurn: Te
	};
	let ke = async (e) => {
		L(null);
		try {
			let t = await createImageBitmap(e), n = Math.min(1, 512 / Math.max(t.width, t.height)), r = Math.max(1, Math.round(t.width * n)), i = Math.max(1, Math.round(t.height * n)), a = document.createElement("canvas");
			a.width = r, a.height = i;
			let o = a.getContext("2d", { willReadFrequently: !0 });
			o.imageSmoothingQuality = "high", o.drawImage(t, 0, 0, r, i), t.close(), Ce({
				data: o.getImageData(0, 0, r, i).data,
				width: r,
				height: i,
				name: e.name.replace(/\.[^.]+$/, "")
			});
		} catch {
			L("That picture could not be read.");
		}
	}, Ae = i.asset ? n.assets?.[i.asset] : void 0, je = async () => {
		if (!Ae || !i.asset) return;
		L(null);
		let t = O(i.asset, Ae.data);
		if (!Hi(t)) L("This model has no picture laid out on it to draw on: use Paint in Brush, which colours its points.");
		else {
			d("starting");
			try {
				let n = /* @__PURE__ */ new Map(), a = Number(P), o = await Promise.all(Vi(t).map(async (e) => [e, await gl(t.textures[e].bytes, t.textures[e].mime, a)]));
				for (let [e, t] of o) n.set(e, t);
				let s = Gi(t, n, a), c = [...s.pictures.keys()].filter((e) => !s.changed.includes(e)), l = {
					at: r,
					assetId: i.asset,
					name: Ae.name,
					surface: Ki(s.asset, s.pictures),
					canvases: new Map([...s.pictures].map(([e, t]) => [e, vl(t)])),
					undo: [],
					dirty: /* @__PURE__ */ new Set(),
					marks: /* @__PURE__ */ new Map(),
					detail: a
				};
				if (s.remade) {
					let n = await yl(l, s.changed);
					l.surface = {
						...l.surface,
						asset: n
					}, el(e, r, i, t, n, Ae.name, "Ready to draw"), l.assetId = He(e.document, r)?.asset ?? l.assetId;
				}
				Oe.current = l, ae(0), d("on"), Pe(c), m !== "color" && await Le(m);
			} catch {
				L("The model's pictures could not be read."), d("off");
			}
		}
	}, Me = async () => {
		let t = Oe.current;
		if (Oe.current = null, !t) return d("off");
		d("keeping");
		try {
			if (t.dirty.size) {
				let n = He(e.document, t.at), r = await yl(t);
				n?.asset === t.assetId && el(e, t.at, n, t.surface.asset, r, t.name, "Drawing");
			}
		} catch {
			L("The drawing could not be kept.");
		}
		d("off");
	}, Ne = K(Me);
	Ne.current = Me, G(() => () => void Ne.current(), []), G(() => {
		let e = Oe.current;
		e && u === "on" && i.asset !== e.assetId && (Oe.current = null, d("off"), L("The model changed, so drawing stopped. Strokes not yet kept with Done are gone."));
	}, [i.asset, u]);
	let Pe = (e) => {
		let t = Oe.current, n = s.current;
		if (!t || !n) return;
		let r = /* @__PURE__ */ new Set();
		for (let n of e) if (n >= Li(0)) {
			let e = n - Li(0), i = t.surface.pictures.get(e), a = t.surface.pictures.get(n), o = t.surface.originals.get(e);
			i && a && o && sa(a, o, i, 12 * (a.width / 1024)), r.add(e);
		} else r.add(n);
		for (let e of r) {
			let r = t.canvases.get(e);
			r && (r.canvas.getContext("2d").putImageData(r.image, 0, 0), n.previewPicture(t.assetId, e, r.canvas));
		}
	}, Fe = () => {
		let e = Oe.current, t = e?.undo.pop();
		if (e && t) {
			Pe(Zi(e.surface, t));
			for (let n of t.pieces) e.dirty.add(n.picture >= Li(0) ? n.picture - Li(0) : n.picture);
			ae(e.undo.length);
		}
	}, Ie = K(Fe);
	Ie.current = Fe;
	let Le = async (t) => {
		h(t);
		let n = Oe.current;
		if (!n) return;
		let r = n.surface.asset, i = [...new Set(r.materials.map((e) => Ri(e, t)))].filter((e) => e >= 0 && !n.surface.pictures.has(e));
		for (let e of i) {
			let t = await gl(r.textures[e].bytes, r.textures[e].mime, n.detail);
			n.surface.pictures.set(e, t), n.canvases.set(e, vl(t));
		}
		let a = oa(r, n.surface.pictures, t);
		for (let e of a.changed) n.canvases.set(e, vl(a.pictures.get(e)));
		let o = a.asset;
		if (a.remade) {
			let i = He(e.document, n.at);
			if (!i || i.asset !== n.assetId) return;
			n.surface = {
				...n.surface,
				asset: o,
				pictures: a.pictures
			}, o = await yl(n, /* @__PURE__ */ new Set([...n.dirty, ...a.changed])), el(e, n.at, i, r, o, n.name, `Ready to paint ${Fi[t].toLowerCase()}`), n.assetId = He(e.document, n.at)?.asset ?? n.assetId, n.dirty.clear();
		}
		n.surface = Ki(o, a.pictures, t, n.surface.originals);
	}, Re = (e, t) => [...e.marks].flatMap(([n, r]) => {
		let i = e.surface.pictures.get(n), a = e.canvases.get(n), o = i && a ? na(r, i.width, i.height, 256) : null;
		return o && a ? [{
			t: n,
			square: o,
			weights: ra(r, i.width, o, t),
			canvas: a.canvas
		}] : [];
	}), ze = (e, t) => {
		if (t.length) {
			e.undo.push({ pieces: t });
			for (let n of t) e.dirty.add(n.picture);
			ae(e.undo.length), Pe(new Set(t.map((e) => e.picture)));
		}
	}, Be = () => {
		Oe.current?.marks.clear(), pe(!1);
	}, Ve = async () => {
		let e = Oe.current;
		if (!e || !ue) return;
		L(null);
		let t = Re(e, 3);
		try {
			for (let [n, r] of t.entries()) {
				xe(`Adding details${t.length > 1 ? ` (${n + 1} of ${t.length})` : ""}… about a minute`);
				let i = Math.max(512, Math.min(1024, r.square[2])), a = document.createElement("canvas");
				a.width = i, a.height = i * 2;
				let o = a.getContext("2d");
				o.drawImage(ml(r.canvas, r.square, i), 0, 0);
				let s = r.square[2], c = new ImageData(s, s);
				for (let e = 0; e < s * s; e++) {
					let t = r.weights[e] > 0 ? 255 : 0;
					c.data.set([
						t,
						t,
						t,
						255
					], e * 4);
				}
				let l = document.createElement("canvas");
				l.width = l.height = s, l.getContext("2d").putImageData(c, 0, 0), o.drawImage(l, 0, i, i, i);
				let u = await new Promise((e, t) => a.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The area could not be prepared.")), "image/png")), d = await hl(await le.client.redraw(u, {
					prompt: me.trim() || "the same, finely detailed, clean lines, high quality",
					negative: ge.trim() || void 0,
					strength: ve,
					guidance: 8,
					steps: 25,
					stacked: !0,
					clamp: !1
				}), s, { topHalf: !0 });
				ze(e, ia(e.surface, r.t, r.square, d, r.weights).pieces);
			}
			Be();
		} catch (e) {
			L(e instanceof Error ? `The AI details did not work: ${e.message}` : "The AI details did not work.");
		} finally {
			xe(null);
		}
	}, Ue = async (e) => {
		let t = Oe.current;
		if (t) {
			L(null);
			try {
				let n = await createImageBitmap(e), r = [];
				for (let e of Re(t, 1)) {
					let i = await hl(n, e.square[2], { cover: !0 });
					r.push(...ia(t.surface, e.t, e.square, i, e.weights).pieces);
				}
				n.close(), ze(t, r);
			} catch {
				L("That image could not be read.");
			}
		}
	};
	if (G(() => {
		let e = c.current, t = s.current, n = Oe.current;
		if (u !== "on" || !e || !t || !n) return;
		let a = n.surface.asset, o = an(i, a), l = Math.max(...i.size), d = (a.min[0] + a.max[0]) / 2, f = (e) => e.length === r.length && e.every((e, t) => e === r[t]), p = null, m = null, h = [void 0, void 0], g = /* @__PURE__ */ new Set(), v = 0, b = /* @__PURE__ */ new Map(), x = !1, S = () => {
			v = 0, Pe(g), g.clear();
		}, w = (e) => {
			let t = o.units(sl(B.current.size) * l);
			return e.pointerType === "pen" ? t * (.3 + .7 * (e.pressure || .5)) : t;
		}, E = (e, n, r) => {
			let i = n, a = Math.abs(i[1]) < .9 ? [
				0,
				1,
				0
			] : [
				1,
				0,
				0
			], o = [
				i[1] * a[2] - i[2] * a[1],
				i[2] * a[0] - i[0] * a[2],
				i[0] * a[1] - i[1] * a[0]
			], s = Math.hypot(...o) || 1, c = o.map((e) => e / s), l = [
				i[1] * c[2] - i[2] * c[1],
				i[2] * c[0] - i[0] * c[2],
				i[0] * c[1] - i[1] * c[0]
			], u = Array.from({ length: 33 }, (t, n) => {
				let i = n / 32 * Math.PI * 2;
				return [
					0,
					1,
					2
				].map((t) => e[t] + (c[t] * Math.cos(i) + l[t] * Math.sin(i)) * r);
			});
			t.setMarks("draw", {
				points: [],
				lines: u.slice(1).map((e, t) => [u[t], e])
			});
		}, D = (e, t, n) => {
			let r = Oe.current;
			if (!r || !p) return;
			let i = B.current, a = i.channel, o = Math.round(i.value * 255), s = Math.round(128 + i.bump * 127), c = {
				tool: i.tool,
				radius: w(t),
				color: a === "rough" ? [
					0,
					o,
					0
				] : a === "metal" ? [
					0,
					0,
					o
				] : a === "coat" ? [
					o,
					0,
					0
				] : a === "bump" ? [
					s,
					s,
					s
				] : fl(i.color),
				write: Ii[a],
				alpha: a === "holes" ? i.fill ? 255 : 0 : void 0,
				opacity: i.opacity * (t.pointerType === "pen" ? .4 + .6 * (t.pressure || .5) : 1),
				hardness: i.hardness
			};
			for (let t of Yi(r.surface, p, {
				...c,
				at: e,
				facing: n,
				part: h[0]
			})) g.add(t);
			if (i.mirror) {
				let t = [
					2 * d - e[0],
					e[1],
					e[2]
				];
				for (let e of Yi(r.surface, p, {
					...c,
					at: t,
					facing: [
						-n[0],
						n[1],
						n[2]
					],
					part: h[1]
				})) g.add(e);
			}
			v ||= requestAnimationFrame(S);
		}, O = (e) => {
			let n = o.move(t.rayAt(e.clientX, e.clientY).dir), r = Math.hypot(...n) || 1;
			return n.map((e) => e / r);
		}, k = (n) => {
			if (n.pointerType === "touch" && b.set(n.pointerId, {
				clientX: n.clientX,
				clientY: n.clientY
			}), x) return;
			if (b.size >= 2) return A(n);
			let r = Oe.current, i = t.modelHitAt(n.clientX, n.clientY);
			if (!r || !i || !f(i.ref)) return;
			n.stopPropagation();
			let a = o.point(i.point);
			if (B.current.picking || n.altKey) {
				let e = ea(r.surface, a, w(n) * 2), t = B.current.channel;
				e && (t === "color" || t === "glow") ? C(dl(e.color)) : e && t === "rough" ? _(e.color[1] / 255) : e && t === "metal" ? _(e.color[2] / 255) : e && t === "coat" ? _(e.color[0] / 255) : e && t === "bump" && y(Math.max(-1, Math.min(1, (e.color[0] - 128) / 127))), I(!1);
				return;
			}
			let s = B.current.sticker;
			if (s && B.current.channel === "color" && B.current.tool === "pen") {
				let e = ul(o.move(i.normal)), t = O(n), c = ll(t, ul(o.move([
					0,
					1,
					0
				]))), u = [
					0,
					1,
					2
				].map((t) => c[t] - e[t] * cl(c, e));
				Math.hypot(...u) < 1e-4 && (u = ll(e, Math.abs(e[1]) < .9 ? [
					0,
					1,
					0
				] : [
					1,
					0,
					0
				])), u = ul(u);
				let d = ll(e, u), f = B.current.stickerTurn * Math.PI / 180, p = [
					0,
					1,
					2
				].map((e) => u[e] * Math.cos(f) + d[e] * Math.sin(f)), m = [
					0,
					1,
					2
				].map((e) => d[e] * Math.cos(f) - u[e] * Math.sin(f)), h = o.units(B.current.stickerSize * l) / 2, g = Ji(), _ = Yi(r.surface, g, {
					tool: "pen",
					at: a,
					radius: h * 1.6,
					color: [
						0,
						0,
						0
					],
					opacity: 1,
					hardness: 1,
					facing: t,
					part: B.current.onePart ? ea(r.surface, a, h * 1.6)?.part : void 0,
					write: Ii.color,
					image: {
						data: s.data,
						width: s.width,
						height: s.height,
						u: p,
						v: m,
						half: h
					}
				}), v = Xi(r.surface, g);
				if (ta(r.surface, r.marks, g), pe(r.marks.size > 0), ce(v.pieces.some((e) => r.surface.repeats.has(e.picture))), v.pieces.length) {
					r.undo.push(v), r.undo.length > 40 && r.undo.shift();
					for (let e of v.pieces) r.dirty.add(e.picture >= Li(0) ? e.picture - Li(0) : e.picture);
					ae(r.undo.length);
				}
				Pe(_);
				return;
			}
			t.setOrbit(!1), e.setPointerCapture(n.pointerId), p = Ji();
			let c = w(n);
			h = B.current.onePart ? [ea(r.surface, a, c)?.part, ea(r.surface, [
				2 * d - a[0],
				a[1],
				a[2]
			], c * 2)?.part] : [void 0, void 0], m = a, D(a, n, O(n));
		}, A = (e) => {
			x = !0;
			let n = Oe.current;
			if (p && n) {
				let e = Xi(n.surface, p);
				p = null, m = null, e.pieces.length && (n.undo.push(e), Ie.current());
			}
			t.setMarks("draw", null), t.setOrbit(!0);
			for (let [n, r] of b) n !== e.pointerId && t.canvas.dispatchEvent(new PointerEvent("pointerdown", {
				...r,
				pointerId: n,
				pointerType: "touch",
				isPrimary: !0,
				button: 0,
				buttons: 1,
				bubbles: !0
			}));
		}, j = (e) => {
			if (e.pointerType === "touch" && b.has(e.pointerId) && b.set(e.pointerId, {
				clientX: e.clientX,
				clientY: e.clientY
			}), x) return;
			let n = t.modelHitAt(e.clientX, e.clientY), r = n && f(n.ref), i = B.current.sticker && B.current.channel === "color" && B.current.tool === "pen";
			if (r ? E(n.point, n.normal, i ? B.current.stickerSize * l / 2 : sl(B.current.size) * l * (e.pointerType === "pen" ? .3 + .7 * (e.pressure || .5) : 1)) : t.setMarks("draw", null), !p || (e.stopPropagation(), !r)) return;
			let a = o.point(n.point), s = m ?? a, c = Math.hypot(a[0] - s[0], a[1] - s[1], a[2] - s[2]), u = Math.max(w(e) / 3, 1e-6), d = Math.min(64, Math.ceil(c / u)), h = O(e);
			for (let t = 1; t <= d; t++) D([
				0,
				1,
				2
			].map((e) => s[e] + (a[e] - s[e]) * t / d), e, h);
			m = a;
		}, M = (e) => {
			if (b.delete(e.pointerId), x) {
				b.size === 0 && (x = !1);
				return;
			}
			let n = Oe.current;
			if (!p || !n) return;
			e.stopPropagation();
			let r = Xi(n.surface, p);
			if (ce(r.pieces.some((e) => n.surface.repeats.has(e.picture))), B.current.channel === "color" && ta(n.surface, n.marks, p), pe(n.marks.size > 0), r.pieces.length) {
				n.undo.push(r), n.undo.length > 40 && n.undo.shift();
				for (let e of r.pieces) n.dirty.add(e.picture >= Li(0) ? e.picture - Li(0) : e.picture);
				ae(n.undo.length);
				let e = B.current.color;
				B.current.tool === "pen" && T((t) => [e, ...t.filter((t) => t !== e)].slice(0, 8));
			}
			p = null, m = null, t.setOrbit(!0);
		}, ee = (e) => {
			(e.metaKey || e.ctrlKey) && !e.shiftKey && e.key.toLowerCase() === "z" && Oe.current?.undo.length && (e.preventDefault(), e.stopPropagation(), Ie.current());
		};
		return e.addEventListener("pointerdown", k, !0), e.addEventListener("pointermove", j, !0), e.addEventListener("pointerup", M, !0), e.addEventListener("pointercancel", M, !0), window.addEventListener("keydown", ee, !0), e.style.cursor = "crosshair", () => {
			e.removeEventListener("pointerdown", k, !0), e.removeEventListener("pointermove", j, !0), e.removeEventListener("pointerup", M, !0), e.removeEventListener("pointercancel", M, !0), window.removeEventListener("keydown", ee, !0), e.style.cursor = "", cancelAnimationFrame(v), t.setMarks("draw", null), t.setOrbit(!0);
		};
	}, [
		u,
		i.position,
		i.rotation,
		i.size,
		r,
		s,
		c
	]), !Ae) return null;
	let We = u === "on";
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Draw" }),
		/* @__PURE__ */ Y("p", {
			className: "gs-m3d__meta",
			children: "Draw on the model's pictures to refine it: eyes, lashes, makeup, patterns. A pen tablet's pressure counts."
		}),
		/* @__PURE__ */ Y(W, {
			label: "Paint into",
			value: m,
			options: Pi,
			labels: Fi,
			onChange: (e) => void Le(e).catch(() => L("That could not be made ready to paint."))
		}),
		/* @__PURE__ */ Y(W, {
			label: "Drawing tool",
			value: f,
			options: zi,
			labels: Bi,
			onChange: p
		}),
		f === "pen" && (m === "rough" || m === "metal" || m === "coat") && /* @__PURE__ */ Y(U, {
			label: m === "rough" ? "Roughness (shiny to matte)" : m === "metal" ? "Metal" : "Clear coat",
			value: g,
			min: 0,
			max: 1,
			step: .05,
			format: (e) => `${Math.round(e * 100)}%`,
			onBegin: () => void 0,
			onChange: _,
			onEnd: () => void 0
		}),
		f === "pen" && m === "bump" && /* @__PURE__ */ Y(U, {
			label: "Raise or lower",
			value: v,
			min: -1,
			max: 1,
			step: .05,
			format: (e) => e > 0 ? `Raise ${Math.round(e * 100)}%` : e < 0 ? `Lower ${Math.round(-e * 100)}%` : "Flat",
			onBegin: () => void 0,
			onChange: y,
			onEnd: () => void 0
		}),
		f === "pen" && m === "holes" && /* @__PURE__ */ Y(W, {
			label: "Holes",
			value: b ? "fill" : "cut",
			options: ["cut", "fill"],
			labels: {
				cut: "Cut a hole",
				fill: "Fill it back"
			},
			onChange: (e) => x(e === "fill")
		}),
		f === "pen" && (m === "color" || m === "glow") && /* @__PURE__ */ X("div", {
			className: "gs-m3d__row",
			children: [/* @__PURE__ */ X("label", {
				className: "gs-m3d__colour",
				children: [/* @__PURE__ */ Y("input", {
					type: "color",
					value: S,
					onChange: (e) => C(e.target.value)
				}), " Colour"]
			}), /* @__PURE__ */ Y("button", {
				type: "button",
				className: `gs-m3d__btn${F ? " is-on" : ""}`,
				disabled: !We,
				onClick: () => I((e) => !e),
				children: "Pick a colour"
			})]
		}),
		f === "pen" && m === "color" && /* @__PURE__ */ X(J, { children: [
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__row",
				children: [/* @__PURE__ */ Y("button", {
					type: "button",
					className: `gs-m3d__btn${R ? " is-on" : ""}`,
					onClick: () => De.current?.click(),
					children: R ? `Sticker: ${R.name}` : "Sticker from a picture…"
				}), R && /* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					"aria-label": "Put the sticker away",
					onClick: () => Ce(null),
					children: "×"
				})]
			}),
			/* @__PURE__ */ Y("input", {
				ref: De,
				type: "file",
				accept: "image/png,image/jpeg,image/webp,image/svg+xml",
				hidden: !0,
				onChange: (e) => {
					let t = e.target.files?.[0];
					e.target.value = "", t && ke(t);
				}
			}),
			R && /* @__PURE__ */ X(J, { children: [
				/* @__PURE__ */ Y(U, {
					label: "Sticker size",
					value: z,
					min: .05,
					max: 1,
					step: .01,
					format: (e) => `${Math.round(e * 100)}%`,
					onBegin: () => void 0,
					onChange: we,
					onEnd: () => void 0
				}),
				/* @__PURE__ */ Y(U, {
					label: "Sticker turn",
					value: Te,
					min: -180,
					max: 180,
					step: 5,
					format: (e) => `${Math.round(e)}°`,
					onBegin: () => void 0,
					onChange: Ee,
					onEnd: () => void 0
				}),
				/* @__PURE__ */ Y("p", {
					className: "gs-m3d__note",
					children: We ? "Click the model to stamp it, as often as you like; its see-through parts leave the model alone. × puts it away." : "Press Draw on the model, then click the model to stamp it."
				}),
				/* @__PURE__ */ Y(o, { id: "m3dSticker" })
			] })
		] }),
		f === "pen" && w.length > 0 && /* @__PURE__ */ Y("div", {
			className: "gs-draw__swatches",
			role: "group",
			"aria-label": "Colours used",
			children: w.map((e) => /* @__PURE__ */ Y("button", {
				type: "button",
				title: e,
				"aria-label": e,
				style: { background: e },
				onClick: () => C(e)
			}, e))
		}),
		/* @__PURE__ */ Y(U, {
			label: "Size",
			value: E,
			min: 0,
			max: 1,
			step: .01,
			format: (e) => `${(sl(e) * 100).toFixed(sl(e) < .01 ? 2 : 1)}%`,
			onBegin: () => void 0,
			onChange: D,
			onEnd: () => void 0
		}),
		/* @__PURE__ */ Y(U, {
			label: "Opacity",
			value: k,
			min: .05,
			max: 1,
			step: .05,
			format: (e) => `${Math.round(e * 100)}%`,
			onBegin: () => void 0,
			onChange: A,
			onEnd: () => void 0
		}),
		/* @__PURE__ */ Y(U, {
			label: "Hardness",
			value: j,
			min: 0,
			max: 1,
			step: .05,
			format: (e) => `${Math.round(e * 100)}%`,
			onBegin: () => void 0,
			onChange: M,
			onEnd: () => void 0
		}),
		/* @__PURE__ */ X("label", {
			className: "gs-m3d__check",
			children: [/* @__PURE__ */ Y("input", {
				type: "checkbox",
				checked: ee,
				onChange: (e) => te(e.target.checked)
			}), " Mirror left and right"]
		}),
		/* @__PURE__ */ X("label", {
			className: "gs-m3d__check",
			children: [/* @__PURE__ */ Y("input", {
				type: "checkbox",
				checked: ne,
				onChange: (e) => N(e.target.checked)
			}), " Only the part the stroke starts on"]
		}),
		!We && /* @__PURE__ */ Y(W, {
			label: "Picture detail",
			value: P,
			options: al,
			labels: ol,
			onChange: re
		}),
		/* @__PURE__ */ Y("div", {
			className: "gs-m3d__row",
			children: We ? /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				disabled: !ie || !!be,
				onClick: Fe,
				children: "Undo stroke"
			}), /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn gs-m3d__btn--primary",
				disabled: !!be,
				onClick: () => void Me(),
				children: "Done"
			})] }) : /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				disabled: u !== "off",
				onClick: () => void je(),
				children: u === "starting" ? "Getting the pictures ready…" : u === "keeping" ? "Keeping the drawing…" : "Draw on the model"
			})
		}),
		We && /* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: "Drag on the model to draw, off it to turn the view; Alt-click takes a colour. Done keeps the strokes as one undo step."
		}),
		We && m === "color" && /* @__PURE__ */ X("div", {
			className: "gs-draw__ai",
			children: [
				/* @__PURE__ */ Y("strong", { children: "AI details (optional)" }),
				de && le.state !== "ready" && /* @__PURE__ */ Y(a, {
					app: le,
					feature: "AI details",
					compact: !0
				}),
				/* @__PURE__ */ X("p", {
					className: "gs-m3d__note",
					hidden: !!de && le.state !== "ready",
					children: [
						ue ? "Free: the image model on this computer, about a minute an area; nothing is sent anywhere. It works where you drew since the last pass, your drawing steering it." : le.state === "ready" ? "AI details need the image model, set up once with: npm run redraw:setup (free, on this computer)." : "AI details need the Gleamshelf app running on this computer (free; nothing is sent anywhere).",
						" ",
						!ue && !le.looking && /* @__PURE__ */ Y("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: () => void le.check(),
							children: "Look for the app"
						})
					]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field gs-m3d__field--top",
					children: [/* @__PURE__ */ Y("span", { children: "Describe" }), /* @__PURE__ */ Y("textarea", {
						rows: 2,
						maxLength: 300,
						value: me,
						placeholder: "e.g. sparkling anime eyes with fine lashes",
						onChange: (e) => he(e.target.value),
						disabled: !!be
					})]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field gs-m3d__field--top",
					children: [/* @__PURE__ */ Y("span", { children: "Avoid" }), /* @__PURE__ */ Y("textarea", {
						rows: 2,
						maxLength: 300,
						value: ge,
						onChange: (e) => _e(e.target.value),
						disabled: !!be
					})]
				}),
				/* @__PURE__ */ Y(U, {
					label: "How much it may change",
					value: ve,
					min: .4,
					max: .95,
					step: .05,
					format: (e) => e < .65 ? `${Math.round(e * 100)}%: keeps your lines` : e > .88 ? `${Math.round(e * 100)}%: free hand` : `${Math.round(e * 100)}%`,
					onBegin: () => void 0,
					onChange: ye,
					onEnd: () => void 0
				}),
				/* @__PURE__ */ X("div", {
					className: "gs-m3d__row",
					children: [
						/* @__PURE__ */ Y("button", {
							type: "button",
							className: "gs-m3d__btn gs-m3d__btn--primary",
							disabled: !ue || !fe || !!be,
							onClick: () => void Ve(),
							children: be ?? "Add details where I drew"
						}),
						/* @__PURE__ */ Y("button", {
							type: "button",
							className: "gs-m3d__btn",
							disabled: !fe || !!be,
							onClick: () => Se.current?.click(),
							children: "Put an image where I drew…"
						}),
						/* @__PURE__ */ Y("button", {
							type: "button",
							className: "gs-m3d__btn",
							disabled: !fe || !!be,
							onClick: Be,
							children: "Start a new area"
						})
					]
				}),
				/* @__PURE__ */ Y("input", {
					ref: Se,
					type: "file",
					accept: "image/png,image/jpeg,image/webp",
					hidden: !0,
					onChange: (e) => {
						let t = e.target.files?.[0];
						e.target.value = "", t && Ue(t);
					}
				}),
				!fe && /* @__PURE__ */ Y("p", {
					className: "gs-m3d__meta",
					children: "Draw on the model first: the area you draw is where the AI or an image goes."
				})
			]
		}),
		We && se && /* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: "This part shares one picture between several places (hair strands often do), so what is drawn shows on each of them."
		}),
		oe && /* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: oe
		}),
		/* @__PURE__ */ Y(o, { id: "m3dDraw" }),
		/* @__PURE__ */ Y(o, { id: "m3dDrawTouch" })
	] });
}
//#endregion
//#region src/model3d/tutorials.ts
var xl = [
	"beginner",
	"intermediate",
	"advanced"
], Sl = {
	beginner: "Beginner: results in a minute",
	intermediate: "Intermediate",
	advanced: "Advanced: for designers"
}, Cl = {
	"3d": "3D",
	voice: "Voice"
}, wl = ".gs-avatar", Tl = ".gs-voice", El = {
	css: "button",
	label: "A character, anime"
}, Dl = { css: "select:has(option[value=\"png\"])" }, Ol = (e) => ({
	css: "[role=tab]",
	text: e
}), $ = (e, t) => ({
	css: "button",
	text: e,
	...t ? { within: t } : {}
}), kl = (e) => ({
	css: "h4",
	text: e
}), Al = [
	{
		id: "b-character",
		level: "beginner",
		topic: "3d",
		title: "Your own anime character, dancing, in 30 seconds",
		blurb: "No 3D skills needed: a few clicks and she moves.",
		minutes: 1,
		steps: [
			{
				say: "Click Character. That is all the 3D you need to know.",
				point: El,
				until: { shows: { css: wl } }
			},
			{
				say: "Press Surprise me as often as you like: a new character every time.",
				point: $("Surprise me")
			},
			{
				say: "Found one you love? Press New design of it.",
				point: $("New design of it"),
				until: { hides: { css: wl } }
			},
			{
				say: "Now make her move: under Animations, pick Hip-hop bounce.",
				point: $("Hip-hop bounce"),
				until: { shows: $("■ Stop") }
			},
			{ say: "She is dancing! Drag the view to look around her, and scroll to zoom. You made that." }
		]
	},
	{
		id: "b-scene",
		level: "beginner",
		topic: "3d",
		title: "A cosy room in one click",
		blurb: "Start from a ready-made scene and make it yours.",
		minutes: 1,
		steps: [
			{
				say: "Click Scenes.",
				point: {
					css: "button",
					label: "Start from a ready-made scene"
				},
				until: { shows: { css: ".gs-library--scenes" } }
			},
			{
				say: "Pick Anime bedroom (or any scene you like).",
				point: {
					css: ".gs-library__item",
					text: "Anime bedroom"
				},
				until: { hides: { css: ".gs-library--scenes" } }
			},
			{ say: "Drag on the view to turn round the room, and scroll to zoom in." },
			{ say: "Click any model to move it with its arrows, or press Delete to remove it." },
			{
				say: "Happy with it? Save… › Picture saves it to share.",
				point: Dl
			}
		]
	},
	{
		id: "b-voice",
		level: "beginner",
		topic: "voice",
		title: "Make a character talk",
		blurb: "Type a line, pick a voice, hear it. No microphone, no voice actor.",
		minutes: 1,
		steps: [
			{
				say: "Open the Game tab.",
				point: Ol("Game"),
				until: { shows: kl("Game project") }
			},
			{
				say: "Press Make this design a game's first level.",
				point: $("Make this design a game's first level"),
				until: { shows: kl("Levels") }
			},
			{
				say: "Press + Voice line…",
				point: $("+ Voice line…"),
				until: { shows: { css: Tl } }
			},
			{
				say: "Type anything, like: Hello! I'm the shop's friendly ghost.",
				point: {
					css: "textarea",
					within: Tl
				}
			},
			{
				say: "Pick an effect (try Ghost!), then press Make the line.",
				point: $("Make the line", Tl),
				until: { shows: { css: `${Tl} audio` } }
			},
			{
				say: "Hear it? Press Use this line: it is now one of your game’s sounds.",
				point: $("Use this line"),
				until: { hides: { css: Tl } }
			}
		]
	},
	{
		id: "i-design",
		level: "intermediate",
		topic: "3d",
		title: "Design a character from head to toe",
		blurb: "Outfit, face, eyes, proportions and colours, then a toon look and a touch of blush.",
		minutes: 5,
		steps: [
			{
				say: "Click Character to open the creator.",
				point: El,
				until: { shows: { css: wl } }
			},
			{
				say: "Outfit: pick a body and its clothes.",
				point: $("Outfit", wl)
			},
			{
				say: "Face: pick a face, then an expression above it.",
				point: $("Face", wl)
			},
			{
				say: "Eyes: take the eyes, lashes and brows each from a different character.",
				point: $("Eyes", wl)
			},
			{
				say: "Shape: try Chibi, then Glamorous, then fine-tune head, eyes, legs and figure.",
				point: $("Shape", wl)
			},
			{
				say: "Colours: give the hair, eyes and clothes your own colours.",
				point: $("Colours", wl)
			},
			{
				say: "Press New design of it.",
				point: $("New design of it"),
				until: { hides: { css: wl } }
			},
			{
				say: "In Material, set Shader to Toon and press This shader on every material: an anime look.",
				point: $("This shader on every material")
			},
			{
				say: "In Draw, press Draw on the model, tick Mirror left and right, and paint a little blush on a cheek. Press Done when happy.",
				point: $("Draw on the model")
			}
		]
	},
	{
		id: "i-game",
		level: "intermediate",
		topic: "3d",
		title: "Build a playable level",
		blurb: "Props from the library, a character, and Play game.",
		minutes: 6,
		steps: [
			{
				say: "Open the Library and add a few props (click one to add it).",
				point: {
					css: "button",
					label: "Ready-made models"
				}
			},
			{ say: "Move each prop with its arrows (M), turn it (T) or resize it (R)." },
			{
				say: "Open the Game tab.",
				point: Ol("Game"),
				until: { shows: kl("Game project") }
			},
			{
				say: "Press Make this design a game's first level.",
				point: $("Make this design a game's first level"),
				until: { shows: kl("Levels") }
			},
			{
				say: "Press + New character, make one in the creator, and press Add to the game.",
				point: $("+ New character")
			},
			{
				say: "Open Level 1 again, then press Place here beside your character.",
				point: {
					css: "button",
					text: "Place here"
				}
			},
			{
				say: "Press ▶ Play game: WASD walks, the mouse looks, E uses things.",
				point: $("▶ Play game")
			}
		]
	},
	{
		id: "i-voice",
		level: "intermediate",
		topic: "voice",
		title: "Speak your own lines in any voice",
		blurb: "Act the line yourself, keep your timing and feeling, change the voice.",
		minutes: 4,
		steps: [
			{
				say: "In the Game tab, open a project (or make this design its first level), then press + Voice line…",
				point: Ol("Game")
			},
			{
				say: "Choose Speak it.",
				point: $("Speak it", Tl)
			},
			{
				say: "Press Record the line and act it out. Press it again to stop.",
				point: $("● Record the line", Tl)
			},
			{
				say: "Choose Change my voice and pick a voice. The first time, a voice takes about a minute to make.",
				point: $("Change my voice", Tl)
			},
			{
				say: "Press Make the line and listen.",
				point: $("Make the line", Tl),
				until: { shows: { css: `${Tl} audio` } }
			},
			{
				say: "Write down what I said turns your words into text, to type over or speak in another voice.",
				point: $("Write down what I said", Tl)
			},
			{
				say: "Press Use this line.",
				point: $("Use this line"),
				until: { hides: { css: Tl } }
			}
		]
	},
	{
		id: "a-materials",
		level: "advanced",
		topic: "3d",
		title: "Materials, maps and renders like a pro",
		blurb: "Per-material shaders, painted roughness, metal, glow and bumps, AI detail, and the photo-real render.",
		minutes: 10,
		steps: [
			{ say: "Select an imported model: a character from the creator or a model from the Library." },
			{
				say: "In Material, press Pick on the model and click a part. Start from a ready-made material, then set roughness, metal, clear coat, sheen and glass. Sliders show as you drag; letting go keeps it.",
				point: $("Pick on the model")
			},
			{
				say: "Mix shaders: a Toon face on a Physical body, Unlit for screens and signs, Clay to judge the form.",
				point: kl("Material")
			},
			{
				say: "In Draw, set Picture detail to 2048 px, then press Draw on the model.",
				point: $("Draw on the model")
			},
			{
				say: "Paint into Roughness for shiny spots, Metal for trims, Glow for neon lines, Bumps to raise stitching, Holes for lace. Each picture the material lacks is made for it.",
				point: {
					css: "[aria-label]",
					label: "Paint into"
				}
			},
			{
				say: "Optional AI details: draw roughly in Colour, say what you want and what to avoid, and let the image model on this computer add the detail.",
				point: { css: ".gs-draw__ai" }
			},
			{
				say: "Save… › Photo-real render: real light, glass and reflections, while toon and flat materials stay drawn.",
				point: Dl
			}
		]
	},
	{
		id: "a-motion",
		level: "advanced",
		topic: "3d",
		title: "Animation, rigging and export",
		blurb: "Bones, ready-made moves tuned by hand, keys on the timeline, and files for other tools.",
		minutes: 10,
		steps: [
			{
				say: "Select a model. In Rig, give it a figure rig (or a chain), and pose it with the sliders or Reach.",
				point: kl("Rig")
			},
			{
				say: "In Animations, pick a move, then tune Speed, Energy and Arm space; Mirror swaps sides, In place keeps it on the spot.",
				point: kl("Animations")
			},
			{
				say: "Timeline shows every key along the clip: drag one to retime it. Keyframes move the camera too.",
				point: $("Timeline")
			},
			{
				say: "Save… › Video for clips, or 3D model (GLB) for other tools and game engines.",
				point: Dl
			}
		]
	},
	{
		id: "a-voice",
		level: "advanced",
		topic: "voice",
		title: "A cast of voices for a whole game",
		blurb: "Consistent characters, performances, effects and pronunciation.",
		minutes: 8,
		steps: [
			{ say: "Give each character one voice and keep to it: put it in their name, like Mika (Bella)." },
			{ say: "Size and age with Pitch: a few semitones up for small or young, down for big or old." },
			{ say: "Effects for kind: Robot voice for machines, Monster for creatures, Radio for calls, Cave or Ghost for places." },
			{ say: "For performances, speak the lines yourself and Change my voice: your timing and feeling, their voice." },
			{ say: "Spell names the way they sound if a voice says them wrong (Gleamshelf as Gleem-shelf)." },
			{
				say: "On a Say lines action in the Game tab, Make the voice… speaks those very lines and links the sound to them.",
				point: $("Make the voice…")
			},
			{ say: "Save the WAV keeps a line for trailers and the video editor." }
		]
	}
];
function jl(e, t = document) {
	let n = e.within ? t.querySelector(e.within) : t;
	if (!n) return null;
	let r = [...n.querySelectorAll(e.css ?? "button, [role=tab], label, h4")];
	for (let t of r) {
		if (e.text !== void 0 && u(t).trim() !== e.text || e.label !== void 0 && !(d(t, "title") ?? d(t, "aria-label") ?? "").startsWith(e.label)) continue;
		let n = t.getBoundingClientRect();
		if (n.width > 0 && n.height > 0) return t;
	}
	return null;
}
function Ml(e, t = document) {
	return e.until ? "shows" in e.until ? !!jl(e.until.shows, t) : !jl(e.until.hides, t) : null;
}
//#endregion
//#region src/model3d/LearnPanel.tsx
var Nl = "gleamshelf:tutorials-done", Pl = () => {
	try {
		let e = JSON.parse(localStorage.getItem(Nl) ?? "[]");
		return Array.isArray(e) ? e.filter((e) => typeof e == "string") : [];
	} catch {
		return [];
	}
}, Fl = (e) => {
	try {
		localStorage.setItem(Nl, JSON.stringify(e));
	} catch {}
}, Il = {
	all: "Everything",
	...Cl
};
function Ll({ open: e, onClose: t }) {
	let [n, r] = q("all"), [i, a] = q(Pl), [s, c] = q(null), [l, u] = q(null), [d, f] = q(!1), p = K(-1), m = (e) => {
		t(), p.current = -1, c({
			tutorial: e,
			step: 0
		});
	}, h = () => {
		if (!s) return;
		let e = [.../* @__PURE__ */ new Set([...i, s.tutorial.id])];
		a(e), Fl(e), c(null), u(null);
	}, g = (e) => c((t) => {
		if (!t) return t;
		let n = t.step + e;
		return n < 0 || n >= t.tutorial.steps.length ? t : (p.current = -1, {
			...t,
			step: n
		});
	});
	G(() => {
		if (!s) return;
		let e = s.tutorial.steps[s.step], t = !1, n = () => {
			let n = e.point ? jl(e.point) : null;
			n && p.current !== s.step && (p.current = s.step, n.scrollIntoView({
				block: "nearest",
				inline: "nearest"
			})), u(n ? n.getBoundingClientRect() : null), !t && Ml(e) === !0 && (t = !0, f(!0), window.setTimeout(() => {
				f(!1), s.step + 1 < s.tutorial.steps.length && g(1);
			}, 700));
		};
		n();
		let r = window.setInterval(n, 250);
		return () => window.clearInterval(r);
	}, [s]);
	let _ = Al.filter((e) => n === "all" || e.topic === n), v = s?.tutorial.steps[s.step], y = !!l && l.left < 400 && l.bottom > window.innerHeight - 240, b = s ? s.step === s.tutorial.steps.length - 1 : !1;
	return /* @__PURE__ */ X(J, { children: [e && /* @__PURE__ */ X(uo, {
		title: "Learn",
		onClose: t,
		children: [
			/* @__PURE__ */ Y("p", {
				className: "gs-m3d__meta",
				children: "Short tutorials you follow in the editor: each points at what to press next. Open them any time."
			}),
			/* @__PURE__ */ Y(W, {
				label: "Topic",
				value: n,
				options: [
					"all",
					"3d",
					"voice"
				],
				labels: Il,
				onChange: r
			}),
			xl.map((e) => {
				let t = _.filter((t) => t.level === e);
				return t.length ? /* @__PURE__ */ X("section", {
					className: "gs-learn__level",
					children: [/* @__PURE__ */ Y("h4", { children: Sl[e] }), /* @__PURE__ */ Y("div", {
						className: "gs-learn__cards",
						children: t.map((e) => /* @__PURE__ */ X("button", {
							type: "button",
							className: "gs-learn__card",
							onClick: () => m(e),
							children: [
								/* @__PURE__ */ X("strong", { children: [i.includes(e.id) ? "✓ " : "", e.title] }),
								/* @__PURE__ */ Y("span", { children: e.blurb }),
								/* @__PURE__ */ Y("small", { children: `${Cl[e.topic]} · ${e.minutes} min` })
							]
						}, e.id))
					})]
				}, e) : null;
			}),
			/* @__PURE__ */ Y(o, { id: "m3dLearn" })
		]
	}), s && v && /* @__PURE__ */ X(J, { children: [l && /* @__PURE__ */ Y("div", {
		className: "gs-coach__ring",
		"aria-hidden": "true",
		style: {
			left: l.left - 6,
			top: l.top - 6,
			width: l.width + 12,
			height: l.height + 12
		}
	}), /* @__PURE__ */ X("div", {
		className: `gs-coach${y ? " gs-coach--right" : ""}`,
		role: "dialog",
		"aria-label": "Tutorial",
		children: [
			/* @__PURE__ */ X("div", {
				className: "gs-coach__head",
				children: [/* @__PURE__ */ Y("strong", { children: s.tutorial.title }), /* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-coach__x",
					"aria-label": "Stop the tutorial",
					onClick: () => (c(null), u(null)),
					children: "✕"
				})]
			}),
			/* @__PURE__ */ Y("small", { children: `Step ${s.step + 1} of ${s.tutorial.steps.length}` }),
			/* @__PURE__ */ X("p", { children: [d && "✓ ", v.say] }),
			v.point && !l && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__meta",
				children: "(What to press is not on the screen yet: it may be in another tab or further down.)"
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__row",
				children: [
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						disabled: s.step === 0,
						onClick: () => g(-1),
						children: "← Back"
					}),
					/* @__PURE__ */ Y("span", { className: "gs-m3d__spacer" }),
					b ? /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						onClick: h,
						children: "Done"
					}) : /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => g(1),
						children: v.until ? "Skip" : "Next"
					})
				]
			})
		]
	})] })] });
}
//#endregion
//#region src/model3d/MaterialSection.tsx
var Rl = (e) => `#${e.map((e) => {
	let t = e <= .0031308 ? e * 12.92 : 1.055 * Math.min(1, e) ** (1 / 2.4) - .055;
	return Math.round(Math.min(1, Math.max(0, t)) * 255).toString(16).padStart(2, "0");
}).join("")}`, zl = (e) => {
	let t = parseInt(e.slice(1), 16);
	return [
		16,
		8,
		0
	].map((e) => {
		let n = (t >> e & 255) / 255;
		return n <= .04045 ? n / 12.92 : ((n + .055) / 1.055) ** 2.4;
	});
}, Bl = (e) => `${Math.round(e * 100)}%`;
function Vl({ editor: e, doc: t, at: n, shape: r, viewRef: i, stageRef: a }) {
	let s = r.asset ? t.assets?.[r.asset] : void 0, c = Xr(() => r.asset && s ? O(r.asset, s.data) : null, [r.asset, s]), [l, u] = q(0), [d, f] = q(!1), [p, m] = q(null), h = K(null), g = (e) => {
		h.current = e, m(e);
	}, _ = K(0), v = c?.materials.length ?? 0, y = Math.min(l, Math.max(0, v - 1)), b = p ?? c?.materials[y];
	if (G(() => {
		let e = a.current, t = i.current;
		if (!d || !e || !t || !c) return;
		let o = (e) => {
			let i = t.modelHitAt(e.clientX, e.clientY);
			if (!i || i.ref.length !== n.length || i.ref.some((e, t) => e !== n[t])) return;
			e.stopPropagation();
			let a = ha(c, an(r, c).point(i.point));
			a >= 0 && u(a), f(!1);
		};
		return e.addEventListener("pointerdown", o, !0), e.style.cursor = "copy", () => {
			e.removeEventListener("pointerdown", o, !0), e.style.cursor = "";
		};
	}, [
		d,
		c,
		r,
		n,
		i,
		a
	]), G(() => () => window.clearTimeout(_.current), []), !s || !c || !b || !r.asset) return null;
	let x = r.asset, S = (e) => i.current?.previewMaterial(x, y, e), C = (t, a) => {
		window.clearTimeout(_.current);
		let o = M(c.parts, t, c.textures);
		el(e, n, r, c, o, s.name, a), i.current?.previewMaterial(x, y, null), g(null);
	}, w = (e, t) => C(c.materials.map((t, n) => n === y ? e : t), t), T = (e, t) => {
		g(e), S(e), window.clearTimeout(_.current), _.current = window.setTimeout(() => w(e, t), 450);
	}, E = (e, t, n, r, i, a, o = Bl) => /* @__PURE__ */ Y(U, {
		label: e,
		value: t,
		min: n,
		max: r,
		step: i,
		format: o,
		onBegin: () => void 0,
		onChange: (e) => {
			let t = a(e);
			g(t), S(t);
		},
		onEnd: () => {
			h.current && w(h.current, `Material ${e.toLowerCase()}`);
		}
	}), D = ua(b), k = Math.max(...b.emissive), A = Math.max(...b.sheenColor);
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Material" }),
		/* @__PURE__ */ Y("p", {
			className: "gs-m3d__meta",
			children: "Each material its own shader and settings. Draw paints them on where they should differ."
		}),
		/* @__PURE__ */ Y("div", {
			className: "gs-mat__list",
			role: "group",
			"aria-label": "Materials",
			children: c.materials.map((e, t) => /* @__PURE__ */ X("button", {
				type: "button",
				className: t === y ? "is-on" : "",
				title: `Material ${t + 1}${e.texture >= 0 ? " (with a picture)" : ""}`,
				onClick: () => {
					g(null), u(t);
				},
				children: [/* @__PURE__ */ Y("span", {
					className: "gs-mat__swatch",
					style: { background: Rl(e.color) },
					"aria-hidden": "true"
				}), t + 1]
			}, t))
		}),
		/* @__PURE__ */ Y("button", {
			type: "button",
			className: `gs-m3d__btn${d ? " is-on" : ""}`,
			onClick: () => f((e) => !e),
			children: d ? "Click the model…" : "Pick on the model"
		}),
		/* @__PURE__ */ Y(W, {
			label: "Shader",
			value: D,
			options: ca,
			labels: la,
			onChange: (e) => w(da(b, e), `${la[e]} shader`)
		}),
		/* @__PURE__ */ Y("div", {
			className: "gs-m3d__row",
			children: /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => C(c.materials.map((e) => da(e, D)), "Shader on every material"),
				children: "This shader on every material"
			})
		}),
		/* @__PURE__ */ Y("div", {
			className: "gs-anim__moves",
			role: "group",
			"aria-label": "Ready-made materials",
			children: ma.map((e) => /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => w(e.make(b), e.label),
				children: e.label
			}, e.id))
		}),
		/* @__PURE__ */ X("label", {
			className: "gs-m3d__colour",
			children: [
				/* @__PURE__ */ Y("input", {
					type: "color",
					value: Rl(b.color),
					onChange: (e) => T({
						...b,
						color: zl(e.target.value)
					}, "Material colour")
				}),
				" ",
				b.texture >= 0 ? "Tint over its picture" : "Colour"
			]
		}),
		D === "toon" && E("Light steps", b.bands ?? 3, 2, 8, 1, (e) => ({
			...b,
			bands: e
		}), (e) => String(e)),
		D === "physical" && /* @__PURE__ */ X(J, { children: [
			E("Roughness", b.roughness, 0, 1, .01, (e) => ({
				...b,
				roughness: e
			})),
			E("Metal", b.metalness, 0, 1, .01, (e) => ({
				...b,
				metalness: e
			})),
			E("Clear coat", b.clearcoat, 0, 1, .01, (e) => ({
				...b,
				clearcoat: e
			})),
			b.clearcoat > 0 && E("Coat roughness", b.clearcoatRoughness, 0, 1, .01, (e) => ({
				...b,
				clearcoatRoughness: e
			})),
			E("Sheen (velvet)", A, 0, 1, .01, (e) => ({
				...b,
				sheenColor: [
					e,
					e,
					e
				],
				sheenRoughness: b.sheenRoughness || .5
			})),
			E("Glass", b.transmission, 0, 1, .01, (e) => ({
				...b,
				transmission: e
			})),
			b.transmission > 0 && E("Bending of light (IOR)", b.ior, 1, 2.5, .01, (e) => ({
				...b,
				ior: e
			}), (e) => e.toFixed(2))
		] }),
		D !== "unlit" && D !== "clay" && /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ X("label", {
			className: "gs-m3d__colour",
			children: [
				/* @__PURE__ */ Y("input", {
					type: "color",
					value: Rl(k > 0 ? b.emissive.map((e) => e / k) : [
						1,
						1,
						1
					]),
					onChange: (e) => T({
						...b,
						emissive: zl(e.target.value).map((e) => e * Math.max(k, 1))
					}, "Glow colour")
				}),
				" ",
				"Glow colour"
			]
		}), E("Glow", Math.min(k, 10), 0, 10, .1, (e) => {
			let t = k > 0 ? b.emissive.map((e) => e / k) : [
				1,
				1,
				1
			];
			return {
				...b,
				emissive: t.map((t) => t * e)
			};
		}, (e) => e ? e.toFixed(1) : "Off")] }),
		b.normalTexture >= 0 && D !== "unlit" && E("Bumps", b.normalScale, 0, 3, .05, (e) => ({
			...b,
			normalScale: e
		}), (e) => e.toFixed(2)),
		/* @__PURE__ */ X("label", {
			className: "gs-m3d__check",
			children: [
				/* @__PURE__ */ Y("input", {
					type: "checkbox",
					checked: b.cutout,
					onChange: (e) => w({
						...b,
						cutout: e.target.checked
					}, "Material holes")
				}),
				" ",
				"See-through parts of its picture are holes"
			]
		}),
		/* @__PURE__ */ X("label", {
			className: "gs-m3d__check",
			children: [
				/* @__PURE__ */ Y("input", {
					type: "checkbox",
					checked: b.doubleSided,
					onChange: (e) => w({
						...b,
						doubleSided: e.target.checked
					}, "Two-sided")
				}),
				" ",
				"Two-sided"
			]
		}),
		/* @__PURE__ */ Y(o, { id: "m3dModelMaterial" })
	] });
}
//#endregion
//#region src/model3d/ElementsSection.tsx
function Hl({ editor: e, doc: t, at: n, shape: r, viewRef: i, stageRef: a, run: s }) {
	let [c, l] = q("vertex"), [u, d] = q(!1), [f, p] = q(null), [m, h] = q(.1), [g, _] = q(null), v = r.asset ? t.assets?.[r.asset] : void 0, y = Xr(() => v && r.asset ? O(r.asset, v.data) : null, [v, r.asset]), b = Xr(() => y ? an(r, y) : null, [r, y]), x = Math.max(...r.size), S = K({
		mode: c,
		model: y,
		space: b,
		sel: f
	});
	S.current = {
		mode: c,
		model: y,
		space: b,
		sel: f
	};
	let C = !!f && !!y && f.part < y.parts.length && f.places.every((e) => e < ti(y.parts[f.part].positions).points.length);
	if (G(() => {
		f && !C && p(null);
	}, [f, C]), G(() => {
		let e = a.current, t = i.current;
		if (!u || !e || !t) return;
		let r = (e) => e.length === n.length && e.every((e, t) => e === n[t]), o = null, s = (e) => {
			let n = t.modelHitAt(e.clientX, e.clientY);
			o = n && r(n.ref) ? {
				x: e.clientX,
				y: e.clientY
			} : null, o && e.stopPropagation();
		}, c = (e) => {
			if (!o || Math.hypot(e.clientX - o.x, e.clientY - o.y) > 4) return;
			o = null, e.stopPropagation();
			let { model: n, space: i, mode: a, sel: s } = S.current, c = t.modelHitAt(e.clientX, e.clientY);
			if (!n || !i || !c || !r(c.ref)) return;
			let l = di(n, i.point(c.point), a);
			l && p(e.shiftKey || e.metaKey || e.ctrlKey || a !== "face" ? fi(s, l) : fi(null, l));
		};
		return e.addEventListener("pointerdown", s, !0), e.addEventListener("pointerup", c, !0), e.style.cursor = "cell", () => {
			e.removeEventListener("pointerdown", s, !0), e.removeEventListener("pointerup", c, !0), e.style.cursor = "";
		};
	}, [
		u,
		n,
		i,
		a
	]), G(() => {
		let e = i.current;
		if (!e) return;
		if (!f || !C || !y || !b) {
			e.setMarks("elements", null);
			return;
		}
		let t = (e) => b.toScene(mi(y, f.part, e));
		e.setMarks("elements", {
			points: f.places.map(t),
			lines: pi(y, f).map(([e, n]) => [t(e), t(n)])
		});
	}, [
		f,
		C,
		y,
		b,
		i
	]), G(() => () => i.current?.setMarks("elements", null), [i]), !y || !v || !r.asset) return null;
	let w = C && !!f?.places.length, T = (e, t) => {
		if (!f || !b) return y;
		if (e === "grow") return yi(y, f, t);
		if (e === "turn") return bi(y, f, 1, t);
		let n = [
			0,
			0,
			0
		];
		return n[e === "x" ? 0 : e === "y" ? 1 : 2] = t * x, vi(y, f, b.move(n));
	}, E = (t, i, a = !1) => {
		el(e, n, r, y, t, v.name, i), a && p(null);
	}, D = (e, t) => void s(`${e}…`, async () => E(t(), e, !0)), k = (e, t, n, a, o, s) => /* @__PURE__ */ Y(U, {
		label: t,
		value: g?.tool === e ? g.value : o,
		min: n,
		max: a,
		step: (a - n) / 200,
		format: s,
		onBegin: () => _({
			tool: e,
			value: o
		}),
		onChange: (t) => {
			_({
				tool: e,
				value: t
			}), i.current?.previewModel(r.asset, T(e, t).parts);
		},
		onEnd: () => {
			g && g.value !== o && E(T(e, g.value), t), _(null);
		}
	}), A = (e) => `${e > 0 ? "+" : ""}${Math.round(e * 100)}%`;
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Points, edges and faces" }),
		/* @__PURE__ */ Y(W, {
			label: "Pick",
			value: c,
			options: Qr,
			labels: $r,
			onChange: (e) => {
				l(e), p(null);
			}
		}),
		/* @__PURE__ */ Y("button", {
			type: "button",
			className: `gs-m3d__btn${u ? " is-on" : ""}`,
			onClick: () => d((e) => !e),
			children: u ? "Picking: click the model (click here to turn the view again)" : "Pick on the model"
		}),
		/* @__PURE__ */ Y("p", {
			className: "gs-m3d__meta",
			children: w ? `${f.places.length} point${f.places.length === 1 ? "" : "s"}${f.triangles.length ? `, ${f.triangles.length} triangles` : ""} picked` : "Nothing picked yet."
		}),
		w && /* @__PURE__ */ X(J, { children: [
			k("x", "Move across", -.5, .5, 0, A),
			k("y", "Move up", -.5, .5, 0, A),
			k("z", "Move forward", -.5, .5, 0, A),
			k("grow", "Grow", .2, 3, 1, (e) => `${Math.round(e * 100)}%`),
			k("turn", "Turn", -180, 180, 0, (e) => `${Math.round(e)}°`),
			c === "face" && /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ Y(U, {
				label: "Push out by",
				value: m,
				min: -.5,
				max: .5,
				step: .01,
				format: A,
				onBegin: () => void 0,
				onChange: h,
				onEnd: () => void 0
			}), /* @__PURE__ */ X("div", {
				className: "gs-m3d__row",
				children: [/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => D("Extrude", () => Ei(y, f, b.units(m * x))),
					children: "Extrude"
				}), /* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => D("Inset", () => Ei(y, f, 0, .3)),
					children: "Inset"
				})]
			})] }),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__row",
				children: [
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => p(null),
						children: "Let go"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => D("Delete", () => Si(y, f)),
						children: "Delete"
					}),
					c !== "face" && f.places.length > 1 && /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => D("Merge", () => Ci(y, f)),
						children: "Merge"
					}),
					c === "vertex" && (f.places.length === 3 || f.places.length === 4) && /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => D("Fill", () => wi(y, f)),
						children: "Fill"
					}),
					c === "edge" && /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => D("Loop cut", () => Oi(y, f)),
						children: "Loop cut"
					})
				]
			})
		] }),
		/* @__PURE__ */ Y(o, { id: "m3dElements" })
	] });
}
//#endregion
//#region src/model3d/RigSection.tsx
function Ul({ editor: e, doc: t, at: n, shape: r, viewRef: i, stageRef: a }) {
	let [s, c] = q(0), [l, u] = q(!1), [d, f] = q(!1), p = r.asset ? t.assets?.[r.asset] : void 0, m = Xr(() => p && r.asset ? O(r.asset, p.data) : null, [p, r.asset]), h = Xr(() => m ? an(r, m) : null, [r, m]), g = r.rig, _ = K({
		rig: g,
		bone: s,
		space: h
	});
	_.current = {
		rig: g,
		bone: s,
		space: h
	};
	let v = (t, r) => e.updateShapeAt(n, { rig: t }, r);
	if (G(() => {
		let e = i.current;
		if (!e) return;
		if (!g || !h || !(d || l)) {
			e.setMarks("rig", null);
			return;
		}
		let t = Te(g).map((e) => ({
			head: h.toScene(e.head),
			tail: h.toScene(e.tail)
		}));
		e.setMarks("rig", {
			points: t.map((e) => e.head),
			lines: t.map((e) => [e.head, e.tail]),
			strong: t[s] ? [t[s].tail] : []
		});
	}, [
		g,
		h,
		s,
		i,
		d,
		l
	]), G(() => () => i.current?.setMarks("rig", null), [i]), G(() => {
		let t = a.current, r = i.current;
		if (!l || !t || !r) return;
		let o = null, s = (e) => {
			if (!o) return null;
			let { origin: t, dir: n } = r.rayAt(e.clientX, e.clientY), i = n[0] * o.normal[0] + n[1] * o.normal[1] + n[2] * o.normal[2];
			if (Math.abs(i) < 1e-6) return null;
			let a = ((o.point[0] - t[0]) * o.normal[0] + (o.point[1] - t[1]) * o.normal[1] + (o.point[2] - t[2]) * o.normal[2]) / i;
			return [
				t[0] + n[0] * a,
				t[1] + n[1] * a,
				t[2] + n[2] * a
			];
		}, c = (t) => {
			let { rig: r, bone: i, space: a } = _.current, o = s(t);
			if (!r || !a || !o) return;
			let c = Me(r, i, a.point(o), r.bones[i].parent >= 0 ? 2 : 1);
			e.updateShapeAt(n, { rig: {
				...r,
				pose: c
			} });
		}, u = (n) => {
			let { rig: i, bone: a, space: s } = _.current;
			i && s && n.target === r.canvas && (n.stopPropagation(), r.setOrbit(!1), t.setPointerCapture(n.pointerId), o = {
				point: s.toScene(Te(i)[a].tail),
				normal: r.rayAt(n.clientX, n.clientY).dir
			}, e.begin("Reach"), c(n));
		}, d = (e) => {
			o && (e.stopPropagation(), c(e));
		}, f = (t) => {
			o && (t.stopPropagation(), o = null, e.commit(), r.setOrbit(!0));
		};
		return t.addEventListener("pointerdown", u, !0), t.addEventListener("pointermove", d, !0), t.addEventListener("pointerup", f, !0), t.style.cursor = "grab", () => {
			t.removeEventListener("pointerdown", u, !0), t.removeEventListener("pointermove", d, !0), t.removeEventListener("pointerup", f, !0), t.style.cursor = "", r.setOrbit(!0);
		};
	}, [
		l,
		n,
		e,
		i,
		a
	]), !m) return null;
	if (!g) return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Rig" }),
		xt(m) && /* @__PURE__ */ Y("button", {
			type: "button",
			className: "gs-m3d__btn",
			onClick: () => v(xt(m), "The model's own bones"),
			children: `Use its own bones (${m.skeleton.length})`
		}),
		/* @__PURE__ */ X("div", {
			className: "gs-m3d__row",
			children: [/* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => v(Ae(m), "Add a figure rig"),
				children: "Add a figure rig"
			}), /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => v(fe(m, 4), "Add a chain"),
				children: "Add a chain"
			})]
		}),
		/* @__PURE__ */ Y(o, { id: "m3dRig" })
	] });
	let y = Math.min(s, g.bones.length - 1), b = Mt(g.bones).length, x = (t, i, a, o) => /* @__PURE__ */ Y(U, {
		label: i,
		value: r.springs?.[t] ?? o,
		min: 0,
		max: a,
		step: .05,
		format: (e) => e.toFixed(2),
		onBegin: () => e.begin("Hair and clothes swing"),
		onChange: (i) => e.updateShapeAt(n, { springs: {
			...r.springs,
			[t]: i
		} }),
		onEnd: () => e.commit()
	}), S = (t, r) => /* @__PURE__ */ Y(U, {
		label: r,
		value: g.pose[y][t],
		min: -180,
		max: 180,
		step: 1,
		format: (e) => `${Math.round(e)}°`,
		onBegin: () => e.begin(`Turn ${g.bones[y].name}`),
		onChange: (r) => {
			let i = g.pose.map((e, n) => n === y ? e.map((e, n) => n === t ? r : e) : e);
			e.updateShapeAt(n, { rig: {
				...g,
				pose: i
			} });
		},
		onEnd: () => e.commit()
	});
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Rig" }),
		/* @__PURE__ */ X("label", {
			className: "gs-m3d__check",
			children: [/* @__PURE__ */ Y("input", {
				type: "checkbox",
				checked: d,
				onChange: (e) => f(e.target.checked)
			}), " Show the bones"]
		}),
		/* @__PURE__ */ X("label", {
			className: "gs-m3d__field",
			children: [/* @__PURE__ */ Y("span", { children: "Bone" }), /* @__PURE__ */ Y("select", {
				value: y,
				onChange: (e) => c(Number(e.target.value)),
				children: g.bones.map((e, t) => /* @__PURE__ */ Y("option", {
					value: t,
					children: e.name
				}, t))
			})]
		}),
		S(0, "Turn forward"),
		S(1, "Turn round"),
		S(2, "Turn sideways"),
		/* @__PURE__ */ Y("button", {
			type: "button",
			className: `gs-m3d__btn${l ? " is-on" : ""}`,
			onClick: () => u((e) => !e),
			children: l ? "Reach on: drag in the view (click here to turn the view again)" : "Reach (drag its tip)"
		}),
		/* @__PURE__ */ X("div", {
			className: "gs-m3d__row",
			children: [/* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => v({
					...g,
					pose: g.pose.map(() => [
						0,
						0,
						0
					])
				}, "Rest pose"),
				children: "Rest pose"
			}), /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => v(void 0, "Remove the rig"),
				children: "Remove the rig"
			})]
		}),
		m.skeleton && /* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: `Its own ${g.bones.length} bones and weights, from its file.`
		}),
		/* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: "Keys keep the pose: set a key, pose it, move the time and set another."
		}),
		b > 0 && /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ X("label", {
			className: "gs-m3d__check",
			children: [
				/* @__PURE__ */ Y("input", {
					type: "checkbox",
					checked: !r.springs?.off,
					onChange: (t) => e.updateShapeAt(n, { springs: {
						...r.springs,
						off: !t.target.checked
					} }, "Hair and clothes swing")
				}),
				" ",
				`Hair and clothes swing (${b} bones)`
			]
		}), !r.springs?.off && /* @__PURE__ */ X(J, { children: [
			x("stiffness", "Springiness", 3, 1),
			x("gravity", "Weight", 3, 1),
			x("drag", "Calm", 1, .5),
			/* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: "They swing as it plays, the same every time, in videos and saved files too."
			})
		] })] }),
		/* @__PURE__ */ X("label", {
			className: "gs-m3d__check",
			children: [
				/* @__PURE__ */ Y("input", {
					type: "checkbox",
					checked: !r.life?.off,
					onChange: (t) => e.updateShapeAt(n, { life: {
						...r.life,
						off: !t.target.checked
					} }, "Life")
				}),
				" ",
				"Life: blinks, breath, glances"
			]
		}),
		!r.life?.off && /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ Y(U, {
			label: "How much life",
			value: r.life?.amount ?? 1,
			min: 0,
			max: 2,
			step: .05,
			format: (e) => e.toFixed(2),
			onBegin: () => e.begin("Life"),
			onChange: (t) => e.updateShapeAt(n, { life: {
				...r.life,
				amount: t
			} }),
			onEnd: () => e.commit()
		}), /* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: "As it plays and in Play game it blinks, breathes, glances about, shifts its weight, and the feeling on its face shows in how it stands. Talking, its mouth and head move with the words."
		})] }),
		/* @__PURE__ */ Y(o, { id: "m3dLife" }),
		/* @__PURE__ */ Y(o, { id: "m3dRig" })
	] });
}
//#endregion
//#region src/model3d/AnimationSection.tsx
var Wl = (e, t) => e.unit === "°" ? `${Math.round(t)}°` : e.unit === "%" ? `${Math.round(t * 100)}%` : `${t.toFixed(2).replace(/\.?0+$/, "")}×`;
function Gl({ editor: e, doc: t, at: n, shape: r, seconds: i, onPlay: a, onClip: s }) {
	let c = r.asset ? t.assets?.[r.asset] : void 0, l = Xr(() => c && r.asset ? O(r.asset, c.data) : null, [c, r.asset]), [u, d] = q(null), [f, p] = q({}), [h, g] = q(!1), [_, v] = q(!1), [y, b] = q(0), [x, S] = q(""), [w, E] = q(null), [D, k] = q(!1), A = K(null);
	if (!l) return null;
	let j = u ? xr(u) : void 0, M = !!r.rig && jn(r.rig, () => Ae(l)) !== r.rig, ee = r.take ? t.takes?.[r.take.id] : void 0, te = (t, o = {}) => {
		let s = xr(t);
		if (!s) return;
		let c = jn(r.rig, () => Ae(l)), u = Tr(r, c, s, {
			values: o.values ?? f,
			mirror: o.mirror ?? h,
			inPlace: o.inPlace ?? _,
			armsDown: o.armsDown ?? y
		}, i), { root: d, ...p } = c;
		e.updateShapeAt(n, {
			rig: {
				...p,
				pose: u[0].bones
			},
			keys: u,
			take: void 0
		}, `Animate: ${s.name}`), a();
	}, ne = (e) => {
		let t = Object.fromEntries(Object.entries(f).filter(([e]) => [
			"speed",
			"energy",
			"armSpace"
		].includes(e)));
		d(e), p(t), te(e, { values: t });
	}, N = () => {
		let t = r.rig, { root: i, ...a } = t ?? {};
		e.updateShapeAt(n, {
			keys: void 0,
			take: void 0,
			...t ? { rig: {
				...a,
				pose: t.pose.map(() => [
					0,
					0,
					0
				])
			} } : {}
		}, "Remove the animation"), d(null), E(null);
	}, P = async (t) => {
		if (t.length) {
			k(!0), E(null);
			try {
				let { bones: i, takes: o, vmd: c } = await m(t), u = jn(r.rig, () => Ae(l)), f = c ? Wn(c, r.size[1], [
					r.position[0],
					r.position[1] - r.size[1] / 2,
					r.position[2]
				]) : null;
				if (f && e.set("cameraTake", f, "A dance camera"), !o.length) {
					let t = c ? c.frames / 30 : 0;
					t >= 1 && (e.set("clip", Math.min(600, t), "Clip length"), s(Math.min(600, t))), a(), E("Its camera moves play with the clip.");
					return;
				}
				if (!ge(i)) {
					E("That animation is not for a person, so it cannot go on another figure: its bones are not named like arms, legs and a spine.");
					return;
				}
				let p = Se(o[0], i, u.bones);
				if (!p) {
					E("That figure has no arms, legs and spine to take this animation.");
					return;
				}
				u !== r.rig && e.updateShapeAt(n, { rig: u }, "Add a figure rig"), e.playTake(n, p.take), p.take.seconds >= 1 && s(Math.min(600, Math.round(p.take.seconds * 100) / 100)), d(null), a(), E(c ? f ? `${T} Its camera moves play too.` : T : o.length > 1 ? `Playing the first of ${o.length} animations in the file.` : null);
			} catch (e) {
				E(e instanceof Error ? e.message : "That animation could not be read.");
			} finally {
				k(!1);
			}
		}
	}, re = x.trim().toLowerCase(), F = nr.filter((e) => !re || e.name.toLowerCase().includes(re) || e.note.toLowerCase().includes(re));
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Animations" }),
		/* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: "Pick a move and it plays: the figure gets bones if it has none, and the move fills its keys over the clip."
		}),
		M && /* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: "Its rig is not a person's: a move gives it a figure rig in place of it."
		}),
		/* @__PURE__ */ X("div", {
			className: "gs-m3d__row",
			children: [/* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				disabled: D,
				onClick: () => A.current?.click(),
				children: D ? "Reading the animation…" : "Animation from a file…"
			}), /* @__PURE__ */ Y("input", {
				ref: A,
				type: "file",
				hidden: !0,
				multiple: !0,
				accept: C,
				onChange: (e) => {
					let t = Array.from(e.target.files ?? []);
					e.target.value = "", P(t);
				}
			})]
		}),
		/* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: "FBX from Mixamo, GLB, BVH motion capture or a MikuMikuDance VMD: it goes on this figure, whatever its bones are called."
		}),
		w && /* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: w
		}),
		ee && /* @__PURE__ */ X(J, { children: [
			/* @__PURE__ */ Y("p", {
				className: "gs-m3d__meta",
				children: `Playing ${ee.name}: ${Math.round(ee.seconds * 10) / 10} s, ${Ke(ee)} frames.`
			}),
			/* @__PURE__ */ Y(U, {
				label: "Take speed",
				value: r.take.speed ?? 1,
				min: .1,
				max: 4,
				step: .05,
				format: (e) => `${e.toFixed(2)}×`,
				onBegin: () => e.begin("Take speed"),
				onChange: (t) => e.updateShapeAt(n, { take: {
					...r.take,
					speed: t
				} }),
				onEnd: () => e.commit()
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__check",
				children: [
					/* @__PURE__ */ Y("input", {
						type: "checkbox",
						checked: r.take.inPlace === !0,
						onChange: (t) => e.updateShapeAt(n, { take: {
							...r.take,
							inPlace: t.target.checked
						} }, "Take in place")
					}),
					" ",
					"In place (no moving forward)"
				]
			})
		] }),
		/* @__PURE__ */ Y("input", {
			type: "search",
			className: "gs-m3d__search",
			placeholder: "Search the moves",
			value: x,
			onChange: (e) => S(e.target.value),
			"aria-label": "Search the moves"
		}),
		tr.map((e) => {
			let t = F.filter((t) => t.group === e);
			return t.length ? /* @__PURE__ */ X("div", {
				className: "gs-anim__group",
				children: [/* @__PURE__ */ Y("span", {
					className: "gs-m3d__meta",
					children: e
				}), /* @__PURE__ */ Y("div", {
					className: "gs-anim__moves",
					children: t.map((e) => /* @__PURE__ */ Y("button", {
						type: "button",
						className: `gs-m3d__btn${u === e.id ? " is-on" : ""}`,
						title: e.note,
						onClick: () => ne(e.id),
						children: e.name
					}, e.id))
				})]
			}, e) : null;
		}),
		j && /* @__PURE__ */ X(J, { children: [
			Dr(j).map((e) => /* @__PURE__ */ Y(U, {
				label: e.name,
				value: f[e.id] ?? e.value,
				min: e.min,
				max: e.max,
				step: e.step,
				format: (t) => Wl(e, t),
				onBegin: () => void 0,
				onChange: (t) => p((n) => ({
					...n,
					[e.id]: t
				})),
				onEnd: () => te(j.id)
			}, e.id)),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__check",
				children: [
					/* @__PURE__ */ Y("input", {
						type: "checkbox",
						checked: h,
						onChange: (e) => {
							g(e.target.checked), te(j.id, { mirror: e.target.checked });
						}
					}),
					" ",
					"Mirror (left for right)"
				]
			}),
			/* @__PURE__ */ Y(U, {
				label: "Arms down",
				value: y,
				min: 0,
				max: 90,
				step: 5,
				onBegin: () => void 0,
				onChange: b,
				onEnd: () => te(j.id)
			}),
			/* @__PURE__ */ Y(o, { id: "m3dArmsDown" }),
			j.travel ? /* @__PURE__ */ X("label", {
				className: "gs-m3d__check",
				children: [
					/* @__PURE__ */ Y("input", {
						type: "checkbox",
						checked: _,
						onChange: (e) => {
							v(e.target.checked), te(j.id, { inPlace: e.target.checked });
						}
					}),
					" ",
					"In place (no moving forward)"
				]
			}) : null,
			/* @__PURE__ */ Y("p", {
				className: "gs-m3d__meta",
				children: `Loops ${Yn(j, f.speed ?? 1, i).loops} times over the ${i} s clip.`
			})
		] }),
		t.cameraTake && /* @__PURE__ */ Y("button", {
			type: "button",
			className: "gs-m3d__btn",
			onClick: () => e.set("cameraTake", void 0, "No dance camera"),
			children: "Remove the dance camera"
		}),
		r.keys?.length || ee ? /* @__PURE__ */ Y("button", {
			type: "button",
			className: "gs-m3d__btn",
			onClick: N,
			children: "Remove the animation"
		}) : null,
		/* @__PURE__ */ Y(o, { id: "m3dAnimations" })
	] });
}
//#endregion
//#region src/model3d/PoseSection.tsx
var Kl = "gleamshelf:poses", ql = () => {
	try {
		let e = JSON.parse(localStorage.getItem(Kl) ?? "[]");
		return Array.isArray(e) ? e.filter((e) => typeof e?.name == "string" && Array.isArray(e.bones)) : [];
	} catch {
		return [];
	}
}, Jl = (e) => {
	try {
		localStorage.setItem(Kl, JSON.stringify(e));
	} catch {}
};
function Yl({ editor: e, doc: t, at: n, shape: r }) {
	let i = r.asset ? t.assets?.[r.asset] : void 0, a = Xr(() => i && r.asset ? O(r.asset, i.data) : null, [i, r.asset]), [s, c] = q(ql), [l, u] = q(""), [d, f] = q(null);
	if (!a) return null;
	let p = (t, i) => {
		let { root: o, ...s } = jn(r.rig, () => Ae(a));
		e.updateShapeAt(n, {
			rig: {
				...s,
				pose: t
			},
			keys: void 0,
			take: void 0
		}, `Pose: ${i}`), f(null);
	}, m = (e) => {
		let t = jn(r.rig, () => Ae(a)), n = nn(t, e);
		n ? p(n, e.name) : f("This model has no arms, legs and spine to pose.");
	}, h = () => {
		let e = r.rig?.pose;
		if (!e?.some((e) => e.some((e) => e))) {
			f("Pose the figure first: strike a pose below, or turn its bones, then keep it.");
			return;
		}
		let t = l.trim() || `My pose ${s.length + 1}`, n = [...s.filter((e) => e.name !== t), {
			name: t,
			bones: e.map((e) => [...e])
		}];
		c(n), Jl(n), u(""), f(null);
	}, g = (e) => {
		let t = jn(r.rig, () => Ae(a));
		e.bones.length === t.bones.length ? p(e.bones, e.name) : f("That pose was kept on a figure with different bones, so it does not fit this one.");
	}, _ = (e) => {
		let t = s.filter((t) => t.name !== e);
		c(t), Jl(t);
	};
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Poses" }),
		/* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: "A click holds the figure in a pose, with no animation playing."
		}),
		/* @__PURE__ */ Y("div", {
			className: "gs-anim__moves",
			role: "group",
			"aria-label": "Poses",
			children: Gn.map((e) => /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => m(e),
				children: e.name
			}, e.id))
		}),
		/* @__PURE__ */ X("div", {
			className: "gs-m3d__row",
			children: [/* @__PURE__ */ Y("input", {
				type: "text",
				value: l,
				maxLength: 40,
				placeholder: "Name this pose",
				"aria-label": "Name this pose",
				onChange: (e) => u(e.target.value)
			}), /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: h,
				children: "Keep this pose"
			})]
		}),
		s.length > 0 && /* @__PURE__ */ Y("div", {
			className: "gs-anim__moves",
			role: "group",
			"aria-label": "Kept poses",
			children: s.map((e) => /* @__PURE__ */ X("span", {
				className: "gs-m3d__chip",
				children: [/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => g(e),
					children: e.name
				}), /* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					"aria-label": `Forget ${e.name}`,
					title: "Forget this pose",
					onClick: () => _(e.name),
					children: "×"
				})]
			}, e.name))
		}),
		d && /* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: d
		}),
		/* @__PURE__ */ Y(o, { id: "m3dPoses" })
	] });
}
//#endregion
//#region src/model3d/PhysicsSection.tsx
function Xl({ editor: e, doc: t, picked: n, seconds: r }) {
	let [i, a] = q(.3), [s, c] = q(.5), l = n.filter((e) => t.shapes[e]);
	return l.length ? /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Drop and stack" }),
		/* @__PURE__ */ Y(U, {
			label: "Bounce",
			value: i,
			min: 0,
			max: .9,
			step: .05,
			format: (e) => `${Math.round(e * 100)}%`,
			onBegin: () => void 0,
			onChange: a,
			onEnd: () => void 0
		}),
		/* @__PURE__ */ Y(U, {
			label: "Grip",
			value: s,
			min: 0,
			max: 1,
			step: .05,
			format: (e) => `${Math.round(e * 100)}%`,
			onBegin: () => void 0,
			onChange: c,
			onEnd: () => void 0
		}),
		/* @__PURE__ */ Y("button", {
			type: "button",
			className: "gs-m3d__btn",
			onClick: () => {
				let n = cr(t, l, {
					seconds: r,
					bounce: i,
					grip: s
				});
				e.updateShapesAt([...n].map(([e, t]) => [[e], {
					keys: t,
					keyPath: void 0
				}]), l.length > 1 ? "Drop them" : "Drop it");
			},
			title: "Works out the fall and keeps it as keys",
			children: l.length > 1 ? `Drop these ${l.length}` : "Drop it"
		}),
		/* @__PURE__ */ Y(o, { id: "m3dDrop" })
	] }) : null;
}
var Zl = {
	confetti: "Confetti",
	sparkles: "Sparkles",
	smoke: "Smoke",
	flame: "Flame",
	pour: "Pour"
}, Ql = {
	confetti: 160,
	sparkles: 60,
	smoke: 120,
	flame: 140,
	pour: 200
}, $l = {
	confetti: 1.5,
	sparkles: 1,
	smoke: 1,
	flame: .6,
	pour: 1
}, eu = ["smoke", "pour"], tu = (e) => [
	0,
	2,
	4
].map((t) => (parseInt(e.slice(1 + t, 3 + t), 16) / 255) ** 2.2);
function nu({ editor: e, doc: t, picked: n, run: r }) {
	let [i, a] = q(2.5), [s, c] = q("#7a1424");
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Cloth" }),
		/* @__PURE__ */ Y(U, {
			label: "Size",
			value: i,
			min: .5,
			max: 8,
			step: .1,
			format: (e) => e.toFixed(1),
			onBegin: () => void 0,
			onChange: a,
			onEnd: () => void 0
		}),
		/* @__PURE__ */ X("label", {
			className: "gs-m3d__colour",
			children: [/* @__PURE__ */ Y("input", {
				type: "color",
				value: s,
				onChange: (e) => c(e.target.value)
			}), " Cloth colour"]
		}),
		/* @__PURE__ */ X("button", {
			type: "button",
			className: "gs-m3d__btn",
			onClick: () => void r("Draping the cloth…", async () => {
				let r = n === null ? void 0 : t.shapes[n], a = r ? jt(r) : null, o = a ? [(a.min[0] + a.max[0]) / 2, (a.min[2] + a.max[2]) / 2] : [t.camera.target[0], t.camera.target[2]];
				await new Promise((e) => setTimeout(e, 30));
				let c = fr(t, {
					size: i,
					centre: o,
					color: tu(s)
				}), l = c.min.map((e, t) => (e + c.max[t]) / 2), u = c.max.map((e, t) => Math.max(.01, e - c.min[t]));
				if (e.addModel(Pr(c, "Cloth"), {
					position: l,
					size: u,
					name: "Cloth"
				}) < 0) throw Error("The design holds no more models.");
			}),
			title: "Lets a square of cloth fall over the shapes and keeps it as a model",
			children: ["Drape a cloth", n === null ? "" : " over the picked shape"]
		}),
		/* @__PURE__ */ Y(o, { id: "m3dCloth" })
	] });
}
function ru({ editor: e, doc: t, picked: n }) {
	let r = t.effects ?? [], i = (t, n) => e.set("effects", t.length ? t : void 0, n), a = (e, t) => i(r.map((n, r) => r === e ? {
		...n,
		...t
	} : n)), s = (e) => {
		let a = n === null ? void 0 : t.shapes[n], o = a ? jt(a) : null, s = o ? [
			(o.min[0] + o.max[0]) / 2,
			o.max[1],
			(o.min[2] + o.max[2]) / 2
		] : [
			0,
			1,
			0
		];
		i([...r, {
			kind: e,
			at: s,
			amount: Ql[e],
			start: 0,
			spread: $l[e]
		}], `Add ${e}`);
	}, c = (t, n, i, o, s, c, l) => /* @__PURE__ */ Y(U, {
		label: i,
		value: r[t][n],
		min: o,
		max: s,
		step: c,
		format: l,
		onBegin: () => e.begin(i),
		onChange: (e) => a(t, { [n]: e }),
		onEnd: () => e.commit()
	});
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Effects" }),
		r.map((e, t) => /* @__PURE__ */ X("div", {
			className: "gs-m3d__card",
			role: "group",
			"aria-label": Zl[e.kind],
			children: [
				/* @__PURE__ */ X("div", {
					className: "gs-m3d__row",
					children: [/* @__PURE__ */ Y("strong", { children: Zl[e.kind] }), /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => i(r.filter((e, n) => n !== t), "Remove effect"),
						children: "Remove"
					})]
				}),
				c(t, "amount", "Amount", 10, 400, 10, (e) => `${Math.round(e)}`),
				c(t, "spread", "Spread", .2, 5, .1, (e) => e.toFixed(1)),
				c(t, "start", "Starts", 0, 1, .01, (e) => `${Math.round(e * 100)}% in`),
				eu.includes(e.kind) && /* @__PURE__ */ X("label", {
					className: "gs-m3d__colour",
					children: [
						/* @__PURE__ */ Y("input", {
							type: "color",
							value: e.color ?? (e.kind === "smoke" ? "#9a9a9a" : "#3fa9f5"),
							onChange: (e) => a(t, { color: e.target.value })
						}),
						" ",
						"Colour"
					]
				})
			]
		}, t)),
		r.length < 4 && /* @__PURE__ */ Y("div", {
			className: "gs-m3d__row",
			children: dt.map((e) => /* @__PURE__ */ X("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => s(e),
				children: ["Add ", Zl[e].toLowerCase()]
			}, e))
		}),
		/* @__PURE__ */ Y(o, { id: "m3dEffects" })
	] });
}
//#endregion
//#region src/model3d/HairSection.tsx
var iu = ["all", "top"], au = {
	all: "Everywhere",
	top: "On top"
}, ou = (e) => [
	0,
	2,
	4
].map((t) => (parseInt(e.slice(1 + t, 3 + t), 16) / 255) ** 2.2);
function su({ editor: e, doc: t, at: n, shape: r, run: i }) {
	let [a, s] = q(1500), [c, l] = q(.12), [u, d] = q(.3), [f, p] = q(0), [m, h] = q("all"), [g, _] = q("#3a2416"), v = r.asset ? t.assets?.[r.asset] : void 0;
	if (!v || !r.asset) return null;
	let y = () => void i("Growing hair…", async () => {
		let t = O(r.asset, v.data);
		el(e, n, r, t, ya(t, {
			count: a,
			length: c,
			droop: u,
			curl: f,
			where: m,
			color: ou(g)
		}), v.name, "Grow hair");
	}), b = (e, t, n, r, i, a, o) => /* @__PURE__ */ Y(U, {
		label: e,
		value: t,
		min: r,
		max: i,
		step: a,
		format: o,
		onBegin: () => void 0,
		onChange: n,
		onEnd: () => void 0
	}), x = (e) => `${Math.round(e * 100)}%`;
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Hair and fur" }),
		/* @__PURE__ */ Y(W, {
			label: "Grows",
			value: m,
			options: iu,
			labels: au,
			onChange: h
		}),
		b("Strands", a, s, 50, 5e3, 50, (e) => `${Math.round(e)}`),
		b("Length", c, l, .01, .6, .01, x),
		b("Hangs", u, d, 0, 1, .05, x),
		b("Curls", f, p, 0, 1, .05, x),
		/* @__PURE__ */ X("label", {
			className: "gs-m3d__colour",
			children: [/* @__PURE__ */ Y("input", {
				type: "color",
				value: g,
				onChange: (e) => _(e.target.value)
			}), " Hair colour"]
		}),
		/* @__PURE__ */ Y("button", {
			type: "button",
			className: "gs-m3d__btn",
			onClick: y,
			children: "Grow hair"
		}),
		/* @__PURE__ */ Y(o, { id: "m3dHair" })
	] });
}
//#endregion
//#region src/model3d/NodeEditor.tsx
var cu = 190, lu = 28, uu = 24, du = (e) => ({
	x: e.x + cu,
	y: e.y + lu / 2
}), fu = (e, t) => ({
	x: e.x,
	y: e.y + lu + t * uu + uu / 2
}), pu = (e, t) => {
	let n = Math.max(40, Math.abs(t.x - e.x) / 2);
	return `M${e.x},${e.y} C${e.x + n},${e.y} ${t.x - n},${t.y} ${t.x},${t.y}`;
};
function mu({ initial: e, shapes: t, done: n, onDone: r, onClose: i }) {
	let [a, s] = q(e), [c, l] = q(null), u = K(null), d = Ut(a.kind), f = (e) => {
		let t = u.current.getBoundingClientRect();
		return {
			x: e.clientX - t.left + u.current.scrollLeft,
			y: e.clientY - t.top + u.current.scrollTop
		};
	}, p = (e, t) => s((n) => ({
		...n,
		nodes: n.nodes.map((n) => n.id === e ? {
			...n,
			...t
		} : n)
	})), m = (e, t, n) => s((r) => ({
		...r,
		nodes: r.nodes.map((r) => r.id === e ? {
			...r,
			values: {
				...r.values,
				[t]: n
			}
		} : r)
	})), h = (e) => (t) => {
		t.preventDefault();
		let n = f(t), r = {
			x: e.x,
			y: e.y
		}, i = (t) => {
			let i = f(t);
			p(e.id, {
				x: Math.max(0, r.x + i.x - n.x),
				y: Math.max(0, r.y + i.y - n.y)
			});
		}, a = () => {
			window.removeEventListener("pointermove", i), window.removeEventListener("pointerup", a);
		};
		window.addEventListener("pointermove", i), window.addEventListener("pointerup", a);
	}, g = (e) => (t) => {
		t.preventDefault(), t.stopPropagation(), l({
			from: e.id,
			...f(t)
		});
		let n = (e) => l((t) => t && {
			...t,
			...f(e)
		}), r = (t) => {
			window.removeEventListener("pointermove", n), window.removeEventListener("pointerup", r), l(null);
			let i = document.elementFromPoint(t.clientX, t.clientY), a = i?.dataset.node, o = i?.dataset.input;
			a && o && s((t) => ct(t, e.id, a, o) ? {
				...t,
				links: [...t.links.filter((e) => e.to !== a || e.input !== o), {
					from: e.id,
					to: a,
					input: o
				}]
			} : t);
		};
		window.addEventListener("pointermove", n), window.addEventListener("pointerup", r);
	}, _ = (e) => {
		let t = u.current;
		s((n) => {
			let r = n.nodes.length % 6 * 28;
			return {
				...n,
				nodes: [...n.nodes, et(n.kind, e, t.scrollLeft + 30 + r, t.scrollTop + 200 + r)]
			};
		});
	}, v = Math.max(420, ...a.nodes.map((e) => e.y + 260)), y = Math.max(760, ...a.nodes.map((e) => e.x + cu + 40));
	return /* @__PURE__ */ X(uo, {
		title: a.kind === "geometry" ? "Geometry nodes" : "Material nodes",
		onClose: i,
		children: [
			/* @__PURE__ */ X("div", {
				className: "gs-nodes__bar",
				children: [/* @__PURE__ */ X("select", {
					value: "",
					onChange: (e) => e.target.value && _(e.target.value),
					disabled: a.nodes.length >= 24,
					"aria-label": "Add a box",
					children: [/* @__PURE__ */ Y("option", {
						value: "",
						children: "Add a box…"
					}), Object.entries(d).filter(([e]) => e !== "output").map(([e, t]) => /* @__PURE__ */ Y("option", {
						value: e,
						children: t.label
					}, e))]
				}), /* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn is-on",
					onClick: () => r(a),
					children: n
				})]
			}),
			/* @__PURE__ */ Y("div", {
				className: "gs-nodes",
				ref: u,
				children: /* @__PURE__ */ X("div", {
					className: "gs-nodes__sheet",
					style: {
						width: y,
						height: v
					},
					children: [/* @__PURE__ */ X("svg", {
						className: "gs-nodes__wires",
						width: y,
						height: v,
						"aria-hidden": "true",
						children: [a.links.map((e, t) => {
							let n = a.nodes.find((t) => t.id === e.from), r = a.nodes.find((t) => t.id === e.to), i = d[r.type].inputs.findIndex((t) => t.key === e.input);
							return /* @__PURE__ */ Y("path", { d: pu(du(n), fu(r, i)) }, t);
						}), c && /* @__PURE__ */ Y("path", {
							className: "is-drawing",
							d: pu(du(a.nodes.find((e) => e.id === c.from)), c)
						})]
					}), a.nodes.map((e) => {
						let n = d[e.type];
						return /* @__PURE__ */ X("div", {
							className: "gs-nodes__box",
							style: {
								left: e.x,
								top: e.y,
								width: cu
							},
							children: [
								/* @__PURE__ */ X("div", {
									className: "gs-nodes__head",
									onPointerDown: h(e),
									children: [
										/* @__PURE__ */ Y("span", { children: n.label }),
										e.type !== "output" && /* @__PURE__ */ Y("button", {
											type: "button",
											"aria-label": `Remove ${n.label}`,
											onPointerDown: (e) => e.stopPropagation(),
											onClick: () => s((t) => ({
												...t,
												nodes: t.nodes.filter((t) => t.id !== e.id),
												links: t.links.filter((t) => t.from !== e.id && t.to !== e.id)
											})),
											children: "×"
										}),
										n.output && /* @__PURE__ */ Y("span", {
											className: `gs-nodes__dot is-out is-${n.output}`,
											onPointerDown: g(e),
											title: `Drag to wire (${n.output})`
										})
									]
								}),
								n.inputs.map((t) => /* @__PURE__ */ X("div", {
									className: "gs-nodes__row",
									children: [/* @__PURE__ */ Y("span", {
										className: `gs-nodes__dot is-in is-${t.type}`,
										"data-node": e.id,
										"data-input": t.key,
										title: "Click to unwire",
										onClick: () => s((n) => ({
											...n,
											links: n.links.filter((n) => n.to !== e.id || n.input !== t.key)
										}))
									}), t.label]
								}, t.key)),
								n.params.map((n) => /* @__PURE__ */ X("label", {
									className: "gs-nodes__param",
									children: [/* @__PURE__ */ Y("span", { children: n.label }), n.kind === "number" ? /* @__PURE__ */ Y("input", {
										type: "number",
										min: n.min,
										max: n.max,
										step: n.step,
										value: Number(e.values[n.key]),
										onChange: (t) => {
											let r = Number(t.target.value);
											Number.isFinite(r) && m(e.id, n.key, Math.min(n.max, Math.max(n.min, r)));
										}
									}) : n.kind === "colour" ? /* @__PURE__ */ Y("input", {
										type: "color",
										value: String(e.values[n.key]),
										onChange: (t) => m(e.id, n.key, t.target.value)
									}) : n.kind === "axis" ? /* @__PURE__ */ X("select", {
										value: String(e.values[n.key]),
										onChange: (t) => m(e.id, n.key, t.target.value),
										children: [
											/* @__PURE__ */ Y("option", {
												value: "x",
												children: "Across"
											}),
											/* @__PURE__ */ Y("option", {
												value: "y",
												children: "Up"
											}),
											/* @__PURE__ */ Y("option", {
												value: "z",
												children: "Forward"
											})
										]
									}) : /* @__PURE__ */ X("select", {
										value: String(e.values[n.key]),
										onChange: (t) => m(e.id, n.key, t.target.value),
										children: [/* @__PURE__ */ Y("option", {
											value: "",
											children: "Pick a shape"
										}), t.map((e) => /* @__PURE__ */ Y("option", {
											value: e.id,
											children: e.name
										}, e.id))]
									})]
								}, n.key))
							]
						}, e.id);
					})]
				})
			}),
			/* @__PURE__ */ Y(o, { id: "m3dNodes" })
		]
	});
}
function hu({ editor: e, doc: t, at: n, shape: r, run: i }) {
	let [a, s] = q(null);
	if (n.length !== 1 || r.kind === "group") return null;
	let c = t.shapes.filter((e) => e.kind !== "group" && !e.nodes).map((e) => ({
		id: e.id,
		name: e.name
	}));
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Nodes" }),
		/* @__PURE__ */ X("div", {
			className: "gs-m3d__row",
			children: [r.nodes ? /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => s(r.nodes),
				children: "Change the nodes"
			}) : /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => s(Yt("geometry", r.id)),
				children: "Copies with nodes"
			}), r.kind === "mesh" && /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => s(Yt("material")),
				children: "Colour with nodes"
			})]
		}),
		a && /* @__PURE__ */ Y(mu, {
			initial: a,
			shapes: c,
			done: a.kind === "geometry" ? r.nodes ? "Make again" : "Make the copies" : "Colour the model",
			onDone: a.kind === "geometry" ? (a) => void i("Making the copies…", async () => {
				let i = Et(a), o = i && t.shapes.find((e) => e.id === i.shape);
				if (!i || !i.places.length) throw Error("Wire some places into the Copies of box.");
				if (!o) throw Error("Pick the shape to copy in the Copies of box.");
				let c = await Ar({
					...t,
					shapes: [{
						...o,
						hidden: !1,
						keys: void 0
					}]
				}, { cells: 40 }), l = gt(c, o.position, i.places), u = l.min.map((e, t) => (e + l.max[t]) / 2), d = l.max.map((e, t) => Math.max(.01, e - l.min[t])), f = Pr(l, `Copies of ${o.name}`);
				if (r.nodes) {
					let t = `m${Date.now().toString(36)}`;
					e.begin("Make again"), e.set("assets", {
						...e.document.assets ?? {},
						[t]: f
					}), e.updateShapeAt(n, {
						asset: t,
						position: u,
						size: d,
						rotation: [
							0,
							0,
							0
						],
						nodes: a
					}), e.commit();
				} else {
					if (e.begin("Copies with nodes"), e.addModel(f, {
						position: u,
						size: d,
						name: `Copies of ${o.name}`,
						nodes: a
					}) < 0) throw e.commit(), Error("The design holds no more models.");
					let n = t.shapes.findIndex((e) => e.id === o.id);
					n >= 0 && e.updateShapeAt([n], { hidden: !0 }), e.commit();
				}
				s(null);
			}) : (a) => void i("Colouring…", async () => {
				let i = r.asset ? t.assets?.[r.asset] : void 0;
				if (!i) return;
				let o = O(r.asset, i.data);
				el(e, n, r, o, Nt(o, a), i.name, "Colour with nodes"), s(null);
			}),
			onClose: () => s(null)
		}),
		/* @__PURE__ */ Y(o, { id: "m3dNodes" })
	] });
}
//#endregion
//#region src/model3d/LabelSection.tsx
var gu = 1024;
async function _u(e) {
	let t = await createImageBitmap(e), n = Math.min(1, gu / Math.max(t.width, t.height)), r = document.createElement("canvas");
	return r.width = Math.max(1, Math.round(t.width * n)), r.height = Math.max(1, Math.round(t.height * n)), r.getContext("2d").drawImage(t, 0, 0, r.width, r.height), t.close(), r.toDataURL("image/png");
}
function vu({ editor: e, doc: t, at: n, shape: r }) {
	let i = K(null), a = r.label, s = (t, r) => a && e.updateShapeAt(n, { label: {
		...a,
		...t
	} }, r), c = r.kind === "cylinder" || r.kind === "capsule" || r.kind === "revolve", l = Pt(t).some((e) => e.shape.id === r.id), u = (t, n, r, i) => a && /* @__PURE__ */ Y(U, {
		label: n,
		value: a[t],
		min: r,
		max: i,
		step: .01,
		format: (e) => `${Math.round(e * 100)}%`,
		onBegin: () => e.begin(n),
		onChange: (e) => s({ [t]: e }),
		onEnd: () => e.commit()
	});
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Label" }),
		a ? /* @__PURE__ */ X(J, { children: [
			/* @__PURE__ */ Y("img", {
				className: "gs-label__thumb",
				src: a.picture,
				alt: "The label's picture"
			}),
			/* @__PURE__ */ Y(W, {
				label: "On",
				value: a.side,
				options: yt,
				labels: rt,
				onChange: (e) => s({ side: e }, "Label side")
			}),
			u("width", "Size", .05, 1),
			u("x", "Across", -.5, .5),
			u("y", "Up", -.5, .5),
			!l && /* @__PURE__ */ X("p", {
				className: "gs-m3d__note",
				children: [
					"A design shows ",
					4,
					" labels at most; this one is past them."
				]
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__row",
				children: [/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => i.current?.click(),
					children: "Other picture…"
				}), /* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => e.updateShapeAt(n, { label: void 0 }, "Remove label"),
					children: "Remove"
				})]
			})
		] }) : /* @__PURE__ */ Y("button", {
			type: "button",
			className: "gs-m3d__btn",
			onClick: () => i.current?.click(),
			children: "Add a picture…"
		}),
		/* @__PURE__ */ Y("input", {
			ref: i,
			type: "file",
			accept: "image/png,image/jpeg,image/webp",
			hidden: !0,
			onChange: (t) => {
				let r = t.target.files?.[0];
				t.target.value = "", r && _u(r).then((t) => e.updateShapeAt(n, { label: a ? {
					...a,
					picture: t
				} : {
					picture: t,
					side: c ? "around" : "front",
					width: c ? .4 : .6,
					x: 0,
					y: 0
				} }, "Label"));
			}
		}),
		/* @__PURE__ */ Y(o, { id: "m3dLabel" })
	] });
}
//#endregion
//#region src/model3d/ExportDialog.tsx
var yu = [
	20,
	50,
	100,
	150,
	200,
	300,
	500,
	1e3
], bu = {
	...Nr,
	usdz: "USDZ (iPhone and iPad: see it in a room)",
	rigged: "GLB with its bones and what it plays, for Blender, Unity and Unreal",
	vrm: "VRM: a character for VRoid Hub, VRChat tools and VTuber apps"
}, xu = {
	rigged: "Bones",
	vrm: "VRM"
};
function Su({ onExport: e, onClose: t, rigged: n }) {
	let [r, i] = q("glb"), [a, s] = q(n?.name ?? "Character"), [c, l] = q(""), u = Object.keys(bu).filter((e) => e === "rigged" ? !!n : e !== "vrm" || !!n?.person), d = r !== "rigged" && r !== "vrm", [f, p] = q("good"), [m, h] = q(100);
	return /* @__PURE__ */ X(uo, {
		title: "Save as a 3D model",
		onClose: t,
		children: [
			/* @__PURE__ */ Y(o, { id: "m3dExport" }),
			/* @__PURE__ */ Y("div", {
				className: "gs-m3d__segments",
				role: "group",
				"aria-label": "Format",
				children: u.map((e) => /* @__PURE__ */ Y("button", {
					type: "button",
					className: r === e ? "is-on" : "",
					onClick: () => i(e),
					title: bu[e],
					children: xu[e] ?? e.toUpperCase()
				}, e))
			}),
			/* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: bu[r]
			}),
			!d && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: `Saves ${n.name} alone, at its own size.`
			}),
			r === "vrm" && /* @__PURE__ */ X(J, { children: [
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: "Character's name" }), /* @__PURE__ */ Y("input", {
						value: a,
						onChange: (e) => s(e.target.value)
					})]
				}),
				/* @__PURE__ */ X("label", {
					className: "gs-m3d__field",
					children: [/* @__PURE__ */ Y("span", { children: "Made by" }), /* @__PURE__ */ Y("input", {
						value: c,
						onChange: (e) => l(e.target.value),
						placeholder: "Shown wherever it is used"
					})]
				}),
				/* @__PURE__ */ Y("p", {
					className: "gs-m3d__note",
					children: "It says only its author may use it and it may not be shared on. A VRM editor can change that."
				})
			] }),
			d && /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Detail" }), /* @__PURE__ */ X("select", {
					value: f,
					onChange: (e) => p(e.target.value),
					children: [
						/* @__PURE__ */ Y("option", {
							value: "draft",
							children: "Draft (quick)"
						}),
						/* @__PURE__ */ Y("option", {
							value: "good",
							children: "Good"
						}),
						/* @__PURE__ */ Y("option", {
							value: "fine",
							children: "Fine (slower, bigger file)"
						})
					]
				})]
			}), /* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Real height" }), /* @__PURE__ */ Y("select", {
					value: m,
					onChange: (e) => h(Number(e.target.value)),
					children: yu.map((e) => /* @__PURE__ */ Y("option", {
						value: e,
						children: e >= 1e3 ? `${e / 1e3} m` : e >= 100 ? `${e / 10} cm` : `${e} mm`
					}, e))
				})]
			})] }),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ Y("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: t,
						children: "Cancel"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						onClick: () => e(r, f, m, {
							name: a,
							author: c
						}),
						children: r === "rigged" ? "Save GLB" : `Save ${r.toUpperCase()}`
					})
				]
			})
		]
	});
}
//#endregion
//#region src/model3d/finish.ts
async function Cu(e, t) {
	if (ne(t) && e instanceof Blob) return e;
	let n = e instanceof Blob ? await createImageBitmap(e) : e, r = document.createElement("canvas");
	r.width = n.width, r.height = n.height;
	let i = r.getContext("2d", { willReadFrequently: !0 });
	if (i.drawImage(n, 0, 0), n instanceof ImageBitmap && n.close(), !ne(t)) {
		let e = i.getImageData(0, 0, r.width, r.height);
		Ne(e.data, r.width, r.height, t), i.putImageData(e, 0, 0);
	}
	return new Promise((e, t) => r.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be made.")), "image/png"));
}
//#endregion
//#region src/model3d/RenderDialog.tsx
var wu = [
	720,
	1080,
	1440,
	2048,
	2880,
	4096
], Tu = {
	draft: 48,
	good: 192,
	best: 640,
	print: 2048
};
function Eu({ design: e, aspect: t, title: n, onClose: r }) {
	let [i, a] = q(1080), [s, c] = q("good"), [l, u] = q(null), [d, f] = q(null), [p, m] = q(!0), [h, _] = q(!0), v = K(null), y = K(null);
	G(() => () => y.current?.dispose(), []);
	let b = async () => {
		y.current?.dispose(), f(null);
		let [n, r] = t >= 1 ? [i, Math.round(i / t)] : [Math.round(i * t), i];
		try {
			u(0);
			let t = await g.create(e, n, r, void 0, h);
			t.denoise = p, y.current = t, t.canvas.className = "gs-render__canvas", v.current?.replaceChildren(t.canvas), u(0), await t.run(Tu[s], u);
		} catch (e) {
			f(e instanceof Error ? `The render did not work on this computer: ${e.message}` : "The render did not work on this computer.");
		}
	}, x = async () => {
		if (!y.current) return;
		let t = await Cu(y.current.canvas, e.compose), r = document.createElement("a");
		r.href = URL.createObjectURL(t), r.download = `${n.replace(/[^\w -]+/g, "").trim() || "3d-design"}-render.png`, r.click(), setTimeout(() => URL.revokeObjectURL(r.href), 1e3);
	}, S = l !== null && l < 1;
	return /* @__PURE__ */ X(uo, {
		title: "Photo-real render",
		onClose: r,
		children: [
			/* @__PURE__ */ Y(o, { id: "m3dRender" }),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Size" }), /* @__PURE__ */ Y("select", {
					value: i,
					disabled: S,
					onChange: (e) => a(Number(e.target.value)),
					children: wu.map((e) => /* @__PURE__ */ X("option", {
						value: e,
						children: [e, " px"]
					}, e))
				})]
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Quality" }), /* @__PURE__ */ X("select", {
					value: s,
					disabled: S,
					onChange: (e) => c(e.target.value),
					children: [
						/* @__PURE__ */ Y("option", {
							value: "draft",
							children: "Draft (seconds)"
						}),
						/* @__PURE__ */ Y("option", {
							value: "good",
							children: "Good"
						}),
						/* @__PURE__ */ Y("option", {
							value: "best",
							children: "Best (slower, smoother)"
						}),
						/* @__PURE__ */ Y("option", {
							value: "print",
							children: "Print (slowest; posters and close looks)"
						})
					]
				})]
			}),
			e.background.transparent && /* @__PURE__ */ X("label", {
				className: "gs-m3d__check",
				children: [/* @__PURE__ */ Y("input", {
					type: "checkbox",
					checked: h,
					disabled: S,
					onChange: (e) => _(e.target.checked)
				}), " Keep the background clear (the ground catches only the shadow)"]
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__check",
				children: [
					/* @__PURE__ */ Y("input", {
						type: "checkbox",
						checked: p,
						onChange: (e) => {
							m(e.target.checked), y.current && (y.current.denoise = e.target.checked, y.current.redraw());
						}
					}),
					" ",
					"Clean up the grain (denoise)"
				]
			}),
			/* @__PURE__ */ Y("div", {
				className: "gs-render",
				ref: v
			}),
			l !== null && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: S ? `Rendering… ${Math.round(l * 100)}%` : "Done."
			}),
			d && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: d
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ Y("span", { className: "gs-m3d__spacer" }),
					S ? /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => (y.current?.stop(), u(1)),
						children: "Stop here"
					}) : /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => void b(),
						children: l === null ? "Render" : "Render again"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: l === null,
						onClick: () => void x(),
						children: "Save PNG"
					})
				]
			})
		]
	});
}
//#endregion
//#region src/model3d/CompositorSection.tsx
var Du = [
	{
		key: "exposure",
		label: "Exposure",
		min: -2,
		max: 2,
		step: .05,
		format: (e) => `${e > 0 ? "+" : ""}${e.toFixed(2)} stops`
	},
	{
		key: "warmth",
		label: "Warmth",
		min: -1,
		max: 1,
		step: .05,
		format: (e) => `${Math.round(e * 100)}`
	},
	{
		key: "contrast",
		label: "Contrast",
		min: -1,
		max: 1,
		step: .05,
		format: (e) => `${Math.round(e * 100)}`
	},
	{
		key: "saturation",
		label: "Colour",
		min: 0,
		max: 2,
		step: .05,
		format: (e) => `${Math.round(e * 100)}%`
	},
	{
		key: "glare",
		label: "Glare",
		min: 0,
		max: 1,
		step: .05,
		format: (e) => `${Math.round(e * 100)}%`
	},
	{
		key: "fringe",
		label: "Lens fringe",
		min: 0,
		max: 1,
		step: .05,
		format: (e) => `${Math.round(e * 100)}%`
	},
	{
		key: "vignette",
		label: "Vignette",
		min: 0,
		max: 1,
		step: .05,
		format: (e) => `${Math.round(e * 100)}%`
	},
	{
		key: "sharpen",
		label: "Sharpen",
		min: 0,
		max: 1,
		step: .05,
		format: (e) => `${Math.round(e * 100)}%`
	},
	{
		key: "grain",
		label: "Film grain",
		min: 0,
		max: 1,
		step: .05,
		format: (e) => `${Math.round(e * 100)}%`
	}
];
function Ou({ editor: e, doc: t, viewRef: n }) {
	let [r, i] = q(null), a = t.compose ?? We, s = (e) => {
		let t = n.current;
		if (!t) return;
		let r = Math.min(1, 360 / Math.max(t.canvas.width, 1)), a = document.createElement("canvas");
		a.width = Math.max(1, Math.round(t.canvas.width * r)), a.height = Math.max(1, Math.round(t.canvas.height * r));
		let o = a.getContext("2d", { willReadFrequently: !0 });
		o.drawImage(t.canvas, 0, 0, a.width, a.height);
		let s = o.getImageData(0, 0, a.width, a.height);
		Ne(s.data, a.width, a.height, e), o.putImageData(s, 0, 0), i(a.toDataURL("image/png"));
	}, c = (t) => {
		let n = {
			...a,
			...t
		};
		e.set("compose", n), r && s(n);
	};
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Compositor" }),
		Du.map((t) => /* @__PURE__ */ Y(U, {
			label: t.label,
			value: a[t.key],
			min: t.min,
			max: t.max,
			step: t.step,
			format: t.format,
			onBegin: () => e.begin(t.label),
			onChange: (e) => c({ [t.key]: e }),
			onEnd: () => e.commit()
		}, t.key)),
		/* @__PURE__ */ X("div", {
			className: "gs-m3d__row",
			children: [/* @__PURE__ */ Y("button", {
				type: "button",
				className: `gs-m3d__btn${r ? " is-on" : ""}`,
				onClick: () => r ? i(null) : s(a),
				children: r ? "Hide the preview" : "Preview"
			}), /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: () => e.set("compose", void 0, "Compositor off"),
				children: "Reset"
			})]
		}),
		r && /* @__PURE__ */ Y("img", {
			className: "gs-m3d__composed",
			src: r,
			alt: "The view as it will be finished"
		}),
		/* @__PURE__ */ Y(o, { id: "m3dCompose" })
	] });
}
//#endregion
//#region src/model3d/SequenceDialog.tsx
var ku = {
	"16:9": 16 / 9,
	"1:1": 1,
	"9:16": 9 / 16,
	"4:5": 4 / 5
}, Au = {
	fade: .5,
	strips: [{
		kind: "title",
		text: "New arrival",
		seconds: 2,
		background: "#111111",
		color: "#ffffff"
	}, {
		kind: "clip",
		camera: "turntable",
		seconds: 5,
		from: 0,
		to: 1
	}]
}, ju = {
	clip: "Clip",
	title: "Title",
	picture: "Picture"
};
async function Mu(e) {
	let t = await createImageBitmap(e), n = Math.min(1, 1920 / Math.max(t.width, t.height)), r = document.createElement("canvas");
	return r.width = Math.round(t.width * n), r.height = Math.round(t.height * n), r.getContext("2d").drawImage(t, 0, 0, r.width, r.height), t.close(), r.toDataURL("image/jpeg", .88);
}
function Nu({ editor: e, title: t, onClose: n, run: r, setBusy: i }) {
	let [a, s] = q(e.document.sequence ?? Au), [c, l] = q("16:9"), [u, d] = q(1080), [f, p] = q(null), m = (t) => {
		s(t), e.set("sequence", t, "Video strips");
	}, h = (e, t) => m({
		...a,
		strips: a.strips.map((n, r) => r === e ? {
			...n,
			...t
		} : n)
	}), g = (e, t) => {
		let n = [...a.strips], [r] = n.splice(e, 1);
		n.splice(Math.min(n.length, Math.max(0, e + t)), 0, r), m({
			...a,
			strips: n
		});
	}, _ = (e) => m({
		...a,
		strips: [...a.strips, e]
	}), v = Je(a);
	return /* @__PURE__ */ X(uo, {
		title: "Video editor",
		onClose: n,
		children: [
			/* @__PURE__ */ Y("div", {
				className: "gs-seq__bar",
				"aria-label": "The strips in time",
				children: a.strips.map((e, t) => /* @__PURE__ */ Y("span", {
					className: `gs-seq__block is-${e.kind}`,
					style: { flexGrow: e.seconds },
					title: `${ju[e.kind]}, ${e.seconds} s`,
					children: ju[e.kind]
				}, t))
			}),
			/* @__PURE__ */ X("p", {
				className: "gs-m3d__meta",
				children: [v.toFixed(1), " seconds in all"]
			}),
			a.strips.map((e, t) => /* @__PURE__ */ X("div", {
				className: "gs-m3d__card",
				role: "group",
				"aria-label": `${ju[e.kind]} ${t + 1}`,
				children: [
					/* @__PURE__ */ X("div", {
						className: "gs-m3d__row",
						children: [
							/* @__PURE__ */ X("strong", { children: [
								t + 1,
								". ",
								ju[e.kind]
							] }),
							/* @__PURE__ */ Y("span", { className: "gs-m3d__spacer" }),
							/* @__PURE__ */ Y("button", {
								type: "button",
								className: "gs-m3d__btn",
								disabled: t === 0,
								onClick: () => g(t, -1),
								"aria-label": "Earlier",
								children: "↑"
							}),
							/* @__PURE__ */ Y("button", {
								type: "button",
								className: "gs-m3d__btn",
								disabled: t === a.strips.length - 1,
								onClick: () => g(t, 1),
								"aria-label": "Later",
								children: "↓"
							}),
							/* @__PURE__ */ Y("button", {
								type: "button",
								className: "gs-m3d__btn",
								onClick: () => m({
									...a,
									strips: a.strips.filter((e, n) => n !== t)
								}),
								children: "Remove"
							})
						]
					}),
					/* @__PURE__ */ Y(U, {
						label: "Length",
						value: e.seconds,
						min: .5,
						max: 30,
						step: .5,
						format: (e) => `${e} s`,
						onBegin: () => void 0,
						onChange: (e) => h(t, { seconds: e }),
						onEnd: () => void 0
					}),
					e.kind === "clip" && /* @__PURE__ */ X(J, { children: [
						/* @__PURE__ */ X("label", {
							className: "gs-m3d__field",
							children: [/* @__PURE__ */ Y("span", { children: "Camera" }), /* @__PURE__ */ Y("select", {
								value: e.camera,
								onChange: (e) => h(t, { camera: e.target.value }),
								children: Object.keys(w).map((e) => /* @__PURE__ */ Y("option", {
									value: e,
									children: w[e]
								}, e))
							})]
						}),
						/* @__PURE__ */ Y(U, {
							label: "From",
							value: e.from,
							min: 0,
							max: 1,
							step: .01,
							format: (e) => `${Math.round(e * 100)}% of the clip`,
							onBegin: () => void 0,
							onChange: (n) => h(t, {
								from: n,
								to: Math.max(n, e.to)
							}),
							onEnd: () => void 0
						}),
						/* @__PURE__ */ Y(U, {
							label: "To",
							value: e.to,
							min: 0,
							max: 1,
							step: .01,
							format: (e) => `${Math.round(e * 100)}% of the clip`,
							onBegin: () => void 0,
							onChange: (n) => h(t, {
								to: n,
								from: Math.min(n, e.from)
							}),
							onEnd: () => void 0
						})
					] }),
					e.kind === "title" && /* @__PURE__ */ X(J, { children: [/* @__PURE__ */ X("label", {
						className: "gs-m3d__field gs-m3d__field--top",
						children: [/* @__PURE__ */ Y("span", { children: "Words" }), /* @__PURE__ */ Y("textarea", {
							rows: 2,
							maxLength: 200,
							value: e.text,
							onChange: (e) => h(t, { text: e.target.value })
						})]
					}), /* @__PURE__ */ X("div", {
						className: "gs-m3d__row",
						children: [/* @__PURE__ */ X("label", {
							className: "gs-m3d__colour",
							children: [/* @__PURE__ */ Y("input", {
								type: "color",
								value: e.background,
								onChange: (e) => h(t, { background: e.target.value })
							}), " Background"]
						}), /* @__PURE__ */ X("label", {
							className: "gs-m3d__colour",
							children: [/* @__PURE__ */ Y("input", {
								type: "color",
								value: e.color,
								onChange: (e) => h(t, { color: e.target.value })
							}), " Words"]
						})]
					})] }),
					e.kind === "picture" && /* @__PURE__ */ Y("img", {
						className: "gs-seq__thumb",
						src: e.picture,
						alt: ""
					})
				]
			}, t)),
			a.strips.length < 16 && /* @__PURE__ */ X("div", {
				className: "gs-m3d__row",
				children: [
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => _({
							kind: "clip",
							camera: "still",
							seconds: 4,
							from: 0,
							to: 1
						}),
						children: "Add a clip"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => _({
							kind: "title",
							text: "Your words",
							seconds: 2,
							background: "#111111",
							color: "#ffffff"
						}),
						children: "Add a title"
					}),
					/* @__PURE__ */ X("label", {
						className: "gs-m3d__btn",
						children: ["Add a picture", /* @__PURE__ */ Y("input", {
							type: "file",
							accept: "image/png,image/jpeg,image/webp",
							hidden: !0,
							onChange: async (e) => {
								let t = e.target.files?.[0];
								e.target.value = "", t && _({
									kind: "picture",
									picture: await Mu(t),
									seconds: 3
								});
							}
						})]
					})
				]
			}),
			/* @__PURE__ */ Y(U, {
				label: "Fade between",
				value: a.fade,
				min: 0,
				max: 1.5,
				step: .1,
				format: (e) => e ? `${e.toFixed(1)} s` : "Cut",
				onBegin: () => void 0,
				onChange: (e) => m({
					...a,
					fade: e
				}),
				onEnd: () => void 0
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Music" }), /* @__PURE__ */ Y("input", {
					type: "file",
					accept: "audio/*",
					onChange: (e) => p(e.target.files?.[0] ?? null)
				})]
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Shape" }), /* @__PURE__ */ X("select", {
					value: c,
					onChange: (e) => l(e.target.value),
					children: [
						/* @__PURE__ */ Y("option", {
							value: "16:9",
							children: "16:9 (wide)"
						}),
						/* @__PURE__ */ Y("option", {
							value: "1:1",
							children: "1:1 (square)"
						}),
						/* @__PURE__ */ Y("option", {
							value: "9:16",
							children: "9:16 (stories, reels)"
						}),
						/* @__PURE__ */ Y("option", {
							value: "4:5",
							children: "4:5 (feed)"
						})
					]
				})]
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__field",
				children: [/* @__PURE__ */ Y("span", { children: "Size" }), /* @__PURE__ */ X("select", {
					value: u,
					onChange: (e) => d(Number(e.target.value)),
					children: [/* @__PURE__ */ Y("option", {
						value: 720,
						children: "720 px"
					}), /* @__PURE__ */ Y("option", {
						value: 1080,
						children: "1080 px"
					})]
				})]
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ Y("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: n,
						children: "Close"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: !a.strips.length,
						onClick: () => {
							n(), r("Making the video…", async () => {
								let n = f ? await new AudioContext().decodeAudioData(await f.arrayBuffer()) : null, r = await x(e.document, a, {
									size: u,
									aspect: ku[c],
									music: n,
									onProgress: (e) => i(`Making the video… ${Math.round(e * 100)}%`)
								}), o = document.createElement("a");
								o.href = URL.createObjectURL(r.blob), o.download = `${t.replace(/[^\w -]+/g, "").trim() || "3d-design"}-edit.${r.extension}`, o.click(), setTimeout(() => URL.revokeObjectURL(o.href), 1e3);
							});
						},
						children: "Make the video"
					})
				]
			}),
			/* @__PURE__ */ Y(o, { id: "m3dSequence" })
		]
	});
}
//#endregion
//#region src/model3d/ScriptDialog.tsx
var Pu = "https://cdn.jsdelivr.net/pyodide/v0.27.7/full/", Fu = null;
function Iu() {
	return Fu ??= (async () => (await import(
		/* @vite-ignore */
		`${Pu}pyodide.mjs`
)).loadPyodide({ indexURL: Pu }))().catch((e) => {
		throw Fu = null, e;
	}), Fu;
}
var Lu = "gleamshelf.script", Ru = () => {
	try {
		return localStorage.getItem(Lu) ?? br;
	} catch {
		return br;
	}
};
function zu({ editor: e, onClose: t }) {
	let [n, r] = q(Ru), [i, a] = q([]), [s, c] = q("idle"), l = K(!1), u = async () => {
		try {
			localStorage.setItem(Lu, n);
		} catch {}
		let t = [], r = (e) => {
			t.push(e), a([...t]);
		};
		a([]), c("loading");
		try {
			let t = await Iu();
			l.current ||= (t.registerJsModule("gleamshelf_bridge", { call: (t, n) => er(e, t, n) }), await t.runPythonAsync(Zn), !0), t.setStdout({ batched: r }), t.setStderr({ batched: r }), c("running"), e.begin("Script");
			try {
				await t.runPythonAsync(n);
			} finally {
				e.commit();
			}
			r("Done.");
		} catch (e) {
			r((e instanceof Error ? e.message : String(e)).split("\n").filter(Boolean).slice(-3).join("\n"));
		}
		c("idle");
	};
	return /* @__PURE__ */ X(uo, {
		title: "Script (Python)",
		onClose: t,
		children: [
			/* @__PURE__ */ Y("textarea", {
				className: "gs-script__code",
				spellCheck: !1,
				value: n,
				onChange: (e) => r(e.target.value),
				onKeyDown: (e) => {
					if ((e.metaKey || e.ctrlKey) && e.key === "Enter" && u(), e.key === "Tab" && !e.shiftKey) {
						e.preventDefault();
						let t = e.currentTarget, i = t.selectionStart;
						r(n.slice(0, i) + "    " + n.slice(t.selectionEnd)), requestAnimationFrame(() => t.setSelectionRange(i + 4, i + 4));
					}
				},
				"aria-label": "Python script"
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__actions",
				children: [
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => r(br),
						children: "Example"
					}),
					/* @__PURE__ */ Y("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: s !== "idle",
						onClick: () => void u(),
						children: s === "loading" ? "Loading Python…" : s === "running" ? "Running…" : "Run (Ctrl Enter)"
					})
				]
			}),
			i.length > 0 && /* @__PURE__ */ Y("pre", {
				className: "gs-script__out",
				children: i.join("\n")
			}),
			/* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: "The first run fetches Python for this browser (about 10 MB, from jsDelivr); scripts run here, nothing is uploaded."
			}),
			/* @__PURE__ */ Y(o, { id: "m3dScript" })
		]
	});
}
//#endregion
//#region src/model3d/LibraryDialog.tsx
function Bu(e) {
	let [t, n] = q(null), [r, i] = q(null);
	return G(() => {
		let t = !0;
		return fetch(`${e}index.json`).then((e) => {
			if (!e.ok) throw Error(String(e.status));
			return e.json();
		}).then((e) => t && n(e)).catch(() => t && i("The library could not be opened here.")), () => {
			t = !1;
		};
	}, [e]), {
		index: t,
		problem: r,
		setProblem: i
	};
}
var Vu = (e) => e.endsWith("/") ? e : `${e}/`;
function Hu({ root: e }) {
	return /* @__PURE__ */ X("p", {
		className: "gs-m3d__meta",
		children: [
			"Free models from",
			" ",
			/* @__PURE__ */ Y("a", {
				href: "https://polyhaven.com",
				target: "_blank",
				rel: "noreferrer",
				children: "Poly Haven"
			}),
			",",
			" ",
			/* @__PURE__ */ Y("a", {
				href: "https://vroid.pixiv.help/hc/en-us/articles/4402614652569",
				target: "_blank",
				rel: "noreferrer",
				children: "VRoid (pixiv)"
			}),
			",",
			" ",
			/* @__PURE__ */ Y("a", {
				href: "https://kaylousberg.com",
				target: "_blank",
				rel: "noreferrer",
				children: "KayKit"
			}),
			",",
			" ",
			/* @__PURE__ */ Y("a", {
				href: "https://quaternius.com",
				target: "_blank",
				rel: "noreferrer",
				children: "Quaternius"
			}),
			", CC0: free for any use, selling included. Seed-san and the VRM sample girl: VRM Public License, selling allowed too.",
			" ",
			/* @__PURE__ */ Y("a", {
				href: `${e}LICENSES.md`,
				target: "_blank",
				rel: "noreferrer",
				children: "Who made each"
			})
		]
	});
}
function Uu({ base: e, onPick: t, onClose: n }) {
	let r = Vu(e), { index: i, problem: a, setProblem: s } = Bu(r), c = i?.items ?? null, [l, u] = q("All"), [d, f] = q(""), [p, m] = q(null), h = Xr(() => ["All", ...new Set((c ?? []).map((e) => e.shelf))], [c]), g = (c ?? []).filter((e) => (l === "All" || e.shelf === l) && (!d.trim() || e.name.toLowerCase().includes(d.trim().toLowerCase()))), _ = async (e) => {
		m(e.id), s(null);
		try {
			let n = await fetch(`${r}${e.model}`);
			if (!n.ok) throw Error(String(n.status));
			await t(new File([await n.blob()], `${e.name} by ${e.author}.glb`, { type: "model/gltf-binary" }), e);
		} catch {
			s(`${e.name} could not be added.`);
		} finally {
			m(null);
		}
	};
	return /* @__PURE__ */ X(uo, {
		title: "3D library",
		onClose: n,
		children: [
			/* @__PURE__ */ Y("div", {
				className: "gs-m3d__segments gs-library__shelves",
				role: "group",
				"aria-label": "Shelf",
				children: h.map((e) => /* @__PURE__ */ Y("button", {
					type: "button",
					className: l === e ? "is-on" : "",
					onClick: () => u(e),
					children: e
				}, e))
			}),
			/* @__PURE__ */ Y("input", {
				type: "search",
				className: "gs-m3d__search",
				placeholder: "Search the library",
				value: d,
				onChange: (e) => f(e.target.value),
				"aria-label": "Search the library"
			}),
			!c && !a && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__meta",
				children: "Opening the library…"
			}),
			a && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: a
			}),
			/* @__PURE__ */ Y("div", {
				className: "gs-library",
				children: g.map((e) => /* @__PURE__ */ X("button", {
					type: "button",
					className: "gs-library__item",
					disabled: p !== null,
					onClick: () => void _(e),
					title: `${e.name}: about ${e.size[1].toFixed(2)} m tall, by ${e.author}`,
					children: [/* @__PURE__ */ Y("img", {
						src: `${r}${e.thumb}`,
						alt: "",
						loading: "lazy",
						width: 256,
						height: 256
					}), /* @__PURE__ */ Y("span", { children: p === e.id ? "Adding…" : e.name })]
				}, e.id))
			}),
			/* @__PURE__ */ Y(Hu, { root: r }),
			/* @__PURE__ */ Y(o, { id: "m3dLibrary" })
		]
	});
}
function Wu({ base: e, onOpen: t, onClose: n }) {
	let r = Vu(e), { index: i, problem: a, setProblem: s } = Bu(r), [c, l] = q(null), [u, d] = q(null), p = async (e) => {
		l(e.id), d(null), s(null);
		try {
			t(await f(e, i?.items ?? [], async (e) => {
				let t = await fetch(`${r}${e}`);
				if (!t.ok) throw Error(String(t.status));
				return new Uint8Array(await t.arrayBuffer());
			}, (e, t) => d([e, t])), e);
		} catch {
			s(`${e.name} could not be opened.`);
		} finally {
			l(null);
		}
	};
	return /* @__PURE__ */ X(uo, {
		title: "Start from a scene",
		onClose: n,
		children: [
			/* @__PURE__ */ Y("p", {
				className: "gs-m3d__meta",
				children: "The scene opens in place of this design; Undo brings the design back."
			}),
			!i && !a && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__meta",
				children: "Opening the library…"
			}),
			i && !i.scenes?.length && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__meta",
				children: "This library has no scenes yet."
			}),
			a && /* @__PURE__ */ Y("p", {
				className: "gs-m3d__note",
				children: a
			}),
			/* @__PURE__ */ Y("div", {
				className: "gs-library gs-library--scenes",
				children: (i?.scenes ?? []).map((e) => /* @__PURE__ */ X("button", {
					type: "button",
					className: "gs-library__item",
					disabled: c !== null,
					onClick: () => void p(e),
					title: e.note,
					children: [/* @__PURE__ */ Y("img", {
						src: `${r}${e.thumb}`,
						alt: "",
						loading: "lazy",
						width: 320,
						height: 200
					}), /* @__PURE__ */ Y("span", { children: c === e.id ? u ? `Opening… ${u[0]} of ${u[1]} models` : "Opening…" : e.name })]
				}, e.id))
			}),
			/* @__PURE__ */ Y(Hu, { root: r }),
			/* @__PURE__ */ Y(o, { id: "m3dScenes" })
		]
	});
}
//#endregion
//#region src/model3d/LayersSection.tsx
var Gu = [
	{
		label: ae.hair,
		tab: "hair",
		layer: "hair",
		of: "hair"
	},
	{
		label: "Eyes, lashes and brows",
		tab: "eyes"
	},
	{
		label: "Mouth and makeup",
		tab: "mouth"
	},
	{
		label: ae.face,
		tab: "face",
		layer: "face",
		of: "face"
	},
	{
		label: ae.body,
		tab: "body",
		layer: "body",
		of: "body"
	},
	{
		label: "Shape",
		tab: "shape"
	},
	{
		label: "Colours",
		tab: "colours"
	}
];
function Ku({ editor: e, doc: t, at: n, shape: r, base: i, run: a, onEdit: s }) {
	let [c, l] = q(/* @__PURE__ */ new Map());
	G(() => {
		if (!i) return;
		let e = !0;
		return ws(i).index().then((t) => e && l(new Map(t.models.map((e) => [e.id, e.name])))).catch(() => void 0), () => {
			e = !1;
		};
	}, [i]);
	let u = r.kind === "mesh" && r.asset ? t.assets?.[r.asset] : void 0, d = u?.character;
	if (!u || !d) return null;
	let f = d.hidden ?? [], p = (t) => void a(f.includes(t) ? `Showing the ${t}…` : `Hiding the ${t}…`, async () => {
		if (!i) throw Error("The characters come with the 3D library, which this page has not got.");
		let r = {
			...d,
			hidden: f.includes(t) ? f.filter((e) => e !== t) : [...f, t]
		};
		r.hidden.length || delete r.hidden;
		let { glb: a } = await ws(i).build(r), { asset: o } = await v([new File([a], `${u.name}.glb`, { type: "model/gltf-binary" })]);
		e.replaceModelAt(n, {
			...o,
			name: u.name,
			character: r
		}, `${f.includes(t) ? "Show" : "Hide"} ${ae[t].toLowerCase()}`);
	}), m = d.kit ? [{
		label: "All its pieces",
		tab: ""
	}] : Gu;
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Layers" }),
		/* @__PURE__ */ Y("ul", {
			className: "gs-layers",
			"aria-label": "The character's layers",
			children: m.map((e) => {
				let t = "layer" in e && e.layer ? f.includes(e.layer) : !1;
				return /* @__PURE__ */ X("li", {
					className: `gs-layers__row${t ? " is-off" : ""}`,
					children: [
						"layer" in e && e.layer ? /* @__PURE__ */ Y("button", {
							type: "button",
							className: "gs-layers__eye",
							"aria-pressed": !t,
							"aria-label": `${t ? "Show" : "Hide"} ${e.label.toLowerCase()}`,
							title: t ? "Hidden: click to show" : "Shown: click to hide",
							onClick: () => p(e.layer),
							children: t ? "◌" : "●"
						}) : /* @__PURE__ */ Y("span", {
							className: "gs-layers__eye",
							"aria-hidden": !0
						}),
						/* @__PURE__ */ X("span", {
							className: "gs-layers__name",
							children: [e.label, "of" in e && e.of && /* @__PURE__ */ Y("small", { children: c.get(d[e.of]) ?? d[e.of] })]
						}),
						/* @__PURE__ */ Y("button", {
							type: "button",
							className: "gs-m3d__btn",
							"aria-label": `Edit ${e.label.toLowerCase()}`,
							onClick: () => s(e.tab),
							children: "Edit"
						})
					]
				}, e.label);
			})
		}),
		/* @__PURE__ */ Y(o, { id: "m3dLayers" })
	] });
}
//#endregion
//#region src/model3d/EnvironmentSection.tsx
var qu = 2048;
async function Ju(e) {
	let t = await createImageBitmap(e), n = Math.min(1, qu / t.width), r = document.createElement("canvas");
	return r.width = Math.max(2, Math.round(t.width * n)), r.height = Math.max(1, Math.round(t.height * n)), r.getContext("2d").drawImage(t, 0, 0, r.width, r.height), t.close(), r.toDataURL("image/jpeg", .92);
}
function Yu({ editor: e, doc: t }) {
	let n = K(null), r = t.environment, i = (t, n) => e.set("environment", t === null ? void 0 : r ? {
		...r,
		...t
	} : t, n);
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Environment" }),
		r ? /* @__PURE__ */ X(J, { children: [
			/* @__PURE__ */ Y("img", {
				className: "gs-label__thumb",
				src: r.picture,
				alt: "The environment picture"
			}),
			/* @__PURE__ */ Y(U, {
				label: "Strength",
				value: r.strength,
				min: 0,
				max: 4,
				step: .05,
				onBegin: () => e.begin("Environment strength"),
				onChange: (e) => i({ strength: e }),
				onEnd: () => e.commit()
			}),
			/* @__PURE__ */ Y(U, {
				label: "Turn",
				value: r.turn,
				min: -180,
				max: 180,
				step: 1,
				format: (e) => `${e}°`,
				onBegin: () => e.begin("Environment turn"),
				onChange: (e) => i({ turn: e }),
				onEnd: () => e.commit()
			}),
			/* @__PURE__ */ X("label", {
				className: "gs-m3d__check",
				children: [/* @__PURE__ */ Y("input", {
					type: "checkbox",
					checked: r.show,
					onChange: (e) => i({ show: e.target.checked }, "Environment behind")
				}), " Show it behind the design"]
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__row",
				children: [/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => n.current?.click(),
					children: "Other picture…"
				}), /* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => i(null, "Remove environment"),
					children: "Remove"
				})]
			})
		] }) : /* @__PURE__ */ Y("button", {
			type: "button",
			className: "gs-m3d__btn",
			onClick: () => n.current?.click(),
			children: "Add a picture all round…"
		}),
		/* @__PURE__ */ Y("input", {
			ref: n,
			type: "file",
			accept: "image/jpeg,image/png,image/webp",
			hidden: !0,
			onChange: (e) => {
				let t = e.target.files?.[0];
				e.target.value = "", t && Ju(t).then((e) => i(r ? { picture: e } : {
					picture: e,
					strength: 1,
					turn: 0,
					show: !1
				}, "Environment"));
			}
		}),
		/* @__PURE__ */ Y(o, { id: "m3dEnvironment" })
	] });
}
//#endregion
//#region src/model3d/TriggersSection.tsx
var Xu = [
	.5,
	.8,
	1.2,
	2
];
function Zu({ editor: e, at: t, shape: n, playing: r, onPlay: i }) {
	let a = n.triggers, s = (n, r) => {
		let i = {
			seconds: we,
			...a,
			...n
		}, o = i.click || i.hover ? i : void 0;
		e.updateShapeAt(t, { triggers: o }, r);
	}, c = (e, t) => /* @__PURE__ */ X("label", {
		className: "gs-m3d__field",
		children: [/* @__PURE__ */ Y("span", { children: t }), /* @__PURE__ */ X("select", {
			value: a?.[e] ?? "none",
			onChange: (n) => {
				let r = n.target.value;
				s({ [e]: r === "none" ? void 0 : r }, `${t}: ${r === "none" ? "nothing" : je[r]}`);
			},
			children: [/* @__PURE__ */ Y("option", {
				value: "none",
				children: "Nothing"
			}), De.map((e) => /* @__PURE__ */ Y("option", {
				value: e,
				children: je[e]
			}, e))]
		})]
	});
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Click and hover" }),
		c("click", "When clicked"),
		c("hover", "When pointed at"),
		a && /* @__PURE__ */ X("label", {
			className: "gs-m3d__field",
			children: [/* @__PURE__ */ Y("span", { children: "Takes" }), /* @__PURE__ */ Y("select", {
				value: a.seconds,
				onChange: (e) => s({ seconds: Number(e.target.value) }, "Reaction length"),
				children: (Xu.includes(a.seconds) ? Xu : [...Xu, a.seconds].sort((e, t) => e - t)).map((e) => /* @__PURE__ */ X("option", {
					value: e,
					children: [e, " s"]
				}, e))
			})]
		}),
		a && /* @__PURE__ */ Y("div", {
			className: "gs-m3d__row",
			children: /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				onClick: i,
				title: "Space",
				children: r ? "Stop" : "Play to try it"
			})
		}),
		a && r && /* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: "Click it, or point at it, in the view."
		}),
		/* @__PURE__ */ Y(o, { id: "m3dTriggers" })
	] });
}
//#endregion
//#region src/model3d/useTriggers.ts
function Qu(e, t, n, r) {
	let i = K(/* @__PURE__ */ new Map()), a = K(null), o = (e, t) => {
		if (!e) return;
		let n = i.current.get(e.id);
		(!n || t === "click" && n.on === "hover") && i.current.set(e.id, {
			...e,
			on: t,
			start: performance.now()
		});
	};
	return G(() => {
		let s = e.current;
		if (!r || !s) {
			i.current.clear(), a.current = null;
			return;
		}
		let c = 0, l = null, u = () => {
			c = 0;
			let e = t.current;
			if (!e || !l) return;
			let r = e.shapeAt(l.clientX, l.clientY), i = ve(n.document, r, "hover");
			(i?.id ?? null) !== a.current && (a.current = i?.id ?? null, o(i, "hover")), s.style.cursor = ve(n.document, r, "click") ? "pointer" : "";
		}, d = (e) => {
			l = e, c ||= requestAnimationFrame(u);
		}, f = () => {
			a.current = null, s.style.cursor = "";
		};
		return s.addEventListener("pointermove", d), s.addEventListener("pointerleave", f), () => {
			s.removeEventListener("pointermove", d), s.removeEventListener("pointerleave", f), cancelAnimationFrame(c), s.style.cursor = "";
		};
	}, [
		r,
		e,
		t,
		n
	]), {
		click: (e) => o(ve(n.document, e, "click"), "click"),
		at: (e) => {
			let t = /* @__PURE__ */ new Map();
			for (let [n, r] of i.current) {
				let a = (e - r.start) / (r.seconds * 1e3);
				a >= 1 ? i.current.delete(n) : t.set(n, {
					reaction: r.reaction,
					at: Math.max(0, a)
				});
			}
			return t;
		}
	};
}
//#endregion
//#region src/model3d/ScenePanel.tsx
function $u({ editor: e, doc: n, aspect: r }) {
	let i = t(), [s, c] = q(Vr[0]), [u, d] = q(null), [f, p] = q(null), m = K(null), h = i.state === "ready" ? i.installed("redraw")[0] : void 0, g = l(), _ = n.background.picture, v = (t, n) => {
		e.setSetting("background", "picture", t, n), Ir(t);
	}, y = async () => {
		p(null);
		try {
			v(await zr(i.client, r(), s.trim() || Vr[0], d), "Scene behind");
		} catch (e) {
			p(e instanceof Error ? e.message : "The scene could not be made.");
		} finally {
			d(null);
		}
	};
	return /* @__PURE__ */ X("section", { children: [
		/* @__PURE__ */ Y("h4", { children: "Scene behind" }),
		_ && /* @__PURE__ */ X("div", {
			className: "gs-scene__now",
			children: [/* @__PURE__ */ Y("img", {
				src: _,
				alt: "The scene behind the design"
			}), /* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__btn",
				disabled: !!u,
				onClick: () => v("", "No scene"),
				children: "Remove the scene"
			})]
		}),
		/* @__PURE__ */ X("label", {
			className: "gs-m3d__field gs-m3d__field--top",
			children: [/* @__PURE__ */ Y("span", { children: "Paint" }), /* @__PURE__ */ Y("textarea", {
				rows: 2,
				value: s,
				maxLength: 200,
				onChange: (e) => c(e.target.value),
				disabled: !!u
			})]
		}),
		/* @__PURE__ */ Y("div", {
			className: "gs-scene__ideas",
			children: Vr.map((e) => /* @__PURE__ */ Y("button", {
				type: "button",
				className: s === e ? "is-on" : "",
				disabled: !!u,
				onClick: () => c(e),
				children: e.split(",")[0]
			}, e))
		}),
		g && i.state !== "ready" && /* @__PURE__ */ Y(a, {
			app: i,
			feature: "Painting a scene",
			compact: !0
		}),
		/* @__PURE__ */ X("p", {
			className: "gs-m3d__note",
			hidden: !!g && i.state !== "ready",
			children: [
				h ? "Free: painted by the image model on this computer, about a minute; nothing is sent anywhere. The scene goes behind; every shape and the product photo stay as they are." : i.state === "ready" ? "Painting a scene needs the image model, set up once with: npm run redraw:setup (free, on this computer). Your own picture works without it." : "Painting a scene needs the Gleamshelf app running on this computer. Your own picture works without it.",
				" ",
				!i.looking && /* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => void i.check(),
					children: "Look for the app"
				})
			]
		}),
		/* @__PURE__ */ X("div", {
			className: "gs-m3d__row",
			children: [
				/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn gs-m3d__btn--primary",
					disabled: !h || !!u,
					onClick: () => void y(),
					children: u ?? (_ ? "Paint another" : "Paint a scene")
				}),
				/* @__PURE__ */ Y("button", {
					type: "button",
					className: "gs-m3d__btn",
					disabled: !!u,
					onClick: () => m.current?.click(),
					children: "Use my own picture…"
				}),
				/* @__PURE__ */ Y("input", {
					ref: m,
					type: "file",
					accept: "image/png,image/jpeg,image/webp",
					hidden: !0,
					onChange: (e) => {
						let t = e.target.files?.[0];
						e.target.value = "", t && Fr(t).then((e) => v(e, "Scene behind"));
					}
				})
			]
		}),
		f && /* @__PURE__ */ Y("p", {
			className: "gs-m3d__note",
			children: f
		}),
		/* @__PURE__ */ Y(o, { id: "m3dScene" })
	] });
}
//#endregion
//#region src/model3d/labels.ts
var ed = {
	add: "Add",
	subtract: "Cut",
	intersect: "Intersect"
}, td = {
	matte: "Matte",
	satin: "Satin",
	glossy: "Glossy",
	metal: "Metal",
	glass: "Glass",
	glow: "Glow",
	velvet: "Velvet",
	coat: "Clear coat"
}, nd = [
	"#ff7ab6",
	"#f87171",
	"#fbbf24",
	"#34d399",
	"#67e8f9",
	"#60a5fa",
	"#a78bfa",
	"#f4f1fb",
	"#9ca3af",
	"#1f2937"
], rd = [
	{
		axis: 0,
		name: "Across",
		labels: {
			min: "Left",
			mid: "Middle",
			max: "Right"
		}
	},
	{
		axis: 1,
		name: "Up",
		labels: {
			min: "Bottom",
			mid: "Middle",
			max: "Top"
		}
	},
	{
		axis: 2,
		name: "Depth",
		labels: {
			min: "Back",
			mid: "Middle",
			max: "Front"
		}
	}
];
function id(e, t) {
	return t.flatMap((t) => {
		let n = e.shapes[t];
		return n ? n.kind === "group" ? (n.children ?? []).map((e, n) => ({
			ref: [t, n],
			shape: e
		})) : [{
			ref: [t],
			shape: n
		}] : [];
	});
}
var ad = (e, t) => e.kind === "mesh" && e.ownColors !== !1 && ("color" in t || "finish" in t) ? {
	...t,
	ownColors: !1
} : t;
function od({ editor: e, doc: t, picked: n, onDuplicate: r, onDelete: i, onGroup: a, onJoin: s, onModelWithShape: c, motion: l, physics: u }) {
	let d = id(t, n), f = d[0]?.shape, p = n.map((e) => t.shapes[e]).filter((e) => !!e), m = (t, n) => e.updateShapesAt(d.map(({ ref: e, shape: n }) => [e, ad(n, t)]), n), h = d.filter((e) => e.shape.kind !== "mesh"), g = p.every((e) => e.locked), _ = p.every((e) => e.hidden), v = Bo();
	return f ? /* @__PURE__ */ X("div", {
		className: "gs-m3d__panel",
		children: [
			/* @__PURE__ */ X("section", { children: [
				/* @__PURE__ */ X("h4", { children: [n.length, " shapes picked"] }),
				/* @__PURE__ */ X("div", {
					className: "gs-m3d__row",
					children: [
						c && /* @__PURE__ */ X(J, { children: [
							/* @__PURE__ */ Y("button", {
								type: "button",
								className: "gs-m3d__btn",
								onClick: () => c("subtract"),
								title: "The shape cut out of the model",
								children: "Cut the model with the shape"
							}),
							/* @__PURE__ */ Y("button", {
								type: "button",
								className: "gs-m3d__btn",
								onClick: () => c("add"),
								title: "One model of both",
								children: "Join the shape on"
							}),
							/* @__PURE__ */ Y("button", {
								type: "button",
								className: "gs-m3d__btn",
								onClick: () => c("intersect"),
								title: "Only where they overlap",
								children: "Keep where they meet"
							})
						] }),
						s && /* @__PURE__ */ Y("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: s,
							title: "One model from these imported models, as they sit",
							children: "Join models"
						}),
						/* @__PURE__ */ Y("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: a,
							title: "Group them (Ctrl G)",
							children: "Group"
						}),
						/* @__PURE__ */ Y("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: r,
							title: "Duplicate them (Ctrl D)",
							children: "Duplicate"
						}),
						/* @__PURE__ */ Y("button", {
							type: "button",
							className: "gs-m3d__btn",
							onClick: i,
							title: "Delete them (Delete)",
							children: "Delete"
						}),
						/* @__PURE__ */ Y("button", {
							type: "button",
							className: "gs-m3d__btn",
							title: "Locked shapes are not picked or dragged in the view (Ctrl Alt L)",
							onClick: () => e.updateShapesAt(n.map((e) => [[e], { locked: !g }]), g ? "Unlock" : "Lock"),
							children: g ? "Unlock" : "Lock"
						}),
						/* @__PURE__ */ Y("button", {
							type: "button",
							className: "gs-m3d__btn",
							title: "Ctrl Shift H",
							onClick: () => e.updateShapesAt(n.map((e) => [[e], { hidden: !_ }]), _ ? "Show" : "Hide"),
							children: _ ? "Show" : "Hide"
						})
					]
				}),
				/* @__PURE__ */ Y(o, { id: "m3dMulti" })
			] }),
			/* @__PURE__ */ X("section", { children: [
				/* @__PURE__ */ Y("h4", { children: "Line up" }),
				rd.map(({ axis: t, name: r, labels: i }) => /* @__PURE__ */ X("div", {
					className: "gs-m3d__align",
					children: [/* @__PURE__ */ Y("span", { children: r }), [
						"min",
						"mid",
						"max"
					].map((r) => /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => e.align(n, t, r),
						children: i[r]
					}, r))]
				}, t)),
				/* @__PURE__ */ X("div", {
					className: "gs-m3d__align",
					children: [/* @__PURE__ */ Y("span", { children: "Spread" }), rd.map(({ axis: t, name: r }) => /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						disabled: n.length < 3,
						title: n.length < 3 ? "Pick three or more to spread them" : `Equal gaps ${r.toLowerCase()}`,
						onClick: () => e.spread(n, t),
						children: r
					}, t))]
				}),
				/* @__PURE__ */ Y("div", {
					className: "gs-m3d__row",
					children: /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => e.toGround(n),
						children: "Put them on the ground"
					})
				}),
				/* @__PURE__ */ Y(o, { id: "m3dAlign" })
			] }),
			/* @__PURE__ */ X("section", { children: [
				/* @__PURE__ */ Y("h4", { children: "Colour and finish" }),
				/* @__PURE__ */ X("div", {
					className: "gs-m3d__swatches",
					children: [nd.map((e) => /* @__PURE__ */ Y("button", {
						type: "button",
						style: { background: e },
						className: d.every((t) => t.shape.color === e) ? "is-on" : "",
						"aria-label": `Colour ${e}`,
						onClick: () => m({ color: e }, "Colour")
					}, e)), /* @__PURE__ */ Y("input", {
						type: "color",
						value: f.color,
						"aria-label": "Any colour",
						onChange: (e) => m({ color: e.target.value }, "Colour")
					})]
				}),
				/* @__PURE__ */ Y(W, {
					label: "Finish",
					value: d.every((e) => e.shape.finish === f.finish) ? f.finish : "",
					options: _t,
					labels: td,
					onChange: (e) => m({ finish: e }, td[e])
				}),
				/* @__PURE__ */ X("div", {
					className: "gs-m3d__row",
					children: [/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: () => zo(f),
						title: "Copy the first one's colour and finish (Ctrl Alt C)",
						children: "Copy look"
					}), /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						disabled: !v,
						title: "Give them all the copied colour and finish (Ctrl Alt V)",
						onClick: () => v && m({
							color: v.color,
							finish: v.finish
						}, "Paste look"),
						children: "Paste look"
					})]
				}),
				/* @__PURE__ */ Y(o, { id: "m3dLookCopy" })
			] }),
			l,
			u,
			h.length > 0 && /* @__PURE__ */ X("section", { children: [
				/* @__PURE__ */ Y("h4", { children: "Combine" }),
				/* @__PURE__ */ Y(W, {
					label: "Combine",
					value: h.every((e) => e.shape.combine === h[0].shape.combine) ? h[0].shape.combine : "",
					options: Lt,
					labels: ed,
					onChange: (t) => e.updateShapesAt(h.map((e) => [e.ref, { combine: t }]), ed[t])
				}),
				/* @__PURE__ */ Y(U, {
					label: "Blend",
					value: h[0].shape.blend,
					min: 0,
					max: 1,
					step: .01,
					format: (e) => `${Math.round(e * 100)}%`,
					onBegin: () => e.begin("Blend"),
					onChange: (t) => e.updateShapesAt(h.map((e) => [e.ref, { blend: t }])),
					onEnd: () => e.commit()
				})
			] })
		]
	}) : null;
}
//#endregion
//#region src/model3d/ModelMode.tsx
var sd = /* @__PURE__ */ e({ ModelMode: () => xd }), cd = {
	soft: "Soft",
	toon: "Toon",
	flat: "Flat",
	clay: "Clay",
	pixel: "Pixel"
}, ld = {
	perspective: "Perspective (0)",
	front: "Front (5)",
	left: "Left (4)",
	side: "Right (6)",
	back: "Back",
	top: "Top (8)",
	bottom: "Bottom (2)",
	"isometric-left": "Isometric, left (7)",
	isometric: "Isometric, right (9)",
	"isometric-below-left": "From below, left (1)",
	"isometric-below": "From below, right (3)"
}, ud = {
	0: "perspective",
	5: "front",
	4: "left",
	6: "side",
	8: "top",
	2: "bottom",
	7: "isometric-left",
	9: "isometric",
	1: "isometric-below-left",
	3: "isometric-below"
}, dd = [
	{
		mode: "translate",
		label: "Move",
		key: "M"
	},
	{
		mode: "rotate",
		label: "Turn",
		key: "T"
	},
	{
		mode: "scale",
		label: "Resize",
		key: "R"
	}
], fd = /* @__PURE__ */ new Set([
	"KeyW",
	"KeyA",
	"KeyS",
	"KeyD",
	"KeyQ",
	"KeyE"
]), pd = "gleamshelf.model3d.grid", md = [
	.1,
	.25,
	.5,
	1,
	2
], hd = (e) => Math.min(10, Math.max(.05, Math.round(e * 100) / 100));
function gd() {
	try {
		let e = JSON.parse(localStorage.getItem(pd) ?? "null");
		if (e && typeof e.size == "number" && Number.isFinite(e.size)) return {
			on: e.on !== !1,
			size: hd(e.size),
			snap: !!e.snap
		};
	} catch {}
	return {
		on: !0,
		size: .5,
		snap: !1
	};
}
var _d = (e, t) => !!e && !!t && e.length === t.length && e[0] === t[0] && e[1] === t[1], vd = [
	"library",
	"scenes",
	"render",
	"avatar"
];
function yd(e) {
	return e === "library" || e === "scenes" || e === "render" ? e : e === "character" ? "avatar" : null;
}
var bd = (e, t) => {
	let n = document.createElement("a");
	n.href = URL.createObjectURL(e), n.download = t, n.click(), setTimeout(() => URL.revokeObjectURL(n.href), 4e3);
};
function xd({ open: e, title: r = "3D design", onDone: i, doneLabel: a = "Use in design", onClose: l, renderSize: u = 2e3, ad: d, photos: f, actions: m, library: g, place: _ = "", onPlace: y }) {
	let x = K(null);
	x.current ||= new rr(e ?? ue());
	let C = t(), w = p(g, {
		ready: C.state === "ready",
		url: C.saved.url
	}), T = x.current, D = Zr(T.subscribe, T.getSnapshot), O = D.doc, k = K(null), A = K(null), [j, M] = q(kc), ee = () => M((e) => (Ac(!e), !e)), te = Yr(() => A.current, []), ne = K(null), [N, P] = q(e ? null : [0]), [I, ie] = q([]), [ae, oe] = q("translate"), [L, se] = q(gd), [ce, de] = q(_ === "light" ? "scene" : _ === "game" || _ === "voice" ? "game" : "shape"), [fe, pe] = q(null), [he, _e] = q(null), [ve, ye] = q(null), be = ve ? He(O, ve.at) : void 0, xe = be?.kind === "mesh" && be.asset ? O.assets?.[be.asset]?.character : void 0, Se = xe && ve ? {
		...xe,
		hidden: xe.hidden?.filter((e) => e !== ve.tab)
	} : void 0, [R, z] = q(d ? "ad" : f ? "photos" : yd(_)), we = r.replace(/[^\w -]+/g, "").trim() || "3d-design", Te = K(null), Ee = K(null), De = K(null), [B, ke] = q(!1), [Ae, je] = q(!1), [Me, Ne] = q(_ === "learn"), [Pe, Fe] = q(!1), [Ie, Le] = q(_ === "voice"), [Re, ze] = q(() => T.document.clip ?? 4), [Be, Ve] = q(0), [Ue, We] = q(!1), [Ge, Ke] = q(!1), qe = Dc(T, (e) => _e(e)), Je = Me ? "learn" : Ie ? "voice" : R === "library" || R === "scenes" || R === "render" ? R : R === "avatar" ? "character" : ce === "scene" ? "light" : ce === "game" ? "game" : "", Ye = K(Je);
	G(() => {
		Je !== Ye.current && (Ye.current = Je, y?.(Je));
	}, [Je, y]), G(() => {
		_ !== Ye.current && (Ye.current = _, Ne(_ === "learn"), Le(_ === "voice"), z((e) => yd(_) ?? (e && vd.includes(e) ? null : e)), _ === "light" ? de("scene") : _ === "game" || _ === "voice" ? de("game") : _ === "" && de("shape"));
	}, [_]);
	let Ze = K(!1), Qe = Qu(k, A, T, Ae), $e = K(Qe);
	$e.current = Qe, Ze.current = Ae, G(() => {
		if (k.current) try {
			let e = new E(k.current, T, { onPick: (e, t) => {
				if (Ze.current) return $e.current.click(e);
				if (t.extend && e) {
					let t = e[0];
					ie((e) => e.includes(t) ? e.filter((e) => e !== t) : [...e, t]), P([t]);
				} else P(e), ie(e ? [e[0]] : []);
			} });
			return A.current = e, () => {
				e.dispose(), A.current = null;
			};
		} catch (e) {
			_e(e instanceof Error ? `3D drawing could not start: ${e.message}` : "3D drawing could not start on this computer.");
		}
	}, [T]), G(() => {
		I.length > 1 ? A.current?.selectSeveral(I) : A.current?.select(N);
	}, [N, I]), G(() => A.current?.setGizmo(ae), [ae]), G(() => {
		A.current?.setGrid(L.on ? L.size : 0, L.on && L.snap);
		try {
			localStorage.setItem(pd, JSON.stringify(L));
		} catch {}
	}, [L]), G(() => ne.current?.focus(), []), G(() => {
		N && !He(O, N) && P(null), ie((e) => e.filter((e) => O.shapes[e]));
	}, [O, N]), G(() => {
		I.length === 1 && N?.[0] !== I[0] && P([I[0]]);
	}, [I, N]);
	let V = He(O, N), et = (e, t) => N && T.updateShapeAt(N, e, t), tt = (e) => () => T.begin(e), nt = () => T.commit(), rt = () => _e("The design is full: it holds 256 shapes (a group counts two more) and 16 outlines or texts."), it = (e, t) => {
		P(e), e.length === 1 && ie((n) => t ? n.includes(e[0]) ? n.filter((t) => t !== e[0]) : [...n, e[0]] : [e[0]]);
	}, at = (e) => {
		let t = T.addShape(e);
		if (t < 0) return rt();
		it([t], !1), de("shape");
	}, st = (e, t, n, r) => {
		z(null);
		let i = t >= 1 ? 1 / t : 1, a = t >= 1 ? 1 : t, o = T.addShape("extrude", {
			name: n,
			outline: e,
			size: [
				a * 1.4,
				i * 1.4,
				.35
			],
			...r ? { pen: r } : {}
		});
		if (o < 0) return rt();
		it([o], !1), de("shape");
	}, ct = () => H("Joining the models…", async () => {
		let e = I.map((e) => O.shapes[e]).filter(Boolean), t = await xn(T.document, e), n = $c(), [r, ...i] = [...I].sort((e, t) => e - t);
		T.begin("Join models"), T.set("assets", {
			...T.document.assets ?? {},
			[n]: Pr(t.asset, "Joined model")
		}), T.updateShapeAt([r], {
			asset: n,
			position: t.position,
			size: t.size,
			rotation: [
				0,
				0,
				0
			],
			name: "Joined model"
		}), T.removeShapes(i), T.commit(), it([r], !1);
	}), lt = (e) => H(e === "subtract" ? "Cutting the model…" : e === "add" ? "Joining the shape on…" : "Keeping where they meet…", async () => {
		let [t, n] = O.shapes[I[0]]?.kind === "mesh" ? [I[0], I[1]] : [I[1], I[0]], r = await Cn(T.document, O.shapes[t], O.shapes[n], e), i = $c();
		T.begin("Model and shape"), T.set("assets", {
			...T.document.assets ?? {},
			[i]: Pr(r.asset, O.assets?.[O.shapes[t].asset ?? ""]?.name ?? "Model")
		}), T.updateShapeAt([t], {
			asset: i,
			position: r.position,
			size: r.size,
			rotation: [
				0,
				0,
				0
			]
		}), T.removeShapes([n]), T.commit(), it([t < n ? t : t - 1], !1);
	}), ut = (e) => H("Tracing the picture…", async () => {
		let t = await createImageBitmap(e), n = Math.min(1, 1024 / Math.max(t.width, t.height)), r = Math.max(1, Math.round(t.width * n)), i = Math.max(1, Math.round(t.height * n)), a = new OffscreenCanvas(r, i).getContext("2d");
		a.drawImage(t, 0, 0, r, i), t.close();
		let o = lr(a.getImageData(0, 0, r, i).data, r, i);
		if (!o) throw Error("Nothing in that picture stands out from its background to push out.");
		st(o.outline, o.aspect, e.name.replace(/\.[^.]+$/, "").slice(0, 40) || "Picture");
		let s = T.document.shapes.length - 1;
		o.color && T.updateShapeAt([s], { color: o.color }, "Picture colour");
	}), dt = (e, t, n = 0) => 2 * e * t / (1 - n), ft = (e, t, n, r) => {
		z(null);
		let i = 1.3, a = Math.min(dt(i, t), 3), o = T.addShape("revolve", {
			name: n,
			outline: e,
			size: [
				a,
				i,
				a
			],
			...r ? { pen: r } : {}
		});
		if (o < 0) return rt();
		it([o], !1), de("shape");
	}, pt = (e, t, n, r) => {
		if (z(null), !V || V.kind !== "extrude" && V.kind !== "revolve") return;
		let i = V.size[1];
		if (V.kind === "revolve") {
			let n = dt(i, t, V.revolve?.offset);
			return et({
				outline: e,
				pen: r,
				size: [
					n,
					i,
					n
				]
			}, "Change profile");
		}
		et({
			outline: e,
			pen: r,
			size: [
				i * t,
				i,
				V.size[2]
			]
		}, "Change outline");
	}, mt = (e) => e.value.replace(/\s+/g, " ").trim().slice(0, 30), ht = async (e) => {
		await Xa(e.font, e.weight, e.value);
		let t = hr(e.value, e.font, e.weight, vr, e);
		if (!t) throw Error("That text draws nothing in this font.");
		return t;
	}, gt = (e) => {
		z(null), H("Drawing the letters…", async () => {
			let t = await ht(e), n = .6 * Math.max(1, e.value.split("\n").length * .8), r = T.addShape("text", {
				name: mt(e),
				text: e,
				outline: t.outline,
				size: [
					n * t.aspect,
					n,
					.3
				]
			});
			if (r < 0) return rt();
			it([r], !1), de("shape");
		});
	}, vt = (e) => {
		if (z(null), !V || V.kind !== "text") return;
		let t = N, [n, r] = [V.size[1], V.size[2]];
		H("Drawing the letters…", async () => {
			let i = await ht(e);
			t && T.updateShapeAt(t, {
				text: e,
				outline: i.outline,
				name: mt(e),
				size: [
					n * i.aspect,
					n,
					r
				]
			}, "Change text");
		});
	}, yt = (e) => H("Reading the SVG…", async () => {
		let t = wt(T.document.shapes), n = Math.min(16 - t.fields, 256 - t.slots - 2);
		if (n < 1) return rt();
		let r = pn(await e.text(), { maxParts: n }), [i, , a] = T.document.camera.target, o = e.name.replace(/\.svg$/i, "").slice(0, 60) || "Logo", s = qn(r, {
			long: 2,
			at: [i, a]
		});
		s.length === 1 && (s[0].name = o);
		let c = T.addShapes(s, `Import ${o}`, o);
		if (c < 0) return rt();
		it([c], !1), de("shape"), T.frameAll(Kt()), r.warnings.length && _e(`Imported. ${r.warnings.join(" ")}`);
	}), bt = (e) => {
		z(null), H("Making the ad…", async () => {
			let t = [], n;
			if (e.picture) {
				let r = await Cd(e.picture);
				n = {
					asset: Xn(r.bytes, "image/png", r.width, r.height, "Product photo"),
					aspect: r.width / r.height
				}, r.seeThrough < .02 && t.push("The picture has no see-through background, so its rectangle shows: a cut-out looks best.");
			}
			let r = [
				e.headline,
				e.tagline,
				e.price
			].join(" ");
			await Xa(e.font.family, 900, r);
			let i = e.logo ? pn(e.logo.svg, { maxParts: 6 }) : void 0, a = _r({
				style: e.style,
				colours: e.colours,
				picture: n,
				headline: e.headline,
				tagline: e.tagline,
				price: e.price,
				logo: i,
				font: e.font.family,
				moving: e.moving,
				text: (e) => hr(e.value, e.font, e.weight, vr, e)
			}, Kt());
			e.scene && (a.background = {
				...a.background,
				picture: e.scene
			}), T.replaceDesign(a, "Make an ad"), P(null), ie([]), de("shape"), e.moving && je(!0), i && t.push(...i.warnings.filter((e) => /^(Text|Lines|Strokes|Pictures)/.test(e))), t.length && _e(t.join(" "));
		});
	}, xt = (e) => H("Opening the design…", async () => {
		let t = await e.text();
		if ($t(JSON.parse(t))) {
			qe.load(t), de("game");
			return;
		}
		let n = Ce(t);
		T.replaceDesign(n, "Open a design"), P(null), ie([]), de("shape"), ze(n.clip ?? 4);
		let r = St(JSON.parse(t));
		r && _e(r);
	}), Ct = (e) => {
		z(null);
		let t = Kt(), n = 1.6, r = t < n ? {
			...e.camera,
			distance: Math.min(200, e.camera.distance * n / t)
		} : e.camera;
		T.replaceDesign({
			...e,
			camera: r
		}, "Start from a scene"), P(null), ie([]), de("shape"), ze(e.clip ?? 4);
	}, Tt = (e) => {
		let t = e.find((e) => /\.json$/i.test(e.name) || e.type === "application/json"), n = e.find((e) => /\.svg$/i.test(e.name) || e.type === "image/svg+xml");
		t ? xt(t) : n ? yt(n) : Jt(e);
	}, Et = () => {
		let e = T.group(I.length ? I : N?.length === 1 ? [N[0]] : []);
		if (e < 0) return rt();
		it([e], !1);
	}, Dt = () => {
		N && N.length === 1 && V?.kind === "group" && it([T.ungroup(N[0])], !1);
	}, Ot = () => {
		if (I.length > 1) T.removeShapes(I);
		else if (N) T.removeShapeAt(N);
		else return;
		P(null), ie([]);
	}, At = () => {
		if (I.length > 1) {
			let e = T.pasteShapes(I.map((e) => O.shapes[e]).filter(Boolean), {}, [
				.6,
				0,
				0
			]);
			if (!e) return rt();
			ie(e), P([e[e.length - 1]]);
			return;
		}
		if (!N) return;
		let e = T.duplicateShapeAt(N);
		if (!e) return rt();
		it(e, !1);
	}, jt = () => (I.length ? I : N ? [N[0]] : []).filter((e) => O.shapes[e]), Mt = (e = !1) => {
		let t = jt();
		t.length && (Io(T.document, t.map((e) => O.shapes[e])), e && (T.removeShapes(t), P(null), ie([])));
	}, Nt = () => {
		let e = Lo();
		if (!e) return !1;
		let t = T.pasteShapes(e.shapes, e.assets, Ro());
		return t ? (ie(t), P([t[t.length - 1]]), de("shape"), !0) : (rt(), !0);
	}, Pt = K(null), Ft = (e) => {
		if (Pt.current && clearTimeout(Pt.current), Pt.current = null, R) return;
		let t = e.target;
		if (t.tagName === "INPUT" || t.tagName === "TEXTAREA") return;
		let n = e.clipboardData.getData("text/plain");
		/^\s*(<\?xml[^>]*>\s*)?(<!--[\s\S]*?-->\s*)*<svg[\s>]/i.test(n) ? (e.preventDefault(), yt(new File([n], "Pasted logo.svg", { type: "image/svg+xml" }))) : Nt() && e.preventDefault();
	}, It = (e) => {
		let t = jt();
		if (!t.length) return;
		let n = !t.every((t) => O.shapes[t][e]);
		T.updateShapesAt(t.map((t) => [[t], { [e]: n }]), e === "locked" ? n ? "Lock" : "Unlock" : n ? "Hide" : "Show");
	}, Rt = () => {
		let e = Bo();
		if (!e) return;
		let t = I.length > 1 ? id(O, I) : N ? V?.kind === "group" ? id(O, [N[0]]) : [{
			ref: N,
			shape: V
		}] : [];
		T.updateShapesAt(t.map(({ ref: t, shape: n }) => [t, {
			color: e.color,
			finish: e.finish,
			...n.kind === "mesh" ? { ownColors: !1 } : {}
		}]), "Paste look");
	}, zt = (e, t = !1) => {
		if (!N) return;
		let n = N;
		for (let r = 0; r < (t ? 256 : 1); r++) {
			let t = T.moveShapeAt(n, e);
			if (_d(t, n)) break;
			n = t;
		}
		it(n, !1);
	}, Bt = K(/* @__PURE__ */ new Set()), Ht = (e) => {
		let t = Bt.current, n = (e, n) => +!!t.has(e) - !!t.has(n);
		A.current?.fly({
			forward: n("KeyW", "KeyS"),
			across: n("KeyD", "KeyA"),
			up: n("KeyE", "KeyQ"),
			fast: e
		});
	}, Ut = () => {
		Bt.current.clear(), A.current?.fly(null, { now: !0 });
	}, Wt = (e) => {
		Bt.current.size && (Bt.current.delete(e.code) || e.key === "Shift") && Ht(e.shiftKey);
	};
	G(() => (window.addEventListener("blur", Ut), () => window.removeEventListener("blur", Ut)), []);
	let Gt = (e) => {
		if (R) return;
		let t = e.target;
		if (t.tagName === "INPUT" && t.type !== "range" || t.tagName === "SELECT" || t.tagName === "TEXTAREA" || t.isContentEditable) return;
		let n = e.metaKey || e.ctrlKey;
		if (n && Bt.current.size && Ut(), !n && !Ge && fd.has(e.code)) {
			e.preventDefault(), Bt.current.add(e.code), Ht(e.shiftKey);
			return;
		}
		e.key === "Shift" && Bt.current.size && Ht(!0);
		let r = e.code.startsWith("Key") ? e.code.slice(3).toLowerCase() : e.key.toLowerCase(), i = /^(?:Digit|Numpad)(\d)$/.exec(e.code)?.[1], a = (t) => {
			e.preventDefault(), t();
		};
		n && r === "z" ? a(() => e.shiftKey ? T.redo() : T.undo()) : n && r === "y" ? a(() => T.redo()) : n && r === "a" ? a(() => {
			ie(O.shapes.map((e, t) => t)), P(O.shapes.length ? [O.shapes.length - 1] : null);
		}) : n && e.altKey && r === "c" ? a(() => V && V.kind !== "group" && zo(V)) : n && e.altKey && r === "v" ? a(Rt) : n && e.altKey && r === "l" ? a(() => It("locked")) : n && e.shiftKey && r === "h" ? a(() => It("hidden")) : n && e.shiftKey && r === "c" ? a(() => void nn()) : n && r === "c" ? a(() => Mt()) : n && r === "x" ? a(() => Mt(!0)) : n && r === "v" && !e.shiftKey ? (Pt.current && clearTimeout(Pt.current), Pt.current = setTimeout(() => {
			Pt.current = null, Nt();
		}, 80)) : n && r === "d" ? a(At) : n && r === "g" ? a(() => e.shiftKey ? Dt() : Et()) : n && (e.code === "BracketRight" || e.code === "BracketLeft") ? a(() => zt(e.code === "BracketRight" ? 1 : -1, e.altKey)) : n && e.key.startsWith("Arrow") ? a(() => T.snapOrbit(e.key === "ArrowLeft" ? -1 : +(e.key === "ArrowRight"), e.key === "ArrowUp" ? 1 : e.key === "ArrowDown" ? -1 : 0)) : !n && i && ud[i] ? a(() => T.setView(ud[i])) : !n && r === "m" ? oe("translate") : !n && r === "t" ? oe("rotate") : !n && r === "r" ? oe("scale") : !n && r === "f" ? T.frameAll(Kt(), { nice: !0 }) : !n && r === "g" ? se((e) => ({
			...e,
			on: !e.on
		})) : !n && r === "p" ? ee() : !n && (e.code === "Space" || e.key === " ") ? a(an) : (e.key === "Delete" || e.key === "Backspace") && (N || I.length) ? a(Ot) : e.key === "Escape" && (P(null), ie([]));
	}, Kt = () => {
		let e = k.current?.getBoundingClientRect();
		return e && e.height > 0 ? e.width / e.height : 1;
	}, qt = async () => {
		let e = Kt(), t = T.document.background.transparent && !T.document.background.picture, r = t ? 1.8 : 1, i = Math.round(u * r), [a, o] = e >= 1 ? [i, Math.round(i / e)] : [Math.round(i * e), i], s = await Cu(await S(T.document, a, o, "image/png", r), T.document.compose);
		if (!t) return s;
		let c = await n(await createImageBitmap(s)), l = document.createElement("canvas");
		return l.width = c.width, l.height = c.height, l.getContext("2d").drawImage(c, 0, 0), c.close(), new Promise((e, t) => l.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be made.")), "image/png"));
	}, H = async (e, t) => {
		pe(e);
		try {
			await t();
		} catch (e) {
			_e(e instanceof Error ? e.message : "That did not work.");
		} finally {
			pe(null);
		}
	}, Jt = (e, t, n) => H("Reading the model…", async () => {
		let { asset: r, warnings: i, takes: a } = await v(e), o = T.addModel(n ? {
			...r,
			...n
		} : r);
		o < 0 ? _e("The design holds 16 imported models; remove one first.") : (it([o], !1), a?.length && (T.playTake([o], a[0]), a[0].seconds >= 1 && ze(Math.min(600, Math.round(a[0].seconds * 100) / 100))), de("shape"), T.frameAll(Kt()), (t || i.length) && _e([t ?? "Imported.", ...i].join(" ")));
	}), Yt = (e) => {
		let t = Xe(e.rotation);
		return [
			0,
			1,
			2
		].reduce((n, r) => n + Math.abs(t[3 + r]) * e.size[r] / 2, 0);
	}, Xt = () => {
		let e = me(T.document).map((e) => e.shape);
		return e.find((e) => e.rig && N && e.id === He(T.document, N)?.id) ?? e.find((e) => e.rig);
	}, Zt = () => H("Drawing the picture…", async () => bd(await qt(), `${we}.png`)), Qt = async () => {
		let e = Kt(), t = T.document.background.transparent && !T.document.background.picture, n = t ? 1200 : 900, [r, i] = e >= 1 ? [n, Math.round(n / e)] : [Math.round(n * e), n];
		return Fn(T.document, {
			width: r,
			height: i,
			frame: t ? 1.6 : 1,
			tones: T.document.style.look === "toon" ? T.document.style.bands : 3,
			onProgress: async (e) => {
				pe(`Tracing the vectors… ${Math.round(e * 100)}%`), await new Promise((e) => setTimeout(e, 0));
			}
		});
	}, tn = () => H("Tracing the vectors…", async () => bd(new Blob([await Qt()], { type: "image/svg+xml" }), `${we}.svg`)), nn = () => H("Copying the picture…", async () => {
		await Vo(qt()), _e("Picture copied: paste it into another app.");
	}), rn = () => H("Tracing the vectors…", async () => {
		await Uo(Qt()), _e("Vectors copied: paste them into a drawing app.");
	});
	G(() => {
		let e = A.current;
		if (!Ae || !e) return;
		let t = performance.now(), n = 0, r = T.document.music, i = r ? new Audio(r.data) : null, a = (e) => (r?.from ?? 0) + e;
		i && (i.currentTime = a(0), i.play().catch(() => void 0));
		let o = (r) => {
			if (i) {
				let e = ((r - t) / 1e3 % Re + Re) % Re;
				Math.abs(i.currentTime - a(e)) > .2 && i.readyState >= 2 && (i.currentTime = a(e)), i.paused && !i.ended && i.play().catch(() => void 0);
			}
			e.showFrame(le(T.document, ((r - t) / 1e3 / Re % 1 + 1) % 1, $e.current.at(r))), n = requestAnimationFrame(o);
		};
		return n = requestAnimationFrame(o), () => {
			cancelAnimationFrame(n), i?.pause(), e.showFrame(null);
		};
	}, [
		Ae,
		Re,
		T
	]);
	let an = () => je((e) => !e), on = (e) => {
		ze(e), T.set("clip", e, "Clip length");
	}, sn = (e, t, n) => {
		ze(t), z(null), H("Making the video…", async () => {
			let r = T.document.music, i = r ? await (async () => {
				let e = await new OfflineAudioContext(2, 1, 48e3).decodeAudioData(await (await fetch(r.data)).arrayBuffer()), t = Math.floor((r.from ?? 0) * e.sampleRate);
				if (!t) return e;
				let n = new AudioBuffer({
					length: Math.max(1, e.length - t),
					numberOfChannels: e.numberOfChannels,
					sampleRate: e.sampleRate
				});
				for (let r = 0; r < e.numberOfChannels; r++) n.copyToChannel(e.getChannelData(r).slice(t), r);
				return n;
			})() : null, a = await h(T.document, {
				music: i,
				kind: e,
				seconds: t,
				size: n,
				aspect: Kt(),
				onProgress: (e) => pe(`Making the video… ${Math.round(e * 100)}%`)
			});
			bd(a.blob, `${we}-${e}.${a.extension}`);
		});
	}, cn = () => i && H("Drawing the picture…", async () => i(await qt(), F(T.document))), ln = O.light, un = O.style, dn = (e) => e.kind === "text" ? "text" : e.kind, fn = (I.length ? I : N?.length === 1 ? [N[0]] : []).some((e) => O.shapes[e] && O.shapes[e].kind !== "group"), mn = (e, t, n) => /* @__PURE__ */ X("li", {
		className: `${_d(t, N) ? "is-on" : ""} ${t.length === 1 && I.includes(t[0]) && !_d(t, N) ? "is-picked" : ""}`,
		style: { paddingLeft: n * 14 },
		children: [
			/* @__PURE__ */ X("button", {
				type: "button",
				className: "gs-m3d__item",
				onClick: (e) => it(t, e.shiftKey || e.metaKey || e.ctrlKey),
				children: [
					e.kind === "group" ? /* @__PURE__ */ Y(Br, { kind: "group" }) : /* @__PURE__ */ Y("span", {
						className: "gs-m3d__dot",
						style: { background: e.color }
					}),
					/* @__PURE__ */ Y("span", {
						className: "gs-m3d__name",
						children: e.name
					}),
					e.combine !== "add" && /* @__PURE__ */ Y("span", {
						className: "gs-m3d__tag",
						children: ed[e.combine]
					})
				]
			}),
			t.length === 1 && /* @__PURE__ */ Y("button", {
				type: "button",
				className: `gs-m3d__icon ${e.locked ? "is-locked" : "gs-m3d__icon--quiet"}`,
				title: e.locked ? "Unlock: it can be picked and dragged again" : "Lock: it cannot be picked or dragged in the view",
				"aria-pressed": !!e.locked,
				onClick: () => T.updateShapeAt(t, { locked: !e.locked }, e.locked ? "Unlock" : "Lock"),
				children: /* @__PURE__ */ Y(Sd, { open: !e.locked })
			}),
			/* @__PURE__ */ Y("button", {
				type: "button",
				className: "gs-m3d__icon",
				title: e.hidden ? "Show" : "Hide",
				onClick: () => T.updateShapeAt(t, { hidden: !e.hidden }, e.hidden ? "Show" : "Hide"),
				children: e.hidden ? "◌" : "●"
			})
		]
	}, e.id);
	return /* @__PURE__ */ X("div", {
		className: "gs-m3d",
		ref: ne,
		tabIndex: -1,
		onKeyDown: Gt,
		onKeyUp: Wt,
		onBlur: (e) => !ne.current?.contains(e.relatedTarget) && Ut(),
		onPaste: Ft,
		children: [
			/* @__PURE__ */ X("header", {
				className: "gs-m3d__top",
				children: [
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						onClick: l,
						children: "← Back"
					}),
					/* @__PURE__ */ Y("strong", {
						className: "gs-m3d__title",
						children: r
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: `gs-m3d__btn ${Ae ? "is-on" : ""}`,
						onClick: an,
						title: re(O) ? "Play the shapes’ motion (Space)" : "Give a shape a motion (in its panel), then play it here (Space)",
						children: Ae ? "■ Stop" : "▶ Play"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: `gs-m3d__btn ${Ge ? "is-on" : ""}`,
						onClick: () => {
							je(!1), Ke((e) => !e);
						},
						title: "Walk through the design in first person, its rules running (set them in the Game tab)",
						children: Ge ? "■ Stop game" : "▶ Play game"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: `gs-m3d__btn ${Ue ? "is-on" : ""}`,
						onClick: () => We((e) => !e),
						title: "Every key of the shapes and the camera along the clip: drag one to move it in time",
						children: "Timeline"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: `gs-m3d__btn ${R === "script" ? "is-on" : ""}`,
						onClick: () => z("script"),
						title: "Change the design with a Python script",
						children: "Script"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: `gs-m3d__btn ${Me ? "is-on" : ""}`,
						onClick: () => Ne(!0),
						title: "Tutorials: beginner to advanced, for 3D and voices",
						children: "Learn"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: `gs-m3d__btn ${Pe ? "is-on" : ""}`,
						onClick: () => Fe((e) => !e),
						title: "Ask where a button is or how to do something: the answer lights up what to press",
						children: "Ask"
					}),
					/* @__PURE__ */ Y("div", {
						className: "gs-m3d__group",
						role: "group",
						"aria-label": "Gizmo",
						children: dd.map((e) => /* @__PURE__ */ X("button", {
							type: "button",
							className: `gs-m3d__btn ${ae === e.mode ? "is-on" : ""}`,
							onClick: () => oe(e.mode),
							title: `${e.label} (${e.key})`,
							children: [
								e.label,
								" ",
								/* @__PURE__ */ Y("kbd", { children: e.key })
							]
						}, e.mode))
					}),
					/* @__PURE__ */ X("select", {
						className: "gs-m3d__select",
						"aria-label": "View",
						value: "",
						onChange: (e) => {
							e.target.value === "frame" ? T.frameAll(Kt(), { nice: !0 }) : e.target.value === "perf" ? ee() : e.target.value && T.setView(e.target.value), e.currentTarget.blur();
						},
						children: [
							/* @__PURE__ */ Y("option", {
								value: "",
								children: "View…"
							}),
							Object.keys(ld).map((e) => /* @__PURE__ */ Y("option", {
								value: e,
								children: ld[e]
							}, e)),
							/* @__PURE__ */ Y("option", {
								value: "frame",
								children: "Fit all (F)"
							}),
							/* @__PURE__ */ Y("option", {
								value: "perf",
								children: j ? "Hide performance (P)" : "Show performance (P)"
							})
						]
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						title: "Everything in view: the camera backs off just enough to fit every shape's box, from a good angle (F)",
						onClick: () => T.frameAll(Kt(), { nice: !0 }),
						children: "Fit all"
					}),
					/* @__PURE__ */ X("div", {
						className: "gs-m3d__group",
						role: "group",
						"aria-label": "Grid",
						children: [
							/* @__PURE__ */ X("button", {
								type: "button",
								className: `gs-m3d__btn ${L.on ? "is-on" : ""}`,
								onClick: () => se((e) => ({
									...e,
									on: !e.on
								})),
								title: "Show the grid on the ground (G); it is never in saved pictures or video",
								children: ["Grid ", /* @__PURE__ */ Y("kbd", { children: "G" })]
							}),
							/* @__PURE__ */ Y("input", {
								className: "gs-m3d__cell",
								type: "number",
								list: "gs-m3d-cells",
								min: .05,
								max: 10,
								step: .05,
								value: L.size,
								disabled: !L.on,
								"aria-label": "Grid cell size",
								title: "Grid cell size, in the same units as Size and Place (the starter box is 1 across)",
								onChange: (e) => {
									let t = Number(e.target.value);
									Number.isFinite(t) && t > 0 && se((e) => ({
										...e,
										size: hd(t)
									}));
								}
							}),
							/* @__PURE__ */ Y("datalist", {
								id: "gs-m3d-cells",
								children: md.map((e) => /* @__PURE__ */ Y("option", { value: e }, e))
							}),
							/* @__PURE__ */ Y("button", {
								type: "button",
								className: `gs-m3d__btn ${L.on && L.snap ? "is-on" : ""}`,
								disabled: !L.on,
								onClick: () => se((e) => ({
									...e,
									snap: !e.snap
								})),
								title: "Snap: moving goes in whole grid cells, turning in 15° steps",
								children: "Snap"
							})
						]
					}),
					/* @__PURE__ */ Y("span", { className: "gs-m3d__spacer" }),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						disabled: !D.canUndo,
						onClick: () => T.undo(),
						title: D.undoLabel ? `Undo ${D.undoLabel}` : "Undo",
						children: "Undo"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						disabled: !D.canRedo,
						onClick: () => T.redo(),
						title: D.redoLabel ? `Redo ${D.redoLabel}` : "Redo",
						children: "Redo"
					}),
					/* @__PURE__ */ X("select", {
						className: "gs-m3d__select",
						"aria-label": "Save",
						value: "",
						disabled: !!fe,
						onChange: (e) => {
							let t = e.target.value;
							e.currentTarget.blur(), t === "design" ? bd(new Blob([Oe(T.document)], { type: "application/json" }), `${we}.json`) : t === "png" ? Zt() : t === "svg" ? tn() : t === "copy-png" ? nn() : t === "copy-svg" ? rn() : t === "video" ? z("video") : t === "sequence" ? z("sequence") : t === "model" ? z("export") : t === "render" && z("render");
						},
						children: [
							/* @__PURE__ */ Y("option", {
								value: "",
								children: "Save…"
							}),
							/* @__PURE__ */ Y("option", {
								value: "design",
								children: "Design (.json), to open again"
							}),
							/* @__PURE__ */ Y("option", {
								value: "png",
								children: "Picture (PNG)"
							}),
							/* @__PURE__ */ Y("option", {
								value: "svg",
								children: "Vectors (SVG)"
							}),
							/* @__PURE__ */ Y("option", {
								value: "video",
								children: "Video…"
							}),
							/* @__PURE__ */ Y("option", {
								value: "sequence",
								children: "Video editor (clips, titles, music)…"
							}),
							/* @__PURE__ */ Y("option", {
								value: "render",
								children: "Photo-real render…"
							}),
							/* @__PURE__ */ Y("option", {
								value: "model",
								children: "3D model (GLB, OBJ, STL, VRM)…"
							}),
							/* @__PURE__ */ Y("option", {
								value: "copy-png",
								children: "Copy the picture (Ctrl Shift C)"
							}),
							/* @__PURE__ */ Y("option", {
								value: "copy-svg",
								children: "Copy as vectors (SVG)"
							})
						]
					}),
					m?.map((e) => /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn",
						title: e.title,
						onClick: () => e.run(F(T.document)),
						children: e.label
					}, e.label)),
					i && /* @__PURE__ */ Y("button", {
						type: "button",
						className: "gs-m3d__btn gs-m3d__btn--primary",
						disabled: !!fe,
						onClick: () => void cn(),
						children: a
					})
				]
			}),
			/* @__PURE__ */ X("div", {
				className: "gs-m3d__body",
				children: [
					/* @__PURE__ */ X("aside", {
						className: "gs-m3d__left",
						"aria-label": "Shapes",
						children: [
							/* @__PURE__ */ Y("h3", { children: "Add a shape" }),
							/* @__PURE__ */ X("div", {
								className: "gs-m3d__add",
								children: [
									Vt.map((e) => /* @__PURE__ */ X("button", {
										type: "button",
										onClick: () => at(e),
										title: `Add a ${ot[e].toLowerCase()}`,
										children: [/* @__PURE__ */ Y(Br, { kind: e }), /* @__PURE__ */ Y("span", { children: ot[e] })]
									}, e)),
									/* @__PURE__ */ X("button", {
										type: "button",
										onClick: () => z("outline"),
										title: "Push out an outline: a star, a heart, or one you draw",
										children: [/* @__PURE__ */ Y(Br, { kind: "extrude" }), /* @__PURE__ */ Y("span", { children: "Outline" })]
									}),
									/* @__PURE__ */ X("button", {
										type: "button",
										onClick: () => z("text"),
										title: "3D text",
										children: [/* @__PURE__ */ Y(Br, { kind: "text" }), /* @__PURE__ */ Y("span", { children: "Text" })]
									}),
									/* @__PURE__ */ X("button", {
										type: "button",
										onClick: () => z("revolve"),
										title: "Spin an outline round: a vase, a bottle, a cup, a display stand",
										children: [/* @__PURE__ */ Y(Br, { kind: "revolve" }), /* @__PURE__ */ Y("span", { children: "Revolve" })]
									}),
									/* @__PURE__ */ X("button", {
										type: "button",
										onClick: () => z("ad"),
										title: "A 3D ad: the product's photo, a headline, the price and your logo",
										children: [/* @__PURE__ */ Y(Br, { kind: "ad" }), /* @__PURE__ */ Y("span", { children: "Ad" })]
									}),
									/* @__PURE__ */ X("button", {
										type: "button",
										onClick: () => Ee.current?.click(),
										title: "A logo or drawing from an SVG file: one 3D piece per colour",
										children: [/* @__PURE__ */ Y(Br, { kind: "svg" }), /* @__PURE__ */ Y("span", { children: "SVG logo" })]
									}),
									/* @__PURE__ */ X("button", {
										type: "button",
										onClick: () => De.current?.click(),
										title: "A picture's shape pushed out: a logo, a drawing or a cut-out (PNG, JPEG, WebP). See-through or plain backgrounds both work",
										children: [/* @__PURE__ */ Y(Br, { kind: "extrude" }), /* @__PURE__ */ Y("span", { children: "Picture" })]
									}),
									/* @__PURE__ */ X("button", {
										type: "button",
										onClick: () => Te.current?.click(),
										title: "Import a 3D model: GLB, glTF, FBX, OBJ, STL, PLY or 3MF",
										children: [/* @__PURE__ */ Y(Br, { kind: "mesh" }), /* @__PURE__ */ Y("span", { children: "Import" })]
									}),
									/* @__PURE__ */ X("button", {
										type: "button",
										onClick: () => z("photos"),
										title: "A 3D model of the figure, made from its photos on this computer",
										children: [/* @__PURE__ */ Y(Br, { kind: "mesh" }), /* @__PURE__ */ Y("span", { children: "From photos" })]
									}),
									/* @__PURE__ */ X("button", {
										type: "button",
										onClick: () => {
											ye(null), z("avatar");
										},
										title: "A character, anime, low-poly or realistic: pick its outfit, face, eyes, mouth, hair, shape and colours",
										children: [/* @__PURE__ */ Y(Br, { kind: "capsule" }), /* @__PURE__ */ Y("span", { children: "Character" })]
									}),
									w && /* @__PURE__ */ X("button", {
										type: "button",
										onClick: () => z("library"),
										title: "Ready-made models, free for any use: anime characters, people, animals, furniture, plants, food, game pieces",
										children: [/* @__PURE__ */ Y(Br, { kind: "mesh" }), /* @__PURE__ */ Y("span", { children: "Library" })]
									}),
									w && /* @__PURE__ */ X("button", {
										type: "button",
										onClick: () => z("scenes"),
										title: "Start from a ready-made scene: a figure shelf, an anime cast, a farm, a game level and more",
										children: [/* @__PURE__ */ Y(Br, { kind: "box" }), /* @__PURE__ */ Y("span", { children: "Scenes" })]
									}),
									/* @__PURE__ */ Y("input", {
										ref: De,
										type: "file",
										accept: "image/png,image/jpeg,image/webp,image/gif",
										hidden: !0,
										onChange: (e) => {
											let t = e.target.files?.[0];
											e.target.value = "", t && ut(t);
										}
									}),
									/* @__PURE__ */ Y("input", {
										ref: Ee,
										type: "file",
										accept: ".svg,image/svg+xml",
										hidden: !0,
										onChange: (e) => {
											let t = e.target.files?.[0];
											e.target.value = "", t && yt(t);
										}
									}),
									/* @__PURE__ */ Y("input", {
										ref: Te,
										type: "file",
										multiple: !0,
										accept: `${b},.json,application/json`,
										hidden: !0,
										onChange: (e) => {
											let t = [...e.target.files ?? []];
											e.target.value = "", t.length && Tt(t);
										}
									})
								]
							}),
							/* @__PURE__ */ Y(o, { id: "m3dAdd" }),
							/* @__PURE__ */ Y("h3", { children: "Shapes" }),
							/* @__PURE__ */ Y("ul", {
								className: "gs-m3d__list",
								children: O.shapes.map((e, t) => [mn(e, [t], 0), ...e.kind === "group" ? (e.children ?? []).map((e, n) => mn(e, [t, n], 1)) : []])
							}),
							/* @__PURE__ */ X("div", {
								className: "gs-m3d__listtools",
								children: [
									N && /* @__PURE__ */ X(J, { children: [
										/* @__PURE__ */ Y("button", {
											type: "button",
											onClick: () => P(T.moveShapeAt(N, -1)),
											title: "Earlier: joined before the ones below",
											children: "↑"
										}),
										/* @__PURE__ */ Y("button", {
											type: "button",
											onClick: () => P(T.moveShapeAt(N, 1)),
											title: "Later: joined onto the ones above",
											children: "↓"
										}),
										/* @__PURE__ */ Y("button", {
											type: "button",
											onClick: At,
											title: "Duplicate (Ctrl D)",
											children: "Duplicate"
										}),
										/* @__PURE__ */ Y("button", {
											type: "button",
											onClick: Ot,
											title: "Delete",
											children: "Delete"
										})
									] }),
									fn && /* @__PURE__ */ X("button", {
										type: "button",
										onClick: Et,
										title: "Group the picked shapes (Ctrl G); Shift-click to pick several",
										children: ["Group", I.length > 1 ? ` ${I.length}` : ""]
									}),
									V?.kind === "group" && /* @__PURE__ */ Y("button", {
										type: "button",
										onClick: Dt,
										title: "Ungroup (Ctrl Shift G)",
										children: "Ungroup"
									})
								]
							}),
							/* @__PURE__ */ Y(o, { id: "m3dShapes" }),
							/* @__PURE__ */ Y(o, { id: "m3dGroup" })
						]
					}),
					/* @__PURE__ */ X("main", {
						className: `gs-m3d__stage ${B ? "is-dropping" : ""}`,
						onDragOver: (e) => {
							e.dataTransfer.types.includes("Files") && (e.preventDefault(), ke(!0));
						},
						onDragLeave: () => ke(!1),
						onDrop: (e) => {
							e.preventDefault(), ke(!1);
							let t = [...e.dataTransfer.files];
							t.length && Tt(t);
						},
						children: [
							/* @__PURE__ */ Y("div", {
								className: "gs-m3d__viewport",
								ref: k
							}),
							j && /* @__PURE__ */ Y(Nc, { viewport: te }),
							Ge && A.current && /* @__PURE__ */ Y(Jr, {
								editor: T,
								viewport: A.current,
								onStop: () => Ke(!1),
								project: qe.api
							}),
							Ue ? /* @__PURE__ */ Y(Yc, {
								editor: T,
								doc: O,
								seconds: Re,
								time: Be,
								onTime: Ve,
								onPick: (e) => it(e, !1),
								selected: N,
								onSeconds: on
							}) : /* @__PURE__ */ Y("div", {
								className: "gs-m3d__hint",
								children: /* @__PURE__ */ Y(o, { id: V ? "m3dGizmo" : "m3dView" })
							}),
							fe && /* @__PURE__ */ X("div", {
								className: "gs-m3d__busy",
								role: "status",
								children: [
									/* @__PURE__ */ Y("span", {
										className: "gs-m3d__spin",
										"aria-hidden": "true"
									}),
									" ",
									fe
								]
							}),
							he && /* @__PURE__ */ X("div", {
								className: "gs-m3d__problem",
								role: "alert",
								children: [he, /* @__PURE__ */ Y("button", {
									type: "button",
									onClick: () => _e(null),
									children: "Dismiss"
								})]
							})
						]
					}),
					/* @__PURE__ */ X("aside", {
						className: "gs-m3d__right",
						"aria-label": "Settings",
						children: [
							/* @__PURE__ */ X("nav", {
								className: "gs-m3d__tabs",
								role: "tablist",
								children: [
									/* @__PURE__ */ Y("button", {
										type: "button",
										role: "tab",
										"aria-selected": ce === "shape",
										className: ce === "shape" ? "is-on" : "",
										onClick: () => de("shape"),
										children: "Shape"
									}),
									/* @__PURE__ */ Y("button", {
										type: "button",
										role: "tab",
										"aria-selected": ce === "scene",
										className: ce === "scene" ? "is-on" : "",
										onClick: () => de("scene"),
										children: "Light and look"
									}),
									/* @__PURE__ */ Y("button", {
										type: "button",
										role: "tab",
										"aria-selected": ce === "game",
										className: ce === "game" ? "is-on" : "",
										onClick: () => de("game"),
										children: "Game"
									})
								]
							}),
							ce === "shape" && (I.length > 1 ? /* @__PURE__ */ Y(od, {
								editor: T,
								doc: O,
								picked: I,
								onDuplicate: At,
								onDelete: Ot,
								onGroup: Et,
								onJoin: I.every((e) => O.shapes[e]?.kind === "mesh") ? () => void ct() : void 0,
								onModelWithShape: I.length === 2 && I.filter((e) => O.shapes[e]?.kind === "mesh").length === 1 && I.every((e) => O.shapes[e]?.kind !== "group") ? (e) => void lt(e) : void 0,
								physics: /* @__PURE__ */ Y(Xl, {
									editor: T,
									doc: O,
									picked: I,
									seconds: Re
								}),
								motion: /* @__PURE__ */ Y(Ic, {
									editor: T,
									items: I.flatMap((e) => O.shapes[e] ? [{
										ref: [e],
										shape: O.shapes[e]
									}] : []),
									playing: Ae,
									onPlay: an
								})
							}) : V ? /* @__PURE__ */ X("div", {
								className: "gs-m3d__panel",
								children: [
									/* @__PURE__ */ Y("input", {
										className: "gs-m3d__rename",
										value: V.name,
										"aria-label": "Shape name",
										onChange: (e) => et({ name: e.target.value }, "Rename")
									}),
									(V.locked || N?.length === 2 && O.shapes[N[0]]?.locked) && /* @__PURE__ */ Y("p", {
										className: "gs-m3d__note",
										children: "Locked: it is not picked or dragged in the view. Unlock it in the list to move it there."
									}),
									V.kind === "mesh" && /* @__PURE__ */ X("section", { children: [
										/* @__PURE__ */ Y("h4", { children: "Imported model" }),
										/* @__PURE__ */ X("p", {
											className: "gs-m3d__meta",
											children: [
												O.assets?.[V.asset ?? ""]?.name ?? "Model",
												" ·",
												" ",
												(O.assets?.[V.asset ?? ""]?.triangles ?? 0).toLocaleString("en"),
												" triangles"
											]
										}),
										/* @__PURE__ */ Y(W, {
											label: "Colours",
											value: V.ownColors === !1 ? "one" : "own",
											options: ["own", "one"],
											labels: {
												own: "Its own",
												one: "One colour"
											},
											onChange: (e) => et({ ownColors: e === "own" }, e === "own" ? "Own colours" : "One colour")
										}),
										/* @__PURE__ */ X("div", {
											className: "gs-m3d__row",
											children: [/* @__PURE__ */ Y("button", {
												type: "button",
												className: "gs-m3d__btn",
												title: "For a model made lying down (z up): turns it a quarter round to stand on the ground",
												onClick: () => {
													let e = [
														V.rotation[0] === -90 ? 0 : -90,
														V.rotation[1],
														V.rotation[2]
													];
													et({
														rotation: e,
														position: [
															V.position[0],
															Yt({
																...V,
																rotation: e
															}),
															V.position[2]
														]
													}, "Stand it up");
												},
												children: "Stand it up"
											}), /* @__PURE__ */ Y("button", {
												type: "button",
												className: "gs-m3d__btn",
												onClick: () => et({ position: [
													V.position[0],
													Yt(V),
													V.position[2]
												] }, "Put on the ground"),
												children: "Put on the ground"
											})]
										}),
										/* @__PURE__ */ Y(o, { id: "m3dImport" })
									] }),
									N && /* @__PURE__ */ Y(hu, {
										editor: T,
										doc: O,
										at: N,
										shape: V,
										run: H
									}),
									V.kind === "mesh" && N && /* @__PURE__ */ Y(Ku, {
										editor: T,
										doc: O,
										at: N,
										shape: V,
										base: w,
										run: H,
										onEdit: (e) => {
											ye({
												at: N,
												tab: e
											}), z("avatar");
										}
									}),
									V.kind === "mesh" && N && /* @__PURE__ */ Y(tl, {
										editor: T,
										doc: O,
										at: N,
										shape: V,
										run: H
									}),
									V.kind === "mesh" && N && /* @__PURE__ */ Y(Hl, {
										editor: T,
										doc: O,
										at: N,
										shape: V,
										viewRef: A,
										stageRef: k,
										run: H
									}),
									V.kind === "mesh" && N && /* @__PURE__ */ Y(Ul, {
										editor: T,
										doc: O,
										at: N,
										shape: V,
										viewRef: A,
										stageRef: k
									}),
									V.kind === "mesh" && N && /* @__PURE__ */ Y(Yl, {
										editor: T,
										doc: O,
										at: N,
										shape: V
									}),
									V.kind === "mesh" && N && /* @__PURE__ */ Y(Gl, {
										editor: T,
										doc: O,
										at: N,
										shape: V,
										seconds: Re,
										onPlay: () => je(!0),
										onClip: ze
									}),
									V.kind === "mesh" && N && /* @__PURE__ */ Y(su, {
										editor: T,
										doc: O,
										at: N,
										shape: V,
										run: H
									}),
									V.kind === "mesh" && N && /* @__PURE__ */ Y(Vl, {
										editor: T,
										doc: O,
										at: N,
										shape: V,
										viewRef: A,
										stageRef: k
									}, `m${N.join(".")}`),
									V.kind === "mesh" && N && /* @__PURE__ */ Y(il, {
										editor: T,
										doc: O,
										at: N,
										shape: V,
										viewRef: A,
										stageRef: k
									}),
									V.kind === "mesh" && N && /* @__PURE__ */ Y(bl, {
										editor: T,
										doc: O,
										at: N,
										shape: V,
										viewRef: A,
										stageRef: k
									}, N.join(".")),
									/* @__PURE__ */ X("section", { children: [/* @__PURE__ */ Y("h4", { children: V.kind === "group" ? "How the group joins" : "Combine" }), V.kind === "mesh" ? /* @__PURE__ */ Y("p", {
										className: "gs-m3d__meta",
										children: "An imported model is always added as it is: Cut and Blend work between the shapes you build, not on a model."
									}) : /* @__PURE__ */ X(J, { children: [
										/* @__PURE__ */ Y(W, {
											label: "Combine",
											value: V.combine,
											options: Lt,
											labels: ed,
											onChange: (e) => et({ combine: e }, ed[e])
										}),
										/* @__PURE__ */ Y(U, {
											label: "Blend",
											value: V.blend,
											min: 0,
											max: 1,
											step: .01,
											format: (e) => `${Math.round(e * 100)}%`,
											onBegin: tt("Blend"),
											onChange: (e) => et({ blend: e }),
											onEnd: nt
										}),
										/* @__PURE__ */ Y(o, { id: V.kind === "group" ? "m3dGroup" : "m3dCombine" })
									] })] }),
									N && V.kind !== "group" && V.kind !== "mesh" && /* @__PURE__ */ Y(Xc, {
										editor: T,
										at: N,
										shape: V
									}),
									N && V.kind !== "group" && V.kind !== "mesh" && /* @__PURE__ */ Y(vu, {
										editor: T,
										doc: O,
										at: N,
										shape: V
									}),
									N && /* @__PURE__ */ Y(Ic, {
										editor: T,
										items: [{
											ref: N,
											shape: V
										}],
										playing: Ae,
										onPlay: an
									}),
									N && /* @__PURE__ */ Y(zc, {
										editor: T,
										target: {
											kind: "shape",
											at: N,
											shape: V
										},
										seconds: Re,
										onSeconds: on,
										time: Be,
										onTime: Ve,
										playing: Ae,
										onPlay: an
									}),
									N && /* @__PURE__ */ Y(Zu, {
										editor: T,
										at: N,
										shape: V,
										playing: Ae,
										onPlay: an
									}),
									N && N.length === 1 && /* @__PURE__ */ Y(Xl, {
										editor: T,
										doc: O,
										picked: [N[0]],
										seconds: Re
									}),
									N && /* @__PURE__ */ X("label", {
										className: "gs-m3d__field",
										children: [/* @__PURE__ */ Y("span", { children: "Looks at" }), /* @__PURE__ */ X("select", {
											value: V.lookAt ?? "",
											onChange: (e) => et({ lookAt: e.target.value || void 0 }, "Looks at"),
											children: [
												/* @__PURE__ */ Y("option", {
													value: "",
													children: "Nothing (turns as set)"
												}),
												/* @__PURE__ */ Y("option", {
													value: "camera",
													children: "The camera"
												}),
												O.shapes.flatMap((e) => [e, ...e.children ?? []]).filter((e) => e.id !== V.id && e.kind !== "group").map((e) => /* @__PURE__ */ Y("option", {
													value: e.id,
													children: e.name
												}, e.id))
											]
										})]
									}),
									dn(V) === "text" && V.text && /* @__PURE__ */ X("section", { children: [
										/* @__PURE__ */ Y("h4", { children: "Text" }),
										/* @__PURE__ */ Y("p", {
											className: "gs-m3d__textpreview",
											style: {
												fontFamily: `"${V.text.font}", sans-serif`,
												fontWeight: V.text.weight,
												whiteSpace: "pre",
												textAlign: V.text.align ?? "center"
											},
											children: V.text.value
										}),
										/* @__PURE__ */ Y("button", {
											type: "button",
											className: "gs-m3d__btn",
											onClick: () => z("edit-text"),
											children: "Change text or font…"
										}),
										/* @__PURE__ */ Y(o, { id: "m3dText" })
									] }),
									V.kind === "extrude" && /* @__PURE__ */ X("section", { children: [
										/* @__PURE__ */ Y("h4", { children: "Outline" }),
										V.pen ? /* @__PURE__ */ Y("button", {
											type: "button",
											className: "gs-m3d__btn",
											onClick: () => z("edit-outline"),
											children: "Edit points…"
										}) : /* @__PURE__ */ Y("p", {
											className: "gs-m3d__note",
											children: "Made from a picture or a logo, so it has no pen points to edit."
										}),
										/* @__PURE__ */ Y(o, { id: "m3dPen" })
									] }),
									V.kind === "revolve" && /* @__PURE__ */ X("section", { children: [
										/* @__PURE__ */ Y("h4", { children: "Spun outline" }),
										/* @__PURE__ */ Y(U, {
											label: "Round by",
											value: V.revolve?.sweep ?? 360,
											min: 10,
											max: 360,
											step: 5,
											format: (e) => e >= 360 ? "All the way" : `${Math.round(e)}°`,
											onBegin: tt("Sweep"),
											onChange: (e) => et({ revolve: {
												offset: V.revolve?.offset ?? 0,
												sweep: e
											} }),
											onEnd: nt
										}),
										/* @__PURE__ */ Y(U, {
											label: "Hole in the middle",
											value: V.revolve?.offset ?? 0,
											min: 0,
											max: .9,
											step: .01,
											format: (e) => e === 0 ? "None" : `${Math.round(e * 100)}%`,
											onBegin: tt("Hole"),
											onChange: (e) => et({ revolve: {
												sweep: V.revolve?.sweep ?? 360,
												offset: e
											} }),
											onEnd: nt
										}),
										/* @__PURE__ */ X("div", {
											className: "gs-m3d__row",
											children: [V.pen && /* @__PURE__ */ Y("button", {
												type: "button",
												className: "gs-m3d__btn",
												onClick: () => z("edit-outline"),
												children: "Edit points…"
											}), /* @__PURE__ */ Y("button", {
												type: "button",
												className: "gs-m3d__btn",
												onClick: () => z("change-revolve"),
												children: "Change profile…"
											})]
										}),
										/* @__PURE__ */ Y(o, { id: "m3dRevolve" })
									] }),
									V.kind !== "group" && V.kind !== "mesh" && /* @__PURE__ */ Y(Oa, {
										shape: V,
										update: et,
										gesture: tt,
										end: nt
									}),
									V.kind !== "group" && /* @__PURE__ */ X(J, { children: [(V.kind !== "mesh" || V.ownColors === !1) && /* @__PURE__ */ X("section", { children: [
										/* @__PURE__ */ Y("h4", { children: "Colour and finish" }),
										/* @__PURE__ */ X("div", {
											className: "gs-m3d__swatches",
											children: [nd.map((e) => /* @__PURE__ */ Y("button", {
												type: "button",
												style: { background: e },
												className: V.color === e ? "is-on" : "",
												"aria-label": `Colour ${e}`,
												onClick: () => et({ color: e }, "Colour")
											}, e)), /* @__PURE__ */ Y("input", {
												type: "color",
												value: V.color,
												"aria-label": "Any colour",
												onChange: (e) => et({ color: e.target.value }, "Colour")
											})]
										}),
										/* @__PURE__ */ Y(W, {
											label: "Finish",
											value: V.finish,
											options: _t,
											labels: td,
											onChange: (e) => et({ finish: e }, td[e])
										}),
										/* @__PURE__ */ X("div", {
											className: "gs-m3d__row",
											children: [/* @__PURE__ */ Y("button", {
												type: "button",
												className: "gs-m3d__btn",
												onClick: () => zo(V),
												title: "Ctrl Alt C",
												children: "Copy look"
											}), /* @__PURE__ */ Y("button", {
												type: "button",
												className: "gs-m3d__btn",
												disabled: !Bo(),
												onClick: Rt,
												title: "Ctrl Alt V",
												children: "Paste look"
											})]
										}),
										/* @__PURE__ */ Y(o, { id: "m3dMaterial" })
									] }), /* @__PURE__ */ X("section", { children: [
										/* @__PURE__ */ Y("h4", { children: "Size and place" }),
										/* @__PURE__ */ Y(Lr, {
											label: V.outline ? "W, H, depth" : "Size",
											value: V.size,
											step: .05,
											min: .01,
											onChange: (e) => et({ size: e }, "Size")
										}),
										/* @__PURE__ */ Y(Lr, {
											label: "Place",
											value: V.position,
											step: .05,
											onChange: (e) => et({ position: e }, "Move")
										}),
										/* @__PURE__ */ Y(Lr, {
											label: "Turn",
											value: V.rotation,
											step: 5,
											onChange: (e) => et({ rotation: e }, "Turn")
										}),
										N?.length === 1 && /* @__PURE__ */ X("div", {
											className: "gs-m3d__row",
											children: [/* @__PURE__ */ Y("button", {
												type: "button",
												className: "gs-m3d__btn",
												onClick: () => T.toGround([N[0]]),
												children: "On the ground"
											}), /* @__PURE__ */ Y("button", {
												type: "button",
												className: "gs-m3d__btn",
												title: "To the middle of the scene, left to right and front to back",
												onClick: () => {
													T.begin("To the middle"), T.align([N[0]], 0, "mid"), T.align([N[0]], 2, "mid"), T.commit();
												},
												children: "To the middle"
											})]
										}),
										V.kind !== "sphere" && V.kind !== "torus" && V.kind !== "capsule" && V.kind !== "mesh" && V.kind !== "revolve" && /* @__PURE__ */ Y(U, {
											label: V.outline ? "Bevel" : "Rounding",
											value: V.round,
											min: 0,
											max: .5,
											step: .01,
											format: (e) => `${Math.round(e * 200)}%`,
											onBegin: tt("Rounding"),
											onChange: (e) => et({ round: e }),
											onEnd: nt
										}),
										V.kind === "torus" && /* @__PURE__ */ Y(U, {
											label: "Tube",
											value: V.thickness,
											min: .05,
											max: .5,
											step: .01,
											format: (e) => `${Math.round(e * 100)}%`,
											onBegin: tt("Tube"),
											onChange: (e) => et({ thickness: e }),
											onEnd: nt
										}),
										/* @__PURE__ */ Y(o, { id: V.outline ? "m3dOutlineShape" : "m3dSize" })
									] })] })
								]
							}) : /* @__PURE__ */ X("div", {
								className: "gs-m3d__panel",
								children: [/* @__PURE__ */ Y("p", {
									className: "gs-m3d__empty",
									children: "Pick a shape in the view or the list to change it, or add one on the left."
								}), /* @__PURE__ */ Y(o, { id: "m3dView" })]
							})),
							ce === "game" && /* @__PURE__ */ Y(_s, {
								editor: T,
								doc: O,
								selected: V ?? null,
								onPlay: () => {
									je(!1), Ke(!0);
								},
								project: qe.api,
								projectPanel: /* @__PURE__ */ Y(Cc, {
									api: qe.api,
									libraryUrl: w,
									onStart: qe.start,
									onOpen: (e) => void H("Opening the project…", async () => qe.load(await e.text())),
									run: H,
									editor: T,
									selected: N,
									shape: V ?? null,
									takePicture: qt
								})
							}),
							ce === "scene" && /* @__PURE__ */ X("div", {
								className: "gs-m3d__panel",
								children: [
									/* @__PURE__ */ X("section", { children: [
										/* @__PURE__ */ Y("h4", { children: "Look" }),
										/* @__PURE__ */ Y(W, {
											label: "Look",
											value: un.look,
											options: kt,
											labels: cd,
											onChange: (e) => T.setSetting("style", "look", e, `${cd[e]} look`)
										}),
										un.look === "pixel" && /* @__PURE__ */ Y(U, {
											label: "Pixel size",
											value: un.pixel,
											min: 3,
											max: 40,
											step: 1,
											format: (e) => `${e}`,
											onBegin: tt("Pixel size"),
											onChange: (e) => T.setSetting("style", "pixel", e),
											onEnd: nt
										}),
										(un.look === "toon" || un.look === "pixel") && /* @__PURE__ */ Y(U, {
											label: "Steps of light",
											value: un.bands,
											min: 2,
											max: 6,
											step: 1,
											onBegin: tt("Steps of light"),
											onChange: (e) => T.setSetting("style", "bands", e),
											onEnd: nt
										}),
										/* @__PURE__ */ Y(o, { id: "m3dLook" })
									] }),
									/* @__PURE__ */ X("section", { children: [
										/* @__PURE__ */ Y("h4", { children: "Outline" }),
										/* @__PURE__ */ Y(U, {
											label: "Width",
											value: un.outline,
											min: 0,
											max: 12,
											step: .5,
											format: (e) => e ? `${e} px` : "None",
											onBegin: tt("Outline"),
											onChange: (e) => T.setSetting("style", "outline", e),
											onEnd: nt
										}),
										un.outline > 0 && /* @__PURE__ */ X("label", {
											className: "gs-m3d__colour",
											children: [
												/* @__PURE__ */ Y("input", {
													type: "color",
													value: un.outlineColor,
													onChange: (e) => T.setSetting("style", "outlineColor", e.target.value, "Outline colour")
												}),
												" ",
												"Outline colour"
											]
										}),
										/* @__PURE__ */ Y(o, { id: "m3dOutline" })
									] }),
									/* @__PURE__ */ X("section", { children: [
										/* @__PURE__ */ Y("h4", { children: "Light" }),
										/* @__PURE__ */ Y(U, {
											label: "Around",
											value: ln.azimuth,
											min: -180,
											max: 180,
											step: 1,
											format: (e) => `${e}°`,
											onBegin: tt("Light around"),
											onChange: (e) => T.setSetting("light", "azimuth", e),
											onEnd: nt
										}),
										/* @__PURE__ */ Y(U, {
											label: "Height",
											value: ln.elevation,
											min: 0,
											max: 90,
											step: 1,
											format: (e) => `${e}°`,
											onBegin: tt("Light height"),
											onChange: (e) => T.setSetting("light", "elevation", e),
											onEnd: nt
										}),
										/* @__PURE__ */ Y(U, {
											label: "Brightness",
											value: ln.intensity,
											min: 0,
											max: 3,
											step: .05,
											onBegin: tt("Brightness"),
											onChange: (e) => T.setSetting("light", "intensity", e),
											onEnd: nt
										}),
										/* @__PURE__ */ Y(U, {
											label: "Fill",
											value: ln.ambient,
											min: 0,
											max: 1,
											step: .01,
											format: (e) => `${Math.round(e * 100)}%`,
											onBegin: tt("Fill light"),
											onChange: (e) => T.setSetting("light", "ambient", e),
											onEnd: nt
										}),
										/* @__PURE__ */ X("label", {
											className: "gs-m3d__check",
											children: [
												/* @__PURE__ */ Y("input", {
													type: "checkbox",
													checked: ln.shadows,
													onChange: (e) => T.setSetting("light", "shadows", e.target.checked, "Shadows")
												}),
												" ",
												"Shadows"
											]
										}),
										/* @__PURE__ */ X("label", {
											className: "gs-m3d__colour",
											children: [
												/* @__PURE__ */ Y("input", {
													type: "color",
													value: ln.color,
													onChange: (e) => T.setSetting("light", "color", e.target.value, "Light colour")
												}),
												" ",
												"Light colour"
											]
										}),
										/* @__PURE__ */ Y(o, { id: "m3dLight" })
									] }),
									/* @__PURE__ */ Y(Na, {
										editor: T,
										light: ln,
										gesture: tt,
										end: nt
									}),
									/* @__PURE__ */ Y(Yu, {
										editor: T,
										doc: O
									}),
									/* @__PURE__ */ Y(ru, {
										editor: T,
										doc: O,
										picked: N?.[0] ?? null
									}),
									/* @__PURE__ */ Y(nu, {
										editor: T,
										doc: O,
										picked: N?.[0] ?? null,
										run: H
									}),
									/* @__PURE__ */ Y(Ou, {
										editor: T,
										doc: O,
										viewRef: A
									}),
									/* @__PURE__ */ X("section", { children: [
										/* @__PURE__ */ Y("h4", { children: "Floor and background" }),
										/* @__PURE__ */ X("label", {
											className: "gs-m3d__check",
											children: [
												/* @__PURE__ */ Y("input", {
													type: "checkbox",
													checked: O.ground.on,
													onChange: (e) => T.setSetting("ground", "on", e.target.checked, "Floor")
												}),
												" ",
												"Floor shadow"
											]
										}),
										O.ground.on && /* @__PURE__ */ Y(U, {
											label: "Shadow strength",
											value: O.ground.shadow,
											min: 0,
											max: 1,
											step: .01,
											format: (e) => `${Math.round(e * 100)}%`,
											onBegin: tt("Floor shadow"),
											onChange: (e) => T.setSetting("ground", "shadow", e),
											onEnd: nt
										}),
										/* @__PURE__ */ X("label", {
											className: "gs-m3d__check",
											children: [
												/* @__PURE__ */ Y("input", {
													type: "checkbox",
													checked: O.background.transparent,
													onChange: (e) => T.setSetting("background", "transparent", e.target.checked, "Background")
												}),
												" ",
												"See-through background"
											]
										}),
										!O.background.transparent && /* @__PURE__ */ X("label", {
											className: "gs-m3d__colour",
											children: [
												/* @__PURE__ */ Y("input", {
													type: "color",
													value: O.background.color,
													onChange: (e) => T.setSetting("background", "color", e.target.value, "Background colour")
												}),
												" ",
												"Background colour"
											]
										}),
										/* @__PURE__ */ Y(o, { id: "m3dFloor" })
									] }),
									/* @__PURE__ */ Y($u, {
										editor: T,
										doc: O,
										aspect: Kt
									}),
									/* @__PURE__ */ X("section", { children: [
										/* @__PURE__ */ Y("h4", { children: "Camera" }),
										/* @__PURE__ */ Y(W, {
											label: "Projection",
											value: O.camera.projection,
											options: ["perspective", "orthographic"],
											labels: {
												perspective: "Perspective",
												orthographic: "Flat (no perspective)"
											},
											onChange: (e) => T.setSetting("camera", "projection", e, "Projection")
										}),
										O.camera.projection === "perspective" && /* @__PURE__ */ Y(U, {
											label: "Lens",
											value: O.camera.fov,
											min: 10,
											max: 90,
											step: 1,
											format: (e) => `${e}°`,
											onBegin: tt("Lens"),
											onChange: (e) => T.setSetting("camera", "fov", e),
											onEnd: nt
										}),
										/* @__PURE__ */ Y(o, { id: "m3dView" }),
										/* @__PURE__ */ Y(o, { id: "m3dPerf" }),
										/* @__PURE__ */ Y(o, { id: "m3dGrid" })
									] }),
									/* @__PURE__ */ Y(ka, {
										editor: T,
										camera: O.camera,
										shape: V,
										gesture: tt,
										end: nt
									}),
									/* @__PURE__ */ X("section", { children: [
										/* @__PURE__ */ Y("h4", { children: "Finish" }),
										i && /* @__PURE__ */ Y(o, { id: "m3dUse" }),
										/* @__PURE__ */ Y(o, { id: "m3dDesignFile" }),
										/* @__PURE__ */ Y(o, { id: "m3dSave" }),
										/* @__PURE__ */ Y(o, { id: "m3dSvg" }),
										/* @__PURE__ */ Y(o, { id: "m3dVideo" })
									] }),
									/* @__PURE__ */ Y(zc, {
										editor: T,
										target: {
											kind: "camera",
											doc: O
										},
										seconds: Re,
										onSeconds: on,
										time: Be,
										onTime: Ve,
										playing: Ae,
										onPlay: an
									})
								]
							}),
							/* @__PURE__ */ Y("footer", {
								className: "gs-m3d__foot",
								children: /* @__PURE__ */ Y(c, {})
							})
						]
					})
				]
			}),
			R === "outline" && /* @__PURE__ */ Y(ho, {
				onPick: st,
				onClose: () => z(null)
			}),
			R === "revolve" && /* @__PURE__ */ Y(ho, {
				revolve: !0,
				onPick: ft,
				onClose: () => z(null)
			}),
			R === "change-revolve" && /* @__PURE__ */ Y(ho, {
				revolve: !0,
				onPick: pt,
				onClose: () => z(null)
			}),
			R === "text" && /* @__PURE__ */ Y(vo, {
				onDone: gt,
				onClose: () => z(null)
			}),
			R === "edit-text" && V?.text && /* @__PURE__ */ Y(vo, {
				initial: V.text,
				onDone: vt,
				onClose: () => z(null)
			}),
			R === "edit-outline" && V?.pen && /* @__PURE__ */ Y(ho, {
				initial: V.pen,
				revolve: V.kind === "revolve",
				onPick: pt,
				onClose: () => z(null)
			}),
			R === "ad" && /* @__PURE__ */ Y(Ao, {
				start: d,
				onMake: bt,
				onClose: () => z(null)
			}),
			R === "avatar" && /* @__PURE__ */ Y(Ks, {
				base: w,
				start: Se,
				startTab: ve?.tab || void 0,
				onClose: () => z(null),
				onMake: (e, t, n, r) => {
					if (z(null), t === "replace" && ve) {
						let t = ve.at;
						H("Changing the character…", async () => {
							let { asset: n } = await v([e]);
							T.replaceModelAt(t, {
								...n,
								character: r
							}, "Change character");
						});
					} else t === "new" && T.replaceDesign({
						...ue(),
						shapes: []
					}, "New character"), Jt([e], n, { character: r });
				}
			}),
			R === "library" && w && /* @__PURE__ */ Y(Uu, {
				base: w,
				onPick: async (e, t) => {
					await Jt([e], `${t.name}, by ${t.author} (${t.from ?? "Poly Haven"}, ${t.licence}).`);
				},
				onClose: () => z(null)
			}),
			R === "scenes" && w && /* @__PURE__ */ Y(Wu, {
				base: w,
				onOpen: Ct,
				onClose: () => z(null)
			}),
			R === "photos" && /* @__PURE__ */ Y(No, {
				start: f,
				onClose: () => z(null),
				onMade: (e, t, n) => {
					z(null), Jt([e], `Made with ${n.name} from ${t.pictures === 1 ? "one photo" : `${t.pictures} photos`} in ${t.seconds} s. Generated: the back and sides are the model's guess, not photographed.`);
				}
			}),
			R === "render" && /* @__PURE__ */ Y(Eu, {
				design: T.document,
				aspect: Kt(),
				title: r,
				onClose: () => z(null)
			}),
			R === "export" && /* @__PURE__ */ Y(Su, {
				onClose: () => z(null),
				rigged: Xt() ? {
					name: Xt().name,
					person: ge(Xt().rig.bones) && !Ln(Xt().rig).length
				} : void 0,
				onExport: (e, t, n, r) => {
					z(null), H("Making the 3D model…", async () => {
						let i = Xt();
						if (i && e === "rigged") {
							bd(new Blob([kr(T.document, i)], { type: "model/gltf-binary" }), `${we}.glb`);
							return;
						}
						if (i && e === "vrm") {
							let e = en(T.document, i, {
								name: r.name,
								authors: r.author.trim() ? [r.author.trim()] : []
							});
							bd(new Blob([e], { type: "model/gltf-binary" }), `${we}.vrm`);
							return;
						}
						if (e === "rigged" || e === "vrm") return;
						if (e === "usdz") {
							let { designUsdz: e } = await import("./ar-De9J95gN.js").then((e) => e.t);
							bd(new Blob([await e(T.document, n)], { type: "model/vnd.usdz+zip" }), `${we}.usdz`);
							return;
						}
						let a = await jr(T.document, e, {
							cells: Mr[t],
							heightMm: n,
							onProgress: async (e) => {
								pe(`Making the 3D model… ${Math.round(e * 100)}%`), await new Promise((e) => setTimeout(e, 0));
							}
						});
						bd(new Blob([a], { type: e === "glb" ? "model/gltf-binary" : e === "obj" ? "text/plain" : "model/stl" }), `${we}.${e}`);
					});
				}
			}),
			R === "script" && /* @__PURE__ */ Y(zu, {
				editor: T,
				onClose: () => z(null)
			}),
			/* @__PURE__ */ Y(Ll, {
				open: Me,
				onClose: () => Ne(!1)
			}),
			/* @__PURE__ */ Y(s, {
				open: Pe,
				onClose: () => Fe(!1),
				prefer: ["3D mode"]
			}),
			Ie && /* @__PURE__ */ Y(ls, {
				onClose: () => Le(!1),
				onMake: (e) => {
					Le(!1), qe.api ? H("Adding the voice line…", async () => void await qe.api.addSound(e)) : bd(e, e.name);
				}
			}),
			R === "sequence" && /* @__PURE__ */ Y(Nu, {
				editor: T,
				title: r,
				onClose: () => z(null),
				run: H,
				setBusy: (e) => pe(e)
			}),
			R === "video" && /* @__PURE__ */ Y(Co, {
				initialKind: re(O) ? "still" : "turntable",
				initialSeconds: Re,
				moving: re(O),
				onMake: sn,
				onClose: () => z(null)
			})
		]
	});
}
function Sd({ open: e }) {
	return /* @__PURE__ */ X("svg", {
		width: "12",
		height: "12",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: 2.2,
		"aria-hidden": "true",
		children: [/* @__PURE__ */ Y("rect", {
			x: "5",
			y: "11",
			width: "14",
			height: "10",
			rx: "2"
		}), /* @__PURE__ */ Y("path", { d: e ? "M8 11V7a4 4 0 0 1 7.5-2" : "M8 11V7a4 4 0 0 1 8 0v4" })]
	});
}
async function Cd(e) {
	let t = await createImageBitmap(e), n = Math.min(1, 1600 / Math.max(t.width, t.height)), [r, i] = [Math.max(1, Math.round(t.width * n)), Math.max(1, Math.round(t.height * n))], a = document.createElement("canvas");
	a.width = r, a.height = i;
	let o = a.getContext("2d");
	o.drawImage(t, 0, 0, r, i), t.close();
	let s = o.getImageData(0, 0, r, i).data, c = 0;
	for (let e = 3; e < s.length; e += 16) s[e] < 128 && c++;
	let l = await new Promise((e, t) => a.toBlob((n) => n ? e(n) : t(/* @__PURE__ */ Error("The picture could not be read.")), "image/png"));
	return {
		bytes: new Uint8Array(await l.arrayBuffer()),
		width: r,
		height: i,
		seeThrough: c / (s.length / 16)
	};
}
//#endregion
export { pi as $, oa as A, fi as B, Yi as C, Li as D, Xi as E, Mi as F, ui as G, Si as H, ki as I, vi as J, Oi as K, Ni as L, Wi as M, Ki as N, ta as O, Zi as P, hi as Q, $r as R, Ri as S, ea as T, Ei as U, Di as V, wi as W, mi as X, di as Y, yi as Z, Ji as _, ya as a, sa as b, la as c, da as d, bi as et, Ii as f, Bi as g, zi as h, Ca as i, Gi as j, na as k, ha as l, Fi as m, sd as n, ma as o, Pi as p, Ci as q, Qu as r, ca as s, xd as t, ti as tt, ua as u, ia as v, Vi as w, Hi as x, ra as y, Qr as z };

//# sourceMappingURL=ModelMode-D8KMyCwU.js.map