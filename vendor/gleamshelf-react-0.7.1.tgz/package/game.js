import { u as e } from "./src-B9VqgbK-.js";
import { R as t, in as n } from "./core-AdQZWWr9.js";
import { t as r } from "./GamePlay-0VCcvge3.js";
/* empty css                 */
import { useEffect as i, useMemo as a, useRef as o, useState as s } from "react";
import { jsx as c, jsxs as l } from "react/jsx-runtime";
//#region src/model3d/GameOnly.tsx
function u({ game: u }) {
	let d = a(() => t(u), [u]), f = d.levels.find((e) => e.id === d.start) ?? d.levels[0], p = a(() => new n(f.design), [f]), m = o(null), [h, g] = s(null), [_, v] = s(null), [y, b] = s(!1);
	i(() => {
		if (m.current) try {
			let t = new e(m.current, p, {});
			return t.setGrid(0), g(t), () => {
				t.dispose(), g(null);
			};
		} catch (e) {
			v(e instanceof Error ? `3D drawing could not start: ${e.message}` : "3D drawing could not start on this computer.");
		}
	}, [p]);
	let x = a(() => ({
		project: d,
		open: (e, t) => {
			let n = d.levels.find((e) => e.id === t);
			n && p.replaceDesign(n.design, n.name);
		}
	}), [d, p]);
	return /* @__PURE__ */ l("div", {
		className: "gs-m3d__game-only",
		children: [
			/* @__PURE__ */ c("div", {
				className: "gs-m3d__game-stage",
				ref: m
			}),
			_ && /* @__PURE__ */ c("p", {
				className: "gs-m3d__note",
				children: _
			}),
			h && !y && /* @__PURE__ */ c(r, {
				editor: p,
				viewport: h,
				onStop: () => b(!0),
				project: x
			}),
			y && /* @__PURE__ */ l("div", {
				className: "gs-m3d__game-end",
				children: [/* @__PURE__ */ c("p", { children: d.credits || d.title }), /* @__PURE__ */ c("div", { children: /* @__PURE__ */ c("button", {
					type: "button",
					className: "gs-m3d__btn",
					onClick: () => b(!1),
					children: "Play again"
				}) })]
			})
		]
	});
}
//#endregion
export { u as GameOnly };

//# sourceMappingURL=game.js.map