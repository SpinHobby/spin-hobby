import { E as e, pt as t } from "./three.core-BCwsimN9.js";
//#region ../../node_modules/three/examples/jsm/loaders/TGALoader.js
var n = class extends e {
	constructor(e) {
		super(e);
	}
	parse(e) {
		function n(e) {
			switch (e.image_type) {
				case f:
				case h:
					if (e.colormap_length > 256 || e.colormap_size !== 24 || e.colormap_type !== 1) throw Error("THREE.TGALoader: Invalid type colormap data for indexed type.");
					break;
				case p:
				case m:
				case g:
				case _:
					if (e.colormap_type) throw Error("THREE.TGALoader: Invalid type colormap data for colormap type.");
					break;
				case d: throw Error("THREE.TGALoader: No data.");
				default: throw Error("THREE.TGALoader: Invalid type " + e.image_type);
			}
			if (e.width <= 0 || e.height <= 0) throw Error("THREE.TGALoader: Invalid image size.");
			if (e.pixel_size !== 8 && e.pixel_size !== 16 && e.pixel_size !== 24 && e.pixel_size !== 32) throw Error("THREE.TGALoader: Invalid pixel size " + e.pixel_size);
		}
		function r(e, t, n, r, i) {
			let a, o, s = n.pixel_size >> 3, c = n.width * n.height * s;
			if (t && (o = i.subarray(r, r += n.colormap_length * (n.colormap_size >> 3))), e) {
				a = new Uint8Array(c);
				let e, t, n, o = 0, l = new Uint8Array(s);
				for (; o < c;) if (e = i[r++], t = (e & 127) + 1, e & 128) {
					for (n = 0; n < s; ++n) l[n] = i[r++];
					for (n = 0; n < t; ++n) a.set(l, o + n * s);
					o += s * t;
				} else {
					for (t *= s, n = 0; n < t; ++n) a[o + n] = i[r++];
					o += t;
				}
			} else a = i.subarray(r, r += t ? n.width * n.height : c);
			return {
				pixel_data: a,
				palettes: o
			};
		}
		function i(e, t, n, r, i, a, o, s, c) {
			let l = c, u, d = 0, f, p, m = E.width;
			for (p = t; p !== r; p += n) for (f = i; f !== o; f += a, d++) u = s[d], e[(f + m * p) * 4 + 3] = 255, e[(f + m * p) * 4 + 2] = l[u * 3 + 0], e[(f + m * p) * 4 + 1] = l[u * 3 + 1], e[(f + m * p) * 4 + 0] = l[u * 3 + 2];
			return e;
		}
		function a(e, t, n, r, i, a, o, s) {
			let c, l = 0, u, d, f = E.width;
			for (d = t; d !== r; d += n) for (u = i; u !== o; u += a, l += 2) c = s[l + 0] + (s[l + 1] << 8), e[(u + f * d) * 4 + 0] = (c & 31744) >> 7, e[(u + f * d) * 4 + 1] = (c & 992) >> 2, e[(u + f * d) * 4 + 2] = (c & 31) << 3, e[(u + f * d) * 4 + 3] = c & 32768 ? 0 : 255;
			return e;
		}
		function o(e, t, n, r, i, a, o, s) {
			let c = 0, l, u, d = E.width;
			for (u = t; u !== r; u += n) for (l = i; l !== o; l += a, c += 3) e[(l + d * u) * 4 + 3] = 255, e[(l + d * u) * 4 + 2] = s[c + 0], e[(l + d * u) * 4 + 1] = s[c + 1], e[(l + d * u) * 4 + 0] = s[c + 2];
			return e;
		}
		function s(e, t, n, r, i, a, o, s) {
			let c = 0, l, u, d = E.width;
			for (u = t; u !== r; u += n) for (l = i; l !== o; l += a, c += 4) e[(l + d * u) * 4 + 2] = s[c + 0], e[(l + d * u) * 4 + 1] = s[c + 1], e[(l + d * u) * 4 + 0] = s[c + 2], e[(l + d * u) * 4 + 3] = s[c + 3];
			return e;
		}
		function c(e, t, n, r, i, a, o, s) {
			let c, l = 0, u, d, f = E.width;
			for (d = t; d !== r; d += n) for (u = i; u !== o; u += a, l++) c = s[l], e[(u + f * d) * 4 + 0] = c, e[(u + f * d) * 4 + 1] = c, e[(u + f * d) * 4 + 2] = c, e[(u + f * d) * 4 + 3] = 255;
			return e;
		}
		function l(e, t, n, r, i, a, o, s) {
			let c = 0, l, u, d = E.width;
			for (u = t; u !== r; u += n) for (l = i; l !== o; l += a, c += 2) e[(l + d * u) * 4 + 0] = s[c + 0], e[(l + d * u) * 4 + 1] = s[c + 0], e[(l + d * u) * 4 + 2] = s[c + 0], e[(l + d * u) * 4 + 3] = s[c + 1];
			return e;
		}
		function u(e, t, n, r, u) {
			let d, f, p, m, h, g;
			switch ((E.flags & v) >> y) {
				default:
				case S:
					d = 0, p = 1, h = t, f = 0, m = 1, g = n;
					break;
				case b:
					d = 0, p = 1, h = t, f = n - 1, m = -1, g = -1;
					break;
				case C:
					d = t - 1, p = -1, h = -1, f = 0, m = 1, g = n;
					break;
				case x: d = t - 1, p = -1, h = -1, f = n - 1, m = -1, g = -1;
			}
			if (k) switch (E.pixel_size) {
				case 8:
					c(e, f, m, g, d, p, h, r);
					break;
				case 16:
					l(e, f, m, g, d, p, h, r);
					break;
				default: throw Error("THREE.TGALoader: Format not supported.");
			}
			else switch (E.pixel_size) {
				case 8:
					i(e, f, m, g, d, p, h, r, u);
					break;
				case 16:
					a(e, f, m, g, d, p, h, r);
					break;
				case 24:
					o(e, f, m, g, d, p, h, r);
					break;
				case 32:
					s(e, f, m, g, d, p, h, r);
					break;
				default: throw Error("THREE.TGALoader: Format not supported.");
			}
			return e;
		}
		let d = 0, f = 1, p = 2, m = 3, h = 9, g = 10, _ = 11, v = 48, y = 4, b = 0, x = 1, S = 2, C = 3;
		if (e.length < 19) throw Error("THREE.TGALoader: Not enough data to contain header.");
		let w = 0, T = new Uint8Array(e), E = {
			id_length: T[w++],
			colormap_type: T[w++],
			image_type: T[w++],
			colormap_index: T[w++] | T[w++] << 8,
			colormap_length: T[w++] | T[w++] << 8,
			colormap_size: T[w++],
			origin: [T[w++] | T[w++] << 8, T[w++] | T[w++] << 8],
			width: T[w++] | T[w++] << 8,
			height: T[w++] | T[w++] << 8,
			pixel_size: T[w++],
			flags: T[w++]
		};
		if (n(E), E.id_length + w > e.length) throw Error("THREE.TGALoader: No data.");
		w += E.id_length;
		let D = !1, O = !1, k = !1;
		switch (E.image_type) {
			case 9:
				D = !0, O = !0;
				break;
			case 1:
				O = !0;
				break;
			case 10:
				D = !0;
				break;
			case 2: break;
			case 11:
				D = !0, k = !0;
				break;
			case 3: k = !0;
		}
		let A = new Uint8Array(E.width * E.height * 4), j = r(D, O, E, w, T);
		return u(A, E.width, E.height, j.pixel_data, j.palettes), {
			data: A,
			width: E.width,
			height: E.height,
			flipY: !0,
			generateMipmaps: !0,
			minFilter: t
		};
	}
};
//#endregion
export { n as TGALoader };

//# sourceMappingURL=TGALoader-0G2gSx5H.js.map