import { At as e, Kn as t, O as n, R as r, Sr as i, _t as a, g as o, h as s, sr as c, vt as l, zn as u } from "./three.core-BCwsimN9.js";
//#region ../../node_modules/three/examples/jsm/loaders/MTLLoader.js
var d = class extends a {
	constructor(e) {
		super(e);
	}
	load(e, t, n, i) {
		let a = this, o = this.path === "" ? l.extractUrlBase(e) : this.path, s = new r(this.manager);
		s.setPath(this.path), s.setRequestHeader(this.requestHeader), s.setWithCredentials(this.withCredentials), s.load(e, function(n) {
			try {
				t(a.parse(n, o));
			} catch (t) {
				i ? i(t) : console.error(t), a.manager.itemError(e);
			}
		}, n, i);
	}
	setMaterialOptions(e) {
		return this.materialOptions = e, this;
	}
	parse(e, t) {
		let n = e.split("\n"), r = {}, i = /\s+/, a = {};
		for (let e = 0; e < n.length; e++) {
			let t = n[e];
			if (t = t.trim(), t.length === 0 || t.charAt(0) === "#") continue;
			let o = t.indexOf(" "), s = o >= 0 ? t.substring(0, o) : t;
			s = s.toLowerCase();
			let c = o >= 0 ? t.substring(o + 1) : "";
			if (c = c.trim(), s === "newmtl") r = { name: c }, a[c] = r;
			else if (s === "ka" || s === "kd" || s === "ks" || s === "ke") {
				let e = c.split(i, 3);
				r[s] = [
					parseFloat(e[0]),
					parseFloat(e[1]),
					parseFloat(e[2])
				];
			} else r[s] = c;
		}
		let o = new f(this.resourcePath || t, this.materialOptions);
		return o.setCrossOrigin(this.crossOrigin), o.setManager(this.manager), o.setMaterials(a), o;
	}
}, f = class {
	constructor(e = "", t = {}) {
		this.baseUrl = e, this.options = t, this.materialsInfo = {}, this.materials = {}, this.materialsArray = [], this.nameLookup = {}, this.crossOrigin = "anonymous", this.side = this.options.side === void 0 ? 0 : this.options.side, this.wrap = this.options.wrap === void 0 ? u : this.options.wrap;
	}
	setCrossOrigin(e) {
		return this.crossOrigin = e, this;
	}
	setManager(e) {
		this.manager = e;
	}
	setMaterials(e) {
		this.materialsInfo = this.convert(e), this.materials = {}, this.materialsArray = [], this.nameLookup = {};
	}
	convert(e) {
		if (!this.options) return e;
		let t = {};
		for (let n in e) {
			let r = e[n], i = {};
			t[n] = i;
			for (let e in r) {
				let t = !0, n = r[e], a = e.toLowerCase();
				switch (a) {
					case "kd":
					case "ka":
					case "ks": this.options && this.options.normalizeRGB && (n = [
						n[0] / 255,
						n[1] / 255,
						n[2] / 255
					]), this.options && this.options.ignoreZeroRGBs && n[0] === 0 && n[1] === 0 && n[2] === 0 && (t = !1);
				}
				t && (i[a] = n);
			}
		}
		return t;
	}
	preload() {
		for (let e in this.materialsInfo) this.create(e);
	}
	getIndex(e) {
		return this.nameLookup[e];
	}
	getAsArray() {
		let e = 0;
		for (let t in this.materialsInfo) this.materialsArray[e] = this.create(t), this.nameLookup[t] = e, e++;
		return this.materialsArray;
	}
	create(e) {
		return this.materials[e] === void 0 && this.createMaterial_(e), this.materials[e];
	}
	createMaterial_(n) {
		let r = this, i = this.materialsInfo[n], a = {
			name: n,
			side: this.side
		};
		function c(e, t) {
			return typeof t != "string" || t === "" ? "" : /^https?:\/\//i.test(t) ? t : e + t;
		}
		function l(e, n) {
			if (a[e]) return;
			let i = r.getTextureParams(n, a), o = r.loadTexture(c(r.baseUrl, i.url));
			o.repeat.copy(i.scale), o.offset.copy(i.offset), o.wrapS = r.wrap, o.wrapT = r.wrap, (e === "map" || e === "emissiveMap") && (o.colorSpace = t), a[e] = o;
		}
		for (let e in i) {
			let n = i[e], r;
			if (n !== "") switch (e.toLowerCase()) {
				case "kd":
					a.color = o.colorSpaceToWorking(new s().fromArray(n), t);
					break;
				case "ks":
					a.specular = o.colorSpaceToWorking(new s().fromArray(n), t);
					break;
				case "ke":
					a.emissive = o.colorSpaceToWorking(new s().fromArray(n), t);
					break;
				case "map_kd":
					l("map", n);
					break;
				case "map_ks":
					l("specularMap", n);
					break;
				case "map_ke":
					l("emissiveMap", n);
					break;
				case "norm":
					l("normalMap", n);
					break;
				case "map_bump":
				case "bump":
					l("bumpMap", n);
					break;
				case "disp":
					l("displacementMap", n);
					break;
				case "map_d":
					l("alphaMap", n), a.transparent = !0;
					break;
				case "ns":
					a.shininess = parseFloat(n);
					break;
				case "d":
					r = parseFloat(n), r < 1 && (a.opacity = r, a.transparent = !0);
					break;
				case "tr": r = parseFloat(n), this.options && this.options.invertTrProperty && (r = 1 - r), r > 0 && (a.opacity = 1 - r, a.transparent = !0);
			}
		}
		return this.materials[n] = new e(a), this.materials[n];
	}
	getTextureParams(e, t) {
		let n = {
			scale: new i(1, 1),
			offset: new i(0, 0)
		}, r = e.split(/\s+/), a;
		return a = r.indexOf("-bm"), a >= 0 && (t.bumpScale = parseFloat(r[a + 1]), r.splice(a, 2)), a = r.indexOf("-mm"), a >= 0 && (t.displacementBias = parseFloat(r[a + 1]), t.displacementScale = parseFloat(r[a + 2]), r.splice(a, 3)), a = r.indexOf("-s"), a >= 0 && (n.scale.set(parseFloat(r[a + 1]), parseFloat(r[a + 2])), r.splice(a, 4)), a = r.indexOf("-o"), a >= 0 && (n.offset.set(parseFloat(r[a + 1]), parseFloat(r[a + 2])), r.splice(a, 4)), n.url = r.join(" ").trim(), n;
	}
	loadTexture(e, t, r, i, a) {
		let o = this.manager === void 0 ? n : this.manager, s = o.getHandler(e);
		s === null && (s = new c(o)), s.setCrossOrigin && s.setCrossOrigin(this.crossOrigin);
		let l = s.load(e, r, i, a);
		return t !== void 0 && (l.mapping = t), l;
	}
};
//#endregion
export { d as MTLLoader };

//# sourceMappingURL=MTLLoader-DgnhkxGj.js.map