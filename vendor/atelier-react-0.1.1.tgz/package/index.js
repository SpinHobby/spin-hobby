import { useEffect as e, useMemo as t, useRef as n, useState as r, useSyncExternalStore as i } from "react";
import { jsx as a, jsxs as o } from "react/jsx-runtime";
import { createPortal as s } from "react-dom";
//#region ../core/src/ops.ts
var c = [
	"free",
	"original",
	"1:1",
	"4:5",
	"3:4",
	"2:3",
	"16:9"
], l = (e) => ({
	kind: "number",
	label: e,
	min: -100,
	max: 100,
	step: 1,
	default: 0
}), u = (e, t) => ({
	kind: "number",
	label: e,
	min: 0,
	max: 1,
	step: .001,
	default: t,
	hidden: !0
}), d = [
	{
		type: "orient",
		label: "Orientation",
		group: "geometry",
		params: {
			quarterTurns: {
				kind: "number",
				label: "Quarter turns clockwise",
				min: 0,
				max: 3,
				step: 1,
				default: 0,
				hidden: !0
			},
			flipH: {
				kind: "boolean",
				label: "Flip horizontally",
				default: !1,
				hidden: !0
			},
			flipV: {
				kind: "boolean",
				label: "Flip vertically",
				default: !1,
				hidden: !0
			}
		}
	},
	{
		type: "straighten",
		label: "Straighten",
		group: "geometry",
		params: { angle: {
			kind: "number",
			label: "Straighten",
			min: -45,
			max: 45,
			step: .1,
			default: 0,
			unit: "°"
		} }
	},
	{
		type: "crop",
		label: "Crop",
		group: "geometry",
		params: {
			aspect: {
				kind: "choice",
				label: "Aspect ratio",
				options: c,
				default: "free",
				hidden: !0
			},
			x: u("Left", 0),
			y: u("Top", 0),
			width: u("Width", 1),
			height: u("Height", 1)
		}
	},
	{
		type: "light",
		label: "Light",
		group: "light",
		params: {
			exposure: {
				kind: "number",
				label: "Exposure",
				min: -3,
				max: 3,
				step: .01,
				default: 0,
				unit: " EV"
			},
			contrast: l("Contrast"),
			highlights: l("Highlights"),
			shadows: l("Shadows")
		}
	},
	{
		type: "color",
		label: "Color",
		group: "color",
		params: {
			temperature: l("Temperature"),
			tint: l("Tint"),
			vibrance: l("Vibrance"),
			saturation: l("Saturation")
		}
	},
	{
		type: "effects",
		label: "Effects",
		group: "effects",
		params: { vignette: l("Vignette") }
	}
], f = new Map(d.map((e) => [e.type, e]));
function p(e, t) {
	let n = f.get(e)?.params;
	return n && Object.hasOwn(n, t) ? n[t] : void 0;
}
function m(e, t) {
	switch (e.kind) {
		case "number": {
			if (typeof t != "number" || !Number.isFinite(t)) return;
			let n = Math.min(e.max, Math.max(e.min, t));
			return Number.isInteger(e.step) && e.step >= 1 ? Math.round(n) : n;
		}
		case "boolean": return typeof t == "boolean" ? t : void 0;
		case "choice": return typeof t == "string" && e.options.includes(t) ? t : void 0;
	}
}
function h(e) {
	return Object.fromEntries(Object.entries(e.params).map(([e, t]) => [e, t.default]));
}
function g() {
	return {
		version: 1,
		ops: Object.fromEntries(d.map((e) => [e.type, h(e)]))
	};
}
function _(e) {
	let t = g(), n = e?.ops;
	if (!n || typeof n != "object") return t;
	for (let e of d) {
		let r = n[e.type];
		if (r && typeof r == "object") for (let [n, i] of Object.entries(e.params)) {
			let a = m(i, r[n]);
			a !== void 0 && (t.ops[e.type][n] = a);
		}
	}
	return t;
}
function v(e, t, n) {
	let r = e.ops[t]?.[n];
	return typeof r == "number" ? r : 0;
}
function y(e, t, n) {
	return e.ops[t]?.[n] === !0;
}
function b(e, t, n) {
	let r = e.ops[t]?.[n];
	return typeof r == "string" ? r : "";
}
//#endregion
//#region ../core/src/document.ts
function x(e, t = g()) {
	if (!(e.width > 0 && e.height > 0)) throw Error("A photo needs a positive width and height.");
	return {
		schema: "atelier/photo",
		version: 1,
		source: { ...e },
		recipe: t
	};
}
function S(e, t) {
	return x(e, _(t));
}
//#endregion
//#region ../core/src/geometry.ts
var C = {
	a: 1,
	b: 0,
	c: 0,
	d: 1,
	e: 0,
	f: 0
}, w = (e) => ({
	...C,
	...e
});
function T(e, t) {
	return {
		a: e.a * t.a + e.c * t.b,
		b: e.b * t.a + e.d * t.b,
		c: e.a * t.c + e.c * t.d,
		d: e.b * t.c + e.d * t.d,
		e: e.a * t.e + e.c * t.f + e.e,
		f: e.b * t.e + e.d * t.f + e.f
	};
}
function E(e) {
	let { width: t, height: n } = e.source;
	return v(e.recipe, "orient", "quarterTurns") % 2 == 1 ? {
		width: n,
		height: t
	} : {
		width: t,
		height: n
	};
}
function D(e, t, n) {
	let r = Math.abs(n) * Math.PI / 180, i = Math.cos(r), a = Math.sin(r);
	return Math.max((e * i + t * a) / e, (e * a + t * i) / t);
}
function O(e) {
	let t = e.recipe;
	return {
		x: v(t, "crop", "x"),
		y: v(t, "crop", "y"),
		width: v(t, "crop", "width"),
		height: v(t, "crop", "height")
	};
}
function k(e, t) {
	let n = E(e), r = O(e), i = Math.max(1, r.width * n.width), a = Math.max(1, r.height * n.height);
	if (t && Math.max(i, a) > t) {
		let e = t / Math.max(i, a);
		i *= e, a *= e;
	}
	return {
		width: Math.max(1, Math.round(i)),
		height: Math.max(1, Math.round(a))
	};
}
function A(e) {
	let t = e.recipe, { width: n, height: r } = E(e), i = O(e), a = v(t, "straighten", "angle"), o = D(n, r, a), s = a * Math.PI / 180, c = Math.cos(s) / o, l = Math.sin(s) / o, u = [
		w({
			a: i.width,
			d: i.height,
			e: i.x,
			f: i.y
		}),
		w({
			a: n,
			d: r,
			e: -n / 2,
			f: -r / 2
		}),
		w({
			a: c,
			b: -l,
			c: l,
			d: c
		}),
		w({
			a: 1 / n,
			d: 1 / r,
			e: .5,
			f: .5
		})
	];
	y(t, "orient", "flipH") && u.push(w({
		a: -1,
		e: 1
	})), y(t, "orient", "flipV") && u.push(w({
		d: -1,
		f: 1
	}));
	for (let e = 0; e < v(t, "orient", "quarterTurns"); e++) u.push(w({
		a: 0,
		b: -1,
		c: 1,
		d: 0,
		f: 1
	}));
	return u.reduce((e, t) => T(t, e), C);
}
function j(e, t) {
	if (e === "original") return t.width / t.height;
	let n = /^(\d+):(\d+)$/.exec(e);
	return n ? Number(n[1]) / Number(n[2]) : null;
}
function M(e) {
	return j(b(e.recipe, "crop", "aspect"), E(e));
}
function ee(e) {
	let t = {
		...e.recipe.ops.crop,
		x: 0,
		y: 0,
		width: 1,
		height: 1
	};
	return {
		...e,
		recipe: {
			...e.recipe,
			ops: {
				...e.recipe.ops,
				crop: t
			}
		}
	};
}
function N(e, t) {
	let n = e.width / e.height, r = t < n ? t / n : 1, i = t < n ? 1 : n / t;
	return {
		x: (1 - r) / 2,
		y: (1 - i) / 2,
		width: r,
		height: i
	};
}
var P = .02, F = (e, t, n) => Math.min(n, Math.max(t, e));
function I(e, t, n, r, i, a) {
	if (t === "move") return {
		...e,
		x: F(e.x + n, 0, 1 - e.width),
		y: F(e.y + r, 0, 1 - e.height)
	};
	let o = t.includes("w"), s = t.includes("e"), c = t.includes("n"), l = t.includes("s"), u = e.x, d = e.y, f = e.x + e.width, p = e.y + e.height;
	if (a === null) return o && (u = F(u + n, 0, f - P)), s && (f = F(f + n, u + P, 1)), c && (d = F(d + r, 0, p - P)), l && (p = F(p + r, d + P, 1)), {
		x: u,
		y: d,
		width: f - u,
		height: p - d
	};
	let m = a * i.height / i.width, h = o || s, g = c || l, _ = o ? f : s ? u : (u + f) / 2, v = c ? p : l ? d : (d + p) / 2, y = o ? _ : s ? 1 - _ : 2 * Math.min(_, 1 - _), b = c ? v : l ? 1 - v : 2 * Math.min(v, 1 - v), x = e.width + (o ? -n : s ? n : 0), S = e.height + (c ? -r : l ? r : 0), C = h && g ? Math.max(x, S * m) : h ? x : S * m, w = Math.max(P, P * m);
	C = F(C, w, Math.min(y, b * m));
	let T = C / m;
	return {
		x: o ? _ - C : s ? _ : _ - C / 2,
		y: c ? v - T : l ? v : v - T / 2,
		width: C,
		height: T
	};
}
function L(e, t) {
	return t === 1 ? {
		x: 1 - e.y - e.height,
		y: e.x,
		width: e.height,
		height: e.width
	} : {
		x: e.y,
		y: 1 - e.x - e.width,
		width: e.height,
		height: e.width
	};
}
//#endregion
//#region ../core/src/history.ts
var R = class {
	limit;
	past = [];
	future = [];
	constructor(e = 200) {
		this.limit = e;
	}
	push(e) {
		this.past.push(e), this.past.length > this.limit && this.past.shift(), this.future = [];
	}
	undo() {
		let e = this.past.pop();
		return e && this.future.push(e), e;
	}
	redo() {
		let e = this.future.pop();
		return e && this.past.push(e), e;
	}
	clear() {
		this.past = [], this.future = [];
	}
	get canUndo() {
		return this.past.length > 0;
	}
	get canRedo() {
		return this.future.length > 0;
	}
	get undoLabel() {
		return this.past.at(-1)?.label;
	}
	get redoLabel() {
		return this.future.at(-1)?.label;
	}
};
//#endregion
//#region ../core/src/path.ts
function z(e) {
	return e.split("/").filter(Boolean);
}
function B(e, t) {
	let n = e;
	for (let e of z(t)) {
		if (typeof n != "object" || !n) return;
		n = n[e];
	}
	return n;
}
function V(e, t, n) {
	let r = z(t), i = (e, t) => {
		if (t === r.length) return n;
		let a = r[t], o = typeof e == "object" && e ? e : {}, s = Array.isArray(o) ? [...o] : { ...o };
		return s[a] = i(o[a], t + 1), s;
	};
	return i(e, 0);
}
//#endregion
//#region ../core/src/editor.ts
var H = (e, t) => `recipe/ops/${e}/${t}`;
function U(e) {
	let [t, n, r, i, ...a] = z(e);
	if (t === "recipe" && n === "ops" && r && i && !a.length) return p(r, i);
}
var te = class {
	doc;
	history = new R();
	gesture = null;
	snapshot;
	listeners = /* @__PURE__ */ new Set();
	constructor(e) {
		this.doc = e, this.snapshot = this.makeSnapshot();
	}
	getSnapshot = () => this.snapshot;
	subscribe = (e) => (this.listeners.add(e), () => this.listeners.delete(e));
	get document() {
		return this.doc;
	}
	set(e, t, n) {
		let r = U(e);
		if (!r) return "invalid-path";
		let i = m(r, t);
		return i === void 0 ? "invalid-value" : B(this.doc, e) === i ? "unchanged" : (this.apply(n ?? r.label, [[e, i]]), "ok");
	}
	begin(e) {
		this.commit(), this.gesture = {
			label: e,
			start: this.doc,
			changes: /* @__PURE__ */ new Map()
		};
	}
	commit() {
		let e = this.gesture;
		if (!e) return;
		this.gesture = null;
		let t = [...e.changes.values()].filter((e) => e.before !== e.after);
		t.length && this.history.push({
			label: e.label,
			changes: t
		}), this.emit();
	}
	cancel() {
		this.gesture && (this.doc = this.gesture.start, this.gesture = null, this.emit());
	}
	undo() {
		this.commit();
		let e = this.history.undo();
		return e ? (this.doc = [...e.changes].reverse().reduce((e, t) => V(e, t.path, t.before), this.doc), this.emit(), !0) : !1;
	}
	redo() {
		this.commit();
		let e = this.history.redo();
		return e ? (this.doc = e.changes.reduce((e, t) => V(e, t.path, t.after), this.doc), this.emit(), !0) : !1;
	}
	rotate(e) {
		let t = this.doc.recipe, n = (v(t, "orient", "quarterTurns") + e + 4) % 4, r = b(t, "crop", "aspect");
		this.apply(e === 1 ? "Rotate right" : "Rotate left", [
			[H("orient", "quarterTurns"), n],
			[H("orient", "flipH"), y(t, "orient", "flipV")],
			[H("orient", "flipV"), y(t, "orient", "flipH")],
			...this.cropValues(L(O(this.doc), e)),
			[H("crop", "aspect"), r === "original" || r === "1:1" ? r : "free"]
		]);
	}
	flip(e) {
		let t = O(this.doc), n = e === "horizontal", r = n ? "flipH" : "flipV";
		this.apply(n ? "Flip horizontally" : "Flip vertically", [[H("orient", r), !y(this.doc.recipe, "orient", r)], ...this.cropValues(n ? {
			...t,
			x: 1 - t.x - t.width
		} : {
			...t,
			y: 1 - t.y - t.height
		})]);
	}
	setCropAspect(e) {
		let t = j(e, E(this.doc));
		this.apply("Crop aspect", [[H("crop", "aspect"), e], ...t === null ? [] : this.cropValues(N(E(this.doc), t))]);
	}
	setCrop(e) {
		this.apply("Crop", this.cropValues(e));
	}
	reset() {
		let e = g(), t = Object.entries(e.ops).flatMap(([e, t]) => Object.entries(t).map(([t, n]) => [H(e, t), n]));
		this.apply("Reset", t);
	}
	load(e) {
		this.gesture = null, this.history.clear(), this.doc = e, this.emit();
	}
	cropValues(e) {
		let t = Math.min(1, Math.max(.001, e.width)), n = Math.min(1, Math.max(.001, e.height));
		return [
			[H("crop", "x"), Math.min(1 - t, Math.max(0, e.x))],
			[H("crop", "y"), Math.min(1 - n, Math.max(0, e.y))],
			[H("crop", "width"), t],
			[H("crop", "height"), n]
		];
	}
	apply(e, t) {
		let n = [], r = this.doc;
		for (let [e, i] of t) {
			let t = U(e), a = t && m(t, i);
			if (a === void 0) throw Error(`Invalid edit: ${e} = ${String(i)}`);
			let o = B(r, e);
			o !== a && (r = V(r, e, a), n.push({
				path: e,
				before: o,
				after: a
			}));
		}
		if (n.length) {
			if (this.doc = r, this.gesture) for (let e of n) {
				let t = this.gesture.changes.get(e.path);
				this.gesture.changes.set(e.path, {
					...e,
					before: t ? t.before : e.before
				});
			}
			else this.history.push({
				label: e,
				changes: n
			});
			this.emit();
		}
	}
	makeSnapshot() {
		return {
			doc: this.doc,
			canUndo: this.history.canUndo || !!this.gesture?.changes.size,
			canRedo: this.history.canRedo,
			undoLabel: this.history.undoLabel,
			redoLabel: this.history.redoLabel
		};
	}
	emit() {
		this.snapshot = this.makeSnapshot();
		for (let e of this.listeners) e();
	}
}, ne = "#version 300 es\nvoid main() {\n  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));\n  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);\n}", re = "#version 300 es\nprecision highp float;\n\nuniform sampler2D uSource;\nuniform mat3 uOutputToSource;\nuniform vec2 uOutputSize;\nuniform bool uFlipY;\n\nuniform float uExposure;   // stops\nuniform float uContrast;   // -1..1\nuniform float uHighlights; // -1..1\nuniform float uShadows;    // -1..1\nuniform vec3 uWhiteBalance; // per-channel gains, luminance-neutral\nuniform float uVibrance;   // -1..1\nuniform float uSaturation; // -1..1\nuniform float uVignette;   // -1..1\n\nout vec4 outColor;\n\nvec3 toLinear(vec3 c) {\n  return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), step(0.04045, c));\n}\n\nvec3 toDisplay(vec3 c) {\n  c = max(c, 0.0);\n  return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c));\n}\n\nfloat luma(vec3 c) {\n  return dot(c, vec3(0.2126, 0.7152, 0.0722));\n}\n\nvoid main() {\n  vec2 uv = gl_FragCoord.xy / uOutputSize;\n  if (uFlipY) uv.y = 1.0 - uv.y;\n\n  vec2 src = (uOutputToSource * vec3(uv, 1.0)).xy;\n  if (any(lessThan(src, vec2(0.0))) || any(greaterThan(src, vec2(1.0)))) {\n    outColor = vec4(0.0);\n    return;\n  }\n  vec4 texel = texture(uSource, src);\n\n  vec3 linear = toLinear(texel.rgb) * exp2(uExposure) * uWhiteBalance;\n  vec3 c = toDisplay(linear);\n\n  float y = luma(c);\n  c *= 1.0 + uShadows * 0.6 * (1.0 - smoothstep(0.0, 0.55, y));\n  c *= 1.0 + uHighlights * 0.5 * smoothstep(0.45, 1.0, y);\n  c = (c - 0.5) * (1.0 + uContrast * 0.8) + 0.5;\n\n  y = luma(c);\n  float chroma = max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b));\n  c = mix(vec3(y), c, 1.0 + uVibrance * (1.0 - clamp(chroma, 0.0, 1.0)));\n  c = mix(vec3(y), c, 1.0 + uSaturation);\n\n  float edge = smoothstep(0.35, 1.0, length(uv - 0.5) * 1.41421);\n  c *= 1.0 + uVignette * edge;\n\n  outColor = vec4(clamp(c, 0.0, 1.0), texel.a);\n}", ie = [
	"uSource",
	"uOutputToSource",
	"uOutputSize",
	"uFlipY",
	"uExposure",
	"uContrast",
	"uHighlights",
	"uShadows",
	"uWhiteBalance",
	"uVibrance",
	"uSaturation",
	"uVignette"
];
function W(e, t, n) {
	let r = e.createShader(t);
	if (e.shaderSource(r, n), e.compileShader(r), !e.getShaderParameter(r, e.COMPILE_STATUS)) {
		let t = e.getShaderInfoLog(r);
		throw e.deleteShader(r), Error(`Shader failed to compile: ${t}`);
	}
	return r;
}
function ae(e, t) {
	let n = e / 100, r = t / 100, i = [
		1 + .25 * n,
		1 - .2 * r,
		1 - .25 * n
	], a = .2126 * i[0] + .7152 * i[1] + .0722 * i[2];
	return i.map((e) => e / a);
}
function G(e, t, n) {
	return new Promise((r, i) => e.toBlob((e) => e ? r(e) : i(/* @__PURE__ */ Error("This browser could not encode the image.")), t, n));
}
var oe = class {
	canvas;
	maxTextureSize;
	gl;
	program;
	vao;
	uniforms;
	source = null;
	constructor(e) {
		this.canvas = e;
		let t = e.getContext("webgl2", {
			alpha: !0,
			premultipliedAlpha: !1,
			antialias: !1
		});
		if (!t) throw Error("This browser does not support WebGL2, which the editor needs.");
		this.gl = t, this.maxTextureSize = t.getParameter(t.MAX_TEXTURE_SIZE);
		let n = t.createProgram();
		if (t.attachShader(n, W(t, t.VERTEX_SHADER, ne)), t.attachShader(n, W(t, t.FRAGMENT_SHADER, re)), t.linkProgram(n), !t.getProgramParameter(n, t.LINK_STATUS)) throw Error(`Shader failed to link: ${t.getProgramInfoLog(n)}`);
		this.program = n, this.vao = t.createVertexArray(), this.uniforms = Object.fromEntries(ie.map((e) => [e, t.getUniformLocation(n, e)]));
	}
	setSource(e) {
		let t = this.gl;
		this.source && t.deleteTexture(this.source), this.source = t.createTexture(), t.bindTexture(t.TEXTURE_2D, this.source), t.pixelStorei(t.UNPACK_FLIP_Y_WEBGL, !1), t.pixelStorei(t.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !1), t.texImage2D(t.TEXTURE_2D, 0, t.RGBA8, t.RGBA, t.UNSIGNED_BYTE, e), t.generateMipmap(t.TEXTURE_2D), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MIN_FILTER, t.LINEAR_MIPMAP_LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MAG_FILTER, t.LINEAR), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_S, t.CLAMP_TO_EDGE), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_T, t.CLAMP_TO_EDGE);
	}
	draw(e, t, n) {
		this.canvas.width !== t && (this.canvas.width = t), this.canvas.height !== n && (this.canvas.height = n), this.gl.bindFramebuffer(this.gl.FRAMEBUFFER, null), this.render(e, t, n, !0);
	}
	async export(e, t = {}) {
		let n = this.gl, r = Math.min(this.maxTextureSize, n.getParameter(n.MAX_RENDERBUFFER_SIZE)), { width: i, height: a } = k(e, Math.min(t.maxSize ?? Infinity, r)), o = n.createTexture();
		n.bindTexture(n.TEXTURE_2D, o), n.texStorage2D(n.TEXTURE_2D, 1, n.RGBA8, i, a);
		let s = n.createFramebuffer();
		n.bindFramebuffer(n.FRAMEBUFFER, s), n.framebufferTexture2D(n.FRAMEBUFFER, n.COLOR_ATTACHMENT0, n.TEXTURE_2D, o, 0);
		let c = new Uint8ClampedArray(i * a * 4);
		try {
			this.render(e, i, a, !1), n.readPixels(0, 0, i, a, n.RGBA, n.UNSIGNED_BYTE, c);
		} finally {
			n.bindFramebuffer(n.FRAMEBUFFER, null), n.deleteFramebuffer(s), n.deleteTexture(o);
		}
		let l = t.type ?? "image/webp", u = document.createElement("canvas");
		u.width = i, u.height = a, u.getContext("2d").putImageData(new ImageData(c, i, a), 0, 0);
		let d = async (e, n) => {
			if (e !== "image/jpeg") return G(u, e, n);
			let r = document.createElement("canvas");
			r.width = i, r.height = a;
			let o = r.getContext("2d");
			return o.fillStyle = t.background ?? "#ffffff", o.fillRect(0, 0, i, a), o.drawImage(u, 0, 0), G(r, e, n);
		}, f = t.quality ?? .88, p = await d(l, f), m = p.type === l ? l : l === "image/webp" ? "image/jpeg" : p.type;
		if (m !== p.type && (p = await d(m, f)), t.maxBytes && m !== "image/png") for (; p.size > t.maxBytes && f > .4;) f -= .08, p = await d(m, f);
		return {
			blob: p,
			width: i,
			height: a,
			type: p.type
		};
	}
	dispose() {
		let e = this.gl;
		this.source && e.deleteTexture(this.source), e.deleteProgram(this.program), e.deleteVertexArray(this.vao), this.source = null;
	}
	render(e, t, n, r) {
		let i = this.gl, a = this.uniforms, o = e.recipe, s = A(e);
		i.viewport(0, 0, t, n), i.clearColor(0, 0, 0, 0), i.clear(i.COLOR_BUFFER_BIT), this.source && (i.useProgram(this.program), i.bindVertexArray(this.vao), i.activeTexture(i.TEXTURE0), i.bindTexture(i.TEXTURE_2D, this.source), i.uniform1i(a.uSource, 0), i.uniformMatrix3fv(a.uOutputToSource, !1, [
			s.a,
			s.b,
			0,
			s.c,
			s.d,
			0,
			s.e,
			s.f,
			1
		]), i.uniform2f(a.uOutputSize, t, n), i.uniform1i(a.uFlipY, +!!r), i.uniform1f(a.uExposure, v(o, "light", "exposure")), i.uniform1f(a.uContrast, v(o, "light", "contrast") / 100), i.uniform1f(a.uHighlights, v(o, "light", "highlights") / 100), i.uniform1f(a.uShadows, v(o, "light", "shadows") / 100), i.uniform3fv(a.uWhiteBalance, ae(v(o, "color", "temperature"), v(o, "color", "tint"))), i.uniform1f(a.uVibrance, v(o, "color", "vibrance") / 100), i.uniform1f(a.uSaturation, v(o, "color", "saturation") / 100), i.uniform1f(a.uVignette, v(o, "effects", "vignette") / 100), i.drawArrays(i.TRIANGLES, 0, 3));
	}
}, se = [
	"nw",
	"n",
	"ne",
	"e",
	"se",
	"s",
	"sw",
	"w"
], K = (e) => `${e * 100}%`;
function ce({ editor: e, doc: t, width: r, height: i }) {
	let s = n(null), c = O(t), l = (t) => (n) => {
		n.preventDefault(), n.stopPropagation(), n.currentTarget.setPointerCapture(n.pointerId), s.current = {
			handle: t,
			start: O(e.document),
			x: n.clientX,
			y: n.clientY
		}, e.begin(t === "move" ? "Move crop" : "Resize crop");
	}, u = (t) => {
		let n = s.current;
		if (!n) return;
		let a = e.document;
		e.setCrop(I(n.start, n.handle, (t.clientX - n.x) / r, (t.clientY - n.y) / i, E(a), M(a)));
	}, d = () => {
		s.current && (s.current = null, e.commit());
	};
	return /* @__PURE__ */ a("div", {
		className: "atl-crop",
		style: {
			width: r,
			height: i
		},
		onPointerMove: u,
		onPointerUp: d,
		onPointerCancel: d,
		children: /* @__PURE__ */ o("div", {
			className: "atl-crop__box",
			style: {
				left: K(c.x),
				top: K(c.y),
				width: K(c.width),
				height: K(c.height)
			},
			onPointerDown: l("move"),
			children: [/* @__PURE__ */ a("div", { className: "atl-crop__thirds" }), se.map((e) => /* @__PURE__ */ a("div", {
				className: `atl-crop__handle atl-crop__handle--${e}`,
				onPointerDown: l(e)
			}, e))]
		})
	});
}
//#endregion
//#region src/images.ts
var q;
function J() {
	if (q === void 0) {
		let e = document.createElement("canvas").getContext("webgl2");
		q = e ? e.getParameter(e.MAX_TEXTURE_SIZE) : 4096, e?.getExtension("WEBGL_lose_context")?.loseContext();
	}
	return q;
}
var Y = 2048;
async function le(e) {
	let t = URL.createObjectURL(e);
	try {
		let n = new Image();
		n.src = t, await n.decode();
		let r = n.naturalWidth || Y, i = n.naturalHeight || Y;
		if (e.type === "image/svg+xml") {
			let e = Y / Math.max(r, i);
			r = Math.round(r * e), i = Math.round(i * e);
		}
		let a = document.createElement("canvas");
		return a.width = r, a.height = i, a.getContext("2d").drawImage(n, 0, 0, r, i), await createImageBitmap(a);
	} catch {
		throw Error("This file couldn't be opened as an image. Try a JPEG, PNG or WebP.");
	} finally {
		URL.revokeObjectURL(t);
	}
}
async function X(e, t = J()) {
	let n;
	try {
		n = await createImageBitmap(e, { imageOrientation: "from-image" });
	} catch {
		n = await le(e);
	}
	let r = Math.max(n.width, n.height);
	if (r <= t) return n;
	let i = t / r, a = await createImageBitmap(n, {
		resizeWidth: Math.floor(n.width * i),
		resizeHeight: Math.floor(n.height * i),
		resizeQuality: "high"
	});
	return n.close(), a;
}
async function Z(e, t) {
	let n;
	try {
		n = await fetch(e, {
			mode: "cors",
			signal: t
		});
	} catch (e) {
		throw t?.aborted ? e : Error("The photo couldn't be downloaded. Its server may not allow other sites to read it (CORS).");
	}
	if (!n.ok) throw Error(`The photo couldn't be downloaded (${n.status}).`);
	return n.blob();
}
//#endregion
//#region src/Panel.tsx
var ue = {
	free: "Free",
	original: "Original",
	"1:1": "Square 1:1",
	"4:5": "Portrait 4:5",
	"3:4": "Portrait 3:4",
	"2:3": "Portrait 2:3",
	"16:9": "Wide 16:9"
};
function de(e, t) {
	let n = t.step < .1 ? 2 : +(t.step < 1);
	return `${e > 0 && t.min < 0 ? "+" : ""}${e.toFixed(n)}${t.unit ?? ""}`;
}
function fe({ editor: e, path: t, spec: n, value: r }) {
	return /* @__PURE__ */ o("label", {
		className: "atl-control",
		children: [/* @__PURE__ */ o("span", {
			className: "atl-control__row",
			children: [/* @__PURE__ */ a("span", { children: n.label }), /* @__PURE__ */ a("output", {
				className: r === n.default ? "" : "is-changed",
				children: de(r, n)
			})]
		}), /* @__PURE__ */ a("input", {
			type: "range",
			min: n.min,
			max: n.max,
			step: n.step,
			value: r,
			onPointerDown: () => e.begin(n.label),
			onPointerUp: () => e.commit(),
			onLostPointerCapture: () => e.commit(),
			onChange: (n) => e.set(t, Number(n.target.value)),
			onDoubleClick: () => e.set(t, n.default, `Reset ${n.label}`)
		})]
	});
}
function Q({ editor: e, type: t, name: n, spec: r, value: i }) {
	let s = `recipe/ops/${t}/${n}`;
	return r.kind === "number" ? /* @__PURE__ */ a(fe, {
		editor: e,
		path: s,
		spec: r,
		value: typeof i == "number" ? i : r.default
	}) : r.kind === "boolean" ? /* @__PURE__ */ o("label", {
		className: "atl-control atl-control--inline",
		children: [/* @__PURE__ */ a("input", {
			type: "checkbox",
			checked: i === !0,
			onChange: (t) => e.set(s, t.target.checked)
		}), r.label]
	}) : null;
}
function pe({ editor: e, doc: t, cropping: n, onToggleCrop: r }) {
	let i = b(t.recipe, "crop", "aspect");
	return /* @__PURE__ */ o("div", {
		className: "atl-panel",
		children: [/* @__PURE__ */ o("section", { children: [
			/* @__PURE__ */ a("h2", { children: "Geometry" }),
			/* @__PURE__ */ o("div", {
				className: "atl-button-row",
				children: [
					/* @__PURE__ */ a("button", {
						type: "button",
						className: "atl-button",
						onClick: () => e.rotate(-1),
						title: "Rotate left",
						children: "⟲ Left"
					}),
					/* @__PURE__ */ a("button", {
						type: "button",
						className: "atl-button",
						onClick: () => e.rotate(1),
						title: "Rotate right",
						children: "⟳ Right"
					}),
					/* @__PURE__ */ a("button", {
						type: "button",
						className: "atl-button",
						onClick: () => e.flip("horizontal"),
						children: "Flip ↔"
					}),
					/* @__PURE__ */ a("button", {
						type: "button",
						className: "atl-button",
						onClick: () => e.flip("vertical"),
						children: "Flip ↕"
					})
				]
			}),
			/* @__PURE__ */ o("div", {
				className: "atl-control",
				children: [/* @__PURE__ */ a("span", {
					className: "atl-control__row",
					children: /* @__PURE__ */ a("span", { children: "Crop" })
				}), /* @__PURE__ */ o("div", {
					className: "atl-crop-tools",
					children: [/* @__PURE__ */ a("button", {
						type: "button",
						className: `atl-button ${n ? "atl-button--primary" : ""}`,
						onClick: r,
						title: "Crop (C)",
						children: n ? "Done" : "Crop"
					}), /* @__PURE__ */ a("select", {
						"aria-label": "Aspect ratio",
						value: i,
						onChange: (t) => {
							e.setCropAspect(t.target.value), t.currentTarget.blur();
						},
						children: c.map((e) => /* @__PURE__ */ a("option", {
							value: e,
							children: ue[e]
						}, e))
					})]
				})]
			}),
			/* @__PURE__ */ a(Q, {
				editor: e,
				type: "straighten",
				name: "angle",
				spec: p("straighten", "angle"),
				value: t.recipe.ops.straighten?.angle
			})
		] }), d.filter((e) => e.group !== "geometry").map((n) => /* @__PURE__ */ o("section", { children: [/* @__PURE__ */ a("h2", { children: n.label }), Object.entries(n.params).filter(([, e]) => !e.hidden).map(([r, i]) => /* @__PURE__ */ a(Q, {
			editor: e,
			type: n.type,
			name: r,
			spec: i,
			value: t.recipe.ops[n.type]?.[r]
		}, r))] }, n.type))]
	});
}
//#endregion
//#region src/AtelierEditor.tsx
var me = {
	maxSize: 2048,
	type: "image/webp",
	quality: .88
}, $ = 32;
function he({ source: t, name: i, recipe: s, exportOptions: c, onDone: l, onCancel: u, doneLabel: d = "Done" }) {
	let [f, p] = r(null), [m, h] = r(null), g = n(s);
	return e(() => {
		let e = new AbortController(), n = null;
		return p(null), h(null), (async () => {
			try {
				if (n = await X(typeof t == "string" ? await Z(t, e.signal) : t), e.signal.aborted) return;
				let r = i ?? (t instanceof File ? t.name : typeof t == "string" ? t.split("/").pop()?.split("?")[0] : void 0), a = S({
					width: n.width,
					height: n.height,
					name: r
				}, g.current);
				p({
					image: n,
					editor: new te(a)
				});
			} catch (t) {
				e.signal.aborted || h(t instanceof Error ? t.message : "This photo couldn't be opened.");
			}
		})(), () => {
			e.abort(), n?.close();
		};
	}, [t, i]), m ? /* @__PURE__ */ o("div", {
		className: "atl-editor atl-editor--message",
		children: [/* @__PURE__ */ a("p", {
			className: "atl-error",
			children: m
		}), u && /* @__PURE__ */ a("button", {
			type: "button",
			className: "atl-button",
			onClick: u,
			children: "Close"
		})]
	}) : f ? /* @__PURE__ */ a(ge, {
		editor: f.editor,
		image: f.image,
		exportOptions: {
			...me,
			...c
		},
		onDone: l,
		onCancel: u,
		doneLabel: d
	}) : /* @__PURE__ */ a("div", {
		className: "atl-editor atl-editor--message",
		children: "Opening photo…"
	});
}
function ge({ editor: s, image: c, exportOptions: l, onDone: u, onCancel: d, doneLabel: f }) {
	let p = i(s.subscribe, s.getSnapshot), { doc: m } = p, h = n(null), g = n(null), _ = n(null), [v, y] = r(null), [b, S] = r({
		width: 0,
		height: 0
	}), [C, w] = r(!1), [T, E] = r(!1), [D, O] = r(!1), [A, j] = r(null);
	e(() => {
		try {
			let e = new oe(_.current);
			return e.setSource(c), y(e), () => e.dispose();
		} catch (e) {
			j(e instanceof Error ? e.message : "The preview could not start.");
		}
	}, [c]), e(() => {
		let e = new ResizeObserver(([e]) => {
			let { width: t, height: n } = e.contentRect;
			S({
				width: t,
				height: n
			});
		});
		return e.observe(g.current), h.current?.focus({ preventScroll: !0 }), () => e.disconnect();
	}, []);
	let M = t(() => C ? x(m.source) : T ? ee(m) : m, [
		C,
		T,
		m
	]), N = k(M), P = k(m, l.maxSize), F = Math.min((b.width - $) / N.width, (b.height - $) / N.height, 1), I = Math.max(1, Math.floor(N.width * F)), L = Math.max(1, Math.floor(N.height * F));
	e(() => {
		if (!v || b.width <= 0) return;
		let e = window.devicePixelRatio || 1, t = requestAnimationFrame(() => v.draw(M, Math.round(I * e), Math.round(L * e)));
		return () => cancelAnimationFrame(t);
	}, [
		v,
		M,
		I,
		L,
		b.width
	]);
	let R = (e) => {
		let t = e.target;
		if (t.tagName === "SELECT" || t.tagName === "INPUT" && t.type !== "range") return;
		let n = e.type === "keydown", r = e.ctrlKey || e.metaKey, i = e.key.toLowerCase();
		n && r && i === "z" ? (e.preventDefault(), e.shiftKey ? s.redo() : s.undo()) : n && r && i === "y" ? (e.preventDefault(), s.redo()) : e.key === "\\" ? w(n) : n && !r && i === "c" ? E((e) => !e) : n && (e.key === "Enter" || e.key === "Escape") && T && (e.preventDefault(), E(!1));
	}, z = async () => {
		if (v && !D) {
			O(!0), j(null);
			try {
				s.commit(), u({
					...await v.export(s.document, l),
					recipe: s.document.recipe,
					source: s.document.source
				});
			} catch (e) {
				j(e instanceof Error ? e.message : "The image could not be saved.");
			} finally {
				O(!1);
			}
		}
	};
	return /* @__PURE__ */ o("div", {
		className: "atl-editor",
		ref: h,
		tabIndex: -1,
		onKeyDown: R,
		onKeyUp: R,
		children: [
			/* @__PURE__ */ o("header", {
				className: "atl-toolbar",
				children: [
					d && /* @__PURE__ */ a("button", {
						type: "button",
						className: "atl-button",
						onClick: d,
						children: "Cancel"
					}),
					/* @__PURE__ */ a("span", { className: "atl-toolbar__divider" }),
					/* @__PURE__ */ a("button", {
						type: "button",
						className: "atl-button",
						disabled: !p.canUndo,
						onClick: () => s.undo(),
						title: p.undoLabel ? `Undo ${p.undoLabel} (Ctrl+Z)` : "Undo",
						children: "Undo"
					}),
					/* @__PURE__ */ a("button", {
						type: "button",
						className: "atl-button",
						disabled: !p.canRedo,
						onClick: () => s.redo(),
						title: p.redoLabel ? `Redo ${p.redoLabel} (Ctrl+Shift+Z)` : "Redo",
						children: "Redo"
					}),
					/* @__PURE__ */ a("button", {
						type: "button",
						className: "atl-button",
						onClick: () => s.reset(),
						children: "Reset"
					}),
					/* @__PURE__ */ a("button", {
						type: "button",
						className: `atl-button ${C ? "is-active" : ""}`,
						onPointerDown: () => w(!0),
						onPointerUp: () => w(!1),
						onPointerLeave: () => w(!1),
						title: "Hold to see the original (or hold \\)",
						children: "Compare"
					}),
					/* @__PURE__ */ a("span", { className: "atl-toolbar__spacer" }),
					/* @__PURE__ */ o("span", {
						className: "atl-toolbar__meta",
						children: [
							P.width,
							"×",
							P.height
						]
					}),
					/* @__PURE__ */ a("button", {
						type: "button",
						className: "atl-button atl-button--primary",
						disabled: !v || D,
						onClick: () => void z(),
						children: D ? "Saving…" : f
					})
				]
			}),
			/* @__PURE__ */ o("main", {
				className: "atl-stage",
				ref: g,
				children: [
					/* @__PURE__ */ o("div", {
						className: "atl-stage__frame",
						children: [/* @__PURE__ */ a("canvas", {
							ref: _,
							className: "atl-stage__canvas",
							style: {
								width: I,
								height: L
							}
						}), T && !C && /* @__PURE__ */ a(ce, {
							editor: s,
							doc: m,
							width: I,
							height: L
						})]
					}),
					C && /* @__PURE__ */ a("span", {
						className: "atl-stage__badge",
						children: "Original"
					}),
					T && !C && /* @__PURE__ */ a("span", {
						className: "atl-stage__badge",
						children: "Cropping · Enter when done"
					}),
					A && /* @__PURE__ */ a("p", {
						className: "atl-error atl-stage__error",
						children: A
					})
				]
			}),
			/* @__PURE__ */ a("aside", {
				className: "atl-sidebar",
				children: /* @__PURE__ */ a(pe, {
					editor: s,
					doc: m,
					cropping: T,
					onToggleCrop: () => E((e) => !e)
				})
			})
		]
	});
}
//#endregion
//#region src/AtelierEditorModal.tsx
function _e({ open: t, ...n }) {
	return e(() => {
		if (!t) return;
		let e = document.body.style.overflow;
		return document.body.style.overflow = "hidden", () => {
			document.body.style.overflow = e;
		};
	}, [t]), t ? s(/* @__PURE__ */ a("div", {
		className: "atl-modal",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Edit photo",
		children: /* @__PURE__ */ a(he, { ...n })
	}), document.body) : null;
}
//#endregion
export { he as AtelierEditor, _e as AtelierEditorModal, X as decodePhoto, Z as fetchPhoto, J as gpuMaxTextureSize };

//# sourceMappingURL=index.js.map