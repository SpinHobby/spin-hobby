import { type Editor, type PhotoDocument } from '../../core/src/index.js';
interface Props {
    editor: Editor;
    doc: PhotoDocument;
    cropping: boolean;
    onToggleCrop: () => void;
}
/** Controls generated from the op definitions, plus dedicated tools for orientation and crop. */
export declare function Panel({ editor, doc, cropping, onToggleCrop }: Props): import("react").JSX.Element;
export {};
