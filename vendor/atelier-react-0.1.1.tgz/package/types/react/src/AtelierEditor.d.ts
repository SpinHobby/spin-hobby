import { type Recipe, type SourceInfo } from '../../core/src/index.js';
import { type ExportOptions, type ExportResult } from '../../render2d/src/index.js';
import './atelier.css';
export interface AtelierResult extends ExportResult {
    /** Save this next to the image; pass it back as `recipe` to continue editing from the original. */
    recipe: Recipe;
    source: SourceInfo;
}
export interface AtelierEditorProps {
    /** The original photo: a File/Blob, or a URL whose server allows cross-origin reads (CORS). */
    source: Blob | string;
    /** File name, kept in the result. Taken from the File when not given. */
    name?: string;
    /** A recipe from an earlier result, to reopen that edit. */
    recipe?: unknown;
    /** Size and format of the finished image; the host's own upload limits belong here. */
    exportOptions?: ExportOptions;
    onDone: (result: AtelierResult) => void;
    onCancel?: () => void;
    doneLabel?: string;
}
/**
 * The whole editor: opens `source`, lets the user edit it, and calls `onDone` with the finished image and
 * its recipe. It fills its container, so give the container a height (or use AtelierEditorModal).
 */
export declare function AtelierEditor({ source, name, recipe, exportOptions, onDone, onCancel, doneLabel }: AtelierEditorProps): import("react").JSX.Element;
