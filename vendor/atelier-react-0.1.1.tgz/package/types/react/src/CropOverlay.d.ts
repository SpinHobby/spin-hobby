import { type Editor, type PhotoDocument } from '../../core/src/index.js';
interface Props {
    editor: Editor;
    doc: PhotoDocument;
    /** On-screen size of the whole (uncropped) frame the box is drawn over. */
    width: number;
    height: number;
}
/**
 * The crop box drawn over the uncropped photo. Dragging its inside moves it, its edges and corners resize it;
 * a locked aspect ratio is kept. Each drag is one undo step.
 */
export declare function CropOverlay({ editor, doc, width, height }: Props): import("react").JSX.Element;
export {};
