import { type AtelierEditorProps } from './AtelierEditor';
export interface AtelierEditorModalProps extends AtelierEditorProps {
    open: boolean;
}
/** The editor full-screen over the host page. Closing is up to the host: `onDone` / `onCancel` set `open` to false. */
export declare function AtelierEditorModal({ open, ...props }: AtelierEditorModalProps): import("react").ReactPortal | null;
