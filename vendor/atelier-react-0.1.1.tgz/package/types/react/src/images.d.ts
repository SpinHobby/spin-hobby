/** The largest texture this device's GPU accepts (often 4096 on phones, 16384 on desktops). */
export declare function gpuMaxTextureSize(): number;
/** Decodes a photo with its EXIF orientation applied, shrinking it if the GPU can't hold it at full size. */
export declare function decodePhoto(file: Blob, maxTextureSize?: number): Promise<ImageBitmap>;
/**
 * Fetches a photo by URL. The server must allow cross-origin reads (CORS), otherwise the browser forbids
 * the editor from reading its pixels.
 */
export declare function fetchPhoto(url: string, signal?: AbortSignal): Promise<Blob>;
