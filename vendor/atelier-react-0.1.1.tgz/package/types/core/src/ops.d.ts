export type ParamValue = number | boolean | string;
interface ParamBase {
    label: string;
    /** Edited by a dedicated tool (rotate buttons, crop box) rather than a generic control. */
    hidden?: boolean;
}
export interface NumberParam extends ParamBase {
    kind: 'number';
    min: number;
    max: number;
    /** Granularity of the UI control. Values are only clamped, never snapped, except whole-number params. */
    step: number;
    default: number;
    unit?: string;
}
export interface BooleanParam extends ParamBase {
    kind: 'boolean';
    default: boolean;
}
export interface ChoiceParam extends ParamBase {
    kind: 'choice';
    options: readonly string[];
    default: string;
}
export type ParamSpec = NumberParam | BooleanParam | ChoiceParam;
export type OpGroup = 'geometry' | 'light' | 'color' | 'effects';
export interface OpDefinition {
    type: string;
    label: string;
    group: OpGroup;
    params: Readonly<Record<string, ParamSpec>>;
}
export declare const CROP_ASPECTS: readonly ["free", "original", "1:1", "4:5", "3:4", "2:3", "16:9"];
export type CropAspect = (typeof CROP_ASPECTS)[number];
/**
 * Every edit the editor knows, in the order the pipeline applies them. Each op appears once in a recipe;
 * an op at its defaults changes nothing.
 */
export declare const OPS: readonly OpDefinition[];
export declare function findOp(type: string): OpDefinition | undefined;
export declare function findParam(type: string, name: string): ParamSpec | undefined;
/** A valid value for `spec`, or undefined when `value` has the wrong type. Numbers are clamped into range. */
export declare function coerceParam(spec: ParamSpec, value: unknown): ParamValue | undefined;
export {};
