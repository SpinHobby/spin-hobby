import type { PhotoDocument } from './document.js';
import { type CropRect } from './geometry.js';
import { type CropAspect } from './ops.js';
import { type Path } from './path.js';
export type SetStatus = 'ok' | 'unchanged' | 'invalid-path' | 'invalid-value';
/** What a UI needs to render: replaced (never mutated) whenever anything changes. */
export interface EditorSnapshot {
    doc: PhotoDocument;
    canUndo: boolean;
    canRedo: boolean;
    undoLabel?: string;
    redoLabel?: string;
}
/**
 * Owns one photo document and its undo history. Everything that edits the document goes through here, by
 * path (`set('recipe/ops/light/exposure', 0.5)`) or by a named command (`rotate(1)`), so a UI, a keyboard
 * shortcut, a test or, later, an AI tool call all edit the same way.
 *
 * Dragging a slider should be wrapped in `begin()` … `commit()`: the preview updates on every move, but
 * the whole drag becomes a single undo step.
 */
export declare class Editor {
    private doc;
    private readonly history;
    private gesture;
    private snapshot;
    private readonly listeners;
    constructor(doc: PhotoDocument);
    /** Stable between changes; suitable for React's useSyncExternalStore. */
    getSnapshot: () => EditorSnapshot;
    subscribe: (listener: () => void) => (() => void);
    get document(): PhotoDocument;
    /** Sets one recipe parameter. Numbers are clamped into range; a wrong type is rejected. */
    set(path: Path, value: unknown, label?: string): SetStatus;
    /** Starts a continuous edit (a slider drag). Changes until `commit()` become one undo step. */
    begin(label: string): void;
    commit(): void;
    /** Abandons the current continuous edit and restores the document as it was when it began. */
    cancel(): void;
    undo(): boolean;
    redo(): boolean;
    /** Turns the photo a quarter clockwise (+1) or anticlockwise (−1), carrying the crop and flips along. */
    rotate(direction: 1 | -1): void;
    flip(axis: 'horizontal' | 'vertical'): void;
    /** Chooses a crop aspect ratio and replaces the crop with the largest centred rectangle of that ratio. */
    setCropAspect(aspect: CropAspect): void;
    setCrop(crop: CropRect): void;
    /** Removes every edit, as one undoable step. */
    reset(): void;
    /** Replaces the document entirely (another photo) and forgets the undo history. */
    load(doc: PhotoDocument): void;
    private cropValues;
    /** Validates and applies several values as one step (merged into the gesture if one is open). */
    private apply;
    private makeSnapshot;
    private emit;
}
