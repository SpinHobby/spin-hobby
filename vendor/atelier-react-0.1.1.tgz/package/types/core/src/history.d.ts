import type { Path } from './path.js';
export interface Change {
    path: Path;
    before: unknown;
    after: unknown;
}
/** One undoable user action, possibly touching several values (e.g. rotating also moves the crop). */
export interface HistoryEntry {
    label: string;
    changes: Change[];
}
export declare class History {
    private readonly limit;
    private past;
    private future;
    constructor(limit?: number);
    push(entry: HistoryEntry): void;
    undo(): HistoryEntry | undefined;
    redo(): HistoryEntry | undefined;
    clear(): void;
    get canUndo(): boolean;
    get canRedo(): boolean;
    /** Label of the action Undo would revert, for menus and tooltips. */
    get undoLabel(): string | undefined;
    get redoLabel(): string | undefined;
}
