import { type Recipe } from './recipe.js';
export interface SourceInfo {
    /** Pixel size of the original after EXIF orientation is applied. */
    width: number;
    height: number;
    name?: string;
}
/** One photo being edited: what the original is, and the recipe applied to it. */
export interface PhotoDocument {
    schema: 'atelier/photo';
    version: 1;
    source: SourceInfo;
    recipe: Recipe;
}
export declare function createDocument(source: SourceInfo, recipe?: Recipe): PhotoDocument;
/** Rebuilds a document from saved JSON, repairing the recipe; the source size must be supplied by whoever has the image. */
export declare function loadDocument(source: SourceInfo, savedRecipe: unknown): PhotoDocument;
