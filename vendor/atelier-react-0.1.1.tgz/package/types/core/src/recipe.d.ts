import { type ParamValue } from './ops.js';
export declare const RECIPE_VERSION = 1;
export type OpParams = Record<string, ParamValue>;
/**
 * Everything done to one photo, as plain JSON. Rendering a recipe over the untouched original always gives
 * the same result, so hosts can store it and reopen the edit later.
 */
export interface Recipe {
    version: typeof RECIPE_VERSION;
    ops: Record<string, OpParams>;
}
export declare function defaultRecipe(): Recipe;
/**
 * Reads a recipe from untrusted JSON (a host's database, an older editor version): unknown ops and params are
 * dropped, missing or invalid values fall back to defaults, numbers are clamped into range.
 */
export declare function normalizeRecipe(input: unknown): Recipe;
export declare function isDefaultRecipe(recipe: Recipe): boolean;
export declare function readNumber(recipe: Recipe, type: string, name: string): number;
export declare function readBoolean(recipe: Recipe, type: string, name: string): boolean;
export declare function readChoice(recipe: Recipe, type: string, name: string): string;
