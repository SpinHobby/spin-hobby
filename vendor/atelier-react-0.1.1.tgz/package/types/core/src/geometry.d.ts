import type { PhotoDocument } from './document.js';
/**
 * A 2D affine map: x' = a·x + c·y + e, y' = b·x + d·y + f (the same layout as DOMMatrix).
 * Image coordinates have y pointing down.
 */
export interface Affine {
    a: number;
    b: number;
    c: number;
    d: number;
    e: number;
    f: number;
}
export interface Size {
    width: number;
    height: number;
}
/** A rectangle in normalized (0–1) coordinates of the oriented, straightened frame. */
export interface CropRect {
    x: number;
    y: number;
    width: number;
    height: number;
}
export declare const IDENTITY: Affine;
/** `outer` applied after `inner`. */
export declare function compose(outer: Affine, inner: Affine): Affine;
export declare function applyAffine(m: Affine, x: number, y: number): [number, number];
/** Size of the photo after quarter turns, before straightening and cropping. */
export declare function frameSize(doc: PhotoDocument): Size;
/**
 * How much a straightened photo is enlarged so that, rotated by `angleDeg`, it still covers its whole frame
 * (no empty corners), as photo editors do.
 */
export declare function coverScale(width: number, height: number, angleDeg: number): number;
export declare function cropRect(doc: PhotoDocument): CropRect;
/** Pixel size of the finished image, optionally shrunk so its longest side is at most `maxSize`. */
export declare function outputSize(doc: PhotoDocument, maxSize?: number): Size;
/**
 * Maps a point of the finished image (normalized 0–1) to the point of the original it shows (normalized 0–1).
 * The renderer evaluates this per pixel; it is the whole geometry pipeline: crop, straighten, flips, turns.
 */
export declare function outputToSource(doc: PhotoDocument): Affine;
/** Width ÷ height for an aspect choice, or null for `free`. */
export declare function aspectRatio(aspect: string, frame: Size): number | null;
/** The width ÷ height the crop is locked to, or null when it is free. */
export declare function lockedCropRatio(doc: PhotoDocument): number | null;
/** The same document showing the whole frame, for drawing the photo behind a crop box while cropping. */
export declare function withoutCrop(doc: PhotoDocument): PhotoDocument;
/** The largest centred crop with the given width ÷ height ratio. */
export declare function centeredCrop(frame: Size, ratio: number): CropRect;
/** The part of the crop box being dragged: its inside, an edge, or a corner (by compass direction). */
export type CropHandle = 'move' | 'n' | 's' | 'e' | 'w' | 'ne' | 'nw' | 'se' | 'sw';
/** Smallest crop side, as a fraction of the frame. */
export declare const MIN_CROP = 0.02;
/**
 * The crop after dragging `handle` by (`dx`, `dy`) from where the drag started, in normalized frame units.
 * `ratio` locks width ÷ height in *pixels* (needs the frame size to convert); null leaves it free.
 * The result always stays inside the frame and no smaller than MIN_CROP.
 */
export declare function dragCrop(start: CropRect, handle: CropHandle, dx: number, dy: number, frame: Size, ratio: number | null): CropRect;
/** Where a crop rectangle lands after the frame turns a quarter clockwise (+1) or anticlockwise (−1). */
export declare function turnCrop(crop: CropRect, direction: 1 | -1): CropRect;
