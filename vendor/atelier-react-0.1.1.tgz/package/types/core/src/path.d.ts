/** A slash-separated address into a document, e.g. `recipe/ops/light/exposure`. */
export type Path = string;
export declare function splitPath(path: Path): string[];
export declare function getAt(root: unknown, path: Path): unknown;
/** Returns a copy of `root` with the value at `path` replaced. Branches off the path are shared, not copied. */
export declare function setAt<T>(root: T, path: Path, value: unknown): T;
