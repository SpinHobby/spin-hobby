import { type PhotoDocument } from '../../core/src/index.js';
export type ExportType = 'image/webp' | 'image/jpeg' | 'image/png';
export interface ExportOptions {
    /** Longest side of the result in pixels; the full cropped resolution when omitted. */
    maxSize?: number;
    type?: ExportType;
    /** 0–1, for WebP and JPEG. */
    quality?: number;
    /** Lowers the quality step by step until the file fits (WebP and JPEG only). */
    maxBytes?: number;
    /** Fill behind transparent areas when the format has no transparency (JPEG). */
    background?: string;
}
export interface ExportResult {
    blob: Blob;
    width: number;
    height: number;
    /** The format actually produced: browsers without a WebP encoder fall back to JPEG. */
    type: string;
}
/**
 * Draws photo documents with WebGL2. One renderer owns one canvas (the on-screen preview) and one source
 * image; exports render offscreen at the export size, so the preview and the file use the exact same shader.
 */
export declare class Renderer {
    private readonly canvas;
    readonly maxTextureSize: number;
    private readonly gl;
    private readonly program;
    private readonly vao;
    private readonly uniforms;
    private source;
    constructor(canvas: HTMLCanvasElement);
    /**
     * Uploads the original photo. Its size must not exceed `maxTextureSize`; callers decode large photos
     * smaller first (createImageBitmap with resizeWidth/resizeHeight).
     */
    setSource(image: TexImageSource): void;
    /** Draws the document onto the preview canvas at `width` × `height` device pixels. */
    draw(doc: PhotoDocument, width: number, height: number): void;
    /** Renders the finished image offscreen and encodes it. */
    export(doc: PhotoDocument, options?: ExportOptions): Promise<ExportResult>;
    dispose(): void;
    private render;
}
